from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Route to serve the HTML frontend
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle the "Send Now" button click
@app.route('/send', methods=['POST'])
def send_crypto():
    data = request.get_json()
    
    network = data.get('network')
    address = data.get('address')
    amount = data.get('amount')

    # Basic validation
    if not address or not amount:
        return jsonify({'error': 'Missing address or amount'}), 400

    # Here is where you would integrate with a real crypto API 
    # (like BlockCypher, Blockchain.com, or a private node)
    # For now, we simulate a success response.
    
    print(f"Sending {amount} on {network} to {address}")

    # Simulate processing time
    # In a real app, you'd call an API here
    
    return jsonify({
        'message': f'Successfully sent {amount} {network} to {address}',
        'tx_id': 'simulated_tx_hash_12345'
    }), 200

if __name__ == '__main__':
    # Run the server
    app.run(host='0.0.0.0', port=5000, debug=True)