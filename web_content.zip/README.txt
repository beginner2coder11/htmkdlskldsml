HOTEL HR MANAGER — PERFORMANCE, BACKUP & EXPORT UPGRADE
======================================================

Files: index.html, style.css, app.js, performance-management-plan.json, README.txt

WHAT'S NEW
- Faster first load: OCR library is loaded only when you choose to analyse a paper.
- Smaller scanned images: images are resized and compressed before saving to reduce storage usage and speed up saving.
- Local JSON backup download, with a safety backup automatically downloaded before importing/restoring.
- Import/restore a previous JSON backup.
- Import employee records from CSV (headings such as Name, Staff ID, Department, Job title, Start date, Probation end, Phone, Email are supported).
- Export HR records to a multi-sheet Excel workbook (.xlsx), including employees, onboarding, training, appraisals, counselling, disciplinary, documents and scan metadata. Image blobs are not embedded in Excel.
- Download individual scanned paper attachments from saved scans and employee-linked records.
- Google Drive cloud backup/restore in the app's private app-data area. This requires the operator to configure a Google Cloud project, enable Google Drive API, create a Web OAuth Client ID, and add the exact app origin. No Gmail password is requested or stored. OAuth access only lasts for the current session; reconnect after reopening the app. Cloud backup is manual, not automatic background sync.
- Import & updates page with ZIP/APK update instructions and pre-update backup button.

DEMO LOGIN
Username: admin
Password: admin123

GOOGLE DRIVE SETUP
1. In Google Cloud Console, create/select a project and enable Google Drive API.
2. Configure OAuth consent and create an OAuth Client ID of type Web application.
3. Add the exact website origin where this app runs under authorised JavaScript origins. A file:// origin or arbitrary APK wrapper origin may not work; the app should be hosted at a stable HTTPS origin for Google OAuth.
4. Paste the Web Client ID into Reports & backup > Google Drive cloud backup, then select Connect Google account.
5. Upload cloud backup. Use Find cloud backups to list and restore saved copies.

PERFORMANCE / STORAGE
- This prototype uses localStorage on the device/browser. It is not a full production database and may have storage limits. If you get a storage warning, download a backup and remove unnecessary large scans.
- Local data can be lost if you uninstall the APK, clear app data, change the app's web origin, or use a different wrapper/package. Always keep a verified backup.
- OCR needs internet the first time it is loaded and may be slow on low-memory phones. The scan text and suggestions must be checked by a human.

UPDATING FROM ZIP OR APK
- ZIP/web app: back up first, extract the ZIP, then deploy/replace the web app files in the same hosted location/origin. Keep the same local data key and do not clear browser/app storage.
- APK: back up first, then install the new APK over the old one. Android requires the same package ID and signing certificate. If the APK is signed differently or uses a different package ID, Android may refuse an in-place update; uninstalling can erase local data. This HTML app cannot self-install an APK or safely rewrite its own executable files, so Android's installer must handle APK updates.

SECURITY WARNING
This is still a prototype. Demo login is not secure authentication. Do not store sensitive employee records in production without real user authentication, role-based access, encryption, audit logging, managed backups, and appropriate HR/privacy controls. Keep backups secure because they contain confidential employee information.
