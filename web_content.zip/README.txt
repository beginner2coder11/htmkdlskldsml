نظام محمد زهيران - النسخة المصححة
====================================
تم وضع ملفات التطبيق داخل:
web/index.html
web/sw.js
web/manifest.webmanifest

هذه البنية مخصصة لتطبيقات Android WebView التي تبحث عن:
appassets.androidplatform.net/web/index.html

إذا كان منشئ APK عندك يطلب مجلد web، استخدم مجلد web كما هو.
