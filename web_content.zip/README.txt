OTP Viet TalkBack - ban thu nghiem goi API OTPVN truc tiep

Cach dung:
1. Giai nen ZIP hoac tai ZIP nay len cong cu dong goi website thanh APK.
2. Dam bao index.html nam o thu muc goc cua goi.
3. Cai APK, nhap token OTPVN cua ban va bam Kiem tra ket noi.

API duoc goi truc tiep tu app: https://api.otpvn.com
Token chi duoc giu trong bo nho cua trang va khong tu dong luu vao localStorage.
Tuy nhien, token nhap trong ung dung client khong an toan bang may chu trung gian; khong chia se APK co token duoc dong cung.

Luu y quan trong:
- Tai khoan OTPVN phai duoc bat quyen API.
- Neu bao loi CORS/khong ket noi, cong cu dong goi co the chua cho phep WebView goi API. Khi do can APK co cau hinh mang/WebView phu hop hoac may chu trung gian; sua JavaScript don thuan khong the vuot qua CORS.
- Thu so co the tru tien. Chi bam thue khi ban chap nhan gia va dieu kien.
- Lich su trong ban nay tai 30 ngay gan nhat cho dich vu da chon.
