KendaraanKu - Web App
Isi utama: index.html
Tidak memakai URL eksternal/CDN.
Data tersimpan lokal melalui localStorage.
Fitur: kendaraan, jadwal perawatan, riwayat, biaya, edit/hapus, date picker, status servis.
Catatan: notifikasi Android native yang tetap berjalan setelah aplikasi ditutup memerlukan wrapper/converter yang mendukung native notifications.
