ClipVerse PWA – deploy & APK steps
1. Upload this whole folder to HTTPS hosting (Netlify / Vercel / GitHub Pages / Firebase Hosting). Keep index.html, sw.js and manifest.json in the same folder.
   Netlify: drag & drop the folder (netlify.toml sets correct headers).
2. In Firebase Console > Authentication > Settings > Authorized domains, add your hosting domain (needed for login).
3. Open the site on Android Chrome -> "Install App" button (or browser menu > Install app).
4. APK: go to pwabuilder.com, paste your site URL, Package for Android -> download. (WebIntoApp also works with the URL.)
5. After changing index.html, bump VERSION in sw.js so users get the update.

V6 notes
- Google login: Firebase Console > Authentication > Settings > Authorized domains must contain your Vercel domain (e.g. clipverse-pwa.vercel.app).
- Install: only works on https and after the page has loaded once; iPhone uses Share > Add to Home Screen.
- Firestore: add rules for users_private (see chat message).

LIVE (V19) - Firestore rules
Add this inside "match /databases/{database}/documents { ... }" in Firebase Console > Firestore > Rules, then Publish:

  match /lives/{id} {
    allow read: if true;
    allow create, update: if request.auth != null;
    allow delete: if false;
    match /{sub=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }

CAMERA LIVE (V19)
Camera Live uses WebRTC (peer-to-peer) with Firestore as the signalling channel (same "lives" rules as above cover it).
- The broadcaster's phone sends video directly to each viewer: up to 8 viewers at once.
- Some mobile networks block direct connections. For better reach add a TURN server in index.html (const ICE = [...]).
- For hundreds of viewers a streaming service (Agora, LiveKit, Cloudflare Stream) is needed.

V20 - Same profile everywhere
- index.html: syncMe()/clearMe()/goOnce() added; version label V20.
- community.html: shows the logged-in ClipVerse name/photo; Profile icon opens the app Profile.
- sw.js, manifest.json, Firebase/login/upload/DB: untouched.

V21 - Endless scroll
- index.html: feedMore() (Home) and shortsMore() (Shorts) added; videos repeat so scrolling never stops.

V22 - Login page like reference
- index.html: new "loginMethods" screen (Use email / Continue with Google / Select account); phone button removed from login. sw.js, manifest.json, Firebase untouched.

V23 - Open on Shorts + YouTube style watch page
- index.html: app opens on Shorts (falls back to Home if no short); long video opens a watch page (player on top, other long videos below, full screen button). sw.js, manifest.json, Firebase untouched.

V24 - Watch page: list scroll fixed, only long videos in list

V25 - Upload Short/Long sections (Short up to 2 min, 9:16), Post button (opens community.html) in Create menu, mini player (drag, tap to expand, X to close)

V26 - Comment sheet for Shorts (TikTok style) and Long videos (YouTube style "Comments" box + sheet)
