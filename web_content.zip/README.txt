VERSION: v8, 26 November 2026 (print page, school logo icon). File name: St-Christopher-Portal-v8-26Nov2026-Print-Page.zip

St Christopher Kids Nursery and Primary School - Accountability Portal (cloud version)

WHAT CHANGED
- All data is now shared live through your Firebase Realtime Database
  (https://st-christopher-kids-default-rtdb.firebaseio.com). Head, Bursar, teachers and parents
  each sign in on their own phone and see the same records.
- Works offline too: changes are kept on the phone and sent when the network returns.
- Fees pre-loaded: School fees 10,000 | PTA 500 per term | Development levy 1,000 | Assessment pack 2,000 |
  Tissue and soap 1,000 | Admission fee 2,000 (new pupils) | Day wear, PE wear, Cultural wear 6,000 each
  (tick the uniforms a pupil ordered when you add or edit the pupil).
- 15 subjects including CRS and Health Education & Health Habits.
- Parents: new "Teacher report" tab (best teacher of the term + their child's class teachers).

ONE-TIME FIREBASE SETUP (required)
Firebase console > Realtime Database > Rules, publish:
  { "rules": { "portal": { ".read": true, ".write": true } } }
Everything is stored under /portal. (Anyone who knows the database address could read it with these
rules, so keep the address private. Stronger locking needs Firebase Authentication.)

SIGN IN
Pick a role and enter its PIN (Admin / Bursar / Teacher / Parent). Parents also enter the child's
admission number. PINs can be changed in Settings (admin).

APK
Use index.html as the web app. The APK needs the INTERNET permission (APK Forge adds it by default).

IMPORTING THE SCHEME OF WORK
Weekly curriculum > pick class and term > Import scheme.
- scheme-files/scheme-of-work-first-term.json loads Primary 1 to 6 first term in one go.
- scheme-files/Primary-N-first-term.csv loads one class (opens in Excel; edit, then import for the class and term selected).

ADDING PUPILS IN BULK
Classes and registration lists > pick the class > "Paste / import list". Paste names (one per line, optional M/F, parent, phone) or choose a .csv/.txt file. Admission numbers are made automatically. Names already in the class are skipped.

FEE COLLECTION (Bursar)
Fee collection page: pick class and term, type the amount a parent has just paid next to the pupil and tap Add. The portal adds it to what was paid before, spreads it over the unpaid fees and updates the balance. Repeat until paid in full. History shows every instalment, with Receipt, Void and Print history. "Print collection sheet" prints the class sheet.

PRINTING
Every page has a Print button in the top bar; it prints the page you are on (without buttons).

PHOTOS AND QR CODE ON REPORT CARDS
- Add a photo: Classes page > Photo (next to the pupil) or inside Edit pupil > Take / choose photo.
- Many at once: Classes page > Upload class photos. Name each picture file after the pupil (for example Ada Nwosu.jpg) or the admission number (SCK-2026-002.jpg).
- Report cards show the photo (or a box to paste a passport photo) and a QR code with the pupil's name, admission number, class, term, total, average, position and a reference code. Any phone camera can scan it.

REPORT CARDS PAGE (Head and teachers)
Top menu > Report cards. Pick session, term and class. For each pupil: Preview, Remarks, Print. "Print all cards" gives one A4 page per pupil. "Suggest remarks for the class" fills class-teacher remarks (and head remarks when signed in as Head) which you can edit.
Remarks window: class teacher's remark, head teacher's remark (Head only) and 1-5 ratings for eight skills (punctuality, neatness, politeness, honesty, attentiveness, handwriting, sports, relationships).
The card shows: photo, details, class teacher, total/average/position/grade/class average, every subject with CA1, CA2, exam, total, performance bar, class average, grade, position and remark, skills ratings, attendance, next term date, remarks, signature lines and a QR code that verifies the card. Parents print the same card from their Results tab.

SHARING DATA BETWEEN PHONES (checklist)
1. Firebase console > Realtime Database > Rules: publish
   { "rules": { "portal": { ".read": true, ".write": true } } }
2. Install this same version on EVERY phone (Head, Bursar, each teacher, proprietor).
3. The top bar must show "● Live". A red bar means the phone is NOT sharing: tap "Check connection" and follow the fix.
4. Settings (Head) > Connection check shows how many pupils, payments, teachers, score sheets and attendance sheets are in the school database compared with this phone.
5. Phones also check for updates every 8 seconds, so entries appear on other phones within seconds even if the live link is blocked.
6. If a phone held records typed before it was linked, it asks once whether to use the school database (recommended) or add this phone's records to it. Records typed separately on different phones can appear twice, so enter each class once.

CAMERA AND PRINTING
- Classes page: "Camera" beside a pupil snaps that pupil's photo. "Photograph class" goes through the class pupil by pupil: snap and it moves to the next one (Skip / Back available). If the live camera will not open, use the "Phone camera app" button. When building the APK, allow the Camera permission.
- Report cards page: Print / Print all open the phone's print screen (choose the printer). "Save as PDF" / "Save all as PDF" makes an A4 PDF (one card per page) you can open, share to a printer app, or print from the PDF viewer. Use this if Print does nothing inside the APK.

IF PRINT DOES NOTHING IN THE APK
Inside many APK wrappers the phone's print screen cannot open. This version detects that and makes Print save an A4 PDF instead (every Print button, including report cards, receipts, sheets and lists). Settings (Head) > "Printing" switches between print screen and PDF.
The PDF still has to leave the app: it is shared (share sheet) or downloaded. If your APK blocks downloads, the most reliable way to print is to use the portal in Chrome as an installed web app:
1. Put these files (index.html, manifest.json, sw.js, icon-192.png, icon-512.png) on any free web host, for example drag the folder onto app.netlify.com/drop, or use GitHub Pages or Firebase Hosting.
2. Open the web address in Chrome on the phone, menu > "Add to Home screen" / "Install app".
3. Printing (to a printer or Save as PDF), the camera and sharing between phones all work there with no extra setup.

V7: PDF AND CAMERA INSIDE THE APK
- After "Save as PDF" a window offers: Download PDF (tap it), Share PDF (if the phone allows), Download (second method), and View pages (screenshot each page and print from the Gallery).
- If the live camera cannot start inside the APK, the camera window switches to "Take photo with phone camera" (opens the phone's own camera app) and "Gallery". In Photograph class, each photo you take is saved to the pupil shown and it moves to the next pupil.
- In the APK builder settings turn ON: Camera permission, file upload / camera upload, and downloads (Download Manager / blob downloads) if those options exist.
- Fallback that always works: open the .html file with Chrome on the phone (Files app > Open with > Chrome). Camera, printing, PDF download and sharing between phones all work there.


V8: PRINTING FROM THE APK (ONE-TIME SETUP, ABOUT 5 MINUTES)
Many app wrappers cannot save a file or open the print screen. v8 solves this by sending the printout to a small web page (print.html) that opens in Chrome, where Android's normal print screen (printer or Save as PDF) works.
1. Unzip this file on the phone. Go to github.com and sign in (the same account you used to build the APK).
2. Tap + > New repository. Name: school-portal. Choose Public. Create repository.
3. In the new repository tap Add file > Upload files. Select index.html, print.html, manifest.json, sw.js, icon-192.png and icon-512.png. Tap Commit changes.
4. Settings > Pages > Source: Deploy from a branch > Branch: main, folder: / (root) > Save. After 1-2 minutes the address is https://YOURNAME.github.io/school-portal/ (GitHub shows it on that page).
5. In the school app (Head login): Settings > Print page address > paste https://YOURNAME.github.io/school-portal/print.html > OK. It is saved for every phone.
6. To print: Report cards > Print. Tap "Open print page". Chrome opens and shows the Android print screen. Choose the printer, or Save as PDF.
Notes: only the program files go on GitHub, not the school's pupil data (that stays in your Firebase database). You can also open https://YOURNAME.github.io/school-portal/ in Chrome and use "Add to Home screen"; printing, the camera and PDF saving all work there directly.
