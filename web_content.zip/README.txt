St Christopher Kids Nursery and Primary School - Accountability Portal (cloud version)

WHAT CHANGED
- All data is now shared live through your Firebase Realtime Database
  (https://st-christopher-kids-default-rtdb.firebaseio.com). Head, Bursar, teachers and parents
  each sign in on their own phone and see the same records.
- Works offline too: changes are kept on the phone and sent when the network returns.
- Fees pre-loaded: School fees 10,000 | PTA 500 per term | Development levy 1,000 | Assessment pack 2,000 |
  Tissue and soap 1,000 | Admission fee 2,000 (new pupils) | Day wear, PE wear, Cultural wear 6,000 each
  (tick the uniforms a pupil ordered when you add or edit the pupil).
- 15 subjects including CRS and Health Education & Health Habits.
- Parents: new "Teacher report" tab (best teacher of the term + their child's class teachers).

ONE-TIME FIREBASE SETUP (required)
Firebase console > Realtime Database > Rules, publish:
  { "rules": { "portal": { ".read": true, ".write": true } } }
Everything is stored under /portal. (Anyone who knows the database address could read it with these
rules, so keep the address private. Stronger locking needs Firebase Authentication.)

SIGN IN
Pick a role and enter its PIN (Admin / Bursar / Teacher / Parent). Parents also enter the child's
admission number. PINs can be changed in Settings (admin).

APK
Use index.html as the web app. The APK needs the INTERNET permission (APK Forge adds it by default).
