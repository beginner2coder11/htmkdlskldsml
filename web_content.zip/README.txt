VOL EngSpo – इंग्लिश स्पीकिंग कोर्स
Vision Of Learners
डेवलपर: सूर्यकांत भारती

फ़ाइलें:
  index.html   – पूरा ऐप (114 लेवल, छात्र लॉगिन, एडमिन पैनल; लोगो और डेवलपर फोटो अंदर ही जुड़े हैं)
  manifest.json, icon-192.png, icon-512.png – ऐप का नाम और आइकन
  vol-logo.jpg, developer-photo.jpg – लोगो और फोटो (APK टूल में ज़रूरत हो तो)
  sw.js        – वेबसाइट पर डालने पर ऑफ़लाइन चलाने के लिए

APK बनाने के लिए: यह ZIP किसी HTML/ZIP-to-APK टूल में डालें, शुरुआती फ़ाइल index.html रखें।
बोलकर अभ्यास (माइक) के लिए APK में RECORD_AUDIO अनुमति चालू करें।
AI टीचर: इंटरनेट से Supabase सर्वर (प्रोजेक्ट VOL EngSpo, फ़ंक्शन vol-engspo-ai) से चलता है।
Anthropic API key केवल Supabase → Edge Functions → Secrets में ANTHROPIC_API_KEY नाम से रखें।
एडमिन → सेटिंग्स → "AI जाँचें" से टेस्ट करें।

एडमिन पासवर्ड (शुरुआती): suryakant123 – पहली बार में ही बदल लें।
