MV GESTOR — PACOTE PRONTO PARA APK

Versão: V7
Tipo: aplicativo web mobile-first / offline-first
Entrada principal: index.html

Este pacote foi organizado para ser carregado diretamente em um criador de APK/WebView.
O index.html está na raiz do ZIP.

MÓDULOS
- Dashboard
- Produtos / estoque inteligente
- Histórico de produtos e custos
- Compras (editar/anular)
- Vendas (editar/anular)
- Caixa / fluxo de caixa
- Despesas
- Clientes / contas a receber
- Dívidas / contas a pagar
- Patrimônio
- Relatórios / impressão em PDF
- Backup / restauração local

REGRAS FINANCEIRAS
- Lucro = Receita - Custo das mercadorias vendidas - Despesas.
- Patrimônio líquido = Ativos - Passivos.
- Investimento do proprietário aumenta caixa e patrimônio; não é receita nem lucro.
- Retirada do proprietário reduz caixa e patrimônio; não é despesa nem reduz o lucro.
- Empréstimo aumenta caixa e dívida; não é receita nem lucro.
- Compra a crédito aumenta estoque e contas a pagar; só o valor efetivamente pago reduz o caixa.
- Venda a crédito reduz estoque e aumenta contas a receber; só o valor recebido aumenta o caixa.
- Recebimento de cliente aumenta caixa e reduz contas a receber.

ARMAZENAMENTO
- Funciona sem servidor e sem base de dados externa.
- Os dados são armazenados localmente no dispositivo via localStorage.
- Faça backups regularmente.

APK
1. Carregue este ZIP no criador de aplicativos.
2. Use Preview para abrir o index.html.
3. Em App Settings, use o nome MV Gestor e o ícone icon.png, se o criador permitir seleção manual.
4. Gere o APK.
5. Depois de instalar, faça um teste real de compra, venda, edição, anulação, caixa, despesas, investimento, retirada, backup e restauração.

OBSERVAÇÃO SOBRE PDF
Os relatórios usam a janela de impressão do navegador/WebView. Dependendo do criador de APK, a opção "Imprimir / Guardar PDF" pode depender do suporte do WebView ao diálogo de impressão.
