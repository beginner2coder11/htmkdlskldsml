GORDO BURGUER - V1
====================

Esta es una primera versión web funcional de la app.

Incluye:
- Menú y categorías.
- Carrito.
- Delivery fijo de S/ 5 para Barranca.
- Efectivo, Yape y Prexpe como métodos de pago.
- Datos del cliente y dirección.
- Envío del pedido a WhatsApp: 955 201 233.
- Guarda el carrito en el navegador.

Cómo probarla:
1. Abre index.html en un navegador.
2. Agrega productos.
3. Abre el carrito.
4. Completa los datos.
5. Pulsa "Pedir por WhatsApp".

Nota: el número de Yape/Prexpe no se muestra porque todavía no se ha proporcionado.
