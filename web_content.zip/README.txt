TJOEF BUDDIES CLASH
APKforge: upload this zip, entry file = index.html, orientation = LANDSCAPE, fullscreen on.
Keyboard: Arrows/WASD move+jump, Down/S block, J punch, K kick, L ki blast, I super (when bar is full).
Phone: on-screen buttons appear during fights (P punch, K kick, star-ish buttons for blast and super).
