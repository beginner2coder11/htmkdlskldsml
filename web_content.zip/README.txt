KEA OT Timesheet (editable HTML)

1. Unzip the folder.
2. Open index.html in Chrome, Edge, Safari or Firefox (works offline).
3. Pick Month / Year, then tap 'Fill all in one click'.
4. Upload signature and stamp images with the Upload buttons.
5. Choose Paper size (A4 / A3 / A5) and tap 'Download PDF'.

Folder structure:
  index.html
  assets/js/jspdf.umd.min.js   (PDF library, v2.5.1)
