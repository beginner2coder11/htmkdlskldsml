RosterHQ — F&B Staff Roster Manager
Android HTML-to-APK project package

START FILE
Open index.html in a modern browser or choose it as the app start page in your HTML-to-APK builder. index.html is at the ZIP root.

IMPORTANT
- This is a web app project, not a prebuilt APK.
- Excel import uses the SheetJS library loaded from jsDelivr, so first load/import requires an internet connection.
- Roster data is stored in the browser/WebView local storage on that device. It does not automatically sync between devices.
- Export a JSON backup before replacing/rebuilding the app. Keep the same app package/storage context where possible to retain local data.
- Test navigation and import in the target APK builder before relying on it operationally.

USAGE
1. Open the app and choose Import weekly roster or Add weekly roster.
2. Select an Excel workbook (.xlsx or .xls) with staff names and dates across the week.
3. Press Import roster and check the confirmation message.
4. Use Export data regularly to create a JSON backup.
