TJOEF BUDDIES CLASH
APKforge: upload this zip, entry file = index.html, orientation = LANDSCAPE, fullscreen on.
Keyboard: Arrows/WASD move+jump, Down/S block, J punch, K kick, L ki blast, I super (when bar is full), P/Esc pause.
Combos: P then K then L chains while your hits connect.
Phone: on-screen buttons appear during fights (P punch, K kick, blast, super star, II pause).
Arcade ladder: beat all 7 other fighters to become TJOEF CHAMPION. CPU gets sharper every stage.
Camera: zooms in close when fighters are near and pulls back when they are far apart.
Stages: Hallway, Sports Field, Classroom, Gym (picked by opponent).
Unique blasts: Perry 3-way spread, Martin fast bolt, Stiaan big slow orb, Micheal diagonal drop, Jayden huge orb, Dustin homing heart-seeker, Henjohan sharp bolt, Seuna twin darts.
Unique supers: Perry / Micheal / Dustin call down a rain of blasts; Stiaan and Jayden fire huge beams; Martin, Henjohan and Seuna fire fast sharp beams.
Look: sprites are smoothed to double resolution with light/shadow shading and fine outlines; stages have texture grain; fighters glow with ki when the SUPER bar is full.
Orientation: no rotate-your-phone screen. The game is always landscape; if the phone is held upright it draws sideways to fill the screen and flips by itself to match the way you turn the phone (small flip button on menus if it ever faces the wrong way).
