GESTÃO COMERCIAL OFFLINE — PRODUÇÃO V6

PACOTE FINAL PARA CONVERSÃO EM APK

1. No HTML to APK, escolha “Arquivo ZIP para APK”.
2. Envie o ZIP inteiro. Não extraia e não envie apenas o index.html.
3. O index.html está diretamente na raiz do ZIP.

MÓDULOS
- Dashboard
- Produtos e histórico
- Compras e lista inteligente de reposição
- Vendas e faturas
- Caixa
- Clientes
- Fornecedores
- Relatórios
- Administração: funcionários, despesas e distribuição financeira
- Empresa / Sistema
- Backup e restauração

ROBUSTEZ
- Dados persistidos localmente com localStorage.
- Migração automática de chaves das versões anteriores.
- Validação de produtos, compras, vendas, despesas e distribuições.
- Proteção contra venda duplicada acima do stock disponível.
- Backup validado antes da restauração.
- Sem CDN, API, fonte externa, fetch, AJAX ou dependência obrigatória de Internet.
- CSS e JavaScript incorporados no index.html.

TESTE
- Sintaxe JavaScript: OK.
- Boot com armazenamento local simulado: OK.
- Cadastro de produto: OK.
- Compra e atualização de stock/caixa: OK.
- Venda e atualização de stock/caixa: OK.
- Clientes e fornecedores: OK.
- Funcionários, despesas e distribuição: OK.
- Proteção contra venda acima do stock combinado: OK.

LIMITAÇÃO DA CONVERSÃO
O comportamento de impressão/PDF, downloads e seletor de arquivos depende do WebView/permissões do HTML to APK. O projeto não depende de servidor externo.

FATURAÇÃO
Os documentos são comerciais locais. A validade como faturação fiscal oficial depende da conformidade legal aplicável e não é garantida por este projeto.

NOVIDADES DA V6
- Avisos e confirmações dentro da própria app (funcionam no WebView do APK, onde alert/confirm podem falhar).
- Anular fatura: devolve o stock e estorna o valor recebido no caixa; faturas anuladas saem dos totais.
- Backup em texto (copiar/colar) como alternativa ao download, que pode não funcionar no APK.
- Restauro/abertura de dados corrompidos sem quebrar a app; numeração de faturas nunca repete após restaurar backup.
- Venda a crédito exige cliente; número da fatura só é consumido quando a venda é válida.
- Total da venda atualiza ao alterar o desconto; erros de arredondamento no stock corrigidos.
- Fornecedores ligados por ID (não por nome); campos protegidos contra código malicioso em backups.
- Moeda padrão Kz.

IMPORTANTE: os dados ficam no aparelho. Se desinstalar o APK ou limpar os dados da app, perde tudo. Faça backup (texto ou ficheiro) com frequência.
