TRASLADOS ADMIN - WEB PARA COMPILAR COMO APK

Esta versión contiene únicamente el panel administrativo.

Archivo de entrada: index.html (es una copia de admin.html)
Nombre sugerido de la app: Traslados Admin
Package ID sugerido: com.svt.trasladosadmin
Orientación: Portrait

El proyecto conserva los archivos JS/CSS/imagenes y la configuración Firebase necesarios para el panel.
No incluye conductor.html ni la página pública index.html original.

Para HTML to APK Builder: sube el ZIP completo y usa index.html como página de inicio si te pregunta.
