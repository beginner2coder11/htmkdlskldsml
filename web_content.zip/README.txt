RosterHQ F&B Staff Roster Manager — Import Fix

IMPORTANT: index.html is at the ZIP root. Open it in a browser or use it as the start page in your HTML-to-APK builder.

Import workflow:
1. Open Import weekly roster.
2. Service: tap Choose / Import Service Excel. The file picker should open. Select the STAFF ROSTER workbook; import starts after selection.
3. Kitchen: choose the Monday date for the Tumbler week, then tap Choose / Import Kitchen Excel and select TUMBLER workbook.
4. The app will show success/error feedback. After a successful import, the dashboard and daily roster date are moved to an imported date.

Excel import uses the SheetJS library loaded from jsDelivr, so an internet connection is required unless the library is bundled separately.

Data safety: Existing browser data is stored in localStorage under rosterhq_v1. Export a JSON backup before replacing/reinstalling the app. Browser storage may differ between Chrome and an installed APK/WebView.
