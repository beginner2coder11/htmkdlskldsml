GORDO BURGUER - PROYECTO DE PEDIDOS
====================================
Archivos:
- index.html: pantalla principal.
- style.css: diseño adaptable a celular.
- app.js: productos, carrito y envío por WhatsApp.

MENÚ INCLUIDO
Hamburguesas: carne 10, pollo 12, mixta 14, de la casa 20.
Alitas Gourmet: 4 por 15, 8 por 20, 16 por 35.
Salchipapas: salchipapas a lo pobre 10, papicarne 12, papipollo 13, papi-mixto 15.
Club House: 25 (para 2 personas).
Arroz chino: arroz, pollo y jamón 12; arroz, pollo, jamón y camarones 16.
Lumpias: 1 por 5; 3 por 12.

Horario: viernes a miércoles, 6:00 pm a 12:00 am.
WhatsApp de pedidos configurado: 955201233.

Nota: No se incluyó alitas de maracuyá.
