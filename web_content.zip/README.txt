Rustic Mango AI No-API-Key Version

This HTML intentionally has NO API-key input.

Important:
A browser-only HTML cannot securely call a paid vision AI service without credentials.
This package is therefore designed for a hosted AI bridge / Android wrapper that supplies
window.RusticMangoAI.analyzeImage(file, callback).

The calculator itself works locally and includes:
- Mango, Acacia/Babul, Sheesham rates
- 2 inch + Rs 40/CFT surcharge
- 30 inch -> 2.75 ft purchasing rule
- plank count = ceil(width/plank width) + 1
- leg rule and 1.74 ft x 4 inch x thickness wastage plank
