TIGRINYA LEARNING APP
Upload index.html and the whole sounds/ folder together (keep the folder names exactly as they are).

Sounds: sounds/<folder>/<name>.mp3 (a .wav with the same name also works).
Folders: letters, numbers, colors, greetings, animal-names, family, days, body-parts, food, clothing, verbs  (all your recordings, converted to small .mp3 files)
         animals/        the animal noises you sent first (chicken, rooster, sheep, goat, horse, donkey, bird)
         animal-sounds/  OPTIONAL: your own recorded animal noises. If a file is here it is used first. Still missing: cow, dog, cat (they play only the spoken name for now).

To add or replace a sound: record it with recorder.html (it names the files correctly), then copy the file into the matching folder.
Full list of file names: SOUNDS-LIST.csv

PHOTOS (optional)
Realistic pictures go in images/<folder>/<name>.jpg (png or webp also work), e.g. images/family/mother.jpg, images/animals/cow.jpg.
IMAGE-PROMPTS.csv now lists only the pictures still missing with a ready-made AI prompt for each. Make them with any AI image tool, square, about 512x512.
Any picture that is missing keeps showing its emoji (or the drawing for animals), so you can add them a few at a time.

NEW: sections "ብሄራት ኤርትራ" (9 ethnic groups) and "ዞባታት ኤርትራ" (6 zones).
Sounds go in sounds/ethnic-groups/ and sounds/zones/; photos in images/ethnic-groups/ and images/zones/ (names in SOUNDS-LIST.csv / IMAGE-PROMPTS.csv).
recorder.html now lists every item in the app, including these.

CALCULATOR: sounds/calculator/ plus, minus, times, divide, equals, negative, point (.mp3) + numbers/0.mp3. The app says e.g. 2 x 4 = 8 by joining your number recordings with these words. See SOUNDS-LIST.csv.

NUMBERS: for bigger numbers the app joins parts with ን, e.g. 1223 = ሽሕን + ክልተ ሚእትን + ዕስራን ሰለስተን. Extra recordings used for this: numbers/100-and, numbers/1000-and, numbers/1000000-and (and numbers/0 for zero). If one is missing, the plain word is used instead.

LANGUAGE: tap the gear (top right) to choose the language shown under the Tigrinya words (English or Dansk). To add another language, add its translations to the TR object in index.html (or ask for it).
ALL REQUIRED SOUNDS ARE NOW IN PLACE. Optional: your own animal noises in sounds/animal-sounds/ (cow, dog, cat... .mp3) are used before the built-in ones.
