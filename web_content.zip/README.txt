KendaraanKu v4 fixed
Semua field jadwal bersifat opsional/manual. Tidak ada syarat interval KM atau bulan.
Tanggal, KM, interval, catatan dapat diisi sesuai kebutuhan.
Tidak memakai URL eksternal/CDN.
