STORY HOME SERVICES PDF FILLER
===============================

CONTENTS
- index.html, styles.css, app.js: the app
- manifest.json and sw.js: installable PWA support
- icons/: green roofline app icons and supplied logo

HOW TO USE
1. Extract this ZIP.
2. Upload the extracted folder to a static web host that serves HTTPS (for example, a static hosting service).
3. Open the hosted URL in Chrome on your Android phone.
4. Use Chrome menu > Add to Home screen / Install app.
5. Add a PDF in PDF Library.
6. Tap Back up library to create one backup file containing all stored PDFs and their field layouts. On Android, choose Google Drive in the share sheet when available; otherwise the backup downloads and can be uploaded to Drive.
7. On a new phone or after reinstalling, open the app and tap Restore backup. Select the saved JSON backup file. Existing PDFs are kept; matching record IDs are replaced by the backup copy.
8. Open Field Editor, choose the PDF, select a field type, enter a label, tap Add field, then drag the field box to position it. Use + / - to zoom the PDF. Save field layout.
9. Open Fill & Sign, choose the PDF, fill the fields, sign in the signature box, then tap Save completed PDF to phone. Choose Downloads, Drive, or an email app if Android offers the share sheet.

IMPORTANT
- This is a web app/PWA ZIP, not a compiled APK. A separate APK builder/wrapper is needed to package it as an APK. No Android Studio is required for using it as a PWA.
- PDF.js and pdf-lib are loaded from public CDNs, so an internet connection is required to load those libraries. Your saved PDF files and field layouts remain in the browser's local IndexedDB storage on that device.
- Do not clear the browser's site data or uninstall the PWA unless you have a backup. Backups contain the original PDFs and field layouts in one JSON file; store that file somewhere safe such as Google Drive.
- Use a static HTTPS host. Browser local file:// access will not reliably support PDF rendering, storage, or service workers.

BRANDING UPDATE
- App icon and header now use the supplied Story Home Services roofline logo.
- App colors use the roofline green (#0E803F).

LATEST LOGO UPDATE
- The supplied square Story Home Services logo is used inside the app header and for launcher icons.
- The green header banner is retained.

LATEST FUNCTIONALITY UPDATE
- PDF field boxes can be resized using the green round handle at the lower-right corner.
- Preview finished PDF opens an in-app preview before saving.
- Save completed PDF creates a PDF download and also opens a viewer fallback on Android browsers that ignore downloads.

BUTTON AUDIT / SAVE IMPROVEMENT
- Checked app and service-worker JavaScript syntax, manifest JSON, unique HTML IDs, and all direct button/input handler references.
- Save completed PDF and preview download now try Android's file share sheet first, then use a browser download and viewer fallback.
- Actual phone file-picker, share-sheet, and download behavior still depends on the Android browser and hosting environment.

PREVIEW AND SAVE UPDATE
- Preview renders PDF pages inside the app using PDF.js.
- Save completed PDF opens a filename dialog, then uses Android's share sheet (when available) to choose Drive, Downloads, email, etc.; otherwise it uses the browser download fallback.
- Browsers that support the File System Access save picker may offer a direct location picker. Android browser support varies.
