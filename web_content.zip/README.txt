NO-API-KEY VERSION

This file does not request an API key.
It contains the calculator and the user's plank/rate/leg rules.

Important technical limitation:
A normal standalone HTML file cannot perform reliable modern AI image understanding entirely offline unless a
large vision model is bundled into the app. This lightweight file therefore provides a native Android AI bridge
hook (window.RusticMangoAI.analyzeImage) and a manual fallback. It does not pretend OCR is full vision AI.

For a genuinely offline Android AI version, a local vision model must be packaged into the APK; that is a separate,
much larger Android build.
