WORD POWER – शब्द-शक्ति (App v1.1)
Developer: सूर्यकांत भारती (Suryakant Bharti) · Vision Of Learners

फ़ाइलें:
  index.html      – पूरा ऐप (सारा डेटा, लोगो व फ़ोटो इसी में शामिल है)
  manifest.json   – ऐप का नाम, आइकन व रंग
  images/         – लोगो, डेवलपर फ़ोटो और ऐप आइकन (192 व 512 px)

उपयोग:
  • सीधे चलाने के लिए index.html को किसी भी ब्राउज़र में खोलें।
  • APK बनाने के लिए यह पूरी ZIP किसी HTML/ZIP-to-APK टूल में डालें;
    Start page = index.html, App icon = images/icon-512.png।
  • शब्दों का उच्चारण (🔊) फ़ोन के Text-to-Speech से चलता है।
