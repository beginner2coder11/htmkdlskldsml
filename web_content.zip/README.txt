Thue SIM So Tien Thong - goi API OTPVN truc tiep

Cach dung:
1. Giai nen ZIP hoac tai ZIP nay len cong cu dong goi website thanh APK.
2. Dam bao index.html nam o thu muc goc cua goi.
3. Cai APK, nhap token OTPVN va bam Kiem tra ket noi.
4. Token duoc luu trong bo nho local cua ung dung tren thiet bi nay de khoi phai nhap lai.
5. Bam "Xoa token da luu va dang xuat" de xoa token khoi bo nho tren thiet bi.

API duoc goi truc tiep tu app: https://api.otpvn.com
Canh bao: token luu trong localStorage khong duoc ma hoa nhu kho luu bi mat cua Android. Chi dung tren dien thoai ca nhan co khoa man hinh; khong dung tren thiet bi dung chung.

Luu y:
- Tai khoan OTPVN phai duoc cap quyen API.
- Neu bao loi CORS/khong ket noi, cong cu dong goi co the chua cho phep WebView goi API. Luu token khong sua duoc loi CORS; can APK Android goc co cau hinh mang phu hop hoac may chu trung gian.
- Thue so co the tru tien. Chi bam thue khi ban chap nhan gia va dieu kien.
- Lich su trong ban nay tai 30 ngay gan nhat cho dich vu da chon.
