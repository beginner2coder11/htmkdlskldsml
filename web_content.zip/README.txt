HOTEL HR MANAGER — UPDATED WEB APP ZIP
======================================
Files: index.html, style.css, app.js, performance-management-plan.json, README.txt

Included updates:
- Imported your Performance management plan draft.xlsx into the Performance plan page.
- Food & Beverage product knowledge scoring table.
- Food & Beverage quarterly appraisal table.
- Document scan workflow: capture with camera or choose an image, basic auto-crop of likely page bounds, preview, link to employee, and save.
- Employee records, probation alerts, onboarding, training, appraisals, counselling notes.
- CSV employee export and JSON data backup/restore.

Demo sign-in: admin / admin123

IMPORTANT:
- This is a prototype. Data is stored locally in the app/browser on the same device.
- Scanner auto-crop is a basic image-boundary estimate. It does not perform full perspective correction; inspect each preview before saving.
- Scanned images consume device/browser storage. If storage fills, export/back up data and reduce scan image sizes.
- Demo sign-in is not secure authentication. Do not use confidential HR data in production until secure authentication, encrypted cloud storage, access control, and backups are implemented.
- For the converter, choose index.html as the entry file if prompted.

NEW: Paper scanning is available inside Onboarding, Training & Tests, Appraisals, Counselling, and Disciplinary record forms. Use the phone camera or choose a photo, then select “Scan & analyse paper”. The app uses Tesseract.js OCR (internet required to load the library/language data in this build) to extract text and adds rule-based HR suggestions to the record details. Always review/correct the text and suggestions before saving. OCR can misread handwriting, numbers, names and dates; it is not a substitute for human HR review or legal process. Scanned images are stored with the record in local device storage and may increase storage use. Back up your data regularly.
