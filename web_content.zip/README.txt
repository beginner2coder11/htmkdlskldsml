ClipVerse PWA – deploy & APK steps
1. Upload this whole folder to HTTPS hosting (Netlify / Vercel / GitHub Pages / Firebase Hosting). Keep index.html, sw.js and manifest.json in the same folder.
   Netlify: drag & drop the folder (netlify.toml sets correct headers).
2. In Firebase Console > Authentication > Settings > Authorized domains, add your hosting domain (needed for login).
3. Open the site on Android Chrome -> "Install App" button (or browser menu > Install app).
4. APK: go to pwabuilder.com, paste your site URL, Package for Android -> download. (WebIntoApp also works with the URL.)
5. After changing index.html, bump VERSION in sw.js so users get the update.

V6 notes
- Google login: Firebase Console > Authentication > Settings > Authorized domains must contain your Vercel domain (e.g. clipverse-pwa.vercel.app).
- Install: only works on https and after the page has loaded once; iPhone uses Share > Add to Home Screen.
- Firestore: add rules for users_private (see chat message).

LIVE (V19) - Firestore rules
Add this inside "match /databases/{database}/documents { ... }" in Firebase Console > Firestore > Rules, then Publish:

  match /lives/{id} {
    allow read: if true;
    allow create, update: if request.auth != null;
    allow delete: if false;
    match /{sub=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }

CAMERA LIVE (V19)
Camera Live uses WebRTC (peer-to-peer) with Firestore as the signalling channel (same "lives" rules as above cover it).
- The broadcaster's phone sends video directly to each viewer: up to 8 viewers at once.
- Some mobile networks block direct connections. For better reach add a TURN server in index.html (const ICE = [...]).
- For hundreds of viewers a streaming service (Agora, LiveKit, Cloudflare Stream) is needed.

V20 - Same profile everywhere
- index.html: syncMe()/clearMe()/goOnce() added; version label V20.
- community.html: shows the logged-in ClipVerse name/photo; Profile icon opens the app Profile.
- sw.js, manifest.json, Firebase/login/upload/DB: untouched.

V21 - Endless scroll
- index.html: feedMore() (Home) and shortsMore() (Shorts) added; videos repeat so scrolling never stops.

V22 - Login page like reference
- index.html: new "loginMethods" screen (Use email / Continue with Google / Select account); phone button removed from login. sw.js, manifest.json, Firebase untouched.

V23 - Open on Shorts + YouTube style watch page
- index.html: app opens on Shorts (falls back to Home if no short); long video opens a watch page (player on top, other long videos below, full screen button). sw.js, manifest.json, Firebase untouched.

V24 - Watch page: list scroll fixed, only long videos in list

V25 - Upload Short/Long sections (Short up to 2 min, 9:16), Post button (opens community.html) in Create menu, mini player (drag, tap to expand, X to close)

V26 - Comment sheet for Shorts (TikTok style) and Long videos (YouTube style "Comments" box + sheet)

V27 - Install App button hidden (CSS only)

V28 - Camera: HD 1280x720 30fps, front camera preview mirrored like a mirror (saved video not mirrored)

V29 - Record camera: Beauty filter (Soft/Natural/Glow), saved into the video

V30 - Record camera: TikTok style filter circles (None, Soft, Radiance, Rosy, Fair, Golden, Cool, Vintage, B&W); each beautifies skin, saved into video

V31 - Shorts: quick swipe always completes to next/previous short (JS swipe, no half-screen stop)

V32 - Shorts swipe ultra fast (0.15s), small push is enough

V33 - Landscape inside installed app (page-rotate), watch list scroll hardened, shorts preload next 2 + preconnect

V34 - Added privacy-policy.html (separate page, nothing else changed)

V35 - privacy-policy.html contact email changed

V36 - Settings: "Privacy Policy" line opens privacy-policy page

V37 - Login stays after refresh (persistent auth, instant restore); Shorts For You = newest upload first

V38 - Own video storage support (index.html: UPLOAD_SERVER setting, empty = still Cloudinary), "Video not available" message,
      vercel.json: HTML pages are never cached, sw.js: VERSION v19 + 12s network wait (new version shows up reliably).
      See GUIDE.md of clipverse-server.zip.

V39 - Community now opens INSIDE the app (one header, one bottom menu, instant tab switch; community.html?embed=1 hides its own bar),
      Shorts hides the sample clip (it is a recording with its own header/menu) once real Shorts exist,
      video tiles get a poster picture (no black boxes), sw.js v20 (a page that is not the app is never answered with index.html).

V40 - Shorts: pull-to-refresh is off (swipe down only changes the video, page never reloads),
      current Short + next 2 use preload="auto" (poster picture shows at once), faster start for own-storage videos.

V41 - Watch page: channel row, buttons and comments box stay in place, only the video list scrolls under them.

V42 - Page opens ~10x faster: index.html was 2.17 MB (sample video + pictures were inside it), now 0.2 MB.
      Sample video and pictures are now files: demo-clip.mp4 and img/*.jpg (upload ALL files to Vercel).
      vercel.json: no-store removed (no-cache only), sw.js v21.

V43: sab kuch index.html ke andar (img/ folder nahi), Community index.html me embedded, purana rang wapas, offline.html pink/purple, sample video hata di.

V44: PC/laptop (bari screen, mouse) ke liye naya layout: left menu, 4 column videos grid, beech me Shorts. Phone/app ka layout same.

V45: Music/Sound (Shorts ki music line pe tap -> Use this sound -> Upload/Record), video na chalne par retry + error code.

V46: sound mobile fix (ruk ruk kar band nahi hoga), Download Video option hata diya.

V47: Forgot password (login page pe), naya icon (manifest.json same, sirf icon files badli).

V8: upload aur video ab apne Oracle server (https://clipverse.duckdns.org) par. Firebase feed/likes/comments same.

V9: Shorts preload (agli 3), 'Video not available' tab tak nahi jab tak data aa raha ho; server par shorts 720p compress.
V10: Upload page khulte hi peeche ki videos aur sound ruk jati hain (atakna band).
V11: Shorts me sirf agli 1 video pehle se load hoti hai (current ko poori speed). Server: HEVC/H.265 phone videos auto H.264 (tasveer na aane ka masla).
V16: profile poori image jaisi (phone + PC), tabs me icons, Invite ⋯ me, offline.html hata di.
V17: video cards (title/duration/views/date/⋯), About me Joined date, Public/Private profile, Subscribers list, Creator Dashboard, Subscribe par subscriber count foran update.
V18: naye user ko default cover + avatar (badal sakta hai), PC sidebar me Explore/Subscriptions/Library/History/Your Videos/Watch Later/Liked Videos/Go Pro.
V19: neeche/left bar se extra options hata diye; Vibe Room (profile) me profile pic wali bar + Menu (side drawer) me Explore/Subscriptions/Library/History/Your Videos/Watch Later/Liked Videos/Go Pro.
V20: Menu drawer hata kar profile/list pages par left side me hamesha nazar aane wali bar (profile pic + Explore...Liked Videos + Go Pro).

V21: Shorts loading fix - pehli 10 clips preload, baqi lazy (2-3 aage), door ki clips free, sirf screen wali play, 7s stall par auto-retry + log, tap-to-retry.
V22: bottom bar labels swapped (Shorts button = My World, Community button = My Universe). Video code untouched.
V23: Shorts preload gentler for the small server - first 4 at once, clips 5-10 one by one every 2.5 s, rest lazy. (approved by user)
V24: own video player - long videos get a control bar (play/pause, time, seek, speed, sound), Shorts get a seek/progress bar above the menu. Loading logic unchanged.
V25: Cloudinary poster/preconnect code removed (videos come only from the Oracle server). Upload and video loading unchanged.
V26: Home long videos load only when on screen (lighter for the small server). Shorts unchanged.
V27: profile button "Verscribe" with ClipVerse logo, "Verscribers" labels, bottom bar "Verse Book" and "My Verse".
V28: new square ClipVerse logo is the default profile picture for new users (old one removed). Users can change it.
V30: Verscribe button icon = play-ring logo; default profile = square logo; app install icons kept as before (square logo icons come at next update).
V31: 22 languages (16 new, all UI strings), video last-resort full download + diagnostic code on "Video not available".

V34: video links always use the own video server (old http/other-host links fixed); "Video not available" now shows server + HTTP code; .well-known/assetlinks.json added (Play Store app without address bar).
V35: private Admin page (admin.html): members, new signups per day, videos, views, likes, comments, top videos/creators. Only for accounts with admin=true in Firestore users doc. App files (index.html, sw.js, manifest.json) unchanged.
V36: first 5 Shorts are kept ready at app start (the rest load later while scrolling); Admin Panel button in Settings (only visible to admin accounts); admin.html has a back arrow.
V37: admin.html login with Email+Password (and Google); 5 taps on the Version text in Settings show the Admin Panel button (once, to find your User ID).
V38: 'Subscribe' is now 'Verscribe' everywhere (all languages, buttons, lists, sidebar); the ClipVerse logo shows on every Verscribe button and the sidebar Verscribes item.
V39: sidebar icons (Explore, Verscribes, Library...) sit on one straight line, a little smaller; long labels no longer push the icon sideways.
V40: new page /speedtest.html (measures real video-server speed from the phone; no app code changed).
V41: TikTok-style video loading: the Short on screen gets the whole connection; the next Shorts (up to 5) load one by one, each only when the clip before has 6 s buffered. Before: 5 clips downloaded at once and slowed the playing one.
V42: new page /regiontest.html (measures phone-to-region latency: India, Dubai, Singapore ... before choosing a new server). No app code changed.
V43: video links go through the Cloudinary fetch CDN (CLD_BASE + Oracle URL); posterOf strips that prefix so the Short poster still comes from Oracle. Upload code unchanged (video saved on Oracle, Firestore keeps the Oracle URL).
V44: cldtest.html added (diagnostic only, app unchanged)
V45: if a Cloudinary video fails (400/slow), it plays from the Oracle server automatically; label V45, sw v59; cldtest.html kept
V46: first 5 Shorts load faster (SAFE_SEC 3, scheduler every 300 ms); TikTok-style loading line under the Short on screen while loading; label V46, sw v60
V47: videos newer than 10 min play straight from Oracle (server is still converting them; Cloudinary was caching an error); older ones via Cloudinary; label V47, sw v61
V48: new uploads show 'Processing...' on the owner's profile (server mark <file>.processing) and join Shorts when ready; first touch turns sound/music on; Oracle window 2 min; label V48, sw v62. Needs server-patch.sh on Oracle.
