RosterHQ F&B Staff Roster Manager - Template-specific import build

IMPORT SERVICE
1. Open Import weekly roster.
2. Under Service — Staff Roster format, select your STAFF ROSTER workbook.
3. Tap Import Service roster. It reads the workbook's weekly sheets and uses the actual dates across the top.

IMPORT KITCHEN
1. Open Import weekly roster.
2. Choose the Monday date for the Tumbler week. This is required because the template's date row contains day numbers but not a full date.
3. Select the TUMBLER workbook and tap Import Kitchen roster.
4. The importer reads names from column A and Monday-Sunday shift cells from columns D-J on the first worksheet.

NOTES
- Excel reading uses the SheetJS library loaded from a CDN, so internet access is required when that library has not already loaded.
- Imported data is saved in this browser's local storage. Export a JSON backup before replacing the app or clearing browser data.
- Check imported shifts against the original Excel file before relying on them for staffing decisions.
- Kitchen Tumbler shifts are assigned to the Monday date selected and the next six calendar days.
