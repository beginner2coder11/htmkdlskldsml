TABLETOP B751 V0.6 TABS

Base exacta: V0.5.1, que ya funciona con el conversor.
Cambio: añadir tab EDITOR y separar los controles de edición de mazos/cartas de la zona de juego.
No se cambió la estructura de archivos ni la lógica principal.
Sin imágenes.
index.html directamente en la raíz.
