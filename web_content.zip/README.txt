TRASLADOS CONDUCTR - NETLIFY

Este ZIP está preparado para un generador Web-to-APK.
La página inicial carga directamente:
https://traslados-vde.netlify.app/conductor

Las actualizaciones publicadas en Netlify se reflejarán al volver a cargar la aplicación.
