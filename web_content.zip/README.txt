Air Pollution Tracker — phone-friendly app

Quick start:
1. Open index.html in a browser to preview the app.
2. To use it on your phone, keep the file in Downloads and open it with Chrome or another browser that supports local HTML files.
3. For a home-screen shortcut, publish the file to a static hosting service or open it from a local-file URL and use the browser menu's Add to Home screen option if available.

Features: sample AQI dashboard, in-app alerts, health tips, works offline after saved locally.
All readings are demonstration values, not live air-quality measurements.
