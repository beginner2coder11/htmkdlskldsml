RosterHQ F&B Staff Roster Manager — Import Fix 1.5

1. Open Import weekly roster.
2. Tap the visible Service roster Excel file field and select the STAFF ROSTER workbook.
3. Tap Import selected Service Excel.
4. For Kitchen, choose the Monday date, tap the visible Kitchen Tumbler Excel file field, select TUMBLER, then tap Import selected Kitchen Excel.

This revision avoids JavaScript-triggered file picker clicks, which some Android WebViews block. If tapping the visible file input itself still does not open Android Files, the APK wrapper must implement WebChromeClient.onShowFileChooser; an HTML-only change cannot add that native Android capability.

Excel parsing uses SheetJS from jsDelivr and currently requires internet access. App data is stored in browser localStorage (rosterhq_v1); export a JSON backup before reinstalling because WebView storage may differ between APK builds.
