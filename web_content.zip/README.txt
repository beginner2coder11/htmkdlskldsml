JAS LAUNDRY - CONVERTER COMPATIBLE PACKAGE

IMPORTANT:
- This package is for an HTML-to-APK converter that expects a web/index.htm entry page.
- The same application is also included as index.html at the package root.
- Import/extract this ZIP in the converter and select web/index.htm if it asks for a start page.
- Do not rename the web folder or index.htm.

CLOUD SIGN-IN:
- Firebase Authentication uses persistent local session on the same app origin.
- After a successful first sign-in on a device, later app launches should restore the saved Firebase session automatically.
- Do not put Firebase passwords into source code or ZIP files.
- A new phone/device must be authenticated once by an authorized Owner/Staff account. This is required by Firebase security and cannot safely be bypassed.
- Firebase Web App config must be saved once per device. After that, the saved config and persistent Firebase Auth session are reused.
- If the user cleared app data, uninstalled the app, changed app origin/package, or signed out, sign-in may be required again.

TEST:
1. Build/install on a test phone without uninstalling the working app first if data needs to be retained.
2. Sign in once and connect Firebase.
3. Close and reopen the app; verify session restores without asking for Firebase password again.
4. Confirm Cloud Sync indicator shows connected.
5. Test on a second device with its own one-time authorized sign-in.
