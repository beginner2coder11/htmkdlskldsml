JR Elétrica — ZIP corrigido para conversor de site para APK
Escolha este ZIP. O index.html está na raiz e abre o endereço do aplicativo diretamente.
