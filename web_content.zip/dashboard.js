'use strict';
const svgNS='http://www.w3.org/2000/svg';
function updateDashClock(){const d=new Date();$('dashTime').textContent=d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});$('dashDate').textContent=d.toLocaleDateString('pt-BR')}
updateDashClock();setInterval(updateDashClock,1000);
function dashboardHome(){if(tracks.find(t=>t.id===current)?.kind==='video'){media.pause();media.hidden=true}document.querySelectorAll('dialog[open]').forEach(d=>d.close());$('musicLibrary').hidden=true;exitVideo();leaveVuFullscreen();window.scrollTo({top:0,behavior:'smooth'})}
function dashboardBack(){const open=document.querySelector('dialog[open]');if(open){open.close();return}dashboardHome()}
$('dashBack').onclick=$('dashBackSide').onclick=dashboardBack;$('dashHome').onclick=$('dashHomeSide').onclick=dashboardHome;
$('dashPower').onclick=()=>{media.pause();status('Reprodução pausada.')};
function dashVolume(delta){media.volume=Math.max(0,Math.min(1,media.volume+delta));$('volume').value=media.volume;status('Volume: '+Math.round(media.volume*100)+'%')}
$('dashVolUp').onclick=()=>dashVolume(.05);$('dashVolDown').onclick=()=>dashVolume(-.05);
$('dashImport').onclick=()=>$('files').click();
$('dashMusic').onclick=()=>{$('musicLibrary').hidden=false;$('musicLibrary').scrollIntoView({behavior:'smooth',block:'start'})};
$('dashApps').onclick=()=>$('menu').showModal();$('dashBluetooth').onclick=()=>$('soundConnect').showModal();$('dashSettings').onclick=()=>$('settings').showModal();$('dashRadio').onclick=()=>$('radioSettings').showModal();
$('radioAdd').onclick=async()=>{try{const url=new URL($('radioAddress').value.trim());if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw Error('Use um endereço HTTP ou HTTPS de áudio.');const item={id:'radio-'+Date.now(),name:$('radioName').value.trim()||'Minha rádio',kind:'audio',remote:true,sourceLabel:'Rádio pela internet',url:url.href,size:0,favorite:false};tracks.push(item);render();$('radioSettings').close();await select(item.id)}catch(e){$('radioStatus').textContent=e.message||'Confira o endereço da rádio.'}};

media.addEventListener('play',()=>{if(tracks.find(t=>t.id===current)?.kind==='video'){media.hidden=false;if(!videoExpanded)toggleVideoFullscreen()}});

$('playbackOptionsOpen').onclick=()=>{$('menu').close();$('playbackSettings').showModal()};
