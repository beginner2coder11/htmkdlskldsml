window.SILVER_ONE_CONFIG = {
  SUPABASE_URL: "https://pkhxvxjtxkzdujpppnmj.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_lVBLKTFPy9atxKOzb-gDKQ_VXpQNQM1"
};
