/* Se inyecta al terminar de cargar la página. Hace que lo que el HTML ya intenta
   (Capacitor Share/Filesystem, <a download>, portapapeles) funcione en Android. */
(function () {
  var B = window.AndroidBridge;
  if (!B || window.__androidShim) return;
  window.__androidShim = true;

  // --- Share + Filesystem con la misma interfaz que usa la página (estilo Capacitor) ---
  window.Capacitor = window.Capacitor || {};
  var P = window.Capacitor.Plugins = window.Capacitor.Plugins || {};

  P.Filesystem = {
    writeFile: function (o) {
      return new Promise(function (res, rej) {
        try {
          if (B.writeCacheFile(String(o.path), String(o.data))) res({ uri: String(o.path) });
          else rej(new Error('No se pudo escribir el archivo'));
        } catch (e) { rej(e); }
      });
    },
    getUri: function (o) { return Promise.resolve({ uri: String(o.path) }); }
  };

  P.Share = {
    share: function (o) {
      return new Promise(function (res, rej) {
        try {
          var f = (o.files && o.files[0]) || '';
          B.share(String(o.title || ''), String(o.text || ''), String(f));
          res({});
        } catch (e) { rej(e); }
      });
    }
  };

  // --- Descargas: <a download href="data:..."> o blob: ---
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var name = this.getAttribute('download');
    var href = this.href || '';
    if (name !== null && href) {
      name = name || 'archivo';
      if (href.indexOf('data:') === 0 && /;base64,/.test(href)) {
        var i = href.indexOf(',');
        var mime = href.substring(5, href.indexOf(';')) || 'application/octet-stream';
        B.saveFile(name, href.substring(i + 1), mime);
        return;
      }
      if (href.indexOf('blob:') === 0) {
        fetch(href).then(function (r) { return r.blob(); }).then(function (b) {
          var fr = new FileReader();
          fr.onload = function () {
            var d = String(fr.result);
            B.saveFile(name, d.substring(d.indexOf(',') + 1), b.type || 'application/octet-stream');
          };
          fr.readAsDataURL(b);
        });
        return;
      }
    }
    return origClick.apply(this, arguments);
  };

  // --- Portapapeles ---
  try {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText: function (t) { B.copyText(String(t)); return Promise.resolve(); } }
    });
  } catch (e) { }
})();
