VOL EduGames - कक्षा 3 से 8 के लिए 180 शैक्षिक गेम
Developer: Suryakant Bharti (सूर्यकांत भारती) · Vision Of Learners · visionoflearners.in

फ़ाइलें:
  index.html   - पूरा ऐप (सभी 6 दुनिया, 180 गेम)
  vol-logo.png - Vision Of Learners लोगो
  vol-dev.jpg  - डेवलपर फ़ोटो

चलाने के लिए: index.html को किसी भी ब्राउज़र में खोलें।
APK के लिए: इस पूरे फ़ोल्डर (तीनों फ़ाइलें साथ) को किसी HTML-to-APK टूल
(जैसे WebIntoApp, Website 2 APK Builder या Android WebView प्रोजेक्ट) में डालें।
तीनों फ़ाइलें एक ही फ़ोल्डर में रहनी चाहिए।
नोट: फ़ॉन्ट (Baloo 2) इंटरनेट से लोड होता है; ऑफ़लाइन में सामान्य फ़ॉन्ट दिखेगा, गेम चलते रहेंगे।
