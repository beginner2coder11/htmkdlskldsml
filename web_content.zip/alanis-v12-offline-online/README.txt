AL-ANIS BUSINESS — OFFLINE + ONLINE ACCESS AND BACKUP

1. Upload all files in this ZIP together to an HTTPS website, for example GitHub Pages.
2. Open the website while online once, then use browser Add to Home Screen / Install.
3. Subsequent launches can work offline after the service worker caches the app.
4. All business records are saved locally in the browser on that device. A Save action does not send records to any cloud.
5. For cloud BACKUP, open Backup > Share backup file, then select Google Drive, iCloud Drive, or another secure storage provider. This is a MANUAL cloud backup.
6. To move data to another device, download the saved JSON file, open the app there and choose Restore backup file.
7. Restore replaces existing records; export a backup first. Do not use two devices independently without a deliberate transfer process.
8. The HTML file opened directly from a local file may not have service worker support. Offline website installation requires HTTPS (or localhost).
9. No account sign-in, automatic cloud backup, automatic two-device sync or encrypted remote storage is included.
10. Test on your own Android/iPhone before relying on it for important bookkeeping.
