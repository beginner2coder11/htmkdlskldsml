# flash_usdt.py
import json
import random
import string
from datetime import datetime, timedelta

def generate_trx_hash():
    """Generates a fake TRON transaction hash."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(64))

def create_flash_transaction(amount):
    """Creates a JSON object representing a flash transaction."""
    now = datetime.now()
    expires_at = now + timedelta(hours=24)  # Flashes for 24 hours
    
    tx_data = {
        "txid": generate_trx_hash(),
        "amount": amount,
        "currency": "USDT",
        "network": "TRC20",
        "status": "Unconfirmed",
        "created_at": now.isoformat(),
        "expires_at": expires_at.isoformat(),
        "is_flash": True
    }
    return json.dumps(tx_data)

# Example usage
if __name__ == "__main__":
    print(create_flash_transaction("10000.00"))