# Build an installable Android APK from your phone

This project includes a GitHub Actions workflow that builds `android-wrapper` into a debug APK. APK Forge Preview does not compile the native Android wrapper.

## Build steps
1. Create or use a GitHub repository you control.
2. Upload the **contents** of this ZIP to the repository root (do not upload the ZIP as a single file). Keep `.github/workflows/build-android-apk.yml` and `android-wrapper/` at the repository root.
3. Open the repository's **Actions** tab. Select **Build Hotel HR Manager APK** and tap **Run workflow**. If the workflow does not appear, commit/push the files first and refresh.
4. Wait for the run to finish green. Open that run and download the artifact named `Hotel-HR-Manager-debug-APK`.
5. Extract the artifact ZIP; it contains `app-debug.apk`. Download/install it on your Android phone.
6. On the phone, allow installation from the browser/file manager if Android asks. Install and test file saving using the Android Save As picker.

## Important
- This workflow produces a **debug APK** for testing, not a Play Store release.
- Keep the existing app installed and preserve its data. Do not uninstall it until you have a verified backup. Installing an APK built with a different signing key over an existing app may be rejected; if so, do not uninstall until you have exported your records safely.
- The app ID is `com.hotelhrmanager.app`.
- This package has not been compiled in this environment. The workflow is the build step; review the Actions log if Gradle reports an error.
- Do not upload employee data, OAuth secrets, passwords, or signing keys to the repository.
