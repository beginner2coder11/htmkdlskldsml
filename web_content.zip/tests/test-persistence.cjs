// npm install jsdom fake-indexeddb; NODE_PATH may point at their installation.
const {JSDOM}=require('jsdom'),{IDBFactory}=require('fake-indexeddb');
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const root=path.join(__dirname,'..'),idb=new IDBFactory();
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function wait(f){for(let i=0;i<150;i++){if(f())return;await pause(10)}throw Error('Timeout')}
async function open(){const dom=new JSDOM(fs.readFileSync(path.join(root,'index.html'),'utf8'),{url:'https://compras.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.indexedDB=idb;w.structuredClone=structuredClone;w.scrollTo=()=>{};w.URL.createObjectURL=()=> 'blob:test';w.URL.revokeObjectURL=()=>{};}});await wait(()=>dom.window.document.querySelector('.menu-tile'));return dom;}
(async()=>{
let dom=await open(),w=dom.window;let ev=s=>w.eval(s),click=(act)=>{const e=w.document.querySelector('[data-act="'+act+'"]');assert(e,act);e.click()};
await ev(`transaction(d=>{d.products.push({id:'p',name:'Arroz',category:'Alimentos',saleUnit:'unidade',units:12,image:'',archived:false});d.sequence=1;d.purchases.push({id:'old',number:1,date:'2026-10-20',reference:'A',capital:50000,freight:100,expenses:[],invoiceTotal:null,notes:'',receipt:'',items:[{id:'i',productId:'p',name:'Arroz',category:'Alimentos',saleUnit:'unidade',boxes:2,units:24,cost:1200,price:100,margin:null}]});})`);
await ev('newPurchase()');ev("chooseProduct('p')");assert.equal(ev('editor.items[0].units'),12);assert.equal(ev('editor.items[0].cost'),null);assert.equal(ev('editor.capital'),null);assert.equal(ev('editor.freight'),null);
ev('editor.items[0].cost=2400;editor.items[0].price=300;refreshEditor()');await ev('saveDraft()');const first=ev('editor.id');
await ev('newPurchase()');assert.notEqual(ev('editor.id'),first);assert.equal(ev('editor.items.length'),0);assert.equal(ev('draftList().length'),1);
ev("chooseProduct('p');editor.items[0].cost=1200;editor.items[0].price=150;");await ev('savePurchase()');assert.equal(ev('db.purchases.length'),2);assert.equal(ev('draftList().length'),1);
// Real DOM click handlers: permanently delete one purchase.
click('deletePurchase');click('erasePurchase');await wait(()=>ev('db.purchases.length')===1&&!ev('operationBusy'));assert.equal(ev('db.trash.length'),0);assert.equal(ev('CC.history(db,"p").length'),1);assert.equal(ev('db.products.length'),1);
dom.window.close();dom=await open();w=dom.window;assert.equal(ev('db.purchases.length'),1);assert.equal(ev('draftList().length'),1);
await ev("editPurchase('old')");click('deletePurchase');click('movePurchase');await wait(()=>ev('db.purchases.length')===0&&!ev('operationBusy'));assert.equal(ev('db.trash.length'),1);
await ev("navigate('settings')");click('trash');click('restoreTrash');await wait(()=>ev('db.purchases.length')===1);click('closeModal');await ev("editPurchase('old')");click('deletePurchase');click('movePurchase');await wait(()=>ev('db.purchases.length')===0&&!ev('operationBusy'));await ev("navigate('settings')");click('trash');click('purgeTrash');click('confirm');await wait(()=>ev('db.trash.length')===0);
// Reset while an old draft save is queued and lifecycle events occur.
click('closeModal');await ev('newPurchase()');ev("chooseProduct('p');editor.items[0].cost=100;editor.items[0].price=200;");await ev('saveDraft()');await ev("navigate('settings')");click('reset');w.document.querySelector('#resetWord').value=' apagar ';
ev('globalThis.originalSave=Store.save;Store.save=async d=>{await new Promise(r=>setTimeout(r,30));return originalSave(d)}');click('doReset');w.document.dispatchEvent(new w.Event('visibilitychange'));
await wait(()=>ev('db.products.length')===0&&!ev('operationBusy'));assert.equal(ev('draftList().length'),0);assert.equal(ev('db.purchases.length'),0);assert.equal(ev('db.trash.length'),0);
dom.window.close();dom=await open();w=dom.window;assert.equal(ev('db.products.length'),0);assert.equal(ev('db.purchases.length'),0);assert.equal(ev('draftList().length'),0);
// Failed write must not report deletion or mutate in-memory data.
await ev(`transaction(d=>d.products.push({id:'p',name:'Teste',category:'Outros',saleUnit:'unidade',units:1,image:'',archived:false}))`);await ev("navigate('settings')");click('reset');w.document.querySelector('#resetWord').value='APAGAR';ev('Store.save=async()=>{throw Error("Falha simulada") }');click('doReset');await wait(()=>!ev('operationBusy'));assert.equal(ev('db.products.length'),1);assert(w.document.querySelector('#toast').textContent.includes('Não foi possível'));
dom.window.close();console.log('OK: cliques reais no DOM; compras independentes; rascunhos separados; eliminação permanente; mover/restaurar/eliminar; reset com espaços/minúsculas; reabertura com IndexedDB simulado partilhado; erro de gravação preserva dados.');
})().catch(e=>{console.error(e);process.exit(1)});
