// Testes de interface com DOM mínimo simulado; não substituem Android/WebView.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.join(__dirname,'..'),CC=require('../core.js');
const nodes=new Map();function node(key){if(!nodes.has(key))nodes.set(key,{innerHTML:'',textContent:'',value:'',style:{},classList:{contains:()=>true,add(){},remove(){}},focus(){},querySelector:s=>node(key+' '+s)});return nodes.get(key)}
let saved=CC.defaults();const context=vm.createContext({CC,console,Intl,Blob,setTimeout:()=>0,clearTimeout(){},document:{querySelector:node,querySelectorAll:()=>[],addEventListener(){},body:{style:{},dataset:{},classList:{add(){},remove(){}}}},window:{addEventListener(){},scrollTo(){}},Store:{load:async()=>CC.copy(saved),save:async d=>{saved=CC.copy(d)}}});
vm.runInContext(fs.readFileSync(path.join(root,'vendor/pdf-lib.min.js'),'utf8'),context);vm.runInContext(fs.readFileSync(path.join(root,'reports.js'),'utf8'),context);vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),context);
const run=s=>vm.runInContext(s,context);
(async()=>{await new Promise(r=>setImmediate(r));
assert.equal((node('#main').innerHTML.match(/class="menu-tile/g)||[]).length,6);
await run(`transaction(d=>{d.products.push({id:'rice',name:'Arroz',category:'Alimentos',saleUnit:'saco',units:1,image:'',archived:false});d.sequence=1;d.purchases.push({id:'old',number:1,date:'2026-10-23',reference:'',capital:null,freight:null,expenses:[],invoiceTotal:null,notes:'',receipt:'',items:[{id:'i1',productId:'rice',name:'Arroz',category:'Alimentos',saleUnit:'saco',boxes:2,units:1,cost:15000,price:18000,margin:null}]});})`);
run('renderHome()');assert(!node('#main').innerHTML.includes('Arroz'));assert(!node('#main').innerHTML.includes(new Intl.NumberFormat('pt-AO',{minimumFractionDigits:2}).format(15000)));
run(`beginNew();editor.date='2026-10-24';chooseProduct('rice')`);assert.equal(run('editor.items[0].cost'),null);assert.equal(run('editor.items[0].price'),null);assert(node('#main').innerHTML.includes('previous-values'));
const itemid=run('editor.items[0].id');assert(node('[data-item="'+itemid+'"] .previous-values').innerHTML.includes(new Intl.NumberFormat('pt-AO',{minimumFractionDigits:2}).format(15000)));assert(node('[data-item="'+itemid+'"] .previous-values').innerHTML.includes(new Intl.NumberFormat('pt-AO',{minimumFractionDigits:2}).format(18000)));
run('editor.items[0].cost=16000;editor.items[0].price=19000;editor.freight=1000;refreshEditor()');const badge=node('[data-item="'+itemid+'"] .comparison').innerHTML;assert(badge.includes('Subiu'));assert(badge.includes(new Intl.NumberFormat('pt-AO',{minimumFractionDigits:2}).format(1000)));assert(badge.includes('%'));
assert.equal(run('CC.calc(editor).rows[0].boxProfit'),3000);assert.equal(run('CC.calc(editor).net'),2000);
await run('savePurchase()');assert.equal(saved.purchases.length,2);assert.equal(saved.purchases[0].items[0].cost,15000);assert.equal(CC.history(saved,'rice').length,2);CC.validateDB(saved);
run('renderReports()');assert(!node('#main').innerHTML.includes('Comparar'));assert.equal(run('typeof Reports.compare'),'undefined');
const blob=await run('Reports.pdf(Reports.purchase(db,db.purchases[1]))');assert(blob.size>1000);
console.log('OK: menu sem compras, cadastro preservado, referência anterior, novos valores vazios, variação Kz/%, despesas apenas no resumo, gravação, histórico e PDF. DOM simulado.');
})().catch(e=>{console.error(e);process.exitCode=1});
