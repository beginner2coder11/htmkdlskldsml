# Leave Tracker addition

This update adds a Leave Tracker view to the existing HR app. Annual leave accrues at 1.75 days per completed month (21 days after 12 months), approved annual leave plans are deducted from the estimated balance, and PH is tracked separately. HR must enter the official public holiday dates for each year; variable dates are not assumed to repeat. PH credits are recorded once per employee/holiday when the employee has a joining date on or before the holiday and no approved annual leave covering that date.

Important: employee joining dates should be stored in `startDate`, `joiningDate`, or `dateJoined`. Existing leave plans should identify the employee by `employeeKey` or match `employeeName` to the employee profile name. Check policy and local requirements before using this for payroll/legal decisions.
