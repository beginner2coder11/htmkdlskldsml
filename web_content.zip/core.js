/* Controlo de Compras · regras independentes da interface */
(function(root){
'use strict';
const nullable=v=>v===null||v===undefined||String(v).trim()==='';
function number(v){if(nullable(v))return null;if(typeof v==='number')return Number.isFinite(v)?v:NaN;let s=String(v).trim().replace(/\s/g,'');if(s.includes(','))s=s.replace(/\./g,'').replace(',','.');return Number(s);}
const round=v=>Math.round((v+Number.EPSILON)*100)/100;
const localDate=()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');};
const id=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2);
const copy=v=>JSON.parse(JSON.stringify(v));
function item(i){
 const boxes=number(i.boxes),units=number(i.units),cost=number(i.cost),price=number(i.price),margin=number(i.margin);
 const valid=[boxes,units,cost].every(v=>v!==null&&Number.isFinite(v))&&boxes>0&&units>0&&cost>=0;
 const qty=valid?boxes*units:null,goods=valid?round(boxes*cost):null,unitCost=valid?cost/units:null;
 const priced=price!==null&&Number.isFinite(price)&&price>=0;
 const revenue=valid&&priced?round(qty*price):null,unitProfit=valid&&priced?price-unitCost:null;
 return {qty,goods,unitCost,price,unitProfit,boxProfit:unitProfit===null?null:unitProfit*units,profit:revenue===null?null:round(revenue-goods),revenue,
 margin:priced&&price>0&&valid?(price-unitCost)/price*100:null,
 suggested:valid&&margin!==null&&Number.isFinite(margin)&&margin>=0&&margin<100?Math.ceil((unitCost/(1-margin/100)-1e-9)*100)/100:null,valid};
}
function calc(p){
 const rows=(p.items||[]).map(item),goods=round(rows.reduce((s,r)=>s+(r.goods||0),0)),freight=number(p.freight)||0,other=round((p.expenses||[]).reduce((s,e)=>s+(number(e.value)||0),0));
 const complete=rows.length>0&&rows.every(r=>r.profit!==null),revenue=complete?round(rows.reduce((s,r)=>s+r.revenue,0)):null,gross=complete?round(rows.reduce((s,r)=>s+r.profit,0)):null,investment=round(goods+freight+other),capital=number(p.capital);
 return {rows,goods,freight,other,investment,revenue,gross,net:gross===null?null:round(gross-freight-other),remaining:capital===null?null:round(capital-investment),complete};
}
function validatePurchase(p){
 const errors=[];
 if(!/^\d{4}-\d{2}-\d{2}$/.test(p.date)||!Number.isFinite(Date.parse(p.date+'T12:00:00Z'))||new Date(p.date+'T12:00:00Z').toISOString().slice(0,10)!==p.date)errors.push('Escolha uma data válida.');
 if(!p.items.length)errors.push('Adicione pelo menos um produto.');
 ['capital','freight','invoiceTotal'].forEach(k=>{const v=number(p[k]);if(v!==null&&(!Number.isFinite(v)||v<0))errors.push('Capital, frete e total da fatura devem ser positivos ou ficar vazios.');});
 for(const e of p.expenses||[]){const v=number(e.value);if(v===null||!Number.isFinite(v)||v<0||!e.name.trim())errors.push('Preencha a descrição e o valor de cada despesa.');}
 p.items.forEach((i,n)=>{
 if(!String(i.name||'').trim())errors.push('Indique o nome do produto '+(n+1)+'.');
 if(!item(i).valid)errors.push('Confira quantidade, unidades e custo de '+(i.name||'produto '+(n+1))+'.');
 const pr=number(i.price),m=number(i.margin);
 if(pr!==null&&(!Number.isFinite(pr)||pr<0))errors.push('Preço de venda inválido em '+i.name+'.');
 if(m!==null&&(!Number.isFinite(m)||m<0||m>=100))errors.push('A margem de '+i.name+' deve estar entre 0% e menos de 100%.');
 });return [...new Set(errors)];
}
const sortPurchases=(a,b)=>a.date.localeCompare(b.date)||a.number-b.number;
function history(db,pid){return db.purchases.slice().sort(sortPurchases).flatMap(p=>p.items.filter(i=>i.productId===pid).map(i=>({purchase:p,item:i,calc:item(i)})));}
function previous(db,i,p){return history(db,i.productId).filter(h=>h.purchase.id!==p.id&&(h.purchase.date<p.date||(h.purchase.date===p.date&&h.purchase.number<p.number))).pop()||null;}
function variation(current,prior){if(current===null||prior===null||!Number.isFinite(current)||!Number.isFinite(prior))return null;const delta=round(current-prior);return {delta,pct:prior?delta/prior*100:null,label:delta>0?'Subiu':delta<0?'Desceu':'Igual'};}
function defaults(){return {schema:2,settings:{business:'Controlo de Compras'},sequence:0,products:[],categories:['Alimentos','Bebidas','Higiene','Limpeza','Eletrónicos','Outros'],purchases:[],trash:[],draft:null,drafts:[],lastBackup:null};}
function validateDB(d){
 if(!d||d.schema!==2||!Array.isArray(d.products)||!Array.isArray(d.purchases)||!Array.isArray(d.categories)||!Array.isArray(d.trash)||!d.settings||typeof d.settings.business!=='string')throw Error('Formato de backup inválido.');
 if(!d.categories.every(c=>typeof c==='string'&&c.trim()))throw Error('Categorias inválidas.');
 const safeId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,100}$/.test(v);
 const ids=new Set();
 for(const p of d.products){if(!p||!safeId(p.id)||typeof p.name!=='string'||!p.name.trim()||ids.has(p.id)||typeof p.category!=='string'||typeof p.saleUnit!=='string')throw Error('Produto inválido ou duplicado.');ids.add(p.id);if(p.image&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(p.image))throw Error('Imagem inválida.');}
 const pids=new Set(),nums=new Set();
 const validImage=v=>!v||typeof v==='string'&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(v);
 function record(p,draft=false){
 if(!p||!safeId(p.id)||!Number.isInteger(p.number)||p.number<1||typeof p.date!=='string'||!Array.isArray(p.items)||!Array.isArray(p.expenses))throw Error('Registo de compra inválido.');
 if(!draft&&validatePurchase(p).length)throw Error('Compra inválida.');
 const rows=new Set();for(const i of p.items){if(!i||!safeId(i.id)||rows.has(i.id)||typeof i.name!=='string'||typeof i.category!=='string'||typeof i.saleUnit!=='string'||!ids.has(i.productId))throw Error('Produto inválido numa compra.');rows.add(i.id);}
 if(!validImage(p.receipt))throw Error('Comprovativo inválido.');
 if(p.expenses.some(e=>!e||typeof e.name!=='string'))throw Error('Despesa inválida.');
 }
 for(const p of d.purchases){record(p);if(pids.has(p.id)||nums.has(p.number))throw Error('Compra duplicada.');pids.add(p.id);nums.add(p.number);}
 for(const t of d.trash){if(!t||t.type!=='purchase')throw Error('Lixeira inválida.');record(t.value);if(pids.has(t.value.id)||nums.has(t.value.number))throw Error('Compra duplicada na lixeira.');pids.add(t.value.id);nums.add(t.value.number);}
 if(!Number.isInteger(d.sequence)||d.sequence<Math.max(0,...nums))throw Error('Sequência inválida.');
 if(d.drafts!==undefined&&!Array.isArray(d.drafts))throw Error('Rascunhos inválidos.');
 const draftIds=new Set();for(const p of [...(d.drafts||[]),...(d.draft?[d.draft]:[])]){record(p,true);if(draftIds.has(p.id)||d.trash.some(t=>t.value.id===p.id))throw Error('Rascunho duplicado ou eliminado.');draftIds.add(p.id);}
 return copy(d);
}
function migrateOld(x){
 if(!x||!Array.isArray(x.purchases)||!Array.isArray(x.products))throw Error('Backup antigo inválido.');
 const d=defaults();d.settings.business=x.settings?.empresa||d.settings.business;
 d.products=x.products.map(p=>({id:p.id||id(),name:p.name,category:p.category||'Outros',saleUnit:'unidade',units:1,image:'',archived:false,notes:p.notes||''}));
 let skipped=0;
 for(const p of x.purchases){if(['Cancelada','Planeada'].includes(p.state)){skipped++;continue;}
 const items=p.items.filter(i=>i.name?.trim()).map(i=>{let prod=d.products.find(v=>v.id===i.productId)||d.products.find(v=>v.name.toLowerCase()===i.name.toLowerCase());if(!prod){prod={id:id(),name:i.name,category:i.category||'Outros',saleUnit:'unidade',units:i.unitsPerBox||1,image:'',archived:false,notes:''};d.products.push(prod);}
 return {id:id(),productId:prod.id,name:i.name,category:prod.category,saleUnit:'unidade',boxes:i.boxes,units:i.unitsPerBox,cost:i.boxCost,price:i.salePrice,margin:null};});
 const n={id:p.id||id(),number:++d.sequence,date:p.date,capital:p.capitalBefore??null,freight:p.freight||null,expenses:p.other?[{name:'Outras despesas',value:p.other}]:[],reference:'',invoiceTotal:null,notes:p.notes||'',receipt:'',items};
 if(validatePurchase(n).length)throw Error('Há compras antigas inválidas. Corrija o backup original antes de importar.');d.purchases.push(n);
 }
 d.categories=[...new Set([...d.categories,...d.products.map(p=>p.category)])];return {data:validateDB(d),skipped};
}
root.CC={number,round,localDate,id,copy,item,calc,validatePurchase,history,previous,variation,defaults,validateDB,migrateOld};
if(typeof module!=='undefined')module.exports=root.CC;
})(globalThis);
