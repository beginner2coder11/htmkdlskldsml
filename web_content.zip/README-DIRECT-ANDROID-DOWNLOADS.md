# Hotel HR Manager — direct Android downloads

This cumulative source preserves the combined Approved leave dashboard card and Leave Plans Excel/CSV import UI.

## Download behavior
- On Android 10 (API 29) and newer, files saved through `HRAndroid.saveFile(...)` are written through Android MediaStore to `Download/Hotel HR Manager/`, without opening a Save As dialog.
- On Android 6–9, the app uses the Android system Save As picker.
- The JavaScript save callback reports success only after the native write completes.

## Important
This is source code, not an APK. The direct-download implementation applies to builds that include `android-wrapper/` and its `MainActivity.kt` native bridge. If APK Forge packages only the `hrsettings/` web files and does not compile this Android wrapper, the native direct-download behavior will not be included. Build and test the APK before relying on it for HR records.
