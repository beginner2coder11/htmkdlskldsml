# ScreenPro Recorder — Android Studio Starter

یہ ZIP ایک **Native Android Studio project starter** ہے، HTML-to-APK فائل نہیں۔ حقیقی screen recording کے لیے Android کا MediaProjection اجازت والا نظام استعمال ہوتا ہے۔

## شامل فیچرز
- Home screen اور Record/Stop controls
- ویڈیو ریکارڈنگ MP4 میں
- مائیکروفون آڈیو کا آپشن
- 380p، 420p، 720p، 1080p اور 4K quality انتخاب
- ریکارڈنگ فون کی Movies/ScreenPro میں محفوظ کرنے کی کوشش
- سادہ Gallery list، جس میں ایپ کی محفوظ کردہ ویڈیوز دکھتی ہیں

## اہم بات
- Android صرف system screen-capture permission dialog کے بعد ریکارڈنگ کی اجازت دیتا ہے۔
- 4K ہر فون پر ممکن نہیں؛ فون کی supported encoder/resolution کے مطابق ریکارڈنگ ناکام بھی ہو سکتی ہے۔ 380p/420p کو قریب ترین عملی resolution پر map کیا گیا ہے۔
- Highlight/drawing overlay اور floating tools اس ابتدائی ورژن میں ابھی شامل نہیں؛ انہیں اگلے مرحلے میں الگ overlay permission اور drawing layer کے ساتھ بنانا ہوگا۔
- یہ project source code ہے؛ APK خودبخود تیار نہیں۔ اسے Android Studio میں کھول کر Gradle sync اور Build APK کرنا ہوگا۔

## Build
1. Android Studio میں اس فولڈر کو Open کریں۔
2. Gradle sync مکمل کریں۔
3. Build > Build APK(s) منتخب کریں۔
4. فون پر انسٹال کرکے Record دبائیں، پھر Android کے اجازت والے ڈائیلاگ میں Start now کریں۔
