package com.screenpro.recorder

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.screenpro.recorder.START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_QUALITY = "quality"
        const val EXTRA_MIC = "mic"
        private const val CHANNEL_ID = "screenpro_recording"
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var outputUri: android.net.Uri? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            createNotificationChannel()
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("ScreenPro is recording")
                .setContentText("Tap Stop in ScreenPro to finish recording.")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .build()
            startForeground(77, notification)
            try {
                startRecording(intent)
            } catch (e: Exception) {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                   else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA) as? Intent
        if (data == null) throw IllegalStateException("Missing screen capture permission data")

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels
        val density = metrics.densityDpi

        val quality = intent.getStringExtra(EXTRA_QUALITY) ?: "720p"
        val targetH = when (quality) {
            "380p" -> 380
            "420p" -> 420
            "720p" -> 720
            "1080p" -> 1080
            "4K" -> 2160
            else -> 720
        }
        val outH = minOf(targetH, screenH)
        val outW = (outH * screenW.toFloat() / screenH).toInt().coerceAtLeast(2) / 2 * 2
        val bitrate = when (quality) {
            "4K" -> 18000000
            "1080p" -> 8000000
            "720p" -> 4500000
            else -> 1500000
        }

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ScreenPro_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenPro")
        }
        outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create output video")
        val fd = contentResolver.openFileDescriptor(outputUri!!, "w")?.fileDescriptor
            ?: throw IllegalStateException("Could not open output file")

        recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        recorder?.apply {
            if (intent.getBooleanExtra(EXTRA_MIC, true)) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            if (intent.getBooleanExtra(EXTRA_MIC, true)) setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoSize(outW, outH)
            setVideoEncodingBitRate(bitrate)
            setVideoFrameRate(30)
            setOutputFile(fd)
            prepare()
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        recorder?.start()
        display = projection?.createVirtualDisplay(
            "ScreenProDisplay", outW, outH, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            recorder?.surface, null, null
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) {}
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        outputUri?.let {
            val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            if (Build.VERSION.SDK_INT >= 29) contentResolver.update(it, values, null, null)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
