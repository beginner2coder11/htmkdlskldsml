package com.screenpro.recorder

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.database.Cursor

class MainActivity : Activity() {
    private lateinit var quality: Spinner
    private lateinit var mic: CheckBox
    private lateinit var status: TextView
    private val qualities = listOf("380p", "420p", "720p", "1080p", "4K")
    private val requestCapture = 4401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 18, 38)
        window.navigationBarColor = Color.rgb(12, 18, 38)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(12, 18, 38))
        }
        val title = TextView(this).apply {
            text = "ScreenPro"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Screen Recorder • Capture • Save"
            textSize = 14f
            setTextColor(Color.rgb(170, 190, 220))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready to record"
            textSize = 16f
            setTextColor(Color.rgb(100, 235, 180))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 18)
        }
        quality = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, qualities)
        }
        mic = CheckBox(this).apply {
            text = "Record microphone audio"
            setTextColor(Color.WHITE)
            isChecked = true
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(100, 235, 180))
        }
        val record = makeButton("●  Start Screen Recording")
        record.setOnClickListener { requestRecordingPermission() }
        val stop = makeButton("■  Stop Recording")
        stop.setOnClickListener {
            stopService(Intent(this, RecordingService::class.java))
            status.text = "Recording stopped. Check Gallery / Movies/ScreenPro."
        }
        val gallery = makeButton("▣  Gallery / Saved Videos")
        gallery.setOnClickListener { showGallery() }
        val note = TextView(this).apply {
            text = "Choose quality before recording. Android will ask permission before capturing your screen. 4K depends on device support."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(4, 20, 4, 10)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(label("Video quality"))
        root.addView(quality)
        root.addView(mic)
        root.addView(record)
        root.addView(stop)
        root.addView(gallery)
        root.addView(note)
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.WHITE)
        setPadding(0, 16, 0, 8)
    }

    private fun makeButton(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(43, 91, 180))
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 8, 0, 8)
        layoutParams = p
    }

    private fun requestRecordingPermission() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Legacy result callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, RecordingService::class.java).apply {
                action = RecordingService.ACTION_START
                putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
                putExtra(RecordingService.EXTRA_DATA, data)
                putExtra(RecordingService.EXTRA_QUALITY, quality.selectedItem.toString())
                putExtra(RecordingService.EXTRA_MIC, mic.isChecked)
            }
            startForegroundService(intent)
            status.text = "Recording started — use Stop Recording to finish."
        } else {
            status.text = "Screen capture permission was cancelled."
        }
    }

    private fun showGallery() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.rgb(12, 18, 38))
        }
        root.addView(TextView(this).apply {
            text = "Saved Videos"
            textSize = 26f
            setTextColor(Color.WHITE)
        })
        val list = ListView(this)
        val names = mutableListOf<String>()
        val uris = mutableListOf<Uri>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.RELATIVE_PATH)
        contentResolver.query(collection, projection, "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("%Movies/ScreenPro%"), "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                names.add(c.getString(1) ?: "Screen recording")
                uris.add(Uri.withAppendedPath(collection, id.toString()))
            }
        }
        if (names.isEmpty()) names.add("No ScreenPro videos found yet.")
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        list.setOnItemClickListener { _, _, position, _ ->
            if (position < uris.size) {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uris[position], "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(makeButton("← Back to Home").apply { setOnClickListener { showHome() } })
        setContentView(root)
    }
}
