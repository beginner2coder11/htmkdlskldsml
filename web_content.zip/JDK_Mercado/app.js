const seed = [
 {id:1,title:"Taladro inalámbrico",price:1250,category:"Herramientas",description:"Taladro inalámbrico en buen estado. Incluye batería y cargador.",seller:"Carlos",phone:"",emoji:"🛠️",place:"Chihuahua"},
 {id:2,title:"Tractor agrícola",price:285000,category:"Maquinaria",description:"Tractor para trabajo de campo. Pregunta por más información y condiciones.",seller:"Miguel",phone:"",emoji:"🚜",place:"Chihuahua"},
 {id:3,title:"Teléfono Android",price:3200,category:"Electrónica",description:"Teléfono usado, funcionando correctamente. Se puede revisar al entregar.",seller:"Ana",phone:"",emoji:"📱",place:"Delicias"},
 {id:4,title:"Juego de herramientas",price:890,category:"Herramientas",description:"Juego de herramientas para taller y uso en casa.",seller:"Luis",phone:"",emoji:"🧰",place:"Cuauhtémoc"},
 {id:5,title:"Camioneta usada",price:95000,category:"Vehículos",description:"Camioneta de trabajo. Papeles para revisar con el vendedor.",seller:"Pedro",phone:"",emoji:"🛻",place:"Chihuahua"},
 {id:6,title:"Refrigerador",price:4600,category:"Hogar",description:"Refrigerador usado en buenas condiciones.",seller:"Rosa",phone:"",emoji:"🧊",place:"Parral"}
];
const $=s=>document.querySelector(s);
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
let products=read("mm_products",seed), favorites=read("mm_favorites",[]), category="Todos", mode="all";
const money=n=>new Intl.NumberFormat("es-MX",{style:"currency",currency:"MXN",maximumFractionDigits:0}).format(n);
function save(){localStorage.setItem("mm_products",JSON.stringify(products));localStorage.setItem("mm_favorites",JSON.stringify(favorites))}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function render(){
 const q=$("#searchInput").value.trim().toLowerCase();
 const list=products.filter(p=>(category==="Todos"||p.category===category)&&(mode!=="saved"||favorites.includes(p.id))&&(!q||(p.title+" "+p.description+" "+p.category+" "+p.place).toLowerCase().includes(q)));
 $("#resultCount").textContent=list.length+" productos";
 $("#productGrid").innerHTML=list.map(p=>`<article class="product" data-id="${p.id}"><div class="photo">${p.photo?`<img src="${p.photo}" alt="">`:p.emoji||"📦"}</div><button class="heart" data-heart="${p.id}" aria-label="Favorito">${favorites.includes(p.id)?"♥":"♡"}</button><div class="p-info"><p class="price">${money(p.price)}</p><p class="p-title">${esc(p.title)}</p><div class="p-meta"><span>${esc(p.place||"México")}</span><span>${esc(p.category)}</span></div></div></article>`).join("");
 $("#emptyState").classList.toggle("hidden",list.length>0);
}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("#productGrid").addEventListener("click",e=>{
 const heart=e.target.closest("[data-heart]");if(heart){const id=Number(heart.dataset.heart);favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];save();render();return}
 const card=e.target.closest("[data-id]");if(card)openProduct(Number(card.dataset.id));
});
function openProduct(id){
 const p=products.find(x=>x.id===id);if(!p)return;
 $("#productDetail").innerHTML=`<p class="eyebrow">${esc(p.category)} · ${esc(p.place||"México")}</p><div class="detail-photo">${p.photo?`<img src="${p.photo}" alt="">`:p.emoji||"📦"}</div><p class="detail-price">${money(p.price)}</p><h3 class="detail-title">${esc(p.title)}</h3><p class="detail-desc">${esc(p.description)}</p><div class="seller-box"><b>Vendedor:</b> ${esc(p.seller||"Usuario")}<br><b>Ubicación:</b> ${esc(p.place||"México")}</div>${p.phone?`<a class="primary full" style="display:block;text-align:center;text-decoration:none" target="_blank" rel="noopener" href="https://wa.me/${p.phone.replace(/\\D/g,"")}">Contactar por WhatsApp</a>`:`<button class="primary full" onclick="alert('En la versión completa se habilitará el chat entre comprador y vendedor.')">Contactar vendedor</button>`}<p class="fine">Consejo: revisa el producto y acuerda una entrega segura antes de pagar.</p>`;
 $("#productDialog").showModal();
}
$("#categories").addEventListener("click",e=>{const b=e.target.closest("[data-cat]");if(!b)return;category=b.dataset.cat;mode="all";document.querySelectorAll(".cat").forEach(x=>x.classList.toggle("active",x===b));render()});
$("#searchInput").addEventListener("input",render);$("#searchBtn").onclick=render;
$("#sellNav").onclick=()=>$("#sellDialog").showModal();
$("#accountBtn").onclick=$("#accountNav").onclick=()=>$("#accountDialog").showModal();
$("#savedNav").onclick=()=>{mode=mode==="saved"?"all":"saved";category="Todos";document.querySelectorAll(".cat").forEach(x=>x.classList.toggle("active",x.dataset.cat==="Todos"));document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("selected"));$("#savedNav").classList.add("selected");render();if(mode==="saved")toast("Mostrando tus favoritos")};
document.querySelectorAll(".nav-item[data-tab]").forEach(x=>x.onclick=()=>{mode="all";document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("selected"));x.classList.add("selected");render()});
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).close());
$("#sellForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.target);let photo="";
 const file=f.get("photo");if(file&&file.size){if(file.size>1500000){toast("La foto pesa demasiado. Usa una imagen menor de 1.5 MB.");return}photo=await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.readAsDataURL(file)})}
 const item={id:Date.now(),title:f.get("title"),price:Number(f.get("price")),category:f.get("category"),description:f.get("description"),seller:f.get("seller"),phone:f.get("phone"),photo,emoji:"📦",place:"México"};
 products.unshift(item);save();e.target.reset();$("#sellDialog").close();category="Todos";mode="all";render();toast("¡Producto publicado en este dispositivo!");
});
$("#myListings").onclick=()=>{toast("En la siguiente versión podrás administrar tu cuenta y publicaciones.");$("#accountDialog").close()};
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();