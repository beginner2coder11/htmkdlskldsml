from flask import Flask, request, jsonify
import sqlite3
import os
import datetime

app = Flask(__name__)

# Database setup (SQLite)
DB_NAME = "transactions.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            wallet_address TEXT,
            amount REAL,
            network TEXT,
            server TEXT,
            use_vpn BOOLEAN,
            hide_ip BOOLEAN,
            stealth_mode BOOLEAN,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    # Serve the HTML file
    with open('index.html', 'r') as f:
        return f.read()

@app.route('/add-btc', methods=['POST'])
def add_btc():
    try:
        data = request.json
        
        wallet_address = data.get('wallet_address')
        amount = data.get('amount')
        network = data.get('network')
        server = data.get('server')
        security = data.get('security', {})
        
        if not wallet_address or not amount:
            return jsonify({'error': 'Missing wallet address or amount'}), 400

        # Simulate processing delay (optional)
        # import time
        # time.sleep(2)

        # Save to database
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            INSERT INTO transactions 
            (wallet_address, amount, network, server, use_vpn, hide_ip, stealth_mode)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            wallet_address, 
            float(amount) if amount != "Max" else 20.0, 
            network, 
            server, 
            security.get('vpn', False), 
            security.get('hide_ip', False), 
            security.get('stealth', False)
        ))
        conn.commit()
        conn.close()

        # Return success response
        return jsonify({
            'message': f'Successfully added {amount} BTC to {wallet_address}',
            'new_balance': '20.10', # Example calculation
            'timestamp': datetime.datetime.now().isoformat()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Run on 0.0.0.0 to allow access from the Android device if running locally
    app.run(host='0.0.0.0', port=5000, debug=True)