# ደዋኡል ቁሉብ — APK አሠራር (በGitHub)

1. github.com ላይ አዲስ **Private** repository ይፍጠሩ (ስም፦ dawaul-qulub)።
2. ይህን ZIP ይክፈቱና ውስጡ ያሉትን ፋይሎችና ፎልደሮች በሙሉ (www፣ .github፣ package.json …) ወደ repository ይጫኑ (Add file → Upload files)።
3. Settings → Secrets and variables → Actions → **KEYSTORE_PASSWORD** ያክሉ (ለሌሎች መተግበሪያዎችዎ የተጠቀሙበትን)።
4. ከዚህ በፊት በAPK Studio መተግበሪያ ሠርተው ከሆነ **KEYSTORE_BASE64**ን ከዚያው ይቅዱ፤ ከዚያ **.github/workflows/keystore.yml**ን ይሰርዙ።
   የመጀመሪያዎ ከሆነ፦ Actions → «Generate Keystore» ን ያስኪዱ፣ የወረደውን keystore-base64.txt ጽሑፍ KEYSTORE_BASE64 ብለው ያስቀምጡ፤ release.keystoreን በሁለት ቦታ ያስቀምጡ፤ keystore.ymlን ይሰርዙ።
5. Actions → «Build APK» አረንጓዴ ሲሆን **app-release** ን ያውርዱ → በስልክዎ ይጫኑ።

ሁሉም ጽሑፎች በAPKው ውስጥ ናቸው — ያለ ኢንተርኔት ይሠራል።
የመተግበሪያ መለያ (App ID): com.alanis.dawaulqulub — በፍጹም አይቀይሩት።
ማዘመን፦ www/index.htmlን ይተኩ፣ በbuild.yml ውስጥ versionCodeን 1 ይጨምሩ።


ማይክራፎን፦ APKው የራስዎን ድምፅ ለመቅዳት ፈቃድ ይጠይቃል (RECORD_AUDIO)። መጀመሪያ «🎙️ ቅዳ» ሲጫኑ «Allow» ይበሉ።
ማሳወቂያ (ኖቲፊኬሽን)፦ APKው መጀመሪያ ሲከፈት የማሳወቂያ ፈቃድ ይጠይቃል — «Allow» ይበሉ። ማስታወሻዎቹ መተግበሪያው ቢዘጋም በሰዓታቸው ይመጣሉ። Samsung ላይ፦ Settings → Apps → دواء القلوب → Battery → «Unrestricted» ቢያደርጉት ይመረጣል።

🔊 የማሳወቂያ ድምፆች፦ www/sounds ፎልደር ውስጥ azan.mp3፣ bell.mp3 እና chime.mp3 ፋይሎችን ያስቀምጡ። ሲገነባ ወደ APKው ይገባሉ። በማስታወሻ ማስተካከያ ውስጥ ለእያንዳንዱ ማስታወሻ ድምፁን ይምረጡ። ስልክ ላይ ከተመረጡ ፋይሎች (📁) የሚመጣ ድምፅ ለማሳወቂያ አይሠራም፤ ገጹ ክፍት ሲሆን ብቻ ይጫወታል።
