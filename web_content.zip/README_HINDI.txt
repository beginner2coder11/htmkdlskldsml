STEELMAKING WITH BNP — GOOGLE PLAY STORE KE LIYE ANDROID PROJECT
===============================================================

Is ZIP mein aapki latest di hui HTML app aur Android wrapper setup shamil hai.

ZAROORI:
Yeh abhi project hai, final upload-ready .aab file nahi. Signed .aab banane,
Android phone par test karne aur Google Play Console par upload karne ke liye
Android Studio wala PC/laptop chahiye.

KYA KAREIN
----------
1. ZIP ko PC/laptop par extract karein.
2. Node.js LTS aur Android Studio install karein.
3. Is folder mein PowerShell/Terminal kholein aur yeh commands ek-ek karke chalayein:

   npm install
   npx cap add android
   npx cap sync android
   npx cap open android

4. Android Studio mein Gradle sync complete hone dein.
5. Pehle emulator ya apne Android phone par app run karke test karein.
6. AOD, LRF, Grade, Materials, PHOS 13-row ledger, CSV Export, Backup aur Restore
   sab ko check karein. Excel ke trusted results se calculation match karein.
7. Android Studio mein:
   Build > Generate Signed Bundle / APK > Android App Bundle (.aab)
   select karein. Release signing key ko safe rakhein.
8. Signed .aab ko pehle Google Play Console ke Internal testing track par upload
   karke test karein. Uske baad hi production release ki taraf badhein.

PACKAGE ID
----------
Starter ID: com.bnp.steelmaking
Agar zaroorat ho to pehle build se pehle is ID ko badlein. Publish hone ke baad
ID badalne par nayi app listing banegi.

PLAY STORE LISTING
------------------
App icon, screenshots, short/full description, privacy policy (jahan applicable),
Data safety, content rating aur account/testing requirements complete karne honge.
Google ki review aur approval guaranteed nahi hai.

CALCULATION
-----------
HTML source ko preserve kiya gaya hai; formulas ko jaanbujhkar modify nahi kiya.
Lekin Android package banana calculation sahi hone ka proof nahi. Release se pehle
Excel parity aur real Android device par testing zaroor karein.

CSV EXPORT
----------
Android WebView mein file download browser se alag behave kar sakta hai. Real
phone par Export CSV test karein. Agar kaam na kare to native file/share support
add karna hoga.

PRIVACY
-------
App ke local storage, backup/export aur kisi bhi data transmission ko review karein.
Play Console declarations aur privacy policy app ke actual behavior ke mutabik
honestly fill karein.
