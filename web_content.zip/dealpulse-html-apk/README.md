# DealPulse HTML-to-APK starter

This package turns the supplied DealPulse project into a working, offline-first HTML app and includes a native Android WebView wrapper project.

## What works
- Add, edit, search, filter, and remove tracked deals
- Current and target prices with savings/discount estimates
- Product links and JSON export
- Saves the watchlist on the device using browser local storage

**Important:** The supplied React app had an empty `src/App.tsx`, so there was no interface to package. This version provides a functional HTML interface. Automatic store price scanning, Gmail alerts, and Google Drive export are not implemented; they need API/service integrations and credentials.

## Build an APK with Android Studio
1. Install Android Studio and its Android SDK.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `dealpulse-html-apk` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync and install any requested Android SDK components.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location. For a shareable release, use **Build > Generate Signed Bundle / APK**.

Package ID: `com.dealpulse.app`

## HTML-only option
The complete web app is at `app/src/main/assets/www/index.html`. You can also host that file on a static web host and open it in Chrome. The APK wrapper loads this local file, so it works without hosting or an internet connection.
