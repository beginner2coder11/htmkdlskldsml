plugins { id("com.android.application") }

android {
    namespace = "de.wochen.plusx"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.wochen.plusx"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
