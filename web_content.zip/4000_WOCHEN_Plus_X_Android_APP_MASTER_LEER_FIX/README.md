# 4.000 WOCHEN Plus X – Android App

Diese Android-Studio-Projektdatei enthält die aktuelle Referenz-Master-Version:
`4000_WOCHEN_Plus_X_MASTER_Inspiration_500_Sprueche_Kacheln_Beschriftung_LEER_FIX.html`

## Enthalten
- Android WebView App
- App-Name: 4.000 WOCHEN Plus X
- aktuelle HTML-Masterdatei lokal in `app/src/main/assets/index.html`
- JavaScript und LocalStorage aktiviert
- Hochformat
- Benachrichtigungsberechtigung vorbereitet
- vorhandenes App-Icon integriert

## Öffnen
1. ZIP entpacken.
2. Den Projektordner in Android Studio öffnen.
3. Gradle synchronisieren lassen.
4. App auf einem Android-Gerät starten oder als APK bauen.

Hinweis: Dieses Paket ist das Android-Studio-Projekt, nicht eine bereits kompilierte APK.
