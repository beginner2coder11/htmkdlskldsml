# 4.000 WOCHEN Plus X – Android API 36 / Native Erinnerungen

Aktuelle Android-Master-Version für das Projekt 4.000 WOCHEN Plus X.

## Technischer Stand
- compileSdk 36
- targetSdk 36
- minSdk 26
- HTML-Master in `app/src/main/assets/index.html`
- WebView mit JavaScript und LocalStorage
- Native Android-Erinnerungen über AlarmManager + BroadcastReceiver
- Android Notification Channel „Erinnerungen"
- POST_NOTIFICATIONS für Android 13+
- Erinnerungen werden bei Neustart/Update der App aus der nativen Sicherung neu geplant
- HTML-Erinnerungen werden mit der nativen Android-Erinnerungsfunktion verbunden
- Für Erinnerungen wird bewusst keine `SCHEDULE_EXACT_ALARM`-Sonderberechtigung verwendet; Android kann die Zustellung bei Energiesparzuständen geringfügig verzögern.

## Build
Projekt in Android Studio öffnen und als APK (Test) bzw. signiertes AAB (Google Play) bauen.
