'use strict';
const interfaceDefaults={line:'#54d5ff',icon:'#d5e5ed',background:'#030710',text:'#f3f6fa',needle:'#54d5ff',overload:'#ff1680',iconStyle:'outline',model:'neon',customIcons:{}};
config.interface=Object.assign({},interfaceDefaults,config.interface||{});
const dockItems=[['navigation','Navegação','.dashDock a','♧'],['radio','Rádio','#dashRadio','▣'],['bluetooth','Bluetooth','#dashBluetooth','ᛒ'],['apps','Funções','#dashApps','▦'],['music','Músicas','#dashMusic','♫'],['settings','Ajustes','#dashSettings','⚙']];
const originalIcons={};dockItems.forEach(([key,,selector])=>{originalIcons[key]=document.querySelector(selector).querySelector('svg').outerHTML});
const colorControls={line:'interfaceLine',icon:'interfaceIcon',background:'interfaceBackground',text:'interfaceText',needle:'interfaceNeedle',overload:'interfaceOverload'};
function interfaceColor(key){const value=config.interface[key];return /^#[0-9a-f]{6}$/i.test(value)?value:interfaceDefaults[key]}
function applyInterface(){
 const settings=config.interface,root=document.body;
 for(const key of Object.keys(colorControls))root.style.setProperty('--ui-'+key,interfaceColor(key));
 document.body.dataset.interfaceModel=['neon','clean','sport'].includes(settings.model)?settings.model:'neon';
 document.body.dataset.iconStyle=['outline','bold','symbols'].includes(settings.iconStyle)?settings.iconStyle:'outline';
 dockItems.forEach(([key,label,selector,symbol])=>{
  const button=document.querySelector(selector),old=button.querySelector('svg,img,.customSymbol');if(old)old.remove();
  const image=settings.customIcons?.[key];
  if(typeof image==='string'&&/^data:image\/(png|jpeg|webp|gif);base64,/.test(image)){const icon=document.createElement('img');icon.src=image;icon.alt='';icon.className='customDockIcon';button.prepend(icon)}
  else if(settings.iconStyle==='symbols'){const icon=document.createElement('span');icon.className='customSymbol';icon.textContent=symbol;button.prepend(icon)}
  else button.insertAdjacentHTML('afterbegin',originalIcons[key]);
 });
 Object.entries(colorControls).forEach(([key,id])=>$(id).value=interfaceColor(key));
 $('interfaceModel').value=document.body.dataset.interfaceModel;$('interfaceIconStyle').value=document.body.dataset.iconStyle;
 if(typeof drawModernMeter==='function')drawModernMeter(false,0,0);
}
Object.entries(colorControls).forEach(([key,id])=>$(id).oninput=()=>{config.interface[key]=$(id).value;applyInterface()});
['Model','IconStyle'].forEach(name=>$('interface'+name).onchange=()=>{config.interface[name[0].toLowerCase()+name.slice(1)]=$('interface'+name).value;applyInterface()});
dockItems.forEach(([key,name])=>{
 const label=document.createElement('label');label.textContent='Seu ícone: '+name;
 const file=document.createElement('input');file.type='file';file.accept='image/png,image/jpeg,image/webp,image/gif';file.setAttribute('aria-label','Escolher ícone para '+name);
 file.onchange=()=>{const image=file.files[0];if(!image)return;if(image.size>250000||!/^image\/(png|jpeg|webp|gif)$/.test(image.type)){status('Use um ícone PNG, JPG, WebP ou GIF de até 250 KB.');return}const reader=new FileReader();reader.onload=()=>{config.interface.customIcons={...config.interface.customIcons,[key]:reader.result};applyInterface();status('Ícone aplicado. Toque em Salvar personalização.')};reader.readAsDataURL(image)};
 const reset=document.createElement('button');reset.type='button';reset.textContent='Ícone padrão';reset.onclick=()=>{config.interface.customIcons={...config.interface.customIcons};delete config.interface.customIcons[key];applyInterface()};label.append(file,reset);$('customIconControls').append(label);
});
$('interfaceReset').onclick=()=>{config.interface={...interfaceDefaults,customIcons:{}};applyInterface();status('Aparência restaurada. Toque em Salvar personalização.')};
let modernNeedle=0;
function drawModernMeter(active,rms,dt){
 const canvas=$('modernMeter');if(!canvas)return;const ctx=canvas.getContext('2d');if(!ctx)return;
 const db=rms>0?Math.max(-60,20*Math.log10(rms)):-60,target=active?Math.max(0,Math.min(1,(db+38)/23)):0;
 modernNeedle+= (target-modernNeedle)*(1-Math.exp(-Math.max(0,dt)/(target>modernNeedle?.1:.3)));
 if(!active&&dt>=1)modernNeedle=0;
 const w=canvas.width;ctx.save();ctx.scale(w/400,canvas.height/400);ctx.clearRect(0,0,400,400);
 const line=interfaceColor('line'),needle=interfaceColor('needle'),over=interfaceColor('overload');
 const bg=ctx.createRadialGradient(200,145,10,200,200,195);bg.addColorStop(0,'#10263a');bg.addColorStop(1,'#01060c');ctx.fillStyle=bg;ctx.beginPath();ctx.arc(200,200,192,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle=line;ctx.lineWidth=2;ctx.globalAlpha=.55;ctx.beginPath();ctx.arc(200,200,179,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;
 const cx=200,cy=236,r=142,start=-Math.PI*.86,end=-Math.PI*.14,angle=t=>start+(end-start)*t;
 ctx.strokeStyle=line;ctx.lineWidth=3;ctx.shadowColor=line;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(cx,cy,r,start,angle(20/23));ctx.stroke();ctx.strokeStyle=over;ctx.beginPath();ctx.arc(cx,cy,r,angle(20/23),end);ctx.stroke();
 for(let i=0;i<=46;i++){const a=angle(i/46),major=i%2===0;ctx.strokeStyle=i>=40?over:line;ctx.lineWidth=major?3:1.5;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*(r-2),cy+Math.sin(a)*(r-2));ctx.lineTo(cx+Math.cos(a)*(r-(major?19:10)),cy+Math.sin(a)*(r-(major?19:10)));ctx.stroke()}
 ctx.shadowBlur=0;ctx.font='bold 18px system-ui';ctx.textAlign='center';
 for(const value of [-20,-10,-5,0,3]){const a=angle((value+20)/23);ctx.fillStyle=value>0?over:'#dceefa';ctx.fillText(value>0?'+'+value:String(value),cx+Math.cos(a)*(r+22),cy+Math.sin(a)*(r+22)+6)}
 const a=angle(modernNeedle);ctx.lineWidth=3;ctx.strokeStyle=needle;ctx.shadowColor=needle;ctx.shadowBlur=14;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.cos(a)*(r-10),cy+Math.sin(a)*(r-10));ctx.stroke();ctx.beginPath();ctx.arc(cx,cy,12,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;
 ctx.fillStyle='#e4f4ff';ctx.font='bold 27px system-ui';ctx.fillText('VU',200,283);ctx.font='11px system-ui';ctx.fillText('NÍVEL DE ÁUDIO',200,304);ctx.fillStyle=needle;ctx.font='bold 23px system-ui';ctx.fillText(active?db.toFixed(1)+' dBFS':eqState.vu?'SEM SINAL':'DESLIGADO',200,337);ctx.restore();
}
// Try the native lock after a gesture; CSS keeps the home design horizontal otherwise.
document.addEventListener('pointerup',()=>{try{const lock=screen.orientation?.lock;if(lock)lock.call(screen.orientation,'landscape').catch(()=>{})}catch{}},{once:true});
applyInterface();

let meterTap=null;
$('modernMeter').addEventListener('pointerup',e=>{if(e.pointerType==='mouse'||!e.isPrimary)return;const now=performance.now();if(meterTap&&now-meterTap.time<350&&Math.hypot(e.clientX-meterTap.x,e.clientY-meterTap.y)<32){meterTap=null;if(!eqState.vu){ensureAudio();showVu(true)}toggleVuFullscreen()}else meterTap={time:now,x:e.clientX,y:e.clientY}});
$('modernMeter').addEventListener('dblclick',e=>{if(e.sourceCapabilities?.firesTouchEvents||(e.pointerType&&e.pointerType!=='mouse'))return;if(!eqState.vu){ensureAudio();showVu(true)}toggleVuFullscreen()});
