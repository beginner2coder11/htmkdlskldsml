-- =====================================================================
--  शिक्षक साथी — Supabase बैकएंड सेटअप
--  निर्माता: सूर्यकांत भारती (7677636062)
--  उपयोग: Supabase Dashboard → SQL Editor → New query → यह पूरी फ़ाइल पेस्ट करें → Run
--  इसे दोबारा चलाना सुरक्षित है (पहले से बनी चीज़ें दोबारा नहीं बनेंगी)।
-- =====================================================================

-- 1) प्रोफ़ाइल (हर शिक्षक / एडमिन)
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  name       text,
  school     text,
  mobile     text unique,
  role       text not null default 'teacher' check (role in ('teacher','admin')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- एडमिन जाँचने का फ़ंक्शन
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

drop policy if exists "profiles_select" on public.profiles;
create policy "profiles_select" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles_update" on public.profiles;
create policy "profiles_update" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
-- शिक्षक केवल नाम व विद्यालय बदल सकें, अपना role नहीं
revoke update on public.profiles from authenticated, anon;
grant update (name, school) on public.profiles to authenticated;

-- नया खाता बनते ही प्रोफ़ाइल अपने-आप बने; 7677636062 अपने-आप एडमिन होगा
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, school, mobile, role)
  values (
    new.id,
    new.raw_user_meta_data->>'name',
    new.raw_user_meta_data->>'school',
    new.raw_user_meta_data->>'mobile',
    case when new.raw_user_meta_data->>'mobile' = '7677636062' then 'admin' else 'teacher' end
  )
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2) हर शिक्षक का अपना डाटा (छात्र, उपस्थिति, पाठ टीका, टेस्ट आदि)
create table if not exists public.teacher_data (
  user_id    uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.teacher_data enable row level security;
drop policy if exists "td_select" on public.teacher_data;
create policy "td_select" on public.teacher_data for select to authenticated using (user_id = auth.uid());
drop policy if exists "td_insert" on public.teacher_data;
create policy "td_insert" on public.teacher_data for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "td_update" on public.teacher_data;
create policy "td_update" on public.teacher_data for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 3) एडमिन कंटेंट (कंटेंट, कोर्स, लेसन प्लान, सूचनाएँ, सोशल लिंक) — सब शिक्षक पढ़ें, केवल एडमिन लिखे
create table if not exists public.admin_content (
  id         text primary key,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.admin_content enable row level security;
drop policy if exists "ac_select" on public.admin_content;
create policy "ac_select" on public.admin_content for select to authenticated using (true);
drop policy if exists "ac_insert" on public.admin_content;
create policy "ac_insert" on public.admin_content for insert to authenticated with check (public.is_admin());
drop policy if exists "ac_update" on public.admin_content;
create policy "ac_update" on public.admin_content for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- 4) फ़ाइल स्टोरेज (PDF, PPT, ऑडियो, वीडियो) — अधिकतम 50 MB प्रति फ़ाइल
insert into storage.buckets (id, name, public, file_size_limit)
values ('ss-files', 'ss-files', false, 52428800)
on conflict (id) do nothing;

drop policy if exists "ss_files_select" on storage.objects;
create policy "ss_files_select" on storage.objects for select to authenticated
  using (bucket_id = 'ss-files' and ((storage.foldername(name))[1] = auth.uid()::text or (storage.foldername(name))[1] = 'admin'));
drop policy if exists "ss_files_insert" on storage.objects;
create policy "ss_files_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'ss-files' and ((storage.foldername(name))[1] = auth.uid()::text or ((storage.foldername(name))[1] = 'admin' and public.is_admin())));
drop policy if exists "ss_files_update" on storage.objects;
create policy "ss_files_update" on storage.objects for update to authenticated
  using (bucket_id = 'ss-files' and ((storage.foldername(name))[1] = auth.uid()::text or ((storage.foldername(name))[1] = 'admin' and public.is_admin())));
drop policy if exists "ss_files_delete" on storage.objects;
create policy "ss_files_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'ss-files' and ((storage.foldername(name))[1] = auth.uid()::text or ((storage.foldername(name))[1] = 'admin' and public.is_admin())));

-- पहले से बने खातों की प्रोफ़ाइल भी बना दें
insert into public.profiles (id, name, school, mobile)
select id, raw_user_meta_data->>'name', raw_user_meta_data->>'school', raw_user_meta_data->>'mobile' from auth.users
on conflict (id) do nothing;

-- 5) अगर आपने इस SQL से पहले ही ऐप में पंजीकरण कर लिया था, तो यह लाइन आपको एडमिन बना देगी:
update public.profiles set role = 'admin' where mobile = '7677636062';

-- किसी और शिक्षक को एडमिन बनाना हो तो (मोबाइल बदलकर) चलाएँ:
-- update public.profiles set role = 'admin' where mobile = '9XXXXXXXXX';

-- किसी शिक्षक का पासवर्ड रीसेट करना हो (मोबाइल व नया पासवर्ड बदलकर) तो:
-- update auth.users set encrypted_password = crypt('newpass123', gen_salt('bf')) where email = 'ss9876543210@visionoflearners.in';
