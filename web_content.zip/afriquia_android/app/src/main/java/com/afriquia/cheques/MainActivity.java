package com.afriquia.cheques;

import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    web.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
      try {
        String name="AFRIQUIA-BACKUP-"+new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss",Locale.US).format(new Date())+".json";
        if(url.startsWith("blob:")){ web.evaluateJavascript("window.__afDownloadBlob && window.__afDownloadBlob()",null); }
        else downloadUrl(url,name,mimeType);
      } catch(Exception e){ }
    });
    web.addJavascriptInterface(new BackupBridge(),"AndroidBackup");
    web.loadUrl("file:///android_asset/index.html");
  }
  void downloadUrl(String url,String name,String mime){
    try{ DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE); DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url)); r.setTitle(name); r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,name); dm.enqueue(r); }catch(Exception e){}
  }
  public class BackupBridge {
    @JavascriptInterface public boolean saveBackup(String json,String fileName){
      try{
        ContentResolver cr=getContentResolver(); ContentValues v=new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME,fileName); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
        Uri u=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)return false;
        try(OutputStream out=cr.openOutputStream(u)){ out.write(json.getBytes("UTF-8")); }
        runOnUiThread(()->web.evaluateJavascript("window.showBackupSavedInfo && window.showBackupSavedInfo("+JSONObjectQuote(fileName)+",'✅ تم حفظ النسخة الاحتياطية في مجلد التنزيلات.')",null));
        return true;
      }catch(Exception e){return false;}
    }
  }
  String JSONObjectQuote(String x){ return "'"+x.replace("\\","\\\\").replace("'","\\'")+"'"; }
}
