# Traslados Metsur – App Android

Tu PWA (`index.html`, sin modificar) dentro de una app nativa, **sin pedir ningún permiso**.

## Por qué antes no funcionaba
Un WebView simple no tiene "compartir archivos" (`navigator.share` con imagen), ignora las descargas
(`<a download>`) y no copia al portapapeles. Eso no se arregla con permisos: se necesita código nativo.
Esta versión lo agrega:

| Botón de la página | Qué hace ahora |
|---|---|
| 📤 Compartir (imagen) | Abre el menú de Android (WhatsApp, etc.) usando FileProvider |
| ⬇ Descargar | Guarda en la Galería, carpeta **Pictures/Metsur** |
| Mantener presionada la imagen | Guarda en la Galería |
| 💬 Enviar por WhatsApp (texto) | Menú de compartir con el texto |
| Copiar / Respaldo copiado | Portapapeles nativo |
| Botón Atrás | Cierra la ventana emergente; si no hay, sale |

En Android 9 o menor, "Descargar" abre "Guardar como…" (también sin permisos).

## Compilar el APK
1. Sube todo el contenido a un repositorio de GitHub (incluida la carpeta `.github`).
2. Actions → *Compilar APK* → Run workflow.
3. Descarga `Metsur-Traslados-APK` (contiene `app-release.apk`).

También sirve Android Studio (*Build → Build APK(s)*) o `gradle assembleRelease` (JDK 17, SDK 34, Gradle 8.9).

## Datos
Los traslados se guardan dentro de la app. Los de la versión web/PWA no pasan solos: usa
*Respaldo → copiar* en la web y *Restaurar respaldo → pegar* en la app. Desinstalar borra los datos.
La llave `app/metsur.keystore` (clave `metsur123`) mantiene la firma para poder actualizar encima.
