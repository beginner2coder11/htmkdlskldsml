# LaunchDeck Remote — Full Android Project

This is a native Android app shell with a self-contained interactive launcher interface.

## Build an APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync to complete.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

## Included
- Home dashboard and status cards
- Sliding/scrollable shortcut deck, search, categories and favorites
- Add shortcut workflow
- Connection settings UI for a PC companion
- Local persistence using browser local storage
- Native Android launcher icon/entry point through MainActivity

## Honest status
This is a working UI prototype and Android project, not a production-ready PC remote-control system. The actual Windows companion service, authenticated pairing protocol, and remote-launch API must be built and tested separately. Connection form does not claim a real PC connection; the Test button is a setup placeholder. Do not enter sensitive PINs on untrusted devices.
