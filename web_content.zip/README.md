# Furniture Hisaab v11

Invoice OCR / Bill Photo fixes:
- Multi-pass OCR now checks full page + table/lower regions with multiple page segmentation modes.
- Invoice item rows are parsed from HSN + Qty + Unit + Rate + Amount; an item row no longer needs a GST percentage on the same line.
- Common OCR HSN error `1440799` is normalized to `440799` when the extra leading `1` is detected.
- Duplicate OCR rows are de-duplicated using both description and numeric row signature.
- Existing invoice date rule remains: `Dated/Invoice Date` is used; Ack Date is not used as invoice date.
- Quantity, rate, amount, GST and grand total remain separate fields.
- Before saving, extracted values can still be edited/verified.

This version keeps the rest of the v10 accounting, stock, labour, GST and month-end report features.
