# دواء القلوب

App ID: `com.alanis.dawaulqulub` (never change this)
Version: 1.0.0 (code 1)

## Update the app
1. Edit `www/index.html` and commit to `main`.
2. Raise `versionCode` in `.github/workflows/build.yml` (the "Set version" step) and the version in `package.json`.
3. Open **Actions**, wait for the green check, download **app-release**.

## Secrets (Settings → Secrets and variables → Actions)
- `KEYSTORE_PASSWORD`
- `KEYSTORE_BASE64`

Signing key alias: `alanis`. Keep `release.keystore` backed up in two places.
