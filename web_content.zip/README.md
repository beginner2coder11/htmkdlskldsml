# ATLAS 0.4.0
- Veri artık `data/*.js` paketleri (fetch yok; file:// ve WebView'de çalışır).
- Yeni içerik: `data/pack-xxx.js` ekle, `index.html`'e script satırı ekle.
- Makale gövdesi: `body` alanı, `## başlık`, `- liste`, `1. adım`, `**kalın**`, `[[ATL-0001]]` çapraz bağlantı.
- Arama: Türkçe karakter normalizasyonu + ek (yaklaşık kök) eşleştirme.
- Yedekleme: Hakkında ekranı.
- Sonraki: SQLite + görsel paketleri (Capacitor), 0.3.
