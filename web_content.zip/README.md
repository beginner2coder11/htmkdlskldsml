# TaskLaunch HTML-to-APK project
This packages TaskLaunch as a local HTML app in Android WebView, using the same method as DealPulse.
Open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
The interface works offline and saves notes/settings locally. Task Manager and terminal are simulations; Android WebView cannot control real Windows processes or run PC executables.
