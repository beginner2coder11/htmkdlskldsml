# TradingView Voice – F&O Floating Voice v3

## What changed
- Native Android SpeechRecognizer; no WebView SpeechRecognition.
- Floating 🎤 overlay bubble above other apps.
- Tap bubble -> speak Hindi/English stock command -> TradingView opens directly.
- Draggable bubble.
- Foreground microphone service so the bubble remains available after leaving the app.
- 213 instruments from the app's current F&O universe.

## First run
1. Open the app.
2. Tap **Enable Floating Voice**.
3. Allow Microphone.
4. Allow **Display over other apps**.
5. A 🎤 bubble appears.
6. Open TradingView/Dhan/any other app; tap the bubble and speak.

Examples: `Reliance kholo`, `HDFC Bank open`, `Bank Nifty kholo`, `Tata Power kholo`, `Fortis kholo`.

## Build
Open this folder in Android Studio and build a debug APK. Target SDK 35.

Note: the overlay service requires the user to explicitly grant Android's Display over other apps permission.
