FLUXO DE CAIXA — PACOTE CORRIGIDO PARA EMPACOTAMENTO ANDROID

Ficheiros:
- index.html: aplicação web offline
- app-config.json: configuração básica de arranque

Correções adicionais (revisão 2):
- PDF: corrigida a formatação de números que cortava dígitos (790 passava a 79, tamanho 10 passava a 1, 0 ficava vazio), o que desformatava o PDF.
- PDF: cabeçalho (título, período, data) estava a ser escrito no fundo da página; agora aparece no topo.
- PDF: valores monetários grandes já não são cortados com '...'.
- CSV com BOM UTF-8 (acentos corretos no Excel).
- Botão apagar sem onclick inline; restauro de backup valida datas e números.
- Arranque protegido contra dados corrompidos no localStorage.

Correções anteriores:
- Corrigida a estrutura de bytes/offsets do PDF para que a tabela de referências cruzadas use posições consistentes com os bytes gerados.
- Normalização de caracteres no PDF para evitar bytes UTF-8 incompatíveis com as fontes PDF padrão.
- Corrigida a quebra de linha na exportação CSV.
- Datas atuais e cálculo de períodos passam a usar datas locais, evitando desvio de dia por fuso horário.
- Validação para impedir intervalo de relatório personalizado com data inicial posterior à final.
- Removida a indicação visual de “Versão de teste” no rodapé.

Como empacotar:
1. Importe o ZIP num empacotador Android WebView/HTML que permita usar index.html local.
2. Defina index.html como página inicial.
3. Ative JavaScript e DOM Storage/localStorage.
4. Permita a seleção de ficheiros para restauro e os downloads/partilha de ficheiros.
5. Gere o APK e teste no próprio telemóvel: criar movimento, fechar/reabrir, gerar os três PDFs, exportar CSV/JSON e restaurar um backup.

IMPORTANTE:
Este pacote contém a aplicação web corrigida, não um APK já compilado. A geração de ficheiros e a persistência dependem também das permissões e do comportamento do empacotador Android escolhido. Faça um backup antes de atualizar uma instalação que já contenha dados.
