# CannaCorrente - Gestão de Óleos CBD em Corrente (PI)

Aplicativo completo e responsivo para gestão comercial e de entregas de CBD em Corrente, Piauí.

## Como Executar
1. Dê duplo clique no arquivo `index.html` para abrir diretamente no navegador.
2. Todos os dados são salvos localmente no seu navegador (`localStorage`).
