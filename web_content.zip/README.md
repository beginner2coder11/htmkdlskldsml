# إرشادات تشغيل حصن المسلم

هذا المشروع مجهز للتحويل إلى APK متوافق مع Google Play باستخدام Capacitor.

## الخطوات:
1. افتح موجه الأوامر (Terminal) في هذا المجلد.
2. قم بتشغيل: `npm install`
3. قم بتشغيل: `npx cap add android`
4. قم بتشغيل: `npm run build`
5. لفتح المشروع في أندرويد استوديو: `npm run open:android`