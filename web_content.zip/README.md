# Noot — PixelPlayer-style music player

Editable web source matching the supplied PixelPlayer library screenshot: blue header,
dark folder cards, breadcrumbs, Songs/Folders/Liked tabs, mini-player, and bottom navigation.
This is Noot's implementation, not PixelPlayer's original source code.

## Run the player

For the standalone player, serve `public` with `python3 -m http.server 8000 --directory public`
and open `http://localhost:8000/noot.html`. Edit `public/noot.html` to change the player.

For the complete application, run `npm install`, then `npm run dev`.

Import your own audio files or folders; the download does not contain sample music.
Browser folder access depends on the browser. Whole-device scanning requires the Android
`NootNative` bridge. This ZIP contains the web source, not an APK or the earlier Android
wrapper source, which is unavailable in the current workspace. The existing bridge hooks
for native scanning and playback are retained in `public/noot.html`.

## Project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
