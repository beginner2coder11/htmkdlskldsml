# Tjoef Buddies — Android P2P source starter

This project wraps the existing punk-themed HTML design in an Android WebView and adds native networking hooks for nearby Android devices.

## Intended connection methods
- Same Wi-Fi: UDP broadcast discovery plus a TCP text-message channel.
- Wi-Fi Direct: Android WifiP2pManager peer discovery and connection requests.
- No central messaging server or separate networking app.

## Important: this is source code, not a finished/tested APK
It has not been compiled or tested on physical phones in this environment. Wi-Fi Direct varies by device and Android version; same-Wi-Fi discovery is the main path implemented in this starter. You need Android Studio or a compatible cloud build environment to compile the APK.

## Current limitations
- Text messages only. Images, videos, audio, documents, and voice recordings remain local previews and are not transferred yet.
- No end-to-end encryption, identity verification, background delivery, store-and-forward, or globally registered usernames.
- The initial networking code is a prototype and should not be used for private/sensitive messages. A production release needs authenticated encrypted sessions and thorough physical-device testing.

## Build
Open the project folder in Android Studio, install Android SDK Platform 35, and build the `app` debug APK. Output normally appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Test on two phones
1. Build and install the same debug APK on both Android phones.
2. Enable Wi-Fi on both; first test with both on the same Wi-Fi network.
3. Open Tjoef Buddies on both, grant nearby Wi-Fi/location permissions if requested.
4. Open the local P2P panel and tap SCAN FOR DEVICES on both phones.
5. Once connected, open a chat and send a text message.
6. If same-Wi-Fi discovery is blocked by the router, try Wi-Fi Direct. Some phone models require the user to accept a system prompt.
