# Off-Grid Repository: Ubuntu install

This installs everything while you still have internet, so it all keeps working after you go offline.

| Piece | What you get |
|---|---|
| **Project NOMAD** | Offline Wikipedia, medical references, Khan Academy, offline maps and local AI. You pick the content packs in NOMAD's web UI after install. |
| **AI integration** | Everything in this repository is loaded into NOMAD's AI Knowledge Base automatically at the end of the install: all original guides, the buy list, your UV-32 channel plans, downloaded manuals and joined medical books, and nearest-places lists built from the locator (closest hospitals, pharmacies, fuel, water, shelters, repeaters, stores within 150 miles, with distance, direction, address and phone). Ask NOMAD's AI Chat and it answers from your own documents with sources. Refresh any time with `sudo offgrid-ai-sync`. The locator header links to NOMAD's AI chat. |
| **Off-Grid Locator** | A searchable offline database of **hospitals, urgent care, clinics, pharmacies, grocery stores, food banks and food distribution, gun and hunting shops, armories and National Guard sites, and military bases** within **500 miles of ZIP 30115**. Shows distance and compass direction from home, from your GPS, or from any coordinates you type in. You can print it. |
| **Library** | About 65 firearm and radio manuals for the most common guns and radios. Guns: Glock, SIG P320/P365, S&W M&P/Shield/M&P15 and revolvers, Springfield Hellcat/XD-S, Ruger 10/22 and LCP, Hi-Point (all models), Henry and Marlin lever actions, Remington 700/870, Mossberg 500/590. Radios: Baofeng, Quansheng, Yaesu, Midland GMRS, Motorola Talkabout, Cobra and Uniden CB, and Midland crank weather radios. Also the federal NIFOG and AUXFOG emergency frequency guides. Open it from the **Library →** link on the locator page. |
| **Vehicle repair** | An original *Vehicle Problems & Field Fixes* guide (no-starts, batteries and charging, overheating, tires, brakes, leaks, warning lights, check-engine codes, diesel, getting unstuck, spares kit), the Army FM 21-305 driver's manual, and the full **iFixit** offline archive (thousands of step-by-step repair guides for cars, trucks, generators, tools and electronics). |
| **Survival & first aid** | An original *Survival Field Guide: Southeast US*. It covers finding and capturing water, purification (EPA bleach doses), first aid, venomous snakes and ticks, about 25 common edible wild plants with their deadly look-alikes, traditional medicinal plants, edible insects and where to find them, trapping, fishing, skinning and field dressing, which parts to eat, safe cooking temperatures, and preserving meat (jerky, pemmican, salting, smoking, canning). Plus the Army FM 21-76 Survival manual, the 2026 Army first aid manual (ATP 4-02.11), Where There Is No Dentist, the EPA water disinfection guide, the full USDA Complete Guide to Home Canning, and Kiwix medical, water, food-preparation and post-disaster archives. |
| **Thermal & night vision** | An original field guide covering how thermal, image-intensifier and digital NV work, how to operate, zero and care for them, battery types, and how to check a device you find. Plus manuals for Pulsar Helion/Axion, ATN X-Sight 4K and ThOR 4, AGM Rattler and Taipan, and three PVS-14 versions. |
| **Off-grid essentials** | An original guide covering solar sizing, generator safety, a radio frequency card (NOAA, FRS/GMRS, MURS, CB, ham, marine), navigation without GPS, fire, shelter, knots, sanitation, gardening and seed saving for north Georgia, storage checklists and a family plan. Plus the Army land navigation manual, FEMA's "Are You Ready?", and offline Appropedia and Stack Exchange archives (DIY, mechanics, gardening, outdoors, ham radio, cooking). |
| **Communications map** | Police and sheriff, fire, EMS, radio/TV studios and newspapers, and communication towers (OpenStreetMap). Every licensed AM/FM/TV transmitter within range, with frequency and owner (FCC public data, refreshed monthly). Ham and GMRS repeaters from your own exports (see below). |
| **My radio programming** | Your UV-32 go-bag radio setup: a searchable, printable channel plan (542 channels, 10 zones, filter by zone or transmit-OK, "grab these first" card with the family, test, ARES, weather and Skywarn channels), the quick-guide PDF, the CSV and Markdown lineups, and the CHIRP `.img` file. CHIRP is installed (and its installer saved in Library → Software) so you can re-flash a radio from that file with no internet. |
| **Home systems** | Home off-grid power and pond water: solar cost and sizing, whether wind is worth it, and the pond water treatment train. |
| **Homestead food** | An original guide to bread (yeast loaf, sourdough with no store yeast, cornbread, biscuits, bannock, tortillas, hardtack, baking without an oven, acorn flour), a north Georgia planting calendar, calorie crops and seed saving, soil and pests, and building cold frames, low tunnels and a 10×12 hoop greenhouse. |
| **Shelter, tracking & hunting** | Picking a site, debris huts, lean-tos and tarp setups, finding existing shelter safely, sheltering at home without power; track and sign ID for Southeast animals, aging a trail; hunting deer, feral hogs, turkey and small game, shot placement and blood trailing. |
| **Fuel & home security** | How long each fuel keeps and how to store it, how much to store, making charcoal/wood gas/biodiesel (plus the FEMA wood-gas generator plans), where to find fuel lawfully after a disaster, fire-starting fuels in the woods; home security in layers, doors and windows, light/noise discipline in an outage, a family security plan, fire and CO safety. |
| **Fuel, shelter & supplies on the map** | The locator now also shows gas stations and propane dealers (with diesel/kerosene/ethanol-free where known), shelters and community centers, and hardware/feed-and-seed stores. |
| **Radio programming** | An original guide to programming any radio: CHIRP step by step, cables and drivers, keypad programming for Baofeng and Quansheng, Yaesu/Icom/Kenwood, GMRS privacy-code chart, mobiles, DMR codeplugs, CB/scanners/SDR, Meshtastic, and copying your UV-32 plan to other family radios. |
| **Off-grid software** | Installed: CHIRP, qdmr/dmrconfig (DMR), Meshtastic CLI, Direwolf/Xastir (APRS), Fldigi suite, JS8Call, WSJT-X, QSSTV, Gqrx/rtl-sdr, Gpredict, Hamlib, Mumble voice server, Wine, Kiwix, Calibre, LibreOffice, KeePassXC, GnuCash, Anki, VLC, Syncthing, gpsd/FoxtrotGPS, Marble, Stellarium, and Grocy (food-storage inventory). Saved installers for phones and other computers (CHIRP for Windows/Mac, Pat Winlink, Meshtastic app and firmware, Kiwix and Organic Maps for Android, KeePassXC, SDR++). Every downloaded .deb is kept for reinstalling offline. |
| **Signals & SDR** | Search the airwaves with a $40 RTL-SDR USB dongle: a hardware shopping list, antennas, the `offgrid-scan` command (sweeps a band and lists every active frequency, labelled), SDR++/Gqrx/SDRangel waterfall receivers, SDRTrunk for digital trunked police/fire, SatDump weather-satellite images, aircraft tracking, sensors, shortwave, hardware scanners, direction-finding, and what to monitor in a crisis. The installer builds the RTL-SDR Blog V4 driver. |
| **Worst-case disasters** | An original guide: nuclear detonation and fallout (shelter, shielding, the 7/10 rule, decontamination, food and water, potassium iodide doses, radiation sickness, meters), EMP and solar storms with Faraday storage, long grid-down blackouts, floods, tornadoes, ice storms, chemical releases, pandemics, unrest and collapse, bug-in vs bug-out, go-bags, stockpile levels and a family comms plan. Plus *Nuclear War Survival Skills* (1979 and 1987 editions) and FEMA's nuclear detonation guidance. |
| **Long-term survival** | An original guide to organizing a neighborhood, sanitation and water at community scale, triage and trauma, wounds, illnesses without a doctor, medicine stocking and expiry, dental, childbirth, burial, morale and kids, soap-making, food over years, skills to learn, and trade. |
| **Medical books** | Hesperian's free *Where There Is No Doctor*, *Where Women Have No Doctor*, *Where There Is No Dentist*, *A Book for Midwives* and *A Community Guide to Environmental Health*, downloaded by chapter and joined into complete books. |
| **Water on the map** | Springs, public wells and water points within 500 miles are now on the locator too. |
| **Buy list** | An interactive checklist of about 80 items to buy now (water, food, medical, power, fuel, heat, sanitation, comms, navigation, radiation, security, tools, vehicles, documents, kids), each with priority, rough cost, how many, and the kinds of places that stock it in a crisis. Map links open the locator filtered to those places. Check items off, add your own, print or export CSV. Linked from the locator header. |
| **Stores on the map** | The locator also shows sporting-goods/outdoor stores, veterinary clinics, auto parts stores and big-box/dollar/general stores. |
| **Stars, sun, moon & weather** | Finding north by the stars, latitude from Polaris or the noon shadow, longitude from the time of local noon, direction and time from the sun, a Big Dipper star clock, moon phases and moonrise rules, the season from the sky, weather signs (clouds, wind, barometer, sayings), dead reckoning, plus offline calculators (sunrise/sunset/moon for any date and place, "where am I" from a noon shadow, star clock, a year of moon phases). |
| **Severe weather** | An original guide to cold (how the body loses heat, dressing, hypothermia and frostbite care, a cold night outdoors, heating one room safely, frozen pipes), ice and winter storms, being stranded in a vehicle, tornadoes (where to shelter anywhere, helmets, safe rooms + FEMA P-320 plans), hurricanes (a timeline from 5 days out), extreme heat and heat stroke, lightning, wildfire smoke and drought, and what to do after any storm. |
| **EMP & backups** | An original guide to EMP and solar storms: what fails and what survives, building and testing Faraday cages, protecting the off-grid computer (battery power, short cables, surge protection, a cold spare in a can), protecting solar, radios and vehicles, what to do with warning, the first 24 hours, and step-by-step recovery of dead electronics. `sudo offgrid-backup /media/<you>/<drive>` copies the repository, NOMAD content and AI models to an external drive with restore instructions. |
| **Rugged computer case** | An original build guide for putting the NOMAD computer in a Pelican-style hard case: three build levels (EMP storage case, battery-powered field workstation, case + steel inner vault), case choices, layout and power wiring diagrams, Faraday liner with a conductive lid seal, cooling and moisture control, an outside connector panel, assembly steps, and electrical, thermal, runtime, shielding and water tests. |
| **Survival USB drive** | The `usb` folder builds a plug-in drive that runs on almost any Windows, Mac or Linux computer — built from a Windows laptop by double-clicking `usb/BUILD-USB-WINDOWS.bat` (or `sh usb/build-usb.sh /path/to/usb` on Mac/Linux). It includes offline AI (llama.cpp with 3B and 7B models), an "Ask the Library" page that answers from your own guides with sources, all guides and manuals, the nearby-places locator (built from OpenStreetMap), a street map, Kiwix medical/repair archives, and one-click launchers. Phones on the same Wi-Fi can use it too. |
| **Off-grid electricity** | An original guide with wiring diagrams: complete solar system layout, panels in series vs parallel, battery banks, salvaged house panels into an MPPT controller, generator interlock to the house panel, vehicle inverter hookup. Step-by-step install order, system sizing with worked examples, wire-gauge and fuse tables for 12/24 V, battery types, golf-cart/EV/vehicle power, micro-hydro, wind, pedal and wood gas, and where to find panels and batteries (solar farms and RV/boat/marina/golf locations are now on the map). |
| **Offline street map** | Street map of the same 500-mile area, with the locator results shown as pins. |

## Quick start

```bash
unzip offgrid.zip && cd offgrid
sudo bash install.sh
```

Then open **http://localhost:8090**. If NOMAD or something else is already using 8090 or 8091, the installer picks the next free port and prints the addresses at the end. Phones and other devices on the same network can use `http://<laptop-ip>:8090`.

### Options
```
--no-nomad          skip Project NOMAD (locator only)
--no-map            skip the street-map download
--data-only         refresh the locator data (run monthly while you have internet)
--lat/--lon/--label move the home point, e.g. --lat 34.24 --lon -84.45 --label "Home"
--radius 300        change the radius in miles
--maxzoom 15        sharper street map (about 3–4× bigger download)
--port 8090         change the locator's port
--library-only      fetch new manuals and rebuild the library index
--no-zim            skip the iFixit repair archive (several GB)
--no-chirp          skip CHIRP
--no-software       skip the radio/off-grid desktop apps, Grocy and saved installers
--ai-sync           only (re)load the repository into NOMAD's AI Knowledge Base
--no-ai-sync        leave NOMAD's Knowledge Base alone
--nomad-url URL     NOMAD address if not http://127.0.0.1:8080
```

## Adding manuals
- **Your own PDFs:** drop them into `/opt/offgrid/www/library/<Category>/` (make a new folder for a new category), then run `sudo bash install.sh --library-only`.
- **More downloads:** add a tab-separated line to `library/manuals.tsv` (category, title, filename, URL), then run `--library-only`.
- Any link that fails gets listed in `/opt/offgrid/www/library/FAILED.txt`. Download those by hand into the folder.

## Adding repeaters
RepeaterBook's terms let registered users export data for **personal use**, but they don't allow bundling or bulk downloading. So the installer doesn't scrape it. Instead:
1. Create a free account at repeaterbook.com and log in.
2. For each state you want (start with GA, AL, TN, SC and NC), open the state's repeater list (amateur and GMRS) and use **Export → CSV** (any export that includes latitude and longitude columns).
3. Copy the CSV files into `/opt/offgrid/repeaters/` and run `sudo bash install.sh --data-only`.

Any CSV with `Lat` and `Long` (or `Latitude`/`Longitude`) columns works, including your own list. Frequency, input/offset, tone, callsign and city columns are picked up automatically and are searchable (try typing `146.` or a callsign).

## Disk space (approximate)
- State map data (raw): 6–8 GB. You can delete `/opt/offgrid/osm/raw` after the build, but `--data-only` will download it again.
- Locator database: under 50 MB
- Street map at zoom 14: about 5–15 GB
- Desktop software + saved .debs: about 4–6 GB (LibreOffice and Wine are the big ones). Saved installers/firmware: about 1 GB.
- NOMAD content: depends on what you pick. Full English Wikipedia with images is about 110 GB, and AI models are 5–40 GB each.

## Where things are
```
/opt/offgrid/www/index.html          the locator page (also works by opening the file directly)
/opt/offgrid/www/data/pois.csv       all places, for a spreadsheet
/opt/offgrid/www/data/pois.geojson   all places, for QGIS / GIS apps
/opt/offgrid/www/map/region.pmtiles  offline street map
```
Copy `/opt/offgrid/www` to a USB drive for a portable backup. Use **Print list** to make a paper copy for a specific radius and category.

## Limits of the data
The places come from **OpenStreetMap**, which volunteers maintain. Coverage is good for hospitals, pharmacies and big grocery chains. It is patchier for:
- **Urgent care:** detected by tag or by name ("Urgent Care", "MinuteClinic", "Walk-In"…). Other clinics are listed separately as *Clinic / doctor*.
- **Food banks and pantries:** many church pantries aren't mapped.
- **Armories:** only sites tagged as military *and* named "Armory", "National Guard" or "Readiness Center".
- **Gun shops:** `shop=weapons/guns/hunting`. Pawn shops and big-box stores that sell firearms aren't included.

Hours and phone numbers can be out of date. Confirm critical places ahead of time while you can.

## States included
GA, AL, TN, SC, NC, FL, MS, KY, VA, WV, LA, AR, MO, IL, IN, OH, PA, MD (every state that touches a 500-mile circle around Canton). If you move the center, edit `STATES=` at the top of `install.sh`.

## Reprogramming a radio with CHIRP

1. Plug the programming cable into the radio and the computer, radio switched on.
2. Run `chirp` from the desktop (CHIRP is a desktop app; it needs a monitor, not just SSH).
3. **File → Open** → `/opt/offgrid/www/library/My Radio Programming/UV32_Useful_Channels.img`.
4. **Radio → Upload to radio**, pick the cable's port (usually `/dev/ttyUSB0`), vendor **Baofeng**, model **UV-32**.

Always do **Radio → Download from radio** and save a backup of a new radio first. If you change the channel list, export the CSV over `UV32_Useful_Channels_Reference.csv` and run `sudo bash install.sh --library-only` to rebuild the printable plan.

## Added in this version
- `usb/command.html` - the Command Center (one page to everything); START-WINDOWS and the Termux script now open it.
- `usb/converter.html` - offline unit converter (also a single-file copy under PLATFORMS\ANDROID).
- `usb/states.html` - places by state, ZIP text and coordinates.
- `usb/platforms.py` - PLATFORMS\ per-device instructions and TRAVEL\<DEVICE>-GO ready-to-copy go-drive folders (PROGRAMS\MAKE-TRAVEL-FOLDERS.bat).
- `usb/library_extras.py` - DoD Inspector General reports, public-domain encyclopedias (Britannica 1911), TiddlyWiki, Ubuntu ISO (PROGRAMS\ADD-LIBRARY-EXTRAS.bat; `--no-extras` skips it in the builder).
- `usb/android_pack.py` - Android start-here page, one-line Termux setup, single-file pages.

## Added in v6
- `command.html` knows when it runs inside the OFFGRID Android app: no localhost checks, drive status line, coordinates are tap-to-copy (the app blocks geo: links), Notes export/import use the clipboard (the app blocks downloads), AI/workspace/Windows tiles dimmed.
- New **Routes** tab: each get-home route with its page, topo sheets and key spots; tap a spot to see the nearest places.
- New `radio.html` (the app's More > Radio page).
- `PLATFORMS/ANDROID/app-source/` carries the app's source zip and build steps (still uncompiled and untested).

## Added in v7 (travel / go drives)
- **ALL-DEVICES-GO**: one exFAT go drive that works on every device, with `START-HERE-WHICH-DEVICE.html` (big buttons per device).
- **Up to 2 TB**: MAKE-TRAVEL-FOLDERS asks for the size (32, 64, 128, 256, 512, 1000, 2000 GB).
- **Rebuilds after UPDATE-DRIVE**: sizes are remembered in `TRAVEL\travel-state.json` and every travel folder is rebuilt at the end of each builder run. `platforms.py --refresh` does it by hand.
- **UPDATE-GO-DRIVE** (on every go drive): way 1 copies what changed from the main drive (additive, never deletes, stops before the drive is full); way 2 refreshes guides, manuals and pages online when the drive carries the builder.
- **Size guide**: `TRAVEL\BUDGET-GUIDE.html` (also `www/platforms/go-drive.html`) shows, per device and size, what is included and what to drop first.

## Added in v8 (Joint Publications)
- `joint_doctrine.py` now reads the Joint Staff's public publication list (and a built-in list) to find the exact JDEIS file names, including change suffixes (`jp3_01ch1.pdf`), and keeps the newest edition of every JP in the reference guide. New menu item **ADD-JOINT-PUBS.bat** runs it alone. Still untested against the live sites.

## Added in v9 (app window, tidy front door)
- **Command Center opens in its own app window** (Edge or Chrome `--app` mode: no tabs or address bar) on Windows, Mac and Linux. Closing the window stops the drive's servers. The window uses a profile stored on the computer (not the drive), so notes persist per computer. Falls back to the normal browser if neither is installed. Launcher waits for the server instead of a fixed delay and re-uses a drive that is already running.
- START-WINDOWS.bat used to open `workspace.html`; it now opens `command.html`.
- Command Center: `/` or Ctrl+K searches, `Esc` clears, `1`-`5` switch tabs; new tiles for the Radio hub, Go-drive size guide and Joint publications; tab icon.
- **One front door.** The `START HERE` folder (a copy of the menu) and the 37 stub pages in `OPEN-THESE-PAGES` are no longer created. `tidy.py` / PROGRAMS `TIDY-DRIVE.bat` (menu Y) moves them, stray `.part/.tmp/.new` files and old top-level update scripts into `_TIDY-BIN` (deleted after 30 days, or at once with the YES prompt). It also runs at the end of every build. `REPORTS\TIDY-REPORT.txt` lists what moved.

## Added in v10
- **Scout** (`scout.html`): photo ID with seven modes (General, Plant, Mushroom, Bug, Tracks, First aid, Read text). Uses the drive's existing vision/medical helper model through `serve_usb.py`; photos are shrunk in the browser and never stored. Dimmed in the Android app (needs the computer's AI).
- **Grid & Gas** (`grid.html`): EIA Open Data electricity demand vs day-ahead forecast by region, Lower-48 gas storage, Henry Hub price. Needs internet and a free EIA key (saved in the browser or in `www/data/eia-key.txt`). Keeps the last reading for offline. Endpoints untested from the build sandbox (no network).
- **Medicine & remedies** (`medicine.html`, `data/medicine.js`): 36 conditions, 20 home measures, 18 herbs from Project NOMAD (Apache-2.0; public-domain US-government text). Licence in `data/MEDICINE-NOTICE.txt`.

## Added in v11
- **State highway maps**: `statemaps.html` (Maps tab) lists all 50 states + DC with the official DOT map PDF when on the drive. `state_maps.py` / `ADD-STATE-MAPS.bat` (menu E) finds each state's map page (built-in list in `LINKS`, editable via `tools/state-map-links.json`; otherwise a web search), saves the newest official map PDF to `www/library/State Highway Maps/`, and lists failures with a link in `REPORTS\NOT-FETCHED-State-Maps.txt`. Needs internet; never run against real DOT sites from the build sandbox, so expect some states to need a manual download the first time.

## Added in v12
- `OCR-OVERNIGHT.bat` (menu F): `usb_builder.py --ocr-only --ocr-pages 100000000`, i.e. OCR every scanned PDF in one resumable run, then rebuild search; optional shutdown when done. Needs Tesseract installed once on Windows.

## Added in v13
- **Commandant's Reading List** (`readinglist.html`, `reading_list.py`, `ADD-READING-LIST.bat` menu 0): FY26 list (72 titles) with a tick-to-mark-read checklist. Downloads the 14 legally free titles (MCUP open-access books, History Division's Semper Fidelis, Gutenberg Duffer's Drift + Constitution, MCDP/MCWP/MCRP from MCPEL) into `www/library/Commandants Reading List/`; others link to WorldCat. T.Rex Arms' Field Manual Vault could not be fetched (site blocks the fetch tool); its free PDFs are the original DoD publications, available from army_pubs/MCPEL.

## Added in v14
- Fixed the zip layout: v10-v13 were zipped from `usb/` only and left out `scripts/` (build_pois), so the builder failed with "No module named build_pois". v14 has the same top-level layout as v9 (README.md, install.sh, library/, scripts/, usb/, www/).
- **OPEN-WITH\\** (`openwith.py`, run at the end of every build): one folder per program (Google Earth Pro, OsmAnd, Organic Maps, QGIS, GeoPDF/Avenza, Command Center map tiles, Kiwix, AI models, CHIRP, phone installers, VLC) holding hard links to the matching files plus a READ-ME.txt, and `WHAT-OPENS-WHAT.html` (also `www/openwith.html`, tile on the Maps tab). Skipped by copy_drive/doctor.

## Added in v15
- **500-mile topo PDFs**: `ADD-TOPO-500-MILES-WINDOWS.bat` (or `--topo-pdf-radius 500`). Only the printable GeoPDF quads use this
  radius (the topo tile layer and satellite still use `--topo-radius`). Over 100 miles the search runs as a grid of ~100-mile boxes
  (each cached) and keeps quads whose center is inside the circle: about 12,700 quads, roughly 740 GB. Nearest first, resumable,
  stops with 150 GB free. The 180 quads already downloaded are kept.
- **More Google Earth layers** (`kml_export.py`, runs at the end of every build): GOOGLE-EARTH-READY now also gets home + distance rings,
  military installation boundaries, get-home routes, topo-quad footprints (one file per state, green = PDF on drive with a click-to-open link,
  orange = not yet downloaded), base/city/lake topo footprints, and a Places\ folder with one KML per category.

## Added in v16
- **Pawn shops, restaurants/fast food, convenience stores, army-surplus** are now place categories (scripts/build_pois.py classifier and the 150-mile Overpass queries; re-run a build once and the new "more" group is fetched).
- **Places within 500 miles**: `ADD-PLACES-500-MILES-WINDOWS.bat` (`--places-only`). Overpass cannot return a 500-mile area, so this downloads Geofabrik state extracts
  (18 states, ~7 GB, each deleted after it is read to `tools/poi-source`), reads them with pyosmium (wheel fetched from PyPI into tools/pylib) and writes
  `www/data/poi500/<state>.js` + `index.js`. Page: `places500.html` (Command Center > Maps) — pick categories, center (home / GPS / lat,lon), radius, nearest first, CSV/GPX download.
  Google Earth: `GOOGLE-EARTH-READY\Places-500mi\<category>.kml`. Resumable per state. Multipolygon-relation campuses are skipped for speed.
- Topo maps were already indexed by grid: `find-map.html` (lat/lon, UTM or MGRS -> every sheet covering that point), rebuilt from the catalog each build.

## Changed in v17
- Wide-area topo and places are back to a 500-mile default, now raised in 100-mile steps: `ADD-TOPO-MILES-WINDOWS.bat` and `ADD-PLACES-MILES-WINDOWS.bat` ask for the radius
  (Enter = 500; later 600, 700 ...). Topo size: 500 mi ~740 GB, 600 ~1.1 TB, 700 ~1.5 TB, 800 ~2 TB. The USGS search uses a fixed 100-mile grid cached on the drive,
  so a bigger radius only searches and downloads the new outer ring. Places state extracts are now kept (tools/poi-source) so widening re-reads them without re-downloading.

## Added in v19
- `online.html` ("Online resources", Command Center > Tools): links for when internet/cell service exists - USNG/MGRS viewers (GISsurfer, USNG Center, Dolbow mashup, NAPSG), weather/alerts, fire & smoke, quakes/rivers/space weather, maps, roads, radio, shelters/health, power outages. Filter box, online/offline indicator, and "My links" saved in the browser.

## Added in v20
- **Caves** are a place category (OSM `natural=cave_entrance`): 150-mile locator (new query in the "more" group, fetched on the next build) and the wide-area layer.
- **Coordinate converter** `coords.html` (Command Center > Tools): decimal / DMS / degrees-decimal-minutes / UTM / MGRS-USNG both ways, GPS button, find any of 31,000 US cities (from `data/us-cities.csv`, SimpleMaps basic edition - attribution in `www/data/US-CITIES-NOTICE.txt`), distance & bearing, convert a pasted list to CSV. coords.js now also exports parseUtm / utmToLatLon.
- **Excel** `EXCEL-READY\`: US-cities.xlsx, Places-150mi.xlsx, Places-wide-area.xlsx (one sheet per category; Latitude, Longitude, MGRS, DMS, address, phone). Pure-stdlib writer (`xlsx_export.py`), rebuilt at the end of every build.

## Added in v21
- `ADD-CAVES-WINDOWS.bat` (`--caves-only --caves-radius N`): one quick OpenStreetMap query -> `CAVES\Caves-<N>mi` .xlsx / .csv / .kml / .gpx with name, miles, direction, lat/lon, MGRS, DMS, notes. No big downloads.

## Added in v22
- `usb/data/us-hospitals.csv` (SimpleMaps US Hospitals, basic v1.0.1: 5,768 hospitals, ER yes/no, beds, ownership; NO coordinates in the basic edition). `hospitals_data.py` adds coordinates
  (exact from OpenStreetMap hospital points when the name matches within 30 mi, else city center) and writes `EXCEL-READY\US-hospitals.xlsx` (nearest first) and `GOOGLE-EARTH-READY\Hospitals.kml`.
  License: private use only; do not publish the file or these outputs on a public site (SimpleMaps license section 4).

## Added in v23
- `ADD-HOSPITALS-WINDOWS.bat` (`--hospitals-only`): downloads the HIFLD Open hospitals layer (NASA NCCS ArcGIS mirror, PASDA fallback; ~7,500 facilities, exact coordinates, phone, beds, trauma level, helipad; public domain),
  merges it with the SimpleMaps list (emergency-services flag, ownership) and rewrites `EXCEL-READY\US-hospitals.xlsx` + `GOOGLE-EARTH-READY\Hospitals.kml`. Rows say which source they came from and how exact the location is.

## v24 - Medicine list (FDA labels)
`ADD-MEDICINES-WINDOWS.bat` downloads the openFDA drug-label files (one time, about 1-2 GB, kept in tools\meds-source) and builds
`www/data/meds/` (searchable page `meds.html`, tile "Medicine list" under Library) plus `EXCEL-READY\Medicines.xlsx`.
One entry per ingredient, OTC and Rx separately: brands, route, used for, purpose (OTC), warnings. Reference only, not medical advice.
Tested on mock data only (real download not reachable from the build sandbox).

## v25 - Project NOMAD on Windows (WSL2)
`usb\INSTALL-NOMAD-WSL2-WINDOWS.bat` (+ `nomad_wsl2.ps1`, `nomad-wsl2\step1-3*.sh`): installs Ubuntu 24.04 in WSL2, turns on systemd and shared mounts,
installs native Docker, runs the official NOMAD installer (user "nomad"), opens http://localhost:8080. Re-runnable; resumes after the Windows restart.
`-Lan` adds the port proxy + firewall rules. `START-NOMAD-WINDOWS.bat` brings it up after a reboot. Guide page: `nomad-wsl2.html` (Command Center, Tools).
Follows https://www.projectnomad.us/install/wsl2 (community-supported). Not testable in the build sandbox (no Windows): the .ps1 is untested.

## v26 - Quick response + Poison & plant ID
`quick.html` (Command Center > Emergency): pick Where am I (wilderness / maritime / urban / aviation-transit), How long (1-4, 5-25, 26+ days) or What threat (medical, natural, man-made):
first steps, links into the drive's guides and the step-by-step situations in topics.html, and online links. Rule-of-threes strip and Poison Help number on top.
`library/Medical/poison_and_plant_id.html`: poison control steps by exposure, household/camp poisons, safe plant ID method, dangerous Southeast plants, online IDs.

## v27 - Southeast US sources
library/manuals.tsv now downloads (category "Southeast US"): UGA C957 and B1428, Auburn/UF Poisonous Plants of the Southeast, Georgia DECAL plant list,
Georgia DNR venomous-snake brochure + six species fact sheets + water-moccasin brochure, MSU wild edibles, UGA Natural Hazards Handbook; plus PHMSA ERG 2024 (Disasters).
quick.html tiles now link to those documents and the Army/USMC manuals already on the drive and name their sources. Run UPDATE-DRIVE-WINDOWS.bat to fetch them.
Not downloadable from the build sandbox: link targets are from the publishers' own pages but untested here.

## v28 - Situation Center, full check, more OPEN-WITH folders
- **situation.html (Command Center > Emergency):** type what is happening (optionally pick place / duration / threat). One board: situation steps, quick-response cards, guide sections, manuals, medicine + poison + plant ID, nearest places, radio, AI, print. Deep link: `situation.html?q=...&env=wild`. meds.html now accepts `?q=`.
- **Shared data:** scenarios moved to `scen-data.js`, quick-response data to `quick-data.js` (used by topics, quick and situation pages; both copied by the builder).
- **Full check:** `python3 scripts/audit_repo.py` (links, tiles, manuals.tsv, builder copy list, syntax, .bat CRLF). Fixed: 6 unindexed library pages (now "local" rows), 2 duplicate manuals lines, 6 .bat files converted to CRLF.
- **OPEN-WITH folders C-H:** Spreadsheets, GPS waypoints, E-books, Notes (TiddlyWiki), Medical and poison references (Southeast US), Survival and disaster manuals.
- Untested on real Windows: all downloaders, medicine download, NOMAD WSL2 script, Southeast PDF URLs.

## v29
- All "could not fetch" lists now live in `REPORTS\NOT-FETCHED-State-Maps.txt`, `-Reading-List.txt`, `-Joint-Doctrine.txt` (plus LIBRARY-EXTRAS-NOT-FETCHED.txt). Old in-folder copies are removed on the next run and Tidy moves leftovers to `_TIDY-BIN`.
- State maps: added DOT pages for GA, NC, SC, VA.
- State maps: page fetch now falls back to headless Edge/Chrome (runs JavaScript); search tries DuckDuckGo, then Bing, then Brave.
- Boot-key add-on (separate zip `offgrid-bootable-addon.zip`): Ventoy boot stick + live-Linux launcher. The main drive carries only a stub page (Command Center > Tools > Boot from USB) that the add-on replaces.
- Places: duplicates (same category + name within ~75 m; ~30 m for unnamed) are removed in the 150-mile locator (`write_outputs`) and across all state files of the wide-area layer (earlier states win, richer entry kept).
- OSM source files: `.osm.pbf` files are now deleted automatically once converted (places layer: `tools\poi-source`, leftovers of finished states are removed on the next run; street maps: `OSM-MAP-SOURCE`). A state file already in OSM-MAP-SOURCE is reused for places instead of downloaded again. `--keep-osm-source` keeps them. Trade-off: widening the radius re-downloads the state files.

## v33
- Builder: heavy "Pages + search index" pass (full-text index, GPS/Excel/KML exports, hospital sheet, OPEN-WITH, catalogs) now runs ONCE at the end; the between-step passes are quick (launchers, topic index, library pages). Previously it ran 7+ times per build.
- Hospital directory: fixed `KeyError: 'phone'` when the HIFLD hospital data is not on the drive (SimpleMaps rows now filled with blanks).
- "Space used" no longer counts OPEN-WITH (hard links, no extra space). OPEN-WITH link cap raised 4000 -> 12000 so big folders (topo maps, music) are not cut off.
- OCR fix: Tesseract output is read as UTF-8 (Windows used cp1252 and crashed on curly quotes, which saved EMPTY pages as done). Failed pages stay queued; pages stored empty by older runs are re-OCR'd once (state flag v=2).

## v35
- NOMAD on low-RAM PCs: `TUNE-WSL2-MAX-WINDOWS.bat` (`wsl_max.ps1`) writes `.wslconfig` giving WSL2 total RAM minus 2-3 GB, all cores and 12-32 GB swap, memory never handed back, then restarts WSL. `-FreeUp` offers to close big apps; `-Restore` undoes it. INSTALL-NOMAD-WSL2 now runs it first (skip with `-NoTune`). NOMAD's own installer has no RAM check.
- UGA C957 link fixed (old pubs.caes.uga.edu no longer resolves): now secure.caes.uga.edu/extension/publications/files/pdf/C%20957_4.PDF.

## v37
- **MAP-DRIVE.bat** (START-HERE menu **W**, `usb/map_drive.py`): read-only map of the whole drive. Writes `REPORTS\DRIVE-MAP.html` (clickable folder map + problems) and `DRIVE-MAP.txt`. Checks launchers, Command Center pages and tiles, links between pages, library documents against `manuals.tsv`, and lists half-finished downloads, leftover `.osm.pbf`, 0-byte files, probable duplicates, loose reports and unexpected top-level items. Uses the builder copy on the drive, so it needs no internet.

## v38 - faster Ask-the-Library
- **Prebuilt index** (`usb/ask_fast.py`, written by the builder's Ask step): `www/docs-idx.js` holds a ready-made BM25 index so `ask.html` no longer tokenizes every passage when it opens; queries touch only the matching words. Falls back to the old in-browser index if the file is missing. Rebuild alone: `ask_fast.py --dest <drive>\OFFGRID`.
- **Tighter context:** 4 best passages (was 6), weak matches dropped (<40% of the top score), at most 2 per source, paragraphs that mention the question's words are kept instead of the first N characters, 3,000-character cap. Fewer tokens in = faster first word.
- **Streaming answers** (`stream:true`; `serve_usb.py` now passes event-streams through) - words appear as they are produced instead of after the whole answer. Shows "first words after X s".
- **Prompt cache:** the AI's instructions are now identical for every question (anything that varies moved to the user message) plus a fixed drive briefing (`www/ask-brief.js`: library sections and example titles). `cache_prompt:true` and a one-token warm-up when the page opens let llama-server read that prefix once and reuse it.
- **Instant answers:** `usb/instant.js` matches the question to the Situation Center checklists and quick-response cards and shows them at once (no AI wait); the same checklist is also given to the AI as a grounded excerpt.
- `max_tokens` 800 -> 600. Nothing is stored in the browser.

## v39 - clean-up from the first full v38 run
- **Tidy** now also deletes build leftovers: `tools\planetiler-tmp` (map-converter scratch; was 25 GB) and `.osm.pbf` files already turned into places (`tools\poi-source`), and deletes `__pycache__` instead of binning it. The builder no longer writes `__pycache__` (stopped the same ~45 files landing in `_TIDY-BIN` every run).
- **Survival guides:** the builder now makes every situation guide at build time, so the Command Center tile always opens (it pointed at `guides/index.html`, which only existed after running MAKE-A-GUIDE by hand).
- **Army publications:** files the Army site lists as public but refuses are counted; after 3 failed tries they are skipped (`tools\armypubs-fails.json`) and listed in `REPORTS\NOT-FETCHED-Army.txt`. Before, ~430 of them were retried every run.
- **Radio channel lists:** "Library" link fixed (`../index.html`); existing pages are repaired in place.
- **Quieter log:** encyclopedia and almanac volumes are only listed when new.
- **Console text:** builder sets UTF-8 output (no more `â€"`).
- **Poisonous Plants of the Southeastern US:** the old UF host now redirects to a web page; manuals.tsv points at Alabama Extension's copy (ANR-0975).
- **MAP-DRIVE fixes:** no longer reports pages the builder puts elsewhere, builder-made top-level folders, empty `py.typed`/`__init__.py`, or "duplicates" that only share a size; duplicates are now confirmed by content and deliberate copies (GOOGLE-EARTH-READY, SOFTWARE, ...) are skipped. Link check no longer trips on links built in JavaScript.
- Still manual: PHMSA's ERG 2024 PDF (the site returns 403 to scripts - save it from a browser as `www\library\Disasters\erg_2024_emergency_response_guidebook.pdf`) and FCC `l_amat.zip` into `tools\fcc\`.

## v40
- **Ask the Library now searches every PDF page.** The Ask page asks the drive server (`/ask-search`, in `serve_usb.py`) for the best pages from the full-text index (the same index the Search page uses: every manual page, guide section, OCR text) and adds up to 3 of them, with page links, to the instant passages. Falls back silently to the 940 built-in passages if the index is missing or the server is busy. The AI system prompt is unchanged, so prompt caching still works.
- **REPORTS\DRIVE-CHECKLIST.txt / .html** (`drive_checklist.py`) — rewritten at the end of every builder run: ticks what exists (search index, Ask index, AI model, checksums, drive map, no skipped downloads, family vault, personal papers), lists what is still missing (ERG, FCC l_amat, Survival & Austere Medicine, fallout shelter plans), and keeps a list of physical/manual jobs only you can confirm (real-Windows test, second copy, card reader/adapters, Faraday storage, password manager, scheduled tasks).
- **MY-PERSONAL-FILES-INBOX → PERSONAL\** (`personal_files.py`) — private family papers are sorted by file/folder name into Identity, Medical, Insurance, Financial & Tax, Home & Property, Vehicles, Legal, Military & Employment, Education, Family Photos & Records, Pets, Emergency Contacts & Plans, Other. Files are moved only after a verified copy; exact duplicates are removed. **Never** put in www, the search index, TEXT-ONLY, OPEN-WITH, the AI, or the drive map; contents are never read. `PERSONAL\CHECKLIST.txt` lists which essential papers look present (by file name) and `PERSONAL\EXPIRING.txt` sorts files named like `Passport exp 2031-05.pdf` by expiry. Keep PERSONAL inside the VeraCrypt vault.
- Added two public-domain shelter plan PDFs to the download list (Family Fallout Shelters, Expedient Shelter Handbook).
- Untested on real Windows: the downloads, the builder steps and the server endpoint were tested on a mock drive only.
- Fix: the manuals step now skips any title you already placed yourself (matched on file-name key words, ERG by name), and stops retrying a site whose own security certificate is broken (it is listed, not bypassed).

## v41
- **START-HERE.bat now opens a window with buttons** (`PROGRAMS\START-HERE-GUI.ps1`, generated by `launcher.py`): a big green START THE DRIVE button (runs START-WINDOWS.bat, which opens the Command Center), Drive checklist, Search, then every program as a button in groups (Use the drive, Add my own files, Check and repair, Update and online, Copy/back up/protect), with the description as a tooltip. Each button runs the same PROGRAMS\*.bat the text menu runs. Plain PowerShell + Windows Forms: no install, no mshta/HTA (flagged by antivirus, VBScript being removed).
- If PowerShell or the window fails, START-HERE.bat falls back to the numbered text menu automatically; `START-HERE.bat text` (or the "Text menu" button) forces it.
- New menu entry **I - Add my PERSONAL family papers** (`ADD-MY-PERSONAL-FILES.bat`).
- Untested on real Windows (the window code was only generated and read here, never run).

## v42 - public edition
- `scripts/make_public.py` builds `offgrid-public-v42.zip` from this repository (a copy; this repo is untouched). Same builder; removes the UV-32 radio plan, the get-home routes and work cities, and the author's name; adds BUILD-MY-DRIVE.bat, a public README, `edition.json` and the 'Files to add yourself' page (`usb/suggested-files.html`, also a button in START-HERE and `www/suggested-files.html` on every drive). Re-run it after each release to refresh the public zip.
- `region.py`: ZIP -> home (zippopotam.us, then the Census ZIP gazetteer, then 'City, ST' from the bundled city list, then typed lat/lon; always confirmed by the user), home-state neighbours for Geofabrik extracts, the regional topo bbox, and `localize()` which rewrites 'Canton, GA' text, the home coordinates and the get-home card in the copied pages (no change when the home is the original).
- `usb_builder.py`: new `--zip` / `--state`; `set_home()` reuses the drive's saved home for every mode (so the add-on scripts use the right home) and, in the public edition on the first run, asks for the ZIP. With a ZIP: no Toronto/Quebec routes or Canadian topo, Geofabrik regions and the topo-south layer follow the home state, bases / cities / lakes come from the home region (`areas.area_list(home=...)`). Without a ZIP nothing changes.
- check_usb no longer fails when the radio or get-home folders are absent.
- Untested: the ZIP lookups need internet (this sandbox blocks them; the logic and the City, ST fallback were tested), and nothing has run on real Windows.

## v43
- **Command Center is the one-stop index.** New `drive_catalog.py` (run at the end of every build) writes `www/data/catalog.js`: every street-map layer, topo set, OsmAnd phone map, KML/GPX file, Kiwix archive, movie, show and album, plus drive used/free. The Command Center merges it into the Library filter chips (Maps / Archives / Movies & TV / Music next to the manual sections) and its search box, shows counts on Home, keeps a **Recent** list (this device), and the search box now offers **Ask the offline AI** for whatever was typed.
- **Maps tab**: one place that says which map to use on which device (browser locator map, printable GeoPDF topo, OsmAnd on Android/iPhone, state DOT PDFs, Google Earth/QGIS/Garmin) and lists every map file on the drive.
- **Manuals remember past runs** (`tools/download-history.json`): a link that is gone (404/410/dead) is retried from the Internet Archive's saved copy of the same URL; a link that fails 3 builds in a row rests for 30 days instead of slowing every build; blocked sites (403) are never worked around. Every miss, with the reason, goes to `REPORTS\NOT-FETCHED-Manuals.txt` (counted by the drive checklist).
- When BUILD finishes it opens the drive folder and the drive checklist.

## v45 - FAS DoD doctrine without duplicates
- New `fas_doddir.py`: fetches the PDFs listed on irp.fas.org/doddir (DoD, Army, Navy, Marine Corps, Air Force, Military Medicine; the NSA Rainbow page is skipped) into `www/library/DoD Doctrine (FAS) - <section>`. Medium builds take Military Medicine; large adds USMC, Army, DoD; full takes all six. A size limit per run (3 / 15 / 40 GB) keeps builds moving; the rest comes next run.
- No duplicates: each publication is reduced to its number (`pub_key`: 'ATP 3-50.21', 'atp3-50-21.pdf' and 'us_army_atp_3_50_21_...pdf' all become `atp 3-50-21`; edition years are dropped). It is skipped if that number is already anywhere in the library (armypubs, Marine Corps, manuals list, your own files) or earlier on the FAS pages (FAS lists many twice and keeps old editions after the current one). Every URL fetched or failed is remembered in `tools/fas-doddir.json`; failures rest 30 days; a 403 stops that section (not worked around); misses go to `REPORTS\NOT-FETCHED-FAS-DoD.txt`.
- Runs in the builder right after the Army & Marine publications, and from menu A (Download Army, Marine & DoD manuals). `fas_doddir.py --dry-run` lists what it would fetch.

## v46 - fixes from the v45 run
- OCR "stuck": before OCR starts it checks every new or changed PDF for picture-only pages. That check was silent, read each PDF inside Python (one huge or broken PDF could hang or crash it) and only saved at the very end, so a closed window started it over. Now it uses Poppler's pdftotext (separate program, 2-minute limit per PDF), shows `checked N/M PDFs`, and saves every 200 files so a re-run continues.
- "AttributeError: '_Tee' object has no attribute 'encoding'" (v44's build log) broke the encyclopedias/TiddlyWiki/Ubuntu and language-book steps: fixed.
- The long blank gap during the FAS step: each download whose size the site doesn't report printed an empty line. No more blank lines; small files show MB instead of "0.00/0.00 GB". FAS now counts and reports what it couldn't get per section, and stops a section (without working around it) after 15 failures in a row, e.g. when the site answers with a robot-check web page instead of the PDF.
- Army publications: no more "Army Army ..." headings; clearer counts ("N to download; M the Army site refused 3 times"); refused items the drive already has from FAS or your own files are no longer listed as missing.
- Garbled dashes and arrows (`â€”`, `â†’`) in the window: the build, update and every PROGRAMS .bat switch the window to UTF-8 (`chcp 65001`).

## v47 - OCR progress lost and recovered
- Cause: OCR's progress file (`www/search/ocr/state.json`) was written in place; a window closed mid-save left it broken, the next run read it as empty, treated all 5,149 PDFs as new and deleted their OCR text, then started all 49,937 pages again.
- Recovery: on the first v47 run each document's OCR text is rebuilt from the search index (`www/search/text/<key>.js` already holds the recognised text of every scanned page), so the finished pages come back in minutes and only truly new pages are OCR'd.
- Prevention: every OCR file is now saved crash-safe (temp file, fsync, swap, previous copy kept as `.bak`, and read back from `.bak` if the main copy is damaged); OCR text is only discarded when the PDF itself really changed, never because its progress entry is missing.

## v48 - faster OCR
- Several pages at once: one Tesseract per core (cores minus 2, up to 8), each limited to one thread and below-normal priority. On an 8-core PC that is about 6x the v47 speed and the computer stays usable. The progress line shows hours left.
- Blank pages (blank sheets, backs of covers) are spotted with a quick 40-dpi look and marked done without OCR.
- Search is updated every 25 pages instead of only at the end, so a closed window loses nothing.
- Recovery also takes back previously OCR'd pages that had only a little text (runs once more on every document).

## v49
- `usb/data/field-notebook-base.html` (the Field Notebook's TiddlyWiki base) now ships gzipped (`.html.gz`, read by field_notebook.py). Windows' zip extractor failed on it with error 0x80004005, typically an antivirus scan locking a large script-heavy .html during extraction.

## v50
- OCR exit code 3221225478 (0xC0000006, "in-page error") means Windows could not read the drive mid-run: the USB drive disconnected or had a read error. The builder now says so, stops cleanly when the drive is gone (instead of failing every later step), and no longer crashes writing the crash log.
- Lighter on USB drives: OCR uses up to 4 pages at a time (was 8) and forces data to disk only for the progress file, not after every page.
- Fixed the garbled `â€”` text at its source: some messages in usb_builder.py / launcher.py / pbf_convert.py had been saved double-encoded.

## v51 - meaning-based search
- New `semantic.py`: every page in the full-text index (manual pages, OCR'd scans, guide sections) gets a 256-number meaning vector from Google's EmbeddingGemma 300M (`ai/models/embeddinggemma-300M-Q8_0.gguf`, 334 MB) run by the drive's own llama-server (`--embeddings`). Stored int8 in `www/search/vec/` (about 256 bytes a page). Resumable per document; a document is redone only when its text changes (e.g. OCR adds pages). numpy is fetched once into `tools/pylib/numpy-<platform>` for building and fast search; computers without it search through 1,024 coarse clusters in pure Python.
- Runs at the end of every build (`--meaning-hours`, default 3 h per run; 0 = skip) and after OCR-OVERNIGHT (12 h+).
- The drive server loads the small model at start (role `embed`, port 8094). Ask mixes word matches and meaning matches (word, meaning, word...); the Search page shows "Related by meaning" above the word results (`/meaning?q=`). Opening files directly (no server) keeps plain word search.
- Drive checklist shows whether the meaning index is built.
- Tested with a stand-in model server here; the real model and llama.cpp on Windows are untested.

## v52
- A damaged file on the drive (Windows error 1392, "corrupted and unreadable", typically left by the drive disconnecting while writing) no longer stops OCR or the full-text search index: it is skipped and listed in `REPORTS\UNREADABLE-FILES.txt` with the fix (`chkdsk E: /f`), and the drive checklist shows it until it is gone.
- Quieter log: language books only list new downloads; "Offline weather" without "Southeast".


## v54
- Removed the v53 "sort the other files" organizer (organize_other.py, ORGANIZE-OTHER-FILES.bat and its START-HERE button); a drive that got it has PROGRAMS\ORGANIZE-OTHER-FILES.bat removed on the next build.

## v55
- New library section **Generators**: owner's manuals for the most common home/portable generators, from the manufacturers' own sites where possible — Honda EU2200i (two editions), EU2000i, EB2200i; Generac GP3250, GP3600, GP6500/GP8000, Guardian air-cooled home standby 10-26 kW owner's manual + installation guidelines, Guardian 7-16 kW (NOAA copy); Champion 3500W (100524 dual fuel, 201286); Predator (Harbor Freight) 3500 inverter, 4400 inverter, 5000 dual fuel inverter; Westinghouse WGen series and WGen7500.

## v56
- Added from the bushcraftusa "best 100 PDFs" list (only items that are public domain or free from the publisher; the thread's own links are personal Google Drive copies, many dead, and several are copyrighted books, so none of them are used): WHO Monographs on Selected Medicinal Plants Vol. 1, Useful Wild Plants of the US and Canada (Saunders 1920), The Making of Leather (Procter 1914), FM 5-426 Carpentry.
- Further research picks: WHO Managing Complications in Pregnancy and Childbirth (2017), MSF Clinical Guidelines, Navy Hospital Corpsman NAVEDTRA 14295 (2 parts), Seabee Builder Basic / Builder Advanced / Builder 3&2, USDA Beekeeping in the US (AH 335).

## v57
- **MEANING-OVERNIGHT.bat** (PROGRAMS, and a button in the START-HERE window): builds the meaning-search index with no time limit (`semantic.py --hours 0`), keeps Windows awake while it runs, optional shutdown when finished. Resumable.
- Faster meaning indexing: llama-server now embeds 4 pages at a time (`--parallel 4`, context 8192) on all cores but one, 32 pages per request. Progress shows pages per minute and hours left (the old "0 pages/s" just meant under one per second).

## v58 - communications
- Two new original guides in Comms: **Radio Security: Keeping Your Location Safe** (how transmitters are found, transmitting less, where to transmit from, terrain/directional antennas/NVIS/wire, devices that beacon your position — phones, APRS, Meshtastic, photos, the FCC licence address — and a printable family comms plan, all within FCC rules) and **Choosing Radios for Emergencies** (FRS/GMRS/MURS/CB/ham/Meshtastic/satellite compared, listening gear, kits by level, what matters more than the radio).
- Downloads added to Radio reference: ARRL ARES Field Resources Manual, ARES Manual, NTS Manual, NTS radiogram format, radiogram form FSD-218, ARL numbered texts; FEMA ICS 205, 205A, 213 forms; NCVEC 2026-2030 Technician question pool (public domain); USMC MCRP 3-40.3B Radio Operator's Handbook; TAC RADIOS (ATP 6-02.72/MCRP 3-40.3A); FM 6-02.53 Tactical Radio Operations.
- Meaning search shows page progress inside very large manuals (it updated only between documents, so one 1,000-page manual looked stuck).

## v60
- **TOP 20 SITUATIONS** folder at the drive root (new `usb/situation_packs.py`). One printable page per situation —
  power out, tornado/severe storm, house fire, flood, winter storm, extreme heat, hurricane, severe bleeding,
  cardiac arrest/CPR, sickness/outbreak, no safe water, evacuate now, stranded away from home, lost, chemical/gas
  release, nuclear/fallout, unrest/break-in, no comms, long-term grid down (EMP/solar), burns & serious injury.
  Picked from what households face most (Census AHS outage data, Red Cross home-fire calls, Ready.gov hazards)
  plus the high-consequence events the drive is built for.
- Each page: **Do this now** (the checked first steps from the Command Center cards; new house-fire card),
  **What you need** (kit list), **How to handle it** — the best 12 pages on *this* drive found by several focused
  full-text searches (plus meaning search when its server is already running), each with a snippet and a link that
  opens the PDF at that page — **Warnings found** in those pages (filtered so another situation's advice doesn't
  leak in), guides, matching Kiwix archives and the nearest real places from the locator.
- Built at the end of every builder run (after the search index). Rebuild any time with
  `PROGRAMS\TOP-20-SITUATIONS.bat` or the new **Rebuild Top 20** button; opened from the gold **TOP 20 SITUATIONS**
  button in START-HERE and a Command Center tile.

## v61
- **DASHBOARD.html** at the top of the drive (new `usb/dashboard.py`): the big-tile front page anyone can
  double-click — Top 20 situations (gold), Command Center, What's happening?, Search, Library, Locator map,
  Medicine, Radio, How to use, Drive checklist, Field Notebook, Programs list — with the home area and last-build
  date. Plain HTML, works with no server; says plainly that programs (AI, map server, archives) start from
  START-HERE because a web page can't launch them. Written every builder/update run (again after the Top 20 pages),
  added to the START-HERE window, the drive check, protect, map-drive and platform copies.

## v62
- **Connect AI apps** (`www/ai-apps.html`, Command Center > Tools): researched Jan, AnythingLLM, Open WebUI, LM Studio
  and agents (OpenClaw). The drive's llama-server is OpenAI-compatible, so the page gives the exact settings for each
  (Base URL `http://ADDRESS:8080/v1`, any key, any model name, 8192 context) and fills in the address by itself
  when opened from another device. START-WINDOWS also prints that Base URL.
- **Borrow a bigger AI on another computer:** new `/ai-target` in serve_usb. Point the drive at LM Studio (1234),
  Jan (1337, with key), Ollama (11434) or another OFFGRID drive (8080) on the home network; the Ask page still
  searches and cites *this* drive's library, only the answering moves. Home-network addresses only (private/
  loopback check, so nothing goes to the internet); tested before saving; model name and key filled in for that
  server; llama.cpp-only options stripped; falls back to the drive's own AI when that computer is off. Setting
  lives in `ai\remote-ai.json`; only changeable from the computer the drive is plugged into. Ask page shows which
  AI is answering.
- **INSTALL-SOFTWARE** now also saves the Jan and AnythingLLM Desktop Windows installers (`SOFTWARE\AI apps\`) for
  offline installs. Open WebUI (pip + internet) and LM Studio (not open source) are documented, not bundled.

## v63
- **ZIM articles in the drive's own index** (new `usb/zim_index.py`, called from the search-index step): every
  article in the smaller Kiwix archives (WikEM, MDWiki, water/medicine/post-disaster zimgit, Appropedia, iFixit,
  Stack Exchange...) is read with python-libzim (installed once into `tools\pylib\_libzim`) and added to Search
  everything, Ask, meaning search and the Top 20 pages - no server needed. Chunks of 600 articles, 4,000 chars each,
  up to 40,000 articles per archive; unchanged archives aren't re-read. Full Wikipedia, Khan Academy, Gutenberg,
  video and >6 GB archives stay live-search only. Report: `REPORTS\ZIM-ARTICLES-INDEXED.txt`. Not copied to TEXT-ONLY.
- **zim.html article viewer:** opens an indexed article's text straight from the index (works as a plain file, search
  words highlighted) with a button to the full page with pictures through Kiwix.
- **Live archive search** (`/zim-search` in serve_usb, kiwix-serve `/search?format=xml`): when the drive is started,
  Search everything shows "From the archives" (full Wikipedia included), and Ask adds up to 2 live archive articles
  (fetched as text) from archives that aren't already in the index. One multi-archive request, falling back to
  per-archive searches if kiwix-serve refuses.
- Meaning search reads manuals and guides first, archive articles last.

## v64
- Fix: "could not install python-libzim" on Windows - the drive's embedded Python has no pip. python-libzim is now
  fetched as a wheel from PyPI (picks the right build for the Python version and system, e.g.
  cp311-abi3-win_amd64 for Python 3.12) and unpacked into `tools\pylib\_libzim-<platform>`, like numpy and pypdf.
  Downloaded once; prints the real reason if it can't download or load.

## v65
- **Every runnable program is now in PROGRAMS** (59 files). New drive-side programs, all using the drive's own
  Python/builder copy and the home settings of the last build (`--update` + one `--*-only` mode):
  REBUILD-SEARCH (new `--search-only`: search, pages, Top 20, dashboard; offline), REFRESH-PAGES (dashboard,
  checklist, catalog, Ask speed-ups, Field Notebook, Top 20 - no search rebuild), REFRESH-GOOGLE-EARTH-AND-EXCEL,
  CONVERT-OSM-MAPS, ADD-PLACES (asks miles), ADD-TOPO-MAPS (asks miles), ADD-SATELLITE-IMAGERY, ADD-US-STREET-MAP,
  ADD-HOSPITALS, ADD-CAVES, ADD-MEDICINES, UPDATE-WEATHER-PAGE, MAKE-ANDROID-FOLDER, REBUILD-OPEN-WITH,
  TOPO-DOWNLOAD-TEST. Before, the map/places/medicine ones existed only in the builder folder (defaulting to E:).
- One `MORE` list in launcher.py drives the files, the START-HERE window ("More programs" sections + a PROGRAMS
  folder button) and READ-ME-FIRST / programs.html (second table). Text menu (no letters left): **S** now offers
  Search page / PROGRAMS folder / Reports.
- `-only` runs log to their own REPORTS\<MODE>-LOG.txt instead of overwriting UPDATE-LOG.txt; search-only and
  convert-only never trigger the 90-day places refresh.

## v66
- **Survival-relevant part of the giant archives is now indexed** (and so in meaning search, Ask and the Top 20
  pages). zim_index.py runs ~330 survival searches (20 topics: first aid, illness, bites, weather, water, food &
  foraging, farming, hunting, shelter & fire, navigation, tools & craft, power, radio, vehicles, security, CBRN,
  sanitation, chemistry, emergency management, plants & animals) in each giant archive's OWN full-text index and
  keeps the best matches: full Wikipedia up to 100,000 articles (3 pages each), Gutenberg up to 2,000 books
  (40 pages), Wikisource 6,000, big Wikibooks 15,000. Long articles now span several pages (all archives), and
  the zim.html reader joins them. Khan Academy, PhET, TED and Wiktionary stay live-search only. The chosen
  list is kept in tools\zim-subsets\ and only re-picked when the archive or the topic list changes.
- **Archive contents page** (new `archive_lists.py`, `www/archives.html`, Command Center > Library, Dashboard):
  every archive with its counts of articles, books (EPUB/PDF), videos and audio; click one for a filterable list
  (kind and section pickers, paging) of EVERYTHING in it up to 400,000 entries - all Gutenberg books, all Khan
  Academy videos - each linking to Kiwix; indexed articles also get "read offline". Full Wikipedia lists its
  survival selection by topic. Rebuilt only when an archive changes.

## v67
- **Guides know where you are.** MAKE-A-GUIDE asks "Where are you now?" (Enter = home; a city like Montreal or
  Albany, NY; or lat, lon - offline lookup in the bundled US city list + Canadian cities + route cities). Away
  from home the guide lists the nearest hospitals, pharmacy, fuel, police... to THAT spot (from the route
  corridors, the 500-mile layer and the home locator) instead of home. `--where` on the command line.
- **Get home from a route** now starts from the route's city and adds "Along the way home": nearest hospital,
  fuel, pharmacy, grocery and water within 25 miles of the start and each waypoint.
- **Radio for this trip** section: all seven NOAA weather channels to program (US); in Canada, Weatheradio Canada
  is out of service - use local AM/FM; US hams in Canada sign /VE2 (Quebec) or /VE3 (Ontario) under the
  reciprocal agreement (carry licence + proof of citizenship); ham/GMRS repeaters mapped along the route.
- **ADD-ROUTE-PLACES** (new `corridor_pois.py`, `--route-places-only`): places within 25 miles of every
  get-home route and 40 miles around each start city, incl. Ontario and Quebec, from Geofabrik extracts (states
  fully inside the 500-mile layer are reused, not downloaded). Canadian extracts stay in OSM-MAP-SOURCE for
  CONVERT-OSM-MAPS street maps. Cached per state/province; kept current by UPDATE-DRIVE once it has run.
  Output www/data/corridors/<route>.js.

## v68
- Fix: an l_amat.zip you download yourself and drop in MY-RADIO-INBOX (as the checklist says) was filed under
  Library > Software and never used. Add-my-radio-files and the builder now move it to tools\fcc\l_amat.zip and
  build the offline call-sign lookup from it straight away (only HD.dat, AM.dat and EN.dat inside are read).
  MY-FILES-INBOX works too.

## v69
- **Canadian ham call signs** (ISED amateur_delim.zip, ~92,000 operators): downloaded by the builder
  (apc-cap.ic.gc.ca, refreshed after 45 days) or dropped in MY-RADIO-INBOX, indexed into the same offline
  lookup (www/ham-calls.html): search VE2.../VA3... call signs or the first 3 characters of a postal code
  (G1R Québec City, M5V Toronto); qualifications shown (Basic, Basic+Honours, Advanced, 5/12 WPM).
- Checked the FCC field codes against ULS Code Definitions (7/18/2024): licence status A = active, operator
  classes A/E/G/N/P/T - the call-sign index already matches them.

## v70
- Ham call-sign lookup can search **by town**: `Canton, GA`, `Quebec, QC` (accents ignored), or a whole state /
  province (`QC`), besides call sign, ZIP and Canadian postal code (new per-state/province files data/ham/st/).
- Both the FCC (US) and ISED (Canada) lists are downloaded and refreshed automatically by every build and
  UPDATE-DRIVE (after 45 days); new **UPDATE-HAM-CALL-SIGNS** program (`--ham-only`) refreshes just these.
  Dropping the zips in MY-RADIO-INBOX is only a fallback if a download is blocked.

## v71
- New library guide **Comms → Mesh Networks** (`mesh_networks_guide.html`): Meshtastic vs MeshCore vs Reticulum vs LoRa APRS vs AREDN vs phone-only apps; US 915 MHz rules incl. the 2026 500 kHz bandwidth question and ham mode; parts lists; builds for a handheld node, solar relay, quarter-wave antenna, Reticulum RNode/Sideband, LoRa APRS; family planning and privacy.
- Library downloads: Reticulum Manual, AREDN documentation and AREDN Beginner's Guide (PDFs).
- Phone apps: Sideband (Reticulum) APK added (skipped quietly if the release file name changes).
- Choosing Radios guide links to the mesh guide.

## v72
- **Satellite imagery for the whole Eastern US and Eastern Canada** (new `usb/imagery.py`). ADD-SATELLITE-IMAGERY now asks for a level:
  1 overview (zoom 6-12) of every eastern state and province + detail along each get-home route (zoom 13-15 within 15 mi, zoom 16 within 2 mi) and home/start cities;
  2 adds the whole region at zoom 13; 3 adds zoom 14 (+ NAIP detail for bases/cities/lakes); 4 adds zoom 15. Asks for an optional hour limit; resumable.
  Sources per tile: USGS NAIP (US), Geospatial Ontario (Ontario), Esri World Imagery (everywhere else / fallback). Servers that keep refusing are dropped and listed in REPORTS\NOT-FETCHED-IMAGERY.txt. Report: REPORTS\SATELLITE-IMAGERY.txt.
  Stored as MBTiles in www/tiles/imagery (one file per band — no millions of small files); the drive server serves one combined layer at /imagery/{z}/{x}/{y} (MBTiles + the older NAIP folder), shown on the map as "Satellite — Eastern US & Canada".
- The older high-detail NAIP step runs after the region layer and is sized by level (home to zoom 18; route spots to 16/17/18; bases/cities/lakes only at levels 3-4).
- **Satellite on phones**: OsmAnd `.sqlitedb` files for home and each route in www/phone-apps/satellite (page with install steps). MAKE-PHONE-SATELLITE remakes them offline.
- **Printable satellite maps**: new `PRINTABLE MAPS` folder — Home (3 zoom levels) and each route as an overview + overlapping letter-size sheets in driving order with the route, border crossings/chokepoints/refuel stops, water/hospitals/fuel/shelters from the route places, towns, lat/long grid, scale and north arrow. MAKE-PRINTABLE-MAPS remakes them offline. Dashboard tile added.
- New builder flags: --imagery-level, --imagery-hours, --phone-satellite-only, --map-sheets-only.

## v73
- **FEMA locations** (new `usb/fema_data.py`, refreshed by UPDATE-FEMA-AND-RIVER-CHARTS and every update):
  every registered shelter in the eastern states (FEMA ESF#6 Shelter System: capacity, accessible, generator, pets, in a flood/surge area),
  shelters open right now and FEMA Disaster Recovery Centers (snapshot), and counties with a disaster declaration in the last 2 years
  (OpenFEMA + Census county outlines; red = individual help still open, with the apply-by date).
  Map layers on the locator; Google Earth files in GOOGLE-EARTH-READY\FEMA; report REPORTS\FEMA-DATA.txt. FEMA shelters also print on the satellite map sheets.
- FEMA's own online Google Earth tools (Stay Dry 3.2, NFHL 3.6 + guides) copied to GOOGLE-EARTH-READY\FEMA\ONLINE-ONLY — they need internet.
- **River charts** (new `usb/ienc.py`): USACE Inland ENC Google Earth charts for the river sections along the routes (Ohio at Cincinnati,
  Tennessee River Chattanooga–Knoxville, lower Clinch), plus one file of the locks, dams, bridges and landings pulled out of them.
  --ienc-all takes all ~109 sections. GOOGLE-EARTH-READY\River charts (IENC).
- Locator map: opens even when the only layers are satellite or FEMA (fixed a crash when there was no street/topo layer).
- New flags: --fema-only, --no-fema, --ienc-all.

## v74
- Library: 32 additions from theswissbay.ch's Survival collection — only US/Canadian government works and pre-1929 public-domain books
  (MCRP 3-02H, TC 31-29A caching, GTA injurious plants, FEMA 196 state-by-state hazards, FEMA H-12-1 fallout shelter plan and food/water
  guides, MCRP 3-02G first aid, MCRP 6-11C combat stress, FM 4-02.17, FM 8-10-4; Kephart, Nessmuk, Beard, Seton, Breck, Taylor,
  Fordyce, Longstreth, Woodcock, Gibson, Alexander, Roberts, Bolton Hall). Copyrighted modern books in that collection were left out.

## v75
- **Fast search database**: `usb/search_db.py` builds www/search/search.db (SQLite FTS5, porter stemming, contentless — page text stays in search/text)
  in the same pass as the JavaScript index, with the same page ids. Used automatically when the drive's server runs: the Search page
  (new /fts endpoint), Ask-the-AI passages, Top 20 situations and search_cli. Adds exact "phrases", word* prefixes, -exclusions, category
  filters and keeps common words. Double-clicked search.html (no server) still uses the JS index. Skipped quietly if Python lacks FTS5.
- **Index backups**: `usb/index_backup.py` → BACKUP\INDEXES\<date>\ (one zip per part + MANIFEST.json with SHA-256), after every build,
  update and -only run that finishes; skipped when nothing changed; newest 2 kept. Covers the search index (incl. meaning-search vectors
  and OCR text), archive lists, ZIM picks, route places, page data, FEMA data and settings. search.db is remade from the page text on restore.
- PROGRAMS\RESTORE-INDEXES.bat: check, restore missing/damaged, restore all, back up now, copy the backup to another drive.
- DRIVE-CHECK reports the backup, missing/damaged index files and the fast search database. --no-backup skips the backup.

## v76
- Library (Radio reference): 6 free radio references from n5dux.com — USMC Antenna Handbook (MCRP 6-22D), IARU VHF Handbook,
  IARU Ethics and Operating Procedures, The Art and Skill of Radio-Telegraphy, Zen and the Art of Radiotelegraphy, W4RNL wire HF antennas.

## v77
- Library: 49 more from n5dux.com — makeshift and wire antennas (J-poles, coax collinear, cheap Yagis, quads, rain-gutter loop,
  zip-cord dipoles, end-feds, doublet, small loops, tuner, hardline, SWR meter, lightning protection), simplex repeater, WWV calibration,
  direction finding / fox hunting, light-beam and laser comms, and detectors (radiation monitor, tornado detector, gas alarm, night vision, bug detector).
  Commercial books in that folder (Dummies, Mims, Grob, Make, Evil Genius) left out.

## v78
- **AI memory** (`usb/ai_memory.py`, ai/memory/knowledge.db, SQLite): every Ask question is logged; 👍 makes the answer a verified
  note, 👎 + a correction makes a correction note (newest per question wins), 👎 demotes those sources for similar questions.
  Notes are searched first and handed to the AI as "your verified answer / correction / note", which override the library.
  New page www/ai-memory.html: notes (add / delete), recent questions, and the AI's drive guide. Server endpoints /memory/*.
- **Drive guide** (`usb/drive_guide.py`): ai/memory/drive-guide.txt + www/ask-brief.js — library sections, archives, Top 20, maps,
  routes, radio and other places, made at the end of every build; goes at the start of the AI's (cached) instructions.
- **Reranker**: bge-reranker-v2-m3 Q4_K_M (~440 MB) downloaded with the offline AI; serve_usb starts it on first Ask (port 8095,
  llama-server --reranking) and re-sorts 16 candidates from the fast index + meaning search before the AI reads the best 5.
- **AI LEARN THE DRIVE - run overnight** (PROGRAMS\AI-LEARN-THE-DRIVE-OVERNIGHT.bat, START-HERE button, `usb/context_notes.py`):
  the local AI writes a 1-2 sentence note per page (library first, by importance; archives after); asks for hours and shutdown;
  resumable; uses the graphics-card build when present. Notes go into search.db (contextual search) and are shown to the AI with
  each page. search.db is remade at the end of each run; the backup now includes ai/memory.
- **Cleanup**: tidy also removes stale scratch (*.building, *.restoring, unfinished backups, imagery/AI journals, ai/dl, .kbbuild,
  FEMA cache zips) and writes REPORTS\CLEANUP-SUGGESTIONS.txt (duplicate files, download caches, unused AI models, older archive
  editions — never deleted automatically). TIDY-DRIVE opens the report.
- DRIVE-CHECK: drive guide, AI memory, reranker.

## v79
- **UV-32 radio image — travel routes**: `library/My Radio Programming/UV32_Useful_Channels.img` now has 704 channels (was 542).
  Zone 3 = ATL+GEORGIA (Georgia moved to ch 239-268), zone 7 = ALABAMA+FLA (Florida moved to ch 644-694).
  New zone 5 VIRGINIA+DC (ch 401-483): Richmond, South Hill, Manassas, Leesburg, Fairfax/Reston, DC/Arlington/Alexandria,
  Winchester-Harrisonburg-Staunton-Roanoke-Blacksburg-Wytheville (I-81), Hagerstown MD.
  New zone 9 CANADA ROUTE (ch 801-879): Dayton, Toledo, Detroit, Windsor, Chatham, London, Kitchener/Guelph, Toronto,
  Montreal, Quebec City/Levis, Plattsburgh/Burlington, Albany/Troy, Syracuse, Binghamton, Scranton, Harrisburg.
  Open analog FM repeaters from RepeaterBook (Nov 2026), named AREA + callsign, Tone mode, high power.
- New `UV32_CHIRP_Import.csv` (CHIRP generic CSV of all 704 channels) as a fallback; Reference CSV, Lineup and Plan regenerated.
- Image edited by a small stand-alone script (tools/radio), not by CHIRP — open it in CHIRP and check before uploading.

## v80
- **Fits the computer (low-memory)**: new `ai_pick.py` runs inside START (Windows and Mac/Linux). It measures total and free
  memory and picks the biggest chat model that fits (default, or the large one on 30 GB+), stepping down to the small
  Llama 3.2 3B on 8 GB machines and shortening the AI's memory (context 8192 → 4096 → 2048) when needed. The START window says
  why ("Low memory: using the smaller model ..."). A model named on the command line still wins.
- **COPY-AI-TO-THIS-COMPUTER** (PROGRAMS, button in START-HERE): copies the llama.cpp program and the models this computer
  uses (plus the small one, the reranker and the meaning-search model) to `%LOCALAPPDATA%\OFFGRID-AI` (`~/.offgrid-ai` on
  Mac/Linux, `copy-ai-mac-linux.sh`). START and the helper models load from that copy while it matches the drive file for
  file; after a drive update they fall back to the drive and say so. S = status, R = remove. The drive stays the master.
- **OUTAGE MODE** (PROGRAMS, gold button in START-HERE; `outage-mode-mac-linux.sh`): starts the drive with the smallest
  model, 4096 context, half the CPU cores and no graphics card, no model preloading; shows battery %, switches to the Power
  saver plan, dims the screen to 30 %, offers to turn Wi-Fi off (opens Wi-Fi settings if Windows needs admin rights), and puts
  plan, brightness and (if you say so) Wi-Fi back when the Command Center closes. The Command Center shows "OUTAGE MODE".
- Untested on real Windows: START's model picker, the power-plan / brightness / Wi-Fi commands.

## v81
- **Unfinished archive downloads**: `gutenberg_en_all_2025-11: Zim file(s) is of bad size or corrupted` was a ZIM whose
  download stopped early - the downloader renamed a short file as finished when the server closed the connection.
  Now it keeps the .part and resumes (attempts that make progress don't use up the retries), and every update compares each
  archive with the Kiwix server's size: a short one is turned back into .part and resumed from where it stopped.
  The indexer reports it as NOT READABLE in REPORTS\ZIM-ARTICLES-INDEXED.txt instead of a bare error.
- kiwix-serve starts with `--skipInvalid`, so one broken archive no longer stops every archive from opening.
- **zimgit archives indexed 0 articles** (Where There Is No Doctor, Knots, Water, Food preparation, Post-disaster): they hold
  PDFs, not web pages. The indexer now reads the PDFs inside archives (up to 400 pages each) with pypdf.
