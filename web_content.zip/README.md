# LaunchDeck Remote — PC server-enabled project

## What this build does
- Adds an actual Windows PowerShell PC server (no Python required).
- The Android app can scan its current IPv4 subnet for port 8765.
- Connect checks the server and validates the PIN.
- Launch buttons send requests to the PC server, which starts an allowlisted Windows app/action.
- Server has `/health`, `/connect`, and `/launch` endpoints. Arbitrary shell commands are not accepted.

## Start the Windows server
1. Extract `LaunchDeckRemote_Working.zip` on your Windows PC.
2. Open `LaunchDeck-PC-Server`.
3. Double-click `Start-LaunchDeck-Server.bat`.
4. The window displays the PC address and PIN. The default PIN is `246810`; change `$Pin` in `LaunchDeck-PC-Server.ps1` before use.
5. If Windows Firewall asks, allow it on **Private networks only**.
6. Keep the server window open. Connect the phone and PC to the same Wi-Fi.
7. In LaunchDeck Remote, open Connect → Auto-find PC → enter the PIN → Connect.

## Build the Android app
Open this project folder in Android Studio, sync Gradle, then choose Build > Build APK(s). The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limits
- This is a LAN server, not a cloud service. It requires the server window to remain open.
- Auto-find scans the phone's current IPv4 `/24` subnet and port `8765`; unusual networks/VLANs may require entering the PC IP manually.
- Use only on a trusted private network. Do not port-forward this server to the internet.
- ADB is Android Debug Bridge for Android devices; it is not a Windows PC app-launch server. This build uses PowerShell for Windows remote launching, without Python or ADB.
- I can't claim the APK has been compiled or tested on your devices from this environment.
