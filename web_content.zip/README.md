# AL-ANIS BUSINESS

Single-page app in `www/index.html` (HTML/CSS/JS, data in browser localStorage). Includes PWA files (manifest, service worker, icons).

## Run as PWA
Host the `www` folder on any HTTPS site. Android Chrome: menu > Install app. iPhone Safari: Share > Add to Home Screen.
Note: the Du'a & Qasidah pages load Google Fonts and a PDF library from the internet, so they look best online.

## Build the APK yourself (not built here - no Android SDK in my environment)
1. Install Node.js and Android Studio.
2. In this folder: `npm install`
3. `npx cap add android` then `npx cap sync`
4. `npx cap open android`, then Build > Build APK(s) in Android Studio.
Set the app icon with Android Studio's Image Asset tool using `www/icon-512.png`.

## Notifications
- In a browser: reminders are checked every 20 s and when the page becomes visible again; a reminder missed by up to 30 minutes still fires when the app is reopened. A closed browser cannot send them.
- In the Android APK: the code schedules the morning/evening/sleep and task reminders with the Capacitor Local Notifications plugin (`npm install` already lists it), so they can fire when the app is closed. This is written but NOT tested on a device. After installing, open Reminders, tap "Enable notifications" and allow it. On some phones also allow exact alarms / disable battery restrictions for the app.
- The reminders inside the three Du'a/Qasidah pages are the original page-based ones and only work while the app is open.

## Backup
Settings tab: copy the backup text and paste it back to restore.

## Offline
- App data (sales, purchases, notes, reminders, theme) is saved in the device's local storage and works without internet.
- `sw.js` caches the app files. Fonts and the PDF library used by the three Du'a pages are cached only after you have opened the app once while online.
- Audio you load with the folder button inside a Du'a page is stored on the device and plays offline. Streaming or downloading audio from an internet link is not built in.
- The header shows Online / Offline.
