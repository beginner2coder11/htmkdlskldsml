package br.com.nossomercadao.inventario;
import com.journeyapps.barcodescanner.CaptureActivity;
public class ScannerActivity extends CaptureActivity {}
