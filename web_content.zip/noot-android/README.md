# Noot

Een open source muziekspeler voor je eigen muziek, in de stijl van Spotify. Eén bestand (`www/index.html`), geen server en geen account. Licentie: MIT (zie `LICENSE`).

## Functies
- Eigen muziek toevoegen (mp3, m4a, aac, wav, ogg, flac, opus)
- Een map kiezen en scannen, met mappen die je uitsluit
- Favorieten, zoeken, willekeurig afspelen, herhalen
- Instellingen: volume, bas, hoge tonen, standaard willekeurig/herhalen, thema

## Uitproberen
Start een lokale server en open die in Chrome of Edge:

    npx serve www

## Map scannen en uitsluiten
Ga naar Instellingen > Muziekmap en kies een map. Uitsluiten kan op twee manieren:
- met een naam (`Podcasts`) of pad (`Muziek/Podcasts`) bij "Uitgesloten mappen"
- door een vinkje weg te halen bij "Gevonden mappen"

Uitsluitingen werken direct, zonder opnieuw scannen. Mappen die met een punt beginnen worden altijd overgeslagen.

Ondersteuning hangt af van de browser:
- Chrome en Edge op een computer: de map wordt onthouden. Na een herstart vraagt de browser opnieuw toegang bij het afspelen of opnieuw scannen.
- Andere browsers met mapkeuze: de scan geldt tot je de app sluit.
- Android-app (WebView): mapkeuze werkt niet. Gebruik daar "Muziek toevoegen". Mapkeuze op Android heeft een native Capacitor-plugin nodig, die zit er nog niet in.

## Android-app (APK) bouwen
Je hebt Node.js en Android Studio nodig.

    npm install @capacitor/core @capacitor/android
    npm install -D @capacitor/cli
    npx cap add android
    npx cap sync
    npx cap open android

Kies in Android Studio Build > Build Bundle(s) / APK(s) > Build APK(s). De APK staat in `android/app/build/outputs/apk/debug/`.

## Bijdragen
Pull requests zijn welkom. Houd de app bij één bestand zonder buildstap, tenzij daar een goede reden voor is. Met een bijdrage ga je akkoord dat die onder de MIT-licentie valt.

## Logo en app-icoon
In `logo/` staan het logo (`noot-icon.svg`, `noot-mark.svg`) en een PNG van 512 px. In `assets/` staan de bronbestanden voor het Android-icoon. Na `npx cap add android` maak je alle icoonformaten zo:

    npm install -D @capacitor/assets
    npx @capacitor/assets generate --android

Het logo valt onder dezelfde MIT-licentie als de rest.
