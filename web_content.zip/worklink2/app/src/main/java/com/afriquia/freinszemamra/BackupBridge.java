package com.afriquia.freinszemamra;

import android.content.Context;
import android.webkit.JavascriptInterface;

/**
 * Native JavaScript bridge for application backup and restore.
 * Exposed to WebView as window.AndroidBackup.
 */
public final class BackupBridge {
    private final MainActivity activity;

    public BackupBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean isReady() {
        return true;
    }

    @JavascriptInterface
    public String getBridgeVersion() {
        return "AFZ-BACKUP-BRIDGE-1.7";
    }

    @JavascriptInterface
    public void saveToGoogleDrive(final String json) {
        activity.startBackupSave(json);
    }

    @JavascriptInterface
    public void restoreFromGoogleDrive() {
        activity.runOnUiThread(activity::openBackupRestorePicker);
    }
}
