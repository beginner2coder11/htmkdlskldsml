JAS LAUNDRY ROOM — EXISTING MODULE REPAIR PASS

ഈ അപ്ഡേറ്റിൽ ചെയ്ത മാറ്റങ്ങൾ
-----------------------------
1. ERP Reports tab തുറക്കുമ്പോൾ പഴയ Reports renderer-ലേക്ക് തെറ്റായി പോകുന്ന dispatch പ്രശ്നം പരിഹരിച്ചു. ERP Reports ഇപ്പോൾ നിലവിലെ Branch അനുസരിച്ചുള്ള Bills, Payments, Expenses, Purchases summary കാണിക്കുന്നു.
2. Expense records-ന് Owner-only Add / Edit / Delete controls ചേർത്തു.
3. Supplier records-ന് Owner-only Add / Edit / Delete controls ചേർത്തു.
4. Purchase records-ന് Owner-only Add / Delete controls ചേർത്തു. Purchase delete ചെയ്യുമ്പോൾ ബന്ധപ്പെട്ട branch stock-ിൽ നിന്ന് quantity reverse ചെയ്യും; നിലവിലെ stock അതിന് മതിയാകാത്ത പക്ഷം delete തടയും.
5. Inventory Add / Edit / Adjust / Delete mutation-ുകൾ Owner-only ആക്കി.
6. Branch create / edit / activate-disable controls Owner-only ആക്കി.
7. Generic ERP delete action-ൽ allowed record types validate ചെയ്തു.
8. Existing db object, localStorage store keys, bills/customers/prices/payment histories, settings, and cloud config എന്നിവ reset ചെയ്യുകയോ clear ചെയ്യുകയോ ചെയ്യുന്ന migration ചേർത്തിട്ടില്ല.

പരിശോധന
---------
- ZIP archive-ിലെ HTML inline JavaScript blocks എല്ലാം Node.js syntax check വിജയിച്ചു.
- ERP Reports dispatch, Expense CRUD, Supplier edit, Purchase delete hooks എന്നിവ static source check ചെയ്തു.
- ZIP archive integrity പരിശോധിച്ചു.

പ്രധാന പരിധികൾ — സത്യസന്ധമായ അറിയിപ്പ്
--------------------------------------
- ഇത് source-level repair pass ആണ്; Android APK-യിൽ install ചെയ്ത് end-to-end test ചെയ്തിട്ടില്ല.
- Google Apps Script / Firebase credentials, deployment, Firestore rules, Android WebView, WhatsApp, Bluetooth printer, രണ്ട് ഫോണിലെ concurrent sync എന്നിവ ഇവിടെ നിന്ന് live test ചെയ്യാനാവില്ല.
- Google Apps Script snapshot sync ഒരു database transaction അല്ല; ഒരേസമയം പല ഫോണിൽ edit ചെയ്താൽ conflict/overwrite സാധ്യത നിലനിൽക്കും.
- എല്ലാ ERP workflows-ഉം production-grade ആയി പൂർത്തിയായിട്ടില്ല. ഉദാഹരണത്തിന് stock movement ledger, supplier payment ledger, purchase return, branch-specific staff access enforcement, audited P&L/GST, full multi-branch access isolation എന്നിവയ്ക്ക് തുടർ വികസനവും യഥാർത്ഥ ഡിവൈസ് പരിശോധനയും വേണം.
- പഴയ ഡാറ്റ സംരക്ഷിക്കാനായി destructive reset/migration ചേർത്തിട്ടില്ല. എന്നിരുന്നാലും HTML മാറ്റുന്നതിന് മുമ്പ് ആപ്പിൽ Settings → Backup → Download Backup ഉപയോഗിച്ച് JSON backup എടുക്കുക; പഴയ APK/HTML-യും സൂക്ഷിക്കുക.
- Cloud Connect സമയത്ത് നിലവിലുള്ള cloud data download ചെയ്യണോ local data upload ചെയ്യണോ എന്ന് ചോദിച്ചാൽ, ഇത് record-by-record merge അല്ല. Backup എടുത്ത് source of truth ഉറപ്പാക്കിയ ശേഷം മാത്രം തിരഞ്ഞെടുക്കുക.

APK build അല്ലെങ്കിൽ cloud sync വിജയിച്ചു എന്ന് ഈ ZIP മാത്രം കൊണ്ട് ഉറപ്പുനൽകുന്നില്ല.
