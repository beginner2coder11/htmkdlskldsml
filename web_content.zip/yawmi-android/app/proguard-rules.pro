# Add project specific ProGuard rules here.
# The WebView wrapper needs no extra keep rules for the release build.
