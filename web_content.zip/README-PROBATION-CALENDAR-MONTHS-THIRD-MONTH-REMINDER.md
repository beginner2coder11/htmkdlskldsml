# Probation calendar-month calculation and dashboard reminder

- Probation end date is calculated as three calendar months after the probation start date, preserving the same day number where possible (for example, 17 Aug -> 17 Nov). If the target month has fewer days, the end date is clamped to that month’s last day.
- The dashboard Probation reminder counter lists staff whose current date is on or after the two-calendar-month anniversary and on or before their probation end date. This means they enter the counter on the first day of their third probation month.
- The clickable report and dashboard list use the same third-month rule.
- Existing native/system probation notifications continue to use the configured lead time (14 days by default) before the end date; this is separate from the dashboard counter.
