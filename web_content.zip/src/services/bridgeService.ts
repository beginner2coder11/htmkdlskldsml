/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  serializeCommand,
  parseResponseLine,
  validateCommandPayload,
  CpuTelemetry,
  ServerConfig,
  DEFAULT_SERVER_CONFIG,
} from '../utils/protocol';
import { PacketLog, ConnectionMode } from '../types';

export class BridgeClient {
  private mode: ConnectionMode = 'simulator';
  private host: string = '127.0.0.1';
  private port: number = 8765;
  private serverConfig: ServerConfig = { ...DEFAULT_SERVER_CONFIG };
  private packetListeners: ((log: PacketLog) => void)[] = [];
  
  // Simulated PC State
  private pcClipboardText: string = 'Welcome to Link-to-Windows++! Local TLS PC Bridge.';
  private simulatedCoreCount: number = 8;
  private simulatedBaseFreq: number = 3600;
  private simulatedCoreLoads: number[] = [12.4, 25.1, 8.3, 44.0, 15.6, 18.2, 31.0, 9.5];

  constructor(host: string = '127.0.0.1', port: number = 8765, mode: ConnectionMode = 'simulator') {
    this.host = host;
    this.port = port;
    this.mode = mode;
  }

  public setMode(mode: ConnectionMode) {
    this.mode = mode;
  }

  public getMode(): ConnectionMode {
    return this.mode;
  }

  public setHostAndPort(host: string, port: number) {
    this.host = host;
    this.port = port;
  }

  public getEndpoint(): string {
    return `${this.host}:${this.port}`;
  }

  public setServerConfig(config: ServerConfig) {
    this.serverConfig = config;
  }

  public getServerConfig(): ServerConfig {
    return this.serverConfig;
  }

  public onPacket(listener: (log: PacketLog) => void) {
    this.packetListeners.push(listener);
    return () => {
      this.packetListeners = this.packetListeners.filter((l) => l !== listener);
    };
  }

  private emitPacket(log: PacketLog) {
    this.packetListeners.forEach((fn) => fn(log));
  }

  /**
   * Dispatches a command payload to either the live bridge or the built-in simulator
   */
  public async executeCommand(payload: Record<string, any>): Promise<{ success: boolean; data?: any; error?: string; latencyMs: number }> {
    const rawTx = serializeCommand(payload);
    const txLog: PacketLog = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      direction: 'tx',
      raw: rawTx,
      parsed: payload,
      byteSize: new Blob([rawTx]).size,
    };
    this.emitPacket(txLog);

    const startTime = performance.now();

    // Validation
    const validation = validateCommandPayload(payload.cmd || '', payload);
    if (!validation.valid) {
      const errResponse = { error: validation.reason };
      const latency = Math.round(performance.now() - startTime);
      const rxLog: PacketLog = {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        direction: 'rx',
        raw: JSON.stringify(errResponse) + '\n',
        parsed: errResponse,
        latencyMs: latency,
        byteSize: new Blob([JSON.stringify(errResponse)]).size,
        isError: true,
      };
      this.emitPacket(rxLog);
      return { success: false, error: validation.reason, latencyMs: latency };
    }

    if (this.mode === 'simulator') {
      // Simulate TLS handshake and round-trip delay (15 - 45 ms)
      const simulatedLatency = Math.floor(Math.random() * 20) + 15;
      await new Promise((resolve) => setTimeout(resolve, simulatedLatency));

      const simulatedResponse = this.handleSimulatedCommand(payload);
      const endTime = performance.now();
      const latencyMs = Math.round(endTime - startTime);

      const isError = Boolean(simulatedResponse.error);
      const rawRx = JSON.stringify(simulatedResponse) + '\n';

      const rxLog: PacketLog = {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        direction: 'rx',
        raw: rawRx,
        parsed: simulatedResponse,
        latencyMs,
        byteSize: new Blob([rawRx]).size,
        isError,
      };
      this.emitPacket(rxLog);

      return {
        success: !isError,
        data: simulatedResponse,
        error: simulatedResponse.error,
        latencyMs,
      };
    } else {
      // Direct mode: In web browser context, direct raw TCP/TLS socket to arbitrary port
      // requires WebSocket or WebTransport bridge. We attempt fetch fallback or guide user.
      try {
        const response = await fetch(`http://${this.host}:${this.port}/api/bridge`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const latencyMs = Math.round(performance.now() - startTime);
        const data = await response.json();
        const rawRx = JSON.stringify(data) + '\n';
        
        const rxLog: PacketLog = {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toLocaleTimeString(),
          direction: 'rx',
          raw: rawRx,
          parsed: data,
          latencyMs,
          byteSize: new Blob([rawRx]).size,
          isError: !response.ok || Boolean(data.error),
        };
        this.emitPacket(rxLog);

        return {
          success: response.ok && !data.error,
          data,
          error: data.error,
          latencyMs,
        };
      } catch (err: any) {
        const latencyMs = Math.round(performance.now() - startTime);
        const errObj = {
          error: `TLS Socket connection to ${this.host}:${this.port} failed. Note: Browsers restrict raw TCP/TLS connections without a bridge proxy. Switch to Simulator Mode or use the Python/Kotlin/Swift client for direct TLS connections. Details: ${err.message}`,
        };
        const rxLog: PacketLog = {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toLocaleTimeString(),
          direction: 'rx',
          raw: JSON.stringify(errObj) + '\n',
          parsed: errObj,
          latencyMs,
          byteSize: new Blob([JSON.stringify(errObj)]).size,
          isError: true,
        };
        this.emitPacket(rxLog);
        return { success: false, error: errObj.error, latencyMs };
      }
    }
  }

  /**
   * Faithful simulation of server.py's execute_command handler
   */
  private handleSimulatedCommand(cmd: Record<string, any>): Record<string, any> {
    const cmdName = cmd.cmd;

    if (cmdName === 'OPEN_APP') {
      const target = cmd.target || '';
      if (!target) {
        return { error: 'missing target' };
      }

      // Check whitelist if enabled
      if (this.serverConfig.allowAppWhitelist) {
        const targetBase = target.split(/[\\/]/).pop().toLowerCase();
        const allowedNormalized = this.serverConfig.allowedApps.map((a) => a.toLowerCase());
        const isAllowed = allowedNormalized.includes(targetBase) || allowedNormalized.includes(target.toLowerCase());

        if (!isAllowed) {
          return { error: `target '${target}' is not in allowed whitelist` };
        }
      }

      return {
        status: 'launched',
        target,
        timestamp: new Date().toISOString(),
      };
    }

    if (cmdName === 'GET_CPU') {
      // Jitter per-core loads realistically
      this.simulatedCoreLoads = this.simulatedCoreLoads.map((load) => {
        const delta = (Math.random() - 0.48) * 12;
        return Math.max(3.0, Math.min(98.5, Math.round((load + delta) * 10) / 10));
      });

      const total = Math.round(
        (this.simulatedCoreLoads.reduce((a, b) => a + b, 0) / this.simulatedCoreCount) * 10
      ) / 10;

      return {
        status: 'ok',
        total,
        per_core: this.simulatedCoreLoads,
        max_mhz: 4800,
        min_mhz: 800,
        timestamp: Date.now(),
      };
    }

    if (cmdName === 'COPY') {
      const text = cmd.text ?? '';
      this.pcClipboardText = String(text);
      return {
        status: 'copied',
        text_len: this.pcClipboardText.length,
      };
    }

    if (cmdName === 'PASTE') {
      return {
        status: 'paste_ok',
        text: this.pcClipboardText,
      };
    }

    if (cmdName === 'PING') {
      return {
        status: 'pong',
        service: 'Link-to-Windows++',
        version: '2.4.0',
        platform: 'Windows 11 / Linux TLS Host',
      };
    }

    return { error: `unknown command: ${cmdName}` };
  }

  // Quick action helpers
  public async getCpu(): Promise<{ success: boolean; data?: CpuTelemetry; error?: string; latencyMs: number }> {
    return this.executeCommand({ cmd: 'GET_CPU' });
  }

  public async openApp(target: string) {
    return this.executeCommand({ cmd: 'OPEN_APP', target });
  }

  public async copyText(text: string) {
    return this.executeCommand({ cmd: 'COPY', text });
  }

  public async pasteText() {
    return this.executeCommand({ cmd: 'PASTE' });
  }

  public async ping() {
    return this.executeCommand({ cmd: 'PING' });
  }
}

// Global singleton instance
export const bridgeClient = new BridgeClient();
