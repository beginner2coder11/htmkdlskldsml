export const WORLD_W = 1280;
export const WORLD_H = 720;
export const CELL = 64;
export const COLS = 20;
export const ROWS = 11;
export const PATH_BLOCK = 50;
export const BASE_BLOCK = 108;
export const START_GOLD = 150;
export const START_LIVES = 20;
export const WAVE_COUNT = 12;
export const BEST_KEY = "donnys-arschwehr-v1";

export type Pt = { x: number; y: number };

export type TowerKind = "schnell" | "scharf" | "saeure" | "kleber";
export type EnemyKind = "wurm" | "raser" | "panzer" | "boss";
export type AimMode = "first" | "last" | "strong" | "near";

export type TowerDef = {
  kind: TowerKind;
  name: string;
  short: string;
  blurb: string;
  cost: number;
  range: number;
  damage: number;
  rate: number;
  shotSpeed: number;
  splash: number;
  slow: number;
  slowDur: number;
};

export type EnemyDef = {
  kind: EnemyKind;
  hp: number;
  speed: number;
  gold: number;
  leak: number;
  scale: number;
  armor: number;
};

export type WaveGroup = { type: EnemyKind; count: number; interval: number };
export type Wave = { groups: WaveGroup[] };

export const TOWERS: Record<TowerKind, TowerDef> = {
  schnell: {
    kind: "schnell",
    name: "Spritzpistole",
    short: "Spritzer",
    blurb: "Billig und schnell. Kurze Reichweite.",
    cost: 55,
    range: 148,
    damage: 7,
    rate: 4.4,
    shotSpeed: 540,
    splash: 0,
    slow: 0,
    slowDur: 0,
  },
  scharf: {
    kind: "scharf",
    name: "Scharfschütze",
    short: "Scharf",
    blurb: "Lange Reichweite, harte Schüsse, langsames Tempo.",
    cost: 150,
    range: 290,
    damage: 48,
    rate: 0.72,
    shotSpeed: 980,
    splash: 0,
    slow: 0,
    slowDur: 0,
  },
  saeure: {
    kind: "saeure",
    name: "Säurefass",
    short: "Säure",
    blurb: "Spritzer in der Fläche. Ignoriert Panzerung.",
    cost: 105,
    range: 168,
    damage: 15,
    rate: 1.15,
    shotSpeed: 300,
    splash: 72,
    slow: 0,
    slowDur: 0,
  },
  kleber: {
    kind: "kleber",
    name: "Kleberkanone",
    short: "Kleber",
    blurb: "Bremst Würmer stark. Wenig Schaden.",
    cost: 80,
    range: 158,
    damage: 4,
    rate: 1.7,
    shotSpeed: 340,
    splash: 0,
    slow: 0.42,
    slowDur: 2.3,
  },
};

export const TOWER_ORDER: TowerKind[] = ["schnell", "kleber", "saeure", "scharf"];

export const ENEMIES: Record<EnemyKind, EnemyDef> = {
  wurm: { kind: "wurm", hp: 36, speed: 76, gold: 5, leak: 1, scale: 1, armor: 0 },
  raser: { kind: "raser", hp: 26, speed: 132, gold: 7, leak: 1, scale: 0.82, armor: 0 },
  panzer: { kind: "panzer", hp: 120, speed: 50, gold: 14, leak: 2, scale: 1.18, armor: 0.4 },
  boss: { kind: "boss", hp: 980, speed: 40, gold: 90, leak: 5, scale: 1.72, armor: 0.15 },
};

const DMG_TABLE = [60, 105, 170];
const RATE_TABLE = [50, 90, 145];

export function upgradeCost(baseCost: number, rank: number, stat: "dmg" | "rate"): number | null {
  if (rank >= 3) return null;
  const table = stat === "dmg" ? DMG_TABLE : RATE_TABLE;
  return Math.round(table[rank] * (0.72 + baseCost / 210));
}

export function scaledDamage(def: TowerDef, rank: number): number {
  return Math.round(def.damage * (1 + rank * 0.45));
}

export function scaledRate(def: TowerDef, rank: number): number {
  return Math.round(def.rate * (1 + rank * 0.28) * 100) / 100;
}

export const WAVES: Wave[] = [
  { groups: [{ type: "wurm", count: 8, interval: 0.82 }] },
  { groups: [{ type: "wurm", count: 12, interval: 0.55 }] },
  {
    groups: [
      { type: "wurm", count: 7, interval: 0.5 },
      { type: "raser", count: 6, interval: 0.4 },
    ],
  },
  {
    groups: [
      { type: "raser", count: 10, interval: 0.36 },
      { type: "wurm", count: 8, interval: 0.4 },
    ],
  },
  {
    groups: [
      { type: "panzer", count: 3, interval: 1.25 },
      { type: "wurm", count: 10, interval: 0.42 },
    ],
  },
  {
    groups: [
      { type: "wurm", count: 10, interval: 0.34 },
      { type: "raser", count: 10, interval: 0.3 },
    ],
  },
  {
    groups: [
      { type: "panzer", count: 5, interval: 0.95 },
      { type: "raser", count: 8, interval: 0.32 },
    ],
  },
  {
    groups: [
      { type: "wurm", count: 14, interval: 0.28 },
      { type: "panzer", count: 4, interval: 0.85 },
    ],
  },
  {
    groups: [
      { type: "raser", count: 14, interval: 0.24 },
      { type: "panzer", count: 5, interval: 0.8 },
    ],
  },
  {
    groups: [
      { type: "panzer", count: 7, interval: 0.7 },
      { type: "raser", count: 10, interval: 0.26 },
    ],
  },
  {
    groups: [
      { type: "wurm", count: 12, interval: 0.22 },
      { type: "raser", count: 12, interval: 0.22 },
      { type: "panzer", count: 6, interval: 0.65 },
    ],
  },
  {
    groups: [
      { type: "boss", count: 1, interval: 0.4 },
      { type: "panzer", count: 4, interval: 0.85 },
      { type: "raser", count: 8, interval: 0.28 },
    ],
  },
];

export function enemyName(kind: EnemyKind, count: number): string {
  if (kind === "wurm") return count === 1 ? "Wurm" : "Würmer";
  if (kind === "raser") return count === 1 ? "Raser" : "Raser";
  if (kind === "panzer") return count === 1 ? "Panzerwurm" : "Panzerwürmer";
  return count === 1 ? "Königswurm" : "Königswürmer";
}

export function describeWave(index: number): string {
  const wave = WAVES[index];
  if (!wave) return "";
  return wave.groups.map((g) => `${g.count} ${enemyName(g.type, g.count)}`).join(" · ");
}

export function waveHpScale(waveIndex: number): number {
  return 1 + waveIndex * 0.16;
}

export const WAYPOINTS: Pt[] = [
  { x: 28, y: 100 },
  { x: 400, y: 100 },
  { x: 400, y: 292 },
  { x: 848, y: 292 },
  { x: 848, y: 100 },
  { x: 1200, y: 100 },
  { x: 1200, y: 420 },
  { x: 512, y: 420 },
  { x: 160, y: 420 },
  { x: 160, y: 612 },
  { x: 960, y: 612 },
  { x: 1144, y: 588 },
];

export const BASE: Pt = WAYPOINTS[WAYPOINTS.length - 1];

export type Track = { samples: Pt[]; cum: number[]; length: number };

export function buildTrack(points: Pt[]): Track {
  const samples: Pt[] = [{ x: points[0].x, y: points[0].y }];
  const cum: number[] = [0];
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    const n = Math.max(1, Math.round(len / 6));
    for (let s = 1; s <= n; s++) {
      const t = s / n;
      const p = { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
      const prev = samples[samples.length - 1];
      samples.push(p);
      cum.push(cum[cum.length - 1] + Math.hypot(p.x - prev.x, p.y - prev.y));
    }
  }
  return { samples, cum, length: cum[cum.length - 1] };
}

export function pointAt(track: Track, dist: number): { x: number; y: number; ang: number } {
  const d = Math.max(0, Math.min(track.length, dist));
  let lo = 0;
  let hi = track.cum.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (track.cum[mid] < d) lo = mid + 1;
    else hi = mid;
  }
  const i = Math.max(1, lo);
  const span = track.cum[i] - track.cum[i - 1] || 1;
  const t = (d - track.cum[i - 1]) / span;
  const a = track.samples[i - 1];
  const b = track.samples[i];
  return {
    x: a.x + (b.x - a.x) * t,
    y: a.y + (b.y - a.y) * t,
    ang: Math.atan2(b.y - a.y, b.x - a.x),
  };
}

export function distToPath(x: number, y: number, pts: Pt[]): number {
  let best = Infinity;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const l2 = dx * dx + dy * dy || 1;
    let t = ((x - a.x) * dx + (y - a.y) * dy) / l2;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;
    const px = a.x + dx * t;
    const py = a.y + dy * t;
    const dd = (x - px) * (x - px) + (y - py) * (y - py);
    if (dd < best) best = dd;
  }
  return Math.sqrt(best);
}

export function cellOf(x: number, y: number): { c: number; r: number } | null {
  const c = Math.floor(x / CELL);
  const r = Math.floor(y / CELL);
  if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return null;
  return { c, r };
}

export function cellCenter(c: number, r: number): Pt {
  return { x: c * CELL + CELL / 2, y: r * CELL + CELL / 2 };
}

export function makeBlocked(): boolean[][] {
  const grid: boolean[][] = [];
  for (let r = 0; r < ROWS; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < COLS; c++) {
      const p = cellCenter(c, r);
      const onPath = distToPath(p.x, p.y, WAYPOINTS) < PATH_BLOCK;
      const onBase = Math.hypot(p.x - BASE.x, p.y - BASE.y) < BASE_BLOCK;
      row.push(onPath || onBase);
    }
    grid.push(row);
  }
  return grid;
}

export const TRACK = buildTrack(WAYPOINTS);
export const BLOCKED = makeBlocked();
