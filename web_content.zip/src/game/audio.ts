import type { TowerKind } from "@/game/data";

type AudioCtor = typeof AudioContext;

function audioCtor(): AudioCtor | null {
  if (typeof window === "undefined") return null;
  if (window.AudioContext) return window.AudioContext;
  const legacy = window as unknown as { webkitAudioContext?: AudioCtor };
  return legacy.webkitAudioContext ?? null;
}

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  muted = false;

  unlock() {
    const Ctor = audioCtor();
    if (!Ctor) return;
    if (!this.ctx) {
      this.ctx = new Ctor({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.18;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(muted ? 0 : 0.18, this.ctx.currentTime, 0.02);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(amp);
    amp.connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      amp.disconnect();
    };
  }

  place() {
    this.tone(180, 0.09, "triangle", 0.16, -60);
  }

  shoot(kind: TowerKind) {
    if (kind === "scharf") this.tone(720, 0.07, "square", 0.05, -400);
    else if (kind === "saeure") this.tone(220, 0.12, "sawtooth", 0.04, -80);
    else if (kind === "kleber") this.tone(160, 0.1, "triangle", 0.06, -40);
    else this.tone(480 + Math.random() * 80, 0.04, "square", 0.035, -120);
  }

  hit() {
    this.tone(320 + Math.random() * 40, 0.04, "square", 0.03, -80);
  }

  kill() {
    this.tone(660, 0.08, "triangle", 0.07, 180);
  }

  leak() {
    this.tone(110, 0.22, "sawtooth", 0.08, -50);
  }

  wave() {
    this.tone(240, 0.12, "triangle", 0.07, 80);
    this.tone(360, 0.16, "triangle", 0.05, 40);
  }

  win() {
    this.tone(523, 0.12, "triangle", 0.08);
    this.tone(659, 0.14, "triangle", 0.07);
    this.tone(784, 0.2, "triangle", 0.08);
  }

  lose() {
    this.tone(200, 0.2, "sawtooth", 0.07, -80);
    this.tone(140, 0.28, "triangle", 0.06, -40);
  }
}
