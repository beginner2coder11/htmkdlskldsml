import { Sfx } from "@/game/audio";
import {
  BASE,
  BEST_KEY,
  BLOCKED,
  CELL,
  COLS,
  ENEMIES,
  ROWS,
  START_GOLD,
  START_LIVES,
  TOWERS,
  TRACK,
  WAVE_COUNT,
  WAVES,
  WAYPOINTS,
  WORLD_H,
  WORLD_W,
  cellCenter,
  cellOf,
  describeWave,
  pointAt,
  scaledDamage,
  scaledRate,
  upgradeCost,
  waveHpScale,
  type AimMode,
  type EnemyKind,
  type TowerKind,
} from "@/game/data";

export type SelectedTower = {
  id: number;
  kind: TowerKind;
  name: string;
  dmgRank: number;
  rateRank: number;
  damage: number;
  rate: number;
  nextDamage: number | null;
  nextRate: number | null;
  dmgCost: number | null;
  rateCost: number | null;
  sell: number;
  aim: AimMode;
};

export type Hud = {
  phase: "menu" | "playing" | "over" | "win";
  lives: number;
  gold: number;
  wave: number;
  wavesTotal: number;
  enemiesLeft: number;
  canStart: boolean;
  preview: string;
  speed: 1 | 2;
  muted: boolean;
  armed: TowerKind | null;
  selected: SelectedTower | null;
  hint: string;
  bestWave: number;
};

type Tower = {
  id: number;
  kind: TowerKind;
  c: number;
  r: number;
  x: number;
  y: number;
  dmgRank: number;
  rateRank: number;
  spent: number;
  cool: number;
  aim: AimMode;
  facing: number;
  kick: number;
};

type Enemy = {
  id: number;
  kind: EnemyKind;
  dist: number;
  hp: number;
  maxHp: number;
  slowT: number;
  flash: number;
  x: number;
  y: number;
  ang: number;
};

type Shot = {
  x: number;
  y: number;
  tx: number;
  ty: number;
  target: number;
  speed: number;
  dmg: number;
  kind: TowerKind;
  splash: number;
  slow: number;
  slowDur: number;
  life: number;
};

type Particle = { x: number; y: number; vx: number; vy: number; life: number; max: number; color: string; r: number };
type Floater = { x: number; y: number; text: string; life: number; color: string };
type Spawn = { at: number; kind: EnemyKind; hp: number };

const STEP = 1 / 60;
const SHOT_COLORS: Record<TowerKind, string> = {
  schnell: "#f0c14a",
  scharf: "#fff4c8",
  saeure: "#9be05a",
  kleber: "#ff8fb8",
};

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(img);
    img.src = src;
  });
}

function readBest(): number {
  if (typeof window === "undefined") return 0;
  const n = Number(window.localStorage.getItem(BEST_KEY) || 0);
  return Number.isFinite(n) ? n : 0;
}

export class Game {
  private ctx: CanvasRenderingContext2D;
  private sfx = new Sfx();
  private raf = 0;
  private last = 0;
  private acc = 0;
  private time = 0;
  private ro: ResizeObserver | null = null;
  private reduced = false;

  private phase: Hud["phase"] = "menu";
  private lives = START_LIVES;
  private gold = START_GOLD;
  private wave = 0;
  private speed: 1 | 2 = 1;
  private armed: TowerKind | null = null;
  private selectedId: number | null = null;
  private hint = "Bandwürmer wollen zu Donny. Stell dich ihnen in den Weg.";
  private hintUntil = 0;
  private bestWave = 0;
  private spawning = false;
  private spawnQueue: Spawn[] = [];
  private spawnClock = 0;
  private nextId = 1;

  private towers: Tower[] = [];
  private enemies: Enemy[] = [];
  private shots: Shot[] = [];
  private particles: Particle[] = [];
  private floaters: Floater[] = [];
  private shake = 0;
  private hurt = 0;
  private hover: { c: number; r: number } | null = null;

  private floor: HTMLImageElement | null = null;
  private donny: HTMLImageElement | null = null;
  private worms: HTMLImageElement[] = [];
  private towerArt: Partial<Record<TowerKind, HTMLImageElement>> = {};
  private path = new Path2D();

  private onPointerDown: (e: PointerEvent) => void;
  private onPointerMove: (e: PointerEvent) => void;
  private onPointerLeave: () => void;
  private onKey: (e: KeyboardEvent) => void;
  private onVis: () => void;

  constructor(
    private canvas: HTMLCanvasElement,
    private onHud: (hud: Hud) => void,
  ) {
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas fehlt");
    this.ctx = ctx;
    this.bestWave = readBest();
    this.path.moveTo(WAYPOINTS[0].x, WAYPOINTS[0].y);
    for (let i = 1; i < WAYPOINTS.length; i++) this.path.lineTo(WAYPOINTS[i].x, WAYPOINTS[i].y);
    this.reduced =
      typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    this.onPointerDown = (e) => this.pointerDown(e);
    this.onPointerMove = (e) => this.pointerMove(e);
    this.onPointerLeave = () => {
      this.hover = null;
    };
    this.onKey = (e) => this.key(e);
    this.onVis = () => {
      if (document.visibilityState === "visible") this.sfx.resume();
    };
    void this.loadArt();
  }

  start() {
    this.resize();
    const parent = this.canvas.parentElement;
    if (parent && typeof ResizeObserver !== "undefined") {
      this.ro = new ResizeObserver(() => this.resize());
      this.ro.observe(parent);
    }
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerleave", this.onPointerLeave);
    window.addEventListener("keydown", this.onKey);
    document.addEventListener("visibilitychange", this.onVis);
    this.publish();
    this.raf = requestAnimationFrame(this.frame);
  }

  stop() {
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerleave", this.onPointerLeave);
    window.removeEventListener("keydown", this.onKey);
    document.removeEventListener("visibilitychange", this.onVis);
  }

  begin() {
    this.sfx.unlock();
    this.resetMatch();
    this.phase = "playing";
    this.say("Wähle einen Turm und tippe ein freies Feld neben dem Schleim.");
    this.publish();
  }

  restart() {
    this.sfx.unlock();
    this.resetMatch();
    this.phase = "playing";
    this.hint = "Neue Runde. Der Weg ist wieder frei.";
    this.publish();
  }

  arm(kind: TowerKind) {
    if (this.phase !== "playing") return;
    this.sfx.unlock();
    this.armed = this.armed === kind ? null : kind;
    this.selectedId = null;
    if (this.armed) this.say(`${TOWERS[this.armed].name}: ${TOWERS[this.armed].blurb}`);
    else this.hint = "Turm abgewählt.";
    this.publish();
  }

  startWave() {
    if (!this.canStart()) return;
    this.sfx.unlock();
    const index = this.wave;
    const spec = WAVES[index];
    let at = 0.15;
    const scale = waveHpScale(index);
    for (const group of spec.groups) {
      const base = ENEMIES[group.type];
      for (let i = 0; i < group.count; i++) {
        this.spawnQueue.push({
          at,
          kind: group.type,
          hp: Math.round(base.hp * scale),
        });
        at += group.interval;
      }
      at += 0.7;
    }
    this.spawnClock = 0;
    this.spawning = true;
    this.wave = index + 1;
    this.sfx.wave();
    this.say(`Welle ${this.wave}: ${describeWave(index)}`);
    this.publish();
  }

  toggleSpeed() {
    if (this.phase !== "playing") return;
    this.speed = this.speed === 1 ? 2 : 1;
    this.publish();
  }

  toggleMute() {
    this.sfx.unlock();
    this.sfx.setMuted(!this.sfx.muted);
    this.publish();
  }

  upgrade(stat: "dmg" | "rate") {
    const tower = this.selectedTower();
    if (!tower || this.phase !== "playing") return;
    const rank = stat === "dmg" ? tower.dmgRank : tower.rateRank;
    const cost = upgradeCost(TOWERS[tower.kind].cost, rank, stat);
    if (cost == null) return;
    if (this.gold < cost) {
      this.say("Zu wenig Gold für die Verbesserung.");
      return;
    }
    this.gold -= cost;
    tower.spent += cost;
    if (stat === "dmg") tower.dmgRank += 1;
    else tower.rateRank += 1;
    this.sfx.place();
    this.say(stat === "dmg" ? "Schaden verbessert." : "Feuerrate verbessert.");
    this.publish();
  }

  sell() {
    const tower = this.selectedTower();
    if (!tower || this.phase !== "playing") return;
    const refund = Math.round(tower.spent * 0.6);
    this.gold += refund;
    this.towers = this.towers.filter((t) => t.id !== tower.id);
    this.selectedId = null;
    this.float(`+${refund}`, tower.x, tower.y - 20, "#f0b429");
    this.sfx.kill();
    this.say(`Verkauft. +${refund} Gold.`);
    this.publish();
  }

  setAim(mode: AimMode) {
    const tower = this.selectedTower();
    if (!tower) return;
    tower.aim = mode;
    this.publish();
  }

  private resetMatch() {
    this.lives = START_LIVES;
    this.gold = START_GOLD;
    this.wave = 0;
    this.speed = 1;
    this.armed = null;
    this.selectedId = null;
    this.spawning = false;
    this.spawnQueue = [];
    this.spawnClock = 0;
    this.towers = [];
    this.enemies = [];
    this.shots = [];
    this.particles = [];
    this.floaters = [];
    this.shake = 0;
    this.hurt = 0;
    this.time = 0;
    this.acc = 0;
  }

  private canStart() {
    return this.phase === "playing" && !this.spawning && this.enemies.length === 0 && this.wave < WAVE_COUNT;
  }

  private selectedTower(): Tower | null {
    return this.towers.find((t) => t.id === this.selectedId) ?? null;
  }

  private say(text: string) {
    this.hint = text;
    this.hintUntil = this.time + 2.4;
  }

  private publish() {
    const selected = this.selectedTower();
    let selectedHud: SelectedTower | null = null;
    if (selected) {
      const def = TOWERS[selected.kind];
      const dmgCost = upgradeCost(def.cost, selected.dmgRank, "dmg");
      const rateCost = upgradeCost(def.cost, selected.rateRank, "rate");
      selectedHud = {
        id: selected.id,
        kind: selected.kind,
        name: def.name,
        dmgRank: selected.dmgRank,
        rateRank: selected.rateRank,
        damage: scaledDamage(def, selected.dmgRank),
        rate: scaledRate(def, selected.rateRank),
        nextDamage: selected.dmgRank < 3 ? scaledDamage(def, selected.dmgRank + 1) : null,
        nextRate: selected.rateRank < 3 ? scaledRate(def, selected.rateRank + 1) : null,
        dmgCost,
        rateCost,
        sell: Math.round(selected.spent * 0.6),
        aim: selected.aim,
      };
    }
    const next = this.canStart() ? this.wave : -1;
    this.onHud({
      phase: this.phase,
      lives: this.lives,
      gold: this.gold,
      wave: this.wave,
      wavesTotal: WAVE_COUNT,
      enemiesLeft: this.enemies.length + this.spawnQueue.length,
      canStart: this.canStart(),
      preview: next >= 0 ? describeWave(next) : "",
      speed: this.speed,
      muted: this.sfx.muted,
      armed: this.armed,
      selected: selectedHud,
      hint: this.hint,
      bestWave: this.bestWave,
    });
  }

  private rememberBest() {
    const reached = this.wave;
    if (reached > this.bestWave) {
      this.bestWave = reached;
      try {
        window.localStorage.setItem(BEST_KEY, String(reached));
      } catch {
        /* ignore quota */
      }
    }
  }

  private frame = (stamp: number) => {
    const raw = this.last ? Math.min(0.1, (stamp - this.last) / 1000) : 0;
    this.last = stamp;
    if (this.phase === "playing") {
      this.acc += raw * this.speed;
      let guard = 0;
      while (this.acc >= STEP && guard++ < 10) {
        this.step(STEP);
        this.acc -= STEP;
      }
    }
    this.render(stamp / 1000);
    this.raf = requestAnimationFrame(this.frame);
  };

  private step(dt: number) {
    this.time += dt;
    if (this.hintUntil && this.time > this.hintUntil) {
      this.hintUntil = 0;
      this.hint = this.defaultHint();
      this.publish();
    }

    if (this.spawning) {
      this.spawnClock += dt;
      while (this.spawnQueue.length && this.spawnQueue[0].at <= this.spawnClock) {
        const job = this.spawnQueue.shift()!;
        this.spawnEnemy(job.kind, job.hp);
      }
      if (!this.spawnQueue.length) this.spawning = false;
    }

    for (const enemy of this.enemies) {
      const def = ENEMIES[enemy.kind];
      if (enemy.slowT > 0) enemy.slowT = Math.max(0, enemy.slowT - dt);
      const mult = enemy.slowT > 0 ? 0.42 : 1;
      enemy.dist += def.speed * mult * dt;
      enemy.flash = Math.max(0, enemy.flash - dt);
      const pose = pointAt(TRACK, enemy.dist);
      enemy.x = pose.x;
      enemy.y = pose.y;
      enemy.ang = pose.ang;
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (enemy.dist >= TRACK.length - 4) {
        this.enemies.splice(i, 1);
        this.leak(enemy);
      }
    }

    for (const tower of this.towers) {
      tower.cool = Math.max(0, tower.cool - dt);
      tower.kick = Math.max(0, tower.kick - dt * 4);
      const target = this.pickTarget(tower);
      if (target) {
        tower.facing = Math.atan2(target.y - tower.y, target.x - tower.x);
        if (tower.cool <= 0) this.fire(tower, target);
      }
    }

    for (let i = this.shots.length - 1; i >= 0; i--) {
      const shot = this.shots[i];
      const target = this.enemies.find((e) => e.id === shot.target);
      if (target) {
        shot.tx = target.x;
        shot.ty = target.y;
      }
      const dx = shot.tx - shot.x;
      const dy = shot.ty - shot.y;
      const dist = Math.hypot(dx, dy) || 1;
      const step = shot.speed * dt;
      if (dist <= Math.max(16, step)) {
        this.impact(shot);
        this.shots.splice(i, 1);
        continue;
      }
      shot.x += (dx / dist) * step;
      shot.y += (dy / dist) * step;
      shot.life -= dt;
      if (shot.life <= 0) this.shots.splice(i, 1);
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 30 * dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.life -= dt;
      f.y -= 22 * dt;
      if (f.life <= 0) this.floaters.splice(i, 1);
    }

    if (this.phase === "playing" && !this.spawning && this.spawnQueue.length === 0 && this.enemies.length === 0 && this.wave > 0) {
      if (this.wave >= WAVE_COUNT) this.finish(true);
    }
  }

  private defaultHint() {
    if (this.phase !== "playing") return this.hint;
    if (this.armed) return `${TOWERS[this.armed].name}: Tippe ein freies Feld.`;
    if (this.canStart()) return this.wave === 0 ? "Baue zuerst, dann starte Welle 1." : "Weg ist frei. Nächste Welle, wenn du soweit bist.";
    return "Halte den Schleimweg.";
  }

  private spawnEnemy(kind: EnemyKind, hp: number) {
    const pose = pointAt(TRACK, 0);
    this.enemies.push({
      id: this.nextId++,
      kind,
      dist: 0,
      hp,
      maxHp: hp,
      slowT: 0,
      flash: 0,
      x: pose.x,
      y: pose.y,
      ang: pose.ang,
    });
  }

  private leak(enemy: Enemy) {
    const loss = ENEMIES[enemy.kind].leak;
    this.lives = Math.max(0, this.lives - loss);
    this.shake = enemy.kind === "boss" ? 16 : 9;
    this.hurt = 0.35;
    this.sfx.leak();
    this.say(loss > 1 ? `Durchbruch! −${loss} Leben.` : "Ein Wurm ist durch.");
    this.publish();
    if (this.lives <= 0) this.finish(false);
  }

  private finish(win: boolean) {
    if (this.phase !== "playing") return;
    this.phase = win ? "win" : "over";
    this.spawning = false;
    this.spawnQueue = [];
    this.rememberBest();
    if (win) this.sfx.win();
    else this.sfx.lose();
    this.hint = win ? "Donny bleibt unangetastet." : "Die Würmer sind angekommen.";
    this.publish();
  }

  private pickTarget(tower: Tower): Enemy | null {
    const range = TOWERS[tower.kind].range;
    const r2 = range * range;
    let best: Enemy | null = null;
    let bestScore = 0;
    for (const enemy of this.enemies) {
      const dx = enemy.x - tower.x;
      const dy = enemy.y - tower.y;
      const d2 = dx * dx + dy * dy;
      if (d2 > r2) continue;
      let score = 0;
      if (tower.aim === "first") score = enemy.dist;
      else if (tower.aim === "last") score = -enemy.dist;
      else if (tower.aim === "strong") score = enemy.hp;
      else score = -d2;
      if (!best || score > bestScore) {
        best = enemy;
        bestScore = score;
      }
    }
    return best;
  }

  private fire(tower: Tower, target: Enemy) {
    const def = TOWERS[tower.kind];
    tower.cool = 1 / scaledRate(def, tower.rateRank);
    tower.kick = 1;
    const dmg = scaledDamage(def, tower.dmgRank);
    this.shots.push({
      x: tower.x,
      y: tower.y,
      tx: target.x,
      ty: target.y,
      target: target.id,
      speed: def.shotSpeed,
      dmg,
      kind: tower.kind,
      splash: def.splash,
      slow: def.slow,
      slowDur: def.slowDur,
      life: 1.6,
    });
    this.sfx.shoot(tower.kind);
  }

  private impact(shot: Shot) {
    const hit = (enemy: Enemy, dmg: number) => {
      const def = ENEMIES[enemy.kind];
      const armor = shot.kind === "saeure" ? 0 : def.armor;
      const dealt = Math.max(1, Math.round(dmg * (1 - armor)));
      enemy.hp -= dealt;
      enemy.flash = 0.08;
      if (shot.slow > 0) enemy.slowT = Math.max(enemy.slowT, shot.slowDur);
      return enemy.hp <= 0;
    };

    if (shot.splash > 0) {
      const r2 = shot.splash * shot.splash;
      for (let i = this.enemies.length - 1; i >= 0; i--) {
        const enemy = this.enemies[i];
        const dx = enemy.x - shot.x;
        const dy = enemy.y - shot.y;
        if (dx * dx + dy * dy > r2) continue;
        if (hit(enemy, shot.dmg)) this.killEnemy(i);
      }
    } else {
      let idx = this.enemies.findIndex((e) => e.id === shot.target);
      if (idx < 0) {
        let best = Infinity;
        for (let i = 0; i < this.enemies.length; i++) {
          const enemy = this.enemies[i];
          const d = (enemy.x - shot.x) ** 2 + (enemy.y - shot.y) ** 2;
          if (d < best && d < 28 * 28) {
            best = d;
            idx = i;
          }
        }
      }
      if (idx >= 0 && hit(this.enemies[idx], shot.dmg)) this.killEnemy(idx);
    }

    this.burst(shot.x, shot.y, SHOT_COLORS[shot.kind], shot.splash > 0 ? 10 : 5);
    this.sfx.hit();
  }

  private killEnemy(index: number) {
    const enemy = this.enemies[index];
    if (!enemy) return;
    const gold = ENEMIES[enemy.kind].gold;
    this.gold += gold;
    this.float(`+${gold}`, enemy.x, enemy.y - 16, "#f0b429");
    this.burst(enemy.x, enemy.y, "#f4e2cf", 12);
    this.enemies.splice(index, 1);
    this.sfx.kill();
    this.publish();
  }

  private burst(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 30 + Math.random() * 90;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.28 + Math.random() * 0.2,
        max: 0.45,
        color,
        r: 2 + Math.random() * 2.5,
      });
    }
  }

  private float(text: string, x: number, y: number, color: string) {
    this.floaters.push({ x, y, text, life: 0.8, color });
  }

  private pointerDown(e: PointerEvent) {
    if (this.phase !== "playing") return;
    this.sfx.unlock();
    const p = this.worldPoint(e);
    if (!p) return;
    const hit = this.towerAt(p.x, p.y);
    if (hit) {
      this.selectedId = hit.id;
      this.armed = null;
      this.say(`${TOWERS[hit.kind].name} gewählt.`);
      this.publish();
      return;
    }
    if (!this.armed) {
      this.selectedId = null;
      this.publish();
      return;
    }
    const cell = cellOf(p.x, p.y);
    if (!cell) {
      this.say("Daneben.");
      this.publish();
      return;
    }
    if (BLOCKED[cell.r][cell.c]) {
      this.say("Nicht auf dem Schleimweg und nicht auf Donny.");
      this.publish();
      return;
    }
    if (this.towers.some((t) => t.c === cell.c && t.r === cell.r)) {
      this.say("Hier steht schon ein Turm.");
      this.publish();
      return;
    }
    const def = TOWERS[this.armed];
    if (this.gold < def.cost) {
      this.say("Zu wenig Gold.");
      this.publish();
      return;
    }
    const center = cellCenter(cell.c, cell.r);
    this.gold -= def.cost;
    this.towers.push({
      id: this.nextId++,
      kind: this.armed,
      c: cell.c,
      r: cell.r,
      x: center.x,
      y: center.y,
      dmgRank: 0,
      rateRank: 0,
      spent: def.cost,
      cool: 0.15,
      aim: "first",
      facing: -Math.PI / 2,
      kick: 0,
    });
    this.sfx.place();
    this.say(`${def.name} steht. Noch ${this.gold} Gold.`);
    this.publish();
  }

  private pointerMove(e: PointerEvent) {
    const p = this.worldPoint(e);
    this.hover = p ? cellOf(p.x, p.y) : null;
  }

  private key(e: KeyboardEvent) {
    if (e.repeat) return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
    if (e.key === " " || e.key === "Enter") {
      if (this.phase === "menu") this.begin();
      else if (this.canStart()) this.startWave();
      e.preventDefault();
    } else if (e.key === "1") this.arm("schnell");
    else if (e.key === "2") this.arm("kleber");
    else if (e.key === "3") this.arm("saeure");
    else if (e.key === "4") this.arm("scharf");
    else if (e.key === "Escape") {
      this.armed = null;
      this.selectedId = null;
      this.publish();
    } else if (e.key === "f" || e.key === "F") this.toggleSpeed();
  }

  private towerAt(x: number, y: number): Tower | null {
    let best: Tower | null = null;
    let bestD = 28 * 28;
    for (const tower of this.towers) {
      const d = (tower.x - x) ** 2 + (tower.y - y) ** 2;
      if (d <= bestD) {
        best = tower;
        bestD = d;
      }
    }
    return best;
  }

  private worldPoint(e: PointerEvent): { x: number; y: number } | null {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;
    return {
      x: ((e.clientX - rect.left) / rect.width) * WORLD_W,
      y: ((e.clientY - rect.top) / rect.height) * WORLD_H,
    };
  }

  private resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const bounds = parent.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const scale = Math.min(bounds.width / WORLD_W, bounds.height / WORLD_H);
    const cssW = Math.max(1, Math.floor(WORLD_W * scale));
    const cssH = Math.max(1, Math.floor(WORLD_H * scale));
    this.canvas.style.width = `${cssW}px`;
    this.canvas.style.height = `${cssH}px`;
    this.canvas.width = Math.floor(cssW * dpr);
    this.canvas.height = Math.floor(cssH * dpr);
    this.ctx.setTransform(dpr * (cssW / WORLD_W), 0, 0, dpr * (cssH / WORLD_H), 0, 0);
  }

  private async loadArt() {
    const [floor, donny, w0, w1, w2, w3, schnell, scharf, saeure, kleber] = await Promise.all([
      loadImage("/game/floor.jpg"),
      loadImage("/game/donny.png"),
      loadImage("/game/worm-0.png"),
      loadImage("/game/worm-1.png"),
      loadImage("/game/worm-2.png"),
      loadImage("/game/worm-3.png"),
      loadImage("/game/tower-schnell.png"),
      loadImage("/game/tower-scharf.png"),
      loadImage("/game/tower-saeure.png"),
      loadImage("/game/tower-kleber.png"),
    ]);
    this.floor = floor.naturalWidth ? floor : null;
    this.donny = donny.naturalWidth ? donny : null;
    this.worms = [w0, w1, w2, w3].filter((img) => img.naturalWidth > 0);
    this.towerArt = {
      schnell: schnell.naturalWidth ? schnell : undefined,
      scharf: scharf.naturalWidth ? scharf : undefined,
      saeure: saeure.naturalWidth ? saeure : undefined,
      kleber: kleber.naturalWidth ? kleber : undefined,
    };
  }

  private render(now: number) {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, WORLD_W, WORLD_H);
    ctx.save();
    if (!this.reduced && this.shake > 0.4) {
      ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
      this.shake *= 0.86;
    } else this.shake = 0;

    if (this.floor) ctx.drawImage(this.floor, 0, 0, WORLD_W, WORLD_H);
    else {
      ctx.fillStyle = "#e7b7bf";
      ctx.fillRect(0, 0, WORLD_W, WORLD_H);
    }

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "rgba(86, 120, 58, 0.45)";
    ctx.lineWidth = 78;
    ctx.stroke(this.path);
    ctx.strokeStyle = "rgba(186, 214, 104, 0.94)";
    ctx.lineWidth = 58;
    ctx.stroke(this.path);
    ctx.strokeStyle = "rgba(255, 252, 220, 0.35)";
    ctx.lineWidth = 14;
    ctx.stroke(this.path);
    this.drawChevrons(ctx, now);

    if (this.phase === "playing" && this.armed) {
      ctx.strokeStyle = "rgba(247, 239, 230, 0.28)";
      ctx.lineWidth = 2;
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          if (BLOCKED[r][c]) continue;
          if (this.towers.some((t) => t.c === c && t.r === r)) continue;
          const x = c * CELL + 8;
          const y = r * CELL + 8;
          this.roundRect(ctx, x, y, CELL - 16, CELL - 16, 10);
          ctx.stroke();
        }
      }
    }

    const ghost = this.hover && this.armed && this.phase === "playing" ? this.hover : null;
    if (ghost && !BLOCKED[ghost.r][ghost.c] && !this.towers.some((t) => t.c === ghost.c && t.r === ghost.r)) {
      const center = cellCenter(ghost.c, ghost.r);
      this.rangeRing(ctx, center.x, center.y, TOWERS[this.armed!].range, "rgba(143, 211, 106, 0.28)");
      this.drawTowerSprite(ctx, this.armed!, center.x, center.y, -Math.PI / 2, 0, 0.55);
    }

    const selected = this.selectedTower();
    if (selected && this.phase === "playing") {
      this.rangeRing(ctx, selected.x, selected.y, TOWERS[selected.kind].range, "rgba(240, 180, 41, 0.28)");
    }

    for (const tower of this.towers) this.drawTowerSprite(ctx, tower.kind, tower.x, tower.y, tower.facing, tower.kick, 1);

    for (const enemy of this.enemies) this.drawEnemy(ctx, enemy, now);

    for (const shot of this.shots) {
      ctx.fillStyle = SHOT_COLORS[shot.kind];
      ctx.beginPath();
      const rad = shot.kind === "scharf" ? 4 : shot.kind === "schnell" ? 3.5 : 7;
      ctx.arc(shot.x, shot.y, rad, 0, Math.PI * 2);
      ctx.fill();
      if (shot.kind === "scharf") {
        ctx.strokeStyle = "rgba(255, 244, 200, 0.7)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        const ang = Math.atan2(shot.ty - shot.y, shot.tx - shot.x);
        ctx.moveTo(shot.x, shot.y);
        ctx.lineTo(shot.x - Math.cos(ang) * 18, shot.y - Math.sin(ang) * 18);
        ctx.stroke();
      }
    }

    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    this.drawDonny(ctx, now);

    ctx.font = "700 18px Fredoka, Outfit, sans-serif";
    ctx.textAlign = "center";
    for (const f of this.floaters) {
      ctx.globalAlpha = Math.max(0, f.life / 0.8);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, f.y);
      ctx.globalAlpha = 1;
    }

    if (this.hurt > 0 && !this.reduced) {
      ctx.fillStyle = `rgba(228, 83, 78, ${this.hurt * 0.28})`;
      ctx.fillRect(0, 0, WORLD_W, WORLD_H);
      this.hurt = Math.max(0, this.hurt - 0.02);
    }

    ctx.restore();
  }

  private drawChevrons(ctx: CanvasRenderingContext2D, now: number) {
    ctx.fillStyle = "rgba(70, 100, 46, 0.55)";
    const shift = this.reduced ? 0 : (now * 46) % 120;
    for (let d = 70 + shift; d < TRACK.length - 80; d += 120) {
      const a = pointAt(TRACK, d);
      const b = pointAt(TRACK, d + 10);
      const ang = Math.atan2(b.y - a.y, b.x - a.x);
      ctx.save();
      ctx.translate(a.x, a.y);
      ctx.rotate(ang);
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-8, -8);
      ctx.lineTo(-8, 8);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private rangeRing(ctx: CanvasRenderingContext2D, x: number, y: number, range: number, color: string) {
    ctx.beginPath();
    ctx.arc(x, y, range, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.strokeStyle = color.replace("0.28", "0.8");
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  private drawTowerSprite(
    ctx: CanvasRenderingContext2D,
    kind: TowerKind,
    x: number,
    y: number,
    facing: number,
    kick: number,
    alpha: number,
  ) {
    const img = this.towerArt[kind];
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(x, y);
    ctx.fillStyle = "rgba(40, 16, 24, 0.28)";
    ctx.beginPath();
    ctx.ellipse(0, 16, 20, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.rotate(facing + Math.PI / 2);
    ctx.translate(0, kick * 7);
    const size = kind === "scharf" ? 78 : 70;
    if (img) ctx.drawImage(img, -size / 2, -size * 0.62, size, size);
    else {
      ctx.fillStyle = SHOT_COLORS[kind];
      ctx.beginPath();
      ctx.arc(0, 0, 16, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, enemy: Enemy, now: number) {
    const def = ENEMIES[enemy.kind];
    const frame = this.worms.length
      ? this.worms[Math.floor(now * 8 + enemy.id) % this.worms.length]
      : null;
    const size = 188 * def.scale;
    ctx.save();
    ctx.translate(enemy.x, enemy.y);
    if (enemy.flash > 0) ctx.filter = "brightness(1.7)";
    ctx.rotate(enemy.ang);
    if (frame) ctx.drawImage(frame, -size / 2, -size / 2, size, size);
    else {
      ctx.fillStyle = "#f3e2c4";
      ctx.fillRect(-20, -8, 40, 16);
    }
    ctx.filter = "none";
    ctx.restore();

    if (enemy.kind === "boss") this.crown(ctx, enemy.x, enemy.y - 28 * def.scale);
    if (enemy.kind === "panzer") {
      ctx.strokeStyle = "rgba(70, 78, 96, 0.8)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(enemy.x, enemy.y, 16 * def.scale, 0, Math.PI * 2);
      ctx.stroke();
    }

    if (enemy.hp < enemy.maxHp) {
      const w = 36 * def.scale;
      const x = enemy.x - w / 2;
      const y = enemy.y - 18 * def.scale - 10;
      ctx.fillStyle = "rgba(20, 10, 14, 0.7)";
      ctx.fillRect(x, y, w, 5);
      ctx.fillStyle = enemy.slowT > 0 ? "#ff8fb8" : "#e4534e";
      ctx.fillRect(x, y, w * Math.max(0, enemy.hp / enemy.maxHp), 5);
    }
  }

  private crown(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#f0b429";
    ctx.beginPath();
    ctx.moveTo(x - 16, y + 8);
    ctx.lineTo(x - 16, y - 2);
    ctx.lineTo(x - 8, y + 4);
    ctx.lineTo(x, y - 10);
    ctx.lineTo(x + 8, y + 4);
    ctx.lineTo(x + 16, y - 2);
    ctx.lineTo(x + 16, y + 8);
    ctx.closePath();
    ctx.fill();
  }

  private drawDonny(ctx: CanvasRenderingContext2D, now: number) {
    const bob = this.reduced ? 0 : Math.sin(now * 2.2) * 3;
    const w = 176;
    const h = 176;
    const x = BASE.x - w / 2;
    const y = BASE.y - h * 0.78 + bob;
    if (this.donny) ctx.drawImage(this.donny, x, y, w, h);
    else {
      ctx.fillStyle = "#f0a05a";
      ctx.beginPath();
      ctx.arc(BASE.x, BASE.y - 40, 36, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
}
