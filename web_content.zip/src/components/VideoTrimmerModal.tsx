import React, { useRef, useState, useEffect } from 'react';
import {
  Scissors,
  Play,
  Pause,
  Download,
  X,
  CheckCircle2,
  Sparkles,
  Loader2,
} from 'lucide-react';
import { RecordingItem } from '../types/recorder';
import { formatDuration, trimVideoSegment, downloadRecording } from '../utils/mediaExport';
import { saveRecording } from '../utils/storage';

interface VideoTrimmerModalProps {
  item: RecordingItem | null;
  onClose: () => void;
  onTrimSaved: (newItem: RecordingItem) => void;
}

export const VideoTrimmerModal: React.FC<VideoTrimmerModalProps> = ({
  item,
  onClose,
  onTrimSaved,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [objectUrl, setObjectUrl] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);
  const [startTime, setStartTime] = useState<number>(0);
  const [endTime, setEndTime] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [completedItem, setCompletedItem] = useState<RecordingItem | null>(null);

  useEffect(() => {
    if (!item) return;
    const url = URL.createObjectURL(item.blob);
    setObjectUrl(url);

    return () => {
      URL.revokeObjectURL(url);
    };
  }, [item]);

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const dur = videoRef.current.duration || item?.duration || 10;
      setDuration(dur);
      setStartTime(0);
      setEndTime(dur);
      setCurrentTime(0);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const current = videoRef.current.currentTime;
      setCurrentTime(current);

      // Loop or stop if reached trim end
      if (current >= endTime) {
        videoRef.current.pause();
        videoRef.current.currentTime = startTime;
        setIsPlaying(false);
      }
    }
  };

  const togglePreview = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      if (videoRef.current.currentTime < startTime || videoRef.current.currentTime >= endTime) {
        videoRef.current.currentTime = startTime;
      }
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleExecuteTrim = async () => {
    if (!item) return;
    try {
      setIsProcessing(true);
      setProgress(5);

      const result = await trimVideoSegment(item.blob, startTime, endTime, (pct) => {
        setProgress(pct);
      });

      const cutDuration = Math.round(endTime - startTime);
      const newTitle = `Trimmed_${Date.now()}_${item.title.replace(/\.[^/.]+$/, '')}.mp4`;

      const newItem: RecordingItem = {
        id: `rec_trimmed_${Date.now()}`,
        title: newTitle,
        blob: result.blob,
        mimeType: result.mimeType,
        extension: 'mp4',
        duration: cutDuration || 1,
        size: result.blob.size || 1200000,
        resolutionBadge: item.resolutionBadge,
        width: item.width,
        height: item.height,
        fps: item.fps,
        bitrateMbps: item.bitrateMbps,
        hasAudio: item.hasAudio,
        createdAt: Date.now(),
        thumbnail: item.thumbnail,
      };

      await saveRecording(newItem);
      setCompletedItem(newItem);
      onTrimSaved(newItem);
    } catch (err) {
      console.error('Trimming failed:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!item) return null;

  const trimLength = Math.max(0, endTime - startTime);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
              <Scissors className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                HD Video Trimmer
              </h3>
              <p className="text-xs text-slate-400">
                Cut start & end timestamps and export a high definition MP4
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Canvas Monitor */}
        <div className="relative aspect-video w-full bg-black flex items-center justify-center select-none">
          {objectUrl && (
            <video
              ref={videoRef}
              src={objectUrl}
              onLoadedMetadata={handleLoadedMetadata}
              onTimeUpdate={handleTimeUpdate}
              playsInline
              className="w-full h-full object-contain"
            />
          )}

          {/* Processing spinner overlay */}
          {isProcessing && (
            <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
              <p className="text-white font-semibold text-sm">
                Rendering Trimmed MP4 Video...
              </p>
              <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  style={{ width: `${progress}%` }}
                  className="h-full bg-blue-500 rounded-full transition-all duration-150"
                />
              </div>
              <span className="text-xs text-slate-400 font-mono">{progress}%</span>
            </div>
          )}
        </div>

        {/* Trimming Controls & Timeline Dual Slider */}
        <div className="p-6 flex flex-col gap-5 bg-slate-900">
          {/* Time statistics */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800/50 rounded-2xl border border-slate-700/50 text-xs">
            <div className="flex flex-col">
              <span className="text-slate-400">Start Time</span>
              <span className="text-white font-bold font-mono text-sm tabular-nums">
                {formatDuration(startTime)}
              </span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-slate-400">Trimmed Length</span>
              <span className="text-blue-400 font-bold font-mono text-sm tabular-nums">
                {formatDuration(trimLength)}
              </span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-slate-400">End Time</span>
              <span className="text-white font-bold font-mono text-sm tabular-nums">
                {formatDuration(endTime)}
              </span>
            </div>
          </div>

          {/* Dual range sliders for start and end */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400 w-16">Start Cut:</span>
              <input
                type="range"
                min={0}
                max={Math.max(0, endTime - 0.5)}
                step={0.1}
                value={startTime}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setStartTime(val);
                  if (videoRef.current) videoRef.current.currentTime = val;
                }}
                className="flex-1 accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-slate-300 w-12 text-right">
                {formatDuration(startTime)}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400 w-16">End Cut:</span>
              <input
                type="range"
                min={Math.min(duration, startTime + 0.5)}
                max={duration || 10}
                step={0.1}
                value={endTime}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setEndTime(val);
                  if (videoRef.current) videoRef.current.currentTime = val;
                }}
                className="flex-1 accent-blue-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-slate-300 w-12 text-right">
                {formatDuration(endTime)}
              </span>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={togglePreview}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-4 h-4 fill-current" />
                  <span>Pause Clip</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Preview Cut</span>
                </>
              )}
            </button>

            {completedItem ? (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium mr-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Saved to Library!</span>
                </div>
                <button
                  onClick={() => downloadRecording(completedItem, 'mp4')}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-lg transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download MP4</span>
                </button>
              </div>
            ) : (
              <button
                onClick={handleExecuteTrim}
                disabled={isProcessing || trimLength <= 0}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold text-xs shadow-lg shadow-blue-600/20 active:scale-95 transition-all cursor-pointer"
              >
                <Scissors className="w-4 h-4" />
                <span>Export Trimmed MP4</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
