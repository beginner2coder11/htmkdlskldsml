/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { CpuTelemetry, calculateCpuSummary } from '../utils/protocol';
import { bridgeClient } from '../services/bridgeService';
import { AppLauncherItem, LaunchedAppRecord } from '../types';
import {
  Cpu,
  Zap,
  Play,
  RotateCw,
  Terminal,
  Calculator,
  FileText,
  Folder,
  Music,
  Gamepad2,
  Activity,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Search,
} from 'lucide-react';

interface DashboardViewProps {
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const PRESET_APPS: AppLauncherItem[] = [
  {
    id: 'notepad',
    name: 'Notepad',
    category: 'productivity',
    executable: 'notepad.exe',
    iconName: 'FileText',
    description: 'Lightweight text editor for quick notes',
  },
  {
    id: 'terminal',
    name: 'Windows Terminal',
    category: 'productivity',
    executable: 'wt.exe',
    iconName: 'Terminal',
    description: 'Modern tabbed command line terminal',
  },
  {
    id: 'calc',
    name: 'Calculator',
    category: 'productivity',
    executable: 'calc.exe',
    iconName: 'Calculator',
    description: 'Standard system math & graphing tool',
  },
  {
    id: 'vscode',
    name: 'VS Code',
    category: 'productivity',
    executable: 'code',
    iconName: 'Code',
    description: 'Code editor & developer workspace',
  },
  {
    id: 'taskmgr',
    name: 'Task Manager',
    category: 'system',
    executable: 'taskmgr.exe',
    iconName: 'Activity',
    description: 'View running tasks and system resources',
  },
  {
    id: 'explorer',
    name: 'File Explorer',
    category: 'system',
    executable: 'explorer.exe',
    iconName: 'Folder',
    description: 'Browse local files and storage drives',
  },
  {
    id: 'spotify',
    name: 'Spotify',
    category: 'media',
    executable: 'spotify.exe',
    iconName: 'Music',
    description: 'Music & podcast streaming audio player',
  },
  {
    id: 'steam',
    name: 'Steam',
    category: 'media',
    executable: 'steam.exe',
    iconName: 'Gamepad2',
    description: 'Digital gaming client and library',
  },
];

export const DashboardView: React.FC<DashboardViewProps> = ({ onNotify }) => {
  // Telemetry state
  const [cpuData, setCpuData] = useState<CpuTelemetry>({
    total: 18.4,
    per_core: [12.0, 24.5, 8.1, 38.2, 14.0, 19.5, 29.8, 11.2],
    max_mhz: 4800,
    min_mhz: 800,
  });
  const [cpuHistory, setCpuHistory] = useState<number[]>([14, 18, 22, 16, 25, 21, 18, 19]);
  const [isQueryingCpu, setIsQueryingCpu] = useState(false);
  const [autoPollInterval, setAutoPollInterval] = useState<number>(2); // 2s default
  const [isAutoPolling, setIsAutoPolling] = useState<boolean>(true);

  // App launcher state
  const [customTarget, setCustomTarget] = useState<string>('');
  const [isLaunching, setIsLaunching] = useState<boolean>(false);
  const [launchHistory, setLaunchHistory] = useState<LaunchedAppRecord[]>([
    {
      id: 'init-1',
      target: 'notepad.exe',
      timestamp: '10:14:22',
      status: 'launched',
    },
  ]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'productivity' | 'system' | 'media'>('all');

  const summary = calculateCpuSummary(cpuData.total, cpuData.per_core);

  // Fetch CPU Telemetry
  const fetchCpu = async (silent = false) => {
    setIsQueryingCpu(true);
    try {
      const res = await bridgeClient.getCpu();
      if (res.success && res.data) {
        setCpuData(res.data);
        setCpuHistory((prev) => [...prev.slice(-29), res.data!.total]);
        if (!silent) {
          onNotify(`CPU telemetry refreshed (${res.latencyMs}ms)`, 'success');
        }
      } else {
        if (!silent) {
          onNotify(res.error || 'Failed to query CPU', 'error');
        }
      }
    } catch (e: any) {
      if (!silent) {
        onNotify(`Connection error: ${e.message}`, 'error');
      }
    } finally {
      setIsQueryingCpu(false);
    }
  };

  // Auto polling effect
  useEffect(() => {
    if (!isAutoPolling || autoPollInterval <= 0) return;
    const interval = setInterval(() => {
      fetchCpu(true);
    }, autoPollInterval * 1000);
    return () => clearInterval(interval);
  }, [isAutoPolling, autoPollInterval]);

  // Launch App handler
  const handleLaunchApp = async (target: string) => {
    if (!target.trim()) {
      onNotify('Target executable cannot be blank', 'error');
      return;
    }
    setIsLaunching(true);
    try {
      const res = await bridgeClient.openApp(target.trim());
      const newRecord: LaunchedAppRecord = {
        id: Math.random().toString(36).substring(2, 9),
        target: target.trim(),
        timestamp: new Date().toLocaleTimeString(),
        status: res.success ? 'launched' : 'failed',
        message: res.error,
      };
      setLaunchHistory((prev) => [newRecord, ...prev.slice(0, 9)]);

      if (res.success) {
        onNotify(`Launched process: ${target.trim()}`, 'success');
      } else {
        onNotify(`Failed to launch: ${res.error}`, 'error');
      }
    } catch (err: any) {
      onNotify(`Launch failed: ${err.message}`, 'error');
    } finally {
      setIsLaunching(false);
    }
  };

  const getLoadBadgeColor = (cat: string) => {
    switch (cat) {
      case 'critical':
        return 'text-rose-400 bg-rose-950/80 border-rose-800';
      case 'high':
        return 'text-amber-400 bg-amber-950/80 border-amber-800';
      case 'moderate':
        return 'text-sky-400 bg-sky-950/80 border-sky-800';
      default:
        return 'text-emerald-400 bg-emerald-950/80 border-emerald-800';
    }
  };

  const getCoreColorClass = (pct: number) => {
    if (pct > 80) return 'from-rose-500 to-red-600';
    if (pct > 50) return 'from-amber-500 to-yellow-600';
    return 'from-cyan-500 to-emerald-500';
  };

  const filteredApps = PRESET_APPS.filter(
    (app) => selectedCategory === 'all' || app.category === selectedCategory
  );

  return (
    <div className="space-y-6">
      {/* Top Banner: Local Protocol Highlights */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-cyan-950/70 border border-cyan-800/70 rounded-xl text-cyan-400">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                PC Control & Hardware Telemetry
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono">
                  TLS / TCP
                </span>
              </h2>
              <p className="text-sm text-slate-400">
                Direct client dispatch for <code className="text-cyan-300 font-mono">GET_CPU</code> and <code className="text-cyan-300 font-mono">OPEN_APP</code> without external cloud relays.
              </p>
            </div>
          </div>

          {/* Quick Auto-Poll Controls */}
          <div className="flex items-center gap-2 self-end sm:self-center">
            <span className="text-xs text-slate-400">Auto-query:</span>
            <button
              type="button"
              onClick={() => setIsAutoPolling(!isAutoPolling)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition ${
                isAutoPolling
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isAutoPolling ? 'Active (2s)' : 'Paused'}
            </button>
            <button
              type="button"
              onClick={() => fetchCpu(false)}
              disabled={isQueryingCpu}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-medium transition shadow-md shadow-cyan-600/20 disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isQueryingCpu ? 'animate-spin' : ''}`} />
              Query Now
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Left Column CPU Telemetry HUD | Right Column Quick Actions & Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: CPU Telemetry Card (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2 min-w-0">
              <Cpu className="w-5 h-5 text-cyan-400 shrink-0" />
              <h3 className="font-bold text-white text-base truncate">Host CPU Telemetry</h3>
              <span className="text-xs text-slate-500 font-mono hidden sm:inline">psutil.cpu_percent</span>
            </div>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-mono uppercase font-semibold border whitespace-nowrap shrink-0 ${getLoadBadgeColor(
                summary.loadCategory
              )}`}
            >
              {summary.loadCategory} load ({summary.safeTotal}%)
            </span>
          </div>

          {/* Primary Dial & Metrics Stat Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Total Load Meter */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
                Overall CPU
              </span>
              <div className="relative flex items-center justify-center">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="38"
                    className="stroke-slate-800"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="38"
                    className="stroke-cyan-400 transition-all duration-500"
                    strokeWidth="8"
                    strokeDasharray={238.76}
                    strokeDashoffset={238.76 * (1 - summary.safeTotal / 100)}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-2xl font-black text-white font-mono">{summary.safeTotal}%</span>
                </div>
              </div>
              <span className="text-[11px] text-slate-400 mt-2">
                Avg Core: <span className="text-cyan-300 font-mono">{summary.averageCoreLoad}%</span>
              </span>
            </div>

            {/* Frequency Stat Card */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  Clock Frequency
                </span>
                <div className="mt-2 text-xl font-bold font-mono text-white">
                  {cpuData.max_mhz ? `${cpuData.max_mhz} MHz` : 'Dynamic'}
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  psutil.cpu_freq() hardware limits
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800 text-xs text-slate-300 space-y-1 font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-500">Min:</span>
                  <span>{cpuData.min_mhz ? `${cpuData.min_mhz} MHz` : '800 MHz'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Max:</span>
                  <span>{cpuData.max_mhz ? `${cpuData.max_mhz} MHz` : '4800 MHz'}</span>
                </div>
              </div>
            </div>

            {/* Core Topology Stat Card */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  Cores Detected
                </span>
                <div className="mt-2 text-xl font-bold font-mono text-emerald-400">
                  {summary.coreCount} Logical Cores
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Peak Core: #{summary.highestCoreIndex} at{' '}
                  <span className="font-mono text-amber-300">{summary.highestCoreLoad}%</span>
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Subprocess isolated</span>
                </div>
              </div>
            </div>
          </div>

          {/* Per-Core Breakdown Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Per-Core Load Distribution
              </span>
              <span className="text-[11px] text-slate-500">interval = 0.3s</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {summary.validCores.map((load, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800/70 rounded-lg p-2.5 flex flex-col justify-between"
                >
                  <div className="flex justify-between items-center text-xs mb-1 font-mono">
                    <span className="text-slate-400 text-[11px]">Core #{idx}</span>
                    <span className="font-semibold text-slate-200">{load}%</span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${getCoreColorClass(
                        load
                      )} transition-all duration-300`}
                      style={{ width: `${Math.min(100, Math.max(3, load))}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Historical Trend Sparkline */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Telemetry Trend (Last Samples)
              </span>
              <span className="text-[11px] font-mono text-slate-500">{cpuHistory.length} frames</span>
            </div>
            <div className="bg-slate-950 border border-slate-800/70 rounded-xl p-3 h-28 flex items-end gap-1.5 overflow-hidden">
              {cpuHistory.map((val, i) => {
                const heightPct = Math.max(12, Math.min(100, Math.round(val)));
                return (
                  <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                    <div
                      className="w-full rounded-t bg-gradient-to-t from-cyan-600/30 via-cyan-500/70 to-cyan-300 border-t border-cyan-300/80 group-hover:brightness-125 transition-all duration-300"
                      style={{ height: `${heightPct}%` }}
                    />
                    <div className="absolute -top-7 opacity-0 group-hover:opacity-100 bg-slate-800 text-[10px] text-cyan-300 font-mono px-1 rounded transition pointer-events-none z-10 whitespace-nowrap">
                      {val}%
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Quick Action & Custom Executable Launcher (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Custom App Launcher Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Play className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-white text-base">Launch Process (OPEN_APP)</h3>
            </div>

            <p className="text-xs text-slate-400">
              Executes target directly via <code className="text-cyan-300 font-mono">subprocess.Popen([target])</code> without shell interpolation, guarding against command injection.
            </p>

            {/* Custom Input */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Target Binary or Command
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customTarget}
                  onChange={(e) => setCustomTarget(e.target.value)}
                  placeholder="e.g. notepad.exe or code"
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleLaunchApp(customTarget);
                  }}
                />
                <button
                  type="button"
                  onClick={() => handleLaunchApp(customTarget)}
                  disabled={isLaunching || !customTarget.trim()}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white rounded-xl text-sm font-medium transition shadow-lg shadow-indigo-600/20 disabled:opacity-50"
                >
                  {isLaunching ? 'Launching...' : 'Run'}
                </button>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="pt-2">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Quick Shortcuts:
              </span>
              <div className="flex flex-wrap gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => handleLaunchApp('notepad.exe')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-700/70 text-slate-200 px-2.5 py-1.5 rounded-lg transition"
                >
                  📝 Notepad
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchApp('calc.exe')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-700/70 text-slate-200 px-2.5 py-1.5 rounded-lg transition"
                >
                  🔢 Calculator
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchApp('taskmgr.exe')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-700/70 text-slate-200 px-2.5 py-1.5 rounded-lg transition"
                >
                  📊 Task Manager
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchApp('explorer.exe')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-700/70 text-slate-200 px-2.5 py-1.5 rounded-lg transition"
                >
                  📁 Explorer
                </button>
              </div>
            </div>

            {/* Recent Launch History */}
            <div className="pt-3 border-t border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Recent Process History
                </span>
                <span className="text-[10px] text-slate-500 font-mono">last 10</span>
              </div>

              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {launchHistory.map((rec) => (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between text-xs bg-slate-950/70 border border-slate-800/80 rounded-lg px-2.5 py-1.5"
                  >
                    <div className="flex items-center gap-2">
                      {rec.status === 'launched' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                      )}
                      <span className="font-mono text-slate-200">{rec.target}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{rec.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Preset Application Launcher Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-bold text-white text-base">Quick App Launcher Matrix</h3>
            <p className="text-xs text-slate-400">
              Single-tap launching of whitelisted productivity tools, utilities, and media players.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`px-2.5 py-1 rounded-md transition ${
                selectedCategory === 'all'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('productivity')}
              className={`px-2.5 py-1 rounded-md transition ${
                selectedCategory === 'productivity'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Productivity
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('system')}
              className={`px-2.5 py-1 rounded-md transition ${
                selectedCategory === 'system'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              System
            </button>
            <button
              type="button"
              onClick={() => setSelectedCategory('media')}
              className={`px-2.5 py-1 rounded-md transition ${
                selectedCategory === 'media'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Media
            </button>
          </div>
        </div>

        {/* Matrix Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredApps.map((app) => (
            <div
              key={app.id}
              className="bg-slate-950 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-4 transition-all duration-200 hover:shadow-lg hover:shadow-cyan-500/5 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 group-hover:text-cyan-300 group-hover:border-cyan-800/80 transition">
                    <Play className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                    {app.category}
                  </span>
                </div>
                <h4 className="font-semibold text-white text-sm">{app.name}</h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">{app.description}</p>
                <div className="mt-2 text-[11px] font-mono text-cyan-400/80 bg-slate-900/60 px-2 py-1 rounded border border-slate-800/60 truncate">
                  {app.executable}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-900">
                <button
                  type="button"
                  onClick={() => handleLaunchApp(app.executable)}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-slate-800 hover:bg-cyan-600 text-slate-200 hover:text-white rounded-lg text-xs font-medium transition"
                >
                  <Play className="w-3.5 h-3.5" /> Launch on PC
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
