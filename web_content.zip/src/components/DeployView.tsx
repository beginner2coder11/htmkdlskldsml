/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ServerConfig,
  DEFAULT_SERVER_CONFIG,
  generateServerPy,
  generateDockerSetup,
  generateSystemdUnit,
  generateOpenSslCommand,
} from '../utils/protocol';
import { bridgeClient } from '../services/bridgeService';
import {
  Server,
  Terminal,
  Container,
  Cpu,
  Shield,
  Copy,
  Check,
  Download,
  Key,
  Layers,
  Settings,
  Plus,
  X,
  FileCode,
} from 'lucide-react';

interface DeployViewProps {
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const DeployView: React.FC<DeployViewProps> = ({ onNotify }) => {
  const [config, setConfig] = useState<ServerConfig>({ ...DEFAULT_SERVER_CONFIG });
  const [activeDeployTab, setActiveDeployTab] = useState<'serverpy' | 'docker' | 'baremetal' | 'certs'>('serverpy');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [newAppInput, setNewAppInput] = useState<string>('');

  const serverPyCode = generateServerPy(config);
  const dockerSetup = generateDockerSetup(config);
  const systemdService = generateSystemdUnit(config);
  const openSslCmd = generateOpenSslCommand(config.host === '0.0.0.0' ? 'localhost' : config.host);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
    onNotify('Copied to clipboard', 'success');
  };

  const handleDownloadServerPy = () => {
    const blob = new Blob([serverPyCode], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'server.py';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    onNotify('Downloaded server.py', 'success');
  };

  const handleAddAllowedApp = () => {
    if (!newAppInput.trim()) return;
    const clean = newAppInput.trim();
    if (!config.allowedApps.includes(clean)) {
      const updated = { ...config, allowedApps: [...config.allowedApps, clean] };
      setConfig(updated);
      bridgeClient.setServerConfig(updated);
    }
    setNewAppInput('');
  };

  const handleRemoveAllowedApp = (appName: string) => {
    const updated = {
      ...config,
      allowedApps: config.allowedApps.filter((a) => a !== appName),
    };
    setConfig(updated);
    bridgeClient.setServerConfig(updated);
  };

  const handleConfigChange = (partial: Partial<ServerConfig>) => {
    const updated = { ...config, ...partial };
    setConfig(updated);
    bridgeClient.setServerConfig(updated);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-950/70 border border-indigo-800/70 rounded-xl text-indigo-400">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Server Package & Deployment Hub
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-950 border border-indigo-800 text-indigo-300 font-mono">
                Production-Ready
              </span>
            </h2>
            <p className="text-sm text-slate-400">
              Generate self-contained Python 3.12+ services, Docker containers, systemd units, and TLS certificates.
            </p>
          </div>
        </div>

        {/* Deploy Modality Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveDeployTab('serverpy')}
            className={`px-3 py-1.5 rounded-lg transition font-medium flex items-center gap-1.5 ${
              activeDeployTab === 'serverpy'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" /> server.py
          </button>
          <button
            type="button"
            onClick={() => setActiveDeployTab('docker')}
            className={`px-3 py-1.5 rounded-lg transition font-medium flex items-center gap-1.5 ${
              activeDeployTab === 'docker'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Container className="w-3.5 h-3.5" /> Docker
          </button>
          <button
            type="button"
            onClick={() => setActiveDeployTab('baremetal')}
            className={`px-3 py-1.5 rounded-lg transition font-medium flex items-center gap-1.5 ${
              activeDeployTab === 'baremetal'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> Bare Metal & Systemd
          </button>
          <button
            type="button"
            onClick={() => setActiveDeployTab('certs')}
            className={`px-3 py-1.5 rounded-lg transition font-medium flex items-center gap-1.5 ${
              activeDeployTab === 'certs'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" /> TLS Certs
          </button>
        </div>
      </div>

      {/* Tab 1: server.py Configurator & Code */}
      {activeDeployTab === 'serverpy' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Configuration Controls (4 cols) */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Service Hardening</h3>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              {/* Host Bind */}
              <div>
                <label className="block font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Bind Interface (HOST)
                </label>
                <select
                  value={config.host}
                  onChange={(e) => handleConfigChange({ host: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="0.0.0.0">0.0.0.0 (All LAN interfaces / Phone access)</option>
                  <option value="127.0.0.1">127.0.0.1 (Localhost only / SSH tunnel)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Use 0.0.0.0 to allow phones on the same Wi-Fi subnet to reach the PC.
                </p>
              </div>

              {/* Port */}
              <div>
                <label className="block font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  TLS Listening Port
                </label>
                <input
                  type="number"
                  value={config.port}
                  onChange={(e) => handleConfigChange({ port: Number(e.target.value) || 8765 })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Whitelist Toggle */}
              <div className="pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-300 uppercase tracking-wider">
                    Application Whitelist
                  </span>
                  <input
                    type="checkbox"
                    checked={config.allowAppWhitelist}
                    onChange={(e) => handleConfigChange({ allowAppWhitelist: e.target.checked })}
                    className="h-4 w-4 rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mb-2">
                  Blocks execution of any executable name not explicitly in this list.
                </p>

                {config.allowAppWhitelist && (
                  <div className="space-y-2">
                    <div className="flex gap-1">
                      <input
                        type="text"
                        value={newAppInput}
                        onChange={(e) => setNewAppInput(e.target.value)}
                        placeholder="e.g. vlc.exe"
                        className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono text-xs focus:outline-none focus:border-cyan-500"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddAllowedApp();
                        }}
                      />
                      <button
                        type="button"
                        onClick={handleAddAllowedApp}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto pr-1">
                      {config.allowedApps.map((app) => (
                        <span
                          key={app}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-950 border border-slate-800 font-mono text-[11px] text-cyan-300"
                        >
                          {app}
                          <button
                            type="button"
                            onClick={() => handleRemoveAllowedApp(app)}
                            className="hover:text-rose-400"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Mutual TLS (mTLS) Toggle */}
              <div className="pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-300 uppercase tracking-wider">
                    Mutual TLS (mTLS)
                  </span>
                  <input
                    type="checkbox"
                    checked={config.requireMtls}
                    onChange={(e) => handleConfigChange({ requireMtls: e.target.checked })}
                    className="h-4 w-4 rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0"
                  />
                </div>
                <p className="text-[11px] text-slate-400">
                  Requires client certificates signed by <code className="text-cyan-300 font-mono">client_ca.crt</code> (Section 4 of guide).
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                type="button"
                onClick={handleDownloadServerPy}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-xs font-semibold transition shadow-md shadow-cyan-600/20"
              >
                <Download className="w-3.5 h-3.5" /> Download server.py
              </button>
            </div>
          </div>

          {/* Right Column: Code Viewer (8 cols) */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-white text-base">server.py Source Code</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopy(serverPyCode, 'pycode')}
                  className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition"
                >
                  {copiedKey === 'pycode' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'pycode' ? 'Copied' : 'Copy Code'}
                </button>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 h-[540px] overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed scrollbar-thin">
              <pre>{serverPyCode}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Docker Setup */}
      {activeDeployTab === 'docker' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Container className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Section 1: Quick Deploy with Docker</h3>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(dockerSetup.runCommand, 'dockerrun')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-medium transition"
              >
                {copiedKey === 'dockerrun' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                Copy Run Command
              </button>
            </div>

            <p className="text-sm text-slate-400 leading-relaxed">
              Run Link-to-Windows++ in an isolated container. The container automatically generates a self-signed certificate upon first launch or binds your existing <code className="text-cyan-300 font-mono">./certs</code> folder.
            </p>

            {/* Step-by-step commands */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 space-y-3">
              <div className="text-slate-400 font-bold"># Step 1: Initialize directory</div>
              <div className="text-cyan-300">mkdir -p link-to-windows-pp/certs && cd link-to-windows-pp</div>

              <div className="text-slate-400 font-bold mt-3"># Step 2: Build & Run container (port {config.port})</div>
              <div className="text-emerald-400 whitespace-pre-wrap">{dockerSetup.runCommand}</div>
            </div>

            {/* Dockerfile & docker-compose tabs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                  <span>Dockerfile</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(dockerSetup.dockerfile, 'df')}
                    className="text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy
                  </button>
                </div>
                <pre className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 overflow-x-auto h-48">
                  {dockerSetup.dockerfile}
                </pre>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                  <span>docker-compose.yml</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(dockerSetup.composeYaml, 'dc')}
                    className="text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy
                  </button>
                </div>
                <pre className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 overflow-x-auto h-48">
                  {dockerSetup.composeYaml}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Bare Metal & Systemd */}
      {activeDeployTab === 'baremetal' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-white text-base">Section 2: Installation on Bare Metal</h3>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column: Linux & systemd */}
              <div className="space-y-3">
                <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                  <span className="p-1 rounded bg-slate-800 text-cyan-400">🐧</span> Linux / WSL systemd Service
                </h4>
                <p className="text-xs text-slate-400">
                  Installs python dependencies, provisions certificates, and creates a persistent background daemon via systemd.
                </p>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 space-y-2">
                  <div className="text-slate-500 font-bold"># 1. Install dependencies</div>
                  <div className="text-cyan-300">python3 -m pip install --user psutil pyperclip</div>

                  <div className="text-slate-500 font-bold mt-2"># 2. Run system service</div>
                  <div className="text-emerald-300">
                    sudo systemctl daemon-reload<br />
                    sudo systemctl enable --now ltwn
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs font-semibold text-slate-400">
                    <span>/etc/systemd/system/ltwn.service</span>
                    <button
                      type="button"
                      onClick={() => handleCopy(systemdService, 'sysd')}
                      className="text-cyan-400 hover:underline flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" /> Copy
                    </button>
                  </div>
                  <pre className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-[11px] font-mono text-slate-300 overflow-x-auto h-40">
                    {systemdService}
                  </pre>
                </div>
              </div>

              {/* Right Column: Native Windows Service */}
              <div className="space-y-3">
                <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                  <span className="p-1 rounded bg-slate-800 text-cyan-400">🪟</span> Native Windows 11 / 10 Setup
                </h4>
                <p className="text-xs text-slate-400">
                  Run directly on your Windows host machine using PowerShell or Windows Task Scheduler:
                </p>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 space-y-2">
                  <div className="text-slate-500 font-bold"># 1. Install via Windows terminal</div>
                  <div className="text-cyan-300">py -m pip install psutil pyperclip</div>

                  <div className="text-slate-500 font-bold mt-2"># 2. Start server</div>
                  <div className="text-emerald-300">python server.py</div>

                  <div className="text-slate-500 font-bold mt-2"># 3. (Optional) Run on Startup via schtasks</div>
                  <div className="text-indigo-300 text-[11px] break-all">
                    schtasks /create /tn "LTWN_Server" /tr "pythonw.exe C:\ltwn\server.py" /sc onlogon
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: TLS Certificates */}
      {activeDeployTab === 'certs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-white text-base">Section 2.3: TLS Certificate Creation & PKI</h3>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(openSslCmd, 'openssl')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium transition"
            >
              {copiedKey === 'openssl' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              Copy OpenSSL Command
            </button>
          </div>

          <p className="text-sm text-slate-400 leading-relaxed">
            Link-to-Windows++ requires TLS encryption. You can let the script auto-generate a self-signed certificate, or create one manually with OpenSSL:
          </p>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-emerald-300 whitespace-pre-wrap">
            {openSslCmd}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl text-xs space-y-2">
              <h4 className="font-semibold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-cyan-400" /> Certificate Specifications
              </h4>
              <ul className="list-disc list-inside text-slate-400 space-y-1">
                <li>Algorithm: RSA 2048-bit with SHA-256 signature</li>
                <li>Validity: 365 days from creation</li>
                <li>TLS Protocol Minimum: TLS 1.2+ enforced</li>
                <li>Downgrade attacks disabled via <code className="text-cyan-300">PROTOCOL_TLS_SERVER</code></li>
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl text-xs space-y-2">
              <h4 className="font-semibold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-emerald-400" /> Custom Domain & mTLS Options
              </h4>
              <ul className="list-disc list-inside text-slate-400 space-y-1">
                <li>Replace <code className="text-emerald-300">/CN=localhost</code> with your PC hostname or local DNS</li>
                <li>For Mutual TLS (mTLS), generate a client certificate and set <code className="text-emerald-300">ssl_ctx.verify_mode = ssl.CERT_REQUIRED</code></li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
