/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { bridgeClient } from '../services/bridgeService';
import { PacketLog } from '../types';
import { SUPPORTED_COMMANDS, CommandType } from '../utils/protocol';
import {
  Terminal,
  Send,
  Trash2,
  Download,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  ArrowDownLeft,
  Copy,
  Info,
} from 'lucide-react';

interface ProtocolViewProps {
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const ProtocolView: React.FC<ProtocolViewProps> = ({ onNotify }) => {
  const [selectedCommand, setSelectedCommand] = useState<CommandType>('GET_CPU');
  const [jsonPayload, setJsonPayload] = useState<string>('{\n  "cmd": "GET_CPU"\n}');
  const [packets, setPackets] = useState<PacketLog[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Subscribe to packet logs from bridgeClient
  useEffect(() => {
    const unsubscribe = bridgeClient.onPacket((log) => {
      setPackets((prev) => [log, ...prev.slice(0, 49)]);
    });
    return () => unsubscribe();
  }, []);

  // When dropdown selection changes, populate default template
  const handleSelectCommand = (cmd: CommandType) => {
    setSelectedCommand(cmd);
    const def = SUPPORTED_COMMANDS.find((c) => c.cmd === cmd);
    if (def) {
      setJsonPayload(JSON.stringify(def.defaultPayload, null, 2));
      setJsonError(null);
    }
  };

  const handleJsonChange = (val: string) => {
    setJsonPayload(val);
    try {
      JSON.parse(val);
      setJsonError(null);
    } catch (e: any) {
      setJsonError(e.message);
    }
  };

  const handleSend = async () => {
    let parsed: any;
    try {
      parsed = JSON.parse(jsonPayload);
    } catch (e: any) {
      setJsonError(e.message);
      onNotify('Malformed JSON format', 'error');
      return;
    }

    setIsSending(true);
    try {
      const res = await bridgeClient.executeCommand(parsed);
      if (res.success) {
        onNotify(`Dispatched ${parsed.cmd || 'frame'} (${res.latencyMs}ms)`, 'success');
      } else {
        onNotify(`Error response: ${res.error}`, 'error');
      }
    } catch (err: any) {
      onNotify(`Transmission failed: ${err.message}`, 'error');
    } finally {
      setIsSending(false);
    }
  };

  const handleExportLogs = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(packets, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ltwn_packets_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    onNotify('Exported session packet log', 'info');
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-950/70 border border-cyan-800/70 rounded-xl text-cyan-400">
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              TLS / TCP Protocol Studio
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                JSON-Line Protocol
              </span>
            </h2>
            <p className="text-sm text-slate-400">
              Inspect raw wire frames terminated by <code className="text-cyan-300 font-mono">\n</code> sent to and received from the Link-to-Windows++ server.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportLogs}
            disabled={packets.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" /> Export Log
          </button>
          <button
            type="button"
            onClick={() => setPackets([])}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 rounded-lg text-xs font-medium transition"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear
          </button>
        </div>
      </div>

      {/* Frame Builder & Live Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Command Frame Builder (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Frame Builder</h3>
              <span className="text-xs text-slate-500 font-mono">TCP / TLS Stream</span>
            </div>

            {/* Command Preset Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Preset Command
              </label>
              <div className="grid grid-cols-2 gap-2">
                {SUPPORTED_COMMANDS.map((c) => (
                  <button
                    key={c.cmd}
                    type="button"
                    onClick={() => handleSelectCommand(c.cmd)}
                    className={`px-3 py-2 text-xs font-mono rounded-lg border text-left transition ${
                      selectedCommand === c.cmd
                        ? 'bg-cyan-950/70 text-cyan-300 border-cyan-700 font-semibold'
                        : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {c.cmd}
                  </button>
                ))}
              </div>
            </div>

            {/* Raw JSON Input */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Payload JSON Body
                </label>
                <span className="text-[11px] text-slate-500 font-mono">+ '\n' suffix</span>
              </div>
              <textarea
                value={jsonPayload}
                onChange={(e) => handleJsonChange(e.target.value)}
                rows={7}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-500 resize-none"
              />
              {jsonError ? (
                <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" /> {jsonError}
                </p>
              ) : (
                <p className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Valid JSON object
                </p>
              )}
            </div>

            {/* Protocol Spec Overview */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-400 space-y-1.5">
              <div className="flex items-center gap-1 text-slate-200 font-semibold">
                <Info className="w-3.5 h-3.5 text-cyan-400" /> Protocol Wire Format
              </div>
              <p className="text-[11px] leading-relaxed">
                The connection is non-persistent or single-query by default: client opens TLS socket, sends one UTF-8 JSON line with trailing <code className="text-cyan-300">\n</code>, receives a single JSON response line with <code className="text-cyan-300">\n</code>, and closes cleanly.
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={handleSend}
              disabled={isSending || Boolean(jsonError)}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-sm font-semibold transition shadow-lg shadow-cyan-600/20 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              {isSending ? 'Transmitting Over TLS...' : 'Transmit Frame'}
            </button>
          </div>
        </div>

        {/* Right Column: Live Network Packet Stream (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-white text-base">Network Stream Inspector</h3>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                {packets.length} Frames
              </span>
            </div>
            <span className="text-xs text-slate-500 font-mono">Real-time Capture</span>
          </div>

          {packets.length === 0 ? (
            <div className="text-center py-16 text-slate-500 text-sm">
              <Terminal className="w-8 h-8 mx-auto mb-2 opacity-40 text-cyan-400" />
              No network packets captured yet. Send a command or query CPU from the dashboard.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {packets.map((pkt) => (
                <div
                  key={pkt.id}
                  className={`border rounded-xl p-3 font-mono text-xs transition ${
                    pkt.isError
                      ? 'bg-rose-950/20 border-rose-900/60'
                      : pkt.direction === 'tx'
                      ? 'bg-slate-950 border-cyan-900/40'
                      : 'bg-slate-950 border-emerald-900/40'
                  }`}
                >
                  {/* Packet Header */}
                  <div className="flex items-center justify-between text-[11px] mb-1.5 pb-1 border-b border-slate-800/60">
                    <div className="flex items-center gap-2">
                      {pkt.direction === 'tx' ? (
                        <span className="flex items-center gap-1 font-bold text-cyan-400">
                          <ArrowUpRight className="w-3.5 h-3.5" /> TX (Client ➔ Host)
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 font-bold text-emerald-400">
                          <ArrowDownLeft className="w-3.5 h-3.5" /> RX (Host ➔ Client)
                        </span>
                      )}
                      <span className="text-slate-500">[{pkt.byteSize} bytes]</span>
                      {pkt.latencyMs !== undefined && (
                        <span className="text-indigo-400 font-semibold">{pkt.latencyMs}ms RTT</span>
                      )}
                    </div>
                    <span className="text-slate-500">{pkt.timestamp}</span>
                  </div>

                  {/* Packet Payload */}
                  <div className="text-slate-300 whitespace-pre-wrap break-all bg-slate-900/80 p-2 rounded border border-slate-800/80 overflow-x-auto">
                    {pkt.raw}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
