import React, { useRef, useEffect, useState } from 'react';
import { Camera, X, FlipHorizontal } from 'lucide-react';
import { RecorderSettings } from '../types/recorder';

interface FacecamOverlayProps {
  stream: MediaStream | null;
  settings: RecorderSettings;
  onClose: () => void;
}

export const FacecamOverlay: React.FC<FacecamOverlayProps> = ({
  stream,
  settings,
  onClose,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 24, y: 80 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isMirrored, setIsMirrored] = useState(settings.facecamMirrored);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const newX = Math.max(10, Math.min(window.innerWidth - 180, e.clientX - dragStartRef.current.x));
    const newY = Math.max(60, Math.min(window.innerHeight - 180, e.clientY - dragStartRef.current.y));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
  };

  if (!stream) return null;

  // Shapes & Sizes
  const sizeClasses = {
    sm: 'w-28 h-28',
    md: 'w-36 h-36',
    lg: 'w-48 h-48',
  }[settings.facecamSize];

  const shapeClass = {
    circle: 'rounded-full',
    squircle: 'rounded-3xl',
    rect: 'rounded-2xl aspect-video h-auto w-48',
  }[settings.facecamShape];

  return (
    <div
      style={{ transform: `translate3d(${position.x}px, ${position.y}px, 0)` }}
      className={`fixed top-0 left-0 z-50 shadow-2xl touch-none select-none ${sizeClasses} ${shapeClass} overflow-hidden border-2 border-blue-500/80 bg-slate-900 group cursor-grab active:cursor-grabbing transition-shadow hover:shadow-blue-500/20`}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full h-full object-cover pointer-events-none ${
          isMirrored ? 'scale-x-[-1]' : ''
        }`}
      />

      {/* Floating controls on hover */}
      <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMirrored(!isMirrored);
          }}
          title="Mirror camera"
          className="p-1.5 rounded-full bg-slate-800/90 text-white hover:bg-slate-700 cursor-pointer"
        >
          <FlipHorizontal className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          title="Close facecam"
          className="p-1.5 rounded-full bg-red-600/90 text-white hover:bg-red-500 cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Subtle brand badge */}
      <div className="absolute bottom-1 right-2 pointer-events-none opacity-60">
        <Camera className="w-3 h-3 text-white" />
      </div>
    </div>
  );
};
