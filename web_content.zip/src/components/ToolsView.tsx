import React, { useState } from 'react';
import {
  Scissors,
  Music,
  Camera,
  PenTool,
  Download,
  FileVideo,
  Sparkles,
  Check,
  Smartphone,
  ShieldAlert,
} from 'lucide-react';
import { RecordingItem } from '../types/recorder';
import { extractAudioFromVideo, downloadRecording } from '../utils/mediaExport';

interface ToolsViewProps {
  recordings: RecordingItem[];
  onOpenTrimmer: (item: RecordingItem) => void;
  onOpenBrush: () => void;
  onTakeScreenshot: () => void;
}

export const ToolsView: React.FC<ToolsViewProps> = ({
  recordings,
  onOpenTrimmer,
  onOpenBrush,
  onTakeScreenshot,
}) => {
  const [selectedVideoId, setSelectedVideoId] = useState<string>(
    recordings[0]?.id || ''
  );
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractedSuccess, setExtractedSuccess] = useState(false);

  const currentVideo = recordings.find((r) => r.id === selectedVideoId) || recordings[0];

  const handleAudioExtract = async () => {
    if (!currentVideo) return;
    try {
      setIsExtracting(true);
      setExtractedSuccess(false);
      const { blob, filename } = await extractAudioFromVideo(currentVideo.blob);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      setExtractedSuccess(true);
      setTimeout(() => setExtractedSuccess(false), 3000);
    } catch (e) {
      console.error('Audio extraction error:', e);
    } finally {
      setIsExtracting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 w-full pb-20">
      {/* Tools Suite Header */}
      <div className="flex flex-col">
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
          Recording & Studio Tools
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Professional high-definition post-processing and on-screen capture utilities
        </p>
      </div>

      {/* Grid of Tools */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Tool 1: Video Trimmer & Cut */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Video Trimmer</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Cut precision start and end segments and export as a new HD MP4 file.
              </p>
            </div>
          </div>

          {recordings.length > 0 ? (
            <div className="flex flex-col gap-2.5">
              <label className="text-[11px] text-slate-400">Select video to trim:</label>
              <select
                value={selectedVideoId}
                onChange={(e) => setSelectedVideoId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {recordings.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.title}
                  </option>
                ))}
              </select>
              <button
                onClick={() => currentVideo && onOpenTrimmer(currentVideo)}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Scissors className="w-3.5 h-3.5" />
                <span>Launch Video Trimmer</span>
              </button>
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">
              Record a video first to use the video trimmer.
            </p>
          )}
        </div>

        {/* Tool 2: Audio Extractor (Video to MP3 / WAV) */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Music className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Audio Extractor</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Extract high fidelity audio stream from any screen capture to WAV/MP3.
              </p>
            </div>
          </div>

          {recordings.length > 0 ? (
            <div className="flex flex-col gap-2.5">
              <button
                onClick={handleAudioExtract}
                disabled={isExtracting || !currentVideo}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs font-semibold active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {extractedSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Audio Saved to Storage!</span>
                  </>
                ) : (
                  <>
                    <Music className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{isExtracting ? 'Extracting...' : 'Extract & Download Audio'}</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">
              Record a video with audio to extract soundtracks.
            </p>
          )}
        </div>

        {/* Tool 3: Screen Brush & Annotator */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-600/20 text-amber-400 flex items-center justify-center shrink-0">
              <PenTool className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Screen Brush Annotator</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Draw arrows, highlighter lines, and rectangles directly across the screen.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenBrush}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <PenTool className="w-3.5 h-3.5 text-amber-400" />
            <span>Open Screen Brush Tool</span>
          </button>
        </div>

        {/* Tool 4: Instant Screen Snapshot */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-600/20 text-rose-400 flex items-center justify-center shrink-0">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Full Screen Snapshot</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Instant high-resolution photo capture of the current active screen.
              </p>
            </div>
          </div>

          <button
            onClick={onTakeScreenshot}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Camera className="w-3.5 h-3.5 text-rose-400" />
            <span>Capture Frame Snapshot</span>
          </button>
        </div>
      </div>
    </div>
  );
};
