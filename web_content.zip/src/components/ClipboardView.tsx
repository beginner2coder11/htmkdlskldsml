/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { bridgeClient } from '../services/bridgeService';
import { ClipboardItem } from '../types';
import {
  ClipboardCopy,
  ArrowRightLeft,
  Upload,
  Download,
  Copy,
  Check,
  Clock,
  Trash2,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';

interface ClipboardViewProps {
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const ClipboardView: React.FC<ClipboardViewProps> = ({ onNotify }) => {
  const [textToPush, setTextToPush] = useState('');
  const [currentPcText, setCurrentPcText] = useState('Welcome to Link-to-Windows++! Local TLS PC Bridge.');
  const [isPushing, setIsPushing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  const [history, setHistory] = useState<ClipboardItem[]>([
    {
      id: 'init-clip-1',
      timestamp: '10:12:05',
      direction: 'to_pc',
      text: 'https://github.com/link-to-windows-pp',
      charCount: 37,
    },
    {
      id: 'init-clip-2',
      timestamp: '10:14:40',
      direction: 'from_pc',
      text: 'Welcome to Link-to-Windows++! Local TLS PC Bridge.',
      charCount: 49,
    },
  ]);

  // Push text to PC clipboard via COPY command
  const handlePushToPc = async (textToSend: string) => {
    if (!textToSend.trim()) {
      onNotify('Clipboard payload cannot be empty', 'error');
      return;
    }

    setIsPushing(true);
    try {
      const res = await bridgeClient.copyText(textToSend);
      if (res.success) {
        onNotify(`Transferred ${textToSend.length} chars to PC clipboard!`, 'success');
        const newItem: ClipboardItem = {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toLocaleTimeString(),
          direction: 'to_pc',
          text: textToSend,
          charCount: textToSend.length,
        };
        setHistory((prev) => [newItem, ...prev]);
        setTextToPush('');
      } else {
        onNotify(`Copy failed: ${res.error}`, 'error');
      }
    } catch (err: any) {
      onNotify(`Network error: ${err.message}`, 'error');
    } finally {
      setIsPushing(false);
    }
  };

  // Pull PC clipboard via PASTE command
  const handlePullFromPc = async () => {
    setIsPulling(true);
    try {
      const res = await bridgeClient.pasteText();
      if (res.success && res.data) {
        const text = res.data.text || '';
        setCurrentPcText(text);
        onNotify(`Retrieved PC clipboard (${text.length} chars)`, 'success');
        const newItem: ClipboardItem = {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toLocaleTimeString(),
          direction: 'from_pc',
          text,
          charCount: text.length,
        };
        setHistory((prev) => [newItem, ...prev]);
      } else {
        onNotify(`Paste failed: ${res.error}`, 'error');
      }
    } catch (err: any) {
      onNotify(`Network error: ${err.message}`, 'error');
    } finally {
      setIsPulling(false);
    }
  };

  // Read local device clipboard and send to PC in one click
  const handleDeviceClipboardToPc = async () => {
    if (!navigator.clipboard?.readText) {
      onNotify('Browser clipboard reading permission not available', 'error');
      return;
    }
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setTextToPush(text);
        await handlePushToPc(text);
      } else {
        onNotify('Local device clipboard is empty', 'info');
      }
    } catch (err: any) {
      onNotify(`Could not read local clipboard: ${err.message}`, 'error');
    }
  };

  // Copy pulled PC text into local device clipboard
  const handleCopyToLocalDevice = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSuccess(true);
      setTimeout(() => setCopiedSuccess(false), 2000);
      onNotify('Copied to your local device clipboard!', 'success');
    } catch (err: any) {
      onNotify(`Failed to copy to device: ${err.message}`, 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Privacy Notice Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-950/70 border border-indigo-800/70 rounded-xl text-indigo-400">
              <ArrowRightLeft className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Privacy-First Clipboard Synchronization
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-300 font-mono">
                  In-Memory Only
                </span>
              </h2>
              <p className="text-sm text-slate-400">
                Data passes directly over TLS to the PC's memory space via <code className="text-indigo-300 font-mono">pyperclip</code>. No external analytics, cloud databases, or third-party servers ever touch your clipboard.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Grid: Push to PC (Left) and Pull from PC (Right) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Column 1: Push to PC (COPY) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Push to PC Clipboard</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {`{"cmd": "COPY"}`}
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              Type or paste text to inject directly into your computer's OS clipboard:
            </p>

            <div className="relative">
              <textarea
                value={textToPush}
                onChange={(e) => setTextToPush(e.target.value)}
                placeholder="Enter text, URL, credentials, or commands to send to PC..."
                rows={5}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-slate-100 font-mono focus:outline-none focus:border-cyan-500 resize-none"
              />
              <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1 px-1">
                <span>{textToPush.length} characters</span>
                <button
                  type="button"
                  onClick={() => setTextToPush('')}
                  className="hover:text-slate-200"
                >
                  Clear
                </button>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="mt-3">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                Quick Text Presets:
              </span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                <button
                  type="button"
                  onClick={() => setTextToPush('https://ai.google.dev')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded"
                >
                  🌐 URL Link
                </button>
                <button
                  type="button"
                  onClick={() => setTextToPush('WIFI:S:MyLocalNet;T:WPA;P:SuperSecretPass;;')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded"
                >
                  📶 Wi-Fi Config
                </button>
                <button
                  type="button"
                  onClick={() => setTextToPush('749201')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded"
                >
                  🔑 2FA Code
                </button>
                <button
                  type="button"
                  onClick={() => setTextToPush('git pull && npm run build')}
                  className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded"
                >
                  💻 Shell Cmd
                </button>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 space-y-2">
            <button
              type="button"
              onClick={() => handlePushToPc(textToPush)}
              disabled={isPushing || !textToPush.trim()}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-sm font-semibold transition shadow-lg shadow-cyan-600/20 disabled:opacity-50"
            >
              <Upload className="w-4 h-4" />
              {isPushing ? 'Transmitting...' : 'Send to PC Clipboard'}
            </button>
            <button
              type="button"
              onClick={handleDeviceClipboardToPc}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 rounded-xl text-xs font-medium transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Read Device Clipboard & Send
            </button>
          </div>
        </div>

        {/* Column 2: Pull from PC (PASTE) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-base">Pull PC Clipboard</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {`{"cmd": "PASTE"}`}
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              Read current text stored in your host PC's operating system clipboard:
            </p>

            <div className="bg-slate-950 border border-slate-700 rounded-xl p-3 h-[140px] overflow-y-auto font-mono text-sm text-slate-200">
              {currentPcText ? (
                <div className="whitespace-pre-wrap break-all">{currentPcText}</div>
              ) : (
                <span className="text-slate-600 italic">Host PC clipboard is currently empty</span>
              )}
            </div>

            <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1 px-1">
              <span>{currentPcText.length} characters on PC</span>
              <span className="text-emerald-400/80">Active in PC RAM</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 space-y-2">
            <button
              type="button"
              onClick={() => handleCopyToLocalDevice(currentPcText)}
              disabled={!currentPcText}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-semibold transition shadow-lg shadow-emerald-600/20 disabled:opacity-50"
            >
              {copiedSuccess ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copiedSuccess ? 'Copied to Phone!' : 'Copy to Local Device'}
            </button>
            <button
              type="button"
              onClick={handlePullFromPc}
              disabled={isPulling}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 rounded-xl text-xs font-medium transition disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              {isPulling ? 'Fetching...' : 'Query PC Clipboard Now'}
            </button>
          </div>
        </div>
      </div>

      {/* Sync History Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base">Clipboard Sync History</h3>
          </div>
          <button
            type="button"
            onClick={() => setHistory([])}
            className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 transition"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear History
          </button>
        </div>

        {history.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            No clipboard transactions recorded in this session.
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {history.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="flex items-start sm:items-center gap-2.5 min-w-0">
                  <span
                    className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-semibold whitespace-nowrap ${
                      item.direction === 'to_pc'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}
                  >
                    {item.direction === 'to_pc' ? 'Phone → PC' : 'PC → Phone'}
                  </span>
                  <div className="font-mono text-xs text-slate-200 truncate max-w-md">
                    {item.text}
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center text-xs">
                  <span className="text-slate-500 text-[11px] font-mono">{item.charCount} chars</span>
                  <span className="text-slate-500 text-[11px] font-mono">{item.timestamp}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyToLocalDevice(item.text)}
                    className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-100 transition"
                    title="Copy text"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePushToPc(item.text)}
                    className="p-1.5 hover:bg-slate-800 rounded text-cyan-400 hover:text-cyan-300 transition"
                    title="Re-send to PC"
                  >
                    <Upload className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
