import { useEffect, useRef, useState } from "react";
import { Coins, Heart, RotateCcw, Volume2, VolumeX, Zap } from "lucide-react";
import { Game, type Hud } from "@/game/engine";
import {
  BEST_KEY,
  START_GOLD,
  START_LIVES,
  TOWER_ORDER,
  TOWERS,
  WAVE_COUNT,
  type AimMode,
  type TowerKind,
} from "@/game/data";

const AIM_LABEL: { id: AimMode; label: string }[] = [
  { id: "first", label: "Erster" },
  { id: "last", label: "Letzter" },
  { id: "strong", label: "Stärkster" },
  { id: "near", label: "Nächster" },
];

function readBest(): number {
  if (typeof window === "undefined") return 0;
  const n = Number(window.localStorage.getItem(BEST_KEY) || 0);
  return Number.isFinite(n) ? n : 0;
}

function initialHud(): Hud {
  return {
    phase: "menu",
    lives: START_LIVES,
    gold: START_GOLD,
    wave: 0,
    wavesTotal: WAVE_COUNT,
    enemiesLeft: 0,
    canStart: false,
    preview: "",
    speed: 1,
    muted: false,
    armed: null,
    selected: null,
    hint: "Die Bandwürmer marschieren. Donny zählt auf die Türme.",
    bestWave: readBest(),
  };
}

function pips(rank: number) {
  return (
    <span className="inline-flex gap-1" aria-hidden="true">
      {[0, 1, 2].map((i) => (
        <span key={i} className={i < rank ? "h-1.5 w-4 rounded-full bg-gold" : "h-1.5 w-4 rounded-full bg-line"} />
      ))}
    </span>
  );
}

export function GameScreen() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [hud, setHud] = useState<Hud>(initialHud);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, setHud);
    gameRef.current = game;
    game.start();
    return () => {
      game.stop();
      gameRef.current = null;
    };
  }, []);

  const game = () => gameRef.current;
  const playing = hud.phase === "playing";
  const status =
    hud.phase === "win"
      ? "Sieg. Donny bleibt unangetastet."
      : hud.phase === "over"
        ? "Niederlage. Die Würmer sind durch."
        : hud.phase === "menu"
          ? "Bereit."
          : `Welle ${hud.wave} von ${hud.wavesTotal}. ${hud.lives} Leben. ${hud.gold} Gold.`;

  return (
    <main className="shell">
      <header className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <div className="min-w-0">
          <p className="font-display text-xl leading-none text-fg">Donnys Arschwehr</p>
          <p className="truncate text-xs text-muted">{hud.hint}</p>
        </div>
        <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
          <span className="inline-flex h-11 items-center gap-1.5 rounded-full bg-surface px-3 text-sm">
            <Heart className="size-4 text-danger" aria-hidden="true" />
            <span className="font-display text-base">{hud.lives}</span>
            <span className="sr-only">Leben</span>
          </span>
          <span className="inline-flex h-11 items-center gap-1.5 rounded-full bg-surface px-3 text-sm">
            <Coins className="size-4 text-gold" aria-hidden="true" />
            <span className="font-display text-base text-gold">{hud.gold}</span>
            <span className="sr-only">Gold</span>
          </span>
          <span className="inline-flex h-11 items-center rounded-full bg-surface px-3 font-display text-sm">
            Welle {hud.wave > 0 ? hud.wave : "–"}/{hud.wavesTotal}
          </span>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-1 rounded-full bg-surface px-3 text-sm text-fg disabled:opacity-40"
            onClick={() => game()?.toggleSpeed()}
            disabled={!playing}
            aria-label={hud.speed === 1 ? "Doppelte Geschwindigkeit" : "Normale Geschwindigkeit"}
          >
            <Zap className="size-4 text-slime" aria-hidden="true" />
            {hud.speed}×
          </button>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full bg-surface text-fg"
            onClick={() => game()?.toggleMute()}
            aria-label={hud.muted ? "Ton an" : "Ton aus"}
          >
            {hud.muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </button>
        </div>
      </header>

      <section className="stage">
        <div className="board-wrap">
          <canvas ref={canvasRef} className="board" aria-label="Schlachtfeld" />
          {hud.phase !== "playing" && (
            <div className="absolute inset-0 grid place-items-center p-3">
              <div className="overlay-card w-full max-w-md rounded-lg border border-line bg-surface px-5 py-5 text-fg shadow-lg">
                {hud.phase === "menu" ? (
                  <>
                    <p className="font-display text-3xl leading-none">Halt den Ausgang dicht</p>
                    <p className="mt-3 text-sm text-muted">
                      Bandwürmer kriechen den Schleimweg entlang auf Donny zu. Setze Türme daneben, kassiere Gold
                      für jeden Abschuss und verbessere Schaden sowie Feuerrate. Zwölf Wellen. Der Königswurm kommt
                      zuletzt.
                    </p>
                    <ul className="mt-3 space-y-1 text-sm text-fg">
                      <li>Spritzer hält die frühen Wellen. Scharfschütze reicht weit.</li>
                      <li>Säure frisst Panzerung. Kleber bremst Raser.</li>
                      <li>Leben oben links. Ein Durchbruch kostet welche.</li>
                    </ul>
                    {hud.bestWave > 0 && (
                      <p className="mt-3 text-xs text-gold">Beste Runde: Welle {hud.bestWave}</p>
                    )}
                    <button
                      type="button"
                      className="mt-4 h-12 w-full rounded-full bg-slime font-display text-lg text-ink"
                      onClick={() => game()?.begin()}
                    >
                      Stellung beziehen
                    </button>
                  </>
                ) : (
                  <>
                    <p className="font-display text-3xl leading-none">
                      {hud.phase === "win" ? "Donny bleibt dicht" : "Durchbruch"}
                    </p>
                    <p className="mt-3 text-sm text-muted">
                      {hud.phase === "win"
                        ? "Welle 12 ist Geschichte. Kein Königswurm hat es bis zum Ende geschafft."
                        : "Die Würmer sind angekommen. Donny ist wenig begeistert. Neue Türme, neue Runde."}
                    </p>
                    <p className="mt-3 font-display text-lg">
                      Welle {hud.wave}/{hud.wavesTotal}
                      {hud.bestWave > 0 ? ` · Bestleistung ${hud.bestWave}` : ""}
                    </p>
                    <button
                      type="button"
                      className="mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-gold font-display text-lg text-ink"
                      onClick={() => game()?.restart()}
                    >
                      <RotateCcw className="size-5" aria-hidden="true" />
                      Nochmal
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      <footer className="border-t border-line bg-bg px-3 pt-2 pb-3">
        <p className="sr-only" aria-live="polite">
          {status}
        </p>
        {hud.selected && playing && (
          <div className="mb-2 flex flex-wrap items-center gap-2 rounded-lg bg-surface px-3 py-2">
            <div className="min-w-36">
              <p className="font-display text-base leading-none">{hud.selected.name}</p>
              <p className="text-xs text-muted">
                {hud.selected.damage} Schaden · {hud.selected.rate}/s
              </p>
            </div>
            <button
              type="button"
              className="inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm disabled:opacity-40"
              disabled={hud.selected.dmgCost == null || hud.gold < (hud.selected.dmgCost ?? 0)}
              onClick={() => game()?.upgrade("dmg")}
            >
              <span>Schaden</span>
              {pips(hud.selected.dmgRank)}
              <span className="text-gold">{hud.selected.dmgCost == null ? "Max" : hud.selected.dmgCost}</span>
            </button>
            <button
              type="button"
              className="inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm disabled:opacity-40"
              disabled={hud.selected.rateCost == null || hud.gold < (hud.selected.rateCost ?? 0)}
              onClick={() => game()?.upgrade("rate")}
            >
              <span>Feuerrate</span>
              {pips(hud.selected.rateRank)}
              <span className="text-gold">{hud.selected.rateCost == null ? "Max" : hud.selected.rateCost}</span>
            </button>
            <label className="inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm">
              Ziel
              <select
                className="bg-transparent text-fg outline-none"
                value={hud.selected.aim}
                onChange={(e) => game()?.setAim(e.target.value as AimMode)}
              >
                {AIM_LABEL.map((opt) => (
                  <option key={opt.id} value={opt.id} className="bg-surface text-fg">
                    {opt.label}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="inline-flex h-11 items-center rounded-full bg-danger px-3 text-sm text-fg"
              onClick={() => game()?.sell()}
            >
              Verkaufen +{hud.selected.sell}
            </button>
          </div>
        )}

        <div className="flex flex-wrap items-stretch gap-2">
          <div className="grid min-w-0 flex-1 grid-cols-4 gap-2">
            {TOWER_ORDER.map((kind) => (
              <TowerButton
                key={kind}
                kind={kind}
                armed={hud.armed === kind}
                gold={hud.gold}
                disabled={!playing}
                onArm={() => game()?.arm(kind)}
              />
            ))}
          </div>
          <button
            type="button"
            className="h-auto min-h-16 min-w-36 flex-1 rounded-lg bg-slime px-3 font-display text-base text-ink disabled:opacity-40 sm:flex-none sm:px-5"
            disabled={!hud.canStart}
            onClick={() => game()?.startWave()}
          >
            <span className="block">
              {hud.canStart ? `Welle ${hud.wave + 1} starten` : hud.phase === "playing" ? "Welle läuft" : "Bereit machen"}
            </span>
            {hud.preview && <span className="block text-xs font-sans font-semibold">{hud.preview}</span>}
          </button>
        </div>
      </footer>
    </main>
  );
}

function TowerButton({
  kind,
  armed,
  gold,
  disabled,
  onArm,
}: {
  kind: TowerKind;
  armed: boolean;
  gold: number;
  disabled: boolean;
  onArm: () => void;
}) {
  const def = TOWERS[kind];
  const poor = gold < def.cost;
  return (
    <button
      type="button"
      disabled={disabled}
      aria-pressed={armed}
      aria-label={`${def.name}, ${def.cost} Gold. ${def.blurb}`}
      onClick={onArm}
      className={
        armed
          ? "flex min-h-16 flex-col items-center justify-center gap-0.5 rounded-lg border border-slime bg-surface-2 px-1 py-1.5 text-fg"
          : "flex min-h-16 flex-col items-center justify-center gap-0.5 rounded-lg border border-line bg-surface px-1 py-1.5 text-fg disabled:opacity-40"
      }
    >
      <img src={`/game/tower-${kind}.png`} alt="" className="size-9 object-contain" />
      <span className="font-display text-xs leading-none sm:text-sm">{def.short}</span>
      <span className={poor ? "text-xs text-danger" : "text-xs text-gold"}>{def.cost}</span>
    </button>
  );
}
