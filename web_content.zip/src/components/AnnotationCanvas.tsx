import React, { useRef, useState, useEffect } from 'react';
import { PenTool, Highlighter, Square, ArrowUpRight, Eraser, RotateCcw, Trash2, X } from 'lucide-react';

interface AnnotationCanvasProps {
  isOpen: boolean;
  onClose: () => void;
}

type ToolMode = 'pen' | 'highlighter' | 'arrow' | 'rect' | 'eraser';

const COLORS = ['#EF4444', '#3B82F6', '#EAB308', '#22C55E', '#FFFFFF'];

export const AnnotationCanvas: React.FC<AnnotationCanvasProps> = ({ isOpen, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<ToolMode>('pen');
  const [color, setColor] = useState<string>('#EF4444');
  const [lineWidth, setLineWidth] = useState<number>(4);
  const [history, setHistory] = useState<ImageData[]>([]);

  const isDrawingRef = useRef(false);
  const startPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const snapshotRef = useRef<ImageData | null>(null);

  // Resize canvas to window dimensions
  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }

    const handleResize = () => {
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const tempImg = ctx.getImageData(0, 0, canvas.width, canvas.height);
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      ctx.putImageData(tempImg, 0, 0);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isOpen]);

  const saveStateToHistory = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setHistory((prev) => [...prev.slice(-15), ctx.getImageData(0, 0, canvas.width, canvas.height)]);
  };

  const undo = () => {
    const canvas = canvasRef.current;
    if (!canvas || history.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = [...history];
    const previous = newHistory.pop();
    setHistory(newHistory);

    if (previous) {
      ctx.putImageData(previous, 0, 0);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    saveStateToHistory();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    saveStateToHistory();
    isDrawingRef.current = true;
    startPosRef.current = { x: e.clientX, y: e.clientY };

    if (tool === 'rect' || tool === 'arrow') {
      snapshotRef.current = ctx.getImageData(0, 0, canvas.width, canvas.height);
    } else {
      ctx.beginPath();
      ctx.moveTo(e.clientX, e.clientY);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = lineWidth * 4;
      ctx.lineTo(e.clientX, e.clientY);
      ctx.stroke();
    } else if (tool === 'pen') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.lineTo(e.clientX, e.clientY);
      ctx.stroke();
    } else if (tool === 'highlighter') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color + '66'; // 40% alpha
      ctx.lineWidth = lineWidth * 3;
      ctx.lineTo(e.clientX, e.clientY);
      ctx.stroke();
    } else if (tool === 'rect' && snapshotRef.current) {
      ctx.putImageData(snapshotRef.current, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      const width = e.clientX - startPosRef.current.x;
      const height = e.clientY - startPosRef.current.y;
      ctx.strokeRect(startPosRef.current.x, startPosRef.current.y, width, height);
    } else if (tool === 'arrow' && snapshotRef.current) {
      ctx.putImageData(snapshotRef.current, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = lineWidth;

      const fromX = startPosRef.current.x;
      const fromY = startPosRef.current.y;
      const toX = e.clientX;
      const toY = e.clientY;

      // Draw arrow line
      ctx.beginPath();
      ctx.moveTo(fromX, fromY);
      ctx.lineTo(toX, toY);
      ctx.stroke();

      // Arrow head
      const angle = Math.atan2(toY - fromY, toX - fromX);
      const headLen = 14;
      ctx.beginPath();
      ctx.moveTo(toX, toY);
      ctx.lineTo(toX - headLen * Math.cos(angle - Math.PI / 6), toY - headLen * Math.sin(angle - Math.PI / 6));
      ctx.lineTo(toX - headLen * Math.cos(angle + Math.PI / 6), toY - headLen * Math.sin(angle + Math.PI / 6));
      ctx.closePath();
      ctx.fill();
    }
  };

  const handlePointerUp = () => {
    isDrawingRef.current = false;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none">
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="w-full h-full pointer-events-auto cursor-crosshair touch-none"
      />

      {/* Floating Brush Toolbar */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 pointer-events-auto flex items-center gap-1.5 p-2 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-md">
        {/* Tool Selectors */}
        <div className="flex items-center gap-1 pr-2 border-r border-slate-700">
          <button
            onClick={() => setTool('pen')}
            title="Pen"
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              tool === 'pen' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <PenTool className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTool('highlighter')}
            title="Highlighter"
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              tool === 'highlighter' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Highlighter className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTool('rect')}
            title="Rectangle Box"
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              tool === 'rect' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Square className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTool('arrow')}
            title="Arrow"
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              tool === 'arrow' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <ArrowUpRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTool('eraser')}
            title="Eraser"
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              tool === 'eraser' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Eraser className="w-4 h-4" />
          </button>
        </div>

        {/* Colors */}
        <div className="flex items-center gap-1.5 px-2 pr-3 border-r border-slate-700">
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              style={{ backgroundColor: c }}
              className={`w-6 h-6 rounded-full transition-transform cursor-pointer ${
                color === c ? 'scale-125 ring-2 ring-white shadow-md' : 'hover:scale-110 opacity-80'
              }`}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={undo}
            title="Undo"
            className="p-2 rounded-xl text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={clearCanvas}
            title="Clear all"
            className="p-2 rounded-xl text-red-400 hover:bg-red-950/60 transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            title="Close brush"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer ml-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
