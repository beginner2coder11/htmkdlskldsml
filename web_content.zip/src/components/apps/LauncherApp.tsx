import { useState } from 'react';
import { PC_APPLICATIONS } from '../../data/defaultApps';
import { PCApplication, AppId } from '../../types/os';
import {
  Activity,
  Terminal,
  Gauge,
  Cpu,
  Server,
  Shield,
  Code,
  Sparkles,
  FileText,
  GitBranch,
  Calculator,
  Folder,
  Settings,
  Palette,
  HardDrive,
  Music,
  MessageSquare,
  Hash,
  Gamepad2,
  Video,
  Globe,
  Mail,
  Copy,
  Check,
  ExternalLink,
  Play,
  Monitor,
  Laptop,
  Search,
} from 'lucide-react';

interface LauncherAppProps {
  onOpenVirtualApp: (appId: AppId) => void;
  onRunCommand: (command: string) => void;
}

const ICON_MAP: Record<string, typeof Activity> = {
  Activity,
  Terminal,
  Gauge,
  Cpu,
  Server,
  Shield,
  Code,
  Sparkles,
  FileText,
  GitBranch,
  Calculator,
  Folder,
  Settings,
  Palette,
  HardDrive,
  Music,
  MessageSquare,
  Hash,
  Gamepad2,
  Video,
  Globe,
  Mail,
};

export function LauncherApp({ onOpenVirtualApp, onRunCommand }: LauncherAppProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [launchFeedback, setLaunchFeedback] = useState<string | null>(null);

  const categories = ['All', 'System Tools', 'Productivity & Code', 'Media & Social', 'Utilities', 'Browsers & Web'];

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setLaunchFeedback(`Copied "${text}" for ${label} to clipboard!`);
    setTimeout(() => {
      setCopiedCmd(null);
      setLaunchFeedback(null);
    }, 2500);
  };

  const handleLaunchApp = (app: PCApplication) => {
    // If it supports virtual app and targetAppId exists, launch virtual window
    if (app.isVirtualSupported && app.targetAppId) {
      onOpenVirtualApp(app.targetAppId);
      setLaunchFeedback(`Launched virtual ${app.name}`);
      setTimeout(() => setLaunchFeedback(null), 2000);
      return;
    }

    // If it has protocol URI, attempt to trigger it on physical machine
    if (app.protocolUri) {
      try {
        window.location.href = app.protocolUri;
        setLaunchFeedback(`Attempted protocol dispatch: ${app.protocolUri}`);
        setTimeout(() => setLaunchFeedback(null), 3000);
      } catch (err) {
        copyToClipboard(app.runCommand, app.name);
      }
      return;
    }

    // Otherwise, copy run command
    copyToClipboard(app.runCommand, app.name);
  };

  const handleRunHostDirect = (app: PCApplication) => {
    if (app.protocolUri) {
      window.location.href = app.protocolUri;
      setLaunchFeedback(`Opening ${app.name} on host PC via ${app.protocolUri}`);
      setTimeout(() => setLaunchFeedback(null), 3000);
    } else {
      copyToClipboard(app.runCommand, app.name);
    }
  };

  const filtered = PC_APPLICATIONS.filter((app) => {
    const matchesCat = selectedCategory === 'All' || app.category === selectedCategory;
    const matchesQuery =
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.executable.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.runCommand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Banner / Guidance */}
      <div className="bg-slate-900/90 border-b border-slate-800 p-4 shrink-0">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Laptop className="w-5 h-5 text-sky-400" />
              PC Application Launcher & Host Bridge
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Launch applications either in the interactive virtual PC desktop or directly on your physical computer via deep-link protocol handlers and Windows Run commands.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenVirtualApp('taskmgr')}
              className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Activity className="w-4 h-4" />
              Open Task Manager
            </button>
            <button
              onClick={() => onOpenVirtualApp('terminal')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Terminal className="w-4 h-4" />
              Open Command Prompt
            </button>
          </div>
        </div>

        {/* Feedback Bar */}
        {launchFeedback && (
          <div className="mt-3 px-3 py-1.5 bg-sky-950/80 border border-sky-800/80 rounded text-xs text-sky-300 flex items-center justify-between animate-fadeIn">
            <span>{launchFeedback}</span>
            <span className="text-[11px] text-sky-400 font-mono">Tip: Use ⊞ Win + R on your keyboard for Run commands</span>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/50 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-1 overflow-x-auto py-0.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded text-xs transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat
                  ? 'bg-slate-800 text-sky-400 font-semibold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-56 shrink-0">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search PC apps..."
            className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Application Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filtered.map((app) => {
            const Icon = ICON_MAP[app.iconName] || Activity;
            const isCopied = copiedCmd === app.runCommand;

            return (
              <div
                key={app.id}
                className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700 rounded-lg p-3.5 flex flex-col justify-between transition-all group hover:shadow-lg"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-sky-400 shrink-0">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-200 leading-tight">
                          {app.name}
                        </h4>
                        <span className="text-[11px] font-mono text-slate-500">{app.executable}</span>
                      </div>
                    </div>

                    {app.badge && (
                      <span className="text-[10px] text-sky-400 px-1.5 py-0.5 rounded bg-sky-950/60 border border-sky-800/50 whitespace-nowrap shrink-0">
                        {app.badge}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                    {app.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/70 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Run in Virtual Desktop button */}
                    {app.isVirtualSupported && app.targetAppId ? (
                      <button
                        onClick={() => app.targetAppId && onOpenVirtualApp(app.targetAppId)}
                        className="px-2.5 py-1 bg-sky-600/20 hover:bg-sky-600 text-sky-300 hover:text-white rounded text-xs font-medium transition-colors flex items-center gap-1 border border-sky-500/30"
                      >
                        <Play className="w-3 h-3" />
                        Run App
                      </button>
                    ) : (
                      <button
                        onClick={() => handleRunHostDirect(app)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium transition-colors flex items-center gap-1 border border-slate-700"
                        title="Launch via protocol or copy run command"
                      >
                        {app.protocolUri ? <ExternalLink className="w-3 h-3 text-sky-400" /> : <Play className="w-3 h-3" />}
                        Open PC
                      </button>
                    )}

                    {/* Copy Run command button */}
                    <button
                      onClick={() => copyToClipboard(app.runCommand, app.name)}
                      className={`px-2 py-1 rounded text-xs transition-colors flex items-center gap-1 border ${
                        isCopied
                          ? 'bg-emerald-950 border-emerald-800 text-emerald-300'
                          : 'border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                      title={`Copy Run Command: ${app.runCommand}`}
                    >
                      {isCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span className="font-mono text-[11px]">{app.runCommand}</span>
                    </button>
                  </div>

                  <span className="text-[11px] text-slate-500 font-mono">
                    {app.isVirtualSupported ? 'Virtual + Host' : 'Host Only'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Windows Run Dialog Quick Reference Card */}
        <div className="mt-6 bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Monitor className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-semibold text-slate-200">
                Direct Host PC Shortcuts (Press ⊞ Win + R)
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">Click any command to copy instantly</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 text-xs">
            {[
              { cmd: 'taskmgr', name: 'Task Manager' },
              { cmd: 'resmon', name: 'Resource Monitor' },
              { cmd: 'cmd', name: 'Command Prompt' },
              { cmd: 'powershell', name: 'PowerShell' },
              { cmd: 'calc', name: 'Calculator' },
              { cmd: 'notepad', name: 'Notepad' },
              { cmd: 'explorer', name: 'File Explorer' },
              { cmd: 'devmgmt.msc', name: 'Device Manager' },
              { cmd: 'services.msc', name: 'Windows Services' },
              { cmd: 'regedit', name: 'Registry Editor' },
              { cmd: 'cleanmgr', name: 'Disk Clean-up' },
              { cmd: 'perfmon', name: 'Performance Monitor' },
            ].map((item) => (
              <button
                key={item.cmd}
                onClick={() => copyToClipboard(item.cmd, item.name)}
                className="p-2 bg-slate-950/80 hover:bg-slate-800 border border-slate-800/80 rounded text-left transition-colors group flex flex-col justify-between"
              >
                <div className="text-[11px] text-slate-400 truncate">{item.name}</div>
                <div className="font-mono text-sky-400 font-medium group-hover:text-sky-300 mt-1 flex items-center justify-between">
                  <span>{item.cmd}</span>
                  <Copy className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 text-slate-400" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
