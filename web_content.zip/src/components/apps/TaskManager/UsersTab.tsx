import { UserCheck } from 'lucide-react';
import { ProcessItem } from '../../../types/os';

interface UsersTabProps {
  processes: ProcessItem[];
}

export function UsersTab({ processes }: UsersTabProps) {
  const userCpu = processes.filter(p => p.category === 'apps').reduce((acc, p) => acc + (p.cpu || 0), 0);
  const userMem = processes.filter(p => p.category === 'apps').reduce((acc, p) => acc + (p.memoryMb || 0), 0);

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden p-4">
      <div className="bg-slate-900 border border-slate-800 rounded p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-sky-600/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              DESKTOP-PC\Administrator
              <span className="text-[10px] text-emerald-400 font-mono px-1.5 py-0.5 bg-emerald-950/60 rounded border border-emerald-800/40">Active Session</span>
            </div>
            <div className="text-xs text-slate-400 font-mono">
              ID: 1 · Console · Windows 11 Pro 64-bit
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs font-mono text-right">
          <div>
            <div className="text-slate-400">Processes</div>
            <div className="text-slate-200 font-semibold">{processes.length}</div>
          </div>
          <div>
            <div className="text-slate-400">CPU</div>
            <div className="text-sky-400 font-semibold">{userCpu.toFixed(1)}%</div>
          </div>
          <div>
            <div className="text-slate-400">Memory</div>
            <div className="text-purple-400 font-semibold">{(userMem / 1024).toFixed(1)} GB</div>
          </div>
        </div>
      </div>
    </div>
  );
}
