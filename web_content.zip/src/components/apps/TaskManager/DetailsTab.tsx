import { useMemo, useState } from 'react';
import { ProcessItem } from '../../../types/os';

interface DetailsTabProps {
  processes: ProcessItem[];
  selectedPid: number | null;
  onSelectPid: (pid: number | null) => void;
  onEndProcess: (pid: number) => void;
  searchQuery: string;
}

export function DetailsTab({
  processes,
  selectedPid,
  onSelectPid,
  onEndProcess,
  searchQuery,
}: DetailsTabProps) {
  const [sortKey, setSortKey] = useState<keyof ProcessItem>('pid');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  const filtered = useMemo(() => {
    let list = processes;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.pid.toString().includes(q) ||
          p.publisher.toLowerCase().includes(q)
      );
    }

    return [...list].sort((a, b) => {
      const valA = a[sortKey] ?? 0;
      const valB = b[sortKey] ?? 0;
      if (typeof valA === 'string') {
        const cmp = (valA as string).localeCompare(valB as string);
        return sortAsc ? cmp : -cmp;
      }
      return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });
  }, [processes, searchQuery, sortKey, sortAsc]);

  const handleSort = (key: keyof ProcessItem) => {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden">
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead className="sticky top-0 bg-slate-900 text-slate-400 text-xs border-b border-slate-800 z-10 shadow-sm">
            <tr>
              <th
                onClick={() => handleSort('name')}
                className="py-2.5 pl-5 pr-3 font-semibold cursor-pointer hover:text-slate-200 w-[26%]"
              >
                Name {sortKey === 'name' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleSort('pid')}
                className="py-2.5 px-3 font-semibold cursor-pointer hover:text-slate-200 w-[12%]"
              >
                PID {sortKey === 'pid' && (sortAsc ? '▲' : '▼')}
              </th>
              <th className="py-2.5 px-3 font-semibold w-[14%]">Status</th>
              <th className="py-2.5 px-3 font-semibold w-[16%]">User Name</th>
              <th
                onClick={() => handleSort('cpu')}
                className="py-2.5 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[10%]"
              >
                CPU {sortKey === 'cpu' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleSort('memoryMb')}
                className="py-2.5 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[14%]"
              >
                Memory {sortKey === 'memoryMb' && (sortAsc ? '▲' : '▼')}
              </th>
              <th className="py-2.5 px-3 font-semibold w-[18%]">Architecture</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/40 text-xs font-mono">
            {filtered.map((proc) => {
              const isSelected = selectedPid === proc.pid;

              return (
                <tr
                  key={proc.pid}
                  onClick={() => onSelectPid(proc.pid)}
                  className={`group cursor-pointer transition-colors ${
                    isSelected ? 'bg-sky-950/60 text-sky-200' : 'hover:bg-slate-800/30 text-slate-300'
                  }`}
                >
                  <td className="py-1.5 pl-5 pr-3 font-sans font-medium text-slate-200 truncate">
                    {proc.name}
                  </td>
                  <td className="py-1.5 px-3 text-slate-400 tabular-nums">{proc.pid}</td>
                  <td className="py-1.5 px-3 text-slate-400 font-sans">{proc.status}</td>
                  <td className="py-1.5 px-3 text-slate-400 font-sans">
                    {proc.category === 'windows' ? 'SYSTEM' : 'DESKTOP-PC\\User'}
                  </td>
                  <td className="py-1.5 px-3 text-right tabular-nums text-slate-200">
                    {proc.cpu.toFixed(1)}%
                  </td>
                  <td className="py-1.5 px-3 text-right tabular-nums text-slate-200">
                    {proc.memoryMb.toFixed(1)} MB
                  </td>
                  <td className="py-1.5 px-3 text-slate-500">x64</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedPid && (
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-400">Selected PID: <strong className="font-mono text-slate-200">{selectedPid}</strong></span>
          </div>
          <button
            onClick={() => onEndProcess(selectedPid)}
            className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded font-medium transition-colors"
          >
            End Process
          </button>
        </div>
      )}
    </div>
  );
}
