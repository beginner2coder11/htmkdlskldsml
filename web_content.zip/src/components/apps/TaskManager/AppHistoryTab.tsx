export function AppHistoryTab() {
  const historyItems = [
    { name: 'Microsoft Edge', cpuTime: '1 hr 12 min', network: '1.4 GB', metered: '0 MB', tile: '0 MB' },
    { name: 'Task Manager', cpuTime: '0 hr 4 min', network: '12 MB', metered: '0 MB', tile: '0 MB' },
    { name: 'Visual Studio Code', cpuTime: '3 hr 45 min', network: '820 MB', metered: '0 MB', tile: '0 MB' },
    { name: 'Windows Terminal', cpuTime: '0 hr 18 min', network: '45 MB', metered: '0 MB', tile: '0 MB' },
    { name: 'Spotify Music', cpuTime: '2 hr 02 min', network: '380 MB', metered: '0 MB', tile: '0 MB' },
    { name: 'Calculator', cpuTime: '0 hr 01 min', network: '0 MB', metered: '0 MB', tile: '0 MB' },
    { name: 'Settings', cpuTime: '0 hr 03 min', network: '2 MB', metered: '0 MB', tile: '0 MB' },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden">
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2.5 flex items-center justify-between text-xs text-slate-400">
        <span>Resource usage since: <strong>October 26, 2026</strong></span>
        <button className="text-xs text-sky-400 hover:text-sky-300">Delete usage history</button>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead className="sticky top-0 bg-slate-900 text-slate-400 text-xs border-b border-slate-800 z-10 shadow-sm">
            <tr>
              <th className="py-2.5 pl-5 pr-3 font-semibold w-[40%]">Name</th>
              <th className="py-2.5 px-3 text-right font-semibold w-[20%]">CPU time</th>
              <th className="py-2.5 px-3 text-right font-semibold w-[20%]">Network</th>
              <th className="py-2.5 px-3 text-right font-semibold w-[20%]">Metered network</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/40 text-xs font-mono">
            {historyItems.map((item) => (
              <tr key={item.name} className="hover:bg-slate-800/30 text-slate-300">
                <td className="py-2 pl-5 pr-3 font-sans font-medium text-slate-200 truncate">
                  {item.name}
                </td>
                <td className="py-2 px-3 text-right text-slate-300 tabular-nums">{item.cpuTime}</td>
                <td className="py-2 px-3 text-right text-slate-300 tabular-nums">{item.network}</td>
                <td className="py-2 px-3 text-right text-slate-500 tabular-nums">{item.metered}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
