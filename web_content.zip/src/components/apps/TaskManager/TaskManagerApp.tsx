import { useState } from 'react';
import { ProcessItem, ProcessPriority, SystemTelemetry } from '../../../types/os';
import {
  Activity,
  BarChart2,
  Clock,
  FastForward,
  Users,
  List,
  Server,
  Play,
  RotateCw,
  Search,
  Leaf,
  Maximize2,
  Layers,
} from 'lucide-react';
import { ProcessesTab } from './ProcessesTab';
import { PerformanceTab } from './PerformanceTab';
import { StartupTab } from './StartupTab';
import { ServicesTab } from './ServicesTab';
import { DetailsTab } from './DetailsTab';
import { AppHistoryTab } from './AppHistoryTab';
import { UsersTab } from './UsersTab';

interface TaskManagerAppProps {
  telemetry: SystemTelemetry;
  processes: ProcessItem[];
  onEndProcess: (pid: number) => void;
  onSetPriority: (pid: number, priority: ProcessPriority) => void;
  onToggleEfficiency: (pid: number) => void;
  onOpenRunDialog: () => void;
}

type TabId = 'processes' | 'performance' | 'history' | 'startup' | 'users' | 'details' | 'services';

export function TaskManagerApp({
  telemetry,
  processes,
  onEndProcess,
  onSetPriority,
  onToggleEfficiency,
  onOpenRunDialog,
}: TaskManagerAppProps) {
  const [activeTab, setActiveTab] = useState<TabId>('processes');
  const [selectedPid, setSelectedPid] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [processSource, setProcessSource] = useState<'virtual' | 'server'>('virtual');
  const [serverProcesses, setServerProcesses] = useState<ProcessItem[]>([]);

  const fetchServerProcesses = () => {
    setIsRefreshing(true);
    fetch('/api/system/processes')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.processes)) {
          setServerProcesses(data.processes);
        }
      })
      .catch(() => {})
      .finally(() => setIsRefreshing(false));
  };

  const handleRefresh = () => {
    if (processSource === 'server') {
      fetchServerProcesses();
    } else {
      setIsRefreshing(true);
      setTimeout(() => setIsRefreshing(false), 300);
    }
  };

  const activeProcesses = processSource === 'server' ? (serverProcesses.length > 0 ? serverProcesses : processes) : processes;

  const handleEndTask = (pid: number) => {
    if (processSource === 'server') {
      fetch('/api/system/kill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pid }),
      })
        .then(() => fetchServerProcesses())
        .catch(() => {});
      setServerProcesses((prev) => prev.filter((p) => p.pid !== pid));
    } else {
      onEndProcess(pid);
    }
    setSelectedPid(null);
  };

  const tabs: { id: TabId; label: string; icon: typeof Activity }[] = [
    { id: 'processes', label: 'Processes', icon: Activity },
    { id: 'performance', label: 'Performance', icon: BarChart2 },
    { id: 'history', label: 'App history', icon: Clock },
    { id: 'startup', label: 'Startup apps', icon: FastForward },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'details', label: 'Details', icon: List },
    { id: 'services', label: 'Services', icon: Server },
  ];

  const selectedProcess = activeProcesses.find((p) => p.pid === selectedPid);

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Windows 11 Command Bar */}
      <div className="h-11 bg-slate-900 border-b border-slate-800/90 px-3 flex items-center justify-between gap-3 shrink-0">
        {/* Left Actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenRunDialog}
            className="px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white hover:bg-slate-800 rounded transition-colors flex items-center gap-1.5 border border-slate-700/60"
          >
            <Play className="w-3.5 h-3.5 text-sky-400" />
            <span>Run new task</span>
          </button>

          <button
            disabled={!selectedPid}
            onClick={() => selectedPid && handleEndTask(selectedPid)}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 border ${
              selectedPid
                ? 'bg-rose-950/80 hover:bg-rose-900 border-rose-700/60 text-rose-200'
                : 'border-transparent text-slate-600 cursor-not-allowed'
            }`}
          >
            <span>End task</span>
          </button>

          <button
            disabled={!selectedPid}
            onClick={() => selectedPid && onToggleEfficiency(selectedPid)}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 border ${
              selectedPid
                ? 'hover:bg-slate-800 border-slate-700/60 text-slate-200'
                : 'border-transparent text-slate-600 cursor-not-allowed'
            }`}
          >
            <Leaf className={`w-3.5 h-3.5 ${selectedProcess?.status === 'Efficiency Mode' ? 'text-emerald-400' : 'text-slate-400'}`} />
            <span>Efficiency mode</span>
          </button>

          <button
            onClick={handleRefresh}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Refresh now"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-sky-400' : ''}`} />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Mode Switcher: Virtual OS vs Live Server */}
          <div className="flex bg-slate-950 border border-slate-800 rounded p-0.5 text-xs">
            <button
              onClick={() => setProcessSource('virtual')}
              className={`px-2 py-0.5 rounded transition-colors ${
                processSource === 'virtual'
                  ? 'bg-sky-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Virtual OS
            </button>
            <button
              onClick={() => {
                setProcessSource('server');
                fetchServerProcesses();
              }}
              className={`px-2 py-0.5 rounded transition-colors flex items-center gap-1 ${
                processSource === 'server'
                  ? 'bg-sky-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Server className="w-3 h-3 text-emerald-400" />
              <span>Host Server</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search processes..."
            className="w-full bg-slate-950/80 border border-slate-800 rounded pl-8 pr-3 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Main Area: Left Nav Rail + Right Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Navigation Rail (Windows 11 Task Manager style) */}
        <div className="w-48 bg-slate-900/90 border-r border-slate-800/80 py-2 px-1.5 flex flex-col justify-between shrink-0">
          <div className="space-y-0.5">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs transition-colors ${
                    isActive
                      ? 'bg-slate-800 text-sky-400 font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="p-2 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono">
            <div>{processSource === 'server' ? 'Host Server OS' : 'Windows 11 OS'}</div>
            <div>PID Table: {activeProcesses.length}</div>
          </div>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-hidden relative">
          {activeTab === 'processes' && (
            <ProcessesTab
              processes={activeProcesses}
              selectedPid={selectedPid}
              onSelectPid={setSelectedPid}
              onEndProcess={handleEndTask}
              onSetPriority={onSetPriority}
              onToggleEfficiency={onToggleEfficiency}
              searchQuery={searchQuery}
            />
          )}

          {activeTab === 'performance' && (
            <PerformanceTab telemetry={telemetry} />
          )}

          {activeTab === 'history' && (
            <AppHistoryTab />
          )}

          {activeTab === 'startup' && (
            <StartupTab />
          )}

          {activeTab === 'users' && (
            <UsersTab processes={activeProcesses} />
          )}

          {activeTab === 'details' && (
            <DetailsTab
              processes={activeProcesses}
              selectedPid={selectedPid}
              onSelectPid={setSelectedPid}
              onEndProcess={handleEndTask}
              searchQuery={searchQuery}
            />
          )}

          {activeTab === 'services' && (
            <ServicesTab searchQuery={searchQuery} />
          )}
        </div>
      </div>
    </div>
  );
}
