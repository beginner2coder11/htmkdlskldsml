import { useState } from 'react';
import { SystemTelemetry } from '../../../types/os';
import { Cpu, HardDrive, Wifi, MemoryStick, MonitorPlay } from 'lucide-react';

interface PerformanceTabProps {
  telemetry: SystemTelemetry;
}

type MetricCategory = 'cpu' | 'memory' | 'disk' | 'network' | 'gpu';

export function PerformanceTab({ telemetry }: PerformanceTabProps) {
  const [selectedMetric, setSelectedMetric] = useState<MetricCategory>('cpu');
  const [cpuViewMode, setCpuViewMode] = useState<'overall' | 'logical'>('overall');

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${days}:${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Helper to render SVG sparkline graph
  const renderGraph = (data: number[], maxVal = 100, stroke = '#38bdf8', fill = 'rgba(56, 189, 248, 0.15)') => {
    const width = 600;
    const height = 240;
    const step = width / (data.length - 1);

    const points = data.map((val, idx) => {
      const x = idx * step;
      const normalized = Math.min(maxVal, Math.max(0, val));
      const y = height - (normalized / maxVal) * (height - 10) - 5;
      return `${x},${y}`;
    });

    const pathData = `M 0,${height} L ${points.join(' L ')} L ${width},${height} Z`;
    const lineData = `M ${points.join(' L ')}`;

    return (
      <div className="relative w-full h-60 bg-slate-900/90 rounded border border-slate-800/80 overflow-hidden shadow-inner">
        {/* Subtle grid lines */}
        <div className="absolute inset-0 grid grid-rows-4 grid-cols-6 pointer-events-none">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="border-b border-r border-slate-800/40" />
          ))}
        </div>

        <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="w-full h-full relative z-10">
          <defs>
            <linearGradient id={`grad-${selectedMetric}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={stroke} stopOpacity="0.35" />
              <stop offset="100%" stopColor={stroke} stopOpacity="0.02" />
            </linearGradient>
          </defs>
          <path d={pathData} fill={`url(#grad-${selectedMetric})`} />
          <path d={lineData} fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>

        <div className="absolute top-2 right-3 text-xs font-mono tabular-nums text-slate-400">
          60 seconds
        </div>
        <div className="absolute bottom-2 left-3 text-xs font-mono tabular-nums text-slate-400">
          0 %
        </div>
        <div className="absolute top-2 left-3 text-xs font-mono tabular-nums text-slate-400">
          100 %
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-full bg-slate-950/60 overflow-hidden select-none">
      {/* Left Sidebar Metrics List */}
      <div className="w-64 border-r border-slate-800/80 bg-slate-900/40 p-2 space-y-1.5 overflow-y-auto shrink-0">
        {/* CPU Item */}
        <button
          onClick={() => setSelectedMetric('cpu')}
          className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between border ${
            selectedMetric === 'cpu'
              ? 'bg-slate-800/90 border-sky-500/50 shadow-sm'
              : 'border-transparent hover:bg-slate-800/40 text-slate-400'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <Cpu className="w-5 h-5 text-sky-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-medium text-slate-200">CPU</div>
              <div className="text-xs text-slate-400 truncate font-mono tabular-nums">
                {telemetry.cpuUsage.toFixed(0)}% {telemetry.cpuFreqGhz} GHz
              </div>
            </div>
          </div>
          <div className="w-14 h-8 bg-slate-950 rounded border border-slate-800 flex items-end p-0.5 shrink-0 overflow-hidden">
            <div
              className="w-full bg-sky-500 transition-all duration-500"
              style={{ height: `${Math.max(5, telemetry.cpuUsage)}%` }}
            />
          </div>
        </button>

        {/* Memory Item */}
        <button
          onClick={() => setSelectedMetric('memory')}
          className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between border ${
            selectedMetric === 'memory'
              ? 'bg-slate-800/90 border-purple-500/50 shadow-sm'
              : 'border-transparent hover:bg-slate-800/40 text-slate-400'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <MemoryStick className="w-5 h-5 text-purple-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-medium text-slate-200">Memory</div>
              <div className="text-xs text-slate-400 truncate font-mono tabular-nums">
                {telemetry.memoryUsedGb.toFixed(1)}/{telemetry.memoryTotalGb.toFixed(0)} GB ({Math.round((telemetry.memoryUsedGb / telemetry.memoryTotalGb) * 100)}%)
              </div>
            </div>
          </div>
          <div className="w-14 h-8 bg-slate-950 rounded border border-slate-800 flex items-end p-0.5 shrink-0 overflow-hidden">
            <div
              className="w-full bg-purple-500 transition-all duration-500"
              style={{ height: `${(telemetry.memoryUsedGb / telemetry.memoryTotalGb) * 100}%` }}
            />
          </div>
        </button>

        {/* Disk 0 Item */}
        <button
          onClick={() => setSelectedMetric('disk')}
          className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between border ${
            selectedMetric === 'disk'
              ? 'bg-slate-800/90 border-emerald-500/50 shadow-sm'
              : 'border-transparent hover:bg-slate-800/40 text-slate-400'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <HardDrive className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-medium text-slate-200">Disk 0 (C: SSD)</div>
              <div className="text-xs text-slate-400 truncate font-mono tabular-nums">
                {telemetry.diskActivePct.toFixed(0)}%
              </div>
            </div>
          </div>
          <div className="w-14 h-8 bg-slate-950 rounded border border-slate-800 flex items-end p-0.5 shrink-0 overflow-hidden">
            <div
              className="w-full bg-emerald-500 transition-all duration-500"
              style={{ height: `${Math.max(5, telemetry.diskActivePct)}%` }}
            />
          </div>
        </button>

        {/* Network Item */}
        <button
          onClick={() => setSelectedMetric('network')}
          className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between border ${
            selectedMetric === 'network'
              ? 'bg-slate-800/90 border-amber-500/50 shadow-sm'
              : 'border-transparent hover:bg-slate-800/40 text-slate-400'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <Wifi className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-medium text-slate-200">Wi-Fi 6</div>
              <div className="text-xs text-slate-400 truncate font-mono tabular-nums">
                S: {telemetry.networkSendKbps} R: {telemetry.networkRecvKbps} Kbps
              </div>
            </div>
          </div>
          <div className="w-14 h-8 bg-slate-950 rounded border border-slate-800 flex items-end p-0.5 shrink-0 overflow-hidden">
            <div
              className="w-full bg-amber-500 transition-all duration-500"
              style={{ height: `${Math.min(100, (telemetry.networkRecvKbps / 300) * 100)}%` }}
            />
          </div>
        </button>

        {/* GPU Item */}
        <button
          onClick={() => setSelectedMetric('gpu')}
          className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between border ${
            selectedMetric === 'gpu'
              ? 'bg-slate-800/90 border-cyan-500/50 shadow-sm'
              : 'border-transparent hover:bg-slate-800/40 text-slate-400'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <MonitorPlay className="w-5 h-5 text-cyan-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-medium text-slate-200">GPU 0 (NVIDIA RTX)</div>
              <div className="text-xs text-slate-400 truncate font-mono tabular-nums">
                {telemetry.gpuUsagePct}% ({telemetry.gpuTempC}°C)
              </div>
            </div>
          </div>
          <div className="w-14 h-8 bg-slate-950 rounded border border-slate-800 flex items-end p-0.5 shrink-0 overflow-hidden">
            <div
              className="w-full bg-cyan-500 transition-all duration-500"
              style={{ height: `${Math.max(5, telemetry.gpuUsagePct)}%` }}
            />
          </div>
        </button>
      </div>

      {/* Main Metric Detail View */}
      <div className="flex-1 p-5 overflow-y-auto">
        {selectedMetric === 'cpu' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-xl font-bold text-slate-100 tracking-tight">CPU</h3>
                <p className="text-xs text-slate-400">12th Gen Intel(R) Core(TM) i7-12700H @ 2.70 GHz</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">View:</span>
                <div className="flex bg-slate-900 border border-slate-800 rounded p-0.5 text-xs">
                  <button
                    onClick={() => setCpuViewMode('overall')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      cpuViewMode === 'overall' ? 'bg-sky-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Overall utilization
                  </button>
                  <button
                    onClick={() => setCpuViewMode('logical')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      cpuViewMode === 'logical' ? 'bg-sky-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Logical processors (8)
                  </button>
                </div>
              </div>
            </div>

            {cpuViewMode === 'overall' ? (
              renderGraph(telemetry.history.cpu, 100, '#38bdf8')
            ) : (
              <div className="grid grid-cols-4 gap-2.5">
                {telemetry.cpuCores.map((load: number, idx: number) => (
                  <div key={idx} className="bg-slate-900/90 border border-slate-800/80 p-2 rounded">
                    <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                      <span>Core {idx}</span>
                      <span className="text-sky-400 tabular-nums font-semibold">{load}%</span>
                    </div>
                    <div className="h-16 bg-slate-950 rounded flex items-end p-0.5 overflow-hidden">
                      <div className="w-full bg-sky-500 transition-all duration-300" style={{ height: `${load}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Spec breakdown */}
            <div className="grid grid-cols-3 gap-6 pt-2 text-xs border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Utilization</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.cpuUsage.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Speed</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.cpuFreqGhz} GHz</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Processes</span>
                  <span className="font-mono tabular-nums text-slate-200">184</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Threads</span>
                  <span className="font-mono tabular-nums text-slate-200">2,419</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Handles</span>
                  <span className="font-mono tabular-nums text-slate-200">92,840</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Up time</span>
                  <span className="font-mono tabular-nums text-slate-200">{formatUptime(telemetry.uptimeSec)}</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Base speed</span>
                  <span className="font-mono tabular-nums text-slate-200">2.70 GHz</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Sockets / Cores</span>
                  <span className="font-mono tabular-nums text-slate-200">1 / 14 (8P + 6E)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Virtualization</span>
                  <span className="font-mono tabular-nums text-emerald-400">Enabled</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedMetric === 'memory' && (
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-xl font-bold text-slate-100 tracking-tight">Memory</h3>
              <p className="text-xs text-slate-400">32.0 GB DDR5 4800 MHz (2 of 2 slots used)</p>
            </div>

            {renderGraph(telemetry.history.memory, 100, '#a855f7')}

            <div className="grid grid-cols-3 gap-6 pt-2 text-xs border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">In use (Compressed)</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.memoryUsedGb.toFixed(1)} GB</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Available</span>
                  <span className="font-mono tabular-nums text-slate-200">{(telemetry.memoryTotalGb - telemetry.memoryUsedGb).toFixed(1)} GB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Committed</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.memoryCommittedGb.toFixed(1)}/36.4 GB</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Cached</span>
                  <span className="font-mono tabular-nums text-slate-200">4.8 GB</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Paged pool</span>
                  <span className="font-mono tabular-nums text-slate-200">624 MB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Non-paged pool</span>
                  <span className="font-mono tabular-nums text-slate-200">480 MB</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Speed</span>
                  <span className="font-mono tabular-nums text-slate-200">4800 MT/s</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Form factor</span>
                  <span className="font-mono tabular-nums text-slate-200">SODIMM</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Hardware reserved</span>
                  <span className="font-mono tabular-nums text-slate-200">182 MB</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedMetric === 'disk' && (
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-xl font-bold text-slate-100 tracking-tight">Disk 0 (C: SSD)</h3>
              <p className="text-xs text-slate-400">SAMSUNG MZVL21T0HCLR-00B00 NVMe PCIe 4.0 x4</p>
            </div>

            {renderGraph(telemetry.history.disk, 100, '#10b981')}

            <div className="grid grid-cols-3 gap-6 pt-2 text-xs border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Active time</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.diskActivePct.toFixed(0)}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Average response time</span>
                  <span className="font-mono tabular-nums text-slate-200">0.8 ms</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Read speed</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.diskReadKbps} KB/s</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Write speed</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.diskWriteKbps} KB/s</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Capacity</span>
                  <span className="font-mono tabular-nums text-slate-200">1024 GB (1.0 TB)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Formatted</span>
                  <span className="font-mono tabular-nums text-slate-200">953 GB (NTFS)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">System disk</span>
                  <span className="font-mono tabular-nums text-emerald-400">Yes</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Page file</span>
                  <span className="font-mono tabular-nums text-slate-200">Yes</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Type</span>
                  <span className="font-mono tabular-nums text-slate-200">NVMe SSD</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedMetric === 'network' && (
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-xl font-bold text-slate-100 tracking-tight">Wi-Fi (Wi-Fi 6 AX201)</h3>
              <p className="text-xs text-slate-400">Intel(R) Wi-Fi 6 AX201 160MHz - 802.11ax</p>
            </div>

            {renderGraph(telemetry.history.network, 100, '#f59e0b')}

            <div className="grid grid-cols-3 gap-6 pt-2 text-xs border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Send throughput</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.networkSendKbps} Kbps</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Receive throughput</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.networkRecvKbps} Kbps</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Connection type</span>
                  <span className="font-mono tabular-nums text-slate-200">802.11ax (Wi-Fi 6)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">IPv4 address</span>
                  <span className="font-mono tabular-nums text-slate-200">192.168.1.142</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Signal strength</span>
                  <span className="font-mono tabular-nums text-emerald-400">5 GHz (Excellent)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Link speed (Rx/Tx)</span>
                  <span className="font-mono tabular-nums text-slate-200">1201 / 1201 (Mbps)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">SSID</span>
                  <span className="font-mono tabular-nums text-slate-200">StudioNetwork_5G</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Protocol</span>
                  <span className="font-mono tabular-nums text-slate-200">WPA3-Personal</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Adapter state</span>
                  <span className="font-mono tabular-nums text-emerald-400">Operational</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedMetric === 'gpu' && (
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-xl font-bold text-slate-100 tracking-tight">GPU 0</h3>
              <p className="text-xs text-slate-400">NVIDIA GeForce RTX 4070 Laptop GPU (8.0 GB GDDR6)</p>
            </div>

            {renderGraph(telemetry.history.gpu, 100, '#06b6d4')}

            <div className="grid grid-cols-3 gap-6 pt-2 text-xs border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Utilization</span>
                  <span className="font-mono tabular-nums text-slate-200 font-semibold">{telemetry.gpuUsagePct}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">GPU Memory</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.gpuMemoryGb.toFixed(1)}/8.0 GB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Temperature</span>
                  <span className="font-mono tabular-nums text-slate-200">{telemetry.gpuTempC}°C</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Dedicated Memory</span>
                  <span className="font-mono tabular-nums text-slate-200">2.1 GB / 8.0 GB</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Shared GPU Memory</span>
                  <span className="font-mono tabular-nums text-slate-200">0.4 GB / 16.0 GB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">DirectX version</span>
                  <span className="font-mono tabular-nums text-slate-200">12 (FL 12.2)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Driver version</span>
                  <span className="font-mono tabular-nums text-slate-200">552.22 WHQL</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span className="text-slate-400">Hardware scheduling</span>
                  <span className="font-mono tabular-nums text-emerald-400">HAGS On</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Bus interface</span>
                  <span className="font-mono tabular-nums text-slate-200">PCIe x16 4.0</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
