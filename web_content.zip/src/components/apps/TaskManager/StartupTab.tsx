import { useState } from 'react';
import { DEFAULT_STARTUP_APPS } from '../../../data/defaultProcesses';
import { StartupApp } from '../../../types/os';
import { Power } from 'lucide-react';

export function StartupTab() {
  const [apps, setApps] = useState<StartupApp[]>(DEFAULT_STARTUP_APPS);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const toggleStatus = (id: string) => {
    setApps((prev) =>
      prev.map((app) =>
        app.id === id
          ? { ...app, status: app.status === 'Enabled' ? 'Disabled' : 'Enabled' }
          : app
      )
    );
  };

  const getImpactBadge = (impact: string) => {
    if (impact === 'High') return <span className="text-rose-400 font-medium">High</span>;
    if (impact === 'Medium') return <span className="text-amber-400 font-medium">Medium</span>;
    if (impact === 'Low') return <span className="text-sky-400 font-medium">Low</span>;
    return <span className="text-slate-400">None</span>;
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden">
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2.5 flex items-center justify-between text-xs text-slate-400">
        <div>
          <span>Last BIOS time: <strong className="font-mono text-slate-200">2.8 seconds</strong></span>
        </div>
        <div className="text-xs text-slate-400">
          Click an app to inspect or toggle startup execution
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead className="sticky top-0 bg-slate-900 text-slate-400 text-xs border-b border-slate-800 z-10 shadow-sm">
            <tr>
              <th className="py-2.5 pl-5 pr-3 font-semibold w-[35%]">Name</th>
              <th className="py-2.5 px-3 font-semibold w-[25%]">Publisher</th>
              <th className="py-2.5 px-3 font-semibold w-[15%]">Status</th>
              <th className="py-2.5 px-3 font-semibold w-[15%]">Startup impact</th>
              <th className="py-2.5 px-3 text-right font-semibold w-[10%]">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/40 text-xs">
            {apps.map((app) => {
              const isSelected = selectedId === app.id;
              const isEnabled = app.status === 'Enabled';

              return (
                <tr
                  key={app.id}
                  onClick={() => setSelectedId(app.id)}
                  className={`group cursor-pointer transition-colors ${
                    isSelected ? 'bg-sky-950/60 text-sky-200' : 'hover:bg-slate-800/30 text-slate-300'
                  }`}
                >
                  <td className="py-2 pl-5 pr-3 font-medium text-slate-200 truncate">
                    {app.name}
                  </td>
                  <td className="py-2 px-3 text-slate-400 truncate">{app.publisher}</td>
                  <td className="py-2 px-3">
                    <span className={`inline-flex items-center gap-1 font-medium ${isEnabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${isEnabled ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                      {app.status}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-mono">{getImpactBadge(app.startupImpact)}</td>
                  <td className="py-2 px-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleStatus(app.id);
                      }}
                      className={`px-2.5 py-1 rounded text-xs transition-colors border ${
                        isEnabled
                          ? 'border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white'
                          : 'border-emerald-700/60 text-emerald-400 hover:bg-emerald-950'
                      }`}
                    >
                      {isEnabled ? 'Disable' : 'Enable'}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedId && (
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
          {(() => {
            const app = apps.find((a) => a.id === selectedId);
            if (!app) return null;
            return (
              <>
                <div className="flex items-center gap-3">
                  <span className="text-slate-400">Command: <code className="font-mono text-slate-200 bg-slate-950 px-2 py-0.5 rounded">{app.command}</code></span>
                  <span className="text-slate-400 font-mono">Load overhead: {app.startupTimeMs} ms</span>
                </div>
                <button
                  onClick={() => toggleStatus(app.id)}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded transition-colors flex items-center gap-1.5"
                >
                  <Power className="w-3.5 h-3.5" />
                  {app.status === 'Enabled' ? 'Disable at boot' : 'Enable at boot'}
                </button>
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}
