import { useState, useMemo } from 'react';
import { ProcessItem, ProcessPriority } from '../../../types/os';
import { ChevronDown, ChevronRight, Leaf, ShieldAlert, MoreHorizontal } from 'lucide-react';

interface ProcessesTabProps {
  processes: ProcessItem[];
  selectedPid: number | null;
  onSelectPid: (pid: number | null) => void;
  onEndProcess: (pid: number) => void;
  onSetPriority: (pid: number, priority: ProcessPriority) => void;
  onToggleEfficiency: (pid: number) => void;
  searchQuery: string;
}

type SortKey = 'name' | 'cpu' | 'memoryMb' | 'diskMbS' | 'networkMbps' | 'gpuPct';

export function ProcessesTab({
  processes,
  selectedPid,
  onSelectPid,
  onEndProcess,
  onSetPriority,
  onToggleEfficiency,
  searchQuery,
}: ProcessesTabProps) {
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [sortKey, setSortKey] = useState<SortKey>('cpu');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const [contextMenuPid, setContextMenuPid] = useState<number | null>(null);

  const toggleGroup = (group: string) => {
    setCollapsedGroups((prev) => ({ ...prev, [group]: !prev[group] }));
  };

  const handleHeaderSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(false); // default desc for numbers
    }
  };

  // Filter and sort
  const filteredProcesses = useMemo(() => {
    let list = processes;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.pid.toString().includes(q) ||
          p.publisher.toLowerCase().includes(q)
      );
    }

    return [...list].sort((a, b) => {
      let valA = a[sortKey];
      let valB = b[sortKey];
      if (typeof valA === 'string') {
        const cmp = (valA as string).localeCompare(valB as string);
        return sortAsc ? cmp : -cmp;
      }
      valA = (valA as number) || 0;
      valB = (valB as number) || 0;
      return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });
  }, [processes, searchQuery, sortKey, sortAsc]);

  const apps = filteredProcesses.filter((p) => p.category === 'apps');
  const background = filteredProcesses.filter((p) => p.category === 'background');
  const windows = filteredProcesses.filter((p) => p.category === 'windows');

  // Aggregates
  const totalCpu = useMemo(() => processes.reduce((acc, p) => acc + (p.cpu || 0), 0).toFixed(1), [processes]);
  const totalMemory = useMemo(() => Math.round(processes.reduce((acc, p) => acc + (p.memoryMb || 0), 0)), [processes]);

  const renderProcessRow = (proc: ProcessItem) => {
    const isSelected = selectedPid === proc.pid;
    const isEfficiency = proc.status === 'Efficiency Mode';

    return (
      <tr
        key={proc.pid}
        onClick={() => onSelectPid(proc.pid)}
        onContextMenu={(e) => {
          e.preventDefault();
          onSelectPid(proc.pid);
          setContextMenuPid(contextMenuPid === proc.pid ? null : proc.pid);
        }}
        className={`group border-b border-slate-800/40 text-xs transition-colors cursor-pointer ${
          isSelected
            ? 'bg-sky-950/60 text-sky-200'
            : 'hover:bg-slate-800/30 text-slate-300'
        }`}
      >
        <td className="py-1.5 pl-6 pr-3 flex items-center gap-2 truncate">
          <span className="font-mono text-slate-500 text-[11px] tabular-nums w-12 shrink-0">{proc.pid}</span>
          <span className="font-medium text-slate-200 truncate">{proc.name}</span>
          {isEfficiency && (
            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-normal px-1 py-0.2 bg-emerald-950/40 rounded border border-emerald-800/40">
              <Leaf className="w-2.5 h-2.5" />
              Efficiency
            </span>
          )}
        </td>
        <td className="py-1.5 px-3 text-slate-400 truncate">{proc.status}</td>
        <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-200">
          <span className={proc.cpu > 5 ? 'text-amber-400 font-semibold' : ''}>
            {proc.cpu.toFixed(1)}%
          </span>
        </td>
        <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-200">
          {proc.memoryMb.toFixed(1)} MB
        </td>
        <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-400">
          {proc.diskMbS.toFixed(1)} MB/s
        </td>
        <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-400">
          {proc.networkMbps.toFixed(1)} Mbps
        </td>
        <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-400">
          {proc.gpuPct.toFixed(1)}%
        </td>
        <td className="py-1.5 px-3 text-right text-slate-400 truncate">
          {proc.powerUsage}
        </td>
      </tr>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden">
      {/* Table Header Summary Strip */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2 flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-4">
          <span>Active Processes: <strong className="text-slate-200">{processes.length}</strong></span>
          <span>Apps: <strong className="text-slate-200">{apps.length}</strong></span>
          <span>Background: <strong className="text-slate-200">{background.length}</strong></span>
        </div>
        <div className="flex items-center gap-4">
          <span>App CPU Total: <strong className="text-sky-400">{totalCpu}%</strong></span>
          <span>App Memory: <strong className="text-purple-400">{totalMemory} MB</strong></span>
        </div>
      </div>

      {/* Main Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead className="sticky top-0 bg-slate-900 text-slate-400 text-xs border-b border-slate-800 z-10 shadow-sm">
            <tr>
              <th
                onClick={() => handleHeaderSort('name')}
                className="py-2 pl-6 pr-3 font-semibold cursor-pointer hover:text-slate-200 w-[34%]"
              >
                Name / PID {sortKey === 'name' && (sortAsc ? '▲' : '▼')}
              </th>
              <th className="py-2 px-3 font-semibold w-[12%]">Status</th>
              <th
                onClick={() => handleHeaderSort('cpu')}
                className="py-2 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[10%]"
              >
                CPU {sortKey === 'cpu' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleHeaderSort('memoryMb')}
                className="py-2 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[12%]"
              >
                Memory {sortKey === 'memoryMb' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleHeaderSort('diskMbS')}
                className="py-2 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[11%]"
              >
                Disk {sortKey === 'diskMbS' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleHeaderSort('networkMbps')}
                className="py-2 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[11%]"
              >
                Network {sortKey === 'networkMbps' && (sortAsc ? '▲' : '▼')}
              </th>
              <th
                onClick={() => handleHeaderSort('gpuPct')}
                className="py-2 px-3 text-right font-semibold cursor-pointer hover:text-slate-200 w-[10%]"
              >
                GPU {sortKey === 'gpuPct' && (sortAsc ? '▲' : '▼')}
              </th>
              <th className="py-2 px-3 text-right font-semibold w-[10%]">Power</th>
            </tr>
          </thead>
          <tbody>
            {/* Apps Group */}
            {apps.length > 0 && (
              <>
                <tr
                  onClick={() => toggleGroup('apps')}
                  className="bg-slate-900/40 hover:bg-slate-800/40 cursor-pointer font-semibold text-xs text-slate-300"
                >
                  <td colSpan={8} className="py-1.5 px-3 flex items-center gap-1.5">
                    {collapsedGroups['apps'] ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    <span>Apps ({apps.length})</span>
                  </td>
                </tr>
                {!collapsedGroups['apps'] && apps.map(renderProcessRow)}
              </>
            )}

            {/* Background processes Group */}
            {background.length > 0 && (
              <>
                <tr
                  onClick={() => toggleGroup('background')}
                  className="bg-slate-900/40 hover:bg-slate-800/40 cursor-pointer font-semibold text-xs text-slate-300"
                >
                  <td colSpan={8} className="py-1.5 px-3 flex items-center gap-1.5">
                    {collapsedGroups['background'] ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    <span>Background processes ({background.length})</span>
                  </td>
                </tr>
                {!collapsedGroups['background'] && background.map(renderProcessRow)}
              </>
            )}

            {/* Windows processes Group */}
            {windows.length > 0 && (
              <>
                <tr
                  onClick={() => toggleGroup('windows')}
                  className="bg-slate-900/40 hover:bg-slate-800/40 cursor-pointer font-semibold text-xs text-slate-300"
                >
                  <td colSpan={8} className="py-1.5 px-3 flex items-center gap-1.5">
                    {collapsedGroups['windows'] ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    <span>Windows processes ({windows.length})</span>
                  </td>
                </tr>
                {!collapsedGroups['windows'] && windows.map(renderProcessRow)}
              </>
            )}
          </tbody>
        </table>
      </div>

      {/* Selected Process Action Floating Helper Bar */}
      {selectedPid && (
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-400">Selected PID: <strong className="font-mono text-slate-200">{selectedPid}</strong></span>
            {(() => {
              const proc = processes.find((p) => p.pid === selectedPid);
              if (!proc) return null;
              return (
                <>
                  <span className="text-slate-300 font-medium truncate max-w-xs">{proc.name}</span>
                  <span className="text-slate-500 font-mono">({proc.priority} priority)</span>
                </>
              );
            })()}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleEfficiency(selectedPid)}
              className="px-2.5 py-1 text-slate-300 hover:text-emerald-300 bg-slate-800 hover:bg-slate-700/80 rounded border border-slate-700 flex items-center gap-1 transition-colors"
            >
              <Leaf className="w-3 h-3 text-emerald-400" />
              Toggle Efficiency
            </button>
            <div className="relative group">
              <button className="px-2.5 py-1 text-slate-300 bg-slate-800 hover:bg-slate-700/80 rounded border border-slate-700 flex items-center gap-1 transition-colors">
                Priority
              </button>
              <div className="absolute right-0 bottom-full mb-1 hidden group-hover:flex flex-col bg-slate-900 border border-slate-800 rounded shadow-xl py-1 z-30 min-w-32">
                {(['Low', 'Below Normal', 'Normal', 'Above Normal', 'High', 'Realtime'] as ProcessPriority[]).map((prio) => (
                  <button
                    key={prio}
                    onClick={() => onSetPriority(selectedPid, prio)}
                    className="px-3 py-1 text-left text-xs text-slate-300 hover:bg-sky-600 hover:text-white"
                  >
                    {prio}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={() => onEndProcess(selectedPid)}
              className="px-3 py-1 text-white bg-rose-600 hover:bg-rose-500 rounded font-medium shadow-sm transition-colors"
            >
              End task
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
