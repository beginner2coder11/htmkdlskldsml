import { useState } from 'react';
import { DEFAULT_SERVICES } from '../../../data/defaultProcesses';
import { ServiceItem } from '../../../types/os';
import { Play, Square, RotateCw } from 'lucide-react';

interface ServicesTabProps {
  searchQuery: string;
}

export function ServicesTab({ searchQuery }: ServicesTabProps) {
  const [services, setServices] = useState<ServiceItem[]>(DEFAULT_SERVICES);
  const [selectedName, setSelectedName] = useState<string | null>(null);

  const toggleService = (name: string) => {
    setServices((prev) =>
      prev.map((s) => {
        if (s.name === name) {
          const isRunning = s.status === 'Running';
          return {
            ...s,
            status: isRunning ? 'Stopped' : 'Running',
            pid: isRunning ? undefined : Math.floor(1000 + Math.random() * 8000),
          };
        }
        return s;
      })
    );
  };

  const restartService = (name: string) => {
    setServices((prev) =>
      prev.map((s) => (s.name === name ? { ...s, pid: Math.floor(1000 + Math.random() * 8000) } : s))
    );
  };

  const filtered = services.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-slate-950/70 select-none overflow-hidden">
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead className="sticky top-0 bg-slate-900 text-slate-400 text-xs border-b border-slate-800 z-10 shadow-sm">
            <tr>
              <th className="py-2.5 pl-5 pr-3 font-semibold w-[20%]">Name</th>
              <th className="py-2.5 px-3 font-semibold w-[10%]">PID</th>
              <th className="py-2.5 px-3 font-semibold w-[42%]">Description</th>
              <th className="py-2.5 px-3 font-semibold w-[13%]">Status</th>
              <th className="py-2.5 px-3 font-semibold w-[15%]">Startup Type</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/40 text-xs">
            {filtered.map((svc) => {
              const isSelected = selectedName === svc.name;
              const isRunning = svc.status === 'Running';

              return (
                <tr
                  key={svc.name}
                  onClick={() => setSelectedName(svc.name)}
                  className={`group cursor-pointer transition-colors ${
                    isSelected ? 'bg-sky-950/60 text-sky-200' : 'hover:bg-slate-800/30 text-slate-300'
                  }`}
                >
                  <td className="py-2 pl-5 pr-3 font-medium text-slate-200 font-mono">
                    {svc.name}
                  </td>
                  <td className="py-2 px-3 font-mono text-slate-400 tabular-nums">
                    {svc.pid || '-'}
                  </td>
                  <td className="py-2 px-3 text-slate-400 truncate">{svc.description}</td>
                  <td className="py-2 px-3">
                    <span className={`inline-flex items-center gap-1 font-medium ${isRunning ? 'text-emerald-400' : 'text-slate-500'}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                      {svc.status}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-slate-400">{svc.startupType}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedName && (
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
          {(() => {
            const svc = services.find((s) => s.name === selectedName);
            if (!svc) return null;
            const isRunning = svc.status === 'Running';
            return (
              <>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-semibold text-slate-200">{svc.name}</span>
                  <span className="text-slate-400 truncate max-w-sm">· {svc.description}</span>
                </div>
                <div className="flex items-center gap-2">
                  {isRunning ? (
                    <>
                      <button
                        onClick={() => restartService(svc.name)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded transition-colors flex items-center gap-1 border border-slate-700"
                      >
                        <RotateCw className="w-3 h-3 text-sky-400" />
                        Restart
                      </button>
                      <button
                        onClick={() => toggleService(svc.name)}
                        className="px-2.5 py-1 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded transition-colors flex items-center gap-1 border border-rose-800/60"
                      >
                        <Square className="w-3 h-3 text-rose-400" />
                        Stop
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => toggleService(svc.name)}
                      className="px-2.5 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded transition-colors flex items-center gap-1 border border-emerald-800/60"
                    >
                      <Play className="w-3 h-3 text-emerald-400" />
                      Start
                    </button>
                  )}
                </div>
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}
