import { useState } from 'react';
import { INITIAL_FILES } from '../../data/defaultProcesses';
import { ExplorerItem, AppId } from '../../types/os';
import {
  Folder,
  FileText,
  HardDrive,
  Play,
  ChevronRight,
  ArrowLeft,
  ArrowUp,
  RotateCw,
  Search,
} from 'lucide-react';

interface FileExplorerAppProps {
  onOpenVirtualApp: (appId: AppId, customData?: any) => void;
}

export function FileExplorerApp({ onOpenVirtualApp }: FileExplorerAppProps) {
  const [currentPath, setCurrentPath] = useState('C:\\Windows\\System32');
  const [items, setItems] = useState<ExplorerItem[]>(INITIAL_FILES);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleItemClick = (item: ExplorerItem) => {
    setSelectedItem(item.name);
  };

  const handleItemDoubleClick = (item: ExplorerItem) => {
    if (item.type === 'folder' || item.type === 'drive') {
      setCurrentPath(item.path);
    } else if (item.type === 'exe' && item.targetAppId) {
      onOpenVirtualApp(item.targetAppId);
    } else if (item.type === 'file' && item.targetAppId === 'notepad') {
      onOpenVirtualApp('notepad', { initialContent: item.content, fileName: item.name });
    }
  };

  const handleGoUp = () => {
    if (currentPath === 'C:') return;
    const parts = currentPath.split('\\');
    if (parts.length > 1) {
      parts.pop();
      setCurrentPath(parts.join('\\'));
    } else {
      setCurrentPath('C:');
    }
  };

  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Address & Navigation Bar */}
      <div className="bg-slate-900 border-b border-slate-800 p-2 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleGoUp}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Up one level"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPath('C:\\Windows\\System32')}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Refresh"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Breadcrumb Path Bar */}
        <div className="flex-1 bg-slate-950/80 border border-slate-800 rounded px-3 py-1 text-xs font-mono text-slate-200 flex items-center gap-1">
          <HardDrive className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span className="truncate">{currentPath}</span>
        </div>

        {/* Search */}
        <div className="relative w-48 shrink-0">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${currentPath.split('\\').pop()}...`}
            className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Main Split: Left Quick Access + Right Files Grid */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Quick Access Sidebar */}
        <div className="w-44 bg-slate-900/60 border-r border-slate-800/80 p-2 space-y-1 text-xs shrink-0 overflow-y-auto">
          <div className="text-[11px] font-semibold text-slate-400 px-2 py-1">Quick Access</div>
          <button
            onClick={() => setCurrentPath('C:\\Windows\\System32')}
            className={`w-full text-left px-2 py-1.5 rounded flex items-center gap-2 transition-colors ${
              currentPath === 'C:\\Windows\\System32' ? 'bg-slate-800 text-sky-400 font-medium' : 'text-slate-300 hover:bg-slate-800/50'
            }`}
          >
            <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">System32</span>
          </button>
          <button
            onClick={() => setCurrentPath('C:\\Users\\User\\Documents')}
            className={`w-full text-left px-2 py-1.5 rounded flex items-center gap-2 transition-colors ${
              currentPath === 'C:\\Users\\User\\Documents' ? 'bg-slate-800 text-sky-400 font-medium' : 'text-slate-300 hover:bg-slate-800/50'
            }`}
          >
            <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">Documents</span>
          </button>
          <button
            onClick={() => setCurrentPath('C:')}
            className={`w-full text-left px-2 py-1.5 rounded flex items-center gap-2 transition-colors ${
              currentPath === 'C:' ? 'bg-slate-800 text-sky-400 font-medium' : 'text-slate-300 hover:bg-slate-800/50'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="truncate">Local Disk (C:)</span>
          </button>
        </div>

        {/* Right Files View (Details List) */}
        <div className="flex-1 overflow-y-auto p-2">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="text-slate-400 border-b border-slate-800 pb-2">
              <tr>
                <th className="py-1.5 pl-3 pr-2 font-semibold w-[45%]">Name</th>
                <th className="py-1.5 px-2 font-semibold w-[25%]">Date modified</th>
                <th className="py-1.5 px-2 font-semibold w-[15%]">Type</th>
                <th className="py-1.5 px-2 text-right font-semibold w-[15%]">Size</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/30">
              {filteredItems.map((item) => {
                const isSelected = selectedItem === item.name;

                return (
                  <tr
                    key={item.name}
                    onClick={() => handleItemClick(item)}
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-sky-950/60 text-sky-200'
                        : 'hover:bg-slate-800/30 text-slate-300'
                    }`}
                  >
                    <td className="py-1.5 pl-3 pr-2 flex items-center gap-2.5 truncate font-medium">
                      {item.type === 'drive' ? (
                        <HardDrive className="w-4 h-4 text-sky-400 shrink-0" />
                      ) : item.type === 'folder' ? (
                        <Folder className="w-4 h-4 text-amber-400 shrink-0" />
                      ) : item.type === 'exe' ? (
                        <Play className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="truncate">{item.name}</span>
                    </td>
                    <td className="py-1.5 px-2 font-mono text-slate-400 text-[11px]">{item.dateModified}</td>
                    <td className="py-1.5 px-2 text-slate-400 capitalize">{item.type === 'exe' ? 'Application' : item.type}</td>
                    <td className="py-1.5 px-2 text-right font-mono text-slate-400 text-[11px]">{item.size || '-'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer bar */}
      <div className="bg-slate-900 border-t border-slate-800 px-4 py-1.5 flex items-center justify-between text-xs text-slate-400 font-mono shrink-0">
        <span>{filteredItems.length} items</span>
        <span className="text-[11px] text-slate-500">Double-click executable to run</span>
      </div>
    </div>
  );
}
