import { useState } from 'react';
import {
  Monitor,
  Volume2,
  HardDrive,
  Info,
  Check,
  Palette,
  Shield,
  Laptop,
} from 'lucide-react';

interface SettingsAppProps {
  currentWallpaper: string;
  onSelectWallpaper: (wp: string) => void;
  taskbarAlignment: 'center' | 'left';
  onSelectTaskbarAlignment: (align: 'center' | 'left') => void;
  accentColor: string;
  onSelectAccentColor: (color: string) => void;
}

export function SettingsApp({
  currentWallpaper,
  onSelectWallpaper,
  taskbarAlignment,
  onSelectTaskbarAlignment,
  accentColor,
  onSelectAccentColor,
}: SettingsAppProps) {
  const [activeSection, setActiveSection] = useState<'personalization' | 'system' | 'about'>('personalization');
  const [volume, setVolume] = useState(75);

  const wallpapers = [
    {
      id: 'bloom-dark',
      name: 'Windows 11 Bloom Dark',
      gradient: 'radial-gradient(ellipse at top, #1e1b4b 0%, #0f172a 45%, #020617 100%)',
    },
    {
      id: 'cyber-horizon',
      name: 'Deep Cyber Horizon',
      gradient: 'radial-gradient(ellipse at 50% 20%, #0369a1 0%, #0c4a6e 25%, #020617 80%)',
    },
    {
      id: 'obsidian',
      name: 'Pure Obsidian Slate',
      gradient: 'linear-gradient(135deg, #090d16 0%, #0f172a 50%, #020617 100%)',
    },
    {
      id: 'nebula',
      name: 'Space Nebula',
      gradient: 'radial-gradient(circle at 80% 20%, #4c1d95 0%, #1e1b4b 35%, #030712 90%)',
    },
    {
      id: 'emerald-aurora',
      name: 'Emerald Aurora',
      gradient: 'radial-gradient(ellipse at top left, #064e3b 0%, #022c22 40%, #020617 95%)',
    },
    {
      id: 'sunset-titanium',
      name: 'Titanium Dusk',
      gradient: 'linear-gradient(to bottom, #1e293b 0%, #0f172a 50%, #090d16 100%)',
    },
  ];

  const accents = [
    { id: 'sky', name: 'Sky Blue', hex: '#0284c7' },
    { id: 'purple', name: 'Royal Purple', hex: '#9333ea' },
    { id: 'emerald', name: 'Emerald', hex: '#059669' },
    { id: 'amber', name: 'Amber Gold', hex: '#d97706' },
    { id: 'rose', name: 'Rose Red', hex: '#e11d48' },
  ];

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Left Settings Navigation */}
      <div className="w-56 bg-slate-900 border-r border-slate-800 p-3 space-y-1 shrink-0">
        <div className="flex items-center gap-2.5 px-3 py-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-sky-600/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
            <Laptop className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-200">DESKTOP-PC</div>
            <div className="text-[10px] text-slate-400 font-mono">Windows 11 Pro</div>
          </div>
        </div>

        <button
          onClick={() => setActiveSection('personalization')}
          className={`w-full text-left px-3 py-2 rounded text-xs flex items-center gap-2.5 transition-colors ${
            activeSection === 'personalization'
              ? 'bg-slate-800 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Palette className="w-4 h-4 shrink-0" />
          <span>Personalization</span>
        </button>

        <button
          onClick={() => setActiveSection('system')}
          className={`w-full text-left px-3 py-2 rounded text-xs flex items-center gap-2.5 transition-colors ${
            activeSection === 'system'
              ? 'bg-slate-800 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Volume2 className="w-4 h-4 shrink-0" />
          <span>Sound & Display</span>
        </button>

        <button
          onClick={() => setActiveSection('about')}
          className={`w-full text-left px-3 py-2 rounded text-xs flex items-center gap-2.5 transition-colors ${
            activeSection === 'about'
              ? 'bg-slate-800 text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Info className="w-4 h-4 shrink-0" />
          <span>About PC</span>
        </button>
      </div>

      {/* Main Settings Panel */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeSection === 'personalization' && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100">Personalization</h2>
              <p className="text-xs text-slate-400 mt-1">Select wallpaper themes, accent styling, and taskbar layout.</p>
            </div>

            {/* Wallpapers */}
            <div>
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">Background Themes</h3>
              <div className="grid grid-cols-3 gap-3">
                {wallpapers.map((wp) => {
                  const isSelected = currentWallpaper === wp.gradient;
                  return (
                    <button
                      key={wp.id}
                      onClick={() => onSelectWallpaper(wp.gradient)}
                      className={`group relative rounded-lg overflow-hidden border-2 transition-all p-1 text-left ${
                        isSelected ? 'border-sky-500 shadow-lg' : 'border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <div
                        className="w-full h-20 rounded"
                        style={{ background: wp.gradient }}
                      />
                      <div className="mt-1.5 flex items-center justify-between px-1">
                        <span className="text-xs text-slate-300 font-medium truncate">{wp.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Taskbar Alignment */}
            <div className="pt-4 border-t border-slate-800/80">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Taskbar Alignment</h3>
              <div className="flex gap-3">
                <button
                  onClick={() => onSelectTaskbarAlignment('center')}
                  className={`px-4 py-2 rounded text-xs border transition-colors ${
                    taskbarAlignment === 'center'
                      ? 'bg-slate-800 border-sky-500 text-sky-300 font-medium'
                      : 'border-slate-800 text-slate-400 hover:bg-slate-900'
                  }`}
                >
                  Center (Windows 11 Default)
                </button>
                <button
                  onClick={() => onSelectTaskbarAlignment('left')}
                  className={`px-4 py-2 rounded text-xs border transition-colors ${
                    taskbarAlignment === 'left'
                      ? 'bg-slate-800 border-sky-500 text-sky-300 font-medium'
                      : 'border-slate-800 text-slate-400 hover:bg-slate-900'
                  }`}
                >
                  Left (Classic Windows)
                </button>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'system' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100">Sound & Display</h2>
              <p className="text-xs text-slate-400 mt-1">Adjust workstation audio playback and display frequency.</p>
            </div>

            <div className="space-y-4 bg-slate-900/60 border border-slate-800 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-semibold text-slate-200">Master Volume</span>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-300">{volume}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
              <div className="text-[11px] text-slate-400 font-mono">Output: Realtek(R) Audio (Default Communication Device)</div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 space-y-2 text-xs">
              <div className="font-semibold text-slate-200">Display Resolution</div>
              <div className="text-slate-400 font-mono">1920 × 1080 @ 144.0 Hz (Recommended)</div>
              <div className="text-slate-500 text-[11px]">HDR: Certified DisplayHDR 400 On</div>
            </div>
          </div>
        )}

        {activeSection === 'about' && (
          <div className="max-w-2xl space-y-5">
            <div>
              <h2 className="text-xl font-bold text-slate-100">About Workstation</h2>
              <p className="text-xs text-slate-400 mt-1">Device specifications and Windows OS build information.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg divide-y divide-slate-800/60 text-xs">
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Device name</span>
                <span className="font-mono text-slate-200 font-medium">DESKTOP-PRO-STUDIO</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Processor</span>
                <span className="font-mono text-slate-200">12th Gen Intel(R) Core(TM) i7-12700H 2.70 GHz</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Installed RAM</span>
                <span className="font-mono text-slate-200">32.0 GB (31.8 GB usable)</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">System type</span>
                <span className="font-mono text-slate-200">64-bit operating system, x64-based processor</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Pen and touch</span>
                <span className="font-mono text-slate-200">Pen support</span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg divide-y divide-slate-800/60 text-xs">
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Edition</span>
                <span className="font-mono text-slate-200 font-medium">Windows 11 Pro</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Version</span>
                <span className="font-mono text-slate-200">24H2</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">OS build</span>
                <span className="font-mono text-slate-200">26100.2161</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-slate-400">Experience</span>
                <span className="font-mono text-slate-200">Windows Feature Experience Pack</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
