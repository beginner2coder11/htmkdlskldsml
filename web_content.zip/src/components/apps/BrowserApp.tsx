import { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Search,
  ExternalLink,
  ShieldCheck,
  Bookmark,
  Plus,
  X,
  Globe,
} from 'lucide-react';

interface BrowserAppProps {
  initialUrl?: string;
}

export function BrowserApp({ initialUrl = 'https://developer.microsoft.com' }: BrowserAppProps) {
  const [tabs, setTabs] = useState([
    { id: '1', title: 'Task Manager Architecture - Sysinternals', url: 'https://learn.microsoft.com/sysinternals' },
    { id: '2', title: 'GitHub - Open Source PC Tools', url: 'https://github.com' },
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [urlInput, setUrlInput] = useState('https://learn.microsoft.com/sysinternals');

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const handleNavigate = (e: React.FormEvent) => {
    e.preventDefault();
    let url = urlInput.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = `https://www.bing.com/search?q=${encodeURIComponent(url)}`;
    }
    setTabs((prev) =>
      prev.map((t) => (t.id === activeTabId ? { ...t, url, title: url } : t))
    );
  };

  const addTab = () => {
    const newId = Date.now().toString();
    const newTab = { id: newId, title: 'New Tab', url: 'https://www.google.com' };
    setTabs([...tabs, newTab]);
    setActiveTabId(newId);
    setUrlInput('https://www.google.com');
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    const remaining = tabs.filter((t) => t.id !== id);
    setTabs(remaining);
    if (activeTabId === id) {
      setActiveTabId(remaining[0].id);
      setUrlInput(remaining[0].url);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Tab Strip */}
      <div className="bg-slate-950 px-2 pt-2 flex items-center gap-1 shrink-0 overflow-x-auto border-b border-slate-800">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <div
              key={tab.id}
              onClick={() => {
                setActiveTabId(tab.id);
                setUrlInput(tab.url);
              }}
              className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs max-w-56 cursor-pointer border-t border-x transition-colors ${
                isActive
                  ? 'bg-slate-900 border-slate-700 text-sky-400 font-medium'
                  : 'bg-slate-950/60 border-transparent text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
              }`}
            >
              <Globe className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{tab.title}</span>
              <button
                onClick={(e) => closeTab(tab.id, e)}
                className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          );
        })}

        <button
          onClick={addTab}
          className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
          title="New Tab"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation & Address Bar */}
      <div className="bg-slate-900 px-3 py-2 flex items-center gap-2 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-1 text-slate-400">
          <button className="p-1 hover:text-white hover:bg-slate-800 rounded"><ArrowLeft className="w-3.5 h-3.5" /></button>
          <button className="p-1 hover:text-white hover:bg-slate-800 rounded"><ArrowRight className="w-3.5 h-3.5" /></button>
          <button className="p-1 hover:text-white hover:bg-slate-800 rounded"><RotateCw className="w-3.5 h-3.5" /></button>
        </div>

        <form onSubmit={handleNavigate} className="flex-1 flex items-center bg-slate-950 border border-slate-800 rounded px-2.5 py-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 mr-2 shrink-0" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            className="w-full bg-transparent text-xs text-slate-200 border-none outline-none font-mono"
          />
        </form>

        <a
          href={activeTab.url}
          target="_blank"
          rel="noopener noreferrer"
          className="p-1.5 text-slate-400 hover:text-sky-400 hover:bg-slate-800 rounded transition-colors flex items-center gap-1 text-xs"
          title="Open externally in real browser"
        >
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      {/* Browser Viewport Simulation */}
      <div className="flex-1 bg-slate-900/40 p-6 overflow-y-auto">
        <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-bold text-slate-100">{activeTab.title}</h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{activeTab.url}</p>
            </div>
            <span className="text-xs px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
              Secure Connection
            </span>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed">
            Windows Task Manager is an essential systems diagnosis tool designed by Microsoft and Sysinternals. It provides advanced real-time monitoring of CPU cycles, memory commit charges, disk read/write throughput, and process priority trees.
          </p>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-xs font-semibold text-slate-200">Process Affinity & Priority</div>
              <p className="text-xs text-slate-400 mt-1">
                Pin execution threads to physical P-cores or E-cores to maximize responsiveness or battery economy.
              </p>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-xs font-semibold text-slate-200">Efficiency Mode (EcoQoS)</div>
              <p className="text-xs text-slate-400 mt-1">
                Throttles background task execution to conserve system power and eliminate background thermal spikes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
