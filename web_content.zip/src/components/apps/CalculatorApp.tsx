import { useState } from 'react';
import { Delete, History } from 'lucide-react';

export function CalculatorApp() {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [memory, setMemory] = useState<number>(0);
  const [resetOnNextInput, setResetOnNextInput] = useState(false);

  const handleNum = (num: string) => {
    if (display === '0' || resetOnNextInput) {
      setDisplay(num);
      setResetOnNextInput(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleDecimal = () => {
    if (resetOnNextInput) {
      setDisplay('0.');
      setResetOnNextInput(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperator = (op: string) => {
    setEquation(`${display} ${op} `);
    setResetOnNextInput(true);
  };

  const handleEquals = () => {
    if (!equation) return;
    try {
      const fullExpr = equation + display;
      // Sanitize expression
      const sanitized = fullExpr.replace(/×/g, '*').replace(/÷/g, '/');
      // eslint-disable-next-line no-eval
      const result = Function(`'use strict'; return (${sanitized})`)();
      const resultStr = String(Number(result.toFixed(8)));
      setHistory((prev) => [`${fullExpr} = ${resultStr}`, ...prev.slice(0, 9)]);
      setDisplay(resultStr);
      setEquation('');
      setResetOnNextInput(true);
    } catch (e) {
      setDisplay('Error');
      setResetOnNextInput(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const handleClearEntry = () => {
    setDisplay('0');
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const handleSquare = () => {
    const val = parseFloat(display);
    const res = val * val;
    setDisplay(String(res));
    setResetOnNextInput(true);
  };

  const handleSqrt = () => {
    const val = parseFloat(display);
    if (val < 0) {
      setDisplay('Invalid input');
    } else {
      setDisplay(String(Math.sqrt(val)));
    }
    setResetOnNextInput(true);
  };

  const handleInvert = () => {
    const val = parseFloat(display);
    if (val === 0) {
      setDisplay('Cannot divide by zero');
    } else {
      setDisplay(String(1 / val));
    }
    setResetOnNextInput(true);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Header */}
      <div className="bg-slate-900 px-3 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
        <span className="font-semibold text-slate-300">Standard Calculator</span>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className={`p-1 rounded transition-colors ${showHistory ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'}`}
          title="Toggle history tape"
        >
          <History className="w-4 h-4" />
        </button>
      </div>

      {/* Screen Area */}
      <div className="p-4 bg-slate-900/50 flex flex-col justify-end text-right border-b border-slate-800/80 min-h-24 shrink-0">
        <div className="text-xs font-mono text-slate-400 h-4 truncate">
          {equation}
        </div>
        <div className="text-3xl font-bold font-mono tracking-tight text-slate-100 truncate mt-1">
          {display}
        </div>
      </div>

      {/* Main Buttons / History */}
      <div className="flex-1 p-2 relative">
        {showHistory ? (
          <div className="h-full overflow-y-auto p-2 space-y-2 text-xs font-mono">
            <div className="flex justify-between items-center text-slate-400 border-b border-slate-800 pb-1 mb-2">
              <span>History</span>
              <button onClick={() => setHistory([])} className="text-sky-400 hover:underline">Clear</button>
            </div>
            {history.length === 0 ? (
              <div className="text-slate-500 text-center py-6">There's no history yet</div>
            ) : (
              history.map((h, i) => (
                <div key={i} className="text-slate-300 py-1 border-b border-slate-800/50">
                  {h}
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="grid grid-cols-4 gap-1.5 h-full text-xs font-medium">
            <button onClick={handleInvert} className="bg-slate-900 hover:bg-slate-800 rounded py-2 text-slate-300">1/x</button>
            <button onClick={handleSquare} className="bg-slate-900 hover:bg-slate-800 rounded py-2 text-slate-300">x²</button>
            <button onClick={handleSqrt} className="bg-slate-900 hover:bg-slate-800 rounded py-2 text-slate-300">√x</button>
            <button onClick={() => handleOperator('÷')} className="bg-slate-800 hover:bg-slate-700 text-sky-400 rounded py-2 text-sm font-bold">÷</button>

            <button onClick={handleClearEntry} className="bg-slate-900 hover:bg-slate-800 rounded py-2 text-slate-300">CE</button>
            <button onClick={handleClear} className="bg-slate-900 hover:bg-slate-800 rounded py-2 text-slate-300">C</button>
            <button onClick={handleBackspace} className="bg-slate-900 hover:bg-slate-800 rounded py-2 flex items-center justify-center text-slate-300">
              <Delete className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => handleOperator('×')} className="bg-slate-800 hover:bg-slate-700 text-sky-400 rounded py-2 text-sm font-bold">×</button>

            <button onClick={() => handleNum('7')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">7</button>
            <button onClick={() => handleNum('8')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">8</button>
            <button onClick={() => handleNum('9')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">9</button>
            <button onClick={() => handleOperator('-')} className="bg-slate-800 hover:bg-slate-700 text-sky-400 rounded py-2 text-sm font-bold">-</button>

            <button onClick={() => handleNum('4')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">4</button>
            <button onClick={() => handleNum('5')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">5</button>
            <button onClick={() => handleNum('6')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">6</button>
            <button onClick={() => handleOperator('+')} className="bg-slate-800 hover:bg-slate-700 text-sky-400 rounded py-2 text-sm font-bold">+</button>

            <button onClick={() => handleNum('1')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">1</button>
            <button onClick={() => handleNum('2')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">2</button>
            <button onClick={() => handleNum('3')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">3</button>
            <button onClick={handleEquals} className="row-span-2 bg-sky-600 hover:bg-sky-500 text-white rounded py-2 text-base font-bold shadow-sm">=</button>

            <button onClick={() => setDisplay(String(-parseFloat(display)))} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 text-xs">+/-</button>
            <button onClick={() => handleNum('0')} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">0</button>
            <button onClick={handleDecimal} className="bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded py-2 font-mono text-sm">.</button>
          </div>
        )}
      </div>
    </div>
  );
}
