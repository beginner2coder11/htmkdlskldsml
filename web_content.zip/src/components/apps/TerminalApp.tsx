import { useState, useRef, useEffect } from 'react';
import { AppId, ProcessItem } from '../../types/os';

interface TerminalAppProps {
  onOpenVirtualApp: (appId: AppId) => void;
  processes: ProcessItem[];
  onEndProcess: (pid: number) => void;
  onRunCommand: (command: string) => void;
}

interface CommandLog {
  id: string;
  type: 'input' | 'output' | 'error';
  text: string;
}

export function TerminalApp({ onOpenVirtualApp, processes, onEndProcess, onRunCommand }: TerminalAppProps) {
  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [logs, setLogs] = useState<CommandLog[]>([
    { id: '1', type: 'output', text: 'Microsoft Windows [Version 10.0.26100.2161]' },
    { id: '2', type: 'output', text: '(c) Microsoft Corporation. All rights reserved.\n' },
    { id: '3', type: 'output', text: 'Type "taskmgr" to launch Task Manager, "tasklist" for active processes, or "help" for command directory.\n' },
  ]);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(inputVal);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const nextIdx = historyIdx + 1 < history.length ? historyIdx + 1 : historyIdx;
        setHistoryIdx(nextIdx);
        setInputVal(history[history.length - 1 - nextIdx] || '');
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx > 0) {
        const nextIdx = historyIdx - 1;
        setHistoryIdx(nextIdx);
        setInputVal(history[history.length - 1 - nextIdx] || '');
      } else if (historyIdx === 0) {
        setHistoryIdx(-1);
        setInputVal('');
      }
    }
  };

  const executeCommand = (rawCmd: string) => {
    const trimmed = rawCmd.trim();
    if (!trimmed) {
      setLogs((prev) => [...prev, { id: Date.now().toString(), type: 'input', text: 'C:\\Windows\\System32>' }]);
      return;
    }

    // Add to history
    setHistory((prev) => [...prev, trimmed]);
    setHistoryIdx(-1);
    setInputVal('');

    // Append user input log
    const cmdId = Date.now().toString();
    const newLogs: CommandLog[] = [
      ...logs,
      { id: `${cmdId}-in`, type: 'input', text: `C:\\Windows\\System32> ${trimmed}` },
    ];

    const parts = trimmed.split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);

    if (command === 'cls' || command === 'clear') {
      setLogs([]);
      return;
    }

    if (command === 'help' || command === '?') {
      newLogs.push({
        id: `${cmdId}-out`,
        type: 'output',
        text: `Supported commands:\n  taskmgr                 Launch Windows Task Manager\n  tasklist                Display all currently running processes\n  taskkill /pid <PID> /f  Terminate process by PID\n  start <app>             Start application (taskmgr, calc, notepad, explorer, browser)\n  calc                    Launch Calculator\n  notepad                 Launch Notepad editor\n  explorer                Launch File Explorer\n  systeminfo              Show OS and hardware telemetry\n  cls                     Clear screen\n  echo <message>          Print text to console\n  ping <host>             Send ICMP echo request`,
      });
    } else if (command === 'taskmgr' || command === 'taskmgr.exe') {
      onOpenVirtualApp('taskmgr');
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started Taskmgr.exe (PID allocated)' });
    } else if (command === 'calc' || command === 'calc.exe') {
      onOpenVirtualApp('calc');
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started calc.exe' });
    } else if (command === 'notepad' || command === 'notepad.exe') {
      onOpenVirtualApp('notepad');
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started notepad.exe' });
    } else if (command === 'explorer' || command === 'explorer.exe') {
      onOpenVirtualApp('explorer');
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started explorer.exe' });
    } else if (command === 'start') {
      const target = args[0]?.toLowerCase();
      if (!target) {
        newLogs.push({ id: `${cmdId}-err`, type: 'error', text: 'Usage: start <app_name> (e.g. start taskmgr, start notepad, start calc)' });
      } else if (target === 'taskmgr' || target === 'taskmgr.exe') {
        onOpenVirtualApp('taskmgr');
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started Taskmgr.exe' });
      } else if (target === 'calc') {
        onOpenVirtualApp('calc');
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started calc.exe' });
      } else if (target === 'notepad') {
        onOpenVirtualApp('notepad');
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started notepad.exe' });
      } else if (target === 'explorer') {
        onOpenVirtualApp('explorer');
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started explorer.exe' });
      } else if (target === 'browser' || target === 'edge' || target === 'chrome') {
        onOpenVirtualApp('browser');
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: 'Started msedge.exe' });
      } else {
        onRunCommand(target);
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: `Dispatched process start for: ${target}` });
      }
    } else if (command === 'tasklist') {
      let table = 'Image Name                     PID Session Name        Session#    Mem Usage\n========================= ======== ================ =========== ============\n';
      processes.forEach((p) => {
        const namePad = p.name.padEnd(25).slice(0, 25);
        const pidPad = p.pid.toString().padEnd(8);
        const sessPad = 'Console'.padEnd(16);
        const sessNum = '1'.padEnd(11);
        const memPad = `${Math.round(p.memoryMb * 1024).toLocaleString()} K`;
        table += `${namePad} ${pidPad} ${sessPad} ${sessNum} ${memPad}\n`;
      });
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: table });
    } else if (command === 'taskkill') {
      // parse /pid <pid>
      const pidIdx = args.findIndex((a) => a.toLowerCase() === '/pid' || a.toLowerCase() === '-pid');
      if (pidIdx !== -1 && args[pidIdx + 1]) {
        const targetPid = parseInt(args[pidIdx + 1], 10);
        const target = processes.find((p) => p.pid === targetPid);
        if (target) {
          onEndProcess(targetPid);
          newLogs.push({ id: `${cmdId}-out`, type: 'output', text: `SUCCESS: The process with PID ${targetPid} (${target.name}) has been terminated.` });
        } else {
          newLogs.push({ id: `${cmdId}-err`, type: 'error', text: `ERROR: The process "${targetPid}" not found.` });
        }
      } else {
        newLogs.push({ id: `${cmdId}-err`, type: 'error', text: 'Usage: taskkill /pid <PID> /f' });
      }
    } else if (command === 'kill') {
      const targetPid = parseInt(args[0], 10);
      if (targetPid) {
        onEndProcess(targetPid);
        newLogs.push({ id: `${cmdId}-out`, type: 'output', text: `Terminated process with PID ${targetPid}.` });
      } else {
        newLogs.push({ id: `${cmdId}-err`, type: 'error', text: 'Usage: kill <PID>' });
      }
    } else if (command === 'systeminfo') {
      newLogs.push({
        id: `${cmdId}-out`,
        type: 'output',
        text: `Host Name:                 DESKTOP-PC\nOS Name:                   Microsoft Windows 11 Pro\nOS Version:                10.0.26100 N/A Build 26100\nSystem Manufacturer:       Google AI Studio\nSystem Model:              Cloud Workstation Virtual Platform\nProcessor(s):              1 Processor(s) Installed. [01]: Intel64 Family 6 Model 154 Stepping 3 ~2.70GHz\nTotal Physical Memory:     32,768 MB\nAvailable Physical Memory: 19,456 MB\nVirtual Memory: Max Size:  37,632 MB\nPage File Location(s):     C:\\pagefile.sys\nHotfix(s):                 4 Hotfix(s) Installed.`,
      });
    } else if (command === 'echo') {
      newLogs.push({ id: `${cmdId}-out`, type: 'output', text: args.join(' ') });
    } else if (command === 'ping') {
      const targetHost = args[0] || '127.0.0.1';
      newLogs.push({
        id: `${cmdId}-out`,
        type: 'output',
        text: `Pinging ${targetHost} with 32 bytes of data:\nReply from ${targetHost}: bytes=32 time=1ms TTL=128\nReply from ${targetHost}: bytes=32 time=1ms TTL=128\nReply from ${targetHost}: bytes=32 time=1ms TTL=128\nReply from ${targetHost}: bytes=32 time=1ms TTL=128\n\nPing statistics for ${targetHost}:\n    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss)`,
      });
    } else {
      newLogs.push({
        id: `${cmdId}-err`,
        type: 'error',
        text: `'${command}' is not recognized as an internal or external command,\noperable program or batch file. Type "help" for list of commands.`,
      });
    }

    setLogs(newLogs);
  };

  return (
    <div
      onClick={() => inputRef.current?.focus()}
      className="flex flex-col h-full bg-black text-slate-100 p-3 font-mono text-xs overflow-hidden select-text"
    >
      <div className="flex-1 overflow-y-auto space-y-1">
        {logs.map((log) => (
          <div
            key={log.id}
            className={`whitespace-pre-wrap leading-relaxed ${
              log.type === 'error'
                ? 'text-rose-400'
                : log.type === 'input'
                ? 'text-slate-200'
                : 'text-slate-300'
            }`}
          >
            {log.text}
          </div>
        ))}

        {/* Input prompt line */}
        <div className="flex items-center gap-1.5 pt-1 text-slate-200">
          <span className="shrink-0 select-none text-slate-400">C:\Windows\System32&gt;</span>
          <input
            ref={inputRef}
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-white p-0 m-0"
            autoFocus
            spellCheck={false}
          />
        </div>
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
