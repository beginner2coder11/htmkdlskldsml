import { useState } from 'react';
import { Save, File, Download } from 'lucide-react';

interface NotepadAppProps {
  initialContent?: string;
  fileName?: string;
}

export function NotepadApp({ initialContent = '', fileName = 'Untitled.txt' }: NotepadAppProps) {
  const [content, setContent] = useState(
    initialContent ||
`PC App Launcher & Task Manager - System Readme
=================================================
This application combines an authentic Windows-grade Task Manager
with a complete PC Application Launcher.

Features available:
- Real-time CPU, Memory, Disk, Network & GPU performance telemetry
- Active processes monitoring, end task, efficiency mode, and priority adjustments
- Startup application impact reviewer and background services control
- Command Prompt (cmd.exe) terminal with interactive commands:
    * taskmgr       (Open Task Manager)
    * tasklist      (Inspect running processes)
    * taskkill /pid <id> /f (Kill process)
    * start <app>   (Launch virtual or host apps)
- Direct 1-click Protocol links for physical host apps:
    * VS Code       (vscode://)
    * Spotify       (spotify://)
    * Discord       (discord://)
    * Steam         (steam://)
    * Settings      (ms-settings:)
    * Calculator    (calculator:)
- File Explorer with virtual C: drive navigation and double-click execution!
`
  );

  const [activeFileName, setActiveFileName] = useState(fileName);
  const [isSaved, setIsSaved] = useState(true);

  const lines = content.split('\n');
  const lineCount = lines.length;
  const charCount = content.length;
  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;

  const handleDownload = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFileName;
    link.click();
    URL.revokeObjectURL(url);
    setIsSaved(true);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Menu Strip */}
      <div className="bg-slate-900 border-b border-slate-800 px-3 py-1 flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setContent('');
              setActiveFileName('Untitled.txt');
              setIsSaved(true);
            }}
            className="hover:text-white px-2 py-0.5 rounded hover:bg-slate-800 flex items-center gap-1"
          >
            <File className="w-3 h-3 text-sky-400" />
            New
          </button>
          <button
            onClick={handleDownload}
            className="hover:text-white px-2 py-0.5 rounded hover:bg-slate-800 flex items-center gap-1"
          >
            <Save className="w-3 h-3 text-emerald-400" />
            Save
          </button>
          <button
            onClick={handleDownload}
            className="hover:text-white px-2 py-0.5 rounded hover:bg-slate-800 flex items-center gap-1"
          >
            <Download className="w-3 h-3 text-slate-400" />
            Export
          </button>
        </div>

        <div className="text-[11px] text-slate-400 font-mono">
          {activeFileName} {isSaved ? '' : '● (Unsaved)'}
        </div>
      </div>

      {/* Editor Canvas */}
      <div className="flex-1 p-3 overflow-hidden select-text">
        <textarea
          value={content}
          onChange={(e) => {
            setContent(e.target.value);
            setIsSaved(false);
          }}
          className="w-full h-full bg-transparent text-slate-200 font-mono text-xs leading-relaxed resize-none border-none outline-none focus:ring-0"
          placeholder="Type notes or commands here..."
          spellCheck={false}
        />
      </div>

      {/* Status Bar */}
      <div className="bg-slate-900/90 border-t border-slate-800 px-4 py-1 flex items-center justify-between text-[11px] text-slate-400 font-mono shrink-0">
        <div className="flex items-center gap-4">
          <span>Ln {lineCount}, Col {content.length}</span>
          <span>{charCount} characters</span>
          <span>{wordCount} words</span>
        </div>
        <div className="flex items-center gap-4">
          <span>100%</span>
          <span>Windows (CRLF)</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
}
