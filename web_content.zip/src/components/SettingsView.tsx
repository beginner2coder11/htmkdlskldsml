import React from 'react';
import {
  Video,
  Mic,
  Camera,
  Sliders,
  Clock,
  Sparkles,
  HardDrive,
  Check,
  ShieldCheck,
  Smartphone,
  Trash2,
} from 'lucide-react';
import {
  RecorderSettings,
  ResolutionPreset,
  RESOLUTION_PRESETS,
  FpsPreset,
  BitratePreset,
  AudioSourceType,
} from '../types/recorder';

interface SettingsViewProps {
  settings: RecorderSettings;
  setSettings: React.Dispatch<React.SetStateAction<RecorderSettings>>;
  totalStorageBytes: number;
  recordingsCount: number;
  onClearAllRecordings: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  setSettings,
  totalStorageBytes,
  recordingsCount,
  onClearAllRecordings,
}) => {
  const resolutions: ResolutionPreset[] = ['4k', '2k', '1080p', '720p', '480p'];
  const frameRates: FpsPreset[] = [60, 30, 24];
  const bitrates: BitratePreset[] = [24, 16, 8, 4];
  const countdowns: (0 | 3 | 5 | 10)[] = [0, 3, 5, 10];

  const mbUsed = (totalStorageBytes / (1024 * 1024)).toFixed(1);

  return (
    <div className="flex flex-col gap-6 w-full max-w-3xl mx-auto pb-24">
      {/* Settings Header */}
      <div className="flex flex-col">
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
          Recorder Preferences
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Configure video resolution, audio mixing, facecam overlay, and MP4 export standards
        </p>
      </div>

      {/* Section 1: Video Engine */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col gap-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <Video className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-semibold text-white">Video Quality & Resolution</h3>
        </div>

        {/* Resolution selector */}
        <div className="flex flex-col gap-2">
          <label className="text-xs text-slate-400 font-medium">Recording Resolution</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {resolutions.map((resKey) => {
              const res = RESOLUTION_PRESETS[resKey];
              const isSelected = settings.resolution === resKey;
              return (
                <button
                  key={resKey}
                  onClick={() => setSettings({ ...settings, resolution: resKey })}
                  className={`flex items-center justify-between p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500 text-white shadow-sm'
                      : 'bg-slate-800/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold flex items-center gap-1.5">
                      {res.label}
                      {resKey === '1080p' && (
                        <span className="text-[10px] text-blue-400 font-normal">
                          (Recommended)
                        </span>
                      )}
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">{res.sublabel}</span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Frame Rate (FPS) */}
        <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
          <label className="text-xs text-slate-400 font-medium">Frame Rate (FPS)</label>
          <div className="grid grid-cols-3 gap-2">
            {frameRates.map((fps) => {
              const isSelected = settings.fps === fps;
              return (
                <button
                  key={fps}
                  onClick={() => setSettings({ ...settings, fps })}
                  className={`py-2.5 px-3 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 border-blue-500 text-white font-semibold shadow-sm'
                      : 'bg-slate-800/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs">{fps} FPS</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">
                    {fps === 60 ? 'Ultra Smooth' : fps === 30 ? 'Standard' : 'Cinematic'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Video Bitrate */}
        <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
          <label className="text-xs text-slate-400 font-medium">Video Bitrate</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {bitrates.map((br) => {
              const isSelected = settings.bitrate === br;
              return (
                <button
                  key={br}
                  onClick={() => setSettings({ ...settings, bitrate: br })}
                  className={`py-2 px-3 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 border-blue-500 text-white font-semibold'
                      : 'bg-slate-800/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs">{br} Mbps</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">
                    {br >= 16 ? 'HD Crisp' : br === 8 ? 'Normal' : 'Compact'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Export Container Format */}
        <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
          <label className="text-xs text-slate-400 font-medium">Export Video Format</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setSettings({ ...settings, exportFormat: 'mp4' })}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                settings.exportFormat === 'mp4'
                  ? 'bg-blue-600/15 border-blue-500 text-white'
                  : 'bg-slate-800/60 border-slate-800 text-slate-300'
              }`}
            >
              <span className="text-xs font-bold block">MP4 (Recommended)</span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                Maximum compatibility with mobile gallery, WhatsApp, YouTube, and PC
              </span>
            </button>
            <button
              onClick={() => setSettings({ ...settings, exportFormat: 'webm' })}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                settings.exportFormat === 'webm'
                  ? 'bg-blue-600/15 border-blue-500 text-white'
                  : 'bg-slate-800/60 border-slate-800 text-slate-300'
              }`}
            >
              <span className="text-xs font-bold block">WebM</span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                Modern open web standard with high compression efficiency
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Section 2: Audio Mixing */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col gap-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
            <Mic className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-semibold text-white">Audio Capture & Mixer</h3>
        </div>

        {/* Audio Source */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {[
            {
              id: 'mic_and_system' as AudioSourceType,
              title: 'Mic + Internal Audio',
              desc: 'Mix your voice with gameplay or system audio',
            },
            {
              id: 'mic_only' as AudioSourceType,
              title: 'Microphone Only',
              desc: 'Voice narration without background device audio',
            },
            {
              id: 'system_only' as AudioSourceType,
              title: 'Internal Audio Only',
              desc: 'Pure system sound and music without microphone',
            },
            {
              id: 'none' as AudioSourceType,
              title: 'Muted Recording',
              desc: 'Silent video without any sound tracks',
            },
          ].map((opt) => {
            const isSelected = settings.audioSource === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => setSettings({ ...settings, audioSource: opt.id })}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600/15 border-emerald-500 text-white'
                    : 'bg-slate-800/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold">{opt.title}</span>
                  {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                </div>
                <span className="text-[11px] text-slate-400 mt-0.5 block">{opt.desc}</span>
              </button>
            );
          })}
        </div>

        {/* Mic Volume Boost */}
        {(settings.audioSource === 'mic_and_system' || settings.audioSource === 'mic_only') && (
          <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Microphone Gain Booster</span>
              <span className="text-emerald-400 font-mono font-bold">
                {Math.round(settings.micGain * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.5}
              max={2.0}
              step={0.1}
              value={settings.micGain}
              onChange={(e) =>
                setSettings({ ...settings, micGain: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>
        )}
      </div>

      {/* Section 3: Facecam Overlay & Floating Ball */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col gap-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center">
            <Camera className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-semibold text-white">Facecam & Floating Bubble</h3>
        </div>

        {/* Facecam switches */}
        <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-800">
          <div>
            <span className="text-xs font-semibold text-white block">Facecam PiP Camera</span>
            <span className="text-[11px] text-slate-400">
              Display live webcam picture-in-picture box over screen
            </span>
          </div>
          <button
            onClick={() => setSettings({ ...settings, showFacecam: !settings.showFacecam })}
            className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative p-0.5 ${
              settings.showFacecam ? 'bg-blue-600' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                settings.showFacecam ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Facecam Shape */}
        {settings.showFacecam && (
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-400">Facecam Shape:</span>
            <div className="flex items-center gap-1.5">
              {(['circle', 'squircle', 'rect'] as const).map((shape) => (
                <button
                  key={shape}
                  onClick={() => setSettings({ ...settings, facecamShape: shape })}
                  className={`px-3 py-1.5 rounded-xl text-xs capitalize cursor-pointer ${
                    settings.facecamShape === shape
                      ? 'bg-blue-600 text-white font-medium'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {shape}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Floating Bubble Widget Switch */}
        <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-800">
          <div>
            <span className="text-xs font-semibold text-white block">
              Floating Quick-Record Bubble
            </span>
            <span className="text-[11px] text-slate-400">
              Draggable AZ Recorder-style floating widget on screen edge
            </span>
          </div>
          <button
            onClick={() =>
              setSettings({
                ...settings,
                floatingBallEnabled: !settings.floatingBallEnabled,
              })
            }
            className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative p-0.5 ${
              settings.floatingBallEnabled ? 'bg-blue-600' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                settings.floatingBallEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Countdown */}
        <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
          <div>
            <span className="text-xs font-semibold text-white block">Countdown Before Start</span>
            <span className="text-[11px] text-slate-400">Preparation timer</span>
          </div>
          <div className="flex items-center gap-1">
            {countdowns.map((sec) => (
              <button
                key={sec}
                onClick={() => setSettings({ ...settings, countdownSeconds: sec })}
                className={`w-10 h-8 rounded-xl text-xs font-mono font-semibold cursor-pointer ${
                  settings.countdownSeconds === sec
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {sec === 0 ? 'Off' : `${sec}s`}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Section 4: Local Storage & Device Space Management */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-600/20 text-amber-400 flex items-center justify-center">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Device Local Storage</h3>
              <p className="text-xs text-slate-400">IndexedDB persistent storage</p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-300">
            {recordingsCount} clips · {mbUsed} MB
          </span>
        </div>

        <p className="text-xs text-slate-400">
          All screen recordings and trimmed segments are kept directly in your browser's private
          local database. No external servers or uploads.
        </p>

        {recordingsCount > 0 && (
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to delete all saved recordings from local storage?')) {
                onClearAllRecordings();
              }
            }}
            className="flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-red-950/60 hover:bg-red-900/70 border border-red-800/80 text-red-300 text-xs font-semibold transition-colors cursor-pointer self-start"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Local Storage Cache</span>
          </button>
        )}
      </div>
    </div>
  );
};
