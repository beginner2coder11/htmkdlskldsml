import React, { useState, useRef } from 'react';
import { Circle, Square, Pause, Play, Camera, PenTool, Film, X } from 'lucide-react';
import { RecorderStatus } from '../types/recorder';

interface FloatingBallProps {
  status: RecorderStatus;
  elapsedTime: number;
  onRecord: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onScreenshot: () => void;
  onToggleBrush: () => void;
  onToggleFacecam: () => void;
  onOpenLibrary: () => void;
}

export const FloatingBall: React.FC<FloatingBallProps> = ({
  status,
  elapsedTime,
  onRecord,
  onPause,
  onResume,
  onStop,
  onScreenshot,
  onToggleBrush,
  onToggleFacecam,
  onOpenLibrary,
}) => {
  const [position, setPosition] = useState<{ x: number; y: number }>({
    x: typeof window !== 'undefined' ? window.innerWidth - 76 : 300,
    y: 220,
  });
  const [isOpen, setIsOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const hasMovedRef = useRef(false);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    hasMovedRef.current = false;
    dragStartRef.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = Math.abs(e.clientX - (position.x + dragStartRef.current.x));
    const dy = Math.abs(e.clientY - (position.y + dragStartRef.current.y));
    if (dx > 4 || dy > 4) {
      hasMovedRef.current = true;
    }
    const newX = Math.max(12, Math.min(window.innerWidth - 68, e.clientX - dragStartRef.current.x));
    const newY = Math.max(70, Math.min(window.innerHeight - 80, e.clientY - dragStartRef.current.y));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
    if (!hasMovedRef.current) {
      setIsOpen(!isOpen);
    }
  };

  const isRecording = status === 'recording' || status === 'paused';

  return (
    <div
      style={{ transform: `translate3d(${position.x}px, ${position.y}px, 0)` }}
      className="fixed top-0 left-0 z-40 touch-none select-none"
    >
      {/* Floating Action Menu Fanout */}
      {isOpen && (
        <div className="absolute right-full top-1/2 -translate-y-1/2 mr-3 flex items-center gap-2 bg-slate-900/95 border border-slate-700 p-2 rounded-full shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-90 duration-150">
          {/* Main Record/Stop/Pause */}
          {!isRecording ? (
            <button
              onClick={() => {
                onRecord();
                setIsOpen(false);
              }}
              title="Start Screen Recording"
              className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer"
            >
              <Circle className="w-5 h-5 fill-current" />
            </button>
          ) : (
            <>
              {status === 'recording' ? (
                <button
                  onClick={onPause}
                  title="Pause Recording"
                  className="w-10 h-10 rounded-full bg-amber-600 hover:bg-amber-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer"
                >
                  <Pause className="w-4 h-4 fill-current" />
                </button>
              ) : (
                <button
                  onClick={onResume}
                  title="Resume Recording"
                  className="w-10 h-10 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                </button>
              )}
              <button
                onClick={() => {
                  onStop();
                  setIsOpen(false);
                }}
                title="Stop & Save HD Recording"
                className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
              </button>
            </>
          )}

          {/* Screenshot */}
          <button
            onClick={() => {
              onScreenshot();
              setIsOpen(false);
            }}
            title="Take Screenshot"
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Screen Brush */}
          <button
            onClick={() => {
              onToggleBrush();
              setIsOpen(false);
            }}
            title="Screen Brush & Draw"
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <PenTool className="w-4 h-4" />
          </button>

          {/* Facecam PiP */}
          <button
            onClick={() => {
              onToggleFacecam();
              setIsOpen(false);
            }}
            title="Toggle Facecam Camera"
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <Camera className="w-4 h-4 text-blue-400" />
          </button>

          {/* Recordings */}
          <button
            onClick={() => {
              onOpenLibrary();
              setIsOpen(false);
            }}
            title="Recorded Videos"
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <Film className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      )}

      {/* Main Draggable Floating Orb */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl cursor-grab active:cursor-grabbing border-2 transition-all ${
          isRecording
            ? 'bg-red-600 border-red-400 shadow-red-600/40 animate-pulse'
            : 'bg-gradient-to-tr from-blue-700 to-indigo-600 border-blue-400 shadow-blue-600/30'
        }`}
      >
        {isRecording ? (
          <div className="flex flex-col items-center">
            <span className="w-2.5 h-2.5 bg-white rounded-full animate-ping mb-0.5" />
            <span className="text-[10px] font-bold text-white font-mono tabular-nums leading-none">
              {String(Math.floor(elapsedTime / 60)).padStart(2, '0')}:
              {String(elapsedTime % 60).padStart(2, '0')}
            </span>
          </div>
        ) : isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center">
            <div className="w-2.5 h-2.5 bg-white rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};
