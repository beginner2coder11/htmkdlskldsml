/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, ConnectionMode } from '../types';
import {
  ShieldCheck,
  Cpu,
  ClipboardCopy,
  Terminal,
  Server,
  Code2,
  Lock,
  Radio,
  Wifi,
  Settings2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  mode: ConnectionMode;
  setMode: (mode: ConnectionMode) => void;
  host: string;
  port: number;
  onUpdateHostPort: (host: string, port: number) => void;
  lastLatencyMs?: number;
  isConnected: boolean;
  onPing: () => void;
  isPinging: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  mode,
  setMode,
  host,
  port,
  onUpdateHostPort,
  lastLatencyMs,
  isConnected,
  onPing,
  isPinging,
}) => {
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [tempHost, setTempHost] = useState(host);
  const [tempPort, setTempPort] = useState(port);

  const navItems = [
    { id: 'dashboard' as ActiveTab, label: 'Control & Telemetry', icon: Cpu },
    { id: 'clipboard' as ActiveTab, label: 'Clipboard Sync', icon: ClipboardCopy },
    { id: 'protocol' as ActiveTab, label: 'Protocol Studio', icon: Terminal },
    { id: 'deploy' as ActiveTab, label: 'Server & Deploy', icon: Server },
    { id: 'sdk' as ActiveTab, label: 'Client SDKs', icon: Code2 },
    { id: 'security' as ActiveTab, label: 'Security & Audit', icon: ShieldCheck },
  ];

  const handleSaveEndpoint = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateHostPort(tempHost.trim() || '127.0.0.1', Number(tempPort) || 8765);
    setShowConfigModal(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      {/* Topmost Brand and Connection Status Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-emerald-500 p-0.5 shadow-lg shadow-cyan-500/20">
              <div className="h-full w-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Radio className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-200 to-cyan-300 bg-clip-text text-transparent">
                  Link-to-Windows++
                </span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/60">
                  TLS Bridge
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Privacy-first, zero-cloud LAN control bridge for PC
              </p>
            </div>
          </div>

          {/* Center/Right Connection & Mode Bar */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Mode Switcher */}
            <div className="inline-flex rounded-lg bg-slate-950 p-0.5 sm:p-1 border border-slate-800 text-[11px] sm:text-xs">
              <button
                type="button"
                onClick={() => setMode('simulator')}
                className={`px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-medium transition flex items-center gap-1 ${
                  mode === 'simulator'
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Simulates local PC server.py without network restrictions"
              >
                <Sparkles className="w-3 h-3 text-cyan-300" />
                <span className="hidden md:inline">Live Simulator</span>
                <span className="md:hidden">Sim</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('direct')}
                className={`px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-medium transition flex items-center gap-1 ${
                  mode === 'direct'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Connects to your running server.py on local network"
              >
                <Wifi className="w-3 h-3 text-emerald-300" />
                <span className="hidden md:inline">Direct Bridge</span>
                <span className="md:hidden">Direct</span>
              </button>
            </div>

            {/* Host & Port Button */}
            <button
              type="button"
              onClick={() => {
                setTempHost(host);
                setTempPort(port);
                setShowConfigModal(true);
              }}
              className="flex items-center gap-1 text-[11px] sm:text-xs bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg transition"
              title="Configure target IP and port"
            >
              <Lock className="w-3 h-3 text-emerald-400" />
              <span className="font-mono text-cyan-300 hidden sm:inline">{host}:{port}</span>
              <Settings2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-400" />
            </button>

            {/* Ping / Latency Badge */}
            <button
              type="button"
              onClick={onPing}
              disabled={isPinging}
              className="flex items-center gap-1 text-[11px] sm:text-xs bg-emerald-950/60 border border-emerald-800/70 text-emerald-300 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg hover:bg-emerald-900/60 transition"
              title="Ping bridge server"
            >
              <RefreshCw className={`w-3 h-3 ${isPinging ? 'animate-spin' : ''}`} />
              <span className="font-mono font-medium">
                {lastLatencyMs !== undefined ? `${lastLatencyMs}ms` : 'TLS'}
              </span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 scrollbar-none border-t border-slate-800/70" aria-label="Main Navigation">
          {navItems.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Endpoint Configuration Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-slate-100 text-lg">Target PC Bridge Endpoint</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowConfigModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEndpoint} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  PC IP Address or Hostname
                </label>
                <input
                  type="text"
                  value={tempHost}
                  onChange={(e) => setTempHost(e.target.value)}
                  placeholder="192.168.1.150 or localhost"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 text-sm font-mono focus:outline-none focus:border-cyan-500"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Use your PC's LAN IP (e.g. 192.168.x.x) if accessing from mobile phone or tablet on the same Wi-Fi.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  TLS Port
                </label>
                <input
                  type="number"
                  value={tempPort}
                  onChange={(e) => setTempPort(Number(e.target.value))}
                  placeholder="8765"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 text-sm font-mono focus:outline-none focus:border-cyan-500"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Default: 8765. Matches the EXPOSE and server.py listener port.
                </p>
              </div>

              {/* Quick Presets */}
              <div className="pt-2">
                <span className="text-xs text-slate-400">Quick Presets:</span>
                <div className="flex gap-2 mt-1">
                  <button
                    type="button"
                    onClick={() => { setTempHost('127.0.0.1'); setTempPort(8765); }}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded"
                  >
                    Localhost (127.0.0.1:8765)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setTempHost('192.168.1.100'); setTempPort(8765); }}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded"
                  >
                    LAN (192.168.1.100)
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowConfigModal(false)}
                  className="px-4 py-2 rounded-lg text-sm text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-gradient-to-r from-cyan-600 to-indigo-600 text-white hover:from-cyan-500 hover:to-indigo-500 shadow-lg shadow-cyan-500/20"
                >
                  Save Endpoint
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};
