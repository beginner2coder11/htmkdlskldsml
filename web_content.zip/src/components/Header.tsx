import React from 'react';
import { Video, Smartphone, Monitor, HardDrive } from 'lucide-react';
import { NavigationTab } from '../types/recorder';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean) => void;
  recordingsCount: number;
  isRecording: boolean;
  onQuickRecord: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isMobileFrame,
  setIsMobileFrame,
  recordingsCount,
  isRecording,
  onQuickRecord,
}) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Single text element Brand wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
            <Video className="w-5 h-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
            Stitch Recorder
          </span>
        </div>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => setActiveTab('record')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              activeTab === 'record'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500 pb-0.5'
                : 'hover:text-white'
            }`}
          >
            Record Studio
          </button>
          <button
            onClick={() => setActiveTab('gallery')}
            className={`whitespace-nowrap shrink-0 transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'gallery'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500 pb-0.5'
                : 'hover:text-white'
            }`}
          >
            Library
            {recordingsCount > 0 && (
              <span className="text-xs text-slate-400 font-normal">
                ({recordingsCount})
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('tools')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              activeTab === 'tools'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500 pb-0.5'
                : 'hover:text-white'
            }`}
          >
            Video Tools
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500 pb-0.5'
                : 'hover:text-white'
            }`}
          >
            Preferences
          </button>
        </nav>

        {/* Zone 3: Primary action & Viewport mode switch */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Mobile frame vs Full-width desktop view toggle */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            title={isMobileFrame ? 'Switch to Full Width View' : 'Switch to Play Store Mobile Frame'}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-blue-400" />
                <span className="whitespace-nowrap">Expanded View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span className="whitespace-nowrap">Play Store Frame</span>
              </>
            )}
          </button>

          {!isRecording ? (
            <button
              onClick={onQuickRecord}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-md shadow-blue-600/20 active:scale-95 transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5"
            >
              <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              <span>Record Screen</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-red-950/80 border border-red-800/80 rounded-lg">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span className="text-xs font-medium text-red-200 whitespace-nowrap">
                Live Recording
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
