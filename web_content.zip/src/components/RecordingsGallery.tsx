import React, { useState } from 'react';
import {
  Play,
  Download,
  Scissors,
  Music,
  Trash2,
  Edit2,
  Check,
  Search,
  Film,
  FileVideo,
  Sparkles,
} from 'lucide-react';
import { RecordingItem } from '../types/recorder';
import { formatDuration, formatFileSize, downloadRecording, extractAudioFromVideo } from '../utils/mediaExport';
import { updateRecordingTitle } from '../utils/storage';

interface RecordingsGalleryProps {
  recordings: RecordingItem[];
  onSelectPlay: (item: RecordingItem) => void;
  onSelectTrim: (item: RecordingItem) => void;
  onDelete: (id: string) => void;
  onRefresh: () => void;
  onGoToRecord: () => void;
}

export const RecordingsGallery: React.FC<RecordingsGalleryProps> = ({
  recordings,
  onSelectPlay,
  onSelectTrim,
  onDelete,
  onRefresh,
  onGoToRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFormat, setFilterFormat] = useState<'all' | 'mp4' | 'webm'>('all');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitleValue, setEditTitleValue] = useState('');
  const [extractingAudioId, setExtractingAudioId] = useState<string | null>(null);

  const filtered = recordings.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFormat =
      filterFormat === 'all'
        ? true
        : filterFormat === 'mp4'
        ? item.title.endsWith('.mp4') || item.extension === 'mp4'
        : item.title.endsWith('.webm') || item.extension === 'webm';
    return matchesSearch && matchesFormat;
  });

  const handleStartRename = (item: RecordingItem) => {
    setEditingId(item.id);
    setEditTitleValue(item.title);
  };

  const handleSaveRename = async (id: string) => {
    if (editTitleValue.trim()) {
      await updateRecordingTitle(id, editTitleValue.trim());
      onRefresh();
    }
    setEditingId(null);
  };

  const handleExtractAudio = async (item: RecordingItem) => {
    try {
      setExtractingAudioId(item.id);
      const { blob, filename } = await extractAudioFromVideo(item.blob);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch (err) {
      console.error('Audio extraction failed:', err);
    } finally {
      setExtractingAudioId(null);
    }
  };

  return (
    <div className="flex flex-col gap-6 w-full pb-20">
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search recorded videos..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-2xl shrink-0">
          <button
            onClick={() => setFilterFormat('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-colors cursor-pointer ${
              filterFormat === 'all'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({recordings.length})
          </button>
          <button
            onClick={() => setFilterFormat('mp4')}
            className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-colors cursor-pointer ${
              filterFormat === 'mp4'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            MP4 HD
          </button>
          <button
            onClick={() => setFilterFormat('webm')}
            className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-colors cursor-pointer ${
              filterFormat === 'webm'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            WebM
          </button>
        </div>
      </div>

      {/* Recordings Grid / List */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 bg-slate-900/40 border border-slate-800 rounded-3xl text-center">
          <div className="w-16 h-16 rounded-3xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-4">
            <Film className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">No recordings found</h3>
          <p className="text-sm text-slate-400 mt-1 max-w-sm">
            {searchQuery
              ? 'Try modifying your search query.'
              : 'You have not recorded any screens yet. Tap below to capture your first HD clip.'}
          </p>
          <button
            onClick={onGoToRecord}
            className="mt-5 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/20 active:scale-95 transition-all cursor-pointer"
          >
            Record Screen Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((item) => {
            const isEditing = editingId === item.id;
            const timeAgo = formatTimeAgo(item.createdAt);

            return (
              <div
                key={item.id}
                className="flex flex-col bg-slate-900/80 border border-slate-800 hover:border-slate-700/80 rounded-3xl overflow-hidden transition-all shadow-lg group"
              >
                {/* Video Thumbnail with Hover Overlay */}
                <div
                  onClick={() => onSelectPlay(item)}
                  className="relative aspect-video w-full bg-slate-950 overflow-hidden cursor-pointer"
                >
                  {item.thumbnail ? (
                    <img
                      src={item.thumbnail}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-950 text-slate-700">
                      <FileVideo className="w-12 h-12" />
                    </div>
                  )}

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-2xl active:scale-95 transition-transform">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </div>
                  </div>

                  {/* Duration Tag */}
                  <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-sm text-[11px] font-mono font-medium text-white tabular-nums">
                    {formatDuration(item.duration)}
                  </div>

                  {/* Resolution Tag */}
                  <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-blue-600/90 backdrop-blur-sm text-[10px] font-semibold text-white uppercase tracking-wider">
                    {item.resolutionBadge || 'HD'}
                  </div>
                </div>

                {/* Content details */}
                <div className="p-4 flex flex-col justify-between flex-1 gap-3">
                  <div>
                    {/* Title with edit capability */}
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editTitleValue}
                          onChange={(e) => setEditTitleValue(e.target.value)}
                          className="flex-1 px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveRename(item.id);
                            if (e.key === 'Escape') setEditingId(null);
                          }}
                        />
                        <button
                          onClick={() => handleSaveRename(item.id)}
                          className="p-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-500 cursor-pointer"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-start justify-between gap-2">
                        <h4
                          onClick={() => onSelectPlay(item)}
                          title={item.title}
                          className="text-sm font-semibold text-white line-clamp-1 hover:text-blue-400 cursor-pointer transition-colors"
                        >
                          {item.title}
                        </h4>
                        <button
                          onClick={() => handleStartRename(item)}
                          title="Rename file"
                          className="text-slate-500 hover:text-slate-300 p-1 rounded transition-colors cursor-pointer shrink-0"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Unboxed clean metadata following Design Constitution */}
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1.5">
                      <span>{formatFileSize(item.size)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.fps || 60} FPS</span>
                      <span aria-hidden="true">·</span>
                      <span>{timeAgo}</span>
                    </div>
                  </div>

                  {/* Primary & Secondary Action Bars */}
                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                    {/* Primary High-Def MP4 Export button */}
                    <button
                      onClick={() => downloadRecording(item, 'mp4')}
                      title="Export high-definition MP4 directly to device storage"
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/20 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export MP4</span>
                    </button>

                    {/* Trim Tool */}
                    <button
                      onClick={() => onSelectTrim(item)}
                      title="Trim video duration"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <Scissors className="w-4 h-4" />
                    </button>

                    {/* Extract Audio */}
                    <button
                      onClick={() => handleExtractAudio(item)}
                      disabled={extractingAudioId === item.id}
                      title="Extract audio soundtrack (WAV/MP3)"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Music className="w-4 h-4" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => onDelete(item.id)}
                      title="Delete recording"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-red-950/60 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

function formatTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
