/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { generateClientCode } from '../utils/protocol';
import {
  Code2,
  Copy,
  Check,
  Smartphone,
  Terminal,
  Cpu,
  Layers,
  ShieldCheck,
} from 'lucide-react';

interface SdkViewProps {
  host: string;
  port: number;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const SdkView: React.FC<SdkViewProps> = ({ host, port, onNotify }) => {
  const [selectedLang, setSelectedLang] = useState<'python' | 'kotlin' | 'swift' | 'curl' | 'nodejs'>('python');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const clientCode = generateClientCode(selectedLang, host, port);

  const handleCopy = () => {
    navigator.clipboard.writeText(clientCode);
    setCopiedKey(selectedLang);
    setTimeout(() => setCopiedKey(null), 2000);
    onNotify(`Copied ${selectedLang.toUpperCase()} client snippet`, 'success');
  };

  const platforms = [
    { id: 'python' as const, label: 'Python CLI (asyncio)', icon: '🐍' },
    { id: 'kotlin' as const, label: 'Android (Kotlin / OkHttp)', icon: '🤖' },
    { id: 'swift' as const, label: 'iOS (Swift / NWConnection)', icon: '🍎' },
    { id: 'curl' as const, label: 'Shell (openssl s_client)', icon: '💻' },
    { id: 'nodejs' as const, label: 'Node.js (tls socket)', icon: '⚡' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-950/70 border border-emerald-800/70 rounded-xl text-emerald-400">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Section 5: Client Implementation & Mobile Guide
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                Cross-Platform
              </span>
            </h2>
            <p className="text-sm text-slate-400">
              Native client implementations for Android phones, iPhones/iPads, and desktop automation over TLS.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">Target:</span>
          <span className="text-xs px-2.5 py-1 rounded bg-slate-950 border border-slate-700 text-cyan-300 font-mono">
            {host}:{port}
          </span>
        </div>
      </div>

      {/* Platform Switcher & Code Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        {/* Navigation tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex flex-wrap gap-1.5">
            {platforms.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedLang(p.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  selectedLang === p.id
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span>{p.icon}</span>
                <span>{p.label}</span>
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition"
          >
            {copiedKey === selectedLang ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedKey === selectedLang ? 'Copied Snippet' : 'Copy Code'}
          </button>
        </div>

        {/* Code Display */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 h-[420px] overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed">
          <pre>{clientCode}</pre>
        </div>

        {/* Platform-Specific Implementation Notes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-xl text-xs space-y-1.5">
            <h4 className="font-semibold text-white flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" /> Android Tips (OkHttp)
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              When using self-signed certs on your home LAN, pass a custom <code className="text-cyan-300">X509TrustManager</code> as shown, or install your <code className="text-cyan-300">server.crt</code> into Android's User Credential Store.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-xl text-xs space-y-1.5">
            <h4 className="font-semibold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> iOS Tips (Swift)
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Swift's <code className="text-emerald-300">sec_protocol_options_set_verify_block</code> allows custom evaluation on LAN. In production, embed the public certificate into the app bundle for certificate pinning.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-xl text-xs space-y-1.5">
            <h4 className="font-semibold text-white flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" /> OpenSSL / Shell
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Test directly in terminal with: <code className="text-indigo-300">echo '{`{"cmd":"GET_CPU"}`}' | openssl s_client -connect {host}:{port} -quiet</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
