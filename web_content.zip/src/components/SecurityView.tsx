/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  EyeOff,
  Server,
  Terminal,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Network,
  Cpu,
} from 'lucide-react';

export const SecurityView: React.FC = () => {
  const [checklist, setChecklist] = useState<Record<string, boolean>>({
    tls: true,
    localOnly: true,
    noShell: true,
    whitelist: true,
    clipboardRam: true,
    sanitizedLogs: true,
    mtls: false,
  });

  const toggleCheck = (key: string) => {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const securityRows = [
    {
      concern: 'Does data leave the local network?',
      mitigation: 'By default the server only accepts TLS-encrypted connections. No traffic is sent to external servers unless you explicitly forward the port.',
      status: 'Protected',
      icon: Network,
    },
    {
      concern: 'Clipboard leakage & tracking',
      mitigation: "Clipboard data stays inside the PC's memory (pyperclip); the script only reads/writes it on explicit COPY/PASTE commands.",
      status: 'In-Memory Only',
      icon: EyeOff,
    },
    {
      concern: 'Process injection & malicious execution',
      mitigation: 'subprocess.Popen receives a single executable array without shell=True, mitigating injection. Whitelist limits targets to approved binaries.',
      status: 'No Shell Interpolation',
      icon: Terminal,
    },
    {
      concern: 'Unauthenticated or spoofed access',
      mitigation: 'TLS 1.2+ mandatory. Mutual TLS (mTLS) can be enabled to require client certificates signed by your private CA.',
      status: 'TLS 1.2+ / Optional mTLS',
      icon: Lock,
    },
    {
      concern: 'Logging of sensitive clipboard data',
      mitigation: 'Log messages omit raw clipboard strings; only command metadata and character lengths are recorded.',
      status: 'Zero Telemetry',
      icon: FileCheck,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-950/70 border border-emerald-800/70 rounded-xl text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Section 4: Security & Privacy Highlights
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-300 font-mono">
                Zero Cloud Architecture
              </span>
            </h2>
            <p className="text-sm text-slate-400">
              Defense-in-depth design principles ensuring total data ownership and process isolation.
            </p>
          </div>
        </div>
      </div>

      {/* Security Concerns & Mitigations Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-white text-base">Threat Model & Defense Matrix</h3>
          <span className="text-xs text-slate-500 font-mono">Section 4 Compliance</span>
        </div>

        <div className="space-y-3">
          {securityRows.map((row, idx) => {
            const Icon = row.icon;
            return (
              <div
                key={idx}
                className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 mt-0.5">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm">{row.concern}</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{row.mitigation}</p>
                  </div>
                </div>

                <div className="self-end md:self-center">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium bg-emerald-950/70 text-emerald-300 border border-emerald-800/80">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {row.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Hardening Checklist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Lock className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base">Production Hardening Checklist</h3>
          </div>

          <div className="space-y-2.5 text-xs">
            <label className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:bg-slate-850">
              <input
                type="checkbox"
                checked={checklist.tls}
                onChange={() => toggleCheck('tls')}
                className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <div>
                <span className="font-semibold text-slate-200">Enforce TLS 1.2+ minimum</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Disable SSLv3, TLS 1.0, and TLS 1.1 to prevent protocol downgrade attacks.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:bg-slate-850">
              <input
                type="checkbox"
                checked={checklist.localOnly}
                onChange={() => toggleCheck('localOnly')}
                className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <div>
                <span className="font-semibold text-slate-200">Restrict firewall to LAN subnet</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Only open port 8765 to your internal subnet (e.g. 192.168.1.0/24) or localhost.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:bg-slate-850">
              <input
                type="checkbox"
                checked={checklist.noShell}
                onChange={() => toggleCheck('noShell')}
                className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <div>
                <span className="font-semibold text-slate-200">No shell interpolation (shell=False)</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Pass executable as argument array: subprocess.Popen([target]) without shell evaluation.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:bg-slate-850">
              <input
                type="checkbox"
                checked={checklist.whitelist}
                onChange={() => toggleCheck('whitelist')}
                className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <div>
                <span className="font-semibold text-slate-200">App launcher whitelist</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Explicitly permit only designated binaries (e.g. notepad.exe, code).
                </p>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:bg-slate-850">
              <input
                type="checkbox"
                checked={checklist.mtls}
                onChange={() => toggleCheck('mtls')}
                className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <div>
                <span className="font-semibold text-slate-200">Mutual TLS (mTLS) Client Verification</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Verify client certificates with private CA for strict zero-trust networks.
                </p>
              </div>
            </label>
          </div>
        </div>

        {/* Network Boundary Architecture Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Network className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-white text-base">Network Boundary Architecture</h3>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-slate-300 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-cyan-400 font-semibold">[Client: Phone/Tablet]</span>
              <span className="text-slate-500">Android / iOS / CLI</span>
            </div>

            <div className="text-center py-1">
              <div className="inline-block px-3 py-1 rounded bg-slate-900 border border-cyan-800/60 text-cyan-300 text-[11px]">
                🔒 TLS 1.2+ Encrypted Socket Frame (Port 8765)
              </div>
              <div className="text-[10px] text-slate-500 mt-1">
                Zero Cloud Relays • Local LAN Subnet (192.168.x.x)
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-emerald-400 font-semibold">[Host: Link-to-Windows++]</span>
              <span className="text-slate-500">Python 3.12+ (Asyncio)</span>
            </div>

            <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800/80 text-[11px] space-y-1 text-slate-400">
              <div>• CPU Telemetry: <span className="text-slate-200">psutil kernel hooks</span></div>
              <div>• Clipboard Sync: <span className="text-slate-200">pyperclip OS memory buffer</span></div>
              <div>• Process Execution: <span className="text-slate-200">subprocess.Popen</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
