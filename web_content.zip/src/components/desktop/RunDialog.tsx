import { useState } from 'react';
import { Play, X, CornerDownLeft } from 'lucide-react';

interface RunDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onExecute: (command: string) => void;
}

export function RunDialog({ isOpen, onClose, onExecute }: RunDialogProps) {
  const [command, setCommand] = useState('taskmgr');
  const [history] = useState(['taskmgr', 'cmd', 'calc', 'notepad', 'explorer', 'resmon', 'devmgmt.msc', 'services.msc']);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (command.trim()) {
      onExecute(command.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-start p-6 pointer-events-none">
      <div className="bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl w-96 text-slate-100 pointer-events-auto overflow-hidden animate-fadeIn font-sans">
        {/* Header */}
        <div className="bg-slate-950 px-3 py-2 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-sky-600 flex items-center justify-center text-white text-[10px] font-bold">
              ⊞
            </div>
            <span className="text-xs font-semibold text-slate-200">Run</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded bg-sky-950/60 border border-sky-800/40 text-sky-400 shrink-0">
              <Play className="w-5 h-5" />
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Type the name of a program, folder, document, or Internet resource, and Windows will open it for you.
            </p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <label className="text-xs font-medium text-slate-400 w-12 shrink-0">Open:</label>
            <input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              list="run-history"
              className="flex-1 bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-100 font-mono focus:outline-none focus:border-sky-500"
              autoFocus
              placeholder="e.g. taskmgr, calc, cmd"
            />
            <datalist id="run-history">
              {history.map((h) => (
                <option key={h} value={h} />
              ))}
            </datalist>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="submit"
              className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-medium transition-colors shadow-sm flex items-center gap-1"
            >
              <span>OK</span>
              <CornerDownLeft className="w-3 h-3 opacity-60" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-medium transition-colors border border-slate-700"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
