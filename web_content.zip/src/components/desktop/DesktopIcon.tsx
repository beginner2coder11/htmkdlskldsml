import { ReactNode } from 'react';

interface DesktopIconProps {
  label: string;
  icon: ReactNode;
  isSelected: boolean;
  onSelect: () => void;
  onOpen: () => void;
}

export function DesktopIcon({ label, icon, isSelected, onSelect, onOpen }: DesktopIconProps) {
  return (
    <div
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className={`w-20 p-2 rounded flex flex-col items-center text-center cursor-pointer transition-colors border select-none group ${
        isSelected
          ? 'bg-sky-500/25 border-sky-400/50 text-white'
          : 'border-transparent hover:bg-white/10 text-slate-200'
      }`}
    >
      <div className="w-11 h-11 rounded-lg flex items-center justify-center transition-transform group-hover:scale-105 drop-shadow-md">
        {icon}
      </div>
      <span className="text-[11px] font-medium mt-1 leading-tight drop-shadow truncate w-full text-center px-0.5">
        {label}
      </span>
    </div>
  );
}
