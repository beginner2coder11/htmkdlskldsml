import { useState, useRef, useEffect, ReactNode } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';
import { WindowState } from '../../types/os';

interface WindowFrameProps {
  window: WindowState;
  isActive: boolean;
  onFocus: () => void;
  onClose: () => void;
  onMinimize: () => void;
  onToggleMaximize: () => void;
  onUpdatePosition: (pos: { x: number; y: number }) => void;
  onUpdateSize: (size: { width: number; height: number }, pos?: { x: number; y: number }) => void;
  children: ReactNode;
  iconComponent: ReactNode;
}

export function WindowFrame({
  window: win,
  isActive,
  onFocus,
  onClose,
  onMinimize,
  onToggleMaximize,
  onUpdatePosition,
  onUpdateSize,
  children,
  iconComponent,
}: WindowFrameProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const dragStartRef = useRef<{ mouseX: number; mouseY: number; startX: number; startY: number }>({ mouseX: 0, mouseY: 0, startX: 0, startY: 0 });
  const resizeStartRef = useRef<{ mouseX: number; mouseY: number; startW: number; startH: number }>({ mouseX: 0, mouseY: 0, startW: 0, startH: 0 });

  // Handle Dragging
  const handleMouseDownHeader = (e: React.MouseEvent) => {
    if (win.isMaximized) return;
    // Don't drag if clicking buttons
    if ((e.target as HTMLElement).closest('button')) return;

    onFocus();
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: win.position.x,
      startY: win.position.y,
    };
  };

  // Handle Resizing
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFocus();
    setIsResizing(true);
    resizeStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startW: win.size.width,
      startH: win.size.height,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const dx = e.clientX - dragStartRef.current.mouseX;
        const dy = e.clientY - dragStartRef.current.mouseY;
        const newX = Math.max(0, Math.min(window.innerWidth - 100, dragStartRef.current.startX + dx));
        const newY = Math.max(0, Math.min(window.innerHeight - 80, dragStartRef.current.startY + dy));
        onUpdatePosition({ x: newX, y: newY });
      } else if (isResizing) {
        const dx = e.clientX - resizeStartRef.current.mouseX;
        const dy = e.clientY - resizeStartRef.current.mouseY;
        const newW = Math.max(320, Math.min(window.innerWidth - 40, resizeStartRef.current.startW + dx));
        const newH = Math.max(220, Math.min(window.innerHeight - 80, resizeStartRef.current.startH + dy));
        onUpdateSize({ width: newW, height: newH });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, onUpdatePosition, onUpdateSize]);

  if (win.isMinimized) return null;

  const style: React.CSSProperties = win.isMaximized
    ? {
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: 'calc(100vh - 48px)', // above taskbar
        zIndex: win.zIndex,
      }
    : {
        position: 'fixed',
        left: `${win.position.x}px`,
        top: `${win.position.y}px`,
        width: `${win.size.width}px`,
        height: `${win.size.height}px`,
        zIndex: win.zIndex,
      };

  return (
    <div
      style={style}
      onMouseDown={onFocus}
      className={`flex flex-col bg-slate-900/95 border rounded-lg shadow-2xl overflow-hidden transition-shadow select-none ${
        isActive
          ? 'border-slate-700/90 shadow-2xl ring-1 ring-sky-500/20'
          : 'border-slate-800/80 shadow-md opacity-95'
      }`}
    >
      {/* Window Title Bar */}
      <div
        onMouseDown={handleMouseDownHeader}
        onDoubleClick={onToggleMaximize}
        className={`h-9 px-3 flex items-center justify-between cursor-move shrink-0 border-b transition-colors ${
          isActive
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-slate-950 border-slate-850 text-slate-400'
        }`}
      >
        {/* Title & Icon */}
        <div className="flex items-center gap-2 min-w-0 pr-2">
          <div className="shrink-0">{iconComponent}</div>
          <span className="text-xs font-semibold truncate tracking-tight">
            {win.title}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center -mr-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onMinimize();
            }}
            className="w-10 h-9 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleMaximize();
            }}
            className="w-10 h-9 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title={win.isMaximized ? 'Restore' : 'Maximize'}
          >
            {win.isMaximized ? (
              <Copy className="w-3 h-3 rotate-180" />
            ) : (
              <Square className="w-3 h-3" />
            )}
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="w-10 h-9 flex items-center justify-center hover:bg-rose-600 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Body Viewport */}
      <div className="flex-1 overflow-hidden relative">
        {children}
      </div>

      {/* Resize Grip (bottom right corner) */}
      {!win.isMaximized && (
        <div
          onMouseDown={handleMouseDownResize}
          className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize flex items-center justify-center text-slate-600 hover:text-sky-400 z-40"
        >
          <div className="w-1.5 h-1.5 border-r border-b border-current" />
        </div>
      )}
    </div>
  );
}
