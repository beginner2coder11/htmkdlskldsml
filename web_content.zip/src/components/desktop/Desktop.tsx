import { useState, useEffect } from 'react';
import { useWindowManager } from '../../hooks/useWindowManager';
import { useSystemTelemetry } from '../../hooks/useSystemTelemetry';
import { AppId, WindowState } from '../../types/os';
import { DesktopIcon } from './DesktopIcon';
import { WindowFrame } from './WindowFrame';
import { Taskbar } from './Taskbar';
import { StartMenu } from './StartMenu';
import { RunDialog } from './RunDialog';

import { TaskManagerApp } from '../apps/TaskManager/TaskManagerApp';
import { LauncherApp } from '../apps/LauncherApp';
import { TerminalApp } from '../apps/TerminalApp';
import { NotepadApp } from '../apps/NotepadApp';
import { CalculatorApp } from '../apps/CalculatorApp';
import { FileExplorerApp } from '../apps/FileExplorerApp';
import { BrowserApp } from '../apps/BrowserApp';
import { SettingsApp } from '../apps/SettingsApp';

import {
  Activity,
  Grid,
  Terminal,
  Calculator,
  FileText,
  Folder,
  Globe,
  Settings,
  Server,
  Play,
  Monitor,
} from 'lucide-react';

const APP_ICONS: Record<AppId, any> = {
  taskmgr: Activity,
  launcher: Grid,
  terminal: Terminal,
  calc: Calculator,
  notepad: FileText,
  explorer: Folder,
  browser: Globe,
  settings: Settings,
};

export function Desktop() {
  const {
    windows,
    activeWindowId,
    processes,
    openApp,
    closeWindow,
    minimizeWindow,
    toggleMaximize,
    focusWindow,
    updateWindowPosition,
    updateWindowSize,
    endProcess,
    setProcessPriority,
    toggleProcessEfficiency,
    runNewTask,
  } = useWindowManager();

  const telemetry = useSystemTelemetry(processes);

  const [selectedDesktopIcon, setSelectedDesktopIcon] = useState<string | null>(null);
  const [isStartMenuOpen, setIsStartMenuOpen] = useState(false);
  const [isRunDialogOpen, setIsRunDialogOpen] = useState(false);
  const [wallpaper, setWallpaper] = useState(
    'radial-gradient(ellipse at top, #1e1b4b 0%, #0f172a 45%, #020617 100%)'
  );
  const [taskbarAlignment, setTaskbarAlignment] = useState<'center' | 'left'>('center');
  const [accentColor, setAccentColor] = useState('#0284c7');
  const [serverHostStatus, setServerHostStatus] = useState<any>(null);

  // Fetch real backend PC App Server status
  useEffect(() => {
    fetch('/api/system/info')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setServerHostStatus(data);
        }
      })
      .catch(() => {
        // Dev client fallback
      });
  }, []);

  // Keyboard shortcut for Win + R or Ctrl + K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
        e.preventDefault();
        setIsRunDialogOpen(true);
      } else if (e.key === 'Meta') {
        setIsStartMenuOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleToggleWindow = (windowId: string) => {
    const win = windows.find((w) => w.id === windowId);
    if (!win) return;
    if (win.isMinimized) {
      focusWindow(windowId);
    } else if (activeWindowId === windowId) {
      minimizeWindow(windowId);
    } else {
      focusWindow(windowId);
    }
  };

  const desktopIcons = [
    {
      id: 'taskmgr' as AppId,
      label: 'Task Manager',
      icon: <Activity className="w-6 h-6 text-sky-400" />,
    },
    {
      id: 'launcher' as AppId,
      label: 'PC App Hub',
      icon: <Grid className="w-6 h-6 text-indigo-400" />,
    },
    {
      id: 'terminal' as AppId,
      label: 'Command Prompt',
      icon: <Terminal className="w-6 h-6 text-emerald-400" />,
    },
    {
      id: 'explorer' as AppId,
      label: 'File Explorer',
      icon: <Folder className="w-6 h-6 text-amber-400" />,
    },
    {
      id: 'calc' as AppId,
      label: 'Calculator',
      icon: <Calculator className="w-6 h-6 text-purple-400" />,
    },
    {
      id: 'notepad' as AppId,
      label: 'Notepad',
      icon: <FileText className="w-6 h-6 text-sky-300" />,
    },
    {
      id: 'browser' as AppId,
      label: 'Edge Browser',
      icon: <Globe className="w-6 h-6 text-cyan-400" />,
    },
    {
      id: 'settings' as AppId,
      label: 'Settings',
      icon: <Settings className="w-6 h-6 text-slate-300" />,
    },
  ];

  return (
    <div
      onClick={() => {
        setSelectedDesktopIcon(null);
        setIsStartMenuOpen(false);
      }}
      style={{ background: wallpaper }}
      className="relative w-screen h-screen overflow-hidden select-none font-sans"
    >
      {/* Top Subtle Workspace Bar */}
      <div className="absolute top-0 left-0 right-0 h-8 px-4 flex items-center justify-between z-10 pointer-events-none text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-4 pointer-events-auto">
          <span className="text-slate-300 font-semibold flex items-center gap-1.5">
            <Monitor className="w-3.5 h-3.5 text-sky-400" />
            PC Workstation
          </span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-400">
            CPU: <strong className="text-sky-400 tabular-nums">{telemetry.cpuUsage.toFixed(0)}%</strong>
          </span>
          <span className="hidden sm:inline text-slate-400">
            RAM: <strong className="text-purple-400 tabular-nums">{telemetry.memoryUsedGb.toFixed(1)} GB</strong>
          </span>
          {serverHostStatus && (
            <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
              <Server className="w-3 h-3" />
              Server Ready ({serverHostStatus.platform} {serverHostStatus.arch})
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => openApp('taskmgr')}
            className="px-2.5 py-0.5 bg-slate-900/80 hover:bg-slate-800 text-sky-300 border border-slate-700/80 rounded transition-colors text-xs flex items-center gap-1"
          >
            <Activity className="w-3 h-3" />
            <span>Task Manager</span>
          </button>
          <button
            onClick={() => setIsRunDialogOpen(true)}
            className="px-2.5 py-0.5 bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-700/80 rounded transition-colors text-xs flex items-center gap-1"
          >
            <Play className="w-3 h-3 text-emerald-400" />
            <span>Run (Win+R)</span>
          </button>
        </div>
      </div>

      {/* Desktop Shortcut Grid */}
      <div className="absolute top-10 left-3 bottom-14 flex flex-col flex-wrap gap-2.5 z-10 pointer-events-auto">
        {desktopIcons.map((icon) => (
          <DesktopIcon
            key={icon.id}
            label={icon.label}
            icon={icon.icon}
            isSelected={selectedDesktopIcon === icon.id}
            onSelect={() => setSelectedDesktopIcon(icon.id)}
            onOpen={() => openApp(icon.id)}
          />
        ))}
      </div>

      {/* Window Canvas */}
      {windows.map((win) => {
        const IconComponent = APP_ICONS[win.appId] || Activity;
        const isActive = activeWindowId === win.id;

        return (
          <WindowFrame
            key={win.id}
            window={win}
            isActive={isActive}
            onFocus={() => focusWindow(win.id)}
            onClose={() => closeWindow(win.id)}
            onMinimize={() => minimizeWindow(win.id)}
            onToggleMaximize={() => toggleMaximize(win.id)}
            onUpdatePosition={(pos) => updateWindowPosition(win.id, pos)}
            onUpdateSize={(size, pos) => updateWindowSize(win.id, size, pos)}
            iconComponent={<IconComponent className="w-4 h-4 text-sky-400" />}
          >
            {win.appId === 'taskmgr' && (
              <TaskManagerApp
                telemetry={telemetry}
                processes={processes}
                onEndProcess={endProcess}
                onSetPriority={setProcessPriority}
                onToggleEfficiency={toggleProcessEfficiency}
                onOpenRunDialog={() => setIsRunDialogOpen(true)}
              />
            )}

            {win.appId === 'launcher' && (
              <LauncherApp
                onOpenVirtualApp={openApp}
                onRunCommand={runNewTask}
              />
            )}

            {win.appId === 'terminal' && (
              <TerminalApp
                onOpenVirtualApp={openApp}
                processes={processes}
                onEndProcess={endProcess}
                onRunCommand={runNewTask}
              />
            )}

            {win.appId === 'notepad' && (
              <NotepadApp
                initialContent={win.customData?.initialContent}
                fileName={win.customData?.fileName}
              />
            )}

            {win.appId === 'calc' && (
              <CalculatorApp />
            )}

            {win.appId === 'explorer' && (
              <FileExplorerApp onOpenVirtualApp={openApp} />
            )}

            {win.appId === 'browser' && (
              <BrowserApp initialUrl={win.customData?.initialUrl} />
            )}

            {win.appId === 'settings' && (
              <SettingsApp
                currentWallpaper={wallpaper}
                onSelectWallpaper={setWallpaper}
                taskbarAlignment={taskbarAlignment}
                onSelectTaskbarAlignment={setTaskbarAlignment}
                accentColor={accentColor}
                onSelectAccentColor={setAccentColor}
              />
            )}
          </WindowFrame>
        );
      })}

      {/* Start Menu */}
      <StartMenu
        isOpen={isStartMenuOpen}
        onClose={() => setIsStartMenuOpen(false)}
        onOpenApp={openApp}
        onOpenRunDialog={() => {
          setIsStartMenuOpen(false);
          setIsRunDialogOpen(true);
        }}
      />

      {/* Run Dialog (Win + R) */}
      <RunDialog
        isOpen={isRunDialogOpen}
        onClose={() => setIsRunDialogOpen(false)}
        onExecute={runNewTask}
      />

      {/* Taskbar */}
      <Taskbar
        windows={windows}
        activeWindowId={activeWindowId}
        onOpenApp={openApp}
        onToggleWindow={handleToggleWindow}
        isStartOpen={isStartMenuOpen}
        onToggleStart={() => setIsStartMenuOpen((prev) => !prev)}
        onOpenRunDialog={() => setIsRunDialogOpen(true)}
        alignment={taskbarAlignment}
      />
    </div>
  );
}
