import { useState } from 'react';
import { AppId } from '../../types/os';
import {
  Activity,
  Terminal,
  Calculator,
  FileText,
  Folder,
  Globe,
  Settings,
  Grid,
  Search,
  Power,
  RotateCw,
  Lock,
  User,
} from 'lucide-react';

interface StartMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenApp: (appId: AppId) => void;
  onOpenRunDialog: () => void;
}

export function StartMenu({ isOpen, onClose, onOpenApp, onOpenRunDialog }: StartMenuProps) {
  const [search, setSearch] = useState('');
  const [showPowerMenu, setShowPowerMenu] = useState(false);

  if (!isOpen) return null;

  const pinned = [
    { id: 'taskmgr' as AppId, name: 'Task Manager', icon: Activity, color: 'text-sky-400 bg-sky-950/60' },
    { id: 'launcher' as AppId, name: 'PC App Hub', icon: Grid, color: 'text-indigo-400 bg-indigo-950/60' },
    { id: 'terminal' as AppId, name: 'Terminal', icon: Terminal, color: 'text-emerald-400 bg-emerald-950/60' },
    { id: 'calc' as AppId, name: 'Calculator', icon: Calculator, color: 'text-purple-400 bg-purple-950/60' },
    { id: 'notepad' as AppId, name: 'Notepad', icon: FileText, color: 'text-amber-400 bg-amber-950/60' },
    { id: 'explorer' as AppId, name: 'File Explorer', icon: Folder, color: 'text-yellow-400 bg-yellow-950/60' },
    { id: 'browser' as AppId, name: 'Edge Browser', icon: Globe, color: 'text-cyan-400 bg-cyan-950/60' },
    { id: 'settings' as AppId, name: 'Settings', icon: Settings, color: 'text-slate-400 bg-slate-900' },
  ];

  const filteredPinned = pinned.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className="fixed bottom-14 left-1/2 -translate-x-1/2 w-[540px] max-w-[95vw] h-[580px] bg-slate-900/95 mica-surface border border-slate-700/80 rounded-xl shadow-2xl z-50 flex flex-col overflow-hidden animate-fadeIn text-slate-100 select-none font-sans"
    >
      {/* Top Search Input */}
      <div className="p-5 pb-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search for apps, settings, and documents..."
            className="w-full bg-slate-950/90 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-sky-500 shadow-inner"
            autoFocus
          />
        </div>
      </div>

      {/* Main Body: Pinned apps */}
      <div className="flex-1 px-5 overflow-y-auto space-y-4">
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-300">Pinned</span>
            <button
              onClick={() => onOpenRunDialog()}
              className="text-[11px] text-sky-400 hover:text-sky-300 font-medium"
            >
              Run Dialog (Win + R)
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {filteredPinned.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onOpenApp(item.id);
                    onClose();
                  }}
                  className="flex flex-col items-center p-3 rounded-lg hover:bg-white/5 transition-colors group"
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center border border-slate-700/60 ${item.color} group-hover:scale-105 transition-transform shadow-sm`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs text-slate-200 mt-2 truncate max-w-full">
                    {item.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recommended Files */}
        <div className="pt-2 border-t border-slate-800/80">
          <div className="text-xs font-semibold text-slate-300 mb-2">Recommended</div>
          <div className="space-y-1.5">
            <button
              onClick={() => {
                onOpenApp('notepad');
                onClose();
              }}
              className="w-full p-2 rounded hover:bg-white/5 transition-colors flex items-center justify-between text-left"
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="text-xs font-medium text-slate-200">System_Readme.txt</div>
                  <div className="text-[10px] text-slate-500">Documents · 2h ago</div>
                </div>
              </div>
            </button>
            <button
              onClick={() => {
                onOpenApp('taskmgr');
                onClose();
              }}
              className="w-full p-2 rounded hover:bg-white/5 transition-colors flex items-center justify-between text-left"
            >
              <div className="flex items-center gap-2.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-xs font-medium text-slate-200">Task Manager Diagnostics</div>
                  <div className="text-[10px] text-slate-500">Active telemetry monitor</div>
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Strip */}
      <div className="bg-slate-950/80 border-t border-slate-800/90 px-5 py-3 flex items-center justify-between shrink-0 relative">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full bg-sky-600/30 border border-sky-500/50 flex items-center justify-center text-sky-300 text-xs font-bold">
            <User className="w-3.5 h-3.5" />
          </div>
          <div className="text-xs font-semibold text-slate-200">Administrator</div>
        </div>

        {/* Power Menu Button */}
        <div className="relative">
          <button
            onClick={() => setShowPowerMenu(!showPowerMenu)}
            className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors"
            title="Power"
          >
            <Power className="w-4 h-4" />
          </button>

          {showPowerMenu && (
            <div className="absolute right-0 bottom-full mb-2 w-36 bg-slate-900 border border-slate-700 rounded-lg shadow-xl py-1 z-50 text-xs">
              <button
                onClick={() => {
                  setShowPowerMenu(false);
                  onClose();
                }}
                className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-sky-600 hover:text-white flex items-center gap-2"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock</span>
              </button>
              <button
                onClick={() => {
                  window.location.reload();
                }}
                className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-sky-600 hover:text-white flex items-center gap-2"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Restart</span>
              </button>
              <button
                onClick={() => {
                  setShowPowerMenu(false);
                  onClose();
                }}
                className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-rose-600 hover:text-white flex items-center gap-2"
              >
                <Power className="w-3.5 h-3.5" />
                <span>Shut down</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
