import { useState, useEffect } from 'react';
import { AppId, WindowState } from '../../types/os';
import {
  Activity,
  Terminal,
  Calculator,
  FileText,
  Folder,
  Globe,
  Settings,
  Grid,
  Search,
  Wifi,
  Volume2,
  BatteryCharging,
} from 'lucide-react';

interface TaskbarProps {
  windows: WindowState[];
  activeWindowId: string | null;
  onOpenApp: (appId: AppId) => void;
  onToggleWindow: (windowId: string) => void;
  isStartOpen: boolean;
  onToggleStart: () => void;
  onOpenRunDialog: () => void;
  alignment: 'center' | 'left';
}

const PINNED_APPS: { id: AppId; name: string; icon: typeof Activity }[] = [
  { id: 'taskmgr', name: 'Task Manager', icon: Activity },
  { id: 'launcher', name: 'PC App Hub', icon: Grid },
  { id: 'terminal', name: 'Command Prompt', icon: Terminal },
  { id: 'explorer', name: 'File Explorer', icon: Folder },
  { id: 'calc', name: 'Calculator', icon: Calculator },
  { id: 'notepad', name: 'Notepad', icon: FileText },
  { id: 'browser', name: 'Microsoft Edge', icon: Globe },
  { id: 'settings', name: 'Settings', icon: Settings },
];

export function Taskbar({
  windows,
  activeWindowId,
  onOpenApp,
  onToggleWindow,
  isStartOpen,
  onToggleStart,
  onOpenRunDialog,
  alignment,
}: TaskbarProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (d: Date) =>
    d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const formatDate = (d: Date) =>
    d.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: 'numeric' });

  return (
    <div className="fixed bottom-0 left-0 right-0 h-12 bg-slate-950/85 acrylic-blur border-t border-slate-800/80 z-40 flex items-center justify-between px-3 select-none font-sans">
      {/* Left side empty space or left-aligned apps */}
      {alignment === 'center' ? (
        <div className="w-48 flex items-center gap-2 text-xs text-slate-400 font-mono">
          <span className="hidden md:inline-block font-semibold text-slate-300">PC Station</span>
        </div>
      ) : null}

      {/* Center Apps Container (or left-aligned if selected) */}
      <div
        className={`flex items-center gap-1.5 ${
          alignment === 'center' ? 'mx-auto' : 'flex-1'
        }`}
      >
        {/* Windows Start Button */}
        <button
          onClick={onToggleStart}
          className={`w-10 h-10 rounded-md flex items-center justify-center transition-all ${
            isStartOpen
              ? 'bg-sky-500/20 text-sky-400'
              : 'hover:bg-white/10 text-sky-400'
          }`}
          title="Start (⊞)"
        >
          <div className="w-5 h-5 flex items-center justify-center font-bold text-base leading-none">
            ⊞
          </div>
        </button>

        {/* Search Button */}
        <button
          onClick={onOpenRunDialog}
          className="w-10 h-10 rounded-md flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Search / Run (Win + R)"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Pinned & Running Apps */}
        {PINNED_APPS.map((app) => {
          const Icon = app.icon;
          const openWin = windows.find((w) => w.appId === app.id);
          const isOpen = Boolean(openWin);
          const isActive = openWin && activeWindowId === openWin.id && !openWin.isMinimized;

          return (
            <button
              key={app.id}
              onClick={() => {
                if (openWin) {
                  onToggleWindow(openWin.id);
                } else {
                  onOpenApp(app.id);
                }
              }}
              className={`relative w-10 h-10 rounded-md flex items-center justify-center transition-all group ${
                isActive
                  ? 'bg-white/15 text-sky-400'
                  : isOpen
                  ? 'bg-white/5 text-slate-200 hover:bg-white/10'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/10'
              }`}
              title={app.name}
            >
              <Icon className="w-4 h-4 transition-transform group-hover:scale-110" />

              {/* Running Indicator Line */}
              {isOpen && (
                <div
                  className={`absolute bottom-1 w-2 h-0.5 rounded-full transition-all ${
                    isActive ? 'bg-sky-400 w-4' : 'bg-slate-400'
                  }`}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Right System Tray & Clock */}
      <div className="flex items-center gap-1.5 text-slate-300">
        {/* Quick Indicators */}
        <div className="flex items-center gap-2 px-2 py-1 rounded hover:bg-white/10 cursor-pointer text-slate-400 hover:text-slate-200 transition-colors">
          <Wifi className="w-3.5 h-3.5 text-sky-400" />
          <Volume2 className="w-3.5 h-3.5" />
          <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
        </div>

        {/* Clock & Date */}
        <div className="px-2 py-1 rounded hover:bg-white/10 cursor-pointer text-right transition-colors">
          <div className="text-xs font-semibold tabular-nums text-slate-200">
            {formatTime(time)}
          </div>
          <div className="text-[10px] text-slate-400 tabular-nums">
            {formatDate(time)}
          </div>
        </div>

        {/* Show Desktop Line Strip */}
        <div className="w-1.5 h-8 border-l border-slate-700/80 ml-1 hover:bg-white/20 transition-colors cursor-pointer" title="Show Desktop" />
      </div>
    </div>
  );
}
