import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  CalendarDays,
  CarFront,
  Check,
  ChevronLeft,
  Compass,
  Home,
  MapPin,
  Menu,
  Plus,
  Sparkles,
  SunMedium,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { CITIES, getCity } from "@/lib/cities";
import { cn } from "@/lib/cn";
import type { DayBrief, LiveReading } from "@/lib/panchang/engine";
import { artFor, type Festival } from "@/lib/panchang/festivals";
import { useApp, type Task } from "@/lib/store";
import { formatRange, formatShort, formatTime, formatUntil } from "@/lib/time";

export function useReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const finish = () => setReady(true);
    if (useApp.persist.hasHydrated()) finish();
    return useApp.persist.onFinishHydration(finish);
  }, []);
  return ready;
}

const NAV = [
  { to: "/", label: "Today", icon: SunMedium, test: (path: string) => path === "/" },
  { to: "/calendar", label: "Calendar", icon: CalendarDays, test: (path: string) => path.startsWith("/calendar") || path.startsWith("/day") },
  { to: "/muhurat", label: "Muhurat", icon: Sparkles, test: (path: string) => path.startsWith("/muhurat") },
  { to: "/tasks", label: "Tasks", icon: Check, test: (path: string) => path.startsWith("/tasks") },
  { to: "/more", label: "More", icon: Menu, test: (path: string) => path.startsWith("/more") || path.startsWith("/festivals") },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const tasks = useApp((state) => state.tasks);
  const markNotified = useApp((state) => state.markNotified);

  useEffect(() => {
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const now = Date.now();
    for (const task of tasks) {
      if (!task.remind || task.done || task.notified || !task.date) continue;
      const when = new Date(`${task.date}T${task.time || "09:00"}:00+05:30`).getTime();
      if (Number.isNaN(when)) continue;
      if (when <= now && now - when < 18 * 3_600_000) {
        new Notification("SUMAN", { body: task.title });
        markNotified(task.id);
      }
    }
  }, [tasks, markNotified]);

  return (
    <div className="phone-col bg-bg text-cream">
      <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
      <nav className="grid shrink-0 grid-cols-5 border-t border-line bg-bg/95 pb-2 backdrop-blur" aria-label="Primary">
        {NAV.map((item) => {
          const on = item.test(path);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-14 flex-col items-center justify-center gap-1 micro",
                on ? "text-gold" : "text-muted",
              )}
            >
              <Icon size={18} strokeWidth={1.75} aria-hidden="true" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function Splash() {
  return (
    <div className="app-frame text-cream">
      <aside className="brand-pane">
        <img src="/art/temple.jpg" alt="" className="h-full w-full object-cover" />
      </aside>
      <div className="phone-col justify-end bg-bg">
        <div className="relative h-80">
          <img src="/art/temple.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-bg to-transparent" />
        </div>
        <div className="px-6 pb-16">
          <p className="eyebrow">Hindu calendar</p>
          <h1 className="mt-2 font-serif text-6xl leading-none">SUMAN</h1>
          <p className="mt-3 text-muted">2027 · Panchang, festivals, muhurat</p>
        </div>
      </div>
    </div>
  );
}

export function CityButton() {
  const cityId = useApp((state) => state.cityId);
  const setCity = useApp((state) => state.setCity);
  const [open, setOpen] = useState(false);
  const city = getCity(cityId);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="inline-flex items-center gap-1 text-sm text-gold">
        <MapPin size={14} aria-hidden="true" />
        {city.name}
      </button>
      {open ? (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/70" onClick={() => setOpen(false)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Choose a city"
            className="sheet w-full max-w-md overflow-y-auto rounded-t-3xl border border-line bg-surface p-4"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <p className="font-serif text-2xl">City</p>
              <button type="button" aria-label="Close" onClick={() => setOpen(false)} className="grid size-10 place-items-center text-muted">
                <X size={18} />
              </button>
            </div>
            <ul className="flex flex-col">
              {CITIES.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className="flex w-full items-center justify-between border-t border-line py-3 text-left"
                    onClick={() => {
                      setCity(item.id);
                      setOpen(false);
                    }}
                  >
                    <span>
                      <span className="block text-cream">{item.name}</span>
                      <span className="text-sm text-muted">{item.region}</span>
                    </span>
                    {item.id === cityId ? <Check size={16} className="text-gold" /> : null}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}
    </>
  );
}

function within(now: Date, window: { start: Date; end: Date }) {
  return now >= window.start && now <= window.end;
}

export function PanchangGrid({ live, anchor }: { live: LiveReading; anchor: Date }) {
  const cells = [
    ["Tithi", live.tithiName, formatUntil(live.tithiEnd, anchor)],
    ["Nakshatra", live.nakshatraName, `Pada ${live.pada} · ${formatUntil(live.nakshatraEnd, anchor)}`],
    ["Yoga", live.yogaName, formatUntil(live.yogaEnd, anchor)],
    ["Karana", live.karanaName, formatUntil(live.karanaEnd, anchor)],
  ];
  return (
    <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line">
      {cells.map(([label, value, until]) => (
        <div key={label} className="bg-surface px-4 py-3">
          <p className="eyebrow">{label}</p>
          <p className="mt-1 font-serif text-2xl leading-none text-cream">{value}</p>
          <p className="mt-2 text-xs text-muted">{until}</p>
        </div>
      ))}
    </div>
  );
}

export function TimingList({ day, now }: { day: DayBrief; now?: Date }) {
  const rows = [
    ["Rahu Kalam", day.timings.rahu, false],
    ["Yamaganda", day.timings.yamaganda, false],
    ["Gulika Kalam", day.timings.gulika, false],
    ["Abhijit Muhurat", day.timings.abhijit, true],
    ["Brahma Muhurta", day.timings.brahma, true],
  ] as const;
  return (
    <ul className="overflow-hidden rounded-2xl border border-line">
      {rows.map(([label, window, good]) => {
        const active = now ? within(now, window) : false;
        return (
          <li key={label} className="flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3 last:border-b-0">
            <div>
              <p className={cn("text-sm", good ? "text-auspicious" : "text-inauspicious")}>{label}</p>
              <p className="tabular-nums text-cream">{formatRange(window.start, window.end)}</p>
            </div>
            {active ? <span className="eyebrow">Now</span> : null}
          </li>
        );
      })}
    </ul>
  );
}

export function EventCard({ event, compact = false }: { event: Festival; compact?: boolean }) {
  return (
    <Link
      to="/day/$date"
      params={{ date: event.date }}
      className="block overflow-hidden rounded-2xl border border-line bg-surface"
    >
      <div className={cn("relative", compact ? "h-24" : "h-36")}>
        <img src={artFor(event.name)} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/75 to-bg/10" />
        <div className="absolute inset-0 flex flex-col justify-end p-4">
          <p className="eyebrow">{formatShort(event.date)}</p>
          <p className={cn("font-serif leading-tight text-cream", compact ? "text-xl" : "text-3xl")}>{event.name}</p>
        </div>
      </div>
      {event.note && !compact ? <p className="px-4 py-3 text-sm leading-relaxed text-muted">{event.note}</p> : null}
    </Link>
  );
}

export function SunMoon({ day }: { day: DayBrief }) {
  const items = [
    ["Sunrise", day.sunrise],
    ["Sunset", day.sunset],
    ["Moonrise", day.moonrise],
    ["Moonset", day.moonset],
  ] as const;
  return (
    <div className="grid grid-cols-4 gap-2">
      {items.map(([label, value]) => (
        <div key={label} className="text-center">
          <p className="micro text-muted">{label}</p>
          <p className="mt-1 text-sm tabular-nums text-cream">{value ? formatTime(value) : "—"}</p>
        </div>
      ))}
    </div>
  );
}

export function BackButton({ fallback = "/calendar" }: { fallback?: "/" | "/calendar" | "/more" | "/festivals" | "/muhurat" | "/tasks" }) {
  const router = useRouter();
  return (
    <button
      type="button"
      className="inline-flex items-center gap-1 text-sm text-gold"
      onClick={() => {
        if (window.history.length > 1) router.history.back();
        else void router.navigate({ to: fallback });
      }}
    >
      <ChevronLeft size={16} aria-hidden="true" />
      Back
    </button>
  );
}

export function TaskDialog({
  open,
  onClose,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  initial?: { title?: string; date?: string; notes?: string };
}) {
  const addTask = useApp((state) => state.addTask);
  const [title, setTitle] = useState(initial?.title ?? "");
  const [date, setDate] = useState(initial?.date ?? "2027-01-15");
  const [time, setTime] = useState("09:00");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [remind, setRemind] = useState(true);

  useEffect(() => {
    if (!open) return;
    setTitle(initial?.title ?? "");
    setDate(initial?.date ?? "2027-01-15");
    setNotes(initial?.notes ?? "");
    setTime("09:00");
    setRemind(true);
  }, [open, initial?.title, initial?.date, initial?.notes]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center" onClick={onClose}>
      <form
        role="dialog"
        aria-modal="true"
        aria-labelledby="task-dialog-title"
        className="w-full max-w-md rounded-t-3xl border border-line bg-surface p-5 sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
        onSubmit={(event) => {
          event.preventDefault();
          const trimmed = title.trim();
          if (!trimmed) return;
          addTask({ title: trimmed, notes: notes.trim(), date, time, remind });
          if (remind && typeof Notification !== "undefined" && Notification.permission === "default") {
            void Notification.requestPermission();
          }
          toast("Reminder saved", { className: "suman-toast" });
          onClose();
        }}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="task-dialog-title" className="font-serif text-3xl">
            New reminder
          </h2>
          <button type="button" aria-label="Close" onClick={onClose} className="grid size-10 place-items-center text-muted">
            <X size={18} />
          </button>
        </div>
        <div className="flex flex-col gap-3">
          <label className="text-sm text-muted">
            Title
            <input className="field mt-1" value={title} onChange={(event) => setTitle(event.target.value)} required maxLength={80} />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm text-muted">
              Date
              <input className="field mt-1" type="date" value={date} min="2026-01-01" max="2027-12-31" onChange={(event) => setDate(event.target.value)} required />
            </label>
            <label className="text-sm text-muted">
              Time
              <input className="field mt-1" type="time" value={time} onChange={(event) => setTime(event.target.value)} />
            </label>
          </div>
          <label className="text-sm text-muted">
            Note
            <textarea className="field mt-1" rows={3} value={notes} maxLength={280} onChange={(event) => setNotes(event.target.value)} />
          </label>
          <label className="flex items-center gap-2 text-sm text-cream">
            <input type="checkbox" checked={remind} onChange={(event) => setRemind(event.target.checked)} />
            Remind me
          </label>
          <button type="submit" className="mt-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-gold text-bg">
            <Plus size={16} aria-hidden="true" />
            Save
          </button>
        </div>
      </form>
    </div>
  );
}

export function TaskRow({ task }: { task: Task }) {
  const toggleTask = useApp((state) => state.toggleTask);
  const removeTask = useApp((state) => state.removeTask);
  const [armed, setArmed] = useState(false);
  return (
    <li className="flex items-start gap-3 border-b border-line py-3">
      <button
        type="button"
        aria-label={task.done ? "Mark not done" : "Mark done"}
        onClick={() => toggleTask(task.id)}
        className={cn(
          "mt-0.5 grid size-6 shrink-0 place-items-center rounded-full border",
          task.done ? "border-gold bg-gold text-bg" : "border-gold-dim text-transparent",
        )}
      >
        <Check size={14} />
      </button>
      <div className="min-w-0 flex-1">
        <p className={cn("text-cream", task.done && "text-muted line-through")}>{task.title}</p>
        <p className="text-sm text-muted">
          {formatShort(task.date)}
          {task.time ? ` · ${task.time}` : ""}
          {task.remind ? " · reminder" : ""}
        </p>
        {task.notes ? <p className="mt-1 text-sm text-muted">{task.notes}</p> : null}
      </div>
      <button
        type="button"
        className="text-sm text-muted"
        onClick={() => {
          if (!armed) {
            setArmed(true);
            return;
          }
          removeTask(task.id);
        }}
      >
        {armed ? "Remove" : <Trash2 size={16} aria-label="Delete reminder" />}
      </button>
    </li>
  );
}

export const MUHURAT_ICONS = {
  marriage: Sparkles,
  griha: Home,
  vehicle: CarFront,
  property: Compass,
  beginnings: Bell,
} as const;

export function dueLabel(task: Task, today: string): string | null {
  if (task.done) return null;
  if (task.date === today) return "Today";
  if (task.date < today) return "Overdue";
  return null;
}

export function isSameDay(task: Task, iso: string) {
  return task.date === iso;
}
