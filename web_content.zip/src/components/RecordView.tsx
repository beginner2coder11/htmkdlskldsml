import React from 'react';
import {
  Circle,
  Square,
  Pause,
  Play,
  Camera,
  Mic,
  MicOff,
  PenTool,
  Volume2,
  Sliders,
  Sparkles,
  Smartphone,
  HardDrive,
  Info,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import {
  RecorderSettings,
  RecorderStatus,
  RESOLUTION_PRESETS,
} from '../types/recorder';
import { formatDuration, formatFileSize } from '../utils/mediaExport';

interface RecordViewProps {
  status: RecorderStatus;
  countdownValue: number;
  elapsedTime: number;
  micVolumeLevel: number;
  settings: RecorderSettings;
  setSettings: React.Dispatch<React.SetStateAction<RecorderSettings>>;
  monitorVideoRef: React.RefObject<HTMLVideoElement | null>;
  onStartRecord: () => void;
  onPauseRecord: () => void;
  onResumeRecord: () => void;
  onStopRecord: () => void;
  onTakeScreenshot: () => void;
  onToggleFacecam: () => void;
  onToggleBrush: () => void;
  onOpenSettings: () => void;
  errorMessage: string | null;
  onDismissError: () => void;
}

export const RecordView: React.FC<RecordViewProps> = ({
  status,
  countdownValue,
  elapsedTime,
  micVolumeLevel,
  settings,
  setSettings,
  monitorVideoRef,
  onStartRecord,
  onPauseRecord,
  onResumeRecord,
  onStopRecord,
  onTakeScreenshot,
  onToggleFacecam,
  onToggleBrush,
  onOpenSettings,
  errorMessage,
  onDismissError,
}) => {
  const isRecording = status === 'recording' || status === 'paused';
  const currentRes = RESOLUTION_PRESETS[settings.resolution];

  // Estimated live recorded file size based on bitrate and elapsed time
  const estimatedSizeBytes = Math.round(((settings.bitrate * 1000000) / 8) * (elapsedTime || 1));

  return (
    <div className="flex flex-col gap-6 w-full pb-20">
      {/* Error alert if permission denied or error */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-950/80 border border-red-800 text-red-200 flex items-start justify-between gap-3 animate-in fade-in">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-red-100">Screen Recording Notice</p>
              <p className="text-red-300 mt-0.5 text-xs">{errorMessage}</p>
            </div>
          </div>
          <button
            onClick={onDismissError}
            className="text-xs text-red-300 hover:text-white px-2 py-1 rounded bg-red-900/60 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Screen Monitor / Preview Canvas */}
      <div className="relative w-full aspect-video sm:aspect-[21/9] md:aspect-[16/8] bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col justify-between p-4 sm:p-6 group">
        {/* Hidden video element that receives the screen stream */}
        <video
          ref={monitorVideoRef}
          autoPlay
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-contain bg-black ${
            isRecording ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        />

        {/* Ambient background simulation when idle */}
        {!isRecording && (
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 flex items-center justify-center p-6 text-center">
            {/* Subtle grid pattern */}
            <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#3b82f6_1px,transparent_1px),linear-gradient(to_bottom,#3b82f6_1px,transparent_1px)] bg-[size:40px_40px]" />
            <div className="relative z-10 max-w-md flex flex-col items-center">
              <div className="w-16 h-16 rounded-3xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-4 shadow-xl">
                <Smartphone className="w-8 h-8" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Mobile & Full Screen HD Recorder
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                <span>{currentRes.label}</span>
                <span aria-hidden="true">·</span>
                <span>{settings.fps} FPS</span>
                <span aria-hidden="true">·</span>
                <span>{settings.bitrate} Mbps</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 uppercase font-semibold">
                  {settings.exportFormat}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Top Status Header inside Monitor */}
        <div className="relative z-10 flex items-center justify-between w-full">
          <div className="flex items-center gap-2">
            {isRecording ? (
              <div className="flex items-center gap-2 px-3 py-1 bg-red-600/90 text-white rounded-full text-xs font-semibold shadow-lg">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                <span>REC</span>
                <span className="font-mono tabular-nums ml-1">
                  {formatDuration(elapsedTime)}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1 bg-slate-800/80 backdrop-blur-md border border-slate-700/60 rounded-full text-xs text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Ready to Capture</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800/80 backdrop-blur-md border border-slate-700/60 text-slate-300 font-mono">
              {currentRes.badge}
            </span>
            <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800/80 backdrop-blur-md border border-slate-700/60 text-blue-400 font-medium uppercase">
              {settings.exportFormat}
            </span>
          </div>
        </div>

        {/* Bottom Audio & Status HUD inside Monitor */}
        <div className="relative z-10 flex items-end justify-between w-full pt-6">
          {/* Live Audio Visualizer Bar */}
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md border border-slate-800 px-3 py-1.5 rounded-2xl">
            {settings.audioSource === 'none' ? (
              <MicOff className="w-4 h-4 text-slate-500" />
            ) : (
              <Mic className="w-4 h-4 text-emerald-400" />
            )}
            <div className="flex items-center gap-0.5 h-3.5 w-16">
              {[15, 30, 45, 60, 75, 90].map((threshold, idx) => {
                const isActive = micVolumeLevel >= threshold;
                return (
                  <div
                    key={idx}
                    className={`flex-1 rounded-full transition-all duration-75 ${
                      isActive
                        ? threshold > 70
                          ? 'bg-amber-400 h-full'
                          : 'bg-emerald-400 h-full'
                        : 'bg-slate-700 h-1.5'
                    }`}
                  />
                );
              })}
            </div>
            <span className="text-[10px] text-slate-400 font-mono tabular-nums">
              {settings.audioSource === 'none' ? 'Mute' : `${micVolumeLevel}%`}
            </span>
          </div>

          {/* Quick HUD controls when recording */}
          {isRecording && (
            <div className="flex items-center gap-2">
              <button
                onClick={onTakeScreenshot}
                title="Instant Screenshot"
                className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white shadow-lg cursor-pointer"
              >
                <Camera className="w-4 h-4" />
              </button>
              <button
                onClick={onToggleBrush}
                title="Screen Brush"
                className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white shadow-lg cursor-pointer"
              >
                <PenTool className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Countdown Overlay */}
        {status === 'countdown' && (
          <div className="absolute inset-0 z-30 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center animate-in fade-in">
            <div className="relative flex items-center justify-center">
              {/* Concentric pulsing rings */}
              <div className="absolute w-36 h-36 rounded-full border-4 border-blue-500/30 animate-ping" />
              <div className="absolute w-28 h-28 rounded-full border-4 border-blue-400/50" />
              <div className="w-20 h-20 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-4xl shadow-2xl">
                {countdownValue}
              </div>
            </div>
            <p className="text-white font-medium text-sm mt-6 tracking-wide">
              Recording starting in {countdownValue}s...
            </p>
            <p className="text-slate-400 text-xs mt-1">Get your screen or mobile ready</p>
          </div>
        )}
      </div>

      {/* Main Recording Control Strip (Natural Reach Thumb Zone) */}
      <div className="flex flex-col items-center justify-center p-6 bg-slate-900/60 rounded-3xl border border-slate-800">
        {!isRecording ? (
          <div className="flex flex-col items-center gap-4">
            {/* Primary Big Record Trigger Button (Google Stitch Style) */}
            <div className="relative group">
              <div className="absolute -inset-2 bg-gradient-to-r from-red-600 to-rose-600 rounded-full opacity-40 blur-lg group-hover:opacity-75 transition-opacity duration-300" />
              <button
                onClick={onStartRecord}
                className="relative w-20 h-20 rounded-full bg-red-600 hover:bg-red-500 active:scale-95 text-white flex items-center justify-center shadow-2xl transition-transform cursor-pointer border-4 border-slate-900"
                aria-label="Start recording screen"
              >
                <Circle className="w-9 h-9 fill-current" />
              </button>
            </div>
            <div className="text-center">
              <p className="text-base font-semibold text-white">Start Recording</p>
              <div className="flex items-center justify-center gap-2 text-xs text-slate-400 mt-1">
                <span>Full Screen</span>
                <span aria-hidden="true">·</span>
                <span>High Definition MP4</span>
                <span aria-hidden="true">·</span>
                <span>Local Storage</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 w-full max-w-sm">
            {/* Live Stats */}
            <div className="flex items-center justify-between w-full px-4 py-2 bg-slate-800/50 rounded-2xl border border-slate-700/50 text-xs">
              <div className="flex flex-col">
                <span className="text-slate-400">Duration</span>
                <span className="text-white font-bold font-mono text-base tabular-nums">
                  {formatDuration(elapsedTime)}
                </span>
              </div>
              <div className="h-6 w-px bg-slate-700" />
              <div className="flex flex-col items-center">
                <span className="text-slate-400">Estimated Size</span>
                <span className="text-blue-400 font-bold font-mono text-base tabular-nums">
                  {formatFileSize(estimatedSizeBytes)}
                </span>
              </div>
              <div className="h-6 w-px bg-slate-700" />
              <div className="flex flex-col items-end">
                <span className="text-slate-400">Quality</span>
                <span className="text-emerald-400 font-bold font-mono text-base">
                  {currentRes.badge}
                </span>
              </div>
            </div>

            {/* Recording Controls: Pause/Resume + Stop */}
            <div className="flex items-center gap-4 mt-2">
              {status === 'recording' ? (
                <button
                  onClick={onPauseRecord}
                  title="Pause Recording"
                  className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-sm border border-slate-700 shadow-lg active:scale-95 transition-all cursor-pointer"
                >
                  <Pause className="w-5 h-5 fill-current" />
                  <span>Pause</span>
                </button>
              ) : (
                <button
                  onClick={onResumeRecord}
                  title="Resume Recording"
                  className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg active:scale-95 transition-all cursor-pointer"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>Resume</span>
                </button>
              )}

              <button
                onClick={onStopRecord}
                title="Stop & Export MP4"
                className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm shadow-xl shadow-red-600/30 active:scale-95 transition-all cursor-pointer"
              >
                <Square className="w-5 h-5 fill-current" />
                <span>Stop & Save</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Settings & Tool Affordances (Play Store Style) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Resolution selector */}
        <button
          onClick={onOpenSettings}
          className="flex flex-col p-3.5 bg-slate-900/80 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-colors cursor-pointer"
        >
          <span className="text-[11px] text-slate-400 font-medium">Resolution</span>
          <span className="text-sm font-semibold text-white mt-1 flex items-center justify-between">
            {currentRes.badge}
            <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5 truncate">
            {currentRes.width} × {currentRes.height}
          </span>
        </button>

        {/* Audio Source Quick Toggle */}
        <button
          onClick={() => {
            const nextAudio: RecorderSettings['audioSource'] =
              settings.audioSource === 'mic_and_system'
                ? 'mic_only'
                : settings.audioSource === 'mic_only'
                ? 'system_only'
                : settings.audioSource === 'system_only'
                ? 'none'
                : 'mic_and_system';
            setSettings({ ...settings, audioSource: nextAudio });
          }}
          className="flex flex-col p-3.5 bg-slate-900/80 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-colors cursor-pointer"
        >
          <span className="text-[11px] text-slate-400 font-medium">Audio Source</span>
          <span className="text-sm font-semibold text-white mt-1 flex items-center justify-between">
            {settings.audioSource === 'mic_and_system' && 'Mic + System'}
            {settings.audioSource === 'mic_only' && 'Mic Only'}
            {settings.audioSource === 'system_only' && 'System Only'}
            {settings.audioSource === 'none' && 'Muted'}
            <Volume2 className="w-3.5 h-3.5 text-slate-500" />
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5">Tap to cycle source</span>
        </button>

        {/* Facecam PiP Toggle */}
        <button
          onClick={onToggleFacecam}
          className="flex flex-col p-3.5 bg-slate-900/80 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-colors cursor-pointer"
        >
          <span className="text-[11px] text-slate-400 font-medium">Facecam Camera</span>
          <span className="text-sm font-semibold text-white mt-1 flex items-center justify-between">
            {settings.showFacecam ? 'Enabled' : 'Disabled'}
            <Camera className="w-3.5 h-3.5 text-slate-500" />
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5">Webcam PiP overlay</span>
        </button>

        {/* Floating Bubble Quick Toggle */}
        <button
          onClick={() =>
            setSettings({
              ...settings,
              floatingBallEnabled: !settings.floatingBallEnabled,
            })
          }
          className="flex flex-col p-3.5 bg-slate-900/80 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-colors cursor-pointer"
        >
          <span className="text-[11px] text-slate-400 font-medium">Floating Widget</span>
          <span className="text-sm font-semibold text-white mt-1 flex items-center justify-between">
            {settings.floatingBallEnabled ? 'Active' : 'Hidden'}
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5">Quick bubble access</span>
        </button>
      </div>

      {/* High Definition MP4 Local Export Guarantee Feature Strip */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-slate-900/40 to-indigo-950/40 border border-blue-900/40 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-white">
              High Definition MP4 Local Storage Guarantee
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Exports directly to your device local storage in crystal-clear MP4 with 60 FPS support.
            </p>
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-600/20 text-blue-400 text-xs font-medium">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Lossless</span>
        </div>
      </div>
    </div>
  );
};
