package br.com.nossomercadao.terminalwindows;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Adapter for the browser on THIS PC, not a replacement price/database server. */
public final class TerminalWindows {
    private static final int UI_PORT=8787;
    private static final String ORIGIN="http://127.0.0.1:"+UI_PORT;
    private static final Properties config=new Properties();
    private static final Object sessionLock=new Object();
    private static volatile Session session;
    private static Path configFile;
    private static final ExecutorService httpWorkers=Executors.newFixedThreadPool(8);
    private static final String[] FIELDS={"serverIp","clientIp","mask","gateway","url","port","terminalName","interface","mode","dhcp","speak","welcome","notFound"};
    private static final Set<String> KEYS=new HashSet<String>(Arrays.asList(FIELDS));

    public static void main(String[] args) throws Exception {
        File jar=new File(TerminalWindows.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        Path directory=(jar.isFile()?jar.getParentFile():jar).toPath();
        configFile=directory.resolve("terminal.properties");
        defaults();
        if(Files.exists(configFile))try(InputStream in=Files.newInputStream(configFile)){config.load(in);}
        HttpServer server;
        try{server=HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),UI_PORT),0);}
        catch(BindException e){System.err.println("Porta local 8787 ocupada. Feche a janela anterior do terminal ou o programa que utiliza essa porta.");return;}
        server.createContext("/",TerminalWindows::handle);server.setExecutor(httpWorkers);server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(()->{server.stop(0);httpWorkers.shutdownNow();synchronized(sessionLock){if(session!=null)session.client.dispose();}}));
        try{if(!config.getProperty("serverIp","").isEmpty()&&"tcp".equals(config.getProperty("mode")))ensure(snapshot());}catch(Exception e){System.out.println("Configuração anterior: "+e.getMessage());}
        System.out.println("NOSSO MERCADAO - TERMINAL WINDOWS");
        System.out.println("Interface: "+ORIGIN);
        System.out.println("Mantenha esta janela aberta. Configure o IP do GERENCIADOR JAVA, nao o IP do banco nem o de outro terminal.");
        System.out.println("Ctrl+C para encerrar.");
        try{if(Desktop.isDesktopSupported())Desktop.getDesktop().browse(URI.create(ORIGIN));}catch(Exception e){System.out.println("Abra manualmente o endereço acima no Chrome.");}
    }
    private static synchronized void defaults(){
        config.setProperty("serverIp","");config.setProperty("clientIp","");config.setProperty("mask","255.255.255.0");
        config.setProperty("gateway","");config.setProperty("url","");config.setProperty("port","6500");config.setProperty("terminalName","TC 506E WINDOWS");
        config.setProperty("interface","ethernet");config.setProperty("mode","tcp");config.setProperty("dhcp","sim");config.setProperty("speak","false");
        config.setProperty("welcome","CONSULTE AQUI O PREÇO DO PRODUTO");config.setProperty("notFound","PRODUTO NÃO CADASTRADO");
    }
    private static synchronized Properties snapshot(){Properties result=new Properties();result.putAll(config);return result;}
    private static boolean local(String host){
        String[] a=host.split("\\.",-1);if(a.length!=4)return false;int[] n=new int[4];
        try{for(int i=0;i<4;i++){if(!a[i].matches("[0-9]{1,3}")||(a[i].length()>1&&a[i].charAt(0)=='0'))return false;n[i]=Integer.parseInt(a[i]);if(n[i]>255)return false;}}catch(Exception e){return false;}
        return n[0]==10||(n[0]==192&&n[1]==168)||(n[0]==172&&n[1]>=16&&n[1]<=31)||host.equals("127.0.0.1");
    }
    private static int port(Properties p){int port=Integer.parseInt(p.getProperty("port","6500"));if(port<1||port>65535)throw new IllegalArgumentException("Porta inválida");return port;}
    private static void validate(Properties p,boolean requireHost){
        String host=p.getProperty("serverIp","").trim(),bind=p.getProperty("clientIp","").trim();
        if(requireHost&&host.isEmpty())throw new IllegalArgumentException("Configure o IP do gerenciador Java na aba Rede.");
        if(!host.isEmpty()&&!local(host))throw new IllegalArgumentException("IP Servidor precisa ser IPv4 privado da loja.");
        if(!bind.isEmpty()&&!local(bind))throw new IllegalArgumentException("IP Cliente inválido. Deixe vazio para usar a rede do Windows.");
        if(!"tcp".equals(p.getProperty("mode"))&&!"http".equals(p.getProperty("mode")))throw new IllegalArgumentException("Modo de comunicação inválido.");
        port(p);
    }
    private static Session ensure(Properties p){
        validate(p,true);
        String key=p.getProperty("serverIp")+":"+port(p)+"/"+p.getProperty("clientIp","");
        synchronized(sessionLock){
            if(session!=null&&session.key.equals(key))return session;
            Session old=session;session=null;if(old!=null)old.client.dispose();
            session=new Session(key,p);return session;
        }
    }
    private static void discard(Session failed){synchronized(sessionLock){if(session==failed){session=null;failed.client.dispose();}}}
    private static class Product {final String code,name,price;Product(String c,String n,String p){code=c;name=n;price=p;}}
    private static class Session implements Tc506Client.Listener {
        final String key;final Tc506Client client;final CountDownLatch firstReady=new CountDownLatch(1);
        volatile String message="Conectando ao gerenciador...";
        volatile boolean connected;
        volatile CompletableFuture<Product> pending;
        volatile String code;
        Session(String k,Properties p){key=k;client=new Tc506Client(this);client.configure(p.getProperty("serverIp"),port(p),p.getProperty("clientIp",""));client.start();}
        public void state(String text,boolean ok){message=text;connected=ok;if(ok)firstReady.countDown();else{CompletableFuture<Product> future=pending;if(future!=null)future.completeExceptionally(new IOException(text));}System.out.println(text);}
        public void log(String text){System.out.println(text);}
        public void product(String received,String name,String price){CompletableFuture<Product> future=pending;if(future!=null&&received.equals(code))future.complete(new Product(received,name,price));}
        void ready() throws Exception{
            if(!connected)firstReady.await(5,TimeUnit.SECONDS);
            if(!connected)throw new IOException(message+". Verifique IP, porta, firewall e se o gerenciador envia #ok.");
        }
        synchronized Product query(String barcode)throws Exception{
            ready();code=barcode;CompletableFuture<Product> future=new CompletableFuture<Product>();pending=future;
            try{client.query(barcode);return future.get(7,TimeUnit.SECONDS);}
            catch(TimeoutException e){discard(this);throw new IOException("O gerenciador não respondeu ao código. A sessão foi reiniciada para não exibir resposta de outra consulta.");}
            catch(ExecutionException e){throw new IOException(e.getCause().getMessage());}
            finally{pending=null;code=null;}
        }
    }
    private static void handle(HttpExchange ex)throws IOException{
        try{
            String host=ex.getRequestHeaders().getFirst("Host");
            String origin=ex.getRequestHeaders().getFirst("Origin");
            boolean hostOK=("127.0.0.1:"+UI_PORT).equals(host)||("localhost:"+UI_PORT).equals(host);
            boolean originOK=origin==null||ORIGIN.equals(origin)||("http://localhost:"+UI_PORT).equals(origin);
            if(!ex.getRemoteAddress().getAddress().isLoopbackAddress()||!hostOK||!originOK){send(ex,403,"Acesso permitido somente pela interface local deste computador.","text/plain");return;}
            String path=ex.getRequestURI().getPath(),method=ex.getRequestMethod();
            if("/".equals(path)||"/consulta_terminal.html".equals(path)){if(!"GET".equals(method)){send(ex,405,"Método inválido","text/plain");return;}resource(ex,"/web/consulta_terminal.html","text/html");return;}
            if("/windows-bridge.js".equals(path)){resource(ex,"/web/windows-bridge.js","application/javascript");return;}
            if("/api/config".equals(path)){
                if("GET".equals(method)){send(ex,200,configJson(snapshot()),"application/json");return;}
                Properties incoming=body(ex);Properties next=snapshot();for(String key:KEYS)if(incoming.containsKey(key))next.setProperty(key,incoming.getProperty(key));validate(next,false);
                Path temp=configFile.resolveSibling("terminal.properties.tmp");try(OutputStream out=Files.newOutputStream(temp)){next.store(out,"Nosso Mercadao - terminal Windows");}
                Files.move(temp,configFile,StandardCopyOption.REPLACE_EXISTING);
                synchronized(TerminalWindows.class){config.clear();config.putAll(next);}
                if(!next.getProperty("serverIp","").isEmpty()&&"tcp".equals(next.getProperty("mode")))ensure(next);
                else synchronized(sessionLock){if(session!=null){session.client.dispose();session=null;}}
                send(ex,200,"{\"ok\":true}","application/json");return;
            }
            if("/api/status".equals(path)){Session s=session;send(ex,200,"{\"connected\":"+(s!=null&&s.connected)+",\"message\":"+quote(s==null?"Configure o IP do gerenciador na aba Rede.":s.message)+"}","application/json");return;}
            if("/api/query".equals(path)){
                Properties p=body(ex);validate(p,true);String code=p.getProperty("codigo","");boolean test="true".equals(p.getProperty("test"));
                if(!test&&!code.matches("[0-9]{4,40}"))throw new IllegalArgumentException("Informe um código numérico de 4 a 40 dígitos.");
                if(!test&&"http".equals(p.getProperty("mode"))){send(ex,200,http(p,code),"application/json");return;}
                Session current=ensure(p);
                if(test){current.ready();send(ex,200,"{\"ok\":true}","application/json");return;}
                Product result=current.query(code);
                String json=result.price.isEmpty()?"{\"encontrado\":false}":"{\"descricao\":"+quote(result.name)+",\"preco\":"+quote(result.price)+",\"codigo\":"+quote(result.code)+"}";
                send(ex,200,json,"application/json");return;
            }
            send(ex,404,"Endereço não encontrado","text/plain");
        }catch(Exception e){try{send(ex,503,e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(),"text/plain");}catch(IOException ignored){}}
        finally{ex.close();}
    }
    private static Properties body(HttpExchange ex)throws Exception{
        if(!"POST".equals(ex.getRequestMethod()))throw new IllegalArgumentException("Use POST para esta operação.");
        String type=ex.getRequestHeaders().getFirst("Content-Type");
        if(type==null||!type.startsWith("application/x-www-form-urlencoded"))throw new IllegalArgumentException("Formato de requisição inválido.");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;
        while((n=ex.getRequestBody().read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>65536)throw new IllegalArgumentException("Requisição muito grande.");}
        Properties p=new Properties();String encoded=new String(out.toByteArray(),StandardCharsets.UTF_8);
        if(!encoded.isEmpty())for(String pair:encoded.split("&")){String[] parts=pair.split("=",2);p.setProperty(URLDecoder.decode(parts[0],"UTF-8"),parts.length==2?URLDecoder.decode(parts[1],"UTF-8"):"");}
        return p;
    }
    private static String http(Properties p,String code)throws Exception{
        String path=p.getProperty("url","");
        if(!path.startsWith("/")||path.startsWith("//")||!path.contains("{codigo}")||path.indexOf('\r')>=0||path.indexOf('\n')>=0)throw new IllegalArgumentException("Configure o caminho HTTP com {codigo}.");
        HttpURLConnection c=(HttpURLConnection)new URL("http",p.getProperty("serverIp"),port(p),path.replace("{codigo}",code)).openConnection(Proxy.NO_PROXY);
        try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(4000);c.setReadTimeout(7000);int status=c.getResponseCode();if(status<200||status>=300)throw new IOException("Serviço retornou HTTP "+status);
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>1048576)throw new IOException("Resposta muito grande.");}return new String(out.toByteArray(),StandardCharsets.UTF_8);}
        }finally{c.disconnect();}
    }
    private static String configJson(Properties p){StringBuilder out=new StringBuilder("{");boolean first=true;for(String key:FIELDS){if(!first)out.append(',');first=false;out.append(quote(key)).append(':');String value=p.getProperty(key,"");out.append("speak".equals(key)?String.valueOf(Boolean.parseBoolean(value)):quote(value));}return out.append('}').toString();}
    private static String quote(String s){StringBuilder b=new StringBuilder("\"");for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'||c=='\\')b.append('\\').append(c);else if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}return b.append('"').toString();}
    private static void resource(HttpExchange ex,String path,String type)throws IOException{try(InputStream in=TerminalWindows.class.getResourceAsStream(path)){if(in==null){send(ex,404,"Recurso não encontrado","text/plain");return;}ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);sendBytes(ex,200,out.toByteArray(),type);}}
    private static void send(HttpExchange ex,int status,String body,String type)throws IOException{sendBytes(ex,status,body.getBytes(StandardCharsets.UTF_8),type);}
    private static void sendBytes(HttpExchange ex,int status,byte[] data,String type)throws IOException{ex.getResponseHeaders().set("Content-Type",type+"; charset=UTF-8");ex.getResponseHeaders().set("Cache-Control","no-store");ex.getResponseHeaders().set("X-Content-Type-Options","nosniff");ex.sendResponseHeaders(status,data.length);ex.getResponseBody().write(data);}
}
