package br.com.nossomercadao.terminalwindows;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Cliente TCP iniciado pelo terminal (celular), no estilo TC506.
 * O servidor precisa aceitar o protocolo Gertec; conectar na porta não garante compatibilidade.
 */
public class Tc506Client {
    public interface Listener {
        void state(String message, boolean connected);
        void product(String code, String name, String price);
        void log(String message);
    }
    private static final Charset WIRE = Charset.forName("ISO-8859-1");
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService actions = Executors.newSingleThreadExecutor();
    private final Listener listener;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile Socket socket;
    private volatile String pendingCode;
    private volatile String host = "192.168.1.100", localIp = "";
    private volatile int port = 6500;
    private volatile boolean handshake = false;
    private volatile long lastRx;
    

    public Tc506Client(Listener listener) { this.listener = listener; }
    public void configure(String h, int p, String local) { host=h; port=p; localIp=local.trim(); }
    public void start() {
        if (!running.compareAndSet(false,true)) return;
        io.execute(this::loop);
    }
    public void stop() {
        running.set(false); close(); listener.state("Desconectado", false);
    }
    public void dispose() { stop(); io.shutdownNow(); actions.shutdownNow(); }
    public void query(String barcode) {
        if (barcode == null || !barcode.matches("[0-9A-Za-z]{4,40}")) { listener.log("Código inválido"); return; }
        // All socket writes run on the same background executor, serializing with session operations.
        actions.execute(() -> {
            if (!handshake || socket == null || socket.isClosed()) { listener.state("Sem comunicação: conecte ao servidor",false); return; }
            try {
                pendingCode=barcode;
                send("#"+barcode);
                listener.log("Consulta enviada: " + barcode);
            } catch(Exception e) { listener.log("Falha ao enviar: "+e.getMessage()); close(); }
        });
    }
    public void test(String h, int p, String ip) {
        actions.execute(() -> {
            try(Socket test=new Socket()) {
                if (!ip.isEmpty()) test.bind(new InetSocketAddress(ip,0));
                test.connect(new InetSocketAddress(h,p),3500);
                listener.log("TCP acessível em " + h + ":" + p + ". IP local: " + test.getLocalAddress().getHostAddress());
                listener.state("Porta acessível (protocolo ainda não validado)",false);
            } catch(Exception e) { listener.state("Falha no TCP: " + e.getMessage(),false); }
        });
    }
    private void loop() {
        while(running.get()) {
            try {
                listener.state("Conectando a " + host + ":" + port, false);
                Socket s = new Socket();
                if (!localIp.isEmpty()) s.bind(new InetSocketAddress(localIp,0));
                s.connect(new InetSocketAddress(host,port),4000);
                s.setKeepAlive(true); s.setTcpNoDelay(true); s.setSoTimeout(650);
                socket=s; handshake=false; pendingCode=null;
                lastRx=System.currentTimeMillis();
                listener.state("TCP conectado. Aguardando #ok do servidor...",false);
                InputStream in=s.getInputStream();
                byte[] buf=new byte[4096];
                ByteArrayOutputStream frame = new ByteArrayOutputStream();
                long lastByte=0;
                while (running.get() && !s.isClosed()) {
                    try {
                        int n=in.read(buf);
                        if(n<0) throw new java.io.EOFException("Servidor encerrou a conexão");
                        for(int i=0;i<n;i++) {
                            int b=buf[i]&255;
                            if(b==10 || b==13 || b==0) {
                                if(frame.size()>0) { process(new String(frame.toByteArray(),WIRE)); frame.reset(); }
                            } else if(frame.size()<8192) frame.write(b);
                        }
                        lastByte=System.currentTimeMillis(); lastRx=lastByte;
                        // Mensagens Gertec frequentemente não têm CR/LF; processar em silêncio de linha.
                        if(frame.size()>0 && in.available()==0) { Thread.sleep(70); if(in.available()==0) { process(new String(frame.toByteArray(),WIRE)); frame.reset(); } }
                    } catch(java.net.SocketTimeoutException e) {
                        if(frame.size()>0 && System.currentTimeMillis()-lastByte>120) { process(new String(frame.toByteArray(),WIRE)); frame.reset(); }
                        if(System.currentTimeMillis()-lastRx>180000) throw new java.io.IOException("Tempo de inatividade da conexão excedido");
                    }
                }
            } catch(Exception e) { if(running.get()) listener.log("Conexão: " + e.getMessage()); }
            finally { handshake=false; close(); if(running.get()) listener.state("Servidor indisponível. Reconectando...",false); }
            if(running.get()) try { Thread.sleep(3000); } catch(InterruptedException ignored) {Thread.currentThread().interrupt(); break;}
        }
    }
    private void process(String msg) throws Exception {
        msg=msg.trim(); if(msg.isEmpty()) return;
        listener.log("Recebido: " + (msg.length()>140 ? msg.substring(0,140)+"..." : msg));
        String low=msg.toLowerCase(java.util.Locale.ROOT);
        if(low.equals("#ok")) {
            // Identificação de terminal TC506 S, ajustável conforme versão/modelo de servidor.
            send("#tc506s|3.3.1 S");
            handshake=true; listener.state("Servidor conectado • TC506 S",true); return;
        }
        if(low.startsWith("#live?")) { send("#live"); return; }
        if(low.startsWith("#alwayslive")) { send("#alwayslive_ok"); return; }
        if(low.startsWith("#checklive")) { send("#checklive_ok"); return; }
        if(low.equals("#nfound") || low.startsWith("#nfound")) {
            listener.product(pendingCode == null? "":pendingCode, "PRODUTO NÃO ENCONTRADO", ""); pendingCode=null; return;
        }
        if(msg.startsWith("#") && msg.contains("|")) {
            String[] a=msg.substring(1).split("\\|",2);
            if(a[0].toLowerCase(java.util.Locale.ROOT).startsWith("tc") || a[0].toLowerCase(java.util.Locale.ROOT).startsWith("bp")) return;
            listener.product(pendingCode==null? "":pendingCode, a[0].trim(), a[1].trim()); pendingCode=null;
        }
    }
    private synchronized void send(String msg) throws Exception {
        Socket s=socket;
        if(s==null||s.isClosed()) throw new java.io.IOException("Sem socket");
        OutputStream out=s.getOutputStream(); out.write(msg.getBytes(WIRE)); out.flush();
        listener.log("Enviado: " + msg);
    }
    private void close() { try { Socket s=socket; socket=null; if(s!=null)s.close(); } catch(Exception ignored) {} }
}
