import { eachDate, getDay, type DayBrief } from "./engine";
import { FESTIVALS } from "./festivals";

export type MuhuratId = "marriage" | "griha" | "vehicle" | "property" | "beginnings";

export type MuhuratGrade = "Excellent" | "Good" | "Classic";

export type MuhuratHit = {
  iso: string;
  grade: MuhuratGrade;
  reason: string;
};

const MARRIAGE_NAK = new Set([3, 4, 9, 11, 12, 14, 16, 18, 20, 25, 26]);
const MARRIAGE_GOOD_NAK = new Set([7, 13, 21, 22]);
const GRIHA_NAK = new Set([3, 4, 11, 12, 13, 14, 16, 20, 25, 26]);
const VEHICLE_NAK = new Set([3, 7, 11, 12, 16, 20, 21, 26]);
const PROPERTY_NAK = new Set([3, 11, 20, 25]);
const BEGIN_NAK = new Set([3, 7, 11, 12, 20, 21, 25, 26]);
const SOFT_TITHI = new Set([2, 3, 5, 7, 10, 11, 13]);
const CORE_MONTHS = new Set([10, 11, 1, 2, 8]);
const BEST_DAYS = new Set([1, 3, 4, 5]);
const SUNDAY = 0;

let devuthani: string | null = null;

function devuthaniDate(cityId: string): string {
  if (devuthani) return devuthani;
  for (const iso of eachDate("2027-11-01", "2027-11-20")) {
    const day = getDay(iso, cityId);
    if (day.paksha === "Shukla" && day.tithiNumber === 11 && day.purnimantaIndex === 7) {
      devuthani = iso;
      return iso;
    }
  }
  devuthani = "2027-11-10";
  return devuthani;
}

function inChaturmas(iso: string, cityId: string): boolean {
  return iso >= "2027-07-14" && iso < devuthaniDate(cityId);
}

function eclipse(iso: string): boolean {
  return FESTIVALS.some((festival) => festival.date === iso && festival.kind === "eclipse");
}

function baseOk(day: DayBrief): boolean {
  return !eclipse(day.iso);
}

export function fitsOn(iso: string, cityId: string): Array<{ id: MuhuratId; hit: MuhuratHit }> {
  if (!iso.startsWith("2027")) return [];
  const day = getDay(iso, cityId);
  const kinds: MuhuratId[] = ["marriage", "griha", "vehicle", "property", "beginnings"];
  const hits = kinds.flatMap((id) => {
    const hit = score(id, day, cityId);
    return hit ? [{ id, hit }] : [];
  });
  const classics: Record<string, string> = {
    "2027-05-09": "Akshaya Tritiya, a classic day for a purchase.",
    "2027-10-09": "Vijayadashami, traditionally used for a new vehicle.",
    "2027-10-27": "Dhanteras, the customary day to bring metal home.",
  };
  const classic = classics[iso];
  if (classic) {
    const vehicle = hits.find((item) => item.id === "vehicle");
    const hit = { iso, grade: "Classic" as const, reason: classic };
    if (vehicle) vehicle.hit = hit;
    else hits.push({ id: "vehicle", hit });
  }
  return hits;
}

export function muhuratFor(kind: MuhuratId, cityId: string): MuhuratHit[] {
  const hits: MuhuratHit[] = [];
  for (const iso of eachDate("2027-01-01", "2027-12-31")) {
    const day = getDay(iso, cityId);
    const hit = score(kind, day, cityId);
    if (hit) hits.push(hit);
  }
  if (kind === "vehicle") {
    for (const classic of [
      ["2027-05-09", "Akshaya Tritiya, a classic day for a purchase."],
      ["2027-10-09", "Vijayadashami, traditionally used for a new vehicle."],
      ["2027-10-27", "Dhanteras, the customary day to bring metal home."],
    ] as const) {
      if (!hits.some((hit) => hit.iso === classic[0])) {
        hits.push({ iso: classic[0], grade: "Classic", reason: classic[1] });
      } else {
        const found = hits.find((hit) => hit.iso === classic[0]);
        if (found) {
          found.grade = "Classic";
          found.reason = classic[1];
        }
      }
    }
    hits.sort((a, b) => a.iso.localeCompare(b.iso));
  }
  return hits;
}

function score(kind: MuhuratId, day: DayBrief, cityId: string): MuhuratHit | null {
  if (!baseOk(day)) return null;
  if (kind === "marriage") return scoreMarriage(day, cityId);
  if (kind === "griha") return scoreHouse(day, cityId, GRIHA_NAK, "A steady nakshatra for entering a home.");
  if (kind === "property") return scoreHouse(day, cityId, GRIHA_NAK, "Steady nakshatra for agreeing a home or a plot.");
  if (kind === "vehicle") return scoreVehicle(day);
  return scoreBeginnings(day, cityId);
}

function scoreMarriage(day: DayBrief, cityId: string): MuhuratHit | null {
  if (inChaturmas(day.iso, cityId)) return null;
  if (day.paksha !== "Shukla") return null;
  const monthOk = CORE_MONTHS.has(day.amantaIndex) || day.amantaIndex === 0 || day.amantaIndex === 7;
  if (!monthOk) return null;
  const strictNak = MARRIAGE_NAK.has(day.nakshatraIndex);
  const softNak = MARRIAGE_GOOD_NAK.has(day.nakshatraIndex);
  if (!strictNak && !softNak) return null;
  const strictTithi = SOFT_TITHI.has(day.tithiNumber);
  if (!strictTithi && day.tithiNumber !== 12) return null;
  const weekdayOk = BEST_DAYS.has(day.weekday) || day.weekday === SUNDAY;
  if (!weekdayOk) return null;
  const excellent = strictNak && strictTithi && BEST_DAYS.has(day.weekday) && CORE_MONTHS.has(day.amantaIndex);
  return {
    iso: day.iso,
    grade: excellent ? "Excellent" : "Good",
    reason: excellent
      ? "Shukla paksha, supportive nakshatra, outside Chaturmas."
      : "Acceptable tithi and nakshatra. A priest may still prefer a stronger combination.",
  };
}

function scoreHouse(day: DayBrief, cityId: string, nakshatras: Set<number>, reason: string): MuhuratHit | null {
  if (inChaturmas(day.iso, cityId)) return null;
  if (day.paksha !== "Shukla") return null;
  if (!SOFT_TITHI.has(day.tithiNumber) && day.tithiNumber !== 12) return null;
  if (!nakshatras.has(day.nakshatraIndex)) return null;
  if (!CORE_MONTHS.has(day.amantaIndex)) return null;
  if (BEST_DAYS.has(day.weekday)) return { iso: day.iso, grade: "Excellent", reason };
  if (day.weekday === SUNDAY) return { iso: day.iso, grade: "Good", reason };
  return null;
}

function scoreVehicle(day: DayBrief): MuhuratHit | null {
  if (day.tithiNumber === 4 || day.tithiNumber === 8 || day.tithiNumber === 9 || day.tithiNumber === 14) return null;
  if (day.paksha === "Krishna" && day.tithiNumber === 15) return null;
  if (!VEHICLE_NAK.has(day.nakshatraIndex)) return null;
  if (!BEST_DAYS.has(day.weekday)) return null;
  return {
    iso: day.iso,
    grade: "Excellent",
    reason: `${day.nakshatraName} with a favourable weekday. Avoid the Rahu Kalam window.`,
  };
}

function scoreBeginnings(day: DayBrief, cityId: string): MuhuratHit | null {
  if (inChaturmas(day.iso, cityId)) return null;
  if (day.paksha === "Krishna" && day.tithiNumber === 15) return null;
  if (!SOFT_TITHI.has(day.tithiNumber)) return null;
  if (!BEGIN_NAK.has(day.nakshatraIndex)) return null;
  if (day.weekday === 2 || day.weekday === 6) return null;
  const grade = day.paksha === "Shukla" && BEST_DAYS.has(day.weekday) ? "Excellent" : "Good";
  return { iso: day.iso, grade, reason: "Supportive for study, business or a first step." };
}

export const MUHURAT_COPY: Record<MuhuratId, { title: string; summary: string }> = {
  marriage: {
    title: "Marriage",
    summary: "Shukla paksha in Magha, Phalguna, Vaishakha, Jyeshtha and Margashirsha, outside Chaturmas.",
  },
  griha: {
    title: "Griha Pravesh",
    summary: "Housewarming dates with a steady nakshatra. Chaturmas is left out.",
  },
  vehicle: {
    title: "Vehicle",
    summary: "Weekdays and nakshatras used for a purchase, plus Dhanteras, Dussehra and Akshaya Tritiya.",
  },
  property: {
    title: "Property",
    summary: "Steady nakshatras for agreeing a home or a plot. Confirm the final hour locally.",
  },
  beginnings: {
    title: "New beginnings",
    summary: "Study, a shop, a name, a journey. Tuesday and Saturday are set aside.",
  },
};
