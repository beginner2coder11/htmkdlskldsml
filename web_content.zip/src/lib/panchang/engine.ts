import {
  Body,
  EclipticGeoMoon,
  MakeTime,
  Observer,
  SearchMoonPhase,
  SearchRiseSet,
  SunPosition,
} from "astronomy-engine";
import type { City } from "@/lib/cities";
import { getCity } from "@/lib/cities";
import { addDays, VARA, WEEKDAYS, weekdayIndex } from "@/lib/time";
import { karanaName, LUNAR_MONTHS, NAKSHATRAS, RASHIS, TITHI, YOGAS } from "./constants";

const RISE = 1;
const SET = -1;
const SPAN = 360 / 27;

export type Paksha = "Shukla" | "Krishna";

export type Window = { start: Date; end: Date };

export type DayBrief = {
  iso: string;
  weekday: number;
  weekdayName: string;
  vara: string;
  sunrise: Date;
  sunset: Date;
  timings: {
    rahu: Window;
    yamaganda: Window;
    gulika: Window;
    abhijit: Window;
    brahma: Window;
  };
  tithiIndex: number;
  tithiName: string;
  paksha: Paksha;
  tithiNumber: number;
  tithiEnd: Date;
  nextTithi: string;
  nakshatraIndex: number;
  nakshatraName: string;
  pada: number;
  nakshatraEnd: Date;
  yogaIndex: number;
  yogaName: string;
  yogaEnd: Date;
  karanaName: string;
  karanaEnd: Date;
  sunRashi: string;
  sunRashiEn: string;
  moonRashi: string;
  moonRashiEn: string;
  amantaIndex: number;
  amantaName: string;
  purnimantaIndex: number;
  purnimantaName: string;
  adhik: boolean;
  sankranti: { name: string; at: Date } | null;
  moonrise: Date | null;
  moonset: Date | null;
};

const cache = new Map<string, DayBrief>();

function norm(deg: number): number {
  return ((deg % 360) + 360) % 360;
}

function lahiri(date: Date): number {
  return 23.852778 + (MakeTime(date).ut / 365.2425) * (50.29 / 3600);
}

function sunTropical(date: Date): number {
  return SunPosition(date).elon;
}

function moonTropical(date: Date): number {
  return EclipticGeoMoon(date).lon;
}

function elongation(date: Date): number {
  return norm(moonTropical(date) - sunTropical(date));
}

function sunSidereal(date: Date): number {
  return norm(sunTropical(date) - lahiri(date));
}

function moonSidereal(date: Date): number {
  return norm(moonTropical(date) - lahiri(date));
}

function advanceTo(start: Date, read: (date: Date) => number, boundary: number): Date {
  const startVal = read(start);
  const need = norm(boundary - startVal);
  if (need < 0.02) return new Date(start.getTime() + 60_000);
  let lo = start.getTime();
  let hi = lo + 40 * 3_600_000;
  for (let i = 0; i < 22; i += 1) {
    const mid = (lo + hi) / 2;
    const progressed = norm(read(new Date(mid)) - startVal);
    if (progressed >= need && progressed < 300) hi = mid;
    else lo = mid;
  }
  return new Date(hi);
}

function nextTithiLabel(index: number): string {
  const next = (index + 1) % 30;
  const paksha: Paksha = next < 15 ? "Shukla" : "Krishna";
  const number = (next % 15) + 1;
  const name = number === 15 ? (paksha === "Shukla" ? "Purnima" : "Amavasya") : TITHI[number - 1];
  return `${paksha} ${name}`;
}

function tithiAt(date: Date) {
  const elong = elongation(date);
  const index = Math.min(29, Math.floor(elong / 12));
  const paksha: Paksha = index < 15 ? "Shukla" : "Krishna";
  const number = (index % 15) + 1;
  const name = number === 15 ? (paksha === "Shukla" ? "Purnima" : "Amavasya") : TITHI[number - 1];
  return { index, paksha, number, name, end: advanceTo(date, elongation, (index + 1) * 12) };
}

function nakshatraAt(date: Date) {
  const lon = moonSidereal(date);
  const index = Math.min(26, Math.floor(lon / SPAN));
  const within = lon - index * SPAN;
  const pada = Math.min(4, Math.floor(within / (SPAN / 4)) + 1);
  return {
    index,
    name: NAKSHATRAS[index],
    pada,
    end: advanceTo(date, moonSidereal, (index + 1) * SPAN),
  };
}

function yogaAt(date: Date) {
  const read = (value: Date) => norm(sunSidereal(value) + moonSidereal(value));
  const sum = read(date);
  const index = Math.min(26, Math.floor(sum / SPAN));
  return { index, name: YOGAS[index], end: advanceTo(date, read, (index + 1) * SPAN) };
}

function karanaAt(date: Date) {
  const elong = elongation(date);
  const index = Math.min(59, Math.floor(elong / 6));
  return { name: karanaName(index), end: advanceTo(date, elongation, (index + 1) * 6) };
}

function rashiAt(lon: number) {
  const index = Math.min(11, Math.floor(norm(lon) / 30));
  return { index, name: RASHIS[index][0], en: RASHIS[index][1] };
}

const monthByNewMoon = new Map<number, { index: number; adhik: boolean }>();

function lunarMonth(sunrise: Date) {
  const current = SearchMoonPhase(0, sunrise, -40);
  if (!current) {
    return { index: 0, adhik: false };
  }
  const key = Math.round(current.date.getTime() / 60_000);
  const cached = monthByNewMoon.get(key);
  if (cached) return cached;
  const rashi = Math.floor(sunSidereal(current.date) / 30) % 12;
  const index = (rashi + 1) % 12;
  const previous = SearchMoonPhase(0, new Date(current.date.getTime() - 86_400_000), -40);
  const prevRashi = previous ? Math.floor(sunSidereal(previous.date) / 30) % 12 : -1;
  const value = { index, adhik: prevRashi === rashi };
  monthByNewMoon.set(key, value);
  return value;
}

function segment(sunrise: Date, sunset: Date, part: number): Window {
  const span = sunset.getTime() - sunrise.getTime();
  return {
    start: new Date(sunrise.getTime() + ((part - 1) / 8) * span),
    end: new Date(sunrise.getTime() + (part / 8) * span),
  };
}

const RAHU = [8, 2, 7, 5, 6, 4, 3];
const YAMA = [5, 4, 3, 2, 1, 7, 6];
const GULIKA = [7, 6, 5, 4, 3, 2, 1];

function timingsFor(sunrise: Date, sunset: Date, weekday: number) {
  const span = sunset.getTime() - sunrise.getTime();
  const muhurta = span / 15;
  return {
    rahu: segment(sunrise, sunset, RAHU[weekday] ?? 8),
    yamaganda: segment(sunrise, sunset, YAMA[weekday] ?? 5),
    gulika: segment(sunrise, sunset, GULIKA[weekday] ?? 7),
    abhijit: {
      start: new Date(sunrise.getTime() + 7 * muhurta),
      end: new Date(sunrise.getTime() + 8 * muhurta),
    },
    brahma: {
      start: new Date(sunrise.getTime() - 96 * 60_000),
      end: new Date(sunrise.getTime() - 48 * 60_000),
    },
  };
}

function sankrantiBetween(sunrise: Date, next: Date): { name: string; at: Date } | null {
  const before = Math.floor(sunSidereal(sunrise) / 30) % 12;
  const after = Math.floor(sunSidereal(new Date(next.getTime() - 60_000)) / 30) % 12;
  if (before === after) return null;
  let lo = sunrise.getTime();
  let hi = next.getTime();
  for (let i = 0; i < 24; i += 1) {
    const mid = (lo + hi) / 2;
    const rashi = Math.floor(sunSidereal(new Date(mid)) / 30) % 12;
    if (rashi === before) lo = mid;
    else hi = mid;
  }
  const entered = Math.floor(sunSidereal(new Date(hi)) / 30) % 12;
  return { name: `${RASHIS[entered][0]} Sankranti`, at: new Date(hi) };
}

function riseSet(body: Body, observer: Observer, direction: number, start: Date): Date | null {
  return SearchRiseSet(body, observer, direction, start, 1)?.date ?? null;
}

export function getDay(iso: string, cityId: string): DayBrief {
  const key = `${cityId}:${iso}`;
  const cached = cache.get(key);
  if (cached) return cached;
  const city = getCity(cityId);
  const observer = new Observer(city.lat, city.lon, 0);
  const midnight = new Date(`${iso}T00:00:00+05:30`);
  const sunrise = riseSet(Body.Sun, observer, RISE, midnight);
  const sunset = sunrise ? riseSet(Body.Sun, observer, SET, new Date(sunrise.getTime() + 60_000)) : null;
  if (!sunrise || !sunset) {
    throw new Error(`Could not find sunrise for ${city.name} on ${iso}.`);
  }
  const next = riseSet(Body.Sun, observer, RISE, new Date(sunrise.getTime() + 3_600_000)) ?? new Date(sunrise.getTime() + 86_400_000);
  const weekday = weekdayIndex(iso);
  const tithi = tithiAt(sunrise);
  const nakshatra = nakshatraAt(sunrise);
  const yoga = yogaAt(sunrise);
  const karana = karanaAt(sunrise);
  const sun = rashiAt(sunSidereal(sunrise));
  const moon = rashiAt(moonSidereal(sunrise));
  const month = lunarMonth(sunrise);
  const purnimantaIndex = tithi.paksha === "Shukla" ? month.index : (month.index + 1) % 12;
  const day: DayBrief = {
    iso,
    weekday,
    weekdayName: WEEKDAYS[weekday] ?? "Sunday",
    vara: VARA[weekday] ?? "Ravivara",
    sunrise,
    sunset,
    timings: timingsFor(sunrise, sunset, weekday),
    tithiIndex: tithi.index,
    tithiName: tithi.name,
    paksha: tithi.paksha,
    tithiNumber: tithi.number,
    tithiEnd: tithi.end,
    nextTithi: nextTithiLabel(tithi.index),
    nakshatraIndex: nakshatra.index,
    nakshatraName: nakshatra.name,
    pada: nakshatra.pada,
    nakshatraEnd: nakshatra.end,
    yogaIndex: yoga.index,
    yogaName: yoga.name,
    yogaEnd: yoga.end,
    karanaName: karana.name,
    karanaEnd: karana.end,
    sunRashi: sun.name,
    sunRashiEn: sun.en,
    moonRashi: moon.name,
    moonRashiEn: moon.en,
    amantaIndex: month.index,
    amantaName: month.adhik ? `Adhik ${LUNAR_MONTHS[month.index]}` : LUNAR_MONTHS[month.index],
    purnimantaIndex,
    purnimantaName: LUNAR_MONTHS[purnimantaIndex],
    adhik: month.adhik,
    sankranti: sankrantiBetween(sunrise, next),
    moonrise: riseSet(Body.Moon, observer, RISE, midnight),
    moonset: riseSet(Body.Moon, observer, SET, midnight),
  };
  cache.set(key, day);
  return day;
}

export type LiveReading = {
  tithiName: string;
  paksha: Paksha;
  tithiNumber: number;
  tithiEnd: Date;
  nakshatraName: string;
  pada: number;
  nakshatraEnd: Date;
  yogaName: string;
  yogaEnd: Date;
  karanaName: string;
  karanaEnd: Date;
};

export function getLive(date = new Date()): LiveReading {
  const tithi = tithiAt(date);
  const nakshatra = nakshatraAt(date);
  const yoga = yogaAt(date);
  const karana = karanaAt(date);
  return {
    tithiName: tithi.name,
    paksha: tithi.paksha,
    tithiNumber: tithi.number,
    tithiEnd: tithi.end,
    nakshatraName: nakshatra.name,
    pada: nakshatra.pada,
    nakshatraEnd: nakshatra.end,
    yogaName: yoga.name,
    yogaEnd: yoga.end,
    karanaName: karana.name,
    karanaEnd: karana.end,
  };
}

export function eachDate(from: string, to: string): string[] {
  const dates: string[] = [];
  let cursor = from;
  while (cursor <= to) {
    dates.push(cursor);
    cursor = addDays(cursor, 1);
  }
  return dates;
}

export function monthLabel(day: DayBrief, system: "amanta" | "purnimanta"): string {
  return system === "amanta" ? day.amantaName : day.purnimantaName;
}
