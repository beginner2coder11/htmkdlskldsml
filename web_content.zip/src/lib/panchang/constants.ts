export const TITHI = [
  "Pratipada",
  "Dwitiya",
  "Tritiya",
  "Chaturthi",
  "Panchami",
  "Shashthi",
  "Saptami",
  "Ashtami",
  "Navami",
  "Dashami",
  "Ekadashi",
  "Dwadashi",
  "Trayodashi",
  "Chaturdashi",
  "Purnima",
] as const;

export const NAKSHATRAS = [
  "Ashwini",
  "Bharani",
  "Krittika",
  "Rohini",
  "Mrigashira",
  "Ardra",
  "Punarvasu",
  "Pushya",
  "Ashlesha",
  "Magha",
  "Purva Phalguni",
  "Uttara Phalguni",
  "Hasta",
  "Chitra",
  "Swati",
  "Vishakha",
  "Anuradha",
  "Jyeshtha",
  "Mula",
  "Purva Ashadha",
  "Uttara Ashadha",
  "Shravana",
  "Dhanishta",
  "Shatabhisha",
  "Purva Bhadrapada",
  "Uttara Bhadrapada",
  "Revati",
] as const;

export const YOGAS = [
  "Vishkambha",
  "Priti",
  "Ayushman",
  "Saubhagya",
  "Shobhana",
  "Atiganda",
  "Sukarma",
  "Dhriti",
  "Shula",
  "Ganda",
  "Vriddhi",
  "Dhruva",
  "Vyaghata",
  "Harshana",
  "Vajra",
  "Siddhi",
  "Vyatipata",
  "Variyan",
  "Parigha",
  "Shiva",
  "Siddha",
  "Sadhya",
  "Shubha",
  "Shukla",
  "Brahma",
  "Indra",
  "Vaidhriti",
] as const;

export const KARANA_REPEAT = ["Bava", "Balava", "Kaulava", "Taitila", "Gara", "Vanija", "Vishti"] as const;

export const RASHIS: ReadonlyArray<readonly [string, string]> = [
  ["Mesha", "Aries"],
  ["Vrishabha", "Taurus"],
  ["Mithuna", "Gemini"],
  ["Karka", "Cancer"],
  ["Simha", "Leo"],
  ["Kanya", "Virgo"],
  ["Tula", "Libra"],
  ["Vrishchika", "Scorpio"],
  ["Dhanu", "Sagittarius"],
  ["Makara", "Capricorn"],
  ["Kumbha", "Aquarius"],
  ["Meena", "Pisces"],
];

export const LUNAR_MONTHS = [
  "Chaitra",
  "Vaishakha",
  "Jyeshtha",
  "Ashadha",
  "Shravana",
  "Bhadrapada",
  "Ashwin",
  "Kartika",
  "Margashirsha",
  "Pausha",
  "Magha",
  "Phalguna",
] as const;

const EKADASHI: Record<"Krishna" | "Shukla", string[]> = {
  Krishna: [
    "Papamochani Ekadashi",
    "Varuthini Ekadashi",
    "Apara Ekadashi",
    "Yogini Ekadashi",
    "Kamika Ekadashi",
    "Aja Ekadashi",
    "Indira Ekadashi",
    "Rama Ekadashi",
    "Utpanna Ekadashi",
    "Saphala Ekadashi",
    "Shattila Ekadashi",
    "Vijaya Ekadashi",
  ],
  Shukla: [
    "Kamada Ekadashi",
    "Mohini Ekadashi",
    "Nirjala Ekadashi",
    "Devshayani Ekadashi",
    "Putrada Ekadashi",
    "Parsva Ekadashi",
    "Papankusha Ekadashi",
    "Devuthani Ekadashi",
    "Mokshada Ekadashi",
    "Pausha Putrada Ekadashi",
    "Jaya Ekadashi",
    "Amalaki Ekadashi",
  ],
};

export function ekadashiName(purnimantaIndex: number, paksha: "Shukla" | "Krishna"): string {
  return EKADASHI[paksha][purnimantaIndex] ?? "Ekadashi";
}

export function karanaName(index: number): string {
  if (index <= 0) return "Kimstughna";
  if (index >= 57) return ["Shakuni", "Chatushpada", "Naga"][Math.min(2, index - 57)] ?? "Naga";
  return KARANA_REPEAT[(index - 1) % 7];
}
