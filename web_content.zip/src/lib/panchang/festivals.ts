export type FestivalKind = "major" | "vrat" | "sankranti" | "eclipse" | "observance";

export type Festival = {
  date: string;
  name: string;
  kind: FestivalKind;
  note: string;
};

function entry(date: string, name: string, kind: FestivalKind, note: string): Festival {
  return { date, name, kind, note };
}

export const FESTIVALS: Festival[] = [
  entry("2027-01-03", "Saphala Ekadashi", "vrat", "Pausha Krishna Ekadashi. A fast kept for Vishnu."),
  entry("2027-01-13", "Lohri", "observance", "Bonfire eve observed in Punjab, the day before Bhogi."),
  entry("2027-01-14", "Bhogi", "observance", "First day of the Pongal cluster. The old is set aside."),
  entry("2027-01-15", "Makara Sankranti", "major", "Uttarayana. Sun’s entry into Makara is observed today across India, with Thai Pongal."),
  entry("2027-01-16", "Mattu Pongal", "observance", "Cattle are honoured on the third Pongal day."),
  entry("2027-01-17", "Kanum Pongal", "observance", "Closing day of Pongal, kept for outings and family."),
  entry("2027-01-18", "Pausha Putrada Ekadashi", "vrat", "Shukla Ekadashi of Pausha."),
  entry("2027-01-22", "Pausha Purnima", "vrat", "Full moon of Pausha."),
  entry("2027-01-25", "Sakat Chauth", "vrat", "Sankashti Chaturthi. Chandra darshan after moonrise ends the fast."),
  entry("2027-02-02", "Shattila Ekadashi", "vrat", "Magha Krishna Ekadashi. Til is offered."),
  entry("2027-02-06", "Mauni Amavasya", "major", "Magha Amavasya. Silence, a holy dip, and charity are traditional."),
  entry("2027-02-06", "Surya Grahan", "eclipse", "A solar eclipse falls on this Amavasya. Sutak and local visibility differ by city."),
  entry("2027-02-11", "Vasant Panchami", "major", "Magha Shukla Panchami. Saraswati is worshipped; spring is welcomed."),
  entry("2027-02-13", "Ratha Saptami", "vrat", "Surya’s ratha. A sunrise bath is traditional."),
  entry("2027-02-13", "Kumbha Sankranti", "sankranti", "Sun enters Kumbha."),
  entry("2027-02-14", "Bhishma Ashtami", "observance", "Magha Shukla Ashtami, in memory of Bhishma."),
  entry("2027-02-17", "Jaya Ekadashi", "vrat", "Magha Shukla Ekadashi."),
  entry("2027-02-20", "Magha Purnima", "vrat", "Full moon of Magha. Bathing at a sacred river is traditional."),
  entry("2027-02-21", "Chandra Grahan", "eclipse", "A lunar eclipse follows Magha Purnima. Follow your local panchang for sutak."),
  entry("2027-03-04", "Vijaya Ekadashi", "vrat", "Phalguna Krishna Ekadashi."),
  entry("2027-03-06", "Maha Shivaratri", "major", "Phalguna Krishna Chaturdashi. The night vigil is for Shiva."),
  entry("2027-03-08", "Somvati Amavasya", "vrat", "Amavasya on a Monday. Pitru tarpana is traditional."),
  entry("2027-03-15", "Meena Sankranti", "sankranti", "Sun enters Meena."),
  entry("2027-03-18", "Amalaki Ekadashi", "vrat", "Phalguna Shukla Ekadashi. The amla tree is honoured."),
  entry("2027-03-21", "Holika Dahan", "major", "Phalguna Purnima evening. The bonfire is lit at the proper prahda muhurat."),
  entry("2027-03-22", "Holi", "major", "Rangwali Holi, the day after Holika Dahan."),
  entry("2027-03-30", "Sheetala Ashtami", "observance", "Basoda. Stale food is offered and the hearth is left to rest."),
  entry("2027-04-02", "Papamochani Ekadashi", "vrat", "Chaitra Krishna Ekadashi."),
  entry("2027-04-07", "Ugadi", "major", "Chaitra Shukla Pratipada. New year in Karnataka, Andhra, Telangana and Maharashtra (Gudi Padwa)."),
  entry("2027-04-07", "Chaitra Navratri", "major", "Nine nights begin. Day 1 is dedicated to Shailputri."),
  entry("2027-04-08", "Navratri · Brahmacharini", "observance", "Chaitra Navratri, day 2."),
  entry("2027-04-09", "Gangaur", "observance", "Gauri puja, widely kept in Rajasthan. Chaitra Navratri, day 3."),
  entry("2027-04-12", "Yamuna Chhath", "observance", "Chaitra Shukla Shashthi."),
  entry("2027-04-14", "Mesha Sankranti", "sankranti", "Solar new year: Puthandu, Vishu and Vaisakhi are observed with this transit."),
  entry("2027-04-15", "Rama Navami", "major", "Chaitra Shukla Navami. Also Bohag Bihu and Pohela Boishakh in the east."),
  entry("2027-04-17", "Kamada Ekadashi", "vrat", "Chaitra Shukla Ekadashi."),
  entry("2027-04-20", "Hanuman Jayanti", "major", "Observed on Chaitra Purnima."),
  entry("2027-05-02", "Varuthini Ekadashi", "vrat", "Vaishakha Krishna Ekadashi."),
  entry("2027-05-08", "Parashurama Jayanti", "observance", "Akshaya Tritiya is observed the following day in 2027."),
  entry("2027-05-09", "Akshaya Tritiya", "major", "Vaishakha Shukla Tritiya. A classic day for beginnings, gold and purchases."),
  entry("2027-05-14", "Sita Navami", "observance", "Vaishakha Shukla Navami."),
  entry("2027-05-15", "Vrishabha Sankranti", "sankranti", "Sun enters Vrishabha."),
  entry("2027-05-16", "Mohini Ekadashi", "vrat", "Vaishakha Shukla Ekadashi."),
  entry("2027-05-18", "Narasimha Jayanti", "observance", "Vaishakha Shukla Chaturdashi."),
  entry("2027-05-20", "Buddha Purnima", "major", "Vaishakha Purnima."),
  entry("2027-06-01", "Apara Ekadashi", "vrat", "Jyeshtha Krishna Ekadashi."),
  entry("2027-06-04", "Vat Savitri", "vrat", "Observed on Jyeshtha Amavasya, with Shani Jayanti."),
  entry("2027-06-13", "Ganga Dussehra", "observance", "Jyeshtha Shukla Dashami."),
  entry("2027-06-14", "Nirjala Ekadashi", "major", "The waterless fast. It is said to stand for all ekadashis."),
  entry("2027-06-15", "Mithuna Sankranti", "sankranti", "Sun enters Mithuna."),
  entry("2027-06-18", "Vat Purnima", "vrat", "Jyeshtha Purnima. The banyan vrat is kept in Maharashtra."),
  entry("2027-06-30", "Yogini Ekadashi", "vrat", "Ashadha Krishna Ekadashi."),
  entry("2027-07-05", "Rath Yatra", "major", "Jagannath’s chariot festival at Puri, Ashadha Shukla Dwitiya."),
  entry("2027-07-14", "Devshayani Ekadashi", "major", "Ashadha Shukla Ekadashi. Chaturmas begins; Vishnu is said to rest."),
  entry("2027-07-17", "Karka Sankranti", "sankranti", "Dakshinayana. Sun enters Karka."),
  entry("2027-07-18", "Guru Purnima", "major", "Ashadha Purnima, kept for the guru."),
  entry("2027-08-06", "Nag Panchami", "observance", "Shravana Shukla Panchami."),
  entry("2027-08-13", "Varalakshmi Vrat", "vrat", "Friday vrat for Lakshmi, ahead of Shravana Purnima."),
  entry("2027-08-17", "Raksha Bandhan", "major", "Shravana Purnima. The thread is tied at the appointed muhurat."),
  entry("2027-08-25", "Krishna Janmashtami", "major", "Bhadrapada Krishna Ashtami in the Purnimanta reckoning. The midnight vigil is traditional."),
  entry("2027-09-03", "Hartalika Teej", "vrat", "Bhadrapada Shukla Tritiya, kept the day before Ganesh Chaturthi."),
  entry("2027-09-04", "Ganesh Chaturthi", "major", "Bhadrapada Shukla Chaturthi. Ganesha is welcomed home."),
  entry("2027-09-08", "Radha Ashtami", "observance", "Bhadrapada Shukla Ashtami."),
  entry("2027-09-11", "Parsva Ekadashi", "vrat", "Parivartini Ekadashi of Bhadrapada Shukla."),
  entry("2027-09-12", "Onam", "major", "Thiruvonam. Sun in Simha with Shravana nakshatra."),
  entry("2027-09-14", "Anant Chaturdashi", "major", "Ganesh visarjan and Anant vrat."),
  entry("2027-09-16", "Pitru Paksha begins", "observance", "The fortnight of shraddha opens after Bhadrapada Purnima."),
  entry("2027-09-26", "Indira Ekadashi", "vrat", "Krishna Ekadashi during Pitru Paksha."),
  entry("2027-09-29", "Mahalaya Amavasya", "major", "Sarva Pitru Amavasya. The last day of shraddha."),
  entry("2027-09-30", "Sharad Navratri", "major", "Ashwin Shukla Pratipada. Day 1, Shailputri. Nine nights begin."),
  entry("2027-10-01", "Navratri · Brahmacharini", "observance", "Sharad Navratri, day 2."),
  entry("2027-10-02", "Navratri · Chandraghanta", "observance", "Sharad Navratri, day 3."),
  entry("2027-10-03", "Navratri · Kushmanda", "observance", "Sharad Navratri, day 4."),
  entry("2027-10-04", "Navratri · Skandamata", "observance", "Sharad Navratri, day 5."),
  entry("2027-10-05", "Navratri · Katyayani", "observance", "Sharad Navratri, day 6."),
  entry("2027-10-06", "Navratri · Kalaratri", "observance", "Sharad Navratri, day 7."),
  entry("2027-10-07", "Durga Ashtami", "major", "Mahagauri. Sharad Navratri, day 8. Kanya puja is traditional."),
  entry("2027-10-08", "Maha Navami", "major", "Siddhidatri and Durga Puja. Sharad Navratri, day 9."),
  entry("2027-10-09", "Dussehra", "major", "Vijayadashami. Rama’s victory, and the close of Navratri."),
  entry("2027-10-14", "Sharad Purnima", "major", "Ashwin Purnima. Kojagari, when moonlight is offered to Lakshmi."),
  entry("2027-10-18", "Karwa Chauth", "major", "Kartika Krishna Chaturthi in the Purnimanta count. The fast breaks at moonrise."),
  entry("2027-10-27", "Dhanteras", "major", "Dhantrayodashi. A traditional day to buy metal, tools and vehicles."),
  entry("2027-10-28", "Naraka Chaturdashi", "major", "Chhoti Diwali. An early oil bath is traditional."),
  entry("2027-10-29", "Diwali", "major", "Lakshmi puja on Kartika Krishna Amavasya (Purnimanta). The new moon night."),
  entry("2027-10-30", "Govardhan Puja", "major", "Annakut, and Bestu Varas — the Gujarati new year."),
  entry("2027-10-31", "Bhai Dooj", "major", "Yama Dwitiya. Brothers are received at home."),
  entry("2027-11-04", "Chhath Puja", "major", "Surya Shashthi. The sandhya arghya is offered at dusk."),
  entry("2027-11-11", "Tulsi Vivah", "observance", "Kartika Shukla Dwadashi. The wedding of Tulsi and Shaligram."),
  entry("2027-11-14", "Kartika Purnima", "major", "Dev Diwali. Lamps are lit again, especially in Kashi."),
  entry("2027-12-09", "Gita Jayanti", "major", "Mokshada Ekadashi. The Bhagavad Gita’s day."),
  entry("2027-12-16", "Dhanu Sankranti", "sankranti", "Sun enters Dhanu."),
];

export function artFor(name: string): string {
  const text = name.toLowerCase();
  if (/diwali|dhanteras|navratri|durga|dussehra|lakshmi|karwa|chhath/.test(text)) return "/art/diyas.jpg";
  if (/vivah|wedding|griha|mandap|akshaya|hanuman|rama/.test(text)) return "/art/mandap.jpg";
  if (/ganesh|onam|pongal|sankranti|holi|janmashtami|shivaratri|ugadi|raksha/.test(text)) return "/art/lotus.jpg";
  return "/art/temple.jpg";
}

const KIND_RANK: Record<FestivalKind, number> = {
  major: 0,
  eclipse: 1,
  sankranti: 2,
  vrat: 3,
  observance: 4,
};

export function byImportance(events: Festival[]): Festival[] {
  return [...events].sort((a, b) => KIND_RANK[a.kind] - KIND_RANK[b.kind] || a.name.localeCompare(b.name));
}

export function upcomingMajors(fromIso: string, count: number): Festival[] {
  const seen = new Set<string>();
  const list: Festival[] = [];
  for (const festival of FESTIVALS) {
    if (festival.date < fromIso || festival.kind !== "major") continue;
    if (seen.has(festival.date + festival.name)) continue;
    seen.add(festival.date + festival.name);
    list.push(festival);
    if (list.length >= count) break;
  }
  return list;
}
