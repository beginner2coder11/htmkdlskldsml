const IST = "Asia/Kolkata";

export function istISO(date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: IST,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function istMidnight(iso: string): Date {
  return new Date(`${iso}T00:00:00+05:30`);
}

export function addDays(iso: string, days: number): string {
  return istISO(new Date(istMidnight(iso).getTime() + days * 86_400_000));
}

export function weekdayIndex(iso: string): number {
  return new Date(`${iso}T12:00:00+05:30`).getUTCDay();
}

export function istHour(date: Date): number {
  const hour = new Intl.DateTimeFormat("en-GB", {
    timeZone: IST,
    hour: "2-digit",
    hourCycle: "h23",
  }).format(date);
  return Number(hour);
}

export function formatTime(date: Date): string {
  const text = new Intl.DateTimeFormat("en-US", {
    timeZone: IST,
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(date);
  return text.replace("AM", "AM").replace("am", "AM").replace("pm", "PM");
}

export function formatRange(start: Date, end: Date): string {
  return `${formatTime(start)} – ${formatTime(end)}`;
}

export function formatUntil(end: Date, anchor: Date): string {
  const time = formatTime(end);
  if (istISO(end) === istISO(anchor)) return `until ${time}`;
  const weekday = new Intl.DateTimeFormat("en-IN", { timeZone: IST, weekday: "short" }).format(end);
  return `until ${weekday}, ${time}`;
}

export function formatLong(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: IST,
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(istMidnight(iso));
}

export function formatMonthYear(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: IST,
    month: "long",
    year: "numeric",
  })
    .format(istMidnight(iso))
    .toUpperCase();
}

export function formatShort(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: IST,
    day: "numeric",
    month: "short",
  }).format(istMidnight(iso));
}

export function daysBetween(fromIso: string, toIso: string): number {
  return Math.round((istMidnight(toIso).getTime() - istMidnight(fromIso).getTime()) / 86_400_000);
}

export function monthLength(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

export function pad2(value: number): string {
  return String(value).padStart(2, "0");
}

export const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
export const WEEK_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export const VARA = ["Ravivara", "Somavara", "Mangalavara", "Budhavara", "Guruvara", "Shukravara", "Shanivara"];

export function greeting(date: Date): string {
  const hour = istHour(date);
  if (hour < 4) return "Good night";
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  if (hour < 21) return "Good evening";
  return "Good night";
}

export function samvatFor(iso: string): { vikram: number; shaka: number } {
  const afterNewYear = iso >= "2027-04-07";
  return {
    vikram: afterNewYear ? 2084 : 2083,
    shaka: afterNewYear ? 1949 : 1948,
  };
}
