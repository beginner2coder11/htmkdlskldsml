export type City = {
  id: string;
  name: string;
  region: string;
  lat: number;
  lon: number;
};

export const CITIES: City[] = [
  { id: "bengaluru", name: "Bengaluru", region: "Karnataka", lat: 12.9716, lon: 77.5946 },
  { id: "mysuru", name: "Mysuru", region: "Karnataka", lat: 12.2958, lon: 76.6394 },
  { id: "mumbai", name: "Mumbai", region: "Maharashtra", lat: 19.076, lon: 72.8777 },
  { id: "pune", name: "Pune", region: "Maharashtra", lat: 18.5204, lon: 73.8567 },
  { id: "delhi", name: "Delhi", region: "Delhi", lat: 28.6139, lon: 77.209 },
  { id: "jaipur", name: "Jaipur", region: "Rajasthan", lat: 26.9124, lon: 75.7873 },
  { id: "lucknow", name: "Lucknow", region: "Uttar Pradesh", lat: 26.8467, lon: 80.9462 },
  { id: "varanasi", name: "Varanasi", region: "Uttar Pradesh", lat: 25.3176, lon: 82.9739 },
  { id: "kolkata", name: "Kolkata", region: "West Bengal", lat: 22.5726, lon: 88.3639 },
  { id: "hyderabad", name: "Hyderabad", region: "Telangana", lat: 17.385, lon: 78.4867 },
  { id: "chennai", name: "Chennai", region: "Tamil Nadu", lat: 13.0827, lon: 80.2707 },
  { id: "kochi", name: "Kochi", region: "Kerala", lat: 9.9312, lon: 76.2673 },
  { id: "ahmedabad", name: "Ahmedabad", region: "Gujarat", lat: 23.0225, lon: 72.5714 },
];

export function getCity(id: string): City {
  return CITIES.find((city) => city.id === id) ?? CITIES[0];
}
