import { create } from "zustand";
import { persist } from "zustand/middleware";

export type MonthSystem = "amanta" | "purnimanta";

export type Task = {
  id: string;
  title: string;
  notes: string;
  date: string;
  time: string;
  remind: boolean;
  done: boolean;
  notified: boolean;
};

type AppState = {
  cityId: string;
  monthSystem: MonthSystem;
  tasks: Task[];
  setCity: (cityId: string) => void;
  setMonthSystem: (monthSystem: MonthSystem) => void;
  addTask: (task: Omit<Task, "id" | "done" | "notified">) => void;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  markNotified: (id: string) => void;
};

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      cityId: "bengaluru",
      monthSystem: "amanta",
      tasks: [],
      setCity: (cityId) => set({ cityId }),
      setMonthSystem: (monthSystem) => set({ monthSystem }),
      addTask: (task) =>
        set((state) => ({
          tasks: [
            {
              ...task,
              id: crypto.randomUUID(),
              done: false,
              notified: false,
            },
            ...state.tasks,
          ],
        })),
      toggleTask: (id) =>
        set((state) => ({
          tasks: state.tasks.map((task) => (task.id === id ? { ...task, done: !task.done } : task)),
        })),
      removeTask: (id) => set((state) => ({ tasks: state.tasks.filter((task) => task.id !== id) })),
      markNotified: (id) =>
        set((state) => ({
          tasks: state.tasks.map((task) => (task.id === id ? { ...task, notified: true } : task)),
        })),
    }),
    { name: "suman-2027" },
  ),
);
