import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { BackButton, PanchangGrid, SunMoon, TaskDialog, TimingList } from "@/components/chrome";
import { getCity } from "@/lib/cities";
import { getDay, getLive, monthLabel, type DayBrief } from "@/lib/panchang/engine";
import { eventsOn } from "@/lib/panchang/observe";
import { fitsOn, type MuhuratId } from "@/lib/panchang/muhurat";
import { useApp } from "@/lib/store";
import { formatLong, formatTime, istISO } from "@/lib/time";

export const Route = createFileRoute("/_app/day/$date")({
  component: DayPage,
});

const LABELS: Record<MuhuratId, string> = {
  marriage: "Marriage",
  griha: "Griha Pravesh",
  vehicle: "Vehicle",
  property: "Property",
  beginnings: "New beginnings",
};

function DayPage() {
  const { date } = Route.useParams();
  const cityId = useApp((state) => state.cityId);
  const system = useApp((state) => state.monthSystem);
  const valid = /^\d{4}-\d{2}-\d{2}$/.test(date);
  if (!valid) {
    return (
      <div className="px-4 py-5">
        <BackButton />
        <p className="mt-6 text-muted">That date is not recognised.</p>
      </div>
    );
  }
  return <DayBody date={date} cityId={cityId} system={system} />;
}

function DayBody({ date, cityId, system }: { date: string; cityId: string; system: "amanta" | "purnimanta" }) {
  const city = getCity(cityId);
  const day = useMemo(() => getDay(date, cityId), [date, cityId]);
  const live = date === istISO() ? getLive() : readingFrom(day);
  const events = eventsOn(date, day);
  const suits = fitsOn(date, cityId);
  const [open, setOpen] = useState(false);
  const headline = events[0]?.name ?? `${day.weekdayName} panchang`;

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <BackButton />
      <header>
        <p className="eyebrow">{day.weekdayName} · {day.vara}</p>
        <h1 className="mt-1 font-serif text-4xl leading-tight">{formatLong(date)}</h1>
        <p className="mt-2 text-gold">
          {monthLabel(day, system)} · {day.paksha} Paksha
        </p>
        <p className="mt-1 text-sm text-muted">
          {city.name} · IST · Amanta {day.amantaName}
          {day.amantaName !== day.purnimantaName ? ` · Purnimanta ${day.purnimantaName}` : ""}
        </p>
      </header>
      <section className="rounded-3xl border border-line bg-surface p-4">
        <SunMoon day={day} />
      </section>
      <PanchangGrid live={live} anchor={date === istISO() ? new Date() : day.sunrise} />
      <p className="text-sm leading-relaxed text-muted">
        Sunrise tithi is {day.tithiName} until {formatTime(day.tithiEnd)}, then {day.nextTithi}. Moon in {day.moonRashi} ({day.moonRashiEn}), Sun in {day.sunRashi} ({day.sunRashiEn}).
        {day.sankranti ? ` ${day.sankranti.name} at ${formatTime(day.sankranti.at)}.` : ""}
      </p>
      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-3xl">Timings</h2>
        <TimingList day={day} now={date === istISO() ? new Date() : undefined} />
      </section>
      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-3xl">On this day</h2>
        {events.length === 0 ? <p className="text-sm text-muted">No major observance is listed. The panchang above still holds.</p> : null}
        <ul className="flex flex-col gap-3">
          {events.map((event) => (
            <li key={event.name} className="rounded-2xl border border-line bg-inset px-4 py-3">
              <p className="eyebrow">{event.kind}</p>
              <p className="mt-1 font-serif text-2xl">{event.name}</p>
              <p className="mt-1 text-sm leading-relaxed text-muted">{event.note}</p>
            </li>
          ))}
        </ul>
      </section>
      {date.startsWith("2027") ? (
        <section className="flex flex-col gap-3">
          <h2 className="font-serif text-3xl">Muhurat fit</h2>
          {suits.length === 0 ? (
            <p className="text-sm text-muted">Not flagged by the guides for marriage, griha pravesh, vehicle, property or new beginnings.</p>
          ) : (
            <ul className="overflow-hidden rounded-2xl border border-line">
              {suits.map((item) => (
                <li key={item.id} className="border-b border-line bg-surface px-4 py-3 last:border-b-0">
                  <p className="text-cream">{LABELS[item.id]}</p>
                  <p className="text-sm text-gold">{item.hit.grade}</p>
                  <p className="text-sm text-muted">{item.hit.reason}</p>
                </li>
              ))}
            </ul>
          )}
          <p className="text-xs leading-relaxed text-muted">A family priest may still set the final hour. Abhijit muhurat is the general midday window.</p>
        </section>
      ) : null}
      <button type="button" className="min-h-12 rounded-2xl bg-gold text-bg" onClick={() => setOpen(true)}>
        Remind me
      </button>
      <TaskDialog open={open} onClose={() => setOpen(false)} initial={{ title: headline, date, notes: events[0]?.note ?? "" }} />
    </div>
  );
}

function readingFrom(day: DayBrief) {
  return {
    tithiName: day.tithiName,
    paksha: day.paksha,
    tithiNumber: day.tithiNumber,
    tithiEnd: day.tithiEnd,
    nakshatraName: day.nakshatraName,
    pada: day.pada,
    nakshatraEnd: day.nakshatraEnd,
    yogaName: day.yogaName,
    yogaEnd: day.yogaEnd,
    karanaName: day.karanaName,
    karanaEnd: day.karanaEnd,
  };
}
