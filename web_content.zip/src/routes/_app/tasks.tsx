import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TaskDialog, TaskRow } from "@/components/chrome";
import { useApp } from "@/lib/store";
import { istISO } from "@/lib/time";

export const Route = createFileRoute("/_app/tasks")({
  component: TasksPage,
});

function TasksPage() {
  const tasks = useApp((state) => state.tasks);
  const [open, setOpen] = useState(false);
  const today = istISO();
  const openTasks = tasks.filter((task) => !task.done).sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
  const done = tasks.filter((task) => task.done);

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <header className="flex items-end justify-between">
        <div>
          <p className="eyebrow">On this device</p>
          <h1 className="font-serif text-4xl">Tasks</h1>
        </div>
        <button type="button" className="min-h-11 rounded-full bg-gold px-4 text-sm text-bg" onClick={() => setOpen(true)}>
          Add
        </button>
      </header>
      <p className="text-sm leading-relaxed text-muted">
        Notes and reminders stay in this browser. If you allow alerts, SUMAN can also notify while the app is open.
      </p>
      {openTasks.length === 0 ? (
        <div className="overflow-hidden rounded-3xl border border-line">
          <img src="/art/lotus.jpg" alt="" className="h-40 w-full object-cover" />
          <div className="bg-surface px-4 py-4">
            <p className="font-serif text-2xl">Nothing waiting</p>
            <p className="mt-1 text-sm text-muted">Save Makar Sankranti, a griha pravesh, or a private note.</p>
          </div>
        </div>
      ) : (
        <ul>
          {openTasks.map((task) => (
            <TaskRow key={task.id} task={task} />
          ))}
        </ul>
      )}
      {done.length > 0 ? (
        <section>
          <h2 className="font-serif text-2xl text-muted">Done</h2>
          <ul>
            {done.map((task) => (
              <TaskRow key={task.id} task={task} />
            ))}
          </ul>
        </section>
      ) : null}
      <TaskDialog open={open} onClose={() => setOpen(false)} initial={{ date: today.startsWith("2027") ? today : "2027-01-15" }} />
    </div>
  );
}
