import { createFileRoute, Outlet } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { Shell } from "@/components/chrome";
import { getCity } from "@/lib/cities";
import { upcomingMajors } from "@/lib/panchang/festivals";
import { useApp } from "@/lib/store";
import { daysBetween, formatLong, istISO } from "@/lib/time";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  return (
    <div className="app-frame">
      <BrandAside />
      <Shell>
        <Outlet />
      </Shell>
      <Toaster position="top-center" />
    </div>
  );
}

function BrandAside() {
  const city = getCity(useApp((state) => state.cityId));
  const today = istISO();
  const anchor = today < "2027-01-01" ? "2027-01-01" : today;
  const next = upcomingMajors(anchor, 3);
  return (
    <aside className="brand-pane">
      <div className="brand-hero">
        <img src="/art/temple.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" />
        <div className="absolute inset-x-0 bottom-0 p-8">
          <p className="eyebrow">2027 Hindu calendar</p>
          <h1 className="mt-2 font-serif text-6xl leading-none text-cream">SUMAN</h1>
          <p className="mt-3 max-w-sm text-base leading-relaxed text-cream">
            Panchang, festivals, muhurat and personal reminders — one year, kept in one place.
          </p>
        </div>
      </div>
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-8 py-6">
        <p className="text-sm text-muted">
          Timings for <span className="text-cream">{city.name}</span>, shown in IST.
        </p>
        <ul className="space-y-3">
          {next.map((festival) => {
            const away = daysBetween(today, festival.date);
            return (
              <li key={festival.date + festival.name} className="flex items-baseline justify-between gap-4 border-t border-line pt-3">
                <span className="font-serif text-2xl text-cream">{festival.name}</span>
                <span className="shrink-0 text-sm text-gold">
                  {away > 0 ? `${away}d` : away === 0 ? "Today" : formatLong(festival.date)}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </aside>
  );
}
