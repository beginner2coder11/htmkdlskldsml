import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";
import { CityButton } from "@/components/chrome";
import { cn } from "@/lib/cn";
import { getDay } from "@/lib/panchang/engine";
import { dotFor, eventsOn } from "@/lib/panchang/observe";
import { useApp } from "@/lib/store";
import { addDays, formatShort, istISO, monthLength, pad2, WEEK_SHORT, weekdayIndex } from "@/lib/time";

export const Route = createFileRoute("/_app/calendar")({
  component: CalendarPage,
});

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function CalendarPage() {
  const cityId = useApp((state) => state.cityId);
  const today = istISO();
  const startMonth = today.startsWith("2027") ? Number(today.slice(5, 7)) : 1;
  const [month, setMonth] = useState(startMonth);
  const isoMonth = `2027-${pad2(month)}`;
  const length = monthLength(2027, month);
  const first = `${isoMonth}-01`;
  const lead = weekdayIndex(first);
  const cells = useMemo(() => {
    const days: Array<string | null> = Array.from({ length: lead }, () => null);
    for (let day = 1; day <= length; day += 1) days.push(`${isoMonth}-${pad2(day)}`);
    while (days.length % 7 !== 0) days.push(null);
    return days;
  }, [isoMonth, lead, length]);

  const marked = useMemo(() => {
    const map = new Map<string, ReturnType<typeof eventsOn>>();
    let cursor = first;
    for (let i = 0; i < length; i += 1) {
      map.set(cursor, eventsOn(cursor, getDay(cursor, cityId)));
      cursor = addDays(cursor, 1);
    }
    return map;
  }, [cityId, first, length]);

  const list = [...marked.entries()].flatMap(([, events]) => events).filter((event) => event.kind === "major" || event.kind === "vrat" || event.kind === "eclipse");

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <header className="flex items-center justify-between">
        <div>
          <p className="eyebrow">2027</p>
          <h1 className="font-serif text-4xl">{MONTHS[month - 1]}</h1>
        </div>
        <CityButton />
      </header>
      <div className="flex items-center justify-between">
        <button type="button" aria-label="Previous month" disabled={month === 1} onClick={() => setMonth((value) => value - 1)} className="grid size-11 place-items-center rounded-full border border-line text-gold disabled:opacity-30">
          <ChevronLeft size={18} />
        </button>
        <p className="text-sm text-muted">January – December</p>
        <button type="button" aria-label="Next month" disabled={month === 12} onClick={() => setMonth((value) => value + 1)} className="grid size-11 place-items-center rounded-full border border-line text-gold disabled:opacity-30">
          <ChevronRight size={18} />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-y-1 text-center">
        {WEEK_SHORT.map((label) => (
          <p key={label} className="micro pb-2 text-muted">
            {label}
          </p>
        ))}
        {cells.map((iso, index) => {
          if (!iso) return <span key={`empty-${index}`} />;
          const events = marked.get(iso) ?? [];
          const dot = dotFor(events);
          const isToday = iso === today;
          return (
            <Link
              key={iso}
              to="/day/$date"
              params={{ date: iso }}
              className={cn(
                "relative mx-auto grid size-11 place-items-center rounded-full text-sm",
                isToday ? "bg-gold text-bg" : "text-cream",
              )}
            >
              <span className="tabular-nums">{Number(iso.slice(8))}</span>
              {dot ? (
                <span
                  className={cn(
                    "absolute bottom-1 size-1 rounded-full",
                    dot === "major" ? (isToday ? "bg-bg" : "bg-gold") : isToday ? "bg-bg/70" : "bg-muted",
                  )}
                />
              ) : null}
            </Link>
          );
        })}
      </div>
      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-3xl">This month</h2>
        {list.length === 0 ? <p className="text-sm text-muted">No listed observances.</p> : null}
        <ul className="flex flex-col">
          {list.map((event) => (
            <li key={event.date + event.name} className="border-t border-line">
              <Link to="/day/$date" params={{ date: event.date }} className="flex items-baseline justify-between gap-3 py-3">
                <span className="text-cream">{event.name}</span>
                <span className="shrink-0 text-sm text-gold">{formatShort(event.date)}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
