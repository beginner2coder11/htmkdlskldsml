import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { BackButton, EventCard } from "@/components/chrome";
import { cn } from "@/lib/cn";
import { FESTIVALS, type FestivalKind } from "@/lib/panchang/festivals";

export const Route = createFileRoute("/_app/festivals")({
  component: FestivalsPage,
});

const FILTERS: Array<{ id: "all" | FestivalKind; label: string }> = [
  { id: "all", label: "All" },
  { id: "major", label: "Major" },
  { id: "vrat", label: "Vrat" },
  { id: "sankranti", label: "Sankranti" },
];

function FestivalsPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [query, setQuery] = useState("");
  const list = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return FESTIVALS.filter((festival) => {
      if (filter !== "all" && festival.kind !== filter) return false;
      if (!needle) return true;
      return festival.name.toLowerCase().includes(needle) || festival.note.toLowerCase().includes(needle);
    });
  }, [filter, query]);

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <BackButton fallback="/more" />
      <header>
        <p className="eyebrow">January – December</p>
        <h1 className="font-serif text-4xl">Festivals & vrat</h1>
      </header>
      <input className="field" placeholder="Search Diwali, Ekadashi…" value={query} onChange={(event) => setQuery(event.target.value)} />
      <div className="flex gap-2 overflow-x-auto">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={cn(
              "min-h-10 shrink-0 rounded-full border px-4 text-sm",
              filter === item.id ? "border-gold bg-gold text-bg" : "border-line text-cream",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <p className="text-sm text-muted">{list.length} observances</p>
      <div className="flex flex-col gap-3">
        {list.map((festival) => (
          <EventCard key={festival.date + festival.name} event={festival} compact={festival.kind !== "major"} />
        ))}
      </div>
    </div>
  );
}
