import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { MUHURAT_ICONS } from "@/components/chrome";
import { cn } from "@/lib/cn";
import { getDay } from "@/lib/panchang/engine";
import { MUHURAT_COPY, muhuratFor, type MuhuratId } from "@/lib/panchang/muhurat";
import { useApp } from "@/lib/store";
import { formatRange, formatShort, WEEK_SHORT, weekdayIndex } from "@/lib/time";

export const Route = createFileRoute("/_app/muhurat")({
  component: MuhuratPage,
});

const ORDER: MuhuratId[] = ["marriage", "griha", "vehicle", "property", "beginnings"];

function MuhuratPage() {
  const cityId = useApp((state) => state.cityId);
  const [kind, setKind] = useState<MuhuratId>("marriage");
  const hits = useMemo(() => muhuratFor(kind, cityId), [kind, cityId]);
  const copy = MUHURAT_COPY[kind];

  const groups = new Map<string, typeof hits>();
  for (const hit of hits) {
    const key = hit.iso.slice(0, 7);
    const list = groups.get(key) ?? [];
    list.push(hit);
    groups.set(key, list);
  }

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <header>
        <p className="eyebrow">2027</p>
        <h1 className="font-serif text-4xl">Muhurat</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">{copy.summary}</p>
      </header>
      <div className="relative -mx-4 overflow-hidden">
        <img src="/art/mandap.jpg" alt="" className="h-36 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" />
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {ORDER.map((id) => {
          const Icon = MUHURAT_ICONS[id];
          const on = id === kind;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setKind(id)}
              className={cn(
                "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm",
                on ? "border-gold bg-gold text-bg" : "border-line text-cream",
              )}
            >
              <Icon size={15} aria-hidden="true" />
              {MUHURAT_COPY[id].title}
            </button>
          );
        })}
      </div>
      <p className="text-sm text-muted">{hits.length} dates · Abhijit is the midday window on each</p>
      {[...groups.entries()].map(([key, list]) => (
        <section key={key} className="flex flex-col">
          <h2 className="font-serif text-2xl text-gold">{monthTitle(key)}</h2>
          <ul>
            {list.map((hit) => {
              const day = getDay(hit.iso, cityId);
              return (
                <li key={hit.iso + hit.grade} className="border-b border-line">
                  <Link to="/day/$date" params={{ date: hit.iso }} className="flex flex-col gap-1 py-3">
                    <span className="flex items-baseline justify-between gap-3">
                      <span className="text-cream">
                        {formatShort(hit.iso)} · {WEEK_SHORT[weekdayIndex(hit.iso)]}
                      </span>
                      <span className="text-sm text-gold">{hit.grade}</span>
                    </span>
                    <span className="text-sm text-muted">
                      {day.paksha} {day.tithiName} · {day.nakshatraName}
                    </span>
                    <span className="text-sm tabular-nums text-auspicious">Abhijit {formatRange(day.timings.abhijit.start, day.timings.abhijit.end)}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
      <p className="text-xs leading-relaxed text-muted">
        These are traditional filters, not a personalised lagna. Rahu Kalam, Yamaganda and Gulika still apply on a chosen day. Ask your priest before fixing a wedding or a griha pravesh.
      </p>
    </div>
  );
}

function monthTitle(key: string) {
  const date = new Date(`${key}-01T12:00:00+05:30`);
  return new Intl.DateTimeFormat("en-IN", { month: "long", timeZone: "Asia/Kolkata" }).format(date);
}
