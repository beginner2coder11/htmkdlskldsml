import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { CityButton, EventCard, PanchangGrid, SunMoon, TaskDialog, TaskRow, TimingList } from "@/components/chrome";
import { getCity } from "@/lib/cities";
import { getDay, getLive, monthLabel } from "@/lib/panchang/engine";
import { upcomingMajors } from "@/lib/panchang/festivals";
import { eventsOn } from "@/lib/panchang/observe";
import { useApp } from "@/lib/store";
import { formatMonthYear, formatTime, greeting, istISO, samvatFor } from "@/lib/time";

export const Route = createFileRoute("/_app/")({
  component: TodayPage,
});

function TodayPage() {
  const cityId = useApp((state) => state.cityId);
  const system = useApp((state) => state.monthSystem);
  const tasks = useApp((state) => state.tasks);
  const [now, setNow] = useState(() => new Date());
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(id);
  }, []);
  const today = istISO(now);
  const city = getCity(cityId);
  const day = useMemo(() => getDay(today, cityId), [today, cityId]);
  const live = useMemo(() => getLive(now), [now]);
  const events = eventsOn(today, day);
  const headline = events[0];
  const upcoming = upcomingMajors(today < "2027-01-01" ? "2027-01-01" : today, 3).filter((item) => item.date !== today);
  const mine = tasks.filter((task) => !task.done && task.date >= today).slice(0, 3);
  const samvat = samvatFor(today);

  return (
    <div className="flex flex-col gap-5 px-4 py-5">
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="wordmark text-cream">SUMAN</p>
          <p className="eyebrow mt-1">Hindu calendar</p>
        </div>
        <CityButton />
      </header>

      <section className="relative overflow-hidden rounded-3xl border border-line">
        <img src="/art/temple.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/80 to-bg/25" />
        <div className="relative flex flex-col gap-4 p-5">
          <div className="flex items-center justify-between">
            <p className="text-sm text-cream">{greeting(now)}</p>
            <p className="text-xs text-muted">
              VS {samvat.vikram} · Shaka {samvat.shaka}
            </p>
          </div>
          <div>
            <p className="eyebrow">{day.weekdayName}</p>
            <p className="date-num text-cream">{Number(today.slice(8))}</p>
            <p className="kicker mt-2 text-cream">{formatMonthYear(today)}</p>
            <p className="mt-2 font-serif text-2xl text-gold">
              {monthLabel(day, system)} · {day.paksha} Paksha
            </p>
          </div>
          <SunMoon day={day} />
        </div>
      </section>

      {!today.startsWith("2027") ? (
        <p className="rounded-2xl border border-line bg-inset px-4 py-3 text-sm leading-relaxed text-muted">
          Festivals and muhurat in SUMAN cover January–December 2027. Today’s panchang is live for {city.name}.
        </p>
      ) : null}

      <section className="flex flex-col gap-3">
        <div className="flex items-end justify-between">
          <h2 className="font-serif text-3xl">Panchang</h2>
          <Link to="/day/$date" params={{ date: today }} className="text-sm text-gold">
            Full day
          </Link>
        </div>
        <PanchangGrid live={live} anchor={now} />
        <p className="text-sm text-muted">
            At sunrise: {day.tithiName}, {day.nakshatraName}. Then {day.nextTithi} from {formatTime(day.tithiEnd)}. Moon in {day.moonRashi} · {day.moonRashiEn}.
          </p>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-3xl">Important timings</h2>
        <TimingList day={day} now={now} />
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex items-end justify-between">
          <h2 className="font-serif text-3xl">{headline ? "Today" : "Coming up"}</h2>
          <Link to="/festivals" className="text-sm text-gold">
            All festivals
          </Link>
        </div>
        {headline ? <EventCard event={headline} /> : null}
        {events.slice(1, 3).map((event) => (
          <EventCard key={event.name} event={event} compact />
        ))}
        {!headline
          ? upcoming.slice(0, 2).map((event) => <EventCard key={event.date + event.name} event={event} />)
          : upcoming.slice(0, 1).map((event) => <EventCard key={event.date + event.name} event={event} compact />)}
      </section>

      <section className="flex flex-col gap-2">
        <div className="flex items-end justify-between">
          <h2 className="font-serif text-3xl">Reminders</h2>
          <button type="button" className="text-sm text-gold" onClick={() => setOpen(true)}>
            Add
          </button>
        </div>
        {mine.length === 0 ? (
          <p className="text-sm text-muted">Nothing saved yet. Pin a festival or a personal date.</p>
        ) : (
          <ul>
            {mine.map((task) => (
              <TaskRow key={task.id} task={task} />
            ))}
          </ul>
        )}
      </section>
      <TaskDialog open={open} onClose={() => setOpen(false)} initial={{ date: today.startsWith("2027") ? today : "2027-01-15" }} />
    </div>
  );
}
