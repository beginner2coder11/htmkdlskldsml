import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { CityButton } from "@/components/chrome";
import { cn } from "@/lib/cn";
import { useApp, type MonthSystem } from "@/lib/store";
import { istISO, samvatFor } from "@/lib/time";

export const Route = createFileRoute("/_app/more")({
  component: MorePage,
});

function MorePage() {
  const system = useApp((state) => state.monthSystem);
  const setMonthSystem = useApp((state) => state.setMonthSystem);
  const today = istISO();
  const samvat = samvatFor(today);
  const [permission, setPermission] = useStateLabel();

  return (
    <div className="flex flex-col gap-6 px-4 py-5">
      <header>
        <p className="eyebrow">SUMAN</p>
        <h1 className="font-serif text-4xl">More</h1>
      </header>
      <Link to="/festivals" className="overflow-hidden rounded-3xl border border-line">
        <div className="relative h-32">
          <img src="/art/diyas.jpg" alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/60 to-transparent" />
          <div className="absolute inset-0 flex flex-col justify-end p-4">
            <p className="eyebrow">2027</p>
            <p className="font-serif text-3xl">Festivals & vrat</p>
          </div>
        </div>
      </Link>
      <section className="flex flex-col gap-3 rounded-3xl border border-line bg-surface p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-2xl">Place</h2>
          <CityButton />
        </div>
        <p className="text-sm leading-relaxed text-muted">
          Sunrise, Rahu Kalam and the other day divisions follow the city. Tithi itself is the same sky everywhere; which tithi is “today” can still shift if sunrise differs.
        </p>
      </section>
      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-2xl">Lunar month</h2>
        <div className="grid grid-cols-2 gap-2">
          {(
            [
              ["amanta", "Amanta", "Month ends on Amavasya. South and West."],
              ["purnimanta", "Purnimanta", "Month ends on Purnima. North."],
            ] as const
          ).map(([id, title, note]) => (
            <button
              key={id}
              type="button"
              onClick={() => setMonthSystem(id as MonthSystem)}
              className={cn("rounded-2xl border px-3 py-3 text-left", system === id ? "border-gold bg-inset" : "border-line")}
            >
              <span className="block text-cream">{title}</span>
              <span className="mt-1 block text-xs leading-relaxed text-muted">{note}</span>
            </button>
          ))}
        </div>
        <p className="text-sm text-muted">
          Vikram Samvat {samvat.vikram} · Shaka {samvat.shaka}. The year-count steps on Ugadi, 7 April 2027.
        </p>
      </section>
      <section className="flex flex-col gap-2">
        <h2 className="font-serif text-2xl">Reminders</h2>
        <p className="text-sm leading-relaxed text-muted">Alerts appear inside SUMAN. Browser notifications only fire while this tab is open.</p>
        <button
          type="button"
          className="min-h-11 self-start rounded-full border border-line px-4 text-sm text-gold"
          onClick={() => {
            if (typeof Notification === "undefined") return;
            void Notification.requestPermission().then(() => setPermission(Notification.permission));
          }}
        >
          {permission === "granted" ? "Alerts allowed" : "Allow alerts"}
        </button>
      </section>
      <section className="flex flex-col gap-2 text-sm leading-relaxed text-muted">
        <h2 className="font-serif text-2xl text-cream">How to read it</h2>
        <p>Tithi is the moon’s distance from the sun, in twelve-degree steps. Nakshatra is the moon’s place among the twenty-seven stars, sidereal, Lahiri ayanamsha.</p>
        <p>Rahu Kalam, Yamaganda and Gulika are eight equal parts of the day from sunrise to sunset, picked by the weekday. Abhijit is the eighth of fifteen muhurtas. Brahma muhurta is the hour before dawn.</p>
        <p>Festival dates follow published Amanta observances for India in 2027. A local temple may keep a tithi on the next morning if it begins late.</p>
      </section>
      <p className="font-serif text-xl italic leading-relaxed text-gold">
        “A companion for the year — confirm the final muhurat with your priest.”
      </p>
    </div>
  );
}

function useStateLabel() {
  const [permission, setPermission] = useStateSafe();
  return [permission, setPermission] as const;
}

function useStateSafe(): [NotificationPermission | "unknown", (value: NotificationPermission | "unknown") => void] {
  const [permission, setPermission] = useState<NotificationPermission | "unknown">(() => {
    if (typeof Notification === "undefined") return "unknown";
    return Notification.permission;
  });
  return [permission, setPermission];
}
