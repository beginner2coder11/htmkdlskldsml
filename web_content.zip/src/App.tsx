import React, { useState, useEffect } from 'react';
import {
  RecorderSettings,
  RecordingItem,
  NavigationTab,
} from './types/recorder';
import {
  getAllRecordings,
  seedSampleIfEmpty,
  deleteRecording,
} from './utils/storage';
import { useScreenRecorder } from './hooks/useScreenRecorder';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { RecordView } from './components/RecordView';
import { RecordingsGallery } from './components/RecordingsGallery';
import { ToolsView } from './components/ToolsView';
import { SettingsView } from './components/SettingsView';
import { FloatingBall } from './components/FloatingBall';
import { FacecamOverlay } from './components/FacecamOverlay';
import { AnnotationCanvas } from './components/AnnotationCanvas';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { VideoTrimmerModal } from './components/VideoTrimmerModal';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor } from 'lucide-react';

const INITIAL_SETTINGS: RecorderSettings = {
  resolution: '1080p',
  fps: 60,
  bitrate: 16,
  audioSource: 'mic_and_system',
  micGain: 1.2,
  countdownSeconds: 3,
  audioBeep: true,
  showFacecam: false,
  facecamShape: 'circle',
  facecamSize: 'md',
  facecamMirrored: true,
  exportFormat: 'mp4',
  includeWatermark: false,
  watermarkText: 'Stitch HD',
  floatingBallEnabled: true,
  deviceFrameMode: false,
};

export default function App() {
  const [settings, setSettings] = useState<RecorderSettings>(INITIAL_SETTINGS);
  const [activeTab, setActiveTab] = useState<NavigationTab>('record');
  const [recordings, setRecordings] = useState<RecordingItem[]>([]);
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(false);
  const [playerItem, setPlayerItem] = useState<RecordingItem | null>(null);
  const [trimmerItem, setTrimmerItem] = useState<RecordingItem | null>(null);
  const [isBrushOpen, setIsBrushOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load recordings from IndexedDB on startup
  useEffect(() => {
    async function loadData() {
      try {
        const items = await seedSampleIfEmpty();
        setRecordings(items);
      } catch (e) {
        console.error('Failed to load initial recordings:', e);
      }
    }
    loadData();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  const handleRecordingSaved = (newItem: RecordingItem) => {
    setRecordings((prev) => [newItem, ...prev]);
    showToast(`High Definition MP4 saved to local storage!`);
    setActiveTab('gallery');
  };

  const {
    status,
    countdownValue,
    elapsedTime,
    micVolumeLevel,
    cameraStream,
    monitorVideoRef,
    errorMessage,
    startRecordingFlow,
    pauseRecording,
    resumeRecording,
    stopRecording,
    takeScreenshot,
    toggleFacecam,
    setErrorMessage,
  } = useScreenRecorder({
    settings,
    onRecordingComplete: handleRecordingSaved,
  });

  const handleDeleteRecording = async (id: string) => {
    await deleteRecording(id);
    const updated = await getAllRecordings();
    setRecordings(updated);
    showToast('Recording removed from local storage');
  };

  const handleRefreshRecordings = async () => {
    const updated = await getAllRecordings();
    setRecordings(updated);
  };

  const handleClearAll = async () => {
    for (const r of recordings) {
      await deleteRecording(r.id);
    }
    setRecordings([]);
    showToast('Local storage database cleared');
  };

  const totalStorageBytes = recordings.reduce((acc, curr) => acc + (curr.size || 0), 0);
  const isRecording = status === 'recording' || status === 'paused';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isMobileFrame={isMobileFrame}
        setIsMobileFrame={setIsMobileFrame}
        recordingsCount={recordings.length}
        isRecording={isRecording}
        onQuickRecord={startRecordingFlow}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 flex flex-col items-center justify-start p-3 sm:p-6 w-full">
        {/* If Mobile Frame mode is toggled, wrap in a Google Pixel Stitch smartphone bezel */}
        {isMobileFrame ? (
          <div className="w-full max-w-[420px] rounded-[44px] bg-slate-900 border-[8px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col relative my-4">
            {/* Phone Top Notch / Status Bar */}
            <div className="h-10 bg-slate-950 px-6 flex items-center justify-between text-xs text-slate-400 select-none">
              <span className="font-semibold text-white font-mono text-[11px]">9:41</span>
              {/* Camera punch hole cutout */}
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800 shadow-inner" />
              <div className="flex items-center gap-1.5 text-slate-300">
                <Signal className="w-3 h-3" />
                <Wifi className="w-3 h-3" />
                <BatteryMedium className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Inner Phone Screen Content */}
            <div className="p-4 flex-1 overflow-y-auto max-h-[740px]">
              {activeTab === 'record' && (
                <RecordView
                  status={status}
                  countdownValue={countdownValue}
                  elapsedTime={elapsedTime}
                  micVolumeLevel={micVolumeLevel}
                  settings={settings}
                  setSettings={setSettings}
                  monitorVideoRef={monitorVideoRef}
                  onStartRecord={startRecordingFlow}
                  onPauseRecord={pauseRecording}
                  onResumeRecord={resumeRecording}
                  onStopRecord={stopRecording}
                  onTakeScreenshot={takeScreenshot}
                  onToggleFacecam={toggleFacecam}
                  onToggleBrush={() => setIsBrushOpen(true)}
                  onOpenSettings={() => setActiveTab('settings')}
                  errorMessage={errorMessage}
                  onDismissError={() => setErrorMessage(null)}
                />
              )}

              {activeTab === 'gallery' && (
                <RecordingsGallery
                  recordings={recordings}
                  onSelectPlay={(item) => setPlayerItem(item)}
                  onSelectTrim={(item) => setTrimmerItem(item)}
                  onDelete={handleDeleteRecording}
                  onRefresh={handleRefreshRecordings}
                  onGoToRecord={() => setActiveTab('record')}
                />
              )}

              {activeTab === 'tools' && (
                <ToolsView
                  recordings={recordings}
                  onOpenTrimmer={(item) => setTrimmerItem(item)}
                  onOpenBrush={() => setIsBrushOpen(true)}
                  onTakeScreenshot={takeScreenshot}
                />
              )}

              {activeTab === 'settings' && (
                <SettingsView
                  settings={settings}
                  setSettings={setSettings}
                  totalStorageBytes={totalStorageBytes}
                  recordingsCount={recordings.length}
                  onClearAllRecordings={handleClearAll}
                />
              )}
            </div>

            {/* Android Home Bar Indicator */}
            <div className="h-6 bg-slate-950 flex items-center justify-center">
              <div className="w-28 h-1 bg-slate-600 rounded-full" />
            </div>
          </div>
        ) : (
          /* Responsive Full Width / Tablet / Desktop Container */
          <div className="w-full max-w-5xl mx-auto px-2 sm:px-4">
            {activeTab === 'record' && (
              <RecordView
                status={status}
                countdownValue={countdownValue}
                elapsedTime={elapsedTime}
                micVolumeLevel={micVolumeLevel}
                settings={settings}
                setSettings={setSettings}
                monitorVideoRef={monitorVideoRef}
                onStartRecord={startRecordingFlow}
                onPauseRecord={pauseRecording}
                onResumeRecord={resumeRecording}
                onStopRecord={stopRecording}
                onTakeScreenshot={takeScreenshot}
                onToggleFacecam={toggleFacecam}
                onToggleBrush={() => setIsBrushOpen(true)}
                onOpenSettings={() => setActiveTab('settings')}
                errorMessage={errorMessage}
                onDismissError={() => setErrorMessage(null)}
              />
            )}

            {activeTab === 'gallery' && (
              <RecordingsGallery
                recordings={recordings}
                onSelectPlay={(item) => setPlayerItem(item)}
                onSelectTrim={(item) => setTrimmerItem(item)}
                onDelete={handleDeleteRecording}
                onRefresh={handleRefreshRecordings}
                onGoToRecord={() => setActiveTab('record')}
              />
            )}

            {activeTab === 'tools' && (
              <ToolsView
                recordings={recordings}
                onOpenTrimmer={(item) => setTrimmerItem(item)}
                onOpenBrush={() => setIsBrushOpen(true)}
                onTakeScreenshot={takeScreenshot}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                settings={settings}
                setSettings={setSettings}
                totalStorageBytes={totalStorageBytes}
                recordingsCount={recordings.length}
                onClearAllRecordings={handleClearAll}
              />
            )}
          </div>
        )}
      </main>

      {/* Floating Action Quick-Record Bubble (Play Store signature) */}
      {settings.floatingBallEnabled && (
        <FloatingBall
          status={status}
          elapsedTime={elapsedTime}
          onRecord={startRecordingFlow}
          onPause={pauseRecording}
          onResume={resumeRecording}
          onStop={stopRecording}
          onScreenshot={takeScreenshot}
          onToggleBrush={() => setIsBrushOpen(true)}
          onToggleFacecam={toggleFacecam}
          onOpenLibrary={() => setActiveTab('gallery')}
        />
      )}

      {/* Facecam Webcam Overlay */}
      {cameraStream && (
        <FacecamOverlay
          stream={cameraStream}
          settings={settings}
          onClose={() => toggleFacecam()}
        />
      )}

      {/* Screen Annotation Canvas */}
      <AnnotationCanvas
        isOpen={isBrushOpen}
        onClose={() => setIsBrushOpen(false)}
      />

      {/* Video Player Modal */}
      {playerItem && (
        <VideoPlayerModal
          item={playerItem}
          onClose={() => setPlayerItem(null)}
          onOpenTrimmer={(item) => setTrimmerItem(item)}
        />
      )}

      {/* Video Trimmer Modal */}
      {trimmerItem && (
        <VideoTrimmerModal
          item={trimmerItem}
          onClose={() => setTrimmerItem(null)}
          onTrimSaved={() => {
            handleRefreshRecordings();
            showToast('Trimmed MP4 clip saved to Library!');
          }}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-blue-600 text-white font-medium text-xs shadow-2xl backdrop-blur-md flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <span className="w-2 h-2 rounded-full bg-white" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar (Natural Thumb Zone) */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        recordingsCount={recordings.length}
      />
    </div>
  );
}
