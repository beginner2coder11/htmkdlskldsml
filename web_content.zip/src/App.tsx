/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, ConnectionMode } from './types';
import { bridgeClient } from './services/bridgeService';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ClipboardView } from './components/ClipboardView';
import { ProtocolView } from './components/ProtocolView';
import { DeployView } from './components/DeployView';
import { SdkView } from './components/SdkView';
import { SecurityView } from './components/SecurityView';
import {
  CheckCircle2,
  AlertCircle,
  Info,
  X,
  Lock,
  Wifi,
  Shield,
  Heart,
} from 'lucide-react';

interface ToastNotification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [mode, setMode] = useState<ConnectionMode>('simulator');
  const [host, setHost] = useState<string>('127.0.0.1');
  const [port, setPort] = useState<number>(8765);
  const [lastLatencyMs, setLastLatencyMs] = useState<number>(24);
  const [isPinging, setIsPinging] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Check URL query parameters (e.g. ?tab=deploy or ?autostart=1)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab');
    if (tabParam && ['dashboard', 'clipboard', 'protocol', 'deploy', 'sdk', 'security'].includes(tabParam)) {
      setActiveTab(tabParam as ActiveTab);
    }
  }, []);

  const handleNotify = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const handleUpdateHostPort = (newHost: string, newPort: number) => {
    setHost(newHost);
    setPort(newPort);
    bridgeClient.setHostAndPort(newHost, newPort);
    handleNotify(`Bridge endpoint set to ${newHost}:${newPort}`, 'info');
  };

  const handleModeChange = (newMode: ConnectionMode) => {
    setMode(newMode);
    bridgeClient.setMode(newMode);
    handleNotify(
      newMode === 'simulator'
        ? 'Switched to Live Simulator Mode (Safe, in-browser PC simulation)'
        : `Switched to Direct Bridge Mode targeting ${host}:${port}`,
      'info'
    );
  };

  const handlePing = async () => {
    setIsPinging(true);
    try {
      const res = await bridgeClient.ping();
      if (res.success) {
        setLastLatencyMs(res.latencyMs);
        handleNotify(`TLS Ping OK (${res.latencyMs}ms)`, 'success');
      } else {
        handleNotify(`Ping failed: ${res.error}`, 'error');
      }
    } catch (err: any) {
      handleNotify(`Ping failed: ${err.message}`, 'error');
    } finally {
      setIsPinging(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        mode={mode}
        setMode={handleModeChange}
        host={host}
        port={port}
        onUpdateHostPort={handleUpdateHostPort}
        lastLatencyMs={lastLatencyMs}
        isConnected={true}
        onPing={handlePing}
        isPinging={isPinging}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && <DashboardView onNotify={handleNotify} />}
        {activeTab === 'clipboard' && <ClipboardView onNotify={handleNotify} />}
        {activeTab === 'protocol' && <ProtocolView onNotify={handleNotify} />}
        {activeTab === 'deploy' && <DeployView onNotify={handleNotify} />}
        {activeTab === 'sdk' && <SdkView host={host} port={port} onNotify={handleNotify} />}
        {activeTab === 'security' && <SecurityView />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              <strong className="text-slate-300">Link-to-Windows++</strong>: Locally-only TCP/TLS Bridge. Zero Cloud Dependencies.
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-cyan-400" /> TLS 1.2+
            </span>
            <span className="flex items-center gap-1">
              <Wifi className="w-3.5 h-3.5 text-indigo-400" /> LAN Subnet Only
            </span>
            <span className="text-slate-600">v2.4.0 Production</span>
          </div>
        </div>
      </footer>

      {/* Toast Notification Container */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-xl border shadow-2xl text-xs font-medium animate-in slide-in-from-bottom-3 duration-200 ${
              toast.type === 'success'
                ? 'bg-slate-900 border-emerald-800/80 text-emerald-300 shadow-emerald-950/20'
                : toast.type === 'error'
                ? 'bg-slate-900 border-rose-800/80 text-rose-300 shadow-rose-950/20'
                : 'bg-slate-900 border-cyan-800/80 text-cyan-300 shadow-cyan-950/20'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />}
              {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />}
              {toast.type === 'info' && <Info className="w-4 h-4 text-cyan-400 flex-shrink-0" />}
              <span>{toast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="text-slate-400 hover:text-white p-0.5 ml-2"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
