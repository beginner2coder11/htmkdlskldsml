export type AppId =
  | 'taskmgr'
  | 'terminal'
  | 'notepad'
  | 'calc'
  | 'explorer'
  | 'browser'
  | 'launcher'
  | 'settings';

export interface WindowState {
  id: string;
  appId: AppId;
  title: string;
  icon: string;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  position: { x: number; y: number };
  size: { width: number; height: number };
  customData?: any;
}

export type ProcessPriority = 'Low' | 'Below Normal' | 'Normal' | 'Above Normal' | 'High' | 'Realtime';

export interface ProcessItem {
  pid: number;
  name: string;
  category: 'apps' | 'background' | 'windows';
  windowId?: string;
  appId?: AppId;
  cpu: number; // percentage
  memoryMb: number;
  diskMbS: number;
  networkMbps: number;
  gpuPct: number;
  powerUsage: 'Very low' | 'Low' | 'Moderate' | 'High' | 'Very high';
  status: 'Running' | 'Suspended' | 'Efficiency Mode';
  publisher: string;
  priority: ProcessPriority;
  commandLine: string;
  startTime: string;
}

export interface SystemTelemetry {
  cpuUsage: number;
  cpuFreqGhz: number;
  cpuCores: number[];
  memoryUsedGb: number;
  memoryTotalGb: number;
  memoryCommittedGb: number;
  diskActivePct: number;
  diskReadKbps: number;
  diskWriteKbps: number;
  networkSendKbps: number;
  networkRecvKbps: number;
  gpuUsagePct: number;
  gpuMemoryGb: number;
  gpuTempC: number;
  uptimeSec: number;
  history: {
    cpu: number[];
    memory: number[];
    disk: number[];
    network: number[];
    gpu: number[];
  };
}

export interface PCApplication {
  id: string;
  name: string;
  executable: string;
  description: string;
  category: 'System Tools' | 'Productivity & Code' | 'Media & Social' | 'Browsers & Web' | 'Utilities';
  protocolUri?: string;
  runCommand: string;
  powershellCommand: string;
  iconName: string;
  isVirtualSupported: boolean;
  targetAppId?: AppId;
  badge?: string;
}

export interface ServiceItem {
  name: string;
  pid?: number;
  description: string;
  status: 'Running' | 'Stopped';
  startupType: 'Automatic' | 'Manual' | 'Disabled';
  group?: string;
}

export interface StartupApp {
  id: string;
  name: string;
  publisher: string;
  status: 'Enabled' | 'Disabled';
  startupImpact: 'High' | 'Medium' | 'Low' | 'None';
  startupTimeMs: number;
  command: string;
}

export interface ExplorerItem {
  name: string;
  path: string;
  type: 'folder' | 'file' | 'drive' | 'exe';
  size?: string;
  dateModified: string;
  targetAppId?: AppId;
  content?: string;
}
