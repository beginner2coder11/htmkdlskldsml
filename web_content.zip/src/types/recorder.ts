export type ResolutionPreset = '4k' | '2k' | '1080p' | '720p' | '480p';

export interface ResolutionDetails {
  label: string;
  sublabel: string;
  width: number;
  height: number;
  badge: string;
}

export const RESOLUTION_PRESETS: Record<ResolutionPreset, ResolutionDetails> = {
  '4k': {
    label: '4K Ultra HD',
    sublabel: '3840 × 2160 · Crystal Clear',
    width: 3840,
    height: 2160,
    badge: '4K UHD',
  },
  '2k': {
    label: '2K Quad HD',
    sublabel: '2560 × 1440 · Pro Detail',
    width: 2560,
    height: 1440,
    badge: '2K QHD',
  },
  '1080p': {
    label: '1080p Full HD',
    sublabel: '1920 × 1080 · High Definition (Recommended)',
    width: 1920,
    height: 1080,
    badge: '1080p HD',
  },
  '720p': {
    label: '720p HD',
    sublabel: '1280 × 720 · Standard HD',
    width: 1280,
    height: 720,
    badge: '720p',
  },
  '480p': {
    label: '480p SD',
    sublabel: '854 × 480 · Compact File Size',
    width: 854,
    height: 480,
    badge: '480p',
  },
};

export type FpsPreset = 60 | 30 | 24;
export type BitratePreset = 24 | 16 | 8 | 4; // in Mbps
export type AudioSourceType = 'mic_and_system' | 'mic_only' | 'system_only' | 'none';

export interface RecorderSettings {
  resolution: ResolutionPreset;
  fps: FpsPreset;
  bitrate: BitratePreset;
  audioSource: AudioSourceType;
  micGain: number; // 0.5 to 2.0
  countdownSeconds: 0 | 3 | 5 | 10;
  audioBeep: boolean;
  showFacecam: boolean;
  facecamShape: 'circle' | 'squircle' | 'rect';
  facecamSize: 'sm' | 'md' | 'lg';
  facecamMirrored: boolean;
  exportFormat: 'mp4' | 'webm';
  includeWatermark: boolean;
  watermarkText: string;
  floatingBallEnabled: boolean;
  deviceFrameMode: boolean; // phone preview frame vs expanded
}

export interface RecordingItem {
  id: string;
  title: string;
  blob: Blob;
  mimeType: string;
  extension: 'mp4' | 'webm';
  duration: number; // seconds
  size: number; // bytes
  resolutionBadge: string;
  width: number;
  height: number;
  fps: number;
  bitrateMbps: number;
  hasAudio: boolean;
  createdAt: number;
  thumbnail: string; // base64 data URL
}

export type RecorderStatus = 'idle' | 'countdown' | 'recording' | 'paused' | 'processing';

export type NavigationTab = 'record' | 'gallery' | 'tools' | 'settings';
