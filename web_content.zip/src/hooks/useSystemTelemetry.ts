import { useState, useEffect, useRef } from 'react';
import { SystemTelemetry, ProcessItem } from '../types/os';

export function useSystemTelemetry(processes: ProcessItem[]) {
  const historyLength = 60;

  // Initialize history buffers
  const [telemetry, setTelemetry] = useState<SystemTelemetry>(() => {
    const initHistory = (val: number) => Array(historyLength).fill(val);
    return {
      cpuUsage: 14.2,
      cpuFreqGhz: 3.84,
      cpuCores: [12, 18, 14, 22, 9, 15, 11, 13],
      memoryUsedGb: 12.8,
      memoryTotalGb: 32.0,
      memoryCommittedGb: 15.4,
      diskActivePct: 3.2,
      diskReadKbps: 420,
      diskWriteKbps: 180,
      networkSendKbps: 45,
      networkRecvKbps: 120,
      gpuUsagePct: 8.5,
      gpuMemoryGb: 2.1,
      gpuTempC: 44,
      uptimeSec: 3600 * 14 + 120, // 14 hours running
      history: {
        cpu: initHistory(14),
        memory: initHistory(40),
        disk: initHistory(4),
        network: initHistory(8),
        gpu: initHistory(10),
      },
    };
  });

  const processesRef = useRef(processes);
  processesRef.current = processes;

  useEffect(() => {
    const timer = setInterval(() => {
      setTelemetry((prev) => {
        const currentProcesses = processesRef.current;
        // Calculate total process CPU and Memory sum
        const procCpuSum = currentProcesses.reduce((acc, p) => acc + (p.cpu || 0), 0);
        const procMemSumMb = currentProcesses.reduce((acc, p) => acc + (p.memoryMb || 0), 0);

        // Fluctuation factor
        const jitter = (Math.random() - 0.48) * 3;
        const targetCpu = Math.max(3, Math.min(99, Number((procCpuSum + 8 + jitter).toFixed(1))));

        // Memory calculations
        const baseSystemMemGb = 11.2;
        const targetMemGb = Math.min(31.5, Number((baseSystemMemGb + procMemSumMb / 1024).toFixed(1)));
        const memPercent = Math.round((targetMemGb / 32.0) * 100);

        // 8 Cores simulation centered on targetCpu
        const cores = Array.from({ length: 8 }, (_, i) => {
          const coreJitter = (Math.random() - 0.5) * 16;
          return Math.max(1, Math.min(100, Math.round(targetCpu + (i % 2 === 0 ? 4 : -3) + coreJitter)));
        });

        // Disk activity
        const diskJitter = Math.random() > 0.75 ? Math.random() * 25 : Math.random() * 6;
        const diskActive = Math.min(100, Number(diskJitter.toFixed(1)));

        // Network throughput
        const netSend = Math.round(20 + Math.random() * 90);
        const netRecv = Math.round(60 + Math.random() * 280);

        // GPU load
        const gpuLoad = Math.max(2, Math.min(95, Math.round(6 + (targetCpu * 0.25) + (Math.random() * 5))));

        return {
          cpuUsage: targetCpu,
          cpuFreqGhz: Number((3.6 + (targetCpu / 100) * 0.75).toFixed(2)),
          cpuCores: cores,
          memoryUsedGb: targetMemGb,
          memoryTotalGb: 32.0,
          memoryCommittedGb: Number((targetMemGb * 1.25).toFixed(1)),
          diskActivePct: diskActive,
          diskReadKbps: Math.round(diskActive * 120 + 50),
          diskWriteKbps: Math.round(diskActive * 80 + 30),
          networkSendKbps: netSend,
          networkRecvKbps: netRecv,
          gpuUsagePct: gpuLoad,
          gpuMemoryGb: Number((1.8 + (gpuLoad / 100) * 1.6).toFixed(1)),
          gpuTempC: Math.round(42 + (gpuLoad / 100) * 18),
          uptimeSec: prev.uptimeSec + 1,
          history: {
            cpu: [...prev.history.cpu.slice(1), targetCpu],
            memory: [...prev.history.memory.slice(1), memPercent],
            disk: [...prev.history.disk.slice(1), diskActive],
            network: [...prev.history.network.slice(1), Math.min(100, Math.round((netRecv + netSend) / 8))],
            gpu: [...prev.history.gpu.slice(1), gpuLoad],
          },
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return telemetry;
}
