import { useState, useCallback } from 'react';
import { AppId, WindowState, ProcessItem, ProcessPriority } from '../types/os';
import { INITIAL_PROCESSES } from '../data/defaultProcesses';

const APP_META: Record<AppId, { title: string; icon: string; defaultSize: { width: number; height: number }; defaultPos: { x: number; y: number } }> = {
  taskmgr: {
    title: 'Task Manager',
    icon: 'Activity',
    defaultSize: { width: 920, height: 600 },
    defaultPos: { x: 120, y: 70 },
  },
  terminal: {
    title: 'Command Prompt (Administrator)',
    icon: 'Terminal',
    defaultSize: { width: 780, height: 480 },
    defaultPos: { x: 160, y: 120 },
  },
  notepad: {
    title: 'Notepad - Untitled',
    icon: 'FileText',
    defaultSize: { width: 680, height: 460 },
    defaultPos: { x: 220, y: 100 },
  },
  calc: {
    title: 'Calculator',
    icon: 'Calculator',
    defaultSize: { width: 340, height: 490 },
    defaultPos: { x: 280, y: 140 },
  },
  explorer: {
    title: 'File Explorer',
    icon: 'Folder',
    defaultSize: { width: 840, height: 520 },
    defaultPos: { x: 180, y: 80 },
  },
  browser: {
    title: 'Microsoft Edge',
    icon: 'Globe',
    defaultSize: { width: 960, height: 620 },
    defaultPos: { x: 140, y: 60 },
  },
  launcher: {
    title: 'PC Application Launcher Station',
    icon: 'Grid',
    defaultSize: { width: 940, height: 610 },
    defaultPos: { x: 100, y: 50 },
  },
  settings: {
    title: 'Settings',
    icon: 'Settings',
    defaultSize: { width: 820, height: 540 },
    defaultPos: { x: 200, y: 90 },
  },
};

export function useWindowManager() {
  const [windows, setWindows] = useState<WindowState[]>(() => [
    {
      id: 'win-taskmgr-1',
      appId: 'taskmgr',
      title: 'Task Manager',
      icon: 'Activity',
      isMinimized: false,
      isMaximized: false,
      zIndex: 10,
      position: { x: 140, y: 60 },
      size: { width: 940, height: 620 },
    },
  ]);

  const [activeWindowId, setActiveWindowId] = useState<string | null>('win-taskmgr-1');
  const [highestZIndex, setHighestZIndex] = useState(11);

  // Processes state (synchronized with windows)
  const [processes, setProcesses] = useState<ProcessItem[]>(() => {
    return INITIAL_PROCESSES.map((proc) => {
      if (proc.appId === 'taskmgr') {
        return { ...proc, windowId: 'win-taskmgr-1' };
      }
      return proc;
    });
  });

  const focusWindow = useCallback((windowId: string) => {
    setActiveWindowId(windowId);
    setHighestZIndex((prev) => {
      const nextZ = prev + 1;
      setWindows((wins) =>
        wins.map((w) => (w.id === windowId ? { ...w, zIndex: nextZ, isMinimized: false } : w))
      );
      return nextZ;
    });
  }, []);

  const openApp = useCallback((appId: AppId, customData?: any) => {
    // Check if window already open
    const existing = windows.find((w) => w.appId === appId);
    if (existing) {
      if (existing.isMinimized) {
        setWindows((wins) =>
          wins.map((w) => (w.id === existing.id ? { ...w, isMinimized: false } : w))
        );
      }
      if (customData) {
        setWindows((wins) =>
          wins.map((w) => (w.id === existing.id ? { ...w, customData } : w))
        );
      }
      focusWindow(existing.id);
      return existing.id;
    }

    const meta = APP_META[appId];
    const newWindowId = `win-${appId}-${Date.now()}`;
    const nextZ = highestZIndex + 1;
    setHighestZIndex(nextZ);

    // Stagger position slightly based on open windows count
    const offset = (windows.length % 5) * 24;
    const pos = {
      x: Math.min(window.innerWidth - meta.defaultSize.width - 20, Math.max(20, meta.defaultPos.x + offset)),
      y: Math.min(window.innerHeight - meta.defaultSize.height - 60, Math.max(20, meta.defaultPos.y + offset)),
    };

    const newWindow: WindowState = {
      id: newWindowId,
      appId,
      title: customData?.title || meta.title,
      icon: meta.icon,
      isMinimized: false,
      isMaximized: false,
      zIndex: nextZ,
      position: pos,
      size: { ...meta.defaultSize },
      customData,
    };

    setWindows((wins) => [...wins, newWindow]);
    setActiveWindowId(newWindowId);

    // Register process in Task Manager
    const newPid = Math.floor(10000 + Math.random() * 89999);
    const procName = appId === 'taskmgr' ? 'Taskmgr.exe' :
                     appId === 'terminal' ? 'cmd.exe' :
                     appId === 'notepad' ? 'notepad.exe' :
                     appId === 'calc' ? 'calc.exe' :
                     appId === 'explorer' ? 'explorer.exe' :
                     appId === 'browser' ? 'msedge.exe' :
                     appId === 'launcher' ? 'LauncherStation.exe' : 'SystemSettings.exe';

    const newProc: ProcessItem = {
      pid: newPid,
      name: procName,
      category: 'apps',
      appId,
      windowId: newWindowId,
      cpu: Number((Math.random() * 2.5 + 0.5).toFixed(1)),
      memoryMb: Math.round(50 + Math.random() * 120),
      diskMbS: 0.0,
      networkMbps: 0.0,
      gpuPct: Number((Math.random() * 1.5).toFixed(1)),
      powerUsage: 'Low',
      status: 'Running',
      publisher: 'Microsoft Windows',
      priority: 'Normal',
      commandLine: `C:\\Windows\\System32\\${procName}`,
      startTime: new Date().toLocaleTimeString('en-US', { hour12: false }),
    };

    setProcesses((procs) => {
      // replace or append
      const filtered = procs.filter((p) => p.windowId !== newWindowId);
      return [newProc, ...filtered];
    });

    return newWindowId;
  }, [windows, highestZIndex, focusWindow]);

  const closeWindow = useCallback((windowId: string) => {
    setWindows((wins) => {
      const remaining = wins.filter((w) => w.id !== windowId);
      if (activeWindowId === windowId) {
        const nextActive = remaining.length > 0 ? remaining[remaining.length - 1].id : null;
        setActiveWindowId(nextActive);
      }
      return remaining;
    });

    // Remove or terminate associated process
    setProcesses((procs) => procs.filter((p) => p.windowId !== windowId));
  }, [activeWindowId]);

  const minimizeWindow = useCallback((windowId: string) => {
    setWindows((wins) =>
      wins.map((w) => (w.id === windowId ? { ...w, isMinimized: true } : w))
    );
    if (activeWindowId === windowId) {
      setActiveWindowId(null);
    }
  }, [activeWindowId]);

  const toggleMaximize = useCallback((windowId: string) => {
    setWindows((wins) =>
      wins.map((w) => (w.id === windowId ? { ...w, isMaximized: !w.isMaximized } : w))
    );
    focusWindow(windowId);
  }, [focusWindow]);

  const updateWindowPosition = useCallback((windowId: string, position: { x: number; y: number }) => {
    setWindows((wins) =>
      wins.map((w) => (w.id === windowId ? { ...w, position, isMaximized: false } : w))
    );
  }, []);

  const updateWindowSize = useCallback((windowId: string, size: { width: number; height: number }, position?: { x: number; y: number }) => {
    setWindows((wins) =>
      wins.map((w) =>
        w.id === windowId
          ? { ...w, size, position: position ? position : w.position, isMaximized: false }
          : w
      )
    );
  }, []);

  // End task action from Task Manager
  const endProcess = useCallback((pid: number) => {
    const target = processes.find((p) => p.pid === pid);
    if (!target) return;

    if (target.windowId) {
      // Close the actual window!
      closeWindow(target.windowId);
    } else {
      // Just remove the background/windows process
      setProcesses((procs) => procs.filter((p) => p.pid !== pid));
    }
  }, [processes, closeWindow]);

  // Set process priority
  const setProcessPriority = useCallback((pid: number, priority: ProcessPriority) => {
    setProcesses((procs) =>
      procs.map((p) => (p.pid === pid ? { ...p, priority } : p))
    );
  }, []);

  // Toggle Efficiency mode
  const toggleProcessEfficiency = useCallback((pid: number) => {
    setProcesses((procs) =>
      procs.map((p) => {
        if (p.pid === pid) {
          const nextStatus = p.status === 'Efficiency Mode' ? 'Running' : 'Efficiency Mode';
          return {
            ...p,
            status: nextStatus,
            priority: nextStatus === 'Efficiency Mode' ? 'Low' : 'Normal',
            cpu: nextStatus === 'Efficiency Mode' ? Math.max(0.1, Number((p.cpu * 0.4).toFixed(1))) : Number((p.cpu * 1.5).toFixed(1)),
          };
        }
        return p;
      })
    );
  }, []);

  // Run new task command
  const runNewTask = useCallback((command: string) => {
    const cmd = command.trim().toLowerCase();
    if (cmd === 'taskmgr' || cmd === 'taskmgr.exe') {
      openApp('taskmgr');
    } else if (cmd === 'cmd' || cmd === 'cmd.exe' || cmd === 'powershell') {
      openApp('terminal');
    } else if (cmd === 'calc' || cmd === 'calc.exe') {
      openApp('calc');
    } else if (cmd === 'notepad' || cmd === 'notepad.exe') {
      openApp('notepad');
    } else if (cmd === 'explorer' || cmd === 'explorer.exe') {
      openApp('explorer');
    } else if (cmd === 'chrome' || cmd === 'msedge' || cmd.startsWith('http://') || cmd.startsWith('https://')) {
      openApp('browser', { initialUrl: cmd.startsWith('http') ? cmd : undefined });
    } else if (cmd.includes('launcher') || cmd.includes('apps')) {
      openApp('launcher');
    } else if (cmd.includes('settings') || cmd === 'ms-settings:') {
      openApp('settings');
    } else {
      // Launch custom task into process list!
      const newPid = Math.floor(10000 + Math.random() * 89999);
      const newProc: ProcessItem = {
        pid: newPid,
        name: command.includes('.') ? command : `${command}.exe`,
        category: 'apps',
        cpu: Number((Math.random() * 2 + 0.2).toFixed(1)),
        memoryMb: Math.round(40 + Math.random() * 80),
        diskMbS: 0.1,
        networkMbps: 0.0,
        gpuPct: 0.0,
        powerUsage: 'Low',
        status: 'Running',
        publisher: 'User Command',
        priority: 'Normal',
        commandLine: command,
        startTime: new Date().toLocaleTimeString('en-US', { hour12: false }),
      };
      setProcesses((prev) => [newProc, ...prev]);
    }
  }, [openApp]);

  return {
    windows,
    activeWindowId,
    processes,
    openApp,
    closeWindow,
    minimizeWindow,
    toggleMaximize,
    focusWindow,
    updateWindowPosition,
    updateWindowSize,
    endProcess,
    setProcessPriority,
    toggleProcessEfficiency,
    runNewTask,
  };
}
