import { useState, useRef, useEffect, useCallback } from 'react';
import {
  RecorderSettings,
  RecorderStatus,
  RecordingItem,
  RESOLUTION_PRESETS,
} from '../types/recorder';
import { getBestSupportedMimeType, generateThumbnail } from '../utils/mediaExport';
import { playCountdownPing, playRecordStartChime, playStopAlert } from '../utils/audioBeep';
import { saveRecording } from '../utils/storage';

interface UseScreenRecorderProps {
  settings: RecorderSettings;
  onRecordingComplete: (item: RecordingItem) => void;
}

export function useScreenRecorder({ settings, onRecordingComplete }: UseScreenRecorderProps) {
  const [status, setStatus] = useState<RecorderStatus>('idle');
  const [countdownValue, setCountdownValue] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [micVolumeLevel, setMicVolumeLevel] = useState<number>(0);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [lastScreenshot, setLastScreenshot] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const monitorVideoRef = useRef<HTMLVideoElement | null>(null);

  // Clean up streams & audio nodes
  const cleanupStreams = useCallback(() => {
    if (screenStream) {
      screenStream.getTracks().forEach((track) => track.stop());
      setScreenStream(null);
    }
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    setMicVolumeLevel(0);
  }, [screenStream, cameraStream]);

  // Audio level meter ticker
  const startAudioMeter = (stream: MediaStream) => {
    try {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const actx = new AudioContextClass();
      audioContextRef.current = actx;
      const source = actx.createMediaStreamSource(stream);
      const analyser = actx.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateMeter = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setMicVolumeLevel(Math.min(100, Math.round((avg / 255) * 100 * 1.5)));
        animationFrameRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();
    } catch (e) {
      console.debug('Audio meter initialization note:', e);
    }
  };

  // Toggle Camera Facecam independently
  const toggleFacecam = async () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((t) => t.stop());
      setCameraStream(null);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
        audio: false,
      });
      setCameraStream(stream);
    } catch (err) {
      console.warn('Facecam camera access declined or unavailable:', err);
    }
  };

  // Start the entire screen recording workflow
  const startRecordingFlow = async () => {
    setErrorMessage(null);

    // 1. Check browser getDisplayMedia support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      setErrorMessage('Screen recording is not supported in this browser environment.');
      return;
    }

    try {
      const res = RESOLUTION_PRESETS[settings.resolution];

      // Request screen stream
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: { ideal: res.width },
          height: { ideal: res.height },
          frameRate: { ideal: settings.fps },
          displaySurface: 'monitor',
        },
        audio: settings.audioSource === 'mic_and_system' || settings.audioSource === 'system_only',
      });

      setScreenStream(displayStream);

      // Handle user ending screen share from native browser stop bar
      displayStream.getVideoTracks()[0].onended = () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
          stopRecording();
        }
      };

      // Optional mic audio stream
      let micStream: MediaStream | null = null;
      if (settings.audioSource === 'mic_and_system' || settings.audioSource === 'mic_only') {
        try {
          micStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          });
          startAudioMeter(micStream);
        } catch (micErr) {
          console.warn('Microphone permission denied, continuing without mic:', micErr);
        }
      }

      // Mix audio tracks if both system audio and mic are available
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      const audioDest = audioCtx.createMediaStreamDestination();
      let hasAudioTrack = false;

      // Connect system audio
      const sysAudioTracks = displayStream.getAudioTracks();
      if (sysAudioTracks.length > 0) {
        const sysSource = audioCtx.createMediaStreamSource(new MediaStream([sysAudioTracks[0]]));
        sysSource.connect(audioDest);
        hasAudioTrack = true;
      }

      // Connect mic audio with custom gain
      if (micStream && micStream.getAudioTracks().length > 0) {
        const micSource = audioCtx.createMediaStreamSource(micStream);
        const gainNode = audioCtx.createGain();
        gainNode.gain.value = settings.micGain;
        micSource.connect(gainNode);
        gainNode.connect(audioDest);
        hasAudioTrack = true;
      }

      // Compose final recording tracks
      const finalTracks: MediaStreamTrack[] = [...displayStream.getVideoTracks()];
      if (hasAudioTrack && audioDest.stream.getAudioTracks().length > 0) {
        finalTracks.push(audioDest.stream.getAudioTracks()[0]);
      }

      const compositeStream = new MediaStream(finalTracks);

      // Determine best MIME type & bitrate
      const { mimeType, extension } = getBestSupportedMimeType(settings.exportFormat);
      const bitrateBps = settings.bitrate * 1000000;

      const mediaRecorder = new MediaRecorder(compositeStream, {
        mimeType,
        videoBitsPerSecond: bitrateBps,
      });

      mediaRecorderRef.current = mediaRecorder;
      recordedChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setStatus('processing');
        if (settings.audioBeep) playStopAlert();

        const videoBlob = new Blob(recordedChunksRef.current, { type: mimeType });

        // Generate thumbnail using monitor element or canvas
        let thumbnail = '';
        if (monitorVideoRef.current) {
          thumbnail = generateThumbnail(monitorVideoRef.current);
        }

        const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const title = `Screen_${res.badge}_${dateStr}.${extension}`;

        const newRecording: RecordingItem = {
          id: `rec_${Date.now()}`,
          title,
          blob: videoBlob,
          mimeType,
          extension,
          duration: elapsedTime || 1,
          size: videoBlob.size,
          resolutionBadge: res.badge,
          width: res.width,
          height: res.height,
          fps: settings.fps,
          bitrateMbps: settings.bitrate,
          hasAudio: hasAudioTrack,
          createdAt: Date.now(),
          thumbnail,
        };

        await saveRecording(newRecording);
        onRecordingComplete(newRecording);

        cleanupStreams();
        setStatus('idle');
        setElapsedTime(0);
      };

      // Handle Countdown if configured
      if (settings.countdownSeconds > 0) {
        setStatus('countdown');
        let remaining = settings.countdownSeconds;
        setCountdownValue(remaining);
        if (settings.audioBeep) playCountdownPing(remaining);

        const countdownInterval = setInterval(() => {
          remaining -= 1;
          if (remaining > 0) {
            setCountdownValue(remaining);
            if (settings.audioBeep) playCountdownPing(remaining);
          } else {
            clearInterval(countdownInterval);
            setCountdownValue(0);
            if (settings.audioBeep) playRecordStartChime();
            mediaRecorder.start(1000);
            setStatus('recording');
            setElapsedTime(0);
            timerIntervalRef.current = window.setInterval(() => {
              setElapsedTime((prev) => prev + 1);
            }, 1000);
          }
        }, 1000);
      } else {
        if (settings.audioBeep) playRecordStartChime();
        mediaRecorder.start(1000);
        setStatus('recording');
        setElapsedTime(0);
        timerIntervalRef.current = window.setInterval(() => {
          setElapsedTime((prev) => prev + 1);
        }, 1000);
      }
    } catch (err: unknown) {
      console.error('Error starting screen recording:', err);
      cleanupStreams();
      setStatus('idle');
      if ((err as Error)?.name === 'NotAllowedError') {
        setErrorMessage('Screen recording permission was cancelled or not granted.');
      } else {
        setErrorMessage((err as Error)?.message || 'Failed to start screen recording.');
      }
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setStatus('paused');
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setStatus('recording');
      timerIntervalRef.current = window.setInterval(() => {
        setElapsedTime((prev) => prev + 1);
      }, 1000);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };

  // Instant snapshot of screen frame
  const takeScreenshot = () => {
    if (!monitorVideoRef.current) return;
    try {
      const snap = generateThumbnail(monitorVideoRef.current);
      if (snap) {
        setLastScreenshot(snap);
        // Automatically save snapshot image file
        const a = document.createElement('a');
        a.href = snap;
        a.download = `ScreenShot_${Date.now()}.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (e) {
      console.warn('Screenshot capture note:', e);
    }
  };

  // Attach screen stream to monitor video element
  useEffect(() => {
    if (monitorVideoRef.current && screenStream) {
      monitorVideoRef.current.srcObject = screenStream;
    }
  }, [screenStream]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      cleanupStreams();
    };
  }, [cleanupStreams]);

  return {
    status,
    countdownValue,
    elapsedTime,
    micVolumeLevel,
    screenStream,
    cameraStream,
    monitorVideoRef,
    lastScreenshot,
    errorMessage,
    startRecordingFlow,
    pauseRecording,
    resumeRecording,
    stopRecording,
    takeScreenshot,
    toggleFacecam,
    setErrorMessage,
  };
}
