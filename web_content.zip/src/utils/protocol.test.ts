/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  serializeCommand,
  parseResponseLine,
  validateCommandPayload,
  calculateCpuSummary,
  generateServerPy,
  generateDockerSetup,
  generateSystemdUnit,
  generateOpenSslCommand,
  generateClientCode,
  DEFAULT_SERVER_CONFIG,
} from './protocol.ts';

test('serializeCommand appends newline and formats JSON', () => {
  const result = serializeCommand({ cmd: 'GET_CPU' });
  assert.equal(result, '{"cmd":"GET_CPU"}\n');

  const withParam = serializeCommand({ cmd: 'OPEN_APP', target: 'notepad.exe' });
  assert.equal(withParam, '{"cmd":"OPEN_APP","target":"notepad.exe"}\n');
});

test('parseResponseLine parses valid JSON and strips surrounding whitespace', () => {
  const parsed = parseResponseLine('{"total": 14.5, "per_core": [12.0, 16.0]}\n');
  assert.equal(parsed.success, true);
  assert.equal(parsed.data.total, 14.5);
  assert.deepEqual(parsed.data.per_core, [12.0, 16.0]);
});

test('parseResponseLine reports protocol errors from server', () => {
  const parsed = parseResponseLine('{"error": "target \'malicious.sh\' is not in allowed whitelist"}');
  assert.equal(parsed.success, false);
  assert.equal(parsed.error, "target 'malicious.sh' is not in allowed whitelist");
});

test('parseResponseLine handles empty or invalid JSON frames safely', () => {
  const empty = parseResponseLine('');
  assert.equal(empty.success, false);
  assert.match(empty.error || '', /Empty response frame/);

  const invalid = parseResponseLine('NOT_JSON_DATA');
  assert.equal(invalid.success, false);
  assert.match(invalid.error || '', /Invalid JSON protocol payload/);
});

test('validateCommandPayload validates command targets and parameters', () => {
  // Empty command name
  const emptyCmd = validateCommandPayload('');
  assert.equal(emptyCmd.valid, false);

  // OPEN_APP without target
  const badOpen = validateCommandPayload('OPEN_APP', {});
  assert.equal(badOpen.valid, false);
  assert.match(badOpen.reason || '', /target/);

  // OPEN_APP with valid target
  const goodOpen = validateCommandPayload('OPEN_APP', { target: 'notepad.exe' });
  assert.equal(goodOpen.valid, true);

  // COPY without text
  const badCopy = validateCommandPayload('COPY', {});
  assert.equal(badCopy.valid, false);
  assert.match(badCopy.reason || '', /text/);

  // COPY with valid text
  const goodCopy = validateCommandPayload('COPY', { text: 'Hello' });
  assert.equal(goodCopy.valid, true);

  // GET_CPU and PASTE require no parameters
  assert.equal(validateCommandPayload('GET_CPU').valid, true);
  assert.equal(validateCommandPayload('PASTE').valid, true);
});

test('calculateCpuSummary categorizes load and finds highest core usage', () => {
  const idle = calculateCpuSummary(12.5, [10.0, 15.0]);
  assert.equal(idle.loadCategory, 'idle');
  assert.equal(idle.highestCoreIndex, 1);
  assert.equal(idle.highestCoreLoad, 15.0);
  assert.equal(idle.averageCoreLoad, 12.5);

  const high = calculateCpuSummary(65, [50, 82, 45, 60]);
  assert.equal(high.loadCategory, 'high');
  assert.equal(high.highestCoreIndex, 1);
  assert.equal(high.highestCoreLoad, 82);

  const critical = calculateCpuSummary(92, [90, 95, 93, 90]);
  assert.equal(critical.loadCategory, 'critical');

  // Bounds clipping check (e.g. invalid negative or >100 values)
  const clipped = calculateCpuSummary(-5, [120, -10]);
  assert.equal(clipped.safeTotal, 0);
  assert.deepEqual(clipped.validCores, [100, 0]);
});

test('generateServerPy produces valid python script with configured port and security', () => {
  const pyCode = generateServerPy({
    ...DEFAULT_SERVER_CONFIG,
    port: 9000,
    allowAppWhitelist: true,
    allowedApps: ['notepad.exe', 'calc.exe'],
    requireMtls: true,
  });

  assert.match(pyCode, /PORT = 9000/);
  assert.match(pyCode, /ALLOWED_APPS = \[/);
  assert.match(pyCode, /"notepad.exe",/);
  assert.match(pyCode, /"calc.exe",/);
  assert.match(pyCode, /ctx\.verify_mode = ssl\.CERT_REQUIRED/);
  assert.match(pyCode, /subprocess\.Popen/);
});

test('generateDockerSetup and systemd unit produce valid configurations', () => {
  const docker = generateDockerSetup({ ...DEFAULT_SERVER_CONFIG, port: 8888 });
  assert.match(docker.dockerfile, /EXPOSE 8888/);
  assert.match(docker.composeYaml, /"8888:8888"/);
  assert.match(docker.runCommand, /-p 8888:8888/);

  const systemd = generateSystemdUnit(DEFAULT_SERVER_CONFIG, 'admin');
  assert.match(systemd, /User=admin/);
  assert.match(systemd, /ExecStart=\/usr\/bin\/python3 \/home\/admin\/ltwn\/server\.py/);

  const openssl = generateOpenSslCommand('my-pc.lan', 'mycerts');
  assert.match(openssl, /-subj "\/CN=my-pc\.lan"/);
  assert.match(openssl, /mkdir -p "mycerts"/);
});

test('generateClientCode generates code for all target languages', () => {
  const python = generateClientCode('python', '192.168.1.100', 8765);
  assert.match(python, /192\.168\.1\.100/);
  assert.match(python, /8765/);
  assert.match(python, /GET_CPU/);

  const kotlin = generateClientCode('kotlin', '192.168.1.100', 8765);
  assert.match(kotlin, /SSLSocket/);
  assert.match(kotlin, /trustAllCerts/);

  const swift = generateClientCode('swift', '192.168.1.100', 8765);
  assert.match(swift, /NWConnection/);

  const curl = generateClientCode('curl', '192.168.1.100', 8765);
  assert.match(curl, /openssl s_client -connect 192\.168\.1\.100:8765/);

  const nodejs = generateClientCode('nodejs', '192.168.1.100', 8765);
  assert.match(nodejs, /tls\.connect/);
});
