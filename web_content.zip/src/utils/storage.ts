import { RecordingItem } from '../types/recorder';

const DB_NAME = 'StitchScreenRecorderDB';
const DB_VERSION = 1;
const STORE_NAME = 'recordings';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllRecordings(): Promise<RecordingItem[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const index = store.index('createdAt');
      const request = index.getAll();

      request.onsuccess = () => {
        // Return descending by createdAt
        const list = (request.result as RecordingItem[]) || [];
        list.sort((a, b) => b.createdAt - a.createdAt);
        resolve(list);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('Failed to load recordings from IndexedDB:', err);
    return [];
  }
}

export async function saveRecording(item: RecordingItem): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(item);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function deleteRecording(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function updateRecordingTitle(id: string, newTitle: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const getRequest = store.get(id);

    getRequest.onsuccess = () => {
      const item = getRequest.result as RecordingItem | undefined;
      if (item) {
        item.title = newTitle;
        const putRequest = store.put(item);
        putRequest.onsuccess = () => resolve();
        putRequest.onerror = () => reject(putRequest.error);
      } else {
        resolve();
      }
    };
    getRequest.onerror = () => reject(getRequest.error);
  });
}

// Generate a lightweight animated sample demo clip (creates a real MP4/WebM video via Canvas + MediaRecorder)
export async function seedSampleIfEmpty(): Promise<RecordingItem[]> {
  const existing = await getAllRecordings();
  if (existing.length > 0) {
    return existing;
  }

  try {
    const sampleItem = await generateSampleRecording();
    await saveRecording(sampleItem);
    return [sampleItem];
  } catch (err) {
    console.warn('Could not generate sample video blob automatically:', err);
    return [];
  }
}

async function generateSampleRecording(): Promise<RecordingItem> {
  const canvas = document.createElement('canvas');
  canvas.width = 1280;
  canvas.height = 720;
  const ctx = canvas.getContext('2d')!;

  const stream = canvas.captureStream(30);
  
  let mimeType = 'video/webm;codecs=vp9';
  let extension: 'mp4' | 'webm' = 'webm';
  if (MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')) {
    mimeType = 'video/mp4;codecs=avc1';
    extension = 'mp4';
  } else if (MediaRecorder.isTypeSupported('video/mp4')) {
    mimeType = 'video/mp4';
    extension = 'mp4';
  } else if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/webm';
  }

  const mediaRecorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 6000000,
  });

  const chunks: Blob[] = [];
  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };

  return new Promise((resolve) => {
    mediaRecorder.onstop = () => {
      const finalBlob = new Blob(chunks, { type: mimeType });
      const thumbnail = canvas.toDataURL('image/jpeg', 0.85);

      const sample: RecordingItem = {
        id: `rec_${Date.now()}_demo`,
        title: 'Android Fullscreen Gameplay HD.mp4',
        blob: finalBlob,
        mimeType,
        extension,
        duration: 4,
        size: finalBlob.size || 1420000,
        resolutionBadge: '1080p HD',
        width: 1280,
        height: 720,
        fps: 30,
        bitrateMbps: 16,
        hasAudio: true,
        createdAt: Date.now() - 3600000 * 2,
        thumbnail,
      };
      resolve(sample);
    };

    mediaRecorder.start();

    // Render an aesthetic Google Stitch mobile simulation for 4 seconds
    let frame = 0;
    const interval = setInterval(() => {
      frame++;
      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(0.5, '#1E293B');
      grad.addColorStop(1, '#0B1120');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Grid lines
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }

      // Animated glowing wave
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 3;
      ctx.beginPath();
      for (let x = 0; x < canvas.width; x += 5) {
        const y = canvas.height / 2 + Math.sin(x * 0.01 + frame * 0.1) * 60;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Material Stitch phone card
      ctx.fillStyle = 'rgba(30, 41, 59, 0.85)';
      ctx.roundRect?.(canvas.width / 2 - 200, 140, 400, 440, 24);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.stroke();

      // Text
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 28px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Stitch HD Screen Recorder', canvas.width / 2, 230);

      ctx.fillStyle = '#94A3B8';
      ctx.font = '16px sans-serif';
      ctx.fillText('Crystal Clear 1080p MP4 Recording', canvas.width / 2, 270);

      // Play Store badge simulation
      ctx.fillStyle = '#22C55E';
      ctx.beginPath();
      ctx.arc(canvas.width / 2 - 90, 360, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#F8FAFC';
      ctx.font = '600 15px sans-serif';
      ctx.fillText(`60 FPS High Definition · Ready`, canvas.width / 2 + 10, 365);

      if (frame >= 30 * 4) {
        clearInterval(interval);
        mediaRecorder.stop();
      }
    }, 1000 / 30);
  });
}
