/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CommandType = 'GET_CPU' | 'OPEN_APP' | 'COPY' | 'PASTE' | 'SYS_INFO' | 'LOCK_PC' | 'PING';

export interface CommandDefinition {
  cmd: CommandType;
  label: string;
  description: string;
  requiresParam?: string;
  defaultPayload: Record<string, any>;
}

export const SUPPORTED_COMMANDS: CommandDefinition[] = [
  {
    cmd: 'GET_CPU',
    label: 'Query CPU Telemetry',
    description: 'Fetches instantaneous total and per-core CPU usage plus frequency limits via psutil.',
    defaultPayload: { cmd: 'GET_CPU' },
  },
  {
    cmd: 'OPEN_APP',
    label: 'Launch Application',
    description: 'Launches target process on host PC using subprocess.Popen without shell interpolation.',
    requiresParam: 'target',
    defaultPayload: { cmd: 'OPEN_APP', target: 'notepad.exe' },
  },
  {
    cmd: 'COPY',
    label: 'Push to Clipboard',
    description: 'Transfers text from mobile/client into the host PC operating system clipboard via pyperclip.',
    requiresParam: 'text',
    defaultPayload: { cmd: 'COPY', text: 'Hello from Link-to-Windows++' },
  },
  {
    cmd: 'PASTE',
    label: 'Read PC Clipboard',
    description: 'Retrieves current contents of the host PC operating system clipboard into the client.',
    defaultPayload: { cmd: 'PASTE' },
  },
];

export interface CpuTelemetry {
  total: number;
  per_core: number[];
  max_mhz?: number | null;
  min_mhz?: number | null;
  timestamp?: number;
}

export interface ServerConfig {
  host: string;
  port: number;
  certDir: string;
  certFile: string;
  keyFile: string;
  requireMtls: boolean;
  clientCaFile: string;
  allowAppWhitelist: boolean;
  allowedApps: string[];
  cpuSampleInterval: number;
}

export const DEFAULT_SERVER_CONFIG: ServerConfig = {
  host: '0.0.0.0',
  port: 8765,
  certDir: 'certs',
  certFile: 'server.crt',
  keyFile: 'server.key',
  requireMtls: false,
  clientCaFile: 'client_ca.crt',
  allowAppWhitelist: true,
  allowedApps: ['notepad.exe', 'calc.exe', 'code', 'cmd.exe', 'powershell.exe', 'spotify.exe', 'explorer.exe'],
  cpuSampleInterval: 0.3,
};

/**
 * Validates command payload before dispatch.
 */
export function validateCommandPayload(cmd: string, params: Record<string, any> = {}): { valid: boolean; reason?: string } {
  if (!cmd || typeof cmd !== 'string' || !cmd.trim()) {
    return { valid: false, reason: 'Command name is missing or empty' };
  }

  const normalized = cmd.trim().toUpperCase();

  if (normalized === 'OPEN_APP') {
    const target = params.target || params.cmd_target;
    if (!target || typeof target !== 'string' || !target.trim()) {
      return { valid: false, reason: 'OPEN_APP command requires a non-empty "target" executable name or path' };
    }
  }

  if (normalized === 'COPY') {
    if (params.text === undefined || params.text === null || typeof params.text !== 'string') {
      return { valid: false, reason: 'COPY command requires a "text" string property' };
    }
  }

  return { valid: true };
}

/**
 * Serializes command object into standard JSON line protocol ending with '\n'
 */
export function serializeCommand(payload: Record<string, any>): string {
  const jsonStr = JSON.stringify(payload);
  return jsonStr.endsWith('\n') ? jsonStr : jsonStr + '\n';
}

/**
 * Parses raw JSON protocol response string (tolerates extra whitespace/newline).
 */
export function parseResponseLine<T = any>(raw: string): { success: boolean; data?: T; error?: string } {
  const trimmed = (raw || '').trim();
  if (!trimmed) {
    return { success: false, error: 'Empty response frame received' };
  }

  try {
    const parsed = JSON.parse(trimmed);
    if (parsed.error) {
      return { success: false, data: parsed, error: parsed.error };
    }
    return { success: true, data: parsed };
  } catch (err: any) {
    return { success: false, error: `Invalid JSON protocol payload: ${err.message}` };
  }
}

/**
 * Calculates CPU load category and summary statistics from telemetry
 */
export function calculateCpuSummary(total: number, perCore: number[] = []) {
  const safeTotal = Math.max(0, Math.min(100, Number(total) || 0));
  const validCores = (Array.isArray(perCore) ? perCore : []).map(v => Math.max(0, Math.min(100, Number(v) || 0)));

  let highestCoreIndex = 0;
  let highestCoreLoad = 0;

  validCores.forEach((load, idx) => {
    if (load > highestCoreLoad) {
      highestCoreLoad = load;
      highestCoreIndex = idx;
    }
  });

  const averageCoreLoad = validCores.length > 0
    ? validCores.reduce((acc, curr) => acc + curr, 0) / validCores.length
    : safeTotal;

  let loadCategory: 'idle' | 'moderate' | 'high' | 'critical' = 'idle';
  if (safeTotal >= 85 || highestCoreLoad >= 95) {
    loadCategory = 'critical';
  } else if (safeTotal >= 60 || highestCoreLoad >= 80) {
    loadCategory = 'high';
  } else if (safeTotal >= 25) {
    loadCategory = 'moderate';
  }

  return {
    safeTotal,
    validCores,
    coreCount: validCores.length,
    highestCoreIndex,
    highestCoreLoad,
    averageCoreLoad: Math.round(averageCoreLoad * 10) / 10,
    loadCategory,
  };
}

/**
 * Generates the complete, production-ready Python server.py source code based on configuration.
 */
export function generateServerPy(config: ServerConfig = DEFAULT_SERVER_CONFIG): string {
  const whitelistList = config.allowedApps.map(app => `    "${app}",`).join('\n');
  const whitelistCheck = config.allowAppWhitelist
    ? `
        # Whitelist enforcement
        base_target = os.path.basename(target).lower()
        allowed_normalized = [a.lower() for a in ALLOWED_APPS]
        if base_target not in allowed_normalized and target.lower() not in allowed_normalized:
            log.warning(f"Blocked unapproved app launch: {target}")
            resp["error"] = f"target '{target}' is not in allowed whitelist"
            return resp
`
    : ``;

  const mtlsConfig = config.requireMtls
    ? `
    # Mutual TLS (mTLS) enforcement: require and verify client certificate
    ca_path = cert_dir / "${config.clientCaFile}"
    if ca_path.is_file():
        ctx.load_verify_locations(cafile=str(ca_path))
        ctx.verify_mode = ssl.CERT_REQUIRED
        log.info(f"mTLS active: requiring verified client certificates signed by {ca_path}")
    else:
        log.error(f"Client CA certificate not found at {ca_path}! mTLS cannot be enforced.")
`
    : ``;

  return `#!/usr/bin/env python3
"""
Production-Ready "Link-to-Windows++" Server
A privacy-first, locally-only TCP/TLS bridge that lets a phone (or any client)
control your PC, launch apps, query CPU telemetry, and sync the clipboard
without sending any data to third-party clouds.

Generated by Link-to-Windows++ Companion Suite
"""
import asyncio
import ssl
import subprocess
import sys
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any

try:
    import psutil
except ImportError:
    sys.exit("Error: psutil is required. Run 'pip install psutil'")

try:
    import pyperclip
except ImportError:
    sys.exit("Error: pyperclip is required. Run 'pip install pyperclip'")

# ----------------------------------------------------------------------
# 0️⃣ Logging configuration
# ----------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("ltwn")

# ----------------------------------------------------------------------
# Configuration & Security Settings
# ----------------------------------------------------------------------
HOST = "${config.host}"
PORT = ${config.port}
CERT_DIR_NAME = "${config.certDir}"
CERT_FILE_NAME = "${config.certFile}"
KEY_FILE_NAME = "${config.keyFile}"
CPU_SAMPLE_INTERVAL = ${config.cpuSampleInterval}

# Whitelist of approved applications (prevents arbitrary command execution)
ALLOWED_APPS = [
${whitelistList}
]

# ----------------------------------------------------------------------
# 1️⃣ Certificate handling
# ----------------------------------------------------------------------
def ensure_cert(cert_path: Path, key_path: Path) -> None:
    """Create a self-signed cert if neither file exists; otherwise, validate."""
    if cert_path.is_file() and key_path.is_file():
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
            log.info(f"Using existing cert from {cert_path}")
            return
        except Exception as e:
            log.warning(f"Existing cert invalid ({e}); regenerating new self-signed pair.")

    cert_path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", str(key_path),
            "-out", str(cert_path),
            "-days", "365",
            "-nodes",
            "-subj", "/CN=localhost"
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    log.info(f"Generated new self-signed cert at {cert_path} & key at {key_path}")

# ----------------------------------------------------------------------
# 2️⃣ Core command dispatcher
# ----------------------------------------------------------------------
def execute_command(cmd: Dict[str, Any]) -> Dict[str, Any]:
    resp: Dict[str, Any] = {}
    cmd_name = cmd.get("cmd")

    if cmd_name == "OPEN_APP":
        target = cmd.get("target", "")
        if not target:
            resp["error"] = "missing target"
            return resp
${whitelistCheck}
        try:
            # subprocess.Popen without shell=True mitigates command injection attacks
            subprocess.Popen([target] if not os.path.isabs(target) else [target])
            resp["status"] = "launched"
            resp["target"] = target
        except Exception as e:
            resp["error"] = f"launch failed: {e}"

    elif cmd_name == "GET_CPU":
        try:
            percpu = psutil.cpu_percent(percpu=True, interval=CPU_SAMPLE_INTERVAL)
            total = psutil.cpu_percent(percpu=False, interval=None)
            freq = psutil.cpu_freq()
            resp.update({
                "status": "ok",
                "total": total,
                "per_core": percpu,
                "max_mhz": freq.max if freq else None,
                "min_mhz": freq.min if freq else None,
            })
        except Exception as e:
            resp["error"] = f"cpu query failed: {e}"

    elif cmd_name == "COPY":
        text = cmd.get("text", "")
        try:
            pyperclip.copy(text)
            resp["status"] = "copied"
            resp["text_len"] = len(text)
        except Exception as e:
            resp["error"] = f"clipboard copy failed: {e}"

    elif cmd_name == "PASTE":
        try:
            txt = pyperclip.paste()
            resp["status"] = "paste_ok"
            resp["text"] = txt
        except Exception as e:
            resp["error"] = f"clipboard read failed: {e}"

    elif cmd_name == "PING":
        resp["status"] = "pong"
        resp["service"] = "Link-to-Windows++"

    else:
        resp["error"] = f"unknown command: {cmd_name}"

    return resp

# ----------------------------------------------------------------------
# 3️⃣ Network Client Handler
# ----------------------------------------------------------------------
async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    peer = writer.get_extra_info("peername")
    log.info(f"New TLS connection from {peer}")
    try:
        raw = await reader.readline()
        if not raw:
            log.debug("Client disconnected without payload.")
            return

        try:
            cmd = json.loads(raw.decode().strip())
        except json.JSONDecodeError as exc:
            log.error(f"Malformed JSON from {peer}: {exc}")
            writer.write(json.dumps({"error": "invalid JSON"}).encode() + b"\\n")
            await writer.drain()
            return

        # Execute command & return response line
        resp = execute_command(cmd)
        writer.write(json.dumps(resp).encode() + b"\\n")
        await writer.drain()
        log.info(f"Handled {cmd.get('cmd')} for {peer} -> status: {resp.get('status', resp.get('error'))}")
    except (asyncio.IncompleteReadError, ConnectionResetError, OSError) as e:
        log.warning(f"Connection error with {peer}: {e}")
    finally:
        writer.close()
        await writer.wait_closed()
        log.debug(f"Connection closed with {peer}")

# ----------------------------------------------------------------------
# 4️⃣ Server Bootstrap
# ----------------------------------------------------------------------
def main():
    base = Path(__file__).parent.resolve()
    cert_dir = base / CERT_DIR_NAME
    cert_path = cert_dir / CERT_FILE_NAME
    key_path = cert_dir / KEY_FILE_NAME

    ensure_cert(cert_path, key_path)

    # Harden TLS Context: Enforce TLS 1.2+
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
${mtlsConfig}
    async def run_server():
        server = await asyncio.start_server(
            handle_client,
            host=HOST,
            port=PORT,
            ssl=ctx
        )
        addrs = ", ".join(str(sock.getsockname()) for sock in server.sockets)
        log.info(f"🔒 Link-to-Windows++ server listening on {HOST}:{PORT} ({addrs})")
        log.info(f"   Certificate: {cert_path}")
        async with server:
            await server.serve_forever()

    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        log.info("Server stopped by user.")

if __name__ == "__main__":
    main()
`;
}

/**
 * Generates Dockerfile and docker-compose.yml configuration
 */
export function generateDockerSetup(config: ServerConfig = DEFAULT_SERVER_CONFIG) {
  const dockerfile = `FROM python:3.12-slim

# Install system dependencies + Python libraries
RUN apt-get update && apt-get install -y --no-install-recommends \\
    openssl xclip \\
    && rm -rf /var/lib/apt/lists/* \\
    && pip install --no-cache-dir psutil pyperclip

WORKDIR /app
COPY server.py .

# TLS listener port
EXPOSE ${config.port}

# Run Link-to-Windows++
CMD ["python", "server.py"]
`;

  const composeYaml = `version: "3.8"

services:
  ltwn:
    build: .
    container_name: link-to-windows-pp
    restart: unless-stopped
    ports:
      - "${config.port}:${config.port}"
    volumes:
      - ./certs:/app/certs
    # Optional resource limits for defense in depth
    deploy:
      resources:
        limits:
          cpus: "0.50"
          memory: 256M
`;

  const runCommand = `docker build -t ltwn . && docker run -d --name ltwn -p ${config.port}:${config.port} -v "$(pwd)/certs:/app/certs" ltwn`;

  return { dockerfile, composeYaml, runCommand };
}

/**
 * Generates Linux systemd service definition
 */
export function generateSystemdUnit(config: ServerConfig = DEFAULT_SERVER_CONFIG, username = 'user'): string {
  return `[Unit]
Description=Link-to-Windows++ Local TLS Bridge
After=network.target

[Service]
Type=simple
User=${username}
WorkingDirectory=/home/${username}/ltwn
ExecStart=/usr/bin/python3 /home/${username}/ltwn/server.py
Restart=on-failure
RestartSec=5s
Environment=PYTHONUNBUFFERED=1

# Hardening
ProtectSystem=full
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
`;
}

/**
 * Generates OpenSSL self-signed certificate bash command
 */
export function generateOpenSslCommand(domainOrIp: string = 'localhost', certDir: string = 'certs'): string {
  return `mkdir -p "${certDir}" && openssl req -x509 -newkey rsa:2048 \\
  -keyout "${certDir}/server.key" \\
  -out "${certDir}/server.crt" \\
  -days 365 -nodes \\
  -subj "/CN=${domainOrIp}"`;
}

/**
 * Generates client SDK implementation code in various programming languages
 */
export function generateClientCode(language: 'python' | 'kotlin' | 'swift' | 'curl' | 'nodejs', host: string = '127.0.0.1', port: number = 8765): string {
  switch (language) {
    case 'python':
      return `import asyncio
import json
import ssl
from pathlib import Path

# Create TLS Client context
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE  # For self-signed cert on LAN

async def send_command(cmd_dict: dict):
    reader, writer = await asyncio.open_connection("${host}", ${port}, ssl=ctx)
    payload = json.dumps(cmd_dict).encode("utf-8") + b"\\n"
    writer.write(payload)
    await writer.drain()

    raw_response = await reader.readline()
    writer.close()
    await writer.wait_closed()
    return json.loads(raw_response.decode("utf-8"))

async def main():
    # 1. Fetch CPU metrics
    cpu = await send_command({"cmd": "GET_CPU"})
    print("CPU Telemetry:", cpu)

    # 2. Push text to PC clipboard
    copied = await send_command({"cmd": "COPY", "text": "Copied from Phone!"})
    print("Copy Status:", copied)

    # 3. Read current PC clipboard
    pasted = await send_command({"cmd": "PASTE"})
    print("PC Clipboard:", pasted.get("text"))

if __name__ == "__main__":
    asyncio.run(main())
`;

    case 'kotlin':
      return `// Android Kotlin client using OkHttp SSLSocket
package com.example.ltwn

import okhttp3.*
import okio.ByteString.Companion.encodeUtf8
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.*

class LtwnClient(private val host: String = "${host}", private val port: Int = ${port}) {

    // Trust manager configured for self-signed LAN certificates
    private val trustAllCerts = arrayOf<TrustManager>(
        object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
    )

    fun sendCommand(jsonCommand: JSONObject): String {
        val sslContext = SSLContext.getInstance("TLS").apply {
            init(null, trustAllCerts, SecureRandom())
        }

        val socket = sslContext.socketFactory.createSocket(host, port) as SSLSocket
        socket.startHandshake()

        val output = socket.outputStream
        val input = socket.inputStream.bufferedReader()

        // Send JSON command followed by newline \\n
        output.write((jsonCommand.toString() + "\\n").toByteArray())
        output.flush()

        // Read single JSON response line
        val responseLine = input.readLine()
        socket.close()
        return responseLine ?: "{}"
    }
}
`;

    case 'swift':
      return `// iOS Swift client using Network framework NWConnection (TLS)
import Foundation
import Network

class LtwnConnection {
    let host: NWEndpoint.Host = "${host}"
    let port: NWEndpoint.Port = ${port}
    private var connection: NWConnection?

    func execute(command: [String: Any], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        let tlsOptions = NWProtocolTLS.Options()
        // Allow self-signed certificates for local PC development
        sec_protocol_options_set_verify_block(tlsOptions.securityProtocolOptions, { (_, _, sec_protocol_verify_complete) in
            sec_protocol_verify_complete(true)
        }, DispatchQueue.main)

        let parameters = NWParameters(tls: tlsOptions)
        connection = NWConnection(host: host, port: port, using: parameters)

        connection?.stateUpdateHandler = { state in
            if case .ready = state {
                guard let data = try? JSONSerialization.data(withJSONObject: command),
                      var payload = String(data: data, encoding: .utf8) else { return }
                payload.append("\\n")

                self.connection?.send(content: payload.data(using: .utf8), completion: .contentProcessed({ sendError in
                    if let err = sendError { completion(.failure(err)); return }
                    self.connection?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, _, recvError in
                        if let err = recvError { completion(.failure(err)); return }
                        if let data = data, let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                            completion(.success(dict))
                        }
                    }
                }))
            }
        }
        connection?.start(queue: .main)
    }
}
`;

    case 'curl':
      return `# Using openssl s_client (raw TLS socket query)
# 1. Fetch CPU telemetry
echo '{"cmd":"GET_CPU"}' | openssl s_client -connect ${host}:${port} -quiet 2>/dev/null

# 2. Launch Notepad on PC
echo '{"cmd":"OPEN_APP","target":"notepad.exe"}' | openssl s_client -connect ${host}:${port} -quiet 2>/dev/null

# 3. Push text to PC clipboard
echo '{"cmd":"COPY","text":"Synced from mobile shell"}' | openssl s_client -connect ${host}:${port} -quiet 2>/dev/null

# 4. Read PC clipboard
echo '{"cmd":"PASTE"}' | openssl s_client -connect ${host}:${port} -quiet 2>/dev/null
`;

    case 'nodejs':
      return `// Node.js TLS socket client
import tls from 'node:tls';
import readline from 'node:readline';

function queryBridge(cmdObj) {
  return new Promise((resolve, reject) => {
    const socket = tls.connect({
      host: '${host}',
      port: ${port},
      rejectUnauthorized: false // LAN self-signed certificate
    }, () => {
      socket.write(JSON.stringify(cmdObj) + '\\n');
    });

    const rl = readline.createInterface({ input: socket });
    rl.on('line', (line) => {
      socket.end();
      try {
        resolve(JSON.parse(line));
      } catch (e) {
        reject(e);
      }
    });

    socket.on('error', reject);
  });
}

// Example usage:
const cpu = await queryBridge({ cmd: 'GET_CPU' });
console.log('CPU:', cpu);
`;
  }
}
