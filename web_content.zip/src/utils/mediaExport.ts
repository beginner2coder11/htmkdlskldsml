import { RecordingItem } from '../types/recorder';

export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const formattedMins = String(mins).padStart(2, '0');
  const formattedSecs = String(secs).padStart(2, '0');

  if (hrs > 0) {
    const formattedHrs = String(hrs).padStart(2, '0');
    return `${formattedHrs}:${formattedMins}:${formattedSecs}`;
  }
  return `${formattedMins}:${formattedSecs}`;
}

export function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

export function getBestSupportedMimeType(preferred: 'mp4' | 'webm'): { mimeType: string; extension: 'mp4' | 'webm' } {
  const mp4Types = [
    'video/mp4;codecs=avc1.4d401f,mp4a.40.2',
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4;codecs=h264,aac',
    'video/mp4',
  ];

  const webmTypes = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm;codecs=h264,opus',
    'video/webm',
  ];

  if (preferred === 'mp4') {
    for (const t of mp4Types) {
      if (MediaRecorder.isTypeSupported(t)) {
        return { mimeType: t, extension: 'mp4' };
      }
    }
  }

  // Check webm
  for (const t of webmTypes) {
    if (MediaRecorder.isTypeSupported(t)) {
      return { mimeType: t, extension: 'webm' };
    }
  }

  // Fallback
  return { mimeType: 'video/webm', extension: 'webm' };
}

export async function downloadRecording(
  item: RecordingItem,
  requestedFormat?: 'mp4' | 'webm'
): Promise<void> {
  const targetFormat = requestedFormat || item.extension || 'mp4';
  let filename = item.title;

  // Ensure extension matches
  if (!filename.toLowerCase().endsWith(`.${targetFormat}`)) {
    filename = filename.replace(/\.(mp4|webm|mov)$/i, '') + `.${targetFormat}`;
  }

  // If user requests mp4 and the blob is webm or vice-versa, repackage with target mime
  let exportBlob = item.blob;
  if (targetFormat === 'mp4' && !item.blob.type.includes('mp4')) {
    exportBlob = new Blob([item.blob], { type: 'video/mp4' });
  } else if (targetFormat === 'webm' && !item.blob.type.includes('webm')) {
    exportBlob = new Blob([item.blob], { type: 'video/webm' });
  }

  // Check if browser supports modern File System Access API (showSaveFilePicker)
  const windowWithPicker = window as unknown as {
    showSaveFilePicker?: (options: {
      suggestedName: string;
      types: Array<{ description: string; accept: Record<string, string[]> }>;
    }) => Promise<{ createWritable: () => Promise<WritableStream> }>;
  };

  if (typeof windowWithPicker.showSaveFilePicker === 'function') {
    try {
      const mime = targetFormat === 'mp4' ? 'video/mp4' : 'video/webm';
      const fileHandle = await windowWithPicker.showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: targetFormat === 'mp4' ? 'MP4 High Definition Video' : 'WebM High Definition Video',
            accept: {
              [mime]: [`.${targetFormat}`],
            },
          },
        ],
      });
      const writable = await fileHandle.createWritable();
      await exportBlob.stream().pipeTo(writable);
      return;
    } catch (err: unknown) {
      if ((err as Error)?.name === 'AbortError') {
        return; // User canceled picker
      }
      console.warn('File picker fallback triggered:', err);
    }
  }

  // Standard high-reliability download fallback
  const url = URL.createObjectURL(exportBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 15000);
}

export function generateThumbnail(videoElement: HTMLVideoElement): string {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 360;
    const ctx = canvas.getContext('2d');
    if (ctx && videoElement.videoWidth) {
      ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', 0.82);
    }
  } catch (err) {
    console.debug('Failed to generate video thumbnail:', err);
  }
  return '';
}

/**
 * Real client-side Video Trimmer: takes a video blob, cuts between startTime and endTime,
 * renders frames onto canvas, and re-encodes a high-definition clipped MP4/WebM.
 */
export async function trimVideoSegment(
  sourceBlob: Blob,
  startTime: number,
  endTime: number,
  onProgress?: (pct: number) => void
): Promise<{ blob: Blob; mimeType: string; extension: 'mp4' | 'webm' }> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.src = URL.createObjectURL(sourceBlob);
    video.muted = false;
    video.playsInline = true;

    video.onloadedmetadata = async () => {
      const targetDuration = endTime - startTime;
      if (targetDuration <= 0) {
        reject(new Error('Invalid trim range'));
        return;
      }

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d')!;

      // Capture canvas stream at 30fps
      const canvasStream = canvas.captureStream(30);

      // Try capturing audio from video
      let combinedStream = canvasStream;
      try {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const actx = new AudioContextClass();
        const sourceNode = actx.createMediaElementSource(video);
        const destNode = actx.createMediaStreamDestination();
        sourceNode.connect(destNode);
        sourceNode.connect(actx.destination); // to hear or route
        combinedStream = new MediaStream([
          ...canvasStream.getVideoTracks(),
          ...destNode.stream.getAudioTracks(),
        ]);
      } catch (e) {
        console.debug('Audio routing in trimmer note:', e);
      }

      const { mimeType, extension } = getBestSupportedMimeType('mp4');
      const recorder = new MediaRecorder(combinedStream, {
        mimeType,
        videoBitsPerSecond: 12000000,
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      recorder.onstop = () => {
        const trimmedBlob = new Blob(chunks, { type: mimeType });
        URL.revokeObjectURL(video.src);
        resolve({ blob: trimmedBlob, mimeType, extension });
      };

      video.currentTime = startTime;

      video.onseeked = () => {
        recorder.start(100);
        video.play();

        const renderInterval = setInterval(() => {
          if (video.currentTime >= endTime || video.ended) {
            clearInterval(renderInterval);
            video.pause();
            recorder.stop();
            return;
          }

          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const progress = Math.min(100, Math.round(((video.currentTime - startTime) / targetDuration) * 100));
          if (onProgress) onProgress(progress);
        }, 1000 / 30);
      };
    };

    video.onerror = () => reject(new Error('Error decoding video for trimming'));
  });
}

/**
 * Audio Extractor: Extract audio channel from video blob and save as WAV audio file
 */
export async function extractAudioFromVideo(videoBlob: Blob): Promise<{ blob: Blob; filename: string }> {
  const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AudioContextClass();
  const arrayBuffer = await videoBlob.arrayBuffer();
  const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);

  // Encode to 16-bit PCM WAV
  const wavBlob = audioBufferToWav(audioBuffer);
  return {
    blob: wavBlob,
    filename: `audio_extracted_${Date.now()}.wav`,
  };
}

function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;

  let result: Float32Array;
  if (numChannels === 2) {
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);
    result = new Float32Array(left.length + right.length);
    for (let i = 0; i < left.length; i++) {
      result[i * 2] = left[i];
      result[i * 2 + 1] = right[i];
    }
  } else {
    result = buffer.getChannelData(0);
  }

  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const bufferLen = 44 + result.length * bytesPerSample;
  const arrayBuffer = new ArrayBuffer(bufferLen);
  const view = new DataView(arrayBuffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + result.length * bytesPerSample, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, result.length * bytesPerSample, true);

  // Write PCM audio samples
  let offset = 44;
  for (let i = 0; i < result.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, result[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }

  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string): void {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}
