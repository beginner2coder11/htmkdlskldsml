/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CommandType, ServerConfig, CpuTelemetry } from './utils/protocol';

export type ActiveTab = 'dashboard' | 'clipboard' | 'protocol' | 'deploy' | 'sdk' | 'security';

export interface PacketLog {
  id: string;
  timestamp: string;
  direction: 'tx' | 'rx';
  raw: string;
  parsed?: any;
  latencyMs?: number;
  byteSize: number;
  isError?: boolean;
}

export interface ClipboardItem {
  id: string;
  timestamp: string;
  direction: 'to_pc' | 'from_pc';
  text: string;
  charCount: number;
}

export interface AppLauncherItem {
  id: string;
  name: string;
  category: 'productivity' | 'system' | 'media';
  executable: string;
  iconName: string;
  description: string;
}

export interface LaunchedAppRecord {
  id: string;
  target: string;
  timestamp: string;
  status: 'launched' | 'blocked' | 'failed';
  message?: string;
}

export type ConnectionMode = 'simulator' | 'direct';
