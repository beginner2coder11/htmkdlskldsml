JAS LAUNDRY ROOM – PERSISTENT GOOGLE DRIVE AUTO SYNC UPDATE

ഈ അപ്ഡേറ്റിൽ ഉൾപ്പെടുത്തിയിരിക്കുന്നത്:
1. Owner ഒരിക്കൽ Google Drive / Google Apps Script Web App URL + Secret Token connect ചെയ്താൽ അത് ഈ ഫോണിലെ app storage-ൽ save ചെയ്യും.
2. Login ചെയ്താൽ Google Drive sync സ്വയം ആരംഭിക്കും; ഓരോ തവണയും Settings-ൽ പോയി Connect അമർത്തേണ്ടതില്ല.
3. എല്ലാ billing / management data-യും ആദ്യം local device-ൽ save ചെയ്യും. Internet ഉണ്ടെങ്കിൽ background-ൽ Cloud-ലേക്ക് upload ചെയ്യും.
4. Internet പോയാൽ local save തുടരും. Network തിരികെ വന്നാൽ pending local changes upload ചെയ്യും.
5. App വീണ്ടും തുറക്കുമ്പോൾ, Android WebView-ൽ app foreground-ലേക്ക് വരുമ്പോൾ, network തിരികെ ലഭിക്കുമ്പോൾ remote changes പരിശോധിക്കും.
6. Online ആയിരിക്കുമ്പോൾ ഏകദേശം 15 സെക്കൻഡിന് ഒരിക്കൽ Google Drive-ൽ നിന്നുള്ള remote updates പരിശോധിക്കും.
7. Sync Now ബട്ടൺ: pending local changes ഉണ്ടെങ്കിൽ upload; ഇല്ലെങ്കിൽ remote changes download.
8. Config app storage-ൽ തുടരും; app data clear ചെയ്യുകയോ uninstall ചെയ്യുകയോ ചെയ്താൽ Android app storage നീക്കം ചെയ്യപ്പെടാം. അതിനാൽ URL/Token സുരക്ഷിതമായി backup ചെയ്യുക.

ആദ്യ setup:
- Owner login ചെയ്യുക.
- Settings → Google Cloud Connection തുറക്കുക.
- Google Apps Script Web App URL, Secret Token നൽകുക.
- Connect Google Cloud അമർത്തുക; ആദ്യത്തെ Cloud/local data തിരഞ്ഞെടുപ്പ് ശ്രദ്ധിച്ച് ചെയ്യുക.
- മറ്റൊരു ഫോണിൽ Login page → Google Cloud Login Setup-ൽ അതേ URL/Token save ചെയ്യുക; തുടർന്ന് അതേ account-ൽ login ചെയ്യുക.

പ്രധാന പരിമിതി:
- ഈ Google Drive connector ഒരു JSON snapshot file ആണ് ഉപയോഗിക്കുന്നത്; ഓരോ 15 സെക്കൻഡിലും polling നടക്കും. ഇത് Firestore പോലുള്ള transactional real-time database അല്ല.
- ഒരേസമയം ഒന്നിലധികം ഫോണുകളിൽ അതേ records edit ചെയ്യുമ്പോൾ last-write-wins / snapshot overwrite സാധ്യതയുണ്ട്. വലിയ multi-user live workload-ന് per-record sync / conflict resolution ഉള്ള backend വേണം.
- Android APK-യിലെ background process OS battery optimization കാരണം പൂർണ്ണമായി നിരന്തരമായി പ്രവർത്തിക്കണമെന്നില്ല. App foreground-ൽ, തുറന്നിരിക്കുമ്പോൾ, network ലഭിക്കുമ്പോൾ sync തുടരും; app പൂർണ്ണമായി അടച്ചിരിക്കുമ്പോൾ Android സ്ഥിരമായി background execution ഉറപ്പുനൽകില്ല.
- യഥാർത്ഥ Google Apps Script URL, token, Google account, Android APK ഉപയോഗിച്ച് live device test ഈ build environment-ൽ നടത്താൻ കഴിയില്ല. ZIP-ൽ JavaScript syntax, archive integrity എന്നിവ പരിശോധിച്ചു.

പഴയ data delete/reset ചെയ്യുന്ന migration ഈ update-ൽ ചേർത്തിട്ടില്ല. Update/install ചെയ്യുന്നതിന് മുമ്പ് Full Backup JSON എടുത്തുവെക്കുക.
