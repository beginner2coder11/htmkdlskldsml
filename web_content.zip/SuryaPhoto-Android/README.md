# सूर्या फोटो (Surya Photo) – Android ऐप

**Developer: SURYAKANT BHARTI**

इस फ़ोल्डर में सूर्या फोटो का पूरा Android प्रोजेक्ट है। इससे APK फ़ाइल बनती है।

## ऐप में क्या है
- 📐 **फोटो रिसाइज़र**: साइज़ पिक्सेल, सेमी/मिमी/इंच, प्रतिशत या KB में बदलें (जैसे 20 KB, 50 KB)
- ✂️ **बैकग्राउंड रिमूवर**: Google ML Kit का AI और ऑटो तरीका, ब्रश से सुधार, सफ़ेद/नीला/लाल या कोई भी रंग
- 🪪 **सभी साइज़**: पासपोर्ट (35×45 मिमी), स्टाम्प, PAN, वीज़ा 2×2 इंच, 3R, 4×6, 5×7, A4 और कस्टम। साथ में नाम व तारीख़ लिखने का विकल्प
- 🖨️ **प्रिंट शीट**: A4 या 4×6 पेपर पर जितनी चाहें उतनी कॉपी, कई लोगों की फोटो एक साथ। सीधे प्रिंट, JPG या PDF सेव
- सेव की गई फ़ाइलें: फोटो **Pictures/SuryaPhoto** में और PDF **Download/SuryaPhoto** में

---

## APK कैसे बनाएँ: तरीका 1, GitHub से (मुफ़्त, कुछ इंस्टॉल नहीं करना)

कंप्यूटर या लैपटॉप के ब्राउज़र से करना आसान रहेगा।

1. **github.com** पर मुफ़्त अकाउंट बनाएँ और लॉग-इन करें।
2. ऊपर दाईं ओर **+ → New repository** दबाएँ।
   - नाम: `SuryaPhoto`
   - **Private** चुनें (ताकि आपकी साइनिंग-की सुरक्षित रहे)
   - **Create repository** दबाएँ।
3. नए पेज पर **"uploading an existing file"** लिंक दबाएँ।
4. यह ZIP खोलें (Extract करें)। `SuryaPhoto-Android` फ़ोल्डर के **अंदर की सारी चीज़ें** (`app`, `.github`, `build.gradle`, `settings.gradle`, `gradle.properties` …) खींचकर (drag) उस पेज पर छोड़ दें। फिर **Commit changes** दबाएँ।
5. ऊपर **Actions** टैब खोलें। **"Build Surya Photo APK"** अपने आप चलने लगेगा। इसमें 5 से 10 मिनट लगते हैं।
   - अगर Actions में कुछ न दिखे, तो `.github` फ़ोल्डर अपलोड नहीं हुआ होगा। तब ये करें: **Actions → set up a workflow yourself** दबाएँ, नाम `build-apk.yml` रखें, इस ZIP की `.github/workflows/build-apk.yml` फ़ाइल का पूरा मैटर चिपकाएँ और **Commit** दबाएँ।
6. हरा ✅ निशान आने पर उस रन पर क्लिक करें। नीचे **Artifacts** में **SuryaPhoto-APK** डाउनलोड करें। उस ZIP के अंदर **SuryaPhoto.apk** मिलेगी।

## APK कैसे बनाएँ: तरीका 2, Android Studio से
1. Android Studio में **File → Open** से यह फ़ोल्डर खोलें।
2. **Build → Generate App Bundles or APKs → Build APK(s)** दबाएँ।

## फ़ोन में इंस्टॉल करना
APK फ़ोन में भेजें और उसे खोलें। फ़ोन पूछे तो **"अनजान ऐप इंस्टॉल करने की अनुमति" (Install unknown apps)** दें।

## ज़रूरी बात: साइनिंग-की
`app/suryaphoto.keystore` आपके ऐप की "चाबी" है (पासवर्ड: `SuryaPhoto@2026`)। ऐप का अगला वर्ज़न इसी चाबी से बनेगा, तभी पुराना ऐप अपडेट होगा। इसलिए इस फ़ाइल की एक कॉपी सुरक्षित रखें और repository को **Private** रखें।
Play Store पर डालना हो तो नई चाबी और नया पासवर्ड बनवा लें।

## ऐप का नया वर्ज़न बनाना
- `app/src/main/assets/index.html` बदलें।
- `app/build.gradle` में `versionCode` को 1 बढ़ाएँ और `versionName` बदलें।
- GitHub पर फ़ाइलें फिर से अपलोड करें। APK अपने आप दोबारा बन जाएगी।
