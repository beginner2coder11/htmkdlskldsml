KOMPRES & SCAN — PROYEK ANDROID

Ini adalah proyek Android WebView yang membungkus aplikasi web lokal.
Cara membangun:
1. Ekstrak ZIP.
2. Buka folder KompresScan-Android di Android Studio.
3. Tunggu Gradle sync dan unduh komponen SDK yang diminta.
4. Pilih Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

PENTING:
- ZIP proyek tidak sama dengan APK yang sudah dikompilasi.
- Dibutuhkan Android Studio, Android SDK, JDK, dan koneksi internet awal untuk mengunduh dependensi.
- Proyek ini membungkus prototipe; bukan klaim bahwa seluruh fitur lanjutan telah selesai.
- Untuk instalasi PWA, file HTML biasa saja tidak otomatis menjadi APK.


FILE TAMBAHAN
- template-transaksi.csv: template pencatatan kompresi, dapat dibuka di Excel/Google Sheets.

PENANDA TANGAN APK
- File keystore (.jks) disediakan terpisah. Jangan masukkan ke repositori publik atau kirim ke orang lain.
- Simpan salinan keystore dan kata sandinya di tempat aman. Jika keystore hilang, update APK dengan identitas tanda tangan yang sama bisa terhambat.
- Untuk APK Android, build dan signing perlu diuji di Android Studio/Gradle; proyek ini belum diverifikasi menghasilkan APK final pada sesi ini.
