# ZERO AI v25 — ProGuard Rules
# (minifyEnabled = false today, so these rules are informational only —
#  but kept correct so they work immediately if minification is ever
#  turned on for a release build; a stale package name here would let
#  R8 obfuscate ZeroBridge's method names and silently break every
#  window.ZeroAndroid.* call from index.html.)

# Keep all WebView JavaScript interfaces
-keepclassmembers class com.zero.v25.ZeroBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep JS interface annotation
-keepattributes JavascriptInterface

# Keep all annotations
-keepattributes *Annotation*

# Keep source file names for crash reporting
-keepattributes SourceFile,LineNumberTable

# Keep our app classes
-keep class com.zero.v25.** { *; }
