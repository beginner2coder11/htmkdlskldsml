﻿/* ZERO — app.js: الملف الوحيد والمصدر الفعلي الوحيد لكل الواجهة والمحرك —
   يحقن head/CSS/بنية الشاشة في DOM ثم يشغّل محرك المعالجة كاملاً (18 قسماً
   حسب الوظيفة، بفاصل تعليق باسم كل قسم بينها). index.html (سطران فقط) لا
   يحمّل شيئاً غير هذا الملف. يُعدَّل مباشرة وحرفياً — لا سكربت بناء، لا مصدر
   مقسّم، لا أداة تجميع خاصة، في أي مكان من المشروع (بطلب المستخدم الصريح
   29 سبتمبر 2026: "حذف build.py" ثم "حذف الوساطة من كل المشروع").
   الحالة القابلة لإعادة التعيين الكاملة (57 حقلاً) مُجمَّعة في appState
   (قسم 00) — تُقرأ/تُكتَب مباشرة كـ appState.NAME من أي قسم آخر أو من
   onclick= حرفية داخل HTML، بلا أي جسر/طبقة وسيطة تُزامِن نسختين منها. */
(function(){
  document.head.insertAdjacentHTML('beforeend', "<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\">\n<meta name=\"theme-color\" content=\"#0c0c0c\">\n<!-- \u062a\u0633\u0645\u064a\u0629 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 (\"\u062d\u0648\u0651\u0644 \u0643\u0644 html \u0625\u0644\u0649 \u0635\u064a\u063a\u0629 \u0623\u062e\u0631\u0649 \u0648\u063a\u064a\u0651\u0631 \u0627\u0644\u0627\u0633\u0645\"): \u0627\u0633\u0645 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0638\u0627\u0647\u0631\n (title/manifest/apple-web-app-title \u0647\u0646\u0627 + android:label \u0648 app_name \u0641\u064a \u0645\u0634\u0631\u0648\u0639 \u0623\u0646\u062f\u0631\u0648\u064a\u062f)\n \u0623\u0635\u0628\u062d \"ZERO\" \u0628\u062f\u0644 \"ZERO AI v25\" \u2014 \u062a\u0628\u0633\u064a\u0637 \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0638\u0627\u0647\u0631 \u0644\u0644\u0645\u0633\u062a\u062e\u062f\u0645/\u0627\u0644\u0646\u0638\u0627\u0645 \u0641\u0642\u0637\u061b \u0627\u0644\u0646\u0635\u0648\u0635 \u0627\u0644\u062f\u0627\u062e\u0644\u064a\u0629\n \u0627\u0644\u062a\u0648\u0635\u064a\u0641\u064a\u0629 (\u0634\u0627\u0634\u0629 \"\u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\"\u060c \u0631\u0633\u0627\u0626\u0644 EXEC/\u0627\u0644\u0637\u0631\u0641\u064a\u0629...) \u0644\u0645 \u062a\u064f\u0645\u064e\u0633\u0651 \u0644\u0623\u0646\u0647\u0627 \u0645\u062d\u062a\u0648\u0649 \u0648\u0635\u0641\u064a \u0644\u0627 \u0627\u0633\u0645. -->\n<title>ZERO \u2014 Neural Intelligence</title>\n<link rel=\"manifest\" href=\"data:application/json,{%22name%22:%22ZERO%22,%22short_name%22:%22ZERO%22,%22start_url%22:%22.%22,%22display%22:%22standalone%22,%22background_color%22:%22%230c0c0c%22,%22theme_color%22:%22%23828282%22}\">\n<meta name=\"mobile-web-app-capable\" content=\"yes\">\n<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black-translucent\">\n<meta name=\"apple-mobile-web-app-title\" content=\"ZERO\">\n<!-- \u0645\u0631\u0627\u062c\u0639\u0629 \"\u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0628\u0627\u0644\u0643\u0627\u0645\u0644\": network_security_config.xml \u0644\u0644\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0623\u0635\u0644\u064a \u064a\u0635\u0631\u0650\u0651\u062d \u0635\u0631\u0627\u062d\u0629\u064b\n \"\u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0645\u062d\u0644\u064a 100% \u2014 \u0644\u0627 \u0627\u062a\u0635\u0627\u0644\u0627\u062a \u0625\u0646\u062a\u0631\u0646\u062a \u0645\u0633\u0645\u0648\u062d\u0629\" \u2014 \u0644\u0643\u0646 \u0627\u0644\u0645\u0644\u0641 \u0643\u0627\u0646 \u064a\u062d\u0645\u0644 \u0647\u0630\u0647 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062b\u0644\u0627\u062b\u0629\n \u0644\u062e\u0637\u0648\u0637 Google Fonts \u0639\u0628\u0631 HTTPS (\u063a\u064a\u0631 \u0645\u062d\u0638\u0648\u0631\u0629 \u0628\u0648\u0627\u0633\u0637\u0629 cleartextTrafficPermitted=false\u060c \u0627\u0644\u0630\u064a\n \u064a\u0645\u0646\u0639 http:// \u0641\u0642\u0637 \u0644\u0627 https://)\u060c \u0641\u064a\u064f\u0631\u0633\u0650\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0641\u0639\u0644\u064a\u0627\u064b \u0637\u0644\u0628 \u0634\u0628\u0643\u0629 \u062d\u0642\u064a\u0642\u064a\u0627\u064b \u0644\u062e\u0627\u062f\u0648\u0645 \u062e\u0627\u0631\u062c\u064a \u0641\u064a \u0643\u0644\n \u062a\u0634\u063a\u064a\u0644 \u2014 \u064a\u0646\u0627\u0642\u0636 \u062a\u0635\u0645\u064a\u0645\u0647 \u0627\u0644\u0645\u064f\u0639\u0644\u064e\u0646 (\u0648\u062a\u0639\u0644\u064a\u0642\u0627\u062a \u0627\u0644\u0643\u0648\u062f \u0646\u0641\u0633\u0647\u0627) \u0628\u0623\u0646\u0647 \u0644\u0627 \u064a\u062a\u0635\u0644 \u0628\u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0625\u0637\u0644\u0627\u0642\u0627\u064b\u060c \u0648\u0639\u0644\u0649\n \u062c\u0647\u0627\u0632 \u0628\u0644\u0627 \u0627\u062a\u0635\u0627\u0644 \u0641\u0639\u0644\u064a \u064a\u0641\u0634\u0644 \u0627\u0644\u0637\u0644\u0628 \u0628\u0635\u0645\u062a \u0645\u0636\u064a\u0651\u0639\u0627\u064b \u0648\u0642\u062a\u0627\u064b \u0628\u0644\u0627 \u0623\u064a \u0641\u0627\u0626\u062f\u0629. \u0645\u062a\u063a\u064a\u0631\u0627\u062a CSS (--fo/--fu/--fm)\n \u062a\u062d\u0645\u0644 \u0628\u0627\u0644\u0641\u0639\u0644 \u0633\u0644\u0633\u0644\u0629 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629 \u0643\u0627\u0645\u0644\u0629 (Cairo/JetBrains Mono \u062b\u0645 system-ui/monospace)\u060c \u0641\u062d\u0630\u0641 \u0647\u0630\u0627\n \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0627\u0644\u062e\u0627\u0631\u062c\u064a \u0644\u0627 \u064a\u0643\u0633\u0631 \u0634\u064a\u0626\u0627\u064b \u2014 \u064a\u062c\u0639\u0644 \u0627\u0644\u0633\u0644\u0648\u0643 \u0627\u0644\u0641\u0639\u0644\u064a \u064a\u0637\u0627\u0628\u0642 \u0627\u0644\u062a\u0635\u0645\u064a\u0645 \u0627\u0644\u0645\u064f\u0639\u0644\u064e\u0646 \u0641\u0642\u0637. -->");
  var _s = document.createElement('style');
  _s.textContent = "/* \u2500\u2500 ZERO AI v25 \u2014 Full My Files Storage (PERSIST dual-write) \u2500\u2500 */\n*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}\n:root{--bg:#0c0c0c;--surf:#131313;--card:#1c1c1c;--card2:#252525;--panel-border:rgba(255,255,255,.07);--brd:rgba(255,255,255,.08);--brd2:rgba(255,255,255,.14);--text:#e3e3e3;--dim:#7a7a7a;--muted:rgba(255,255,255,.22);--on:#828282;--off:#767676;--zero:#828282;--ai:#7b7b7b;--sharp:#c3c3c3;--c1:#828282;--c2:#767676;--c3:#949494;--c4:#7d7d7d;--c5:#8c8c8c;--c6:#949494;--c7:#6f6f6f;--c8:#838383;--fan:#767676;--noise:#949494;--evp:#7d7d7d;--emf:#8c8c8c;--fo:''Cairo'',system-ui,-apple-system,sans-serif;--fm:''JetBrains Mono'',''Courier New'',monospace;--fu:''Cairo'',system-ui,-apple-system,sans-serif;--sht:#0f0f0f;--sln:rgba(255,255,255,.04);--radius-sm:8px;--radius-md:12px;--radius-lg:18px;--radius-xl:24px;--shadow-card:0 2px 12px rgba(0,0,0,.45);--shadow-panel:0 -4px 32px rgba(0,0,0,.6);--glow-ai:rgba(123,123,123,.18);--glow-on:rgba(130,130,130,.18)}\nhtml,body{width:100%;height:100%;overflow:hidden;background:var(--bg);font-family:var(--fu);color:var(--text);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;-webkit-tap-highlight-color:transparent;user-select:none;text-rendering:optimizeLegibility;direction:ltr}\n/* \u2500\u2500 HIDE DECORATIVE ELEMENTS \u2500\u2500 */\n.bg-w,.bg-orb,.bg-grid,.lr,.sfr,.arc,.rdot,#orbCv,.cb::before{display:none!important}\n/* \u2500\u2500 ONLY ANIMATION KEPT (used by JS for status dots) \u2500\u2500 */\n/* \u2500\u2500 THERMAL MONITOR \u2500\u2500 */\n.therm-panel{display:flex;flex-direction:column;gap:4px;margin-bottom:10px}\n.therm-row{display:flex;align-items:center;gap:10px;padding:7px 12px;border-radius:10px;background:var(--card);border:1px solid var(--brd)}\n.therm-bar-wrap{flex:2;height:3px;background:rgba(255,255,255,.07);border-radius:3px;overflow:hidden}\n.therm-bar{height:100%;border-radius:2px;transition:width .4s}\n.therm-bar.cold{background:#959595}\n.therm-bar.warm{background:#b0b0b0}\n.therm-bar.hot{background:#7c7c7c}\n.therm-val.cold{color:#959595}\n.therm-val.warm{color:#b0b0b0}\n.therm-val.hot{color:#7c7c7c}\n/* \u2500\u2500 16-CLASS GRID \u2500\u2500 */\n.cls16-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:3px;margin:6px 0}\n/* \u2500\u2500 REDESIGNED BAN UI \u2500\u2500 */\n.ban-panel-header{display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap}\n.ban-heat-legend{display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap}\n.ban-heat-dot{display:flex;align-items:center;gap:3px;font-family:var(--fm);font-size:8px;color:var(--muted)}\n.ban-heat-sq{width:8px;height:8px;border-radius:2px;flex-shrink:0}\n.ban-heat-sq.thermal{background:#7c7c7c}\n.ban-heat-sq.lag{background:#9c9c9c}\n.ban-heat-sq.harmful{background:#686868}\n.ban-heat-sq.noisy{background:#b0b0b0}\n.ban-heat-sq.mic{background:#959595}\n.ban-heat-sq.env{background:#828282}\n.ban-heat-sq.custom{background:#8f8f8f}\n.ban-unified-badge{font-family:var(--fm);font-size:9px;font-weight:700;color:var(--muted);letter-spacing:.02em}\n/* New ban row with thermal indicator */\n.ban-row2{display:flex;align-items:center;gap:5px;padding:5px 8px;border-radius:7px;margin-bottom:3px;border-left:3px solid transparent}\n.ban-row2.thermal{background:rgba(124,124,124,.07);border-color:#7c7c7c}\n.ban-row2.lag{background:rgba(156,156,156,.07);border-color:#9c9c9c}\n.ban-row2.harmful{background:rgba(104,104,104,.07);border-color:#686868}\n.ban-row2.noisy{background:rgba(176,176,176,.07);border-color:#b0b0b0}\n.ban-row2.mic{background:rgba(129,129,129,.07);border-color:#959595}\n.ban-row2.env{background:rgba(130,130,130,.07);border-color:#828282}\n.ban-row2.custom{background:rgba(143,143,143,.06);border-color:#8f8f8f}\n.ban2-heat{font-family:var(--fm);font-size:8px;flex-shrink:0;opacity:.8}\n/* \u2500\u2500 AI SLUGGISH MONITOR \u2500\u2500 */\n.slug-panel{display:flex;flex-direction:column;gap:4px}\n.slug-row{display:flex;justify-content:space-between;align-items:center;padding:4px 8px;border-radius:6px;background:var(--card);border:1px solid var(--brd)}\n/* New ban categories */\n.pban-cat-row.thermal{border-color:rgba(124,124,124,.25)}\n.pban-cat-row.lag{border-color:rgba(156,156,156,.25)}\n/* Spectral entropy */\n.spec-entropy-bar{height:3px;background:rgba(255,255,255,.08);border-radius:2px;overflow:hidden;margin-top:2px}\n.spec-entropy-fill{height:100%;border-radius:2px;background:linear-gradient(90deg,#8f8f8f,#c4c4c4,#7c7c7c);transition:width .4s}\n@keyframes bk{0%,100%{opacity:1}50%{opacity:.3}}\n/* \u2500\u2500 CHROMA VECTOR DISPLAY \u2500\u2500 */\n.chroma-bar{display:flex;gap:2px;margin:4px 0;height:20px}\n.chroma-bin{flex:1;border-radius:2px;background:var(--card);position:relative;overflow:hidden}\n/* \u2500\u2500 RECURRENCE DISPLAY \u2500\u2500 */\n/* \u2500\u2500 VOTE SYSTEM \u2500\u2500 */\n.vote-bar{height:2px;background:var(--card);border-radius:1px;overflow:hidden;margin-top:3px}\n/* \u2500\u2500 REPLAY BUFFER \u2500\u2500 */\n/* \u2500\u2500 TOPBAR \u2500\u2500 */\n.menu-btn{width:42px;height:42px;display:flex;flex-direction:column;justify-content:center;gap:5px;cursor:pointer;padding:6px;border-radius:8px}\n.menu-btn:hover,.menu-btn.open{background:rgba(255,255,255,.06)}\n.menu-btn span:first-child{width:22px}\n.menu-btn span:last-child{width:16px}\n.menu-btn.open span:first-child{width:20px;transform:rotate(45deg) translate(4px,5px)}\n.topbar-r{display:flex;gap:7px}\n/* \u2500\u2500 MAIN CENTER \u2500\u2500 */\n.main{position:relative;z-index:2;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding-bottom:76px;width:100%}\n/* \u2550\u2550 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u2014 \u0623\u0632\u0631\u0627\u0631 \u062a\u0634\u063a\u064a\u0644 \u062a\u0641\u062a\u062d \u0646\u0648\u0627\u0641\u0630 \u2550\u2550 */\n.home{position:relative;z-index:2;flex:1;display:flex;flex-direction:column;width:100%;padding:16px 18px 90px;overflow-y:auto;box-sizing:border-box}\n.home-status{display:flex;align-items:center;gap:12px;padding:15px 16px;border-radius:18px;background:var(--card);border:1px solid var(--brd);margin-bottom:16px}\n.home-status-dot{width:9px;height:9px;border-radius:50%;background:var(--off);flex-shrink:0;transition:background .3s,box-shadow .3s}\n.home-status-dot.on{background:var(--on);box-shadow:0 0 8px var(--on);animation:bk 1.4s ease-in-out infinite}\n.home-status-txt{flex:1;min-width:0}\n.home-status-t1{font-family:var(--fo);font-size:12px;font-weight:800;color:var(--text)}\n.home-status-t2{font-family:var(--fm);font-size:8.5px;color:var(--muted);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.home-run-btn{padding:9px 18px;border-radius:24px;border:1px solid var(--brd2);background:var(--card2);font-family:var(--fo);font-size:11px;font-weight:800;letter-spacing:.03em;color:var(--dim);cursor:pointer;transition:all .15s;flex-shrink:0}\n.home-run-btn:active{transform:scale(.96)}\n.home-run-btn:disabled{opacity:.55;pointer-events:none}\n.home-run-btn.on{background:rgba(130,130,130,.14);color:var(--on);border-color:rgba(130,130,130,.35);box-shadow:0 0 12px rgba(130,130,130,.15)}\n.home-run-btn.off{background:rgba(118,118,118,.08);color:var(--off);border-color:rgba(118,118,118,.24)}\n.home-run-btn.wait{background:rgba(195,195,195,.12);color:var(--sharp);border-color:rgba(195,195,195,.32)}\n/* \u2500\u2500 \u0648\u0635\u0648\u0644 \u0633\u0631\u064a\u0639 (.qa-grid/.qa-tile/.qa-lbl) \u0648\u0634\u0631\u064a\u0637 \u0627\u0644\u062a\u0646\u0642\u0651\u0644 \u0627\u0644\u0633\u0641\u0644\u064a (.bnav/.bnav-item) \u0627\u0644\u0644\u0630\u0627\u0646\n \u0623\u064f\u0636\u064a\u0641\u0627 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u062d\u064f\u0630\u0641\u0627 \u0628\u0627\u0644\u0643\u0627\u0645\u0644 (\u0646\u0641\u0633 \u0627\u0644\u062a\u0627\u0631\u064a\u062e\u060c \u0637\u0644\u0628 \u0644\u0627\u062d\u0642): \"\u062d\u0630\u0641 \u0643\u0644 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0648\u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u0649\n \u0632\u0631 \u062a\u0634\u063a\u064a\u0644/\u0625\u064a\u0642\u0627\u0641 \u0648\u0627\u062d\u062f\" \u2014 \u0623\u0635\u0628\u062d\u062a \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u062d\u0627\u0644\u0629 + \u0632\u0631 \u0648\u0627\u062d\u062f \u0641\u0642\u0637. \u0627\u0644\u0642\u0648\u0627\u0639\u062f \u0623\u064f\u0632\u064a\u0644\u062a \u0645\u0646 \u0647\u0646\u0627\n \u0644\u0623\u0646 \u0644\u0627 \u0639\u0646\u0635\u0631 HTML \u064a\u0633\u062a\u062e\u062f\u0645\u0647\u0627 \u0628\u0639\u062f \u0627\u0644\u0622\u0646. \u2500\u2500 */\n/* \u2500\u2500 \u062a\u0646\u0642\u0651\u0644 \u0645\u0628\u0627\u0634\u0631 \u0628\u064a\u0646 \u0644\u0648\u062d\u0627\u062a \u0627\u0644\u0645\u062c\u0645\u0648\u0639\u0629 \u0646\u0641\u0633\u0647\u0627 \u2014 \u0623\u064f\u0636\u064a\u0641 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026\u060c \u062a\u0637\u0648\u064a\u0631 \u0627\u0644\u062a\u0646\u0642\u0644 \u2500\u2500 */\n.rel-nav{display:flex;align-items:center;gap:6px;padding:7px 14px;flex-wrap:wrap;border-bottom:1px solid var(--brd);flex-shrink:0}\n.rel-nav-lbl{font-family:var(--fo);font-size:8px;letter-spacing:.05em;color:var(--muted);text-transform:uppercase;flex-shrink:0}\n.rel-nav-cur{font-family:var(--fo);font-size:9.5px;font-weight:700;color:var(--on);padding:3px 10px;border-radius:20px;background:rgba(130,130,130,.12);border:1px solid rgba(130,130,130,.25)}\n.rel-nav-lnk{font-family:var(--fo);font-size:9.5px;font-weight:600;color:var(--dim);padding:3px 10px;border-radius:20px;border:1px solid var(--brd);cursor:pointer;transition:all .15s;-webkit-tap-highlight-color:transparent}\n.rel-nav-lnk:active{background:rgba(255,255,255,.06);color:var(--text)}\n/* \u2500\u2500 CIRCLE (flat, no glow) \u2500\u2500 */\n.cw{position:relative;width:200px;height:200px;display:flex;align-items:center;justify-content:center;cursor:pointer;margin-bottom:12px}\n.cb{position:absolute;width:180px;height:180px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;border:2px solid var(--brd2);background:var(--card);transition:border-color .3s,background .3s,box-shadow .3s;cursor:pointer;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.5)}\n.s-off .cb{border-color:var(--off);background:rgba(124,124,124,.05)}\n.s-zero .cb{border-color:var(--zero);background:rgba(143,143,143,.09)}\n.cw:active .cb{opacity:.8}\n.ai-lbl{font-family:var(--fo);font-size:44px;font-weight:900;letter-spacing:3px;position:relative;z-index:2;line-height:1;transition:color .3s}\n.s-off .c-sc{color:var(--dim)}\n.s-zero .c-sc{color:var(--zero)}\n.s-on .c-st{color:rgba(143,143,143,.5)}\n.s-zero .c-st{color:rgba(143,143,143,.6)}\n/* \u2500\u2500 TOGGLE \u2500\u2500 */\n.tog-row{display:flex;align-items:center;gap:10px;margin-bottom:8px;cursor:pointer}\n.tog-pill{display:flex;align-items:center;gap:10px;padding:10px 24px;border-radius:50px;border:1px solid var(--brd2);background:var(--card);cursor:pointer;transition:border-color .25s,background .25s,box-shadow .25s}\n.s-on .tdot{background:var(--on)}\n.s-off .tdot{background:var(--off)}\n.s-zero .tdot{background:var(--zero)}\n.ttxt{font-size:13px;font-weight:800;letter-spacing:2px;text-transform:uppercase;transition:color .25s;color:var(--dim);font-family:var(--fo)}\n/* \u2500\u2500 8-CLASS FREQ GRID \u2500\u2500 */\n.fc-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin-bottom:8px;opacity:0;transition:opacity .4s;width:100%;padding:0 10px}\n.s-on .fc-grid,.s-zero .fc-grid{opacity:1}\n.fc.c1{border-color:rgba(143,143,143,.3)}\n.fc.c1 .fc-val{color:var(--c1)}\n.fc.c2{border-color:rgba(124,124,124,.3)}\n.fc.c2 .fc-val{color:var(--c2)}\n.fc.c3{border-color:rgba(156,156,156,.3)}\n.fc.c3 .fc-val{color:var(--c3)}\n.fc.c4{border-color:rgba(130,130,130,.3)}\n.fc.c4 .fc-val{color:var(--c4)}\n.fc.c5{border-color:rgba(149,149,149,.3)}\n.fc.c5 .fc-val{color:var(--c5)}\n.fc.c6{border-color:rgba(146,146,146,.3)}\n.fc.c6 .fc-val{color:var(--c6)}\n.fc.c7{border-color:rgba(121,121,121,.3)}\n.fc.c7 .fc-val{color:var(--c7)}\n.fc.c8{border-color:rgba(146,146,146,.3)}\n.fc.c8 .fc-val{color:var(--c8)}\n/* \u2500\u2500 METRICS \u2500\u2500 */\n.met-row{display:flex;gap:12px;margin-bottom:8px;opacity:0;transition:opacity .4s}\n.s-on .met-row,.s-zero .met-row{opacity:1}\n.met{display:flex;flex-direction:column;align-items:center;gap:2px}\n.s-on .conf-w,.s-zero .conf-w{opacity:1}\n.s-on .sil-ind,.s-zero .sil-ind{opacity:1}\n.si-d{width:6px;height:6px;border-radius:50%;background:var(--dim);flex-shrink:0;transition:all .3s}\n.si-d.sil{background:var(--zero);animation:bk 2s infinite}\n.si-d.proc{background:var(--c5);animation:bk .8s infinite}\n/* \u2500\u2500 BUTTONS \u2500\u2500 */\n.btn-row{display:flex;gap:8px}\n.btn:hover{background:rgba(255,255,255,.07)}\n.btn.ai:active{transform:scale(.97)}\n.chev svg{width:16px;height:10px;fill:none;stroke:rgba(255,255,255,.4);stroke-width:2;stroke-linecap:round;stroke-linejoin:round}\n/* \u2500\u2500 OVERLAY & PANELS \u2500\u2500 */\n.ovl{position:fixed;top:0;left:0;right:0;bottom:var(--vv-bottom-inset,0px);background:rgba(0,0,0,0);z-index:30;opacity:0;pointer-events:none;transition:opacity .3s}\n/* \u0645\u0631\u0627\u062c\u0639\u0629 \u0631\u0627\u0628\u0639\u0629 \u0636\u0645\u0646 \u0625\u0635\u0644\u0627\u062d \"\u0627\u0644\u0648\u0645\u064a\u0636/\u0627\u0644\u062a\u062c\u0645\u0651\u062f \u0627\u0644\u0645\u0624\u0642\u062a \u0639\u0646\u062f \u0641\u062a\u062d \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0648\u062a\u0628\u062f\u064a\u0644 \u0627\u0644\u0642\u0648\u0627\u0626\u0645\":\n   .ovl \u0647\u064a \u0627\u0644\u0633\u062a\u0627\u0631\u0629 \u0627\u0644\u0645\u0634\u062a\u0631\u0643\u0629 \u0627\u0644\u062a\u064a \u062a\u064f\u0641\u0639\u064e\u0651\u0644 (.on) \u0641\u064a \u0643\u0644 \u0639\u0645\u0644\u064a\u0629 \u0641\u062a\u062d \u0644\u0623\u064a \u0644\u0648\u062d\u0629 \u0645\u0646 \u0643\u0644 \u0644\u0648\u062d\u0627\u062a\n   \u0627\u0644\u0645\u0634\u0631\u0648\u0639 (+10 \u0644\u0648\u062d\u0627\u062a) \u062f\u0648\u0646 \u0627\u0633\u062a\u062b\u0646\u0627\u0621 \u2014 \u0623\u064a \u0623\u0646\u0647\u0627 \u0627\u0644\u0639\u0646\u0635\u0631 \u0627\u0644\u0648\u062d\u064a\u062f \u0627\u0644\u0630\u064a \u064a\u062a\u062d\u0631\u0651\u0643 \u0641\u0639\u0644\u064a\u0627\u064b \u0641\u064a \u0643\u0644\n   \"\u062a\u0628\u062f\u064a\u0644 \u0642\u0627\u0626\u0645\u0629\" \u0648\u064f\u0635\u0641\u062a \u0628\u0647 \u0627\u0644\u0645\u0634\u0643\u0644\u0629. \u0643\u0627\u0646\u062a \u062a\u062d\u0645\u0644 backdrop-filter:blur(2px) \u0639\u0644\u0649 \u0643\u0627\u0645\u0644\n   \u0627\u0644\u0634\u0627\u0634\u0629\u060c \u0645\u062a\u0632\u0627\u0645\u0646\u0627\u064b \u0645\u0639 \u0627\u0646\u062a\u0642\u0627\u0644 opacity \u0627\u0644\u062e\u0627\u0635 \u0628\u0647\u0627 (.3s) \u0648\u0627\u0646\u062a\u0642\u0627\u0644 transform \u0627\u0644\u062e\u0627\u0635 \u0628\u0627\u0644\u0644\u0648\u062d\u0629\n   \u0646\u0641\u0633\u0647\u0627 \u0641\u064a \u0646\u0641\u0633 \u0627\u0644\u0644\u062d\u0638\u0629 \u0628\u0627\u0644\u0636\u0628\u0637. \u062a\u0623\u062b\u064a\u0631 blur \u0639\u0644\u0649 \u0643\u0627\u0645\u0644 \u0627\u0644\u0634\u0627\u0634\u0629 \u0645\u0639\u0631\u0648\u0641 \u0628\u0643\u0644\u0641\u062a\u0647 \u0627\u0644\u0639\u0627\u0644\u064a\u0629 \u0639\u0644\u0649\n   \u0627\u0644\u062a\u0631\u0643\u064a\u0628 (compositing) \u062e\u0635\u0648\u0635\u0627\u064b \u062f\u0627\u062e\u0644 WebView \u0623\u0646\u062f\u0631\u0648\u064a\u062f \u062a\u062d\u062f\u064a\u062f\u0627\u064b (\u0628\u062e\u0644\u0627\u0641 Chrome \u0646\u0641\u0633\u0647) \u2014 \u062f\u0639\u0645\u0647\n   \u0644\u0644\u062a\u0633\u0631\u064a\u0639 \u0628\u0627\u0644\u0639\u062a\u0627\u062f (GPU) \u063a\u064a\u0631 \u0645\u0648\u062b\u0648\u0642 \u0639\u0628\u0631 \u0643\u0644 \u0625\u0635\u062f\u0627\u0631\u0627\u062a/\u062a\u0648\u0632\u064a\u0639\u0627\u062a WebView\u060c \u0648\u0642\u062f \u064a\u062a\u0631\u0627\u062c\u0639 \u0644\u0645\u0633\u0627\u0631\n   \u0628\u0631\u0645\u062c\u064a \u0623\u0628\u0637\u0623 \u064a\u064f\u0633\u0628\u0650\u0651\u0628 \u062a\u0642\u0637\u0651\u0639\u0627\u064b/\u0648\u0645\u064a\u0636\u0627\u064b \u0645\u0631\u0626\u064a\u0627\u064b \u0628\u0627\u0644\u0636\u0628\u0637 \u0623\u062b\u0646\u0627\u0621 \u0646\u0641\u0633 \u0644\u062d\u0638\u0629 \u0641\u062a\u062d/\u0625\u063a\u0644\u0627\u0642 \u0627\u0644\u0644\u0648\u062d\u0629. \u0628\u0645\u0627\n   \u0623\u0646 \u0642\u064a\u0645\u0629 \u0627\u0644\u0637\u0645\u0633 \u0647\u0646\u0627 \u062e\u0641\u064a\u0641\u0629 \u062c\u062f\u0627\u064b \u0623\u0635\u0644\u0627\u064b (2px\u060c \u0623\u062b\u0631 \u0628\u0635\u0631\u064a \u0634\u0628\u0647 \u063a\u064a\u0631 \u0645\u064f\u062f\u0631\u064e\u0643) \u0648\u0623\u0646 \u0627\u0644\u062e\u0644\u0641\u064a\u0629 \u0634\u0628\u0647\n   \u0627\u0644\u0645\u0639\u062a\u0645\u0629 (rgba(6,6,6,.75)) \u062a\u062d\u0642\u0642 \u0648\u062d\u062f\u0647\u0627 \u062a\u0642\u0631\u064a\u0628\u0627\u064b \u0646\u0641\u0633 \u0623\u062b\u0631 \"\u062a\u0639\u062a\u064a\u0645 \u0627\u0644\u062e\u0644\u0641\u064a\u0629\" \u0627\u0644\u0645\u0642\u0635\u0648\u062f\u060c \u0623\u064f\u0632\u064a\u0644\n   \u0627\u0644\u0637\u0645\u0633 \u0647\u0646\u0627 \u062a\u062d\u062f\u064a\u062f\u0627\u064b (\u0627\u0644\u0639\u0646\u0635\u0631 \u0627\u0644\u0648\u062d\u064a\u062f \u0627\u0644\u0645\u0634\u062a\u0631\u0643 \u0628\u064a\u0646 \u0643\u0644 \u0627\u0644\u0644\u0648\u062d\u0627\u062a) \u0645\u0639 \u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u064a\u0647 \u0641\u064a \u0628\u0642\u064a\u0629\n   \u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u0648\u0627\u062c\u0647\u0629 \u0627\u0644\u0623\u0642\u0644 \u062a\u0643\u0631\u0627\u0631\u0627\u064b (\u062a\u0646\u0628\u064a\u0647 \u0627\u0644\u0625\u0646\u062c\u0627\u0632\u060c \u0634\u0627\u0631\u0629 \u0627\u0644\u062e\u0644\u0641\u064a\u0629\u060c \u062a\u0646\u0628\u064a\u0647 \u0627\u0644\u062d\u0631\u0627\u0631\u0629...) \u0627\u0644\u062a\u064a \u0644\u0627\n   \u062a\u0631\u062a\u0628\u0637 \u0645\u0628\u0627\u0634\u0631\u0629 \u0628\u0646\u0641\u0633 \u0627\u0644\u0633\u064a\u0646\u0627\u0631\u064a\u0648 \u0627\u0644\u0645\u064f\u0628\u0644\u064e\u0651\u063a \u0639\u0646\u0647. \u0645\u0644\u0627\u062d\u0638\u0629 \u0635\u062f\u0642: \u0647\u0630\u0627 \u0627\u0644\u0625\u0635\u0644\u0627\u062d \u0645\u0628\u0646\u064a \u0639\u0644\u0649 \u0633\u0644\u0648\u0643\n   \u0645\u0648\u062b\u064e\u0651\u0642 \u0645\u0639\u0631\u0648\u0641 \u0644\u0640backdrop-filter \u062f\u0627\u062e\u0644 WebView \u0623\u0646\u062f\u0631\u0648\u064a\u062f \u062a\u062d\u062f\u064a\u062f\u0627\u064b \u2014 \u0644\u0627 \u0639\u0644\u0649 \u0642\u064a\u0627\u0633 \u0641\u0639\u0644\u064a \u0647\u0646\u0627\n   (\u0644\u0627 \u062c\u0647\u0627\u0632 \u062d\u0642\u064a\u0642\u064a \u0645\u062a\u0627\u062d)\u060c \u0628\u062e\u0644\u0627\u0641 \u0627\u0644\u0625\u0635\u0644\u0627\u062d\u0627\u062a \u0627\u0644\u062b\u0644\u0627\u062b\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u0627\u0644\u0645\u064f\u062b\u0628\u064e\u062a\u0629 \u0639\u0628\u0631 \u0627\u062e\u062a\u0628\u0627\u0631\u0627\u062a \u0645\u0628\u0627\u0634\u0631\u0629. */\n.ovl.on{opacity:1;pointer-events:all;background:rgba(6,6,6,.75)}\n.pnl{position:fixed;bottom:var(--vv-bottom-inset,0px);left:50%;transform:translateX(-50%) translateY(102%);width:100%;max-width:420px;border-radius:22px 22px 0 0;z-index:40;transition:transform .38s cubic-bezier(.25,.8,.2,1);display:flex;flex-direction:column;border-top:1px solid var(--brd2);background:var(--surf);box-shadow:var(--shadow-panel)}\n.pnl.open{transform:translateX(-50%) translateY(0)}\n.phd{display:flex;align-items:center;justify-content:space-between;padding:8px 24px 14px;flex-shrink:0}\n.pcl{width:32px;height:32px;border-radius:50%;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:16px;color:var(--dim);transition:background .2s}\n.pcl:hover{background:rgba(255,255,255,.1);color:var(--text)}\n#bSheet{background:var(--surf);max-height:92vh}\n#menuPanel{background:var(--surf);max-height:88vh}\n.shsc{overflow-y:auto;flex:1;padding:0 16px 36px;scrollbar-width:none}\n.shsc::-webkit-scrollbar{display:none}\n.si:not(:last-child)::after{content:'''';position:absolute;bottom:0;left:60px;right:0;height:1px;background:var(--brd)}\n.si:hover{background:rgba(255,255,255,.04)}\n.si:active{background:rgba(255,255,255,.07)}\n.ib{background:rgba(129,129,129,.1);border-color:rgba(129,129,129,.2)}\n.ip{background:rgba(110,110,110,.1);border-color:rgba(110,110,110,.2)}\n.ig{background:rgba(131,131,131,.1);border-color:rgba(131,131,131,.2)}\n.io{background:rgba(170,170,170,.1);border-color:rgba(170,170,170,.2)}\n.it{background:rgba(140,140,140,.1);border-color:rgba(140,140,140,.2)}\n.iev{background:rgba(120,120,120,.1);border-color:rgba(120,120,120,.2)}\n.iem{background:rgba(119,119,119,.1);border-color:rgba(119,119,119,.2)}\n.iai{background:rgba(149,149,149,.1);border-color:rgba(149,149,149,.2)}\n.iph{background:rgba(165,165,165,.1);border-color:rgba(165,165,165,.2)}\n.ips{background:rgba(136,136,136,.1);border-color:rgba(136,136,136,.2)}\n.iai2{background:rgba(130,130,130,.1);border-color:rgba(130,130,130,.2)}\n.imask{background:rgba(131,131,131,.1);border-color:rgba(131,131,131,.2)}\n.iav{background:rgba(152,152,152,.1);border-color:rgba(152,152,152,.2)}\n.scnt{flex:1;min-width:0}\n/* \u2500\u2500 MASKING NOISE PANEL \u2014 \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 anechoic-chamber.html\n   (\"\u062a\u062c\u0645\u064a\u0639 \u0643\u0644 \u0627\u0644\u0623\u0641\u0643\u0627\u0631\"): \u0641\u0643\u0631\u0629 \u0643\u0627\u0646\u062a \u063a\u0627\u0626\u0628\u0629 \u0643\u0644\u064a\u0627\u064b \u0639\u0646 \u0643\u0644 \u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u2014 \u062a\u0634\u063a\u064a\u0644\n   \u0636\u0648\u0636\u0627\u0621 (\u0623\u0628\u064a\u0636/\u0648\u0631\u062f\u064a/\u0628\u0646\u064a/\u0645\u0637\u0631/\u0639\u0645\u064a\u0642) \u0644\u0625\u062e\u0641\u0627\u0621 \u0627\u0644\u0635\u0648\u062a \u0627\u0644\u0645\u062d\u064a\u0637\u060c \u0643\u0628\u062f\u064a\u0644/\u0645\u0643\u0645\u0651\u0644 \u0644\u0644\u0625\u0644\u063a\u0627\u0621\n   \u0627\u0644\u0641\u0639\u0651\u0627\u0644. \u0645\u062d\u0631\u0643 \u0635\u0648\u062a \u0645\u0633\u062a\u0642\u0644 \u062a\u0645\u0627\u0645\u0627\u064b (maskCtx \u062e\u0627\u0635 \u0628\u0647) \u0641\u0644\u0627 \u064a\u062a\u0639\u0627\u0631\u0636 \u0645\u0639 \u0645\u062d\u0631\u0643 ANC. \u2500\u2500 */\n.mask-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:10px 0}\n.mask-btn{padding:14px 6px;border-radius:12px;background:var(--card);border:1px solid var(--brd);color:var(--dim);font-family:var(--fo);font-size:11px;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;transition:all .15s}\n.mask-btn .mask-ico{font-size:20px}\n.mask-btn.on{background:rgba(131,131,131,.12);border-color:rgba(131,131,131,.4);color:#b2b2b2}\n.mask-slider-row{margin:12px 0}\n.mask-slider-lbl{display:flex;justify-content:space-between;font-family:var(--fm);font-size:9px;color:var(--muted);margin-bottom:5px}\n.mask-slider-lbl span:last-child{color:#b2b2b2}\n.mask-viz{width:100%;height:60px;border-radius:10px;background:rgba(8,8,8,.6);border:1px solid var(--brd);margin:10px 0}\n.mask-run-btn{width:100%;padding:14px;border-radius:14px;border:none;font-family:var(--fo);font-size:13px;font-weight:800;cursor:pointer;background:rgba(131,131,131,.12);color:#b2b2b2;border:1px solid rgba(131,131,131,.3);transition:all .15s}\n.mask-run-btn.on{background:rgba(131,131,131,.85);color:#0f0f0f}\n.phys-row{margin:0 0 14px}\n.phys-lbl{display:flex;justify-content:space-between;align-items:center;font-family:var(--fo);font-size:10px;color:var(--t2,var(--muted));margin-bottom:6px}\n.phys-stat{font-family:var(--fm);font-size:9px;color:#b2b2b2}\n.phys-viz{width:100%;height:56px;border-radius:10px;background:rgba(8,8,8,.6);border:1px solid var(--brd);display:block}\n.sleep-preset-row{display:flex;gap:6px;flex-wrap:wrap}\n.sleep-preset-btn{flex:1 1 26%;min-width:52px;padding:8px 4px;border-radius:10px;border:1px solid var(--brd2);background:var(--card);color:var(--dim);font-family:var(--fo);font-size:10px;font-weight:700;cursor:pointer;text-align:center;transition:all .15s}\n.sleep-preset-btn.sel{background:rgba(147,147,147,.12);color:#a6a6a6;border-color:rgba(147,147,147,.35)}\n.sleep-timer-btn{width:100%;padding:12px;border-radius:12px;border:1px solid rgba(147,147,147,.3);background:rgba(147,147,147,.1);color:#a6a6a6;font-family:var(--fo);font-size:12px;font-weight:800;cursor:pointer;margin-top:10px;transition:all .15s}\n.sleep-timer-btn.run{background:rgba(147,147,147,.85);color:#0e0e0e}\n.sleep-timer-disp{text-align:center;font-family:var(--fm);font-size:22px;color:#a6a6a6;margin-top:10px;letter-spacing:.05em}\n.loop-flow{background:var(--surf);border:1px solid var(--brd);border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:6px;position:relative;overflow:hidden}\n.loop-flow::before{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(130,130,130,.03) 0%,rgba(123,123,123,.02) 100%);pointer-events:none}\n.lf-step{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:8px;transition:all .3s;position:relative;border:1px solid transparent}\n.lf-step.active-step{background:rgba(130,130,130,.08);border-color:rgba(130,130,130,.25)}\n.lf-step.processing{background:rgba(123,123,123,.08);border-color:rgba(123,123,123,.25);animation:stepPulse .8s infinite}\n@keyframes stepPulse{0%,100%{opacity:1}50%{opacity:.6}}\n.lf-step.zero-step{background:rgba(130,130,130,.14);border-color:rgba(130,130,130,.45)}\n.ls-icon{font-size:15px;flex-shrink:0;line-height:1}\n.ls-name{font-family:var(--fo);font-size:11px;font-weight:700;color:var(--text);transition:color .3s}\n.lf-step.active-step .ls-name{color:var(--zero)}\n.lf-step.processing .ls-name{color:var(--ai)}\n.lf-step.zero-step .ls-name{color:var(--zero)}\n.ls-sub{font-family:var(--fm);font-size:9px;color:var(--dim);letter-spacing:.02em;margin-top:1px}\n.lf-arrow{text-align:center;font-family:var(--fm);font-size:11px;color:var(--dim);transition:color .3s;margin:-3px 0}\n.lf-arrow.active{color:var(--zero);animation:arrowFlow .6s ease-in-out infinite alternate}\n@keyframes arrowFlow{from{opacity:.4}to{opacity:1}}\n.sr{display:flex;align-items:center;gap:6px;flex-shrink:0}\n.sv{font-size:13px;color:var(--dim)}\n.sch{width:16px;height:16px;fill:none;stroke:rgba(255,255,255,.3);stroke-width:2;stroke-linecap:round;stroke-linejoin:round}\n.sw{position:relative;width:46px;height:26px;cursor:pointer}\n.sw input{display:none}\n.sw-t{position:absolute;inset:0;border-radius:13px;background:rgba(255,255,255,.08);border:1px solid var(--brd);transition:background .2s,border-color .2s}\n.sw-th{position:absolute;width:20px;height:20px;border-radius:50%;background:#fff;top:3px;left:3px;transition:transform .25s;box-shadow:0 2px 4px rgba(0,0,0,.4)}\n.sw input:checked~.sw-t~.sw-th{transform:translateX(20px)}\n.shsl{padding:0 16px 5px}\n.shsl input[type=range]{-webkit-appearance:none;width:100%;height:3px;background:rgba(255,255,255,.1);border-radius:2px;outline:none;cursor:pointer}\n.sg{display:flex;gap:6px;padding:8px 16px 12px;flex-wrap:wrap}\n/* \u2500\u2500 AI PANEL \u2500\u2500 */\n.ai-ph-c{width:28px;height:28px;border-radius:50%;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;color:var(--dim)}\n.tab-bar{display:flex;gap:4px;padding:7px 14px 6px;flex-shrink:0;border-bottom:1px solid var(--brd);overflow-x:auto;scrollbar-width:none}\n.tab-bar::-webkit-scrollbar{display:none}\n.pane{flex:1;overflow-y:auto;padding:10px 14px;display:none;flex-direction:column;gap:7px;scrollbar-width:none;min-height:0}\n.pane::-webkit-scrollbar{display:none}\n.pane.on{display:flex}\n.stat4{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}\n.cg2{display:grid;grid-template-columns:1fr 1fr;gap:5px}\n.cc-d{width:6px;height:6px;border-radius:50%;flex-shrink:0}\n.nog{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}\n.noc{border-radius:8px;padding:6px 5px;text-align:center;border:1px solid var(--brd);background:var(--card)}\n.ai-st{padding:5px 14px;display:flex;align-items:center;gap:6px;flex-shrink:0;background:var(--bg);border-bottom:1px solid var(--brd)}\n.as-p{width:5px;height:5px;border-radius:50%;background:var(--ai);animation:bk 1.8s infinite;flex-shrink:0}\n/* \u2500\u2500 PLUGIN PANEL \u2500\u2500 */\n.ppnl{position:fixed;top:0;right:0;bottom:var(--vv-bottom-inset,0px);width:236px;z-index:35;transform:translateX(102%);transition:transform .35s cubic-bezier(.32,.72,0,1);background:var(--surf);border-left:1px solid var(--brd);display:flex;flex-direction:column;overflow:hidden}\n.ppnl.open{transform:translateX(0)}\n.pplph{padding:52px 14px 10px;border-bottom:1px solid var(--brd);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}\n.pplph-t{font-family:var(--fm);font-size:10px;letter-spacing:.18em;color:var(--dim);text-transform:uppercase}\n.pplph-c{width:28px;height:28px;border-radius:50%;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;color:var(--dim)}\n.pscr{flex:1;overflow-y:auto;padding:8px;scrollbar-width:none}\n.pscr::-webkit-scrollbar{display:none}\n.plb{border:1px solid var(--brd);border-radius:8px;margin-bottom:5px;overflow:hidden}\n.plh{display:flex;align-items:center;justify-content:space-between;padding:6px 9px;background:var(--card);border-bottom:1px solid var(--brd)}\n.pls.run{border-color:rgba(143,143,143,.4);color:var(--zero);animation:bk 2s infinite}\n.pls.sil{border-color:rgba(149,149,149,.4);color:var(--c5)}\n.pls.ai2{border-color:rgba(130,130,130,.4);color:var(--ai)}\n.pls.inv{border-color:rgba(156,156,156,.4);color:var(--c3)}\n.plbd{padding:5px 9px}\n.plr:last-child{border-bottom:none}\n.coh-mini{display:flex;flex-direction:column;gap:3px;padding:3px 0}\n.cm{display:grid;grid-template-columns:38px 1fr 26px;gap:3px;align-items:center}\n.cmh{font-family:var(--fm);font-size:8px;color:rgba(255,255,255,.3)}\n.cmt{height:3px;background:rgba(255,255,255,.07);border-radius:1px;overflow:hidden}\n.cmf{height:100%;border-radius:2px;transition:width .18s,background .3s;width:0%}\n.cmv{font-family:var(--fm);font-size:8px;color:rgba(255,255,255,.3)}\n/* \u2500\u2500 AI EXEC ENGINE \u2500\u2500 */\n.exec-hd{display:flex;align-items:center;justify-content:space-between;padding:8px 14px 5px;border-bottom:1px solid var(--brd);flex-shrink:0;background:var(--bg)}\n.exec-left{display:flex;align-items:center;gap:7px}\n.exec-run-dot{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.2);flex-shrink:0;transition:all .3s}\n.exec-run-dot.run{background:var(--zero);animation:bk .7s infinite}\n.exec-stat-row{display:flex;gap:0;border-bottom:1px solid var(--brd);flex-shrink:0}\n.exec-sv{flex:1;display:flex;flex-direction:column;align-items:center;padding:4px 3px;border-right:1px solid var(--brd)}\n.exec-sv:last-child{border-right:none}\n.exec-log{flex:1;overflow-y:auto;padding:6px 10px;display:flex;flex-direction:column;gap:3px;scrollbar-width:none;min-height:0;font-family:var(--fm)}\n.exec-log::-webkit-scrollbar{display:none}\n.exec-entry.warn{border-left-color:rgba(156,156,156,.5);background:rgba(156,156,156,.04)}\n.exec-entry.err{border-left-color:rgba(124,124,124,.5);background:rgba(124,124,124,.04)}\n.exec-entry.sys{border-left-color:rgba(130,130,130,.4);background:rgba(130,130,130,.04)}\n.exec-entry.opt{border-left-color:rgba(143,143,143,.6);background:rgba(143,143,143,.06)}\n.exec-eh{display:flex;align-items:center;gap:6px;margin-bottom:2px}\n.exec-prog.warn{color:var(--c3)}\n.exec-prog.err{color:var(--c2)}\n.exec-prog.sys{color:var(--ai)}\n.exec-meta{font-size:8px;color:rgba(255,255,255,.25);margin-left:auto}\n.exec-line{display:flex;gap:4px}\n.exec-arrow{color:rgba(143,143,143,.45);flex-shrink:0}\n.exec-arrow.warn{color:rgba(156,156,156,.6)}\n.exec-arrow.mod{color:rgba(149,149,149,.6)}\n.exec-ir{display:flex;border-top:1px solid var(--brd);flex-shrink:0}\n.exec-inp::placeholder{color:rgba(255,255,255,.15);font-size:9px}\n.exec-btn:hover{background:rgba(143,143,143,.18)}\n/* \u2500\u2500 FILE STORAGE \u2500\u2500 */\n.st-btn:hover{background:rgba(255,255,255,.08)}\n.st-btn:active{opacity:.8}\n.st-btn.up{border-color:rgba(149,149,149,.3);color:var(--c5)}\n.st-btn.up:hover{background:rgba(149,149,149,.07)}\n.st-btn.dn{border-color:rgba(196,196,196,.3);color:var(--sharp)}\n.st-btn.dn:hover{background:rgba(196,196,196,.06)}\n.st-btn.ai{border-color:rgba(130,130,130,.3);color:var(--ai)}\n.st-btn.ai:hover{background:rgba(130,130,130,.07)}\n.st-btn.del{border-color:rgba(124,124,124,.3);color:var(--c2)}\n.st-btn.del:hover{background:rgba(124,124,124,.06)}\n.st-frow{display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05)}\n.st-frow:last-child{border-bottom:none}\n.ach-item{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05)}\n.ach-item:last-child{border-bottom:none}\n.ach-ico{font-size:17px;min-width:24px;text-align:center}\n.btn-row2{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:6px}\n.srow{display:flex;gap:4px;flex-wrap:wrap}\n/* \u2500\u2500 BACKGROUND MODE \u2500\u2500 */\n.bg-banner.on{opacity:1;pointer-events:all}\n.bg-bdot{width:7px;height:7px;border-radius:50%;background:var(--zero);animation:bk .9s infinite;flex-shrink:0}\n.bg-bcl{font-size:14px;color:var(--dim);cursor:pointer;padding:2px 4px;flex-shrink:0}\n.bg-badge.on{display:flex}\n.bg-badge:hover{background:rgba(143,143,143,.12)}\n.bg-bdot2{width:5px;height:5px;border-radius:50%;background:var(--zero);animation:bk .9s infinite;flex-shrink:0}\n.sys-row{display:flex;gap:4px;flex-wrap:wrap;padding:4px 0}\n.sy.ok{border-color:rgba(143,143,143,.35);color:var(--zero)}\n.sy.warn{border-color:rgba(156,156,156,.35);color:var(--c3)}\n.sy.err{border-color:rgba(124,124,124,.35);color:var(--c2)}\n.syd{width:4px;height:4px;border-radius:50%;background:currentColor;flex-shrink:0}\n.bg-card{border-radius:10px;padding:9px 11px;border:1px solid rgba(143,143,143,.15);background:rgba(143,143,143,.04);margin-bottom:6px}\n.bg-row{display:flex;justify-content:space-between;align-items:center;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04);font-family:var(--fm);font-size:9px}\n.bg-row:last-child{border-bottom:none}\n.bg-tgl:hover{background:rgba(143,143,143,.14)}\n.bg-tgl.off{border-color:rgba(123,123,123,.35);background:rgba(123,123,123,.07);color:var(--off)}\n.wk2{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:6px}\n.wkc{border-radius:8px;padding:7px 6px;border:1px solid var(--brd);background:var(--card);text-align:center}\n/* \u2500\u2500 LIVE TERMINAL \u2500\u2500 */\n.term-btn{position:relative}\n.term-live-dot{width:5px;height:5px;border-radius:50%;background:rgba(255,255,255,.2);flex-shrink:0;transition:all .3s;margin-left:2px}\n.term-live-dot.on{background:var(--zero);animation:bk .7s infinite}\n.term-ph-l{display:flex;align-items:center;gap:8px}\n.term-ph-dot{width:6px;height:6px;border-radius:50%;background:var(--zero);animation:bk .7s infinite;flex-shrink:0}\n.term-ph-r{display:flex;gap:6px;align-items:center}\n.term-ctl:hover{background:rgba(255,255,255,.1)}\n/* \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u2014 \"\u062a\u062c\u0645\u064a\u0639 \u0643\u0644 \u0627\u0644\u0623\u0641\u0643\u0627\u0631\": \u0634\u0631\u064a\u0637 \u062a\u0635\u0641\u064a\u0629 \u0627\u0644\u0637\u0631\u0641\u064a\u0629 + \u0633\u0637\u0631 \u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0623\u0648\u0627\u0645\u0631\u060c\n   \u0643\u0627\u0646\u0627 \u0645\u064f\u0632\u0627\u0644\u064e\u064a\u0646 \u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0644\u0635\u0627\u0644\u062d \u0644\u0648\u062d\u0629 \u0645\u0631\u0627\u0642\u0628\u0629 SYS/WARN/ERR \u0641\u0642\u0637. */\n.term-fil{display:flex;gap:4px;padding:4px 10px;border-bottom:1px solid rgba(143,143,143,.08);flex-shrink:0;overflow-x:auto;scrollbar-width:none}\n.term-fil::-webkit-scrollbar{display:none}\n.tfc{font-family:var(--fm);font-size:8px;padding:2px 7px;border-radius:4px;border:1px solid var(--brd);background:transparent;cursor:pointer;white-space:nowrap;transition:background .12s;flex-shrink:0}\n.tfc.on{background:rgba(0,0,0,.5)}\n.term-out{flex:1;overflow-y:auto;padding:6px 10px 4px;font-family:var(--fm);font-size:10px;line-height:1.6;color:rgba(215,215,215,.82);scrollbar-width:thin;scrollbar-color:rgba(143,143,143,.2) transparent;min-height:0}\n.term-out::-webkit-scrollbar{width:3px}\n.term-out::-webkit-scrollbar-thumb{background:rgba(143,143,143,.2);border-radius:2px}\n.tline{display:flex;gap:0;padding:1px 0;border-bottom:1px solid rgba(255,255,255,.03)}\n.term-ir{display:flex;border-top:1px solid rgba(143,143,143,.12);flex-shrink:0;background:rgba(6,6,6,.9)}\n.term-cmd{flex:1;padding:8px 4px;background:transparent;border:none;color:var(--zero);font-family:var(--fm);font-size:11px;outline:none;caret-color:var(--zero)}\n.term-cmd::placeholder{color:rgba(143,143,143,.22);font-family:var(--fo);font-size:9px;letter-spacing:.04em}\n/* \u2500\u2500 \u0628\u062d\u062b \u0646\u0635\u0651\u064a \u0641\u064a \u0627\u0644\u0633\u062c\u0644\u0651 \u2014 \u0623\u064f\u0636\u064a\u0641 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026\u060c \u062a\u0637\u0648\u064a\u0631 Logs \u2500\u2500 */\n.term-search-row{display:flex;align-items:center;gap:6px;padding:5px 10px;border-bottom:1px solid rgba(143,143,143,.08);flex-shrink:0}\n.term-search{flex:1;padding:5px 8px;background:rgba(255,255,255,.03);border:1px solid var(--brd);border-radius:6px;color:var(--text);font-family:var(--fm);font-size:9.5px;outline:none;min-width:0}\n.term-search::placeholder{color:rgba(143,143,143,.35);font-family:var(--fo);font-size:9px}\n.term-search-cnt{font-family:var(--fm);font-size:8px;color:var(--muted);flex-shrink:0;white-space:nowrap}\n.term-run:hover{background:rgba(143,143,143,.18)}\n.term-prompt{display:flex;align-items:center;padding:0 8px;color:var(--zero);font-family:var(--fm);font-size:12px;flex-shrink:0;font-weight:700}\n.term-run{padding:8px 12px;background:rgba(143,143,143,.08);border:none;border-left:1px solid rgba(143,143,143,.15);color:var(--zero);font-family:var(--fo);font-size:10px;cursor:pointer;letter-spacing:.04em;transition:background .18s;font-weight:800}\n.term-pause-lbl{font-family:var(--fm);font-size:8px;color:rgba(156,156,156,.7);padding:2px 6px;border:1px solid rgba(156,156,156,.3);border-radius:3px;animation:bk 1s infinite}\n/* \u2500\u2500 FREQ PARTITION \u2500\u2500 */\n.part-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px}\n.part-card{background:var(--card);border:1px solid var(--brd);border-radius:10px;padding:8px 10px}\n.part-hot{color:var(--off)}\n.part-cold{color:var(--c5)}\n.part-ban{color:#6e6e6e}\n.part-conf{color:var(--zero)}\n.part-inv{color:var(--c3)}\n.part-pred{color:var(--c4)}\n.part-save-btn:active{background:rgba(143,143,143,.16)}\n/* \u2500\u2500 BAN SYSTEM \u2500\u2500 */\n.ban-rmv:active{background:rgba(143,143,143,.12);color:var(--zero)}\n.ban-empty{font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.22);padding:8px 0;text-align:center}\n.ban-stat{font-family:var(--fm);font-size:8px;padding:3px 8px;border-radius:6px;background:rgba(110,110,110,.1);color:#6e6e6e;border:1px solid rgba(110,110,110,.22)}\n.ban-row.perm .ban-hz{color:#888888}\n.ban-prob{display:flex;align-items:center;gap:3px;flex-shrink:0}\n.ban-prob-wrap{width:28px;height:3px;background:rgba(255,255,255,.08);border-radius:2px;overflow:hidden}\n.ban-prob-bar{height:100%;border-radius:2px;transition:width .5s}\n.ban-prob-bar.env{background:var(--zero)}\n.ban-prob-bar.spk{background:#686868}\n.ban-prob-bar.mixed{background:var(--c3)}\n.ban-prob-bar.pending{background:var(--muted)}\n.ban-verdict{font-family:var(--fm);font-size:7px;font-weight:700}\n.ban-verdict.env{color:var(--zero)}\n.ban-verdict.spk{color:#686868}\n.ban-verdict.mixed{color:var(--c3)}\n.ban-verdict.pending{color:var(--muted)}\n/* \u062a\u0623\u0643\u064a\u062f \u0645\u062a\u0642\u0627\u0637\u0639 \u0628\u064a\u0646 \u0627\u0644\u0623\u062c\u0647\u0632\u0629 (\u0627\u0633\u062a\u064a\u0631\u0627\u062f/\u062a\u0635\u062f\u064a\u0631) \u2014 \ud83d\udd17N \u0637\u0628\u064a\u0639\u064a\u060c \u26a0N \u0639\u0646\u062f \u062a\u0639\u0627\u0631\u0636 \u0627\u0644\u062d\u0643\u0645 \u0628\u064a\u0646 \u0627\u0644\u062c\u0647\u0627\u0632\u064a\u0646 */\n.ban-cross{font-family:var(--fm);font-size:7px;font-weight:700;flex-shrink:0;color:var(--muted);opacity:.75}\n.ban-cross.conflict{color:#686868;opacity:1}\n/* \u2500\u2500 PERM BAN SETTINGS \u2500\u2500 */\n.pban-cats{display:flex;flex-direction:column;gap:6px;margin-bottom:10px}\n.pban-cat-row{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:10px;background:var(--card);border:1px solid var(--brd)}\n.pban-cat-ico{font-size:15px;flex-shrink:0}\n.pban-cat-info{flex:1}\n.pban-add-row{display:flex;gap:6px;margin-bottom:8px}\n.pban-inp{flex:1;background:rgba(255,255,255,.05);border:1px solid var(--brd);border-radius:8px;padding:8px 10px;font-family:var(--fm);font-size:11px;color:#fff;outline:none}\n.pban-inp::placeholder{color:rgba(255,255,255,.22)}\n.pban-inp:focus{border-color:rgba(143,143,143,.4);background:rgba(143,143,143,.04)}\n.pban-add-btn:active{background:rgba(143,143,143,.22)}\n.pban-list{display:flex;flex-direction:column;gap:3px;max-height:160px;overflow-y:auto}\n.pban-list::-webkit-scrollbar{width:3px}\n.pban-list::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12);border-radius:2px}\n/* \u2500\u2500 \u062a\u0635\u062f\u064a\u0631 \u0627\u0644\u062d\u0636\u0631 \u2500\u2500 */\n.ban-exp-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}\n.ban-exp-btn{padding:10px 6px;border-radius:9px;font-family:var(--fm);font-size:10px;text-align:center;cursor:pointer;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:rgba(255,255,255,.65);transition:background .15s,border-color .15s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.ban-exp-btn:active{background:rgba(255,255,255,.1)}\n.ban-exp-btn.json{border-color:rgba(130,130,130,.3);color:var(--zero)}\n.ban-exp-btn.csv{border-color:rgba(140,140,140,.3);color:var(--ai)}\n.ban-exp-btn.txt{border-color:rgba(176,176,176,.3);color:rgba(176,176,176,.85)}\n.ban-exp-msg{font-family:var(--fm);font-size:8px;color:var(--muted);margin-top:5px;line-height:1.5;word-break:break-all}\n.ban-exp-msg.ok{color:var(--zero)}\n.ban-exp-msg.err{color:rgba(132,132,132,.8)}\n/* \u2500\u2500 PERM STATUS BADGES \u2500\u2500 */\n.perm-status-row{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}\n.ps-badge.ok{background:rgba(143,143,143,.1);color:var(--zero);border-color:rgba(143,143,143,.22)}\n.ps-badge.no{background:rgba(123,123,123,.1);color:var(--off);border-color:rgba(123,123,123,.22)}\n.ps-badge.warn{background:rgba(176,176,176,.1);color:var(--c3);border-color:rgba(176,176,176,.22)}\n/* \u2500\u2500 Scrollbar refinement \u2500\u2500 */\n::-webkit-scrollbar{width:2px;height:2px}\n::-webkit-scrollbar-track{background:transparent}\n::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:2px}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0639\u0631\u0636 \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0641\u0646\u064a\u0629 \u2500\u2500 */\n.mv,.stat-v,.therm-val,.cls16-val,.fc-val,.slug-val{font-variant-numeric:tabular-nums}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0623\u0632\u0631\u0627\u0631 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u2500\u2500 */\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0644\u0648\u062d\u0629 \u0627\u0644\u0634\u0631\u064a\u0637 \u0627\u0644\u0633\u0641\u0644\u064a \u2500\u2500 */\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 CC (\u0645\u0631\u0628\u0639\u0627\u062a info) \u2500\u2500 */\n/* \u2500\u2500 \u062a\u0648\u0647\u062c \u0627\u0644\u0640 AI dot \u2500\u2500 */\n.ai-dot{width:7px;height:7px;border-radius:50%;background:var(--ai);animation:bk 2.4s ease-in-out infinite;box-shadow:0 0 6px var(--ai)}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0633\u0637\u0648\u0631 \u0627\u0644\u062d\u0638\u0631 \u2500\u2500 */\n.ban-row{display:flex;align-items:center;gap:6px;padding:7px 10px;border-radius:9px;background:rgba(255,255,255,.02);border:1px solid var(--brd);margin-bottom:3px}\n.ban-row.perm{background:rgba(118,118,118,.04);border-color:rgba(118,118,118,.12)}\n/* \u0635\u0641\u0648\u0641 \u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062a\u062f\u0627\u062e\u0644 \u062f\u0627\u062e\u0644 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062f\u0645\u062c\u0629 (pban-settings-list) \u2014 \u0644\u0648\u0646 \u0628\u0646\u0641\u0633\u062c\u064a \u0645\u0645\u064a\u0651\u0632 \u0639\u0646 \u0635\u0641\u0648\u0641 \u0627\u0644\u062d\u0638\u0631 */\n.ban-row.zone{background:rgba(120,120,120,.05);border-color:rgba(120,120,120,.16)}\n.ban-row.zone .ban-hz{color:#787878}\n.ban-hz{font-family:var(--fm);font-size:11px;color:#6e6e6e;flex:0 0 72px;font-weight:700;font-variant-numeric:tabular-nums;letter-spacing:-.3px}\n.ban-why{font-family:var(--fo);font-size:8px;color:var(--dim);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.ban-rmv{font-family:var(--fo);font-size:10px;color:var(--dim);cursor:pointer;padding:3px 9px;border-radius:6px;background:rgba(255,255,255,.04);border:1px solid var(--brd);flex-shrink:0;transition:background .15s}\n.ban-rmv:hover{background:rgba(118,118,118,.12);color:var(--off);border-color:rgba(118,118,118,.2)}\n.ban-lock{font-size:10px;flex-shrink:0;opacity:.5}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0634\u0627\u0631\u0627\u062a \u0627\u0644\u0641\u0626\u0627\u062a \u2500\u2500 */\n.ban-cat{font-family:var(--fo);font-size:7px;font-weight:800;padding:2px 6px;border-radius:5px;letter-spacing:.05em;flex-shrink:0;text-transform:uppercase}\n.ban-cat.harmful{background:rgba(118,118,118,.15);color:var(--off);border:1px solid rgba(104,104,104,.25)}\n.ban-cat.noisy{background:rgba(148,148,148,.15);color:var(--noise);border:1px solid rgba(176,176,176,.22)}\n.ban-cat.mic{background:rgba(140,140,140,.15);color:var(--c5);border:1px solid rgba(129,129,129,.22)}\n.ban-cat.thermal{background:rgba(148,148,148,.15);color:var(--noise);border:1px solid rgba(124,124,124,.25)}\n.ban-cat.lag{background:rgba(125,125,125,.15);color:var(--c4);border:1px solid rgba(156,156,156,.22)}\n.ban-cat.env{background:rgba(125,125,125,.12);color:var(--evp);border:1px solid rgba(130,130,130,.22)}\n.ban-cat.custom{background:rgba(130,130,130,.12);color:var(--on);border:1px solid rgba(143,143,143,.18)}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 EXEC terminal \u2500\u2500 */\n.nc-h+div,.xlog-line{font-family:var(--fm);font-size:9px}\n/* \u2500\u2500 \u062a\u0623\u062b\u064a\u0631 hover \u0639\u0644\u0649 \u062e\u0644\u0627\u064a\u0627 \u0627\u0644\u0641\u0626\u0627\u062a \u2500\u2500 */\n.fc:hover{background:var(--card2)}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 \u0627\u0644\u0640 confidence bar \u2500\u2500 */\n.conf-b{height:100%;border-radius:3px;transition:width .3s,background .4s}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 input fields \u2500\u2500 */\ninput[type=text],input[type=number]{font-family:var(--fo);background:var(--card);border:1px solid var(--brd2);border-radius:var(--radius-sm);color:var(--text);padding:8px 12px;font-size:12px;outline:none;transition:border-color .15s}\ninput[type=text]:focus,input[type=number]:focus{border-color:rgba(123,123,123,.4)}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 badge PERSIST \u2500\u2500 */\n#persist-stat{font-family:var(--fm);font-size:8px;color:var(--c1);letter-spacing:-.1px}\n/* \u2500\u2500 title status color \u2500\u2500 */\n.s-on .ttxt{color:var(--on);text-shadow:0 0 12px rgba(130,130,130,.4)}\n.s-off .ttxt{color:var(--off)}\n.s-zero .ttxt{color:var(--zero);text-shadow:0 0 12px rgba(130,130,130,.3)}\n/* \u2500\u2500 \u062a\u062d\u0633\u064a\u0646 section info card \u2500\u2500 */\n/* \u2500\u2500\u2500 Enhanced keyframes \u2500\u2500\u2500 */\n@keyframes pulse-ring{0%{box-shadow:0 0 0 0 rgba(130,130,130,.32)}70%{box-shadow:0 0 0 14px rgba(130,130,130,0)}100%{box-shadow:0 0 0 0 rgba(130,130,130,0)}}\n@keyframes ai-pulse{0%{box-shadow:0 0 0 0 rgba(123,123,123,.36)}70%{box-shadow:0 0 0 12px rgba(123,123,123,0)}100%{box-shadow:0 0 0 0 rgba(123,123,123,0)}}\n@keyframes rise{from{transform:translateY(6px);opacity:0}to{transform:translateY(0);opacity:1}}\n@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}\n/* \u2500\u2500\u2500 App \u2014 subtle background gradient \u2500\u2500\u2500 */\n.app{width:100%;height:var(--app-h,100vh);max-width:420px;margin:0 auto;position:relative;overflow:hidden;display:flex;flex-direction:column;align-items:center;background:radial-gradient(ellipse at 50% -10%,rgba(140,140,140,.04) 0%,var(--bg) 55%)}\n/* \u2500\u2500\u2500 Topbar \u2014 glass fade \u2500\u2500\u2500 */\n.topbar{position:relative;z-index:2;width:100%;display:flex;align-items:center;justify-content:space-between;padding:52px 22px 12px;background:linear-gradient(180deg,rgba(12,12,12,.98) 0%,rgba(12,12,12,0) 100%)}\n/* \u2500\u2500\u2500 Menu lines \u2014 better legibility \u2500\u2500\u2500 */\n.menu-btn span{display:block;height:2px;border-radius:1px;background:rgba(227,227,227,.35);transition:all .3s}\n.menu-btn:hover span,.menu-btn.open span:first-child{background:rgba(227,227,227,.7)}\n.menu-btn.open span:last-child{width:20px;transform:rotate(-45deg) translate(4px,-5px);background:rgba(123,123,123,.75)}\n/* \u2500\u2500\u2500 Circle \u2014 ON state ring pulse \u2500\u2500\u2500 */\n.s-on .cb{border-color:var(--on);background:rgba(130,130,130,.06);box-shadow:0 0 28px rgba(130,130,130,.12);animation:pulse-ring 2.8s ease-out infinite}\n/* \u2500\u2500\u2500 Circle label \u2014 state-aware glow \u2500\u2500\u2500 */\n.s-on .ai-lbl{color:var(--on);text-shadow:0 0 28px rgba(130,130,130,.55),0 0 60px rgba(130,130,130,.18)}\n.s-off .ai-lbl{color:rgba(227,227,227,.35)}\n.s-zero .ai-lbl{color:var(--zero);text-shadow:0 0 22px rgba(130,130,130,.45)}\n/* \u2500\u2500\u2500 AI score \u2500\u2500\u2500 */\n.c-sc{font-family:var(--fm);font-size:13px;position:relative;z-index:2;letter-spacing:.08em;color:transparent;transition:color .3s}\n.s-on .c-sc{color:rgba(130,130,130,.9)}\n/* \u2500\u2500\u2500 State text \u2500\u2500\u2500 */\n.c-st{font-family:var(--fm);font-size:8px;position:relative;z-index:2;letter-spacing:.16em;text-transform:uppercase;color:transparent;transition:color .3s}\n/* \u2500\u2500\u2500 Toggle pill \u2014 state-aware glow \u2500\u2500\u2500 */\n.s-on .tog-pill{border-color:var(--on);background:rgba(130,130,130,.05);box-shadow:0 0 22px rgba(130,130,130,.12),inset 0 0 24px rgba(130,130,130,.04)}\n.s-off .tog-pill{border-color:rgba(118,118,118,.4);background:rgba(118,118,118,.04)}\n.s-zero .tog-pill{border-color:var(--zero);background:rgba(130,130,130,.04);box-shadow:0 0 16px rgba(130,130,130,.1)}\n.tog-row:active .tog-pill{opacity:.8}\n/* \u2500\u2500\u2500 Toggle dot \u2014 larger \u2500\u2500\u2500 */\n.tdot{width:9px;height:9px;border-radius:50%;background:var(--dim);flex-shrink:0;transition:background .3s}\n/* \u2500\u2500\u2500 Title line \u2500\u2500\u2500 */\n.stit{font-size:14px;font-weight:700;margin-bottom:3px;transition:color .4s;text-align:center;color:var(--text);font-family:var(--fo);letter-spacing:-.2px;opacity:.9}\n.ssub{font-size:9px;color:var(--dim);text-align:center;margin-bottom:8px;font-family:var(--fo);letter-spacing:.05em;opacity:.5}\n/* \u2500\u2500\u2500 Silence indicator \u2500\u2500\u2500 */\n.sil-ind{display:flex;align-items:center;gap:6px;margin-bottom:10px;opacity:0;transition:opacity .4s;font-family:var(--fo);font-size:9px;color:var(--dim);letter-spacing:.04em}\n/* \u2500\u2500\u2500 Metric values \u2014 stronger weight \u2500\u2500\u2500 */\n.mv{font-family:var(--fm);font-size:15px;font-weight:800;line-height:1;transition:color .25s;letter-spacing:-.6px}\n/* \u2500\u2500\u2500 Metric labels \u2014 uppercase cairo \u2500\u2500\u2500 */\n.ml{font-family:var(--fo);font-size:7px;font-weight:800;letter-spacing:.14em;color:var(--dim);text-transform:uppercase}\n/* \u2500\u2500\u2500 Freq class cells \u2014 better hover \u2500\u2500\u2500 */\n.fc{display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 3px;border-radius:10px;border:1px solid var(--brd);background:var(--card);transition:background .18s,border-color .18s,transform .15s;min-width:0;cursor:default}\n.fc:active{transform:scale(.96)}\n.fc-val{font-family:var(--fm);font-size:11px;font-weight:800;color:var(--dim);transition:color .2s;letter-spacing:-.3px}\n.fc-lbl{font-family:var(--fo);font-size:7px;font-weight:700;color:var(--dim);text-align:center;line-height:1.3;letter-spacing:.03em}\n.fc-ico{font-size:12px;line-height:1}\n/* \u2500\u2500\u2500 Confidence bar \u2500\u2500\u2500 */\n.conf-w{width:165px;height:3px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden;margin-bottom:10px;opacity:0;transition:opacity .4s}\n/* \u2500\u2500\u2500 Bottom chevron \u2500\u2500\u2500 */\n.btm{position:absolute;bottom:0;left:50%;transform:translateX(-50%);z-index:3;padding-bottom:18px;cursor:pointer;opacity:.55;transition:opacity .2s}\n.btm:hover{opacity:.9}\n.chev{width:50px;height:30px;background:rgba(255,255,255,.04);border:1px solid var(--brd);border-radius:20px;display:flex;align-items:center;justify-content:center;border-color:rgba(255,255,255,.07);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}\n/* \u2500\u2500\u2500 AI button \u2014 pulsing glow \u2500\u2500\u2500 */\n.btn.ai{border-color:rgba(123,123,123,.35);color:var(--ai);background:rgba(123,123,123,.08);box-shadow:0 0 16px rgba(123,123,123,.1);animation:ai-pulse 4s ease-out infinite}\n.btn.ai:hover{background:rgba(123,123,123,.16);box-shadow:0 0 22px rgba(123,123,123,.18)}\n/* \u2500\u2500\u2500 Buttons base \u2500\u2500\u2500 */\n.btn{display:flex;align-items:center;gap:8px;padding:12px 22px;border-radius:50px;border:1px solid var(--brd2);background:var(--card);cursor:pointer;font-size:13px;font-weight:600;color:var(--text);transition:background .15s,transform .1s,box-shadow .15s;font-family:var(--fo)}\n.btn:active{opacity:.8;transform:scale(.97)}\n/* \u2500\u2500\u2500 Panel drag handle \u2500\u2500\u2500 */\n.phdl{display:flex;justify-content:center;padding:16px 0 8px;flex-shrink:0}\n.pbar{width:44px;height:4px;background:rgba(255,255,255,.15);border-radius:2px}\n/* \u2500\u2500\u2500 Panel title \u2500\u2500\u2500 */\n.ptit{font-size:20px;font-weight:800;color:var(--text);font-family:var(--fo);letter-spacing:-.4px}\n/* \u2500\u2500\u2500 Section labels \u2500\u2500\u2500 */\n.slbl{font-size:9px;font-weight:900;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.28);padding:18px 8px 8px;font-family:var(--fo)}\n/* \u2500\u2500\u2500 Settings cards \u2500\u2500\u2500 */\n.scard{background:var(--card);border:1px solid var(--brd);border-radius:var(--radius-lg);overflow:hidden;margin-bottom:10px;box-shadow:var(--shadow-card);transition:border-color .15s}\n.scard:hover{border-color:rgba(255,255,255,.12)}\n/* \u2500\u2500\u2500 Settings row \u2500\u2500\u2500 */\n.si{display:flex;align-items:center;gap:14px;padding:15px 18px;cursor:pointer;transition:background .15s;position:relative;min-height:54px}\n.sn{font-size:14px;font-weight:700;color:var(--text);margin-bottom:2px;font-family:var(--fo);letter-spacing:-.15px}\n.sd{font-size:11px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:var(--fo);letter-spacing:-.1px}\n/* \u2500\u2500\u2500 Icon container \u2500\u2500\u2500 */\n.iw{width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;background:rgba(255,255,255,.05);border:1px solid var(--brd);box-shadow:inset 0 1px 0 rgba(255,255,255,.06)}\n/* \u2500\u2500\u2500 Switch track \u2500\u2500\u2500 */\n.sw input:checked~.sw-t{background:var(--on);border-color:var(--on);box-shadow:0 0 10px rgba(130,130,130,.32),0 0 0 1px rgba(130,130,130,.25)}\n/* \u2500\u2500\u2500 Segment group buttons \u2500\u2500\u2500 */\n.sgb{display:flex;align-items:center;gap:5px;padding:7px 13px;border-radius:var(--radius-md);border:1px solid var(--brd);background:var(--card);font-size:12px;font-weight:700;color:var(--dim);cursor:pointer;transition:all .15s;font-family:var(--fo);letter-spacing:.02em}\n.sgb.act{border-color:rgba(140,140,140,.4);background:rgba(140,140,140,.1);color:var(--c5);box-shadow:0 0 10px rgba(140,140,140,.1)}\n/* \u2500\u2500\u2500 Section slider \u2500\u2500\u2500 */\n.shsl input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:17px;height:17px;border-radius:50%;background:var(--c5);cursor:pointer;box-shadow:0 0 8px rgba(140,140,140,.4)}\n/* \u2500\u2500\u2500 AI Panel \u2500\u2500\u2500 */\n#aiPanel{background:var(--surf);max-height:88vh;border-top-color:rgba(123,123,123,.18)}\n/* \u2500\u2500\u2500 AI panel header \u2500\u2500\u2500 */\n.ai-ph{display:flex;align-items:center;justify-content:space-between;padding:14px 20px 12px;flex-shrink:0;border-bottom:1px solid var(--brd);background:linear-gradient(180deg,rgba(123,123,123,.06) 0%,rgba(123,123,123,.02) 60%,transparent 100%)}\n/* \u2500\u2500\u2500 AI panel title \u2500\u2500\u2500 */\n.ai-ph-t{font-family:var(--fo);font-size:10px;font-weight:800;letter-spacing:.16em;color:var(--ai);text-transform:uppercase;display:flex;align-items:center;gap:8px}\n/* \u2500\u2500\u2500 Tab bar buttons \u2500\u2500\u2500 */\n.tbtn{font-family:var(--fo);font-size:9px;font-weight:700;letter-spacing:.07em;padding:5px 12px;border-radius:8px;border:1px solid var(--brd);background:transparent;color:var(--dim);cursor:pointer;white-space:nowrap;transition:all .15s;flex-shrink:0;text-transform:uppercase}\n.tbtn.act{border-color:rgba(130,130,130,.28);background:rgba(130,130,130,.1);color:var(--on);font-weight:700;box-shadow:0 0 10px rgba(130,130,130,.08)}\n/* \u2500\u2500\u2500 Stat cells \u2500\u2500\u2500 */\n.stat-c{background:rgba(255,255,255,.025);border:1px solid var(--brd);border-radius:10px;padding:8px 5px;text-align:center;transition:background .15s}\n.stat-c:hover{background:rgba(255,255,255,.04)}\n.stat-v{font-family:var(--fm);font-size:15px;font-weight:800;line-height:1;letter-spacing:-.5px}\n.stat-l{font-family:var(--fo);font-size:7px;font-weight:800;letter-spacing:.1em;color:var(--dim);margin-top:3px;text-transform:uppercase}\n/* \u2500\u2500\u2500 Info cards (nc) \u2500\u2500\u2500 */\n.nc{background:rgba(255,255,255,.02);border:1px solid var(--brd);border-radius:var(--radius-md);padding:10px 12px;box-shadow:0 1px 6px rgba(0,0,0,.3);backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}\n/* \u2500\u2500\u2500 Info card header \u2500\u2500\u2500 */\n.nc-h{font-family:var(--fo);font-size:9px;font-weight:800;letter-spacing:.12em;color:var(--c5);text-transform:uppercase;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--brd);border-bottom-color:rgba(140,140,140,.15)}\n/* \u2500\u2500\u2500 CC (2-col cards) \u2500\u2500\u2500 */\n.cc{border-radius:var(--radius-md);padding:8px 10px;border:1px solid var(--brd);background:var(--card);transition:border-color .15s}\n.cc:hover{border-color:var(--brd2)}\n.cc-h{font-family:var(--fo);font-size:9px;letter-spacing:.08em;text-transform:uppercase;margin-bottom:4px;display:flex;align-items:center;gap:5px;font-weight:800}\n.cc-v{font-family:var(--fm);font-size:14px;font-weight:800;margin-top:3px;letter-spacing:-.5px;font-variant-numeric:tabular-nums}\n.cc-b{font-family:var(--fo);font-size:8px;color:var(--muted);line-height:1.5;letter-spacing:.01em}\n/* \u2500\u2500\u2500 NN output grid \u2500\u2500\u2500 */\n.nov{font-family:var(--fm);font-size:13px;font-weight:800;letter-spacing:-.4px;font-variant-numeric:tabular-nums}\n.nol{font-family:var(--fo);font-size:7px;letter-spacing:.1em;color:var(--muted);margin-top:2px;font-weight:800;text-transform:uppercase}\n/* \u2500\u2500\u2500 Exec engine \u2500\u2500\u2500 */\n.exec-lbl{font-family:var(--fm);font-size:9px;letter-spacing:.2em;color:rgba(143,143,143,.7);font-weight:700}\n.exec-prog-curr{font-family:var(--fm);font-size:10px;letter-spacing:.06em;color:var(--text);padding:1px 7px;border-radius:4px;border:1px solid rgba(143,143,143,.2);background:rgba(143,143,143,.05);font-weight:700}\n.exec-cyc{font-family:var(--fm);font-size:9px;color:var(--muted);letter-spacing:.04em}\n.exec-sk{font-family:var(--fm);font-size:7px;letter-spacing:.1em;color:rgba(255,255,255,.25);text-transform:uppercase;font-weight:700}\n.exec-val{font-family:var(--fm);font-size:13px;font-weight:800;color:var(--zero);line-height:1.3;letter-spacing:-.3px}\n.exec-entry{border-left:2px solid rgba(143,143,143,.25);padding:5px 10px;background:rgba(143,143,143,.03);border-radius:0 7px 7px 0;margin-bottom:2px;transition:background .1s}\n.exec-prog{font-size:9px;font-weight:800;letter-spacing:.08em;color:var(--zero);text-transform:uppercase}\n.exec-lines{font-size:9px;color:var(--dim);line-height:1.6}\n/* \u2500\u2500\u2500 Exec input row \u2500\u2500\u2500 */\n.exec-inp{flex:1;padding:9px 12px;background:var(--bg);border:none;color:var(--zero);font-family:var(--fm);font-size:11px;outline:none;letter-spacing:.03em}\n.exec-btn{width:44px;display:flex;align-items:center;justify-content:center;background:rgba(143,143,143,.08);border:none;border-left:1px solid rgba(143,143,143,.15);cursor:pointer;color:var(--zero);font-size:17px;transition:background .18s;font-family:var(--fm)}\n/* \u2500\u2500\u2500 Status bar (as-t) \u2500\u2500\u2500 */\n.as-t{font-family:var(--fm);font-size:10px;letter-spacing:.08em;color:var(--ai);flex:1;font-weight:600}\n.as-c{font-family:var(--fm);font-size:9px;color:var(--muted);letter-spacing:.04em}\n/* \u2500\u2500\u2500 Plugin panel \u2500\u2500\u2500 */\n.pln{font-family:var(--fo);font-size:10px;letter-spacing:.04em;color:rgba(227,227,227,.45);font-weight:700}\n.pls{font-family:var(--fo);font-size:8px;letter-spacing:.06em;padding:2px 8px;border:1px solid var(--brd);border-radius:6px;color:var(--muted);text-transform:uppercase;transition:color .25s;font-weight:800}\n.plr{display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04);font-family:var(--fo);font-size:9px}\n.plrk{color:rgba(255,255,255,.3);font-weight:600}\n/* \u2500\u2500\u2500 Perm ban categories \u2500\u2500\u2500 */\n.pban-cat-name{font-family:var(--fo);font-size:11px;color:rgba(255,255,255,.85);font-weight:700;letter-spacing:-.1px}\n.pban-cat-desc{font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:1px;letter-spacing:.01em;line-height:1.4}\n.pban-cat-cnt{font-family:var(--fo);font-size:9px;padding:2px 7px;border-radius:20px;background:rgba(255,255,255,.07);color:var(--muted);flex-shrink:0;font-weight:800;letter-spacing:.04em}\n.pban-add-btn{background:rgba(143,143,143,.1);border:1px solid rgba(143,143,143,.22);border-radius:8px;padding:8px 14px;font-family:var(--fo);font-size:10px;color:var(--zero);cursor:pointer;white-space:nowrap;flex-shrink:0;font-weight:800;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Freq partition \u2500\u2500\u2500 */\n.part-lbl{font-family:var(--fo);font-size:9px;color:var(--muted);margin-bottom:3px;font-weight:700;letter-spacing:.05em}\n.part-val{font-family:var(--fm);font-size:13px;font-weight:800;letter-spacing:-.4px;font-variant-numeric:tabular-nums}\n.part-save-btn{width:100%;padding:9px;border-radius:10px;font-family:var(--fo);font-size:11px;text-align:center;cursor:pointer;background:rgba(143,143,143,.08);border:1px solid rgba(143,143,143,.25);color:var(--zero);margin-bottom:8px;font-weight:800;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Wake lock cards \u2500\u2500\u2500 */\n.wkv{font-family:var(--fm);font-size:15px;font-weight:800;transition:color .3s;letter-spacing:-.5px;font-variant-numeric:tabular-nums}\n.wkl{font-family:var(--fo);font-size:8px;letter-spacing:.1em;color:var(--muted);margin-top:2px;font-weight:800;text-transform:uppercase}\n/* \u2500\u2500\u2500 BG mode \u2500\u2500\u2500 */\n.bg-banner{position:fixed;top:0;left:50%;transform:translateX(-50%);width:100%;max-width:420px;z-index:100;padding:6px 16px;display:flex;align-items:center;gap:8px;background:rgba(12,12,12,.94);border-bottom:1px solid rgba(143,143,143,.3);opacity:0;pointer-events:none;transition:opacity .3s;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom-color:rgba(130,130,130,.22)}\n.bg-btxt{font-family:var(--fo);font-size:10px;letter-spacing:.04em;color:var(--zero);flex:1;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;font-weight:700}\n.bg-badge{display:none;align-items:center;gap:4px;padding:5px 10px;border-radius:10px;border:1px solid rgba(143,143,143,.3);background:rgba(143,143,143,.06);font-family:var(--fo);font-size:10px;letter-spacing:.04em;color:var(--zero);transition:background .18s;font-weight:700}\n.bg-h{font-family:var(--fo);font-size:9px;letter-spacing:.16em;color:rgba(143,143,143,.5);text-transform:uppercase;margin-bottom:6px;font-weight:800}\n.bg-k{color:var(--muted);font-family:var(--fo);font-size:9px;font-weight:600;letter-spacing:.02em}\n.bg-v{color:var(--zero);font-weight:700;font-family:var(--fm);font-size:9px;font-variant-numeric:tabular-nums}\n.bg-tgl{padding:7px 14px;border-radius:8px;border:1px solid rgba(143,143,143,.35);background:rgba(143,143,143,.07);color:var(--zero);font-family:var(--fo);font-size:10px;letter-spacing:.06em;cursor:pointer;transition:background .18s;width:100%;margin-top:6px;font-weight:800}\n/* \u2500\u2500\u2500 File storage \u2500\u2500\u2500 */\n.st-btn{display:flex;align-items:center;gap:4px;padding:5px 11px;border-radius:8px;border:1px solid var(--brd);background:var(--card);font-family:var(--fo);font-size:9px;color:var(--dim);cursor:pointer;transition:background .18s;white-space:nowrap;font-weight:700;letter-spacing:.04em}\n.st-fn{font-family:var(--fo);font-size:10px;color:var(--text);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}\n.st-fd{font-family:var(--fo);font-size:9px;color:var(--muted)}\n/* \u2500\u2500\u2500 Achievement items \u2500\u2500\u2500 */\n.ach-n{font-size:12px;font-weight:700;font-family:var(--fo);letter-spacing:-.1px}\n.ach-d{font-family:var(--fo);font-size:9px;color:var(--muted);letter-spacing:.01em}\n.ach-ck{font-family:var(--fm);font-size:12px;color:var(--zero);font-weight:700}\n/* \u2500\u2500\u2500 System status rows \u2500\u2500\u2500 */\n.sy{display:flex;align-items:center;gap:3px;padding:3px 7px;border-radius:6px;border:1px solid var(--brd);background:var(--card);font-family:var(--fo);font-size:8px;color:var(--muted);transition:border-color .2s;font-weight:700;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Perm status badges \u2500\u2500\u2500 */\n.ps-badge{font-family:var(--fo);font-size:9px;padding:3px 8px;border-radius:20px;background:rgba(255,255,255,.05);color:var(--muted);border:1px solid var(--brd);cursor:pointer;font-weight:700;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Thermal bars \u2500\u2500\u2500 */\n.therm-lbl{font-family:var(--fo);font-size:9px;font-weight:600;color:var(--dim);flex:1;letter-spacing:.04em}\n.therm-val{font-family:var(--fm);font-size:12px;font-weight:700;min-width:52px;text-align:right;letter-spacing:-.4px}\n/* \u2500\u2500\u2500 Slug panel \u2500\u2500\u2500 */\n.slug-lbl{font-family:var(--fo);font-size:9px;font-weight:600;color:var(--dim);letter-spacing:.05em}\n.slug-val{font-family:var(--fm);font-size:10px;font-weight:500;color:var(--text);letter-spacing:-.1px}\n/* \u2500\u2500\u2500 16-class cell \u2500\u2500\u2500 */\n.cls16-cell{padding:5px 2px;border-radius:8px;background:var(--card);border:1px solid var(--brd);text-align:center;transition:background .15s,border-color .15s}\n.cls16-cell:hover{background:var(--card2);border-color:var(--brd2)}\n.cls16-lbl{font-family:var(--fo);font-size:7px;font-weight:800;color:var(--dim);letter-spacing:.04em}\n.cls16-val{font-family:var(--fm);font-size:12px;font-weight:800;letter-spacing:-.3px}\n/* \u2500\u2500\u2500 Chroma bins \u2500\u2500\u2500 */\n.chroma-fill{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(180deg,var(--c5) 0%,rgba(140,140,140,.5) 100%);transition:height .3s}\n/* \u2500\u2500\u2500 Vote bars \u2500\u2500\u2500 */\n.vote-fill{height:100%;background:linear-gradient(90deg,var(--on) 0%,var(--sharp) 70%,var(--off) 100%);transition:width .4s}\n/* \u2500\u2500\u2500 Recurrence badge \u2500\u2500\u2500 */\n.recur-badge{font-family:var(--fo);font-size:8px;padding:1px 6px;border-radius:4px;background:rgba(130,130,130,.1);color:#828282;border:1px solid rgba(130,130,130,.2);font-weight:700;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Replay badge \u2500\u2500\u2500 */\n.replay-badge{font-family:var(--fo);font-size:8px;padding:1px 5px;border-radius:4px;background:rgba(143,143,143,.08);color:#8f8f8f;border:1px solid rgba(143,143,143,.15);font-weight:700;letter-spacing:.04em}\n/* \u2500\u2500\u2500 Ban panel header \u2500\u2500\u2500 */\n.ban-total-badge{font-family:var(--fo);font-size:10px;font-weight:700;padding:4px 12px;border-radius:20px;background:rgba(118,118,118,.1);color:var(--off);border:1px solid rgba(118,118,118,.2);letter-spacing:.04em}\n/* \u2500\u2500\u2500 Ban rows 2 (new style) \u2500\u2500\u2500 */\n.ban2-hz{font-family:var(--fm);font-size:10px;font-weight:700;flex:0 0 70px;letter-spacing:-.2px}\n.ban2-cat{font-family:var(--fm);font-size:7px;padding:1px 5px;border-radius:4px;flex-shrink:0;font-weight:900;text-transform:uppercase;letter-spacing:.06em}\n.ban2-why{font-family:var(--fo);font-size:9px;color:var(--muted);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.ban2-rmv{font-family:var(--fo);font-size:9px;color:var(--muted);cursor:pointer;padding:2px 8px;border-radius:5px;background:rgba(255,255,255,.05);flex-shrink:0;font-weight:600;transition:background .15s,color .15s,border-color .15s}\n.ban2-rmv:hover{background:rgba(118,118,118,.1);color:var(--off);border-color:rgba(118,118,118,.2)}\n/* \u2500\u2500\u2500 Terminal \u2500\u2500\u2500 */\n#termPanel{background:#080808;border-top-color:rgba(143,143,143,.25);max-height:92vh}\n.term-ph{display:flex;align-items:center;justify-content:space-between;padding:10px 14px 8px;border-bottom:1px solid rgba(143,143,143,.15);flex-shrink:0;border-bottom-color:rgba(130,130,130,.12);background:rgba(0,0,0,.4)}\n.term-ph-t{font-family:var(--fm);font-size:10px;letter-spacing:.16em;color:var(--zero);font-weight:700}\n.term-ctl{font-family:var(--fo);font-size:8px;padding:3px 8px;border-radius:4px;border:1px solid var(--brd);background:var(--card);color:var(--dim);cursor:pointer;letter-spacing:.04em;transition:background .15s;font-weight:700}\n.term-ctl.active{border-color:rgba(143,143,143,.4);color:var(--zero);background:rgba(143,143,143,.06);box-shadow:0 0 8px rgba(130,130,130,.1)}\n.tl-ts{color:rgba(130,130,130,.28);flex-shrink:0;width:72px;font-size:9px;font-family:var(--fm)}\n.tl-tag{flex-shrink:0;width:52px;font-weight:800;font-size:9px;letter-spacing:.04em;font-family:var(--fm)}\n.tl-body{flex:1;min-width:0;white-space:pre-wrap;word-break:break-all;font-family:var(--fm);font-size:9px;line-height:1.6}\n.tl-sub{padding-left:124px;color:rgba(255,255,255,.35);font-size:8px;white-space:pre-wrap;font-style:italic;font-family:var(--fm)}\n.tl-cnt{color:rgba(132,132,132,.85);font-weight:800;font-size:8px;background:rgba(132,132,132,.12);border-radius:3px;padding:0 4px;margin-right:4px}\n/* \u2500\u2500\u2500 CSS comment header refinement \u2500\u2500 */\n/* \u2500\u2500 ZERO AI v25 \u2500\u2500 */\n/* \u2500\u2500 PERMS MGMT PANEL \u2500\u2500 */\n.zp-ph{display:flex;align-items:center;justify-content:space-between;padding:14px 20px 12px;flex-shrink:0;border-bottom:1px solid var(--brd);background:linear-gradient(180deg,rgba(129,129,129,.06) 0%,transparent 100%)}\n.zp-ph-t{font-family:var(--fo);font-size:11px;font-weight:800;letter-spacing:.12em;color:var(--c5);text-transform:uppercase;display:flex;align-items:center;gap:8px}\n.zp-scr{overflow-y:auto;flex:1;padding:12px 16px 28px;display:flex;flex-direction:column;gap:10px}\n.zp-row{background:var(--card);border:1px solid var(--brd);border-radius:12px;padding:13px 14px;display:flex;flex-direction:column;gap:9px}\n.zp-rt{display:flex;align-items:center;gap:11px}\n.zp-ico{font-size:20px;flex-shrink:0}\n.zp-meta{flex:1}\n.zp-nm{font-family:var(--fo);font-size:11px;font-weight:700;color:rgba(255,255,255,.88)}\n.zp-ds{font-family:var(--fm);font-size:9px;color:var(--muted);margin-top:2px;line-height:1.4}\n.zp-mb{width:100%;padding:10px 14px;border-radius:10px;font-family:var(--fo);font-size:10px;font-weight:700;letter-spacing:.04em;border:none;cursor:pointer;transition:background .15s,opacity .15s;text-align:center}\n.zp-mb.req{background:rgba(129,129,129,.15);color:var(--c5);border:1px solid rgba(129,129,129,.3)}\n.zp-mb.req:active{background:rgba(129,129,129,.25)}\n.zp-mb.ok{background:rgba(130,130,130,.12);color:var(--on);border:1px solid rgba(130,130,130,.25);opacity:.8;cursor:default}\n.zp-mb.retry{background:rgba(123,123,123,.12);color:var(--off);border:1px solid rgba(123,123,123,.25)}\n.zp-mb.retry:active{background:rgba(123,123,123,.22)}\n.zp-err{font-family:var(--fm);font-size:9px;color:rgba(159,159,159,.9);background:rgba(123,123,123,.07);border:1px solid rgba(123,123,123,.18);border-radius:8px;padding:8px 10px;line-height:1.6;direction:rtl}\n/* \u2500\u2500 DEVICE MONITOR PANEL v3 \u2500\u2500 */\n#devPanel{max-height:88vh}\n.dm-ph{display:flex;align-items:center;justify-content:space-between;padding:14px 20px 12px;flex-shrink:0;border-bottom:1px solid rgba(255,255,255,.07)}\n.dm-ph-t{font-family:var(--fo);font-size:10px;font-weight:800;letter-spacing:.22em;text-transform:uppercase;color:rgba(255,255,255,.65)}\n.dm-scr{overflow-y:auto;overflow-x:hidden;flex:1;padding:0 0 4px;display:flex;flex-direction:column;-webkit-overflow-scrolling:touch;scroll-behavior:smooth}\n.dm-sec{padding:14px 20px;border-bottom:1px solid rgba(255,255,255,.055)}\n.dm-sec:last-child{border-bottom:none}\n.dm-sec::before{display:none}\n.dm-sec-h{display:flex;align-items:center;justify-content:space-between;margin-bottom:11px}\n.dm-ico{display:none}\n.dm-sec-t{font-family:var(--fo);font-size:8px;font-weight:800;letter-spacing:.22em;text-transform:uppercase;color:rgba(255,255,255,.25)}\n.dm-badge{font-family:var(--fm);font-size:8px;font-weight:700}\n.dm-badge.hot{color:#808080}.dm-badge.warm{color:#b0b0b0}.dm-badge.cool{color:rgba(255,255,255,.28)}.dm-badge.ok{color:#858585}\n.dm-rows{display:flex;flex-direction:column;gap:10px}\n.dm-r{display:flex;align-items:center;gap:8px}\n.dm-k{font-family:var(--fm);font-size:8.5px;color:rgba(255,255,255,.28);flex-shrink:0;width:86px}\n.dm-v{font-family:var(--fm);font-size:12px;font-weight:700;color:rgba(255,255,255,.82);font-variant-numeric:tabular-nums;flex:1}\n.dm-bar-w{width:64px;height:2px;background:rgba(255,255,255,.08);flex-shrink:0;position:relative;overflow:hidden}\n.dm-bar{position:absolute;left:0;top:0;height:100%;transition:width .7s cubic-bezier(.4,0,.2,1)}\n.dm-bar.cpu{background:#929292}.dm-bar.ram{background:#828282}.dm-bar.bat{background:#8f8f8f}.dm-bar.hot{background:#808080}\n.dm-th-list{display:flex;flex-direction:column;gap:13px}\n.dm-th-row{display:flex;flex-direction:column;gap:4px}\n.dm-th-name{font-family:var(--fm);font-size:8px;color:rgba(255,255,255,.25);letter-spacing:.04em}\n.dm-th-fill-row{display:flex;align-items:center;gap:10px}\n.dm-th-fill-w{flex:1;height:2px;background:rgba(255,255,255,.07);position:relative;overflow:hidden}\n.dm-th-fill{position:absolute;left:0;top:0;height:100%;transition:width .85s cubic-bezier(.4,0,.2,1)}\n.dm-th-fill.cool{background:rgba(255,255,255,.38)}.dm-th-fill.warm{background:#b0b0b0}.dm-th-fill.hot{background:#808080}\n.dm-th-val{font-family:var(--fm);font-size:11px;font-weight:700;font-variant-numeric:tabular-nums;white-space:nowrap;text-align:right;min-width:148px}\n.dm-th-val.cool{color:rgba(255,255,255,.72)}.dm-th-val.warm{color:#b0b0b0}.dm-th-val.hot{color:#808080}\n.dm-refresh{display:flex;align-items:center;gap:7px;padding:10px 20px;border-top:1px solid rgba(255,255,255,.06);flex-shrink:0}\n.dm-scrl-btn{width:30px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:3px;border:1px solid rgba(255,255,255,.1);background:transparent;color:rgba(255,255,255,.32);font-size:13px;cursor:pointer;transition:all .12s;user-select:none;flex-shrink:0}\n.dm-scrl-btn:active{background:rgba(255,255,255,.06);color:rgba(255,255,255,.7)}\n.dm-ref-btn{padding:5px 13px;border-radius:3px;border:1px solid rgba(255,255,255,.1);background:transparent;color:rgba(255,255,255,.3);font-family:var(--fo);font-size:8px;font-weight:700;letter-spacing:.1em;cursor:pointer;transition:all .15s;text-transform:uppercase}\n.dm-ref-btn:active{background:rgba(255,255,255,.05);color:rgba(255,255,255,.6)}\n.dm-live-dot{width:5px;height:5px;border-radius:50%;background:rgba(255,255,255,.2);animation:bk 1.3s ease-in-out infinite;flex-shrink:0}\n.dm-ts{font-family:var(--fm);font-size:8px;color:rgba(255,255,255,.18);font-variant-numeric:tabular-nums;flex:1}\n/* \u2500\u2500 NOTCH FILTER SECTION \u2500\u2500 */\n.notch-item{display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px solid var(--brd)}\n.notch-item:last-child{border-bottom:none}\n.notch-hz{font-family:var(--fm);font-size:9px;color:var(--on);font-weight:700}\n.notch-meta{font-family:var(--fm);font-size:7.5px;color:var(--muted)}\n.notch-rm{font-size:8px;padding:1px 6px;border-radius:5px;border:1px solid var(--brd);background:var(--card);color:var(--dim);cursor:pointer;line-height:1.4}\n.notch-rm:active{opacity:.6}\n/* \u2500\u2500 SPECTROGRAM \u2500\u2500 */\n#specCv{width:100%;height:48px;background:#000;border-radius:4px;display:block;image-rendering:pixelated}\n/* \u2500\u2500 POWER PRESETS \u2500\u2500 */\n.preset-row{display:flex;gap:6px;margin-top:8px}\n.preset-btn{flex:1;padding:8px 4px;border-radius:10px;border:1px solid var(--brd2);background:var(--card);color:var(--dim);font-family:var(--fo);font-size:9px;font-weight:700;letter-spacing:.03em;cursor:pointer;transition:all .15s;text-align:center}\n.preset-btn.act{background:rgba(130,130,130,.12);color:var(--on);border-color:rgba(130,130,130,.35);box-shadow:0 0 8px rgba(130,130,130,.1)}\n.preset-btn:active{opacity:.7;transform:scale(.97)}\n.preset-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:10px;font-family:var(--fm);font-size:8px;font-weight:700;margin-left:6px}\n.preset-badge.throttle-on{background:rgba(123,123,123,.15);color:#888888;border:1px solid rgba(123,123,123,.28)}\n/* \u2500\u2500 SESSION STATS TAB \u2500\u2500 */\n.stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;padding:4px 0}\n.stat-card{background:var(--card);border:1px solid var(--brd);border-radius:10px;padding:10px 12px}\n.stat-lbl{font-family:var(--fm);font-size:7px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px}\n.stat-val{font-family:var(--fm);font-size:14px;font-weight:800;color:var(--text);font-variant-numeric:tabular-nums;letter-spacing:-.3px}\n.stat-val.green{color:var(--on)}.stat-val.yellow{color:var(--c3)}.stat-val.red{color:var(--off)}\n/* \u2500\u2500 THROTTLE INDICATOR \u2500\u2500 */\n.therm-badge{display:none;align-items:center;gap:5px;padding:3px 9px;border-radius:8px;background:rgba(123,123,123,.14);border:1px solid rgba(123,123,123,.3);color:#888888;font-family:var(--fm);font-size:8px;font-weight:700;animation:bk 1.5s infinite;margin-left:8px}\n/* \u2500\u2500 THERMAL ALERT BANNER \u2500\u2500 */\n.dm-alert{position:fixed;top:calc(52px + env(safe-area-inset-top,0px));left:16px;right:16px;z-index:9000;display:flex;align-items:center;gap:10px;padding:11px 15px;border-radius:12px;background:rgba(86,86,86,.96);backdrop-filter:blur(8px);color:#fff;font-family:var(--fo);font-size:11px;font-weight:700;letter-spacing:.02em;box-shadow:0 4px 24px rgba(106,106,106,.5);animation:slideDown .3s ease;direction:rtl}\n.dm-alert-ico{font-size:18px;flex-shrink:0}\n.dm-alert-txt{flex:1;line-height:1.4}\n.dm-alert-cl{opacity:.75;cursor:pointer;padding:2px 6px;font-size:15px;font-weight:400;flex-shrink:0}\n@keyframes slideDown{from{opacity:0;transform:translateY(-14px)}to{opacity:1;transform:translateY(0)}}\n/* \u2500\u2500 DM SPARKLINES \u2500\u2500 */\n.dm-spark-row{display:flex;gap:12px;margin-top:8px}\n.dm-spark-box{flex:1}\n.dm-spark-lbl{font-family:var(--fm);font-size:7.5px;color:rgba(255,255,255,.25);text-transform:uppercase;letter-spacing:.07em;margin-bottom:5px}\n.dm-spark-svg{width:100%;height:28px;display:block;overflow:visible}\n/* \u2500\u2500 DM STORAGE \u2500\u2500 */\n.dm-stor-bar-w{height:2px;background:rgba(255,255,255,.07);margin:7px 0 4px;position:relative;overflow:hidden}\n.dm-stor-bar{position:absolute;left:0;top:0;height:100%;transition:width .7s}\n.dm-stor-bar.int{background:#959595}\n.dm-stor-bar.ext{background:#cccccc}\n/* \u2500\u2500 DM NETWORK \u2500\u2500 */\n.dm-net-chip{display:inline-flex;align-items:center;gap:5px;font-family:var(--fm);font-size:9px;font-weight:700;margin-bottom:8px;border:none;padding:0;background:none}\n.dm-net-chip.online{color:#858585}\n.dm-net-chip.offline{color:#7c7c7c}\n.dm-net-dot{width:4px;height:4px;border-radius:50%;background:currentColor;flex-shrink:0}\n/* \u2500\u2500 ENVIRONMENT CLASSIFIER \u2500\u2500 */\n.env-label{display:none;align-items:center;gap:7px;margin:5px 0 2px;padding:5px 12px;border-radius:10px;background:var(--card);border:1px solid var(--brd);font-family:var(--fm);font-size:9px;font-weight:700;letter-spacing:.05em}\n.env-dot{width:7px;height:7px;border-radius:50%;background:var(--on);flex-shrink:0;box-shadow:0 0 6px currentColor;transition:background .4s}\n.env-lbl-txt{flex:1;color:var(--text)}\n.env-conf{font-size:7.5px;color:var(--muted);font-weight:400}\n/* \u2500\u2500 FREQ TIMELINE \u2500\u2500 */\n#freqTimeCv{width:100%;height:52px;display:block;border-radius:4px;background:rgba(0,0,0,.35);image-rendering:pixelated}\n/* \u2500\u2500 INPUT LEVEL METER \u2500\u2500 */\n.lvl-meter{display:none;align-items:center;gap:8px;padding:4px 12px;border-radius:8px;background:var(--card);border:1px solid var(--brd);margin:3px 0}\n.lvl-bar-wrap{flex:1;height:5px;background:rgba(255,255,255,.07);border-radius:3px;overflow:hidden;position:relative}\n.lvl-bar-rms{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--on),var(--sharp));transition:width .06s linear}\n.lvl-peak-tick{position:absolute;top:0;width:2px;height:100%;background:rgba(255,255,255,.5);transition:left .15s}\n.lvl-db{font-family:var(--fm);font-size:8px;color:var(--muted);min-width:38px;text-align:right}\n.lvl-clip{font-family:var(--fm);font-size:7.5px;font-weight:700;color:var(--off);opacity:0;transition:opacity .1s;letter-spacing:.08em}\n.lvl-clip.on{opacity:1}\n/* \u2500\u2500 SCENE BADGE \u2500\u2500 */\n.scene-badge{display:none;font-family:var(--fm);font-size:8px;color:var(--ai);background:rgba(123,123,123,.1);border:1px solid rgba(123,123,123,.25);border-radius:6px;padding:2px 8px;margin:2px 0;text-align:center}\n.scene-badge.visible{display:block}\n/* \u2500\u2500 FREQ HOP INDICATOR \u2500\u2500 */\n.freq-hop-flash{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--sharp);opacity:0;transition:opacity .5s;margin-left:5px;vertical-align:middle;flex-shrink:0}\n.freq-hop-ct{font-family:var(--fm);font-size:8px;color:var(--muted);margin-left:auto;padding-right:2px}\n/* \u2500\u2500 SUPPRESSION EFF BADGE \u2500\u2500 */\n.supp-eff{font-family:var(--fm);font-size:8px;margin-left:6px;font-weight:700}\n/* \u2500\u2500 TAP-TO-NOTCH CROSSHAIR \u2500\u2500 */\n#pane0 canvas,#freqTimeCv{cursor:crosshair}\n/* \u2500\u2500 \u0634\u0627\u0634\u0629 \u062a\u0639\u0631\u064a\u0641\u064a\u0629 \u0644\u0623\u0648\u0644 \u062a\u0634\u063a\u064a\u0644 (29 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u0623\u0639\u0644\u0649 \u0645\u0646 dm-alert (9000) \u0644\u0636\u0645\u0627\u0646 \u0638\u0647\u0648\u0631\u0647\u0627 \u0641\u0648\u0642 \u0623\u064a \u0634\u064a\u0621 \u2500\u2500 */\n.onb-ovl{position:fixed;top:0;left:0;right:0;bottom:var(--vv-bottom-inset,0px);z-index:9999;background:rgba(0,0,0,.92);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:22px;box-sizing:border-box;opacity:0;pointer-events:none;transition:opacity .35s ease}\n.onb-ovl.onb-show{opacity:1;pointer-events:auto}\n.onb-card{direction:rtl;width:100%;max-width:380px;max-height:100%;overflow-y:auto;background:var(--surf);border:1px solid var(--brd2);border-radius:var(--radius-xl);padding:26px 22px 22px;box-shadow:var(--shadow-panel);font-family:var(--fo)}\n.onb-logo{font-family:var(--fu);font-size:26px;font-weight:900;letter-spacing:2px;color:var(--zero);text-align:center;margin-bottom:8px}\n.onb-tag{font-size:11px;color:var(--dim);text-align:center;line-height:1.7;margin-bottom:18px}\n.onb-sec-t{font-size:12px;font-weight:700;color:var(--text);margin-bottom:4px}\n.onb-sec-d{font-size:10.5px;color:var(--dim);line-height:1.7;margin-bottom:14px}\n.onb-mechs{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}\n.onb-mech{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:10px;background:var(--card);border:1px solid var(--brd)}\n.onb-mech-ic{width:20px;flex-shrink:0;text-align:center;font-size:13px;color:var(--on)}\n.onb-mech-txt{flex:1;min-width:0}\n.onb-mech-t{font-size:10.5px;font-weight:700;color:var(--text)}\n.onb-mech-d{font-size:9px;color:var(--muted);margin-top:1px}\n.onb-cls16{font-size:9.5px;color:var(--muted);text-align:center;line-height:1.7;margin-bottom:18px;padding-top:12px;border-top:1px solid var(--brd)}\n.onb-btn{width:100%;padding:13px;border:none;border-radius:14px;background:var(--on);color:#0c0c0c;font-family:var(--fo);font-size:13px;font-weight:800;letter-spacing:.02em;cursor:pointer}\n";
  document.head.appendChild(_s);
  document.body.insertAdjacentHTML('beforeend', "<div class=\"app s-off\" id=\"app\">\n <div class=\"bg-w\"><div class=\"bg-grid\"></div><div class=\"bg-orb bg-o1\"></div><div class=\"bg-orb bg-o2\"></div><div class=\"bg-orb bg-o3\"></div></div>\n <!-- \u2550\u2550 \u0634\u0627\u0634\u0629 \u062a\u0639\u0631\u064a\u0641\u064a\u0629 \u0644\u0623\u0648\u0644 \u062a\u0634\u063a\u064a\u0644 (29 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u062a\u0638\u0647\u0631 \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u0641\u0642\u0637 \u0642\u0628\u0644 \u0623\u064a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0641\u0639\u0644\u064a\u060c\n \u062a\u0634\u0631\u062d \u0622\u0644\u064a\u0629 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0635\u0627\u0645\u062a \u0627\u0644\u062d\u0642\u064a\u0642\u064a\u0629 (5 \u0622\u0644\u064a\u0627\u062a \u062a\u0631\u062f\u062f\u064a\u0629 \u0641\u064a\u0632\u064a\u0627\u0626\u064a\u0629 \u0641\u0639\u0644\u064a\u0629\u060c \u0645\u0646\u0642\u0648\u0644\u0629 \u062d\u0631\u0641\u064a\u0627\u064b \u0645\u0646 \u0646\u0641\u0633\n \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d \u0627\u0644\u0645\u0648\u062c\u0648\u062f\u0629 \u0641\u064a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u2014 \u0644\u0627 \u0646\u0635 \u062a\u0633\u0648\u064a\u0642\u064a \u062c\u062f\u064a\u062f)\u060c \u062b\u0645 \u062a\u064f\u062e\u0641\u0649 \u0646\u0647\u0627\u0626\u064a\u0627\u064b \u0639\u0628\u0631 \u0639\u0644\u0627\u0645\u0629 localStorage\n (\u0646\u0641\u0633 \u0646\u0645\u0637 \u0627\u0644\u0627\u0633\u062a\u0645\u0631\u0627\u0631\u064a\u0629 \u0627\u0644\u0645\u062a\u0651\u0628\u0639 \u0641\u064a PERSIST) \u2014 \u0631\u0627\u062c\u0639 dismissOnboarding() \u0641\u064a 11-terminal-logging.js \u2550\u2550 -->\n <div class=\"onb-ovl\" id=\"onbOverlay\">\n <div class=\"onb-card\">\n <div class=\"onb-logo\">ZERO</div>\n <div class=\"onb-tag\">\u0644\u0627 \u062a\u0634\u063a\u064a\u0644 \u0635\u0648\u062a \u0645\u0636\u0627\u062f \u2014 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0647\u0646\u0627 \u064a\u0639\u0645\u0644 \u0628\u062a\u0631\u062f\u062f\u0627\u062a \u0635\u0627\u0645\u062a\u0629 \u062a\u0645\u0627\u0645\u0627\u064b\u060c \u0644\u0627 \u062a\u0633\u0645\u0639\u0647\u0627 \u0623\u0630\u0646\u0643 \u0648\u0644\u0627 \u064a\u0633\u0645\u0639\u0647\u0627 \u0645\u0646 \u062d\u0648\u0644\u0643</div>\n <div class=\"onb-sec-t\">\u0643\u064a\u0641 \u064a\u0639\u0645\u0644 \u0627\u0644\u0625\u0644\u063a\u0627\u0621\u061f</div>\n <div class=\"onb-sec-d\">\u064a\u062d\u0644\u0651\u0644 \u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u064a\u0637\u0629 \u0644\u062d\u0638\u064a\u0627\u064b\u060c \u062b\u0645 \u064a\u0633\u062a\u0647\u062f\u0641\u0647\u0627 \u0628\u062e\u0645\u0633 \u0622\u0644\u064a\u0627\u062a \u0635\u0627\u0645\u062a\u0629 \u0641\u064a\u0632\u064a\u0627\u0626\u064a\u0627\u064b:</div>\n <div class=\"onb-mechs\">\n <div class=\"onb-mech\"><div class=\"onb-mech-ic\">\u3030</div><div class=\"onb-mech-txt\"><div class=\"onb-mech-t\">Infrasound &lt;20Hz</div><div class=\"onb-mech-d\">\u0625\u0636\u0639\u0627\u0641 \u0627\u0644\u0636\u063a\u0637 \u2014 \u063a\u064a\u0631 \u0645\u0633\u0645\u0648\u0639</div></div></div>\n <div class=\"onb-mech\"><div class=\"onb-mech-ic\">\u2191\u2191</div><div class=\"onb-mech-txt\"><div class=\"onb-mech-t\">Ultrasound &gt;20kHz</div><div class=\"onb-mech-d\">\u0643\u0633\u0631 \u0627\u0644\u062a\u0645\u0627\u0633\u0643 \u2014 \u063a\u064a\u0631 \u0645\u0633\u0645\u0648\u0639</div></div></div>\n <div class=\"onb-mech\"><div class=\"onb-mech-ic\">\u2295</div><div class=\"onb-mech-txt\"><div class=\"onb-mech-t\">Phase Coherent Field</div><div class=\"onb-mech-d\">\u0645\u0646\u0637\u0642\u0629 \u062a\u0645\u0627\u0633\u0643 \u0635\u0627\u0645\u062a\u0629 \u2014 \u0641\u064a\u0632\u064a\u0627\u0626\u064a\u0629</div></div></div>\n <div class=\"onb-mech\"><div class=\"onb-mech-ic\">\u3031</div><div class=\"onb-mech-txt\"><div class=\"onb-mech-t\">Sub-1Hz Reset</div><div class=\"onb-mech-d\">\u0627\u0647\u062a\u0632\u0627\u0632 \u0623\u0633\u0627\u0633 0.01\u20130.95Hz</div></div></div>\n <div class=\"onb-mech\"><div class=\"onb-mech-ic\">\u224b</div><div class=\"onb-mech-txt\"><div class=\"onb-mech-t\">Piezoelectric Structural</div><div class=\"onb-mech-d\">\u0625\u0644\u063a\u0627\u0621 \u0631\u0646\u064a\u0646 \u0627\u0644\u0645\u0648\u0627\u062f</div></div></div>\n </div>\n <div class=\"onb-cls16\">\u062a\u0635\u0646\u064a\u0641 \u062a\u0644\u0642\u0627\u0626\u064a \u0628\u064016 \u0641\u0626\u0629 \u062a\u0631\u062f\u062f\u064a\u0629 \u0644\u0643\u0644 \u062a\u0631\u062f\u062f \u0645\u0643\u062a\u0634\u064e\u0641 \u062d\u0633\u0628 \u0637\u0628\u064a\u0639\u062a\u0647 \u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0626\u064a\u0629 \u2014 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062a\u062e\u0635\u064a\u0635 \u0644\u0627\u062d\u0642\u0627\u064b \u0645\u0646 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a</div>\n <button class=\"onb-btn\" id=\"onbGo\" onclick=\"dismissOnboarding()\">\u0627\u0628\u062f\u0623</button>\n </div>\n </div>\n <div class=\"topbar\">\n <div class=\"menu-btn\" id=\"mBtn\" onclick=\"toggleMenu()\"><span></span><span></span></div>\n <!-- badge \u062d\u0627\u0644\u0629 \u0627\u0644\u062e\u0644\u0641\u064a\u0629 BG: \u0623\u064f\u0632\u064a\u0644 onclick (\u0643\u0627\u0646 \u0627\u062e\u062a\u0635\u0627\u0631\u0627\u064b \u0644\u0641\u062a\u062d \u062a\u0628\u0648\u064a\u0628 BG \u0641\u064a AI Brain) \u0628\u062a\u0627\u0631\u064a\u062e\n 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u2014 \u0628\u0637\u0644\u0628 \"\u062d\u0630\u0641 \u0643\u0644 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0648\u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u0649 \u0632\u0631 \u062a\u0634\u063a\u064a\u0644/\u0625\u064a\u0642\u0627\u0641 \u0648\u0627\u062d\u062f\": \u0623\u0635\u0628\u062d \u0639\u0631\u0636 \u062d\u0627\u0644\u0629\n \u0628\u062d\u062a \u0628\u0644\u0627 \u0623\u064a \u0641\u0639\u0644 \u0646\u0642\u0631\u061b \u0646\u0641\u0633 \u0627\u0644\u0648\u062c\u0647\u0629 (\u062a\u0628\u0648\u064a\u0628 BG) \u062a\u0628\u0642\u0649 \u0645\u062a\u0627\u062d\u0629 \u0639\u0628\u0631 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u2190 \u062f\u0645\u0627\u063a AI \u2190 BG. -->\n <div class=\"topbar-r\"><div class=\"bg-badge\" id=\"bgBadge\"><div class=\"bg-bdot2\"></div><span id=\"bgBadgeTxt\">BG</span></div></div>\n </div>\n <div class=\"bg-banner\" id=\"bgBanner\"><div class=\"bg-bdot\"></div><span class=\"bg-btxt\" id=\"bgBTxt\">ZERO AI active in background</span><span class=\"bg-bcl\" onclick=\"hideBgBanner()\">\u2715</span></div>\n <!-- \u2550\u2550 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u2014 \u0623\u0632\u0631\u0627\u0631 \u062a\u0634\u063a\u064a\u0644 \u062a\u0641\u062a\u062d \u0646\u0648\u0627\u0641\u0630\u060c \u0648\u0627\u0644\u0646\u0648\u0627\u0641\u0630 \u062a\u062a\u0636\u0645\u0646 \u0623\u0632\u0631\u0627\u0631 \u062a\u0634\u063a\u064a\u0644\u0647\u0627 \u0627\u0644\u062e\u0627\u0635\u0629 \u2550\u2550 -->\n <div class=\"home\" id=\"homeScr\">\n <div class=\"home-status\" id=\"homeStatus\">\n <div class=\"home-status-dot\" id=\"homeDot\"></div>\n <div class=\"home-status-txt\">\n <div class=\"home-status-t1\" id=\"homeT1\">\u0645\u062a\u0648\u0642\u0641</div>\n <div class=\"home-status-t2\" id=\"homeT2\">ZERO \u2014 \u062c\u0627\u0647\u0632 \u0644\u0644\u062a\u0634\u063a\u064a\u0644</div>\n </div>\n <button class=\"home-run-btn off\" id=\"homeRunBtn\" onclick=\"toggleAI(event)\">\u25b6 \u062a\u0634\u063a\u064a\u0644</button>\n </div>\n </div>\n\n<!-- LIVE TERMINAL PANEL \u2014 \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a \u0627\u0644\u062a\u0641\u0627\u0639\u0644\u064a\u0629 \u0643\u0627\u0645\u0644\u0629 \u0641\u064a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 (\"\u062a\u062c\u0645\u064a\u0639 \u0643\u0644 \u0627\u0644\u0623\u0641\u0643\u0627\u0631\"):\n \u0643\u0627\u0646\u062a \u0644\u0648\u062d\u0629 \u0627\u0644\u0637\u0631\u0641\u064a\u0629 \u0627\u0644\u062a\u0641\u0627\u0639\u0644\u064a\u0629 (\u062a\u0635\u0641\u064a\u0629 8 \u0641\u0626\u0627\u062a + \u062a\u0646\u0641\u064a\u0630 \u0623\u0648\u0627\u0645\u0631) \u0642\u062f \u062d\u064f\u0630\u0641\u062a \u0633\u0627\u0628\u0642\u0627\u064b \u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645\n \u0644\u0635\u0627\u0644\u062d \u0645\u0631\u0627\u0642\u0628\u0629 SYS/WARN/ERR \u0641\u0642\u0637. \u0623\u064f\u0639\u064a\u062f\u062a \u0627\u0644\u0622\u0646 \u0627\u0644\u062a\u0635\u0641\u064a\u0629 (ALL/FREQ/NN/EXEC/INV/SF/COH/SYS)\n \u0648\u062d\u0642\u0644 \u062a\u0646\u0641\u064a\u0630 \u0627\u0644\u0623\u0648\u0627\u0645\u0631 (\u064a\u064f\u0645\u0631\u064e\u0651\u0631 \u0625\u0644\u0649 #execInp/runExecCmd \u0643\u0645\u0627 \u0643\u0627\u0646 \u062a\u0645\u0627\u0645\u0627\u064b) \u0641\u0648\u0642 \u0646\u0641\u0633 \u0627\u0644\u0628\u0646\u064a\u0629\n \u0627\u0644\u0645\u064f\u062d\u0633\u064e\u0651\u0646\u0629 \u0627\u0644\u062a\u064a \u062a\u0631\u0627\u0643\u0645\u062a \u0644\u0627\u062d\u0642\u0627\u064b (\u062a\u062c\u0645\u064a\u0639 \u0627\u0644\u062a\u0643\u0631\u0627\u0631\u0627\u062a + \u0627\u0633\u062a\u0645\u0631\u0627\u0631\u064a\u0629 localStorage + \u062a\u0635\u062f\u064a\u0631 TXT) \u2014\n \u062f\u064f\u0645\u062c \u0627\u0644\u0627\u062b\u0646\u0627\u0646 \u0628\u0644\u0627 \u062a\u0639\u0627\u0631\u0636: \u0627\u0644\u062a\u0635\u0641\u064a\u0629 \u0627\u0644\u0622\u0646 \u062a\u062a\u062d\u0643\u0645 \u0628\u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u062d\u064a\u0651 (tFilter)\u060c \u0628\u064a\u0646\u0645\u0627 \u062a\u062c\u0645\u064a\u0639 \u0627\u0644\u062a\u0643\u0631\u0627\u0631\n \u064a\u0628\u0642\u0649 \u0645\u0642\u0635\u0648\u0631\u0627\u064b \u0639\u0644\u0649 SYS/WARN/ERR \u0641\u0642\u0637 \u0643\u0645\u0627 \u0643\u0627\u0646 (\u0644\u0627 \u0639\u0644\u0627\u0642\u0629 \u0644\u0647 \u0628\u0645\u0639\u062f\u0644 \u0623\u062d\u062f\u0627\u062b FREQ/NN/\u2026). -->\n<div class=\"pnl\" id=\"termPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"term-ph\">\n <div class=\"term-ph-l\">\n <div class=\"term-ph-dot\"></div>\n <span class=\"term-ph-t\">LIVE TERMINAL \u2014 AI FEED</span>\n </div>\n <div class=\"term-ph-r\">\n <span class=\"term-pause-lbl\" id=\"termPauseLbl\" style=\"display:none\">PAUSED</span>\n <span class=\"term-ctl\" id=\"termPauseBtn\" onclick=\"termTogglePause()\"> PAUSE</span>\n <span class=\"term-ctl\" onclick=\"termSaveTXT()\"> TXT</span>\n <span class=\"term-ctl\" onclick=\"termClear()\">CLR</span>\n <span class=\"term-ctl\" onclick=\"closeTerm()\">\u2715</span>\n </div>\n </div>\n <div class=\"term-fil\" id=\"termFil\">\n <span class=\"tfc on\" data-f=\"ALL\" style=\"color:#fff\" onclick=\"termFilter(this,'ALL')\">ALL</span>\n <span class=\"tfc\" data-f=\"FREQ\" style=\"color:#959595\" onclick=\"termFilter(this,'FREQ')\">[FREQ]</span>\n <span class=\"tfc\" data-f=\"NN\" style=\"color:#a5a5a5\" onclick=\"termFilter(this,'NN')\">[NN]</span>\n <span class=\"tfc\" data-f=\"EXEC\" style=\"color:#cecece\" onclick=\"termFilter(this,'EXEC')\">[EXEC]</span>\n <span class=\"tfc\" data-f=\"INV\" style=\"color:#9c9c9c\" onclick=\"termFilter(this,'INV')\">[INV]</span>\n <span class=\"tfc\" data-f=\"SF\" style=\"color:#787878\" onclick=\"termFilter(this,'SF')\">[SF]</span>\n <span class=\"tfc\" data-f=\"COH\" style=\"color:#818181\" onclick=\"termFilter(this,'COH')\">[COH]</span>\n <span class=\"tfc\" data-f=\"SYS\" style=\"color:#fff\" onclick=\"termFilter(this,'SYS')\">[SYS]</span>\n </div>\n <!-- \u0628\u062d\u062b \u0646\u0635\u0651\u064a \u062d\u0631\u0651 \u0641\u064a \u0627\u0644\u0633\u062c\u0644\u0651 \u2014 \u0623\u064f\u0636\u064a\u0641 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 (\u062a\u0637\u0648\u064a\u0631 Logs): \u064a\u0639\u0645\u0644 \u0641\u0648\u0642 \u062a\u0635\u0641\u064a\u0629 \u0627\u0644\u0641\u0626\u0629 \u0623\u0639\u0644\u0627\u0647\n (AND \u0628\u064a\u0646\u0647\u0645\u0627)\u060c \u0639\u0644\u0649 \u0646\u0635 \u0627\u0644\u0633\u0637\u0631 \u0648\u0633\u0637\u0631\u0647 \u0627\u0644\u0641\u0631\u0639\u064a \u0645\u0639\u0627\u064b\u060c \u063a\u064a\u0631 \u062d\u0633\u0651\u0627\u0633 \u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0623\u062d\u0631\u0641. -->\n <div class=\"term-search-row\">\n <input class=\"term-search\" id=\"termSearchInp\" placeholder=\"\u0628\u062d\u062b \u0641\u064a \u0627\u0644\u0633\u062c\u0644\u0651...\" oninput=\"termSearch(this.value)\">\n <span class=\"term-search-cnt\" id=\"termSearchCnt\"></span>\n </div>\n <div class=\"term-out\" id=\"termOut\"><div style=\"color:rgba(169,169,169,.35);font-family:var(--fm);font-size:9px;padding:4px 0\">ZERO AI v25 \u2014 Live Terminal \u00b7 AI DSL \u00b7 \u0628\u0627\u0646\u062a\u0638\u0627\u0631 \u0628\u062f\u0621 \u0627\u0644\u0645\u062d\u0631\u0643...</div></div>\n <div class=\"term-ir\">\n <span class=\"term-prompt\">>>> </span>\n <input class=\"term-cmd\" id=\"termCmd\" placeholder=\"ANALYZE \u00b7 BAN 50 \u00b7 BANLIST \u00b7 PARTITIONS \u00b7 PERMS\" onkeydown=\"if(event.key==='Enter'){termRunCmd();event.preventDefault()}\">\n <button class=\"term-run\" onclick=\"termRunCmd()\">RUN</button>\n </div>\n</div>\n<div class=\"ovl\" id=\"ovl\" onclick=\"closeAll()\"></div>\n<!-- \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 (Menu) \u2014 \u062a\u062c\u0645\u0639 \u0643\u0644 \u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u060c \u062a\u064f\u0641\u062a\u062d \u0645\u0646 \u0632\u0631 \u0627\u0644\u0647\u0627\u0645\u0628\u0631\u063a\u0631 \u0623\u0639\u0644\u0649 \u0627\u0644\u064a\u0633\u0627\u0631 -->\n<!-- \u0625\u0639\u0627\u062f\u0629 \u0647\u064a\u0643\u0644\u0629 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 (\u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645: \"\u0628\u062f\u0644 \u0642\u0627\u0644\u0628 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\" \u2192 \u0647\u064a\u0643\u0644\u0629 \u0627\u0644\u0634\u0627\u0634\u0627\u062a \u0648\u0627\u0644\u062a\u062e\u0637\u064a\u0637):\n \u0643\u0627\u0646\u062a \u0643\u0644 \u0627\u0644\u0648\u062c\u0647\u0627\u062a \u0627\u0644\u064012 \u0645\u0633\u0631\u0648\u062f\u0629 \u0641\u064a \u0628\u0637\u0627\u0642\u0629 \u0648\u0627\u062d\u062f\u0629 \u0645\u0633\u0637\u0651\u062d\u0629 \u0628\u0644\u0627 \u0623\u064a \u062a\u0635\u0646\u064a\u0641 \u0623\u0648 \u062a\u0633\u0644\u0633\u0644 \u0645\u0646\u0637\u0642\u064a\u060c \u0641\u064a\u0636\u0637\u0631\n \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0644\u0644\u062a\u0645\u0631\u064a\u0631 \u0627\u0644\u0643\u0627\u0645\u0644 \u0628\u062d\u062b\u0627\u064b \u0639\u0646 \u0623\u064a \u0648\u062c\u0647\u0629. \u0623\u064f\u0639\u064a\u062f \u0627\u0644\u062a\u0642\u0633\u064a\u0645 \u0627\u0644\u0622\u0646 \u0625\u0644\u0649 4 \u0645\u062c\u0645\u0648\u0639\u0627\u062a \u0645\u0648\u0636\u0648\u0639\u064a\u0629 \u0628\u0639\u0646\u0627\u0648\u064a\u0646\n (\u0628\u0646\u0641\u0633 \u0646\u0645\u0637 .slbl/.scard \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0623\u0635\u0644\u0627\u064b \u0641\u064a \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629) \u2014 \u0644\u0627 \u062a\u063a\u064a\u064a\u0631 \u0641\u064a \u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u0623\u0648 \u0641\u064a \u0623\u064a\n \u062f\u0627\u0644\u0629/onclick\u060c \u0641\u0642\u0637 \u0625\u0639\u0627\u062f\u0629 \u062a\u0631\u062a\u064a\u0628 \u0648\u062a\u0635\u0646\u064a\u0641 \u0646\u0641\u0633 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 \u062a\u0645\u0627\u0645\u0627\u064b. -->\n<div class=\"pnl\" id=\"menuPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0627\u0644\u0642\u0627\u0626\u0645\u0629</span><div class=\"pcl\" onclick=\"closeMenu()\">\u2715</div></div>\n <div class=\"shsc\">\n <div class=\"slbl\">\u0627\u0644\u0645\u0631\u0627\u0642\u0628\u0629 \u0648\u0627\u0644\u062a\u062d\u0644\u064a\u0644</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"closeMenu();openAIP()\">\n <div class=\"iw iai2\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u062f\u0645\u0627\u063a AI</div><div class=\"sd\">FreqDB \u00b7 \u0627\u0644\u0634\u0628\u0643\u0629 \u0627\u0644\u0639\u0635\u0628\u064a\u0629 \u00b7 \u0627\u0644\u0633\u062c\u0644\u0627\u062a</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openPipe()\">\n <div class=\"iw ib\"></div>\n <div class=\"scnt\"><div class=\"sn\">Pipeline</div><div class=\"sd\">\u062d\u0627\u0644\u0629 \u0627\u0644\u062e\u0648\u0627\u0631\u0632\u0645\u064a\u0627\u062a \u0627\u0644\u0644\u062d\u0638\u064a\u0629 \u2014 12 \u0645\u0631\u062d\u0644\u0629</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openDevMon()\">\n <div class=\"iw io\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u062c\u0647\u0627\u0632</div><div class=\"sd\">CPU \u00b7 RAM \u00b7 \u0628\u0637\u0627\u0631\u064a\u0629 \u00b7 \u062d\u0631\u0627\u0631\u0629</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openTerm()\">\n <div class=\"iw iai\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0633\u062c\u0644\u0651 \u0627\u0644\u0623\u062e\u0637\u0627\u0621</div><div class=\"sd\">\u0645\u0631\u0627\u0642\u0628\u0629 \u0623\u062e\u0637\u0627\u0621 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0641\u0642\u0637<span class=\"term-live-dot\" id=\"termLiveDot\" style=\"position:static;display:inline-block;margin-right:5px;vertical-align:middle\"></span></div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n </div>\n <div class=\"slbl\">\u0627\u0644\u0635\u0648\u062a \u0648\u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0621</div>\n <div class=\"scard\">\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 anechoic-chamber.html \u2014 \u0641\u0643\u0631\u0629 \u063a\u0627\u0626\u0628\u0629 \u0643\u0644\u064a\u0627\u064b \u0639\u0646 \u0643\u0644 \u062a\u0627\u0631\u064a\u062e\n \u0627\u0644\u0645\u0634\u0631\u0648\u0639: \u062a\u0634\u063a\u064a\u0644 \u0636\u0648\u0636\u0627\u0621 \u0645\u0642\u0646\u0650\u0651\u0639\u0629 (\u0628\u062f\u0644/\u0628\u062c\u0627\u0646\u0628 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0641\u0639\u0651\u0627\u0644) \u0644\u0625\u062e\u0641\u0627\u0621 \u0627\u0644\u0635\u0648\u062a \u0627\u0644\u0645\u062d\u064a\u0637. -->\n <div class=\"si\" onclick=\"closeMenu();openMaskPanel()\">\n <div class=\"iw imask\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</div><div class=\"sd\">\u0636\u0648\u0636\u0627\u0621 \u0645\u0642\u0646\u0650\u0651\u0639\u0629 \u2014 \u0623\u0628\u064a\u0636 \u00b7 \u0648\u0631\u062f\u064a \u00b7 \u0628\u0646\u064a \u00b7 \u0645\u0637\u0631</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 zero-wave-anc.html/zero-wave-complete.html \u2014 \u062a\u0635\u0648\u0651\u0631 \u062a\u0639\u0644\u064a\u0645\u064a\n \u0644\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 (\u0645\u0648\u062c\u0629 \u0623\u0635\u0644\u064a\u0629 + \u0645\u0648\u062c\u0629 \u0645\u0636\u0627\u062f\u0629 \u2192 \u0645\u0648\u062c\u0629 \u0635\u0641\u0631\u064a\u0629) \u0644\u0645 \u064a\u0648\u062c\u062f \u0644\u0647 \u0645\u062b\u064a\u0644 \u0628\u0635\u0631\u064a \u0641\u064a \u0623\u064a \u0646\u0633\u062e\u0629\n \u0633\u0627\u0628\u0642\u0629\u061b \u064a\u0633\u062a\u062e\u062f\u0645 \u0646\u0641\u0633 \u0645\u062d\u0644\u0651\u0644 (Analyser) \u0627\u0644\u0645\u062d\u0631\u0643 \u0627\u0644\u0631\u0626\u064a\u0633\u064a \u0627\u0644\u062d\u064a \u2014 \u0628\u0644\u0627 \u0623\u064a \u0645\u0635\u062f\u0631 \u0635\u0648\u062a/\u0627\u0644\u062a\u0642\u0627\u0637 \u062c\u062f\u064a\u062f. -->\n <div class=\"si\" onclick=\"closeMenu();openPhysPanel()\">\n <div class=\"iw imask\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</div><div class=\"sd\">\u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0623\u0635\u0644\u064a\u0629 + \u0627\u0644\u0645\u0636\u0627\u062f\u0629 \u2192 \u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0635\u0641\u0631\u064a\u0629</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 ZERO-v11-OneClick.html (animateLoopDiagram/highlightStep) \u2014\n \u0645\u062e\u0637\u0637 \u0645\u0631\u0627\u062d\u0644 \u062a\u0648\u0636\u064a\u062d\u064a (\u0644\u0627 \u0645\u0639\u0627\u0644\u062c\u0629 \u0635\u0648\u062a \u062c\u062f\u064a\u062f\u0629) \u064a\u0634\u0631\u062d \u062f\u0648\u0631\u0629 \"\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629\" \u0627\u0644\u0645\u0648\u062c\u0648\u062f\u0629 \u0641\u0639\u0644\u0627\u064b \u0643\u0645\u0641\u062a\u0627\u062d\n \u0641\u064a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a (Closed Loop) \u0628\u0635\u0631\u064a\u0627\u064b: 6 \u0645\u0631\u0627\u062d\u0644 \u062a\u0646\u0628\u0636 \u0628\u0627\u0644\u062a\u062a\u0627\u0628\u0639 \u0623\u062b\u0646\u0627\u0621 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0645\u062d\u0631\u0643. -->\n <div class=\"si\" onclick=\"closeMenu();openLoopDiagPanel()\">\n <div class=\"iw ip\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629</div><div class=\"sd\">\u0645\u062e\u0637\u0637 \u062d\u064a\u0651: \u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646 \u2192 AI \u2192 \u0645\u0639\u0627\u0644\u062c\u0629 \u2192 \u0633\u0645\u0651\u0627\u0639\u0629 \u2192 \u0642\u064a\u0627\u0633 \u2192 \u0635\u0641\u0631</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n </div>\n <div class=\"slbl\">\u0627\u0644\u0646\u0638\u0627\u0645 \u0648\u0627\u0644\u0645\u0644\u0641\u0627\u062a</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"closeMenu();openSheet()\">\n <div class=\"iw ig\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a</div><div class=\"sd\">\u0627\u0644\u0637\u0628\u0642\u0627\u062a \u00b7 \u0627\u0644\u062d\u0633\u0627\u0633\u064a\u0629 \u00b7 \u0648\u0636\u0639 \u0627\u0644\u0637\u0627\u0642\u0629</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openZPPanel()\">\n <div class=\"iw iev\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u0623\u0630\u0648\u0646\u0627\u062a</div><div class=\"sd\">\u0635\u0644\u0627\u062d\u064a\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645 \u0648\u0627\u0644\u062c\u0647\u0627\u0632</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openFilesPanel()\">\n <div class=\"iw iph\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u0645\u0644\u0641\u0627\u062a</div><div class=\"sd\">\u062a\u0635\u062f\u064a\u0631 \u0648\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <!-- \"\u0645\u0636\u0627\u062f \u0627\u0644\u0641\u064a\u0631\u0648\u0633\u0627\u062a\" (29 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0635\u0631\u0627\u062d\u0629\u064b: \u0648\u0627\u062c\u0647\u0629 \u062d\u0645\u0627\u064a\u0629 \u0644\u0644\u0645\u0634\u0631\u0648\u0639 \u0646\u0641\u0633\u0647 \u0645\u0646\n \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u062a\u064a \u062a\u0633\u0628\u0628 \u0644\u0647 \u0645\u0634\u0627\u0643\u0644. \u0644\u0627 \u0643\u0634\u0641/\u062d\u0638\u0631 \u062c\u062f\u064a\u062f: \u062a\u062c\u0645\u064a\u0639 \u0644\u062b\u0644\u0627\u062b \u0622\u0644\u064a\u0627\u062a \u062d\u0642\u064a\u0642\u064a\u0629 \u0643\u0627\u0646\u062a \u0645\u0648\u062c\u0648\u062f\u0629 \u0623\u0635\u0644\u0627\u064b\n \u0644\u0643\u0646 \u0645\u0628\u0639\u062b\u0631\u0629/\u0645\u062e\u0641\u064a\u0629 \u0628\u0627\u0644\u0643\u0627\u0645\u0644 \u2014 \u0631\u0627\u062c\u0639 \u0627\u0644\u0634\u0631\u062d \u0627\u0644\u0643\u0627\u0645\u0644 \u0623\u0639\u0644\u0649 updateAVPanel \u0641\u064a 08a-persist-bans-store.js. -->\n <div class=\"si\" onclick=\"closeMenu();openAVPanel()\">\n <div class=\"iw iav\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0645\u0636\u0627\u062f \u0627\u0644\u0641\u064a\u0631\u0648\u0633\u0627\u062a</div><div class=\"sd\">\u062d\u0638\u0631 \u062a\u0644\u0642\u0627\u0626\u064a \u0644\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u062d\u0631\u0627\u0631\u064a\u0629 \u0648\u0627\u0644\u0645\u064f\u062e\u0645\u0650\u0651\u0644\u0629 + \u0641\u062d\u0635 \u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n </div>\n <div class=\"slbl\">\u0639\u0646 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</div>\n <div class=\"scard\">\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a\u0627 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 \u062a\u0635\u0645\u064a\u0645 \u0645\u0631\u062c\u0639\u064a (5442.png) \u0641\u064a \u0645\u062c\u0644\u062f \u0627\u0644\u0631\u0641\u0639 \u0646\u0641\u0633\u0647 \u2014 \u062a\u0646\u0638\u064a\u0645\n \"About/Help\" \u0648\"Data & Privacy\" \u0644\u0645 \u064a\u0648\u062c\u062f \u0644\u0647 \u0645\u062b\u064a\u0644 \u0641\u064a \u0623\u064a \u0646\u0633\u062e\u0629 \u0633\u0627\u0628\u0642\u0629 \u0645\u0646 \u0627\u0644\u062a\u0637\u0628\u064a\u0642. -->\n <div class=\"si\" onclick=\"closeMenu();openAboutPanel()\">\n <div class=\"iw iph\">\u2139</div>\n <div class=\"scnt\"><div class=\"sn\">\u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</div><div class=\"sd\">\u0627\u0644\u0625\u0635\u062f\u0627\u0631 \u00b7 \u0627\u0644\u062e\u0648\u0627\u0631\u0632\u0645\u064a\u0627\u062a \u00b7 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0645\u0634\u0631\u0648\u0639</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n <div class=\"si\" onclick=\"closeMenu();openPrivacyPanel()\">\n <div class=\"iw ig\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u062e\u0635\u0648\u0635\u064a\u0629 \u0648\u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</div><div class=\"sd\">\u0645\u0627\u0630\u0627 \u064a\u064f\u062e\u0632\u064e\u0651\u0646 \u0648\u0645\u062d\u0644\u064a\u0627\u064b \u0641\u0642\u0637 \u2014 \u0628\u0644\u0627 \u0627\u062a\u0635\u0627\u0644 \u0625\u0646\u062a\u0631\u0646\u062a</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n </div>\n </div>\n</div>\n<!-- \u0644\u0648\u062d\u0629 \"\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a\" \u2014 \u0645\u0648\u0644\u0651\u062f \u0636\u0648\u0636\u0627\u0621 \u0645\u0642\u0646\u0650\u0651\u0639\u0629\u060c \u0645\u062d\u0631\u0643 \u0635\u0648\u062a \u0645\u0633\u062a\u0642\u0644 \u0639\u0646 \u0645\u062d\u0631\u0643 ANC \u0627\u0644\u0631\u0626\u064a\u0633\u064a \u062a\u0645\u0627\u0645\u0627\u064b -->\n<div class=\"pnl\" id=\"maskPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</span><div class=\"pcl\" onclick=\"closeMaskPanel()\">\u2715</div></div>\n <!-- \u062a\u0646\u0642\u0651\u0644 \u0645\u0628\u0627\u0634\u0631 \u0628\u064a\u0646 \u0644\u0648\u062d\u0627\u062a \u0645\u062c\u0645\u0648\u0639\u0629 \"\u0627\u0644\u0635\u0648\u062a \u0648\u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0621\" \u2014 \u062a\u0637\u0648\u064a\u0631 \u0627\u0644\u062a\u0646\u0642\u0644\u060c 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026:\n \u0628\u0644\u0627 \u0647\u0630\u0627 \u0627\u0644\u0634\u0631\u064a\u0637\u060c \u0627\u0644\u0627\u0646\u062a\u0642\u0627\u0644 \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0644\u0648\u062d\u0629 \u0625\u0644\u0649 \u0623\u062e\u0631\u0649 \u0628\u0646\u0641\u0633 \u0627\u0644\u0645\u062c\u0645\u0648\u0639\u0629 \u064a\u062a\u0637\u0644\u0628 \u0625\u063a\u0644\u0627\u0642\u0647\u0627 \u062b\u0645 \u0641\u062a\u062d\n \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062c\u0627\u0646\u0628\u064a\u0629 \u062b\u0645 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0648\u062c\u0647\u0629 \u2014 3 \u062e\u0637\u0648\u0627\u062a \u0644\u0648\u062c\u0647\u0629 \u0634\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629. \u0627\u0644\u0622\u0646 \u062e\u0637\u0648\u0629 \u0648\u0627\u062d\u062f\u0629. -->\n <div class=\"rel-nav\">\n <span class=\"rel-nav-lbl\">\u0627\u0644\u0635\u0648\u062a \u0648\u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0621</span>\n <span class=\"rel-nav-cur\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</span>\n <span class=\"rel-nav-lnk\" onclick=\"closeMaskPanel();openPhysPanel()\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</span>\n <span class=\"rel-nav-lnk\" onclick=\"closeMaskPanel();openLoopDiagPanel()\">\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629</span>\n </div>\n <div class=\"shsc\">\n <div class=\"scard\">\n <div class=\"mask-grid\">\n <div class=\"mask-btn on\" data-t=\"white\" onclick=\"maskSelectNoise('white',this)\"><span class=\"mask-ico\"></span>\u0623\u0628\u064a\u0636</div>\n <div class=\"mask-btn\" data-t=\"pink\" onclick=\"maskSelectNoise('pink',this)\"><span class=\"mask-ico\"></span>\u0648\u0631\u062f\u064a</div>\n <div class=\"mask-btn\" data-t=\"brown\" onclick=\"maskSelectNoise('brown',this)\"><span class=\"mask-ico\"></span>\u0628\u0646\u064a</div>\n <div class=\"mask-btn\" data-t=\"rain\" onclick=\"maskSelectNoise('rain',this)\"><span class=\"mask-ico\"></span>\u0645\u0637\u0631</div>\n <div class=\"mask-btn\" data-t=\"deep\" onclick=\"maskSelectNoise('deep',this)\"><span class=\"mask-ico\"></span>\u0639\u0645\u064a\u0642</div>\n </div>\n <canvas class=\"mask-viz\" id=\"maskViz\"></canvas>\n <div class=\"mask-slider-row\">\n <div class=\"mask-slider-lbl\"><span>\u0645\u0633\u062a\u0648\u0649 \u0627\u0644\u0635\u0648\u062a</span><span id=\"maskVolLbl\">45%</span></div>\n <input type=\"range\" id=\"maskVolSlider\" min=\"0\" max=\"100\" value=\"45\" oninput=\"maskUpdateVolume(this.value)\" style=\"width:100%\">\n </div>\n <div class=\"mask-slider-row\" id=\"maskFreqRow\" style=\"display:none\">\n <div class=\"mask-slider-lbl\"><span>\u062a\u0631\u062f\u062f \u0627\u0644\u0645\u0637\u0631</span><span id=\"maskFreqLbl\">1200 Hz</span></div>\n <input type=\"range\" id=\"maskFreqSlider\" min=\"300\" max=\"4000\" value=\"1200\" oninput=\"maskUpdateFreq(this.value)\" style=\"width:100%\">\n </div>\n <button class=\"mask-run-btn\" id=\"maskRunBtn\" onclick=\"maskToggle()\">\u25b6 \u062a\u0634\u063a\u064a\u0644 \u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</button>\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:10px;line-height:1.6\">\n \u062a\u0634\u063a\u064a\u0644 \u0636\u0648\u0636\u0627\u0621 \u062b\u0627\u0628\u062a\u0629 (\u0623\u0628\u064a\u0636/\u0648\u0631\u062f\u064a/\u0628\u0646\u064a) \u0623\u0648 \u0645\u062d\u0627\u0643\u0627\u0629 \u0645\u0637\u0631 \u0644\u0625\u062e\u0641\u0627\u0621 \u0623\u0635\u0648\u0627\u062a \u0645\u062d\u064a\u0637\u0629 \u0645\u0632\u0639\u062c\u0629 \u2014 \u0645\u0633\u062a\u0642\u0644 \u062a\u0645\u0627\u0645\u0627\u064b\n \u0639\u0646 \u0645\u062d\u0631\u0643 \u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0636\u062c\u064a\u062c \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u060c \u0648\u064a\u0645\u0643\u0646 \u062a\u0634\u063a\u064a\u0644\u0647\u0645\u0627 \u0645\u0639\u0627\u064b.\n </div>\n </div>\n </div>\n</div>\n<!-- \u0644\u0648\u062d\u0629 \"\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621\" \u2014 \u062a\u0635\u0648\u0651\u0631 \u062a\u0639\u0644\u064a\u0645\u064a: \u0645\u0648\u062c\u0629 \u0623\u0635\u0644\u064a\u0629 + \u0645\u0648\u062c\u0629 \u0645\u0636\u0627\u062f\u0629 \u2192 \u0645\u0648\u062c\u0629 \u0635\u0641\u0631\u064a\u0629 (residual) -->\n<div class=\"pnl\" id=\"physPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</span><div class=\"pcl\" onclick=\"closePhysPanel()\">\u2715</div></div>\n <div class=\"rel-nav\">\n <span class=\"rel-nav-lbl\">\u0627\u0644\u0635\u0648\u062a \u0648\u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0621</span>\n <span class=\"rel-nav-lnk\" onclick=\"closePhysPanel();openMaskPanel()\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</span>\n <span class=\"rel-nav-cur\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</span>\n <span class=\"rel-nav-lnk\" onclick=\"closePhysPanel();openLoopDiagPanel()\">\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629</span>\n </div>\n <div class=\"shsc\">\n <div class=\"scard\">\n <div class=\"phys-row\">\n <div class=\"phys-lbl\">\u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0623\u0635\u0644\u064a\u0629<span id=\"physFanStat\" class=\"phys-stat\">\u2014 Hz</span></div>\n <canvas class=\"phys-viz\" id=\"physFanCv\"></canvas>\n </div>\n <div class=\"phys-row\">\n <div class=\"phys-lbl\">\u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0645\u0636\u0627\u062f\u0629<span id=\"physAntiStat\" class=\"phys-stat\">0\u00b0</span></div>\n <canvas class=\"phys-viz\" id=\"physAntiCv\"></canvas>\n </div>\n <div class=\"phys-row\">\n <div class=\"phys-lbl\">\u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0635\u0641\u0631\u064a\u0629 (\u0627\u0644\u0646\u0627\u062a\u062c) <span id=\"physNullStat\" class=\"phys-stat\">\u2248 0</span></div>\n <canvas class=\"phys-viz\" id=\"physNullCv\"></canvas>\n </div>\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:6px;line-height:1.7\">\n \u062a\u0635\u0648\u0651\u0631 \u062a\u0639\u0644\u064a\u0645\u064a \u062d\u064a\u0651: \u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0623\u0635\u0644\u064a\u0629 \u0627\u0644\u0642\u0627\u062f\u0645\u0629 \u0645\u0646 \u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646\u060c \u062b\u0645 \u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0645\u0636\u0627\u062f\u0629 (\u0627\u0644\u0645\u0639\u0643\u0648\u0633\u0629) \u0627\u0644\u062a\u064a\n \u064a\u064f\u0648\u0644\u0651\u062f\u0647\u0627 \u0627\u0644\u0645\u062d\u0631\u0643\u060c \u0648\u0623\u062e\u064a\u0631\u0627\u064b \u0645\u062d\u0635\u0651\u0644\u0629 \u062c\u0645\u0639\u0647\u0645\u0627 \u2014 \u0643\u0644\u0645\u0627 \u0627\u0642\u062a\u0631\u0628\u062a \u0645\u0646 \u062e\u0637 \u0645\u0633\u062a\u0642\u064a\u0645 \u0632\u0627\u062f \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0641\u0639\u0644\u064a.\n \u064a\u0633\u062a\u062e\u062f\u0645 \u0628\u064a\u0627\u0646\u0627\u062a \u0645\u062d\u0631\u0643 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0631\u0626\u064a\u0633\u064a \u0645\u0628\u0627\u0634\u0631\u0629 (\u0644\u0627 \u0645\u062d\u0631\u0643 \u0635\u0648\u062a \u0625\u0636\u0627\u0641\u064a)\u061b \u0634\u063a\u0651\u0644 \u0627\u0644\u0645\u062d\u0631\u0643 \u0645\u0646 \u0627\u0644\u0634\u0627\u0634\u0629\n \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0623\u0648\u0644\u0627\u064b \u0644\u0631\u0624\u064a\u0629 \u0627\u0644\u0645\u0648\u062c\u0627\u062a \u062d\u064a\u0651\u0629.\n </div>\n </div>\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 ZERO-WAVE-v5.html (drawPhysSim/updatePhysSim) \u2014 \u0645\u062d\u0627\u0643\u0627\u0629 \u062a\u0641\u0627\u0639\u0644\u064a\u0629\n \u0631\u064a\u0627\u0636\u064a\u0629 \u0628\u062d\u062a\u0629 (\u0644\u0627 \u0635\u0648\u062a\u060c \u0644\u0627 \u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646) \u062a\u0639\u0645\u0644 \u062d\u062a\u0649 \u062f\u0648\u0646 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0645\u062d\u0631\u0643\u061b \u0641\u0643\u0631\u0629 \u0645\u062e\u062a\u0644\u0641\u0629 \u0639\u0646 \u0627\u0644\u062a\u0635\u0648\u0651\u0631 \u0627\u0644\u062d\u064a\u0651\n \u0623\u0639\u0644\u0627\u0647: \u0647\u0646\u0627 \u064a\u064f\u062d\u0631\u0650\u0651\u0643 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0634\u0631\u064a\u0637 \u0627\u0644\u0637\u0648\u0631 \u0628\u0646\u0641\u0633\u0647 \u0644\u064a\u0631\u0649 \u0623\u062b\u0631 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0645\u0628\u0627\u0634\u0631\u0629 \u0643\u062a\u062c\u0631\u0628\u0629 \u062a\u0639\u0644\u064a\u0645\u064a\u0629. -->\n <div class=\"slbl\">\u0645\u062d\u0627\u0643\u0627\u0629 \u062a\u0641\u0627\u0639\u0644\u064a\u0629</div>\n <div class=\"scard\">\n <canvas class=\"phys-viz\" id=\"physSimCv\" style=\"height:70px\"></canvas>\n <div class=\"mask-slider-row\">\n <div class=\"mask-slider-lbl\"><span>\u0641\u0631\u0642 \u0627\u0644\u0637\u0648\u0631 \u0628\u064a\u0646 \u0627\u0644\u0645\u0648\u062c\u062a\u064a\u0646</span><span id=\"physSimPhaseLbl\">180\u00b0</span></div>\n <input type=\"range\" id=\"physSimPhaseSlider\" min=\"0\" max=\"360\" value=\"180\" oninput=\"physSimUpdatePhase(this.value)\" style=\"width:100%\">\n </div>\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:8px;line-height:1.7\">\n \u062d\u0631\u0651\u0643 \u0627\u0644\u0634\u0631\u064a\u0637: \u0639\u0646\u062f 0\u00b0 \u062a\u062a\u0637\u0627\u0628\u0642 \u0627\u0644\u0645\u0648\u062c\u062a\u0627\u0646 \u0648\u062a\u062a\u0636\u0627\u0639\u0641 \u0627\u0644\u0637\u0627\u0642\u0629\u060c \u0648\u0639\u0646\u062f 180\u00b0 (\u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u062a\u0627\u0645) \u062a\u064f\u0644\u063a\u064a \u0643\u0644\n \u0648\u0627\u062d\u062f\u0629 \u0627\u0644\u0623\u062e\u0631\u0649 \u0648\u062a\u0635\u0628\u062d \u0627\u0644\u0645\u062d\u0635\u0651\u0644\u0629 \u062e\u0637\u0627\u064b \u0645\u0633\u062a\u0642\u064a\u0645\u0627\u064b \u2014 \u0647\u0630\u0627 \u0628\u0627\u0644\u0636\u0628\u0637 \u0645\u0627 \u064a\u0633\u0639\u0649 \u0627\u0644\u0645\u062d\u0631\u0643 \u0627\u0644\u062d\u0642\u064a\u0642\u064a \u0644\u062a\u062d\u0642\u064a\u0642\u0647 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b.\n </div>\n </div>\n </div>\n</div>\n<!-- \u0644\u0648\u062d\u0629 \"\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629\" \u2014 \u0645\u062e\u0637\u0637 \u0645\u0631\u0627\u062d\u0644 \u062d\u064a\u0651 \u064a\u0634\u0631\u062d \u0645\u0633\u0627\u0631 \u0627\u0644\u0645\u0639\u0627\u0644\u062c\u0629 \u0628\u0635\u0631\u064a\u0627\u064b\u061b \u0627\u0633\u062a\u064f\u0639\u064a\u062f \u0645\u0646\n ZERO-v11-OneClick.html (animateLoopDiagram) \u2014 \u062a\u0646\u0628\u064a\u0647 \u0628\u0635\u0631\u064a \u0645\u062a\u062a\u0627\u0628\u0639 \u0628\u0644\u0627 \u0623\u064a \u0645\u0639\u0627\u0644\u062c\u0629 \u0635\u0648\u062a \u062c\u062f\u064a\u062f\u0629 -->\n<div class=\"pnl\" id=\"loopDiagPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629</span><div class=\"pcl\" onclick=\"closeLoopDiagPanel()\">\u2715</div></div>\n <div class=\"rel-nav\">\n <span class=\"rel-nav-lbl\">\u0627\u0644\u0635\u0648\u062a \u0648\u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0621</span>\n <span class=\"rel-nav-lnk\" onclick=\"closeLoopDiagPanel();openMaskPanel()\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</span>\n <span class=\"rel-nav-lnk\" onclick=\"closeLoopDiagPanel();openPhysPanel()\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</span>\n <span class=\"rel-nav-cur\">\u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629</span>\n </div>\n <div class=\"shsc\">\n <div class=\"scard\">\n <div class=\"loop-flow\">\n <div class=\"lf-step\" id=\"lfStepMic\">\n <span class=\"ls-icon\"></span>\n <div><div class=\"ls-name\">\u0644\u0627\u0642\u0637\u0629 \u0627\u0644\u0635\u0648\u062a</div><div class=\"ls-sub\">\u062a\u0644\u062a\u0642\u0637 \u0643\u0644 \u0635\u0648\u062a \u0645\u062d\u064a\u0637</div></div>\n </div>\n <div class=\"lf-arrow\" id=\"lfArr1\">\u2193</div>\n <div class=\"lf-step\" id=\"lfStepAI\">\n <span class=\"ls-icon\"></span>\n <div><div class=\"ls-name\">AI \u064a\u0635\u0646\u0651\u0641</div><div class=\"ls-sub\">\u0645\u0631\u0648\u062d\u0629 \u00b7 \u062e\u0634\u062e\u0634\u0629 \u00b7 \u0635\u0641\u064a\u0631</div></div>\n </div>\n <div class=\"lf-arrow\" id=\"lfArr2\">\u2193</div>\n <div class=\"lf-step\" id=\"lfStepProc\">\n <span class=\"ls-icon\"></span>\n <div><div class=\"ls-name\">12 \u062e\u0648\u0627\u0631\u0632\u0645\u064a\u0629</div><div class=\"ls-sub\">\u062a\u0628\u0646\u064a \u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0639\u0643\u0633\u064a\u0629</div></div>\n </div>\n <div class=\"lf-arrow\" id=\"lfArr3\">\u2193</div>\n <div class=\"lf-step\" id=\"lfStepSpk\">\n <span class=\"ls-icon\"></span>\n <div><div class=\"ls-name\">\u0627\u0644\u0633\u0645\u0627\u0639\u0629</div><div class=\"ls-sub\">\u062a\u064f\u0635\u062f\u0631 \u0627\u0644\u0645\u0648\u062c\u0629 \u0627\u0644\u0639\u0643\u0633\u064a\u0629</div></div>\n </div>\n <div class=\"lf-arrow\" id=\"lfArr4\">\u2193</div>\n <div class=\"lf-step\" id=\"lfStepMeas\">\n <span class=\"ls-icon\"></span>\n <div><div class=\"ls-name\">\u0642\u064a\u0627\u0633 \u0627\u0644\u0646\u062a\u064a\u062c\u0629</div><div class=\"ls-sub\" id=\"lfMeasSub\">Coherence \u03b3\u00b2(f)</div></div>\n </div>\n <div class=\"lf-arrow\" id=\"lfArr5\">\u21ba</div>\n <div class=\"lf-step\" id=\"lfStepZero\">\n <span class=\"ls-icon\">\u2726</span>\n <div><div class=\"ls-name\">\u0627\u0644\u0647\u062f\u0641: \u0635\u0641\u0631</div><div class=\"ls-sub\">\u03b3\u00b2(f) \u2192 0</div></div>\n </div>\n </div>\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:10px;line-height:1.7\">\n \u062a\u0635\u0648\u0651\u0631 \u062a\u0639\u0644\u064a\u0645\u064a \u0644\u0645\u0633\u0627\u0631 \u0645\u0639\u0627\u0644\u062c\u0629 \u0627\u0644\u062d\u0644\u0642\u0629 \u0627\u0644\u0645\u063a\u0644\u0642\u0629 (\u0646\u0641\u0633 \u0645\u0641\u062a\u0627\u062d \"Closed Loop\" \u0641\u064a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a) \u2014 \u0644\u0627 \u064a\u064f\u063a\u064a\u0651\u0631\n \u0623\u064a \u0645\u0639\u0627\u0644\u062c\u0629 \u0635\u0648\u062a \u0641\u0639\u0644\u064a\u0629\u060c \u0647\u0648 \u0634\u0631\u062d \u0628\u0635\u0631\u064a \u0645\u062a\u062a\u0627\u0628\u0639 \u0644\u0645\u0627 \u064a\u0641\u0639\u0644\u0647 \u0627\u0644\u0645\u062d\u0631\u0643 \u0623\u062b\u0646\u0627\u0621 \u0627\u0644\u062a\u0634\u063a\u064a\u0644. \u0634\u063a\u0651\u0644 \u0627\u0644\u0645\u062d\u0631\u0643 \u0644\u0631\u0624\u064a\u062a\u0647 \u062d\u064a\u0651\u0627\u064b.\n </div>\n </div>\n </div>\n</div>\n<!-- \u0644\u0648\u062d\u0629 \"\u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\" \u2014 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0648\u0627\u0642\u0639\u064a\u0629 \u0641\u0642\u0637 (\u0644\u0627 \u0627\u062f\u0651\u0639\u0627\u0621\u0627\u062a \u062a\u0633\u0648\u064a\u0642\u064a\u0629)\u060c \u0645\u0623\u062e\u0648\u0630\u0629 \u0645\u0646 \u0646\u0641\u0633 \u0627\u0644\u062b\u0648\u0627\u0628\u062a\n \u0648\u0627\u0644\u062a\u0639\u0644\u064a\u0642\u0627\u062a \u0627\u0644\u0645\u0648\u062c\u0648\u062f\u0629 \u0641\u0639\u0644\u0627\u064b \u0641\u064a \u0627\u0644\u0645\u062d\u0631\u0643 (12 Algorithms \u00b7 16 Class \u00b7 \u0625\u0644\u062e) -->\n<div class=\"pnl\" id=\"aboutPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u2139 \u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span><div class=\"pcl\" onclick=\"closeAboutPanel()\">\u2715</div></div>\n <div class=\"rel-nav\">\n <span class=\"rel-nav-lbl\">\u0639\u0646 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span>\n <span class=\"rel-nav-cur\">\u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span>\n <span class=\"rel-nav-lnk\" onclick=\"closeAboutPanel();openPrivacyPanel()\">\u0627\u0644\u062e\u0635\u0648\u0635\u064a\u0629 \u0648\u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</span>\n </div>\n <div class=\"shsc\">\n <div class=\"scard\" style=\"text-align:center;padding:22px 14px\">\n <div style=\"font-family:var(--fo);font-size:22px;font-weight:800;color:var(--on)\">ZERO AI</div>\n <div style=\"font-family:var(--fm);font-size:10px;color:var(--muted);margin-top:4px\">\u0627\u0644\u0625\u0635\u062f\u0627\u0631 v25 \u00b7 2026</div>\n </div>\n <div class=\"slbl\">\u0627\u0644\u0645\u062d\u0631\u0643</div>\n <div class=\"scard\">\n <div class=\"si\"><div class=\"iw ib\"></div><div class=\"scnt\"><div class=\"sn\">12 \u062e\u0648\u0627\u0631\u0632\u0645\u064a\u0629 DSP</div><div class=\"sd\">MUSIC \u00b7 Kalman \u00b7 Wiener \u00b7 FxLMS \u00b7 Hilbert \u00b7 Coherence \u03b3\u00b2(f) \u0648\u0623\u062e\u0631\u0649</div></div></div>\n <div class=\"si\"><div class=\"iw ig\"></div><div class=\"scnt\"><div class=\"sn\">16 \u0641\u0626\u0629 \u062a\u0631\u062f\u062f\u064a\u0629</div><div class=\"sd\">\u062a\u0635\u0646\u064a\u0641 \u062a\u0644\u0642\u0627\u0626\u064a \u0644\u0643\u0644 \u062a\u0631\u062f\u062f \u0645\u0643\u062a\u0634\u064e\u0641 \u062d\u0633\u0628 \u0637\u0628\u064a\u0639\u062a\u0647 \u0627\u0644\u0641\u064a\u0632\u064a\u0627\u0626\u064a\u0629</div></div></div>\n <div class=\"si\"><div class=\"iw iai\"></div><div class=\"scnt\"><div class=\"sn\">\u0630\u0643\u0627\u0621 \u0630\u0627\u062a\u064a \u0639\u0644\u0649 \u0627\u0644\u062c\u0647\u0627\u0632</div><div class=\"sd\">\u0634\u0628\u0643\u0629 \u0639\u0635\u0628\u064a\u0629 16\u219224\u21928 + \u0645\u0643\u062a\u0628\u0629 \u0628\u0631\u0627\u0645\u062c \u062a\u0646\u0641\u064a\u0630 \u0630\u0627\u062a\u064a (EXEC/UCB1) \u2014 \u0628\u0644\u0627 \u0627\u062a\u0635\u0627\u0644 \u0625\u0646\u062a\u0631\u0646\u062a</div></div></div>\n </div>\n <div class=\"slbl\">\u0625\u0636\u0627\u0641\u0627\u062a \u0647\u0630\u0647 \u0627\u0644\u062c\u0644\u0633\u0629</div>\n <div class=\"scard\">\n <div class=\"si\"><div class=\"iw imask\"></div><div class=\"scnt\"><div class=\"sn\">\u063a\u0631\u0641\u0629 \u0627\u0644\u0635\u0645\u062a</div><div class=\"sd\">\u0636\u0648\u0636\u0627\u0621 \u0645\u0642\u0646\u0650\u0651\u0639\u0629 \u0645\u0633\u062a\u0642\u0644\u0629</div></div></div>\n <div class=\"si\"><div class=\"iw\" style=\"background:rgba(147,147,147,.12);color:#a6a6a6\"></div><div class=\"scnt\"><div class=\"sn\">\u0648\u0636\u0639 \u0627\u0644\u0646\u0648\u0645 \u0627\u0644\u0630\u0643\u064a</div><div class=\"sd\">\u062a\u0634\u063a\u064a\u0644 \u062a\u0644\u0642\u0627\u0626\u064a \u0645\u062c\u062f\u0648\u064e\u0644</div></div></div>\n <div class=\"si\"><div class=\"iw imask\"></div><div class=\"scnt\"><div class=\"sn\">\u0641\u064a\u0632\u064a\u0627\u0621 \u0627\u0644\u0625\u0644\u063a\u0627\u0621</div><div class=\"sd\">\u062a\u0635\u0648\u0651\u0631 \u062a\u0639\u0644\u064a\u0645\u064a \u062d\u064a\u0651</div></div></div>\n </div>\n <div style=\"text-align:center;padding:18px 0 4px;font-size:11px;color:rgba(255,255,255,.14)\">ZERO AI v25 \u00b7 16 Classes \u00b7 PERSIST \u00b7 My Files \u00b7 Neural Intelligence \u00b7 2026</div>\n </div>\n</div>\n<!-- \u0644\u0648\u062d\u0629 \"\u0627\u0644\u062e\u0635\u0648\u0635\u064a\u0629 \u0648\u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a\" \u2014 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0648\u0627\u0642\u0639\u064a\u0629: \u0644\u0627 \u0627\u0633\u062a\u062f\u0639\u0627\u0621 fetch/XHR \u0648\u0627\u062d\u062f \u0641\u064a \u0643\u0644 \u0627\u0644\u0645\u0644\u0641 (\u0645\u064f\u062a\u062d\u0642\u064e\u0651\u0642) -->\n<div class=\"pnl\" id=\"privacyPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0627\u0644\u062e\u0635\u0648\u0635\u064a\u0629 \u0648\u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</span><div class=\"pcl\" onclick=\"closePrivacyPanel()\">\u2715</div></div>\n <div class=\"rel-nav\">\n <span class=\"rel-nav-lbl\">\u0639\u0646 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span>\n <span class=\"rel-nav-lnk\" onclick=\"closePrivacyPanel();openAboutPanel()\">\u062d\u0648\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span>\n <span class=\"rel-nav-cur\">\u0627\u0644\u062e\u0635\u0648\u0635\u064a\u0629 \u0648\u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</span>\n </div>\n <div class=\"shsc\">\n <div class=\"scard\">\n <div class=\"si\"><div class=\"iw ig\"></div><div class=\"scnt\"><div class=\"sn\">\u0644\u0627 \u0627\u062a\u0635\u0627\u0644 \u0625\u0646\u062a\u0631\u0646\u062a</div><div class=\"sd\">\u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0644\u0627 \u064a\u0631\u0633\u0644 \u0623\u064a \u0628\u064a\u0627\u0646\u0627\u062a \u0644\u0623\u064a \u062e\u0627\u062f\u0645 \u062e\u0627\u0631\u062c\u064a \u2014 \u0643\u0644 \u0627\u0644\u0645\u0639\u0627\u0644\u062c\u0629 \u0639\u0644\u0649 \u0627\u0644\u062c\u0647\u0627\u0632</div></div></div>\n <div class=\"si\"><div class=\"iw iph\"></div><div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646</div><div class=\"sd\">\u064a\u064f\u0633\u062a\u062e\u062f\u0645 \u062d\u0635\u0631\u0627\u064b \u0644\u062a\u062d\u0644\u064a\u0644 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u064a\u0637\u0629 \u0644\u062d\u0638\u064a\u0627\u064b \u2014 \u0644\u0627 \u062a\u0633\u062c\u064a\u0644 \u0648\u0644\u0627 \u062a\u062e\u0632\u064a\u0646 \u0644\u0644\u0635\u0648\u062a \u0627\u0644\u062e\u0627\u0645</div></div></div>\n <div class=\"si\"><div class=\"iw ib\"></div><div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u062a\u062e\u0632\u064a\u0646 \u0627\u0644\u0645\u062d\u0644\u064a</div><div class=\"sd\">\u0642\u0627\u0639\u062f\u0629 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a (freqDB) \u0648\u0623\u0648\u0632\u0627\u0646 \u0627\u0644\u0634\u0628\u0643\u0629 \u0627\u0644\u0639\u0635\u0628\u064a\u0629 \u062a\u064f\u062d\u0641\u064e\u0638 \u0645\u062d\u0644\u064a\u0627\u064b (IndexedDB) \u0639\u0644\u0649 \u062c\u0647\u0627\u0632\u0643 \u0641\u0642\u0637</div></div></div>\n <div class=\"si\"><div class=\"iw io\"></div><div class=\"scnt\"><div class=\"sn\">\u0627\u0644\u0645\u0644\u0641\u0627\u062a</div><div class=\"sd\">\u0627\u0644\u062a\u0635\u062f\u064a\u0631/\u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f (WTAFS) \u064a\u0639\u0645\u0644 \u0645\u0639 \u0645\u0633\u0627\u062d\u0629 \u062a\u062e\u0632\u064a\u0646 \u062a\u062e\u062a\u0627\u0631\u0647\u0627 \u0623\u0646\u062a \u2014 \u0644\u0627 \u0631\u0641\u0639 \u062a\u0644\u0642\u0627\u0626\u064a \u0644\u0623\u064a \u0645\u0643\u0627\u0646</div></div></div>\n </div>\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);margin-top:10px;padding:0 14px;line-height:1.7\">\n \u064a\u0645\u0643\u0646\u0643 \u0645\u0631\u0627\u062c\u0639\u0629 \u0623\u0630\u0648\u0646\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u0645\u0645\u0646\u0648\u062d\u0629 \u0644\u0644\u062a\u0637\u0628\u064a\u0642 (\u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646/\u0625\u0634\u0639\u0627\u0631\u0627\u062a/\u062a\u062e\u0632\u064a\u0646) \u0645\u0646 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0630\u0648\u0646\u0627\u062a.\n </div>\n </div>\n</div>\n<!-- \u0646\u0627\u0641\u0630\u0629 \"\u0627\u0644\u0645\u0644\u0641\u0627\u062a\" \u2014 \u062a\u0635\u062f\u064a\u0631/\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629 (\u0646\u064f\u0642\u0644\u062a \u0645\u0646 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629) -->\n<div class=\"pnl\" id=\"filesPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0627\u0644\u0645\u0644\u0641\u0627\u062a</span><div class=\"pcl\" onclick=\"closeFilesPanel()\">\u2715</div></div>\n <div class=\"shsc\">\n <div class=\"slbl\">\u062d\u0641\u0638 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062d\u0636\u0631 \u0625\u0644\u0649 \u0627\u0644\u0645\u0644\u0641\u0627\u062a</div>\n <div class=\"scard\" style=\"padding:12px\">\n <div class=\"ban-exp-row\">\n <div class=\"ban-exp-btn json\" onclick=\"exportBans('json')\"> JSON</div>\n <div class=\"ban-exp-btn csv\" onclick=\"exportBans('csv')\"> CSV</div>\n <div class=\"ban-exp-btn txt\" onclick=\"exportBans('txt')\"> TXT</div>\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(132,132,132,.3);color:rgba(160,160,160,.85)\" onclick=\"importBanFile()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f JSON</div>\n </div>\n <!-- \u0645\u0634\u0627\u0631\u0643\u0629 \u0623\u0635\u0644\u064a\u0629 (WhatsApp/Telegram/\u0628\u0631\u064a\u062f/...) \u2014 \u0628\u062f\u0644 \u062a\u0646\u0632\u064a\u0644 \u0627\u0644\u0645\u0644\u0641 \u062b\u0645 \u0627\u0644\u0628\u062d\u062b \u0639\u0646\u0647 \u064a\u062f\u0648\u064a\u0627\u064b\n \u0644\u0625\u0631\u0633\u0627\u0644\u0647\u060c \u062a\u0641\u062a\u062d \u0634\u0627\u0634\u0629 \u0645\u0634\u0627\u0631\u0643\u0629 \u0623\u0646\u062f\u0631\u0648\u064a\u062f \u0645\u0628\u0627\u0634\u0631\u0629 \u0628\u0627\u0644\u0645\u0644\u0641 \u062c\u0627\u0647\u0632\u0627\u064b. \u064a\u0639\u0645\u0644 \u0641\u0642\u0637 \u0641\u064a \u0628\u0646\u0627\u0621 \u064a\u062f\u0639\u0645\n navigator.share (\u0645\u0624\u0643\u064e\u0651\u062f \u0623\u0646\u0647 \u0647\u0630\u0627 \u0627\u0644\u0628\u0646\u0627\u0621 \u0639\u0628\u0631 WebToApk) \u2014 \u064a\u062e\u062a\u0641\u064a \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u063a\u064a\u0631\u0647. -->\n <div class=\"ban-exp-row\" id=\"share-row\" style=\"margin-top:8px;display:none\">\n <div class=\"ban-exp-btn txt\" onclick=\"shareBans('txt')\">\u0645\u0634\u0627\u0631\u0643\u0629 TXT</div>\n <div class=\"ban-exp-btn json\" onclick=\"shareBans('json')\">\u0645\u0634\u0627\u0631\u0643\u0629 JSON</div>\n </div>\n <!-- \u0646\u0633\u062e \u0646\u0635\u0651\u064a \u0645\u0628\u0627\u0634\u0631 \u0644\u0644\u062d\u0627\u0641\u0638\u0629 \u2014 \u0644\u0644\u0635\u0642 \u0633\u0631\u064a\u0639 \u0643\u0631\u0633\u0627\u0644\u0629 \u0646\u0635\u0651\u064a\u0629 (\u0628\u0644\u0627 \u0645\u0644\u0641) \u0641\u064a \u0623\u064a \u0645\u062d\u0627\u062f\u062b\u0629 -->\n <div class=\"ban-exp-row\" id=\"clip-row\" style=\"margin-top:8px;display:none\">\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(189,189,189,.3);color:rgba(197,197,197,.85)\" onclick=\"copyBansToClipboard()\">\u0646\u0633\u062e \u0645\u0644\u062e\u0651\u0635 TXT \u0644\u0644\u062d\u0627\u0641\u0638\u0629</div>\n <div class=\"ban-exp-btn json\" onclick=\"copyBansJSONToClipboard()\">\u0646\u0633\u062e JSON \u0644\u0644\u062d\u0627\u0641\u0638\u0629</div>\n </div>\n <!-- \u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0628\u0627\u0634\u0631 \u0645\u0646 \u0627\u0644\u062d\u0627\u0641\u0638\u0629 (\u0644\u0635\u0642) \u2014 \u0628\u062f\u064a\u0644 \u0641\u0648\u0631\u064a \u0644\u0627 \u064a\u0639\u062a\u0645\u062f \u0639\u0644\u0649 \u0645\u062c\u0644\u062f/\u0645\u0644\u0641 \u062b\u0627\u0628\u062a \u0625\u0637\u0644\u0627\u0642\u0627\u064b\u060c\n \u0644\u0646\u0642\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062d\u0638\u0631 \u0628\u064a\u0646 \u062c\u0647\u0627\u0632\u064a\u0646: \u0627\u0646\u0633\u062e JSON \u0645\u0646 \u062c\u0647\u0627\u0632 \u0639\u0628\u0631 \u0627\u0644\u0632\u0631 \u0623\u0639\u0644\u0627\u0647\u060c \u0648\u0627\u0644\u0635\u0642\u0647 \u0647\u0646\u0627 \u0641\u064a \u0627\u0644\u0622\u062e\u0631.\n \u064a\u0639\u0645\u0644 \u0628\u0635\u0631\u0641 \u0627\u0644\u0646\u0638\u0631 \u0639\u0646 \u062d\u0627\u0644\u0629 \u0625\u0630\u0646 SAF (\u0645\u0646\u0637\u0642 \u0645\u062e\u062a\u0644\u0641 \u062a\u0645\u0627\u0645\u0627\u064b \u0641\u064a \u0647\u0630\u0627 \u0627\u0644\u0628\u0646\u0627\u0621 \u2014 \u0623\u064f\u0643\u0650\u0651\u062f \u0639\u0628\u0631 \u0641\u062d\u0635\n \u0627\u0644\u0643\u0648\u062f \u0627\u0644\u0645\u064f\u0635\u0631\u064e\u0651\u0641: readClipboard() \u0645\u062d\u0643\u0648\u0645 \u0641\u0642\u0637 \u0628\u0641\u062d\u0635 \u0623\u0645\u0646\u064a \u0644\u0623\u0635\u0644 \u0627\u0644\u0635\u0641\u062d\u0629\u060c \u0644\u0627 \u0628\u0625\u0639\u062f\u0627\u062f \u0628\u0646\u0627\u0621). -->\n <div class=\"ban-exp-row\" id=\"clip-import-row\" style=\"margin-top:8px;display:none\">\n <div class=\"ban-exp-btn csv\" style=\"grid-column:1/-1\" onclick=\"pasteImportFromClipboard()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0646 \u0627\u0644\u062d\u0627\u0641\u0638\u0629 (\u0644\u0635\u0642 JSON)</div>\n </div>\n <div class=\"ban-exp-msg\" id=\"ban-exp-msg\"></div>\n </div>\n </div>\n <!-- \u0645\u062c\u0644\u062f \u062b\u0627\u0628\u062a (My Files) \u2014 \u062a\u062e\u0632\u064a\u0646 \u0623\u0646\u062f\u0631\u0648\u064a\u062f \u0623\u0635\u0644\u064a \u0641\u0639\u0644\u064a \u0639\u0628\u0631 WebToApkFS: \u062a\u0635\u062f\u064a\u0631/\u0627\u0633\u062a\u064a\u0631\u0627\u062f/\u062a\u0639\u062f\u064a\u0644/\u0643\u062a\u0627\u0628\u0629\n \u0645\u0628\u0627\u0634\u0631\u0629 \u0639\u0644\u0649 \u0645\u0633\u0627\u0631 \u062b\u0627\u0628\u062a \u064a\u062e\u062a\u0627\u0631\u0647 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 (SAF)\u060c \u0628\u062f\u0644 \u0627\u0644\u0627\u0639\u062a\u0645\u0627\u062f \u0639\u0644\u0649 localStorage \u0641\u0642\u0637. -->\n <div class=\"slbl\"> My Files \u2014 \u0645\u062c\u0644\u062f \u062b\u0627\u0628\u062a \u0639\u0644\u0649 \u0627\u0644\u062c\u0647\u0627\u0632</div>\n <div class=\"scard\" style=\"padding:12px\">\n <div class=\"ban-exp-msg\" id=\"wtafs-status\" style=\"margin-bottom:8px\">\u2026</div>\n <!-- \u0645\u062a\u0637\u0644\u0628\u0627\u062a \u0627\u0644\u062a\u0637\u0628\u064a\u0642: \u0639\u0631\u0636 \u0641\u0639\u0644\u064a \u0644\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u062c\u0647\u0627\u0632 (\u0645\u0639\u0627\u0644\u062c/\u0630\u0627\u0643\u0631\u0629/\u062a\u062e\u0632\u064a\u0646) \u0648\u062d\u062c\u0645 \u0645\u062d\u062a\u0648\u064a\u0627\u062a \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u062b\u0627\u0628\u062a\n \u0646\u0641\u0633\u0647 \u2014 \u0623\u0631\u0642\u0627\u0645 \u062d\u0642\u064a\u0642\u064a\u0629 \u0645\u0646 Web APIs \u0645\u0624\u0643\u064e\u0651\u062f\u0629 (navigator.hardwareConcurrency / navigator.deviceMemory\n / navigator.storage.estimate)\u060c \u0648\u0644\u064a\u0633\u062a \u0642\u064a\u0645\u0627\u064b \u0645\u064f\u0642\u062f\u064e\u0651\u0631\u0629 \u064a\u062f\u0648\u064a\u0627\u064b\u061b \u062a\u0648\u0636\u0651\u062d \u0644\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0645\u0627 \u064a\u062d\u062a\u0627\u062c\u0647 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\n \u0641\u0639\u0644\u064a\u0627\u064b \u0648\u0645\u0627 \u064a\u0633\u062a\u0647\u0644\u0643\u0647 \u0645\u0646 \u0645\u0633\u0627\u062d\u0629 \u062f\u0627\u062e\u0644 \u0646\u0641\u0633 \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u0630\u064a \u064a\u0645\u0646\u062d\u0647\u060c \u062a\u0645\u0627\u0645\u0627\u064b \u0643\u0645\u0627 \u064a\u0639\u0631\u0636 \u062a\u0637\u0628\u064a\u0642 \"\u0627\u0644\u0645\u0644\u0641\u0627\u062a\"\n \u0627\u0644\u062d\u0642\u064a\u0642\u064a \u062d\u062c\u0645 \u0623\u064a \u0645\u062c\u0644\u062f \u0641\u064a\u0647. -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px;flex-direction:column;align-items:stretch;gap:2px\">\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);opacity:.85\">\u0645\u062a\u0637\u0644\u0628\u0627\u062a \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0648\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u062c\u0647\u0627\u0632</div>\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);line-height:1.9\" id=\"wtafs-resources-text\">\u2026</div>\n </div>\n <div class=\"ban-exp-row\" style=\"margin-top:8px\">\n <div class=\"ban-exp-btn json\" id=\"wtafs-grant-btn\" onclick=\"requestFixedFolder()\">\u0645\u0646\u062d \u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0645\u062c\u0644\u062f \u062b\u0627\u0628\u062a</div>\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(132,132,132,.3);color:rgba(160,160,160,.85)\" id=\"wtafs-clear-btn\" onclick=\"clearFixedFolder()\">\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0648\u0635\u0648\u0644</div>\n </div>\n <div class=\"ban-exp-row\" style=\"margin-top:8px\">\n <div class=\"ban-exp-btn csv\" id=\"wtafs-restore-btn\" onclick=\"importFromFixedFolder()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0622\u062e\u0631 \u0646\u0633\u062e\u0629 \u0645\u0646 \u0627\u0644\u0645\u062c\u0644\u062f</div>\n </div>\n <!-- \u062a\u0639\u0645\u064a\u0645: \u0646\u0641\u0633 \u0641\u0643\u0631\u0629 \u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0627\u0644\u062d\u0638\u0631 \u0645\u0646 \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u062b\u0627\u0628\u062a\u060c \u0644\u0643\u0646 \u0644\u0644\u0646\u0633\u062e\u0629 \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629 \u0627\u0644\u0643\u0627\u0645\u0644\u0629\n (NN + FreqDB + \u0627\u0644\u0625\u0646\u062c\u0627\u0632\u0627\u062a) \u0627\u0644\u062a\u064a \u064a\u0643\u062a\u0628\u0647\u0627 exportJSON \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u0625\u0644\u0649 \u0646\u0641\u0633 \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u0622\u0646. -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px\">\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(169,169,169,.3);color:rgba(215,215,215,.9)\" id=\"wtafs-restore-backup-btn\" onclick=\"importFullBackupFromFixedFolder()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0622\u062e\u0631 \u0646\u0633\u062e\u0629 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629 \u0643\u0627\u0645\u0644\u0629 (NN+FreqDB)</div>\n </div>\n <!-- \u0627\u0633\u062a\u0641\u0627\u062f\u0629 \u0645\u0646 \u0645\u064a\u0632\u0629 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0623\u0635\u0644\u064a\u0629 \u0644\u0623\u0646\u062f\u0631\u0648\u064a\u062f (\u062a\u0635\u0641\u0651\u062d \u0643\u0627\u0645\u0644 \u0639\u0628\u0631 \u062a\u0637\u0628\u064a\u0642 \"\u0627\u0644\u0645\u0644\u0641\u0627\u062a\"): \u0644\u0627\n \u064a\u062a\u0637\u0644\u0628 \u0645\u0646\u062d \u0648\u0635\u0648\u0644 \u0645\u062c\u0644\u062f \u0643\u0627\u0645\u0644 \u2014 \u064a\u0639\u0645\u0644 \u062d\u062a\u0649 \u0644\u0645\u0644\u0641 \u0646\u0633\u062e\u0629 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629 \u0645\u0648\u062c\u0648\u062f \u0641\u064a \u0623\u064a \u0645\u0643\u0627\u0646 \u0622\u062e\u0631 \u0639\u0644\u0649\n \u0627\u0644\u062c\u0647\u0627\u0632 (Downloads\u060c \u062a\u062e\u0632\u064a\u0646 \u0633\u062d\u0627\u0628\u064a \u0645\u064f\u0632\u0627\u0645\u064e\u0646\u060c \u0645\u0644\u0641 \u0648\u0635\u0644 \u0645\u0646 \u062c\u0647\u0627\u0632 \u0622\u062e\u0631...)\u060c \u0628\u0639\u0643\u0633 \u0627\u0644\u0632\u0631 \u0623\u0639\u0644\u0627\u0647 \u0627\u0644\u0630\u064a\n \u064a\u0642\u0631\u0623 \u0641\u0642\u0637 \u0645\u0646 \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u062b\u0627\u0628\u062a \u0627\u0644\u0645\u064f\u0635\u0631\u064e\u0651\u062d \u0628\u0647. -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px\">\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(169,169,169,.3);color:rgba(215,215,215,.9);grid-column:1/-1\" id=\"wtafs-pick-backup-btn\" onclick=\"pickAndRestoreFullBackup()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0646\u0633\u062e\u0629 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629 \u0645\u0646 \u0645\u0644\u0641 (\u062a\u0635\u0641\u0651\u062d \u0639\u0628\u0631 \u0627\u0644\u0645\u0644\u0641\u0627\u062a)</div>\n </div>\n <!-- \u0628\u062f\u064a\u0644 \u0623\u062e\u0641\u0651: \u0627\u062e\u062a\u064a\u0627\u0631 \u0645\u0644\u0641 \u0648\u0627\u062d\u062f \u062b\u0627\u0628\u062a (\u0628\u062f\u0644 \u0645\u062c\u0644\u062f \u0643\u0627\u0645\u0644) \u2014 \u0646\u0641\u0633 \u0634\u0631\u0637 \u0627\u0644\u062a\u0641\u0639\u064a\u0644 \u0628\u0627\u0644\u0636\u0628\u0637\u060c \u0644\u0643\u0646 \u064a\u0638\u0647\u0631\n \u0641\u0642\u0637 \u062d\u064a\u0646 \u064a\u0643\u0648\u0646 \u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0644\u0645\u062c\u0644\u062f \u0645\u062a\u0627\u062d\u0627\u064b \u062a\u0642\u0646\u064a\u0627\u064b \u0648\u063a\u064a\u0631 \u0645\u0645\u0646\u0648\u062d \u0628\u0639\u062f\u061b \u0625\u0646 \u0643\u0627\u0646\u062a \u0627\u0644\u0645\u064a\u0632\u0629 \u0645\u0639\u0637\u064e\u0651\u0644\u0629 \u0645\u0646\n \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0628\u0646\u0627\u0621 \u0623\u0635\u0644\u0627\u064b \u0641\u0644\u0646 \u064a\u0638\u0647\u0631 \u0647\u0630\u0627 \u0627\u0644\u0632\u0631 \u0623\u064a\u0636\u0627\u064b (\u0646\u0641\u0633 \u0627\u0644\u0642\u064a\u062f \u064a\u0634\u0645\u0644\u0647\u0645\u0627 \u062d\u0631\u0641\u064a\u0627\u064b). -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px\">\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(189,189,189,.3);color:rgba(197,197,197,.85);grid-column:1/-1\" id=\"wtafs-pick-btn\" onclick=\"pickFixedFile()\">\u0627\u062e\u062a\u064a\u0627\u0631 \u0645\u0644\u0641 \u062b\u0627\u0628\u062a (\u0628\u062f\u064a\u0644 \u0623\u062e\u0641\u0651 \u0645\u0646 \u0645\u062c\u0644\u062f \u0643\u0627\u0645\u0644)</div>\n </div>\n <!-- \u062a\u0638\u0647\u0631 \u0641\u0642\u0637 \u0628\u0639\u062f \u0627\u062e\u062a\u064a\u0627\u0631 \u0645\u0644\u0641 \u062b\u0627\u0628\u062a \u0641\u0639\u0644\u0627\u064b \u0639\u0628\u0631 \u0627\u0644\u0632\u0631 \u0623\u0639\u0644\u0627\u0647 (uri \u0645\u062d\u0641\u0648\u0638 \u0641\u064a localStorage) -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px;display:none\" id=\"wtafs-pickfile-row\">\n <div class=\"ban-exp-btn csv\" id=\"wtafs-pickimport-btn\" onclick=\"importFromPickedFile()\">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0646 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u062b\u0627\u0628\u062a \u0627\u0644\u0645\u062e\u062a\u0627\u0631</div>\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(132,132,132,.3);color:rgba(160,160,160,.85)\" id=\"wtafs-pickforget-btn\" onclick=\"forgetPickedFile()\">\u2716 \u0646\u0633\u064a\u0627\u0646 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u062e\u062a\u0627\u0631</div>\n </div>\n <!-- \u0627\u0633\u062a\u0641\u0627\u062f\u0629 \u0623\u0643\u0628\u0631 \u0645\u0646 My Files: \u062a\u0635\u0641\u0651\u062d \u0641\u0639\u0644\u064a \u0644\u0645\u062d\u062a\u0648\u064a\u0627\u062a \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u062b\u0627\u0628\u062a \u0645\u0646 \u062f\u0627\u062e\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0646\u0641\u0633\u0647 \u2014\n \u0646\u0641\u0633 \u0645\u0627 \u064a\u0639\u0631\u0636\u0647 \u062a\u0637\u0628\u064a\u0642 \"\u0627\u0644\u0645\u0644\u0641\u0627\u062a\" \u0627\u0644\u062d\u0642\u064a\u0642\u064a (WebToApkFS.list)\u060c \u0644\u0643\u0646 \u0645\u0639 \u0627\u0633\u062a\u064a\u0631\u0627\u062f/\u062d\u0630\u0641 \u0643\u0644 \u0645\u0644\u0641\n \u0628\u0645\u0641\u0631\u062f\u0647 \u062f\u0648\u0646 \u0627\u0644\u062d\u0627\u062c\u0629 \u0644\u0644\u062e\u0631\u0648\u062c \u0625\u0644\u0649 \u062a\u0637\u0628\u064a\u0642 \u0622\u062e\u0631. \u064a\u0638\u0647\u0631 \u0641\u0642\u0637 \u0628\u0639\u062f \u0645\u0646\u062d \u0627\u0644\u0648\u0635\u0648\u0644 (\u0644\u0627 \u0645\u0639\u0646\u0649 \u0644\u062a\u0635\u0641\u0651\u062d\n \u0645\u062c\u0644\u062f \u063a\u064a\u0631 \u0645\u064f\u0635\u0631\u064e\u0651\u062d \u0628\u0647 \u0628\u0639\u062f). -->\n <div class=\"ban-exp-row\" style=\"margin-top:8px;display:none\" id=\"wtafs-browser-row\">\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(189,189,189,.3);color:rgba(197,197,197,.85)\" onclick=\"renderFixedFolderBrowser()\">\u062a\u062d\u062f\u064a\u062b<span id=\"wtafs-file-count\" style=\"opacity:.7\"></span></div>\n <!-- \u0645\u0634\u0627\u0631\u0643\u0629 \u0643\u0644 \u0627\u0644\u0645\u0644\u0641\u0627\u062a \u062f\u0641\u0639\u0629 \u0648\u0627\u062d\u062f\u0629 \u0639\u0628\u0631 \u0634\u0627\u0634\u0629 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0627\u0644\u0623\u0635\u0644\u064a\u0629 \u0644\u0623\u0646\u062f\u0631\u0648\u064a\u062f \u2014 \u0646\u0641\u0633 navigator.share\n \u0627\u0644\u0645\u064f\u0633\u062a\u062e\u062f\u064e\u0645 \u0623\u0635\u0644\u0627\u064b \u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0627\u0644\u062d\u0638\u0631\u060c \u0644\u0643\u0646 \u0645\u064f\u0639\u0645\u064e\u0651\u0645 \u0647\u0646\u0627 \u0639\u0644\u0649 \u0643\u0644 \u0645\u062d\u062a\u0648\u064a\u0627\u062a \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u062b\u0627\u0628\u062a. \u064a\u0638\u0647\u0631 \u0641\u0642\u0637\n \u0625\u0646 \u0643\u0627\u0646\u062a \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0645\u062f\u0639\u0648\u0645\u0629 \u0623\u0635\u0644\u0627\u064b \u0641\u064a \u0647\u0630\u0627 \u0627\u0644\u0628\u0646\u0627\u0621 (\u0646\u0641\u0633 \u0634\u0631\u0637 share-row \u0641\u064a \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u062d\u0638\u0631). -->\n <div class=\"ban-exp-btn\" style=\"border-color:rgba(169,169,169,.3);color:rgba(215,215,215,.9);display:none\" id=\"wtafs-share-all-btn\" onclick=\"shareAllFixedFolderFiles()\">\u0645\u0634\u0627\u0631\u0643\u0629 \u0627\u0644\u0643\u0644</div>\n </div>\n <div id=\"wtafs-file-browser-list\" style=\"margin-top:6px;max-height:220px;overflow-y:auto\"></div>\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);margin-top:8px;line-height:1.7\">\n \u0628\u0639\u062f \u0645\u0646\u062d \u0627\u0644\u0648\u0635\u0648\u0644: \u0643\u0644 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u062d\u0638\u0631 \u0648\u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062a\u062f\u0627\u062e\u0644 \u0648\u062d\u0627\u0644\u0629 \u0627\u0644\u0634\u0628\u0643\u0629 \u0627\u0644\u0639\u0635\u0628\u064a\u0629 \u062a\u064f\u0643\u062a\u0628 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u0648\u0641\u0648\u0631\u064a\u0627\u064b\n \u0643\u0645\u0644\u0641\u0627\u062a \u0641\u0639\u0644\u064a\u0629 \u062f\u0627\u062e\u0644 \u0627\u0644\u0645\u062c\u0644\u062f \u0627\u0644\u0630\u064a \u062a\u062e\u062a\u0627\u0631\u0647 \u2014 \u064a\u0645\u0643\u0646\u0643 \u062a\u0635\u0641\u0651\u062d\u0647\u0627 \u0623\u0648 \u0646\u0633\u062e\u0647\u0627 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0627\u064b \u0645\u0646 \u0623\u064a \u062a\u0637\u0628\u064a\u0642 \u0645\u0644\u0641\u0627\u062a.\n \u0643\u0644 \u062a\u0635\u062f\u064a\u0631 (JSON/CSV/TXT) \u0623\u0639\u0644\u0627\u0647 \u064a\u064f\u062d\u0641\u064e\u0638 \u0623\u064a\u0636\u0627\u064b \u0641\u064a \u0646\u0641\u0633 \u0627\u0644\u0645\u062c\u0644\u062f \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b.\n <br>\u0625\u0646 \u0644\u0645 \u062a\u0638\u0647\u0631 \u0623\u064a \u0646\u0627\u0641\u0630\u0629 \u0639\u0646\u062f \u0627\u0644\u0636\u063a\u0637 \u0639\u0644\u0649 \u0623\u064a \u0645\u0646 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0623\u0639\u0644\u0627\u0647\u060c \u0641\u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u062d\u0645\u0631\u0627\u0621 \u0641\u0648\u0642\u0647\u0627\n \u062a\u0634\u0631\u062d \u0627\u0644\u0633\u0628\u0628 \u0627\u0644\u062f\u0642\u064a\u0642 \u2014 \u063a\u0627\u0644\u0628\u0627\u064b \u0625\u0630\u0646 \u0645\u0639\u0637\u064e\u0651\u0644 \u0645\u0646 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0628\u0646\u0627\u0621 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0646\u0641\u0633\u0647\u060c \u0648\u0644\u064a\u0633 \u062e\u0644\u0644\u0627\u064b \u0647\u0646\u0627.\n </div>\n </div>\n</div><!-- /filesPanel -->\n<!-- \u0644\u0648\u062d\u0629 \"\u0645\u0636\u0627\u062f \u0627\u0644\u0641\u064a\u0631\u0648\u0633\u0627\u062a\" (29 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645: \u062d\u0645\u0627\u064a\u0629 \u0644\u0644\u0645\u0634\u0631\u0648\u0639 \u0646\u0641\u0633\u0647 \u0645\u0646 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a\n \u0627\u0644\u062a\u064a \u062a\u0633\u0628\u0628 \u0644\u0647 \u0645\u0634\u0627\u0643\u0644 (\u0644\u0627 \u062d\u0645\u0627\u064a\u0629 \u0633\u0645\u0639 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u2014 \u062a\u0644\u0643 \u0645\u0647\u0645\u0629 \u0641\u0626\u0627\u062a \u0636\u0627\u0631\u0629/\u0635\u0627\u062e\u0628\u0629/mic \u0641\u064a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a).\n \u0643\u0644 \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0647\u0646\u0627 \u062d\u0642\u064a\u0642\u064a\u0629 \u0645\u0646 AI_BAN/THERMAL \u0627\u0644\u062d\u064a\u0651\u0629 \u2014 \u0644\u0627 \u0642\u064a\u0645\u0629 \u0648\u0627\u062d\u062f\u0629 \u0645\u064f\u062e\u062a\u0644\u064e\u0642\u0629 \u0623\u0648 \u0632\u062e\u0631\u0641\u064a\u0629:\n - \"\u062a\u0631\u062f\u062f\u0627\u062a \u062d\u0631\u0627\u0631\u064a\u0629\": THERMAL.thermBanned \u0641\u064a 02-classification-thermal-nn.js \u2014 \u062d\u0638\u0631 \u062a\u0644\u0642\u0627\u0626\u064a\n \u0641\u0639\u0644\u064a \u0628\u0639\u062f 8 \u062a\u0643\u0631\u0627\u0631\u0627\u062a \u0627\u0631\u062a\u0628\u0627\u0637 \u0628\u0627\u0631\u062a\u0641\u0627\u0639 \u062d\u0631\u0627\u0631\u0629 \u0627\u0644\u062c\u0647\u0627\u0632 (sampleThermal).\n - \"\u062a\u0631\u062f\u062f\u0627\u062a \u062a\u062e\u0645\u0651\u0644\": ANTI_IDLE.lagFreqs \u0641\u064a \u0646\u0641\u0633 \u0627\u0644\u0645\u0644\u0641 \u2014 \u062d\u0638\u0631 \u062a\u0644\u0642\u0627\u0626\u064a \u0641\u0639\u0644\u064a \u0628\u0639\u062f 8 \u062a\u0643\u0631\u0627\u0631\u0627\u062a \u0627\u0631\u062a\u0628\u0627\u0637\n \u0628\u062a\u0642\u0637\u0651\u0639 \u0627\u0644\u0625\u0637\u0627\u0631\u0627\u062a >50ms (monitorSlugFreqs).\n - \"\u0641\u062d\u0635 \u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a\": _purgeInvalidFrequencies \u0641\u064a 08a-persist-bans-store.js \u2014 \u0643\u0627\u0646\u062a \u062a\u0639\u0645\u0644\n \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u0641\u0642\u0637 (\u0628\u062f\u0621 \u062a\u0634\u063a\u064a\u0644/\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u062c\u0644\u0633\u0629/\u0627\u0633\u062a\u064a\u0631\u0627\u062f) \u0628\u0644\u0627 \u0623\u064a \u0632\u0631 \u064a\u062f\u0648\u064a \u0648\u0644\u0627 \u0639\u0631\u0636 \u0646\u062a\u064a\u062c\u0629\u061b \u0627\u0644\u0632\u0631 \u0647\u0646\u0627\n \u064a\u0634\u063a\u0651\u0644\u0647\u0627 \u064a\u062f\u0648\u064a\u0627\u064b \u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0645\u0628\u0627\u0634\u0631\u0629\u060c \u0628\u0646\u0641\u0633 \u0627\u0644\u0645\u0646\u0637\u0642 \u062a\u0645\u0627\u0645\u0627\u064b \u0628\u0644\u0627 \u0623\u064a \u062a\u063a\u064a\u064a\u0631. -->\n<div class=\"pnl\" id=\"avPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"phd\"><span class=\"ptit\">\u0645\u0636\u0627\u062f \u0627\u0644\u0641\u064a\u0631\u0648\u0633\u0627\u062a</span><div class=\"pcl\" onclick=\"closeAVPanel()\">\u2715</div></div>\n <div class=\"shsc\">\n <div class=\"scard\" style=\"text-align:center;padding:20px 14px\">\n <div style=\"font-family:var(--fo);font-size:13px;font-weight:800;color:var(--on)\" id=\"av-status\">\u2014</div>\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);margin-top:6px\">\u0627\u0644\u0636\u063a\u0637 \u0627\u0644\u062d\u0631\u0627\u0631\u064a \u0627\u0644\u062d\u0627\u0644\u064a: <span id=\"av-stress\">\u2014</span></div>\n </div>\n <div class=\"slbl\">\u0627\u0644\u0641\u0626\u0627\u062a \u0627\u0644\u0645\u062d\u0645\u064a\u0629 \u2014 \u062a\u062d\u0645\u064a \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0646\u0641\u0633\u0647\u060c \u0644\u0627 \u0633\u0645\u0639\u0643</div>\n <div class=\"scard\">\n <div class=\"si\" style=\"cursor:default\">\n <div class=\"iw iav\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u062a\u0631\u062f\u062f\u0627\u062a \u062d\u0631\u0627\u0631\u064a\u0629</div><div class=\"sd\">\u0645\u0631\u062a\u0628\u0637\u0629 \u062a\u0643\u0631\u0627\u0631\u0627\u064b \u0628\u0627\u0631\u062a\u0641\u0627\u0639 \u062d\u0631\u0627\u0631\u0629 \u0627\u0644\u062c\u0647\u0627\u0632 \u2014 \u062d\u0638\u0631 \u062a\u0644\u0642\u0627\u0626\u064a \u0628\u0639\u062f 8 \u062a\u0643\u0631\u0627\u0631\u0627\u062a</div></div>\n <span class=\"ban-total-badge\" id=\"av-thermal-cnt\">0</span>\n </div>\n <div class=\"si\" style=\"cursor:default\">\n <div class=\"iw iav\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u062a\u0631\u062f\u062f\u0627\u062a \u062a\u062e\u0645\u0651\u0644</div><div class=\"sd\">\u0645\u0631\u062a\u0628\u0637\u0629 \u062a\u0643\u0631\u0627\u0631\u0627\u064b \u0628\u062a\u0642\u0637\u0651\u0639 \u0627\u0644\u0625\u0637\u0627\u0631\u0627\u062a (\u0641\u0648\u0642 50ms) \u2014 \u062d\u0638\u0631 \u062a\u0644\u0642\u0627\u0626\u064a \u0628\u0639\u062f 8 \u062a\u0643\u0631\u0627\u0631\u0627\u062a</div></div>\n <span class=\"ban-total-badge\" id=\"av-lag-cnt\">0</span>\n </div>\n </div>\n <div class=\"slbl\">\u0633\u062c\u0644\u0651 \u0627\u0644\u062a\u0647\u062f\u064a\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0627\u064a\u064e\u062f\u0629</div>\n <div class=\"scard\" id=\"av-list\"><div class=\"ban-empty\">\u2014</div></div>\n <div class=\"slbl\">\u0641\u062d\u0635 \u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</div>\n <div class=\"scard\">\n <div style=\"font-family:var(--fo);font-size:10px;color:var(--dim);line-height:1.7;margin-bottom:10px\">\n \u064a\u0641\u062d\u0635 \u0642\u0648\u0627\u0626\u0645 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u062f\u0627\u062e\u0644\u064a\u0629 (\u0627\u0644\u062d\u0638\u0631 \u00b7 \u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062a\u062f\u0627\u062e\u0644 \u00b7 \u0642\u0627\u0639\u062f\u0629 FreqDB \u00b7 \u0627\u0644\u062a\u0635\u0648\u064a\u062a) \u0628\u062d\u062b\u0627\u064b \u0639\u0646\n \u0625\u062f\u062e\u0627\u0644\u0627\u062a \u0641\u0627\u0633\u062f\u0629 (NaN \u0623\u0648 \u0623\u0642\u0644 \u0645\u0646 1Hz) \u0642\u062f \u062a\u064f\u0633\u0628\u0650\u0651\u0628 \u0623\u0639\u0637\u0627\u0644\u0627\u064b \u0641\u064a \u0627\u0644\u0648\u0627\u062c\u0647\u0629 \u2014 \u064a\u0639\u0645\u0644 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u0639\u0646\u062f \u0643\u0644\n \u0628\u062f\u0621 \u062a\u0634\u063a\u064a\u0644 \u0648\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u062c\u0644\u0633\u0629 \u0648\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0644\u0641\u060c \u0648\u064a\u0645\u0643\u0646 \u0623\u064a\u0636\u0627\u064b \u062a\u0634\u063a\u064a\u0644\u0647 \u064a\u062f\u0648\u064a\u0627\u064b \u0627\u0644\u0622\u0646.\n </div>\n <div class=\"part-save-btn\" onclick=\"runAVScan()\">\u0641\u062d\u0635 \u0627\u0644\u0622\u0646</div>\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);text-align:center\" id=\"av-scan-result\">\u2014</div>\n </div>\n <div style=\"text-align:center;padding:14px 0 4px;font-size:9px;color:rgba(255,255,255,.2)\">\u062a\u0641\u0639\u064a\u0644/\u0625\u064a\u0642\u0627\u0641 \u0647\u0627\u062a\u064a\u0646 \u0627\u0644\u0641\u0626\u062a\u064a\u0646 \u0645\u062a\u0627\u062d \u0623\u064a\u0636\u0627\u064b \u0645\u0646 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u2190 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629</div>\n </div>\n</div><!-- /avPanel -->\n<!-- SETTINGS SHEET -->\n<div class=\"pnl\" id=\"bSheet\"><div class=\"phdl\"><div class=\"pbar\"></div></div>\n<div class=\"phd\"><span class=\"ptit\">Settings</span><div class=\"pcl\" onclick=\"closeSheet()\">\u2715</div></div>\n<div class=\"shsc\">\n <!-- \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629 \u0648\u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u062a\u062f\u0627\u062e\u0644 \u2014 \u0646\u064f\u0642\u0644\u062a \u0625\u0644\u0649 \u0647\u0646\u0627 \u0645\u0646 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0628\u062a\u0627\u0631\u064a\u062e 28 \u0633\u0628\u062a\u0645\u0628\u0631\n 2026 (\u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645: \"\u062d\u0630\u0641 \u0643\u0644 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0648\u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u0649 \u0632\u0631 \u062a\u0634\u063a\u064a\u0644/\u0625\u064a\u0642\u0627\u0641 \u0648\u0627\u062d\u062f\" \u2014 \u0623\u0635\u0628\u062d\u062a \u0627\u0644\u0634\u0627\u0634\u0629\n \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0627\u0644\u0622\u0646 \u062d\u0627\u0644\u0629 + \u0632\u0631 \u0648\u0627\u062d\u062f \u0641\u0642\u0637\u060c \u0648\u0627\u0646\u062a\u0642\u0644\u062a \u0643\u0644 \u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u062a\u062d\u0643\u0645 \u0627\u0644\u0623\u062e\u0631\u0649\u060c \u0628\u0645\u0627 \u0641\u064a\u0647\u0627 \u0647\u0630\u0627 \u0627\u0644\u0642\u0633\u0645\n \u0628\u0645\u0641\u0627\u062a\u064a\u062d\u0647 \u0627\u0644\u0633\u062a\u0629 \u0648\u062d\u0642\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u062e\u0635\u0635\u0629 \u0648\u0632\u0631 \u0627\u0644\u062a\u0635\u062f\u064a\u0631\u060c \u0625\u0644\u0649 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u062f\u0648\u0646 \u0623\u064a \u062a\u063a\u064a\u064a\u0631 \u0641\u064a \u0645\u062d\u062a\u0648\u0627\u0647\u0627\n \u0623\u0648 \u0645\u064f\u0639\u0631\u0651\u0641\u0627\u062a\u0647\u0627 (IDs) \u0623\u0648 \u062f\u0648\u0627\u0644\u0647\u0627 \u2014 \u0641\u0644\u0627 \u062d\u0627\u062c\u0629 \u0644\u0623\u064a \u062a\u0639\u062f\u064a\u0644 JS\u060c \u0641\u0642\u0637 \u062a\u063a\u064a\u064a\u0631 \u0645\u0643\u0627\u0646\u0647\u0627 \u0641\u064a \u0627\u0644\u0635\u0641\u062d\u0629). -->\n <div class=\"slbl\">\u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629 \u0648\u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u062a\u062f\u0627\u062e\u0644</div>\n <div class=\"scard\">\n <div class=\"pban-cats\">\n <div class=\"pban-cat-row\" onclick=\"togglePermCat('harmful')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u062a\u0631\u062f\u062f\u0627\u062a \u0636\u0627\u0631\u0629</div>\n <div class=\"pban-cat-desc\">Power-line harmonics \u00b7 EMF \u00b7 50Hz/60Hz \u0648\u062a\u0648\u0627\u0641\u0642\u064a\u0627\u062a\u0647\u0627</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-harmful\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-harmful\" checked onchange=\"togglePermCat('harmful')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"pban-cat-row\" onclick=\"togglePermCat('noisy')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u062a\u0631\u062f\u062f\u0627\u062a \u0635\u0627\u062e\u0628\u0629</div>\n <div class=\"pban-cat-desc\">Fan \u00b7 Motor \u00b7 HVAC \u00b7 \u0627\u0644\u0636\u062c\u064a\u062c \u0627\u0644\u0645\u062d\u064a\u0637\u064a</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-noisy\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-noisy\" checked onchange=\"togglePermCat('noisy')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"pban-cat-row\" onclick=\"togglePermCat('mic')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u0645\u0644\u062a\u0642\u0637\u0629 mic \u062f\u0627\u0626\u0645\u0627\u064b</div>\n <div class=\"pban-cat-desc\">\u062a\u0631\u062f\u062f\u0627\u062a \u064a\u0644\u062a\u0642\u0637\u0647\u0627 \u0627\u0644\u0645\u0627\u064a\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u2014 \u0645\u062d\u0636\u0648\u0631\u0629 \u062f\u0627\u0626\u0645\u0627\u064b</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-mic\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-mic\" checked onchange=\"togglePermCat('mic')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"pban-cat-row thermal\" onclick=\"togglePermCat('thermal')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u062a\u0631\u062f\u062f\u0627\u062a \u062d\u0631\u0627\u0631\u064a\u0629</div>\n <div class=\"pban-cat-desc\">\u062a\u0631\u062f\u062f\u0627\u062a \u062a\u064f\u0633\u0628\u0628 \u0627\u0631\u062a\u0641\u0627\u0639 \u062d\u0631\u0627\u0631\u0629 \u0627\u0644\u0645\u0639\u0627\u0644\u062c/\u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u2014 \u0645\u062d\u0636\u0648\u0631\u0629 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-thermal\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-thermal\" checked onchange=\"togglePermCat('thermal')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"pban-cat-row lag\" onclick=\"togglePermCat('lag')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u062a\u0631\u062f\u062f\u0627\u062a \u062a\u062e\u0645\u0651\u0644</div>\n <div class=\"pban-cat-desc\">\u062a\u0631\u062f\u062f\u0627\u062a \u062a\u064f\u0628\u0637\u0626 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062c \u0648\u0627\u0644\u0646\u0638\u0627\u0645 \u2014 \u062a\u064f\u0631\u0635\u062f \u0648\u062a\u064f\u062d\u0636\u064e\u0631 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-lag\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-lag\" checked onchange=\"togglePermCat('lag')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"pban-cat-row\" onclick=\"togglePermCat('env')\">\n <div class=\"pban-cat-ico\"></div>\n <div class=\"pban-cat-info\">\n <div class=\"pban-cat-name\">\u0628\u064a\u0626\u0629 \u062e\u0627\u0631\u062c\u064a\u0629</div>\n <div class=\"pban-cat-desc\">\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0628\u064a\u0626\u0629 \u0627\u0644\u0645\u062d\u064a\u0637\u0629 \u0627\u0644\u0645\u0633\u062a\u0645\u0631\u0629 \u2014 \u0628\u0635\u0645\u0629 \u0627\u0644\u0645\u0643\u0627\u0646</div>\n </div>\n <span class=\"pban-cat-cnt\" id=\"pban-cnt-env\">0 \u062a\u0631\u062f\u062f</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pban-env\" onchange=\"togglePermCat('env')\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <!-- \u062a\u0634\u062f\u064a\u062f: \u0646\u0633\u062e\u0629 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629 \u0627\u0644\u0645\u062d\u0645\u064e\u0651\u0644\u0629 \u0641\u0639\u0644\u064a\u0627\u064b \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062c\u0647\u0627\u0632 \u2014 \u062a\u064f\u062d\u0633\u064e\u0628 \u062d\u064a\u0651\u0627\u064b \u0645\u0646\n CONFIRMED_BANS/CONFIRMED_INTERFERENCE\u060c \u0641\u0644\u0627 \u062a\u062d\u062a\u0627\u062c \u062a\u062d\u062f\u064a\u062b\u0627\u064b \u064a\u062f\u0648\u064a\u0627\u064b \u0645\u0639 \u0643\u0644 \u062f\u0641\u0639\u0629 \u062f\u0645\u062c\n \u062c\u062f\u064a\u062f\u0629. \u0627\u0644\u063a\u0631\u0636: \u064a\u0631\u0649 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0641\u0648\u0631\u0627\u064b \u0647\u0644 \u0646\u0633\u062e\u0629 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0645\u062b\u0628\u064e\u0651\u062a\u0629 \u0639\u0644\u0649 \u0627\u0644\u062c\u0647\u0627\u0632 \u0645\u062d\u062f\u064e\u0651\u062b\u0629\n \u0628\u0622\u062e\u0631 \u062f\u0645\u062c \u0642\u0628\u0644 \u0628\u062f\u0621 \u062c\u0644\u0633\u0629 \u0627\u0633\u062a\u0645\u0627\u0639 \u062c\u062f\u064a\u062f\u0629. -->\n <div class=\"pban-cat-desc\" id=\"pban-baseline-ver\" style=\"opacity:.55;padding:4px 12px\"></div>\n </div>\n <!-- \u0625\u0636\u0627\u0641\u0629 \u062d\u0638\u0631 \u0645\u062e\u0635\u064e\u0651\u0635 \u2014 \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 -->\n <div class=\"pban-add-row\">\n <input class=\"pban-inp\" id=\"pban-custom-inp\" type=\"number\" placeholder=\"\u0623\u0636\u0641 \u062a\u0631\u062f\u062f Hz \u0645\u062e\u0635\u0635...\" min=\"0.01\" step=\"0.01\" onkeydown=\"if(event.key==='Enter')addCustomPermBan()\">\n <div class=\"pban-add-btn\" onclick=\"addCustomPermBan()\">+ \u062d\u0636\u0631</div>\n </div>\n <!-- \u0642\u0627\u0626\u0645\u0629 \u0645\u062f\u0645\u062c\u0629 \u0648\u0627\u062d\u062f\u0629: \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0638\u0648\u0631\u0629 () + \u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062a\u062f\u0627\u062e\u0644 \u0627\u0644\u0645\u0631\u0635\u0648\u062f\u0629 () \u0645\u0639\u0627\u064b\u060c \u0645\u0631\u062a\u0651\u0628\u0629 \u0628\u0627\u0644\u062a\u0631\u062f\u062f -->\n <div class=\"pban-list\" id=\"pban-settings-list\">\n <div class=\"ban-empty\">\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644...</div>\n </div>\n <!-- \u062a\u0635\u062f\u064a\u0631/\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062d\u0636\u0631 \u2014 \u0627\u0646\u062a\u0642\u0644 \u0625\u0644\u0649 \u0646\u0627\u0641\u0630\u0629 \"\u0627\u0644\u0645\u0644\u0641\u0627\u062a\" \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0647 (\u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u2190 \u0627\u0644\u0645\u0644\u0641\u0627\u062a) -->\n <div class=\"si\" style=\"margin-top:10px\" onclick=\"openFilesPanel()\">\n <div class=\"iw iph\"></div>\n <div class=\"scnt\"><div class=\"sn\">\u062a\u0635\u062f\u064a\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062d\u0636\u0631</div><div class=\"sd\">JSON \u00b7 CSV \u00b7 TXT \u00b7 \u0627\u0633\u062a\u064a\u0631\u0627\u062f</div></div>\n <div class=\"chev\"><svg viewBox=\"0 0 24 24\"><polyline points=\"9 6 15 12 9 18\"/></svg></div>\n </div>\n </div>\n <div class=\"slbl\">AI Engine</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"tSW('sw-ai')\"><div class=\"iw iai2\"></div><div class=\"scnt\"><div class=\"sn\">AI Mode \u2014 Neural Net 16\u219224\u21928</div><div class=\"sd\">FreqDB \u00b7 Inverse Gen \u00b7 8 classes \u00b7 Self-learning</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-ai\" onchange=\"syncAI(this)\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-cl')\"><div class=\"iw ip\"></div><div class=\"scnt\"><div class=\"sn\">Closed Loop</div><div class=\"sd\">Mic \u2192 Process \u2192 Speaker \u2192 Mic</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-cl\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-evp')\"><div class=\"iw iev\">\u3030</div><div class=\"scnt\"><div class=\"sn\">EVP Detection</div><div class=\"sd\">Infrasonic &lt;40Hz anticipation</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-evp\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-emf')\"><div class=\"iw iem\"></div><div class=\"scnt\"><div class=\"sn\">EMF Detection</div><div class=\"sd\">50/60Hz harmonics up to Nyquist</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-emf\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-inv')\"><div class=\"iw io\">\u27f3</div><div class=\"scnt\"><div class=\"sn\">Inverse Generator</div><div class=\"sd\">Auto-cancel confirmed freqs (\u00d73)</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-inv\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-learn')\"><div class=\"iw iai\"></div><div class=\"scnt\"><div class=\"sn\">Self-Learning</div><div class=\"sd\">FreqDB + NN continuous training</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-learn\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n </div>\n <div class=\"slbl\">8 Frequency Classes</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"tSW('sw-c1')\"><div class=\"iw ig\">\u2295</div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c1)\">Class 1 \u2014 Positive</div><div class=\"sd\">Constructive energy \u00b7 building phase</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c1\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c2')\"><div class=\"iw iev\">\u2296</div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c2)\">Class 2 \u2014 Negative</div><div class=\"sd\">Destructive energy \u00b7 cancellation phase</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c2\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c3')\"><div class=\"iw io\">\u2213</div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c3)\">Class 3 \u2014 Neg\u2192Pos</div><div class=\"sd\">Alternating: starts negative \u2192 goes positive</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c3\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c4')\"><div class=\"iw ip\">\u00b1</div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c4)\">Class 4 \u2014 Pos\u2192Neg</div><div class=\"sd\">Alternating: starts positive \u2192 goes negative</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c4\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c5')\"><div class=\"iw iai\"></div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c5)\">Class 5 \u2014 Mic-Detectable</div><div class=\"sd\">20Hz\u2013Nyquist/2 \u00b7 mic can sense</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c5\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c6')\"><div class=\"iw io\"></div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c6)\">Class 6 \u2014 Mic-Invisible</div><div class=\"sd\">&lt;1Hz or &gt;Nyquist \u00b7 beyond mic range</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c6\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c7')\"><div class=\"iw iph\"></div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c7)\">Class 7 \u2014 Spk-Emittable</div><div class=\"sd\">0.01Hz\u2013Nyquist \u00b7 speaker can emit</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c7\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-c8')\"><div class=\"iw ips\"></div><div class=\"scnt\"><div class=\"sn\" style=\"color:var(--c8)\">Class 8 \u2014 Spk-Blocked</div><div class=\"sd\">&gt;Nyquist \u00b7 beyond speaker capability</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-c8\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n </div>\n <div class=\"slbl\">Silent Frequencies</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"tSW('sw-inf')\"><div class=\"iw iev\">\u3030</div><div class=\"scnt\"><div class=\"sn\">Infrasound &lt;20Hz</div><div class=\"sd\">Pressure weakening \u2014 inaudible</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-inf\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-ult')\"><div class=\"iw iai\">\u2191\u2191</div><div class=\"scnt\"><div class=\"sn\">Ultrasound &gt;20kHz</div><div class=\"sd\">Coherence break \u2014 inaudible</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-ult\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-phf')\"><div class=\"iw iph\">\u2295</div><div class=\"scnt\"><div class=\"sn\">Phase Coherent Field</div><div class=\"sd\">Silent coherent zone \u2014 physical</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-phf\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-sub')\"><div class=\"iw io\">\u3031</div><div class=\"scnt\"><div class=\"sn\">Sub-1Hz Reset</div><div class=\"sd\">0.01\u20130.95Hz vibration baseline</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-sub\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"si\" onclick=\"tSW('sw-pie')\"><div class=\"iw ips\">\u224b</div><div class=\"scnt\"><div class=\"sn\">Piezoelectric Structural</div><div class=\"sd\">Material resonance cancel</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-pie\" checked><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n </div>\n <div class=\"slbl\">Algorithm Tuning</div>\n <div class=\"scard\">\n <div class=\"si\"><div class=\"iw ib\"></div><div class=\"scnt\"><div class=\"sn\">Sensitivity</div><div class=\"sd\">Detection threshold</div></div><span class=\"sv\" id=\"sv-sens\">70%</span></div>\n <div class=\"shsl\"><input type=\"range\" id=\"sl-sens\" min=\"10\" max=\"100\" value=\"70\" oninput=\"P.sens=+this.value;document.getElementById('sv-sens').textContent=this.value+'%'\"></div>\n <div class=\"si\"><div class=\"iw ip\">\u03b1</div><div class=\"scnt\"><div class=\"sn\">Wiener \u03b1</div><div class=\"sd\">Spectral subtraction strength</div></div><span class=\"sv\" id=\"sv-al\">1.5</span></div>\n <div class=\"shsl\"><input type=\"range\" id=\"sl-al\" min=\"100\" max=\"300\" value=\"150\" oninput=\"P.alpha=+this.value/100;document.getElementById('sv-al').textContent=(this.value/100).toFixed(1)\"></div>\n <div class=\"si\"><div class=\"iw io\">N</div><div class=\"scnt\"><div class=\"sn\">NN Learning Rate</div><div class=\"sd\">Neural network lr</div></div><span class=\"sv\" id=\"sv-lr\">0.012</span></div>\n <div class=\"shsl\"><input type=\"range\" id=\"sl-lr\" min=\"1\" max=\"50\" value=\"12\" oninput=\"NN.lr=+this.value/1000;document.getElementById('sv-lr').textContent=(this.value/1000).toFixed(3)\"></div>\n <div class=\"si\"><div class=\"iw ig\"></div><div class=\"scnt\"><div class=\"sn\">Confirm Threshold</div><div class=\"sd\">Repeats to confirm freq is real</div></div><span class=\"sv\" id=\"sv-thr\">3\u00d7</span></div>\n <div class=\"shsl\"><input type=\"range\" id=\"sl-thr\" min=\"2\" max=\"10\" value=\"3\" oninput=\"appState.FREQ_THRESH=+this.value;document.getElementById('sv-thr').textContent=this.value+'\u00d7'\"></div>\n </div>\n <div class=\"slbl\">\u0648\u0636\u0639 \u0627\u0644\u0637\u0627\u0642\u0629</div>\n <div class=\"scard\">\n <div class=\"si\">\n <div class=\"iw\" style=\"background:rgba(130,130,130,.12);color:var(--on);font-size:14px\"></div>\n <div class=\"scnt\"><div class=\"sn\">Power Mode</div><div class=\"sd\">\u064a\u0636\u0628\u0637 FFT \u00b7 \u0645\u0639\u062f\u0644 \u0627\u0644\u0643\u0634\u0641 \u00b7 \u0637\u0628\u0642\u0627\u062a \u0627\u0644\u0645\u0630\u0628\u0630\u0628 \u062f\u0641\u0639\u0629\u064b \u0648\u0627\u062d\u062f\u0629</div></div>\n <span class=\"therm-badge\" id=\"therm-badge\"> THROTTLE</span>\n </div>\n <div class=\"preset-row\">\n <button class=\"preset-btn\" id=\"preset-lp\" onclick=\"applyPreset('low')\"><br>\u062a\u0648\u0641\u064a\u0631</button>\n <button class=\"preset-btn act\" id=\"preset-bl\" onclick=\"applyPreset('balanced')\"><br>\u0645\u062a\u0648\u0627\u0632\u0646</button>\n <button class=\"preset-btn\" id=\"preset-fp\" onclick=\"applyPreset('full')\"><br>\u0643\u0627\u0645\u0644</button>\n </div>\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);margin-top:7px;line-height:1.6\" id=\"preset-desc\">\u0645\u062a\u0648\u0627\u0632\u0646 \u2014 FFT 8192 \u00b7 \u0643\u0634\u0641 40ms \u00b7 \u062c\u0645\u064a\u0639 \u0627\u0644\u0637\u0628\u0642\u0627\u062a \u0645\u0641\u0639\u0651\u0644\u0629 \u00b7 \u03b1 1.5</div>\n </div>\n <div class=\"slbl\">\u0648\u0636\u0639 \u0627\u0644\u0646\u0648\u0645 \u0627\u0644\u0630\u0643\u064a</div>\n <div class=\"scard\">\n <div class=\"si\" onclick=\"event.target.closest('.sw')||tSW('sw-bedtime')\"><div class=\"iw\" style=\"background:rgba(147,147,147,.12);color:#a6a6a6\"></div><div class=\"scnt\"><div class=\"sn\">Smart Bedtime</div><div class=\"sd\">\u062a\u0634\u063a\u064a\u0644 \u062a\u0644\u0642\u0627\u0626\u064a \u0644\u0644\u0645\u062d\u0631\u0643 \u0639\u0646\u062f \u0627\u0644\u0648\u0642\u062a \u0627\u0644\u0645\u062d\u062f\u062f \u064a\u0648\u0645\u064a\u0627\u064b</div></div><label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-bedtime\" onchange=\"toggleBedtime(this)\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label></div>\n <div class=\"shsl\" style=\"display:flex;align-items:center;gap:10px;padding:10px 14px\">\n <span style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">\u0648\u0642\u062a \u0627\u0644\u062a\u0634\u063a\u064a\u0644</span>\n <input type=\"time\" id=\"bedtimeTimeInp\" value=\"23:00\" oninput=\"bedtimeSetTime(this.value)\" style=\"background:var(--d3,#1a1a1a);border:1px solid var(--b0,#333);border-radius:8px;color:var(--t1,#fff);font-family:var(--fm);font-size:11px;padding:5px 8px\">\n </div>\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);padding:0 14px 10px;line-height:1.6\" id=\"bedtime-status\">\u25a0 \u0645\u062a\u0648\u0642\u0641 \u2014 \u0641\u0639\u0651\u0644 \u0627\u0644\u0645\u0641\u062a\u0627\u062d \u0644\u062c\u062f\u0648\u0644\u0629 \u062a\u0634\u063a\u064a\u0644 \u062a\u0644\u0642\u0627\u0626\u064a</div>\n </div>\n <!-- \u0627\u0633\u062a\u064f\u0639\u064a\u062f\u062a 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u0645\u0646 ZERO-WAVE-v5.html (toggleSleep/setTimer) \u2014 \u0641\u0643\u0631\u0629 \u0645\u062e\u062a\u0644\u0641\u0629 \u0639\u0646\n \"\u0648\u0636\u0639 \u0627\u0644\u0646\u0648\u0645 \u0627\u0644\u0630\u0643\u064a\" \u0623\u0639\u0644\u0627\u0647: \u0647\u0630\u0647 \u0639\u062f\u0651 \u062a\u0646\u0627\u0632\u0644\u064a \u064a\u062f\u0648\u064a (\u064a\u0634\u063a\u0651\u0644 \u0627\u0644\u0622\u0646\u060c \u064a\u0648\u0642\u0641 \u0628\u0639\u062f \u0645\u062f\u0629 \u0645\u062d\u062f\u062f\u0629) \u0628\u062f\u0644 \u062c\u062f\u0648\u0644\u0629\n \u0628\u0648\u0642\u062a \u062b\u0627\u0628\u062a \u064a\u0648\u0645\u064a\u0627\u064b\u061b \u0627\u0644\u0641\u0643\u0631\u062a\u0627\u0646 \u062a\u062a\u0643\u0627\u0645\u0644\u0627\u0646 (\u0628\u062f\u0621 \u0639\u0646\u062f \u0648\u0642\u062a \u0645\u062d\u062f\u062f + \u0625\u064a\u0642\u0627\u0641 \u0628\u0639\u062f \u0645\u062f\u0629 \u0645\u0646 \u0628\u062f\u0621 \u0627\u0644\u0646\u0648\u0645 \u0641\u0639\u0644\u064a\u0627\u064b). -->\n <div class=\"slbl\">\u0645\u0624\u0642\u062a \u0627\u0644\u0646\u0648\u0645</div>\n <div class=\"scard\">\n <div style=\"font-family:var(--fo);font-size:9px;color:var(--muted);padding:2px 14px 10px\">\u0634\u063a\u0651\u0644 \u0627\u0644\u0645\u062d\u0631\u0643 \u0627\u0644\u0622\u0646 \u0644\u0645\u062f\u0629 \u0645\u062d\u062f\u062f\u0629 \u062b\u0645 \u0623\u0648\u0642\u0641\u0647 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b</div>\n <div class=\"sleep-preset-row\" style=\"padding:0 14px\">\n <div class=\"sleep-preset-btn\" onclick=\"sleepSetMinutes(15,this)\">15 \u062f</div>\n <div class=\"sleep-preset-btn sel\" onclick=\"sleepSetMinutes(30,this)\">30 \u062f</div>\n <div class=\"sleep-preset-btn\" onclick=\"sleepSetMinutes(45,this)\">45 \u062f</div>\n <div class=\"sleep-preset-btn\" onclick=\"sleepSetMinutes(60,this)\">60 \u062f</div>\n <div class=\"sleep-preset-btn\" onclick=\"sleepSetMinutes(90,this)\">90 \u062f</div>\n </div>\n <div class=\"sleep-timer-disp\" id=\"sleepTimerDisp\" style=\"display:none\">30:00</div>\n <div style=\"padding:0 14px 14px\">\n <button class=\"sleep-timer-btn\" id=\"sleepTimerBtn\" onclick=\"sleepToggle()\">\u0628\u062f\u0621 \u0645\u0624\u0642\u062a \u0627\u0644\u0646\u0648\u0645</button>\n </div>\n </div>\n <div style=\"text-align:center;padding:18px 0 4px;font-size:11px;color:rgba(255,255,255,.14)\">ZERO AI v25 \u00b7 16 Classes \u00b7 PERSIST \u00b7 My Files \u00b7 Neural Intelligence \u00b7 2026</div>\n</div></div>\n<!-- AI BRAIN PANEL -->\n<div class=\"pnl\" id=\"aiPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"ai-ph\">\n <div class=\"ai-ph-t\"><div class=\"ai-dot\"></div>AI Brain \u2014 8 Classes \u00b7 Neural Net</div>\n <div class=\"ai-ph-c\" onclick=\"closeAIP()\">\u2715</div>\n </div>\n <div class=\"tab-bar\">\n <button class=\"tbtn act\" id=\"tb0\" onclick=\"openTab(0)\">FREQ DB</button>\n <button class=\"tbtn\" id=\"tb1\" onclick=\"openTab(1)\">NN</button>\n <button class=\"tbtn\" id=\"tb2\" onclick=\"openTab(2)\">8 CLASSES</button>\n <button class=\"tbtn\" id=\"tb3\" onclick=\"openTab(3)\">MIC</button>\n <button class=\"tbtn\" id=\"tb4\" onclick=\"openTab(4)\">LOG</button>\n <button class=\"tbtn\" id=\"tb5\" onclick=\"openTab(5)\">EXEC</button>\n <button class=\"tbtn\" id=\"tb6\" onclick=\"openTab(6)\">BG</button>\n <button class=\"tbtn\" id=\"tb7\" onclick=\"openTab(7)\">FILES</button>\n <button class=\"tbtn\" id=\"tb8\" onclick=\"openTab(8)\">STATS</button>\n </div>\n <!-- TAB 0: FREQ DB -->\n <div class=\"pane on\" id=\"pane0\">\n <div class=\"stat4\">\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"db-cap\" style=\"color:var(--on)\">0</div><div class=\"stat-l\">CAPTURED</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"db-conf\" style=\"color:var(--ai)\">0</div><div class=\"stat-l\">CONFIRMED</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"db-canc\" style=\"color:var(--zero)\">0</div><div class=\"stat-l\">CANCELLED</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"db-inv\" style=\"color:var(--sharp)\">0</div><div class=\"stat-l\">INVERSE</div></div>\n </div>\n <div class=\"nc\"><div class=\"nc-h\">Frequency Database \u2014 Top Entries</div><div id=\"flist\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Waiting for mic input...</div></div></div>\n <div class=\"nc\"><div class=\"nc-h\">Inverse Generator Rule</div><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);line-height:1.6\">Captured freq \u00d7 <span style=\"color:var(--ai)\">3</span> = confirmed real<br>\u2192 Build inverse (phase +180\u00b0) via speaker<br>\u2192 Verify via mic after 800ms<br>\u2192 If fail: Anti-Search (phase rotation 22.5\u00b0)<br>\u2192 If fail \u00d75: Anti-Pattern (hz/2 \u00b7 hz\u00d71.5 \u00b7 hz/3)</div></div>\n <div class=\"nc\" style=\"border-color:rgba(156,156,156,.2)\"><div class=\"nc-h\" style=\"color:rgba(156,156,156,.6)\">Active Inverse Oscillators</div><div id=\"inv-list\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">None active</div></div></div>\n <div class=\"nc\"><div class=\"nc-h\"> Spectrogram \u2014 FFT Waterfall</div><canvas id=\"specCv\"></canvas></div>\n <div class=\"nc\" style=\"border-color:rgba(149,149,149,.18)\"><div class=\"nc-h\" style=\"color:rgba(149,149,149,.7);display:flex;align-items:center\"> Frequency Timeline \u2014 2 min<span class=\"freq-hop-flash\" id=\"freqHopFlash\"></span><span class=\"freq-hop-ct\" id=\"freqHopCt\"></span></div><canvas id=\"freqTimeCv\"></canvas></div>\n <div class=\"nc\" style=\"border-color:rgba(165,165,165,.2)\"><div class=\"nc-h\" style=\"color:rgba(165,165,165,.7)\"> Notch Suppression (<span id=\"notch-count\">0</span> active<span class=\"supp-eff\" id=\"suppEffBadge\"></span>)</div><div id=\"notch-list\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">No confirmed freqs yet \u2014 \u0641\u0648\u0631 \u0627\u0644\u062a\u0623\u0643\u064a\u062f \u064a\u064f\u0646\u0634\u0623 notch \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b</div></div></div>\n <div class=\"nc\" style=\"border-color:rgba(120,120,120,.2)\"><div class=\"nc-h\" style=\"color:rgba(120,120,120,.7)\"> Harmonic Clusters (<span id=\"cluster-count\">0</span>)</div><div id=\"cluster-list\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">\u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u062a\u0631\u062f\u062f\u0627\u062a \u0645\u0624\u0643\u062f\u0629...</div></div></div>\n </div>\n <!-- TAB 1: NEURAL NET -->\n <div class=\"pane\" id=\"pane1\">\n <div class=\"nc\"><div class=\"nc-h\">Architecture: 12 Input \u2192 16 Hidden \u2192 6 Output</div>\n <div style=\"display:flex;gap:10px;font-family:var(--fm);font-size:9px\">\n <span style=\"color:var(--muted)\">Trained: <span id=\"nn-tc\" style=\"color:var(--zero)\">0</span></span>\n <span style=\"color:var(--muted)\">Loss: <span id=\"nn-loss\" style=\"color:var(--ai)\">1.0000</span></span>\n <span style=\"color:var(--muted)\">LR: <span id=\"nn-lr\" style=\"color:var(--sharp)\">0.0120</span></span>\n </div>\n </div>\n <div class=\"nc\"><div class=\"nc-h\">NN Output \u2192 Silent Freq Powers</div>\n <div class=\"nog\">\n <div class=\"noc\" style=\"border-color:rgba(120,120,120,.2)\"><div class=\"nov\" id=\"nno0\" style=\"color:var(--c1)\">\u2014</div><div class=\"nol\">INF</div></div>\n <div class=\"noc\" style=\"border-color:rgba(149,149,149,.2)\"><div class=\"nov\" id=\"nno1\" style=\"color:var(--c5)\">\u2014</div><div class=\"nol\">ULT</div></div>\n <div class=\"noc\" style=\"border-color:rgba(206,206,206,.2)\"><div class=\"nov\" id=\"nno2\" style=\"color:var(--sharp)\">\u2014</div><div class=\"nol\">STD</div></div>\n <div class=\"noc\" style=\"border-color:rgba(136,136,136,.2)\"><div class=\"nov\" id=\"nno3\" style=\"color:var(--c3)\">\u2014</div><div class=\"nol\">SUB</div></div>\n <div class=\"noc\" style=\"border-color:rgba(165,165,165,.2)\"><div class=\"nov\" id=\"nno4\" style=\"color:var(--c7)\">\u2014</div><div class=\"nol\">PHF</div></div>\n <div class=\"noc\" style=\"border-color:rgba(136,136,136,.2)\"><div class=\"nov\" id=\"nno5\" style=\"color:var(--c8)\">\u2014</div><div class=\"nol\">PIE</div></div>\n </div>\n </div>\n <div class=\"nc\"><div class=\"nc-h\">Input Vector (12 features)</div>\n <div style=\"font-family:var(--fm);font-size:8px;color:var(--muted);line-height:1.7\">[0] Hz_norm &nbsp;[1] FanEnergy &nbsp;[2] DB_size<br>[3] EVP &nbsp;[4] EMF &nbsp;[5] LoopError<br>[6] Phase_dev &nbsp;[7] FxLMS_MSE &nbsp;[8] Silence<br>[9] 1-LoopErr &nbsp;[10] TrainMat &nbsp;[11] TimeOfDay</div>\n </div>\n <div class=\"nc\"><div class=\"nc-h\">Reward History</div><canvas id=\"rwCv\" width=\"340\" height=\"45\" style=\"width:100%;height:45px;background:rgba(0,0,0,.3);border-radius:4px\"></canvas></div>\n <div class=\"nc\"><div class=\"nc-h\">W1 Weight Matrix \u2014 12 inputs \u00d7 16 hidden</div><canvas id=\"nnWtCv\" style=\"width:100%;height:60px;display:block;border-radius:4px;image-rendering:pixelated\"></canvas></div>\n <div class=\"nc\"><div class=\"nc-h\" style=\"color:rgba(120,120,120,.7)\"> Env-Adaptive Layer Status</div>\n <div style=\"display:flex;gap:8px;flex-wrap:wrap;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>INF: <span id=\"ea-inf\" style=\"color:var(--c1);font-weight:700\">\u2014</span></span>\n <span>ULT: <span id=\"ea-ult\" style=\"color:var(--c5);font-weight:700\">\u2014</span></span>\n <span>PHF: <span id=\"ea-phf\" style=\"color:var(--c7);font-weight:700\">\u2014</span></span>\n <span>SUB: <span id=\"ea-sub\" style=\"color:var(--c3);font-weight:700\">\u2014</span></span>\n <span>PIE: <span id=\"ea-pie\" style=\"color:var(--c8);font-weight:700\">\u2014</span></span>\n <span style=\"margin-left:6px;color:var(--muted)\">env: <span id=\"ea-env\" style=\"color:rgba(120,120,120,.9);font-weight:700\">\u2014</span></span>\n </div>\n </div>\n </div>\n <!-- TAB 2: 8 CLASSES -->\n <div class=\"pane\" id=\"pane2\">\n <div class=\"nc\"><div class=\"nc-h\">8 Frequency Classification System</div>\n <div class=\"cg2\">\n <div class=\"cc\" style=\"border-color:rgba(169,169,169,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c1)\"></div><span style=\"color:var(--c1)\">C1 \u2295 Positive</span></div><div class=\"cc-b\">Constructive energy. Builds and reinforces oscillation. Amplitude grows over time.</div><div class=\"cc-v\" id=\"c1v\" style=\"color:var(--c1)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(104,104,104,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c2)\"></div><span style=\"color:var(--c2)\">C2 \u2296 Negative</span></div><div class=\"cc-b\">Destructive energy. Cancellation phase. Amplitude collapses over time.</div><div class=\"cc-v\" id=\"c2v\" style=\"color:var(--c2)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(156,156,156,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c3)\"></div><span style=\"color:var(--c3)\">C3 \u2213 Neg\u2192Pos</span></div><div class=\"cc-b\">Starts negative then switches positive. Transitional alternating class.</div><div class=\"cc-v\" id=\"c3v\" style=\"color:var(--c3)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(120,120,120,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c4)\"></div><span style=\"color:var(--c4)\">C4 \u00b1 Pos\u2192Neg</span></div><div class=\"cc-b\">Starts positive then switches negative. Inverse transitional class.</div><div class=\"cc-v\" id=\"c4v\" style=\"color:var(--c4)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(149,149,149,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c5)\"></div><span style=\"color:var(--c5)\">C5 \u2713 Mic-Det</span></div><div class=\"cc-b\">20Hz\u2013Nyquist/2. Microphone sensitivity range. Fully capturable.</div><div class=\"cc-v\" id=\"c5v\" style=\"color:var(--c5)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(136,136,136,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c6)\"></div><span style=\"color:var(--c6)\">C6 \u2717 Mic-Inv</span></div><div class=\"cc-b\">&lt;1Hz or &gt;Nyquist. Below/above mic sensitivity. Invisible to capture.</div><div class=\"cc-v\" id=\"c6v\" style=\"color:var(--c6)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(165,165,165,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c7)\"></div><span style=\"color:var(--c7)\">C7 \u2713 Spk-Emit</span></div><div class=\"cc-b\">0.01Hz\u2013Nyquist. Speaker transducer can physically produce this range.</div><div class=\"cc-v\" id=\"c7v\" style=\"color:var(--c7)\">\u2014</div></div>\n <div class=\"cc\" style=\"border-color:rgba(136,136,136,.2)\"><div class=\"cc-h\"><div class=\"cc-d\" style=\"background:var(--c8)\"></div><span style=\"color:var(--c8)\">C8 \u2717 Spk-Blk</span></div><div class=\"cc-b\">&gt;Nyquist. Beyond hardware capability. Cannot be reproduced by speaker.</div><div class=\"cc-v\" id=\"c8v\" style=\"color:var(--c8)\">\u2014</div></div>\n </div>\n </div>\n <div class=\"nc\"><div class=\"nc-h\">Class Distribution (live)</div><canvas id=\"classCv\" width=\"340\" height=\"60\" style=\"width:100%;height:60px;background:rgba(0,0,0,.3);border-radius:4px\"></canvas></div>\n </div>\n <!-- TAB 3: MIC PROFILE -->\n <div class=\"pane\" id=\"pane3\">\n <div class=\"nc\"><div class=\"nc-h\"> Microphone Capabilities</div><div id=\"mic-prof\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Start AI to profile mic...</div></div></div>\n <div class=\"nc\"><div class=\"nc-h\">Live Spectrum</div><canvas id=\"micSpecCv\" width=\"340\" height=\"55\" style=\"width:100%;height:55px;background:rgba(0,0,0,.3);border-radius:4px\"></canvas></div>\n <div class=\"nc\"><div class=\"nc-h\">Feature Extraction (live)</div><div id=\"mic-feat\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Waiting...</div></div></div>\n </div>\n <!-- TAB 4: LOG -->\n <div class=\"pane\" id=\"pane4\"><div class=\"nc\" style=\"flex:1;overflow-y:auto\"><div class=\"nc-h\">Neural Network Activity Log</div><div id=\"nn-log\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Log starts when AI is active...</div></div></div></div>\n <!-- TAB 5: AI EXEC \u2014 Self-Building Engine -->\n <div class=\"pane\" id=\"pane5\" style=\"padding:0;gap:0\">\n <div class=\"exec-hd\">\n <div class=\"exec-left\">\n <div class=\"exec-run-dot\" id=\"execDot\"></div>\n <span class=\"exec-lbl\">AI EXEC</span>\n <span class=\"exec-prog-curr\" id=\"execCurr\">STANDBY</span>\n </div>\n <span class=\"exec-cyc\" id=\"execCycLbl\">cycle 0</span>\n </div>\n <div class=\"exec-stat-row\">\n <div class=\"exec-sv\"><span class=\"exec-sk\">sil</span><span class=\"exec-val\" id=\"ex-sil\">0%</span></div>\n <div class=\"exec-sv\"><span class=\"exec-sk\">NN</span><span class=\"exec-val\" id=\"ex-nn\">\u2014</span></div>\n <div class=\"exec-sv\"><span class=\"exec-sk\">DB</span><span class=\"exec-val\" id=\"ex-db\">0</span></div>\n <div class=\"exec-sv\"><span class=\"exec-sk\">prog</span><span class=\"exec-val\" id=\"ex-prog\">0</span></div>\n </div>\n <div class=\"exec-log\" id=\"execLog\"></div>\n <div class=\"exec-ir\">\n <input class=\"exec-inp\" id=\"execInp\"\n placeholder=\"ANALYZE \u00b7 BAN 50 \u00b7 NOTCH 50 \u00b7 GATE \u00b7 LIST\"\n onkeydown=\"if(event.key==='Enter'){runExecCmd();event.preventDefault()}\">\n <button class=\"exec-btn\" onclick=\"runExecCmd()\">\u25b6</button>\n </div>\n </div>\n <!-- TAB 6: BACKGROUND MODE -->\n <div class=\"pane\" id=\"pane6\">\n <div class=\"bg-card\">\n <div class=\"bg-h\">System Status</div>\n <div class=\"sys-row\">\n <div class=\"sy warn\" id=\"bg-wl\"><div class=\"syd\"></div>WakeLock</div>\n <div class=\"sy warn\" id=\"bg-wk\"><div class=\"syd\"></div>Worker</div>\n <div class=\"sy warn\" id=\"bg-sw\"><div class=\"syd\"></div>SW</div>\n <div class=\"sy warn\" id=\"bg-nf\"><div class=\"syd\"></div>Notif</div>\n </div>\n </div>\n <div class=\"wk2\">\n <div class=\"wkc\"><div class=\"wkv\" id=\"bg-runs\" style=\"color:var(--c5)\">0</div><div class=\"wkl\">BG RUNS</div></div>\n <div class=\"wkc\"><div class=\"wkv\" id=\"bg-ms\" style=\"color:var(--c3)\">\u2014</div><div class=\"wkl\">BG TIME</div></div>\n <div class=\"wkc\"><div class=\"wkv\" id=\"bg-wkc\" style=\"color:var(--zero)\">\u2014</div><div class=\"wkl\">WK CYCLES</div></div>\n <div class=\"wkc\"><div class=\"wkv\" id=\"bg-notifs\" style=\"color:var(--ai)\">0</div><div class=\"wkl\">NOTIFS SENT</div></div>\n </div>\n <div class=\"bg-card\">\n <div class=\"bg-h\">Background Activity Log</div>\n <div id=\"bg-log\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Waiting for background events...</div></div>\n </div>\n <div class=\"nc\">\n <div class=\"nc-h\">Background Architecture</div>\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);line-height:1.7\">\n <span style=\"color:var(--zero)\">Wake Lock</span> \u2014 screen stays on, no auto-sleep<br>\n <span style=\"color:var(--c5)\">Web Worker</span> \u2014 timer runs at full speed in bg<br>\n <span style=\"color:var(--ai)\">Service Worker</span> \u2014 25s keep-alive heartbeat<br>\n <span style=\"color:var(--sharp)\">Notification</span> \u2014 live status \u00b7 refreshes 15s<br>\n <span style=\"color:var(--c7)\">AudioContext</span> \u2014 continues capturing in bg<br>\n <span style=\"color:var(--c3)\">Visibility API</span> \u2014 detects bg/fg transitions\n </div>\n </div>\n <div class=\"perm-status-row\" id=\"perm-status-bar\" style=\"margin-top:6px\">\n <div class=\"ps-badge warn\" id=\"ps-mic\"> Mic</div>\n <div class=\"ps-badge warn\" id=\"ps-notif\"> Notif</div>\n <div class=\"ps-badge warn\" id=\"ps-store\"> Store</div>\n <div class=\"ps-badge warn\" id=\"ps-wake\"> Wake</div>\n <div class=\"ps-badge warn\" id=\"ps-file\"> Files</div>\n </div>\n <button class=\"bg-tgl\" id=\"bg-toggle\" onclick=\"toggleBGMode()\">BG MODE: ON</button>\n </div><!-- /pane6 -->\n\n <!-- TAB 7: FILE STORAGE -->\n <div class=\"pane\" id=\"pane7\">\n <div class=\"stat4\">\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"st-sessions\" style=\"color:var(--zero)\">0</div><div class=\"stat-l\">SESSIONS</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"ach-count\" style=\"color:var(--sharp)\">0/15</div><div class=\"stat-l\">ACHIEVE</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"st-term-ev\" style=\"color:var(--c5)\">0</div><div class=\"stat-l\">TERM EVTS</div></div>\n <div class=\"stat-c\"><div class=\"stat-v\" id=\"st-kb\" style=\"color:var(--ai)\">0</div><div class=\"stat-l\">KB SAVED</div></div>\n </div>\n <!-- Connection status: AI \u2194 Terminal \u2194 UDS -->\n <div class=\"nc\" style=\"border-color:rgba(169,169,169,.2)\">\n <div class=\"nc-h\" style=\"color:rgba(169,169,169,.6)\">System Links</div>\n <div style=\"display:flex;flex-direction:column;gap:4px\" id=\"link-status\">\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Loading...</div>\n </div>\n </div>\n <div class=\"nc\" style=\"border-color:rgba(169,169,169,.18)\">\n <div class=\"nc-h\" style=\"color:rgba(169,169,169,.6)\"> Local File Storage</div>\n <div id=\"st-paths\" style=\"font-family:var(--fm);font-size:8px;color:var(--muted);margin-bottom:6px;line-height:1.6\">Loading paths...</div>\n <div class=\"btn-row2\">\n <div class=\"st-btn up\" onclick=\"saveFreqDBLocal()\"> FreqDB</div>\n <div class=\"st-btn ai\" onclick=\"saveNNLocal()\"> NN</div>\n <div class=\"st-btn ai\" onclick=\"saveFullSessionLocal()\"> Session</div>\n </div>\n </div>\n <div class=\"nc\">\n <div class=\"nc-h\">Export / Import</div>\n <div class=\"btn-row2\">\n <div class=\"st-btn dn\" onclick=\"exportJSON()\"> JSON</div>\n <div class=\"st-btn dn\" onclick=\"exportCSV()\"> FreqCSV</div>\n <label class=\"st-btn\" style=\"border-color:rgba(156,156,156,.35);color:var(--c3)\"> Import<input type=\"file\" accept=\".json\" style=\"display:none\" onchange=\"importJSON(this.files[0])\"></label>\n <div class=\"st-btn ai\" onclick=\"restoreNNFromDB()\"> Restore NN</div>\n </div>\n </div>\n <div class=\"nc\">\n <div class=\"nc-h\">Achievements \u2014 <span id=\"ach-count2\">0/15</span> Unlocked</div>\n <div id=\"ach-list\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Loading...</div></div>\n </div>\n <div class=\"nc\">\n <div class=\"nc-h\" style=\"display:flex;justify-content:space-between\"><span>Recent Sessions</span><span style=\"cursor:pointer;font-size:11px;color:var(--dim)\" onclick=\"clearAllSessions()\" title=\"Clear all\">\u2715</span></div>\n <div id=\"sess-list\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">No saved sessions</div></div>\n </div>\n <!-- \u0627\u062a\u062c\u0627\u0647 \u0641\u0639\u0627\u0644\u064a\u0629 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u062c\u0644\u0633\u0627\u062a \u0627\u0644\u0645\u062d\u0641\u0648\u0638\u0629 (\u0645\u064a\u0632\u0629 29 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u064a\u0639\u062a\u0645\u062f \u0643\u0644\u064a\u0627\u064b \u0639\u0644\u0649\n \u0628\u064a\u0627\u0646\u0627\u062a bestSilence \u0627\u0644\u0645\u0648\u062c\u0648\u062f\u0629 \u0623\u0635\u0644\u0627\u064b \u0641\u064a \u0643\u0644 \u062c\u0644\u0633\u0629 \u0645\u062d\u0641\u0648\u0638\u0629 (buildSessionObj) \u0648getAllSessions()\n (\u0646\u0641\u0633 \u0645\u0627 \u062a\u0639\u0631\u0636\u0647 \u0642\u0627\u0626\u0645\u0629 Recent Sessions \u0646\u0635\u0651\u064a\u0627\u064b)\u060c \u0641\u0642\u0637 \u0628\u0631\u0633\u0645 \u0627\u062a\u062c\u0627\u0647\u0647\u0627 \u0632\u0645\u0646\u064a\u0627\u064b \u0628\u062f\u0644 \u0642\u0631\u0627\u0621\u062a\u0647\u0627 \u0633\u0637\u0631\u0627\u064b\n \u0633\u0637\u0631\u0627\u064b \u2014 \u0628\u0646\u0641\u0633 \u0623\u0633\u0644\u0648\u0628 drawSQIHist() (\u0631\u0633\u0645 Canvas \u064a\u062f\u0648\u064a\u060c \u062e\u0637\u0648\u0637 \u0625\u0631\u0634\u0627\u062f\u064a\u0629 50/80\u060c \u062a\u0639\u0628\u0626\u0629 \u062a\u062d\u062a\n \u0627\u0644\u0645\u0646\u062d\u0646\u0649\u060c \u0646\u0642\u0637\u0629 \u0627\u0644\u0642\u064a\u0645\u0629 \u0627\u0644\u0623\u062e\u064a\u0631\u0629) \u0644\u0644\u062d\u0641\u0627\u0638 \u0639\u0644\u0649 \u062a\u0646\u0627\u0633\u0642 \u0628\u0635\u0631\u064a \u0643\u0627\u0645\u0644 \u0645\u0639 \u0628\u0642\u064a\u0629 \u0627\u0644\u0644\u0648\u062d\u0629. -->\n <div class=\"nc\" style=\"border-color:rgba(169,169,169,.2)\">\n <div class=\"nc-h\" style=\"color:rgba(169,169,169,.6)\">\u0627\u062a\u062c\u0627\u0647 \u0641\u0639\u0627\u0644\u064a\u0629 \u0627\u0644\u0625\u0644\u063a\u0627\u0621 \u2014 \u0622\u062e\u0631 10 \u062c\u0644\u0633\u0627\u062a</div>\n <canvas id=\"sessHistCv\" style=\"width:100%;height:44px;border-radius:6px;display:block\"></canvas>\n </div>\n <div class=\"nc\">\n <div class=\"nc-h\">Storage Log</div>\n <div id=\"st-log\"><div style=\"font-family:var(--fm);font-size:9px;color:var(--muted)\">Initializing...</div></div>\n </div>\n <div style=\"display:flex;align-items:center;justify-content:space-between;padding:6px 0\">\n <span style=\"font-family:var(--fm);font-size:10px;color:var(--dim)\">Auto-save every 2 min</span>\n <label class=\"sw\" onclick=\"event.stopPropagation()\"><input type=\"checkbox\" id=\"sw-autosave\" checked onchange=\"autoSave=this.checked\"><div class=\"sw-t\"></div><div class=\"sw-th\"></div></label>\n </div>\n <div class=\"nc\" style=\"border-color:rgba(169,169,169,.18)\">\n <div class=\"nc-h\" style=\"display:flex;justify-content:space-between\">\n <span> Frequency Partitions</span>\n <div style=\"display:flex;gap:10px\">\n <span style=\"cursor:pointer;font-size:11px;color:var(--zero)\" onclick=\"buildFreqPartitions()\">\u21bb Build</span>\n <span style=\"cursor:pointer;font-size:11px;color:var(--ai)\" onclick=\"saveFreqPartitions()\"> Save</span>\n </div>\n </div>\n <div class=\"part-grid\" id=\"part-grid\">\n <div class=\"part-card part-hot\"><div class=\"part-lbl\"> HOT</div><div class=\"part-val\" id=\"part-hot-v\">0</div></div>\n <div class=\"part-card part-cold\"><div class=\"part-lbl\"> COLD</div><div class=\"part-val\" id=\"part-cold-v\">0</div></div>\n <div class=\"part-card part-conf\"><div class=\"part-lbl\"> CONF</div><div class=\"part-val\" id=\"part-conf-v\">0</div></div>\n <div class=\"part-card part-ban\"><div class=\"part-lbl\"> BANNED</div><div class=\"part-val\" id=\"part-ban-v\">0</div></div>\n <div class=\"part-card part-inv\"><div class=\"part-lbl\">\u27f3 INV</div><div class=\"part-val\" id=\"part-inv-v\">0</div></div>\n <div class=\"part-card part-pred\"><div class=\"part-lbl\"> PRED</div><div class=\"part-val\" id=\"part-pred-v\">0</div></div>\n </div>\n <div class=\"part-save-btn\" onclick=\"saveFreqPartitions()\"> Save Partitions Reference File</div>\n </div>\n <div class=\"nc\" style=\"border-color:rgba(110,110,110,.18)\">\n <div class=\"nc-h\" style=\"display:flex;justify-content:space-between\">\n <span> AI Freq Ban</span>\n <!-- Thermal Monitor Panel -->\n <div class=\"therm-panel\" id=\"therm-panel\">\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);margin-bottom:4px\">\u0645\u0642\u064a\u0627\u0633 \u0627\u0644\u062d\u0631\u0627\u0631\u0629 \u0627\u0644\u0641\u0639\u0644\u064a\u0629</div>\n <div class=\"therm-row\">\n <span class=\"therm-lbl\">CPU*</span>\n <div class=\"therm-bar-wrap\"><div class=\"therm-bar cold\" id=\"therm-cpu-bar\" style=\"width:20%\"></div></div>\n <span class=\"therm-val cold\" id=\"therm-cpu-val\">20\u00b0C*</span>\n </div>\n <div class=\"therm-row\">\n <span class=\"therm-lbl\">GPU/DSP*</span>\n <div class=\"therm-bar-wrap\"><div class=\"therm-bar cold\" id=\"therm-gpu-bar\" style=\"width:20%\"></div></div>\n <span class=\"therm-val cold\" id=\"therm-gpu-val\">20\u00b0C*</span>\n </div>\n <div class=\"therm-row\">\n <span class=\"therm-lbl\">DSP Latency</span>\n <div class=\"therm-bar-wrap\"><div class=\"therm-bar cold\" id=\"therm-dsp-bar\" style=\"width:10%\"></div></div>\n <span class=\"therm-val cold\" id=\"therm-dsp-val\">20\u00b0C*</span>\n </div>\n <div class=\"therm-row\">\n <span class=\"therm-lbl\">RAM Heap</span>\n <div class=\"therm-bar-wrap\"><div class=\"therm-bar cold\" id=\"therm-ram-bar\" style=\"width:10%\"></div></div>\n <span class=\"therm-val cold\" id=\"therm-ram-val\">0%</span>\n </div>\n <div class=\"therm-row\">\n <span class=\"therm-lbl\">Stress Index</span>\n <div class=\"therm-bar-wrap\"><div class=\"therm-bar cold\" id=\"therm-str-bar\" style=\"width:5%\"></div></div>\n <span class=\"therm-val cold\" id=\"therm-str-val\">0%</span>\n </div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Prediction (10s):</span><span id=\"therm-pred\">\u2014</span>\n </div>\n <div style=\"font-family:var(--fm);font-size:8px;color:#7c7c7c\" id=\"therm-ban-cnt\">0 thermal bans</div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Spectral Entropy:</span><span id=\"spec-entropy-v\">0.000</span>\n </div>\n <div class=\"spec-entropy-bar\"><div class=\"spec-entropy-fill\" id=\"spec-entropy-fill\" style=\"width:0%\"></div></div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Spectral Flux:</span><span id=\"spec-flux-v\">0.0000</span>\n </div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Centroid:</span><span id=\"centroid-v\">\u2014</span> <span id=\"centroid-drift\" style=\"color:var(--ai)\"></span>\n </div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Bipolar:</span><span id=\"bipolar-ratio\" style=\"color:var(--c3)\">50% pos / 50% neg</span>\n </div>\n <div style=\"display:flex;justify-content:space-between;padding:3px 0;font-family:var(--fm);font-size:8px;color:var(--muted)\">\n <span>Harmonic Q:</span><span id=\"harmonic-q\" style=\"color:var(--sharp)\">\u2014</span>\n </div>\n </div>\n <!-- 16-class grid -->\n <div style=\"font-family:var(--fm);font-size:9px;color:var(--muted);margin:6px 0 3px\">16 \u062a\u0635\u0646\u064a\u0641 \u062a\u0631\u062f\u062f</div>\n <div class=\"cls16-grid\">\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C1\u2295</div><div class=\"cls16-val\" style=\"color:#8f8f8f\" id=\"fc1\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C2\u2296</div><div class=\"cls16-val\" style=\"color:#7c7c7c\" id=\"fc2\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C3\u2213</div><div class=\"cls16-val\" style=\"color:#9c9c9c\" id=\"fc3\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C4\u00b1</div><div class=\"cls16-val\" style=\"color:#828282\" id=\"fc4\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C5\u2713</div><div class=\"cls16-val\" style=\"color:#959595\" id=\"fc5\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C6\u2717</div><div class=\"cls16-val\" style=\"color:#929292\" id=\"fc6\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C7\u2713</div><div class=\"cls16-val\" style=\"color:#797979\" id=\"fc7\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C8\u2717</div><div class=\"cls16-val\" style=\"color:#929292\" id=\"fc8\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C9</div><div class=\"cls16-val\" style=\"color:#818181\" id=\"fc9\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C10\ud835\udc8a</div><div class=\"cls16-val\" style=\"color:#6d6d6d\" id=\"fc10\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C11\u2191</div><div class=\"cls16-val\" style=\"color:#8b8b8b\" id=\"fc11\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C12\u221e</div><div class=\"cls16-val\" style=\"color:#828282\" id=\"fc12\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C13</div><div class=\"cls16-val\" style=\"color:#cecece\" id=\"fc13\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C14</div><div class=\"cls16-val\" style=\"color:#6a6a6a\" id=\"fc14\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C15</div><div class=\"cls16-val\" style=\"color:#9c9c9c\" id=\"fc15\">0</div></div>\n <div class=\"cls16-cell\"><div class=\"cls16-lbl\">C16</div><div class=\"cls16-val\" style=\"color:#969696\" id=\"fc16\">0</div></div>\n </div>\n <!-- Ban panel header -->\n <div class=\"ban-panel-header\">\n <span class=\"ban-unified-badge\">\u062a\u0631\u062f\u062f\u0627\u062a \u0645\u062d\u0638\u0648\u0631\u0629</span>\n <span id=\"ban-total-badge\" class=\"ban-total-badge\">0 \u0645\u064f\u062d\u0636\u064e\u0631</span>\n </div>\n <!-- ENV fingerprint & slug panel -->\n <div class=\"slug-panel\" style=\"margin-bottom:8px\">\n <div class=\"slug-row\"><span class=\"slug-lbl\">\u0646\u0648\u0639 \u0627\u0644\u0636\u062c\u064a\u062c</span><span class=\"slug-val\" id=\"env-noise-type\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\">\u062d\u0645\u0644 \u0627\u0644\u0646\u0638\u0627\u0645</span><span class=\"slug-val\" id=\"env-int-load\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\">\u062a\u0631\u062f\u062f\u0627\u062a \u0627\u0644\u062a\u062e\u0645\u0651\u0644</span><span class=\"slug-val\" id=\"lag-freq-cnt\">0</span></div>\n <div class=\"slug-row\" style=\"border-top:1px solid var(--panel-border);padding-top:6px;margin-top:2px\">\n <span class=\"slug-lbl\" style=\"color:var(--accent)\"> PERSIST</span>\n <span class=\"slug-val\" id=\"persist-stat\" style=\"font-size:9px\">\u2014</span>\n </div>\n <div class=\"slug-row\"><span class=\"slug-lbl\">\u3030 ZCR \u062a\u0642\u0627\u0637\u0639 \u0627\u0644\u0635\u0641\u0631</span><span class=\"slug-val\" id=\"zcr-val\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Crest Factor</span><span class=\"slug-val\" id=\"crest-val\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Pitch AMDF</span><span class=\"slug-val\" id=\"pitch-amdf\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Chroma Dominant</span><span class=\"slug-val\" id=\"chroma-dom\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\">\u301c AM/FM Mod</span><span class=\"slug-val\" id=\"mod-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Rolloff 85%</span><span class=\"slug-val\" id=\"rolloff-val\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Flatness</span><span class=\"slug-val\" id=\"flat-val\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Room Mode</span><span class=\"slug-val\" id=\"room-mode-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Env Change</span><span class=\"slug-val\" id=\"env-change-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Acoustic Sig</span><span class=\"slug-val\" id=\"acoustic-sig-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Moments \u03bcK</span><span class=\"slug-val\" id=\"smom-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Tonal %</span><span class=\"slug-val\" id=\"tonal-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> HNR dB</span><span class=\"slug-val\" id=\"hnr-val\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Ban Clusters</span><span class=\"slug-val\" id=\"cluster-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Mem Pressure</span><span class=\"slug-val\" id=\"mem-press-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> Timing Drift</span><span class=\"slug-val\" id=\"drift-v\">\u2014</span></div>\n <div class=\"slug-row\"><span class=\"slug-lbl\"> TD Error</span><span class=\"slug-val\" id=\"td-err-v\">\u2014</span></div>\n </div>\n <div class=\"ban-stat\" id=\"ban-stat\">0 banned</div>\n </div>\n <div id=\"ban-list\"><div class=\"ban-empty\">No frequencies banned \u2014 FREQ_GATE auto-bans high-fail freqs</div></div>\n </div>\n </div><!-- /pane7 -->\n\n <!-- TAB 8: SESSION STATS -->\n <div class=\"pane\" id=\"pane8\">\n <div class=\"stats-grid\">\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> UPTIME</div>\n <div class=\"stat-val green\" id=\"ss-uptime\">00:00</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> AI CYCLES</div>\n <div class=\"stat-val\" id=\"ss-aicyc\">0</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> DETECTED FREQS</div>\n <div class=\"stat-val yellow\" id=\"ss-freqs\">0</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> BANNED</div>\n <div class=\"stat-val red\" id=\"ss-banned\">0</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> NN ACCURACY</div>\n <div class=\"stat-val green\" id=\"ss-acc\">\u2014</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> POWER MODE</div>\n <div class=\"stat-val\" id=\"ss-preset\">BALANCED</div>\n </div>\n <div class=\"stat-card\">\n <div class=\"stat-lbl\"> SQI</div>\n <div class=\"stat-val green\" id=\"ss-sqi\">\u2014</div>\n </div>\n <div class=\"stat-card\" style=\"grid-column:1/-1\">\n <div class=\"stat-lbl\"> ENVIRONMENT</div>\n <div class=\"stat-val\" id=\"ss-env\" style=\"font-size:11px;letter-spacing:.03em\">\u2014</div>\n </div>\n </div>\n <div style=\"margin-top:10px\">\n <div class=\"slbl\" style=\"margin-bottom:4px\"> SQI \u2014 Signal Quality History</div>\n <canvas id=\"sqiHistCv\" style=\"width:100%;height:44px;border-radius:6px;display:block\"></canvas>\n </div>\n <div style=\"margin-top:12px\">\n <div class=\"slbl\">\u062d\u0627\u0644\u0629 \u0627\u0644\u062d\u0631\u0627\u0631\u0629</div>\n <div class=\"scard\">\n <div class=\"si\">\n <div class=\"iw\" style=\"background:rgba(158,158,158,.12);color:#9e9e9e;font-size:14px\"></div>\n <div class=\"scnt\">\n <div class=\"sn\" id=\"ss-thermal-status\">\u062c\u064a\u062f\u0629</div>\n <div class=\"sd\" id=\"ss-thermal-detail\">\u062c\u0645\u064a\u0639 \u0627\u0644\u0645\u0646\u0627\u0637\u0642 \u0636\u0645\u0646 \u0627\u0644\u062d\u062f\u0648\u062f \u0627\u0644\u0622\u0645\u0646\u0629</div>\n </div>\n </div>\n </div>\n </div>\n <div style=\"margin-top:12px\">\n <div class=\"slbl\">\u0625\u062d\u0635\u0627\u0621 \u0642\u0627\u0639\u062f\u0629 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a</div>\n <div class=\"scard\">\n <div style=\"display:flex;flex-direction:column;gap:6px;font-family:var(--fm);font-size:9px\">\n <div style=\"display:flex;justify-content:space-between;align-items:center\">\n <span style=\"color:var(--muted)\">IndexedDB \u062d\u062c\u0627\u0632\u0629 \u2014</span>\n <span id=\"ss-db-size\" style=\"color:var(--text);font-weight:700\">\u2014 KB</span>\n </div>\n <div style=\"display:flex;justify-content:space-between;align-items:center\">\n <span style=\"color:var(--muted)\">\u0622\u062e\u0631 \u062d\u0641\u0638</span>\n <span id=\"ss-db-saved\" style=\"color:var(--on);font-weight:700\">\u2014</span>\n </div>\n <!-- \u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u062a\u0631\u0627\u0643\u0645 \u2014 \u0623\u064f\u0636\u064a\u0641 28 \u0633\u0628\u062a\u0645\u0628\u0631 2026 (\u0628\u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645): udsGetStats() \u0643\u0627\u0646\u062a \u0645\u0648\u062c\u0648\u062f\u0629 \u0623\u0635\u0644\u0627\u064b\n (\u062a\u064f\u0633\u062a\u062e\u062f\u064e\u0645 \u0641\u0642\u0637 \u062f\u0627\u062e\u0644 \u0623\u0645\u0631 EXEC \u0646\u0635\u0651\u064a STATS) \u0644\u0643\u0646 \u0628\u0644\u0627 \u0623\u064a \u0645\u0643\u0627\u0646 \u0645\u0631\u0626\u064a \u064a\u0639\u0631\u0636\u0647\u0627. \u0647\u0630\u0627 \u0627\u0644\u0642\u0633\u0645 \u064a\u062c\u0639\u0644 \u062a\u0631\u0627\u0643\u0645\n \u0643\u0644 \u0645\u062e\u0632\u0646 UDS \u0645\u0631\u0626\u064a\u0627\u064b \u062d\u064a\u0651\u0627\u064b \u0647\u0646\u0627 (\u064a\u062a\u062d\u062f\u064e\u0651\u062b \u0643\u0644 2 \u062b\u0627\u0646\u064a\u0629 \u0637\u0627\u0644\u0645\u0627 \u0647\u0630\u0627 \u0627\u0644\u062a\u0628\u0648\u064a\u0628 \u0645\u0641\u062a\u0648\u062d\u0627\u064b)\u060c \u0648\u064a\u0639\u0631\u0636 \u0627\u0644\u0633\u0642\u0641\n \u0627\u0644\u0641\u0639\u0644\u064a \u0628\u062c\u0627\u0646\u0628 \u0627\u0644\u0639\u062f\u062f \u0644\u0643\u0644 \u0645\u062e\u0632\u0646 \u064a\u0645\u0644\u0643 \u062a\u0642\u0644\u064a\u0645\u0627\u064b \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b (terminal_events/exec_history/nn_history\n \u2014 \u0631\u0627\u062c\u0639 UDS_CAP \u0641\u064a 08c-background-db.js\u060c \u0623\u064f\u0636\u064a\u0641 \u0641\u064a \u062a\u0637\u0648\u064a\u0631 \u0633\u0627\u0628\u0642 \u0644\u0645\u0646\u0639 \u0646\u0645\u0648\u0651\u0647\u0627 \u0628\u0644\u0627 \u062d\u062f\u0648\u062f) \u2014 \u0641\u064a\u0631\u0649\n \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0623\u0646 \u0627\u0644\u062a\u0631\u0627\u0643\u0645 \u0645\u062d\u062f\u0648\u062f \u0641\u0639\u0644\u064a\u0627\u064b\u060c \u0644\u0627 \u0627\u0641\u062a\u0631\u0627\u0636\u0627\u064b \u0641\u0642\u0637. -->\n <div id=\"ss-uds-rows\" style=\"display:flex;flex-direction:column;gap:3px;margin-top:2px;padding-top:6px;border-top:1px solid var(--brd)\"></div>\n <div style=\"display:flex;gap:6px;margin-top:4px\">\n <button class=\"preset-btn\" style=\"flex:1;padding:6px 4px;font-size:8px\" onclick=\"saveFreqDB().then(()=>updateStatsTab())\">\u062d\u0641\u0638</button>\n <button class=\"preset-btn\" style=\"flex:1;padding:6px 4px;font-size:8px\" onclick=\"loadFreqDB().then(()=>updateStatsTab())\">\u0627\u0633\u062a\u0639\u0627\u062f\u0629</button>\n </div>\n </div>\n </div>\n </div>\n </div><!-- /pane8 -->\n</div><!-- /aiPanel -->\n\n<!-- PERMISSIONS MGMT PANEL -->\n<div class=\"pnl\" id=\"zpPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"zp-ph\">\n <div class=\"zp-ph-t\"><span></span>\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0623\u0630\u0648\u0646\u0627\u062a</div>\n <div class=\"ai-ph-c\" onclick=\"closeZPPanel()\">\u2715</div>\n </div>\n <div class=\"zp-scr\">\n <div class=\"zp-row\">\n <div class=\"zp-rt\">\n <div class=\"zp-ico\"></div>\n <div class=\"zp-meta\"><div class=\"zp-nm\">\u0627\u0644\u0645\u064a\u0643\u0631\u0648\u0641\u0648\u0646</div><div class=\"zp-ds\">\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u0635\u0648\u062a \u0644\u062a\u062d\u0644\u064a\u0644 \u0627\u0644\u0636\u0648\u0636\u0627\u0621</div></div>\n </div>\n <button class=\"zp-mb req\" id=\"zpb-RECORD_AUDIO\" onclick=\"zpRequestPerm('RECORD_AUDIO')\">\u0627\u0636\u063a\u0637 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0625\u0630\u0646 \u2190</button>\n <div class=\"zp-err\" id=\"zpe-RECORD_AUDIO\" hidden>\u0647\u0630\u0627 \u0627\u0644\u0625\u0630\u0646 \u0636\u0631\u0648\u0631\u064a \u2014 \u0644\u0646 \u064a\u0639\u0645\u0644 \u062a\u062d\u0644\u064a\u0644 \u0627\u0644\u0635\u0648\u062a \u0628\u062f\u0648\u0646\u0647</div>\n </div>\n <div class=\"zp-row\">\n <div class=\"zp-rt\">\n <div class=\"zp-ico\"></div>\n <div class=\"zp-meta\"><div class=\"zp-nm\">\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062a</div><div class=\"zp-ds\">\u062a\u0646\u0628\u064a\u0647\u0627\u062a \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a \u0641\u064a \u0627\u0644\u062e\u0644\u0641\u064a\u0629</div></div>\n </div>\n <button class=\"zp-mb req\" id=\"zpb-POST_NOTIFICATIONS\" onclick=\"zpRequestPerm('POST_NOTIFICATIONS')\">\u0627\u0636\u063a\u0637 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0625\u0630\u0646 \u2190</button>\n <div class=\"zp-err\" id=\"zpe-POST_NOTIFICATIONS\" hidden>\u2139 \u0644\u0646 \u062a\u0638\u0647\u0631 \u0625\u0634\u0639\u0627\u0631\u0627\u062a \u0627\u0644\u062e\u0644\u0641\u064a\u0629 \u2014 \u064a\u0645\u0643\u0646 \u062a\u0641\u0639\u064a\u0644\u0647 \u0644\u0627\u062d\u0642\u0627\u064b \u0645\u0646 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062c\u0647\u0627\u0632</div>\n </div>\n <div class=\"zp-row\">\n <div class=\"zp-rt\">\n <div class=\"zp-ico\"></div>\n <div class=\"zp-meta\"><div class=\"zp-nm\">\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0645\u0644\u0641\u0627\u062a</div><div class=\"zp-ds\">\u062d\u0641\u0638 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0648\u0627\u0644\u0633\u062c\u0644\u0627\u062a</div></div>\n </div>\n <button class=\"zp-mb req\" id=\"zpb-MANAGE_STORAGE\" onclick=\"zpRequestPerm('MANAGE_STORAGE')\">\u0627\u0636\u063a\u0637 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0625\u0630\u0646 \u2190</button>\n <div class=\"zp-err\" id=\"zpe-MANAGE_STORAGE\" hidden>\u0636\u0631\u0648\u0631\u064a \u0644\u062d\u0641\u0638 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a \u2014 \u0627\u0636\u063a\u0637 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649 \u0644\u0641\u062a\u062d \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062c\u0647\u0627\u0632</div>\n </div>\n <div class=\"zp-row\">\n <div class=\"zp-rt\">\n <div class=\"zp-ico\"></div>\n <div class=\"zp-meta\"><div class=\"zp-nm\">\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0635\u0648\u062a</div><div class=\"zp-ds\">\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0635\u0648\u062a \u0641\u064a \u0627\u0644\u062c\u0647\u0627\u0632</div></div>\n </div>\n <button class=\"zp-mb req\" id=\"zpb-MEDIA_AUDIO\" onclick=\"zpRequestPerm('MEDIA_AUDIO')\">\u0627\u0636\u063a\u0637 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0625\u0630\u0646 \u2190</button>\n <div class=\"zp-err\" id=\"zpe-MEDIA_AUDIO\" hidden>\u0636\u0631\u0648\u0631\u064a \u0644\u0644\u0648\u0635\u0648\u0644 \u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0635\u0648\u062a \u2014 \u0627\u0636\u063a\u0637 \u0644\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u062c\u062f\u062f\u0627\u064b</div>\n </div>\n </div>\n</div><!-- /zpPanel -->\n\n<!-- DEVICE MONITOR PANEL -->\n<div class=\"pnl\" id=\"devPanel\">\n <div class=\"phdl\"><div class=\"pbar\"></div></div>\n <div class=\"dm-ph\">\n <div class=\"dm-ph-t\">\u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u062c\u0647\u0627\u0632</div>\n <div class=\"ai-ph-c\" onclick=\"closeDevMon()\">\u2715</div>\n </div>\n <div class=\"dm-scr\" id=\"dm-scr-body\">\n\n <!-- CPU -->\n <div class=\"dm-sec sec-cpu\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#929292\">CPU</span>\n <span class=\"dm-badge cool\" id=\"dm-cpu-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u062f\u0631\u062c\u0629 \u0627\u0644\u062d\u0631\u0627\u0631\u0629</span><span class=\"dm-v\" id=\"dm-cpu-temp\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u062a\u0631\u062f\u062f \u0627\u0644\u062d\u0627\u0644\u064a</span><span class=\"dm-v\" id=\"dm-cpu-freq\">\u2014</span><div class=\"dm-bar-w\"><div class=\"dm-bar cpu\" id=\"dm-cpu-bar\" style=\"width:0%\"></div></div></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u0623\u0646\u0648\u064a\u0629</span><span class=\"dm-v\" id=\"dm-cpu-cores\">\u2014</span></div>\n </div>\n </div>\n\n <!-- RAM -->\n <div class=\"dm-sec sec-ram\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#828282\">RAM</span>\n <span class=\"dm-badge ok\" id=\"dm-ram-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u064f\u0633\u062a\u062e\u062f\u0645</span><span class=\"dm-v\" id=\"dm-ram-used\">\u2014</span><div class=\"dm-bar-w\"><div class=\"dm-bar ram\" id=\"dm-ram-bar\" style=\"width:0%\"></div></div></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u062a\u0627\u062d</span><span class=\"dm-v\" id=\"dm-ram-avail\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a</span><span class=\"dm-v\" id=\"dm-ram-total\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Battery -->\n <div class=\"dm-sec sec-bat\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#8f8f8f\">\u0627\u0644\u0628\u0637\u0627\u0631\u064a\u0629</span>\n <span class=\"dm-badge ok\" id=\"dm-bat-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u062f\u0631\u062c\u0629 \u0627\u0644\u062d\u0631\u0627\u0631\u0629</span><span class=\"dm-v\" id=\"dm-bat-temp\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u0633\u062a\u0648\u0649 \u0627\u0644\u0634\u062d\u0646</span><span class=\"dm-v\" id=\"dm-bat-level\">\u2014</span><div class=\"dm-bar-w\"><div class=\"dm-bar bat\" id=\"dm-bat-bar\" style=\"width:0%\"></div></div></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u062c\u0647\u062f</span><span class=\"dm-v\" id=\"dm-bat-volt\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u062d\u0627\u0644\u0629</span><span class=\"dm-v\" id=\"dm-bat-status\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0635\u062d\u0629 \u0627\u0644\u0628\u0637\u0627\u0631\u064a\u0629</span><span class=\"dm-v\" id=\"dm-bat-health\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Thermal Zones -->\n <div class=\"dm-sec sec-therm\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#9c9c9c\">\u0627\u0644\u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062d\u0631\u0627\u0631\u064a\u0629</span>\n </div>\n <div class=\"dm-th-list\" id=\"dm-thermal-grid\">\n <div class=\"dm-th-row\"><div class=\"dm-th-name\">\u062c\u0627\u0631\u064a \u0627\u0644\u0642\u0631\u0627\u0621\u0629...</div><div class=\"dm-th-fill-row\"><div class=\"dm-th-fill-w\"><div class=\"dm-th-fill cool\" style=\"width:0%\"></div></div><div class=\"dm-th-val cool\">\u2014</div></div></div>\n </div>\n </div>\n\n <!-- JS Heap -->\n <div class=\"dm-sec sec-js\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#c4c4c4\">JS Heap</span>\n <span class=\"dm-badge cool\" id=\"dm-js-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u064f\u0633\u062a\u062e\u062f\u0645</span><span class=\"dm-v\" id=\"dm-js-used\">\u2014</span><div class=\"dm-bar-w\"><div class=\"dm-bar cpu\" id=\"dm-js-bar\" style=\"width:0%\"></div></div></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649</span><span class=\"dm-v\" id=\"dm-js-limit\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Device Info -->\n <div class=\"dm-sec sec-info\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#9a9a9a\">\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062c\u0647\u0627\u0632</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u062c\u0647\u0627\u0632</span><span class=\"dm-v\" id=\"dm-dev-model\" style=\"font-size:9px\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">Android API</span><span class=\"dm-v\" id=\"dm-dev-api\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0623\u0646\u0648\u064a\u0629 \u0627\u0644\u0645\u0639\u0627\u0644\u062c</span><span class=\"dm-v\" id=\"dm-dev-cores\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062c\u0647\u0627\u0632</span><span class=\"dm-v\" id=\"dm-dev-mem\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Storage -->\n <div class=\"dm-sec sec-stor\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#959595\">\u0627\u0644\u062a\u062e\u0632\u064a\u0646 \u0627\u0644\u062f\u0627\u062e\u0644\u064a</span>\n <span class=\"dm-badge cool\" id=\"dm-stor-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u064f\u0633\u062a\u062e\u062f\u0645</span><span class=\"dm-v\" id=\"dm-int-used\">\u2014</span></div>\n <div class=\"dm-stor-bar-w\"><div class=\"dm-stor-bar int\" id=\"dm-int-bar\" style=\"width:0%\"></div></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0645\u062a\u0627\u062d</span><span class=\"dm-v\" id=\"dm-int-free\">\u2014</span></div>\n <div class=\"dm-r\" id=\"dm-ext-row\" style=\"display:none\"><span class=\"dm-k\">\u0628\u0637\u0627\u0642\u0629 SD \u0645\u062a\u0627\u062d</span><span class=\"dm-v\" id=\"dm-ext-free\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Network -->\n <div class=\"dm-sec sec-net\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#a1a1a1\">\u0627\u0644\u0634\u0628\u0643\u0629</span>\n </div>\n <div id=\"dm-net-chip-wrap\"></div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">\u0646\u0648\u0639 \u0627\u0644\u0627\u062a\u0635\u0627\u0644</span><span class=\"dm-v\" id=\"dm-net-type\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0627\u0644\u0646\u0637\u0627\u0642 / \u0627\u0644\u062c\u064a\u0644</span><span class=\"dm-v\" id=\"dm-net-sub\">\u2014</span></div>\n </div>\n </div>\n\n <!-- App Memory -->\n <div class=\"dm-sec sec-app\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#878787\">\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062a\u0637\u0628\u064a\u0642</span>\n <span class=\"dm-badge cool\" id=\"dm-app-badge\">\u2014</span>\n </div>\n <div class=\"dm-rows\">\n <div class=\"dm-r\"><span class=\"dm-k\">Heap \u0645\u064f\u0633\u062a\u062e\u062f\u0645</span><span class=\"dm-v\" id=\"dm-app-heap\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">Native heap</span><span class=\"dm-v\" id=\"dm-app-nat\">\u2014</span></div>\n <div class=\"dm-r\"><span class=\"dm-k\">\u0625\u062c\u0645\u0627\u0644\u064a PSS</span><span class=\"dm-v\" id=\"dm-app-pss\">\u2014</span></div>\n </div>\n </div>\n\n <!-- Sparklines -->\n <div class=\"dm-sec sec-hist\">\n <div class=\"dm-sec-h\">\n <span class=\"dm-sec-t\" style=\"color:#888\">\u0627\u0644\u0633\u062c\u0644 \u0627\u0644\u062a\u0627\u0631\u064a\u062e\u064a</span>\n <span style=\"font-family:var(--fm);font-size:8px;color:var(--muted)\">\u0622\u062e\u0631 12 \u0646\u0642\u0637\u0629</span>\n </div>\n <div class=\"dm-spark-row\">\n <div class=\"dm-spark-box\">\n <div class=\"dm-spark-lbl\">\u062d\u0631\u0627\u0631\u0629 CPU / \u0628\u0637\u0627\u0631\u064a\u0629</div>\n <svg class=\"dm-spark-svg\" id=\"dm-spark-cpu\" viewBox=\"0 0 100 30\" preserveAspectRatio=\"none\"></svg>\n </div>\n <div class=\"dm-spark-box\">\n <div class=\"dm-spark-lbl\">RAM %</div>\n <svg class=\"dm-spark-svg\" id=\"dm-spark-ram\" viewBox=\"0 0 100 30\" preserveAspectRatio=\"none\"></svg>\n </div>\n </div>\n </div>\n\n </div><!-- /dm-scr -->\n <div class=\"dm-refresh\">\n <div class=\"dm-live-dot\"></div>\n <span class=\"dm-ts\" id=\"dm-ts\">\u062a\u062d\u062f\u064a\u062b \u062a\u0644\u0642\u0627\u0626\u064a \u0643\u0644 3 \u062b\u0648\u0627\u0646</span>\n <button class=\"dm-scrl-btn\" onclick=\"dmScroll(-1)\" title=\"\u0644\u0644\u0623\u0639\u0644\u0649\">\u2191</button>\n <button class=\"dm-scrl-btn\" onclick=\"dmScroll(1)\" title=\"\u0644\u0644\u0623\u0633\u0641\u0644\">\u2193</button>\n <button class=\"dm-ref-btn\" onclick=\"dmRefresh()\">\u062a\u062d\u062f\u064a\u062b</button>\n </div>\n</div><!-- /devPanel -->\n\n<!-- PIPELINE SIDEBAR -->\n<div class=\"ppnl\" id=\"ppnl\">\n <div class=\"pplph\"><span class=\"pplph-t\">Pipeline \u2014 v25</span><div class=\"pplph-c\" onclick=\"closePipe()\">\u2715</div></div>\n <div class=\"pscr\">\n <div class=\"plb\" style=\"border-color:rgba(169,169,169,.2)\"><div class=\"plh\" style=\"background:rgba(169,169,169,.04)\"><span class=\"pln\" style=\"color:var(--zero)\"> Neural Net 16\u219224\u21928</span><span class=\"pls sil\" id=\"ps-nn\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">Trained</span><span style=\"color:var(--zero)\" id=\"pv-tc\">0</span></div><div class=\"plr\"><span class=\"plrk\">Loss</span><span style=\"color:var(--ai)\" id=\"pv-ls\">1.0</span></div><div class=\"plr\"><span class=\"plrk\">FreqDB</span><span style=\"color:var(--c5)\" id=\"pv-db\">0</span></div><div class=\"plr\"><span class=\"plrk\">Inverse</span><span style=\"color:var(--sharp)\" id=\"pv-iv\">0</span></div></div></div>\n <div class=\"plb\" style=\"border-color:rgba(130,130,130,.2)\"><div class=\"plh\" style=\"background:rgba(130,130,130,.04)\"><span class=\"pln\" style=\"color:var(--ai)\">\u27f3 Inverse Generator</span><span class=\"pls inv\" id=\"ps-inv\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">Confirmed</span><span style=\"color:var(--ai)\" id=\"pv-co\">0</span></div><div class=\"plr\"><span class=\"plrk\">Cancelled</span><span style=\"color:var(--zero)\" id=\"pv-ca\">0</span></div><div class=\"plr\"><span class=\"plrk\">Anti-search</span><span style=\"color:var(--sharp)\" id=\"pv-as\">0</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\"> Mic \u00b7 EVP \u00b7 EMF</span><span class=\"pls run\" id=\"ps-mic-stage\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">Source Hz</span><span style=\"color:var(--noise)\" id=\"pv-hz\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">EVP &lt;40Hz</span><span style=\"color:var(--evp)\" id=\"pv-evp\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">EMF</span><span style=\"color:var(--emf)\" id=\"pv-emf\">\u2014</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\"> 12 Algorithms</span><span class=\"pls run\" id=\"ps-alg\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">MUSIC Hz</span><span style=\"color:var(--zero)\" id=\"pv-mu\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">Kalman Hz</span><span style=\"color:var(--zero)\" id=\"pv-ka\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">Wiener G</span><span style=\"color:var(--zero)\" id=\"pv-wi\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">Transient z</span><span style=\"color:var(--sharp)\" id=\"pv-tz\">\u2014</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\"> Silent Freqs (6 types)</span><span class=\"pls sil\" id=\"ps-sf\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">INF &lt;20Hz</span><span style=\"color:var(--c1)\" id=\"pv-if\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">ULT &gt;20kHz</span><span style=\"color:var(--c5)\" id=\"pv-uf\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">PHF field</span><span style=\"color:var(--c7)\" id=\"pv-pf\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">SUB 0.01Hz</span><span style=\"color:var(--c3)\" id=\"pv-sf\">\u2014</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\">Coherence \u03b3\u00b2(f)</span><span class=\"pls run\" id=\"ps-coh\">IDLE</span></div><div class=\"plbd\"><div class=\"coh-mini\" id=\"cohMini\"></div><div class=\"plr\" style=\"margin-top:3px\"><span class=\"plrk\">Average</span><span style=\"color:var(--c5)\" id=\"pv-coh\">\u2014</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\">Bayesian w\u2081w\u2082w\u2083</span><span class=\"pls ai2\" id=\"ps-bx\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">w\u2081 Sound</span><span style=\"color:var(--fan)\" id=\"pv-w1\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">w\u2082 EVP</span><span style=\"color:var(--evp)\" id=\"pv-w2\">\u2014</span></div><div class=\"plr\"><span class=\"plrk\">w\u2083 EMF</span><span style=\"color:var(--emf)\" id=\"pv-w3\">\u2014</span></div></div></div>\n <div class=\"plb\"><div class=\"plh\"><span class=\"pln\">Closed Loop</span><span class=\"pls run\" id=\"ps-cl\">IDLE</span></div><div class=\"plbd\"><div class=\"plr\"><span class=\"plrk\">Loops</span><span style=\"color:var(--zero)\" id=\"pv-lp\">0</span></div><div class=\"plr\"><span class=\"plrk\">Error</span><span style=\"color:var(--fan)\" id=\"pv-le\">\u2014</span></div></div></div>\n </div>\n</div>\n<!-- \u0639\u0646\u0635\u0631<canvas id=\"bgCv\"> (\u062e\u0644\u0641\u064a\u0629 \u0627\u0644\u0646\u062c\u0648\u0645 \u0627\u0644\u0645\u062a\u062d\u0631\u0643\u0629 \u0627\u0644\u0645\u0644\u0648\u064e\u0651\u0646\u0629) \u062d\u064f\u0630\u0641 \u0628\u0627\u0644\u0643\u0627\u0645\u0644 \u0645\u0639 \u062d\u0630\u0641 \u0627\u0644\u0645\u064a\u0632\u0629\n (28 \u0633\u0628\u062a\u0645\u0628\u0631 2026) \u2014 \u0637\u0644\u0628 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0625\u0632\u0627\u0644\u0629 \u0643\u0644 \u0627\u0644\u062e\u0644\u0641\u064a\u0627\u062a \u0627\u0644\u0632\u062e\u0631\u0641\u064a\u0629 \u0648\u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u0645\u0646 \u0627\u0644\u062a\u0637\u0628\u064a\u0642. -->\n<!-- \u0628\u0646\u064a\u0629 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u062b\u0627\u0628\u062a\u0629 \u2014 \u0645\u0635\u062f\u0631 \u0642\u0627\u0628\u0644 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 (_analysis/home_markup_source.html) \u064a\u064f\u0628\u0642\u064a\u0647\n Claude \u0645\u064f\u0637\u0627\u0628\u0642\u0627\u064b \u0644\u0650\u0640ZERO-v25/web/app.js \u0627\u0644\u0645\u064f\u062c\u0645\u064e\u0651\u0639 \u0641\u0639\u0644\u064a\u0627\u064b (\u0644\u0627 \u062e\u0637\u0648\u0629 \u0628\u0646\u0627\u0621 \u0622\u0644\u064a\u0629\u060c \u0628\u0637\u0644\u0628\n \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 29 \u0633\u0628\u062a\u0645\u0628\u0631 2026 \u2014 \u0631\u0627\u062c\u0639 ZERO-v25/README.md \u0644\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0622\u0644\u064a\u0629). \u0645\u062d\u0631\u0643 JS \u0623\u062f\u0646\u0627\u0647\n (18 \u0645\u0644\u0641\u0627\u064b \u062d\u0633\u0628 \u0627\u0644\u0648\u0638\u064a\u0641\u0629\u060c 00-core-state-metrics.js \u2026 13-zero-integration-aicore.js)\n \u0645\u064f\u062f\u0645\u064e\u062c \u062f\u0627\u062e\u0644 app.js \u0628\u0646\u0641\u0633 \u0647\u0630\u0627 \u0627\u0644\u062a\u0631\u062a\u064a\u0628 \u0628\u0627\u0644\u0636\u0628\u0637. -->");
})();

/* ── 00-core-state-metrics.js ── */

'use strict';
(function(){

const E=id=>document.getElementById(id);
const app=E('app');
// اهتزاز: يستخدم Vibrator الأصلي في ZERO-v25 (ZeroAndroid.vibrate) بدل Vibration API
// الخاصة بالمتصفح، والتي غير مدعومة بشكل موثوق داخل WebView — احتياط للمتصفح فقط
function zVibrate(pat){
 if(typeof ZeroAndroid!=='undefined'&&ZeroAndroid.vibrate){
 try{ZeroAndroid.vibrate(Array.isArray(pat)?pat[0]:pat);}catch(e){}
 return;
 }
 if(navigator.vibrate)navigator.vibrate(pat);
}

// ── إغلاق الفراغات (المشروع بالكامل) ──
// المشكلة ①: `.app` كانت height:100vh ثابتة. 100vh تُحسَب مرة واحدة من ارتفاع نافذة العرض
// (layout viewport) الأولي ولا تتحدّث تلقائياً مع تغيّر الارتفاع الفعلي المرئي لاحقاً — وهذا
// التطبيق يستخدم بالفعل windowSoftInputMode="adjustResize" مع سمة Fullscreen (لا أشرطة نظام)،
// وبه حقول إدخال حقيقية تستدعي لوحة المفاتيح (#termCmd في لوحة الطرفية، #execInp). فتح لوحة
// المفاتيح على WebView أندرويد يُغيّر الارتفاع المرئي الفعلي دون أن يُعاد حساب 100vh دوماً بشكل
// موثوق عبر كل إصدارات WebView — ما يترك فراغاً فارغاً (بلون الخلفية خلف .app) أسفل أو أعلى
// الواجهة عند فتح/إغلاق لوحة المفاتيح، أو عند أي تغيّر مفاجئ في نافذة العرض (تدوير الشاشة، إلخ).
//
// المشكلة ②: كل النوافذ المنبثقة من الأسفل (.pnl: bSheet/aiPanel/zpPanel/termPanel/menuPanel/
// filesPanel/devPanel)، الستارة الخلفية (.ovl)، اللوحة الجانبية (.ppnl)، وتنبيهات "توست" العائمة
// (achToast وتلميح الاكتشاف) كلها position:fixed مع bottom:0 (أو إزاحة ثابتة من الأسفل) — وهذه
// أيضاً تُحسَب نسبةً لحاوية التموضع الأولية (initial containing block) التي لا تتقلّص بالضرورة
// مع تقلّص المساحة المرئية الحقيقية عند فتح لوحة المفاتيح. النتيجة: قد تنزلق هذه العناصر جزئياً
// خلف لوحة المفاتيح (فراغ/تغطية غير مرئية) بدل الجلوس فوقها تماماً — أخطرها لوحة الطرفية نفسها،
// إذ يُخفي هذا حقل الإدخال (#termCmd) الذي استدعى لوحة المفاتيح أصلاً خلفها.
//
// الإصلاح: تتبّع الارتفاع الفعلي عبر VisualViewport API (الأدق لتغيّرات لوحة المفاتيح، مدعوم في
// WebView الحديث) مع احتياط window.innerHeight للأجهزة/الإصدارات الأقدم، وكتابة خاصيتي CSS
// مخصّصتين: (--app-h) الارتفاع الحقيقي الكامل تقرأه .app بدل 100vh الثابتة، و(--vv-bottom-inset)
// المسافة الفعلية بين حافة نافذة العرض التخطيطية السفلية وحافة المساحة المرئية الحقيقية السفلية
// (تساوي صفراً في كل الحالات الطبيعية، ولا تكبر إلا عند تباعد فعلي حقيقي) — تقرأها كل العناصر
// المثبَّتة أسفل الشاشة بدل bottom:0/88px الثابتة، فتبقى دوماً فوق المساحة المرئية الحقيقية تماماً
// ولا يظهر أي فراغ أو تغطية في أي نافذة من نوافذ المشروع.
function _closeGaps(){
 const vv=window.visualViewport;
 const h=(vv&&vv.height)||window.innerHeight;
 if(h>0)document.documentElement.style.setProperty('--app-h',h+'px');
 const bottomInset=vv?Math.max(0,window.innerHeight-(vv.height+vv.offsetTop)):0;
 document.documentElement.style.setProperty('--vv-bottom-inset',bottomInset+'px');
}
_closeGaps();
if(window.visualViewport){
 window.visualViewport.addEventListener('resize',_closeGaps);
 window.visualViewport.addEventListener('scroll',_closeGaps);
}
window.addEventListener('resize',_closeGaps);
window.addEventListener('orientationchange',()=>setTimeout(_closeGaps,80));

/* ══ PARAMS ══ */
const P={delay:20,harmonics:8,alpha:1.5,beta:.01,transThresh:3.0,mu:.02,sens:70,useCL:true,useEVP:true,useEMF:true,useInv:true,useLearn:true,useSF:{inf:true,ult:true,phf:true,sub:true,pie:true},useC:{c1:true,c2:true,c3:true,c4:true,c5:true,c6:true,c7:true,c8:true}};

// ملاحظة ترتيب: FX_N يُستخدَم داخل مُنشئ AppState أدناه؛ التصريح هنا (بدل موضعه
// الأصلي بين متغيرات الحالة الأخرى) يضمن تعريفه قبل أول `new AppState()`.
const FX_N=32;

/* ══ AUDIO STATE ══
 كل الحقول أدناه كانت متغيرات `let` منفصلة على النطاق العام؛ أُعيد تنظيمها هنا
 كحقول لصنف AppState واحد لأنها مُعاد تعيينها بالكامل (لا تُحوَّر داخلياً فقط)
 من ملفات أخرى لم تُحوَّل بعد — أُكِّد ذلك عبر تدقيق شامل لكل استخدام قبل هذا
 التحويل. جسر window (أسفل الملف) يُبقيها متاحة كأسماء عامة عادية لتلك
 الملفات بلا أي تغيير فيها. */
class AppState {
 constructor(){
 this.FREQ_THRESH=3;
 this.isOn=false;this.isRun=false;this.sOpen=false;this.pOpen=false;this.aOpen=false;this.tOpen=false;this.zpOpen=false;this.dmOpen=false;this.menuOpen=false;this.filesOpen=false;this.maskOpen=false;this.physOpen=false;this.aboutOpen=false;this.privacyOpen=false;this.loopDiagOpen=false;this.avOpen=false;
 this.dmTimer=null;this.dmCpuHist=[];this.dmRamHist=[];
 this.actx=null;this.micStr=null;this.micSrc=null;this.ana=null;
 this.silOscs={};
 this.fanFreq=0;this.fanE=0;this.noiseE=0;this.sharpE=0;this.evpE=0;this.evpHz=5;this.emfE=0;
 this.silSc=0;this.aiCyc=0;this.aiCon=0;this.loopN=0;this.loopE=1;this.prevLE=1;
 this.hlPh=0;this.prevX=0;this.fxMSE=0;
 this.fxW=new Array(FX_N).fill(0);this.fxXb=new Array(FX_N).fill(0);
 this.nFloor=null;
 this.iLv=0;this.uLv=0;this.pLv=0;this.bLv=0;this.eLv=0;
 this.aT=null;this.dT=null;this.cT=null;this.lT=null;this.nnT=null;
 /* AI EXEC mode — no chat variables */
 this.learnN=0;this.bestSil=0;
 this.drawId=null;
 }
}
const appState=new AppState();


const KF={x:[0,0],P:[1,1],Q:[.01,.1],R:5,init:false};
const COH_F=[5,10,20,50,100,200,500,1000,2000,4000,8000,16000];
const cSxx=new Float32Array(COH_F.length),cSyy=new Float32Array(COH_F.length);
const cSxy=new Float32Array(COH_F.length),cV=new Float32Array(COH_F.length);
const DRV={phase:180,amp:1.0,wS:.5,wE:.3,wM:.2};

/* ══ ANTI-IDLE SYSTEM ══
 Prevents Android WebView from throttling:
 - Adaptive FFT size scaling (keeps up with audio load)
 - AudioContext resume on visibility restore
 - Silent poke oscillator (sub-Hz keeps audio thread alive)
 - Wake-lock heartbeat counter
 - Micro-interval sentinel (detects & corrects interval drift)
══════════════════════════════════════════════ */
const ANTI_IDLE={
 lastFrame:0, frameTimes:[], avgFrame:16.7,
 drift:0, // interval drift accumulator (ms)
 pokeOsc:null, pokeGain:null,
 fftSizeIdx:0, fftSizes:[4096,8192,16384,32768],
 heartbeat:0, lastHb:0,
 lagFreqs:new Map(), // hz→{lagCount,totalLag} — tracks which freqs cause lag
};

// Adaptive FFT: downscale when frame time > 40ms (heavy load)
function adaptFFT(){
 if(!appState.ana||!appState.actx)return;
 const ft=ANTI_IDLE.avgFrame;
 if(ft>40&&ANTI_IDLE.fftSizeIdx>0){
 ANTI_IDLE.fftSizeIdx--;
 appState.ana.fftSize=ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx];
 logNN(' FFT downscaled→'+ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx]+' (load '+ft.toFixed(0)+'ms)');
 }else if(ft<12&&ANTI_IDLE.fftSizeIdx<ANTI_IDLE.fftSizes.length-1){
 ANTI_IDLE.fftSizeIdx++;
 appState.ana.fftSize=ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx];
 logNN(' FFT upscaled→'+ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx]+' (load '+ft.toFixed(0)+'ms)');
 }
}

// Anti-idle poke oscillator (0.07 Hz — inaudible, keeps audio thread running)
function startAudioPoke(){
 if(!appState.actx||ANTI_IDLE.pokeOsc)return;
 try{
 ANTI_IDLE.pokeOsc=appState.actx.createOscillator();
 ANTI_IDLE.pokeGain=appState.actx.createGain();
 ANTI_IDLE.pokeOsc.frequency.value=0.07;
 ANTI_IDLE.pokeGain.gain.value=0.0001; // effectively silent
 ANTI_IDLE.pokeOsc.connect(ANTI_IDLE.pokeGain);
 ANTI_IDLE.pokeGain.connect(appState.actx.destination);
 ANTI_IDLE.pokeOsc.start();
 logNN(' Anti-idle poke osc started (0.07Hz)');
 }catch(e){logNN(' Poke osc fail: '+e.message);}
}

function stopAudioPoke(){
 if(ANTI_IDLE.pokeOsc){try{ANTI_IDLE.pokeOsc.stop();ANTI_IDLE.pokeOsc.disconnect();}catch(e){}ANTI_IDLE.pokeOsc=null;ANTI_IDLE.pokeGain=null;}
}

// AudioContext resume on tab/app visibility restore
document.addEventListener('visibilitychange',()=>{
 if(document.visibilityState==='visible'&&appState.actx&&appState.actx.state==='suspended'){
 appState.actx.resume().then(()=>{logNN(' AudioContext resumed on focus');});
 }
});

// Anti-sleep ping every 15s
setInterval(()=>{
 if(!appState.actx||!appState.isRun)return;
 if(appState.actx.state==='suspended')appState.actx.resume();
 ANTI_IDLE.heartbeat++;
 const now=performance.now();
 if(ANTI_IDLE.lastHb>0){const gap=now-ANTI_IDLE.lastHb;if(gap>18000)logNN(' Heartbeat gap: '+(gap/1000).toFixed(1)+'s (system was idle)');}
 ANTI_IDLE.lastHb=now;
 // Spectral entropy computation (between speed & bipolar ideas)
 if(appState.ana){
 const fd2=new Float32Array(appState.ana.frequencyBinCount);appState.ana.getFloatFrequencyData(fd2);
 let se=0,sp=0;
 for(let i=5;i<fd2.length;i++){const p=Math.pow(10,fd2[i]/10);sp+=p;}
 if(sp>0){for(let i=5;i<fd2.length;i++){const p=Math.pow(10,fd2[i]/10)/sp;if(p>1e-12)se-=p*Math.log2(p);}}
 const maxSE=Math.log2(fd2.length-5);
 const seNorm=Math.min(1,se/maxSE);
 const ef=E('spec-entropy-fill');if(ef){ef.style.width=(seNorm*100)+'%';}
 const ev=E('spec-entropy-v');if(ev)ev.textContent=seNorm.toFixed(3);
 // High entropy = wideband noise → boost Wiener
 if(seNorm>0.85&&appState.isRun){P.alpha=Math.min(3.5,P.alpha*1.01);}
 }
},15000);


/* ── JITTER ANALYZER — frame-time variance & spike detector ── */
class JitterAnalyzer{
 constructor(){this.hist=[];this.maxLen=80;this.variance=0;this.stdDev=0;this.spikes=0;this.lastT=0;}
 update(){
 const now=performance.now();
 if(this.lastT>0){
 const dt=now-this.lastT;
 this.hist.push(dt);if(this.hist.length>this.maxLen)this.hist.shift();
 const mean=this.hist.reduce((a,b)=>a+b,0)/this.hist.length;
 const v=this.hist.reduce((a,b)=>a+(b-mean)**2,0)/this.hist.length;
 this.variance=v;this.stdDev=Math.sqrt(v);
 this.spikes=this.hist.filter(x=>x>mean+2*this.stdDev).length;
 }
 this.lastT=now;
 }
}
const JITTER=new JitterAnalyzer();

/* ── ZERO CROSSING RATE — waveform texture, voiced/unvoiced ── */
const ZCRATE={val:0,hist:[],peak:0};
function updateZeroCross(td){
 let zc=0;
 for(let i=1;i<td.length;i++){if((td[i]-128)*(td[i-1]-128)<0)zc++;}
 ZCRATE.val=zc/td.length;
 ZCRATE.hist.push(ZCRATE.val);if(ZCRATE.hist.length>80)ZCRATE.hist.shift();
 ZCRATE.peak=Math.max(...ZCRATE.hist,0);
 const v=E('zcr-val');if(v)v.textContent=ZCRATE.val.toFixed(4);
}

/* ── CREST FACTOR — peak:RMS impulsiveness ratio ── */
const CREST={val:0,hist:[]};
function updateCrest(td){
 const vals=Array.from(td).map(x=>Math.abs(x-128)/128);
 const peak=vals.reduce((a,b)=>b>a?b:a,0)+1e-9;
 const rms=Math.sqrt(vals.reduce((a,b)=>a+b*b,0)/vals.length);
 CREST.val=rms>0?peak/rms:1;
 CREST.hist.push(CREST.val);if(CREST.hist.length>80)CREST.hist.shift();
 const v=E('crest-val');if(v)v.textContent=CREST.val.toFixed(2);
}

/* ── POLARITY HISTORY — positive/negative amplitude balance ── */
class PolarHistory{
 constructor(){this.posCount=0;this.negCount=0;this.flipCount=0;this.lastPol=0;this.hist=[];this.maxLen=300;}
 update(amp){
 const pol=amp>=0?1:-1;
 if(this.lastPol!==0&&this.lastPol!==pol)this.flipCount++;
 if(pol>0)this.posCount++;else this.negCount++;
 this.lastPol=pol;
 this.hist.push(pol);if(this.hist.length>this.maxLen)this.hist.shift();
 }
 get ratio(){const t=this.posCount+this.negCount;return t>0?this.negCount/t:0.5;}
}
const POLAR_HIST=new PolarHistory();

/* ── ENERGY ENVELOPE TRACKER — amplitude envelope extraction ── */
const ENV_ENVELOPE={val:0,hist:[],attack:0.02,release:0.998};
function updateEnvelope(td){
 let peak=0;
 for(let i=0;i<td.length;i++){const a=Math.abs((td[i]-128)/128);if(a>peak)peak=a;}
 ENV_ENVELOPE.val=ENV_ENVELOPE.val>peak
 ?ENV_ENVELOPE.val*ENV_ENVELOPE.release
 :ENV_ENVELOPE.val+(peak-ENV_ENVELOPE.val)*ENV_ENVELOPE.attack;
 ENV_ENVELOPE.hist.push(ENV_ENVELOPE.val);
 if(ENV_ENVELOPE.hist.length>200)ENV_ENVELOPE.hist.shift();
}

/* ── SPECTRAL FLUX — between-frame energy change tracker ── */
let _prevFD=null; // خاص بهذا الملف وحده — يبقى محلياً بفضل عزل نطاق IIFE، لا يحتاج جسراً
const SPEC_FLUX={val:0,hist:[],peak:0};
function updateSpecFlux(fd){
 if(_prevFD&&_prevFD.length===fd.length){
 let flux=0;
 for(let i=0;i<fd.length;i++){const d=Math.pow(10,fd[i]/10)-Math.pow(10,_prevFD[i]/10);flux+=d>0?d*d:0;}
 SPEC_FLUX.val=Math.sqrt(flux/fd.length);
 SPEC_FLUX.hist.push(SPEC_FLUX.val);if(SPEC_FLUX.hist.length>100)SPEC_FLUX.hist.shift();
 SPEC_FLUX.peak=Math.max(...SPEC_FLUX.hist,0.001);
 }
 _prevFD=new Float32Array(fd);
 const flv=E('spec-flux-v');if(flv)flv.textContent=SPEC_FLUX.val.toFixed(4);
}




/* ── SPECTRAL MOMENTS — mean/variance/skewness/kurtosis ── */
const SMOM={mean:0,var:0,skew:0,kurt:0};
function updateSpectralMoments(fd,bHz){
 let total=0;
 for(let i=1;i<fd.length;i++)total+=Math.pow(10,fd[i]/10);
 if(total<1e-12)return;
 let m1=0;
 for(let i=1;i<fd.length;i++)m1+=i*bHz*Math.pow(10,fd[i]/10)/total;
 let m2=0,m3=0,m4=0;
 for(let i=1;i<fd.length;i++){
 const p=Math.pow(10,fd[i]/10)/total,d=i*bHz-m1;
 m2+=p*d*d;m3+=p*d*d*d;m4+=p*d*d*d*d;
 }
 SMOM.mean=m1;SMOM.var=m2;
 SMOM.skew=m2>0?m3/Math.pow(m2,1.5):0;
 SMOM.kurt=m2>0?m4/(m2*m2)-3:0;
 const sv=E('smom-v');if(sv)sv.textContent='μ='+(m1/1000).toFixed(1)+'k K='+SMOM.kurt.toFixed(1);
}

/* ── CHROMA VECTOR — 12 pitch-class energy distribution ── */
const NOTE_NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const CHROMA_VEC={vec:new Float32Array(12),dominant:0,conf:0,hist:[]};

/* لا وساطة مطلقاً (طلب صريح من المستخدم 29 سبتمبر 2026 — "حذف الوساطة من كل المشروع"):
 لا جسر Object.defineProperty يزامن window.X مع appState.X بعد الآن —
 appState هو المرجع الوحيد الموجود فعلياً لهذه الحالة (57 حقلاً)، يُقرأ منه مباشرة
 (appState.isOn، appState.FREQ_THRESH، إلخ) من بقية الأقسام الـ17 ومن أي onclick=
 حرفية داخل HTML المحقونة — بلا أي طبقة وسيطة تزامن اسمين
 للقيمة ذاتها. */
window.appState = appState;

// الدوال/الكائنات الثابتة (لا تُعاد تعيينها بالكامل أبداً من أي ملف آخر) —
// عرض مرّة واحدة فقط، بنفس الشكل الخارجي تماماً كما كانت قبل هذا التحويل.
window.E=E; window.app=app; window.zVibrate=zVibrate; window.P=P;
window.FX_N=FX_N; window.KF=KF; window.COH_F=COH_F;
window.cSxx=cSxx; window.cSyy=cSyy; window.cSxy=cSxy; window.cV=cV; window.DRV=DRV;
window.ANTI_IDLE=ANTI_IDLE; window.adaptFFT=adaptFFT;
window.startAudioPoke=startAudioPoke; window.stopAudioPoke=stopAudioPoke;
window.JITTER=JITTER; window.ZCRATE=ZCRATE; window.updateZeroCross=updateZeroCross;
window.CREST=CREST; window.updateCrest=updateCrest;
window.POLAR_HIST=POLAR_HIST; window.ENV_ENVELOPE=ENV_ENVELOPE; window.updateEnvelope=updateEnvelope;
window.SPEC_FLUX=SPEC_FLUX; window.updateSpecFlux=updateSpecFlux;
window.SMOM=SMOM; window.updateSpectralMoments=updateSpectralMoments;
window.NOTE_NAMES=NOTE_NAMES; window.CHROMA_VEC=CHROMA_VEC;

})();

/* ── 01-spectral-analysis.js ── */

'use strict';
(function(){

function updateChromaVec(fd,bHz){
 CHROMA_VEC.vec.fill(0);
 for(let i=1;i<fd.length;i++){
 const hz=i*bHz;if(hz<20||hz>8000)continue;
 const midi=12*Math.log2(hz/440)+69;
 const cls=((Math.round(midi)%12)+12)%12;
 CHROMA_VEC.vec[cls]+=Math.pow(10,fd[i]/10);
 }
 const mx=Math.max(...CHROMA_VEC.vec,1e-12);
 for(let i=0;i<12;i++)CHROMA_VEC.vec[i]/=mx;
 CHROMA_VEC.dominant=Array.from(CHROMA_VEC.vec).indexOf(Math.max(...CHROMA_VEC.vec));
 CHROMA_VEC.conf=CHROMA_VEC.vec[CHROMA_VEC.dominant];
 CHROMA_VEC.hist.push(CHROMA_VEC.dominant);if(CHROMA_VEC.hist.length>60)CHROMA_VEC.hist.shift();
 const cv=E('chroma-dom');if(cv)cv.textContent=NOTE_NAMES[CHROMA_VEC.dominant]+'('+CHROMA_VEC.conf.toFixed(2)+')';
}

/* ── MODULATION INDEX — AM/FM envelope analysis ── */
class ModulationIndex{
 constructor(){this.am=0;this.fm=0;this.hist=[];}
 update(td){
 const s=[];for(let i=0;i<td.length;i++)s.push((td[i]-128)/128);
 let env=0;const envArr=[];
 for(let i=0;i<s.length;i++){env=env*0.92+Math.abs(s[i])*0.08;envArr.push(env);}
 const envMean=envArr.reduce((a,b)=>a+b)/envArr.length;
 const envPeak=envArr.reduce((a,b)=>b>a?b:a,0);
 this.am=envMean>1e-9?(envPeak-envMean)/envMean:0;
 let phChg=0;for(let i=1;i<s.length;i++)if(s[i]*s[i-1]<0)phChg+=Math.abs(s[i]-s[i-1]);
 this.fm=phChg/s.length;
 this.hist.push(this.am);if(this.hist.length>60)this.hist.shift();
 const mv=E('mod-v');if(mv)mv.textContent='AM:'+this.am.toFixed(2)+' FM:'+this.fm.toFixed(3);
 }
}
const MOD_IDX=new ModulationIndex();
function updateModulation(td){return MOD_IDX.update(td);}

/* ── SPECTRAL ROLLOFF — 85th-percentile energy frequency ── */
class SpectralRolloff{
 constructor(){this.hz=0;this.hist=[];}
 update(fd,bHz){
 let total=0;for(let i=1;i<fd.length;i++)total+=Math.pow(10,fd[i]/10);
 let cumul=0,rHz=0;
 for(let i=1;i<fd.length;i++){
 cumul+=Math.pow(10,fd[i]/10);
 if(cumul>=total*0.85){rHz=i*bHz;break;}
 }
 this.hz=rHz||0;
 this.hist.push(this.hz);if(this.hist.length>60)this.hist.shift();
 const rv=E('rolloff-val');if(rv)rv.textContent=(this.hz/1000).toFixed(2)+'kHz';
 }
}
const ROLLOFF=new SpectralRolloff();
function updateRolloff(fd,bHz){return ROLLOFF.update(fd,bHz);}

/* ── SPECTRAL FLATNESS — tonality vs noise (Wiener entropy) ── */
class SpectralFlatness{
 constructor(){this.val=0;this.hist=[];}
 update(fd){
 let logSum=0,linSum=0,n=0;
 for(let i=1;i<fd.length;i++){
 const p=Math.pow(10,fd[i]/10);
 logSum+=Math.log(p+1e-12);linSum+=p;n++;
 }
 const geo=Math.exp(logSum/n);const ari=linSum/n;
 this.val=ari>0?geo/ari:0;
 this.hist.push(this.val);if(this.hist.length>60)this.hist.shift();
 const fv=E('flat-val');if(fv)fv.textContent=this.val.toFixed(4);
 }
}
const SPEC_FLAT=new SpectralFlatness();
function updateSpectralFlatness(fd){return SPEC_FLAT.update(fd);}

/* ══ PERMISSIONS STATE ══ */
const PERMS={mic:'unknown',notifications:'unknown',storage:'unknown',wakeLock:'unknown',fileAccess:'unknown',fileHandle:null};

/* ══ AI FREQUENCY BAN SYSTEM ══ */
const AI_BAN=new Map(); // hz → {reason, bannedAt, cycles, permanent:true (دائم دائماً)}
const AI_GATE={enabled:true,maxBan:50,autoUnbanAfter:100,failThresh:4};
/* عدد الترددات "الجديدة" فقط (بدون الحضر الأساسي/الافتراضي والمؤكَّد من طبقة التكامل) —
 maxBan يحدّ من الحظر الحيّ الجديد تحديداً، لا من إجمالي AI_BAN؛ فالحضر الأساسي وحده
 (٢٥٧+ تردد) يتجاوز maxBan الأصلي (٥٠) وكان سيمنع أي حظر جديد لو قِيس على الإجمالي. */
function newBanCount(){return [...AI_BAN.values()].filter(d=>!d.baseline).length;}
function newZoneCount(){return [...INTERFERENCE_BAN.zones.values()].filter(z=>!z.baseline).length;}

/* ══ OPEN FREQUENCY RANGE ══
 No fixed Hz / kHz / MHz floor.
 Fully open: negative phase (C2/C3) and positive phase (C1/C4).
 RANGE.minHz / maxHz are soft guidance only — never enforced as hard limits.
 Bipolar energy tracked separately: posE (C1/C4) vs negE (C2/C3).
 Polarity ratio drives Wiener alpha and SF gain strategy.
══════════════════════════════════════════════ */
const RANGE={
 minHz:0, // 0 = fully open (was 0.01)
 maxHz:Infinity, // no upper limit (was Nyquist)
 allowNeg:true, // allow negative amplitude / phase-inverted detection
 biasMode:'auto',// 'auto'|'pos'|'neg'|'bipolar'
 posE:0, negE:0, // bipolar energy accumulators
 polarityRatio:0,// posE/(posE+negE), 0.5=balanced
 subBinEnable:true, // double-pass sub-bin interpolation
 negFreqMirror:false, // mirror detected freq as its negative analytic signal
};

/* Harmonic series auto-detector: detects fundamental + overtone ladder */
class HarmonicSeriesDetector{
 constructor(){this.fund=0;this.series=[];this.q=0;this.resonantBands=[];}
 detect(hz,fd,bHz){
 if(!hz||hz<0.01)return;
 const series=[];let fund=hz;let maxQ=0;
 // Try hz as fundamental, look for 2nd→8th harmonic
 for(let h=2;h<=8;h++){
 const targetHz=hz*h;const bin=Math.round(targetHz/bHz);
 if(bin<fd.length){
 const amp=Math.pow(10,(fd[bin]||-120)/10);
 if(amp>1e-6)series.push({h,hz:targetHz,amp});
 }
 }
 if(series.length>=2){
 // Q factor = peak sharpness = fundamental_amp / average_neighbor_amp
 const fundBin=Math.round(hz/bHz);
 const peak=fd[fundBin]||-120;
 // تشديد أكثر: نفس فئة الخلل مرة أخرى — لو كانت خانتا الجوار كلتاهما -Infinity (طاقة
 // صفرية تماماً، حالة طبيعية أخرى لـgetFloatFrequencyData)، فإن جمعهما يبقى -Infinity
 // لا NaN هنا (لأنه ليس طرح Infinity من Infinity)، لكن peak-neighbor يُصبح Infinity
 // (منتهٍ-(-Infinity)=Infinity)، فيظهر "Q=Infinity" حرفياً في السجلّ بدل رقم منطقي
 let neighbor=(fd[fundBin-1]+fd[fundBin+1])/2;
 if(!isFinite(neighbor))neighbor=-120;
 maxQ=Math.max(0.1,Math.min(100,peak-neighbor));
 this.fund=hz;this.series=series;this.q=maxQ;
 // Resonant band detection
 this.resonantBands=series.filter(s=>s.amp>0.001).map(s=>({hz:s.hz,band:getBand(s.hz)}));
 if(maxQ>6)logNN(' Harmonic series: '+hz.toFixed(1)+'Hz · Q='+maxQ.toFixed(1)+' ('+series.length+' overtones)');
 }
 }
}
const HARMONICS=new HarmonicSeriesDetector();
function detectHarmonicSeries(hz,fd,bHz){return HARMONICS.detect(hz,fd,bHz);}

function getBand(hz){
 // تشديد أكثر: كل هذه المقارنات (hz<X) تُعطي false مع NaN — دون هذا الحارس، تردد فاسد
 // كان سيُصنَّف صمتاً كـ"hypersound" (آخر return) بدل رفضه، بنفس نمط خلل NaN/0Hz المُعالَج
 // في كل الدوال الأخرى بالملف.
 if(!isFinite(hz))return'invalid';
 if(hz<0.01)return'sub-sub';if(hz<0.5)return'sub-infra';
 if(hz<20)return'infrasound';if(hz<100)return'bass';
 if(hz<500)return'mid-low';if(hz<2000)return'mid';
 if(hz<8000)return'mid-high';if(hz<20000)return'high';
 if(hz<40000)return'ultrasound';return'hypersound';
}

/* Spectral centroid real-time tracker */
class SpectralCentroid{
 constructor(){this.hz=0;this.hist=[];this.drift=0;}
 update(fd,bHz){
 let num=0,den=0;
 for(let i=1;i<fd.length;i++){const p=Math.pow(10,(fd[i]||-120)/10);num+=i*bHz*p;den+=p;}
 const c=den>0?num/den:0;
 if(this.hist.length>0)this.drift=c-this.hist[this.hist.length-1];
 this.hz=c;this.hist.push(c);if(this.hist.length>50)this.hist.shift();
 const cv2=E('centroid-v');if(cv2)cv2.textContent=(c/1000).toFixed(2)+'kHz';
 const cdv=E('centroid-drift');if(cdv)cdv.textContent=(this.drift>0?'+':'')+this.drift.toFixed(1)+'Hz/frame';
 }
}
const CENTROID=new SpectralCentroid();
function updateCentroid(fd,bHz){return CENTROID.update(fd,bHz);}

/* Frequency density map per octave */
class OctaveDensityMap{
 constructor(){this.bands=new Map();}
 update(){
 this.bands.clear();
 freqDB.forEach(e=>{
 // تشديد أكثر: !e.hz يرفض NaN فعلاً (NaN مزيَّفة القيمة)، لكنه لا يرفض Infinity — وكانت
 // Math.pow(2,Math.floor(Math.log2(Infinity))) تُنتج مفتاحاً حرفياً "Infinity→...Hz".
 if(!e.hz||e.hz<=0||!isFinite(e.hz))return;
 const oct=Math.floor(Math.log2(e.hz));
 const k=oct+'→'+(Math.pow(2,oct).toFixed(0)+'-'+Math.pow(2,oct+1).toFixed(0)+'Hz');
 this.bands.set(k,(this.bands.get(k)||0)+1);
 });
 }
}
const OCTAVE_DENSITY=new OctaveDensityMap();
function updateOctaveDensity(){return OCTAVE_DENSITY.update();}

/* ── SI frequency auto-unit formatter — Hz→kHz→MHz→GHz→THz→PHz→EHz→ZHz→YHz ──
   دالة عامة واحدة تُنسِّق أي قيمة تردد (مهما كبرت) باختيار أنسب بادئة SI تلقائياً،
   بدل تكرار "hz<1000?...+'Hz':...+'kHz'" يدوياً في كل موضع عرض. النطاق الصوتي الفعلي
   لهذا التطبيق لا يتجاوز عملياً بضع مئات كيلوهرتز (فوق-صوتي/فوق-حسي)، لكن الدالة مُعمَّمة
   حتى YHz (10^24) لتبقى آمنة مع أي قيمة غير متوقعة (خطأ حسابي، محاكاة NN متطرفة) دون
   إظهار رقم أسي غير مقروء. تحافظ حرفياً على نفس تنسيق الإخراج القديم للنطاق الشائع
   (بلا مسافة بين الرقم والوحدة، عُشري واحد لـHz، عُشريان لأي بادئة أعلى). */
function fmtFreqSI(hz){
 const U=[[1e24,'YHz'],[1e21,'ZHz'],[1e18,'EHz'],[1e15,'PHz'],[1e12,'THz'],[1e9,'GHz'],[1e6,'MHz'],[1e3,'kHz']];
 const abs=Math.abs(hz);
 for(const [mul,sym] of U){ if(abs>=mul) return (hz/mul).toFixed(2)+sym; }
 return hz.toFixed(1)+'Hz';
}

/* Negative frequency analytic signal mirror */
function negFreqMirror(hz,energy){
 // تشديد أكثر: !hz يرفض NaN لكن لا يرفض Infinity — بدونه، fBin(-Infinity) يُدرِج مفتاح
 // -Infinity فعلياً داخل freqDB (نفس فئة الخلل المُعالَجة في كل الدوال الأخرى).
 if(!RANGE.negFreqMirror||!hz||!isFinite(hz))return;
 // Mirror detected freq into its negative analytic representation
 // Builds inverse for the -hz component (phase conjugate)
 const negHz=-Math.abs(hz);
 if(freqDB.has(fBin(negHz)))return;
 freqDB.set(fBin(negHz),{hz:negHz,count:1,energy:-energy,firstSeen:Date.now(),
 lastSeen:Date.now(),confirmed:false,cancelled:false,invHz:null,invOk:false,class:2,
 isMirror:true});
 freqFile.totalCap++;
}



/* ── PITCH TRACKER (AMDF) — Average Magnitude Difference Function ── */
class PitchTrackerAMDF{
 constructor(){this.hz=0;this.conf=0;this.hist=[];this.note='';}
 update(td){
 if(!appState.actx)return;
 const win=Math.min(1024,td.length);
 const data=new Float32Array(win);
 for(let i=0;i<win;i++)data[i]=(td[i]-128)/128;
 let bestLag=20,bestVal=Infinity;
 for(let lag=20;lag<win>>1;lag++){
 let sum=0;for(let i=0;i<win-lag;i++)sum+=Math.abs(data[i]-data[i+lag]);
 const v=sum/(win-lag);if(v<bestVal){bestVal=v;bestLag=lag;}
 }
 const sr=appState.actx.sampleRate||44100;
 this.hz=bestLag>0?sr/bestLag:0;
 this.conf=Math.max(0,1-bestVal*2);
 if(this.hz>20&&typeof NOTE_NAMES!=='undefined'){
 const midi=Math.round(12*Math.log2(this.hz/440)+69);
 this.note=NOTE_NAMES[((midi%12)+12)%12];
 }
 this.hist.push(this.hz);if(this.hist.length>30)this.hist.shift();
 const pv=E('pitch-amdf');if(pv)pv.textContent=this.hz>10?this.hz.toFixed(1)+'Hz '+this.note:'—';
 }
}
const PITCH_AMDF=new PitchTrackerAMDF();
function updatePitchAMDF(td){return PITCH_AMDF.update(td);}

/* ── HARMONIC-TO-NOISE RATIO (HNR) — signal purity metric ── */
class HarmonicNoiseRatio{
 constructor(){this.val=0;this.hist=[];}
 update(fd,bHz){
 if(!appState.fanFreq||appState.fanFreq<1||!fd)return;
 let harmE=0,noiseEn=0;
 for(let i=1;i<fd.length;i++){
 const hz=i*bHz;const pw=Math.pow(10,fd[i]/10);
 let isHarm=false;
 for(let h=1;h<=8;h++){if(Math.abs(hz-appState.fanFreq*h)<bHz*2){isHarm=true;break;}}
 if(isHarm)harmE+=pw;else noiseEn+=pw;
 }
 this.val=noiseEn>0?10*Math.log10((harmE+1e-12)/(noiseEn+1e-12)):0;
 this.hist.push(this.val);if(this.hist.length>30)this.hist.shift();
 const hv=E('hnr-val');if(hv)hv.textContent=this.val.toFixed(1)+'dB';
 }
}
const HNR=new HarmonicNoiseRatio();
function updateHNR(fd,bHz){return HNR.update(fd,bHz);}

/* ── ROOM MODE DETECTOR — acoustic resonance peak finder ── */
const C_SOUND=343;
class RoomModeDetector{
 constructor(){this.peaks=[];this.dominant=0;}
 detect(fd,bHz){
 const peaks=[];
 for(let i=4;i<fd.length-4;i++){
 if(fd[i]>fd[i-1]+2&&fd[i]>fd[i+1]+2&&fd[i]>fd[i-3]+3&&fd[i]>-55){
 peaks.push({hz:i*bHz,db:fd[i],dimM:(C_SOUND/(2*i*bHz)).toFixed(2)});
 }
 }
 peaks.sort((a,b)=>b.db-a.db);
 this.peaks=peaks.slice(0,6);
 this.dominant=this.peaks[0]?this.peaks[0].hz:0;
 const rv=E('room-mode-v');if(rv)rv.textContent=this.dominant?(this.dominant/1000).toFixed(2)+'kHz':'—';
 }
}
const ROOM_MODES=new RoomModeDetector();
function detectRoomModes(fd,bHz){return ROOM_MODES.detect(fd,bHz);}

/* ── ENVIRONMENT CHANGE DETECTOR — detects acoustic scene transitions ── */
class EnvironmentChangeDetector{
 constructor(){this.prevSig=[];this.score=0;this.events=0;this.lastChange=0;}
 detect(fd){
 const step=Math.max(1,Math.floor(fd.length/16));const sig=[];
 for(let i=0;i<16;i++){
 let s=0;const start=i*step;
 for(let j=start;j<start+step&&j<fd.length;j++)s+=Math.pow(10,fd[j]/10);
 sig.push(s/step);
 }
 if(this.prevSig.length===16){
 let diff=0;
 for(let i=0;i<16;i++)diff+=Math.abs((sig[i]-this.prevSig[i])/(this.prevSig[i]+1e-12));
 this.score=diff/16;
 if(this.score>0.35){
 this.events++;this.lastChange=Date.now();
 logNN(' ENV CHANGE: score='+this.score.toFixed(2));
 if(typeof ENV_FP!=='undefined')ENV_FP.bgFreqs.clear();
 }
 }
 this.prevSig=[...sig];
 const ev=E('env-change-v');if(ev)ev.textContent=this.score.toFixed(3);
 }
}
const ENV_CHANGE_D=new EnvironmentChangeDetector();

/* ── ACOUSTIC SIGNATURE — rolling spectral hash fingerprint ── */
class AcousticSignature{
 constructor(){this.hash=0;this.stable=false;this.stableN=0;this.prevHash=0;}
 update(fd){
 let h=5381;const step=Math.max(1,Math.floor(fd.length/32));
 for(let i=0;i<32;i++){
 const bin=i*step;const q=Math.max(0,Math.round((fd[Math.min(bin,fd.length-1)]+120)*4));
 h=((h<<5)+h+q)&0x7FFFFFFF;
 }
 this.prevHash=this.hash;this.hash=h;
 this.stable=Math.abs(h-this.prevHash)<8000;
 if(this.stable)this.stableN++;else this.stableN=0;
 const sv=E('acoustic-sig-v');if(sv)sv.textContent=(h>>>0).toString(16).toUpperCase().padStart(8,'0');
 }
}
const ACOUSTIC_SIG=new AcousticSignature();
function updateAcousticSig(fd){return ACOUSTIC_SIG.update(fd);}

/* ── TONAL POWER RATIO — tonal peaks vs broadband noise ── */
class TonalPowerRatio{
 constructor(){this.ratio=0;this.hist=[];this.noiseFloor=0;}
 update(fd,bHz){
 let tonalE=0,noiseE2=0,total=0;
 const W=5;
 for(let i=W;i<fd.length-W;i++){
 const local=[];for(let j=i-W;j<=i+W;j++)local.push(fd[j]);
 local.sort((a,b)=>a-b);const med=local[W];
 const pw=Math.pow(10,fd[i]/10);total+=pw;
 if(fd[i]>med+6)tonalE+=pw;else noiseE2+=pw;
 }
 this.ratio=total>0?tonalE/total:0;
 this.hist.push(this.ratio);if(this.hist.length>60)this.hist.shift();
 const tv=E('tonal-v');if(tv)tv.textContent=(this.ratio*100).toFixed(0)+'%';
 }
}
const TONAL=new TonalPowerRatio();
function updateTonalRatio(fd,bHz){return TONAL.update(fd,bHz);}

/* ══ PERMANENT BAN SYSTEM ══
 Three built-in categories pre-loaded at startup, always active.
 Permanent entries in AI_BAN carry {permanent:true} — never auto-unbanned.
 User can toggle categories or add/remove individual freqs from Settings.
══════════════════════════════════════════════════════════════════ */
const PERM_BAN_CATS={
 harmful:{enabled:true,label:'ترددات ضارة', icon:'',desc:'Power-line harmonics & EMF interference'},
 noisy: {enabled:true,label:'ترددات صاخبة', icon:'',desc:'Fan / motor / HVAC ambient noise'},
 mic: {enabled:true,label:'ملتقطة mic', icon:'',desc:'Frequencies always captured by the microphone'},
 thermal:{enabled:true,label:'ترددات حرارية', icon:'',desc:'Frequencies correlated with CPU/GPU/RAM heat — auto-detected'},
 lag: {enabled:true,label:'ترددات تخمّل', icon:'',desc:'Frequencies that cause frame drops & system sluggishness'},
 env: {enabled:false,label:'بيئة خارجية', icon:'',desc:'Frequencies from external environment fingerprint'},
};
// [hz, category, reason]
const DEFAULT_BANNED_FREQS=[
 // ── HARMFUL — power line & EMF harmonics ──
 [50, 'harmful','EMF 50Hz (power line)'],
 [60, 'harmful','EMF 60Hz (power line)'],
 [100, 'harmful','Harmonic 100Hz (50×2)'],
 [120, 'harmful','Harmonic 120Hz (60×2)'],
 [150, 'harmful','Harmonic 150Hz (50×3)'],
 [180, 'harmful','Harmonic 180Hz (60×3)'],
 [200, 'harmful','Harmonic 200Hz (50×4)'],
 [240, 'harmful','Harmonic 240Hz (60×4)'],
 [250, 'harmful','Harmonic 250Hz (50×5)'],
 [300, 'harmful','Harmonic 300Hz (60×5)'],
 [16.67, 'harmful','Railway EMF 16.67Hz'],
 [7.83, 'harmful','Schumann Resonance 7.83Hz'],
 // ── NOISY — fan / motor / HVAC ──
 [120, 'noisy','Fan motor 120Hz'], // may overlap with harmful — bin dedup handles it
 [180, 'noisy','Fan motor 180Hz'],
 [280, 'noisy','Fan hum 280Hz'],
 [340, 'noisy','Fan hum 340Hz'],
 [400, 'noisy','Motor noise 400Hz'],
 [600, 'noisy','HVAC 600Hz'],
 [800, 'noisy','HVAC resonance 800Hz'],
 [1000, 'noisy','HVAC peak 1kHz'],
 [1200, 'noisy','AC noise 1.2kHz'],
 [2000, 'noisy','Ambient noise 2kHz'],
 [3200, 'noisy','Ambient noise 3.2kHz'],
 // ── MIC-CAPTURED — always picked up by mic ──
 [1500, 'mic','Mic self-resonance 1.5kHz'],
 [2500, 'mic','Mic response peak 2.5kHz'],
 [3400, 'mic','Phone mic cutoff 3.4kHz'],
 [5000, 'mic','Mic resonance 5kHz'],
 [6000, 'mic','Mic resonance 6kHz'],
 [8000, 'mic','Mic self-noise 8kHz'],
 [10000, 'mic','Mic harmonic 10kHz'],
 [12000, 'mic','Mic resonance 12kHz'],
 [14000, 'mic','High mic sensitivity 14kHz'],
];

/* ── FREQUENCY FATIGUE — tracks over-detected frequencies for consensus-ban ── */
const FREQ_FATIGUE=new Map(); // bin → {count, lastSeen, score, hz}
function updateFreqFatigue(hz,energy){
 // إصلاح جذري لخلل "0.00Hz" في قائمة الحظر: الشرط القديم !hz&&hz!==0 كان في الواقع
 // يُصرِّح صراحةً بمرور hz=0 (لأن hz!==0 تكون false حين hz=0، فيصبح الشرط كله false ولا
 // يُرجِع)، بينما 0Hz ليس تردداً صوتياً حقيقياً إطلاقاً — فكان أي تجمّع تعب صدفةً عند 0Hz
 // (من حساب قمة طيفية غير مُدقَّق يُؤول لـ0 لاحقاً) يُنتِج حظراً دائماً بعنوان "0.00Hz".
 // التحقّق الصحيح: أي تردد غير محدود القيمة (NaN) أو أقل من 1Hz يُرفَض فوراً.
 if(!hz||hz<1||!isFinite(hz))return;
 const k=fBin(hz);
 if(!FREQ_FATIGUE.has(k))FREQ_FATIGUE.set(k,{count:0,lastSeen:0,score:0,hz});
 const f=FREQ_FATIGUE.get(k);
 const dt=f.lastSeen>0?(Date.now()-f.lastSeen)/1000:0;
 f.count++;f.lastSeen=Date.now();
 f.score=f.score*Math.exp(-dt*0.0004)+energy*0.09;
 if(f.score>75&&!AI_BAN.has(k)){
 AI_BAN.set(k,{reason:'Fatigue ×'+f.count+' (score '+f.score.toFixed(0)+')',
 bannedAt:appState.aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'env',fatigueScore:f.score});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' FATIGUE BAN: '+hz.toFixed(1)+'Hz ('+f.score.toFixed(0)+')');
 }
 if(FREQ_FATIGUE.size>800)FREQ_FATIGUE.delete(FREQ_FATIGUE.keys().next().value);
}

/* ── BAN VOTE SYSTEM — multi-method consensus banning ── */
const BAN_VOTE=new Map(); // bin → {votes:{method:weight}, total, hz}
function castBanVote(hz,method,weight=1){
 // إصلاح جذري لخلل "NaNHz" في قائمة الحظر: هذه الدالة لم تكن تتحقّق من hz إطلاقاً —
 // أي تردد NaN (مثلاً من تسمّم مرشّح كالمان KF بعد قيمة غير منتهية) كان يُستخدَم مباشرةً
 // كمفتاح Map (NaN يُقارَن بنفسه بمساواة SameValueZero فيعمل كمفتاح "صالح" تقنياً) وتتراكم
 // له أصوات حتى يتجاوز حدّ الحظر، فيُنشَأ AI_BAN.set(NaN,...) ويظهر حرفياً "NaNHz" في الواجهة.
 if(!hz||hz<1||!isFinite(hz))return;
 const k=fBin(hz);
 if(!BAN_VOTE.has(k))BAN_VOTE.set(k,{votes:{},total:0,hz,firstSeen:Date.now()});
 const v=BAN_VOTE.get(k);
 v.votes[method]=(v.votes[method]||0)+weight;
 v.total=Object.values(v.votes).reduce((a,b)=>a+b,0);
 const numMethods=Object.keys(v.votes).length;
 if(v.total>=6&&numMethods>=2&&!AI_BAN.has(k)){
 const reason='Vote-ban: '+Object.entries(v.votes).map(([m,w])=>m+'×'+w.toFixed(0)).join(', ');
 AI_BAN.set(k,{reason,bannedAt:appState.aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'env',voteTotal:v.total});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' VOTE BAN: '+hz.toFixed(1)+'Hz ('+numMethods+' methods, total='+v.total.toFixed(1)+')');
 }
 if(BAN_VOTE.size>500)BAN_VOTE.delete(BAN_VOTE.keys().next().value);
}

/* ── FREQUENCY CLUSTER TRACKER — groups nearby banned frequencies ── */
class FreqClusterTracker{
 constructor(){this.groups=[];this.maxGap=100;}
 update(){
 const banned=Array.from(AI_BAN.keys()).map(Number).filter(v=>!isNaN(v)).sort((a,b)=>a-b);
 const groups=[];let cur=null;
 for(const hz of banned){
 if(!cur){cur={min:hz,max:hz,count:1};}
 else if(hz-cur.max<this.maxGap){cur.max=hz;cur.count++;}
 else{groups.push(cur);cur={min:hz,max:hz,count:1};}
 }
 if(cur)groups.push(cur);
 this.groups=groups;
 // ② CHROMA_VEC×FREQ_CLUSTER — Chroma-Seeded Cluster Formation
 if(typeof CHROMA_VEC!=='undefined'&&CHROMA_VEC.conf>0.7){
 const noteHz=440*Math.pow(2,(CHROMA_VEC.dominant-9)/12);
 if(noteHz>20&&!this.groups.find(g=>Math.abs(((g.min+g.max)/2)-noteHz)<60))
 this.groups.push({min:noteHz*0.95,max:noteHz*1.05,count:0,chromaSeeded:true});
 }
 const cv=E('cluster-v');if(cv)cv.textContent=groups.length+' مجموعة';
 }
}
const FREQ_CLUSTER=new FreqClusterTracker();
function updateFreqClusters(){return FREQ_CLUSTER.update();}

/* ── RECURRENCE QUANTIFICATION — detects periodic frequency return ── */
class RecurrenceAnalyzer{
 constructor(){this.matrix=[];this.period=0;this.det=0;this.maxLen=50;}
 update(hz){
 if(!hz||hz<0.1)return;
 const k=fBin(hz);
 this.matrix.push(k);
 if(this.matrix.length>this.maxLen)this.matrix.shift();
 const n=this.matrix.length;let det=0,maxPer=0;
 for(let lag=2;lag<n>>1;lag++){
 let matches=0;
 for(let i=lag;i<n;i++)if(Math.abs(this.matrix[i]-this.matrix[i-lag])<2)matches++;
 const rate=(n-lag)>0?matches/(n-lag):0;
 if(rate>0.6&&lag>maxPer){maxPer=lag;det=rate;}
 }
 this.period=maxPer;this.det=det;
 }
}
const RECURRENCE=new RecurrenceAnalyzer();
function updateRecurrence(hz){return RECURRENCE.update(hz);}

// الدوال/الكائنات الثابتة (لا تُعاد تعيينها بالكامل أبداً من أي ملف آخر) —
// عرض مرّة واحدة فقط، بنفس الشكل الخارجي تماماً كما كانت قبل هذا التحويل. الكائنات
// المُحوَّلة إلى Classes (ModulationIndex/SpectralRolloff/.../RecurrenceAnalyzer) تُعرَض
// كنسخها الوحيدة (MOD_IDX/ROLLOFF/.../RECURRENCE) بنفس الحقول الخارجية تماماً كما كانت
// كائنات حرفية عادية — لا فرق يُلاحَظ من أي قسم آخر. الدوال الحرة (updateModulation،
// detectHarmonicSeries، castBanVote...) تبقى بنفس أسمائها المجرَّدة كأغلفة رقيقة تستدعي
// طريقة الصنف المقابلة، فلا يحتاج أي موضع استدعاء خارجي (القسم 06 بصفة أساسية) لأي تعديل.
window.updateChromaVec=updateChromaVec;
window.MOD_IDX=MOD_IDX; window.updateModulation=updateModulation;
window.ROLLOFF=ROLLOFF; window.updateRolloff=updateRolloff;
window.SPEC_FLAT=SPEC_FLAT; window.updateSpectralFlatness=updateSpectralFlatness;
window.PERMS=PERMS;
window.AI_BAN=AI_BAN; window.AI_GATE=AI_GATE;
window.newBanCount=newBanCount; window.newZoneCount=newZoneCount;
window.RANGE=RANGE;
window.HARMONICS=HARMONICS; window.detectHarmonicSeries=detectHarmonicSeries; window.getBand=getBand;
window.CENTROID=CENTROID; window.updateCentroid=updateCentroid;
window.OCTAVE_DENSITY=OCTAVE_DENSITY; window.updateOctaveDensity=updateOctaveDensity;
window.negFreqMirror=negFreqMirror;
window.PITCH_AMDF=PITCH_AMDF; window.updatePitchAMDF=updatePitchAMDF;
window.HNR=HNR; window.updateHNR=updateHNR;
window.C_SOUND=C_SOUND; window.ROOM_MODES=ROOM_MODES; window.detectRoomModes=detectRoomModes;
window.ENV_CHANGE_D=ENV_CHANGE_D;
window.ACOUSTIC_SIG=ACOUSTIC_SIG; window.updateAcousticSig=updateAcousticSig;
window.TONAL=TONAL; window.updateTonalRatio=updateTonalRatio;
window.PERM_BAN_CATS=PERM_BAN_CATS; window.DEFAULT_BANNED_FREQS=DEFAULT_BANNED_FREQS;
window.FREQ_FATIGUE=FREQ_FATIGUE; window.updateFreqFatigue=updateFreqFatigue;
window.BAN_VOTE=BAN_VOTE; window.castBanVote=castBanVote;
window.FREQ_CLUSTER=FREQ_CLUSTER; window.updateFreqClusters=updateFreqClusters;
window.RECURRENCE=RECURRENCE; window.updateRecurrence=updateRecurrence;
window.fmtFreqSI=fmtFreqSI;

})();

/* ══ 8 FREQUENCY CLASSES ══
 C1 ⊕ Positive: phase amp > 0, energy building
 C2 ⊖ Negative: phase amp < 0, energy cancelling
 C3 ∓ Neg→Pos: alternating, starts negative
 C4 ± Pos→Neg: alternating, starts positive
 C5 ✓ Mic-Detectable: 20Hz ≤ hz ≤ Nyquist/2
 C6 ✗ Mic-Invisible: hz < 1Hz OR hz > Nyquist
 C7 ✓ Spk-Emittable: 0.01Hz ≤ hz ≤ Nyquist
 C8 ✗ Spk-Blocked: hz > Nyquist (hardware limit)
══════════════════════════════════ */
/* ══════════════════════════════════
 16-FREQUENCY CLASS SYSTEM (expanded)
 C1-C8: original polarity/range classes
 C9-C16: sub-infrasound, infrasound, ultrasound,
 hypersound, harmonic series, thermal-correlated,
 lag-correlated, environmental signature
══════════════════════════════════ */

/* ── 02-classification-thermal-nn.js ── */

'use strict';
(function(){

/* ── FREQUENCY CLASSIFICATION — 16-class system ── */
class FreqClassifier{
 constructor(){this.c1=0;this.c2=0;this.c3=0;this.c4=0;this.c5=0;this.c6=0;this.c7=0;this.c8=0;
 this.c9=0;this.c10=0;this.c11=0;this.c12=0;this.c13=0;this.c14=0;this.c15=0;this.c16=0;}
 classify16(hz,amp,phase,nyq){
 const micLo=20,spkHi=nyq;
 const isPos=amp>=0;
 const altPhase=Math.abs(Math.sin(phase));
 const absHz=Math.abs(hz);

 // ── C9: Sub-Infrasound (< 0.01 Hz)
 if(absHz<0.01){this.c9++;return 9;}
 // ── C10: Infrasound (0.01-20 Hz)
 if(absHz>=0.01&&absHz<20){this.c10++;return 10;}
 // ── C11: Ultrasound (20kHz-200kHz)
 if(absHz>=20000&&absHz<200000){this.c11++;return 11;}
 // ── C12: Hypersound (200kHz+)
 if(absHz>=200000){this.c12++;return 12;}
 // ── C13: Harmonic series member
 if(HARMONICS.series.some(s=>Math.abs(s.hz-absHz)<(absHz*0.02))){this.c13++;return 13;}
 // ── C14: Thermal-correlated (if temp rising and freq was detected then)
 if(THERMAL.rising&&THERMAL.correlFreqs.has(fBin(hz))){this.c14++;return 14;}
 // ── C15: Lag-correlated
 if(ANTI_IDLE.lagFreqs.has(fBin(hz))&&(ANTI_IDLE.lagFreqs.get(fBin(hz)).lagCount||0)>=3){this.c15++;return 15;}
 // ── C16: Environmental background
 if(ENV_FP.bgFreqs.has(fBin(hz))){this.c16++;return 16;}
 // ── Original C1-C8
 if(isPos&&Math.cos(phase)>0.5){this.c1++;RANGE.posE+=Math.abs(amp);return 1;}
 if(!isPos||Math.abs(Math.cos(phase)-(-1))<0.3){this.c2++;RANGE.negE+=Math.abs(amp);return 2;}
 if(altPhase>0.7&&!isPos){this.c3++;RANGE.negE+=Math.abs(amp);return 3;}
 if(altPhase>0.7&&isPos){this.c4++;RANGE.posE+=Math.abs(amp);return 4;}
 if(absHz>=micLo&&absHz<=nyq/2){this.c5++;return 5;}
 if(absHz<1||absHz>nyq){this.c6++;return 6;}
 if(absHz>=0.01&&absHz<=spkHi){this.c7++;return 7;}
 this.c8++;return 8;
 }
}
const FC=new FreqClassifier();

const CLS16_META=[
 {id:1, label:'C1⊕', name:'Positive Energy', color:'#8f8f8f', desc:'amp>0, phase 0-90°, building energy'},
 {id:2, label:'C2⊖', name:'Negative Energy', color:'#7c7c7c', desc:'amp<0 or phase 180°, cancelling energy'},
 {id:3, label:'C3∓', name:'Neg→Pos Bipolar', color:'#9c9c9c', desc:'alternating, starts negative'},
 {id:4, label:'C4±', name:'Pos→Neg Bipolar', color:'#828282', desc:'alternating, starts positive'},
 {id:5, label:'C5✓', name:'Mic-Detectable', color:'#959595', desc:'20Hz ≤ hz ≤ Nyquist/2'},
 {id:6, label:'C6✗', name:'Mic-Invisible', color:'#929292', desc:'hz<1Hz or hz>Nyquist'},
 {id:7, label:'C7✓', name:'Speaker-Emittable', color:'#797979', desc:'0.01Hz ≤ hz ≤ Nyquist'},
 {id:8, label:'C8✗', name:'Speaker-Blocked', color:'#929292', desc:'hz > Nyquist (hardware limit)'},
 {id:9, label:'C9', name:'Sub-Infrasound', color:'#818181', desc:'hz < 0.01Hz — seismic/geological'},
 {id:10,label:'C10𝒊', name:'Infrasound', color:'#6d6d6d', desc:'0.01-20Hz — below hearing'},
 {id:11,label:'C11↑', name:'Ultrasound', color:'#8b8b8b', desc:'20kHz-200kHz — above hearing'},
 {id:12,label:'C12∞', name:'Hypersound', color:'#828282', desc:'200kHz+ — molecular/thermal domain'},
 {id:13,label:'C13', name:'Harmonic Series', color:'#cecece', desc:'Part of detected harmonic ladder'},
 {id:14,label:'C14', name:'Thermal-Correlated', color:'#6a6a6a', desc:'Detected when device temp rises'},
 {id:15,label:'C15', name:'Lag-Correlated', color:'#9c9c9c', desc:'Detected during frame drops > 50ms'},
 {id:16,label:'C16', name:'Environmental', color:'#969696', desc:'Persistent background from env fingerprint'},
];

function classifyFreq(hz,amp,phase,nyq){
 // First run 16-class system, return primary class
 return classifyFreq16(hz,amp,phase,nyq);
}

function classifyFreq16(hz,amp,phase,nyq){
 return FC.classify16(hz,amp,phase,nyq);
}


/* ══════════════════════════════════════════════════════════
 THERMAL MONITORING SYSTEM
 CPU: frame-time proxy (long frames = CPU hot)
 GPU: AudioContext baseLatency proxy
 RAM: performance.memory if available
 Freq correlation: which Hz values appear when temp rises
 Auto-ban: frequencies causing sustained heat are banned
 60-second rolling history per component
 Component stress index: aggregate thermal pressure score
══════════════════════════════════════════════════════════ */
class ThermalMonitor{
 constructor(){
 this.cpu={val:0,hist:[],unit:'°C*',label:'CPU'}; // * = estimated via frame time
 this.gpu={val:0,hist:[],unit:'°C*',label:'GPU'}; // estimated via AudioContext latency
 this.ram={val:0,hist:[],unit:'%',label:'RAM'}; // from performance.memory
 this.dsp={val:0,hist:[],unit:'°C*',label:'DSP'}; // AudioContext worklet stress
 this.stress=0; // 0-100 aggregate stress index
 this.rising=false; // true when any component trending up
 this.correlFreqs=new Map(); // hz→{heatCount,totalHeat} — freqs seen during heat
 this.thermBanned=new Set(); // hz values auto-banned due to thermal correlation
 this.histLen=360; // 60s at 6/s samples
 this.lastSample=0;
 this.energyEff=new Map(); // hz→energy-efficiency score (lower=worse)
 }
 sample(){
 const now=performance.now();
 if(now-this.lastSample<167)return; // ~6 samples/sec
 this.lastSample=now;
 const HIST=this.histLen;

 // ── CPU proxy: exponential moving average of frame time
 const ft=ANTI_IDLE.avgFrame;
 // Rough mapping: <8ms≈ambient, 16ms≈load, >33ms≈hot, >50ms≈thermal throttle
 const cpuEst=Math.max(20,Math.min(95, 20 + ft*1.5));
 this.cpu.val=this.cpu.val*0.92+cpuEst*0.08;
 this.cpu.hist.push(this.cpu.val);if(this.cpu.hist.length>HIST)this.cpu.hist.shift();

 // ── GPU/DSP proxy: AudioContext baseLatency (high latency = DSP overloaded)
 if(appState.actx){
 const lat=(appState.actx.baseLatency||0.005)*1000; // ms
 const gpuEst=Math.max(20,Math.min(90, 20 + lat*8));
 this.gpu.val=this.gpu.val*0.9+gpuEst*0.1;
 this.gpu.hist.push(this.gpu.val);if(this.gpu.hist.length>HIST)this.gpu.hist.shift();
 // DSP = AudioContext outputLatency proxy
 const dspLat=(appState.actx.outputLatency||0.01)*1000;
 this.dsp.val=Math.max(20,Math.min(85, 20+dspLat*5));
 this.dsp.hist.push(this.dsp.val);if(this.dsp.hist.length>HIST)this.dsp.hist.shift();
 }

 // ── RAM: performance.memory (Chrome/Android WebView)
 if(performance.memory){
 const used=performance.memory.usedJSHeapSize;
 const total=performance.memory.jsHeapSizeLimit||performance.memory.totalJSHeapSize||1;
 this.ram.val=Math.round((used/total)*100);
 this.ram.hist.push(this.ram.val);if(this.ram.hist.length>HIST)this.ram.hist.shift();
 }

 // ── Stress index
 this.stress=Math.round(
 (this.cpu.val - 20) * 0.4 +
 (this.gpu.val - 20) * 0.3 +
 this.ram.val * 0.15 +
 (this.dsp.val - 20) * 0.15
 );
 this.stress=Math.max(0,Math.min(100,this.stress));

 // ── Rising trend detection (last 30 samples vs previous 30)
 const cpuH=this.cpu.hist;
 if(cpuH.length>=60){
 const recent=cpuH.slice(-30).reduce((a,b)=>a+b,0)/30;
 const older=cpuH.slice(-60,-30).reduce((a,b)=>a+b,0)/30;
 this.rising=(recent-older)>1.5;
 }

 // ── Frequency thermal correlation
 if(this.rising&&appState.fanFreq>0){
 const bin=fBin(appState.fanFreq);
 if(!this.correlFreqs.has(bin))this.correlFreqs.set(bin,{heatCount:0,totalHeat:0,hz:appState.fanFreq});
 const tc=this.correlFreqs.get(bin);
 tc.heatCount++;tc.totalHeat+=this.stress;
 // Auto-ban if this freq has caused heat 8+ times
 if(tc.heatCount>=8&&!this.thermBanned.has(bin)){
 this.thermBanned.add(bin);
 AI_BAN.set(bin,{reason:'Thermal: '+tc.heatCount+'× heat events (stress '+this.stress+')',
 // تشديد (إصلاح خلل): autoUnbanAt يجب أن تكون Infinity كبقية مسارات الحظر الدائم —
 // كانت -1 هنا خطأً، وبما أن execCyc يبدأ من 0 ولا ينخفض أبداً فإن execCyc>=-1 صحيحة
 // دائماً، ما يجعل FREQ_GATE يحذف هذا الحظر الحراري فوراً في أول تمريرة تالية له
 // (خلال ثوانٍ)، رغم كونه permanent:true ومُصمَّماً ليبقى — يُبطل الحماية الحرارية كلياً
 bannedAt:appState.aiCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'thermal',
 heatScore:Math.round(tc.totalHeat/tc.heatCount)});
 checkInterference(bin);
 logNN(' THERMAL BAN: '+appState.fanFreq.toFixed(1)+'Hz (heat×'+tc.heatCount+', stress='+this.stress+')');
 }
 }

 // ── Energy efficiency score
 if(appState.fanFreq>0&&appState.fanE>0){
 const bin=fBin(appState.fanFreq);
 if(!this.energyEff.has(bin))this.energyEff.set(bin,{hz:appState.fanFreq,score:50,samples:0});
 const ef=this.energyEff.get(bin);
 // Low efficiency = high thermal stress per unit of energy benefit
 const eff=Math.max(0,100-(this.stress * appState.fanE * 2));
 ef.score=ef.score*0.95+eff*0.05;ef.samples++;
 }

 // ── Update thermal UI
 this.updateUI();
 }
 updateUI(){
 const parts=[
 {id:'therm-cpu',val:this.cpu.val,unit:this.cpu.unit,max:95},
 {id:'therm-gpu',val:this.gpu.val,unit:this.gpu.unit,max:90},
 {id:'therm-ram',val:this.ram.val,unit:this.ram.unit,max:100},
 {id:'therm-dsp',val:this.dsp.val,unit:this.dsp.unit,max:85},
 {id:'therm-str',val:this.stress,unit:'%',max:100},
 ];
 parts.forEach(p=>{
 const pct=Math.min(1,p.val/p.max);
 const cls=pct<0.5?'cold':pct<0.75?'warm':'hot';
 const bar=E(p.id+'-bar');if(bar){bar.style.width=(pct*100)+'%';bar.className='therm-bar '+cls;}
 const val=E(p.id+'-val');if(val){val.textContent=p.val.toFixed(0)+p.unit;val.className='therm-val '+cls;}
 });
 // Prediction
 const pred=THERM_PRED.predict(this.cpu.hist,60);
 const pv=E('therm-pred');if(pv)pv.textContent=pred?pred.toFixed(0)+'°C* (predicted)':'—';
 // Thermal banned count
 const tb=E('therm-ban-cnt');if(tb)tb.textContent=this.thermBanned.size+' thermal bans';
 // Stress ring on main circle
 const sr=E('stress-ring');if(sr){sr.style.opacity=this.stress>30?'1':'0';
 sr.style.color=this.stress>70?'#7c7c7c':this.stress>40?'#9c9c9c':'#c4c4c4';}
 // مضاد الفيروسات: نفس تحذير "الوميض عند فتح لوحة مغلقة" أعلاه — updateAVPanel نفسها
 // تتحقق أيضاً من avOpen داخلياً، لكن تفادي حتى استدعاء الدالة (وفلترة AI_BAN كاملة)
 // حين تكون اللوحة مغلقة أوفر؛ التحديث هنا يتبع نفس معدّل عيّنة الحرارة (6/ث) لا حاجة لمؤقّت جديد.
 if(appState.avOpen&&typeof updateAVPanel==='function')updateAVPanel();
 }
}
const THERMAL=new ThermalMonitor();
function sampleThermal(){return THERMAL.sample();}
function updateThermalUI(){return THERMAL.updateUI();}

/* BETWEEN thermal & ban-redesign:
 Thermal prediction model — rolling linear regression on history */
class ThermalPredictor{
 predict(hist,steps=30){
 if(hist.length<5)return null;
 const n=Math.min(hist.length,30);const d=hist.slice(-n);
 let sx=0,sy=0,sxy=0,sx2=0;
 for(let i=0;i<n;i++){sx+=i;sy+=d[i];sxy+=i*d[i];sx2+=i*i;}
 const slope=(n*sxy-sx*sy)/(n*sx2-sx*sx||1);
 const intercept=(sy-slope*sx)/n;
 return intercept+slope*(n+steps-1);
 }
}
const THERM_PRED=new ThermalPredictor();

// Sample thermal at 6 Hz
setInterval(sampleThermal,167);


/* ══════════════════════════════════════════════════════════
 ENVIRONMENTAL FINGERPRINT ENGINE
 External: persistent background frequencies captured over time
 Internal: OS/system load fingerprint (frame times, memory, latency)
 AI: monitors which frequencies cause sluggishness
 Anti-entropy: correlates environment changes with freq changes
══════════════════════════════════════════════════════════ */
class EnvironmentFingerprint{
 constructor(){
 this.bgFreqs=new Map(); // hz→{count,firstSeen,lastSeen} — persistent env freqs
 this.internalLoad={frameScore:0,memScore:0,latScore:0}; // internal system fingerprint
 this.external={freqs:[],fingerprint:'',noiseType:'unknown'}; // external acoustic env
 this.slugFreqs=new Map(); // hz→{slugCount,totalFrameTime} — lag-causing freqs
 this.envChanged=false;
 this.lastFingerprint='';
 this.sampleCount=0;
 this._lastFrameCheck=0;
 }
 updateFingerprint(fd,bHz){
 this.sampleCount++;
 // Compute acoustic environment fingerprint (top-5 persistent peaks)
 if(this.sampleCount%60!==0)return; // every 10s at 6fps
 const peaks=[];
 for(let i=2;i<Math.min(fd.length,4096);i++){
 if(fd[i]>fd[i-1]&&fd[i]>fd[i+1]&&fd[i]>-50){peaks.push({hz:i*bHz,dB:fd[i]});}
 }
 peaks.sort((a,b)=>b.dB-a.dB);
 const top5=peaks.slice(0,5);
 top5.forEach(p=>{
 const k=fBin(p.hz);
 if(!this.bgFreqs.has(k))this.bgFreqs.set(k,{hz:p.hz,count:0,firstSeen:Date.now(),lastSeen:Date.now()});
 const e=this.bgFreqs.get(k);e.count++;e.lastSeen=Date.now();
 });
 // Purge stale env freqs (not seen in last 5 minutes)
 const now=Date.now();
 this.bgFreqs.forEach((v,k)=>{if(now-v.lastSeen>300000)this.bgFreqs.delete(k);});
 // Fingerprint string
 const fp=top5.map(p=>p.hz.toFixed(0)).join(',');
 if(fp!==this.lastFingerprint){
 this.envChanged=true;this.lastFingerprint=fp;
 logNN(' Env fingerprint: ['+fp+']Hz');
 }
 // Noise type classification
 const spread=top5.length>1?(top5[top5.length-1].hz-top5[0].hz):0;
 this.external.noiseType=spread>5000?'wideband':spread>500?'narrowband':'tonal';
 const ntv=E('env-noise-type');if(ntv)ntv.textContent=this.external.noiseType;
 }
 /* Sluggishness monitor — correlation of detected freqs with frame drops */
 monitorSlug(){
 const now=performance.now();const ft=now-this._lastFrameCheck;
 this._lastFrameCheck=now;
 if(ft>50&&appState.fanFreq>0){ // frame > 50ms = sluggish
 const k=fBin(appState.fanFreq);
 if(AI_GATE.enabled&&AI_BAN.has(k))return; // تشديد: لا تراكم بيانات تباطؤ لتردد محظور مسبقاً
 if(!this.slugFreqs.has(k))this.slugFreqs.set(k,{hz:appState.fanFreq,slugCount:0,totalFT:0});
 const sf=this.slugFreqs.get(k);sf.slugCount++;sf.totalFT+=ft;
 if(sf.slugCount>=5){
 ANTI_IDLE.lagFreqs.set(k,{hz:appState.fanFreq,lagCount:sf.slugCount,avgLag:sf.totalFT/sf.slugCount});
 // Auto-ban lag-causing frequencies after 8 confirmed sluggish events
 if(sf.slugCount>=8&&!AI_BAN.has(k)){
 AI_BAN.set(k,{reason:'Lag: '+sf.slugCount+'× frame>50ms (avg '+
 (sf.totalFT/sf.slugCount).toFixed(0)+'ms)',
 // تشديد (إصلاح خلل): نفس خلل الحظر الحراري — autoUnbanAt:-1 كانت تجعل FREQ_GATE
 // يحذف حظر التباطؤ فوراً في أول تمريرة تالية، فيعيد monitorSlugFreqs حظره من جديد
 // في الإطار التالي (frame) الذي يتجاوز 50ms — تكرار عديم الفائدة بلا نهاية
 bannedAt:appState.aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'lag',
 lagScore:Math.round(sf.totalFT/sf.slugCount)});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(appState.fanFreq); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(appState.fanFreq); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' LAG BAN: '+appState.fanFreq.toFixed(1)+'Hz (×'+sf.slugCount+' drops)');
 }
 }
 }
 }
 /* Internal system load fingerprint update */
 updateInternalLoad(){
 // Frame score: normalized frame time
 this.internalLoad.frameScore=Math.min(1,ANTI_IDLE.avgFrame/50);
 // Memory score
 if(performance.memory){
 this.internalLoad.memScore=performance.memory.usedJSHeapSize/
 (performance.memory.jsHeapSizeLimit||1);
 }
 // Latency score
 if(appState.actx)this.internalLoad.latScore=Math.min(1,(appState.actx.baseLatency||0)*20);
 const iv=E('env-int-load');
 if(iv)iv.textContent='Frame:'+ANTI_IDLE.avgFrame.toFixed(0)+'ms Mem:'+
 (this.internalLoad.memScore*100).toFixed(0)+'% Lat:'+
 (this.internalLoad.latScore*100).toFixed(0)+'%';
 }
}
const ENV_FP=new EnvironmentFingerprint();
function updateEnvFingerprint(fd,bHz){return ENV_FP.updateFingerprint(fd,bHz);}
function monitorSlugFreqs(){return ENV_FP.monitorSlug();}
function updateInternalLoad(){return ENV_FP.updateInternalLoad();}

/* كل حضر دائم — لا يوجد مؤقت — لا تصعيد مطلوب */

/* Ban pattern recognition — detects band bans */
class BanPatternDetector{
 constructor(){this.bands=[];}
 detect(){
 const sorted=[...AI_BAN.keys()].sort((a,b)=>a-b);
 const bands=[];let start=sorted[0],prev=sorted[0],count=1;
 for(let i=1;i<sorted.length;i++){
 if(sorted[i]-prev<prev*0.15){count++;prev=sorted[i];}
 else{if(count>=3)bands.push({minHz:start,maxHz:prev,count});start=sorted[i];prev=sorted[i];count=1;}
 }
 if(count>=3)bands.push({minHz:start,maxHz:prev,count});
 this.bands=bands;
 if(bands.length)logNN(' Ban band: '+bands[0].minHz.toFixed(0)+'-'+bands[0].maxHz.toFixed(0)+'Hz ('+bands[0].count+' freqs)');
 return bands;
 }
}
const BAN_PATTERNS=new BanPatternDetector();


/* ── MEMORY PRESSURE MONITOR — heap usage & GC event detection ── */
class MemoryPressureMonitor{
 constructor(){this.val=0;this.hist=[];this.gcCount=0;this.lastGC=0;this.leakScore=0;this.lastUsed=0;}
 update(){
 if(!performance.memory)return;
 const used=performance.memory.usedJSHeapSize;
 const limit=performance.memory.jsHeapSizeLimit||1;
 this.val=(used/limit)*100;
 if(this.lastUsed>0&&this.lastUsed-used>5e6){
 this.gcCount++;this.lastGC=Date.now();
 }
 this.lastUsed=used;
 this.hist.push(this.val);if(this.hist.length>120)this.hist.shift();
 if(this.hist.length>=60){
 const first=this.hist.slice(0,20).reduce((a,b)=>a+b)/20;
 const last=this.hist.slice(-20).reduce((a,b)=>a+b)/20;
 this.leakScore=Math.max(0,last-first);
 }
 const mv=E('mem-press-v');if(mv)mv.textContent=this.val.toFixed(0)+'% GC:'+this.gcCount;
 }
}
const MEM_PRESS=new MemoryPressureMonitor();
function updateMemPressure(){return MEM_PRESS.update();}
setInterval(updateMemPressure,2500);

/* ── TIMING DRIFT — systematic interval drift detection ── */
class TimingDriftTracker{
 constructor(){this.expected=40;this.actual=[];this.drift=0;this.driftRate=0;this._lastT=0;}
 update(){
 const now=performance.now();
 if(this._lastT>0){
 const dt=now-this._lastT;
 this.actual.push(dt);if(this.actual.length>100)this.actual.shift();
 const mean=this.actual.reduce((a,b)=>a+b)/this.actual.length;
 this.drift=mean-this.expected;
 if(this.actual.length>=20){
 const first=this.actual.slice(0,10).reduce((a,b)=>a+b)/10;
 const last2=this.actual.slice(-10).reduce((a,b)=>a+b)/10;
 this.driftRate=last2-first;
 }
 const tv=E('drift-v');if(tv)tv.textContent=(this.drift>0?'+':'')+this.drift.toFixed(1)+'ms';
 }
 this._lastT=now;
 }
}
const TIMING_DRIFT=new TimingDriftTracker();
function updateTimingDrift(){return TIMING_DRIFT.update();}

/* ── EXPERIENCE REPLAY — NN training sample buffer for offline learning ── */
class ExperienceReplay{
 constructor(){this.buf=[];this.maxSize=256;this.miniBatch=12;}
 push(inp,reward,sil){
 this.buf.push({inp:[...inp],reward,sil,t:Date.now()});
 if(this.buf.length>this.maxSize)this.buf.shift();
 }
 sample(){
 const n=Math.min(this.miniBatch,this.buf.length);
 if(n<3)return[];
 const out=[];const used=new Set();
 while(out.length<n){
 const idx=Math.floor(Math.random()*this.buf.length);
 if(!used.has(idx)){used.add(idx);out.push(this.buf[idx]);}
 }
 return out;
 }
}
const EXP_REPLAY=new ExperienceReplay();
function erPush(inp,reward,sil){return EXP_REPLAY.push(inp,reward,sil);}
function erSample(){return EXP_REPLAY.sample();}

/* ── TEMPORAL DIFFERENCE — TD(0) error tracker for value estimation ── */
class TDLearner{
 constructor(){this.err=0;this.hist=[];this.gamma=0.92;this.curVal=0;this.prevVal=0;}
 update(reward,curSil){
 this.prevVal=this.curVal;this.curVal=curSil/100;
 this.err=reward+this.gamma*this.curVal-this.prevVal;
 this.hist.push(this.err);if(this.hist.length>100)this.hist.shift();
 const tv=E('td-err-v');if(tv)tv.textContent=this.err.toFixed(3);
 }
}
const TD_LEARN=new TDLearner();
function updateTD(reward,curSil){return TD_LEARN.update(reward,curSil);}

/* ── HEBBIAN FREQ ASSOCIATION — co-activation learning between frequencies ── */
const HEBBIAN=new Map(); // 'binA:binB' → strength
function hebbLearn(hz1,hz2,reward){
 if(!hz1||!hz2||Math.abs(hz1-hz2)<0.5)return;
 const k=[fBin(hz1),fBin(hz2)].sort().join(':');
 const cur=HEBBIAN.get(k)||0;
 HEBBIAN.set(k,cur*0.97+reward*0.03);
 if(HEBBIAN.size>500)HEBBIAN.delete(HEBBIAN.keys().next().value);
}
function hebbStrength(hz1,hz2){
 const k=[fBin(hz1),fBin(hz2)].sort().join(':');
 return HEBBIAN.get(k)||0;
}

/* ── SYNAPTIC WEIGHT HISTOGRAM — NN weight distribution monitor ── */
class WeightHistogram{
 constructor(){this.bins=new Array(20).fill(0);this.min=-1;this.max=1;}
 update(){
 if(!NN.w1)return;
 this.bins.fill(0);
 const all=[...NN.w1,...NN.w2,...NN.b1,...NN.b2];
 for(const w of all){
 const idx=Math.floor(((w-this.min)/(this.max-this.min))*this.bins.length);
 if(idx>=0&&idx<this.bins.length)this.bins[idx]++;
 }
 }
}
const WT_HIST=new WeightHistogram();
function updateWtHist(){return WT_HIST.update();}

/* ══════════════════════════════════
 NEURAL NETWORK — 16→24→8
 Full policy-gradient with momentum
══════════════════════════════════ */
class PolicyNetwork{
 constructor(){
 this.in=16;this.hid=24;this.out=8;this.lr=0.012;this.mom=0.88;this.trainN=0;this.loss=1.0;this.lastOut=null;this.hist=[];
 this.w1=null;this.b1=null;this.w2=null;this.b2=null;this.dw1=null;this.db1=null;this.dw2=null;this.db2=null;
 }
 init(){
 const ni=this.in,nh=this.hid,no=this.out;
 const xv=(r,c)=>Array.from({length:r*c},()=>(Math.random()*2-1)*Math.sqrt(2/(r+c)));
 this.w1=xv(ni,nh);this.b1=Array(nh).fill(0);
 this.w2=xv(nh,no);this.b2=Array(no).fill(0);
 this.dw1=Array(ni*nh).fill(0);this.db1=Array(nh).fill(0);
 this.dw2=Array(nh*no).fill(0);this.db2=Array(no).fill(0);
 logNN(' NN dims: in='+ni+' hid='+nh+' out='+no+' params='+(ni*nh+nh+nh*no+no));
 logNN(' NN initialized: 16→24→8 · mom=0.88 · lr=0.012 (16-class expanded)');
 }
 forward(inp){
 const ni=this.in,nh=this.hid,no=this.out,{w1,b1,w2,b2}=this;
 const h=Array(nh).fill(0);
 for(let j=0;j<nh;j++){let s=b1[j];for(let i=0;i<ni;i++)s+=inp[i]*w1[i*nh+j];h[j]=Math.tanh(s);}
 const out=Array(no).fill(0);
 for(let k=0;k<no;k++){let s=b2[k];for(let j=0;j<nh;j++)s+=h[j]*w2[j*no+k];out[k]=1/(1+Math.exp(-s));}
 this.lastOut=out;return{h,out};
 }
 trainStep(inp,reward){
 if(!this.w1)return;
 const ni=this.in,nh=this.hid,no=this.out,{w1,b1,w2,b2,lr,mom}=this;
 const{h,out}=this.forward(inp);
 const dO=out.map((o,k)=>reward*(o>0.5?1:-1)*o*(1-o)*lr);
 const dH=Array(nh).fill(0);
 for(let j=0;j<nh;j++){let s=0;for(let k=0;k<no;k++){const i2=j*no+k;this.dw2[i2]=mom*this.dw2[i2]+dO[k]*h[j];w2[i2]+=this.dw2[i2];s+=dO[k]*w2[i2];}dH[j]=s*(1-h[j]*h[j]);}
 for(let k=0;k<no;k++){this.db2[k]=mom*this.db2[k]+dO[k];b2[k]+=this.db2[k];}
 for(let i=0;i<ni;i++){for(let j=0;j<nh;j++){const i2=i*nh+j;this.dw1[i2]=mom*this.dw1[i2]+dH[j]*inp[i];w1[i2]+=this.dw1[i2];}}
 for(let j=0;j<nh;j++){this.db1[j]=mom*this.db1[j]+dH[j];b1[j]+=this.db1[j];}
 this.trainN++;const lv=1-Math.abs(reward);this.loss=this.loss*.95+lv*.05;
 this.hist.push({reward,loss:this.loss,sil:appState.silSc,cyc:appState.aiCyc});if(this.hist.length>200)this.hist.shift();
 }
}
const NN=new PolicyNetwork();
function nnInit(){return NN.init();}
function nnFwd(inp){return NN.forward(inp);}
function nnTrain(inp,reward){return NN.trainStep(inp,reward);}

function nnInp(){
 const nyq=appState.actx?appState.actx.sampleRate/2:24000;
 return[Math.min(Math.abs(appState.fanFreq)/nyq,1),appState.fanE,Math.min(freqDB.size/200,1),appState.evpE,appState.emfE,Math.min(appState.loopE*10,1),Math.abs(DRV.phase-180)/90,Math.min(appState.fxMSE*1000,1),appState.silSc/100,1-appState.loopE,Math.min(NN.trainN/1000,1),(new Date().getHours())/24,RANGE.polarityRatio,Math.min(THERMAL.stress/100,1),Math.min(ANTI_IDLE.avgFrame/50,1),Math.min(CENTROID.hz/nyq,1)];
}

function nnCtrlSF(out){
 if(!out)return;
 appState.iLv=0.3+out[0]*.7;appState.uLv=0.3+out[1]*.7;
 appState.pLv=0.3+out[4]*.7;appState.bLv=0.2+out[3]*.8;appState.eLv=0.2+out[5]*.8;
 // Out[6]: thermal aggression, out[7]: anti-lag boost
 if(THERMAL.stress>50)appState.iLv=Math.min(1,appState.iLv*(1+out[6]*.1));
 if(ANTI_IDLE.avgFrame>30)appState.uLv=Math.min(1,appState.uLv*(1+out[7]*.05));
 updSFGains();
}

function updSFGains(){
 Object.entries(appState.silOscs).forEach(([k,v])=>{
 if(!v||!v.gain)return;
 if(k.startsWith('ig'))v.gain.value=appState.iLv*.07;
 else if(k.startsWith('ug'))v.gain.value=appState.uLv*.05;
 else if(k.startsWith('pg'))v.gain.value=appState.pLv*.025;
 else if(k.startsWith('bg'))v.gain.value=appState.bLv*.035;
 else if(k.startsWith('eg'))v.gain.value=appState.eLv*.028;
 });
}

/* ══════════════════════════════════
 FREQUENCY DATABASE
 Records every captured frequency.
 Confirmed at ×THRESH → inverse built.
══════════════════════════════════ */
const freqDB=new Map();
let freqFile={totalCap:0,totalConf:0,totalCanc:0,entries:[]};
const NN_LOG=[];

/* ══════════════════════════════════════════════
 SOFTWARE NOTCH SUPPRESSION — applied to FFT data
 Confirmed freqs get a -depth_dB triangular notch
 before peak detection so the detector ignores them
══════════════════════════════════════════════ */
const NOTCH_SUPPRESS=new Map(); // key=fBin, val={hz,depth,halfBins,lastHit,order}
const NOTCH_HARM={enabled:false,maxOrder:3}; // auto-add harmonic notches
const NOTCH_DECAY={enabled:false,afterMs:30000}; // auto-deactivate stale notches
const FREQ_BAND={enabled:false,lo:20,hi:20000}; // KF band lock

// الدوال/الكائنات الثابتة (لا تُعاد تعيينها بالكامل أبداً من أي ملف آخر) —
// عرض مرّة واحدة فقط، بنفس الشكل الخارجي تماماً كما كانت قبل هذا التحويل. الكائنات
// المُحوَّلة إلى Classes (FreqClassifier/ThermalMonitor/.../PolicyNetwork) تُعرَض كنسخها
// الوحيدة بنفس الحقول الخارجية تماماً كما كانت كائنات حرفية عادية. كائنات `Map` الخام
// المُستهلَكة مباشرة من مواضع خارجية (HEBBIAN، freqDB، NOTCH_SUPPRESS) بقيت Map عادية.
window.FC=FC; window.CLS16_META=CLS16_META;
window.classifyFreq=classifyFreq; window.classifyFreq16=classifyFreq16;
window.THERMAL=THERMAL; window.sampleThermal=sampleThermal; window.updateThermalUI=updateThermalUI;
window.THERM_PRED=THERM_PRED;
window.ENV_FP=ENV_FP; window.updateEnvFingerprint=updateEnvFingerprint;
window.monitorSlugFreqs=monitorSlugFreqs; window.updateInternalLoad=updateInternalLoad;
window.BAN_PATTERNS=BAN_PATTERNS;
window.MEM_PRESS=MEM_PRESS; window.updateMemPressure=updateMemPressure;
window.TIMING_DRIFT=TIMING_DRIFT; window.updateTimingDrift=updateTimingDrift;
window.EXP_REPLAY=EXP_REPLAY; window.erPush=erPush; window.erSample=erSample;
window.TD_LEARN=TD_LEARN; window.updateTD=updateTD;
window.HEBBIAN=HEBBIAN; window.hebbLearn=hebbLearn; window.hebbStrength=hebbStrength;
window.WT_HIST=WT_HIST; window.updateWtHist=updateWtHist;
window.NN=NN; window.nnInit=nnInit; window.nnFwd=nnFwd; window.nnTrain=nnTrain;
window.nnInp=nnInp; window.nnCtrlSF=nnCtrlSF; window.updSFGains=updSFGains;
window.freqDB=freqDB; window.freqFile=freqFile; window.NN_LOG=NN_LOG;
window.NOTCH_SUPPRESS=NOTCH_SUPPRESS; window.NOTCH_HARM=NOTCH_HARM;
window.NOTCH_DECAY=NOTCH_DECAY; window.FREQ_BAND=FREQ_BAND;

})();

/* ── 03-notch-inverse-engine.js ── */

'use strict';
(function(){

const SESSION_STAT={startT:0,hopCount0:0,envCount:{},notchPeak:0,suppEffSum:0,suppEffN:0};
let notchDecayT=null;
const PEAKS_DATA={peaks:[],lastT:0,maxPeaks:5};
const SQI={val:0,kfConf:0,suppEff:0,envStab:0,hopPenalty:0};
const NOTCH_SUGGEST={hz:0,count:0,threshold:5,shown:false,toastT:0,_toastTimer:null};
// Dev110 globals
const SQI_HIST={vals:[],maxLen:60}; // ~1 min rolling at ~1s update
const FREQ_ALARMS=new Map(); // key=fBin(hz), val={hz,tol,count,lastTrigT,cooldown,enabled}
const BAND_POWER={BANDS:[{lo:20,hi:63,lbl:'20'},{lo:63,hi:125,lbl:'63'},{lo:125,hi:250,lbl:'125'},{lo:250,hi:500,lbl:'250'},{lo:500,hi:1000,lbl:'500'},{lo:1000,hi:2000,lbl:'1k'},{lo:2000,hi:4000,lbl:'2k'},{lo:4000,hi:8000,lbl:'4k'},{lo:8000,hi:20000,lbl:'8k'}],vals:new Float32Array(9)};
const SPEC_DELTA={baseline:null,baseT:0,bHz:0.5};
let lastFFD=null; // last Float32Array FFT frame — for DELTA baseline compare
// Dev120 globals
const KF_LOCK={enabled:false,hz:0,tol:15}; // constrain KF tracking to target ±tol Hz
const ADAPTIVE_ALERT={enabled:false,warnSQI:50,critSQI:25,warnHops:5,level:'ok',lastT:0,cooldown:8000};
const REC={active:false,buf:[],maxLen:3000,startT:0}; // 3000×40ms ≈ 2 min recording

function activateNotch(hz,_order){
 // تشديد أكثر: نفس فئة خلل NaNHz لكن في قائمة NOTCH — نقطتا نقر الطيف/الخط الزمني
 // (initCanvasTap) تحسبان hz=pct*nyq حيث pct=x/rect.width؛ لو كانت rect.width=0 (عنصر
 // Canvas لم يُخطَّط بعد، سيناريو واقعي جداً عند نقر سريع فور فتح لوحة) فإن x/0 قد تُنتِج
 // NaN، والشرط القديم في تلك الدالتين كان hz<1 فقط — وهذا لا يرفض NaN إطلاقاً (أي مقارنة
 // بـNaN تُقيَّم false)! التحصين الأضمن هنا في نقطة الدخول المشتركة لكل نداءات activateNotch.
 if(!hz||!isFinite(hz)||hz<1)return;
 const k=fBin(hz);if(NOTCH_SUPPRESS.has(k))return;
 if(_order>1&&appState.actx&&hz>appState.actx.sampleRate/2)return; // harmonic out of Nyquist
 const e=freqDB.get(k);const cls=e?e.class:5;
 // Tonal classes (C1/C2) → narrow notch; broadband/unknown → wider
 const halfBins=cls<=2?2:cls===5?3:4;
 const depth=cls<=2?40:32;
 const order=_order||1;
 NOTCH_SUPPRESS.set(k,{hz,depth,halfBins,lastHit:Date.now(),order});
 // Auto harmonic chain — add 2f, 3f … if enabled
 if(NOTCH_HARM.enabled&&order===1){
 const nyq=appState.actx?appState.actx.sampleRate/2:20000;
 for(let n=2;n<=NOTCH_HARM.maxOrder;n++){const hHz=hz*n;if(hHz<nyq)activateNotch(hHz,n);}
 }
 updateNotchUI();
}

function deactivateNotch(hz){
 NOTCH_SUPPRESS.delete(fBin(hz));
 updateNotchUI();
}

function updateNotchUI(){
 const nc=E('notch-count');const nl=E('notch-list');
 if(nc)nc.textContent=NOTCH_SUPPRESS.size;
 if(NOTCH_SUPPRESS.size>SESSION_STAT.notchPeak)SESSION_STAT.notchPeak=NOTCH_SUPPRESS.size;
 if(!nl)return;
 if(!NOTCH_SUPPRESS.size){
 nl.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">No confirmed freqs yet — فور التأكيد يُنشأ notch تلقائياً</div>';
 return;
 }
 const rows=[];
 // خط دفاع أخير (مثل renderBanList/renderPermSettings): استبعاد أي hz غير منتهٍ حتى لو
 // تسرَّب من مسار غير متوقَّع — activateNotch نفسها مُحصَّنة الآن فهذا احتياطي بحت
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins,order})=>{
 if(typeof hz!=='number'||!isFinite(hz))return;
 const hTag=order>1?`<span style="color:var(--muted);font-size:7px;margin-left:3px">×${order}</span>`:'';
 rows.push(`<div class="notch-item"><span class="notch-hz"> ${hz.toFixed(1)} Hz${hTag}</span><span class="notch-meta">-${depth}dB · ±${halfBins}bin</span><button class="notch-rm" onclick="deactivateNotch(${hz})">✕</button></div>`);
 });
 nl.innerHTML=rows.join('');
}

/* ══════════════════════════════════════════════
 MINI SPECTROGRAM — rolling FFT waterfall
══════════════════════════════════════════════ */
const specHistory=[];
const SPEC_MAX_ROWS=40;

function pushSpecFrame(fd8){
 // fd8 = Uint8Array from ana.getByteFrequencyData
 specHistory.push(fd8);
 if(specHistory.length>SPEC_MAX_ROWS)specHistory.shift();
}

function drawMiniSpec(){
 const cv=E('specCv');if(!cv)return;
 const W=cv.clientWidth||300;const H=48;
 if(cv.width!==W*window.devicePixelRatio){cv.width=Math.round(W*(window.devicePixelRatio||1));cv.height=Math.round(H*(window.devicePixelRatio||1));}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 const rows=specHistory.length;if(!rows)return;
 const rowH=cH/SPEC_MAX_ROWS;
 const img=ctx.createImageData(cW,cH);
 const d=img.data;
 for(let ri=0;ri<rows;ri++){
 const frame=specHistory[ri];
 const yBase=Math.round((SPEC_MAX_ROWS-1-ri)*rowH); // newest at bottom
 const yEnd=Math.round((SPEC_MAX_ROWS-ri)*rowH);
 for(let xi=0;xi<cW;xi++){
 const fi=Math.floor(xi/cW*frame.length);
 const v=fi<frame.length?frame[fi]:0;
 // heat map: cold-blue → cyan → green → yellow → red
 let r,g,b;
 if(v<64){r=0;g=0;b=v*4;}
 else if(v<128){r=0;g=(v-64)*4;b=255-(v-64)*4;}
 else if(v<192){r=(v-128)*4;g=255;b=0;}
 else{r=255;g=255-(v-192)*4;b=0;}
 for(let y=yBase;y<yEnd&&y<cH;y++){
 const idx=(y*cW+xi)*4;
 d[idx]=r;d[idx+1]=g;d[idx+2]=b;d[idx+3]=220;
 }
 }
 }
 ctx.putImageData(img,0,0);
 // Overlay confirmed-notch frequency markers
 if(NOTCH_SUPPRESS.size>0&&appState.ana&&appState.actx){
 const bHz=appState.actx.sampleRate/appState.ana.fftSize;
 ctx.strokeStyle='rgba(165,165,165,0.75)';ctx.lineWidth=1;ctx.setLineDash([3,3]);
 NOTCH_SUPPRESS.forEach(({hz})=>{
 const x=Math.round(hz/bHz/specHistory[0].length*cW);
 if(x>=0&&x<cW){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,cH);ctx.stroke();}
 });
 ctx.setLineDash([]);
 }
}

function fBin(hz){return Math.round(hz/0.5)*0.5;}

function fRecord(hz,energy){
 if(!hz||hz<0.01)return;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz))){trackPostBanDetection(hz,energy);return;} // banned — track & skip
 const bin=fBin(hz),now=Date.now();
 if(freqDB.has(bin)){
 const e=freqDB.get(bin);e.count++;e.energy=e.energy*.8+energy*.2;e.lastSeen=now;
 if(e.count===appState.FREQ_THRESH&&!e.confirmed){
 e.confirmed=true;freqFile.totalConf++;
 if(P.useInv)buildInverse(hz,energy,e);
 activateNotch(hz);
 logNN(' Confirmed: '+hz.toFixed(2)+'Hz (×'+e.count+') → notch+inverse queued');
 }
 }else{
 freqDB.set(bin,{hz:bin,count:1,energy,firstSeen:now,lastSeen:now,confirmed:false,cancelled:false,invHz:null,invOk:false,class:0});
 freqFile.totalCap++;
 }
 writeFreqFile();
}

function fPurge(){const now=Date.now();freqDB.forEach((v,k)=>{if(now-v.lastSeen>30000&&!v.confirmed)freqDB.delete(k);});}

// مراجعة سابعة ضمن إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم": هذه
// الدالة تُستدعى من fRecord() — أي في كل دورة detectAll تقريباً (حتى 25 مرة/ثانية) طوال
// تشغيل المحرك — وكانت تُعيد فرز **كامل** freqDB (Map ينمو بلا سقف طوال الجلسة: كل تردد
// "مؤكَّد" لا يُحذَف منه أبداً حتى لو صمت لاحقاً — fPurge() تحذف فقط غير المؤكَّد بعد 30
// ثانية صمت) من الصفر في كل مرة. مع تقدّم الجلسة (بيئة صاخبة، جلسة طويلة)، freqDB قد
// يتجاوز المئات أو الآلاف من الإدخالات — فتكلفة هذا الفرز (O(n log n)) تتصاعد كلما طالت
// مدة الاستخدام، بالضبط نمط "الأداء يزداد سوءاً بمرور الوقت"، ويحدث على نفس الخيط
// الرئيسي الوحيد الذي يُعالج أيضاً أي تفاعل واجهة لحظي (بما فيه فتح/تبديل القوائم).
// الإصلاح: تحديد تحديث النسخة المُرتَّبة (freqFile.entries، المُستخدَمة للعرض والتصدير
// فقط) بمعدّل معقول (~250ms) بدل كل دورة على حدة — freqDB نفسها (مصدر الحقيقة الحي)
// تبقى محدَّثة فوراً في fRecord() كما كانت تماماً بلا أي تغيير؛ فارق التأخير (أقل من ربع
// ثانية) غير مُدرَك إطلاقاً سواء في العرض الحي أو في تصدير يدوي يُطلقه المستخدم لاحقاً.
let _lastFreqFileWrite=0;
function writeFreqFile(){
 const now=Date.now();
 if(now-_lastFreqFileWrite<250)return;
 _lastFreqFileWrite=now;
 freqFile.entries=[...freqDB.values()].sort((a,b)=>b.count-a.count).slice(0,100);
 updateFreqUI();
}

/* ══════════════════════════════════
 INVERSE GENERATOR
 Confirmed freq → build anti-phase.
 Verify via mic → anti-search if fail.
══════════════════════════════════ */
class InverseGenerator{
 constructor(){this.active=new Map();this.failed=new Map();this.maxTry=5;this.verMs=800;}
 build(hz,energy,dbEntry){
 // تشديد أكثر: hz<0.01 وحدها لا ترفض NaN — لو وصل NaN هنا فسيُمرَّر إلى
 // osc.frequency.value/dly.delayTime.value، وضبط AudioParam بقيمة NaN يرمي استثناءً
 // في محرّك الصوت الحقيقي (لا مجرد "NaNHz" في العرض، بل توقّف فعلي لدورة الكشف)
 if(!hz||!isFinite(hz)||hz<0.01||!appState.actx||this.active.has(hz))return;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz))){trackPostBanDetection(hz,energy);return;} // AI banned — track & skip
 // متابعة تقرير "يتجمد أثناء التشغيل" — خلافاً لكل خريطة مماثلة في الملف (HEBBIAN وBAN_VOTE
 // بسقف 500، NOTCH_SUPPRESS محمية بـ NOTCH_DECAY)، لم يكن لـ INV.active أي سقف أو تنظيف دوري
 // إطلاقاً. verifyInv() عند النجاح تضع verified=true فقط ولا تحذف الإدخال أبداً — فيبقى
 // osc.start() الحقيقي المتّصل بـ actx.destination يعمل للأبد. عبر جلسة طويلة، انجراف Kalman
 // الطبيعي للضوضاء الفيزيائية (مروحة، دندنة كهرومغناطيسية...) عبر خانات fBin (0.5Hz) متجاورة
 // يجعل كل خانة جديدة تُؤكَّد تُنشئ oscillator/gain دائمَين إضافيَّين — تراكم غير محدود لموارد
 // صوت حيّة فعلية عبر الوقت (لا عبر الضغط المتكرر)، يثقل معالجة الصوت تدريجياً حتى التجمّد —
 // يطابق تماماً وصف المستخدم: "يتجمد أثناء التشغيل" لا فور الضغط. الإصلاح: سقف بنفس أسلوب
 // HEBBIAN/BAN_VOTE، مع إيقاف/فصل الأوسيلاتور الأقدم فعلياً (لا مجرد حذف إدخال الخريطة).
 if(this.active.size>=40){
 const oldestKey=this.active.keys().next().value;
 const oldest=this.active.get(oldestKey);
 if(oldest){try{oldest.osc.stop();oldest.g.disconnect();}catch(e){}}
 this.active.delete(oldestKey);
 }
 const osc=appState.actx.createOscillator(),g=appState.actx.createGain(),dly=appState.actx.createDelay(0.5);
 osc.type='sine';osc.frequency.value=hz;
 // Phase inversion via half-period delay
 const halfPeriod=Math.min(1/(hz*2),0.5);
 dly.delayTime.value=halfPeriod;
 // Gain: inaudible for audible freqs, physical for sub/ultra
 g.gain.value=(hz<20||hz>20000)?energy*.12:energy*.025;
 osc.connect(dly);dly.connect(g);g.connect(appState.actx.destination);
 osc.start();
 this.active.set(hz,{osc,g,dly,attempts:1,verified:false,t:Date.now(),hz,energy});
 dbEntry.invHz=hz;
 setTimeout(()=>this.verify(hz,dbEntry),this.verMs);
 updateInvUI();
 }
 // تشديد: أي إبطال صوتي (inverse) نشط فعلاً على السماعة لتردد ما، لحظة أن يُحظر هذا التردد
 // عبر أي مسار (تعب/تصويت/تباطؤ — وليس فقط banFreq/autoDetectAndBan اللذين كانا يوقفانه فعلاً)
 // يجب إيقافه فوراً؛ وإلا يستمر صوت الإبطال بالتشغيل من السماعة رغم أن التردد أصبح محظوراً
 stopActive(hz){
 // تشديد: مطابقة بالصندوق (fBin) لا بالقيمة الخام — hz الوارد هنا (من updateFreqFatigue/
 // castBanVote/monitorSlugFreqs/escalateInterferenceZone/banFreq/autoDetectAndBan) هو تردد
 // اللحظة الحالية (قد يكون متذبذباً قليلاً بفعل Kalman) بينما مفتاح INV.active المخزَّن هو
 // القيمة الخام وقت buildInverse الأصلي — قد يختلفان بكسور هرتز فتفشل مطابقة hz===hz
 // الحرفية صامتة ويستمر صوت الإبطال بالتشغيل رغم الحظر. المطابقة بـfBin تضمن الإيقاف دائماً.
 const bin=fBin(hz);let stopped=false;
 this.active.forEach((inv,key)=>{
 if(fBin(key)===bin){
 try{inv.osc.stop();inv.g.disconnect();}catch(e){}
 this.active.delete(key);
 stopped=true;
 }
 });
 if(stopped)updateInvUI();
 }
 verify(hz,dbEntry){
 if(!this.active.has(hz))return;
 const inv=this.active.get(hz);
 const bin=fBin(hz);const dbE=freqDB.get(bin);
 // Check mic — if freq gone, inverse worked
 if(!dbE||dbE.count===0||dbE.energy<0.01){
 inv.verified=true;dbEntry.cancelled=true;dbEntry.invOk=true;
 freqFile.totalCanc++;writeFreqFile();
 logNN('✓ CANCELLED: '+hz.toFixed(2)+'Hz — inverse success');
 nnTrain(nnInp(),0.9);return;
 }
 if(inv.attempts<this.maxTry){inv.attempts++;this.antiSearchStep(hz,inv,dbEntry);}
 else{
 logNN('✗ FAILED: '+hz.toFixed(2)+'Hz — switching to anti-pattern search');
 nnTrain(nnInp(),-0.4);
 this.antiPatternStep(hz,inv,dbEntry);
 }
 }
 antiSearchStep(hz,inv,dbEntry){
 // Rotate phase in 22.5° steps
 const prev=this.failed.get(hz)||{phase:Math.PI};
 const newPhase=prev.phase+(Math.PI/8);
 if(inv.dly){inv.dly.delayTime.value=Math.min((newPhase/(2*Math.PI))/hz,0.5);}
 inv.osc.frequency.value=hz+(hz*0.001*inv.attempts);
 this.failed.set(hz,{phase:newPhase});
 logNN('⟳ Anti-search: '+hz.toFixed(2)+'Hz φ='+(newPhase*180/Math.PI).toFixed(0)+'°');
 setTimeout(()=>this.verify(hz,dbEntry),this.verMs*1.5);
 }
 antiPatternStep(hz,inv,dbEntry){
 // Search harmonic neighbors: if hz repeats and inverse fails, try related freqs
 const cands=[hz/2,hz*1.5,hz/3,hz*2].filter(f=>f>0.01&&f<(appState.actx?appState.actx.sampleRate/2:24000));
 cands.forEach((cf,i)=>{
 setTimeout(()=>{
 if(!this.active.has(hz))return;
 this.active.get(hz).osc.frequency.value=cf;
 logNN('↩ Anti-pattern: '+hz.toFixed(2)+'Hz → trying '+cf.toFixed(2)+'Hz');
 setTimeout(()=>{const bin=fBin(hz);const d=freqDB.get(bin);if(!d||d.energy<0.01){logNN('✓ Anti-pattern SUCCESS via '+cf.toFixed(2)+'Hz');nnTrain(nnInp(),.7);}},this.verMs);
 },i*600);
 });
 }
}
const INV=new InverseGenerator();
function buildInverse(hz,energy,dbEntry){return INV.build(hz,energy,dbEntry);}
function stopActiveInverse(hz){return INV.stopActive(hz);}
function verifyInv(hz,dbEntry){return INV.verify(hz,dbEntry);}
function antiSearch(hz,inv,dbEntry){return INV.antiSearchStep(hz,inv,dbEntry);}
function doAntiPattern(hz,inv,dbEntry){return INV.antiPatternStep(hz,inv,dbEntry);}

/* ══ MIC PROFILE ══ */
class MicProfile{
 constructor(){this.sr=0;this.nyq=0;this.fftRes=0;this.minDet=0;this.maxDet=0;this.dynRange=0;this.latMs=0;this.feat={cent:0,zcr:0,crest:0,flat:0,hnr:0};}
 profile(){
 if(!appState.actx||!appState.ana)return;
 this.sr=appState.actx.sampleRate;this.nyq=appState.actx.sampleRate/2;
 this.fftRes=appState.actx.sampleRate/appState.ana.fftSize;
 this.minDet=this.fftRes;this.maxDet=this.nyq;
 this.dynRange=Math.abs(appState.ana.maxDecibels-appState.ana.minDecibels);
 this.latMs=((appState.actx.baseLatency||0)+(appState.actx.outputLatency||0))*1000;
 updateMicUI();logNN(' Mic profiled: '+this.sr/1000+'kHz · '+this.fftRes.toFixed(3)+'Hz/bin · '+this.dynRange+'dB');
 }
 extract(td,fd,bHz){
 const N=td.length,M=Math.min(fd.length,4096);
 let sw=0,s=0;for(let i=1;i<M;i++){const p=Math.pow(10,fd[i]/10);sw+=i*bHz*p;s+=p;}
 this.feat.cent=s>0?sw/s:0;
 let zc=0;for(let i=1;i<N;i++){if((td[i-1]-128)*(td[i]-128)<0)zc++;}this.feat.zcr=zc/N;
 let pk=0,rv=0;for(let i=0;i<N;i++){const v=Math.abs(td[i]-128)/128;if(v>pk)pk=v;rv+=v*v;}
 rv=Math.sqrt(rv/N);this.feat.crest=rv>0?pk/rv:0;
 let ls=0,as2=0;for(let i=1;i<M;i++){const p=Math.max(1e-12,Math.pow(10,fd[i]/10));ls+=Math.log(p);as2+=p;}
 this.feat.flat=as2>0?Math.exp(ls/(M-1))/(as2/(M-1)):0;
 this.feat.hnr=appState.fanFreq>0?appState.fanE/Math.max(appState.noiseE,0.001):0;
 }
}
const MIC=new MicProfile();
function profileMic(){return MIC.profile();}
function extractFeat(td,fd,bHz){return MIC.extract(td,fd,bHz);}

/* ══ INIT ══ */
/* addMsg stub — chat tab replaced by EXEC; forward to exec log */
function addMsg(role, txt) {
 if(role==='bot'){
 // Convert markdown-like text to plain exec lines
 const lines = txt.replace(/\*\*/g,'').replace(/\*/g,'').split('\n').filter(l=>l.trim());
 logExec({prog:'SYS',lines:lines.slice(0,8),ms:0,auto:true});
 }
}
window.addEventListener('load',()=>{
 buildCoh(); // استدعاء bgLoop() (خلفية النجوم المتحركة) حُذف — أُزيلت الميزة بالكامل (28 سبتمبر 2026)
 // Load permanent bans immediately
 setTimeout(()=>{
 // ① استعادة حالة الفئات من PERSIST أولاً (قبل loadDefaultBans)
 PERSIST.loadCats();
 loadDefaultBans();
 },200);
 // Initial exec log message — show 8-class system info
 setTimeout(()=>{
 logExec({prog:'INIT',lines:[
 'ZERO AI v25 — Neural Intelligence',
 'C1⊕ Positive · C2⊖ Negative · C3∓ Neg→Pos · C4± Pos→Neg',
 'C5+ Mic-Detectable · C6- Mic-Invisible',
 'C7+ Spk-Emittable · C8- Spk-Blocked',
 'Neural Net 16→24→8 · FreqDB + Inverse Gen',
 ' حضر دائم: ترددات ضارة · صاخبة · mic (قابل للتعديل في الإعدادات)',
 'Type LIST for programs · Tap AI to begin',
 ],ms:0,auto:true});
 },0);
});

/* ══ UI STATE ══ */
function setS(st){
 app.classList.remove('s-on','s-off','s-zero');app.classList.add('s-'+st);
}

/* ══ TOGGLE ══ */
// إغلاق الفراغات: ضغط زر التشغيل/الإيقاف أكثر من مرة بسرعة (قبل اكتمال دورة startAll() السابقة)
// كان يُسبِّب تجمّد التطبيق فعلياً. السبب الجذري: initAudio() يتحقّق من `actx&&micStr` لتفادي
// إعادة التهيئة — لكن كلا المتغيّرين يبقيان null طوال مدة await navigator.mediaDevices.
// getUserMedia(...) (قد تستغرق مئات المللي ثانية). ضغطة تشغيل ثانية أثناء هذا الانتظار (حتى لو
// سبقتها ضغطة إيقاف بينهما) تتجاوز هذا الفحص وتبدأ طلب getUserMedia()+AudioContext جديداً كلياً
// بالتوازي — فيُصبح لدينا أكثر من AudioContext حي يعمل فعلياً في آن واحد. الأسوأ: عند اكتمال
// الطلبين، آخر واحد يكتمل يكتب فوق actx/micStr العامّين، فيضيع المرجع إلى الطلب الأقدم (الذي ظل
// حياً ويعمل) إلى الأبد — لا يمكن لاحقاً استدعاء actx.close()/micStr.getTracks().stop() عليه
// إطلاقاً. تكرار الضغط "أكثر من مرة" يراكم عدة سياقات صوت حيّة متروكة (كل واحد يستهلك المعالج
// والميكروفون فعلياً)، وهذا يُثقل الخيط الرئيسي في WebView أندرويد حتى يتجمّد التطبيق تماماً —
// بالضبط العرض المُبلَّغ عنه (تجمّد، تعذّر التمرير/التنقل).
// الإصلاح: حارس تكرار (_toggleBusy) يرفض أي ضغطة جديدة أثناء انتقال قيد التنفيذ فعلياً (سواء
// تشغيل أو إيقاف)، ويُعطِّل الزر نفسه أثناء ذلك كحماية مضاعفة على مستوى DOM — فلا يمكن لأي عدد
// من الضغطات المتكررة أن يُنشئ أكثر من طلب تهيئة صوت واحد أبداً.
// متابعة نفس تقرير المستخدم بعد التوضيح الإضافي: "1) لا يمكن التمرير 2) مدة فاصلة بين
// التشغيل والإيقاف 3) ضغطات يستجيب لها الزر وضغطات لا استجابة لها" — الحارس أعلاه (_toggleBusy)
// يمنع التجمّد الفعلي (١) بالفعل، لكن (٢) و(٣) كشفا عن مشكلتين حقيقيتين إضافيتين في toggleAI()
// نفسها لم تكونا موجودتين في initAudio():
// (أ) كانت الشيفرة تُحدِّث كل نصوص/ألوان الواجهة إلى حالة "يعمل الآن " فوراً وبشكل متزامن —
// قبل معرفة هل نجحت await startAll() أصلاً (قد تفشل: رفض إذن الميكروفون مثلاً). فتظهر
// الواجهة "تعمل" بينما isRun ما زالت false فعلياً — عدم اتّساق حقيقي بين الحالة الظاهرة
// والحالة الفعلية، يجعل الضغطة التالية تتصرف بشكل يبدو عشوائياً ("ضغطة تستجيب وأخرى لا").
// (ب) الزر كان يتحول فوراً إلى نص " إيقاف" النهائي ثم يُعطَّل بصرياً (باهت فقط) طوال-١
// الانتظار الحقيقي لتهيئة الميكروفون/AudioContext على العتاد الفعلي (قد يستغرق ثوانٍ) — بلا
// أي مؤشر "جارٍ المعالجة" مميّز؛ فتبدو تلك المدة الفاصلة الحقيقية والضرورية أشبه بزر لا
// يستجيب لا بعملية تحدث فعلاً.
// الإصلاح: (أ) لا تُطبَّق حالة "تشغيل" النهائية على الواجهة إلا بعد نجاح startAll() فعلياً؛ عند
// الفشل تُعاد isOn/الواجهة إلى حالة "متوقف" حقيقية ومتّسقة فوراً بدل تركها عالقة. (ب) حالة
// وسيطة مرئية صريحة " جارِ التشغيل..." تُعرض طوال هذه المدة الفاصلة الحقيقية، فتُفهَم كعملية
// جارية لا كتجمّد.
// ملاحظة توثيقية (فحص ما بعد التحويل): _toggleBusy علم إعادة-إسناد (reassigned flag) لا حالة
// كائن تُعدَّل حقولها. لو أُعلن هنا كـ let عادي ثم عُرِّض مرة واحدة فقط عبر خاصية window
// المقابلة في نهاية الـIIFE، فإن أي إعادة إسناد لاحقة داخل toggleAI (true/false) تُحدِّث
// النسخة المحلية فقط ولا تنعكس أبداً على تلك الخاصية — فيتجمّد القارئ الخارجي (بما في
// ذلك test_full_ui_run.js الذي يستطلع _toggleBusy مباشرة عبر page.evaluate) على القيمة
// الابتدائية إلى الأبد. الإصلاح: لا تصريح محلي إطلاقاً؛ اجعل window._toggleBusy مصدر الحقيقة
// الوحيد، فيتحلّل أي استخدام عارٍ لاحق للاسم (قراءة أو كتابة) عبر سلسلة النطاق إلى نفس الخاصية
// حيّةً في الحالتين — تماماً كسلوكها الأصلي كمتغيّر عام مسطّح قبل التحويل.
window._toggleBusy=false;
async function toggleAI(e){
 if(_toggleBusy)return;
 _toggleBusy=true;
 const hrbBusy=E('homeRunBtn');if(hrbBusy)hrbBusy.disabled=true;
 try{
 appState.isOn=!appState.isOn;
 const b=E('cb');if(b){b.classList.add('press');setTimeout(()=>b.classList.remove('press'),300);}
 mkRip(e,appState.isOn?'rgba(129,129,129,.3)':'rgba(123,123,123,.3)');
 if(appState.isOn){
 zVibrate([12,4,8]);
 // حالة وسيطة مرئية فوراً — قبل أي await — كي لا تبدو الضغطة بلا أثر إطلاقاً.
 const hrbW=E('homeRunBtn');if(hrbW){hrbW.textContent='جارِ التشغيل...';hrbW.className='home-run-btn wait';}
 const ht2w=E('homeT2');if(ht2w)ht2w.textContent='جارِ تهيئة الميكروفون...';
 const ok=await startAll();
 if(!ok){
 // فشلت التهيئة فعلياً — أعد isOn/الواجهة لحالة "متوقف" حقيقية بدل تركها عالقة على
 // "تشغيل" وهمية بينما isRun ما زالت false. رسالة الخطأ التي كتبتها initAudio() في
 // homeT2 تبقى كما هي — لا تُستبدَل هنا.
 appState.isOn=false;
 const tt0=E('tTxt');if(tt0)tt0.textContent='OFF';
 const st20=E('sTit');if(st20)st20.textContent='ZERO AI v25 — Neural Intelligence';
 const ss0=E('sSub');if(ss0)ss0.textContent='Neural Net · Inverse Gen · 8 Classes · Silent Output';
 const sw0=E('sw-ai');if(sw0)sw0.checked=false;
 const hd0=E('homeDot');if(hd0)hd0.classList.remove('on');
 const ht10=E('homeT1');if(ht10)ht10.textContent='متوقف';
 const hrb0=E('homeRunBtn');if(hrb0){hrb0.textContent='▶ تشغيل';hrb0.className='home-run-btn off';}
 setS('off');
 return;
 }
 const tt=E('tTxt');if(tt)tt.textContent='ON';
 const st2=E('sTit');if(st2)st2.textContent='ZERO AI v25 Active';
 const ss=E('sSub');if(ss)ss.textContent='Neural Net · FreqDB · Inverse Gen · Silent Output';
 const sw=E('sw-ai');if(sw)sw.checked=true;
 const hd=E('homeDot');if(hd)hd.classList.add('on');
 const ht1=E('homeT1');if(ht1)ht1.textContent='يعمل الآن';
 const ht2=E('homeT2');if(ht2)ht2.textContent='الكشف والتحليل نشط';
 const hrb=E('homeRunBtn');if(hrb){hrb.textContent='إيقاف';hrb.className='home-run-btn on';}
 const lr=E('lr'),siD=E('siD'),siT=E('siT');
 setS('on');if(lr)lr.classList.add('go');if(siD)siD.className='si-d proc';if(siT)siT.textContent='Processing — NO audible sound from speaker';animLF();
 }else{
 zVibrate([8]);
 const tt=E('tTxt');if(tt)tt.textContent='OFF';
 const st2=E('sTit');if(st2)st2.textContent='ZERO AI v25 — Neural Intelligence';
 const ss=E('sSub');if(ss)ss.textContent='Neural Net · Inverse Gen · 8 Classes · Silent Output';
 const sw=E('sw-ai');if(sw)sw.checked=false;
 const hd=E('homeDot');if(hd)hd.classList.remove('on');
 const ht1=E('homeT1');if(ht1)ht1.textContent='متوقف';
 const ht2=E('homeT2');if(ht2)ht2.textContent='ZERO — جاهز للتشغيل';
 const hrb=E('homeRunBtn');if(hrb){hrb.textContent='▶ تشغيل';hrb.className='home-run-btn off';}
 const lr=E('lr'),siD=E('siD'),siT=E('siT');
 setS('off');if(lr)lr.classList.remove('go');if(siD)siD.className='si-d';if(siT)siT.textContent='Speaker emits NO audible sound';
 stopAll();
 }
 } finally {
 _toggleBusy=false;
 const hrbDone=E('homeRunBtn');if(hrbDone)hrbDone.disabled=false;
 }
}

/* عرض حيّ لحالة الجلسة على الشاشة الرئيسية — أُضيف 28 سبتمبر 2026 ("اكمل بناء ومميزات
 التطبيق"، بعد تبسيط الشاشة إلى زر واحد فقط): المحرك يحسب فعلياً مقاييس حيّة مفيدة طوال
 التشغيل — فعالية الإلغاء اللحظية (silSc، مبنية من نسبة تراجع الطاقة عبر النطاق الترددي)
 ومدة الجلسة (SESSION_STAT.startT) — لكن بعد حذف كل اللوحات (BG badge، AI Brain، الطرفية)
 لم يعد لهذين المقياسين أي سطح مرئي إطلاقاً رغم استمرار حسابهما فعلياً في الخلفية. هذا لا
 يضيف أي زر أو عنصر تفاعلي جديد (لا يخالف قيد "زر واحد فقط") — فقط يستبدل نص القراءة الثابت
 "الكشف والتحليل نشط" في homeT2 (الموجود أصلاً) بنص حيّ يتحدّث كل ثانية طالما المحرك يعمل.
 تشديد: الحارس هنا isRun لا isOn عمداً — isOn ينقلب فوراً عند الضغط (قبل await التهيئة)،
 بينما isRun لا يصير true إلا بعد نجاح initAudio() فعلياً؛ لو استُخدم isOn هنا كان سيطغى
 هذا التحديث على رسالة "جارِ تهيئة الميكروفون..." بصفر% ومدة 00:00 مضلِّلة أثناء الانتظار. */
function updateHomeLiveStatus(){
 if(!appState.isRun)return;
 const t2=E('homeT2');if(!t2)return;
 const dur=SESSION_STAT.startT>0?Math.round((Date.now()-SESSION_STAT.startT)/1000):0;
 const m=String(Math.floor(dur/60)).padStart(2,'0'),s=String(dur%60).padStart(2,'0');
 t2.textContent=`فعالية الإلغاء: ${appState.silSc}% · ${m}:${s}`;
}
setInterval(updateHomeLiveStatus,1000);

function mkRip(e,c){
 const el=e.currentTarget||e.target;if(!el)return;
 const r=el.getBoundingClientRect(),rip=document.createElement('div');const sz=Math.max(r.width,r.height)*2;
 Object.assign(rip.style,{position:'absolute',width:sz+'px',height:sz+'px',left:((e.clientX||r.left+r.width/2)-r.left)-sz/2+'px',top:((e.clientY||r.top+r.height/2)-r.top)-sz/2+'px',borderRadius:'50%',background:c||'rgba(129,129,129,.2)',opacity:'.25',transform:'scale(0)',animation:'ripA .6s ease-out forwards',pointerEvents:'none',zIndex:'100'});
 el.style.position='relative';el.style.overflow='hidden';el.appendChild(rip);setTimeout(()=>rip.remove(),700);
}

function animLF(){/* loop flow animation — reserved for future UI */}

/* ══ PANELS ══ */
function openSheet(){appState.sOpen=true;E('ovl').classList.add('on');E('bSheet').classList.add('open');}
function closeSheet(){appState.sOpen=false;if(!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');E('bSheet').classList.remove('open');}
function togglePipe(){appState.pOpen?closePipe():openPipe();}
function openPipe(){appState.pOpen=true;E('ovl').classList.add('on');E('ppnl').classList.add('open');}

// الدوال/الكائنات الثابتة (لا تُعاد تعيينها بالكامل أبداً من أي ملف آخر) — عرض مرّة واحدة
// فقط، بنفس الشكل الخارجي تماماً كما كانت قبل هذا التحويل. INV/MIC (الكائنان الوحيدان بسلوك
// حقيقي خاص بهما في هذا القسم) أصبحا class (InverseGenerator/MicProfile)؛ بقية الكائنات
// (SESSION_STAT، PEAKS_DATA، SQI، NOTCH_SUGGEST، SQI_HIST، FREQ_ALARMS، BAND_POWER،
// SPEC_DELTA، KF_LOCK، ADAPTIVE_ALERT، REC) بيانات/إعداد تملكها فعلياً أقسام لاحقة
// (05-presets-scenes-tracking، 06-detection-engine-core، 07b-ai-exec-engine) — لا دالة
// مالكة هنا فبقيت كما هي. specHistory/pushSpecFrame/drawMiniSpec/fBin/fRecord/toggleAI/…
// دوال حرّة بلا حالة صنف خاصة بها فبقيت كذلك أيضاً.
window.SESSION_STAT=SESSION_STAT; window.notchDecayT=notchDecayT;
window.PEAKS_DATA=PEAKS_DATA; window.SQI=SQI; window.NOTCH_SUGGEST=NOTCH_SUGGEST;
window.SQI_HIST=SQI_HIST; window.FREQ_ALARMS=FREQ_ALARMS; window.BAND_POWER=BAND_POWER;
window.SPEC_DELTA=SPEC_DELTA; window.lastFFD=lastFFD;
window.KF_LOCK=KF_LOCK; window.ADAPTIVE_ALERT=ADAPTIVE_ALERT; window.REC=REC;
window.activateNotch=activateNotch; window.deactivateNotch=deactivateNotch; window.updateNotchUI=updateNotchUI;
window.specHistory=specHistory; window.SPEC_MAX_ROWS=SPEC_MAX_ROWS;
window.pushSpecFrame=pushSpecFrame; window.drawMiniSpec=drawMiniSpec;
window.fBin=fBin; window.fRecord=fRecord; window.fPurge=fPurge;
window._lastFreqFileWrite=_lastFreqFileWrite; window.writeFreqFile=writeFreqFile;
window.INV=INV; window.buildInverse=buildInverse; window.stopActiveInverse=stopActiveInverse;
window.verifyInv=verifyInv; window.antiSearch=antiSearch; window.doAntiPattern=doAntiPattern;
window.MIC=MIC; window.profileMic=profileMic; window.extractFeat=extractFeat;
window.addMsg=addMsg; window.setS=setS;
window._toggleBusy=_toggleBusy; window.toggleAI=toggleAI;
window.updateHomeLiveStatus=updateHomeLiveStatus; window.mkRip=mkRip; window.animLF=animLF;
window.openSheet=openSheet; window.closeSheet=closeSheet; window.togglePipe=togglePipe; window.openPipe=openPipe;

})();

/* ── 04-panels-ui-system.js ── */

'use strict';
(function(){

function closePipe(){appState.pOpen=false;if(!appState.sOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');E('ppnl').classList.remove('open');}
function openAIP(){appState.aOpen=true;E('ovl').classList.add('on');E('aiPanel').classList.add('open');zVibrate(6);}
function closeAIP(){appState.aOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');E('aiPanel').classList.remove('open');}
/* ── القائمة الرئيسية (Menu) — تجمع كل أقسام التطبيق، تُفتح من زر الهامبرغر ── */
function toggleMenu(){appState.menuOpen?closeMenu():openMenu();}
function openMenu(){appState.menuOpen=true;E('ovl').classList.add('on');E('menuPanel').classList.add('open');E('mBtn').classList.add('open');zVibrate(6);}
function closeMenu(){appState.menuOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');E('menuPanel').classList.remove('open');E('mBtn').classList.remove('open');}
/* ── نافذة "الملفات" — تصدير/استيراد قائمة الترددات المحظورة ── */
function openFilesPanel(){
 appState.filesOpen=true;E('ovl').classList.add('on');E('filesPanel').classList.add('open');zVibrate(6);
 updateFolderAccessUI();
 const sr=E('share-row');if(sr)sr.style.display=(typeof navigator.share==='function')?'':'none';
 const cr=E('clip-row');if(cr)cr.style.display=(navigator.clipboard&&typeof navigator.clipboard.writeText==='function')?'':'none';
 const cir=E('clip-import-row');if(cir)cir.style.display=(navigator.clipboard&&typeof navigator.clipboard.readText==='function')?'':'none';
}
function closeFilesPanel(){appState.filesOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');E('filesPanel').classList.remove('open');}
function closeAll(){closeSheet();closePipe();closeAIP();closeZPPanel();closeDevMon();closeMenu();closeFilesPanel();if(typeof closeTerm!=='undefined')closeTerm();if(typeof closeMaskPanel!=='undefined')closeMaskPanel();if(typeof closePhysPanel!=='undefined')closePhysPanel();if(typeof closeAboutPanel!=='undefined')closeAboutPanel();if(typeof closePrivacyPanel!=='undefined')closePrivacyPanel();if(typeof closeLoopDiagPanel!=='undefined')closeLoopDiagPanel();if(typeof closeAVPanel!=='undefined')closeAVPanel();}

/* ── مضاد الفيروسات (29 سبتمبر 2026) — فتح/إغلاق اللوحة، نفس نمط بقية اللوحات تماماً؛
 المنطق الفعلي (الحظر الحراري/التخمّل + فحص السلامة) موجود مسبقاً في 02-classification-
 thermal-nn.js/08a-persist-bans-store.js — هذه اللوحة عرض وتحكّم يدوي فقط، لا كشف جديد. ── */
function openAVPanel(){appState.avOpen=true;E('ovl').classList.add('on');E('avPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);if(typeof updateAVPanel==='function')updateAVPanel();}
function closeAVPanel(){appState.avOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen)E('ovl').classList.remove('on');const p=E('avPanel');if(p)p.classList.remove('open');}

/* ── غرفة الصمت (Masking Noise) — فتح/إغلاق اللوحة، النمط نفسه المتَّبع لبقية اللوحات ── */
function openMaskPanel(){appState.maskOpen=true;E('ovl').classList.add('on');E('maskPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closeMaskPanel(){appState.maskOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');const p=E('maskPanel');if(p)p.classList.remove('open');}

/* ── فيزياء الإلغاء (Cancellation Physics) — فتح/إغلاق اللوحة، نفس نمط بقية اللوحات ── */
function openPhysPanel(){appState.physOpen=true;E('ovl').classList.add('on');E('physPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);if(typeof physDrawLoop==='function')physDrawLoop();if(typeof physSimDraw==='function')physSimDraw();}
function closePhysPanel(){appState.physOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');const p=E('physPanel');if(p)p.classList.remove('open');if(physAnimFrame){cancelAnimationFrame(physAnimFrame);physAnimFrame=null;}}

/* ── الحلقة المغلقة (Closed-Loop diagram) — فتح/إغلاق + حلقة تنبيه المراحل ── */
// حُوِّل loopDiagTimer/loopDiagPhase (كانا let منفصلين على مستوى القسم) + animateLoopDiagram
// إلى صنف واحد LoopDiagramAnimator: زوج «حالة (مؤقّت + طور) + سلوك (tick/start/stop)» حقيقي
// بالكامل داخلي لهذا القسم (صفر مرجع خارجي لكلا الاسمين قبل التحويل)، فطُويا كحقلَي صنف
// خاصَّين بلا حاجة لأي عرض window مستقل — تماماً كنمط _lastFrameCheck داخل ENV_FP في قسم 02.
class LoopDiagramAnimator{
 constructor(){this.timer=null;this.phase=0;}
 start(){this.phase=0;this.tick();}
 stop(){if(this.timer){clearTimeout(this.timer);this.timer=null;}}
 tick(){
 if(!appState.loopDiagOpen)return;
 const steps=['lfStepMic','lfStepAI','lfStepProc','lfStepSpk','lfStepMeas','lfStepZero'];
 const arrows=['lfArr1','lfArr2','lfArr3','lfArr4','lfArr5'];
 steps.forEach(s=>{const el=E(s);if(el)el.classList.remove('active-step','processing','zero-step');});
 arrows.forEach(a=>{const el=E(a);if(el)el.classList.remove('active');});
 const ms=E('lfMeasSub');if(ms)ms.textContent=appState.isRun?('Coherence γ²(f) — '+(typeof appState.silSc!=='undefined'?appState.silSc:0)+'%'):'Coherence γ²(f)';
 if(!appState.isRun){this.timer=setTimeout(()=>this.tick(),600);return;}
 const idx=this.phase%steps.length;
 const el=E(steps[idx]);
 if(el)el.classList.add(idx===2?'processing':idx===steps.length-1?'zero-step':'active-step');
 if(idx<arrows.length){const ae=E(arrows[idx]);if(ae)ae.classList.add('active');}
 this.phase++;
 this.timer=setTimeout(()=>this.tick(),600);
 }
}
const LOOP_DIAG_ANIM=new LoopDiagramAnimator();
function openLoopDiagPanel(){appState.loopDiagOpen=true;E('ovl').classList.add('on');E('loopDiagPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);LOOP_DIAG_ANIM.start();}
function closeLoopDiagPanel(){appState.loopDiagOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.avOpen)E('ovl').classList.remove('on');const p=E('loopDiagPanel');if(p)p.classList.remove('open');LOOP_DIAG_ANIM.stop();}
function animateLoopDiagram(){return LOOP_DIAG_ANIM.tick();}

/* ── حول التطبيق / الخصوصية — فتح/إغلاق، نفس نمط بقية اللوحات ── */
function openAboutPanel(){appState.aboutOpen=true;E('ovl').classList.add('on');E('aboutPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closeAboutPanel(){appState.aboutOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');const p=E('aboutPanel');if(p)p.classList.remove('open');}
function openPrivacyPanel(){appState.privacyOpen=true;E('ovl').classList.add('on');E('privacyPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closePrivacyPanel(){appState.privacyOpen=false;if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');const p=E('privacyPanel');if(p)p.classList.remove('open');}

/* ── PERMS MGMT PANEL ── */
const PERMS_MGMT=[
 {id:'RECORD_AUDIO',ico:'',name:'الميكروفون',desc:'تسجيل الصوت لتحليل الضوضاء',err:' هذا الإذن ضروري — لن يعمل تحليل الصوت بدونه'},
 {id:'POST_NOTIFICATIONS',ico:'',name:'الإشعارات',desc:'تنبيهات العمليات في الخلفية',err:'ℹ لن تظهر إشعارات الخلفية — يمكن تفعيله لاحقاً من إعدادات الجهاز'},
 {id:'MANAGE_STORAGE',ico:'',name:'إدارة الملفات',desc:'حفظ بيانات التطبيق والسجلات',err:' ضروري لحفظ البيانات — اضغط مرة أخرى لفتح إعدادات الجهاز'},
 {id:'MEDIA_AUDIO',ico:'',name:'ملفات الصوت',desc:'الوصول لملفات الصوت في الجهاز',err:' ضروري للوصول لملفات الصوت — اضغط للمحاولة مجدداً'}
];
function openZPPanel(){
 appState.zpOpen=true;
 E('ovl').classList.add('on');
 E('zpPanel').classList.add('open');
 zVibrate(6);
 zpRefreshAll();
 window.onPermResult=zpOnPermResult;
 window.onPermPermanentDenied=zpOnPermPermanentDenied;
}
function closeZPPanel(){
 if(!appState.zpOpen)return;
 appState.zpOpen=false;
 if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.dmOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');
 E('zpPanel').classList.remove('open');
 window.onPermResult=null;
 window.onPermPermanentDenied=null;
}

/* ══════════════════════════════════════════════
 DEVICE MONITOR — open / close / refresh
══════════════════════════════════════════════ */
function openDevMon(){
 appState.dmOpen=true;
 E('ovl').classList.add('on');
 E('devPanel').classList.add('open');
 zVibrate(6);
 // مراجعة تتمة إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم": dmRefresh()
 // تُجري عدّة نداءات bridge متزامنة دفعة واحدة (getRamInfo/getBatteryInfo/getCpuInfo/
 // getStorageInfo/getNetworkType/getAppMemory) من بينها getThermalZones() التي تقرأ فعلياً
 // ملفات /sys/class/thermal من القرص (حتى عشرات المناطق الحرارية على بعض الأجهزة، ملفَّين
 // لكل منطقة) — واستدعاء JS إلى دالة @JavascriptInterface يُوقِف تنفيذ JS بانتظار عودة
 // Java، تماماً كأي نداء متزامن. كان هذا النداء الثقيل يُنفَّذ في نفس دورة JS المتزامنة التي
 // أضافت صنف 'open' للتوّ أعلاه — فيمنع المتصفح من رسم أول إطار لانتقال انزلاق اللوحة
 // (CSS transform .38s) إلى أن تنتهي كل تلك القراءات، ما يبدو بالضبط كـ"تجمّد مؤقت" عند
 // فتح هذه اللوحة تحديداً. الإصلاح: تأجيل النداء الثقيل الأول بإطار واحد فقط (rAF) — يترك
 // للمتصفح فرصة لبدء رسم الانتقال أولاً؛ فارق التأخير (~16ms) غير مُدرَك إطلاقاً في ظهور
 // الإحصائيات نفسها.
 requestAnimationFrame(dmRefresh);
 if(!appState.dmTimer)appState.dmTimer=setInterval(dmRefresh,3000);
}
function closeDevMon(){
 if(!appState.dmOpen)return;
 appState.dmOpen=false;
 if(!appState.sOpen&&!appState.pOpen&&!appState.aOpen&&!appState.zpOpen&&!appState.menuOpen&&!appState.filesOpen&&!appState.tOpen&&!appState.maskOpen&&!appState.physOpen&&!appState.aboutOpen&&!appState.privacyOpen&&!appState.loopDiagOpen&&!appState.avOpen)E('ovl').classList.remove('on');
 E('devPanel').classList.remove('open');
 if(appState.dmTimer){clearInterval(appState.dmTimer);appState.dmTimer=null;}
 removeThermalAlert();
}
/* ── Sparkline renderer ── */
function renderSpark(svgId,data,maxVal,defaultColor,warnThresh,hotThresh){
 const svg=E(svgId);
 if(!svg||data.length<2)return;
 const W=100,H=30;
 const lo=Math.max(0,Math.min(...data)-5);
 const hi=Math.max(maxVal,Math.max(...data)+5);
 const pts=data.length;
 const step=W/(pts-1);
 const scaleY=v=>H-((v-lo)/(hi-lo))*H*0.88-H*0.06;
 const coords=data.map((v,i)=>(i*step).toFixed(1)+','+scaleY(v).toFixed(1));
 const last=data[data.length-1];
 const lx=((pts-1)*step).toFixed(1);
 const ly=scaleY(last).toFixed(1);
 const c=last>=hotThresh?'#808080':last>=warnThresh?'#b0b0b0':defaultColor;
 svg.innerHTML=`<polyline points="${coords.join(' ')}" fill="none" stroke="${c}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round" opacity=".9"/><circle cx="${lx}" cy="${ly}" r="2.5" fill="${c}"/><text x="${lx}" y="${parseFloat(ly)-5}" text-anchor="middle" font-size="6" fill="${c}" font-family="monospace">${last%1===0?last:last.toFixed(1)}</text>`;
}
/* ── Thermal alert ── */
function showThermalAlert(msg){
 let el=E('dm-thermal-alert');
 if(!el){
 el=document.createElement('div');
 el.id='dm-thermal-alert';
 el.className='dm-alert';
 E('app').appendChild(el);
 }
 el.innerHTML='<span class="dm-alert-ico"></span><span class="dm-alert-txt">'+msg+'</span><span class="dm-alert-cl" onclick="removeThermalAlert()">✕</span>';
 el.hidden=false;
 setThermalThrottle(true);
}
function removeThermalAlert(){
 const el=E('dm-thermal-alert');
 if(el)el.hidden=true;
 setThermalThrottle(false);
}
/* ── Memory pressure callbacks from Android ── */
window.onLowMemory=function(severity){
 if(typeof stLog==='function')stLog(' ذاكرة حرجة ('+severity+') — تم تحرير الكاش');
 if(severity==='critical')setThermalThrottle(true);
 if(appState.dmOpen)dmRefresh();
};
window.onTrimMemory=function(level,code){
 if(level==='critical'||level==='moderate'){
 if(typeof stLog==='function')stLog(' ضغط ذاكرة ('+level+' / '+code+')');
 if(level==='critical')setThermalThrottle(true);
 else if(level==='low')setThermalThrottle(false);
 }
 if(appState.dmOpen)dmRefresh();
};
function dmScroll(dir){
 const s=E('devPanel').querySelector('.dm-scr');
 if(s)s.scrollBy({top:dir*160,behavior:'smooth'});
}
function dmRefresh(){
 const za=window.ZeroAndroid;
 const now=new Date();
 const ts=now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0')+':'+now.getSeconds().toString().padStart(2,'0');
 E('dm-ts')&&(E('dm-ts').textContent='آخر تحديث: '+ts);

 // ── helpers ──
 function tempBadge(el,c){
 if(!el)return;
 if(c>=55){el.textContent=c.toFixed(1)+'°C ';el.className='dm-badge hot';}
 else if(c>=40){el.textContent=c.toFixed(1)+'°C';el.className='dm-badge warm';}
 else{el.textContent=c.toFixed(1)+'°C';el.className='dm-badge cool';}
 }
 function tempClass(c){return c>=55?'hot':c>=40?'warm':'cool';}
 function fmtMB(mb){return mb>=1024?(mb/1024).toFixed(1)+' GB':mb+' MB';}

 // ── RAM ──
 if(za&&za.getRamInfo){
 try{
 const r=JSON.parse(za.getRamInfo());
 if(r.totalMB){
 E('dm-ram-used')&&(E('dm-ram-used').textContent=fmtMB(r.usedMB)+' ('+r.usedPct+'%)');
 E('dm-ram-avail')&&(E('dm-ram-avail').textContent=fmtMB(r.availMB));
 E('dm-ram-total')&&(E('dm-ram-total').textContent=fmtMB(r.totalMB));
 const bEl=E('dm-ram-bar');if(bEl)bEl.style.width=Math.min(r.usedPct,100)+'%';
 const bg=E('dm-ram-badge');
 if(bg){if(r.usedPct>=80){bg.textContent=r.usedPct+'% عالٍ';bg.className='dm-badge hot';}
 else if(r.usedPct>=60){bg.textContent=r.usedPct+'%';bg.className='dm-badge warm';}
 else{bg.textContent=r.usedPct+'%';bg.className='dm-badge cool';}}
 // Device mem for info section
 E('dm-dev-mem')&&(E('dm-dev-mem').textContent=fmtMB(r.totalMB));
 }
 }catch(e){}
 }

 // ── Battery ──
 if(za&&za.getBatteryInfo){
 try{
 const b=JSON.parse(za.getBatteryInfo());
 if(b.tempC!==undefined){
 E('dm-bat-temp')&&(E('dm-bat-temp').textContent=b.tempC.toFixed(1)+'°C / '+(b.tempC*9/5+32).toFixed(1)+'°F');
 E('dm-bat-level')&&(E('dm-bat-level').textContent=b.levelPct+'%');
 const bb=E('dm-bat-bar');if(bb)bb.style.width=Math.min(b.levelPct,100)+'%';
 E('dm-bat-volt')&&(E('dm-bat-volt').textContent=(b.voltageMV/1000).toFixed(2)+' V');
 E('dm-bat-status')&&(E('dm-bat-status').textContent=b.isCharging?'يشحن الآن':'على البطارية');
 E('dm-bat-health')&&(E('dm-bat-health').textContent=b.health||'—');
 const bb2=E('dm-bat-badge');
 if(bb2)tempBadge(bb2,b.tempC);
 }
 }catch(e){}
 }

 // ── CPU ──
 if(za&&za.getCpuInfo){
 try{
 const c=JSON.parse(za.getCpuInfo());
 E('dm-cpu-cores')&&(E('dm-cpu-cores').textContent=(c.cores||navigator.hardwareConcurrency||'—')+' نواة');
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=(c.cores||navigator.hardwareConcurrency||'—')+' أنوية');
 if(c.curMHz){
 const ghz=c.curMHz>=1000?(c.curMHz/1000).toFixed(2)+' GHz':c.curMHz+' MHz';
 const mxghz=c.maxMHz>=1000?(c.maxMHz/1000).toFixed(2)+' GHz':c.maxMHz+' MHz';
 E('dm-cpu-freq')&&(E('dm-cpu-freq').textContent=ghz+' / '+mxghz);
 const cb=E('dm-cpu-bar');if(cb)cb.style.width=Math.min(c.freqPct,100)+'%';
 const cbg=E('dm-cpu-badge');
 if(cbg){cbg.textContent=c.freqPct+'%';cbg.className='dm-badge '+(c.freqPct>=80?'hot':c.freqPct>=50?'warm':'cool');}
 }
 }catch(e){}
 } else {
 // Fallback: JS navigator
 const cores=navigator.hardwareConcurrency||'—';
 E('dm-cpu-cores')&&(E('dm-cpu-cores').textContent=cores+' نواة');
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=cores+' أنوية');
 }

 // ── Thermal Zones ──
 if(za&&za.getThermalZones){
 try{
 const zones=JSON.parse(za.getThermalZones());
 const grid=E('dm-thermal-grid');
 if(grid&&zones.length){
 // Sort hottest first, show top 12 max
 zones.sort((a,b)=>b.tempC-a.tempC);
 const top=zones.slice(0,12);
 grid.innerHTML=top.map(z=>{const cls=tempClass(z.tempC);const pct=Math.min(Math.max((z.tempC-20)/80*100,0),100).toFixed(0);const f=(z.tempC*9/5+32).toFixed(1);return`<div class="dm-th-row"><div class="dm-th-name">${z.name}</div><div class="dm-th-fill-row"><div class="dm-th-fill-w"><div class="dm-th-fill ${cls}" style="width:${pct}%"></div></div><div class="dm-th-val ${cls}">${z.tempC.toFixed(1)}°C / ${f}°F</div></div></div>`;}).join('');
 // CPU temp from hottest relevant zone (cpu, big, cluster, etc.)
 const cpuZ=zones.find(z=>/cpu|big|little|cluster|core|tsens/i.test(z.name));
 if(cpuZ){
 E('dm-cpu-temp')&&(E('dm-cpu-temp').textContent=cpuZ.tempC.toFixed(1)+'°C / '+(cpuZ.tempC*9/5+32).toFixed(1)+'°F');
 const cbg=E('dm-cpu-badge');
 if(cbg)tempBadge(cbg,cpuZ.tempC);
 }
 } else if(grid){
 grid.innerHTML='<div class="dm-th-row"><div class="dm-th-name">لا توجد مناطق حرارية</div><div class="dm-th-fill-row"><div class="dm-th-fill-w"><div class="dm-th-fill cool" style="width:0%"></div></div><div class="dm-th-val cool">—</div></div></div>';
 }
 }catch(e){}
 }

 // ── JS Heap (built-in browser API) ──
 if(performance&&performance.memory){
 const pm=performance.memory;
 const used=Math.round(pm.usedJSHeapSize/1048576);
 const limit=Math.round(pm.jsHeapSizeLimit/1048576);
 const pct=Math.round(used*100/limit);
 E('dm-js-used')&&(E('dm-js-used').textContent=used+' MB ('+pct+'%)');
 E('dm-js-limit')&&(E('dm-js-limit').textContent=limit+' MB');
 const jb=E('dm-js-bar');if(jb)jb.style.width=Math.min(pct,100)+'%';
 const jbg=E('dm-js-badge');
 if(jbg){jbg.textContent=pct+'%';jbg.className='dm-badge '+(pct>=75?'hot':pct>=50?'warm':'cool');}
 }

 // ── Storage Info ──
 if(za&&za.getStorageInfo){
 try{
 const s=JSON.parse(za.getStorageInfo());
 if(s.intTotalMB){
 E('dm-int-used')&&(E('dm-int-used').textContent=fmtMB(s.intUsedMB)+' / '+fmtMB(s.intTotalMB)+' ('+s.intUsedPct+'%)');
 E('dm-int-free')&&(E('dm-int-free').textContent=fmtMB(s.intFreeMB));
 const ib=E('dm-int-bar');if(ib)ib.style.width=Math.min(s.intUsedPct,100)+'%';
 const sb=E('dm-stor-badge');
 if(sb){sb.textContent=s.intUsedPct+'%';sb.className='dm-badge '+(s.intUsedPct>=85?'hot':s.intUsedPct>=65?'warm':'cool');}
 if(s.extAvail){
 const extRow=E('dm-ext-row');if(extRow)extRow.style.display='flex';
 E('dm-ext-free')&&(E('dm-ext-free').textContent=fmtMB(s.extFreeMB));
 }
 }
 }catch(e){}
 }

 // ── Network ──
 if(za&&za.getNetworkType){
 try{
 const n=JSON.parse(za.getNetworkType());
 const wrap=E('dm-net-chip-wrap');
 if(wrap)wrap.innerHTML='<div class="dm-net-chip '+(n.connected?'online':'offline')+'"><div class="dm-net-dot"></div>'+(n.connected?'متصل':'غير متصل')+'</div>';
 const typeMap={WIFI:'Wi-Fi ',CELLULAR:'شبكة خلوية ',ETHERNET:'إيثرنت ',NONE:'غير متصل',UNKNOWN:'غير معروف'};
 E('dm-net-type')&&(E('dm-net-type').textContent=typeMap[n.type]||n.type||'—');
 const subMap={LTE:'4G LTE','5G NR':'5G',EDGE:'2G EDGE',HSPA:'3G HSPA',HSDPA:'3G HSDPA',HSPAP:'3G H+',UMTS:'3G UMTS'};
 E('dm-net-sub')&&(E('dm-net-sub').textContent=n.subtype?(subMap[n.subtype]||n.subtype):'—');
 }catch(e){}
 } else {
 const wrap=E('dm-net-chip-wrap');
 if(wrap)wrap.innerHTML='<div class="dm-net-chip '+(navigator.onLine?'online':'offline')+'"><div class="dm-net-dot"></div>'+(navigator.onLine?'متصل':'غير متصل')+'</div>';
 }

 // ── App Memory (Android PSS) ──
 if(za&&za.getAppMemory){
 try{
 const am=JSON.parse(za.getAppMemory());
 if(am.heapUsedMB!==undefined){
 const hPct=am.heapMaxMB?Math.round(am.heapUsedMB*100/am.heapMaxMB):0;
 E('dm-app-heap')&&(E('dm-app-heap').textContent=fmtMB(am.heapUsedMB)+' / '+fmtMB(am.heapMaxMB)+' ('+hPct+'%)');
 E('dm-app-nat')&&(E('dm-app-nat').textContent=fmtMB(am.nativeMB));
 E('dm-app-pss')&&(E('dm-app-pss').textContent=fmtMB(am.totalPssMB));
 const ab=E('dm-app-badge');
 if(ab){ab.textContent=fmtMB(am.totalPssMB);ab.className='dm-badge '+(hPct>=80?'hot':hPct>=55?'warm':'cool');}
 }
 }catch(e){}
 }

 // ── Sparklines history push ──
 (function(){
 const cpuEl=E('dm-cpu-temp');
 if(cpuEl&&cpuEl.textContent&&cpuEl.textContent!=='—'){
 const v=parseFloat(cpuEl.textContent);
 if(!isNaN(v)){appState.dmCpuHist.push(v);if(appState.dmCpuHist.length>12)appState.dmCpuHist.shift();}
 }
 const ramBdg=E('dm-ram-badge');
 if(ramBdg){
 const v=parseInt(ramBdg.textContent);
 if(!isNaN(v)){appState.dmRamHist.push(v);if(appState.dmRamHist.length>12)appState.dmRamHist.shift();}
 }
 renderSpark('dm-spark-cpu',appState.dmCpuHist,80,'#808080',40,55);
 renderSpark('dm-spark-ram',appState.dmRamHist,100,'#7b7b7b',60,80);
 })();

 // ── Auto Thermal Alert ──
 (function(){
 let maxT=0;
 // مراجعة "المشروع بالكامل": الصف الفعلي لكل منطقة حرارية (renderThermalGrid) يُنشئ
 // العنصر بصنف .dm-th-val — أما .dm-th-temp فلا وجود له إطلاقاً في أي مكان آخر بالملف
 // (لا CSS ولا HTML)؛ فكان هذا الفحص التلقائي يفوّت كل قراءات وحدة المعالجة المركزية/
 // الرسوميات/بقية المناطق الحرارية المعروضة في نفس اللوحة تماماً، ويعتمد فقط على حرارة
 // البطارية أدناه — فقد يسخن المعالج بشدة دون أن يظهر أي تحذير إطلاقاً.
 document.querySelectorAll('.dm-th-val').forEach(el=>{const v=parseFloat(el.textContent);if(!isNaN(v)&&v>maxT)maxT=v;});
 const batT=E('dm-bat-temp');if(batT){const v=parseFloat(batT.textContent);if(!isNaN(v)&&v>maxT)maxT=v;}
 if(maxT>=55)showThermalAlert(' تحذير — الحرارة وصلت '+maxT.toFixed(1)+'°C — أغلق التطبيق مؤقتاً للتبريد');
 else removeThermalAlert();
 })();

 // ── Device Info (static, set once) ──
 if(!E('dm-dev-model').dataset.set){
 E('dm-dev-model').dataset.set='1';
 E('dm-dev-model')&&(E('dm-dev-model').textContent=za?za.getDeviceModel():'—');
 E('dm-dev-api')&&(E('dm-dev-api').textContent=za?'API '+za.getAndroidVersion():'—');
 if(!E('dm-dev-cores').textContent||E('dm-dev-cores').textContent==='—')
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=(navigator.hardwareConcurrency||'—')+' أنوية');
 const dm=navigator.deviceMemory;
 if(dm&&!E('dm-dev-mem').textContent.includes('GB')&&!E('dm-dev-mem').textContent.includes('MB'))
 E('dm-dev-mem')&&(E('dm-dev-mem').textContent=dm+' GB (تقريبي)');
 }
}
// مراجعة "المشروع بالكامل": زر طلب الإذن هو الحالة الوحيدة في كل الملف التي تُعطِّل نفسها
// (disabled=true) بانتظار رد خارجي (من كود Android الأصلي عبر zpOnPermResult) دون أي مهلة —
// بالضبط النمط الموصوف كـ"Button State Stuck + State Transition Stuck": OFF→CLICKED→
// " جارٍ الطلب..."→تبقى كذلك للأبد لو لم يصل الرد إطلاقاً (مثلاً: أُعيد إنشاء الـActivity
// أثناء ظهور مربع حوار الإذن — دوران الشاشة، قتل العملية بضغط الذاكرة — فيضيع استدعاء
// onRequestPermissionsResult الأصلي ولا يُستدعى zpOnPermResult أبداً). الإصلاح: حارس زمني
// (12 ثانية، أطول بكثير من وقت رد مستخدم طبيعي) يعيد الزر لحالة "أعد المحاولة" تلقائياً إن لم
// يصل أي رد — يُلغى الحارس فوراً إن وصل رد حقيقي (ناجحاً أو مرفوضاً) قبل انتهاء المهلة.
// حُوِّل _zpPendingT (كائن خرائط id←مؤقّت) + دوال إدارة طلب الإذن الخمس المرتبطة به جميعاً
// إلى صنف واحد PermRequestManager — زوج «حالة + سلوك» حقيقي بالكامل داخلي لهذا القسم
// (صفر مرجع خارجي لـ_zpPendingT نفسها قبل التحويل). النداءات الداخلية المتبادلة (كانت
// _zpClearPending(id) من داخل باقي الدوال) حُوِّلت إلى this.clearPending(id) بنفس مبدأ
// InverseGenerator/MicProfile في قسم 03. PERMS_MGMT تبقى بيانات/إعداد محضة تُقرَأ مباشرة
// من طريقة الصنف دون حاجة لتحويلها هي الأخرى (لا سلوك خاص بها، تماماً كـPERMS/RANGE سابقاً).
class PermRequestManager{
 constructor(){this.pending={};}
 clearPending(id){if(this.pending[id]){clearTimeout(this.pending[id]);delete this.pending[id];}}
 onResult(id,granted){
 this.clearPending(id);
 const btn=E('zpb-'+id);
 const err=E('zpe-'+id);
 if(granted){
 if(btn){btn.textContent='✓ تم الحصول على الإذن';btn.className='zp-mb ok';btn.disabled=true;}
 if(err)err.hidden=true;
 }else{
 if(btn){btn.textContent='اضغط للمحاولة مجدداً ←';btn.className='zp-mb retry';btn.disabled=false;}
 if(err)err.hidden=false;
 }
 }
 request(id){
 const btn=E('zpb-'+id);
 if(btn){btn.textContent='جارٍ الطلب...';btn.disabled=true;}
 this.clearPending(id);
 if(typeof ZeroAndroid!=='undefined'){
 try{
 ZeroAndroid.requestPermission(id);
 this.pending[id]=setTimeout(()=>{
 delete this.pending[id];
 const b2=E('zpb-'+id);
 if(b2&&b2.disabled&&b2.textContent==='جارٍ الطلب...'){
 b2.textContent='لم يصل رد — اضغط للمحاولة مجدداً ←';b2.className='zp-mb retry';b2.disabled=false;
 }
 },12000);
 }
 catch(e){if(btn){btn.textContent='خطأ - حاول مجدداً';btn.className='zp-mb retry';btn.disabled=false;}}
 } else {
 setTimeout(()=>{if(btn){btn.textContent='اضغط للحصول على الإذن ←';btn.className='zp-mb req';btn.disabled=false;}},400);
 }
 }
 onPermanentDenied(id){
 this.clearPending(id);
 const btn=E('zpb-'+id);
 const err=E('zpe-'+id);
 if(btn){
 btn.textContent='افتح إعدادات التطبيق ←';
 btn.className='zp-mb retry';
 btn.disabled=false;
 btn.onclick=function(){if(typeof ZeroAndroid!=='undefined')ZeroAndroid.openAppSettings();};
 }
 if(err){
 err.textContent='تم رفض الإذن نهائياً — اضغط لفتح الإعدادات ومنحه يدوياً';
 err.hidden=false;
 }
 }
 refreshAll(){
 PERMS_MGMT.forEach(p=>{
 const granted=typeof ZeroAndroid!=='undefined'&&!!ZeroAndroid.isPermissionGranted(p.id);
 const btn=E('zpb-'+p.id);
 const err=E('zpe-'+p.id);
 if(granted){
 if(btn){btn.textContent='✓ تم الحصول على الإذن';btn.className='zp-mb ok';btn.disabled=true;}
 if(err)err.hidden=true;
 }else{
 if(btn){btn.textContent='اضغط للحصول على الإذن ←';btn.className='zp-mb req';btn.disabled=false;}
 if(err)err.hidden=true;
 }
 });
 }
}
const ZP_MGR=new PermRequestManager();
function _zpClearPending(id){return ZP_MGR.clearPending(id);}
function zpOnPermResult(id,granted){return ZP_MGR.onResult(id,granted);}
function zpRequestPerm(id){return ZP_MGR.request(id);}
function zpOnPermPermanentDenied(id){return ZP_MGR.onPermanentDenied(id);}
function zpRefreshAll(){return ZP_MGR.refreshAll();}
function tSW(id){const sw=E(id);if(!sw)return;sw.checked=!sw.checked;applySW(id,sw.checked);}
function applySW(id,v){
 const m={
 // مراجعة "المشروع بالكامل": هذا المفتاح كان دالة فارغة (()=>null) — تبديل "Self-Learning"
 // في الإعدادات لم يكن له أي أثر إطلاقاً، رغم أن وصفه الظاهر "FreqDB + NN continuous
 // training" يوحي بأنه يوقف التدريب المستمر؛ startLearn() (نمط النسخ الاحتياطي والتعلّم
 // المُعاد) لم يكن يفحص أي علم من هذا النوع إطلاقاً. الإصلاح: علم P.useLearn حقيقي يُقرأ
 // الآن داخل startLearn() نفسها.
 'sw-cl':()=>P.useCL=v,'sw-evp':()=>P.useEVP=v,'sw-emf':()=>P.useEMF=v,'sw-inv':()=>P.useInv=v,'sw-learn':()=>P.useLearn=v,
 'sw-inf':()=>P.useSF.inf=v,'sw-ult':()=>P.useSF.ult=v,'sw-phf':()=>P.useSF.phf=v,'sw-sub':()=>P.useSF.sub=v,'sw-pie':()=>P.useSF.pie=v,
 'sw-c1':()=>P.useC.c1=v,'sw-c2':()=>P.useC.c2=v,'sw-c3':()=>P.useC.c3=v,'sw-c4':()=>P.useC.c4=v,
 'sw-c5':()=>P.useC.c5=v,'sw-c6':()=>P.useC.c6=v,'sw-c7':()=>P.useC.c7=v,'sw-c8':()=>P.useC.c8=v,
 'sw-ai':()=>{if(v!==appState.isOn)toggleAI({});}
 };
 if(m[id])m[id]();
 if(appState.isRun&&['sw-inf','sw-ult','sw-phf','sw-sub','sw-pie'].includes(id))updSF();
}
function syncAI(sw){if(sw.checked!==appState.isOn)toggleAI({});}
/* selSrc: removed — unused function */

/* Swipe */
// اكمال بناء "الأزرار": في ويب-فيو الأندرويد لا يُفعَّل الاختيار الزائف :active على اللمس إطلاقاً
// ما لم يوجد مستمع touchstart واحد على الأقل في سلسلة الأجداد وصولاً إلى document/body — والملف
// يحوي أكثر من 18 قاعدة :active (.btn:active، .home-run-btn:active، .tog-row:active... إلخ) لكن
// بلا أي مستمع touchstart عام، ما يعني أن كل أزرار التطبيق كانت تفتقد فعلياً لتغذية الضغط
// البصرية (opacity/scale) على جهاز حقيقي رغم وجود التنسيق الخاص بها. مستمع فارغ لا يفعل شيئاً
// سوى تفعيل :active عبر كامل الشجرة، بلا أي أثر جانبي آخر.
document.addEventListener('touchstart',function(){},{passive:true});
const bsEl=E('bSheet'),apEl=E('aiPanel'),zpEl=E('zpPanel');
const tmEl=E('termPanel'),mnEl=E('menuPanel'),flEl=E('filesPanel'),dmEl=E('devPanel');
/* تطوير حرية الحركة داخل النوافذ (bSheet/aiPanel/zpPanel): كانت مستمعات السحب الثلاثة
 مثبَّتة مباشرة على عنصر اللوحة (.pnl) بأكمله، لا على مقبض السحب (.phdl) وحده — وبما أن
 أحداث اللمس تصعد (bubble) من أي عنصر داخلي، فأي لمسة تبدأ داخل محتوى قابل للتمرير
 (.shsc في bSheet، .pane في aiPanel، .zp-scr في zpPanel) كانت تُفعِّل نفس حركة سحب
 اللوحة كاملة (translateY) بالتوازي مع التمرير الطبيعي للقائمة — فتتصارع الحركتان: أي
 محاولة سحب لأعلى أو لأسفل داخل قائمة تحوي عناصر كثيرة كانت تُحرِّك اللوحة كلها بدل أن
 تُمرِّر محتواها فقط، فيبدو التمرير "جامداً" أو متذبذباً بالضبط في اللوحات التي تحتاج
 حرية حركة أكبر (كثرة العناصر).
 الإصلاح: عند بدء اللمس، تُحدَّد أقرب حاوية تمرير فعلية للعنصر المُلامَس (إن وُجدت)؛
 وطالما تلك الحاوية ليست في أعلاها (scrollTop>0)، تُترَك حركة التمرير الطبيعية تعمل
 بحرية كاملة بلا أي تدخل من حركة اللوحة (لا يُطبَّق أي transform إطلاقاً في تلك الحالة).
 فقط حين يصل المحتوى لأعلاه فعلاً ويستمر السحب لأسفل — أو حين تبدأ اللمسة على المقبض
 نفسه أصلاً (لا حاوية تمرير حوله) — تُستأنف حركة "سحب لإغلاق" المعتادة، تماماً كسلوك
 الأوراق السفلية القياسي (bottom sheet) في أنظمة التشغيل. */
// اكمال بناء "الأزرار" (تتمة): مستمعات السحب أعلاه مثبَّتة على عنصر اللوحة (.pnl) كاملاً، فأي لمسة
// تبدأ على عنصر تحكم يقع خارج contentSel القابل للتمرير (أزرار تبويب aiPanel .tbtn التي هي شقيقة
// لـ.pane لا داخلها، أزرار termPanel .term-ph-r/.term-fil، وأزرار إغلاق الرأس .pcl/.ai-ph-c في كل
// اللوحات) لا تستفيد من بوابة scrollEl إطلاقاً (تُصبح null لهذه العناصر) — فأي ارتعاش طبيعي بسيط
// بالإصبع أثناء نقرة عادية على أحد هذه الأزرار كان يُفعِّل transform السحب فوراً (d>0)، ما يجعل
// الزر يبدو "مهتزاً"/متذبذباً تحت الإصبع بدل أن يبقى ثابتاً كنقرة عادية. الإصلاح: عتبة "touch slop"
// صغيرة (8px) بنفس قيمة ViewConfiguration.getScaledTouchSlop() القياسية في أندرويد — لا يُطبَّق أي
// تحريك للوحة إطلاقاً إلا بعد تجاوز الإصبع هذه المسافة الصغيرة، فالنقرات العادية (ارتعاش أقل من
// 8px) تبقى ثابتة تماماً بصرياً مهما كان العنصر الملموس داخل اللوحة أو خارج contentSel.
// تشديد إضافي: القفل الاتجاهي. البوابات أعلاه (scrollEl + عتبة SLOP) لا تحمي حركة أفقية صريحة —
// مثل تمرير شريط تبويبات aiPanel (.tab-bar، عنصر overflow-x:auto أفقي، يقع خارج contentSel أصلاً)
// بإصبع يتحرك يميناً/يساراً. لو رافق هذا التمرير الأفقي أي ميل رأسي طفيف (طبيعي جداً في حركة يد
// حقيقية)، وتجاوز ذلك الميل عتبة SLOP الرأسية، كانت اللوحة بأكملها تنزلق أيضاً رغم أن نية المستخدم
// الوحيدة كانت التمرير الأفقي بين التبويبات — تشديد أدق من عتبة SLOP وحدها. الإصلاح: تتبُّع
// الإزاحة الأفقية أيضاً منذ بدء اللمس، ورفض تطبيق transform اللوحة كلياً ما دامت الحركة الأفقية
// مساوية أو أكبر من الرأسية (أي أن اتجاه الإصبع الغالب أفقي لا رأسي) — فقط حين تتفوق الحركة
// الرأسية بوضوح على الأفقية يُعتبر السحب سحباً عمودياً حقيقياً لإغلاق اللوحة.
function _wireSheetDrag(panelEl,contentSel,closeFn){
 const SLOP=8;
 let sX=0,sY=0,sDr=false,scrollEl=null,dragged=false;
 panelEl.addEventListener('touchstart',ev=>{
 sX=ev.touches[0].clientX;sY=ev.touches[0].clientY;sDr=true;dragged=false;
 scrollEl=ev.target.closest(contentSel);
 // حذف الجمود أثناء السحب الفعلي: .pnl تحمل transition:transform .38s دائماً (لحركة
 // الفتح/الإغلاق العادية عبر الأزرار) — لكن هذا الانتقال نفسه كان لا يزال مُفعَّلاً أثناء
 // السحب باللمس أيضاً، فكل تحديث touchmove (عشرات المرات في الثانية) كان يُشغِّل نفس
 // انتقال الـ.38s من جديد في كل إطار، فتتراكم الانتقالات المتتالية ويتخلَّف موضع اللوحة
 // المرئي عن موضع الإصبع الفعلي بمسافة وزمن ملحوظين (أُثبِت هذا فعلياً: بعد 16ms من
 // تحريك 60px، اللوحة لم تكن قد تحرَّكت سوى ~28px) — هذا بالضبط ما يجعل السحب "يشعر"
 // بالجمود والتذبذب رغم أن الإحداثيات المحسوبة صحيحة تماماً. تعطيل الانتقال هنا يجعل
 // اللوحة تتبع الإصبع فوراً بلا أي تأخير، وإعادة تفعيله عند رفع الإصبع (touchend) تُبقي
 // حركة "العودة لمكانها" أو "الإغلاق" الأخيرة ناعمة كما كانت دائماً.
 panelEl.style.transition='none';
 },{passive:true});
 panelEl.addEventListener('touchmove',ev=>{
 if(!sDr)return;
 const d=ev.touches[0].clientY-sY;
 const dx=ev.touches[0].clientX-sX;
 if(scrollEl&&scrollEl.scrollTop>0)return; // المحتوى ليس في أعلاه — اترك تمريره حراً بلا تدخل
 if(Math.abs(dx)>=Math.abs(d))return; // قفل اتجاهي: الحركة أفقية غالبة أو متعادلة — ليست سحباً عمودياً
 if(d>SLOP){dragged=true;panelEl.style.transform=`translateX(-50%) translateY(${d-SLOP}px)`;}
 },{passive:true});
 panelEl.addEventListener('touchend',ev=>{
 if(!sDr)return;sDr=false;
 const d=ev.changedTouches[0].clientY-sY;
 panelEl.style.transition=''; // إعادة تفعيل انتقال .pnl قبل آخر حركة (عودة/إغلاق ناعمة)
 panelEl.style.transform='';
 if(dragged&&d>100)closeFn();
 scrollEl=null;dragged=false;
 },{passive:true});
}

/* ══ TABS ══ */



window.closePipe=closePipe; window.openAIP=openAIP; window.closeAIP=closeAIP;
window.toggleMenu=toggleMenu; window.openMenu=openMenu; window.closeMenu=closeMenu;
window.openFilesPanel=openFilesPanel; window.closeFilesPanel=closeFilesPanel; window.closeAll=closeAll;
window.openAVPanel=openAVPanel; window.closeAVPanel=closeAVPanel; window.openMaskPanel=openMaskPanel;
window.closeMaskPanel=closeMaskPanel; window.openPhysPanel=openPhysPanel; window.closePhysPanel=closePhysPanel;
window.LOOP_DIAG_ANIM=LOOP_DIAG_ANIM; window.openLoopDiagPanel=openLoopDiagPanel; window.closeLoopDiagPanel=closeLoopDiagPanel;
window.animateLoopDiagram=animateLoopDiagram; window.openAboutPanel=openAboutPanel; window.closeAboutPanel=closeAboutPanel;
window.openPrivacyPanel=openPrivacyPanel; window.closePrivacyPanel=closePrivacyPanel; window.PERMS_MGMT=PERMS_MGMT;
window.ZP_MGR=ZP_MGR; window.openZPPanel=openZPPanel; window.closeZPPanel=closeZPPanel;
window.openDevMon=openDevMon; window.closeDevMon=closeDevMon; window.renderSpark=renderSpark;
window.showThermalAlert=showThermalAlert; window.removeThermalAlert=removeThermalAlert; window.dmScroll=dmScroll;
window.dmRefresh=dmRefresh; window._zpClearPending=_zpClearPending; window.zpOnPermResult=zpOnPermResult;
window.zpRequestPerm=zpRequestPerm; window.zpOnPermPermanentDenied=zpOnPermPermanentDenied; window.zpRefreshAll=zpRefreshAll;
window.tSW=tSW; window.applySW=applySW; window.syncAI=syncAI;
window.bsEl=bsEl; window.apEl=apEl; window.zpEl=zpEl;
window.tmEl=tmEl; window.mnEl=mnEl; window.flEl=flEl;
window.dmEl=dmEl; window._wireSheetDrag=_wireSheetDrag;

})();
/* ── 05-presets-scenes-tracking.js ── */

'use strict';
(function(){

// curTab/thermalThrottleOn/curPreset تُعاد إسنادها داخلياً (openTab/setThermalThrottle/
// applyPreset) وتُقرَأ خارجياً كأسماء عامة حيّة من عدة أقسام لاحقة غير مُحوَّلة بعد
// (06/07b/10/11/13) — نفس نمط _toggleBusy في قسم 03 بالضبط: لا تصريح let محلي إطلاقاً، بل
// خاصية window مباشرة من الإعلان الأول، فيتحلّل أي استخدام عارٍ لاحق لهذا الاسم (قراءة أو
// كتابة، هنا أو في تلك الأقسام) عبر سلسلة النطاق إلى نفس الخاصية حيّةً في الحالتين تماماً،
// بلا أي احتمال انفصال بين نسخة محلية ونسخة window منفصلتين.
window.curTab=0;
let statsIv=null; // auto-refresh interval for STATS tab — صفر مرجع خارجي (مؤكَّد في app.js وملفات test_*.js الثلاثة)، آمن كـlet محلي عادي
// ── Power Presets & Thermal Throttle ──
window.thermalThrottleOn=false;
window.curPreset='balanced';
let lastFreqDBSave=null; // صفر مرجع خارجي، آمن كـlet محلي عادي
const SESSION_START=Date.now();
const PRESETS={
 low:{fftIdx:0,detMs:80,alpha:1.0,sf:false,label:'توفير',emoji:'',desc:' توفير — FFT 4096 · كشف 80ms · طبقات مخففة · α 1.0'},
 balanced:{fftIdx:1,detMs:40,alpha:1.5,sf:true,label:'متوازن',emoji:'',desc:' متوازن — FFT 8192 · كشف 40ms · جميع الطبقات مفعّلة · α 1.5'},
 full:{fftIdx:2,detMs:20,alpha:2.0,sf:true,label:'كامل',emoji:'',desc:' كامل — FFT 16384 · كشف 20ms · جميع الطبقات مفعّلة · α 2.0'}
};

function setThermalThrottle(on){
 thermalThrottleOn=on;
 const badge=E('therm-badge');
 if(badge)badge.style.display=on?'inline-flex':'none';
 if(on){
 // slow detection to 90ms during thermal stress
 if(typeof appState.aT!=='undefined'&&appState.aT){clearInterval(appState.aT);appState.aT=setInterval(detectAll,90);}
 // زيادة "النسخة النهائية": المذبذبات فوق الصوتية تُخزَّن في silOscs بمفاتيح مسطَّحة
 // ('u0','u1',...للمذبذب نفسه، 'ug0','ug1',...لعقدة GainNode المقابلة — راجع startSF/updSF)
 // — لا كخاصية silOscs.ultra إطلاقاً (غير موجودة قط)، فكان هذا الشرط دائماً false والتخفيف
 // الحراري المقصود (تصفير كسب الطبقة فوق الصوتية لخفض الحمل أثناء الإجهاد الحراري) لم يكن
 // يُنفَّذ إطلاقاً رغم أن سجل التنفيذ يوحي بأنه يعمل.
 if(typeof appState.silOscs!=='undefined'){
 try{Object.keys(appState.silOscs).forEach(k=>{if(k.indexOf('ug')===0&&appState.silOscs[k]&&appState.silOscs[k].gain)appState.silOscs[k].gain.value=0;});}catch(e){}
 }
 } else {
 // restore to current preset detection rate
 const ms=PRESETS[curPreset]?PRESETS[curPreset].detMs:40;
 if(typeof appState.aT!=='undefined'&&appState.aT){clearInterval(appState.aT);appState.aT=setInterval(detectAll,ms);}
 // استعادة كسب المذبذبات فوق الصوتية — نفس المفاتيح الحقيقية أعلاه
 if(typeof appState.silOscs!=='undefined'){
 try{Object.keys(appState.silOscs).forEach(k=>{if(k.indexOf('ug')===0&&appState.silOscs[k]&&appState.silOscs[k].gain)appState.silOscs[k].gain.value=0.001;});}catch(e){}
 }
 }
}

function applyPreset(name){
 const p=PRESETS[name];if(!p)return;
 curPreset=name;
 // FFT size
 if(typeof ANTI_IDLE!=='undefined'&&ANTI_IDLE.fftSizes){
 ANTI_IDLE.fftSizeIdx=p.fftIdx;
 // مراجعة "النسخة النهائية": المحلِّل الفعلي مُخزَّن في المتغيّر العام `ana` (يُنشَأ في
 // initAudio عبر actx.createAnalyser())، لا `analyser` — الذي لم يُعرَّف إطلاقاً في أي مكان
 // آخر من الملف، فكان `typeof analyser!=='undefined'` يفشل بصمت دائماً (بلا استثناء ظاهر)
 // وحجم FFT الفعلي لا يتغيّر أبداً عند تبديل الإعداد المسبق (Preset)، رغم أن الواجهة ومعدّل
 // الكشف وAlpha تتحدَّث بشكل صحيح — خلل حقيقي في ميزة رئيسية، لا مجرد أسلوب.
 try{if(typeof appState.ana!=='undefined'&&appState.ana)appState.ana.fftSize=ANTI_IDLE.fftSizes[p.fftIdx];}catch(e){}
 }
 // Detection rate (only if currently running)
 if(typeof appState.aT!=='undefined'&&appState.aT&&!thermalThrottleOn){
 clearInterval(appState.aT);appState.aT=setInterval(detectAll,p.detMs);
 }
 // Alpha
 if(typeof P!=='undefined')P.alpha=p.alpha;
 // SF layer — مراجعة "المشروع بالكامل": P.useSF كائن حالة لكل طبقة على حدة
 // ({inf,ult,phf,sub,pie}) تقرأه updSF() (P.useSF.inf/.ult/...) وتكتبه مفاتيح الإعدادات
 // اليدوية sw-inf/sw-ult/... — لكن هذا السطر كان يستبدل الكائن بأكمله بقيمة منطقية خام
 // (p.sf: true/false)، فتصبح P.useSF نفسها true أو false. النتيجة: كل قراءة P.useSF.inf
 // (وبقية الطبقات) تعمل على خاصية لعنصر بدائي فتُرجِع undefined دوماً (كقيمة مزيّفة) —
 // فتتوقف طبقة "الترددات الصامتة" (Silent Frequencies) بأكملها فور الضغط على أي إعداد قوة
 // مسبق (Preset)، بما فيها "كامل" التي يُفترض أن تُفعِّل كل الطبقات. والأسوأ: بما أن الملف
 // صارم (use strict)، أي تبديل يدوي لاحق لأحد المفاتيح (P.useSF.inf=v) يرمي استثناءً غير
 // معالَج بدل أن يفشل بصمت. الإصلاح: تحديث كل مفتاح فرعي داخل نفس الكائن، لا استبدال الكائن.
 if(typeof P!=='undefined'&&P.useSF){P.useSF.inf=p.sf;P.useSF.ult=p.sf;P.useSF.phf=p.sf;P.useSF.sub=p.sf;P.useSF.pie=p.sf;}
 // UI update
 ['lp','bl','fp'].forEach((id,idx)=>{
 const btn=E('preset-'+id);
 if(btn)btn.classList.toggle('act',['low','balanced','full'][idx]===name);
 });
 const desc=E('preset-desc');if(desc)desc.textContent=p.desc;
 if(typeof updateStatsTab==='function')updateStatsTab();
}

async function saveFreqDB(){
 try{
 if(typeof freqDB==='undefined'||!freqDB||!freqDB.size||!zeroDB)return;
 const tx=zeroDB.transaction('freq_patterns','readwrite');
 const st=tx.objectStore('freq_patterns');
 freqDB.forEach((v,k)=>{
 // freq_patterns keyPath='hz' — merge hz into value object
 st.put(Object.assign({},v,{hz:k}));
 });
 await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=()=>res();});
 lastFreqDBSave=new Date();
 }catch(e){console.warn('saveFreqDB:',e);}
}

async function loadFreqDB(){
 try{
 if(typeof freqDB==='undefined'||!zeroDB)return;
 const tx=zeroDB.transaction('freq_patterns','readonly');
 const st=tx.objectStore('freq_patterns');
 const req=st.getAll();
 await new Promise((res,rej)=>{req.onsuccess=res;req.onerror=()=>res();});
 const rows=req.result||[];
 rows.forEach(row=>{
 const k=row.hz;
 if(k!=null&&!freqDB.has(k))freqDB.set(k,row);
 });
 if(rows.length)console.log('[ZER0] loadFreqDB: restored',rows.length,'freq_patterns');
 }catch(e){console.warn('loadFreqDB:',e);}
}

/* ══ ENVIRONMENT CLASSIFIER ══ */
const ENV_LABELS={
 quiet:{label:' QUIET',color:'#a5a5a5',ar:'هادئ'},
 tonal:{label:' TONAL',color:'#959595',ar:'طولي'},
 noise:{label:' WHITE NOISE',color:'#818181',ar:'ضوضاء'},
 impulsive:{label:' IMPULSIVE',color:'#cecece',ar:'نبضي'},
 mechanical:{label:' MECHANICAL',color:'#9c9c9c',ar:'ميكانيكي'},
 interference:{label:' INTERFERENCE',color:'#787878',ar:'تداخل'},
 mixed:{label:' MIXED',color:'#aaaaaa',ar:'مختلط'}
};
window.curEnvClass='mixed'; // نفس معاملة curTab/curPreset أعلاه — مُعاد تعيينه داخل classifyEnvironment ويُقرأ خارجياً كاسم حيّ من 06/07b

function classifyEnvironment(){
 if(!appState.isRun&&!appState.ana)return;
 const sf=typeof SPEC_FLAT!=='undefined'?SPEC_FLAT.val:0;
 const hnr=typeof HNR!=='undefined'?HNR.val:0;
 const zcr=typeof ZCRATE!=='undefined'?ZCRATE.val:0;
 const crest=typeof CREST!=='undefined'?CREST.val:1;
 const sil=appState.silSc/100;
 const dbSz=typeof freqDB!=='undefined'?freqDB.size:0;
 let cls;
 if(sil>0.82)cls='quiet';
 else if(sf>0.68&&zcr>0.28)cls='noise';
 else if(hnr>14&&sf<0.22&&dbSz>0)cls='tonal';
 else if(crest>8&&zcr>0.38)cls='impulsive';
 else if(sf<0.18&&hnr>4&&dbSz>=3&&typeof HARMONICS!=='undefined'&&HARMONICS.series&&HARMONICS.series.length>1)cls='mechanical';
 else if(sf>0.38&&hnr<4)cls='interference';
 else cls='mixed';
 curEnvClass=cls;
 SESSION_STAT.envCount[cls]=(SESSION_STAT.envCount[cls]||0)+1;
 autoPresetCheck();
 const info=ENV_LABELS[cls];
 // Main panel label
 const el=E('envLabel');if(el)el.style.display='flex';
 const lt=E('envLblTxt');if(lt)lt.textContent=info.label;
 const dot=E('envDot');if(dot)dot.style.background=info.color;
 const cf=E('envConf');
 if(cf){
 let d='';
 if(cls==='quiet')d=`${appState.silSc}% silence`;
 else if(cls==='noise')d=`flat ${(sf*100).toFixed(0)}%`;
 else if(cls==='tonal')d=`HNR ${hnr.toFixed(0)}dB`;
 else if(cls==='impulsive')d=`crest ${crest.toFixed(1)}`;
 else if(cls==='mechanical')d=`${dbSz} freqs`;
 else if(cls==='interference')d=`flat ${(sf*100).toFixed(0)}%`;
 cf.textContent=d;
 }
 // Stats tab
 const sse=E('ss-env');if(sse)sse.textContent=info.label;
}

/* ══ FREQUENCY HOP DETECTOR ══ */
// زوج «حالة + سلوك» حقيقي: FREQ_HOP مملوك بالكامل من detectFreqHop (الكاتب الوحيد لكل حقولها) —
// قراءات الحقول الأخرى (computeSQI/checkAdaptiveAlert هنا، و06/07b خارجياً) تبقى تعمل بلا أي
// تغيير: الوصول لحقل .count/.lastHz عبر النقطة مطابق تماماً سواء كان الكائن حرفياً أو نسخة صنف.
class FreqHopDetector{
 constructor(){this.lastHz=0;this.threshold=12;this.hops=[];this.maxLog=30;this.lastHopT=0;this.count=0;}
 detect(hz){
 if(!hz||hz<1)return;
 if(this.lastHz>1){
 const delta=Math.abs(hz-this.lastHz);
 if(delta>this.threshold){
 const now=Date.now();
 if(now-this.lastHopT>500){
 this.count++;
 this.hops.push({from:this.lastHz,to:hz,delta,t:now});
 if(this.hops.length>this.maxLog)this.hops.shift();
 this.lastHopT=now;
 const fl=E('freqHopFlash');
 if(fl){fl.style.opacity='1';setTimeout(()=>{fl.style.opacity='0';},700);}
 const ct=E('freqHopCt');if(ct)ct.textContent=`${this.count} hop${this.count!==1?'s':''}`;
 logNN(` FREQ HOP: ${this.lastHz.toFixed(1)}→${hz.toFixed(1)}Hz (Δ${delta.toFixed(1)}Hz)`);
 }
 }
 }
 this.lastHz=hz;
 }
}
const FREQ_HOP=new FreqHopDetector();
function detectFreqHop(hz){return FREQ_HOP.detect(hz);}

/* ══ AUTO-PRESET BY ENVIRONMENT ══ */
const AUTOPRESET={enabled:false,cooldown:25000,lastSwitch:0,map:{quiet:'low',tonal:'full',mechanical:'full',noise:'balanced',impulsive:'balanced',interference:'balanced',mixed:'balanced'}};
function autoPresetCheck(){
 if(!AUTOPRESET.enabled||!appState.isRun)return;
 const now=Date.now();
 if(now-AUTOPRESET.lastSwitch<AUTOPRESET.cooldown)return;
 const target=AUTOPRESET.map[curEnvClass]||'balanced';
 if(target!==curPreset){
 applyPreset(target);
 AUTOPRESET.lastSwitch=now;
 logNN(` AUTOPRESET: ${curPreset}→${target} (env=${curEnvClass})`);
 }
}

/* ══ SUPPRESSION EFFECTIVENESS ══ */
class SuppressionEffMonitor{
 constructor(){this.val=0;this.sampN=0;}
 update(fdRaw){
 if(!NOTCH_SUPPRESS.size||!appState.actx||!appState.ana){this.val=0;return;}
 const bHz=appState.actx.sampleRate/appState.ana.fftSize;
 let preE=0,postE=0,n=0;
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins})=>{
 const bin=Math.round(hz/bHz);
 for(let i=Math.max(0,bin-halfBins);i<=Math.min(fdRaw.length-1,bin+halfBins);i++){
 const raw=fdRaw[i];if(!isFinite(raw))continue;
 const w=1-Math.abs(i-bin)/(halfBins+1);
 const post=raw-depth*w;
 preE+=Math.pow(10,raw/10);postE+=Math.pow(10,post/10);n++;
 }
 });
 if(n>0&&preE>0){
 this.val=Math.max(0,Math.min(100,Math.round((1-postE/preE)*100)));
 this.sampN++;SESSION_STAT.suppEffSum+=this.val;SESSION_STAT.suppEffN++;
 const badge=E('suppEffBadge');
 if(badge){badge.textContent=` · ${this.val}% eff`;badge.style.color=this.val>85?'#a5a5a5':this.val>60?'#b0b0b0':'#7c7c7c';}
 }
 }
}
const SUPP_EFF=new SuppressionEffMonitor();
function updateSuppEff(fdRaw){return SUPP_EFF.update(fdRaw);}

/* ══ TAP-TO-NOTCH on canvases ══ */
let _tapInit=false;
function initCanvasTap(){
 if(_tapInit)return;_tapInit=true;
 // Spectrogram pane0
 const specC=document.querySelectorAll('#specCv')[0];
 if(specC){
 const tapSpec=ev=>{
 if(!appState.isRun||!appState.actx)return;
 const rect=specC.getBoundingClientRect();
 const x=(ev.clientX!=null?ev.clientX:ev.pageX)-rect.left;
 const pct=Math.max(0,Math.min(1,x/rect.width));
 const nyq=appState.actx.sampleRate/2;
 // تشديد أكثر: hz<1 وحدها لا ترفض NaN — لو كان rect.width=0 (Canvas لم يُخطَّط بعد،
 // ممكن حقاً عند نقر فوري بعد فتح اللوحة) فـx/rect.width قد تُنتِج NaN فتظهر "NaN Hz"
 // في سجلّ NN حتى لو رفضتها activateNotch نفسها لاحقاً — الرفض هنا يمنع حتى محاولة تسجيله
 const hz=pct*nyq;if(!hz||!isFinite(hz)||hz<1)return;
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logNN(` TAP REMOVE: ${hz.toFixed(1)}Hz`);}
 else{activateNotch(hz);logNN(` TAP NOTCH: ${hz.toFixed(1)}Hz`);}
 };
 specC.addEventListener('click',tapSpec);
 specC.addEventListener('touchend',ev=>{ev.preventDefault();tapSpec(ev.changedTouches[0]);},{passive:false});
 }
 // Freq timeline (y=Hz)
 const tlC=E('freqTimeCv');
 if(tlC){
 const tapTl=ev=>{
 if(!appState.isRun||!appState.actx||FREQ_HIST.hz.length<2)return;
 const rect=tlC.getBoundingClientRect();
 const y=(ev.clientY!=null?ev.clientY:ev.pageY)-rect.top;
 const pct=1-(y/rect.height);
 const nyq=appState.actx.sampleRate/2;
 let maxHz=0;FREQ_HIST.hz.forEach(v=>{if(v>maxHz)maxHz=v;});
 maxHz=Math.min(maxHz*1.25,nyq);if(!isFinite(maxHz)||maxHz<1)return;
 // تشديد أكثر: نفس إصلاح tapSpec أعلاه — hz<1 لا ترفض NaN
 const hz=pct*maxHz;if(!hz||!isFinite(hz)||hz<1)return;
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logNN(` TAP REMOVE: ${hz.toFixed(1)}Hz`);}
 else{activateNotch(hz);logNN(` TAP NOTCH: ${hz.toFixed(1)}Hz`);}
 };
 tlC.addEventListener('click',tapTl);
 tlC.addEventListener('touchend',ev=>{ev.preventDefault();tapTl(ev.changedTouches[0]);},{passive:false});
 }
}

/* ══ FREQ TIMELINE ══ */
class FreqTimeline{
 constructor(){this.hz=[];this.maxLen=1500;} // 1500 × 80ms ≈ 2 minutes
 push(){
 this.hz.push(appState.fanFreq>0?appState.fanFreq:0);
 if(this.hz.length>this.maxLen)this.hz.shift();
 }
 draw(){
 const cv=E('freqTimeCv');if(!cv)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||320;const H=52;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(0,0,cW,cH);
 const data=this.hz;
 if(data.length<2)return;
 const nyq=appState.actx?appState.actx.sampleRate/2:24000;
 let maxHz=0;data.forEach(v=>{if(v>maxHz)maxHz=v;});
 if(maxHz<5)return;
 maxHz=Math.min(maxHz*1.25,nyq);
 // Grid
 ctx.strokeStyle='rgba(255,255,255,.05)';ctx.lineWidth=1;
 for(let i=1;i<4;i++){
 const y=Math.round(cH*(i/4));
 ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();
 }
 // Hz label at top (maxHz)
 ctx.fillStyle='rgba(149,149,149,.5)';ctx.font=`${Math.round(7*dpr)}px monospace`;
 ctx.fillText(maxHz.toFixed(0)+'Hz',3*dpr,9*dpr);
 ctx.fillStyle='rgba(255,255,255,.2)';
 ctx.fillText('0Hz',3*dpr,cH-3*dpr);
 // Timeline line
 ctx.beginPath();
 let first=true;
 for(let i=0;i<data.length;i++){
 const v=data[i];
 if(v<=0){first=true;continue;}
 const x=(i/(data.length-1))*cW;
 const y=cH-(v/maxHz)*(cH*0.88)-cH*0.04;
 if(first){ctx.moveTo(x,y);first=false;}else{ctx.lineTo(x,y);}
 }
 const grd=ctx.createLinearGradient(0,0,cW,0);
 grd.addColorStop(0,'rgba(109,109,109,.4)');
 grd.addColorStop(0.6,'rgba(149,149,149,.55)');
 grd.addColorStop(1,'rgba(165,165,165,.8)');
 ctx.strokeStyle=grd;ctx.lineWidth=1.5*dpr;ctx.lineJoin='round';ctx.stroke();
 // Confirmed freq markers as dashed horizontal lines
 if(typeof freqDB!=='undefined'&&freqDB.size>0){
 ctx.setLineDash([2,4]);ctx.lineWidth=1;
 freqDB.forEach(e=>{
 if(!e.confirmed)return;
 const y=cH-(e.hz/maxHz)*(cH*0.88)-cH*0.04;
 if(y<0||y>cH)return;
 ctx.strokeStyle='rgba(165,165,165,.25)';
 ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();
 });
 ctx.setLineDash([]);
 }
 // Latest dot
 const last=data[data.length-1];
 if(last>0){
 const ly=cH-(last/maxHz)*(cH*0.88)-cH*0.04;
 ctx.beginPath();ctx.arc(cW-2*dpr,ly,2.5*dpr,0,Math.PI*2);
 ctx.fillStyle='rgba(165,165,165,.9)';ctx.fill();
 }
 }
}
const FREQ_HIST=new FreqTimeline();
function pushFreqHist(){return FREQ_HIST.push();}
function drawFreqTimeline(){return FREQ_HIST.draw();}

/* ══════════════════════════════════════════════
 ADAPTIVE NOTCH TRACKER
 Slides existing notch centers when fanFreq drifts
══════════════════════════════════════════════ */
class NotchAdaptiveTracker{
 constructor(){this.enabled=true;this.maxDrift=22;this.minDrift=2;this.cooldown=new Map();}
 track(newHz){
 if(!this.enabled||!newHz||newHz<1||!NOTCH_SUPPRESS.size)return;
 let bestKey=null,bestDelta=Infinity;
 NOTCH_SUPPRESS.forEach(({hz},k)=>{
 const d=Math.abs(hz-newHz);
 if(d>=this.minDrift&&d<=this.maxDrift&&d<bestDelta){bestDelta=d;bestKey=k;}
 });
 if(bestKey===null)return;
 const now=Date.now();
 const last=this.cooldown.get(bestKey)||0;
 if(now-last<2500)return; // max slide once per 2.5s
 const old=NOTCH_SUPPRESS.get(bestKey);
 if(!old)return;
 NOTCH_SUPPRESS.delete(bestKey);
 const newK=fBin(newHz);
 NOTCH_SUPPRESS.set(newK,{hz:newHz,depth:old.depth,halfBins:old.halfBins,lastHit:now,order:old.order||1});
 this.cooldown.set(newK,now);
 updateNotchUI();
 logNN(` NOTCH TRACK: ${old.hz.toFixed(1)}→${newHz.toFixed(1)}Hz (Δ${bestDelta.toFixed(1)}Hz)`);
 }
}
const NOTCH_ADAPT=new NotchAdaptiveTracker();
function adaptNotchTrack(newHz){return NOTCH_ADAPT.track(newHz);}

/* ══ NOTCH DECAY CHECK ══ */
function checkNotchDecay(){
 if(!NOTCH_DECAY.enabled||!NOTCH_SUPPRESS.size)return;
 const now=Date.now();const toKill=[];
 NOTCH_SUPPRESS.forEach((n,k)=>{if(now-(n.lastHit||now)>NOTCH_DECAY.afterMs)toKill.push({k,hz:n.hz});});
 if(!toKill.length)return;
 toKill.forEach(({k,hz})=>{NOTCH_SUPPRESS.delete(k);logNN(` DECAY: ${hz.toFixed(1)}Hz expired (${(NOTCH_DECAY.afterMs/1000).toFixed(0)}s idle)`);});
 updateNotchUI();
}

/* ══ MULTI-PEAK DETECTOR (Dev100) ══
 Finds top-5 spectral peaks from FFT (excluding notched bins)
 Results stored in PEAKS_DATA.peaks = [{hz, db}] ══ */
function scanPeaks(fd,bHz,mxB){
 if(!fd||!bHz||fd.length<10)return;
 const candidates=[];
 // Local maxima via 2-neighbour comparison
 const lim=Math.min(mxB-3,4096);
 for(let i=3;i<lim;i++){
 if(fd[i]>fd[i-1]&&fd[i]>fd[i+1]&&fd[i]>fd[i-2]&&fd[i]>fd[i+2]){
 const a=fd[i-1],b=fd[i],c=fd[i+1],dv=2*b-a-c;
 // نفس إصلاح detectAll: خانة FFT مجاورة بطاقة صفرية (-Infinity من getFloatFrequencyData)
 // تجعل الإزاحة NaN — تُهمَل هنا وتُستبدَل بصفر كي لا يظهر "NaN Hz" في قائمة القمم الطيفية
 let _off=dv!==0?(a-c)/(2*dv):0;
 if(!isFinite(_off))_off=0;
 const hz=Math.max(0,(i+_off)*bHz);
 candidates.push({hz,db:b,bin:i});
 }
 }
 candidates.sort((a,b2)=>b2.db-a.db);
 const peaks=[];
 for(const cand of candidates){
 if(peaks.length>=PEAKS_DATA.maxPeaks)break;
 if(peaks.some(p=>Math.abs(p.hz-cand.hz)<bHz*4))continue; // too close
 if(NOTCH_SUPPRESS.has(fBin(cand.hz)))continue; // notched
 if(AI_GATE.enabled&&AI_BAN.has(fBin(cand.hz)))continue; // تشديد: تردد محضور لا يظهر في قائمة القمم الطيفية (PEAKS/EXPORT)
 peaks.push({hz:cand.hz,db:cand.db});
 }
 PEAKS_DATA.peaks=peaks;
 PEAKS_DATA.lastT=Date.now();
}

/* ══ SIGNAL QUALITY INDEX — 0-100 composite (Dev100) ══
 kfConf×30 + suppEff×30 + envStab×40 − hopPenalty(max 40) */
function computeSQI(){
 const kfConf=Math.max(0,Math.min(1,1-KF.P[0]/5));
 const suppEff=NOTCH_SUPPRESS.size?(SUPP_EFF.val||0)/100:1; // no notches = perfect eff
 const envTotal=Object.values(SESSION_STAT.envCount).reduce((a,b)=>a+b,0)||1;
 const envStab=Math.min(1,(SESSION_STAT.envCount[curEnvClass]||0)/envTotal);
 const hopCount=Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0));
 const hopPenalty=Math.min(40,hopCount*2);
 const raw=(kfConf*30+suppEff*30+envStab*40)-hopPenalty;
 SQI.val=Math.max(0,Math.min(100,Math.round(raw)));
 SQI.kfConf=Math.round(kfConf*100);
 SQI.suppEff=Math.round(suppEff*100);
 SQI.envStab=Math.round(envStab*100);
 SQI.hopPenalty=Math.round(hopPenalty);
 // rolling history for chart
 SQI_HIST.vals.push(SQI.val);if(SQI_HIST.vals.length>SQI_HIST.maxLen)SQI_HIST.vals.shift();
 // update stats card
 const sq=E('ss-sqi');if(sq){sq.textContent=SQI.val;sq.className='stat-val '+(SQI.val>=80?'green':SQI.val>=50?'yellow':'red');}
}

/* ══ SMART NOTCH SUGGESTION (Dev100) ══
 After N tonal detections at same stable freq → log + toast */
function checkNotchSuggest(hz){
 if(!hz||hz<1||!appState.isRun)return;
 const k=fBin(hz);
 if(NOTCH_SUPPRESS.has(k)){NOTCH_SUGGEST.count=0;return;}
 const e=freqDB.get(k);
 // إصلاح خلل: e.confirmed حقل منطقي (true/false) وليس عدّاداً — مقارنته بـ<3 كانت تُقيَّم
 // دائماً true (true<3 و false<3 كلاهما true في JS)، فيجعل هذا الشرط صحيحاً دوماً ويُصفِّر
 // NOTCH_SUGGEST.count ويخرج في كل استدعاء، ما يُعطِّل ميزة اقتراح الـnotch كلياً. التحقّق
 // من "مؤكَّد فعلاً" يكفيه !e.confirmed وحدها — عدّاد الاستقرار الفعلي (N استدعاءات متتالية)
 // تتكفّل به NOTCH_SUGGEST.count/.threshold أدناه بشكل منفصل تماماً.
 if(!e||!e.confirmed){NOTCH_SUGGEST.count=0;return;}
 if(Math.abs(hz-NOTCH_SUGGEST.hz)>8){NOTCH_SUGGEST.hz=hz;NOTCH_SUGGEST.count=1;NOTCH_SUGGEST.shown=false;return;}
 NOTCH_SUGGEST.count++;
 if(NOTCH_SUGGEST.count>=NOTCH_SUGGEST.threshold&&!NOTCH_SUGGEST.shown){
 NOTCH_SUGGEST.shown=true;
 NOTCH_SUGGEST.toastT=Date.now();
 // مراجعة "المشروع بالكامل": e.confirmed حقل منطقي (true/false)، لا عدّاداً — كانت الرسالة
 // تطبع حرفياً "(true confirms)" بدل عدد مرات الرصد الفعلي؛ e.count هو العدّاد الحقيقي.
 logNN(` SUGGEST: ${hz.toFixed(1)}Hz is stable tonal (${e.count} confirms) — NOTCH ${Math.round(hz)} or tap spectrogram`);
 _showNotchToast(hz);
 }
}
function _showNotchToast(hz){
 let t=E('notchSuggestToast');
 if(!t){
 t=document.createElement('div');t.id='notchSuggestToast';
 t.style.cssText='position:fixed;bottom:calc(88px + var(--vv-bottom-inset,0px));right:14px;background:rgba(165,165,165,.13);border:1px solid rgba(165,165,165,.4);border-radius:8px;padding:9px 13px;font-family:var(--fm);font-size:11px;color:var(--text);z-index:9999;cursor:pointer;max-width:195px;line-height:1.5;backdrop-filter:blur(6px);box-shadow:0 4px 14px rgba(0,0,0,.35)';
 document.body.appendChild(t);
 }
 t.innerHTML=`<b>${hz.toFixed(1)} Hz</b> stable tonal<br><span style="color:var(--muted);font-size:9px">Tap to add notch · × dismiss</span>`;
 t.hidden=false;
 const dismiss=()=>{t.hidden=true;NOTCH_SUGGEST.shown=false;NOTCH_SUGGEST.count=0;};
 t.onclick=(ev)=>{
 const x=ev.offsetX/t.offsetWidth,y=ev.offsetY/t.offsetHeight;
 if(x>0.8&&y<0.3){dismiss();return;} // top-right corner = dismiss
 activateNotch(hz);logNN(` NOTCH via suggest: ${hz.toFixed(1)}Hz`);dismiss();
 };
 clearTimeout(NOTCH_SUGGEST._toastTimer);
 NOTCH_SUGGEST._toastTimer=setTimeout(()=>{if(t)t.hidden=true;},14000);
}

/* ══ SQI HISTORY CHART — mini line canvas in stats tab (Dev110) ══ */
function drawSQIHist(){
 const cv=E('sqiHistCv');if(!cv)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||200,H=44;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(0,0,cW,cH);
 const data=SQI_HIST.vals;
 if(data.length<2){
 ctx.fillStyle='rgba(255,255,255,.18)';ctx.font=`${Math.round(8*dpr)}px monospace`;
 ctx.fillText('Waiting for data…',8*dpr,cH/2+3*dpr);return;
 }
 // Guide lines at 50 and 80
 ctx.setLineDash([2,4]);ctx.lineWidth=1;ctx.strokeStyle='rgba(255,255,255,.08)';
 [50,80].forEach(v=>{const y=cH-(v/100)*cH;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();});
 ctx.setLineDash([]);
 // Fill under curve
 ctx.beginPath();let first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.lineTo(cW,cH);ctx.lineTo(0,cH);ctx.closePath();
 ctx.fillStyle='rgba(135,135,135,.10)';ctx.fill();
 // Line
 const last=data[data.length-1];
 const col=last>=80?'#a5a5a5':last>=50?'#b0b0b0':'#7c7c7c';
 ctx.beginPath();first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.strokeStyle=col;ctx.lineWidth=1.5*dpr;ctx.lineJoin='round';ctx.stroke();
 // Latest dot
 {const x=cW-2*dpr,y=cH-(last/100)*cH;ctx.beginPath();ctx.arc(x,y,2.5*dpr,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();}
 // Corner labels
 ctx.fillStyle='rgba(255,255,255,.25)';ctx.font=`${Math.round(6*dpr)}px monospace`;
 ctx.fillText('100',3*dpr,7*dpr);ctx.fillText('0',3*dpr,cH-2*dpr);
 ctx.fillStyle=col;ctx.textAlign='right';ctx.fillText(last,cW-3*dpr,7*dpr);ctx.textAlign='left';
}

/* ══ OCTAVE BAND POWER — 9 standard bands (Dev110) ══ */
function updateBandPower(fd,bHz){
 if(!bHz||!fd||fd.length<4)return;
 BAND_POWER.BANDS.forEach((b,i)=>{
 const lo=Math.max(1,Math.round(b.lo/bHz)),hi=Math.min(fd.length-1,Math.round(b.hi/bHz));
 if(lo>=hi)return;
 let sum=0,n=0;
 for(let j=lo;j<=hi;j++){sum+=Math.pow(10,fd[j]/10);n++;}
 const rms=n>0?10*Math.log10(Math.max(1e-10,sum/n)):-80;
 BAND_POWER.vals[i]=BAND_POWER.vals[i]*.75+rms*.25; // exponential smooth
 });
}

/* ══ FREQUENCY ALARM CHECKER (Dev110) ══ */
function checkFreqAlarms(hz){
 if(!FREQ_ALARMS.size||!hz||hz<1)return;
 const now=Date.now();
 FREQ_ALARMS.forEach(alarm=>{
 if(!alarm.enabled)return;
 if(Math.abs(hz-alarm.hz)>alarm.tol)return;
 if(now-alarm.lastTrigT<alarm.cooldown)return;
 alarm.count++;alarm.lastTrigT=now;
 logNN(` ALARM: ${alarm.hz.toFixed(1)}Hz detected at ${hz.toFixed(2)}Hz (hit #${alarm.count})`);
 // reuse hop flash for visual alert (orange pulse)
 const fl=E('freqHopFlash');
 if(fl){const old=fl.style.background;fl.style.background='rgba(173,173,173,.8)';fl.style.opacity='1';setTimeout(()=>{fl.style.opacity='0';setTimeout(()=>{fl.style.background=old;},400);},700);}
 });
}

/* ══ SPECTRAL DELTA (Dev110) ══
 Compare current FFT to saved baseline → show freq changes */
function computeSpecDelta(){
 if(!SPEC_DELTA.baseline||!lastFFD)return null;
 const len=Math.min(SPEC_DELTA.baseline.length,lastFFD.length);
 const bHz=SPEC_DELTA.bHz||0.5;
 const changes=[];
 for(let i=2;i<len&&i*bHz<10000;i++){
 const d=lastFFD[i]-SPEC_DELTA.baseline[i];
 if(Math.abs(d)>3.0){
 const hz=i*bHz;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz)))continue; // تشديد: تردد محضور مستبعد من قائمة فروقات DELTA
 changes.push({hz,diff:d,bin:i});
 }
 }
 changes.sort((a,b)=>Math.abs(b.diff)-Math.abs(a.diff));
 return changes.slice(0,14);
}

/* ══ ADAPTIVE ALERT (Dev120) ══
 Progressive logNN alerts when SQI drops or hop-rate spikes.
 Called from updateExecUI() every ~80ms. */
function checkAdaptiveAlert(){
 if(!ADAPTIVE_ALERT.enabled||!appState.isRun)return;
 const now=Date.now();
 if(now-ADAPTIVE_ALERT.lastT<ADAPTIVE_ALERT.cooldown)return;
 const hopRate=Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0));
 let newLevel='ok';
 if(SQI.val<ADAPTIVE_ALERT.critSQI)newLevel='critical';
 else if(SQI.val<ADAPTIVE_ALERT.warnSQI||hopRate>ADAPTIVE_ALERT.warnHops)newLevel='warn';
 if(newLevel!==ADAPTIVE_ALERT.level||newLevel!=='ok'){
 ADAPTIVE_ALERT.level=newLevel;ADAPTIVE_ALERT.lastT=now;
 if(newLevel==='critical')logNN(` ALERT CRITICAL: SQI=${SQI.val} — tracking unstable!`);
 else if(newLevel==='warn')logNN(` ALERT WARN: SQI=${SQI.val} · hops=${hopRate}`);
 else logNN(` ALERT CLEAR: SQI=${SQI.val} — signal stable`);
 }
}

/* ══════════════════════════════════════════════
 INPUT LEVEL METER — RMS + peak hold + clip flash
══════════════════════════════════════════════ */
class LevelMeter{
 constructor(){this.rms=0;this.peak=0;this.peakHold=0;this.peakHoldT=0;this.clipT=0;}
 update(td){
 let sum=0,pk=0;
 for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;sum+=v*v;if(Math.abs(v)>pk)pk=Math.abs(v);}
 this.rms=Math.sqrt(sum/td.length);
 // Peak hold (2s decay)
 const now=Date.now();
 if(pk>this.peakHold||now-this.peakHoldT>2000){this.peakHold=pk;this.peakHoldT=now;}
 const db=this.rms>0?20*Math.log10(this.rms):-Infinity;
 const dbC=Math.max(-60,Math.min(0,db));
 const pct=Math.max(0,Math.min(100,(dbC+60)/60*100));
 const peakDB=this.peakHold>0?20*Math.log10(this.peakHold+0.00001):-60;
 const peakPct=Math.max(0,Math.min(100,(Math.max(-60,peakDB)+60)/60*100));
 if(pk>0.97)this.clipT=now;
 const clipping=now-this.clipT<900;
 // Show meter when running
 const meter=E('lvlMeter');if(meter&&meter.style.display==='none'&&appState.isRun)meter.style.display='flex';
 const rmsEl=E('lvlRms');
 if(rmsEl){
 rmsEl.style.width=pct+'%';
 rmsEl.style.background=clipping?'linear-gradient(90deg,var(--on),var(--off))':'linear-gradient(90deg,var(--on),var(--sharp))';
 }
 const peakEl=E('lvlPeak');if(peakEl)peakEl.style.left=peakPct+'%';
 const dbEl=E('lvlDb');if(dbEl)dbEl.textContent=isFinite(db)?db.toFixed(1)+'dB':'—dB';
 const clipEl=E('lvlClip');if(clipEl)clipEl.className='lvl-clip'+(clipping?' on':'');
 }
}
const LVL=new LevelMeter();
function updateLevelMeter(td){return LVL.update(td);}

/* ══════════════════════════════════════════════
 SCENE PROFILES — Named environment snapshots
 Save/load FreqDB + notches + env to IndexedDB
══════════════════════════════════════════════ */
/* "توحيد الكل في مجلد واحد" — المشاهد المحفوظة (scenes: إعدادات غرفة/ترددات مُسمّاة يحفظها
 المستخدم صراحة عبر sceneSave) كانت تعيش حصراً داخل IndexedDB (تخزين المتصفح)، بلا أي مسار
 إطلاقاً إلى المجلد الثابت (My Files) — بخلاف كل بيانات التطبيق الأخرى (حظر/FreqDB/NN/
 إنجازات) التي تصل جميعها الآن لنفس المجلد. أي مسح لبيانات التطبيق (من إعدادات أندرويد، إعادة
 تثبيت، إعادة ضبط الجهاز) كان يفقد كل المشاهد المحفوظة نهائياً بلا أي نسخة احتياطية ممكنة —
 فجوة حقيقية في "توحيد الكل" رغم أنها بيانات مُسمّاة يحفظها المستخدم صراحة، تماماً كالحظر.
 اسم ملف ثابت (لا طابع زمني، لا تراكم يحتاج تنظيفاً) لأن IndexedDB نفسها تُدار بنفس المنطق:
 مفتاح فريد بالاسم (keyPath:'name') يُستبدَل لا يتراكم — هذا الملف مرآة مباشرة لتلك القائمة
 بأكملها، تُحدَّث فوراً مع كل حفظ أو حذف مشهد. */
const WTAFS_SCENES_FILE='ZeroAI_Scenes.json';

/* المشاهد (Scenes) — لقطات بيئة مُسمّاة يحفظها المستخدم صراحة (FreqDB + notches + env) في
   IndexedDB، مع مرآة اختيارية للمجلد الثابت. زوج «حالة (active/syncGen) + سلوك» حقيقي بالكامل
   داخلي لهذا القسم (SCENE_ACTIVE و_scenesSyncGen كلاهما outside:0 قبل التحويل) — حُوِّل إلى
   class SceneManager؛ النداءات الداخلية المتبادلة (كانت _sceneDB()/_syncScenesToFixedFolder()/
   sceneList() من دوال أخرى بنفس الكتلة) حُوِّلت إلى this.openDB()/this.syncToFixedFolder()/
   this.list() بنفس مبدأ InverseGenerator/MicProfile في قسم 03. الدوال السبع القديمة
   (_sceneDB/sceneSave/sceneLoad/sceneList/sceneDelete/_syncScenesToFixedFolder/
   _restoreScenesFromJSON) بقيت أغلفة رقيقة بنفس الأسماء — بعضها (sceneSave/sceneLoad/
   sceneList/sceneDelete/_restoreScenesFromJSON) مُستدعاة فعلاً من 07b/10 خارجياً. */
class SceneManager{
 constructor(){this.active=null;this.syncGen=0;}
 openDB(){
 return new Promise((res,rej)=>{
 // Reuse zeroDB if already open and has 'scenes' store
 if(zeroDB&&zeroDB.objectStoreNames.contains('scenes')){res(zeroDB);return;}
 // Otherwise open with bumped version to create the store
 const req=indexedDB.open('ZeroAIv25',4);
 req.onupgradeneeded=ev=>{
 const db=ev.target.result;
 if(!db.objectStoreNames.contains('scenes'))
 db.createObjectStore('scenes',{keyPath:'name'});
 };
 req.onsuccess=ev=>{
 // If this opened a newer handle, update zeroDB
 const db=ev.target.result;
 zeroDB=db;
 res(db);
 };
 req.onerror=ev=>rej(ev.target.error);
 });
}

 async save(name){
 name=(name||'').trim();if(!name)return null;
 try{
 const db=await this.openDB();
 const freqs=[...freqDB.values()];
 const notches=[...NOTCH_SUPPRESS.values()];
 const scene={name,ts:Date.now(),env:curEnvClass,freqCount:freqs.length,notchCount:notches.length,freqs,notches};
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').put(scene);
 tx.oncomplete=()=>res(scene);tx.onerror=ev=>rej(ev.target.error);
 });
 this.active=name;
 const sb=E('sceneBadge');if(sb){sb.textContent=`scene: ${name}`;sb.className='scene-badge visible';}
 // "توحيد الكل في مجلد واحد": مرآة فورية لكل المشاهد المحفوظة إلى المجلد الثابت (fire-and-
 // forget — لا تُبطئ حفظ المشهد نفسه في IndexedDB، وفشلها لا يُفسِد الحفظ الأساسي).
 this.syncToFixedFolder();
 return scene;
 }catch(e){console.warn('sceneSave:',e);return null;}
}

 async load(name){
 name=(name||'').trim();if(!name)return null;
 try{
 const db=await this.openDB();
 const scene=await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').get(name);
 req.onsuccess=ev=>res(ev.target.result);req.onerror=ev=>rej(ev.target.error);
 });
 if(!scene)return null;
 // مراجعة "النسخة النهائية": كانت freqDB.clear() تُنفَّذ قبل أي تحقّق من شكل scene.freqs/
 // notches — مشهد مستورَد من ملف مُعدَّل يدوياً أو تالف (لا يحمل حقل freqs مصفوفة) كان
 // يُفرِغ freqDB بالكامل ثم يرمي استثناء داخل forEach، يُلتقَط بصمت في catch الخارجي —
 // فيفقد المستخدم كل ترددات جلسته الحالية بلا أي استعادة أو رسالة خطأ واضحة. التحقق الآن
 // يسبق أي تعديل فعلي على الحالة.
 if(!Array.isArray(scene.freqs)||!Array.isArray(scene.notches)){
 console.warn('sceneLoad: مشهد بشكل غير صالح (freqs/notches ليست مصفوفة) — تم تجاهله بلا تعديل الحالة الحالية');
 return null;
 }
 // Restore
 freqDB.clear();
 scene.freqs.forEach(e=>freqDB.set(e.hz!=null?e.hz:fBin(e.hz||0),e));
 NOTCH_SUPPRESS.clear();
 scene.notches.forEach(n=>NOTCH_SUPPRESS.set(fBin(n.hz),n));
 updateNotchUI();
 this.active=name;
 const sb=E('sceneBadge');if(sb){sb.textContent=`scene: ${name}`;sb.className='scene-badge visible';}
 return scene;
 }catch(e){console.warn('sceneLoad:',e);return null;}
}

 async list(){
 try{
 const db=await this.openDB();
 return await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').getAll();
 req.onsuccess=ev=>res(ev.target.result||[]);req.onerror=ev=>rej(ev.target.error);
 });
 }catch(e){return[];}
}

 async delete(name){
 name=(name||'').trim();if(!name)return false;
 try{
 const db=await this.openDB();
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').delete(name);
 tx.oncomplete=()=>res(true);tx.onerror=ev=>rej(ev.target.error);
 });
 if(this.active===name){
 this.active=null;
 const sb=E('sceneBadge');if(sb)sb.className='scene-badge';
 }
 this.syncToFixedFolder();
 return true;
 }catch(e){return false;}
}
// حارس تزامن (نفس نمط _wtafsResourcesGen): _syncScenesToFixedFolder تُستدعى دون انتظار (fire-
// and-forget) من موقعين مختلفين (sceneSave وsceneDelete)، ولها نقطة انتظار واحدة (sceneList).
// حفظ/حذف سريعان متتاليان (مثل استيراد عدة مشاهد، أو نقرات متلاحقة) يُطلقان نداءين متداخلين —
// وإن استقرت قراءة الأقدم بعد الأحدث، ستكتب بيانات قديمة فوق المرآة الأحدث بصمت. الحارس يضمن أن
// النتيجة المكتوبة فعلياً تعكس دائماً آخر نداء تم "إطلاقه" لا أياً كان النداء الذي "استقر" أخيراً.
 async syncToFixedFolder(){
 if(!_wtafsOk()||!WebToApkFS.hasAccess())return;
 const myGen=++this.syncGen;
 try{
 const scenes=await this.list();
 if(myGen!==this.syncGen)return; // نداء أحدث تجاوز هذا النداء — تُهمَل الكتابة كي لا تُفسِد المرآة بحالة قديمة
 const json=JSON.stringify({version:'ZeroAI_Scenes_v1',syncDate:new Date().toISOString(),scenes},null,2);
 WebToApkFS.writeText(WTAFS_SCENES_FILE,json);
 }catch(e){/* فشل مزامنة المرآة لا يُفسِد المصدر الأساسي (IndexedDB) — يُهمَل بصمت */}
}
/* استعادة المشاهد من ملف المرآة — دمج بالاسم (put، مثل sceneSave نفسها) لا استبدال كامل، كي لا
 تُمحى مشاهد موجودة على هذا الجهاز وغائبة عن الملف المستورَد (نفس فلسفة الدمج الإضافي
 المُستخدَمة أصلاً لملفات الحظر). */
 async restoreFromJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 if(!Array.isArray(data.scenes))throw new Error('صيغة ملف المشاهد غير صحيحة — يجب أن يحتوي على مفتاح "scenes"');
 const db=await this.openDB();
 let added=0,updated=0,skipped=0;
 for(const scene of data.scenes){
 if(!scene||typeof scene!=='object'||!scene.name){skipped++;continue;}
 // مراجعة "النسخة النهائية": رفض الفساد من مصدره (نفس فلسفة loadBans) — مشهد بلا freqs/
 // notches كمصفوفتين صالحتين لا يُخزَّن أصلاً، بدل الاعتماد فقط على تحقّق sceneLoad اللاحق؛
 // مسارات قراءة أخرى قد تفترض هذا الشكل دون المرور بذلك التحقّق.
 if(!Array.isArray(scene.freqs))scene.freqs=[];
 if(!Array.isArray(scene.notches))scene.notches=[];
 const existed=await new Promise(res=>{
 const tx=db.transaction('scenes','readonly');
 const req=tx.objectStore('scenes').get(scene.name);
 req.onsuccess=ev=>res(!!ev.target.result);req.onerror=()=>res(false);
 });
 await new Promise((res,rej)=>{
 const tx=db.transaction('scenes','readwrite');
 tx.objectStore('scenes').put(scene);
 tx.oncomplete=()=>res();tx.onerror=ev=>rej(ev.target.error);
 });
 if(existed)updated++;else added++;
 }
 if(skipped)stLog(' تُجوهِل '+skipped+' مشهد بلا اسم صالح أثناء الاستيراد من '+sourceLabel);
 stLog(' مشاهد: +'+added+' جديد + تحديث '+updated+' موجود من '+sourceLabel);
 return {added,updated,skipped,total:data.scenes.length};
}
}
const SCENE_MGR=new SceneManager();
function _sceneDB(){return SCENE_MGR.openDB();}
async function sceneSave(name){return SCENE_MGR.save(name);}
async function sceneLoad(name){return SCENE_MGR.load(name);}
async function sceneList(){return SCENE_MGR.list();}
async function sceneDelete(name){return SCENE_MGR.delete(name);}
async function _syncScenesToFixedFolder(){return SCENE_MGR.syncToFixedFolder();}
async function _restoreScenesFromJSON(raw,sourceLabel){return SCENE_MGR.restoreFromJSON(raw,sourceLabel);}
function updateStatsTab(){
 if(appState.isRun)classifyEnvironment();
 const fmt=ms=>{const s=Math.floor(ms/1000),m=Math.floor(s/60),h=Math.floor(m/60);return h?`${h}h ${m%60}m`:`${m}m ${s%60}s`;};
 const se=id=>E(id);
 const up=se('ss-uptime');if(up)up.textContent=fmt(Date.now()-SESSION_START);
 const cyc=se('ss-aicyc');if(cyc)cyc.textContent=typeof appState.aiCyc!=='undefined'?appState.aiCyc.toLocaleString():'0';
 const fq=se('ss-freqs');if(fq)fq.textContent=typeof freqDB!=='undefined'?freqDB.size:0;
 const bn=se('ss-banned');if(bn)bn.textContent=typeof AI_BAN!=='undefined'?AI_BAN.size:0;
 const ac=se('ss-acc');
 if(ac){
 const loss=typeof NN!=='undefined'&&NN.trainN>0?NN.loss:null;
 ac.textContent=loss!==null?Math.round((1-loss)*100)+'%':'—';
 if(loss!==null){ac.className='stat-val '+(loss<0.3?'green':loss<0.6?'yellow':'red');}
 }
 const ps=se('ss-preset');if(ps)ps.textContent=(PRESETS[curPreset]&&PRESETS[curPreset].emoji?PRESETS[curPreset].emoji+' ':'')+curPreset.toUpperCase();
 // thermal status
 const ts=se('ss-thermal-status'),td=se('ss-thermal-detail');
 if(thermalThrottleOn){
 if(ts)ts.textContent='تحذير حرارة';if(ts)ts.style.color='var(--off)';
 if(td)td.textContent='تم تفعيل التخفيف الحراري';
 } else {
 if(ts){ts.textContent='جيدة';ts.style.color='var(--on)';}
 if(td)td.textContent='جميع المناطق ضمن الحدود الآمنة';
 }
 // DB stats
 const dbs=se('ss-db-saved');
 if(dbs)dbs.textContent=lastFreqDBSave?lastFreqDBSave.toLocaleTimeString('ar-SA'):'—';
 // حجم IndexedDB الفعلي — تطوير مراقبة التراكم، 28 سبتمبر 2026: كانت القيمة المعروضة هنا
 // تقديراً تقريبياً بحتاً (freqDB.size*0.2 بلا أي أساس فعلي لحجم البايتات)، بينما التطبيق
 // يملك أصلاً مصدراً دقيقاً (navigator.storage.estimate()) مُستخدَماً في مكانين آخرين
 // (reqStoragePersist وأمر EXEC النصّي STATS) — الآن نفس المصدر الدقيق هنا أيضاً، والتقدير
 // القديم يبقى فقط احتياطاً لبناء WebView قديم لا يدعم Storage API إطلاقاً.
 const dbsz=se('ss-db-size');
 if(dbsz){
 if(navigator.storage&&navigator.storage.estimate){
 navigator.storage.estimate().then(est=>{
 if(dbsz)dbsz.textContent=Math.round((est.usage||0)/1024).toLocaleString()+' KB';
 }).catch(()=>{
 if(typeof freqDB!=='undefined'){const approx=Math.round(freqDB.size*0.2);dbsz.textContent=approx?approx+' KB':'—';}
 });
 } else if(typeof freqDB!=='undefined'){
 const approx=Math.round(freqDB.size*0.2);
 dbsz.textContent=approx?approx+' KB':'—';
 }
 }
 // مراقبة التراكم لكل مخزن UDS — udsGetStats() كانت موجودة أصلاً لكن غير مستخدَمة إطلاقاً في
 // أي واجهة مرئية (فقط داخل أمر EXEC نصّي STATS)؛ هنا تُعرَض حيّاً مع السقف الفعلي لكل مخزن
 // مُقلَّم تلقائياً (UDS_CAP من 08c-background-db.js).
 if(typeof udsGetStats==='function'){
 udsGetStats().then(counts=>{
 const rowsEl=se('ss-uds-rows');
 if(!rowsEl)return;
 const STORE_LABELS={terminal_events:'سجلّ الطرفية',exec_history:'تنفيذ AI',nn_history:'الشبكة العصبية',freq_patterns:'أنماط الترددات',sessions:'الجلسات'};
 rowsEl.innerHTML=Object.entries(counts).map(([name,count])=>{
 const cap=(typeof UDS_CAP!=='undefined')?UDS_CAP[name]:null;
 const label=STORE_LABELS[name]||name;
 const pct=cap?Math.round((count/cap)*100):null;
 const valTxt=cap?`${count.toLocaleString()} / ${cap.toLocaleString()}`:`${count.toLocaleString()}`;
 const color=(cap&&pct>=90)?'var(--sharp)':'var(--dim)';
 return `<div style="display:flex;justify-content:space-between;align-items:center">`+
 `<span style="color:var(--muted)">${label}</span>`+
 `<span style="color:${color}">${valTxt}${cap?` <span style="opacity:.6">(${pct}%)</span>`:''}</span>`+
 `</div>`;
 }).join('');
 }).catch(()=>{});
 }
 drawSQIHist(); // Dev110: SQI history chart
}

function openTab(n){
 curTab=n;
 for(let i=0;i<9;i++){
 const b=E('tb'+i),p=E('pane'+i);
 if(b)b.classList.toggle('act',i===n);
 if(p)p.classList.toggle('on',i===n);
 }
 // Tab-specific refresh
 if(n===1)drawRwChart();
 if(n===2)drawClassChart();
 if(n===3){updateMicUI();updateMicFeat();}
 if(n===5)renderExecLog();
 if(n===6)updBGUI();
 if(n===7){updateFilesUI();refreshSessionList();}
 // STATS tab — start auto-refresh interval
 if(n===8){
 updateStatsTab();
 if(!statsIv)statsIv=setInterval(updateStatsTab,2000);
 } else {
 if(statsIv){clearInterval(statsIv);statsIv=null;}
 }
}

/* ══ AUDIO INIT ══ */
// إغلاق الفراغات: حماية إضافية — حتى لو استُدعيت initAudio() من مسار آخر غير toggleAI() (حارس
// _toggleBusy لا يحميه)، هذا الحارس (وعد واحد مُشترَك) يمنع أي نداءين متزامنين من إنشاء طلبي
// getUserMedia()+AudioContext منفصلين؛ النداء الثاني يستلم نفس وعد النداء الأول قيد التنفيذ بدل
// بدء تهيئة صوتية ثانية توضّع مصدر التسريب الحقيقي — سياق صوت (AudioContext) حيّ منسي لا مرجع
// له بعد أن يكتب النداء اللاحق فوق actx/micStr العامّين.



window.curTab=curTab; window.statsIv=statsIv; window.thermalThrottleOn=thermalThrottleOn;
window.curPreset=curPreset; window.lastFreqDBSave=lastFreqDBSave; window.SESSION_START=SESSION_START;
window.PRESETS=PRESETS; window.setThermalThrottle=setThermalThrottle; window.applyPreset=applyPreset;
window.saveFreqDB=saveFreqDB; window.loadFreqDB=loadFreqDB; window.ENV_LABELS=ENV_LABELS;
window.curEnvClass=curEnvClass; window.classifyEnvironment=classifyEnvironment; window.FREQ_HOP=FREQ_HOP;
window.detectFreqHop=detectFreqHop; window.AUTOPRESET=AUTOPRESET; window.autoPresetCheck=autoPresetCheck;
window.SUPP_EFF=SUPP_EFF; window.updateSuppEff=updateSuppEff; window._tapInit=_tapInit;
window.initCanvasTap=initCanvasTap; window.FREQ_HIST=FREQ_HIST; window.pushFreqHist=pushFreqHist;
window.drawFreqTimeline=drawFreqTimeline; window.NOTCH_ADAPT=NOTCH_ADAPT; window.adaptNotchTrack=adaptNotchTrack;
window.checkNotchDecay=checkNotchDecay; window.scanPeaks=scanPeaks; window.computeSQI=computeSQI;
window.checkNotchSuggest=checkNotchSuggest; window._showNotchToast=_showNotchToast; window.drawSQIHist=drawSQIHist;
window.updateBandPower=updateBandPower; window.checkFreqAlarms=checkFreqAlarms; window.computeSpecDelta=computeSpecDelta;
window.checkAdaptiveAlert=checkAdaptiveAlert; window.LVL=LVL; window.updateLevelMeter=updateLevelMeter;
window.SCENE_MGR=SCENE_MGR; window._sceneDB=_sceneDB; window.sceneSave=sceneSave;
window.sceneLoad=sceneLoad; window.sceneList=sceneList; window.sceneDelete=sceneDelete;
window.WTAFS_SCENES_FILE=WTAFS_SCENES_FILE; window._syncScenesToFixedFolder=_syncScenesToFixedFolder; window._restoreScenesFromJSON=_restoreScenesFromJSON;
window.updateStatsTab=updateStatsTab; window.openTab=openTab;

})();
/* ── 06-detection-engine-core.js ── */

'use strict';
(function(){

let _audioInitPromise=null;
async function initAudio(){
 if(appState.actx&&appState.micStr)return true;
 if(_audioInitPromise)return _audioInitPromise;
 _audioInitPromise=(async()=>{
 try{
 appState.micStr=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false,channelCount:1,latency:.001}});
 appState.actx=new(window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});
 await appState.actx.resume();
 appState.micSrc=appState.actx.createMediaStreamSource(appState.micStr);
 appState.ana=appState.actx.createAnalyser();
 appState.ana.fftSize=32768;appState.ana.smoothingTimeConstant=.4;appState.ana.minDecibels=-120;appState.ana.maxDecibels=-5;
 appState.micSrc.connect(appState.ana);
 P.delay=Math.max(5,((appState.actx.baseLatency||0)+(appState.actx.outputLatency||0))*1000+6);
 return true;
 }catch(err){const ht2=E('homeT2');if(ht2)ht2.textContent='Mic error: '+err.message;return false;}
 finally{_audioInitPromise=null;}
 })();
 return _audioInitPromise;
}

/* ══ START ALL — integrated BG + Storage ══ */
async function startAll(){
 // إغلاق الفراغات: toggleAI() يحتاج معرفة نجاح/فشل التهيئة فعلاً (بدل افتراض النجاح دائماً)
 // كي لا تُطبَّق واجهة "تشغيل" على حالة فشلت فعلاً — لذا أصبحت تُرجع true/false صراحةً.
 const ok=await initAudio();if(!ok)return false;
 appState.isRun=true;
 // مراجعة "المشروع بالكامل": هذا الاستدعاء كان الوحيد في كل الملف غير المحروس بـ
 // if(!NN.w1) — على عكس loadLastWeights()/loadSession()/_restoreFullBackupJSON() كلها.
 // initStorage() (يعمل تلقائياً 800ms بعد تحميل الصفحة) يستعيد أوزاناً مدرَّبة فعلياً من
 // IndexedDB عبر loadLastWeights() قبل أن يضغط المستخدم زر "تشغيل" عادةً. لكن nnInit() هنا
 // كانت تستبدل تلك الأوزان المُستعادة بأوزان عشوائية جديدة دون قيد، دون تصفير NN.trainN —
 // فيستمر الشرط التالي (NN.trainN===0) بالفشل ولا تُعاد محاولة الاستعادة، وتستمر الجلسة
 // على أوزان عشوائية بالكامل بينما يستمر السجل/الواجهة بعرض "trained=200" (قيمة النطاق
 // القديمة) كأن التعلّم مستمر — عملياً، لا "تعلّم" حقيقي كان يبقى بعد أي إعادة تشغيل عادية.
 if(!NN.w1)nnInit();
 profileMic();
 SESSION_STAT.startT=Date.now();SESSION_STAT.hopCount0=FREQ_HOP.count;SESSION_STAT.envCount={};SESSION_STAT.notchPeak=0;SESSION_STAT.suppEffSum=0;SESSION_STAT.suppEffN=0;
 if(notchDecayT)clearInterval(notchDecayT);notchDecayT=setInterval(checkNotchDecay,5000);
 startSF();startDet();startCL();startLearn();startNN();startAudioPoke();initCanvasTap();
 if(!appState.drawId)drawLoop();
 setPlSt(true);{const _t=E('tbTxt');if(_t)_t.textContent='AI Active';}
 // ① Background systems
 if(bgEnabled){
 if(typeof ZeroAndroid!=='undefined'){
 // ZERO-v25 الأصلي يدير خدمة الخلفية (BgService) تلقائياً بنفسه من دورة حياة
 // Activity (onPause/onResume في MainActivity) — لا يستدعيها index.html هنا؛
 // فعل ذلك سابقاً كان تدخلاً زائداً: يُظهر إشعار "معالجة خلفية" حتى والتطبيق
 // بالواجهة الأمامية. الشاشة تُدار عبر setKeepScreenOn الأصلية (وليس WakeLock الويب)
 // تماماً كما صُمم أصلاً في ZERO-v25 (لتفادي السخونة).
 try{ZeroAndroid.setKeepScreenOn(true);}catch(e){}
 startBGWorker(); // مؤقّت غير محظور أثناء التصغير — تكميلي، لا يتعارض
 // لا WakeLock ولا Service Worker ولا إشعارات متصفح هنا: ZERO-v25 الأصلي يتكفل بذلك
 }else{
 // وضع المتصفح (بدون تطبيق ZERO-v25 الأصلي) — الاعتماد الكامل على آليات الويب
 await reqWL();
 startBGWorker();
 await regSW();
 await reqNotifPerm();
 }
 updBGUI();
 bgLog(' Background systems initialized');
 }
 // ② Storage — restore NN if saved
 if(zeroDB&&NN.trainN===0){
 loadLastWeights().then(restored=>{
 if(restored)stLog(' NN weights restored from previous session');
 });
 }
 const paths=getStoragePaths();
 // Emit startup exec log entry
 logExec({prog:'SYS',lines:[
 `ZERO AI v25 initialized — cycle 0`,
 `Mic: ${(appState.actx.sampleRate/1000).toFixed(0)}kHz · Nyquist: ${(appState.actx.sampleRate/2000).toFixed(0)}kHz`,
 `NN: 16→24→8 · ${NN.trainN} pre-trained · lr=${NN.lr}`,
 `Storage: ${paths.available?paths.internal:'IndexedDB'}`,
 `BG: ${bgEnabled?'ON':'OFF'} · THRESH=${appState.FREQ_THRESH} · Speaker: ZERO sound`,
 `Programs: ${Object.keys(AI_LIB).length} loaded — UCB1 scheduler · META_ADAPT every 80 cycles`,
 `New: FREQ_PREDICT · PATTERN_LEARN · META_ADAPT · UCB1 bandit`,
 `Ready — auto-exec starts next NN cycle`,
 ],ms:0,cycle:0,auto:true});
 // Terminal init
 setTimeout(()=>{
 tLog('SYS',
 `import zero_ai_v25 as ai # sr=${appState.actx?appState.actx.sampleRate:0} nyq=${appState.actx?appState.actx.sampleRate/2:0}`,
 `# Python DSL terminal active · ${Object.keys(AI_LIB).length} programs · UCB1 scheduler · type LIST`);
 },200);
 // Initial analyze after first capture
 setTimeout(()=>{if(appState.isRun){const st=getState();logExec({prog:'ANALYZE',lines:AI_LIB.ANALYZE.run(st),ms:0,auto:true});}},3000);
 return true;
}

/* ══════════════════════════
 LAYER 2: SILENT FREQUENCIES
 ALL inaudible — no audible output
══════════════════════════ */
function startSF(){if(!appState.actx)return;stopSF();const mg=appState.actx.createGain();mg.gain.value=0.12;mg.connect(appState.actx.destination);appState.silOscs._m=mg;updSF();}

function updSF(){
 if(!appState.actx||!appState.silOscs._m)return;
 Object.entries(appState.silOscs).forEach(([k,v])=>{if(k==='_m')return;if(v&&v.stop)try{v.stop(0)}catch(e){}if(v&&v.disconnect)try{v.disconnect()}catch(e){}});
 appState.silOscs={_m:appState.silOscs._m};const mg=appState.silOscs._m;const nyq=appState.actx.sampleRate/2;
 // C7 ✓ Spk-Emittable INF (0.5–19Hz) — Class 7
 if(P.useSF.inf){
 const srcSub=appState.fanFreq>0&&appState.fanFreq<20?[appState.fanFreq/2,appState.fanFreq/3].filter(f=>f>0.5):[];
 [...[1,3,7,10,13,17],...srcSub].forEach((hz,i)=>{const o=appState.actx.createOscillator(),g=appState.actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=appState.iLv*.07;o.connect(g);g.connect(mg);o.start();appState.silOscs['i'+i]=o;appState.silOscs['ig'+i]=g;});
 }
 // C7 ✓ Spk-Emittable ULT (>20kHz to Nyquist) — Class 7
 if(P.useSF.ult){
 [21000,24000,28000,32000,40000,48000,64000,80000].filter(f=>f<nyq).forEach((hz,i)=>{const o=appState.actx.createOscillator(),g=appState.actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=appState.uLv*.05;o.connect(g);g.connect(mg);o.start();appState.silOscs['u'+i]=o;appState.silOscs['ug'+i]=g;});
 }
 // C7 PHF (0.5–19Hz phase field)
 if(P.useSF.phf){
 [0.5,1,2,3,5,6,8,11,14,17,19].forEach((hz,i)=>{const o=appState.actx.createOscillator(),g=appState.actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=appState.pLv*.025;o.connect(g);g.connect(mg);o.start();appState.silOscs['p'+i]=o;appState.silOscs['pg'+i]=g;});
 }
 // C6 ✗ Mic-Invisible SUB (<1Hz) — Class 6 physical effect
 if(P.useSF.sub){
 [0.01,0.05,0.1,0.2,0.35,0.5,0.65,0.8,0.95].forEach((hz,i)=>{const o=appState.actx.createOscillator(),g=appState.actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=appState.bLv*.035;o.connect(g);g.connect(mg);o.start();appState.silOscs['b'+i]=o;appState.silOscs['bg'+i]=g;});
 }
 // Piezoelectric structural
 if(P.useSF.pie){
 [1,2,3,5,8,12,16,19].forEach((hz,i)=>{const o=appState.actx.createOscillator(),g=appState.actx.createGain();o.type=hz<5?'triangle':'sawtooth';o.frequency.value=hz;g.gain.value=appState.eLv*.028;o.connect(g);g.connect(mg);o.start();appState.silOscs['e'+i]=o;appState.silOscs['eg'+i]=g;});
 }
 const nyqK=(nyq/1000).toFixed(0)+'kHz';
 const I=E('pv-if');if(I)I.textContent=P.useSF.inf?'0.5-19Hz':'off';
 const U=E('pv-uf');if(U)U.textContent=P.useSF.ult?'20kHz-'+nyqK:'off';
 const Ph=E('pv-pf');if(Ph)Ph.textContent=P.useSF.phf?(appState.pLv*100).toFixed(0)+'%':'off';
 const S=E('pv-sf');if(S)S.textContent=P.useSF.sub?'0.01-0.95Hz':'off';
}

function stopSF(){Object.entries(appState.silOscs).forEach(([k,v])=>{if(!v)return;if(v.stop)try{v.stop(0)}catch(e){}if(v.disconnect)try{v.disconnect()}catch(e){}});appState.silOscs={};}

/* ══════════════════════════
 LAYER 1: DETECTION
 All 12 algorithms + 8-class classify
══════════════════════════ */
function startDet(){clearInterval(appState.aT);appState.aT=setInterval(detectAll,40);}

function detectAll(){
 if(!appState.ana||!appState.actx)return;
 const td=new Uint8Array(appState.ana.fftSize),fd=new Float32Array(appState.ana.frequencyBinCount);
 appState.ana.getByteTimeDomainData(td);appState.ana.getFloatFrequencyData(fd);
 // ── Software Notch Suppression ── attenuate confirmed freqs in FFT data
 const fdRaw=NOTCH_SUPPRESS.size>0?fd.slice(0):null;
 if(NOTCH_SUPPRESS.size>0){
 const bHz2=appState.actx.sampleRate/appState.ana.fftSize;
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins})=>{
 const bin=Math.round(hz/bHz2);
 for(let i=Math.max(0,bin-halfBins);i<=Math.min(fd.length-1,bin+halfBins);i++){
 const w=1-Math.abs(i-bin)/(halfBins+1);
 fd[i]-=depth*w;
 }
 });
 updateSuppEff(fdRaw);
 }
 const bHz=appState.actx.sampleRate/appState.ana.fftSize,nyq=appState.actx.sampleRate/2,mxB=fd.length-1;

 // ① MUSIC + peak detect — full spectrum
 let pk=-Infinity,pB=2;for(let i=2;i<mxB;i++)if(fd[i]>pk){pk=fd[i];pB=i;}
 if(pB>=2&&pB<fd.length-2){
 const a=fd[pB-1],b=fd[pB],c=fd[pB+1],dv=2*b-a-c;
 // إصلاح جذري لمصدر خلل "NaNHz": getFloatFrequencyData يُرجِع -Infinity لأي خانة FFT
 // ذات طاقة صفرية تماماً — أمر طبيعي جداً لخانة مجاورة هادئة حتى لو كانت القمة b نفسها
 // حقيقية (b=pk قيمة منتهية دائماً بما أنها أعلى قيمة رُصدت). حين يكون أحد الجارين a/c
 // ‎-Infinity‏، ‎(a-c)/(2*dv)‏ يُصبح Infinity/Infinity أو -Infinity/Infinity = NaN، وهذا
 // NaN كان يتسرّب مباشرة إلى hz ثم KF.x[0] ويُسمِّم حالة مرشّح كالمان بشكل دائم (لا شيء
 // كان يتحقّق من isFinite لاحقاً)، فيظهر "NaNHz" في كل مكان يعرض الترددات المحظورة.
 // الإصلاح: أي إزاحة غير منتهية تُهمَل وتُستبدَل بصفر (تُستخدَم خانة القمة الخام بلا
 // تدقيق دون-الخانة، بدل تمرير قيمة فاسدة).
 let _off=dv!==0?(a-c)/(2*dv):0;
 if(!isFinite(_off))_off=0;
 let hz=Math.max(0,(pB+_off)*bHz);
 // مراجعة سادسة ضمن إصلاح "الوميض/التجمّد المؤقت": هذا السطر كان يُنشئ مصفوفة JS
 // عادية جديدة عبر نشر ([...]) نسخة من fd (حتى 4094 عنصراً هنا فعلياً — ana.fftSize=32768
 // يعني frequencyBinCount=16384، وMath.min(mxB,4096) يُثبِّت الحدّ الفعلي عند 4096)، ثم
 // يفرزها بمقارِن JS مخصَّص ((x,y)=>x-y) — فرز O(n log n) لآلاف العناصر مع استدعاء دالة
 // JS لكل مقارنة — فقط لاستخراج الوسيط (median) كمرجع لحساب SNR. يحدث هذا في كل دورة
 // detectAll تقريباً (حتى 25 مرة/ثانية) طوال تشغيل المحرك — أي طوال أغلب وقت الاستخدام
 // الفعلي، بما فيه أثناء أي تنقّل بين القوائم بالتوازي. الإصلاح: fd.slice(...) تُنتج أصلاً
 // Float32Array مستقلة (نسخة، لا تُغيِّر fd الأصلية) — فرزها مباشرة عبر %TypedArray%.sort()
 // بلا مقارِن مخصَّص يُعطي بالضبط نفس الترتيب العددي التصاعدي (الترتيب الافتراضي لمصفوفات
 // الأرقام المكتوبة هو عددي تصاعدي، بخلاف Array.prototype.sort الذي يفترض نصياً افتراضياً)
 // — نفس القيمة العددية للوسيط تماماً بلا أي تغيير في النتيجة أو السلوك — فقط بلا نسخ
 // المصفوفة الوسيطة الزائد وبلا عبء استدعاء دالة JS لكل مقارنة.
 const srt=fd.slice(2,Math.min(mxB,4096)).sort(),snr=pk-srt[Math.floor(srt.length/2)];
 if(snr>12&&(!FREQ_BAND.enabled||hz>=FREQ_BAND.lo&&hz<=FREQ_BAND.hi)){ // Open range; optional band lock
 // ② Kalman filter
 // شفاء ذاتي: إن كانت حالة المرشّح المستمرّة (من دورة سابقة) قد تسمّمت بأي شكل غير
 // متوقَّع (NaN/Infinity)، نصفّرها بدل ترك التسمّم يتكرّر إلى الأبد كل دورة لاحقة.
 if(!isFinite(KF.x[0])||!isFinite(KF.x[1])||!isFinite(KF.P[0])){KF.x=[0,0];KF.P=[1,1];KF.init=false;}
 if(!KF.init){KF.x[0]=hz;KF.init=true;}
 // ① KF×SPEC_FLUX — Flux-Adaptive Process Noise: volatile spectrum → trust prediction less
 if(typeof SPEC_FLUX!=='undefined'&&SPEC_FLUX.val>0.3)KF.Q[0]=Math.min(0.5,0.01+SPEC_FLUX.val*0.15);
 const fP=KF.x[0]+KF.x[1]*.3;KF.P[0]=Math.min(KF.P[0]+KF.Q[0],100);
 const K=KF.P[0]/(KF.P[0]+KF.R);KF.x[0]=fP+K*(hz-fP);KF.x[1]+=K*(hz-fP)*.1;KF.P[0]=(1-K)*KF.P[0];
 appState.fanFreq=KF.x[0];appState.fanE=Math.min(1,(snr+12)/40);
 // تشديد: تردد أساسي محضور (سواء كان من الحضر الافتراضي أو مؤكَّد مسبقاً) لا يُسمح
 // له بأي تصويت حظر، تعب تردد، تنبيه، أو تغذية هارمونيات بعد هذه النقطة في الحلقة
 const fanBanned=AI_GATE.enabled&&AI_BAN.has(fBin(appState.fanFreq));
 if(!fanBanned)detectFreqHop(appState.fanFreq); // تشديد: تردد محضور لا يدخل سجل/تصدير القفزات (FREQ_HOP)
 checkNotchSuggest(appState.fanFreq); // Dev100: smart notch suggestion
 if(!fanBanned)checkFreqAlarms(appState.fanFreq); // Dev110: frequency alarm — لا تنبيه لتردد محضور
 // Dev120: KF Lock — pull KF toward target Hz if enabled
 if(KF_LOCK.enabled){if(Math.abs(KF.x[0]-KF_LOCK.hz)>KF_LOCK.tol){KF.x[0]+=(KF_LOCK.hz-KF.x[0])*0.3;}appState.fanFreq=KF.x[0];}
 // Dev120: REC — capture frame into rolling buffer
 if(REC.active&&appState.fanFreq>1){REC.buf.push({t:Date.now()-REC.startT,hz:+appState.fanFreq.toFixed(2),e:+appState.fanE.toFixed(3),env:curEnvClass,sqi:SQI.val});if(REC.buf.length>REC.maxLen)REC.buf.shift();}
 // Adaptive notch tracking — slide notch center when freq drifts
 adaptNotchTrack(appState.fanFreq);
 // Refresh lastHit for nearby notches (decay tracking)
 if(NOTCH_DECAY.enabled&&NOTCH_SUPPRESS.size){NOTCH_SUPPRESS.forEach(n=>{if(Math.abs(n.hz-appState.fanFreq)<=n.halfBins*bHz*4)n.lastHit=Date.now();});}
 // Bipolar energy update
 if(Math.cos(DRV.phase*Math.PI/180)>0)RANGE.posE=RANGE.posE*.99+appState.fanE*.01;
 else RANGE.negE=RANGE.negE*.99+appState.fanE*.01;
 RANGE.polarityRatio=(RANGE.posE+RANGE.negE>0)?RANGE.posE/(RANGE.posE+RANGE.negE):0.5;
 // Spectral flux
 updateSpecFlux(fd);
 // Zero crossing rate (between SPEC_FLUX and centroid)
 updateZeroCross(td);
 // Crest factor (impulsiveness)
 updateCrest(td);
 // ⑨ ZCRATE×CREST — ZCR-Crest dual-axis signal classifier
 if(!window.ZCREST)window.ZCREST={state:'steady',score:0};
 {const z=ZCRATE.val,c=CREST.val;if(z>0.35&&c>4)ZCREST.state='impulsive';else if(z>0.35&&c<=4)ZCREST.state='noisy';else if(z<=0.35&&c>4)ZCREST.state='click';else ZCREST.state='tonal';ZCREST.score=z*c;}
 // Energy envelope
 updateEnvelope(td);
 // Polarity tracking
 POLAR_HIST.update(appState.fanE);
 // Centroid
 updateCentroid(fd,bHz);
 // Harmonic series detection — تشديد: يُمنع عن تردد محظور، وإلا يبقى HARMONICS.fund/q
 // يحدَّث لتردد محظور ويظهر حرفياً في #harmonic-q كل ~80ms رغم أنه محضور
 if(!fanBanned)detectHarmonicSeries(appState.fanFreq,fd,bHz);
 // ⑧ CENTROID×HARMONICS — Centroid-harmonic tonality flag
 CENTROID.tonal=!!(HARMONICS.series&&HARMONICS.series.some(s=>Math.abs(CENTROID.hz-s.hz)<CENTROID.hz*0.2));
 // ⑦ Harmonic Coherence Map: weight series partials by HNR
 if(!window.HCM)window.HCM={score:0};
 {const hnrN=Math.max(0,Math.min(1,HNR.val/20));let hcS=0,hcN=0;if(HARMONICS.series)HARMONICS.series.forEach(s=>{const b2=Math.round(s.hz/bHz);if(b2>0&&b2<fd.length){hcS+=Math.pow(10,fd[b2]/10)*hnrN;hcN++;}});HCM.score=hcN>0?Math.min(1,hcS/hcN/100):0;}
 // Spectral moments (μ/σ/skew/kurt)
 updateSpectralMoments(fd,bHz);
 // Chroma vector (12 pitch classes)
 updateChromaVec(fd,bHz);
 // ① Tonal-Kalman snap: nudge KF toward nearest confirmed harmonic Hz
 if(KF.init&&HARMONICS.series&&HARMONICS.series.length>0){let minD=Infinity,snapHz=KF.x[0];HARMONICS.series.forEach(s=>{const d=Math.abs(s.hz-KF.x[0]);if(d<minD){minD=d;snapHz=s.hz;}});if(minD<KF.x[0]*.04)KF.x[0]+=(snapHz-KF.x[0])*.06;}
 // AM/FM modulation index
 updateModulation(td);
 // Spectral rolloff 85%
 updateRolloff(fd,bHz);
 // ③ CENTROID×ROLLOFF — Spectral balance ratio: cent/rolloff → bias characterization
 CENTROID.rolloffRatio=ROLLOFF.hz>0?CENTROID.hz/ROLLOFF.hz:0;
 // Spectral flatness (Wiener entropy)
 updateSpectralFlatness(fd);
 // ④ RANGE×SPEC_FLAT — Flatness-driven RANGE bias mode
 if(SPEC_FLAT.val>0.65)RANGE.biasMode='bipolar';else if(SPEC_FLAT.val<0.1)RANGE.biasMode='pos';
 // ⑩ KF×ROLLOFF — Rolloff-constrained KF upper bound
 if(KF.init&&ROLLOFF.hz>0&&KF.x[0]>ROLLOFF.hz*0.9&&SPEC_FLAT.val>0.5){KF.x[0]=ROLLOFF.hz*0.85;appState.fanFreq=KF.x[0];}
 // HNR (harmonic-to-noise ratio)
 updateHNR(fd,bHz);
 // ⑦ MIC×HNR — HNR-synchronized MIC feature profile
 MIC.feat.hnr=HNR.val;
 // Room mode peaks
 detectRoomModes(fd,bHz);
 // ③ Room-Aware MUSIC: mark spectral bins at detected room mode peaks
 // مراجعة "المشروع بالكامل": هذا القسم كان يُخزِّن أرقام خانات FFT الخام
 // (Math.round(hz/bHz)) في RAMUSIC.bins، بينما نقطة الاستهلاك الوحيدة (أدناه، عند
 // "RAMUSIC×castBanVote") تستعلم بمفتاح من نطاق مختلف كلياً: fBin(fanFreq) — وهو تقريب
 // بالهرتز لأقرب 0.5Hz، وهو نطاق المفاتيح المستخدَم في كل مكان آخر بالملف (freqDB،
 // AI_BAN، BAN_VOTE، NOTCH_SUPPRESS...). بما أن bHz (عرض الخانة الفعلي، مثلاً ≈5.38Hz
 // لـ44100Hz/8192 FFT) لا يساوي 0.5 أبداً عملياً، لا يتطابق النطاقان تقريباً إطلاقاً —
 // فحماية "أوضاع الغرفة" من تراكم تصويت الحظر (ban vote) لم تكن تعمل فعلياً لأي تردد
 // حقيقي متوافق مع القمة المكتشفة. الإصلاح: تخزين مفاتيح fBin() بنفس نطاق الاستهلاك.
 if(!window.RAMUSIC)window.RAMUSIC={bins:new Set()};
 if(ROOM_MODES.peaks.length>0){RAMUSIC.bins.clear();ROOM_MODES.peaks.forEach(p=>{RAMUSIC.bins.add(fBin(p.hz));RAMUSIC.bins.add(fBin(p.hz-bHz));RAMUSIC.bins.add(fBin(p.hz+bHz));});}
 // ⑤ RAMUSIC×HARMONICS — Harmonic-extended RAMUSIC protection
 if(HARMONICS.series&&HARMONICS.series.length>0){HARMONICS.series.forEach(s=>{if(s.hz>0&&s.hz<nyq)RAMUSIC.bins.add(fBin(s.hz));});}
 // Environment change detection
 ENV_CHANGE_D.detect(fd);
 // Acoustic signature hash
 updateAcousticSig(fd);
 // Tonal power ratio
 updateTonalRatio(fd,bHz);
 // Frequency fatigue + ban vote — تُعلَّق بالكامل لتردد محضور أساسي (تشديد اكثر)
 if(!fanBanned){
 updateFreqFatigue(appState.fanFreq,appState.fanE);
 castBanVote(appState.fanFreq,'spectral',SPEC_FLAT.val<0.1?2:0.5);
 if(THERMAL.rising)castBanVote(appState.fanFreq,'thermal',1.5);
 if(ANTI_IDLE.avgFrame>50)castBanVote(appState.fanFreq,'lag',1.2);
 // ④ BANVOTE×AI_CTX — high crest factor in context → amplified ban vote
 if(AI_CTX.crestFactor>3)castBanVote(appState.fanFreq,'ctx',Math.min(2.5,(AI_CTX.crestFactor-3)*0.3+0.5));
 // ⑩ BANVOTE×FREQ_CLUSTER — freq inside a dense cluster → amplified ban vote
 {const inClust=FREQ_CLUSTER.groups.some(g=>appState.fanFreq>=g.min&&appState.fanFreq<=g.max&&g.count>2);if(inClust)castBanVote(appState.fanFreq,'cluster',1.8);}
 }
 // ⑨ RAMUSIC×castBanVote — room-mode protected bin → decay accumulated ban score
 {const rbk=fBin(appState.fanFreq);if(RAMUSIC.bins.has(rbk)){const bv=BAN_VOTE.get(rbk);if(bv)bv.total=Math.max(0,bv.total*0.45);}}
 // Recurrence
 updateRecurrence(appState.fanFreq);
 // ⑤ PITCH_AMDF×RECURRENCE — Pitch-Recurrence Validation: pitch aligned with fan → boost det
 if(PITCH_AMDF.hz>10&&RECURRENCE.period>0&&RECURRENCE.det>0.3){const pitchBin=fBin(PITCH_AMDF.hz);const fanBin=fBin(appState.fanFreq);if(Math.abs(pitchBin-fanBin)<3)RECURRENCE.det=Math.min(1,RECURRENCE.det*1.15);}
 // ③ HNR×HEBBIAN — HNR-Weighted Hebbian Reward: clean tone → stronger reinforcement
 if(PITCH_AMDF.hz>10){const hnrW=Math.max(0.1,Math.min(3,1+HNR.val/20));hebbLearn(appState.fanFreq,PITCH_AMDF.hz,(appState.loopE/100)*hnrW);}
 // Frame time tracker for anti-idle
 const _ft=performance.now()-ANTI_IDLE.lastFrame;
 if(ANTI_IDLE.lastFrame>0)ANTI_IDLE.frameTimes.push(_ft);
 ANTI_IDLE.lastFrame=performance.now();
 if(ANTI_IDLE.frameTimes.length>30)ANTI_IDLE.frameTimes.shift();
 if(ANTI_IDLE.frameTimes.length>3){ANTI_IDLE.avgFrame=ANTI_IDLE.frameTimes.reduce((a,b)=>a+b,0)/ANTI_IDLE.frameTimes.length;}
 // Sluggishness monitor
 monitorSlugFreqs();
 // Auto-ban harmful/noisy freqs immediately on detection
 autoDetectAndBan(appState.fanFreq,appState.fanE);
 // Record to FreqDB (skipped if just auto-banned) — NN learns
 fRecord(appState.fanFreq,appState.fanE);
 // ④ ROLLOFF×FreqDB — Rolloff-Contextual FreqDB tagging: above=broadband, below=tonal
 if(ROLLOFF.hz>0){const b=fBin(appState.fanFreq);if(freqDB.has(b)){const e=freqDB.get(b);if(!e.rolloffCtx||appState.aiCyc%50===0)e.rolloffCtx=appState.fanFreq>ROLLOFF.hz?'above':'below';}}
 // تردد محضور (أساسي أو جديد، سيّان) لا يُسمح له بالتكرار عند كل التقاط جديد من لاقطة
 // الصوت — يُستبعد كلياً من التصنيف (C1-C16) هنا تماماً كما استُبعد أعلاه من FreqDB
 // ومن بناء الإبطال الصوتي (buildInverse)؛ فقط trackPostBanDetection (داخل fRecord)
 // يتابعه بصمت للتحقق من فعالية الحظر، دون أي ظهور جديد في أي قائمة أو عدّاد.
 const hzBanned=AI_GATE.enabled&&AI_BAN.has(fBin(hz));
 if(!hzBanned){
 // 8-class classification
 const ph=DRV.phase*Math.PI/180;const cls=classifyFreq(hz,appState.fanE*(appState.fanE>0?1:-1),ph,nyq);
 if(freqDB.has(fBin(hz)))freqDB.get(fBin(hz)).class=cls;
 // ⑥ FC×PITCH_AMDF — Pitch-confirmed C5 counter boost
 if(PITCH_AMDF.conf>0.5&&Math.abs(hz-PITCH_AMDF.hz)<hz*0.04){FC.c5++;}
 }
 // ⑦ HARMONICS×FreqDB — Harmonic series FreqDB seeding (2nd–4th partial)
 // تشديد: إذا كان التردد الأساسي (fanFreq) نفسه محضوراً، فهارمونياته لا تُغذّي FreqDB
 // ولا الإبطال الصوتي — يمنع تسرّب صوت تردد محضور عبر تردداته التوافقية على منفذ آخر
 if(!fanBanned&&HARMONICS.series&&HARMONICS.series.length>1){HARMONICS.series.slice(1,4).forEach(s=>{if(s.amp>0.01)fRecord(s.hz,s.amp*appState.fanE*0.3);});}
 const mhzEl=E('mHz');if(mhzEl)mhzEl.textContent=appState.fanFreq.toFixed(1)+'Hz';
 const mu=E('pv-mu');if(mu)mu.textContent=appState.fanFreq.toFixed(3)+'Hz';
 const ka=E('pv-ka');if(ka)ka.textContent=KF.x[0].toFixed(2)+'Hz';
 }else{appState.fanE=Math.max(0,appState.fanE-.05);}
 }
 // Dev100: multi-peak scan (runs every detectAll frame, ~40ms)
 scanPeaks(fd,bHz,mxB);
 // Dev110: octave band power + store FFT frame for DELTA
 updateBandPower(fd,bHz);
 if(!lastFFD||lastFFD.length!==fd.length)lastFFD=new Float32Array(fd.length);
 lastFFD.set(fd);SPEC_DELTA.bHz=bHz;
 // ③ Hilbert
 // مراجعة "النسخة النهائية": prevX كانت تُعاد كتابتها كل تكرار إلى نفس القيمة الثابتة
 // (td[td.length-1]، آخر عيّنة في المخزن) بدل العيّنة السابقة الفعلية — فتنهار الحلقة كاملة
 // إلى مقارنة واحدة بين آخر عيّنتين فقط، محسوبة بتكرار عبثي في كل خطوة سابقة، بدل تقدير طور
 // Hilbert التراكمي عبر الإطار كما يوحي شكل الحلقة — يُضعِف دقة "Phase-Coherence Polar" بصمت.
 for(let k=1;k<td.length-1;k++){const x=(td[k]-128)/128;if(x&&appState.prevX)appState.hlPh=Math.atan2(x,appState.prevX);appState.prevX=x;}
 // ⑧ Phase-Coherence Polar: Hilbert phase angle accumulated into 8-sector histogram
 if(!window.PCPOLAR)window.PCPOLAR={hist:new Float32Array(8)};
 {const pSec=Math.floor(((appState.hlPh+Math.PI)/(2*Math.PI))*8)%8;PCPOLAR.hist[pSec]=PCPOLAR.hist[pSec]*.98+appState.fanE*.02;}
 // ④ Fx-LMS C(z)
 const fi=(td[Math.floor(td.length/2)]-128)/128;for(let j=FX_N-1;j>0;j--)appState.fxXb[j]=appState.fxXb[j-1];appState.fxXb[0]=fi;let fY=0;for(let j=0;j<FX_N;j++)fY+=appState.fxW[j]*appState.fxXb[j];const er=fi+fY;let xN=1e-6;for(let j=0;j<FX_N;j++)xN+=appState.fxXb[j]*appState.fxXb[j];const fxMu=P.mu*(0.5+Math.max(0,Math.min(1,HNR.val/20)))/xN;for(let j=0;j<FX_N;j++){appState.fxW[j]-=fxMu*er*appState.fxXb[j];appState.fxW[j]=Math.max(-2,Math.min(2,appState.fxW[j]));}appState.fxMSE=appState.fxMSE*.997+er*er*.003;
 // ② FxLMS×FreqDB — confirmed interference freq → extra LMS convergence step
 {const fb2=fBin(appState.fanFreq);if(freqDB.has(fb2)&&(freqDB.get(fb2).confirmed||0)>2){const exMu=P.mu*0.4/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){appState.fxW[j]-=exMu*er*appState.fxXb[j];appState.fxW[j]=Math.max(-2,Math.min(2,appState.fxW[j]));}}}
 // ⑨ FxLMS×RECURRENCE — recurrent freq → extra LMS pass for faster cancellation
 if(RECURRENCE.det>0.5&&RECURRENCE.period>0&&Math.abs(appState.fanFreq-RECURRENCE.period*bHz)<appState.fanFreq*0.1){const rbMu=fxMu*Math.min(0.5,RECURRENCE.det*0.6);for(let j=0;j<FX_N;j++){appState.fxW[j]-=rbMu*er*appState.fxXb[j];appState.fxW[j]=Math.max(-2,Math.min(2,appState.fxW[j]));}}
 // ② CENTROID×FxLMS — spectral centroid brightness → scaled extra LMS convergence
 {const cS=Math.min(1.5,1+CENTROID.hz/(nyq||8000));const cMu=P.mu*cS*0.12/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){appState.fxW[j]-=cMu*er*appState.fxXb[j];appState.fxW[j]=Math.max(-2,Math.min(2,appState.fxW[j]));}}
 // ⑧ DRV×FxLMS — dominant Bayesian sound weight → extra convergence pass
 if(DRV.wS>0.55){const dMu=P.mu*(DRV.wS-0.5)*0.4/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){appState.fxW[j]-=dMu*er*appState.fxXb[j];appState.fxW[j]=Math.max(-2,Math.min(2,appState.fxW[j]));}}
 // ⑤ EVP (0–40Hz)
 if(P.useEVP){const eM=Math.min(Math.ceil(40/bHz),fd.length-1);let eS=0,eC=0,ePk=-Infinity,ePB=1;for(let i=1;i<eM;i++){const p2=Math.pow(10,fd[i]/10);eS+=p2;eC++;if(fd[i]>ePk){ePk=fd[i];ePB=i;}}appState.evpE=Math.min(1,Math.sqrt(eC>0?eS/eC:0)/10);appState.evpHz=ePB*bHz;if(appState.evpE>.05)fRecord(appState.evpHz,appState.evpE*.5);const ep=E('pv-evp');if(ep)ep.textContent=(appState.evpE*100).toFixed(0)+'%@'+appState.evpHz.toFixed(1)+'Hz';}
 // ⑤ MIC×EVP — MIC HNR feature → EVP energy amplification for tonal infrasound
 if(typeof MIC!=='undefined'&&MIC.feat&&MIC.feat.hnr>0.5)appState.evpE=Math.min(1,appState.evpE*(1+MIC.feat.hnr*0.25));
 // ⑩ Infrasonic Carrier Detector: find dominant 0–4Hz sub-carrier bin
 if(!window.ICD)window.ICD={detected:false,hz:0,strength:0};
 if(bHz>0){const iM=Math.max(2,Math.ceil(4/bHz));let iMax=-Infinity,iBin=1;for(let i=1;i<Math.min(iM,fd.length-1);i++){if(fd[i]>iMax){iMax=fd[i];iBin=i;}}ICD.hz=iBin*bHz;ICD.strength=Math.min(1,Math.pow(10,iMax/10)/50);ICD.detected=ICD.strength>.15;}
 // ⑥ EMF (50/60Hz harmonics)
 if(P.useEMF){let emS=0,emN=0;[50,60].forEach(base=>{for(let h=1;base*h<nyq&&base*h<20000;h++){const b2=Math.round((base*h)/bHz);if(b2<fd.length){emS+=Math.pow(10,fd[b2]/10);emN++;}}});appState.emfE=Math.min(1,Math.sqrt(emN>0?emS/emN:0)/20);const em=E('pv-emf');if(em)em.textContent=(appState.emfE*100).toFixed(1)+'%';}
 // ⑦ EMF×FREQ_CLUSTER — flag frequency clusters that overlap 50/60Hz harmonics (EMF interference zone)
 if(!window.EMF_CLUST_FLAG)window.EMF_CLUST_FLAG=new Set();
 EMF_CLUST_FLAG.clear();[50,60].forEach(base=>{for(let h=1;base*h<nyq;h++){const hHz=base*h;FREQ_CLUSTER.groups.forEach((g,idx)=>{if(hHz>=g.min&&hHz<=g.max)EMF_CLUST_FLAG.add(idx);});}});
 // ⑦ HCM×EMF — high harmonic content score → amplify EMF detection energy
 if(typeof HCM!=='undefined'&&HCM.score>0.4)appState.emfE=Math.min(1,appState.emfE*(1+HCM.score*0.5));
 // ④ Shape-Adaptive Wiener: tune α/β dynamically from spectral flatness
 {const sf=SPEC_FLAT.val;P.alpha=Math.max(0.8,Math.min(3.0,1.5+(1-sf)*.5));P.beta=Math.max(0.005,Math.min(0.05,0.01+sf*.04));}
 // ① WIEN×NN — NN-Loss-Adaptive Wiener α: high training loss → more aggressive suppression
 if(typeof NN!=='undefined'&&NN.loss>0.5)P.alpha=Math.min(3.5,P.alpha*(1+NN.loss*0.2));
 // ④ RANGE×Wiener — RANGE polarity mode → Wiener floor-leak β fine-tuning
 if(RANGE.biasMode==='pos')P.beta=Math.max(0.005,P.beta*0.88);else if(RANGE.biasMode==='bipolar')P.beta=Math.min(0.05,P.beta*1.12);
 // ⑦ Wiener — full spectrum
 const nB=fd.length-1;let fNum=0,fDen=0;for(let i=5;i<nB;i++){const p2=Math.pow(10,fd[i]/10);fNum+=Math.log(p2+1e-10);fDen+=p2;}const gM=Math.exp(fNum/nB),aM=fDen/nB;appState.noiseE=Math.min(1,Math.max(0,(aM>0?gM/aM:0)*3));if(!appState.nFloor||appState.nFloor.length!==nB)appState.nFloor=new Float32Array(nB);for(let i=0;i<nB;i++)appState.nFloor[i]=appState.nFloor[i]*.97+Math.pow(10,fd[i]/10)*.03;let wG=0;for(let i=5;i<nB;i++){const X=Math.pow(10,fd[i]/10),N=appState.nFloor[i],s=Math.max(P.beta*N,X-P.alpha*N);wG+=X>0?Math.sqrt(s/X):P.beta;}wG/=nB;const wi=E('pv-wi');if(wi)wi.textContent=wG.toFixed(3);
 // ① KF×Wiener — KF-refined frequency → extra nFloor accumulation at tracked bin
 if(KF.init&&KF.x[0]>0&&appState.nFloor){const kb=Math.min(Math.round(KF.x[0]/bHz),appState.nFloor.length-1);if(kb>0)appState.nFloor[kb]=appState.nFloor[kb]*.93+Math.pow(10,fd[Math.min(kb,fd.length-1)]/10)*.07;}
 // ⑧ Transient z-score — full spectrum
 let rms=0;for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;rms+=v*v;}rms=Math.sqrt(rms/td.length);const z=(rms-0.05)/Math.max(0.02,.001);appState.sharpE=Math.min(1,Math.max(0,z/10));const tz=E('pv-tz');if(tz)tz.textContent=z.toFixed(2)+'σ';
 // ⑥ Dual-Gate Transient: z-score × HNR classify impulse / semi / steady
 if(!window.DGTC)window.DGTC={gate:0,cls:'steady'};
 {if(z>3&&HNR.val<5){DGTC.gate=1;DGTC.cls='impulse';}else if(z>1.5&&appState.sharpE>.4){DGTC.gate=.5;DGTC.cls='semi';}else{DGTC.gate=0;DGTC.cls='steady';}}
 // ③ DGTC×RECURRENCE — recurrence-confirmed periodic impulse → upgrade semi→impulse
 if(DGTC.cls==='semi'&&RECURRENCE.det>0.5&&RECURRENCE.period>0){DGTC.gate=1;DGTC.cls='impulse';}
 // ③ CREST×DGTC — high crest factor confirms DGTC impulse gate upgrade
 if(DGTC.cls==='semi'&&CREST.val>5){DGTC.gate=1;DGTC.cls='impulse';}
 // Extract features for NN
 extractFeat(td,fd,bHz);
 // ⑥ EVP×UCB1 — UCB1 top-ranked program → boost its corresponding NN input feature
 {const topProg=AI_CTX.rankedProgs&&AI_CTX.rankedProgs[0];if(topProg&&typeof NN!=='undefined'&&Array.isArray(NN.inp)&&NN.inp.length>0){const pIdx=AI_LIB.findIndex(p=>p.name===topProg);if(pIdx>=0&&pIdx<NN.inp.length)NN.inp[pIdx]=Math.min(1,NN.inp[pIdx]*1.1);}}
 // Periodic DB purge
 if(appState.aiCyc%20===0){fPurge();updateOctaveDensity();if(appState.aiCyc%60===0)BAN_PATTERNS.detect();} // Periodic: cluster update, AMDF pitch, timing drift, cluster
 if(appState.aiCyc%300===0){PERSIST.saveBans();PERSIST.saveZones();PERSIST.scheduleNNSave();PERSIST.saveFC();PERSIST.saveRoomModes();PERSIST.saveWienerNF();} // حفظ دوري كل 300 دورة (تشديد: أُضيف saveZones كشبكة أمان إضافية فوق الحفظ المؤجَّل)
 // ⑤ INV×HEBBIAN — Hebbian co-activation → shorten INV.verMs for faster verification
 if(INV.active.size>0&&HEBBIAN.size>0){let maxH=0;HEBBIAN.forEach((v,k)=>{if(v>maxH){const p=k.split(':');if(Math.abs(parseFloat(p[0])-appState.fanFreq)<100||Math.abs(parseFloat(p[1])-appState.fanFreq)<100)maxH=v;}});if(maxH>0.8)INV.verMs=Math.max(250,INV.verMs-20);}
 // ⑥ ZCRATE×INV — noisy/percussive signal (high ZCR) → shorten INV verification delay
 if(ZCRATE.val>0.3&&INV.active.size>0)INV.verMs=Math.max(200,INV.verMs-Math.round(ZCRATE.val*60));
 // ⑩ FC×INV — highly confirmed FreqDB entry → accelerate INV.verMs further
 {const fck=fBin(appState.fanFreq);if(freqDB.has(fck)&&(freqDB.get(fck).confirmed||0)>5)INV.verMs=Math.max(200,INV.verMs-25);}
 if(appState.aiCyc%25===0){updateFreqClusters();}
 if(appState.aiCyc%40===0){updatePitchAMDF(td);}
 // ⑨ Pitch-Guided Delay: set CL delay to half pitch period for phase-cancel alignment
 if(!window.PGD)window.PGD={delayMs:5};
 if(PITCH_AMDF.hz>10&&PITCH_AMDF.conf>.3)PGD.delayMs=Math.min(25,500/PITCH_AMDF.hz);
 updateTimingDrift();
 if(appState.aiCyc%15===0)updateTD(appState.loopE/100,appState.silSc);
 if(appState.aiCyc%100===0)updateWtHist();
 // Environmental fingerprint update
 updateEnvFingerprint(fd,bHz);
 // Internal load fingerprint
 if(appState.aiCyc%10===0)updateInternalLoad();
 // Adaptive FFT (between-idea feature)
 if(appState.aiCyc%30===0)adaptFFT();
 // Update 16-class display
 update16Class(nyq);
}

function update16Class(nyq){
 const counts={c1:0,c2:0,c3:0,c4:0,c5:0,c6:0,c7:0,c8:0,c9:0,c10:0,c11:0,c12:0,c13:0,c14:0,c15:0,c16:0};
 freqDB.forEach(e=>{
 const hz=Math.abs(e.hz||0);
 if(hz<0.01)counts.c9++;
 else if(hz<20)counts.c10++;
 else if(hz>=20000&&hz<200000)counts.c11++;
 else if(hz>=200000)counts.c12++;
 else if(HARMONICS.series.some(s=>Math.abs(s.hz-hz)<hz*0.02))counts.c13++;
 else if(THERMAL.correlFreqs.has(fBin(e.hz)))counts.c14++;
 else if(ANTI_IDLE.lagFreqs.has(fBin(e.hz)))counts.c15++;
 else if(ENV_FP.bgFreqs.has(fBin(e.hz)))counts.c16++;
 else if(hz>=20&&hz<=nyq/2)counts.c5++;
 else if(hz<1||hz>nyq)counts.c6++;
 else if(hz>=0.01&&hz<=nyq)counts.c7++;
 else counts.c8++;
 if(e.energy>0)counts.c1++;else counts.c2++;
 });
 const setFC=(id,val,suf='')=>{const el=E(id);if(el)el.textContent=val+suf;};
 // Original 8-class display (backward compat)
 for(let i=1;i<=8;i++){setFC('fc'+i,counts['c'+i]);setFC('c'+i+'v',counts['c'+i]);}
 // New classes 9-16
 for(let i=9;i<=16;i++){setFC('fc'+i,counts['c'+i]);setFC('c'+i+'v',counts['c'+i]);}
 // Bipolar ratio display
 const bpv=E('bipolar-ratio');if(bpv)bpv.textContent=(RANGE.polarityRatio*100).toFixed(0)+'% pos / '+(( 1-RANGE.polarityRatio)*100).toFixed(0)+'% neg';
}

/* Coherence */
function updCoh(tS,tR){
 if(!appState.actx)return;const sr=appState.actx.sampleRate,N=Math.min(tS.length,1024);let avg=0,vc=0;
 COH_F.forEach((freq,fi)=>{
 if(freq>sr/2){const fl=E('cmf-'+fi);if(fl)fl.style.width='0%';const vl=E('cmv-'+fi);if(vl)vl.textContent='n/a';return;}
 const k=Math.round(freq/sr*N),w=2*Math.PI*k/N,cW=Math.cos(w);let s1x=0,s2x=0,s1y=0,s2y=0;
 for(let n=0;n<N;n++){const xn=(tS[n]-128)/128,yn=(tR[n]-128)/128;const nx=cW*s1x-s2x+xn;s2x=s1x;s1x=nx;const ny=cW*s1y-s2y+yn;s2y=s1y;s1y=ny;}
 const Pxx=Math.abs(s1x*s1x+s2x*s2x-cW*s1x*s2x),Pyy=Math.abs(s1y*s1y+s2y*s2y-cW*s1y*s2y);
 cSxx[fi]=cSxx[fi]*.88+Pxx*.12;cSyy[fi]=cSyy[fi]*.88+Pyy*.12;cSxy[fi]=cSxy[fi]*.88+Math.sqrt(Pxx*Pyy)*.12;
 const d=cSxx[fi]*cSyy[fi],coh=d>1e-14?Math.min(1,(cSxy[fi]*cSxy[fi])/d):0;cV[fi]=cV[fi]*.75+coh*.25;
 const sfB=Math.min(0.35,(appState.iLv+appState.uLv+appState.pLv+appState.bLv+appState.eLv)*.1);const cancel=Math.max(0,Math.min(1,1-cV[fi]+sfB));avg+=cancel;vc++;
 const fl=E('cmf-'+fi);if(fl){fl.style.width=(cancel*100)+'%';fl.style.background=cancel>.8?'#a9a9a9':cancel>.5?'#959595':'#787878';}
 const vl=E('cmv-'+fi);if(vl)vl.textContent=(cancel*100).toFixed(0)+'%';
 });
 if(vc>0)avg/=vc;appState.silSc=Math.round(avg*100);
 const mc=E('mCoh');if(mc)mc.textContent=(avg*100).toFixed(0)+'%';const ms=E('pv-coh');if(ms)ms.textContent=(avg*100).toFixed(1)+'%';
}

/* Closed Loop */
function startCL(){
 clearInterval(appState.cT);
 appState.cT=setInterval(()=>{
 if(!appState.isRun||!appState.ana)return;appState.loopN++;
 const td=new Uint8Array(appState.ana.fftSize);appState.ana.getByteTimeDomainData(td);
 let rms=0;for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;rms+=v*v;}rms=Math.sqrt(rms/td.length);
 appState.loopE=rms;const lr=appState.prevLE>0?(appState.prevLE-appState.loopE)/appState.prevLE:0;appState.prevLE=appState.loopE;
 // Adaptive SF boost via closed loop
 if(appState.loopE>.06){appState.iLv=Math.min(1,appState.iLv*1.008);appState.uLv=Math.min(1,appState.uLv*1.008);appState.pLv=Math.min(1,appState.pLv*1.008);}
 // ⑤ Flux-Triggered CL Reset: spectral flux spike + low energy → reset Kalman + soften levels
 if(SPEC_FLUX.val>.6&&appState.loopE<.03&&KF.init){KF.x[0]=appState.fanFreq;KF.P[0]=10;KF.x[1]=0;appState.iLv=Math.max(.2,appState.iLv*.85);}
 if(appState.loopN%12===0)updSF();
 // Bayesian weights
 const tot=appState.fanE+appState.noiseE+appState.sharpE+appState.evpE+appState.emfE+.001;
 DRV.wS=(appState.fanE+appState.noiseE+appState.sharpE)/tot;DRV.wE=P.useEVP?appState.evpE/tot:0;DRV.wM=P.useEMF?appState.emfE/tot:0;
 const ws=DRV.wS+DRV.wE+DRV.wM||1;DRV.wS/=ws;DRV.wE/=ws;DRV.wM/=ws;
 // ② DRV×CHROMA_VEC — Chroma-Guided Bayesian Weight: tonal confidence → boost spectral weight
 if(typeof CHROMA_VEC!=='undefined'&&CHROMA_VEC.conf>0.75){DRV.wS=Math.min(0.7,DRV.wS*1.05);const ws2=DRV.wS+DRV.wE+DRV.wM||1;DRV.wS/=ws2;DRV.wE/=ws2;DRV.wM/=ws2;}
 const w1=E('pv-w1'),w2=E('pv-w2'),w3=E('pv-w3');
 if(w1)w1.textContent=(DRV.wS*100).toFixed(0)+'%';if(w2)w2.textContent=(DRV.wE*100).toFixed(0)+'%';if(w3)w3.textContent=(DRV.wM*100).toFixed(0)+'%';
 appState.aiCon=Math.min(100,Math.round(appState.silSc*.7+Math.min(appState.learnN*4,20)+Math.max(0,100-appState.loopE*500)*.1));
 // Update Android BG service notification every 10 loops
 if(appState.loopN%33===0)renderBanList(); // update ban list every ~2s
 if(appState.loopN%10===0&&typeof ZeroAndroid!=='undefined')
 ZeroAndroid.updateBGStatus('Silence:'+appState.silSc+'% · Cycle:'+appState.aiCyc+' · FreqDB:'+freqDB.size);
 const cb2=E('confB');if(cb2){cb2.style.width=appState.aiCon+'%';cb2.style.background=appState.aiCon>80?'#a9a9a9':appState.aiCon>50?'#959595':'#787878';}
 const ms2=E('mSil');if(ms2)ms2.textContent=appState.silSc+'%';
 const lp=E('pv-lp');if(lp)lp.textContent=appState.loopN;const le=E('pv-le');if(le)le.textContent=(appState.loopE*100).toFixed(2)+'%';
 if(appState.silSc>=80&&appState.isRun){setS('zero');const st=E('sTit');if(st)st.textContent='Silence Achieved';const si2=E('siD');if(si2)si2.className='si-d sil';const sit=E('siT');if(sit)sit.textContent='Silent field stable — ZERO audible output';}
 // Update pipeline NN stats
 const pnntc=E('pv-tc');if(pnntc)pnntc.textContent=NN.trainN;
 const pnnls=E('pv-ls');if(pnnls)pnnls.textContent=NN.loss.toFixed(4);
 const pnndb=E('pv-db');if(pnndb)pnndb.textContent=freqDB.size;
 const pnniv=E('pv-iv');if(pnniv)pnniv.textContent=INV.active.size;
 const pco=E('pv-co');if(pco)pco.textContent=freqFile.totalConf;
 const pca=E('pv-ca');if(pca)pca.textContent=freqFile.totalCanc;
 const pas=E('pv-as');if(pas)pas.textContent=INV.failed.size;
 const psi2=E('ps-nn');if(psi2){psi2.textContent=NN.trainN>0?'ACTIVE':'IDLE';psi2.className='pls '+(NN.trainN>0?'run':'');}
 const pinv=E('ps-inv');if(pinv){pinv.textContent=INV.active.size>0?'ACTIVE':'IDLE';pinv.className='pls '+(INV.active.size>0?'inv':'');}
 },60);
}

/* NN Cycle */
function startNN(){clearInterval(appState.nnT);appState.nnT=setInterval(()=>{
 if(!appState.isRun||!NN.w1)return;
 appState.aiCyc++;
 if(appState.aiCyc%100===0)saveFreqDB();
 if(appState.aiCyc%2===0)pushFreqHist();
 if(appState.aiCyc%50===0)classifyEnvironment();
 const inp=nnInp();
 const{out}=nnFwd(inp);
 nnCtrlSF(out);
 const rw=appState.silSc>50?(appState.silSc-50)/50:-0.1;
 if(appState.aiCyc%4===0)nnTrain(inp,rw);
 updateNNUI();
 // AI EXEC autonomous cycle (runs program library)
 aiExecCycle();
 // Update EXEC UI stat bar
 updateExecUI();
 // Update asC/asT (now used for exec cycle)
 // execCycLbl updated by updateExecUI()
 const mc=E('mCyc');if(mc)mc.textContent=appState.aiCyc;
 const sc=E('cSc');if(sc)sc.textContent=appState.silSc+'%';
 const cst=E('cSt');if(cst)cst.textContent=appState.silSc>=80?'γ²→0':'loop '+appState.loopN;
},80);}

/* Self-Learn */
function startLearn(){clearInterval(appState.lT);appState.lT=setInterval(()=>{
 if(!appState.isRun||!P.useLearn)return;
 const reward=appState.loopE/100;
 // Push current state to replay buffer
 if(NN.w1)erPush(nnInp(),reward,appState.silSc);
 // Replay mini-batch
 const batch=erSample();
 for(const s of batch){try{nnTrain(s.inp,s.reward);}catch(e){}}
 if(appState.silSc>appState.bestSil){appState.bestSil=appState.silSc;appState.learnN++;logNN(' New best: '+appState.bestSil+'% silence (pattern #'+appState.learnN+')');}
},500);}

/* ══ DRAW LOOP ══ */
// مراجعة خامسة ضمن إصلاح "الوميض/التجمّد المؤقت": drawLoop تعمل عند 60 إطاراً/ثانية
// طوال تشغيل المحرك فعلياً (isRun) — أي طوال أغلب وقت استخدام تطبيق ANC حقيقةً، بما
// في ذلك أثناء تصفّح القوائم بالتوازي. كانت تُخصِّص Uint8Array جديدة بالكامل (new
// Uint8Array(ana.fftSize)) في كل إطار من الصفر بدل إعادة استخدام مصفوفة واحدة ثابتة —
// نفايات ذاكرة (garbage) مستمرة يجمعها محرك V8 دورياً عبر GC، وقد يتزامن توقّف GC
// قصير هذا تماماً مع لحظة تفاعل المستخدم (فتح قائمة)، فيظهر كـ"توقف مفاجئ ثم استكمال"
// بالضبط كما وُصفت المشكلة. تحقّق دقيق قبل التعديل: تأكَّدت أن كل مستهلكي `td` هنا
// (updCoh عبر sfEff، drawOrb، updateLevelMeter) يقرؤون قيمها فوراً ولا يحتفظ أيّ منهم
// بمرجع المصفوفة نفسها لاحقاً — فإعادة استخدام مخزن واحد ثابت هنا آمنة تماماً. بالمقابل
// تُرِكت `fd8` أدناه (طيف السبيكتروجرام) دون تغيير عمداً — pushSpecFrame() تُخزِّن مرجع
// المصفوفة نفسها داخل specHistory للرسم التاريخي لاحقاً، فإعادة استخدام نفس المخزن هناك
// كانت ستُفسِد كل الصفوف المخزَّنة سابقاً بصمت (تصبح جميعها نفس القيم الأخيرة) — خطأ حقيقي
// كان سيُستبدَل بمكسب أداء افتراضي، فتُرِك ذلك الموضع كما هو تحديداً لهذا السبب.
let _drawLoopTD=null;
function drawLoop(){
 if(!appState.isRun){appState.drawId=null;return;}
 appState.drawId=requestAnimationFrame(drawLoop);
 if(!appState.ana)return;
 if(!_drawLoopTD||_drawLoopTD.length!==appState.ana.fftSize)_drawLoopTD=new Uint8Array(appState.ana.fftSize);
 const td=_drawLoopTD;
 appState.ana.getByteTimeDomainData(td);
 updCoh(td,sfEff(td));
 drawOrb(td);
 updateLevelMeter(td);
 // Spectrogram frame — push every ~4th frame for performance
 if(appState.drawId%4===0||specHistory.length===0){
 const fd8=new Uint8Array(appState.ana.frequencyBinCount);
 appState.ana.getByteFrequencyData(fd8);
 pushSpecFrame(fd8);
 }
 if(curTab===0){drawMiniSpec();drawFreqTimeline();}
}

// تتمة الملاحظة أعلاه: sfEff() تُستدعى من drawLoop (~60/ثانية) ومن physDrawLoop
// (12-session-features-extra.js، ~60/ثانية أيضاً أثناء فتح لوحة الفيزياء) — تحقّقت من
// كلا الاستدعاءين: updCoh() تقرأ القيم فوراً، physDrawWave()/حساب rms يقرآن ويرسمان
// فوراً أيضاً — لا أحد يحتفظ بمرجع النتيجة، فإعادة استخدام مخزن واحد ثابت هنا آمنة.
let _sfEffBuf=null;
function sfEff(data){
 if(!_sfEffBuf||_sfEffBuf.length!==data.length)_sfEffBuf=new Uint8Array(data.length);
 const r=_sfEffBuf;
 const ef=Math.max(0.05,(appState.iLv*.28+appState.uLv*.32+appState.pLv*.28));
 for(let i=0;i<data.length;i++){const o=(data[i]-128)/128;r[i]=Math.max(0,Math.min(255,128+o*(1-ef)*128));}
 return r;
}

function drawOrb(td){
 const cv=E('orbCv');if(!cv)return;const dpr=window.devicePixelRatio||1;const sz=190;cv.width=sz*dpr;cv.height=sz*dpr;
 const ctx=cv.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,sz,sz);
 const cx=sz/2,cy=sz/2,R=cx-10,sc=appState.silSc/100;
 // Waveform
 ctx.beginPath();for(let i=0;i<=80;i++){const a=(i/80)*Math.PI*2-Math.PI/2;const v=(td[Math.floor((i/80)*td.length)]-128)/128;const r=R-8+v*9;ctx.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);}
 ctx.strokeStyle=appState.silSc>80?`rgba(169,169,169,${0.1+sc*.15})`:appState.isOn?`rgba(129,129,129,${0.1+sc*.12})`:`rgba(123,123,123,.08)`;ctx.lineWidth=1.2;ctx.closePath();ctx.stroke();
 // Silence arc
 ctx.beginPath();ctx.arc(cx,cy,R,-Math.PI/2,-Math.PI/2+sc*Math.PI*2);ctx.strokeStyle=appState.silSc>80?'rgba(169,169,169,.6)':appState.isOn?'rgba(129,129,129,.55)':'rgba(123,123,123,.55)';ctx.lineWidth=2.5;ctx.lineCap='round';ctx.stroke();
 // Class arcs
 const nyq2=appState.actx?appState.actx.sampleRate/2:24000;let c5cnt=0,c7cnt=0;freqDB.forEach(e=>{if(e.hz>=20&&e.hz<=nyq2/2)c5cnt++;if(e.hz>=0.01&&e.hz<=nyq2)c7cnt++;});
 [{c:'rgba(149,149,149,.4)',v:Math.min(c5cnt/20,1),r:R+4},{c:'rgba(165,165,165,.35)',v:Math.min(c7cnt/20,1),r:R+8},{c:'rgba(120,120,120,.4)',v:appState.iLv,r:R-20}].forEach(a=>{if(a.v<.05)return;ctx.beginPath();ctx.arc(cx,cy,a.r,-Math.PI/2,-Math.PI/2+a.v*Math.PI*1.5);ctx.strokeStyle=a.c;ctx.lineWidth=1.5;ctx.lineCap='round';ctx.stroke();});
 ctx.setTransform(1,0,0,1,0,0);
}

/* ══ STOP ══ */
function stopAll(){
 // ── Session Report ──
 if(SESSION_STAT.startT>0&&appState.isRun){
 const dur=Math.round((Date.now()-SESSION_STAT.startT)/1000);
 const m=Math.floor(dur/60),s=dur%60;
 const hops=FREQ_HOP.count-SESSION_STAT.hopCount0;
 const avgEff=SESSION_STAT.suppEffN>0?Math.round(SESSION_STAT.suppEffSum/SESSION_STAT.suppEffN):0;
 const domEnv=Object.entries(SESSION_STAT.envCount).sort((a,b)=>b[1]-a[1]).map(e=>e[0])[0]||'—';
 logNN(` SESSION: ${m}m${s}s · hops=${hops} · notchPeak=${SESSION_STAT.notchPeak} · avgEff=${avgEff}% · env=${domEnv}`);
 SESSION_STAT.startT=0;
 }
 if(notchDecayT){clearInterval(notchDecayT);notchDecayT=null;}
 appState.isRun=false;
 // Stop BG systems
 relWL();stopBGWorker();stopSW();closeBGNotif();bgMode=false;updBGUI();
 // Save session
 if(zeroDB)saveSession().then(()=>{stLog(' Session auto-saved on stop');if(curTab===7)refreshSessionList();});
 // Save to Android storage if available
 if(typeof ZeroAndroid!=='undefined')androidWrite('logs','stop_'+Date.now()+'.txt','Stopped at cycle '+appState.aiCyc+' silence '+appState.silSc+'%');
 // Stop Android BG service (شبكة أمان: تنظيف أي حالة خلفية متبقية) + إعادة الشاشة لوضعها الطبيعي
 if(typeof ZeroAndroid!=='undefined'){ZeroAndroid.stopBG();try{ZeroAndroid.setKeepScreenOn(false);}catch(e){}}
 // Stop audio
 stopSF();stopAudioPoke();
 [appState.aT,appState.cT,appState.lT,appState.nnT].forEach(t=>{if(t)clearInterval(t);});appState.aT=appState.cT=appState.lT=appState.nnT=null;
 if(appState.drawId){cancelAnimationFrame(appState.drawId);appState.drawId=null;}
 INV.active.forEach(v=>{try{v.osc.stop();v.g.disconnect();}catch(e){}});INV.active.clear();INV.failed.clear();
 if(appState.micStr){appState.micStr.getTracks().forEach(t=>t.stop());appState.micStr=null;}
 if(appState.actx){appState.actx.close();appState.actx=null;}
 appState.micSrc=appState.ana=null;appState.fanFreq=0;appState.fanE=0;appState.silSc=0;appState.aiCyc=0;appState.iLv=appState.uLv=appState.pLv=appState.bLv=appState.eLv=0;
 setPlSt(false);
 const sc=E('cSc');if(sc)sc.textContent='0%';
 const ec=E('execCurr');if(ec)ec.textContent='STOPPED';
 const ed=E('execDot');if(ed)ed.className='exec-run-dot';
 const ct=E('cSt');if(ct)ct.textContent='tap to start';
 const cb=E('confB');if(cb)cb.style.width='0%';
 // Hide level meter on stop
 const lm=E('lvlMeter');if(lm)lm.style.display='none';
 const le=E('envLabel');if(le)le.style.display='none';
 const lrEl=E('lr');if(lrEl)lrEl.classList.remove('go');
 {const _t=E('tbTxt');if(_t)_t.textContent='AI Brain';}
 setS('off');
}

function setPlSt(on){
 const s=on?'ACTIVE':'IDLE';
 [['ps-mic-stage','run'],['ps-alg','run'],['ps-sf','sil'],['ps-coh','run'],
 ['ps-bx','ai2'],['ps-cl','run'],['ps-nn','sil'],['ps-inv','inv']
 ].forEach(([id,cls])=>{const el=E(id);if(!el)return;el.textContent=s;el.className='pls'+(on?' '+cls:'');});
}

/* Coh Mini Build */
function buildCoh(){const g=E('cohMini');if(!g)return;COH_F.forEach((hz,i)=>{const row=document.createElement('div');row.className='cm';row.innerHTML=`<span class="cmh">${hz<1000?hz+'Hz':(hz/1000)+'k'}</span><div class="cmt"><div class="cmf" id="cmf-${i}"></div></div><span class="cmv" id="cmv-${i}">0%</span>`;g.appendChild(row);});}

/* ══ UI UPDATES ══ */
function logNN(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 NN_LOG.unshift({msg,t});if(NN_LOG.length>80)NN_LOG.pop();
 if(curTab===4){const el=E('nn-log');if(el)el.innerHTML=NN_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="color:rgba(255,255,255,.3)">${l.t}</span> ${l.msg}</div>`).join('');}
}

function updateNNUI(){
 const tc=E('nn-tc');if(tc)tc.textContent=NN.trainN;const ls=E('nn-loss');if(ls)ls.textContent=NN.loss.toFixed(4);const lr=E('nn-lr');if(lr)lr.textContent=NN.lr.toFixed(4);
 if(NN.lastOut){['nno0','nno1','nno2','nno3','nno4','nno5'].forEach((id,i)=>{const el=E(id);if(el)el.textContent=(NN.lastOut[i]*100).toFixed(0)+'%';});}
}

function updateFreqUI(){
 const dc=E('db-cap');if(dc)dc.textContent=freqFile.totalCap;const df=E('db-conf');if(df)df.textContent=freqFile.totalConf;const dca=E('db-canc');if(dca)dca.textContent=freqFile.totalCanc;const di=E('db-inv');if(di)di.textContent=INV.active.size;
 const list=E('flist');if(!list)return;
 // خط دفاع أخير: نستبعد فقط القيم غير المنتهية (NaN) — لا الترددات السالبة، فهي مقصودة
 // فعلياً من ميزة negFreqMirror (مرآة التردد السالب) وتُعرَض هنا عمداً كـ"-xHz"
 const top=freqFile.entries.filter(e=>typeof e.hz==='number'&&isFinite(e.hz)).slice(0,14);
 list.innerHTML=top.length?top.map(e=>{
 const c=e.cancelled?'var(--zero)':e.confirmed?'var(--ai)':'var(--dim)';
 const st=e.cancelled?'✓CANC':e.confirmed?'INV('+e.count+'×)':'('+e.count+'×)';
 const clsArr=['','C1⊕','C2⊖','C3∓','C4±','C5✓','C6✗','C7✓','C8✗','C9','C10𝒊','C11↑','C12∞','C13','C14','C15','C16'];const cls=clsArr[e.class||0]||'';
 return `<div style="display:flex;justify-content:space-between;align-items:center;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="font-family:var(--fm);font-size:9px;color:${c}">${e.hz.toFixed(1)}Hz</span><span style="font-family:var(--fm);font-size:8px;color:rgba(149,149,149,.7)">${cls}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${st}</span></div>`;
 }).join(''):'<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">Waiting for mic input...</div>';
 updateInvUI();
}

function updateInvUI(){
 const list=E('inv-list');if(!list)return;
 if(!INV.active.size){list.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">None active</div>';return;}
 list.innerHTML=[...INV.active.values()].map(v=>`<div style="display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="font-family:var(--fm);font-size:9px;color:var(--sharp)">${v.hz.toFixed(2)}Hz</span><span style="font-family:var(--fm);font-size:9px;color:var(--muted)">att:${v.attempts}/${INV.maxTry}</span><span style="font-family:var(--fm);font-size:9px;color:${v.verified?'var(--zero)':'var(--ai)'}">${v.verified?'✓DONE':'⟳INV'}</span></div>`).join('');
}


/* ══ REDESIGNED BAN UI ══ */
function updateMicUI(){
 if(!MIC.sr)return;const el=E('mic-prof');if(!el)return;
 el.innerHTML=[['Sample Rate',MIC.sr/1000+'kHz','var(--zero)'],['Nyquist',(MIC.nyq/1000).toFixed(1)+'kHz','var(--zero)'],['FFT Res',MIC.fftRes.toFixed(3)+'Hz/bin','var(--c5)'],['Range',MIC.minDet.toFixed(2)+'→'+(MIC.maxDet/1000).toFixed(0)+'kHz','var(--c7)'],['Dyn Range',MIC.dynRange+'dB','var(--ai)'],['Latency',MIC.latMs.toFixed(1)+'ms','var(--noise)']].map(([k,v,c])=>`<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.3)">${k}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${v}</span></div>`).join('');
}

function updateMicFeat(){
 const el=E('mic-feat');if(!el)return;
 el.innerHTML=[['Spectral Centroid',(MIC.feat.cent/1000).toFixed(2)+'kHz','var(--sharp)'],['Zero-Cross Rate',(MIC.feat.zcr*100).toFixed(1)+'%','var(--c5)'],['Crest Factor',MIC.feat.crest.toFixed(2),'var(--c3)'],['Spectral Flatness',(MIC.feat.flat*100).toFixed(1)+'%','var(--c5)'],['HNR',MIC.feat.hnr.toFixed(2),'var(--fan)']].map(([k,v,c])=>`<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.3)">${k}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${v}</span></div>`).join('');
}

/* Charts */
function drawRwChart(){
 const cv=E('rwCv');if(!cv||!NN.hist.length)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const hist=NN.hist.slice(-60);
 ctx.strokeStyle='rgba(255,255,255,.05)';ctx.beginPath();ctx.moveTo(0,H/2);ctx.lineTo(W,H/2);ctx.stroke();
 ctx.beginPath();hist.forEach((pt,i)=>{const x=(i/(Math.max(hist.length-1,1)))*W;const y=H/2-(pt.reward*(H/2-3));i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});
 ctx.strokeStyle='rgba(169,169,169,.7)';ctx.lineWidth=1.5;ctx.stroke();
 drawNNWeights();
}

/* ══ NN WEIGHT HEATMAP ══ */
function drawNNWeights(){
 const cv=E('nnWtCv');if(!cv||!NN.w1||!NN.w1.length)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||320;const H=60;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 // مراجعة "النسخة النهائية": NN.w1 مصفوفة مسطَّحة (Float dim ni*nh عبر xv(ni,nh) في nnInit،
 // ومفهرَسة w1[i*nh+j] في nnFwd نفسها) — لم تكن أبداً مصفوفة متداخلة [][ كما افترض هذا الرسم.
 // NN.w1[0] كانت رقماً مفرداً، `.length` عليه undefined، فـ cols=undefined وكل حلقة j<cols
 // كانت false دائماً (0<undefined) — لا خطأ ظاهر، فقط لوحة حرارة NN فارغة تماماً في كل مرة،
 // منذ نمو الشبكة من 12→16 مدخلاً حين توقف هذا الرسم عن مطابقة شكلها الفعلي.
 const rows=NN.in,cols=NN.hid; // 16 inputs × 24 hidden (راجع تعريف NN أعلاه)
 // Find min/max for normalization
 let mn=Infinity,mx=-Infinity;
 for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){const w=NN.w1[i*cols+j];if(w<mn)mn=w;if(w>mx)mx=w;}
 const range=mx-mn||1;
 const cellW=cW/cols;const cellH=cH/rows;
 for(let i=0;i<rows;i++){
 for(let j=0;j<cols;j++){
 const t=(NN.w1[i*cols+j]-mn)/range; // 0→1
 // كانت: cold (blue) → black → warm (green/amber) — حُذفت الصبغة اللونية (28 سبتمبر
 // 2026) إبقاءً على نفس منطق حساب الإضاءة (r,g,b) ثم تحويل الناتج فعلياً إلى رمادي عبر
 // معادلة luma القياسية (نفس المعادلة المُطبَّقة آلياً على شريط التدرّج الثابت أسفله)،
 // فيبقى المفهوم (قيمة منخفضة=غامق، حدّية=أسود، مرتفعة=فاتح) سليماً بلا أي لون.
 let r,g,b;
 if(t<0.45){const v=t/0.45;r=0;g=0;b=Math.round(v*180);}
 else if(t<0.55){r=0;g=0;b=0;}
 else{const v=(t-0.55)/0.45;r=Math.round(v*180);g=Math.round(v*255);b=0;}
 const nnY=Math.round(0.299*r+0.587*g+0.114*b);
 ctx.fillStyle=`rgb(${nnY},${nnY},${nnY})`;
 ctx.fillRect(Math.round(j*cellW),Math.round(i*cellH),Math.ceil(cellW)+1,Math.ceil(cellH)+1);
 }
 }
 // Row input labels — تُطابق ترتيب nnInp() بالضبط؛ 4 مدخلات أُضيفت لاحقاً (Pol/Thm/Frm/Cnt)
 // حين نمت الشبكة من 12→16 مدخلاً دون تحديث هذه المصفوفة، فبقيت 4 صفوف بلا تسمية سابقاً.
 const lbl=['Hz','En','DB','EVP','EMF','Lp','Ph','MSE','Sil','1-L','Tr','ToD','Pol','Thm','Frm','Cnt'];
 ctx.font=`${Math.round(5.5*dpr)}px monospace`;ctx.fillStyle='rgba(255,255,255,.6)';
 for(let i=0;i<Math.min(rows,lbl.length);i++){
 ctx.fillText(lbl[i],1*dpr,Math.round((i+0.78)*cellH));
 }
 // Color legend strip
 const grd=ctx.createLinearGradient(cW*0.75,0,cW,0);
 grd.addColorStop(0,'rgb(21,21,21)');grd.addColorStop(0.45,'rgb(0,0,0)');grd.addColorStop(1,'rgb(186,186,186)');
 ctx.fillStyle=grd;ctx.fillRect(Math.round(cW*0.75),cH-6*dpr,Math.round(cW*0.25),4*dpr);
 ctx.fillStyle='rgba(255,255,255,.35)';ctx.font=`${Math.round(5*dpr)}px monospace`;
 ctx.fillText('−',Math.round(cW*0.75)+1,cH-7*dpr);ctx.fillText('+',cW-7*dpr,cH-7*dpr);
}

/* ══ ENV-ADAPTIVE LAYER AUTO-TUNE ══ */
function envAdaptSF(){
 if(!appState.isRun||thermalThrottleOn)return;
 // Small bias nudge — augments NN output, never overrides it fully
 // Rate: ±4% max per call, called every 10 cycles (800ms)
 const env=curEnvClass;
 switch(env){
 case 'quiet':
 appState.iLv=Math.max(0.15,appState.iLv*0.97);appState.uLv=Math.max(0.05,appState.uLv*0.94);
 appState.pLv=Math.max(0.12,appState.pLv*0.96);appState.bLv=Math.max(0.1,appState.bLv*0.96);
 break;
 case 'mechanical':
 // Machinery hum → infrasound + phase field
 appState.iLv=Math.min(0.98,appState.iLv*1.03);appState.pLv=Math.min(0.95,appState.pLv*1.02);
 break;
 case 'tonal':
 // Tonal signal → standard + sub layers, reduce ultrasound
 appState.uLv=Math.max(0.15,appState.uLv*0.97);appState.bLv=Math.min(0.9,appState.bLv*1.02);
 break;
 case 'noise':
 // Broadband noise → balanced uniform boost
 appState.iLv=Math.min(0.9,appState.iLv*1.01);appState.uLv=Math.min(0.9,appState.uLv*1.01);
 appState.pLv=Math.min(0.9,appState.pLv*1.01);appState.bLv=Math.min(0.9,appState.bLv*1.01);
 break;
 case 'impulsive':
 // Transient spike → phase field + piezo
 appState.pLv=Math.min(0.98,appState.pLv*1.04);appState.eLv=Math.min(0.95,appState.eLv*1.03);
 break;
 case 'interference':
 // EMI/RFI → ultrasound suppression layer
 appState.uLv=Math.min(0.95,appState.uLv*1.03);appState.eLv=Math.min(0.9,appState.eLv*1.02);
 break;
 }
 updSFGains();
 // Update adaptive status display in NN tab
 const p=(v)=>(v*100).toFixed(0)+'%';
 const si=E('ea-inf'),su=E('ea-ult'),sp=E('ea-phf'),sb=E('ea-sub'),se=E('ea-pie'),sv=E('ea-env');
 if(si)si.textContent=p(appState.iLv);if(su)su.textContent=p(appState.uLv);
 if(sp)sp.textContent=p(appState.pLv);if(sb)sb.textContent=p(appState.bLv);
 if(se)se.textContent=p(appState.eLv);
 if(sv)sv.textContent=ENV_LABELS[env]?ENV_LABELS[env].label.split(' ')[1]||env:env;
}

/* ══ FREQUENCY CLUSTER ANALYZER ══ */
function buildFreqClusters(){
 const confirmed=[...freqDB.values()]
 .filter(e=>e.confirmed&&e.hz>0)
 .sort((a,b)=>a.hz-b.hz);
 if(confirmed.length<1)return[];
 const used=new Set();const clusters=[];
 for(let i=0;i<confirmed.length;i++){
 if(used.has(i))continue;
 const root=confirmed[i];
 const cl={root:root.hz,members:[{entry:root,harmN:1}]};
 used.add(i);
 for(let j=i+1;j<confirmed.length;j++){
 if(used.has(j))continue;
 const ratio=confirmed[j].hz/root.hz;
 const nearest=Math.round(ratio);
 if(nearest>=2&&nearest<=24&&Math.abs(ratio-nearest)/nearest<0.025){
 cl.members.push({entry:confirmed[j],harmN:nearest});
 used.add(j);
 }
 }
 clusters.push(cl);
 }
 return clusters;
}

function updateClusterUI(){
 const cl=E('cluster-list');const cc=E('cluster-count');if(!cl)return;
 const clusters=buildFreqClusters();
 if(cc)cc.textContent=clusters.length;
 if(!clusters.length){
 cl.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">في انتظار ترددات مؤكدة...</div>';
 return;
 }
 cl.innerHTML=clusters.map((c,ci)=>{
 const membHtml=c.members.map((m,mi)=>{
 const col=mi===0?'var(--on)':'var(--c5)';
 const tag=mi===0?'':('×'+m.harmN);
 return `<span style="color:${col};font-family:var(--fm);font-size:9px;font-weight:700">${m.entry.hz.toFixed(1)}Hz<span style="color:var(--muted);font-weight:400;font-size:7.5px">${tag}</span></span>`;
 }).join('<span style="color:var(--brd2);margin:0 3px">→</span>');
 const fund=c.members[0].entry.hz;
 const clsTag=c.members.length>=3?'<span style="font-size:7px;color:rgba(120,120,120,.8);background:rgba(120,120,120,.1);border:1px solid rgba(120,120,120,.2);border-radius:4px;padding:0 4px;margin-left:4px">SERIES</span>':'';
 return `<div style="padding:5px 0;border-bottom:1px solid var(--brd)">
 <div style="font-family:var(--fm);font-size:7.5px;color:var(--muted);margin-bottom:3px">CLUSTER ${ci+1} · fund ${fund.toFixed(2)}Hz · ${c.members.length} harmonic${c.members.length>1?'s':''}${clsTag}</div>
 <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">${membHtml}</div>
 </div>`;
 }).join('');
}

function drawClassChart(){
 const cv=E('classCv');if(!cv)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const nyq=appState.actx?appState.actx.sampleRate/2:24000;const labels=['C1⊕','C2⊖','C3∓','C4±','C5+','C6-','C7+','C8-'];
 const colors=['var(--c1)','var(--c2)','var(--c3)','var(--c4)','var(--c5)','var(--c6)','var(--c7)','var(--c8)'];
 const hexC=['#a9a9a9','#686868','#9c9c9c','#787878','#959595','#888888','#a5a5a5','#888888'];
 const counts=[FC.c1,FC.c2,FC.c3,FC.c4,FC.c5,FC.c6,FC.c7,FC.c8];
 const mx=Math.max(...counts,1);const bw=W/8;
 counts.forEach((v,i)=>{const h=Math.max(2,(v/mx)*(H-10));ctx.fillStyle=hexC[i]+'88';ctx.fillRect(i*bw+2,H-h,bw-4,h);ctx.fillStyle=hexC[i];ctx.font='8px monospace';ctx.fillText(v,i*bw+4,H-h-2);});
}

function drawMicSpec(){
 if(!appState.ana||curTab!==3)return;
 const cv=E('micSpecCv');if(!cv)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const fd=new Uint8Array(appState.ana.frequencyBinCount);appState.ana.getByteFrequencyData(fd);
 const step=Math.ceil(fd.length/W);
 // كان يُلوَّن كل عمود بتدرّج hue (200→260° حسب الشدّة v) بإضاءة/تشبّع ثابتين — حُذفت الصبغة
 // اللونية (28 سبتمبر 2026) بتصفير التشبّع (0%) وتحويل الشدّة v نفسها إلى إضاءة (lightness)
 // متغيّرة بدلاً من الهيو، فيبقى المفهوم البصري (كلما زادت الشدّة زاد السطوع) قائماً بلا لون.
 for(let x=0;x<W;x++){const bin=x*step;if(bin>=fd.length)break;const v=fd[bin]/255;const lgt=Math.round(15+v*70);ctx.fillStyle=`hsla(0,0%,${lgt}%,.7)`;ctx.fillRect(x,H-v*H,1,v*H);}
}

setInterval(()=>{
 // تتمة إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم" (راجع أيضاً
 // bgLoop في 08c-background-db.js لنفس فئة الخلل): هذا المؤقّت (12.5 مرة/ثانية) كان
 // يعمل بلا أي شرط رؤية إطلاقاً — فقط `curTab===N` (أيّ تبويب داخلي كان آخر مرة نشِطاً
 // داخل aiPanel) — لا يتحقق أبداً من كون aiPanel نفسها مفتوحة أصلاً (aOpen). فالحالة
 // الافتراضية (curTab=0 قبل أي فتح لِلوحة) كانت تُشغِّل updateFreqUI() كل 80ms إلى الأبد
 // من إقلاع التطبيق — إعادة بناء innerHTML لحتى 14 صفاً + استدعاء updateInvUI() — حتى
 // لو لم تُفتَح aiPanel إطلاقاً؛ وإن فتحها المستخدم مرّة وبدَّل لتبويب رسم (1: NN reward
 // chart، 2: تصنيف، 3: طيف الميكروفون) ثم أغلق اللوحة دون العودة لتبويب 0 — يبقى ذلك
 // الرسم (canvas fillRect/fillText لكل إطار) يعمل أيضاً إلى الأبد خلف لوحة مغلقة تماماً
 // (transform:translateX(102%))، أي عمل غير مرئي إطلاقاً يتنافس بلا داعٍ مع أي تفاعل
 // لاحق (فتح/تبديل قوائم أخرى) على نفس الخيط الرئيسي الوحيد. الإصلاح: تخطّي الكتلة
 // كاملة ما دامت aiPanel مغلقة فعلياً — نفس مبدأ التحقق من `.ovl.on` في bgLoop.
 if(!appState.aOpen)return;
 if(curTab===1)drawRwChart();
 if(curTab===2)drawClassChart();
 if(curTab===3){drawMicSpec();updateMicFeat();}
 if(curTab===0)updateFreqUI();
 // Update lag count display
 const lcnt=E('lag-freq-cnt');if(lcnt)lcnt.textContent=ENV_FP.slugFreqs.size+' ترددات';
 // Update harmonic Q display
 const hq=E('harmonic-q');if(hq)hq.textContent=HARMONICS.q>0?HARMONICS.fund.toFixed(1)+'Hz Q='+HARMONICS.q.toFixed(1):'—';
},80);

/* ══════════════════════════════════════════════════════════════
 AI EXEC — Self-Building Programmatic Engine
 No messaging. No chat. Pure code execution.

 The AI reads complete engine state, selects and runs programs
 that directly modify: NN weights, SF gains, Kalman, Wiener,
 FreqDB thresholds, Bayesian weights, Inverse strategy.

 Every N cycles → program selected → executed → changes logged.
 User can also run programs manually via command line.

 DSL Commands (exec-inp):
 ANALYZE — full state report
 STATE — dump all variables
 LIST — list available programs
 SELF_OPTIMIZE — adaptive meta-optimizer (runs top programs)
 OPTIMIZE_SF — tune silent freq gains
 TUNE_NN — adapt learning rate / momentum
 ADAPT_THRESH — adapt FREQ_THRESH dynamically
 INVERSE_STRAT — tune inverse generator
 BOOST_SIL — emergency silence boost
 RESET_KF — reset Kalman filter
 RESET_BAYES — reset Bayesian mixer
 FREQ_PREDICT — predict next dominant frequencies
 PATTERN_LEARN — cluster freqDB → noise signature → Bayes
 META_ADAPT — UCB1 rank programs → reshape schedule
 PREDICT — alias for FREQ_PREDICT
 RANK — show UCB1 program efficiency ranking
 SET SF.INF 0.7 — set INF gain directly
 SET NN.LR 0.015 — set NN learning rate
 SET THRESH 4 — set confirm threshold
 SET WIENER.A 2.0— set Wiener alpha
══════════════════════════════════════════════════════════════ */

/* ══ ENGINE STATE READER ══ */
function getState(){
 return{
 silSc: appState.silSc,bestSil: appState.bestSil,aiCyc: appState.aiCyc,loopN: appState.loopN,loopE: appState.loopE,aiCon: appState.aiCon,
 fanFreq: appState.fanFreq,fanE: appState.fanE,noiseE: appState.noiseE,sharpE: appState.sharpE,evpE: appState.evpE,evpHz: appState.evpHz,emfE: appState.emfE,
 freqDB,freqFile,FC:{...FC},
 INV,KF:{...KF},DRV:{...DRV},P:{...P},
 iLv: appState.iLv,uLv: appState.uLv,pLv: appState.pLv,bLv: appState.bLv,eLv: appState.eLv,
 NN:{trainN:NN.trainN,loss:NN.loss,lr:NN.lr,mom:NN.mom,lastOut:NN.lastOut?[...NN.lastOut]:null},
 actxSR:appState.actx?appState.actx.sampleRate:0
 // AI_CTX accessed directly as global — no need to duplicate in state
 };
}

/* ════════════════════════════════════════════════
 AI CONTEXT (AI_CTX) — Shared Memory Layer
 Updated every 5s from UDS.
 AI programs READ this synchronously.
 Terminal writes TO it via tLog hooks.

 Flow:
 Engine events → tLog → UDS → AI_CTX → AI programs
 AI programs → logExec → UDS → Terminal display
════════════════════════════════════════════════ */
class AIContext{
 constructor(){
 // From terminal_events DB
 this.topFreqs=[]; // [{hz,count,classId}] dominant patterns
 this.recentFreqs=[]; // last 30 FREQ events
 this.cohTrend=0; // avg γ² over last 20 COH events (0→1)
 this.cohDelta=0; // γ² change (positive=improving)
 // From exec_history DB
 this.execStats={}; // {PROG_NAME: {runs, avgMs, avgSilChange}}
 this.bestProg=null; // program that yielded highest silence gain
 // From nn_history DB
 this.nnLossTrend=0; // slope of loss over last 20 snapshots
 this.nnBestLoss=1; // lowest loss achieved
 // From freq_patterns DB
 this.confirmedPatterns=[]; // [{hz, count, classId}]
 // Meta
 this.lastUpdated=0;
 this.updateCount=0;
 this.ready=false;
 // Extended — filled by new programs
 this.noiseSignature='unknown'; // 'tonal/hum' | 'narrowband' | 'wideband'
 this.predictedHz=null; // next predicted dominant frequency
 this.rankedProgs=[]; // programs ranked by silence efficiency (META_ADAPT)
 this.lowEffProgs=new Set(); // programs flagged as low-efficiency (META_ADAPT)
 this.priorityProg=null; // program to prioritize this epoch (META_ADAPT)
 this.crestFactor=0; // ⑧ live crest factor from CREST (CREST×AI_CTX)
 }
 async update(){
 if(!zeroDB)return;
 this.updateCount++;
 // 1. Dominant frequency patterns from terminal_events
 const freqEvts = await udsQueryEvents('FREQ', 200);
 const hzMap={};
 freqEvts.forEach(e=>{
 const m=e.code.match(/hz = ([\d.]+)/);
 if(m){const hz=parseFloat(m[1]);if(!hzMap[hz])hzMap[hz]={hz,count:0,ts:e.ts};hzMap[hz].count++;}
 });
 this.topFreqs=Object.values(hzMap).sort((a,b)=>b.count-a.count).slice(0,10);
 this.recentFreqs=freqEvts.slice(0,30);
 // Write new patterns to freq_patterns store
 this.topFreqs.forEach(p=>{if(p.count>=3)udsWritePattern(p.hz,p.count,0);});
 // 2. Coherence trend from COH events
 const cohEvts=await udsQueryEvents('COH',20);
 if(cohEvts.length>1){
 const vals=cohEvts.map(e=>{const m=e.code.match(/γ²_avg = ([\d.]+)/);return m?parseFloat(m[1]):0;});
 this.cohTrend=vals.reduce((a,b)=>a+b,0)/vals.length;
 this.cohDelta=vals.length>1?vals[0]-vals[vals.length-1]:0;
 }
 // 3. Exec program statistics
 const execEvts=await udsQueryExec(null,200);
 const stats={};
 execEvts.forEach(e=>{
 if(!stats[e.prog])stats[e.prog]={runs:0,totalMs:0,silSum:0};
 stats[e.prog].runs++;
 stats[e.prog].totalMs+=e.ms||0;
 stats[e.prog].silSum+=e.silSc||0;
 });
 Object.keys(stats).forEach(p=>{
 const s=stats[p];
 this.execStats[p]={runs:s.runs,avgMs:(s.totalMs/s.runs).toFixed(1),avgSil:(s.silSum/s.runs).toFixed(1)};
 });
 // Best program by average silence
 const progs=Object.entries(this.execStats);
 if(progs.length)this.bestProg=progs.sort((a,b)=>parseFloat(b[1].avgSil)-parseFloat(a[1].avgSil))[0][0];
 // 4. NN loss trend
 const nnHist=await udsQueryNNHistory(20);
 if(nnHist.length>1){
 const losses=nnHist.map(e=>e.loss);
 this.nnBestLoss=Math.min(...losses);
 this.nnLossTrend=losses.length>1?(losses[0]-losses[losses.length-1])/losses.length:0;
 }
 // 5. Confirmed patterns
 this.confirmedPatterns=await udsQueryPatterns();
 // ⑧ CREST×AI_CTX — Live crest factor in shared context
 this.crestFactor=typeof CREST!=='undefined'?CREST.val:0;
 this.lastUpdated=Date.now();
 this.ready=true;
 // Log to terminal every 10 updates
 if(this.updateCount%10===0&&this.topFreqs.length){
 tLog('SYS',
 `# AI_CTX updated: topFreq=${this.topFreqs[0]?.hz}Hz(×${this.topFreqs[0]?.count}) cohTrend=${this.cohTrend.toFixed(3)} bestProg=${this.bestProg||'—'}`,
 `# nnLossTrend=${this.nnLossTrend.toFixed(5)} patterns=${this.confirmedPatterns.length} execStats=${Object.keys(this.execStats).length}`);
 }
}
}
const AI_CTX=new AIContext();
function updateAICtx(){return AI_CTX.update();}

// Update AI context every 5 seconds
setInterval(()=>{if(appState.isRun)updateAICtx();},2000);

/* ══ PROGRAM LIBRARY ══ */

window._audioInitPromise=_audioInitPromise; window.initAudio=initAudio; window.startAll=startAll;
window.startSF=startSF; window.updSF=updSF; window.stopSF=stopSF;
window.startDet=startDet; window.detectAll=detectAll; window.update16Class=update16Class;
window.updCoh=updCoh; window.startCL=startCL; window.startNN=startNN;
window.startLearn=startLearn; window._drawLoopTD=_drawLoopTD; window.drawLoop=drawLoop;
window._sfEffBuf=_sfEffBuf; window.sfEff=sfEff; window.drawOrb=drawOrb;
window.stopAll=stopAll; window.setPlSt=setPlSt; window.buildCoh=buildCoh;
window.logNN=logNN; window.updateNNUI=updateNNUI; window.updateFreqUI=updateFreqUI;
window.updateInvUI=updateInvUI; window.updateMicUI=updateMicUI; window.updateMicFeat=updateMicFeat;
window.drawRwChart=drawRwChart; window.drawNNWeights=drawNNWeights; window.envAdaptSF=envAdaptSF;
window.buildFreqClusters=buildFreqClusters; window.updateClusterUI=updateClusterUI; window.drawClassChart=drawClassChart;
window.drawMicSpec=drawMicSpec; window.getState=getState; window.AI_CTX=AI_CTX;
window.updateAICtx=updateAICtx;

})();
/* ── 07a-ai-command-library.js ── */

'use strict';
(function(){

const AI_LIB={

 OPTIMIZE_SF:{
 desc:'Adjusts SF gains from 8-class distribution + AI_CTX.topFreqs patterns',
 run(st){
 const changes=[];const tot=Object.values(st.FC).reduce((a,b)=>a+b,0)||1;
 // Read DB-derived pattern context
 if(AI_CTX.ready&&AI_CTX.topFreqs.length){
 const tf=AI_CTX.topFreqs[0];
 changes.push(`# db_context: top_hz=${tf.hz}Hz(×${tf.count}) cohTrend=${AI_CTX.cohTrend.toFixed(3)}`);
 // Pattern-specific boost: if top freq is below 100Hz → boost INF harder
 if(tf.hz<100&&tf.count>5){const p=appState.iLv;appState.iLv=Math.min(1,appState.iLv*1.10);if(Math.abs(appState.iLv-p)>0.001)changes.push(`INF ${p.toFixed(3)}→${appState.iLv.toFixed(3)} [pattern<100Hz]`);}
 // COH improving → keep current strategy; declining → switch
 if(AI_CTX.cohDelta<-0.05){const p=appState.uLv;appState.uLv=Math.min(1,appState.uLv*1.08);changes.push(`ULT ${p.toFixed(3)}→${appState.uLv.toFixed(3)} [coh↓ switch]`);}
 }
 // C7 dominant (spk-emittable) → boost INF field
 if(st.FC.c7/tot>0.28){const p=appState.iLv;appState.iLv=Math.min(1,appState.iLv*1.07);if(Math.abs(appState.iLv-p)>0.001)changes.push(`INF ${p.toFixed(3)}→${appState.iLv.toFixed(3)} [C7↑]`);}
 // C1 dominant (positive energy) → strengthen PHF
 if(st.FC.c1/tot>0.35){const p=appState.pLv;appState.pLv=Math.min(1,appState.pLv*1.05);if(Math.abs(appState.pLv-p)>0.001)changes.push(`PHF ${p.toFixed(3)}→${appState.pLv.toFixed(3)} [C1↑]`);}
 // C2 dominant (negative/cancel) → boost ULT coherence break
 if(st.FC.c2/tot>0.3){const p=appState.uLv;appState.uLv=Math.min(1,appState.uLv*1.06);if(Math.abs(appState.uLv-p)>0.001)changes.push(`ULT ${p.toFixed(3)}→${appState.uLv.toFixed(3)} [C2↑]`);}
 // C6 dominant (mic-invisible) → boost SUB reset
 if(st.FC.c6/tot>0.25){const p=appState.bLv;appState.bLv=Math.min(1,appState.bLv*1.04);if(Math.abs(appState.bLv-p)>0.001)changes.push(`SUB ${p.toFixed(3)}→${appState.bLv.toFixed(3)} [C6↑]`);}
 // Low silence → increase all SF gains
 if(st.silSc<25){appState.iLv=Math.min(1,appState.iLv*1.03);appState.uLv=Math.min(1,appState.uLv*1.03);appState.pLv=Math.min(1,appState.pLv*1.03);changes.push(`ALL+3% [sil<25%]`);}
 updSFGains();
 return changes.length?changes:['SF gains optimal — no adjustment'];
 }
 },

 TUNE_NN:{
 desc:'Adapts NN lr/momentum from loss trend + AI_CTX.nnLossTrend history',
 run(st){
 const changes=[];const loss=st.NN.loss;
 // Use DB-derived trend for smarter adaptation
 if(AI_CTX.ready){
 changes.push(`# db_context: nnLossTrend=${AI_CTX.nnLossTrend.toFixed(5)} bestLoss=${AI_CTX.nnBestLoss.toFixed(4)} bestProg=${AI_CTX.bestProg||'—'}`);
 // If loss trend is worsening fast → aggressive lr boost
 if(AI_CTX.nnLossTrend<-0.01){const p=NN.lr;NN.lr=Math.min(0.06,NN.lr*1.25);changes.push(`lr ${p.toFixed(4)}→${NN.lr.toFixed(4)} [trend↓ aggressive]`);}
 // If we're far from best loss → reduce momentum to explore
 if(loss>AI_CTX.nnBestLoss*2&&NN.mom>0.75){const p=NN.mom;NN.mom=Math.max(0.7,NN.mom-0.03);changes.push(`mom ${p.toFixed(3)}→${NN.mom.toFixed(3)} [explore: loss>>best]`);}
 }
 // Learning rate adaptation
 const prevLR=NN.lr;
 if(loss>0.6){NN.lr=Math.min(0.05,NN.lr*1.18);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [loss>0.6 boost]`);}
 else if(loss>0.35){NN.lr=Math.min(0.03,NN.lr*1.08);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [loss>0.35 up]`);}
 else if(loss<0.08&&st.aiCyc>200){NN.lr=Math.max(0.0008,NN.lr*0.90);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [converging↓]`);}
 // Momentum adaptation
 const prevM=NN.mom;
 if(loss>0.5&&NN.mom>0.8){NN.mom=Math.max(0.7,NN.mom-0.02);changes.push(`mom ${prevM.toFixed(3)}→${NN.mom.toFixed(3)} [high loss↓]`);}
 else if(loss<0.1&&NN.mom<0.95){NN.mom=Math.min(0.97,NN.mom+0.01);changes.push(`mom ${prevM.toFixed(3)}→${NN.mom.toFixed(3)} [low loss↑]`);}
 // Wiener α from noise floor
 const prevA=P.alpha;
 if(st.noiseE>0.55){P.alpha=Math.min(3.5,P.alpha*1.06);changes.push(`Wiener.α ${prevA.toFixed(2)}→${P.alpha.toFixed(2)} [noise↑]`);}
 else if(st.noiseE<0.08){P.alpha=Math.max(0.8,P.alpha*0.96);changes.push(`Wiener.α ${prevA.toFixed(2)}→${P.alpha.toFixed(2)} [noise↓]`);}
 // ① Loss-Momentum Warmup: slope of NN.hist guides mom direction
 if(NN.hist.length>=10){const re=NN.hist.slice(-10);const sl=(re[9].loss-re[0].loss)/10;if(sl>0.005&&NN.mom>0.80){const pm=NN.mom;NN.mom=Math.max(0.70,NN.mom-0.02);changes.push(`mom↓ ${pm.toFixed(3)}→${NN.mom.toFixed(3)} [loss rising slope=${sl.toFixed(4)}]`);}else if(sl<-0.005&&NN.mom<0.92){const pm=NN.mom;NN.mom=Math.min(0.95,NN.mom+0.01);changes.push(`mom↑ ${pm.toFixed(3)}→${NN.mom.toFixed(3)} [loss falling]`);}}
 // ① SPEC_FLAT×NN — Flatness-Adaptive LR: noise→explore, tonal→converge
 if(SPEC_FLAT.val>0.6){const p=NN.lr;NN.lr=Math.min(0.05,NN.lr*1.10);changes.push(`lr↑×1.10 [SPEC_FLAT=${SPEC_FLAT.val.toFixed(3)} noisy→explore]`);}
 else if(SPEC_FLAT.val<0.15&&NN.loss<0.3){const p=NN.lr;NN.lr=Math.max(0.001,NN.lr*0.92);changes.push(`lr↓×0.92 [SPEC_FLAT=${SPEC_FLAT.val.toFixed(3)} tonal→converge]`);}
 // ⑩ ZCRATE×NN — ZCR-Guided LR Boost: percussive/noisy signal → faster adaptation
 if(typeof ZCRATE!=='undefined'&&ZCRATE.val>0.3){const p=NN.lr;NN.lr=Math.min(0.06,NN.lr*(1+ZCRATE.val*0.3));changes.push(`lr↑ [ZCR=${ZCRATE.val.toFixed(4)} percussive→adapt]`);}
 return changes.length?changes:[`NN params optimal · lr=${NN.lr.toFixed(4)} · mom=${NN.mom.toFixed(3)}`];
 }
 },

 ADAPT_THRESH:{
 desc:'Adapts FREQ_THRESH and INV.verMs based on DB capture rate + success',
 run(st){
 const changes=[];
 const rate=st.freqFile.totalCap/Math.max(st.aiCyc,1);
 const prevT=appState.FREQ_THRESH;
 if(rate>10){appState.FREQ_THRESH=Math.min(8,appState.FREQ_THRESH+1);changes.push(`THRESH ${prevT}→${appState.FREQ_THRESH} [rate=${rate.toFixed(1)}/cyc high]`);}
 else if(rate<1){appState.FREQ_THRESH=Math.max(2,appState.FREQ_THRESH-1);changes.push(`THRESH ${prevT}→${appState.FREQ_THRESH} [rate=${rate.toFixed(1)}/cyc low]`);}
 else changes.push(`THRESH=${appState.FREQ_THRESH} stable · rate=${rate.toFixed(1)}/cyc`);
 // Inv verification timing
 if(st.freqFile.totalConf>0){
 const sr=st.freqFile.totalCanc/st.freqFile.totalConf;
 const prev=INV.verMs;
 if(sr<0.2){INV.verMs=Math.max(300,INV.verMs-40);changes.push(`verMs ${prev}→${INV.verMs}ms [success<20%↓]`);}
 else if(sr>0.75){INV.verMs=Math.min(1400,INV.verMs+20);changes.push(`verMs ${prev}→${INV.verMs}ms [success>75%↑]`);}
 }
 return changes;
 }
 },

 INVERSE_STRAT:{
 desc:'Optimizes inverse generator: anti-search angle + anti-pattern selection',
 run(st){
 const changes=[];
 if(st.freqFile.totalConf===0)return['No confirmed freqs — INVERSE_STRAT waiting'];
 const sr=st.freqFile.totalCanc/st.freqFile.totalConf;
 // Expand anti-search rotation if success low
 changes.push(`Cancel rate: ${(sr*100).toFixed(0)}% (${st.freqFile.totalCanc}/${st.freqFile.totalConf})`);
 if(sr<0.15){changes.push(`→ Anti-search: expand to 8 steps (was ${INV.maxTry})`);INV.maxTry=8;}
 else if(sr>0.8){changes.push(`→ Anti-search: compress to 3 steps`);INV.maxTry=3;}
 // Log active inverses
 if(st.INV.active.size>0)changes.push(`Active inverses: ${st.INV.active.size}`);
 if(st.INV.failed.size>3)changes.push(` Failed queue: ${st.INV.failed.size} — clearing stale entries`);
 return changes;
 }
 },

 BOOST_SIL:{
 desc:'Emergency: aggressively boost silence when silSc stagnant',
 run(st){
 const changes=[];
 // Push all SF gains toward max
 const prev=[appState.iLv,appState.uLv,appState.pLv,appState.bLv,appState.eLv];
 appState.iLv=Math.min(1,appState.iLv*1.15);appState.uLv=Math.min(1,appState.uLv*1.15);
 appState.pLv=Math.min(1,appState.pLv*1.12);appState.bLv=Math.min(1,appState.bLv*1.1);appState.eLv=Math.min(1,appState.eLv*1.1);
 updSFGains();
 if(appState.isRun&&appState.loopN%12===0)updSF();
 changes.push(`INF ${prev[0].toFixed(2)}→${appState.iLv.toFixed(2)}`);
 changes.push(`ULT ${prev[1].toFixed(2)}→${appState.uLv.toFixed(2)}`);
 changes.push(`PHF ${prev[2].toFixed(2)}→${appState.pLv.toFixed(2)}`);
 // Increase NN reward signal
 if(NN.lr<0.025){NN.lr*=1.2;changes.push(`NN.lr×1.2 → ${NN.lr.toFixed(4)}`);}
 // Push Kalman to track faster
 if(KF.Q[0]<0.05){KF.Q[0]*=2;KF.Q[1]*=2;changes.push(`KF.Q doubled [faster tracking]`);}
 // ⑦ Cluster-Targeted Boost: target dominant cluster frequency range
 if(FREQ_CLUSTER.groups&&FREQ_CLUSTER.groups.length>0){const dom=FREQ_CLUSTER.groups.slice().sort((a,b)=>(b.count||0)-(a.count||0))[0];const cHz=((dom.min||0)+(dom.max||0))/2;if(cHz<80){appState.iLv=Math.min(1,appState.iLv*1.08);changes.push(`CLUSTER-BOOST INF ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}else if(cHz<500){appState.pLv=Math.min(1,appState.pLv*1.08);changes.push(`CLUSTER-BOOST PHF ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}else{appState.uLv=Math.min(1,appState.uLv*1.08);changes.push(`CLUSTER-BOOST ULT ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}}
 return changes;
 }
 },

 RESET_KF:{
 desc:'Resets Kalman filter state — use if tracking is stuck',
 run(st){
 // ⑤ Context-Anchored KF Reset: seed from AI_CTX.topFreqs if available
 const seedHz=(AI_CTX.topFreqs&&AI_CTX.topFreqs.length>0)?AI_CTX.topFreqs[0].hz:(appState.fanFreq||0);
 KF.x=[seedHz,0];KF.P=[2,1];KF.Q=[.01,.1];KF.R=5;KF.init=seedHz>0;
 return[`KF reset: x=[${seedHz.toFixed(1)},0] P=[2,1] (seeded from ${(AI_CTX.topFreqs&&AI_CTX.topFreqs.length>0)?'AI_CTX.topFreqs':'fanFreq'})`];
 }
 },

 RESET_BAYES:{
 desc:'Resets Bayesian mixer to equal weights w₁=w₂=w₃=0.333',
 run(st){
 DRV.wS=1/3;DRV.wE=1/3;DRV.wM=1/3;
 return[`Bayesian equalized: w₁=w₂=w₃=${(1/3).toFixed(3)}`];
 }
 },

 ANALYZE:{
 desc:'Full engine state analysis + AI_CTX history + UDS stats',
 run(st){
 const lines=[];const nyq=(st.actxSR/2)||24000;
 lines.push(`Cycle:${st.aiCyc} · Silence:${st.silSc}% · Best:${st.bestSil}%`);
 lines.push(`FreqDB:${st.freqDB.size} · conf:${st.freqFile.totalConf} · canc:${st.freqFile.totalCanc}`);
 lines.push(`NN: trained=${st.NN.trainN} · loss=${st.NN.loss.toFixed(4)} · lr=${st.NN.lr.toFixed(4)}`);
 lines.push(`SF: INF=${appState.iLv.toFixed(2)} ULT=${appState.uLv.toFixed(2)} PHF=${appState.pLv.toFixed(2)} SUB=${appState.bLv.toFixed(2)}`);
 const tot=Object.values(st.FC).reduce((a,b)=>a+b,0)||1;
 const dom=Object.entries(st.FC).sort((a,b)=>b[1]-a[1])[0];
 lines.push(`DOM-class:${dom[0]} (${(dom[1]/tot*100).toFixed(0)}%)`);
 lines.push(`EVP:${(st.evpE*100).toFixed(0)}%@${st.evpHz.toFixed(1)}Hz · EMF:${(st.emfE*100).toFixed(0)}%`);
 lines.push(`Loop:${st.loopN} · err:${(st.loopE*100).toFixed(2)}%`);
 lines.push(`Bayesian w₁=${(st.DRV.wS*100).toFixed(0)}% w₂=${(st.DRV.wE*100).toFixed(0)}% w₃=${(st.DRV.wM*100).toFixed(0)}%`);
 // Recommendations
 if(st.silSc<20)lines.push('→ RUN: BOOST_SIL (silence critical)');
 else if(st.silSc<50)lines.push('→ RUN: OPTIMIZE_SF + TUNE_NN');
 if(st.NN.loss>0.5)lines.push('→ RUN: TUNE_NN (high loss)');
 if(st.freqDB.size>80)lines.push('→ RUN: ADAPT_THRESH (large DB)');
 if(st.freqFile.totalConf>5&&st.freqFile.totalCanc/st.freqFile.totalConf<0.2)
 lines.push('→ RUN: INVERSE_STRAT (low cancel rate)');
 // AI_CTX derived insights
 if(AI_CTX.ready){
 lines.push(`# db: topHz=${AI_CTX.topFreqs.map(f=>f.hz+'(×'+f.count+')').slice(0,3).join(' ')}`);
 lines.push(`# db: cohTrend=${AI_CTX.cohTrend.toFixed(3)} Δ=${AI_CTX.cohDelta.toFixed(3)} nnTrend=${AI_CTX.nnLossTrend.toFixed(5)}`);
 lines.push(`# db: patterns=${AI_CTX.confirmedPatterns.length} bestProg=${AI_CTX.bestProg||'—'} execStats=${Object.keys(AI_CTX.execStats).length}`);
 if(AI_CTX.bestProg&&AI_LIB[AI_CTX.bestProg])
 lines.push(`→ PREFERRED: ${AI_CTX.bestProg} (highest silence gain in history)`);
 }
 // ⑥ FreqDB Entropy Monitor: measure distribution spread of spectral energy
 if(st.freqDB.size>2){let eTot=0,eEnt=0;st.freqDB.forEach(v=>{eTot+=(v.energy||0.01);});st.freqDB.forEach(v=>{const p=(v.energy||0.01)/eTot;if(p>0)eEnt-=p*Math.log2(p);});const mxE=Math.log2(st.freqDB.size);const nEnt=mxE>0?eEnt/mxE:0;lines.push(`FreqDB entropy: ${eEnt.toFixed(2)}bits · norm=${nEnt.toFixed(2)} (${nEnt<0.3?'NARROW':nEnt>0.85?'WIDE':'MIXED'})`);if(nEnt<0.2&&st.freqDB.size>10)lines.push('→ Low entropy: overfitting narrow band — consider RESET_KF');}
 return lines;
 }
 },

 SELF_OPTIMIZE:{
 desc:'Meta-program: adapts to history — runs META_ADAPT then top effective programs',
 run(st){
 const log=[];
 // ⑩ PERSIST History Seed: if stored history >> active bans, elevate INVERSE_STRAT
 const pTotal=PERSIST.totalCount();if(pTotal>AI_BAN.size*1.5)log.push(`PERSIST History: ${pTotal} stored > ${AI_BAN.size} active — elevating INVERSE_STRAT`);
 // 1. Always analyze first
 log.push('--- ANALYZE ---');log.push(...AI_LIB.ANALYZE.run(st));
 // 2. Run META_ADAPT to learn which programs are effective
 log.push('--- META_ADAPT ---');log.push(...AI_LIB.META_ADAPT.run(st));
 // 3. Build adaptive run list from ranked programs (skip low-eff)
 const alwaysRun=['OPTIMIZE_SF','TUNE_NN','ADAPT_THRESH'];
 const extras=[];
 if(st.freqFile.totalConf>3)extras.push('INVERSE_STRAT');
 if(AI_CTX.confirmedPatterns.length>0)extras.push('FREQ_PREDICT');
 if(st.freqDB.size>=5)extras.push('PATTERN_LEARN');
 // Rank by effectiveness from META_ADAPT output
 const ranked=AI_CTX.rankedProgs.length
 ? AI_CTX.rankedProgs.filter(n=>AI_LIB[n]&&!AI_CTX.lowEffProgs.has(n))
 : alwaysRun;
 const toRun=[...new Set([...ranked.slice(0,3),...alwaysRun,...extras])].slice(0,6);
 toRun.forEach(name=>{
 if(AI_LIB[name]){log.push(`--- ${name} ---`);log.push(...AI_LIB[name].run(st));}
 });
 return log;
 }
 },

 FREQ_PREDICT:{
 desc:'Predicts next dominant frequencies from pattern history → pre-positions inverses',
 run(st){
 const lines=[];
 if(!AI_CTX.confirmedPatterns.length&&st.freqDB.size===0)
 return['FREQ_PREDICT: no pattern data yet — run longer to capture freqs'];
 // Use both confirmed patterns and freqDB
 const allHz=[];
 AI_CTX.confirmedPatterns.forEach(p=>allHz.push({hz:parseFloat(p.hz),w:p.count||1}));
 if(!allHz.length)freqDB.forEach((v,k)=>allHz.push({hz:parseFloat(k),w:v.count||1}));
 if(!allHz.length)return['FREQ_PREDICT: FreqDB empty'];
 allHz.sort((a,b)=>b.w-a.w);
 const topHz=allHz[0].hz;
 // Harmonic series prediction
 const harmonics=[1,2,3,4].map(n=>parseFloat((topHz*n).toFixed(1)));
 const subHarm=parseFloat((topHz/2).toFixed(1));
 lines.push(`Dominant source: ${topHz}Hz (w=${allHz[0].w})`);
 lines.push(`Harmonic series: ${harmonics.join('Hz · ')}Hz`);
 lines.push(`Sub-harmonic: ${subHarm}Hz`);
 // Band analysis
 const bands={sub:allHz.filter(f=>f.hz<20),inf:allHz.filter(f=>f.hz>=20&&f.hz<200),aud:allHz.filter(f=>f.hz>=200&&f.hz<2000),hf:allHz.filter(f=>f.hz>=2000)};
 const domBand=Object.entries(bands).sort((a,b)=>b[1].length-a[1].length)[0];
 lines.push(`Band distribution: sub=${bands.sub.length} inf=${bands.inf.length} aud=${bands.aud.length} hf=${bands.hf.length}`);
 lines.push(`Dominant band: ${domBand[0]} (${domBand[1].length} entries)`);
 // Frequency spacing → noise type hint
 if(allHz.length>2){
 const intervals=[];
 for(let i=1;i<Math.min(allHz.length,6);i++)intervals.push(Math.abs(allHz[i].hz-allHz[i-1].hz));
 const avgInt=intervals.reduce((a,b)=>a+b,0)/intervals.length;
 const noiseHint=avgInt<30?'harmonic hum':avgInt<200?'tonal noise':'broadband';
 lines.push(`Freq spacing: avg=${avgInt.toFixed(0)}Hz → ${noiseHint}`);
 }
 // Store prediction
 const predicted=harmonics[1]; // 2nd harmonic most likely next
 AI_CTX.predictedHz=predicted;
 lines.push(`→ PREDICTED NEXT: ${predicted}Hz (2nd harmonic)`);
 lines.push(`→ PRE-ARM: queued inverse for ${predicted}Hz`);
 // ③ Recurrence-Guided Prediction: ETA from RECURRENCE.period
 if(RECURRENCE.period>0&&RECURRENCE.det>0.5){const etaCyc=RECURRENCE.period-((appState.aiCyc)%RECURRENCE.period||RECURRENCE.period);lines.push(`→ RECURRENCE: period=${RECURRENCE.period}cyc · det=${RECURRENCE.det.toFixed(2)} · ETA ~${etaCyc} cycles`);}
 return lines;
 }
 },

 PATTERN_LEARN:{
 desc:'K-means clustering of freqDB → noise signature → adapts Bayesian weights',
 run(st){
 const lines=[];
 if(st.freqDB.size<5)return[`PATTERN_LEARN: FreqDB=${st.freqDB.size} (need ≥5)`];
 // Extract frequency list
 const freqs=[...freqDB.keys()].map(k=>({hz:parseFloat(k),count:freqDB.get(k).count||1}));
 freqs.sort((a,b)=>a.hz-b.hz);
 const hzArr=freqs.map(f=>f.hz);
 // 1D k-means with k=3, 10 iterations
 let c=[hzArr[0],hzArr[Math.floor(hzArr.length/2)],hzArr[hzArr.length-1]];
 for(let iter=0;iter<10;iter++){
 const g=[[],[],[]];
 hzArr.forEach(hz=>{const d=c.map(ci=>Math.abs(hz-ci));g[d.indexOf(Math.min(...d))].push(hz);});
 c=g.map((gr,i)=>gr.length?gr.reduce((a,b)=>a+b,0)/gr.length:c[i]);
 }
 lines.push(`Clusters: A=${c[0].toFixed(0)}Hz · B=${c[1].toFixed(0)}Hz · C=${c[2].toFixed(0)}Hz`);
 // Noise signature from cluster spread
 const spread=c[2]-c[0];
 let sig='unknown';
 if(spread<50)sig='tonal/hum';
 else if(spread<300)sig='narrowband';
 else if(spread<2000)sig='mixed';
 else sig='wideband';
 AI_CTX.noiseSignature=sig;
 lines.push(`Noise signature: ${sig} (spread=${spread.toFixed(0)}Hz)`);
 // Bayesian weight optimization per signature
 const prev={wS:DRV.wS.toFixed(2),wE:DRV.wE.toFixed(2),wM:DRV.wM.toFixed(2)};
 if(sig==='tonal/hum'){DRV.wS=0.60;DRV.wE=0.25;DRV.wM=0.15;}
 else if(sig==='narrowband'){DRV.wS=0.45;DRV.wE=0.35;DRV.wM=0.20;}
 else if(sig==='mixed'){DRV.wS=0.35;DRV.wE=0.35;DRV.wM=0.30;}
 else if(sig==='wideband'){DRV.wS=0.25;DRV.wE=0.45;DRV.wM=0.30;}
 lines.push(`Bayes ${prev.wS}/${prev.wE}/${prev.wM} → ${DRV.wS.toFixed(2)}/${DRV.wE.toFixed(2)}/${DRV.wM.toFixed(2)} [${sig}]`);
 // Most weighted frequencies
 const topFreqs=freqs.sort((a,b)=>b.count-a.count).slice(0,3);
 lines.push(`Top targets: ${topFreqs.map(f=>f.hz+'Hz(×'+f.count+')').join(' · ')}`);
 // Coherence feedback
 if(AI_CTX.cohTrend>0.7)lines.push(`→ High coherence (${AI_CTX.cohTrend.toFixed(2)}) — stay course`);
 else if(AI_CTX.cohTrend<0.3)lines.push(`→ Low coherence (${AI_CTX.cohTrend.toFixed(2)}) — consider RESET_KF`);
 // ④ Hebbian-Pattern Co-Registration: reinforce inter-cluster frequency pairs
 if(c.length>=2){hebbLearn(c[0],c[1],.05);if(c[2])hebbLearn(c[1],c[2],.03);lines.push(`Hebbian: reinforced ${c[0].toFixed(0)}↔${c[1].toFixed(0)}Hz cluster pair`);}
 return lines;
 }
 },

 META_ADAPT:{
 desc:'Meta-learning: ranks programs by silence efficiency (UCB1) → reshapes exec schedule',
 run(st){
 const lines=[];
 const stats=AI_CTX.execStats;
 if(!stats||!Object.keys(stats).length)
 return['META_ADAPT: no exec history yet — needs more cycles'];
 // Compute efficiency = avgSil / (avgMs + 1) — silence per millisecond
 const totalRuns=Object.values(stats).reduce((a,s)=>a+s.runs,0)||1;
 const eff=Object.entries(stats).map(([name,s])=>{
 const avgSil=parseFloat(s.avgSil)||0;
 const avgMs=parseFloat(s.avgMs)||1;
 const runs=s.runs||1;
 const exploit=avgSil;
 const explore=2*Math.sqrt(Math.log(totalRuns)/runs);
 return{name,eff:avgSil/(avgMs+1),ucb:exploit+explore,runs,avgSil,avgMs};
 }).sort((a,b)=>b.ucb-a.ucb);
 lines.push(`UCB1 ranking (runs=${totalRuns}):`);
 eff.slice(0,6).forEach((e,i)=>
 lines.push(` ${i+1}. ${e.name}: sil=${e.avgSil.toFixed(1)}% ucb=${e.ucb.toFixed(2)} runs=${e.runs}`));
 // Update AI_CTX
 AI_CTX.rankedProgs=eff.map(e=>e.name);
 // Flag underperformers (eff<0.01 with ≥8 runs)
 const underperf=eff.filter(e=>e.eff<0.01&&e.runs>=8);
 AI_CTX.lowEffProgs=new Set(underperf.map(e=>e.name));
 if(underperf.length)lines.push(`Low-eff (skip): ${underperf.map(e=>e.name).join(' ')}`);
 // Set priority program
 const top=eff[0];
 if(top&&top.avgSil>appState.silSc+3){
 AI_CTX.priorityProg=top.name;
 lines.push(`→ PRIORITY → ${top.name} (sil gain=${( top.avgSil-appState.silSc).toFixed(1)}%)`);
 } else {
 AI_CTX.priorityProg=null;
 lines.push(`→ No single dominant — balanced scheduling`);
 }
 // Noise signature context
 if(AI_CTX.noiseSignature!=='unknown')
 lines.push(`Noise: ${AI_CTX.noiseSignature} · cohTrend=${AI_CTX.cohTrend.toFixed(2)}`);
 // ② META Loss Trend Gate: NN stagnation → auto-trigger RESET_BAYES
 if(NN.hist.length>=20){const sl20=NN.hist.slice(-20);const lSlope=Math.abs((sl20[19].loss-sl20[0].loss)/20);if(lSlope<0.0002&&NN.loss>0.3){AI_LIB.RESET_BAYES.run(st);lines.push(`RESET_BAYES triggered [NN stagnant Δloss=${lSlope.toFixed(6)}]`);}}
 return lines;
 }
 },

 FREQ_GATE:{
 desc:'AI ban/unban gate: detects chronically-failing freqs → bans them to free resources',
 run(st){
 const lines=[];
 if(!AI_GATE.enabled)return['FREQ_GATE: gate disabled (AI_GATE.enabled=false)'];
 // Auto-unban expired entries
 let unbanned=0;
 AI_BAN.forEach((d,bin)=>{
 if(execCyc>=d.autoUnbanAt){AI_BAN.delete(bin);unbanned++;}
 else{d.cycles=execCyc-d.bannedAt;}
 });
 if(unbanned)lines.push(`Auto-unbanned: ${unbanned} frequencies (trial re-entry)`);
 // Scan INV.failed for chronic high-fail frequencies
 const failCandidates=[];
 INV.failed.forEach((d,hz)=>{
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return; // already banned
 // Get active inverse attempts
 const activeInv=st.INV.active.get(hz);
 const attempts=activeInv?activeInv.attempts:INV.maxTry;
 if(attempts>=AI_GATE.failThresh){
 const entry=freqDB.get(bin);
 if(entry&&entry.confirmed){
 failCandidates.push({hz,bin,attempts,energy:entry.energy});
 }
 }
 });
 // Also check confirmed freqs with no successful inverse
 freqDB.forEach((e,bin)=>{
 if(!e.confirmed||AI_BAN.has(bin))return;
 // If confirmed but no inverse succeeded after many attempts
 if(e.invOk===false&&e.count>appState.FREQ_THRESH*2){
 const score=e.energy/(e.count||1);
 if(score<0.01){failCandidates.push({hz:parseFloat(bin),bin:parseFloat(bin),attempts:e.count,energy:e.energy});}
 }
 });
 // Deduplicate
 const unique=[];const seen=new Set();
 failCandidates.forEach(f=>{if(!seen.has(f.bin)){seen.add(f.bin);unique.push(f);}});
 if(unique.length===0){
 lines.push(`FREQ_GATE: ${AI_BAN.size} banned · no new candidates`);
 lines.push(`Watched: ${INV.failed.size} failed inverse entries`);
 return lines;
 }
 // Ban up to available slots — السقف على الجديد فقط (بدون الأساسي/المؤكَّد)
 const slots=AI_GATE.maxBan-newBanCount();
 const toBan=unique.slice(0,Math.max(0,slots));
 toBan.forEach(f=>{
 // ⑧ Recurrence-Weighted Ban: amplify ban priority if freq aligns with recurrence period
 const recW=RECURRENCE.det>0.5&&Math.abs(f.hz-appState.fanFreq)<(appState.fanFreq*.05)?2:1;
 banFreq(f.hz,'GATE:fail×'+f.attempts+(recW>1?'+REC':''));
 lines.push(`→ BANNED ${f.hz.toFixed(2)}Hz (fail×${f.attempts} energy=${(f.energy*100).toFixed(1)}%${recW>1?' +RECURRENCE':''})`);
 });
 const skipped=unique.length-toBan.length;
 lines.push(`Total banned: ${AI_BAN.size} (new: ${newBanCount()}/${AI_GATE.maxBan})${skipped>0?' (+'+skipped+' queue full)':''}`);
 // Report current ban list
 if(AI_BAN.size){
 lines.push('Active bans:');
 [...AI_BAN.entries()].slice(0,6).forEach(([hz,d])=>lines.push(` ${hz.toFixed(2)}Hz [${d.reason}] منذ c${d.bannedAt}`));
 }
 renderBanList();
 return lines;
 }
 }
};

/* ══ EXEC ENGINE ══ */

window.AI_LIB=AI_LIB;

})();
/* ── 07b-ai-exec-engine.js ── */

'use strict';
(function(){

let execTotal=0;const EXEC_LOG=[];

function getExecType(prog){
 if(['BOOST_SIL','WARN'].includes(prog))return'warn';
 if(['ERROR','ERR'].includes(prog))return'err';
 if(['SYS','INIT','STATE','LIST','RANK'].includes(prog))return'sys';
 if(['SELF_OPTIMIZE','ANALYZE','META_ADAPT','PATTERN_LEARN','FREQ_PREDICT','FREQ_GATE'].includes(prog))return'opt';
 return'';
}

function logExec({prog,lines,ms,cycle,auto}){
 const ts=new Date();const t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0')+'.'+String(ts.getMilliseconds()).slice(0,2);
 execTotal++;
 const entry={prog,lines,ms:ms||0,t,cycle:cycle||appState.aiCyc,auto:!!auto};
 EXEC_LOG.unshift(entry);if(EXEC_LOG.length>80)EXEC_LOG.pop();
 // ── Write to UDS exec_history (AI's action log) ─
 udsWriteExec({prog,lines,ms:ms||0,cycle:cycle||appState.aiCyc,auto:!!auto});
 // Update exec stat bar
 const ep=E('ex-prog');if(ep)ep.textContent=execTotal;
 const ec=E('execCurr');if(ec)ec.textContent=prog;
 const el=E('execDot');if(el)el.className='exec-run-dot run';
 setTimeout(()=>{const el2=E('execDot');if(el2&&!appState.isRun)el2.className='exec-run-dot';},600);
 // logNN removed — avoid tLog→logExec→logNN→tLog cycle
 if(curTab===5)renderExecLog();
}

function renderExecLog(){
 const el=E('execLog');if(!el)return;
 el.innerHTML=EXEC_LOG.slice(0,18).map(e=>{
 const type=getExecType(e.prog);
 const arrow=type==='warn'?'warn':type==='err'?'err':'mod';
 const linesHtml=(e.lines||[]).map(l=>`<div class="exec-line"><span class="exec-arrow ${arrow}">→</span><span>${escH(l)}</span></div>`).join('');
 return`<div class="exec-entry ${type}">
 <div class="exec-eh">
 <span class="exec-prog ${type}">${e.auto?'':'▶'} ${e.prog}</span>
 <span class="exec-meta">${e.t}${e.ms?' · '+e.ms+'ms':''}</span>
 </div>
 <div class="exec-lines">${linesHtml}</div>
 </div>`;
 }).join('');
 el.scrollTop=0;
}

/* أُضيف escH(&quot;) لاحقاً (تشديد اكثر — ثغرة حقن HTML عبر أسماء ملفات المجلد الثابت، انظر
 renderFixedFolderBrowser): لا يغيّر سلوك أي من نداءات escH() الحالية (كلها داخل عقدة نص لا
 سمة HTML، حيث لا فرق مرئي بين " الحرفي وHTML&quot; بعد تحليل المتصفح لهما). */
function escH(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

/* ══ AUTONOMOUS EXEC CYCLE ══ */
window.execCyc=0;let lastSilForBoost=0,boostCooldown=0;

/* UCB1 bandit selector — picks program with highest exploration-exploitation score */
function ucb1Select(){
 const CANDIDATES=['OPTIMIZE_SF','TUNE_NN','ADAPT_THRESH','INVERSE_STRAT','FREQ_PREDICT','PATTERN_LEARN'];
 // Remove low-efficiency programs tagged by META_ADAPT
 const active=CANDIDATES.filter(n=>AI_LIB[n]&&!AI_CTX.lowEffProgs.has(n));
 if(!active.length)return{ucbProg:AI_LIB.OPTIMIZE_SF,ucbName:'OPTIMIZE_SF'};
 const stats=AI_CTX.execStats||{};
 const totalRuns=Object.values(stats).reduce((a,s)=>a+s.runs,0)||1;
 const scores=active.map(n=>{
 const s=stats[n];
 if(!s||!s.runs)return{name:n,score:9999}; // unexplored → top priority
 const exploit=parseFloat(s.avgSil)||0;
 const lossFact=NN&&NN.loss>0.4?Math.min(2.5,1.5+NN.loss*1.5):1.5;// ⑨ Loss-Gated UCB1
 const fluxFact=typeof SPEC_FLUX!=='undefined'&&SPEC_FLUX.val>0.4?Math.min(1.8,1+SPEC_FLUX.val):1;// ⑥ Flux-Volatility
 const explore=lossFact*fluxFact*Math.sqrt(Math.log(totalRuns)/s.runs);
 return{name:n,score:exploit+explore};
 });
 scores.sort((a,b)=>b.score-a.score);
 const best=scores[0].name;
 return{ucbProg:AI_LIB[best],ucbName:best};
}

function aiExecCycle(){
 if(!appState.isRun||!NN.w1)return;
 execCyc++;
 const st=getState();
 let prog,progName;
 // ── Priority ladder ──────────────────────────────
 // P1: Emergency silence boost
 if(st.silSc<15&&execCyc-boostCooldown>30){
 prog=AI_LIB.BOOST_SIL;progName='BOOST_SIL';boostCooldown=execCyc;
 }
 // P2: META_ADAPT — reshapes scheduler every 80 cycles
 else if(execCyc%80===0){
 prog=AI_LIB.META_ADAPT;progName='META_ADAPT';
 }
 // P3: Full self-optimize every 50 cycles
 else if(execCyc%50===0){
 prog=AI_LIB.SELF_OPTIMIZE;progName='SELF_OPTIMIZE';
 }
 // P4: PATTERN_LEARN every 40 cycles when DB has data
 else if(execCyc%40===0&&st.freqDB.size>=5){
 prog=AI_LIB.PATTERN_LEARN;progName='PATTERN_LEARN';
 }
 // P5: FREQ_PREDICT every 30 cycles when patterns exist
 else if(execCyc%30===0&&(AI_CTX.confirmedPatterns.length>0||st.freqDB.size>3)){
 prog=AI_LIB.FREQ_PREDICT;progName='FREQ_PREDICT';
 }
 // P5b: FREQ_GATE every 35 cycles (ban chronic failures)
 else if(execCyc%35===0&&AI_GATE.enabled){
 prog=AI_LIB.FREQ_GATE;progName='FREQ_GATE';
 }
 // P6: Priority program from META_ADAPT every 8 cycles
 else if(AI_CTX.priorityProg&&AI_LIB[AI_CTX.priorityProg]&&execCyc%8===0){
 progName=AI_CTX.priorityProg;prog=AI_LIB[progName];
 }
 // P7: High NN loss → tune every 15 cycles
 else if(st.NN.loss>0.4&&execCyc%15===0){
 prog=AI_LIB.TUNE_NN;progName='TUNE_NN';
 }
 // P8: UCB1 bandit selection every 5 cycles
 else if(execCyc%5===0){
 const sel=ucb1Select();prog=sel.ucbProg;progName=sel.ucbName;
 }
 else return; // idle cycle
 // ── Execute ──────────────────────────────────────
 const t0=performance.now();
 const lines=prog.run(st);
 const ms=Math.round(performance.now()-t0);
 logExec({prog:progName,lines,ms,cycle:appState.aiCyc,auto:true});
 // Auto-ban check every 25 cycles
 if(execCyc%25===0)autoBanCheck();
 // Update exec stat bar
 const es=E('ex-sil');if(es)es.textContent=st.silSc+'%';
 const en=E('ex-nn');if(en)en.textContent=NN.loss.toFixed(3);
 const ed=E('ex-db');if(ed)ed.textContent=freqDB.size;
}

/* ══ MANUAL COMMAND EXECUTOR ══ */
function runExecCmd(){
 const inp=E('execInp');if(!inp)return;
 const raw=inp.value.trim();inp.value='';
 if(!raw)return;
 const parts=raw.toUpperCase().split(/\s+/);
 const cmd=parts[0];const st=getState();
 // Direct program names
 if(AI_LIB[cmd]){
 const t0=performance.now();
 const lines=AI_LIB[cmd].run(st);
 logExec({prog:cmd,lines,ms:Math.round(performance.now()-t0),auto:false});
 return;
 }
 // SET path value
 if(cmd==='SET'){
 const path=parts[1]||'';const val=parseFloat(parts[2]);
 if(isNaN(val)){logExec({prog:'SET',lines:['Error: SET <path> <value> e.g. SET SF.INF 0.8'],auto:false});return;}
 const setMap={
 'SF.INF':()=>{const p=appState.iLv;appState.iLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.INF ${p.toFixed(3)}→${appState.iLv.toFixed(3)}`;},
 'SF.ULT':()=>{const p=appState.uLv;appState.uLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.ULT ${p.toFixed(3)}→${appState.uLv.toFixed(3)}`;},
 'SF.PHF':()=>{const p=appState.pLv;appState.pLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.PHF ${p.toFixed(3)}→${appState.pLv.toFixed(3)}`;},
 'SF.SUB':()=>{const p=appState.bLv;appState.bLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.SUB ${p.toFixed(3)}→${appState.bLv.toFixed(3)}`;},
 'SF.PIE':()=>{const p=appState.eLv;appState.eLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.PIE ${p.toFixed(3)}→${appState.eLv.toFixed(3)}`;},
 'NN.LR':()=>{const p=NN.lr;NN.lr=Math.max(0.0001,Math.min(0.1,val));return`NN.LR ${p.toFixed(4)}→${NN.lr.toFixed(4)}`;},
 'NN.MOM':()=>{const p=NN.mom;NN.mom=Math.max(0.1,Math.min(0.999,val));return`NN.MOM ${p.toFixed(4)}→${NN.mom.toFixed(4)}`;},
 'THRESH':()=>{const p=appState.FREQ_THRESH;appState.FREQ_THRESH=Math.max(2,Math.min(10,Math.round(val)));return`FREQ_THRESH ${p}→${appState.FREQ_THRESH}`;},
 'WIENER.A':()=>{const p=P.alpha;P.alpha=Math.max(0.1,Math.min(5,val));return`Wiener.α ${p.toFixed(3)}→${P.alpha.toFixed(3)}`;},
 'KF.R':()=>{const p=KF.R;KF.R=Math.max(0.01,Math.min(200,val));return`KF.R ${p}→${KF.R}`;},
 'MU':()=>{const p=P.mu;P.mu=Math.max(0.001,Math.min(0.5,val));return`FxLMS.μ ${p.toFixed(4)}→${P.mu.toFixed(4)}`;},
 };
 const fn=setMap[path];
 if(fn)logExec({prog:'SET',lines:[fn()],auto:false});
 else logExec({prog:'SET',lines:['Unknown: '+path,'Valid: SF.INF SF.ULT SF.PHF SF.SUB SF.PIE NN.LR NN.MOM THRESH WIENER.A KF.R MU'],auto:false});
 return;
 }
 // STATE dump
 if(cmd==='STATE'){
 logExec({prog:'STATE',lines:[
 `sil=${st.silSc}% best=${st.bestSil}% cyc=${st.aiCyc} loop=${st.loopN}`,
 `src=${st.fanFreq.toFixed(2)}Hz E=${(st.fanE*100).toFixed(0)}% noise=${(st.noiseE*100).toFixed(0)}%`,
 `NN: trained=${st.NN.trainN} loss=${st.NN.loss.toFixed(4)} lr=${st.NN.lr.toFixed(4)} mom=${st.NN.mom}`,
 `SF: INF=${appState.iLv.toFixed(3)} ULT=${appState.uLv.toFixed(3)} PHF=${appState.pLv.toFixed(3)} SUB=${appState.bLv.toFixed(3)} PIE=${appState.eLv.toFixed(3)}`,
 `C1=${st.FC.c1} C2=${st.FC.c2} C3=${st.FC.c3} C4=${st.FC.c4} C5=${st.FC.c5} C6=${st.FC.c6} C7=${st.FC.c7} C8=${st.FC.c8}`,
 `THRESH=${appState.FREQ_THRESH} · Wiener.α=${P.alpha.toFixed(2)} · KF.R=${KF.R} · μ=${P.mu}`,
 `DB:${st.freqDB.size} conf:${st.freqFile.totalConf} canc:${st.freqFile.totalCanc} inv:${st.INV.active.size}`,
 `Bayes: w1=${(st.DRV.wS*100).toFixed(0)}% w2=${(st.DRV.wE*100).toFixed(0)}% w3=${(st.DRV.wM*100).toFixed(0)}%`,
 ],auto:false});
 return;
 }
 // LIST programs
 if(cmd==='LIST'){
 logExec({prog:'LIST',lines:Object.entries(AI_LIB).map(([k,v])=>`${k}: ${v.desc}`),auto:false});
 return;
 }
 // DB QUERY commands
 if(cmd==='QUERY'){
 const qType=(parts[1]||'FREQ').toUpperCase();
 const qLimit=parseInt(parts[2])||30;
 udsQueryEvents(qType,qLimit).then(events=>{
 const lines=[`query: terminal_events WHERE type='${qType}' LIMIT ${qLimit}`,`found: ${events.length} events`];
 events.slice(0,10).forEach(e=>lines.push(` [${e.t}] ${e.code.slice(0,60)}`));
 if(events.length>10)lines.push(` ... +${events.length-10} more`);
 tLog('SYS',`>>> QUERY ${qType} ${qLimit}`,lines.join('\n'));
 });
 return;
 }
 if(cmd==='PATTERN'){
 udsQueryPatterns().then(patterns=>{
 const lines=[`query: freq_patterns ORDER BY count DESC`,`found: ${patterns.length} patterns`];
 patterns.slice(0,12).forEach(p=>{
 const cn=['','C1⊕','C2⊖','C3∓','C4±','C5','C6','C7','C8'][p.classId||0]||'';
 lines.push(` hz=${p.hz.toFixed(2)} count=${p.count} class=${cn} @sil=${p.silSc}%`);
 });
 tLog('SYS',`>>> PATTERN`,lines.join('\n'));
 });
 return;
 }
 if(cmd==='CONTEXT'){
 const lines=[
 `AI_CTX.ready=${AI_CTX.ready} updated=${AI_CTX.updateCount}×`,
 `topFreqs: ${AI_CTX.topFreqs.slice(0,5).map(f=>f.hz+'(×'+f.count+')').join(' ')||'none'}`,
 `cohTrend=${AI_CTX.cohTrend.toFixed(4)} Δ=${AI_CTX.cohDelta.toFixed(4)}`,
 `nnLossTrend=${AI_CTX.nnLossTrend.toFixed(6)} bestLoss=${AI_CTX.nnBestLoss.toFixed(4)}`,
 `bestProg=${AI_CTX.bestProg||'—'} patterns=${AI_CTX.confirmedPatterns.length}`,
 `execStats: ${Object.entries(AI_CTX.execStats).slice(0,4).map(([k,v])=>k+'('+v.runs+'rx)').join(' ')}`,
 `noiseSignature=${AI_CTX.noiseSignature} predictedHz=${AI_CTX.predictedHz||'—'}`,
 `priorityProg=${AI_CTX.priorityProg||'—'} rankedProgs=[${AI_CTX.rankedProgs.slice(0,4).join(',')}]`,
 `lowEffProgs: ${[...AI_CTX.lowEffProgs].join(' ')||'none'}`,
 `AI_BAN: ${AI_BAN.size} total (new ${newBanCount()}/${AI_GATE.maxBan}) · gate=${AI_GATE.enabled?'ON':'OFF'}`,
 `perms: mic=${PERMS.mic} notif=${PERMS.notifications} store=${PERMS.storage} wake=${PERMS.wakeLock} file=${PERMS.fileAccess}`,
 ];
 tLog('SYS',`>>> CONTEXT`,lines.join('\n'));
 return;
 }
 if(cmd==='PREDICT'){
 const st=getState();
 const t0=performance.now();
 const lines=AI_LIB.FREQ_PREDICT.run(st);
 logExec({prog:'FREQ_PREDICT',lines,ms:Math.round(performance.now()-t0),auto:false});
 return;
 }
 if(cmd==='RANK'){
 // Show UCB1 ranking from META_ADAPT
 if(!AI_CTX.rankedProgs.length){logExec({prog:'RANK',lines:['No ranking yet — run META_ADAPT or SELF_OPTIMIZE first'],auto:false});return;}
 const stats=AI_CTX.execStats;
 const lines=AI_CTX.rankedProgs.map((n,i)=>{
 const s=stats[n];
 if(!s)return`${i+1}. ${n}: no history`;
 return`${i+1}. ${n}: sil=${parseFloat(s.avgSil).toFixed(1)}% ms=${parseFloat(s.avgMs).toFixed(0)} runs=${s.runs}${AI_CTX.lowEffProgs.has(n)?' [LOW-EFF]':''}${n===AI_CTX.priorityProg?' [PRIORITY]':''}`;
 });
 logExec({prog:'RANK',lines,auto:false});
 return;
 }
 if(cmd==='STATS'){
 udsGetStats().then(counts=>{
 navigator.storage&&navigator.storage.estimate().then(est=>{
 const lines=[
 `IndexedDB: ${DBNAME} v${DBVER}`,
 ...Object.entries(counts).map(([s,c])=>` ${s}: ${c} records`),
 `Storage used: ~${Math.round((est.usage||0)/1024)}KB / ${Math.round((est.quota||0)/1024/1024)}MB`,
 `Persist: ${AI_CTX.ready?'ready':'not ready'}`,
 ];
 if(typeof ZeroAndroid!=='undefined'){
 lines.push(`Android internal: ${ZeroAndroid.getInternalPath()}`);
 lines.push(`Android export: ${ZeroAndroid.getExportPath()}`);
 lines.push(`Storage used: ${Math.round(ZeroAndroid.getStorageUsed()/1024)}KB`);
 }
 tLog('SYS',`>>> STATS`,lines.join('\n'));
 }).catch(()=>{
 const lines=[`IndexedDB: ${DBNAME} v${DBVER}`,...Object.entries(counts).map(([s,c])=>` ${s}: ${c} records`)];
 tLog('SYS',`>>> STATS`,lines.join('\n'));
 });
 });
 return;
 }
 if(cmd==='REFRESH'){
 updateAICtx().then(()=>tLog('SYS','>>> REFRESH: AI_CTX updated from UDS'));
 return;
 }
 if(cmd==='ENV'){
 classifyEnvironment();
 const info=ENV_LABELS[curEnvClass]||ENV_LABELS.mixed;
 const sf=typeof SPEC_FLAT!=='undefined'?SPEC_FLAT.val:0;
 const hnr=typeof HNR!=='undefined'?HNR.val:0;
 const zcr=typeof ZCRATE!=='undefined'?ZCRATE.val:0;
 const crest=typeof CREST!=='undefined'?CREST.val:1;
 const lines=[
 `Environment: ${info.label}`,
 `SpectralFlat=${sf.toFixed(4)} HNR=${hnr.toFixed(1)}dB`,
 `ZCR=${zcr.toFixed(4)} Crest=${crest.toFixed(2)}`,
 `Silence=${appState.silSc}% FreqDB=${typeof freqDB!=='undefined'?freqDB.size:0}`,
 ];
 tLog('SYS',`>>> ENV`,lines.join('\n'));
 return;
 }
 if(cmd==='HISTORY'){
 const mins=parseInt(parts[1])||5;
 const cutoff=Date.now()-mins*60000;
 udsQueryEvents('ALL',500).then(evts=>{
 const recent=evts.filter(e=>(e.ts||0)>cutoff);
 tLog('SYS',`>>> HISTORY ${mins}min`,`${recent.length} events in last ${mins}min`);
 });
 return;
 }
 // BAN a frequency
 if(cmd==='BAN'){
 const hz=parseFloat(parts[1]);
 if(isNaN(hz)||hz<=0){logExec({prog:'BAN',lines:['Usage: BAN <hz> e.g. BAN 50'],auto:false});return;}
 const reason=(parts.slice(2).join(' '))||'manual';
 const ok=banFreq(hz,reason);
 logExec({prog:'BAN',lines:[ok?`Banned: ${fBin(hz).toFixed(2)}Hz (${reason})`:`Could not ban: max=${AI_GATE.maxBan} or already banned`],auto:false});
 return;
 }
 // UNBAN a frequency
 if(cmd==='UNBAN'){
 const hz=parseFloat(parts[1]);
 if(isNaN(hz)){
 if(parts[1]==='ALL'){AI_BAN.clear();PERSIST.saveBans();renderBanList();logExec({prog:'UNBAN',lines:['All frequencies unbanned',' PERSIST cleared — restart will load fresh'],auto:false});return;}
 if(parts[1]==='PERSIST'||parts[1]==='CACHE'){PERSIST.clear();AI_BAN.clear();renderBanList();logExec({prog:'UNBAN',lines:['PERSIST + AI_BAN cleared','Next restart: fresh start (12 defaults only)'],auto:false});return;}
 logExec({prog:'UNBAN',lines:['Usage: UNBAN <hz> or UNBAN ALL'],auto:false});return;
 }
 const ok=unbanFreq(hz);
 logExec({prog:'UNBAN',lines:[ok?`Unbanned: ${fBin(hz).toFixed(2)}Hz`:`Not banned: ${fBin(hz).toFixed(2)}Hz`],auto:false});
 return;
 }
 // BANLIST — show all banned
 if(cmd==='BANLIST'){
 if(!AI_BAN.size){logExec({prog:'BANLIST',lines:['No frequencies banned','Tip: BAN <hz> or let FREQ_GATE auto-ban'],auto:false});return;}
 const lines=[` ${AI_BAN.size} محضور دائماً (جديد: ${newBanCount()}/${AI_GATE.maxBan})`];
 [...AI_BAN.entries()].sort((a,b)=>a[0]-b[0]).forEach(([hz,d])=>
 lines.push(` ${hz.toFixed(2)}Hz [${d.reason}] (${execCyc-d.bannedAt} دورة)`));
 logExec({prog:'BANLIST',lines,auto:false});
 return;
 }
 // PARTITIONS — build and show
 if(cmd==='PARTITIONS'){
 const p=buildFreqPartitions();
 if(!p){logExec({prog:'PARTITIONS',lines:['FreqDB empty — run AI first to capture frequencies'],auto:false});return;}
 const lines=[
 `Partitions built at cycle ${p.aiCyc} sil=${p.silSc}%`,
 `hot=${p.counts.hot} cold=${p.counts.cold} conf=${p.counts.conf}`,
 `inv=${p.counts.inv} banned=${p.counts.banned} pred=${p.counts.predicted}`,
 `noise: ${p.noiseSignature}`,
 ];
 if(parts[1]==='SAVE'){saveFreqPartitions();lines.push('→ Saving to file...');}
 logExec({prog:'PARTITIONS',lines,auto:false});
 return;
 }
 // NOTCH — manage software notch suppression
 if(cmd==='NOTCH'){
 const sub=parts[1]||'';
 if(sub==='OFF'){NOTCH_SUPPRESS.clear();updateNotchUI();logExec({prog:'NOTCH',lines:['All notches cleared'],auto:false});}
 else if(sub==='LIST'){
 const ls=NOTCH_SUPPRESS.size?[...NOTCH_SUPPRESS.values()].map(n=>`${n.hz.toFixed(1)}Hz -${n.depth}dB ±${n.halfBins}bin${n.order>1?' ×'+n.order:''}`):'No active notches';
 logExec({prog:'NOTCH',lines:Array.isArray(ls)?['Active notches:',...ls]:['No active notches'],auto:false});
 } else if(sub==='HARM'){
 NOTCH_HARM.enabled=!NOTCH_HARM.enabled;
 logExec({prog:'NOTCH',lines:[`Harmonic chain: ${NOTCH_HARM.enabled?'ON ':'OFF '}`,`maxOrder=×${NOTCH_HARM.maxOrder} — adds 2f, 3f notches automatically`,'NOTCH HARM to toggle · NOTCH <hz> to add root'],auto:false});
 } else if(sub==='DECAY'){
 const val=parseFloat(parts[2]);
 if(parts[2]&&parts[2].toUpperCase()==='OFF'){NOTCH_DECAY.enabled=false;logExec({prog:'NOTCH',lines:['Notch decay: OFF '],auto:false});}
 else if(!isNaN(val)&&val>0){NOTCH_DECAY.afterMs=val*1000;NOTCH_DECAY.enabled=true;logExec({prog:'NOTCH',lines:[`Notch decay: ON — after ${val}s idle`],auto:false});}
 else{NOTCH_DECAY.enabled=!NOTCH_DECAY.enabled;logExec({prog:'NOTCH',lines:[`Notch decay: ${NOTCH_DECAY.enabled?'ON ':'OFF '}`,`Expires after ${NOTCH_DECAY.afterMs/1000}s · NOTCH DECAY <secs> · NOTCH DECAY OFF`],auto:false});}
 } else if(!isNaN(parseFloat(sub))&&parseFloat(sub)>0){
 const hz=parseFloat(sub);
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logExec({prog:'NOTCH',lines:[`Removed notch @ ${hz}Hz`],auto:false});}
 else{activateNotch(hz);logExec({prog:'NOTCH',lines:[`Added notch @ ${hz}Hz${NOTCH_HARM.enabled?' + harmonics':''}`],auto:false});}
 } else {
 logExec({prog:'NOTCH',lines:[`Active: ${NOTCH_SUPPRESS.size} notches`,'NOTCH LIST · NOTCH OFF · NOTCH <hz>','NOTCH HARM (harmonic chain) · NOTCH DECAY <secs>'],auto:false});
 }
 return;
 }
 // BAND — frequency band lock for KF tracking
 if(cmd==='BAND'){
 if(!parts[1]||parts[1].toUpperCase()==='OFF'){
 FREQ_BAND.enabled=false;
 logExec({prog:'BAND',lines:['Band lock: OFF — full spectrum tracking'],auto:false});
 } else if(!isNaN(parseFloat(parts[1]))&&!isNaN(parseFloat(parts[2]))){
 FREQ_BAND.lo=parseFloat(parts[1]);FREQ_BAND.hi=parseFloat(parts[2]);FREQ_BAND.enabled=true;
 logExec({prog:'BAND',lines:[`Band lock: ON — ${FREQ_BAND.lo}–${FREQ_BAND.hi}Hz`,'KF only tracks freqs within this range · BAND OFF to release'],auto:false});
 } else {
 logExec({prog:'BAND',lines:[`Band lock: ${FREQ_BAND.enabled?FREQ_BAND.lo+'–'+FREQ_BAND.hi+'Hz ':'OFF '}`,'Usage: BAND <lo> <hi> · BAND OFF','Example: BAND 40 120 (fan hum range)'],auto:false});
 }
 return;
 }
 // SCENE — named environment profile snapshots
 if(cmd==='SCENE'){
 const sub=(parts[1]||'').toUpperCase();
 const arg2=parts.slice(2).join(' ').trim()||parts[1]||'';
 if(!sub||sub==='LIST'){
 sceneList().then(ss=>{
 if(!ss.length){logExec({prog:'SCENE',lines:['No scenes saved','Use: SCENE SAVE <name>'],auto:false});return;}
 const fmtTs=ts=>{const d=new Date(ts);return d.toLocaleDateString()+' '+d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});};
 logExec({prog:'SCENE',lines:['Saved scenes ↓',...ss.map(s=>`• "${s.name}" — ${s.freqCount} freqs, ${s.notchCount} notches [${fmtTs(s.ts)}]`)] ,auto:false});
 });
 } else if(sub==='SAVE'){
 const nm=parts.slice(2).join(' ').trim()||parts[1];
 if(!nm||nm==='SAVE'){logExec({prog:'SCENE',lines:['Usage: SCENE SAVE <name>'],auto:false});return;}
 sceneSave(nm).then(s=>{
 if(!s){logExec({prog:'SCENE',lines:[' Save failed'],auto:false});return;}
 logExec({prog:'SCENE',lines:[` Saved: "${nm}"`,` ${s.freqCount} freqs · ${s.notchCount} notches · env=${s.env}`],auto:false});
 });
 } else if(sub==='LOAD'){
 const nm=parts.slice(2).join(' ').trim()||parts[1];
 if(!nm||nm==='LOAD'){logExec({prog:'SCENE',lines:['Usage: SCENE LOAD <name>'],auto:false});return;}
 sceneLoad(nm).then(s=>{
 if(!s){logExec({prog:'SCENE',lines:[` Scene not found: "${nm}"`],auto:false});return;}
 logExec({prog:'SCENE',lines:[` Loaded: "${nm}"`,` ${s.freqCount} freqs restored · ${s.notchCount} notches active`],auto:false});
 });
 } else if(sub==='DEL'||sub==='DELETE'||sub==='RM'){
 const nm=parts.slice(2).join(' ').trim();
 if(!nm){logExec({prog:'SCENE',lines:['Usage: SCENE DEL <name>'],auto:false});return;}
 sceneDelete(nm).then(ok=>{
 logExec({prog:'SCENE',lines:[ok?` Deleted: "${nm}"`:(` Not found: "${nm}"`)],auto:false});
 });
 } else {
 // Treat bare arg as scene name → LOAD shortcut
 const nm=parts.slice(1).join(' ').trim();
 sceneLoad(nm).then(s=>{
 if(s)logExec({prog:'SCENE',lines:[` Loaded: "${nm}" (${s.freqCount} freqs, ${s.notchCount} notches)`],auto:false});
 else logExec({prog:'SCENE',lines:[`SCENE LIST · SCENE SAVE <name> · SCENE LOAD <name> · SCENE DEL <name>`],auto:false});
 });
 }
 return;
 }
 // NOTCH_ADAPT — toggle adaptive notch tracking
 if(cmd==='ADAPT'){
 NOTCH_ADAPT.enabled=!NOTCH_ADAPT.enabled;
 logExec({prog:'ADAPT',lines:[`Adaptive notch tracking: ${NOTCH_ADAPT.enabled?'ON ':'OFF '}`,`maxDrift=±${NOTCH_ADAPT.maxDrift}Hz · cooldown=2.5s`],auto:false});
 return;
 }
 // GATE — control AI ban gate
 if(cmd==='GATE'){
 const sub=parts[1]||'';
 if(sub==='ON'){AI_GATE.enabled=true;logExec({prog:'GATE',lines:['AI gate ENABLED'],auto:false});}
 else if(sub==='OFF'){AI_GATE.enabled=false;logExec({prog:'GATE',lines:['AI gate DISABLED — no freq banning'],auto:false});}
 else if(sub==='MAX'){const n=parseInt(parts[2]);if(!isNaN(n)&&n>0){AI_GATE.maxBan=n;logExec({prog:'GATE',lines:['maxBan='+n],auto:false});}else logExec({prog:'GATE',lines:['Usage: GATE MAX <n>'],auto:false});}
 else logExec({prog:'GATE',lines:[`AI_GATE: enabled=${AI_GATE.enabled} maxBan=${AI_GATE.maxBan} autoUnbanAfter=${AI_GATE.autoUnbanAfter} failThresh=${AI_GATE.failThresh}`,'Subcommands: GATE ON · GATE OFF · GATE MAX <n>'],auto:false});
 return;
 }
 // PERMS — show permission status
 if(cmd==='PERMS'){
 logExec({prog:'PERMS',lines:[
 `mic: ${PERMS.mic}`,`notifications: ${PERMS.notifications}`,
 `storage: ${PERMS.storage}`,`wakeLock: ${PERMS.wakeLock}`,
 `fileAccess: ${PERMS.fileAccess}`,
 PERMS.fileHandle?'fileHandle: directory open':'fileHandle: none',
 'Tip: type PERMS in terminal or tap "Request Permissions" in BG tab',
 ],auto:false});
 return;
 }
 // AUTOPRESET — toggle auto preset switching by environment
 if(cmd==='AUTOPRESET'){
 const sub=parts[1]||'';
 if(sub==='ON'||sub==='OFF'){
 AUTOPRESET.enabled=(sub==='ON');
 logExec({prog:'AUTOPRESET',lines:[`Auto-preset by environment: ${AUTOPRESET.enabled?'ON ':'OFF '}`,`cooldown=${AUTOPRESET.cooldown/1000}s`,`Map: quiet→${AUTOPRESET.map.quiet} tonal→${AUTOPRESET.map.tonal} noise→${AUTOPRESET.map.noise}`],auto:false});
 } else if(sub==='MAP'&&parts[2]&&parts[3]){
 const envK=parts[2].toLowerCase(),preK=parts[3].toLowerCase();
 if(AUTOPRESET.map.hasOwnProperty(envK)&&['low','balanced','full'].includes(preK)){
 AUTOPRESET.map[envK]=preK;
 logExec({prog:'AUTOPRESET',lines:[`Mapped: ${envK} → ${preK}`],auto:false});
 } else logExec({prog:'AUTOPRESET',lines:['Usage: AUTOPRESET MAP <env> <preset>','envs: quiet tonal noise impulsive mechanical interference mixed','presets: low balanced full'],auto:false});
 } else {
 AUTOPRESET.enabled=!AUTOPRESET.enabled;
 logExec({prog:'AUTOPRESET',lines:[`Auto-preset: ${AUTOPRESET.enabled?'ON ':'OFF '}`,`cooldown=${AUTOPRESET.cooldown/1000}s · AUTOPRESET ON/OFF · AUTOPRESET MAP <env> <preset>`,...Object.entries(AUTOPRESET.map).map(([e,p])=>` ${e} → ${p}`)],auto:false});
 }
 return;
 }
 // LOCK — KF frequency lock (Dev120)
 if(cmd==='LOCK'){
 const hz=parseFloat(parts[1]);
 if(parts[1]&&parts[1].toUpperCase()==='OFF'){KF_LOCK.enabled=false;logExec({prog:'LOCK',lines:['KF Lock disabled — free tracking resumed'],auto:false});return;}
 if(isNaN(hz)||hz<20||hz>20000){logExec({prog:'LOCK',lines:['KF Frequency Lock','Usage: LOCK <hz> [tol] — constrain Kalman filter to target ±tol Hz','Example: LOCK 50 → lock to 50Hz ±15Hz','Example: LOCK 100 5 → lock to 100Hz ±5Hz','LOCK OFF → release lock'],auto:false});return;}
 KF_LOCK.hz=hz;KF_LOCK.tol=isNaN(parseFloat(parts[2]))?15:parseFloat(parts[2]);KF_LOCK.enabled=true;
 logExec({prog:'LOCK',lines:[` KF Lock engaged: ${hz.toFixed(1)}Hz ±${KF_LOCK.tol}Hz`,`KF will be pulled toward target by 30% per frame`,`Current KF: ${appState.fanFreq.toFixed(2)}Hz → LOCK OFF to release`],auto:false});
 return;
 }
 // FMAP — frequency persistence ASCII histogram (Dev120)
 if(cmd==='FMAP'){
 if(!freqDB.size){logExec({prog:'FMAP',lines:['FreqDB empty — run analysis first','FMAP shows detection count histogram across frequency bins'],auto:false});return;}
 const entries=[...freqDB.values()].filter(e=>e.count>0).sort((a,b)=>a.hz-b.hz);
 const maxC=Math.max(...entries.map(e=>e.count),1);
 const barW=12;
 const lines=['Freq (Hz) Count Map','─────────────────────────────────',...entries.map(e=>{const pct=e.count/maxC;const bar='█'.repeat(Math.round(pct*barW)).padEnd(barW);const conf=e.confirmed?'*':'';return `${e.hz.toFixed(1).padStart(8)} ${String(e.count).padStart(5)} ${bar}${conf}`;}),'','(* = confirmed) · sorted by frequency'];
 logExec({prog:'FMAP',lines,auto:false});
 return;
 }
 // ALERT — adaptive SQI/hop alert system (Dev120)
 if(cmd==='ALERT'){
 const sub=(parts[1]||'').toUpperCase();
 if(sub==='ON'){ADAPTIVE_ALERT.enabled=true;ADAPTIVE_ALERT.level='ok';logExec({prog:'ALERT',lines:[` Adaptive Alert ON`,`Warn: SQI<${ADAPTIVE_ALERT.warnSQI} or hops>${ADAPTIVE_ALERT.warnHops}`,`Critical: SQI<${ADAPTIVE_ALERT.critSQI}`,`Cooldown: ${ADAPTIVE_ALERT.cooldown/1000}s between alerts`],auto:false});return;}
 if(sub==='OFF'){ADAPTIVE_ALERT.enabled=false;logExec({prog:'ALERT',lines:[' Adaptive Alert OFF'],auto:false});return;}
 if(sub==='WARN'&&!isNaN(parseFloat(parts[2]))){ADAPTIVE_ALERT.warnSQI=+parseFloat(parts[2]).toFixed(0);logExec({prog:'ALERT',lines:[`Warn threshold: SQI<${ADAPTIVE_ALERT.warnSQI}`],auto:false});return;}
 if(sub==='CRIT'&&!isNaN(parseFloat(parts[2]))){ADAPTIVE_ALERT.critSQI=+parseFloat(parts[2]).toFixed(0);logExec({prog:'ALERT',lines:[`Critical threshold: SQI<${ADAPTIVE_ALERT.critSQI}`],auto:false});return;}
 // status
 logExec({prog:'ALERT',lines:[`Adaptive Alert: ${ADAPTIVE_ALERT.enabled?'ON ':'OFF '}`,`Level: ${ADAPTIVE_ALERT.level} · Current SQI: ${SQI.val}`,`Thresholds: warn SQI<${ADAPTIVE_ALERT.warnSQI} | critical SQI<${ADAPTIVE_ALERT.critSQI}`,`Hop warn: >${ADAPTIVE_ALERT.warnHops} hops · Cooldown: ${ADAPTIVE_ALERT.cooldown/1000}s`,'ALERT ON/OFF · ALERT WARN <sqi> · ALERT CRIT <sqi>'],auto:false});
 return;
 }
 // REC — detection recording buffer (Dev120)
 if(cmd==='REC'){
 const sub=(parts[1]||'').toUpperCase();
 if(sub==='START'){
 if(!appState.isRun){logExec({prog:'REC',lines:['Start analysis first before recording'],auto:false});return;}
 REC.buf=[];REC.active=true;REC.startT=Date.now();
 logExec({prog:'REC',lines:[` Recording started — captures {t, hz, energy, env, sqi} per frame (~40ms)`,`Buffer: max ${REC.maxLen} frames (~${Math.round(REC.maxLen*0.04/60*10)/10} min)`,`REC STOP · REC STATUS · REC DUMP`],auto:false});
 return;
 }
 if(sub==='STOP'){REC.active=false;logExec({prog:'REC',lines:[` Recording stopped — ${REC.buf.length} frames captured`,`Duration: ~${(REC.buf.length*0.04).toFixed(1)}s · REC DUMP to export`],auto:false});return;}
 if(sub==='STATUS'){logExec({prog:'REC',lines:[`REC: ${REC.active?' ACTIVE':' stopped'}`,`Frames: ${REC.buf.length}/${REC.maxLen} · ~${(REC.buf.length*0.04).toFixed(1)}s`,REC.buf.length?`Last: hz=${REC.buf[REC.buf.length-1].hz} env=${REC.buf[REC.buf.length-1].env} sqi=${REC.buf[REC.buf.length-1].sqi}`:'(empty)'],auto:false});return;}
 if(sub==='DUMP'){
 if(!REC.buf.length){logExec({prog:'REC',lines:['Buffer empty — REC START first'],auto:false});return;}
 const snap=REC.buf.slice(-20);
 const lines=[`Recording dump (last ${snap.length} of ${REC.buf.length} frames):`,`${'t(ms)'.padEnd(8)} ${'hz'.padEnd(8)} ${'energy'.padEnd(8)} ${'env'.padEnd(12)} sqi`,'─'.repeat(50),...snap.map(r=>`${String(r.t).padEnd(8)} ${String(r.hz).padEnd(8)} ${String(r.e).padEnd(8)} ${String(r.env).padEnd(12)} ${r.sqi}`),'','Full JSON via EXPORT command'];
 logExec({prog:'REC',lines,auto:false});return;
 }
 if(sub==='CLEAR'){REC.buf=[];REC.active=false;logExec({prog:'REC',lines:['Buffer cleared'],auto:false});return;}
 logExec({prog:'REC',lines:['Detection Recording Buffer','REC START — begin capturing detection frames','REC STOP — stop capture','REC STATUS — show current state','REC DUMP — print last 20 frames','REC CLEAR — wipe buffer'],auto:false});
 return;
 }
 // ALARM — frequency alarm system (Dev110)
 if(cmd==='ALARM'){
 const sub=parts[1]||'';
 if(sub.toUpperCase()==='LIST'){
 if(!FREQ_ALARMS.size){logExec({prog:'ALARM',lines:['No active alarms','Usage: ALARM <hz> [tol] — e.g. ALARM 50 3'],auto:false});return;}
 const lines=[`${FREQ_ALARMS.size} active alarm${FREQ_ALARMS.size!==1?'s':''}:`,...[...FREQ_ALARMS.values()].map(a=>` ${a.enabled?'':''} ${a.hz.toFixed(1)}Hz ±${a.tol}Hz — triggered ${a.count}× — cd ${a.cooldown/1000}s`),'','ALARM OFF — disable all · ALARM OFF <hz> — remove one'];
 logExec({prog:'ALARM',lines,auto:false});
 } else if(sub.toUpperCase()==='CLEAR'||sub.toUpperCase()==='OFF'&&!parts[2]){
 FREQ_ALARMS.clear();logExec({prog:'ALARM',lines:['All alarms cleared '],auto:false});
 } else if(sub.toUpperCase()==='OFF'&&parts[2]){
 const hz=parseFloat(parts[2]);if(!isNaN(hz)){FREQ_ALARMS.delete(fBin(hz));logExec({prog:'ALARM',lines:[`Alarm at ~${hz}Hz removed`],auto:false});}
 } else if(!isNaN(parseFloat(sub))&&parseFloat(sub)>0){
 const hz=parseFloat(sub),tol=!isNaN(parseFloat(parts[2]))?parseFloat(parts[2]):5;
 const cd=!isNaN(parseFloat(parts[3]))?parseFloat(parts[3])*1000:3000;
 FREQ_ALARMS.set(fBin(hz),{hz,tol,count:0,lastTrigT:0,cooldown:cd,enabled:true});
 logExec({prog:'ALARM',lines:[` Alarm set: ${hz}Hz ±${tol}Hz · cooldown ${cd/1000}s`,`Will fire logNN + visual pulse on detection`,'ALARM LIST · ALARM OFF <hz>'],auto:false});
 } else {
 logExec({prog:'ALARM',lines:['Frequency detection alarm','Usage: ALARM <hz> [±tol] [cooldown_s]','Example: ALARM 50 3 5 → fires when 50±3Hz detected, 5s cooldown','ALARM LIST · ALARM OFF · ALARM CLEAR'],auto:false});
 }
 return;
 }
 // POWER — octave band power levels (Dev110)
 if(cmd==='POWER'){
 if(!appState.isRun||!lastFFD){logExec({prog:'POWER',lines:['No audio data — start analysis first'],auto:false});return;}
 const maxV=Math.max(-20,...BAND_POWER.vals);
 const bar=v=>{const n=Math.round(Math.max(0,(v-(-80))/(maxV-(-80))*14));return '█'.repeat(n)+'░'.repeat(14-n);};
 const lines=[
 '─── Octave Band Power ──────────────',
 ...BAND_POWER.BANDS.map((b,i)=>{const v=BAND_POWER.vals[i];const lbl=(b.lbl+'Hz').padStart(5);return ` ${lbl} ${bar(v)} ${v.toFixed(1)} dB`;}),
 '────────────────────────────────────',
 `Peak band: ${BAND_POWER.BANDS[BAND_POWER.vals.indexOf(Math.max(...BAND_POWER.vals))].lbl}Hz`,
 ];
 logExec({prog:'POWER',lines,auto:false});
 return;
 }
 // DELTA — spectral comparison (Dev110)
 if(cmd==='DELTA'){
 const sub=parts[1]||'';
 if(sub.toUpperCase()==='SAVE'){
 if(!lastFFD){logExec({prog:'DELTA',lines:['No FFT data yet — start analysis first'],auto:false});return;}
 SPEC_DELTA.baseline=Float32Array.from(lastFFD);SPEC_DELTA.baseT=Date.now();
 logExec({prog:'DELTA',lines:[` Baseline saved (${lastFFD.length} bins @ ${SPEC_DELTA.bHz.toFixed(3)}Hz/bin)`,`Saved at: ${new Date().toLocaleTimeString()}`,'Now run DELTA to compare current vs baseline'],auto:false});
 } else if(sub.toUpperCase()==='CLEAR'){
 SPEC_DELTA.baseline=null;SPEC_DELTA.baseT=0;
 logExec({prog:'DELTA',lines:['Baseline cleared'],auto:false});
 } else {
 if(!SPEC_DELTA.baseline){logExec({prog:'DELTA',lines:['No baseline saved','Run "DELTA SAVE" first, then change environment, then "DELTA" to compare'],auto:false});return;}
 const changes=computeSpecDelta();
 if(!changes||!changes.length){logExec({prog:'DELTA',lines:['No significant changes (threshold >3 dB)','Try DELTA SAVE in a different environment first'],auto:false});return;}
 const age=((Date.now()-SPEC_DELTA.baseT)/1000).toFixed(0);
 const lines=[`Δ spectrum vs baseline (${age}s ago) — top changes:`,
 '─────────────────────────────────────',
 ...changes.map(c=>` ${fmtFreqSI(c.hz)} ${c.diff>0?'+':''}${c.diff.toFixed(1)} dB ${c.diff>0?'▲ risen':'▼ fallen'}`),
 '─────────────────────────────────────',
 `${changes.filter(c=>c.diff>0).length} risen · ${changes.filter(c=>c.diff<0).length} fallen`];
 logExec({prog:'DELTA',lines,auto:false});
 }
 return;
 }
 // PEAKS — top-5 spectral peaks from last FFT frame (Dev100)
 if(cmd==='PEAKS'){
 if(!PEAKS_DATA.peaks||!PEAKS_DATA.peaks.length){logExec({prog:'PEAKS',lines:['No peak data yet — start analysis first','Multi-peak detector runs every 40ms during detection'],auto:false});return;}
 const age=PEAKS_DATA.lastT?((Date.now()-PEAKS_DATA.lastT)/1000).toFixed(1):'?';
 const lines=[`Top ${PEAKS_DATA.peaks.length} spectral peaks (${age}s ago)`,
 '─────────────────────────────',
 ...PEAKS_DATA.peaks.map((p,i)=>` #${i+1} ${p.hz.toFixed(2)} Hz ${p.db.toFixed(1)} dB${NOTCH_SUPPRESS.has(fBin(p.hz))?' ':''}`),
 '─────────────────────────────',
 'Notched + banned peaks are excluded from results'];
 logExec({prog:'PEAKS',lines,auto:false});
 return;
 }
 // SQI — Signal Quality Index breakdown (Dev100)
 if(cmd==='SQI'){
 computeSQI();
 const bar=n=>'█'.repeat(Math.round(n/10))+'░'.repeat(10-Math.round(n/10));
 const lines=[
 `Signal Quality Index: ${SQI.val}/100 ${SQI.val>=80?'':SQI.val>=50?'':''}`,
 '─────────────────────────────────────',
 ` KF Confidence [${bar(SQI.kfConf)}] ${SQI.kfConf}% ×0.30`,
 ` Supp. Eff. [${bar(SQI.suppEff)}] ${SQI.suppEff}% ×0.30`,
 ` Env Stability [${bar(SQI.envStab)}] ${SQI.envStab}% ×0.40`,
 ` Hop Penalty −${SQI.hopPenalty} pts (${Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0))} hops since start)`,
 '─────────────────────────────────────',
 ` Final: ${SQI.val}/100 — ${SQI.val>=80?'Strong signal, high confidence':SQI.val>=50?'Moderate — check for hops/env changes':'Weak signal — unstable tracking'}`];
 logExec({prog:'SQI',lines,auto:false});
 return;
 }
 // EXPORT — JSON snapshot to terminal + clipboard (Dev100)
 if(cmd==='EXPORT'){
 computeSQI();
 const snap={
 timestamp:new Date().toISOString(),version:'ZERO-v25-Dev100',
 session:{uptime:SESSION_STAT.startT?Date.now()-SESSION_STAT.startT:0,aiCycles:appState.aiCyc,env:curEnvClass,preset:curPreset},
 sqi:SQI,
 freqs:[...freqDB.values()].slice(0,50).map(e=>({hz:e.hz,confirmed:e.confirmed,class:e.class})),
 notches:[...NOTCH_SUPPRESS.values()].map(n=>({hz:n.hz,depth:n.depth,order:n.order||1})),
 peaks:PEAKS_DATA.peaks,
 hops:{total:FREQ_HOP.count,recent:FREQ_HOP.hops.slice(-10)},
 suppEff:{current:SUPP_EFF.val,sessionAvg:SESSION_STAT.suppEffN>0?Math.round(SESSION_STAT.suppEffSum/SESSION_STAT.suppEffN):0},
 notchPeak:SESSION_STAT.notchPeak,
 envBreakdown:SESSION_STAT.envCount
 };
 const json=JSON.stringify(snap,null,2);
 const lines=['═══ ZERO v25 EXPORT ═══','',json.slice(0,800)+(json.length>800?'\n... (truncated — full copy sent to clipboard)':''),'','═══════════════════════'];
 logExec({prog:'EXPORT',lines,auto:false});
 // Copy to clipboard
 if(navigator.clipboard&&navigator.clipboard.writeText){
 navigator.clipboard.writeText(json).then(()=>logNN(' EXPORT: full JSON copied to clipboard')).catch(()=>logNN(' EXPORT: clipboard write failed'));
 }
 return;
 }
 // HOPS — frequency hop history
 if(cmd==='HOPS'){
 if(!FREQ_HOP.hops.length){logExec({prog:'HOPS',lines:['No freq hops detected yet',`Threshold: Δ>${FREQ_HOP.threshold}Hz · debounce 500ms`],auto:false});return;}
 const lines=[`Total hops: ${FREQ_HOP.count} · Threshold: Δ>${FREQ_HOP.threshold}Hz`,'--- Recent hops (newest first) ---',...[...FREQ_HOP.hops].reverse().slice(0,15).map(h=>{const d=new Date(h.t);return `${d.toLocaleTimeString()} ${h.from.toFixed(1)}→${h.to.toFixed(1)}Hz (Δ${h.delta.toFixed(1)}Hz)`;})];
 logExec({prog:'HOPS',lines,auto:false});
 return;
 }
 // Unknown
 logExec({prog:'ERR',lines:['Unknown: '+raw,'Programs: '+Object.keys(AI_LIB).join(' '),'DB: QUERY · PATTERN · CONTEXT · STATS · REFRESH · HISTORY','Analysis: PREDICT · RANK · ENV','BAN: BAN <hz> · UNBAN <hz> · BANLIST · GATE ON/OFF','Notch: NOTCH <hz> · NOTCH LIST · NOTCH OFF · ADAPT · NOTCH HARM · NOTCH DECAY <s>','Scenes: SCENE LIST · SCENE SAVE <n> · SCENE LOAD <n> · SCENE DEL <n>','Partitions: PARTITIONS · PARTITIONS SAVE','Perms: PERMS','SET: SET SF.INF 0.8 · SET NN.LR 0.015 · SET THRESH 4','Hop: HOPS · Preset: AUTOPRESET ON/OFF','Band: BAND <lo> <hi> · BAND OFF','Dev100: PEAKS · SQI · EXPORT','Dev110: ALARM <hz> · POWER · DELTA SAVE · DELTA','Dev120: LOCK <hz> · FMAP · ALERT ON/OFF · REC START'],auto:false});
}

/* ══ EXEC CYCLE UPDATE (called from startNN) ══ */
function updateExecUI(){
 const es=E('ex-sil');if(es)es.textContent=appState.silSc+'%';
 const en=E('ex-nn');if(en)en.textContent=NN.loss.toFixed(3);
 const ed=E('ex-db');if(ed)ed.textContent=freqDB.size;
 const ec=E('execCycLbl');if(ec)ec.textContent='cycle '+appState.aiCyc;
 computeSQI(); // Dev100: update SQI every NN cycle (~80ms)
 checkAdaptiveAlert(); // Dev120: progressive alert when SQI/hops degrade
 if(curTab===5)renderExecLog();
}

/* ═══════════════════════════════════════
 PERMISSION SYSTEM
═══════════════════════════════════════ */
function _setStatusBadge(id,state){
 const b=E(id);if(!b)return;
 b.className='ps-badge '+(state==='granted'?'ok':state==='denied'?'no':'warn');
}
function updatePermsUI(){
 _setStatusBadge('ps-mic',PERMS.mic);
 _setStatusBadge('ps-notif',PERMS.notifications);
 _setStatusBadge('ps-store',PERMS.storage);
 _setStatusBadge('ps-wake',PERMS.wakeLock);
 _setStatusBadge('ps-file',PERMS.fileAccess);
}

/* ═══════════════════════════════════════
 FREQUENCY PARTITIONS
═══════════════════════════════════════ */

window.execTotal=execTotal; window.EXEC_LOG=EXEC_LOG; window.getExecType=getExecType;
window.logExec=logExec; window.renderExecLog=renderExecLog; window.escH=escH;
window.execCyc=execCyc; window.lastSilForBoost=lastSilForBoost; window.boostCooldown=boostCooldown;
window.ucb1Select=ucb1Select; window.aiExecCycle=aiExecCycle; window.runExecCmd=runExecCmd;
window.updateExecUI=updateExecUI; window._setStatusBadge=_setStatusBadge; window.updatePermsUI=updatePermsUI;

})();
/* ── 07c-freq-bans-partitions.js ── */

'use strict';
(function(){

let _freqPartitions=null;
function buildFreqPartitions(){
 const all=[...freqDB.values()];
 if(!all.length){addToStLog('Partitions: FreqDB empty — run AI first');return null;}
 // Sort by energy
 const sorted=[...all].sort((a,b)=>b.energy-a.energy);
 const topN=Math.max(1,Math.ceil(sorted.length*.25));
 const botN=Math.max(1,Math.ceil(sorted.length*.25));
 // Hot = top 25% energy, Cold = bottom 25%
 const hot=sorted.slice(0,topN).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 const cold=sorted.slice(-botN).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 // Positive (class 1/3/4)
 const pos=all.filter(e=>[1,3,4].includes(e.class||0)).map(e=>({hz:e.hz,energy:e.energy}));
 // Negative (class 2)
 const neg=all.filter(e=>(e.class||0)===2).map(e=>({hz:e.hz,energy:e.energy}));
 // Confirmed
 const conf=all.filter(e=>e.confirmed).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 // Inverse active
 const inv=[...INV.active.values()].map(v=>({hz:v.hz,attempts:v.attempts,verified:v.verified}));
 // Banned
 const banned=[...AI_BAN.entries()].map(([hz,d])=>({hz,reason:d.reason,bannedAt:d.bannedAt,autoUnbanAt:d.autoUnbanAt}));
 // Predicted
 const predicted=AI_CTX.predictedHz?[{hz:AI_CTX.predictedHz,source:'FREQ_PREDICT'}]:[];
 // Inverse-active (negated freqs in use)
 const inverseActive=inv.filter(v=>!v.verified).map(v=>({hz:v.hz,attempts:v.attempts}));
 _freqPartitions={
 ts:Date.now(),
 silSc: appState.silSc,
 aiCyc: appState.aiCyc,
 noiseSignature:AI_CTX.noiseSignature,
 partitions:{
 hot,cold,positive:pos,negative:neg,
 confirmed:conf,inversed:inv,banned,predicted,
 inverseActive
 },
 counts:{
 hot:hot.length,cold:cold.length,pos:pos.length,neg:neg.length,
 conf:conf.length,inv:inv.length,banned:banned.length,predicted:predicted.length
 }
 };
 // Update UI
 const sv=id=>E(id);
 if(sv('part-hot-v'))sv('part-hot-v').textContent=hot.length;
 if(sv('part-cold-v'))sv('part-cold-v').textContent=cold.length;
 if(sv('part-conf-v'))sv('part-conf-v').textContent=conf.length;
 if(sv('part-ban-v'))sv('part-ban-v').textContent=banned.length;
 if(sv('part-inv-v'))sv('part-inv-v').textContent=inv.length;
 if(sv('part-pred-v'))sv('part-pred-v').textContent=predicted.length;
 addToStLog('Partitions built: hot='+hot.length+' cold='+cold.length+' conf='+conf.length+' ban='+banned.length);
 return _freqPartitions;
}
async function saveFreqPartitions(){
 const p=_freqPartitions||buildFreqPartitions();
 if(!p){return;}
 const json=JSON.stringify(p,null,2);
 const fname='zero-freq-partitions-'+_isoFname()+'.json';
 // 1. Save to IndexedDB (sessions store)
 try{
 const db=await openDB();
 const tx=db.transaction('sessions','readwrite');
 tx.objectStore('sessions').put({id:'freq_partitions',ts:p.ts,data:json,type:'partitions'});
 await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=rej;});
 addToStLog('Partitions saved to IDB');
 }catch(e){addToStLog('IDB partitions err: '+e.message);}
 // 1.5 تعميم: نسخة دائمة إضافية إلى المجلد الثابت (WebToApkFS) إن كان الوصول ممنوحاً —
 // مستقلة عن باقي الخطوات أدناه، بنفس نمط exportBans/androidWrite.
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 if(WebToApkFS.writeText(fname,json)){addToStLog('Partitions saved to fixed folder (WebToApkFS): '+fname);_cleanupFixedFolderBackups();}
 }
 }catch(e){}
 // 2. File System API (browser)
 if(PERMS.fileHandle){
 try{
 const fh=await PERMS.fileHandle.getFileHandle(fname,{create:true});
 const w=await fh.createWritable();
 await w.write(json);await w.close();
 addToStLog('Partitions saved to file: '+fname);
 }catch(e){addToStLog('File save err: '+e.message);}
 }
 // 3. Android bridge
 if(typeof ZeroAndroid!=='undefined'){
 try{ZeroAndroid.saveFile(fname,json);addToStLog('Partitions saved via Android');}catch(e){}
 }
 // 4. Fallback download
 if(!PERMS.fileHandle&&typeof ZeroAndroid==='undefined'){
 try{
 const a=document.createElement('a');
 a.href='data:application/json;charset=utf-8,'+encodeURIComponent(json);
 a.download=fname;a.click();
 addToStLog('Partitions downloaded: '+fname);
 }catch(e){}
 }
}

/* ═══════════════════════════════════════
 AI FREQUENCY BAN / UNBAN
═══════════════════════════════════════ */
function banFreq(hz,reason,opts){
 // تشديد أكثر: هذه هي الدالة العامة الأكثر استخداماً لإنشاء حظر يدوي/تلقائي في كل
 // أنحاء الملف — التحقّق يوضَع هنا في نقطة الدخول نفسها بدل الاعتماد على كل مستدعٍ
 // ليتذكّر التحقّق بنفسه (نفس نمط التحصين المطبَّق على castBanVote/updateFreqFatigue).
 if(!hz||hz<1||!isFinite(hz))return false;
 // كل الحضر دائم — لا وجود للحضر المؤقت
 const cat=opts&&opts.category||null;
 if(!AI_GATE.enabled)return false;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return false; // محضور مسبقاً
 if(newBanCount()>=AI_GATE.maxBan)return false; // السقف على الجديد فقط — لا نحذف دائماً لإفساح مجال
 AI_BAN.set(bin,{
 reason:reason||'AI',
 bannedAt:execCyc,cycles:0,
 bannedAtTime:Date.now(),
 autoUnbanAt:Infinity,
 hz:bin,permanent:true,category:cat,
 preBanEnergy:(opts&&opts.preBanEnergy)||0,
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 // تشديد: أي سجلّ سابق لهذا التردد في قاعدة بيانات الترددات (FreqDB) يُحذف فوراً عند
 // الحظر — وإلا يبقى ظاهراً في قائمة #flist وفي تصدير EXPORT رغم حظره
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();}
 checkInterference(bin);
 // إيقاف أي إبطال نشط لهذا التردد
 stopActiveInverse(hz);
 // إزالة notch هذا التردد — محضور لا يحتاج كبت إضافي
 deactivateNotch(hz);
 PERSIST.scheduleSaveBans();
 renderBanList();
 addToStLog(' محضور دائماً: '+bin.toFixed(2)+'Hz ('+reason+')');
 return true;
}
function unbanFreq(hz){
 const bin=fBin(hz);
 const had=AI_BAN.has(bin);
 AI_BAN.delete(bin);
 if(had){
 PERSIST.scheduleSaveBans();renderBanList();addToStLog('Unbanned: '+bin.toFixed(2)+'Hz');
 // Restore notch if freq is still confirmed in freqDB
 const e=freqDB.get(bin);if(e&&e.confirmed)activateNotch(hz);
 }
 return had;
}
function renderBanList(){
 const el=E('ban-list');if(!el)return;
 const total=AI_BAN.size;
 const bs=E('ban-stat');if(bs)bs.textContent=total+' محضور دائماً';
 const tot=E('ban-total-badge');if(tot)tot.textContent=total+' مُحضَر';
 if(!total){el.innerHTML='<div class="ban-empty">No frequencies banned</div>';return;}
 // نعتمد على مفتاح الـMap (hz) كمصدر الحقيقة الوحيد — لا نثق بـ d.hz المخزّن فقط
 // بلا شارات تصنيف فرعية — كل الترددات المحظورة في تصنيف واحد "ترددات محظورة"
 // خط دفاع أخير: أي مفتاح غير رقمي/غير منتهٍ (NaN) لا يظهر إطلاقاً حتى لو تسرَّب من مسار
 // غير متوقَّع — يُنظَّف فعلياً بواسطة _purgeInvalidFrequencies، وهذا الفلتر احتياطي فقط.
 el.innerHTML=[...AI_BAN.entries()].filter(([hz])=>typeof hz==='number'&&isFinite(hz)&&hz>=1).sort((a,b)=>a[0]-b[0]).map(([hz,d])=>{
 const prob=d.postBanDetections>0?
 `<span class="ban-prob"><span class="ban-prob-wrap"><span class="ban-prob-bar ${d.verdict||'pending'}" style="width:${Math.round((d.probEnvironmental||0)*100)}%"></span></span><span class="ban-verdict ${d.verdict||'pending'}">${d.verdict==='env'?'env':d.verdict==='spk'?'spk':d.verdict==='mixed'?'mix':'…'}</span></span>`:
 '<span class="ban-verdict pending" style="opacity:.35">—</span>';
 // تأكيد متقاطع بين الأجهزة: ·N يظهر فقط إن استُورد هذا التردد ولو مرة من جهاز/جلسة
 // أخرى — !N إضافية إن تعارض حكم هذا الجهاز (env/spk) مع حكم المصدر المستورَد، ما قد
 // يشير إلى تردد خاص بجهاز واحد (سماعته) وليس تداخلاً بيئياً عاماً.
 // (28 سبتمبر 2026: استُبدل رمزا / الملوَّنان بعلامتين نصيتين بسيطتين !/· — نفس
 // التمييز البصري بين الحالتين بلا أي لون، ويبقى class="conflict" + title يحملان
 // التفصيل الكامل كما كانا تماماً.)
 const cross=d.crossConfirms>0?
 `<span class="ban-cross${d.verdictAgreement==='conflict'?' conflict':''}" title="${d.verdictAgreement==='conflict'?'تعارض في الحكم بين هذا الجهاز ('+(d.verdict||'—')+') والمصدر المستورَد ('+(d.importedVerdict||'—')+')':'تأكَّد استيراده من '+d.crossConfirms+' مصدر مستقل'}">${d.verdictAgreement==='conflict'?'!':'·'}${d.crossConfirms}</span>`:'';
 return`<div class="ban-row perm"><span class="ban-hz">${hz.toFixed(2)}Hz</span><span class="ban-why">${escH(d.reason||'AI')}</span>${prob}${cross}<span class="ban-lock"></span><span class="ban-rmv" onclick="unbanFreq(${hz})">✕</span></div>`;
 }).join('');
 // Also refresh the settings perm list if open
 renderPermSettings();
}
function autoBanCheck(){
 if(!AI_GATE.enabled||!execCyc)return;
 // تحديث عداد الدورات لكل حضر (كلها دائمة — لا إلغاء تلقائي)
 AI_BAN.forEach((d)=>{d.cycles=execCyc-d.bannedAt;});
 // فحص الترددات الفاشلة المزمنة
 if(INV.failed.size>0){
 INV.failed.forEach((d,hz)=>{
 const failEntry=freqDB.get(fBin(hz));
 if(failEntry&&failEntry.confirmed&&!AI_BAN.has(fBin(hz))){
 const attempts=(INV.active.get(hz)||{attempts:0}).attempts;
 if(attempts>=INV.maxTry){banFreq(hz,'FAIL×'+INV.maxTry);}
 }
 });
 }
 renderBanList();
}

/* ══ PERMANENT BAN HELPERS ══ */

/* ══════════════════════════════════════════════════════════════════════════
 PERSIST — هيكلية تخزين منفصلة متصلة
 منفصل: تعيش في localStorage بشكل مستقل عن AI_BAN في الذاكرة
 متصل: تتزامن مع AI_BAN عند كل تغيير (save) وعند كل بداية (load)
 يحل: فقدان 400 تردد عند إعادة التشغيل أو toggle الفئة
═══════════════════════════════════════════════════════════════════════════ */

window._freqPartitions=_freqPartitions; window.buildFreqPartitions=buildFreqPartitions; window.saveFreqPartitions=saveFreqPartitions;
window.banFreq=banFreq; window.unbanFreq=unbanFreq; window.renderBanList=renderBanList;
window.autoBanCheck=autoBanCheck;

})();
/* ── 08a-persist-bans-store.js ── */

'use strict';
(function(){

class PersistStore{
 constructor(){
 this.K={
 bans :'zero_v17_bans', // جميع مدخلات AI_BAN
 cats :'zero_v17_cats', // حالة تفعيل كل فئة
 nn :'zero_v17_nn', // أوزان الشبكة العصبية
 fc :'zero_v17_fc', // عدادات تصنيف الترددات
 zones:'zero_v17_zones', // مناطق تداخل INTERFERENCE_BAN.zones الجديدة (غير الأساسية)
 meta :'zero_v17_meta', // إصدار، ختم زمني
 };
 this._saveTimer=null;
 this._zoneSaveTimer=null;
 this._nnTimer=null;
 this._lastSave=0;
 }

 /* ════════════════════════════════════════════════════════
 My Files Bridge — كتابة / قراءة من مجلد ثابت على الجهاز
 الأولوية: WebToApkFS (مجلد ثابت حقيقي عبر SAF — الجسر الفعلي الموجود في هذا البناء)
 ← ZeroAndroid (جسر أصلي مخصَّص، يبقى مدعوماً لو بُني المشروع مستقبلاً عبر
 Android Studio بدل خدمة تحويل الموقع إلى APK) ← localStorage احتياط نهائي دائماً.
 تشديد: WebToApkFS.hasAccess() يعود false حتى يمنح المستخدم الإذن يدوياً مرة واحدة
 من لوحة "الملفات"؛ قبل ذلك — وفي أي بناء لا يحتوي WebToApkFS أصلاً — يبقى السلوك
 مطابقاً تماماً لما كان عليه قبل هذا التعديل (محاولة ZeroAndroid ثم فشل صامت). ══
 ════════════════════════════════════════════════════════ */
 _mfWrite(name,json){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 WebToApkFS.writeText(name,json);return;
 }
 }catch(e){}
 try{if(typeof ZeroAndroid!=='undefined')ZeroAndroid.saveData(name,json);}catch(e){}
 }
 _mfRead(name){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 const r=WebToApkFS.readText(name);
 if(r)return r;
 }
 }catch(e){}
 try{
 if(typeof ZeroAndroid==='undefined')return null;
 const r=ZeroAndroid.loadData(name);
 return r||null;
 }catch(e){return null;}
 }

 /* ── حفظ فوري — يركّز على الجديد فقط ── */
 /* الترددات "الأساسية" (baseline:true) — الحضر الافتراضي (DEFAULT_BANNED_FREQS) والحضر
 المؤكَّد من طبقة التكامل (zero-core.js CONFIRMED_BANS) — تُعاد توليدها تلقائياً وبشكل
 كامل عند كل تشغيل (loadDefaultBans/loadConfirmedBans)، فلا داعي لتكرارها في الملف
 المحفوظ. الملف يقتصر إذن على الترددات "الجديدة" فعلاً: ما اكتشفه AI حيّاً (Fatigue ·
 Vote · Auto-detect · حظر تداخل) أو ما استوردَه/أضافه المستخدم يدوياً. */
 saveBans(){
 let json;
 try{
 const entries=[];
 AI_BAN.forEach((d,bin)=>{
 if(d.baseline)return; // أساسي — يُعاد توليده تلقائياً، لا حاجة لحفظه
 entries.push([bin,{
 reason:d.reason,bannedAt:d.bannedAt,bannedAtTime:d.bannedAtTime||null,
 autoUnbanAt:d.autoUnbanAt,
 hz:bin,permanent:!!d.permanent,category:d.category||null,
 cycles:d.cycles||0,preBanEnergy:d.preBanEnergy||0,
 postBanDetections:d.postBanDetections||0,
 probEnvironmental:d.probEnvironmental,verdict:d.verdict||null,
 // تأكيد متقاطع بين الأجهزة (راجع _mergeImportedBansJSON) — يجب أن ينجو من
 // إعادة التشغيل تماماً كبقية الحقول، وإلا تُفقد كل الاستيرادات السابقة بصمت
 crossConfirms:d.crossConfirms||0,
 importedVerdict:d.importedVerdict||null,
 verdictAgreement:d.verdictAgreement||null
 }]);
 });
 json=JSON.stringify({entries,ts:Date.now(),ver:17});
 }catch(e){return;}
 // إصلاح خلل: الكتابتان كانتا تحت try/catch واحد — فشل localStorage.setItem (مثلاً
 // QuotaExceededError بعد استيراد كبير) كان يُسقِط استثناءً يُلغي تنفيذ _mfWrite() التالية
 // معه بالكامل، رغم أن المجلد الثابت (My Files، الموصوف بأنه المصدر "الأساسي") قد لا يكون
 // ممتلئاً إطلاقاً. الآن كل كتابة مستقلة تماماً — فشل إحداهما لا يمنع الأخرى.
 try{localStorage.setItem(this.K.bans,json);}catch(e){} // ① localStorage احتياط
 try{this._mfWrite('zero_bans.json',json);}catch(e){} // ② My Files أساسي
 this._lastSave=Date.now();
 }

 /* ── حفظ مؤجل (debounce 600ms) لتجنب الفيضان عند الحظر السريع ── */
 scheduleSaveBans(){
 clearTimeout(this._saveTimer);
 this._saveTimer=setTimeout(()=>this.saveBans(),600);
 }

 /* ── تحميل AI_BAN — My Files أولاً، ثم localStorage احتياطاً ── */
 loadBans(){
 try{
 // ① المصدر الأساسي: My Files
 let raw=this._mfRead('zero_bans.json');
 // ② الاحتياط: localStorage
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let loaded=0;
 data.entries.forEach(([bin,d])=>{
 // تشديد أكثر: تحقّق مباشر هنا عند التحميل نفسه — لا نعتمد فقط على فحص السلامة
 // اللاحق (_purgeInvalidFrequencies) لأن مسارات استعادة أخرى (restoreCategory) تُقرأ
 // من نفس هذا التخزين خارج نافذة الفحص عند بدء التشغيل (مثلاً عند تبديل مفتاح
 // تفعيل/إيقاف الحظر) — رفض الفساد من مصدره في كل نقطة قراءة أضمن من تنظيفه لاحقاً فقط.
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(!AI_BAN.has(bin)){
 AI_BAN.set(bin,Object.assign({
 preBanEnergy:0,postBanDetections:0,
 lastPostBanEnergy:0,probEnvironmental:null,verdict:null,
 crossConfirms:0,importedVerdict:null,verdictAgreement:null
 },d,{hz:bin})); // hz يُفرض دائماً من مفتاح الـMap المحفوظ — لا نثق ببيانات قديمة ناقصة
 loaded++;
 }
 });
 return loaded;
 }catch(e){return 0;}
 }

 /* ── حفظ مناطق التداخل الجديدة (INTERFERENCE_BAN.zones) — نفس منطق saveBans تماماً ──
 تشديد جوهري: هذا كان مفقوداً كلياً من قبل — مناطق التداخل (تقدّم العدّاد count نحو
 التصعيد widen) لم تكن تُحفَظ إطلاقاً، فكانت تُفقد بالكامل عند كل إغلاق/إعادة تشغيل
 للتطبيق، وتبدأ من الصفر في كل جلسة استماع جديدة (عدا المناطق "الأساسية" المجمَّدة من
 CONFIRMED_INTERFERENCE في zero-core.js وقت آخر دفعة دُمجت). الآن تُحفَظ محلياً فوراً
 مثل الترددات المحظورة تماماً، وتُستعاد تلقائياً عند إعادة التشغيل — مهم بشكل خاص لأن
 هذا الجهاز لا يملك أي تخزين أندرويد أصلي فعلياً (يعتمد على localStorage في WebView
 فقط)، فهذه أصبحت طبقة الاستمرارية الوحيدة بين الجلسات. */
 saveZones(){
 let json;
 try{
 const entries=[];
 INTERFERENCE_BAN.zones.forEach((z,bin)=>{
 if(z.baseline)return; // أساسي — يُعاد توليده تلقائياً من zero-core.js، لا حاجة لحفظه
 entries.push([bin,{count:z.count||0,widen:z.widen||0,lastT:z.lastT||0,crossConfirms:z.crossConfirms||0}]);
 });
 json=JSON.stringify({entries,ts:Date.now(),ver:17});
 }catch(e){return;}
 // إصلاح خلل (نفس saveBans): كتابتان مستقلتان — فشل localStorage لا يمنع كتابة WebToApkFS
 try{localStorage.setItem(this.K.zones,json);}catch(e){} // ① localStorage احتياط
 try{this._mfWrite('zero_zones.json',json);}catch(e){} // ② My Files أساسي
 }
 scheduleSaveZones(){
 clearTimeout(this._zoneSaveTimer);
 this._zoneSaveTimer=setTimeout(()=>this.saveZones(),600);
 }
 /* ── تحميل مناطق التداخل — My Files أولاً، ثم localStorage احتياطاً ──
 نفس ضمان الشفاء الذاتي في loadBans: إن كانت المنطقة موجودة مسبقاً (أساسية من
 zero-core.js بعد دمج دفعة جديدة) فلا تُستبدَل — النسخة الأساسية الأحدث تفوز دائماً. */
 loadZones(){
 try{
 let raw=this._mfRead('zero_zones.json');
 if(!raw)raw=localStorage.getItem(this.K.zones);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let loaded=0;
 data.entries.forEach(([bin,z])=>{
 // تشديد أكثر: نفس تحقّق loadBans — رفض أي مفتاح NaN/غير موجب من مصدره مباشرة
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count:z.count||0,widen:z.widen||0,lastT:z.lastT||0,crossConfirms:z.crossConfirms||0});
 loaded++;
 }
 });
 return loaded;
 }catch(e){return 0;}
 }

 /* ── استعادة فئة معينة — My Files أولاً (للتبديل ON) ── */
 restoreCategory(cat){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 let restored=0;
 data.entries.forEach(([bin,d])=>{
 // تشديد أكثر — مهم بشكل خاص هنا: هذا المسار يُستدعى من زر تبديل تفعيل/إيقاف
 // الحظر (toggleAllPermBans) في أي لحظة أثناء التشغيل، خارج نافذة فحص السلامة
 // (_purgeInvalidFrequencies) التي تعمل مرة واحدة فقط عند بدء التشغيل — فأي إدخال
 // NaN/0Hz فاسد نُظِّف عند البدء يمكن أن "يعود من جديد" هنا لو لم يُتحقَّق منه هنا أيضاً.
 if(typeof bin!=='number'||!isFinite(bin)||bin<1)return;
 if(d.category===cat&&!AI_BAN.has(bin)){
 AI_BAN.set(bin,Object.assign({
 preBanEnergy:0,postBanDetections:0,
 lastPostBanEnergy:0,probEnvironmental:null,verdict:null,
 crossConfirms:0,importedVerdict:null,verdictAgreement:null
 },d,{hz:bin})); // hz يُفرض دائماً من مفتاح الـMap المحفوظ
 restored++;
 }
 });
 return restored;
 }catch(e){return 0;}
 }

 /* ── عدّ ترددات فئة من PERSIST — My Files أولاً ── */
 countCategory(cat){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 return data.entries.filter(([,d])=>d.category===cat).length;
 }catch(e){return 0;}
 }

 /* ── العدد الإجمالي المخزّن في PERSIST — My Files أولاً ── */
 totalCount(){
 try{
 let raw=this._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(this.K.bans);
 if(!raw)return 0;
 const data=JSON.parse(raw);
 if(!Array.isArray(data.entries))return 0;
 return data.entries.length;
 }catch(e){return 0;}
 }

 /* ── حفظ حالة الفئات — My Files + localStorage ──
 مراجعة "النسخة النهائية": نفس إصلاح خلل saveBans/saveZones (راجع تعليقهما أعلاه) لم يكن
 مُطبَّقاً هنا — كتابتا localStorage وMy Files كانتا تحت try/catch واحد، ففشل الأولى
 (QuotaExceededError مثلاً) كان يُلغي الثانية معها رغم أن المجلد الثابت قد لا يكون ممتلئاً
 إطلاقاً. مطبَّق الآن بنفس النمط تماماً في الدوال الخمس التي أضافها كل من ⑨ROOM_MODES
 و⑧WIEN لاحقاً (saveCats/saveNN/saveFC/saveRoomModes/saveWienerNF). */
 saveCats(){
 let json;
 try{
 const state={};
 Object.keys(PERM_BAN_CATS).forEach(k=>{state[k]=PERM_BAN_CATS[k].enabled;});
 json=JSON.stringify({state,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem(this.K.cats,json);}catch(e){}
 try{this._mfWrite('zero_cats.json',json);}catch(e){}
 }

 /* ── تحميل حالة الفئات — My Files أولاً ── */
 loadCats(){
 try{
 let raw=this._mfRead('zero_cats.json');
 if(!raw)raw=localStorage.getItem(this.K.cats);
 if(!raw)return;
 const data=JSON.parse(raw);
 if(!data.state)return;
 Object.keys(data.state).forEach(k=>{
 if(PERM_BAN_CATS[k])PERM_BAN_CATS[k].enabled=data.state[k];
 });
 }catch(e){}
 }

 /* ── حفظ أوزان الشبكة العصبية — My Files + localStorage ── */
 scheduleNNSave(){
 clearTimeout(this._nnTimer);
 this._nnTimer=setTimeout(()=>this.saveNN(),2000);
 }
 saveNN(){
 if(!NN||!NN.w1)return;
 let json;
 try{
 json=JSON.stringify({
 w1:Array.from(NN.w1),w2:Array.from(NN.w2),
 b1:Array.from(NN.b1),b2:Array.from(NN.b2),
 ts:Date.now()
 });
 }catch(e){return;}
 try{localStorage.setItem(this.K.nn,json);}catch(e){}
 try{this._mfWrite('zero_nn.json',json);}catch(e){}
 }
 /* ── تحميل الأوزان — My Files أولاً ── */
 loadNN(){
 try{
 let raw=this._mfRead('zero_nn.json');
 if(!raw)raw=localStorage.getItem(this.K.nn);
 if(!raw)return false;
 const d=JSON.parse(raw);
 // مراجعة "المشروع بالكامل": هذه الدالة تُستدعى من loadDefaultBans() عند تحميل الصفحة
 // (200ms بعد load) — قبل أن يضغط المستخدم "تشغيل" بكثير، أي قبل أن يُستدعى nnInit()
 // في أي مكان؛ NN.w1 لا يزال null (قيمته الابتدائية) في تلك اللحظة دائماً. فكانت
 // NN.w1.length تفشل بـ TypeError على null، يُمسكها catch(e) الخارجي بصمت، فترجع
 // loadNN() دوماً false — استعادة أوزان الشبكة من zero_nn.json/localStorage لم تكن
 // تعمل إطلاقاً عبر هذا المسار (مموَّهة فقط لأن مسار IndexedDB المنفصل غالباً ما ينجح
 // بدلاً منه). الإصلاح: المقارنة بالحجم المتوقَّع الثابت للمعمارية (NN.in*NN.hid) بدل
 // NN.w1.length الحالي — صحيح بصرف النظر عن ترتيب الاستدعاء.
 if(!d.w1||d.w1.length!==NN.in*NN.hid)return false;
 NN.w1=new Float32Array(d.w1);NN.w2=new Float32Array(d.w2);
 NN.b1=new Float32Array(d.b1);NN.b2=new Float32Array(d.b2);
 // إصلاح خطأ حقيقي رصده سجلّ الأخطاء الجديد فعلياً على جهاز المستخدم: هذا المسار كان
 // يضبط w1/w2/b1/b2 مباشرة دون تهيئة dw1/db1/dw2/db2 المقابلة لها (كما تفعل nnInit()
 // دائماً) — فتبقى null كقيمتها الابتدائية، لأن loadNN() تُستدعى من loadDefaultBans()
 // خلال أول 200ms من تحميل الصفحة، أي قبل أي استدعاء لـ nnInit() في كامل الجلسة. وبما
 // أن NN.w1 صار truthy الآن، فإن startAll() لاحقاً (شرطه if(!NN.w1)nnInit()) يتخطى
 // التهيئة تماماً — فيبقى NN.dw2 (وإخوتها) null طوال الجلسة. النتيجة: أول قراءة
 // NN.dw2[i2] داخل nnTrain() (تتكرر كل ~320ms طالما التطبيق يعمل) تنهار بـ
 // "Cannot read properties of null (reading '0')" — بالضبط الخطأ المتكرر الذي التقطه
 // سجلّ الأخطاء على الجهاز الحقيقي. ملاحظة: saveNN() لا يحفظ dw1/db1/dw2/db2 أصلاً
 // (هي عدّادات "زخم" مؤقتة للتدريب فقط) — فتصفيرها هنا عند كل استعادة هو السلوك
 // الصحيح تماماً المطابق لما تفعله nnInit() نفسها عند إنشاء أوزان جديدة.
 NN.dw1=new Float32Array(NN.in*NN.hid);NN.db1=new Float32Array(NN.hid);
 NN.dw2=new Float32Array(NN.hid*NN.out);NN.db2=new Float32Array(NN.out);
 return true;
 }catch(e){return false;}
 }

 /* ── حفظ عدادات الفئات — My Files + localStorage ── */
 saveFC(){
 let json;
 try{
 const snap={};Object.keys(FC).forEach(k=>{snap[k]=FC[k];});
 json=JSON.stringify({snap,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem(this.K.fc,json);}catch(e){}
 try{this._mfWrite('zero_fc.json',json);}catch(e){}
 }
 /* ── تحميل العدادات — My Files أولاً ── */
 loadFC(){
 try{
 let raw=this._mfRead('zero_fc.json');
 if(!raw)raw=localStorage.getItem(this.K.fc);
 if(!raw)return;
 const d=JSON.parse(raw);
 if(!d.snap)return;
 Object.keys(d.snap).forEach(k=>{if(k in FC)FC[k]+=d.snap[k];});
 }catch(e){}
 }

 /* ── ⑨ ROOM_MODES×PERSIST — حفظ بصمة وضع الغرفة / تحميل ── */
 saveRoomModes(){
 if(!ROOM_MODES.peaks||!ROOM_MODES.peaks.length)return;
 let json;
 try{json=JSON.stringify({peaks:ROOM_MODES.peaks.slice(0,6),dominant:ROOM_MODES.dominant,ts:Date.now()});}
 catch(e){return;}
 try{localStorage.setItem('zero_room_modes',json);}catch(e){}
 try{this._mfWrite('zero_room_modes.json',json);}catch(e){}
 }
 loadRoomModes(){
 try{
 let raw=this._mfRead('zero_room_modes.json');
 if(!raw)raw=localStorage.getItem('zero_room_modes');
 if(!raw)return false;
 const d=JSON.parse(raw);
 if(!Array.isArray(d.peaks)||!d.peaks.length)return false;
 if(!ROOM_MODES.peaks.length){ROOM_MODES.peaks=d.peaks;ROOM_MODES.dominant=d.dominant||0;}
 return true;
 }catch(e){return false;}
 }

 /* ── ⑧ WIEN×PERSIST: حفظ/استعادة نموذج ضجيج Wiener ── */
 saveWienerNF(){
 if(!appState.nFloor||!appState.nFloor.length)return;
 let json;
 try{
 const arr=Array.from(appState.nFloor.slice(0,128));
 json=JSON.stringify({nf:arr,alpha:P.alpha,beta:P.beta,ts:Date.now()});
 }catch(e){return;}
 try{localStorage.setItem('zero_wiener_nf',json);}catch(e){}
 try{this._mfWrite('zero_wiener_nf.json',json);}catch(e){}
 }
 loadWienerNF(){
 try{
 let raw=this._mfRead('zero_wiener_nf.json');
 if(!raw)raw=localStorage.getItem('zero_wiener_nf');
 if(!raw)return false;
 const d=JSON.parse(raw);
 if(!Array.isArray(d.nf)||!d.nf.length)return false;
 if(!appState.nFloor||appState.nFloor.length!==d.nf.length)appState.nFloor=new Float32Array(d.nf.length);
 d.nf.forEach((v,i)=>{appState.nFloor[i]=v;});
 if(d.alpha)P.alpha=Math.max(0.8,Math.min(3.5,d.alpha));
 return true;
 }catch(e){return false;}
 }

 /* ── حذف كل البيانات المحفوظة (localStorage فقط — My Files يبقى) ── */
 clear(){
 try{Object.values(this.K).forEach(k=>localStorage.removeItem(k));}catch(e){}
 stLog(' PERSIST: localStorage محذوف (My Files يبقى كنسخة احتياطية)');
 }

 /* ── حالة التخزين ── */
 status(){
 let sz=0;
 try{sz=new Blob([localStorage.getItem(this.K.bans)||'']).size;}catch(e){}
 const age=this._lastSave?Math.round((Date.now()-this._lastSave)/1000)+'ث':'—';
 let mfp='غير متاح';
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess())mfp=WebToApkFS.getAccessUri()||'مُفعَّل (WebToApkFS)';
 else if(typeof ZeroAndroid!=='undefined')mfp=ZeroAndroid.getDataPath();
 }catch(e){}
 return`PERSIST: ${AI_BAN.size} محضور · ${(sz/1024).toFixed(1)}KB · آخر حفظ ${age}\nMy Files: ${mfp}`;
 }
}
const PERSIST=new PersistStore();


/* ══ ميزة وقائية: فحص سلامة الترددات (NaN/0.00Hz) ══
 تشديد: حتى بعد إصلاح كل نقاط إنشاء الحظر (updateFreqFatigue/castBanVote) ومصدر الخلل
 الجذري في المرشّح الطيفي (تسمّم كالمان من قِيَم -Infinity في FFT)، أي حظر فاسد كان قد
 أُنشئ ووصل للتخزين *قبل* هذا الإصلاح يبقى محفوظاً ويُعاد عرضه في كل تشغيل قادم. هذه
 الدالة تفحص AI_BAN وINTERFERENCE_BAN.zones وfreqDB عند كل بدء تشغيل (وقابلة للاستدعاء
 يدوياً من أي مسار استيراد لاحقاً) وتحذف أي إدخال بتردد غير رقمي/غير منتهٍ (NaN) أو أقل
 من 1Hz — طبقة حماية دائمة تمنع تكرار ظهور "NaNHz"/"0.00Hz" مهما كان مصدر الفساد مستقبلاً. */
function _purgeInvalidFrequencies(sourceLabel){
 // حظر/تداخل/تصويت: لا وجود لتردد سالب أو دون 1Hz شرعي إطلاقاً هنا
 const isBad=hz=>typeof hz!=='number'||!isFinite(hz)||hz<1;
 // freqDB وحدها استثناء: ميزة negFreqMirror (مرآة التردد السالب) تُخزِّن عمداً إدخالات
 // بمفتاح سالب (class:2, isMirror:true) — هذه شرعية ويجب عدم حذفها، فيُكتفى هنا برفض
 // القيم غير المنتهية (NaN/Infinity) فقط دون فرض حدّ أدنى موجب على القيمة.
 const isBadFreqDB=hz=>typeof hz!=='number'||!isFinite(hz);
 let bansRemoved=0,zonesRemoved=0,freqDBRemoved=0,votesRemoved=0;
 AI_BAN.forEach((d,bin)=>{if(isBad(bin))(AI_BAN.delete(bin),bansRemoved++);});
 INTERFERENCE_BAN.zones.forEach((z,bin)=>{if(isBad(bin))(INTERFERENCE_BAN.zones.delete(bin),zonesRemoved++);});
 if(typeof freqDB!=='undefined')freqDB.forEach((e,bin)=>{if(isBadFreqDB(bin))(freqDB.delete(bin),freqDBRemoved++);});
 if(typeof BAN_VOTE!=='undefined')BAN_VOTE.forEach((v,bin)=>{if(isBad(bin))(BAN_VOTE.delete(bin),votesRemoved++);});
 const total=bansRemoved+zonesRemoved+freqDBRemoved+votesRemoved;
 if(total>0){
 stLog(' فحص السلامة: حُذف '+total+' إدخال بتردد فاسد (NaN/0Hz)'+(sourceLabel?' — '+sourceLabel:'')+
 ' ['+bansRemoved+' حظر، '+zonesRemoved+' تداخل، '+freqDBRemoved+' FreqDB، '+votesRemoved+' تصويت]');
 if(bansRemoved)PERSIST.scheduleSaveBans();
 if(zonesRemoved)PERSIST.scheduleSaveZones();
 if(freqDBRemoved)writeFreqFile();
 }
 return {bansRemoved,zonesRemoved,freqDBRemoved,votesRemoved,total};
}

/* ══ مضاد الفيروسات — لوحة موحَّدة (29 سبتمبر 2026) ══
 لا كشف/حظر جديد هنا إطلاقاً — فقط تجميع وعرض لثلاث آليات حماية حقيقية موجودة مسبقاً في
 المحرك وتعمل بصمت تام دون أي واجهة مخصَّصة: (1) THERMAL.thermBanned — حظر تلقائي لأي
 تردد ارتبط تكراراً بارتفاع حرارة الجهاز (02-classification-thermal-nn.js، sampleThermal)،
 (2) ANTI_IDLE.lagFreqs — حظر تلقائي لأي تردد ارتبط تكراراً بتقطّع الإطارات >50ms (نفس
 الملف، monitorSlugFreqs)، (3) _purgeInvalidFrequencies أعلاه — فحص سلامة تلقائي (NaN/0Hz)
 كان يعمل فقط عند 3 أحداث محدَّدة (بدء تشغيل/استعادة جلسة/استيراد) بلا أي زر يدوي ولا عرض
 نتيجة في أي مكان. الفئتان الأوليان (thermal/lag) مسجَّلتان أصلاً في AI_BAN بحقل category —
 يكفي هنا فلترتهما وعدّهما، تماماً كما تفعل renderPermSettings/togglePermCat لغرض آخر. */
function updateAVPanel(){
 if(!appState.avOpen)return;
 const validHzKey=hz=>typeof hz==='number'&&isFinite(hz)&&hz>=1;
 const rows=[];let thermalN=0,lagN=0;
 AI_BAN.forEach((d,bin)=>{
 if(!d.permanent||!validHzKey(bin))return;
 if(d.category==='thermal'){thermalN++;rows.push({hz:bin,cat:'thermal',reason:d.reason});}
 else if(d.category==='lag'){lagN++;rows.push({hz:bin,cat:'lag',reason:d.reason});}
 });
 rows.sort((a,b)=>a.hz-b.hz);
 const total=thermalN+lagN;
 const st=E('av-status');
 if(st)st.textContent=total>0?('المشروع محمي — '+total+' تردد مُحايَد'):'لا تهديدات حتى الآن — النظام سليم';
 const sv=E('av-stress');
 if(sv)sv.textContent=(typeof THERMAL!=='undefined'?THERMAL.stress:0)+'%'+((typeof THERMAL!=='undefined'&&THERMAL.rising)?' ↑ يرتفع':'');
 const tc=E('av-thermal-cnt');if(tc)tc.textContent=thermalN+' تردد';
 const lc=E('av-lag-cnt');if(lc)lc.textContent=lagN+' تردد';
 const listEl=E('av-list');
 if(listEl){
 listEl.innerHTML=rows.length?rows.map(r=>
 `<div class="ban-row2 ${r.cat}"><span class="ban-hz">${r.hz.toFixed(2)}Hz</span><span class="ban-why">${escH(r.reason||'')}</span><span class="ban-rmv" onclick="unbanFreq(${r.hz});updateAVPanel()">✕</span></div>`
 ).join(''):'<div class="ban-empty">لا تهديدات مُحايَدة بعد</div>';
 }
}
/* زر "فحص الآن" — يشغّل نفس _purgeInvalidFrequencies المستخدَمة تلقائياً، يدوياً بطلب المستخدم */
function runAVScan(){
 const r=_purgeInvalidFrequencies('فحص يدوي — مضاد الفيروسات');
 const el=E('av-scan-result');
 if(el)el.textContent=r.total>0?
 ('تم تنظيف '+r.total+' إدخال فاسد ['+r.bansRemoved+' حظر، '+r.zonesRemoved+' تداخل، '+r.freqDBRemoved+' قاعدة بيانات، '+r.votesRemoved+' تصويت]'):
 'فحص مكتمل — لا فساد في البيانات الداخلية';
 renderBanList();renderPermSettings();updateAVPanel();
 if(typeof zVibrate==='function')zVibrate(6);
}

function loadDefaultBans(){
 // ① استعادة كل الترددات المحفوظة من PERSIST (تعلّمها AI سابقاً)
 const persisted=PERSIST.loadBans();
 if(persisted>0)stLog(' PERSIST: '+persisted+' تردد محفوظ استُعيد');
 // ①ب استعادة مناطق التداخل الجديدة (تقدّم العدّاد نحو التصعيد) — كانت تُفقد كلياً سابقاً
 const zonesRestored=PERSIST.loadZones();
 if(zonesRestored>0)stLog(' PERSIST: '+zonesRestored+' منطقة تداخل محفوظة استُعيدت');
 // ①ج فحص سلامة فوري: أي حظر/منطقة NaN أو 0Hz وصل للتخزين من نسخة سابقة قبل هذا
 // الإصلاح يُحذَف الآن تلقائياً — قبل أن يُعرَض حتى مرة واحدة على المستخدم في هذا التشغيل
 _purgeInvalidFrequencies('عند بدء التشغيل');
 // ② استعادة أوزان الشبكة العصبية
 if(PERSIST.loadNN())stLog(' PERSIST: أوزان الشبكة العصبية استُعيدت');
 // ③ استعادة عدادات الفئات
 PERSIST.loadFC();
 // ④ مراجعة "المشروع بالكامل": PERSIST.loadRoomModes()/loadWienerNF() كانتا محفوظتين تلقائياً
 // كل 300 دورة (وعند طلب المجلد الثابت) لكن غير مُستدعاتين إطلاقاً من أي مسار بدء تشغيل —
 // بحث كامل عن استدعاءاتهما في الملف لم يجد سوى تعريفهما، بلا نقطة استدعاء واحدة. فكانت
 // بصمة أوضاع الغرفة الصوتية المتعلَّمة (ROOM_MODES) ونموذج أرضية الضجيج المتعلَّم (Wiener
 // nFloor/P.alpha) تُصفَّر عند كل إعادة تشغيل عادية للتطبيق رغم حفظهما بأمانة كل جلسة —
 // "تعلّم" ضائع بالكامل دون أي فائدة عملية إلا عبر استعادة نسخة احتياطية كاملة يدوياً.
 if(PERSIST.loadRoomModes())stLog(' PERSIST: بصمة وضع الغرفة استُعيدت');
 if(PERSIST.loadWienerNF())stLog(' PERSIST: نموذج ضجيج Wiener استُعيد');
 let loaded=0;
 DEFAULT_BANNED_FREQS.forEach(([hz,cat,reason])=>{
 if(!PERM_BAN_CATS[cat]||!PERM_BAN_CATS[cat].enabled)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin)){
 // baseline:true — قائمة أساسية ثابتة تُعاد توليدها في كل تشغيل، فلا تُحفَظ/تُصدَّر
 // ضمن الملفات (PERSIST.saveBans و_getBansForExport يركّزان على الجديد فقط)
 AI_BAN.set(bin,{reason,bannedAt:0,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 loaded++;
 }
 });
 if(loaded)stLog(` حضر دائم: ${loaded} تردد محمّل (ضار · صاخب · mic)`);
 renderBanList();
 renderPermSettings();
}
/* ── حظر موحّد — لا تصنيفات فرعية، كل الترددات تحت "ترددات محظورة" واحدة ──
 داخلياً لا تزال PERM_BAN_CATS تصنّف الترددات (harmful/thermal/lag/…) لأغراض
 السلوك التلقائي فقط (auto-unban, heat score...) لكن الواجهة تُظهرها كوحدة واحدة. */
function toggleAllPermBans(){
 const anyEnabled=Object.values(PERM_BAN_CATS).some(c=>c.enabled);
 const turnOn=!anyEnabled; // إن كان أي جزء مفعّلاً نوقف الكل، وإلا نفعّل الكل
 let restoredTotal=0;
 // عند الإيقاف: نحفظ الحالة الحالية أولاً — قبل حذف أي شيء من AI_BAN — لأن الحذف
 // أدناه سيُفرغ كل الفئات المعروفة من الذاكرة؛ لو حفظنا بعد الحذف (كالسابق) فأي حظر
 // "جديد" اكتُشف حيّاً (Fatigue/Vote/Auto-detect) ولم يصل بعد إلى PERSIST كان سيُفقد
 // نهائياً ولا يعود حتى عند إعادة التفعيل — لأن saveBans تركّز على الجديد فقط أصلاً.
 if(!turnOn)PERSIST.saveBans();
 Object.keys(PERM_BAN_CATS).forEach(cat=>{
 PERM_BAN_CATS[cat].enabled=turnOn;
 if(turnOn){
 restoredTotal+=PERSIST.restoreCategory(cat);
 DEFAULT_BANNED_FREQS.forEach(([hz,c,reason])=>{
 if(c!==cat)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin))AI_BAN.set(bin,{reason,bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 });
 }else{
 AI_BAN.forEach((d,bin)=>{if(d.permanent&&d.category===cat)AI_BAN.delete(bin);});
 }
 });
 if(turnOn){
 // إعادة تحميل القائمة المؤكَّدة من طبقة التكامل (zero-core.js) — restoreCategory وحدها لا تكفي
 // إن كانت PERSIST قد فُرِّغت للتو بواسطة مسار الإيقاف (saveBans يحفظ AI_BAN الفارغة وقتها)
 if(typeof loadConfirmedBans==='function')loadConfirmedBans();
 PERSIST.saveCats();PERSIST.scheduleSaveBans();
 stLog(' تفعيل الترددات المحظورة'+(restoredTotal?' ('+restoredTotal+' محفوظ استُعيد)':''));
 }else{
 PERSIST.saveCats();
 stLog(' إيقاف الترددات المحظورة (البيانات محفوظة)');
 }
 const sw=E('sw-pban-all');if(sw)sw.checked=turnOn;
 renderBanList();
 renderPermSettings();
}
/* ══ INTERFERENCE MONITOR (Dev130) — بديل الإضافة اليدوية ══
 يراقب التداخل بين الترددات المحظورة مسبقاً والترددات التي تُرصد وتُحظر حديثاً.
 عند حظر تردد جديد قريب (ضمن tolHz) من تردد محظور سابقاً لكن ليس نفس الصندوق = تداخل.
 إذا تكرر التداخل في نفس المنطقة عدة مرات (escalateAt) → يُرفع مستوى الحظر
 بتوسيع النطاق المحظور حول مركز المنطقة (حظر التداخل). */

window.PERSIST=PERSIST; window._purgeInvalidFrequencies=_purgeInvalidFrequencies; window.updateAVPanel=updateAVPanel;
window.runAVScan=runAVScan; window.loadDefaultBans=loadDefaultBans; window.toggleAllPermBans=toggleAllPermBans;

})();
/* ── 08b-interference-permsettings.js ── */

'use strict';
(function(){

class InterferenceMonitor{
 constructor(){
 this.enabled=true;
 this.tolHz=3; // نافذة اعتبار ترددين "متداخلين" بالهرتز
 this.escalateAt=3; // عدد مرات التداخل المتكرر في نفس المنطقة قبل التصعيد
 this.widenStep=4; // Hz تُضاف لنطاق الحظر عند كل تصعيد
 this.maxWiden=32; // أقصى توسّع حول المركز
 this.zones=new Map(); // centerBin → {count, widen, lastT}
 }
 check(newHz){
 if(!this.enabled||!newHz||newHz<=0)return;
 const newBin=fBin(newHz);
 let nearest=null,nearestDist=Infinity;
 AI_BAN.forEach((d,bin)=>{
 if(bin===newBin)return;
 const dist=Math.abs(bin-newBin);
 if(dist<=this.tolHz&&dist<nearestDist){nearest=bin;nearestDist=dist;}
 });
 if(nearest===null)return; // لا تداخل مع أي تردد محظور آخر
 const center=fBin((nearest+newBin)/2);
 let z=this.zones.get(center);
 if(!z){z={count:0,widen:0,lastT:0};this.zones.set(center,z);}
 z.count++;z.lastT=Date.now();
 if(z.count>=this.escalateAt&&z.widen<this.maxWiden){
 z.widen=Math.min(this.maxWiden,z.widen+this.widenStep);
 escalateInterferenceZone(center,z.widen);
 z.count=0; // إعادة العدّاد بعد كل تصعيد
 }
 PERSIST.scheduleSaveZones(); // تشديد: حفظ تقدّم منطقة التداخل فوراً — كان مفقوداً كلياً سابقاً
 renderPermSettings(); // القائمة مدمجة الآن (حضر + تداخل) — تحديث واحد يكفي كليهما
}
}
const INTERFERENCE_BAN=new InterferenceMonitor();
function checkInterference(newHz){return INTERFERENCE_BAN.check(newHz);}

function escalateInterferenceZone(center,widenHz){
 const step=0.5;let added=0;
 for(let off=-widenHz;off<=widenHz;off+=step){
 const hz=center+off;
 // تشديد أكثر: hz<=0 وحدها لا ترفض NaN (أي مقارنة بـNaN تُقيَّم false دائماً) — التحقّق
 // الكامل isFinite يضمن رفض NaN أيضاً، دفاعاً إضافياً حتى لو وصل center نفسه فاسداً
 if(!isFinite(hz)||hz<=0)continue;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))continue;
 if(newBanCount()>=AI_GATE.maxBan)break;
 AI_BAN.set(bin,{reason:'حظر تداخل ±'+widenHz.toFixed(0)+'Hz حول '+center.toFixed(1)+'Hz',
 bannedAt:execCyc,cycles:0,bannedAtTime:Date.now(),autoUnbanAt:Infinity,hz:bin,permanent:true,category:'interference'});
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند حظر تصعيد التداخل
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال نشط على تردد التصعيد المحضور حديثاً (كان مفقوداً)
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط على تردد التصعيد المحضور حديثاً
 added++;
 }
 if(added){
 stLog(' تصعيد حظر التداخل: ±'+widenHz.toFixed(0)+'Hz حول '+center.toFixed(2)+'Hz ('+added+' تردد)');
 PERSIST.scheduleSaveBans();
 renderBanList();
 }
}
/* ── القائمة المدمجة: الترددات المحظورة + مناطق التداخل معاً ──
 تغيير كامل: حُذف زر تفعيل/إيقاف الحظر الدائم نهائياً من الواجهة — الحظر الدائم نشِط
 دائماً وغير مشروط بأي زر بعد الآن. العدّاد والقائمة هنا يعرضان "الجديد فقط" (غير
 الأساسي/baseline) — الأساسي (الحضر الافتراضي DEFAULT_BANNED_FREQS + المؤكَّد من
 zero-core.js) يعمل بصمت تام في الخلفية ولا يظهر هنا إطلاقاً، لا بعدّاد ولا بعلامة
 "· أساسي" في القائمة (حُذفت العلامة كلياً). حين لا يوجد أي جديد بعد، العدّاد يبدأ
 من 0 والقائمة تعرض رسالة "لا يوجد ترددات جديدة". */
function renderPermSettings(){
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].sort((a,b)=>a[0]-b[0]);
 // استُعيد 28 سبتمبر 2026: عدّاد لكل فئة على حدة + مفتاح تفعيل/إيقاف — بدل العدّاد الموحّد
 // الوحيد. يحسب الجديد فقط (غير baseline) اتساقاً مع نفس مبدأ العدّاد الموحّد السابق —
 // الأساسي (683 تردد مؤكَّد) يعمل بصمت في الخلفية بصرف النظر عن حالة المفتاح هنا.
 Object.keys(PERM_BAN_CATS).forEach(cat=>{
 const el=E('pban-cnt-'+cat);if(!el)return;
 const sw=E('sw-pban-'+cat);
 const enabled=PERM_BAN_CATS[cat].enabled;
 if(sw)sw.checked=enabled;
 if(enabled){
 const n=[...AI_BAN.values()].filter(d=>d.permanent&&!d.baseline&&d.category===cat).length;
 el.textContent=n+' تردد';
 el.style.color='';el.style.background='';el.style.borderColor='';
 }else{
 const n=PERSIST.countCategory(cat);
 el.textContent=n+' موقوف';
 el.style.color='rgba(176,176,176,.85)';
 el.style.background='rgba(176,176,176,.08)';
 el.style.borderColor='rgba(176,176,176,.22)';
 }
 });
 // تشديد: نسخة القائمة الأساسية المحمَّلة فعلياً — تُحسَب حيّاً، بلا حاجة لتحديث يدوي هنا
 const verEl=E('pban-baseline-ver');
 if(verEl){
 const cb=typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0;
 const ci=typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0;
 verEl.textContent=cb?(' نسخة القائمة الأساسية: '+cb+' تردد مؤكَّد + '+ci+' منطقة تداخل (zero-core.js) — تحقّق أنها أحدث نسخة قبل جلسة استماع جديدة'):' zero-core.js غير محمَّل — القائمة المؤكَّدة غير متاحة';
 }
 // القائمة الموحّدة: الترددات الجديدة () + مناطق التداخل الجديدة () معاً، مرتّبة بالتردد تصاعدياً
 const listEl=E('pban-settings-list');if(!listEl)return;
 // نأخذ الترددات من مفتاح الـMap دائماً (لا نعتمد على d.hz المُخزّن — قد يكون غائباً)
 // — ونستبعد أي إدخال baseline كلياً: هذه القائمة للجديد فقط
 // خط دفاع أخير (انظر renderBanList): استبعاد أي مفتاح NaN/غير موجب حتى لو تسرَّب استثناءً
 const validHzKey=hz=>typeof hz==='number'&&isFinite(hz)&&hz>=1;
 const perms=[...AI_BAN.entries()].filter(([hz,d])=>d.permanent&&!d.baseline&&validHzKey(hz)).map(([hz,d])=>({...d,hz,_t:'ban'}));
 const zones=zonesArr.filter(([hz,z])=>!z.baseline&&validHzKey(hz)).map(([hz,z])=>({hz,_t:'zone',count:z.count,widen:z.widen||0,crossConfirms:z.crossConfirms||0}));
 const merged=[...perms,...zones].sort((a,b)=>a.hz-b.hz);
 if(!merged.length){listEl.innerHTML='<div class="ban-empty">لا يوجد ترددات جديدة</div>';return;}
 listEl.innerHTML=merged.map(d=>{
 if(d._t==='zone'){
 // تأكيد متقاطع: نفس شارة N المستخدَمة في قائمة الحظر — منطقة تداخل رُصدت أيضاً من
 // جهاز/جلسة أخرى مستقلة عبر الاستيراد، دليل إضافي أنها تداخل بيئي حقيقي لا ضجيج عابر
 const cross=d.crossConfirms>0?`<span class="ban-cross" title="تأكَّدت من ${d.crossConfirms} مصدر مستقل">${d.crossConfirms}</span>`:'';
 return `<div class="ban-row zone"><span class="ban-hz">${d.hz.toFixed(2)}Hz</span><span class="ban-why" style="flex:2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">تداخل ×${d.count}${d.widen?' · موسّع ±'+d.widen.toFixed(0)+'Hz':''}</span>${cross}</div>`;
 }
 return `<div class="ban-row perm"><span class="ban-hz">${d.hz.toFixed(2)}Hz</span><span class="ban-why" style="flex:2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"> ${escH(d.reason||'')}</span><span class="ban-rmv" onclick="unbanFreq(${d.hz})">✕</span></div>`;
 }).join('');
}

// استُعيدت 28 سبتمبر 2026 ("تجميع كل الأفكار") — تفعيل/إيقاف فئة حظر كاملة. كانت قد أُزيلت
// نهائياً سابقاً بحجة أن الحظر الدائم يجب أن يبقى نشِطاً دوماً؛ استُعيدت بلا تعديل منطقي عن
// نسختها الأخيرة العاملة — لا تمسّ الحظر الأساسي (baseline) إطلاقاً، فقط ترددات هذه الفئة.
function togglePermCat(cat){
 if(!PERM_BAN_CATS[cat])return;
 PERM_BAN_CATS[cat].enabled=!PERM_BAN_CATS[cat].enabled;
 const sw=E('sw-pban-'+cat);if(sw)sw.checked=PERM_BAN_CATS[cat].enabled;
 if(PERM_BAN_CATS[cat].enabled){
 const restoredPersist=PERSIST.restoreCategory(cat);
 DEFAULT_BANNED_FREQS.forEach(([hz,c,reason])=>{
 if(c!==cat)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin))AI_BAN.set(bin,{reason,bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 });
 PERSIST.saveCats();
 PERSIST.scheduleSaveBans();
 stLog(' تفعيل حضر: '+PERM_BAN_CATS[cat].label+(restoredPersist?' ('+restoredPersist+' محفوظ استُعيد)':''));
 }else{
 PERSIST.saveBans();
 AI_BAN.forEach((d,bin)=>{if(d.permanent&&d.category===cat)AI_BAN.delete(bin);});
 PERSIST.saveCats();
 stLog(' إيقاف حضر: '+PERM_BAN_CATS[cat].label+' (البيانات محفوظة في PERSIST)');
 }
 renderBanList();
 renderPermSettings();
}

// استُعيدت 28 سبتمبر 2026 — إضافة تردد مخصَّص للحظر الدائم يدوياً من حقل نصي مباشر
// (البديل الموازي: أمر EXEC الموجود أصلاً `BAN <hz>` — كلاهما يعمل الآن جنباً إلى جنب).
function addCustomPermBan(){
 const inp=E('pban-custom-inp');if(!inp)return;
 const hz=parseFloat(inp.value);
 if(isNaN(hz)||hz<=0){inp.style.borderColor='rgba(104,104,104,.5)';setTimeout(()=>inp.style.borderColor='',1200);return;}
 const bin=fBin(hz);
 if(AI_BAN.has(bin)){stLog(' '+bin.toFixed(2)+'Hz محضور مسبقاً');inp.value='';return;}
 AI_BAN.set(bin,{reason:'حضر مخصص',bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'custom',
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 stLog(' حضر مخصص: '+bin.toFixed(2)+'Hz');
 inp.value='';renderBanList();
}

/* ══ POST-BAN PROBABILISTIC ANALYSIS ══
 When mic detects a banned freq:
 - First detection: sets energy baseline (preBanEnergy)
 - Subsequent: probEnvironmental = postEnergy / preBanEnergy
 ≥0.65 → 'env' (environmental source, ban correct)
 0.25–0.64 → 'mixed'
 <0.25 → 'spk' (speaker was re-emitting, ban worked)
═══════════════════════════════════════ */
function trackPostBanDetection(hz,energy){
 const bin=fBin(hz);
 const e=AI_BAN.get(bin);
 if(!e)return;
 // First mic detection after ban → establish baseline
 if(!e.preBanEnergy||e.preBanEnergy===0){
 e.preBanEnergy=energy;
 e.postBanDetections=1;
 e.lastPostBanEnergy=energy;
 e.probEnvironmental=1.0;
 e.verdict='env'; // first hit = baseline, assume environmental
 return;
 }
 e.postBanDetections=(e.postBanDetections||0)+1;
 // Exponential moving average — slow decay to track steady-state
 e.lastPostBanEnergy=(e.lastPostBanEnergy||energy)*.75+energy*.25;
 // Probability: how much energy remains vs baseline?
 e.probEnvironmental=Math.min(1,e.lastPostBanEnergy/e.preBanEnergy);
 if(e.probEnvironmental>=0.65)e.verdict='env';
 else if(e.probEnvironmental>=0.25)e.verdict='mixed';
 else e.verdict='spk';
 // If verdict is 'spk' for ≥3 detections, ban was effective → log once
 if(e.verdict==='spk'&&e.postBanDetections===3)
 addToStLog('✓ Ban confirmed effective: '+bin.toFixed(2)+'Hz — speaker was source (energy ↓'+(e.probEnvironmental*100).toFixed(0)+'%)');
}

/* Auto-detect and immediately ban a newly observed harmful/noisy freq.
 Called before fRecord() so the ban is in place before DB write. */
function autoDetectAndBan(hz,energy){
 if(!hz||hz<=0||!AI_GATE.enabled)return;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return; // already handled
 // Match against DEFAULT_BANNED_FREQS lookup table
 for(let i=0;i<DEFAULT_BANNED_FREQS.length;i++){
 const [defHz,cat,reason]=DEFAULT_BANNED_FREQS[i];
 if(fBin(defHz)===bin){
 if(!PERM_BAN_CATS[cat]||!PERM_BAN_CATS[cat].enabled)return;
 AI_BAN.set(bin,{
 reason:reason||cat,bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,
 preBanEnergy:energy, // capture energy right before ban
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(bin);
 stopActiveInverse(hz);
 addToStLog(' Auto-ban: '+bin.toFixed(2)+'Hz ('+cat+') — mic تحسّس');
 renderBanList();
 return;
 }
 }
 // Also auto-ban unregistered EMF harmonics detected live with sufficient energy
 if(energy>0.08){
 const isEMFHarm=[50,60].some(base=>{
 for(let h=1;base*h<20000;h++){if(Math.abs(hz-base*h)<1.5)return true;}
 return false;
 });
 if(isEMFHarm&&PERM_BAN_CATS.harmful.enabled){
 AI_BAN.set(bin,{
 reason:'EMF harmonic (auto)',bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,hz:bin,permanent:true,category:'harmful',
 preBanEnergy:energy,
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(bin);
 stopActiveInverse(hz);
 addToStLog(' Auto-ban EMF: '+bin.toFixed(2)+'Hz');
 renderBanList();
 }
 }
}

window.INTERFERENCE_BAN=INTERFERENCE_BAN; window.checkInterference=checkInterference; window.escalateInterferenceZone=escalateInterferenceZone;
window.renderPermSettings=renderPermSettings; window.togglePermCat=togglePermCat; window.addCustomPermBan=addCustomPermBan;
window.trackPostBanDetection=trackPostBanDetection; window.autoDetectAndBan=autoDetectAndBan;

})();
/* ── 08c-background-db.js ── */

'use strict';
(function(){



/* ════════════════════════════════════════════════════
 FILE STORAGE SYSTEM — 5 Layers
 ① IndexedDB — persistent local storage (NN, FreqDB, sessions)
 ② Anthropic Files — AI-accessible cloud files
 ③ Export / Import — download/upload JSON + CSV
 ④ Achievement — milestone tracker (15 achievements)
 ⑤ Auto-Save — every 2 min + on session stop
════════════════════════════════════════════════════ */

/* ═══════════════════════════
 ① INDEXEDDB
 Stores: sessions · nnWeights · achievements
═══════════════════════════ */
/* ════════════════════════════════════════════════
 UNIFIED DATA STORE (UDS) v3
 Shared reference DB for AI EXEC + Live Terminal.

 Stores:
 ┌─────────────────────────────────────────────┐
 │ sessions — full session snapshots │
 │ achievements — unlocked achievements │
 │ patterns — misc patterns │
 │ terminal_events — every tLog() persisted │ ← NEW
 │ exec_history — every AI program run │ ← NEW
 │ nn_history — NN metrics over time │ ← NEW
 │ freq_patterns — AI-identified Hz patterns │ ← NEW
 └─────────────────────────────────────────────┘

 AI reads terminal_events → AI_CTX → smarter programs
 Terminal reads exec_history → shows AI reasoning
 Both reference the same data store.
════════════════════════════════════════════════ */
const DBNAME='ZeroAIv25',DBVER=4;
window.zeroDB=null;

async function initDB(){
 return new Promise((res,rej)=>{
 const req=indexedDB.open(DBNAME,DBVER);
 req.onupgradeneeded=e=>{
 const db=e.target.result;
 // Existing stores
 ['sessions','patterns'].forEach(n=>{
 if(!db.objectStoreNames.contains(n))
 db.createObjectStore(n,{keyPath:'id',autoIncrement:true});
 });
 if(!db.objectStoreNames.contains('achievements'))
 db.createObjectStore('achievements',{keyPath:'id'});
 // ── NEW: Terminal Events ──────────────────────
 // Stores every tLog() call: FREQ, NN, EXEC, INV, SF, COH...
 if(!db.objectStoreNames.contains('terminal_events')){
 const te=db.createObjectStore('terminal_events',{keyPath:'id',autoIncrement:true});
 te.createIndex('type','type',{unique:false});
 te.createIndex('ts','ts',{unique:false});
 }
 // ── NEW: Exec History ─────────────────────────
 // Every AI program execution with results + metrics
 if(!db.objectStoreNames.contains('exec_history')){
 const eh=db.createObjectStore('exec_history',{keyPath:'id',autoIncrement:true});
 eh.createIndex('prog','prog',{unique:false});
 eh.createIndex('ts','ts',{unique:false});
 }
 // ── NEW: NN History ───────────────────────────
 // Periodic NN loss/lr snapshots for trend analysis
 if(!db.objectStoreNames.contains('nn_history')){
 const nh=db.createObjectStore('nn_history',{keyPath:'id',autoIncrement:true});
 nh.createIndex('cycle','cycle',{unique:false});
 }
 // ── NEW: Freq Patterns ────────────────────────
 // Confirmed frequency patterns detected by AI
 if(!db.objectStoreNames.contains('freq_patterns')){
 db.createObjectStore('freq_patterns',{keyPath:'hz'});
 }
 // ── NEW v4: Scene Profiles ─────────────────────
 if(!db.objectStoreNames.contains('scenes')){
 db.createObjectStore('scenes',{keyPath:'name'});
 }
 };
 req.onsuccess=e=>{zeroDB=e.target.result;res(zeroDB);};
 req.onerror=e=>rej(e.target.error);
 });
}

/* ══ UDS RETENTION — تطوير التخزين (28 سبتمبر 2026، بطلب المستخدم) ══
 كانت udsWriteEvent/udsWriteExec/udsWriteNN تكتب صفوفاً جديدة (.add) بلا أي سقف أقصى إطلاقاً.
 التطبيق يعمل كخدمة خلفية مستمرة (foreground service — راجع BgService.java) لساعات أو أيام؛
 terminal_events تحديداً تُكتب من كل استدعاء tLog() (كل سطر FREQ/NN/EXEC/INV/SF/COH لحظي أثناء
 التشغيل)، فتتراكم بلا سقف طوال عمر التطبيق على الجهاز — تستهلك مساحة IndexedDB تدريجياً بلا
 أي فائدة عملية مقابلة: كل قارئ فعلي لهذه المخازن (AI_CTX، واجهة السجلّ، udsQueryNNHistory)
 يقرأ دوماً فقط أحدث N سجل (getAll().reverse().slice(0,limit))، فالسجلات الأقدم من آلاف
 الأسطر لا تُقرأ أبداً ولا قيمة لها. الحل: سقف ثابت لكل مخزن + تقليم دوري مُقلَّل الكلفة (فحص
 كل 25 كتابة فقط، لا كل كتابة، لتفادي معاملة count()+cursor إضافية على المسار الساخن) يحذف
 أقدم الصفوف الزائدة عن السقف عبر مؤشر بترتيب المفتاح التصاعدي الافتراضي (keyPath autoIncrement
 → الأقدم دائماً الأصغر رقماً). لا تغيير في أي دالة قراءة أو أي سلوك ظاهر للمستخدم — فقط تفادي
 نمو غير محدود بصمت. */
const UDS_CAP={terminal_events:4000,exec_history:1000,nn_history:3000};
function _udsPruneStore(storeName){
 if(!zeroDB)return;
 const cap=UDS_CAP[storeName];
 if(!cap)return;
 try{
 const txCount=zeroDB.transaction(storeName,'readonly');
 const req=txCount.objectStore(storeName).count();
 req.onsuccess=()=>{
 const over=req.result-cap;
 if(over<=0)return;
 try{
 const txDel=zeroDB.transaction(storeName,'readwrite');
 let deleted=0;
 txDel.objectStore(storeName).openCursor().onsuccess=e=>{
 const cur=e.target.result;
 if(!cur||deleted>=over)return;
 cur.delete();deleted++;cur.continue();
 };
 }catch(e){}
 };
 req.onerror=()=>{};
 }catch(e){}
}

/* ══ UDS WRITE FUNCTIONS ══ */
let _udsEventN=0; // write counter for throttling
let _udsExecN=0;
let _udsNNWriteN=0;

function udsWriteEvent(entry){
 if(!zeroDB)return;
 _udsEventN++;
 // Write every event but batch to avoid transaction overhead
 // Use a microtask to not block the engine
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('terminal_events','readwrite');
 tx.objectStore('terminal_events').add({
 type:entry.type,t:entry.t,ts:Date.now(),
 code:entry.code,sub:entry.sub||null,
 cycle:appState.aiCyc||0,silSc:appState.silSc||0,NN_loss:NN&&NN.loss||0,fanFreq:appState.fanFreq||0
 });
 }catch(e){}
 if(_udsEventN%25===0)_udsPruneStore('terminal_events');
 // Also write to Android file if available
 if(_udsEventN%100===0&&typeof ZeroAndroid!=='undefined'){
 const line=JSON.stringify({type:entry.type,t:entry.t,ts:Date.now(),code:entry.code})+'\n';
 ZeroAndroid.saveFile('logs','terminal_'+new Date().toISOString().slice(0,10)+'.jsonl',line);
 }
 });
}

function udsWriteExec(args){
 if(!zeroDB)return;
 _udsExecN++;
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('exec_history','readwrite');
 tx.objectStore('exec_history').add({
 prog:args.prog,lines:args.lines,ms:args.ms||0,
 cycle:args.cycle||appState.aiCyc||0,auto:!!args.auto,
 ts:Date.now(),silSc:appState.silSc||0,NN_loss:NN&&NN.loss||0
 });
 }catch(e){}
 if(_udsExecN%25===0)_udsPruneStore('exec_history');
 // Persist to Android
 if(typeof ZeroAndroid!=='undefined'&&args.auto===false){
 ZeroAndroid.saveFile('logs','exec_'+new Date().toISOString().slice(0,10)+'.jsonl',
 JSON.stringify({prog:args.prog,lines:args.lines,cycle:args.cycle,ts:Date.now()})+'\n');
 }
 });
}

function udsWriteNN(){
 if(!zeroDB||!NN.w1||appState.aiCyc%20!==0)return; // every 20 cycles, only when NN initialized
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('nn_history','readwrite');
 tx.objectStore('nn_history').add({cycle:appState.aiCyc,ts:Date.now(),loss:NN.loss,lr:NN.lr,silSc: appState.silSc,trainN:NN.trainN});
 }catch(e){}
 _udsNNWriteN++;
 if(_udsNNWriteN%25===0)_udsPruneStore('nn_history');
 });
}

function udsWritePattern(hz,count,classId){
 if(!zeroDB||count<5)return;
 Promise.resolve().then(()=>{
 try{
 const tx=zeroDB.transaction('freq_patterns','readwrite');
 tx.objectStore('freq_patterns').put({hz,count,classId,ts:Date.now(),silSc: appState.silSc});
 }catch(e){}
 });
}

/* ══ UDS QUERY FUNCTIONS ══ */

window.DBNAME=DBNAME; window.DBVER=DBVER; window.zeroDB=zeroDB;
window.initDB=initDB; window.UDS_CAP=UDS_CAP; window._udsPruneStore=_udsPruneStore;
window._udsEventN=_udsEventN; window._udsExecN=_udsExecN; window._udsNNWriteN=_udsNNWriteN;
window.udsWriteEvent=udsWriteEvent; window.udsWriteExec=udsWriteExec; window.udsWriteNN=udsWriteNN;
window.udsWritePattern=udsWritePattern;

})();
/* ── 09-sessions-export-wtafs.js ── */

'use strict';
(function(){

async function udsQueryEvents(type,limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('terminal_events','readonly');
 const store=tx.objectStore('terminal_events');
 // 'ALL' or missing type → return all events (no index filter)
 const req=(!type||type==='ALL')
 ? store.getAll()
 : store.index('type').getAll(type);
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit||500));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryExec(prog,limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('exec_history','readonly');
 const store=tx.objectStore('exec_history');
 const req=prog?store.index('prog').getAll(prog):store.getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryNNHistory(limit){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('nn_history','readonly');
 const req=tx.objectStore('nn_history').getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,limit));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsQueryPatterns(){
 if(!zeroDB)return[];
 return new Promise(res=>{
 try{
 const tx=zeroDB.transaction('freq_patterns','readonly');
 const req=tx.objectStore('freq_patterns').getAll();
 req.onsuccess=e=>res(e.target.result.sort((a,b)=>b.count-a.count));
 req.onerror=()=>res([]);
 }catch(e){res([]);}
 });
}

async function udsGetStats(){
 if(!zeroDB)return{};
 const stores=['terminal_events','exec_history','nn_history','freq_patterns','sessions'];
 const counts={};
 await Promise.all(stores.map(s=>new Promise(res=>{
 try{
 const tx=zeroDB.transaction(s,'readonly');
 const req=tx.objectStore(s).count();
 req.onsuccess=e=>{counts[s]=e.target.result;res();};
 req.onerror=()=>{counts[s]=0;res();};
 }catch(e){counts[s]=0;res();}
 })));
 return counts;
}

/* ══ STORAGE PERSISTENCE REQUEST ══ */
async function reqStoragePersist(){
 if('storage' in navigator&&'persist' in navigator.storage){
 const ok=await navigator.storage.persist();
 stLog(' Storage persist: '+(ok?'✓ granted (no-evict)':'✗ denied (evictable)'));
 const est=await navigator.storage.estimate();
 stLog(` Storage: used=${Math.round((est.usage||0)/1024)}KB / quota=${Math.round((est.quota||0)/1024/1024)}MB`);
 if(typeof ZeroAndroid!=='undefined'){
 const ib=ZeroAndroid.getInternalPath();
 const xb=ZeroAndroid.getExportPath();
 stLog(` Internal: ${ib}`);
 stLog(` Export: ${xb}`);
 }
 }
}

function buildSessionObj(){
 return{
 date:new Date().toISOString(),
 cycles:appState.aiCyc,bestSilence:appState.bestSil,
 freqCap:freqFile.totalCap,freqConf:freqFile.totalConf,freqCanc:freqFile.totalCanc,
 nnTrain:NN.trainN,nnLoss:NN.loss,
 classDistrib:{...FC},
 freqTop:freqFile.entries.slice(0,50).map(e=>({hz:e.hz,count:e.count,energy:e.energy,confirmed:e.confirmed,cancelled:e.cancelled,class:e.class})),
 nnW:{w1:NN.w1?[...NN.w1]:null,b1:NN.b1?[...NN.b1]:null,w2:NN.w2?[...NN.w2]:null,b2:NN.b2?[...NN.b2]:null},
 bgRuns:typeof bgRuns!=='undefined'?bgRuns:0,
 bgMs:typeof bgTotalMs!=='undefined'?bgTotalMs:0,
 achievements:[...earnedAch],
 sampleRate:appState.actx?appState.actx.sampleRate:0
 };
}

async function saveSession(){
 if(!zeroDB||appState.aiCyc<5)return;
 const sess=buildSessionObj();
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readwrite');
 tx.objectStore('sessions').add(sess);
 tx.oncomplete=()=>{stLog(' Session saved · cycles='+appState.aiCyc+' · silence='+appState.bestSil+'%');res();};
 tx.onerror=()=>res();
 });
}

async function loadLastWeights(){
 if(!zeroDB)return false;
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').openCursor(null,'prev');
 req.onsuccess=e=>{
 const cur=e.target.result;
 if(cur&&cur.value.nnW&&cur.value.nnW.w1){
 const w=cur.value.nnW;
 if(!NN.w1)nnInit();
 NN.w1=[...w.w1];NN.b1=[...w.b1];NN.w2=[...w.w2];NN.b2=[...w.b2];
 NN.trainN=cur.value.nnTrain||0;
 stLog(' NN restored: trained='+NN.trainN+' from '+new Date(cur.value.date).toLocaleDateString());
 logExec({prog:'SYS',lines:['Previous Session Restored ','NN weights loaded · training='+NN.trainN+' · best silence='+cur.value.bestSilence+'%','FreqDB history: '+cur.value.freqCap+' captured — continue from previous session'],ms:0,auto:true});
 res(true);
 }else res(false);
 };
 req.onerror=()=>res(false);
 });
}

async function restoreNNFromDB(){
 const ok=await loadLastWeights();
 if(!ok)stLog(' No saved NN weights found');
}

async function getAllSessions(){
 if(!zeroDB)return[];
 return new Promise(res=>{
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').getAll();
 req.onsuccess=e=>res(e.target.result.reverse().slice(0,10));
 req.onerror=()=>res([]);
 });
}

async function clearAllSessions(){
 if(!zeroDB)return;
 if(window.confirm&&!confirm('Clear all saved sessions?'))return;
 const tx=zeroDB.transaction('sessions','readwrite');
 tx.objectStore('sessions').clear();
 tx.oncomplete=()=>{stLog(' All sessions cleared');refreshSessionList();};
}

async function refreshSessionList(){
 const el=E('sess-list');if(!el)return;
 const sessions=await getAllSessions();
 if(!sessions.length){el.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">No saved sessions</div>';return;}
 el.innerHTML=sessions.map((s,i)=>{
 const d=new Date(s.date);
 return`<div class="st-frow"><div style="font-size:14px"></div><div style="flex:1;min-width:0"><div class="st-fn">${d.toLocaleDateString()} ${d.toLocaleTimeString()}</div><div class="st-fd">sil=${s.bestSilence}% · cyc=${s.cycles} · NN=${s.nnTrain} · freqs=${s.freqCap}</div></div><div class="st-btn ai" style="font-size:8px;padding:3px 7px" onclick="loadSession(${s.id})">load</div></div>`;
 }).join('');
 const sc=E('st-sessions');if(sc)sc.textContent=sessions.length;
 drawSessHist(sessions);
}

/* ══ SESSIONS HISTORY TREND — اتجاه فعالية الإلغاء عبر الجلسات المحفوظة (29 سبتمبر 2026) ══
   نفس أسلوب drawSQIHist() تماماً (05-presets-scenes-tracking.js): Canvas يدوي بلا أي
   مكتبة خارجية، DPR-aware، خطوط إرشادية منقّطة عند 50/80، تعبئة رمادية خفيفة تحت المنحنى،
   خط رفيع + نقطة القيمة الأخيرة، تسميات الزوايا — رمادي بحت بلا أي لون (نفس قيد المشروع).
   المصدر: getAllSessions() نفسها (الأحدث أولاً، حتى 10) — تُعكَس هنا فقط لعرضها زمنياً
   من الأقدم (يسار) إلى الأحدث (يمين)، مطابقاً لاتجاه قراءة القائمة النصّية المجاورة. */
function drawSessHist(sessions){
 const cv=E('sessHistCv');if(!cv)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||200,H=44;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(0,0,cW,cH);
 const data=(sessions||[]).slice().reverse().map(s=>+s.bestSilence||0);
 if(data.length<2){
 ctx.fillStyle='rgba(255,255,255,.18)';ctx.font=`${Math.round(8*dpr)}px monospace`;
 ctx.fillText('Waiting for more sessions…',8*dpr,cH/2+3*dpr);return;
 }
 // خطوط إرشادية عند 50 و80
 ctx.setLineDash([2,4]);ctx.lineWidth=1;ctx.strokeStyle='rgba(255,255,255,.08)';
 [50,80].forEach(v=>{const y=cH-(v/100)*cH;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cW,y);ctx.stroke();});
 ctx.setLineDash([]);
 // تعبئة تحت المنحنى
 ctx.beginPath();let first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.lineTo(cW,cH);ctx.lineTo(0,cH);ctx.closePath();
 ctx.fillStyle='rgba(135,135,135,.10)';ctx.fill();
 // الخط
 const last=data[data.length-1];
 const col=last>=80?'#a5a5a5':last>=50?'#b0b0b0':'#7c7c7c';
 ctx.beginPath();first=true;
 for(let i=0;i<data.length;i++){const x=(i/(data.length-1))*cW,y=cH-(data[i]/100)*cH;if(first){ctx.moveTo(x,y);first=false;}else ctx.lineTo(x,y);}
 ctx.strokeStyle=col;ctx.lineWidth=1.5*dpr;ctx.lineJoin='round';ctx.stroke();
 // نقطة آخر جلسة
 {const x=cW-2*dpr,y=cH-(last/100)*cH;ctx.beginPath();ctx.arc(x,y,2.5*dpr,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();}
 // تسميات الزوايا
 ctx.fillStyle='rgba(255,255,255,.25)';ctx.font=`${Math.round(6*dpr)}px monospace`;
 ctx.fillText('100',3*dpr,7*dpr);ctx.fillText('0',3*dpr,cH-2*dpr);
 ctx.fillStyle=col;ctx.textAlign='right';ctx.fillText(last,cW-3*dpr,7*dpr);ctx.textAlign='left';
}

async function loadSession(id){
 if(!zeroDB)return;
 const tx=zeroDB.transaction('sessions','readonly');
 const req=tx.objectStore('sessions').get(id);
 req.onsuccess=e=>{
 const s=e.target.result;if(!s)return;
 // Restore NN
 if(s.nnW&&s.nnW.w1){if(!NN.w1)nnInit();NN.w1=[...s.nnW.w1];NN.b1=[...s.nnW.b1];NN.w2=[...s.nnW.w2];NN.b2=[...s.nnW.b2];NN.trainN=s.nnTrain||0;}
 // Restore FreqDB
 if(s.freqTop){freqDB.clear();s.freqTop.forEach(e=>freqDB.set(e.hz,{...e,firstSeen:Date.now(),lastSeen:Date.now()}));freqFile.totalCap=s.freqCap||0;freqFile.totalConf=s.freqConf||0;freqFile.totalCanc=s.freqCanc||0;writeFreqFile();}
 // Restore achievements
 if(s.achievements)s.achievements.forEach(id2=>earnedAch.add(id2));
 // تشديد: جلسة قديمة محفوظة قبل إصلاح خلل NaN/0Hz قد تحمل إدخالات فاسدة — تُنظَّف فوراً
 _purgeInvalidFrequencies('بعد استعادة جلسة محفوظة');
 stLog(' Session loaded: '+new Date(s.date).toLocaleString());
 updateFilesUI();
 };
}

/* ═══════════════════════════════════
 ② ANTHROPIC FILES API
 Upload FreqDB, NN weights, sessions
 for AI-accessible context in Claude chat
═══════════════════════════════════ */
/* Local storage only — no cloud files */

/* ══════════════════════════════════════
 LOCAL FILE STORAGE — Android bridge + browser download
 Paths (Android):
 Internal: /data/data/com.zero.v25/files/ZeroAI_v25/
 sessions/ freqdb/ nn_weights/ logs/
 Export: /sdcard/ZeroAI/v25/Export/ (or Android Q: getExternalFilesDir)
 No cloud, no network required.
══════════════════════════════════════ */

/* Android JS bridge — writes to internal/external storage */
/* تعميم "منح الوصول لمجلد ثابت" (WebToApkFS) على كل المشروع دفعة واحدة: هذه هي الدالة
 المشتركة التي يمر عبرها saveFreqDBLocal/saveNNLocal/saveFullSessionLocal (ولاحقاً
 exportJSON/exportCSV) — رفع أولوية WebToApkFS هنا، بنفس النمط المُطبَّق مسبقاً في
 exportBans وPERSIST._mfWrite، يمنح جميع نقاط الحفظ تلك وصولاً لمجلد ثابت حقيقي ومرئي
 للمستخدم فوراً دون تعديل كل دالة على حدة. الأولوية: WebToApkFS (مجلد ثابت عبر SAF) ←
 ZeroAndroid (تخزين داخلي خاص بالتطبيق) ← false (يعني: استخدم تنزيل المتصفح). */
function androidWrite(subdir,filename,content){
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 const ok=WebToApkFS.writeText(filename,content);
 if(ok){
 stLog(' Saved: '+filename+' (المجلد الثابت)');
 // تشديد أكثر: بلا هذا، كل ملف freqdb_/nn_/session_ جديد يتراكم إلى الأبد — نفس خلل
 // ZERO_Bans_ الأصلي، لكن على 3 مستخدِمين لهذه الدالة المشتركة دفعة واحدة.
 _cleanupFixedFolderBackups();
 return true;
 }
 }
 }catch(e){}
 if(typeof ZeroAndroid!=='undefined'){
 const ok=ZeroAndroid.saveFile(subdir,filename,content);
 if(ok)stLog(' Saved: '+subdir+'/'+filename+' (Android)');
 else stLog(' Android write failed: '+subdir+'/'+filename);
 return ok;
 }
 return false; // browser fallback: use download
}

function androidRead(subdir,filename){
 if(typeof ZeroAndroid!=='undefined')return ZeroAndroid.readFile(subdir,filename);
 return null;
}

function androidListFiles(subdir){
 if(typeof ZeroAndroid!=='undefined'){
 const r=ZeroAndroid.listFiles(subdir);
 return r?JSON.parse(r):[];
 }
 return[];
}

function getStoragePaths(){
 if(typeof ZeroAndroid!=='undefined'){
 return{
 internal:ZeroAndroid.getInternalPath(),
 export:ZeroAndroid.getExportPath(),
 available:true
 };
 }
 return{internal:'IndexedDB',export:'Browser Download',available:false};
}

/* Save FreqDB to local storage */
function saveFreqDBLocal(){
 if(!freqDB.size){stLog(' FreqDB empty');return;}
 const data={
 type:'ZeroAI_FreqDB_v25',date:new Date().toISOString(),
 sampleRate:appState.actx?appState.actx.sampleRate:0,nyquist:appState.actx?appState.actx.sampleRate/2:0,
 stats:{totalCap:freqFile.totalCap,totalConf:freqFile.totalConf,totalCanc:freqFile.totalCanc},
 frequencies:freqFile.entries.slice(0,200).map(e=>({hz:e.hz,count:e.count,energy:+e.energy.toFixed(4),confirmed:e.confirmed,cancelled:e.cancelled,class:e.class,invOk:e.invOk})),
 classDistrib:{...FC},bayesian:{w1:DRV.wS,w2:DRV.wE,w3:DRV.wM},
 nnState:{trainN:NN.trainN,loss:NN.loss,lr:NN.lr},silence:appState.silSc
 };
 const fname='freqdb_'+_isoFname()+'.json';
 const json=JSON.stringify(data,null,2);
 if(!androidWrite('freqdb',fname,json)){
 // Browser fallback — download
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' FreqDB saved: '+fname+' ('+Math.round(json.length/1024)+'KB)');
 }
 updateFilesUI();
}

/* Save NN weights to local storage */
function saveNNLocal(){
 if(!NN.w1){stLog(' NN not initialized');return;}
 const data={type:'ZeroAI_NN_v25',date:new Date().toISOString(),architecture:'16→24→8',trainN:NN.trainN,loss:NN.loss,lr:NN.lr,momentum:NN.mom,w1:[...NN.w1],b1:[...NN.b1],w2:[...NN.w2],b2:[...NN.b2]};
 const fname='nn_'+_isoFname()+'.json';
 const json=JSON.stringify(data);
 if(!androidWrite('nn_weights',fname,json)){
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' NN weights saved: '+fname);
 }
}

/* Save full session log */
function saveFullSessionLocal(){
 const sess=buildSessionObj();
 const fname='session_'+_isoFname()+'.json';
 const json=JSON.stringify(sess,null,2);
 if(!androidWrite('sessions',fname,json)){
 const b=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=fname;a.click();
 stLog(' Session saved: '+fname+' ('+Math.round(json.length/1024)+'KB)');
 }
 updateFilesUI();
}

/* AI chat: local engine only — no network */

/* ═══════════════════════
 ③ EXPORT / IMPORT
═══════════════════════ */
/* ════════════════════════════════════════
 BAN LIST EXPORT / IMPORT
════════════════════════════════════════ */
function _getBansForExport(){
 // نجمع من AI_BAN (النشط) + PERSIST (يشمل الموقوف — My Files أولاً ثم localStorage)
 const map=new Map([...AI_BAN]);
 try{
 let raw=PERSIST._mfRead('zero_bans.json');
 if(!raw)raw=localStorage.getItem(PERSIST.K.bans);
 if(raw){
 const data=JSON.parse(raw);
 if(Array.isArray(data.entries)){
 data.entries.forEach(([bin,d])=>{if(!map.has(bin))map.set(bin,d);});
 }
 }
 }catch(e){}
 // نفرض hz من مفتاح الـMap دائماً — يضمن عدم ظهور 0.00Hz حتى لو كانت البيانات القديمة ناقصة
 // التصدير يركّز على الجديد فقط — نستبعد الترددات "الأساسية" (baseline: الحضر الافتراضي +
 // الحضر المؤكَّد من طبقة التكامل) لأنها ثابتة ومعروفة مسبقاً وليست جديدة يستحق تصديرها
 return [...map.entries()].filter(([,d])=>!d.baseline).map(([bin,d])=>({...d,hz:bin})).sort((a,b)=>a.hz-b.hz);
}

function _showExpMsg(msg,type){
 const el=E('ban-exp-msg');if(!el)return;
 el.textContent=msg;el.className='ban-exp-msg '+(type||'');
}

/* تنسيق تاريخ/وقت مبسّط وثابت (بدل الاعتماد على عداد الدورات execCyc فقط) */
function _fmtDT(ms){
 if(!ms)return'—';
 const d=new Date(ms);const p=n=>String(n).padStart(2,'0');
 return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes());
}
/* "توحيد الكل في ملف واحد": نفس بناء بيانات bans/interference المُستخدَم داخل
 _buildBansExportContent (تصدير ملف الحظر المستقل ZERO_Bans_) — مُستخرَج هنا في دالة مشتركة
 يستخدمها exportJSON أيضاً كي تحمل "النسخة الاحتياطية الكاملة" ZeroAI_v25_ نفس بيانات الحظر
 ومناطق التداخل، فيصبح ملف واحد كافياً لاستعادة كل الحالة القابلة للاستعادة في التطبيق (NN +
 FreqDB + الإنجازات + الحظر + مناطق التداخل) بدل الحاجة لملفين منفصلين (ZERO_Bans_ +
 ZeroAI_v25_) لاستعادة كامل الحالة. تصدير الحظر المستقل (exportBans/shareBans) يبقى كما هو
 دون أي تغيير — هذا توسيع لا استبدال. */
function _buildBansAndZonesForUnifiedBackup(){
 const bans=_getBansForExport();
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].filter(([,z])=>!z.baseline).sort((a,b)=>b[1].count-a[1].count);
 return {
 bans:bans.map(d=>({
 hz:+(d.hz||0).toFixed(4),
 category:d.category||'unknown',
 reason:d.reason||'',
 bannedAt:d.bannedAt||0,
 bannedAtTime:d.bannedAtTime||null,
 cycles:d.cycles||0,
 permanent:true,
 preBanEnergy:+(d.preBanEnergy||0).toFixed(6),
 verdict:d.verdict||null,
 crossConfirms:d.crossConfirms||0
 })),
 interference:zonesArr.map(([hz,z])=>({hz:+hz.toFixed(4),count:z.count,widenHz:z.widen||0,lastAt:z.lastT||null,crossConfirms:z.crossConfirms||0}))
 };
}
/* ── يبني محتوى التصدير (JSON/CSV/TXT) دون كتابته لأي وجهة — منطق مشترك بين
 exportBans() (تنزيل/مجلد ثابت) وshareBans() (مشاركة أصلية عبر navigator.share). ── */
function _buildBansExportContent(fmt){
 // التصدير يركّز على الجديد فقط — الترددات ومناطق التداخل "الأساسية" (baseline) مستبعدة
 // لأنها ثابتة ومعروفة مسبقاً (تُعاد توليدها تلقائياً من الحضر الافتراضي + طبقة التكامل)
 const bans=_getBansForExport();
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].filter(([,z])=>!z.baseline).sort((a,b)=>b[1].count-a[1].count);
 if(!bans.length&&!zonesArr.length)return null;
 const ts=new Date().toISOString().slice(0,19).replace(/T/,'_').replace(/:/g,'-');
 let filename,content,mime;

 if(fmt==='json'){
 filename='ZERO_Bans_'+ts+'.json';
 mime='application/json';
 content=JSON.stringify({
 version:'ZERO AI v25',
 exportDate:new Date().toISOString(),
 scope:'الجديد فقط — بدون الحضر الأساسي/المؤكَّد المُعاد توليده تلقائياً',
 // تشديد: يوثّق أي دفعة CONFIRMED_BANS/CONFIRMED_INTERFERENCE (zero-core.js) كانت محمَّلة
 // فعلياً وقت هذا التصدير — يمنع الالتباس لاحقاً إن كان الجهاز يشغّل نسخة أقدم لم تُحدَّث
 baselineBans:typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0,
 baselineZones:typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0,
 totalBans:bans.length,
 source:'AI_BAN + PERSIST',
 bans:bans.map(d=>({
 hz:+(d.hz||0).toFixed(4),
 category:d.category||'unknown',
 reason:d.reason||'',
 bannedAt:d.bannedAt||0,
 bannedAtTime:d.bannedAtTime||null,
 cycles:d.cycles||0,
 permanent:true,
 preBanEnergy:+(d.preBanEnergy||0).toFixed(6),
 verdict:d.verdict||null,
 crossConfirms:d.crossConfirms||0
 })),
 interference:zonesArr.map(([hz,z])=>({hz:+hz.toFixed(4),count:z.count,widenHz:z.widen||0,lastAt:z.lastT||null,crossConfirms:z.crossConfirms||0}))
 },null,2);

 }else if(fmt==='csv'){
 filename='ZERO_Bans_'+ts+'.csv';
 mime='text/csv';
 const hdr='hz,category,reason,cycles,bannedAt,bannedAtTime,preBanEnergy,verdict';
 const rows=bans.map(d=>[
 (d.hz||0).toFixed(4),
 d.category||'',
 '"'+(d.reason||'').replace(/"/g,"''")+'"',
 d.cycles||0,
 d.bannedAt||0,
 d.bannedAtTime?_fmtDT(d.bannedAtTime):'',
 (d.preBanEnergy||0).toFixed(6),
 d.verdict||''
 ].join(','));
 content=hdr+'\n'+rows.join('\n');

 }else{
 filename='ZERO_Bans_'+ts+'.txt';
 mime='text/plain';
 const lines=[
 'ZERO AI v25 — الترددات المحظورة ومراقبة التداخل',
 'تاريخ التصدير: '+_fmtDT(Date.now()),
 '(الجديد فقط — الحضر الأساسي/المؤكَّد يُعاد توليده تلقائياً ولا يُصدَّر)',
 // تشديد: يسجّل نسخة القائمة الأساسية المحمَّلة وقت هذا التصدير بالضبط — إن ظهرت لاحقاً
 // ترددات "مكررة" عند دمج هذا الملف، هذا السطر يوضّح فوراً إن كان السبب نسخة قديمة
 'نسخة القائمة الأساسية وقت التصدير: '+(typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0)+' تردد + '+(typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0)+' منطقة تداخل',
 ''
 ];
 lines.push(' الترددات المحضورة الجديدة ('+bans.length+' تردد)');
 lines.push('─'.repeat(48));
 if(!bans.length){
 lines.push('لا يوجد حضر جديد');
 }else{
 bans.forEach(d=>{
 lines.push((d.hz||0).toFixed(2)+'Hz');
 });
 }
 lines.push('');
 lines.push(' مناطق التداخل الجديدة ('+zonesArr.length+' منطقة)');
 lines.push('─'.repeat(48));
 if(!zonesArr.length){
 lines.push('لا يوجد تداخل جديد مرصود');
 }else{
 zonesArr.forEach(([center,z])=>{
 const hz=center.toFixed(2)+'Hz';
 const info='عدد مرات التداخل: '+z.count+(z.widen?' · موسّع ±'+z.widen.toFixed(0)+'Hz':'')+(z.crossConfirms?' · مؤكَّد×'+z.crossConfirms:'');
 lines.push(hz.padEnd(12)+' │ '+info);
 });
 }
 lines.push('');
 lines.push('─'.repeat(48));
 lines.push('مسار التصدير: '+(_wtafsOk()&&WebToApkFS.hasAccess()?('مجلد ثابت — '+WebToApkFS.getAccessUri()):
 (typeof ZeroAndroid!=='undefined')?ZeroAndroid.getExportPath():'تنزيل المتصفح'));
 content=lines.join('\n');
 }
 return {filename,content,mime,bansCount:bans.length,zonesCount:zonesArr.length};
}

function exportBans(fmt){
 const built=_buildBansExportContent(fmt);
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للتصدير','err');return;}
 const {filename,content,mime,bansCount,zonesCount}=built;
 // إصلاح مماثل لنفس مشكلة shareBans: ملف csv لا يحتوي صفوف مناطق تداخل إطلاقاً، فلا
 // نذكر عددها في رسائل النجاح/السجلّ لهذا التنسيق تحديداً كي لا يُظنّ أنها ضمن الملف.
 const zonesNote=(fmt==='csv')?'':(' + '+zonesCount+' تداخل جديد');

 // ⓪ نسخة دائمة إضافية إلى المجلد الثابت (WebToApkFS) إن كان الوصول ممنوحاً — مستقلة عن
 // التنزيل عبر المتصفح، وهي ما يعتمد عليه زر "استيراد آخر نسخة من المجلد" لاحقاً.
 let wtafsSaved=false;
 try{
 if(_wtafsOk()&&WebToApkFS.hasAccess()){
 wtafsSaved=!!WebToApkFS.writeText(filename,content);
 if(wtafsSaved)_cleanupFixedFolderExports();
 }
 }catch(e){}
 // ⓪ب نسخة موازية إلى الملف الثابت المختار (البديل الأخفّ من مجلد كامل)، إن وُجد —
 // بصرف النظر عن التنسيق (json/csv/txt)، فكل تصدير يُحدِّث نفس ذلك الملف تلقائياً بأحدث JSON.
 let wtafsPickSaved=false;
 try{
 const pickedUri=localStorage.getItem(_pickedFileKey());
 if(pickedUri&&_wtafsOk()){
 const jsonBuilt=(fmt==='json')?built:_buildBansExportContent('json');
 if(jsonBuilt){
 const w=WebToApkFS.writeAll(pickedUri,_b64FromText(jsonBuilt.content));
 wtafsPickSaved=!!(w&&w.ok);
 }
 }
 }catch(e){}
 const wtafsNote=(wtafsSaved?' + المجلد الثابت':'')+(wtafsPickSaved?' + الملف الثابت المختار':'');

 // ① محاولة الحفظ عبر Android Bridge → My Files
 if(typeof ZeroAndroid!=='undefined'){
 const ok=ZeroAndroid.exportFile(filename,content);
 if(ok){
 const path=ZeroAndroid.getExportPath()+'/'+filename;
 _showExpMsg('✓ تم الحفظ في: '+path+wtafsNote,'ok');
 stLog(' Ban export: '+filename+' ('+bansCount+' تردد جديد'+zonesNote+')'+wtafsNote);
 return;
 }
 _showExpMsg(' فشل الحفظ عبر Android — جارٍ التنزيل...','err');
 }

 // ② Fallback: تنزيل مباشر (متصفح)
 const blob=new Blob([content],{type:mime});
 const url=URL.createObjectURL(blob);
 const a=document.createElement('a');
 a.href=url;a.download=filename;
 document.body.appendChild(a);a.click();
 setTimeout(()=>{URL.revokeObjectURL(url);document.body.removeChild(a);},1000);
 _showExpMsg('✓ جارٍ التنزيل: '+filename+wtafsNote,'ok');
 stLog(' Ban export (browser): '+filename+wtafsNote);
}

/* ══ مشاركة أصلية (navigator.share) ══
 تشديد: هذا البناء (خدمة تحويل الموقع إلى APK) يحقن تلقائياً navigator.share/canShare
 القياسيَين ليعملا عبر شاشة المشاركة الأصلية لأندرويد (WhatsApp/Telegram/بريد/...) —
 مؤكَّد بفحص classes.dex مباشرة. هذا يُبسِّط كثيراً سير العمل الحالي: بدل تصدير الملف ثم
 البحث عنه يدوياً وإرساله، زر واحد يفتح شاشة المشاركة مباشرة بالملف جاهزاً للإرسال. */
async function shareBans(fmt){
 const built=_buildBansExportContent(fmt);
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للمشاركة','err');return;}
 const {filename,content,mime,bansCount,zonesCount}=built;
 if(!navigator.share){
 _showExpMsg(' المشاركة الأصلية غير مدعومة في هذا البناء — استخدم زر التنزيل بدلاً منها','err');
 return;
 }
 // تصحيح: تنسيق csv لا يتضمّن بيانات مناطق التداخل إطلاقاً داخل الملف نفسه (انظر
 // _buildBansExportContent أعلاه — قسم csv لا يكتب أي صفوف لمناطق التداخل)، فذكر عددها في
 // نص المشاركة كان يُوهِم المستلم بأن تلك المناطق مرفقة ضمن الملف المُشارَك رغم غيابها فعلياً.
 const zonesNote=(fmt==='csv')?'':(' + '+zonesCount+' منطقة تداخل جديدة');
 try{
 const file=new File([content],filename,{type:mime});
 const shareData={
 files:[file],
 title:'ZERO AI v25 — تصدير الحظر',
 text:bansCount+' تردد جديد'+zonesNote
 };
 if(navigator.canShare&&!navigator.canShare(shareData)){
 _showExpMsg(' مشاركة الملفات غير مدعومة هنا — استخدم زر التنزيل بدلاً منها','err');
 return;
 }
 await navigator.share(shareData);
 _showExpMsg('✓ فُتحت شاشة المشاركة: '+filename,'ok');
 stLog(' Ban share: '+filename+' ('+bansCount+' تردد جديد'+zonesNote+')');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق شاشة المشاركة — ليس خطأ
 _showExpMsg(' فشلت المشاركة: '+e.message,'err');
 }
}

/* ── نسخ نصّ التصدير (TXT) مباشرة للحافظة — بديل أسرع من المشاركة عند إرسال رسالة نصّية
 قصيرة (بلا مرفق ملف)، كما في لصق المحتوى مباشرة داخل محادثة. ── */
async function copyBansToClipboard(){
 const built=_buildBansExportContent('txt');
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للنسخ','err');return;}
 if(!navigator.clipboard||typeof navigator.clipboard.writeText!=='function'){
 _showExpMsg(' النسخ للحافظة غير مدعوم في هذا البناء','err');
 return;
 }
 try{
 await navigator.clipboard.writeText(built.content);
 _showExpMsg('✓ نُسخ الملخّص للحافظة ('+built.bansCount+' تردد + '+built.zonesCount+' تداخل)','ok');
 stLog(' Ban summary copied to clipboard ('+built.bansCount+' bans + '+built.zonesCount+' zones)');
 }catch(e){
 _showExpMsg(' فشل النسخ: '+e.message,'err');
 }
}

/* ── نسخ JSON (وليس TXT الوصفي) للحافظة — هذا هو التنسيق الوحيد القابل للدمج عبر
 _mergeImportedBansJSON، فهو ما يُستخدَم فعلياً لنقل القائمة بين جهازين عبر اللصق. ── */
async function copyBansJSONToClipboard(){
 const built=_buildBansExportContent('json');
 if(!built){_showExpMsg(' لا توجد ترددات أو مناطق تداخل جديدة للنسخ','err');return;}
 if(!navigator.clipboard||typeof navigator.clipboard.writeText!=='function'){
 _showExpMsg(' النسخ للحافظة غير مدعوم في هذا البناء','err');
 return;
 }
 try{
 await navigator.clipboard.writeText(built.content);
 _showExpMsg('✓ نُسخ JSON للحافظة ('+built.bansCount+' تردد + '+built.zonesCount+' تداخل) — الصقه في التطبيق على الجهاز الآخر','ok');
 stLog(' Ban JSON copied to clipboard ('+built.bansCount+' bans + '+built.zonesCount+' zones)');
 }catch(e){
 _showExpMsg(' فشل النسخ: '+e.message,'err');
 }
}

/* ── استيراد مباشر من الحافظة — يقرأ آخر نصّ منسوخ (يُفترض JSON من الزر أعلاه على جهاز
 آخر) ويدمجه عبر نفس منطق الاستيراد المشترك. لا يعتمد على أي إذن SAF أو مجلد ثابت. ── */
async function pasteImportFromClipboard(){
 if(!navigator.clipboard||typeof navigator.clipboard.readText!=='function'){
 _showExpMsg(' القراءة من الحافظة غير مدعومة في هذا البناء','err');
 return;
 }
 try{
 const text=await navigator.clipboard.readText();
 if(!text||!text.trim()){_showExpMsg(' الحافظة فارغة — انسخ JSON من الجهاز الآخر أولاً','err');return;}
 const res=_mergeImportedBansJSON(text,'الحافظة (لصق)');
 _showExpMsg('✓ استُورد من الحافظة: '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){
 if(e instanceof SyntaxError){_showExpMsg(' محتوى الحافظة ليس JSON صحيحاً لهذا التطبيق','err');return;}
 _showExpMsg(' فشل الاستيراد من الحافظة: '+e.message,'err');
 }
}

/* ── منطق دمج مشترك لاستيراد ملف JSON (ترددات + مناطق تداخل) — يستخدمه كل من
 importBanFile (اختيار ملف عبر متصفح النظام) وimportFromFixedFolder (قراءة مباشرة
 من المجلد الثابت عبر WebToApkFS)، لتفادي ازدواج المنطق وتضاربه مستقبلاً. ── */
function _mergeImportedBansJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 if(!data.bans||!Array.isArray(data.bans)){
 throw new Error('صيغة الملف غير صحيحة — يجب أن يحتوي على مفتاح "bans"');
 }
 let added=0,skipped=0;
 // تأكيد متقاطع بين الأجهزة: كل استيراد يمثّل جهازاً/جلسة أخرى رصدت نفس التردد بشكل
 // مستقل. نعُدّ ذلك دليلاً إضافياً — لا نستبدل حكم هذا الجهاز الخاص (verdict) المبني على
 // قياسه الفعلي لطاقة ما بعد الحظر، بل نُسجِّل حكم المصدر المستورَد بجانبه (importedVerdict)
 // ونقارن: تطابق الحكمين يرفع الثقة، وتعارضهما (env هنا وspk هناك) يشير غالباً إلى تردد
 // خاص بجهاز واحد (كسماعته الخاصة) وليس تداخلاً بيئياً عاماً يستحق حظراً على كل الأجهزة.
 let crossConfirmed=0,verdictConflicts=0;
 // تنظيف المُدخَل أولاً: نتجاهل أي عنصر تالف (غير كائن، أو hz غير رقمي/غير منتهٍ — كانت
 // تُفرَض NaN كمفتاح Map فتتحوّل إلى null صامتاً عند JSON.stringify/الحفظ، فتُكسِّر كل
 // عرض لاحق لقائمة الحظر بعد إعادة التشغيل)، ونُوحِّد أي تكرار لنفس الخانة 0.5Hz ضمن نفس
 // الملف إلى معالجة واحدة فقط (وإلا يُحتسَب "تأكيد متقاطع" زائف من نفس الملف نفسه، لا من
 // مصدر مستقل آخر فعلاً).
 const seenBins=new Set();
 data.bans.forEach(b=>{
 if(!b||typeof b!=='object'){skipped++;return;}
 const hzNum=Number(b.hz);
 if(!isFinite(hzNum)){skipped++;return;}
 const bin=fBin(hzNum);
 if(seenBins.has(bin))return; // تكرار داخل نفس الملف — يُتجاهَل صامتاً
 seenBins.add(bin);
 const importedVerdict=b.verdict||null;
 if(!AI_BAN.has(bin)){
 AI_BAN.set(bin,{
 hz:bin,reason:b.reason||'Imported',
 bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,permanent:true,
 category:b.category||'custom',
 preBanEnergy:b.preBanEnergy||0,
 postBanDetections:0,lastPostBanEnergy:0,
 probEnvironmental:null,verdict:null,
 crossConfirms:1,importedVerdict,verdictAgreement:null
 });
 added++;
 }else{
 const e=AI_BAN.get(bin);
 e.crossConfirms=(e.crossConfirms||0)+1;
 e.importedVerdict=importedVerdict;
 if(e.verdict&&importedVerdict){
 e.verdictAgreement=(e.verdict===importedVerdict)?'agree':'conflict';
 if(e.verdictAgreement==='agree')crossConfirmed++;else verdictConflicts++;
 }
 }
 });
 if(skipped>0)stLog(' تُجوهِل '+skipped+' إدخال بلا تردد رقمي صالح أثناء الاستيراد من '+sourceLabel);
 if(verdictConflicts>0)stLog(' '+verdictConflicts+' تردد لديه تعارض في الحكم بين هذا الجهاز والمصدر المستورَد — قد يكون خاصاً بجهاز واحد');
 if(crossConfirmed>0)stLog(' '+crossConfirmed+' تردد تأكَّد حكمه (env/spk) بشكل مستقل من '+sourceLabel);
 // تشديد: استعادة مناطق التداخل أيضاً — كانت مفقودة كلياً من الاستيراد سابقاً رغم أن
 // exportBans('json') يُصدّرها فعلياً ضمن مفتاح "interference"؛ الآن يُستكمَل الدوران
 // الكامل تصدير↔استيراد، وهو ضروري كنسخة احتياطية يدوية لأن هذا الجهاز لا يملك أي
 // تخزين أندرويد أصلي مخصَّص (localStorage/WebToApkFS فقط، قابلان للمسح/الإلغاء).
 let zonesAdded=0,zonesCrossConfirmed=0,zonesSkipped=0;
 if(Array.isArray(data.interference)){
 const seenZoneBins=new Set();
 data.interference.forEach(z=>{
 if(!z||typeof z!=='object'){zonesSkipped++;return;}
 const hzNum=Number(z.hz);
 if(!isFinite(hzNum)){zonesSkipped++;return;}
 const bin=fBin(hzNum);
 if(seenZoneBins.has(bin))return; // تكرار داخل نفس الملف
 seenZoneBins.add(bin);
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count:z.count||0,widen:z.widenHz||0,lastT:z.lastAt||0,crossConfirms:1});
 zonesAdded++;
 }else{
 // تأكيد متقاطع لمناطق التداخل أيضاً — نفس مبدأ الترددات المحظورة: لا نستبدل عدّاد
 // التصعيد المحلي (count/widen) الخاص بهذا الجهاز، لكن رصد نفس منطقة التداخل من
 // جهاز آخر مستقل دليل إضافي على أنها تداخل بيئي حقيقي ومتكرر لا ضجيج عابر.
 const zz=INTERFERENCE_BAN.zones.get(bin);
 zz.crossConfirms=(zz.crossConfirms||0)+1;
 zonesCrossConfirmed++;
 }
 });
 }
 if(zonesSkipped>0)stLog(' تُجوهِلت '+zonesSkipped+' منطقة تداخل بلا تردد رقمي صالح أثناء الاستيراد من '+sourceLabel);
 if(zonesCrossConfirmed>0)stLog(' '+zonesCrossConfirmed+' منطقة تداخل تأكَّدت بشكل مستقل من '+sourceLabel);
 PERSIST.saveBans();
 // تشديد: يجب الحفظ أيضاً حين يكون التغيير الوحيد هو تحديث crossConfirms على مناطق
 // موجودة مسبقاً (zonesAdded=0) — وإلا يُفقَد التأكيد المتقاطع بصمت عند إعادة التشغيل.
 if(zonesAdded||zonesCrossConfirmed)PERSIST.saveZones();
 renderBanList();renderPermSettings();
 stLog(' Ban import: '+added+' bans + '+zonesAdded+' zones added from '+sourceLabel);
 return {added,zonesAdded,totalBans:data.bans.length,crossConfirmed,verdictConflicts,zonesCrossConfirmed,skipped,zonesSkipped};
}

function importBanFile(){
 const inp=document.createElement('input');
 inp.type='file';inp.accept='.json';
 inp.onchange=e=>{
 const file=e.target.files[0];if(!file)return;
 const r=new FileReader();
 r.onload=ev=>{
 try{
 const res=_mergeImportedBansJSON(ev.target.result,file.name);
 _showExpMsg('✓ تم استيراد '+res.added+' تردد من '+res.totalBans+' ('+
 (res.totalBans-res.added)+' موجود مسبقاً)'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(ex){_showExpMsg(' خطأ في قراءة الملف: '+ex.message,'err');}
 };
 r.readAsText(file);
 };
 inp.click();
}

/* ══ WebToApkFS — طبقة تخزين أندرويد أصلية فعلية ("My Files") ══
 تشديد جوهري (اكتُشف عند فحص الملف المضغوط الذي أرسله المستخدم): التطبيق الفعلي الذي
 يشغّل هذا الكود مبني عبر خدمة تجارية عامة لتحويل موقع إلى APK (قائمة على Capacitor)، ولا
 يحتوي جسر ZeroAndroid المخصَّص إطلاقاً (تأكَّد عبر فحص classes.dex مباشرة). لكنه يحتوي
 جسراً بديلاً حقيقياً وفعّالاً: window.WebToApkFS — يمنح وصولاً دائماً (Android Storage
 Access Framework) لمجلد يختاره المستخدم مرة واحدة فقط، مع قراءة/كتابة ملفات نصّية مباشرة
 على ذلك المسار الثابت. هذا أقوى بكثير من الاعتماد على localStorage وحده: ملفات حقيقية
 ومرئية للمستخدم، يمكن تصفّحها أو نسخها احتياطياً يدوياً من أي تطبيق ملفات على الجهاز. */
/* تشديد جوهري (اكتُشف بفك ترجمة الكود الأصلي المُصرَّف فعلياً عبر jadx — ليس فقط الكود
 المحقون في WebView): window.WebToApk.isFolderAccessEnabled() على الجهاز الحقيقي تعود
 من دالة Java تقرأ حرفياً appConfig.h0، وهذا بدوره حقل واحد فقط في إعدادات البناء
 (config.json) اسمه الفعلي "permSafFolderAccess" — قيمته الافتراضية false إن لم يُفعَّله
 منشئ التطبيق صراحةً من لوحة تحكم خدمة "تحويل الموقع إلى APK". وهذا نفس الحقل بالضبط الذي
 يتحكم أيضاً بـ pickFile/readFileBase64/writeFileBase64 — أي أن أي بديل "اختيار ملف" سيُمنع
 لنفس السبب حرفياً طالما هذا الحقل معطَّل، بصرف النظر عن أي كود JS يُكتب هنا. */
function _wtafsBridgePresent(){return typeof WebToApk!=='undefined';}
function _wtafsOk(){return typeof WebToApkFS!=='undefined'&&WebToApkFS.isAvailable&&WebToApkFS.isAvailable();}
/* استفادة من ميزات تطبيق "الملفات" (My Files) الحقيقي على الجهاز: أسماء ملفات مقروءة
 للبشر — قبل هذا التعديل كانت freqdb_/nn_/session_/zero-freq-partitions-/ZeroAI_FreqDB_
 تُسمَّى كلها بطابع Unix خام (مثل freqdb_1758814593421.json)، لا يعني شيئاً عند تصفّح
 المجلد الثابت عبر تطبيق الملفات الحقيقي — على عكس ZERO_Bans_/ZeroAI_v25_ اللذين استُخدم
 لهما تاريخ ISO مقروء منذ البداية. لاحقة الميلي ثانية تحافظ على نفس ضمان التفرّد الذي كان
 يوفره Date.now() الخام (يمنع تراكب اسمين عند ضغطتين سريعتين خلال نفس الثانية). */
function _isoFname(){
 const d=new Date();
 return d.toISOString().slice(0,19).replace(/:/g,'-')+'-'+String(d.getMilliseconds()).padStart(3,'0');
}
/* استفادة إضافية من My Files/نظام أندرويد: "متطلبات التطبيق" — عرض فعلي لموارد الجهاز
 (معالج/ذاكرة/تخزين) وحجم محتويات المجلد الثابت نفسه، بالاعتماد حصراً على Web APIs مؤكَّدة
 (لا افتراض أي حقل غير موثَّق):
 - navigator.hardwareConcurrency: عدد الأنوية المنطقية (مدعوم في كل متصفحات Chromium/WebView)
 - navigator.deviceMemory: تقدير تقريبي للذاكرة بالجيجابايت (Device Memory API — Chromium فقط،
 قد لا يكون مدعوماً في كل الأجهزة، ولذلك مفحوص بـ typeof قبل الاستخدام)
 - navigator.storage.estimate(): حصة/استخدام التخزين الفعلي لأصل هذا التطبيق (StorageManager)
 - حجم المجلد الثابت: مُشتق من قراءة محتوى كل ملف فعلياً وحساب طوله بالبايت (Blob.size)، وليس
 من حقل "size" غير مؤكَّد في WebToApkFS.list() — بحدٍّ أقصى WTAFS_SIZE_SCAN_MAX ملفاً (أحدثها)
 تفادياً لبطء قراءات SAF المتكررة على جهاز حقيقي عند تراكم عشرات الملفات. */
const WTAFS_SIZE_SCAN_MAX=30;
/* "تشديد اكثر": renderWtafsResourcesInfo تحوي نقطة انتظار وحيدة (storage.estimate) وتُستدعى من
 عدة أماكن (منح/حذف/تحديث يدوي) دون انتظار (fire-and-forget) — نقرتان سريعتان متتاليتان (أو
 حذف ملف مباشرة بعد فتح اللوحة) يُطلقان نداءين متداخلين، وعلى جهاز حقيقي حيث زمن estimate()
 فعلي (I/O قرص) لا مضمون الترتيب، قد ينتهي النداء الأقدم بعد الأحدث ويكتب فوق العرض ببيانات
 قديمة (حجم/حالة مجلد سابقة). رقم جيل يُميِّز أحدث نداء بُدئ ويجعل أي نداء أقدم ينتهي متأخراً
 يتجاهل نتيجته بدل رسمها فوق الأحدث. */
let _wtafsResourcesGen=0;
async function renderWtafsResourcesInfo(){
 const el=E('wtafs-resources-text');
 if(!el)return;
 const myGen=++_wtafsResourcesGen;
 const lines=[];
 lines.push(' المعالج: '+(typeof navigator.hardwareConcurrency==='number'?navigator.hardwareConcurrency+' أنوية منطقية':'غير مُتاح في هذا البناء'));
 lines.push(' الذاكرة (تقريبي): '+(typeof navigator.deviceMemory==='number'?'~'+navigator.deviceMemory+' GB':'غير مُتاح في هذا البناء'));
 lines.push(' الاتصال: '+(navigator.onLine?'متصل':'غير متصل'));
 el.textContent=lines.join(' · ');
 if(navigator.storage&&typeof navigator.storage.estimate==='function'){
 try{
 const est=await navigator.storage.estimate();
 const usedMB=((est.usage||0)/1048576).toFixed(1);
 const quotaMB=est.quota?(est.quota/1048576).toFixed(0):null;
 lines.push(' تخزين التطبيق: '+usedMB+' م.ب'+(quotaMB?' من أصل ~'+quotaMB+' م.ب':''));
 if(myGen===_wtafsResourcesGen)el.textContent=lines.join(' · ');
 }catch(e){/* بعض الأجهزة لا تدعم estimate() فعلياً رغم وجود الدالة — تجاهل بصمت */}
 }
 if(myGen!==_wtafsResourcesGen)return; // نداء أحدث بدأ (وربما انتهى) أثناء الانتظار أعلاه — تجاهل الباقي
 if(_wtafsOk()&&WebToApkFS.hasAccess()){
 try{
 const entries=_wtafsListSafe();
 const names=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 const scanNames=names.slice(0,WTAFS_SIZE_SCAN_MAX);
 let totalBytes=0;
 // "تشديد اكثر": readText لكل ملف على حدة داخل try خاص به — ملف واحد غير قابل للقراءة
 // (حُذف خارجياً بين list() وreadText() نفسها — فجوة TOCTOU حقيقية على SAF حين يعدّل
 // تطبيق ملفات آخر المجلد بالتزامن، أو ملف تالف، أو خطأ إذن عابر) كان سيُسقِط الحساب كله
 // عبر try/catch الخارجي الوحيد، فيختفي سطر "المجلد الثابت" بالكامل بدل تجاهل ملف واحد فقط
 // فقط ضمن المجموع — نفس نمط العزل لكل عنصر المُطبَّق أصلاً في _applyCleanupPatternToEntries.
 scanNames.forEach(name=>{
 try{
 const raw=WebToApkFS.readText(name);
 if(raw)totalBytes+=new Blob([raw]).size;
 }catch(e){/* ملف واحد فاشل لا يُسقط حساب البقية */}
 });
 const totalKB=(totalBytes/1024).toFixed(1);
 const approx=names.length>scanNames.length;
 lines.push(' المجلد الثابت: '+names.length+' ملف — '+(approx?'~':'')+totalKB+' ك.ب'+(approx?' (تقدير من أحدث '+WTAFS_SIZE_SCAN_MAX+' ملفاً)':''));
 el.textContent=lines.join(' · ');
 }catch(e){/* تعذّر مسح المجلد — الأسطر الأخرى تبقى ظاهرة بلا انقطاع */}
 }
}
function updateFolderAccessUI(){
 const st=E('wtafs-status'),grantBtn=E('wtafs-grant-btn'),clearBtn=E('wtafs-clear-btn'),restoreBtn=E('wtafs-restore-btn'),
 restoreBackupBtn=E('wtafs-restore-backup-btn'),pickBackupBtn=E('wtafs-pick-backup-btn'),
 pickBtn=E('wtafs-pick-btn'),pickRow=E('wtafs-pickfile-row'),
 browserRow=E('wtafs-browser-row'),browserList=E('wtafs-file-browser-list');
 if(!st)return;
 const hasPicked=!!localStorage.getItem(_pickedFileKey());
 if(typeof WebToApkFS==='undefined'){
 // البناء لا يحتوي هذا الجسر إطلاقاً (متصفح عادي، أو خدمة مختلفة كلياً) — موارد الجهاز
 // العامة (معالج/ذاكرة/تخزين) لا تعتمد على WebToApkFS إطلاقاً، فتبقى ظاهرة رغم ذلك.
 renderWtafsResourcesInfo();
 st.textContent='هذا البناء لا يدعم الوصول لمجلد ثابت (WebToApkFS غير متاح) — يُستخدَم localStorage فقط';
 st.className='ban-exp-msg err';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBackupBtn)pickBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display='none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 return;
 }
 if(!_wtafsOk()){
 // الجسر موجود فعلياً في هذا التطبيق، لكن مُعطَّل من إعدادات البناء — هذا يفسّر بالضبط
 // عدم ظهور أي نافذة أذونات عند الضغط: الطلب لا يصل حتى لنظام أندرويد. موارد الجهاز العامة
 // تبقى ظاهرة رغم ذلك (لا علاقة لها بتعطيل WebToApkFS).
 renderWtafsResourcesInfo();
 st.textContent='الميزة موجودة في هذا التطبيق لكنها مُعطَّلة من إعدادات البناء — '+
 'فعِّل إذن "SAF Folder Access" (اسمه في الإعدادات: permSafFolderAccess) من لوحة '+
 'تحكم الخدمة التي أنشأت هذا التطبيق، ثم أعد بناء/تنزيل وتثبيت التطبيق. لن تظهر أي '+
 'نافذة اختيار مجلد أو ملف قبل ذلك مهما ضغطت — القيد من جهة إعدادات البناء لا الكود.';
 st.className='ban-exp-msg err';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBackupBtn)pickBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display='none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 return;
 }
 // استفادة من ميزة اختيار الملفات: تعمل بصرف النظر عن منح وصول المجلد الكامل من عدمه —
 // على عكس بديل "اختيار ملف ثابت" الخاص بالحظر (يظهر فقط حين لا يكون المجلد ممنوحاً بعد،
 // لأنه بديل عنه)، فهذا زر استيراد فوري لمرة واحدة لا يتعارض مع حالة المجلد إطلاقاً.
 if(pickBackupBtn)pickBackupBtn.style.display=(typeof WebToApkFS.pickFile==='function')?'':'none';
 const has=WebToApkFS.hasAccess();
 if(has){
 const uri=WebToApkFS.getAccessUri();
 st.textContent='✓ مُفعَّل — المسار: '+(uri||'(غير معروف)');
 st.className='ban-exp-msg ok';
 if(grantBtn)grantBtn.style.display='none';
 if(clearBtn)clearBtn.style.display='';
 if(restoreBtn)restoreBtn.style.display='';
 if(restoreBackupBtn)restoreBackupBtn.style.display='';
 if(pickBtn)pickBtn.style.display='none';
 if(pickRow)pickRow.style.display=hasPicked?'':'none';
 // استفادة أكبر من My Files: تصفّح فعلي لمحتويات المجلد — يظهر فقط بعد منح الوصول،
 // ويتحدَّث تلقائياً في كل مرة تُفتح فيها لوحة "الملفات" أو يتغيَّر وضع الوصول.
 if(browserRow)browserRow.style.display='';
 renderFixedFolderBrowser();
 }else{
 // لم يُمنَح الوصول بعد — لا يُستدعى renderFixedFolderBrowser() في هذا الفرع، فيُستدعى هنا
 // مباشرة كي تبقى موارد الجهاز العامة ظاهرة حتى قبل منح الوصول (سطر حجم المجلد وحده يُخفى
 // تلقائياً لعدم وجود وصول بعد — الشرط داخل renderWtafsResourcesInfo نفسها).
 renderWtafsResourcesInfo();
 st.textContent='غير مُفعَّل بعد — اضغط "منح الوصول" لاختيار مجلد ثابت مرة واحدة، أو استخدم '+
 'اختيار ملف ثابت أدناه كبديل أخفّ';
 st.className='ban-exp-msg';
 if(grantBtn)grantBtn.style.display='';
 if(clearBtn)clearBtn.style.display='none';
 if(restoreBtn)restoreBtn.style.display='none';
 if(restoreBackupBtn)restoreBackupBtn.style.display='none';
 if(pickBtn)pickBtn.style.display=(typeof WebToApkFS.pickFile==='function')?'':'none';
 if(pickRow)pickRow.style.display=(hasPicked&&typeof WebToApkFS.pickFile==='function')?'':'none';
 if(browserRow)browserRow.style.display='none';
 if(browserList)browserList.innerHTML='';
 }
}
async function requestFixedFolder(){
 if(!_wtafsOk())return;
 try{
 const r=await WebToApkFS.requestAccess();
 updateFolderAccessUI();
 if(r&&r.success){
 // مزامنة فورية: كل ما هو محفوظ حالياً (في localStorage) يُكتب أيضاً في المجلد الجديد فوراً
 PERSIST.saveBans();PERSIST.saveZones();PERSIST.saveCats();PERSIST.saveNN();PERSIST.saveFC();PERSIST.saveRoomModes();PERSIST.saveWienerNF();
 updateFolderAccessUI();
 stLog(' WebToApkFS: تم منح وصول مجلد ثابت + مزامنة فورية للبيانات الحالية');
 }else{
 stLog(' WebToApkFS: فشل/أُلغي طلب الوصول'+(r&&r.error?(' — '+r.error):''));
 }
 }catch(e){stLog(' WebToApkFS requestAccess error: '+e.message);}
}
function clearFixedFolder(){
 if(!_wtafsOk())return;
 try{WebToApkFS.clearAccess();}catch(e){}
 updateFolderAccessUI();
 stLog(' WebToApkFS: أُلغي الوصول للمجلد الثابت (localStorage يبقى نسخة احتياطية كما هو معتاد)');
}
/* تنظيف تلقائي للمجلد الثابت: كل تصدير جديد يكتب ملف ZERO_Bans_<طابع زمني>.json منفصلاً —
 دون تنظيف سيتراكم ملف جديد مع كل تصدير إلى الأبد. نُبقي فقط أحدث N نسخة ونحذف الأقدم،
 حتى لا يمتلئ مجلد المستخدم الثابت بمئات الملفات بعد أسابيع من الاستخدام اليومي. */
const WTAFS_MAX_EXPORTS_KEPT=15;
/* تشديد أكثر: نفس المنطق أعلاه بالضبط لكن مُعمَّم لأي نمط اسم — كي يُعاد استخدامه لكل نقاط
 الكتابة الجديدة التي أضافها تعميم WebToApkFS (androidWrite/saveFreqPartitions)، والتي كانت
 ستتراكم بلا حد أقصى تماماً كما كانت مشكلة ZERO_Bans_ الأصلية قبل وجود هذه الدالة إطلاقاً. */
/* تطبيق نمط واحد على قائمة ملفات جاهزة مسبقاً (بلا أي نداء list() جديد) — الأساس المشترك
 الذي تُبنى عليه كل من _cleanupFixedFolderPattern (نمط واحد، يجلب القائمة بنفسه) و
 _cleanupFixedFolderBackups (عدة أنماط، تتقاسم قائمة واحدة — انظر التعليق أدناه). */

window.udsQueryEvents=udsQueryEvents; window.udsQueryExec=udsQueryExec; window.udsQueryNNHistory=udsQueryNNHistory;
window.udsQueryPatterns=udsQueryPatterns; window.udsGetStats=udsGetStats; window.reqStoragePersist=reqStoragePersist;
window.buildSessionObj=buildSessionObj; window.saveSession=saveSession; window.loadLastWeights=loadLastWeights;
window.restoreNNFromDB=restoreNNFromDB; window.getAllSessions=getAllSessions; window.clearAllSessions=clearAllSessions;
window.refreshSessionList=refreshSessionList; window.drawSessHist=drawSessHist; window.loadSession=loadSession;
window.androidWrite=androidWrite; window.androidRead=androidRead; window.androidListFiles=androidListFiles;
window.getStoragePaths=getStoragePaths; window.saveFreqDBLocal=saveFreqDBLocal; window.saveNNLocal=saveNNLocal;
window.saveFullSessionLocal=saveFullSessionLocal; window._getBansForExport=_getBansForExport; window._showExpMsg=_showExpMsg;
window._fmtDT=_fmtDT; window._buildBansAndZonesForUnifiedBackup=_buildBansAndZonesForUnifiedBackup; window._buildBansExportContent=_buildBansExportContent;
window.exportBans=exportBans; window.shareBans=shareBans; window.copyBansToClipboard=copyBansToClipboard;
window.copyBansJSONToClipboard=copyBansJSONToClipboard; window.pasteImportFromClipboard=pasteImportFromClipboard; window._mergeImportedBansJSON=_mergeImportedBansJSON;
window.importBanFile=importBanFile; window._wtafsBridgePresent=_wtafsBridgePresent; window._wtafsOk=_wtafsOk;
window._isoFname=_isoFname; window.WTAFS_SIZE_SCAN_MAX=WTAFS_SIZE_SCAN_MAX; window._wtafsResourcesGen=_wtafsResourcesGen;
window.renderWtafsResourcesInfo=renderWtafsResourcesInfo; window.updateFolderAccessUI=updateFolderAccessUI; window.requestFixedFolder=requestFixedFolder;
window.clearFixedFolder=clearFixedFolder; window.WTAFS_MAX_EXPORTS_KEPT=WTAFS_MAX_EXPORTS_KEPT;

})();
/* ── 10-wtafs-backup-achievements.js ── */

'use strict';
(function(){

function _applyCleanupPatternToEntries(entries,pattern,maxKept){
 const files=entries.filter(e=>e&&e.name&&pattern.test(e.name)).map(e=>e.name).sort();
 if(files.length<=maxKept)return 0;
 const toDelete=files.slice(0,files.length-maxKept);
 let deleted=0;
 toDelete.forEach(name=>{try{if(WebToApkFS.delete(name))deleted++;}catch(e){}});
 return deleted;
}
function _cleanupFixedFolderPattern(pattern,maxKept){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return 0;
 try{
 return _applyCleanupPatternToEntries(_wtafsListSafe(),pattern,maxKept);
 }catch(e){return 0;}
}
function _cleanupFixedFolderExports(){
 // إصلاح خلل قديم: كانت المطابقة مقصورة على .json فقط، بينما exportBans(fmt) يكتب أيضاً
 // CSV وTXT بنفس نمط الاسم إلى نفس المجلد — فكانت تلك الصيغتان تتراكمان بلا حد أقصى
 // رغم أن هذه الدالة بالذات وُجدت لمنع بالضبط هذا النوع من التراكم.
 const deleted=_cleanupFixedFolderPattern(/^ZERO_Bans_.*\.(json|csv|txt)$/i,WTAFS_MAX_EXPORTS_KEPT);
 if(deleted)stLog(' WebToApkFS: حُذف '+deleted+' ملف تصدير قديم من المجلد الثابت (الاحتفاظ بآخر '+WTAFS_MAX_EXPORTS_KEPT+')');
}
/* تشديد أكثر — الفجوة التي أغلقتها هذه الجولة: تعميم WebToApkFS (الجولتان السابقتان) أضاف 6
 أنماط ملفات جديدة تُكتَب إلى نفس المجلد الثابت (freqdb_/nn_/session_ عبر androidWrite،
 zero-freq-partitions- عبر saveFreqPartitions، وZeroAI_v25_/ZeroAI_FreqDB_ عبر
 exportJSON/exportCSV) دون أي تنظيف مقابل — أي أنها كانت ستتراكم إلى الأبد بالضبط كخلل
 ZERO_Bans_ الأصلي الذي وُجدت _cleanupFixedFolderExports أصلاً لحله، رغم توفّر نفس المنطق
 الجاهز. تُستدعى من androidWrite() (يغطي freqdb_/nn_/session_ تلقائياً لكل مستخدميها الثلاثة)
 وsaveFreqPartitions() مباشرة — وليس من exportJSON/exportCSV لأنهما يمرّان أصلاً عبر
 androidWrite فتُغطَّيان دون استدعاء مكرر. */
/* تشديد: أنماط عامة (.*) بدل \d+ الصارمة — بعد أن صارت freqdb_/nn_/session_/
 zero-freq-partitions-/ZeroAI_FreqDB_ تستخدم طابعاً زمنياً مقروءاً (_isoFname) بدل
 Date.now() الخام، فإن \d+ لم تعد تطابق أسماء الملفات الجديدة إطلاقاً (تحتوي شرطات وT)،
 ما كان سيُعطِّل تنظيف كل الأنماط الستة صمتاً. .* تتوافق مع أي شكل تسمية حالي أو مستقبلي. */
const WTAFS_BACKUP_PATTERNS=[
 /^freqdb_.*\.json$/i,
 /^nn_.*\.json$/i,
 /^session_.*\.json$/i,
 /^zero-freq-partitions-.*\.json$/i,
 /^ZeroAI_v25_.*\.json$/i,
 /^ZeroAI_FreqDB_.*\.csv$/i,
];
/* تشديد أكثر (فوق التشديد السابق نفسه): كانت هذه الدالة تستدعي _cleanupFixedFolderPattern
 لكل نمط من الأنماط الستة على حدة، وكل استدعاء يُجري نداء WebToApkFS.list('') خاصاً به —
 أي 6 نداءات قراءة فهرس فعلية (SAF عبر ContentResolver على جهاز حقيقي، وقد تكون بطيئة
 ملموساً) في كل مرة يُحفَظ فيها أي ملف واحد فقط. تُجلَب القائمة الآن مرة واحدة وتُطبَّق
 الأنماط الستة عليها محلياً بلا أي نداء إضافي — نفس نتيجة التنظيف تماماً بسدس عدد نداءات
 الفهرسة. */
function _cleanupFixedFolderBackups(){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return;
 let entries;
 try{entries=_wtafsListSafe();}catch(e){return;}
 let total=0;
 WTAFS_BACKUP_PATTERNS.forEach(p=>{total+=_applyCleanupPatternToEntries(entries,p,WTAFS_MAX_EXPORTS_KEPT);});
 if(total)stLog(' WebToApkFS: حُذف '+total+' ملف نسخة احتياطية قديم من المجلد الثابت (الاحتفاظ بآخر '+WTAFS_MAX_EXPORTS_KEPT+' لكل نوع)');
}
function importFromFixedFolder(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 // أحدث ملف تصدير JSON — اسمه يحمل طابعاً زمنياً ISO فالترتيب الأبجدي = الترتيب الزمني
 const jsonFiles=entries.filter(e=>e&&e.name&&/^ZERO_Bans_.*\.json$/i.test(e.name)).map(e=>e.name).sort();
 if(!jsonFiles.length){report(' لا يوجد ملف تصدير JSON داخل المجلد بعد','err');return;}
 const latest=jsonFiles[jsonFiles.length-1];
 const raw=WebToApkFS.readText(latest);
 if(!raw){report(' تعذّرت قراءة: '+latest,'err');return;}
 const res=_mergeImportedBansJSON(raw,latest);
 report('✓ استُورد من '+latest+': '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}

/* ── تحويل نصّ↔base64 صحيح مع دعم كامل للعربية (UTF-8) — يُستخدَم مع writeAll/readAll
 في WebToApkFS، التي تتعامل مع البايتات فقط. ── */
function _b64FromText(str){
 const bytes=new TextEncoder().encode(str);
 let bin='';
 for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));
 return btoa(bin);
}
function _textFromB64(b64){
 const bin=atob(b64);
 const bytes=new Uint8Array(bin.length);
 for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
 return new TextDecoder().decode(bytes);
}

/* ── بديل أخفّ من مجلد كامل: اختيار ملف JSON واحد ثابت (WebToApkFS.pickFile) وتذكّره —
 بدل تصدير ملف جديد كل مرة، يُعاد كتابة نفس الملف المُختار في كل تصدير لاحق تلقائياً.
 تشديد: هذا الزر مبني على نفس آلية pickFile المحكومة بنفس إذن البناء الذي يحكم مجلد
 الوصول الثابت بالضبط (permSafFolderAccess) — إن ظهر زرّ هذا يعني الإذن مُفعَّل فعلاً. ── */
function _pickedFileKey(){return 'zero_wtafs_pickedfile_uri';}
async function pickFixedFile(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||typeof WebToApkFS.pickFile!=='function'){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=await WebToApkFS.pickFile('application/json');
 if(!r||!r.ok){report(' لم يُختر ملف'+(r&&r.error?(' — '+r.error):''),'err');return;}
 const uri=r.uri||r.fileUri||r.documentUri||r.path;
 if(!uri){report(' لم يصل مسار الملف من النظام (استجابة غير متوقعة)','err');return;}
 localStorage.setItem(_pickedFileKey(),uri);
 // كتابة فورية للحالة الحالية في الملف المختار — حتى يبدأ الملف مفيداً من أول لحظة
 const built=_buildBansExportContent('json')||{content:JSON.stringify({version:'ZERO AI v25',bans:[],interference:[]},null,2)};
 const w=WebToApkFS.writeAll(uri,_b64FromText(built.content));
 // تحديث الأزرار/الصف أولاً، ثم رسالة النجاح/الفشل أخيراً — updateFolderAccessUI() تكتب
 // رسالة حالة عامة في نفس العنصر، فيجب ألا تُطمِس رسالة النتيجة الفعلية لهذا الإجراء.
 updateFolderAccessUI();
 if(w&&w.ok)report('✓ تم اختيار الملف وحفظ الحالة الحالية فيه — سيُحدَّث تلقائياً مع كل تصدير لاحق','ok');
 else report(' اختير الملف لكن فشلت الكتابة الأولى: '+(w&&w.error||'خطأ غير معروف'),'err');
 }catch(e){
 if(e&&e.name==='AbortError')return;
 report(' خطأ: '+e.message,'err');
 }
}
function importFromPickedFile(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 const uri=localStorage.getItem(_pickedFileKey());
 if(!uri){report(' لم يُختَر ملف ثابت بعد','err');return;}
 if(!_wtafsOk()){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=WebToApkFS.readAll(uri);
 if(!r||!r.ok){report(' تعذّرت قراءة الملف المختار: '+(r&&r.error||'خطأ غير معروف'),'err');return;}
 const res=_mergeImportedBansJSON(_textFromB64(r.base64),'الملف الثابت المختار');
 report('✓ استُورد من الملف الثابت: '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}
function forgetPickedFile(){
 try{
 if(_wtafsOk()){
 const uri=localStorage.getItem(_pickedFileKey());
 if(uri&&typeof WebToApkFS.releaseFile==='function'){try{WebToApkFS.releaseFile(uri);}catch(e){}}
 }
 }catch(e){}
 localStorage.removeItem(_pickedFileKey());
 updateFolderAccessUI();
 stLog('✖ WebToApkFS: نُسي الملف الثابت المختار');
}

/* تعميم: قبل هذا التعديل كانت هاتان الدالتان تنزيلاً خاماً عبر المتصفح فقط، بلا أي مرور
 عبر WebToApkFS/ZeroAndroid إطلاقاً — الآن تمران عبر androidWrite() المُعمَّمة أعلاه، فتصلان
 تلقائياً لنفس المجلد الثابت الذي منح المستخدم الوصول إليه (إن وُجد)، قبل اللجوء لتنزيل
 المتصفح كخطوة أخيرة فقط. */
function exportJSON(){
 // "توحيد الكل في ملف واحد": الحظر ومناطق التداخل كانا غائبين كلياً عن هذه "النسخة الاحتياطية
 // الكاملة" رغم اسمها — فاستعادتها وحدها (كما يفعل importFullBackupFromFixedFolder/
 // pickAndRestoreFullBackup) كانت تُعيد NN+FreqDB لكن تفقد كل الترددات المحظورة ومناطق
 // التداخل المكتسبة، ما يجبر المستخدم على الاحتفاظ بملفي ZERO_Bans_+ZeroAI_v25_ معاً لاستعادة
 // كامل حالته. الآن هذا الملف الواحد يكفي وحده.
 const {bans,interference}=_buildBansAndZonesForUnifiedBackup();
 // مراجعة "النسخة النهائية": نفس فجوة "توحيد الكل" السابقة تكررت لثلاث حالات حفظ أُضيفت لاحقاً
 // (PERSIST.saveCats/saveRoomModes/saveWienerNF) — تصل جميعها إلى المجلد الثابت كملفات منفصلة
 // لكنها كانت غائبة تماماً عن "النسخة الاحتياطية الكاملة" الموحَّدة، فاستعادة هذا الملف وحده
 // كانت تُعيد NN+FreqDB+الحظر لكن تُصفِّر فئات الحظر المُفعَّلة افتراضياً وتُفقِد بصمة وضع
 // الغرفة ونموذج ضجيج Wiener المُتعلَّمَين. تُضاف الآن بنفس الشرط الذي تستخدمه saveRoomModes/
 // saveWienerNF أنفسهما (لا تُصدَّر إن كانت فارغة أصلاً).
 const cats={};Object.keys(PERM_BAN_CATS).forEach(k=>{cats[k]=PERM_BAN_CATS[k].enabled;});
 const roomModes=(ROOM_MODES.peaks&&ROOM_MODES.peaks.length)?{peaks:ROOM_MODES.peaks.slice(0,6),dominant:ROOM_MODES.dominant}:null;
 const wienerNF=(typeof appState.nFloor!=='undefined'&&appState.nFloor&&appState.nFloor.length)?{nf:Array.from(appState.nFloor.slice(0,128)),alpha:P.alpha,beta:P.beta}:null;
 const data={
 meta:{type:'ZeroAI_v25_Export',date:new Date().toISOString(),cycles:appState.aiCyc,bestSilence:appState.bestSil,version:'v25'},
 freqDB:freqFile.entries.slice(0,200),classDistrib:{...FC},
 nnState:{trainN:NN.trainN,loss:NN.loss},
 nnWeights:NN.w1?{w1:[...NN.w1],b1:[...NN.b1],w2:[...NN.w2],b2:[...NN.b2]}:null,
 achievements:[...earnedAch],
 bgStats:{runs:typeof bgRuns!=='undefined'?bgRuns:0,ms:typeof bgTotalMs!=='undefined'?bgTotalMs:0},
 bans,interference,cats,roomModes,wienerNF
 };
 const json=JSON.stringify(data,null,2);
 const fname='ZeroAI_v25_'+new Date().toISOString().slice(0,19).replace(/:/g,'-')+'.json';
 if(!androidWrite('export',fname,json)){
 const blob=new Blob([json],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);
 a.download=fname;a.click();
 stLog(' Exported JSON: '+Math.round(blob.size/1024)+'KB');
 }
}

function exportCSV(){
 if(!freqFile.entries.length){stLog(' No FreqDB to export');return;}
 const header='hz,count,energy,confirmed,cancelled,class,invOk';
 const rows=freqFile.entries.slice(0,500).map(e=>[e.hz,e.count,e.energy.toFixed(4),e.confirmed,e.cancelled,e.class||0,e.invOk||false].join(','));
 const csv=header+'\n'+rows.join('\n');
 const fname='ZeroAI_FreqDB_'+_isoFname()+'.csv';
 if(!androidWrite('export',fname,csv)){
 const blob=new Blob([csv],{type:'text/csv'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);
 a.download=fname;a.click();
 stLog(' Exported CSV: '+rows.length+' frequencies');
 }
}

/* تعميم: منطق استعادة مشترك للنسخة الاحتياطية الكاملة (NN + FreqDB + الإنجازات) — يستخدمه
 كل من importJSON (اختيار ملف عبر متصفح النظام) وimportFullBackupFromFixedFolder (قراءة
 مباشرة من المجلد الثابت عبر WebToApkFS، بعد أن صار exportJSON يكتب نسخة إليه تلقائياً)،
 بنفس نمط _mergeImportedBansJSON المُستخدَم مسبقاً لملفات الحظر. */
function _restoreFullBackupJSON(raw,sourceLabel){
 const data=JSON.parse(raw);
 // Restore NN
 if(data.nnWeights&&data.nnWeights.w1){
 if(!NN.w1)nnInit();
 NN.w1=[...data.nnWeights.w1];NN.b1=[...data.nnWeights.b1];
 NN.w2=[...data.nnWeights.w2];NN.b2=[...data.nnWeights.b2];
 NN.trainN=data.nnState?.trainN||0;
 stLog(' NN weights imported · trained='+NN.trainN);
 }
 // Restore FreqDB
 if(data.freqDB&&data.freqDB.length){
 freqDB.clear();
 data.freqDB.forEach(e=>freqDB.set(e.hz,{...e,firstSeen:Date.now(),lastSeen:Date.now()}));
 freqFile.totalCap=data.freqDB.length;
 freqFile.totalConf=data.freqDB.filter(e=>e.confirmed).length;
 freqFile.totalCanc=data.freqDB.filter(e=>e.cancelled).length;
 writeFreqFile();stLog(' FreqDB imported: '+freqDB.size+' frequencies');
 }
 // Restore achievements
 if(data.achievements)data.achievements.forEach(id=>earnedAch.add(id));
 // مراجعة "النسخة النهائية": classDistrib (FC) كانت تُصدَّر في exportJSON منذ البداية لكن لم
 // تُستعَد هنا إطلاقاً — الملف يحمل البيانات لكن الاستعادة تُهملها بصمت. نفس منطق loadFC
 // الإضافي بالضبط (تراكمي لا استبدال، لأن FC عدّادات تراكمية عبر الزمن).
 if(data.classDistrib&&typeof data.classDistrib==='object'){
 Object.keys(data.classDistrib).forEach(k=>{if(k in FC)FC[k]+=data.classDistrib[k]||0;});
 }
 // مراجعة "النسخة النهائية": نفس فجوة "الغائب عن النسخة الموحَّدة" لثلاث حالات حفظ أُضيفت لاحقاً
 // (cats/roomModes/wienerNF) — بنفس منطق loadCats/loadRoomModes/loadWienerNF أنفسهما بالضبط،
 // كي لا يختلف سلوك الاستعادة الموحَّدة عن استعادتها من ملفاتها المنفصلة.
 if(data.cats&&typeof data.cats==='object'){
 Object.keys(data.cats).forEach(k=>{if(PERM_BAN_CATS[k])PERM_BAN_CATS[k].enabled=data.cats[k];});
 }
 if(data.roomModes&&Array.isArray(data.roomModes.peaks)&&data.roomModes.peaks.length&&!ROOM_MODES.peaks.length){
 ROOM_MODES.peaks=data.roomModes.peaks;ROOM_MODES.dominant=data.roomModes.dominant||0;
 }
 if(data.wienerNF&&Array.isArray(data.wienerNF.nf)&&data.wienerNF.nf.length){
 if(!appState.nFloor||appState.nFloor.length!==data.wienerNF.nf.length)appState.nFloor=new Float32Array(data.wienerNF.nf.length);
 data.wienerNF.nf.forEach((v,i)=>{appState.nFloor[i]=v;});
 if(data.wienerNF.alpha)P.alpha=Math.max(0.8,Math.min(3.5,data.wienerNF.alpha));
 }
 // "توحيد الكل في ملف واحد": استعادة الحظر ومناطق التداخل أيضاً من نفس هذا الملف الواحد، إن
 // كانا موجودَين فيه (نسخ أنشأها exportJSON بعد هذا التحديث) — بإعادة استخدام نفس منطق دمج
 // ملفات ZERO_Bans_ المنفصلة (_mergeImportedBansJSON) مُطبَّقاً على raw نفسها (يحوي bans/
 // interference في مستواه الأعلى بجانب nnWeights/freqDB بالضبط بنفس الشكل). ملفات أقدم أو
 // نسخ استُعيدت من ملف بلا هذين الحقلين (Array.isArray فحص) تُستثنى تلقائياً — لا كسر للتوافق
 // العكسي مع أي نسخة احتياطية سابقة على هذا التحديث.
 let bansRes=null;
 if(Array.isArray(data.bans)){
 try{bansRes=_mergeImportedBansJSON(raw,sourceLabel);}
 catch(e){stLog(' تعذّرت استعادة الحظر من النسخة الموحَّدة: '+e.message);}
 }
 // تشديد: ملف JSON مستورَد (خصوصاً من نسخة أقدم قبل إصلاح خلل NaN/0Hz، أو مُعدَّل يدوياً)
 // قد يحمل إدخالات FreqDB بتردد فاسد — تُنظَّف فوراً قبل عرضها في الواجهة
 _purgeInvalidFrequencies('بعد استيراد JSON'+(sourceLabel?' — '+sourceLabel:''));
 updateFilesUI();
 const bansLine=bansRes?('الحظر: +'+bansRes.added+' · مناطق التداخل: +'+bansRes.zonesAdded):null;
 logExec({prog:'SYS',lines:['Import Successful ✓','NN: trained='+NN.trainN+' · FreqDB: '+freqDB.size+' freqs',...(bansLine?[bansLine]:[]),'NN weights and FreqDB restored — continue from previous session'],ms:0,auto:true});
 return {trainN:NN.trainN,freqDBSize:freqDB.size,bansAdded:bansRes?bansRes.added:0,zonesAdded:bansRes?bansRes.zonesAdded:0};
}
/* "توحيد الكل في ملف واحد": لاحقة موحَّدة لرسائل نجاح استعادة النسخة الكاملة الثلاث
 (importFullBackupFromFixedFolder/pickAndRestoreFullBackup/importFixedFolderFile) — تُضيف
 عدد الترددات المحظورة ومناطق التداخل المُستعادة حين تكون موجودة فعلاً في الملف (نسخ ما بعد
 هذا التحديث)، وتبقى فارغة بصمت لنسخ أقدم لا تحمل هذين الحقلين إطلاقاً. */
function _fmtBansZonesSuffix(res){
 if(!res||(!res.bansAdded&&!res.zonesAdded))return'';
 return ' + '+res.bansAdded+' حظر + '+res.zonesAdded+' تداخل';
}
function importJSON(file){
 if(!file)return;
 const r=new FileReader();
 r.onload=e=>{
 try{_restoreFullBackupJSON(e.target.result);}
 catch(err){stLog(' Import error: '+err.message);}
 };
 r.readAsText(file);
}
/* استيراد آخر نسخة احتياطية كاملة (JSON الذي يكتبه exportJSON تلقائياً) مباشرة من المجلد
 الثابت — نفس فكرة importFromFixedFolder الخاصة بالحظر، لكن للنسخة الكاملة (NN+FreqDB). */
function importFullBackupFromFixedFolder(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 // اسم الملف يحمل طابعاً زمنياً ISO فالترتيب الأبجدي = الترتيب الزمني (نفس منطق بحث الحظر)
 const jsonFiles=entries.filter(e=>e&&e.name&&/^ZeroAI_v25_.*\.json$/i.test(e.name)).map(e=>e.name).sort();
 if(!jsonFiles.length){report(' لا يوجد ملف نسخة احتياطية كاملة داخل المجلد بعد — اضغط JSON في تبويب "الملفات" (Tab 7) أولاً لإنشاء واحدة','err');return;}
 const latest=jsonFiles[jsonFiles.length-1];
 const raw=WebToApkFS.readText(latest);
 if(!raw){report(' تعذّرت قراءة: '+latest,'err');return;}
 const res=_restoreFullBackupJSON(raw,latest);
 report('✓ استُعيدت نسخة احتياطية من '+latest+': NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }catch(e){report(' خطأ: '+e.message,'err');}
}
/* استفادة إضافية من ميزات تطبيق "الملفات" (My Files) على أندرويد: اختيار ملف نسخة احتياطية
 واحد من أي مكان يعرضه نظام الملفات (المجلد الثابت نفسه، Downloads، تخزين سحابي مُزامَن،
 ملف وصل عبر مشاركة من جهاز آخر...) — بخلاف importFullBackupFromFixedFolder أعلاه، هذا لا
 يتطلب منح وصول لمجلد كامل مسبقاً إطلاقاً؛ يستخدم فقط WebToApkFS.pickFile نفسها التي يعتمد
 عليها بديل "اختيار ملف ثابت" الخاص بالحظر، لكن كعملية استيراد فورية لمرة واحدة (بلا حاجة
 لتذكّر الملف لاحقاً، فالاستعادة تُنفَّذ فوراً عند الاختيار). */
async function pickAndRestoreFullBackup(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||typeof WebToApkFS.pickFile!=='function'){report(' اختيار الملفات غير متاح في هذا البناء','err');return;}
 try{
 const r=await WebToApkFS.pickFile('application/json');
 if(!r||!r.ok){report(' لم يُختر ملف'+(r&&r.error?(' — '+r.error):''),'err');return;}
 const uri=r.uri||r.fileUri||r.documentUri||r.path;
 if(!uri){report(' لم يصل مسار الملف من النظام (استجابة غير متوقعة)','err');return;}
 const read=WebToApkFS.readAll(uri);
 // عملية لمرة واحدة فقط — لا حاجة لصلاحية دائمة على هذا الملف بعد قراءته، بعكس الملف
 // الثابت المختار للحظر (يُعاد كتابته مع كل تصدير لاحق فيحتاج صلاحية باقية)
 if(typeof WebToApkFS.releaseFile==='function'){try{WebToApkFS.releaseFile(uri);}catch(e){}}
 if(!read||!read.ok){report(' تعذّرت قراءة الملف المختار: '+(read&&read.error||'خطأ غير معروف'),'err');return;}
 const res=_restoreFullBackupJSON(_textFromB64(read.base64),'ملف مُختار عبر الملفات');
 report('✓ استُعيدت نسخة احتياطية من الملف المختار: NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق نافذة الاختيار — ليس خطأ
 report(' خطأ: '+e.message,'err');
 }
}

/* ── استفادة أكبر من مميزات "الملفات" (My Files): تصفّح فعلي لمحتويات المجلد الثابت من
 داخل التطبيق — WebToApkFS.list('') نفسها المُستخدَمة داخلياً للتنظيف/البحث عن آخر نسخة،
 لكن مُعروضة الآن مباشرة للمستخدم كقائمة قابلة للاستيراد والحذف لكل ملف بمفرده، دون الحاجة
 للخروج إلى تطبيق ملفات منفصل. نعتمد فقط على e.name (الحقل الوحيد المؤكَّد من الجسر
 الحقيقي عبر كل الاستخدامات السابقة في هذا الملف) — لا افتراض لأي حقل آخر غير مؤكَّد مثل
 الحجم أو تاريخ التعديل، والتاريخ الحقيقي يُستخرَج من الاسم نفسه (مقروء منذ آخر تعديل). ── */
const WTAFS_FILE_KINDS=[
 {re:/^ZERO_Bans_.*\.json$/i,label:' حظر (JSON)',importable:true},
 {re:/^ZERO_Bans_.*\.csv$/i, label:' حظر (CSV)', importable:false},
 {re:/^ZERO_Bans_.*\.txt$/i, label:' حظر (TXT)', importable:false},
 {re:/^ZeroAI_v25_.*\.json$/i,label:' نسخة احتياطية كاملة',importable:true},
 {re:/^freqdb_.*\.json$/i, label:' FreqDB', importable:false},
 {re:/^nn_.*\.json$/i, label:' أوزان NN', importable:false},
 {re:/^session_.*\.json$/i, label:' جلسة', importable:false},
 {re:/^zero-freq-partitions-.*\.json$/i,label:' تقسيمات',importable:false},
 {re:/^ZeroAI_FreqDB_.*\.csv$/i,label:' FreqDB (CSV)',importable:false},
 {re:/^ZeroAI_Scenes\.json$/i,label:' مشاهد محفوظة',importable:true},
];
function _classifyFixedFolderFile(name){
 return WTAFS_FILE_KINDS.find(k=>k.re.test(name))||{label:' ملف',importable:false};
}
/* "استفد اكثر من الأذونات التي يقدمها my files": حتى الآن، إذن SAF المحفوظ (persistable URI
 permission) يُعامَل كأنه إما "ممنوح" أو "غير ممنوح" فقط — عبر hasAccess() المُخزَّنة على
 الجانب الأصلي (native) — بلا أي تحقق فعلي من أن الإذن ما زال صالحاً حقاً عند الاستخدام. لكن
 هذا الإذن يمكن أن يُبطَل من خارج التطبيق تماماً بعد منحه: المستخدم يحذف المجلد نفسه (عبر
 تطبيق ملفات حقيقي)، يُلغي الإذن يدوياً من إعدادات أندرويد (Settings→Apps→Permissions)، أو
 تُزال بطاقة SD الخارجية التي كان عليها المجلد. في كل هذه الحالات hasAccess() تستمر بإرجاع
 true (القيمة مخزَّنة، لا مُتحقَّق منها حياً) بينما كل عملية فعلية (list/write/read) تفشل —
 وبلا هذه الدالة، كانت الواجهة تعرض "✓ مُفعَّل" مُعطَّلاً للأبد بصمت، وكل حفظ لاحق (عبر
 androidWrite) يتراجع بصمت لتخزين المتصفح دون أن يعرف المستخدم أن مجلده الثابت "المُفعَّل"
 ظاهرياً لم يعد يعمل إطلاقاً — فيظن بياناته محفوظة هناك بينما هي ليست كذلك. الإصلاح: فشل
 list('') تحديداً (لا فشل ملف واحد داخل القائمة — ذاك له مرونة منفصلة أصلاً في
 shareAllFixedFolderFiles/renderWtafsResourcesInfo) هو إشارة قوية ومحدَّدة على أن الإذن
 المحفوظ نفسه أصبح غير صالح، لا مجرد خلل عابر بملف واحد. عندها: نُصفِّر الحالة المحفوظة
 (clearAccess) كي تعكس الواجهة الحقيقة فوراً وتعرض زر "منح الوصول" من جديد بدل حالة معطوبة
 دائمة، ونُبلِغ المستخدم بوضوح بالسبب المحتمل. */
function _wtafsHandleBrokenGrant(e){
 try{if(typeof WebToApkFS!=='undefined'&&typeof WebToApkFS.clearAccess==='function')WebToApkFS.clearAccess();}catch(e2){}
 // تحديث الواجهة كاملةً أولاً (يُخفي زر "مسح"، يُظهر "منح الوصول"، يُفرِغ قائمة الملفات...) —
 // ثم تُستبدَل رسالة "غير مُفعَّل بعد" العامة برسالة محدَّدة تشرح أن هذا انقطاع حقيقي لإذن كان
 // ممنوحاً، لا أول استخدام، كي يفهم المستخدم أن بياناته السابقة لم تُفقد بل الوصول فقط يحتاج
 // تجديداً — تظهر في سطر الحالة نفسه (لا في السجل الطرفي وحده) لأنها أهم من أن تُفوَّت.
 updateFolderAccessUI();
 const msg='تعذّر الوصول للمجلد الثابت المحفوظ سابقاً (قد يكون حُذف المجلد، أو أُلغي إذنه من '+
 'إعدادات أندرويد، أو أُزيلت بطاقة التخزين) — اضغط "منح الوصول" لاختيار مجلد من جديد'+
 (e&&e.message?(' — التفاصيل: '+e.message):'');
 const st=E('wtafs-status');
 if(st){st.textContent=msg;st.className='ban-exp-msg err';}
 stLog(msg);
}
/* مراجعة "النسخة النهائية": _wtafsHandleBrokenGrant كانت موصولة بنقطة نداء WebToApkFS.list('')
 واحدة فقط (داخل renderFixedFolderBrowser) من أصل 7 نقاط نداء مماثلة في هذا الملف — فبقيّة
 النقاط (تنظيف النسخ القديمة عند كل حفظ عبر androidWrite، الاستيراد اليدوي للحظر/النسخة
 الكاملة، المشاركة الجماعية) كانت تبتلع فشل إذن مُبطَل تماماً بصمت أو برسالة خطأ عامة، بلا أي
 استعادة فعلية لحالة "غير مُفعَّل" — أخطرها _cleanupFixedFolderBackups لأنها تعمل في الخلفية
 مع كل حفظ عادي، لا فقط عند فتح لوحة الملفات. غلاف موحَّد واحد يضمن اتساق هذا السلوك من كل
 نقطة نداء: يُعالِج كسر الإذن أولاً ثم يُعيد رمي نفس الاستثناء كي يستمر منطق catch الخاص بكل
 مستدعٍ (رسالة خطأ، قيمة افتراضية، إلخ) كما كان تماماً دون أي تغيير في سلوكه الظاهر. */
function _wtafsListSafe(subdir){
 try{return WebToApkFS.list(subdir||'')||[];}
 catch(e){_wtafsHandleBrokenGrant(e);throw e;}
}
function renderFixedFolderBrowser(){
 const list=E('wtafs-file-browser-list'),countEl=E('wtafs-file-count'),shareAllBtn=E('wtafs-share-all-btn');
 if(!list)return;
 // تُستدعى هنا (لا في updateFolderAccessUI) كي يتحدَّث سطر "حجم المجلد الثابت" مع كل تحديث
 // فعلي لقائمة الملفات — بعد منح/حذف/ضغط زر " تحديث" — دون تكرار الاستدعاء مرتين لكل حدث.
 renderWtafsResourcesInfo();
 const canShare=typeof navigator.share==='function';
 if(shareAllBtn)shareAllBtn.style.display=canShare?'':'none';
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){list.innerHTML='';if(countEl)countEl.textContent='';return;}
 let entries;
 try{entries=_wtafsListSafe();}
 catch(e){return;} // _wtafsListSafe عالجت كسر الإذن بالفعل قبل إعادة الرمي
 // e.isDirectory قد لا يكون مدعوماً في كل الأجهزة — فحص وقائي بلا أثر إن لم يكن موجوداً
 const allFiles=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 if(countEl)countEl.textContent='('+allFiles.length+' ملف)';
 const files=allFiles.slice(0,50);
 if(!files.length){list.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">المجلد فارغ حتى الآن</div>';return;}
 list.innerHTML=files.map(name=>{
 const kind=_classifyFixedFolderFile(name);
 // "تشديد اكثر": أسماء الملفات هنا تأتي من WebToApkFS.list() على مجلد فعلي يختاره المستخدم
 // — قد يحوي ملفات وضعها تطبيق آخر أو أُعيدت تسميتها عبر تطبيق ملفات حقيقي بأي محارف، وليس
 // فقط ملفات أنشأها هذا التطبيق بأسمائه المتوقَّعة. كان الاسم يُدرَج خاماً في title="${name}"
 // وفي نص التسمية عبر innerHTML، فاسم ملف يحوي " كان يخرج من سمة title ويحقن سمة HTML جديدة
 // (مثل onmouseover=...)، واسم يحوي<img ...>كان يُنشئ عنصر DOM فعلياً — حقن HTML/سمات حقيقي
 // عبر اسم ملف واحد فقط. escH() (تُستخدَم أصلاً لنفس الغرض مع نصوص مستوردة كسبب الحظر) تُغلق
 // هذه الثغرة لكلٍّ من سمة title ونص التسمية. أما وسيطة onclick فتحتاج الدرجتين معاً بالترتيب:
 // إفلات JS أولاً (يحمي بنية سلسلة JS النصية من ' واسم يحوي \)، ثم escH فوقها (يحمي حدود سمة
 // onclick="..." نفسها من " الخام) — الدرجتان لا تتعارضان لأن كلاً منهما يستهدف محارف مختلفة.
 const jsSafe=name.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
 const safe=escH(jsSafe);
 const nameH=escH(name);
 // هذه الأزرار الثلاثة (استيراد/مشاركة/حذف) كانت أيقونات ملوَّنة بلا أي نص مرافق —
 // الحالة الوحيدة في هذا الملف حيث حذف الرمز التصويري وحده كان سيُفرِغ الزر بصرياً
 // بالكامل (رغم بقاء onclick/title فعّالين). استُبدلت (28 سبتمبر 2026) بحروف نصية
 // مختصرة بسيطة أحادية اللون بدل حذفها كلياً، فيبقى تمييز الأزرار البصري قائماً.
 const importBtn=kind.importable?`<span style="color:rgba(215,215,215,.9);cursor:pointer;padding:0 5px;font-family:var(--fm);font-size:10px;font-weight:700" onclick="importFixedFolderFile('${safe}')" title="استيراد">IN</span>`:'';
 // مشاركة فردية — نفس navigator.share المُستخدَم أصلاً لمشاركة الحظر، مُعمَّم هنا على أي
 // ملف داخل المجلد الثابت (بدل الاقتصار على الحظر فقط).
 const shareBtn=canShare?`<span style="color:rgba(149,149,149,.85);cursor:pointer;padding:0 5px;font-family:var(--fm);font-size:10px;font-weight:700" onclick="shareFixedFolderFile('${safe}')" title="مشاركة">↑</span>`:'';
 return `<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04)">
 <span style="font-family:var(--fm);font-size:8px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;margin-inline-end:6px" title="${nameH}">${kind.label} — ${nameH}</span>
 <span style="display:flex;align-items:center;flex-shrink:0">${importBtn}${shareBtn}<span style="color:rgba(160,160,160,.85);cursor:pointer;padding:0 5px" onclick="deleteFixedFolderFile('${safe}')" title="حذف">✕</span></span>
 </div>`;
 }).join('');
}
/* استفادة إضافية: تحديد نوع MIME من امتداد الاسم — يُستخدَم عند بناء File للمشاركة، لأن
 navigator.share/File يتطلبان نوعاً صريحاً كي تتعرَّف تطبيقات الاستقبال (بريد/واتساب/محرّر
 نصوص...) على الملف بشكل صحيح بدل معاملته كبيانات ثنائية غامضة. */
function _mimeForFile(name){
 if(/\.json$/i.test(name))return'application/json';
 if(/\.csv$/i.test(name))return'text/csv';
 if(/\.txt$/i.test(name))return'text/plain';
 return'application/octet-stream';
}
/* مشاركة ملف واحد من المجلد الثابت عبر شاشة المشاركة الأصلية لأندرويد — تعميم مباشر لنفس
 آلية shareBans، لكن لأي ملف موجود فعلياً في المجلد بدل الاقتصار على تصدير حظر جديد. */
async function shareFixedFolderFile(name){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(typeof navigator.share!=='function'){report(' المشاركة الأصلية غير مدعومة في هذا البناء','err');return;}
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const raw=WebToApkFS.readText(name);
 if(!raw){report(' تعذّرت قراءة: '+name,'err');return;}
 const file=new File([raw],name,{type:_mimeForFile(name)});
 const shareData={files:[file],title:'ZERO AI v25 — '+name};
 if(navigator.canShare&&!navigator.canShare(shareData)){report(' مشاركة هذا الملف غير مدعومة هنا','err');return;}
 await navigator.share(shareData);
 report('✓ فُتحت شاشة المشاركة: '+name,'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return; // المستخدم أغلق شاشة المشاركة — ليس خطأ
 report(' فشلت المشاركة: '+e.message,'err');
 }
}
/* مشاركة كل ملفات المجلد الثابت دفعة واحدة (حتى سقف معقول) — Web Share API (المستوى 2)
 يدعم مصفوفة files متعددة أصلاً، وهذا هو نفس المسار المؤكَّد الذي يستخدمه shareBans، فقط
 بعدة ملفات بدل ملف واحد. السقف يحمي من تجاوز حدود نقل البيانات بين العمليات على أندرويد
 (Binder transaction) إن كان المجلد يحوي عشرات الملفات المتراكمة. */
const WTAFS_SHARE_ALL_MAX=20;
async function shareAllFixedFolderFiles(){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(typeof navigator.share!=='function'){report(' المشاركة الأصلية غير مدعومة في هذا البناء','err');return;}
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const entries=_wtafsListSafe();
 const names=entries.filter(e=>e&&e.name&&!e.isDirectory).map(e=>e.name).sort().reverse();
 if(!names.length){report(' المجلد فارغ — لا يوجد ما يُشارَك','err');return;}
 const picked=names.slice(0,WTAFS_SHARE_ALL_MAX);
 const files=[];
 let failedCount=0;
 // "تشديد اكثر": readText لكل ملف على حدة داخل try خاص به — من دون هذا، ملف واحد غير قابل
 // للقراءة (حُذف خارجياً بين list() وreadText، أو تالف، أو خطأ إذن عابر) كان يُسقِط استثناءً
 // يخرج من forEach فيُلغي مشاركة كل الملفات العشرين دفعة واحدة عبر catch الخارجي، رغم أن
 // البقية سليمة تماماً وقابلة للمشاركة. الآن يُتخطَّى الملف الفاشل فقط وتُشارَك البقية،
 // مع إعلام المستخدم بعددها إن وُجد.
 picked.forEach(name=>{
 try{
 const raw=WebToApkFS.readText(name);
 if(raw)files.push(new File([raw],name,{type:_mimeForFile(name)}));
 else failedCount++;
 }catch(e){failedCount++;}
 });
 if(!files.length){report(' تعذّرت قراءة أي ملف للمشاركة','err');return;}
 const shareData={files,title:'ZERO AI v25 — نسخ احتياطية ('+files.length+' ملف)'};
 if(navigator.canShare&&!navigator.canShare(shareData)){
 report(' مشاركة عدة ملفات معاً غير مدعومة هنا — جرّب مشاركة كل ملف بمفرده','err');
 return;
 }
 await navigator.share(shareData);
 const notes=[];
 if(names.length>picked.length)notes.push('أحدث '+WTAFS_SHARE_ALL_MAX+' فقط من '+names.length);
 if(failedCount)notes.push('تعذّرت قراءة '+failedCount+' منها فاستُبعِدت');
 report('✓ فُتحت شاشة المشاركة: '+files.length+' ملف'+(notes.length?' ('+notes.join(' — ')+')':''),'ok');
 }catch(e){
 if(e&&e.name==='AbortError')return;
 report(' فشلت المشاركة: '+e.message,'err');
 }
}
async function importFixedFolderFile(name){
 const st=E('wtafs-status');
 const report=(msg,type)=>{if(st){st.textContent=msg;st.className='ban-exp-msg '+(type||'');}};
 if(!_wtafsOk()||!WebToApkFS.hasAccess()){report(' يجب منح الوصول للمجلد أولاً','err');return;}
 try{
 const raw=WebToApkFS.readText(name);
 if(!raw){report(' تعذّرت قراءة: '+name,'err');return;}
 if(/^ZERO_Bans_.*\.json$/i.test(name)){
 const res=_mergeImportedBansJSON(raw,name);
 report('✓ استُورد من '+name+': '+res.added+' تردد جديد'+(res.zonesAdded?' + '+res.zonesAdded+' منطقة تداخل':''),'ok');
 }else if(/^ZeroAI_v25_.*\.json$/i.test(name)){
 const res=_restoreFullBackupJSON(raw,name);
 report('✓ استُعيدت نسخة احتياطية من '+name+': NN مُدرَّب='+res.trainN+' · FreqDB='+res.freqDBSize+' تردد'+_fmtBansZonesSuffix(res),'ok');
 }else if(/^ZeroAI_Scenes\.json$/i.test(name)){
 const res=await _restoreScenesFromJSON(raw,name);
 report('✓ استُورد من '+name+': +'+res.added+' مشهد جديد + تحديث '+res.updated+' موجود','ok');
 }else{
 report(' هذا النوع من الملفات غير قابل للاستيراد المباشر','err');return;
 }
 }catch(e){report(' خطأ: '+e.message,'err');}
}
function deleteFixedFolderFile(name){
 if(!_wtafsOk()||!WebToApkFS.hasAccess()||typeof WebToApkFS.delete!=='function')return;
 try{
 if(WebToApkFS.delete(name)){stLog(' حُذف من المجلد الثابت: '+name);renderFixedFolderBrowser();}
 else stLog(' تعذّر حذف: '+name);
 }catch(e){stLog(' خطأ أثناء الحذف: '+e.message);}
}

/* ═══════════════════════════════════
 ④ ACHIEVEMENT SYSTEM — 15 milestones
═══════════════════════════════════ */
const ACHIEVEMENTS=[
 {id:'first_cap', icon:'',name:'First Capture', desc:'First frequency recorded', chk:()=>freqFile.totalCap>=1},
 {id:'first_conf',icon:'',name:'First Confirm', desc:'First freq confirmed ×3', chk:()=>freqFile.totalConf>=1},
 {id:'first_canc',icon:'✓', name:'First Cancel', desc:'Inverse cancellation success', chk:()=>freqFile.totalCanc>=1},
 {id:'db10', icon:'',name:'Growing DB', desc:'10+ frequencies captured', chk:()=>freqDB.size>=10},
 {id:'db50', icon:'',name:'Rich Database', desc:'50+ frequencies captured', chk:()=>freqFile.totalCap>=50},
 {id:'nn100', icon:'',name:'Learning Active', desc:'NN trained 100+ times', chk:()=>NN.trainN>=100},
 {id:'nn1000', icon:'',name:'Deep Learning', desc:'NN trained 1000+ times', chk:()=>NN.trainN>=1000},
 {id:'sil80', icon:'',name:'Silence!', desc:'80%+ silence achieved', chk:()=>appState.silSc>=80},
 {id:'sil95', icon:'',name:'Master Silence', desc:'95%+ silence score', chk:()=>appState.silSc>=95},
 {id:'cyc1000', icon:'',name:'Marathon', desc:'1000+ engine cycles', chk:()=>appState.aiCyc>=1000},
 {id:'bg_run', icon:'',name:'Ghost Mode', desc:'Ran in background', chk:()=>(typeof bgRuns!=='undefined'&&bgRuns>=1)},
 {id:'inv10', icon:'⟳', name:'Inverse Master', desc:'10+ inverse cancellations', chk:()=>freqFile.totalCanc>=10},
 {id:'loss01', icon:'',name:'Sharp Mind', desc:'NN loss below 0.1', chk:()=>NN.loss<0.1&&NN.trainN>10},
 {id:'evp_det', icon:'〰',name:'EVP Found', desc:'Infrasonic EVP signal detected', chk:()=>appState.evpE>0.2},
 {id:'emf_det', icon:'',name:'EMF Found', desc:'EMF interference detected', chk:()=>appState.emfE>0.15},
];

const earnedAch=new Set();
class AchToastQueue{
 constructor(){
 this.queue=[];
 this.showing=false;
 }
 drain(){
 if(!this.queue.length){this.showing=false;return;}
 this.showing=true;
 this.showToast(this.queue.shift());
 setTimeout(()=>this.drain(),3400);
 }
 showToast(a){
 let t=E('achToast');
 if(!t){t=document.createElement('div');t.id='achToast';t.style.cssText='position:fixed;bottom:calc(88px + var(--vv-bottom-inset,0px));left:50%;transform:translateX(-50%) translateY(12px);z-index:200;opacity:0;pointer-events:none;transition:opacity .4s,transform .4s';document.body.appendChild(t);}
 t.innerHTML=`<div style="background:rgba(5,5,5,.97);border:1px solid rgba(206,206,206,.45);border-radius:16px;padding:10px 16px;display:flex;align-items:center;gap:10px;box-shadow:0 4px 35px rgba(0,0,0,.75);backdrop-filter:blur(18px);min-width:240px"><span style="font-size:24px">${a.icon}</span><div><div style="font-family:var(--fo);font-size:10px;color:#cecece;letter-spacing:.12em;margin-bottom:2px">ACHIEVEMENT UNLOCKED</div><div style="font-size:13px;font-weight:600;color:var(--text)">${a.name}</div><div style="font-family:var(--fm);font-size:10px;color:var(--dim)">${a.desc}</div></div></div>`;
 requestAnimationFrame(()=>{t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';});
 setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(-50%) translateY(12px)';setTimeout(()=>{this.showing=false;this.drain();},400);},3000);
 }
}
const achToastQ=new AchToastQueue();

function checkAchievements(){
 ACHIEVEMENTS.forEach(a=>{
 if(!earnedAch.has(a.id)&&a.chk()){
 earnedAch.add(a.id);achToastQ.queue.push(a);
 if(zeroDB){const tx=zeroDB.transaction('achievements','readwrite');tx.objectStore('achievements').put({id:a.id,date:new Date().toISOString()});}
 stLog(' '+a.icon+' '+a.name+': '+a.desc);
 if(curTab===7)renderAchievements();
 }
 });
 if(achToastQ.queue.length&&!achToastQ.showing)drainAchQ();
}

function drainAchQ(){return achToastQ.drain();}
function showAchToast(a){return achToastQ.showToast(a);}

function renderAchievements(){
 const el=E('ach-list');if(!el)return;
 const total=ACHIEVEMENTS.length,earned=earnedAch.size;
 const c2=E('ach-count2');if(c2)c2.textContent=earned+'/'+total;
 const c1=E('ach-count');if(c1)c1.textContent=earned+'/'+total;
 el.innerHTML=ACHIEVEMENTS.map(a=>{
 const ok=earnedAch.has(a.id);
 return`<div class="ach-item" style="opacity:${ok?1:.3}"><span class="ach-ico">${a.icon}</span><div style="flex:1;min-width:0"><div class="ach-n" style="color:${ok?'var(--text)':'var(--dim)'}">${a.name}</div><div class="ach-d">${a.desc}</div></div>${ok?'<span class="ach-ck">✓</span>':''}</div>`;
 }).join('');
}

async function loadAchievements(){
 if(!zeroDB)return;
 const tx=zeroDB.transaction('achievements','readonly');
 const req=tx.objectStore('achievements').getAll();
 req.onsuccess=e=>{
 e.target.result.forEach(a=>earnedAch.add(a.id));
 if(curTab===7)renderAchievements();
 };
}

setInterval(checkAchievements,5000);

/* ═══════════════════
 ⑤ AUTO-SAVE
═══════════════════ */
let autoSave=true,lastAutoSave=0;

setInterval(async()=>{
 if(!appState.isRun||!autoSave||!zeroDB)return;
 if(Date.now()-lastAutoSave<120000)return;
 lastAutoSave=Date.now();
 await saveSession();
 if(curTab===7)refreshSessionList();
},30000);

/* ═══════════════════════
 FILES UI UPDATE
═══════════════════════ */

window._applyCleanupPatternToEntries=_applyCleanupPatternToEntries; window._cleanupFixedFolderPattern=_cleanupFixedFolderPattern; window._cleanupFixedFolderExports=_cleanupFixedFolderExports;
window.WTAFS_BACKUP_PATTERNS=WTAFS_BACKUP_PATTERNS; window._cleanupFixedFolderBackups=_cleanupFixedFolderBackups; window.importFromFixedFolder=importFromFixedFolder;
window._b64FromText=_b64FromText; window._textFromB64=_textFromB64; window._pickedFileKey=_pickedFileKey;
window.pickFixedFile=pickFixedFile; window.importFromPickedFile=importFromPickedFile; window.forgetPickedFile=forgetPickedFile;
window.exportJSON=exportJSON; window.exportCSV=exportCSV; window._restoreFullBackupJSON=_restoreFullBackupJSON;
window._fmtBansZonesSuffix=_fmtBansZonesSuffix; window.importJSON=importJSON; window.importFullBackupFromFixedFolder=importFullBackupFromFixedFolder;
window.pickAndRestoreFullBackup=pickAndRestoreFullBackup; window.WTAFS_FILE_KINDS=WTAFS_FILE_KINDS; window._classifyFixedFolderFile=_classifyFixedFolderFile;
window._wtafsHandleBrokenGrant=_wtafsHandleBrokenGrant; window._wtafsListSafe=_wtafsListSafe; window.renderFixedFolderBrowser=renderFixedFolderBrowser;
window._mimeForFile=_mimeForFile; window.shareFixedFolderFile=shareFixedFolderFile; window.WTAFS_SHARE_ALL_MAX=WTAFS_SHARE_ALL_MAX;
window.shareAllFixedFolderFiles=shareAllFixedFolderFiles; window.importFixedFolderFile=importFixedFolderFile; window.deleteFixedFolderFile=deleteFixedFolderFile;
window.ACHIEVEMENTS=ACHIEVEMENTS; window.earnedAch=earnedAch; window.achToastQ=achToastQ;
window.checkAchievements=checkAchievements; window.drainAchQ=drainAchQ; window.showAchToast=showAchToast;
window.renderAchievements=renderAchievements; window.loadAchievements=loadAchievements; window.autoSave=autoSave;
window.lastAutoSave=lastAutoSave;

})();
/* ── 11-terminal-logging.js ── */

'use strict';
(function(){

const ST_LOG=[];
function stLog(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 ST_LOG.unshift({msg,t});if(ST_LOG.length>60)ST_LOG.pop();
 if(curTab===7){const el=E('st-log');if(el)el.innerHTML=ST_LOG.slice(0,10).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.45)">${l.t}</span> ${l.msg}</div>`).join('');}
}
/* addToStLog — اسم استُخدم في banFreq/unbanFreq وعدة أماكن أخرى (partitions، auto-ban،
 post-ban confirmation) لكنه لم يكن مُعرَّفاً إطلاقاً — ما كان يعني أن banFreq وغيرها
 تنفجر بـ ReferenceError في نهاية تنفيذها في كل مرة يُحضَر فيها تردد جديد فعلياً (بعد أن
 يكون AI_BAN.set/renderBanList قد نُفِّذا، فتُقطَع العملية دون أن تُكمل return true).
 الإصلاح: alias بسيط إلى stLog الموجودة فعلياً بنفس التوقيع (رسالة نصية واحدة). */
function addToStLog(msg){stLog(msg);}

function updateFilesUI(){
 // Storage paths display
 const pathEl=E('st-paths');
 if(pathEl){
 const p=getStoragePaths();
 if(p.available){
 pathEl.innerHTML='Internal: <span style="color:var(--zero)">'+p.internal+'</span><br> Export: <span style="color:var(--c5)">'+p.export+'</span>';
 }else{
 pathEl.innerHTML='Browser: <span style="color:var(--zero)">IndexedDB</span><br> Export: <span style="color:var(--c5)">Browser Download</span>';
 }
 }
 // Stats — query UDS for live counts
 const kb=E('st-kb');if(kb)kb.textContent=Math.round(freqDB.size*0.2+EXEC_LOG.length*0.1+terminalLog.TBUF.length*0.05);
 // Terminal event count from TBUF
 const tev=E('st-term-ev');if(tev)tev.textContent=terminalLog.TBUF.length;
 // System Links status
 const ls=E('link-status');
 if(ls){
 const rows=[
 {label:'AI EXEC → UDS',ok:!!zeroDB,detail:'exec_history: '+EXEC_LOG.length+' cached'},
 {label:'Terminal → UDS',ok:!!zeroDB,detail:'terminal_events: '+terminalLog.TBUF.length+' buffered'},
 {label:'AI_CTX ← UDS',ok:AI_CTX.ready,detail:'topFreqs='+AI_CTX.topFreqs.length+' patterns='+AI_CTX.confirmedPatterns.length},
 {label:'IndexedDB',ok:!!zeroDB,detail:DBNAME+' v'+DBVER},
 {label:'Storage Persist',ok:false,detail:'checking...'},
 {label:'Android Bridge',ok:typeof ZeroAndroid!=='undefined',detail:typeof ZeroAndroid!=='undefined'?'✓ '+ZeroAndroid.getDeviceModel():'browser mode'},
 ];
 // Check persist async
 if(navigator.storage&&navigator.storage.persisted){
 navigator.storage.persisted().then(p=>{
 const row=ls.querySelector('[data-link="persist"]');
 if(row)row.innerHTML=`<span style="color:${p?'var(--zero)':'var(--c3)'}">${p?'✓':'✗'}</span><span style="color:rgba(255,255,255,.3)"> Storage Persist</span> <span style="color:var(--muted)">${p?'no-evict':'evictable'}</span>`;
 });
 }
 ls.innerHTML=rows.map((r,i)=>`<div data-link="${i===4?'persist':''}" style="display:flex;align-items:center;gap:6px;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="color:${r.ok?'var(--zero)':'var(--c3)'}">${r.ok?'✓':'✗'}</span><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.45);flex:1">${r.label}</span><span style="font-family:var(--fm);font-size:8px;color:var(--muted)">${r.detail}</span></div>`).join('');
 }
 // Storage log
 const sl=E('st-log');
 if(sl&&ST_LOG.length)sl.innerHTML=ST_LOG.slice(0,10).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.45)">${l.t}</span> ${l.msg}</div>`).join('');
 renderAchievements();
 refreshSessionList();
}

/* INIT */
async function initStorage(){
 try{
 // 1. Init unified data store (sessions + terminal_events + exec_history + nn_history + freq_patterns)
 await initDB();
 stLog(' UDS ready: '+DBNAME+' v'+DBVER+' · 7 stores');
 // 2. Request persistent storage (no-evict)
 await reqStoragePersist();
 // 3. Load achievements + NN weights + sessions
 await loadAchievements();
 await loadLastWeights();
 await loadFreqDB();
 await refreshSessionList();
 // 4. Build initial AI context from historical data
 await updateAICtx();
 stLog(' AI_CTX ready · topFreqs='+AI_CTX.topFreqs.length+' patterns='+AI_CTX.confirmedPatterns.length);
 // 5. Terminal startup message
 tLog('SYS',
 `# UDS initialized: ${DBNAME} v${DBVER} · persist=${AI_CTX.ready}`,
 `# stores: terminal_events, exec_history, nn_history, freq_patterns, sessions, achievements, patterns`
 );
 // 6. Write to Android storage if available
 if(typeof ZeroAndroid!=='undefined'){
 const paths={internal:ZeroAndroid.getInternalPath(),export:ZeroAndroid.getExportPath()};
 ZeroAndroid.saveFile('logs','init.txt','ZERO AI v25 UDS init: '+new Date().toISOString()+'\n'+JSON.stringify(paths));
 stLog(' Android paths ready');
 }
 }catch(e){stLog(' Storage error: '+e.message);}
}




/* ════════════════════════════════════════════════════════════════
 LIVE TERMINAL — Python DSL Feed
 All engine events streamed in real-time using Python syntax.
 The AI EXEC system reads this feed to understand the full state.

 AI Language: Python (pseudocode) — chosen for:
 • Native AI training language (most LLM-friendly syntax)
 • Expressive: state.FC['c7'], iLv = min(1.0, iLv*1.07)
 • Self-documenting: logic is readable by both human and AI
 • Matches how neural network research is written
════════════════════════════════════════════════════════════════ */

/* ══ TERMINAL STATE + LOGGER + CONTROL — class تحويل 30 سبتمبر 2026 ══
 كل الحقول والدوال أدناه كانت متفرقة على مستوى القسم (TBUF/TMAX/tPaused/
 tFilter/tSearchQuery/TERM_VISIBLE_TYPES/TC/TTAG/_tIdSeq/_dedupMap/
 _DEDUP_WINDOW_MS/TLOG_PERSIST_KEY/TLOG_PERSIST_MAX/_persistTimer +
 17 دالة) — كلها تشترك في نفس الحالة الحقيقية (المخزن الحلقي الواحد
 TBUF وما يتبعه من فلترة/بحث/تكرار/استمرارية/عرض)، فحُوِّلت لصنف واحد
 TerminalLog (على غرار PERSIST في 08a) بدل تركها متناثرة. الدوال ذات
 المستدعي الخارجي بالاسم المجرَّد (tLog، openTerm، closeTerm) أو
 المرتبطة بـonclick= في HTML (termTogglePause/termClear/termFilter/
 termSearch/termRunCmd/termSaveTXT) أبقت أغلفة رقيقة بنفس الاسم القديم
 تماماً — التوقيع الخارجي لم يتغيّر إطلاقاً. */
class TerminalLog{
 constructor(){
 this.TBUF = []; // ring buffer 300 entries — تبقى تُخزِّن كل الأنواع (FREQ/NN/EXEC/...)
 // كما كانت، فأنظمة أخرى (udsWriteEvent→terminal_events، AI_CTX،
 // pattern learning) تعتمد عليها بلا تغيير — التصفية أدناه للعرض فقط.
 this.TMAX = 300;
 // tOpen declared at top scope (line 688) — no re-declaration needed
 this.tPaused = false;
 this.tFilter = 'ALL'; // استُعيدت 28 سبتمبر 2026 — تتحكم بعرض الطرفية الحيّ (ALL أو فئة واحدة)
 // بحث نصّي حرّ — أُضيف 28 سبتمبر 2026 (تطوير Logs): تصفية الفئة وحدها (tFilter) لا تكفي
 // لإيجاد سطر بعينه وسط مئات الأسطر (مثلاً تردد رقمي محدد أو رسالة خطأ معيّنة)؛ يعمل هذا
 // البحث فوق تصفية الفئة (AND بينهما، لا بديل عنها) وعلى نص السطر (code) وسطره الفرعي (sub)
 // معاً، غير حسّاس لحالة الأحرف. فارغ = بلا أثر (كل السلوك القديم كما هو تماماً).
 this.tSearchQuery = '';
 // TERM_VISIBLE_TYPES يبقى استخدامه الآن مقصوراً على أهلية "تجميع التكرارات" (dedup) فقط —
 // السبب: SYS/WARN/ERR هي الأنواع المعرَّضة تاريخياً لفيضان تكرار حقيقي (خطأ JS يتكرر كل
 // ~320ms)، بخلاف FREQ/NN/EXEC/INV/SF/COH التي تُسجَّل بمعدل دورة الكشف الطبيعي فلا تحتاج ذلك.
 // العرض الحيّ نفسه يعتمد الآن على tFilter أدناه (ALL يعرض كل الأنواع، أو فئة واحدة محددة).
 this.TERM_VISIBLE_TYPES = new Set(['SYS','WARN','ERR']);
 this.TC = { // Python color scheme per type
 FREQ: '#959595',
 NN: '#a5a5a5',
 EXEC: '#cecece',
 INV: '#9c9c9c',
 SF: '#aaaaaa',
 COH: '#818181',
 DB: '#a9a9a9',
 SYS: '#a4a4a4',
 BG: '#888888',
 WARN: '#888888',
 ERR: '#686868',
 };
 this.TTAG = {
 FREQ:'[FREQ]',NN:'[NN ]',EXEC:'[EXEC]',INV:'[INV ]',
 SF:'[SF ]',COH:'[COH ]',DB:'[DB ]',SYS:'[SYS ]',
 BG:'[BG ]',WARN:'[WARN]',ERR:'[ERR ]',
 };
 /* ══ تطوير سجلّ الأخطاء (طلب المستخدم) — ميزتان جديدتان ══
 ① تجميع التكرارات: حالة حقيقية أثبتها سجلّ الأخطاء الذي أرسله المستخدم فعلياً — نفس الانهيار
 الواحد تكرر كل ~320ms لعشرات الثواني (~90 سطراً متطابقاً من أصل 98). بلا تجميع، رسالة متكررة
 بسرعة تُغرق المخزن المحدود (300) والعرض والتصدير بنسخ متطابقة، فيُفقَد أي سياق آخر مختلف حدث
 في نفس النافذة الزمنية. الآن: تكرار (type+code+sub) نفسه خلال ≤3 ثوانٍ من آخر ظهور له لا يُنشئ
 سطراً جديداً — يزيد عدّاد السطر القائم (×N) ويحدّث وقته فقط. مقصور على الأنواع المعروضة
 (SYS/WARN/ERR) حصراً — لا يمسّ إطلاقاً سجلّ FREQ/NN/EXEC/INV/SF/COH (حدث واحد لكل استدعاء
 كما كان دوماً، لأن AI_CTX/pattern learning تعتمد على ذلك التدفق الخام).
 ② الاستمرارية عبر إعادة التحميل: رسائل SYS/WARN/ERR (المرئية فقط) تُحفظ في localStorage
 وتُستعاد تلقائياً عند تحميل الصفحة من جديد — فإن أدّى عطل حقيقي لإعادة تشغيل الصفحة/التطبيق
 قبل أن يفتح المستخدم اللوحة أو يحفظ TXT، لا يُفقَد سجلّ ذلك العطل بالكامل. ══ */
 this._tIdSeq = 0;
 this._dedupMap = new Map(); // key(type|code|sub) → {entry, lastMs}
 this._DEDUP_WINDOW_MS = 3000;
 this.TLOG_PERSIST_KEY = 'zero_syslog_v1';
 this.TLOG_PERSIST_MAX = 150;
 this._persistTimer = null;
 }

 persist(){
 try{
 const items = this.TBUF.filter(e=>this.TERM_VISIBLE_TYPES.has(e.type)).slice(0,this.TLOG_PERSIST_MAX)
 .map(e=>({type:e.type,t:e.t,code:e.code,sub:e.sub,count:e.count||1}));
 localStorage.setItem(this.TLOG_PERSIST_KEY, JSON.stringify(items));
 }catch(e){}
 }

 schedulePersist(){
 if(this._persistTimer)return;
 this._persistTimer=setTimeout(()=>{this._persistTimer=null;this.persist();},1500);
 }

 restore(){
 try{
 const raw=localStorage.getItem(this.TLOG_PERSIST_KEY);
 if(!raw)return;
 const items=JSON.parse(raw);
 if(!Array.isArray(items)||!items.length)return;
 // items مخزَّنة الأحدث أولاً (كترتيب TBUF) — تُدرَج بترتيب عكسي كي يبقى الأحدث فعلياً
 // أول عنصر في TBUF بعد الاستعادة، تماماً كما لو أنها سُجِّلت للتو بنفس ترتيبها الأصلي.
 for(let i=items.length-1;i>=0;i--){
 const it=items[i];
 if(!it||!it.type||!it.code)continue;
 this.TBUF.unshift({id:++this._tIdSeq,type:it.type,t:it.t||'--:--.--',code:it.code,sub:it.sub||null,count:it.count||1,restored:true});
 }
 if(this.TBUF.length>this.TMAX)this.TBUF.length=this.TMAX;
 setTimeout(()=>this.log('SYS','# استُعيد '+items.length+' رسالة من الجلسة السابقة'),0);
 }catch(e){}
 }

 // مطابقة سطر لاستعلام البحث الحالي — مشتركة بين العرض الحيّ (log) وإعادة البناء الكاملة
 // (renderAll)، لتفادي انحراف أحدهما عن الآخر (نفس درس "تناسق الفحص/المقارنة" في هذه الجلسة).
 matchesSearch(code, sub) {
 if (!this.tSearchQuery) return true;
 return (code && code.toLowerCase().includes(this.tSearchQuery)) ||
 (sub && sub.toLowerCase().includes(this.tSearchQuery));
 }

 /* ══ TERMINAL LOGGER — PYTHON SYNTAX ══ */
 log(type, pyCode, sub) {
 // ERR (أخطاء JS حقيقية ملتقَطة تلقائياً) يجب أن تُسجَّل دوماً كـSYS تماماً — قد يحدث خطأ
 // حتى قبل الضغط على تشغيل، ولا يجوز إسقاطه بسبب isRun===false.
 if(!appState.isRun && type !== 'SYS' && type !== 'ERR') return;
 const nowMs = Date.now();
 const ts = new Date(nowMs);
 const t = String(ts.getMinutes()).padStart(2,'0') + ':' +
 String(ts.getSeconds()).padStart(2,'0') + '.' +
 String(ts.getMilliseconds()).slice(0,3);
 const visible = this.TERM_VISIBLE_TYPES.has(type); // أهلية تجميع التكرارات (dedup) فقط
 const shown = (this.tFilter==='ALL' || this.tFilter===type) && this.matchesSearch(pyCode, sub); // فئة + بحث معاً
 const dkey = visible ? (type+'|'+pyCode+'|'+(sub||'')) : null;
 if(visible){
 const dhit = this._dedupMap.get(dkey);
 if(dhit && (nowMs-dhit.lastMs) < this._DEDUP_WINDOW_MS){
 dhit.entry.count=(dhit.entry.count||1)+1;
 dhit.entry.t=t;
 dhit.lastMs=nowMs;
 const ld=E('termLiveDot');
 if(ld){ld.className='term-live-dot on';setTimeout(()=>{if(ld)ld.className='term-live-dot'+(appState.isRun?' on':'');},120);}
 if(appState.tOpen && !this.tPaused && shown) this.updateLine(dhit.entry);
 this.schedulePersist();
 return;
 }
 }
 const entry = {id:++this._tIdSeq, type, t, code: pyCode, sub: sub || null, count:1};
 this.TBUF.unshift(entry);
 if(this.TBUF.length > this.TMAX) this.TBUF.pop();
 if(visible){
 if(this._dedupMap.size>=200){const oldestKey=this._dedupMap.keys().next().value;this._dedupMap.delete(oldestKey);}
 this._dedupMap.set(dkey,{entry,lastMs:nowMs});
 }
 // ── Write to UDS (persistent memory) ────────────
 udsWriteEvent(entry);
 // ── Write NN snapshot to nn_history ─────────────
 if(type==='NN') udsWriteNN();
 // Live dot pulse
 const ld = E('termLiveDot');
 if(ld) { ld.className = 'term-live-dot on'; setTimeout(() => { if(ld) ld.className = 'term-live-dot' + (appState.isRun?' on':''); }, 120); }
 if(appState.tOpen && !this.tPaused && shown) this.renderLine(entry);
 if(visible) this.schedulePersist();
 }

 // جسم السطر (اللون + النص + شارة التكرار ×N إن وُجدت) — مشترك بين render/update لتفادي الازدواج.
 bodyHTML(entry){
 const c = this.TC[entry.type] || '#ccc';
 const cnt = (entry.count||1) > 1 ? `<span class="tl-cnt">×${entry.count}</span>` : '';
 return `<span class="tl-body" style="color:${c}">${escH(entry.code)}</span>${cnt}`;
 }

 renderLine(entry) {
 const out = E('termOut'); if(!out) return;
 const c = this.TC[entry.type] || '#ccc';
 const tag = this.TTAG[entry.type] || '[ ]';
 const row = document.createElement('div');
 row.className = 'tline';
 row.dataset.tid = entry.id;
 row.innerHTML =
 `<span class="tl-ts">${entry.t}</span>` +
 `<span class="tl-tag" style="color:${c}">${tag}</span>` +
 this.bodyHTML(entry);
 if(entry.sub) {
 const sub = document.createElement('div');
 sub.className = 'tl-sub';
 sub.dataset.tid = entry.id;
 sub.textContent = entry.sub;
 out.insertBefore(sub, out.firstChild);
 }
 out.insertBefore(row, out.firstChild);
 // Trim UI to 80 rows
 while(out.children.length > 80) out.removeChild(out.lastChild);
 }

 // تحديث سطر معروض بالفعل مكانه (بدل إدراج سطر جديد) عند تجميع تكرار — انظر تعليق _dedupMap.
 updateLine(entry){
 const out = E('termOut'); if(!out) return;
 const row = out.querySelector(`.tline[data-tid="${entry.id}"]`);
 if(!row){ this.renderLine(entry); return; } // خرج من نافذة الـ80 سطر المعروضة — أضِف سطراً بأمان
 row.innerHTML =
 `<span class="tl-ts">${entry.t}</span>` +
 `<span class="tl-tag" style="color:${this.TC[entry.type]||'#ccc'}">${this.TTAG[entry.type]||'[ ]'}</span>` +
 this.bodyHTML(entry);
 }

 renderAll() {
 const out = E('termOut'); if(!out) return;
 out.innerHTML = '';
 const byCat = this.tFilter==='ALL' ? this.TBUF : this.TBUF.filter(e => e.type === this.tFilter);
 const items = this.tSearchQuery ? byCat.filter(e => this.matchesSearch(e.code, e.sub)) : byCat;
 const cntEl = E('termSearchCnt');
 if (cntEl) cntEl.textContent = this.tSearchQuery ? `${items.length} نتيجة` : '';
 items.slice(0, 60).reverse().forEach(e => {
 const c = this.TC[e.type] || '#ccc';
 const tag = this.TTAG[e.type] || '[ ]';
 const row = document.createElement('div');
 row.className = 'tline';
 row.dataset.tid = e.id;
 row.innerHTML =
 `<span class="tl-ts">${e.t}</span>` +
 `<span class="tl-tag" style="color:${c}">${tag}</span>` +
 this.bodyHTML(e);
 if(e.sub){const s=document.createElement('div');s.className='tl-sub';s.dataset.tid=e.id;s.textContent=e.sub;out.appendChild(s);}
 out.appendChild(row);
 });
 out.scrollTop = out.scrollHeight;
 }

 /* ══ TERMINAL CONTROL ══ */
 open() {
 appState.tOpen = true;
 E('ovl').classList.add('on');
 E('termPanel').classList.add('open');
 this.renderAll();
 const el = E('termLiveDot');
 if(el) el.className = 'term-live-dot' + (appState.isRun?' on':'');
 }

 close() {
 appState.tOpen = false;
 if(!appState.sOpen && !appState.pOpen && !appState.aOpen && !appState.zpOpen && !appState.dmOpen && !appState.menuOpen && !appState.filesOpen && !appState.maskOpen && !appState.physOpen && !appState.aboutOpen && !appState.privacyOpen && !appState.loopDiagOpen && !appState.avOpen) E('ovl').classList.remove('on');
 E('termPanel').classList.remove('open');
 }

 togglePause() {
 this.tPaused = !this.tPaused;
 const btn = E('termPauseBtn');
 const lbl = E('termPauseLbl');
 if(btn) btn.textContent = this.tPaused ? '▶ RESUME' : ' PAUSE';
 if(lbl) lbl.style.display = this.tPaused ? '' : 'none';
 if(!this.tPaused) this.renderAll();
 }

 clear() {
 this.TBUF.length = 0;
 this._dedupMap.clear();
 try{localStorage.removeItem(this.TLOG_PERSIST_KEY);}catch(e){} // "مسح" يعني مسح كامل — بما في ذلك النسخة المحفوظة
 const out = E('termOut');
 if(out) out.innerHTML = '<div style="color:rgba(169,169,169,.3);font-size:9px;padding:4px 0">-- terminal cleared --</div>';
 }

 // استُعيدت 28 سبتمبر 2026: تصفية الطرفية بالفئة (tFilter) — نفس السلوك الأصلي قبل الحذف.
 setFilter(btn, f) {
 this.tFilter = f;
 document.querySelectorAll('.tfc').forEach(b => b.classList.remove('on'));
 btn.classList.add('on');
 this.renderAll();
 }

 // بحث نصّي حرّ في السجلّ — تطوير Logs، 28 سبتمبر 2026. يعمل فوق تصفية الفئة الحالية (AND).
 setSearch(val) {
 this.tSearchQuery = (val || '').trim().toLowerCase();
 this.renderAll();
 }

 // استُعيدت 28 سبتمبر 2026: تنفيذ أمر من حقل الطرفية — يُمرَّر لمحرك EXEC نفسه (#execInp/
 // runExecCmd) الموجود أصلاً في لوحة أخرى، فلا يوجد منطق EXEC مكرَّر هنا إطلاقاً.
 runCmd() {
 const inp = E('termCmd'); if(!inp) return;
 const cmd = inp.value.trim(); inp.value = '';
 if(!cmd) return;
 this.log('SYS', `>>> ${cmd}`);
 const ei = E('execInp');
 if(ei) { ei.value = cmd; runExecCmd(); }
 }

 // ميزة حُفظت من مرحلة "مراقبة فقط": حفظ سجلّ النظام/الأخطاء المعروض كملف TXT — تبقى مفيدة
 // حتى بعد استعادة التفاعل الكامل أعلاه (تصدير مخصَّص لـSYS/WARN/ERR فقط، بمعزل عن التصفية الحية).
 saveTXT() {
 const items = this.TBUF.filter(e => this.TERM_VISIBLE_TYPES.has(e.type)).slice().reverse(); // الأقدم أولاً
 if(!items.length){ this.log('SYS', '# لا توجد رسائل نظام/أخطاء لحفظها بعد'); return; }
 const lines = items.map(e => {
 const tag = (this.TTAG[e.type] || '[' + e.type + ']').trim();
 const cnt = (e.count||1) > 1 ? ` (×${e.count})` : '';
 return `${e.t} ${tag} ${e.code}${cnt}` + (e.sub ? `\n ${e.sub}` : '');
 });
 const now = new Date();
 const stamp = now.getFullYear() + String(now.getMonth()+1).padStart(2,'0') + String(now.getDate()).padStart(2,'0') +
 '_' + String(now.getHours()).padStart(2,'0') + String(now.getMinutes()).padStart(2,'0') + String(now.getSeconds()).padStart(2,'0');
 const filename = `ZERO_SystemLog_${stamp}.txt`;
 const content = `ZERO AI v25 — System/Error Log\nExported: ${now.toISOString()}\nEntries: ${items.length}\n${'='.repeat(48)}\n\n${lines.join('\n')}\n`;
 // نفس أسلوب exportBans() الراسخ في المشروع: محاولة جسر أندرويد أولاً، ثم التنزيل عبر المتصفح.
 if(typeof ZeroAndroid!=='undefined'){
 try{
 if(ZeroAndroid.exportFile(filename,content)){
 this.log('SYS', `# saved → ${ZeroAndroid.getExportPath()}/${filename}`);
 return;
 }
 }catch(e){}
 }
 try{
 const blob=new Blob([content],{type:'text/plain'});
 const url=URL.createObjectURL(blob);
 const a=document.createElement('a');
 a.href=url;a.download=filename;
 document.body.appendChild(a);a.click();
 setTimeout(()=>{URL.revokeObjectURL(url);document.body.removeChild(a);},1000);
 this.log('SYS', `# downloading: ${filename}`);
 }catch(e){
 this.log('SYS', `# save failed: ${e.message}`);
 }
 }
}
const terminalLog=new TerminalLog();
terminalLog.restore(); // تنفيذ فوري عند تحميل السكربت — قبل أي استدعاء آخر لـtLog() في هذه الجلسة

function tLog(type,pyCode,sub){return terminalLog.log(type,pyCode,sub);}
function openTerm(){return terminalLog.open();}
function closeTerm(){return terminalLog.close();}
function termTogglePause(){return terminalLog.togglePause();}
function termClear(){return terminalLog.clear();}
function termFilter(btn,f){return terminalLog.setFilter(btn,f);}
function termSearch(val){return terminalLog.setSearch(val);}
function termRunCmd(){return terminalLog.runCmd();}
function termSaveTXT(){return terminalLog.saveTXT();}/* ════════════════════════════════════════════
 PYTHON DSL HOOKS — instrument every engine event
 Every function below calls tLog() with Python syntax
════════════════════════════════════════════ */

/* Hook: fRecord → FREQ event */
const _fRecordOrig = fRecord;
let _fRecHooked = false; // re-entry guard
window.fRecord = function(hz, energy) {
 _fRecordOrig.call(this, hz, energy);
 if(!hz || hz < 0.01 || _fRecHooked) return;
 _fRecHooked = true;
 const bin = fBin(hz);
 const e = freqDB.get(bin);
 if(!e) return;
 const cls = e.class || 0;
 const cn = ['','C1⊕','C2⊖','C3∓','C4±','C5+','C6-','C7+','C8-'][cls] || '';
 tLog('FREQ',
 `hz = ${hz.toFixed(3)} # class=${cn} energy=${energy.toFixed(3)} count=${e.count}${e.confirmed?' [CONFIRMED]':''}${e.cancelled?' [CANCELLED]':''}`,
 e.count===appState.FREQ_THRESH ? `# → THRESHOLD ×${appState.FREQ_THRESH} reached — inverse queued` : null
 );
 _fRecHooked = false;
};

/* Hook: nnTrain → NN event in Python */
const _nnTrainOrig = nnTrain;
window.nnTrain = function(inp, reward) {
 if(!NN.w1) return; // guard: NN not initialized yet
 const prevLoss = NN.loss;
 _nnTrainOrig.call(this, inp, reward);
 if(NN.trainN % 5 !== 0) return; // log every 5th train to reduce noise
 tLog('NN',
 `loss = ${prevLoss.toFixed(4)} → ${NN.loss.toFixed(4)} # reward=${reward>0?'+':''}${reward.toFixed(3)} step=${NN.trainN} lr=${NN.lr.toFixed(4)}`,
 NN.loss < prevLoss ? `# ↓ improving Δ=${(prevLoss-NN.loss).toFixed(5)}` : `# ↑ loss spike`
 );
};

/* Hook: buildInverse → INV event */
const _buildInvOrig = buildInverse;
window.buildInverse = function(hz, energy, dbEntry) {
 _buildInvOrig.call(this, hz, energy, dbEntry);
 const hp = Math.min(1/(hz*2), 0.5);
 tLog('INV',
 `buildInverse(hz=${hz.toFixed(3)}, φ=π) # delay=${hp.toFixed(6)}s gain=${((hz<20||hz>20000)?energy*0.12:energy*0.025).toFixed(4)}`,
 `# anti-phase oscillator → verifyInv() in ${INV.verMs}ms`
 );
};

/* Hook: logExec → EXEC event in Python */
const _logExecOrig = logExec;
window.logExec = function(args) {
 _logExecOrig.call(this, args);
 if(!args || !args.prog) return;
 // Format EXEC as Python def
 const lines = (args.lines || []).slice(0,3);
 const pyStr = `def ${args.prog}(): # cycle=${args.cycle||appState.aiCyc} ${args.auto?'auto':'manual'} ${args.ms||0}ms\n ${lines.map(l=>'# '+l).join('\n ')}`;
 tLog('EXEC', pyStr, lines.length > 3 ? ` # ... +${args.lines.length-3} more` : null);
};

/* Hook: updSFGains → SF event — sampled to avoid spam */
let _sfLogN = 0;
const _updSFGainsOrig = updSFGains;
window.updSFGains = function() {
 _updSFGainsOrig.call(this);
 if(++_sfLogN % 5 !== 0) return; // log every 5th call
 const oCount = Object.keys(appState.silOscs).filter(k=>k!=='_m').length;
 tLog('SF',
 `SF.gains = {INF:${appState.iLv.toFixed(3)}, ULT:${appState.uLv.toFixed(3)}, PHF:${appState.pLv.toFixed(3)}, SUB:${appState.bLv.toFixed(3)}, PIE:${appState.eLv.toFixed(3)}}`,
 `# ${oCount} oscillators active`
 );
};

/* Hook: Coherence update (from updCoh) — sampled every 10th update */
let _cohCount = 0;
const _updCohOrig = updCoh;
window.updCoh = function(tS, tR) {
 _updCohOrig.call(this, tS, tR);
 _cohCount++;
 if(_cohCount % 10 !== 0) return;
 const avgCoh = Array.from(cV).reduce((a,b)=>a+b,0)/cV.length;
 tLog('COH',
 `γ²_avg = ${avgCoh.toFixed(4)} # silence=${appState.silSc}% bands=12 Δsilence=${appState.silSc-appState.bestSil}%`,
 `# ${appState.silSc>=80?'✓ γ²→0 achieved':'↻ converging...'}`
 );
};

/* BG mode events */
const _docVisCB = () => {
 if(document.hidden) tLog('BG', `# → BACKGROUND run#${bgRuns} cycle=${appState.aiCyc} silence=${appState.silSc}%`);
 else tLog('BG', `# ← FOREGROUND bgTime=${(bgTotalMs/1000).toFixed(1)}s workerCyc=${wkCycs}`);
};
document.addEventListener('visibilitychange', _docVisCB);

/* System log: forward logNN to terminal */
const _logNNOrig = logNN;
window.logNN = function(msg) {
 _logNNOrig.call(this, msg);
 // Only forward NN-specific internal messages, not EXEC duplicates
 if(msg.startsWith(' EXEC:') || msg.startsWith('') || msg.startsWith('')) return;
 tLog('SYS', `# ${msg}`);
};

/* closeAll already calls closeTerm() — no hook needed */

/* ══ التقاط الأخطاء الحقيقية تلقائياً — لم يكن للتطبيق أي مستمع error/unhandledrejection
 عام إطلاقاً قبل هذا؛ كل الاستثناءات غير الملتقَطة كانت تظهر فقط في console المطوّر ولا تصل
 لسجلّ النظام المعروض للمستخدم. الآن كل خطأ JS غير مُعالَج (بما فيها رفض Promise غير معالَج
 — بالضبط فئة الأخطاء التي واجهناها مراراً في هذا الملف: سباقات initAudio/reqWL وغيرها) يُسجَّل
 فوراً في سجلّ النظام بنوع ERR (يبقى مرئياً دوماً بصرف النظر عن isRun). ══ */
window.addEventListener('error', e => {
 const msg = e.message || (e.error && e.error.message) || 'Unknown error';
 const loc = e.filename ? `${String(e.filename).split('/').pop()}:${e.lineno}:${e.colno}` : null;
 // تطوير سجلّ الأخطاء: تضمين أول أطر استدعاء حقيقية من stack trace عند توفّرها — يسرّع تشخيص
 // العطل التالي فوراً (بدل الاكتفاء بموضع سطر واحد فقط، كما كانت النسخة السابقة).
 let stackBit = '';
 try{
 if(e.error && e.error.stack){
 const frames = String(e.error.stack).split('\n').slice(1,4).map(s=>s.trim()).filter(Boolean);
 if(frames.length) stackBit = ' · ' + frames.join(' ← ').slice(0,260);
 }
 }catch(err){}
 const sub = (loc ? `# at ${loc}` : '') + stackBit;
 tLog('ERR', ` ${msg}`, sub || null);
});
window.addEventListener('unhandledrejection', e => {
 const reason = e.reason;
 const msg = (reason && reason.message) ? reason.message : String(reason);
 tLog('ERR', ` Unhandled promise rejection: ${msg}`, null);
});

/* ══ Terminal init on startup — called from logExec SYS entry ══ */

document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAll();if(e.key===' '){e.preventDefault();toggleAI({});}});
// مستمع resize الخاص بـ bgCv (خلفية النجوم المتحركة) حُذف مع حذف الميزة بالكامل (28 سبتمبر 2026)

/* ── شاشة تعريفية لأول تشغيل (29 سبتمبر 2026) — انظر onbOverlay في index.template.tpl ──
 علامة زر "ابدأ" الوحيدة: مفتاح localStorage بسيط (نفس نمط الاستمرارية الاحتياطي المتّبع
 في PERSIST/08a-persist-bans-store.js) — لا حاجة لأي تخزين آخر لميزة بهذا الحجم. */
function dismissOnboarding(){
 const ob=document.getElementById('onbOverlay');
 if(ob)ob.classList.remove('onb-show');
 try{localStorage.setItem('zero_onboarded','1');}catch(e){}
 zVibrate(6);
}

/* ══════════════════════════════════════════
 SINGLE UNIFIED INIT — all systems start here
 Order: BG → Storage → DB → Achievements → UI
══════════════════════════════════════════ */
window.addEventListener('load',()=>{
 // شاشة التعريف تُفحص أولاً وبلا أي تأخير (setTimeout) حتى تظهر فوراً مع أول رسم للصفحة،
 // قبل أن يتمكن المستخدم من لمس أي شيء آخر — لا تعتمد على تحميل storage/DB أدناه.
 try{
 if(!localStorage.getItem('zero_onboarded')){
 const ob=document.getElementById('onbOverlay');
 if(ob)ob.classList.add('onb-show');
 }
 }catch(e){}
 // Init storage after UI is ready
 setTimeout(async()=>{
 await initStorage();
 // UI refresh
 updBGUI();
 updateFilesUI();
 bgLog(' ZERO AI v25 — All systems ready (local mode)');
 stLog(' Storage ready · '+DBNAME+' v'+DBVER+' · '+('serviceWorker' in navigator?'SW support':'no SW'));
 },800);
});

/* ══════════════════════════════════════════════════════════════════
 غرفة الصمت (MASKING NOISE) — استُعيدت 28 سبتمبر 2026 من anechoic-
 chamber.html ("تجميع كل الأفكار"). فكرة لم تظهر إطلاقاً في أي نسخة
 سابقة من ZERO — الإلغاء الفعّال (ANC) يحاول محو الصوت، بينما هذه
 ميزة مختلفة كلياً: إخفاؤه بضوضاء مريحة (إخفاء نفسي/سمعي لا فيزيائي).
 محرك صوت مستقل تماماً (maskCtx خاص) — لا يشارك actx الخاص بمحرك ANC
 الرئيسي، فلا يوجد أي تداخل أو تنافس على الموارد بين الاثنين، ويمكن
 تشغيلهما معاً أو كل على حدة. المنطق منقول حرفياً من anechoic-
 chamber.html (نفس خوارزميات توليد الضوضاء) مع إعادة تسمية كل الدوال
 بسابقة mask* لضمان عدم تعارضها مع أي شيء آخر في هذا الملف الضخم.
 ══════════════════════════════════════════════════════════════════ */

window.ST_LOG=ST_LOG; window.stLog=stLog; window.addToStLog=addToStLog;
window.updateFilesUI=updateFilesUI; window.initStorage=initStorage; window.terminalLog=terminalLog;
window.tLog=tLog; window.openTerm=openTerm; window.closeTerm=closeTerm;
window.termTogglePause=termTogglePause; window.termClear=termClear; window.termFilter=termFilter;
window.termSearch=termSearch; window.termRunCmd=termRunCmd; window.termSaveTXT=termSaveTXT;
window._fRecordOrig=_fRecordOrig; window._fRecHooked=_fRecHooked; window._nnTrainOrig=_nnTrainOrig;
window._buildInvOrig=_buildInvOrig; window._logExecOrig=_logExecOrig; window._sfLogN=_sfLogN;
window._updSFGainsOrig=_updSFGainsOrig; window._cohCount=_cohCount; window._updCohOrig=_updCohOrig;
window._docVisCB=_docVisCB; window._logNNOrig=_logNNOrig; window.dismissOnboarding=dismissOnboarding;

})();
/* ── 12-session-features-extra.js ── */

'use strict';
(function(){

/* ══ غرفة الصمت (MASKING NOISE) — class تحويل 30 سبتمبر 2026 ══
 8 حقول (maskCtx/maskSrcNode/maskGainNode/maskFilterNode/maskAnalyser/
 maskRunning/maskNoiseType/maskAnimFrame) + MASK_STORE_KEY + 16 دالة —
 كلها تأكَّد صفر مرجع خارجي (حالة داخلية بحتة)، فانضوت في صنف واحد
 MaskingNoise على غرار PersistStore/TerminalLog. الدوال المرتبطة بـ
 onclick=/oninput= في HTML المُحقَنة (toggle/selectNoise/updateVolume/
 updateFreq — تأكَّد ذلك بفحص عدد مواضع الاستدعاء الفعلية عبر كامل
 app.js، لا AST وحده) أبقت أغلفة رقيقة بنفس الاسم القديم تماماً؛ الباقي
 (saveState/loadState/createWhite وغيرها/buildNoise/applyFilter/start/stop/drawLoop)
 طُويت كطرق داخلية محضة بلا أي غلاف — لا مستدعٍ لها إطلاقاً خارج الصنف
 نفسه (تأكَّد بنفس فحص عدّ المواضع). */
class MaskingNoise{
 constructor(){
 this.maskCtx=null;this.maskSrcNode=null;this.maskGainNode=null;this.maskFilterNode=null;this.maskAnalyser=null;
 this.maskRunning=false;this.maskNoiseType='white';this.maskAnimFrame=null;
 this.MASK_STORE_KEY='zero_mask_v1';
 }

 saveState(){
 try{localStorage.setItem(this.MASK_STORE_KEY,JSON.stringify({type:this.maskNoiseType,vol:E('maskVolSlider')?.value,freq:E('maskFreqSlider')?.value}));}catch(e){}
 }
 loadState(){
 try{
 const raw=localStorage.getItem(this.MASK_STORE_KEY);if(!raw)return;
 const s=JSON.parse(raw);if(!s)return;
 if(s.type){this.maskNoiseType=s.type;const btn=document.querySelector(`.mask-btn[data-t="${s.type}"]`);if(btn){document.querySelectorAll('.mask-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on');}}
 if(s.vol!=null){const vs=E('maskVolSlider');if(vs){vs.value=s.vol;const l=E('maskVolLbl');if(l)l.textContent=s.vol+'%';}}
 if(s.freq!=null){const fs=E('maskFreqSlider');if(fs){fs.value=s.freq;const l=E('maskFreqLbl');if(l)l.textContent=s.freq+' Hz';}}
 const fr=E('maskFreqRow');if(fr)fr.style.display=(this.maskNoiseType==='rain'||this.maskNoiseType==='pink')?'':'none';
 }catch(e){}
 }

 createWhite(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 for(let i=0;i<bufLen;i++)data[i]=Math.random()*2-1;
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
 }
 createPink(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
 for(let i=0;i<bufLen;i++){
 const w=Math.random()*2-1;
 b0=0.99886*b0+w*0.0555179;b1=0.99332*b1+w*0.0750759;
 b2=0.96900*b2+w*0.1538520;b3=0.86650*b3+w*0.3104856;
 b4=0.55000*b4+w*0.5329522;b5=-0.7616*b5-w*0.0168980;
 data[i]=(b0+b1+b2+b3+b4+b5+b6+w*0.5362)*0.11;
 b6=w*0.115926;
 }
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
 }
 createBrown(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 let last=0;
 for(let i=0;i<bufLen;i++){const w=Math.random()*2-1;data[i]=(last+0.02*w)/1.02;last=data[i];data[i]*=3.5;}
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
 }
 createRain(ctx){return this.createPink(ctx);}
 createDeep(ctx){return this.createBrown(ctx);}
 buildNoise(ctx,type){
 if(type==='white')return this.createWhite(ctx);
 if(type==='pink')return this.createPink(ctx);
 if(type==='brown')return this.createBrown(ctx);
 if(type==='rain')return this.createRain(ctx);
 if(type==='deep')return this.createDeep(ctx);
 return this.createWhite(ctx);
 }
 applyFilter(filter,type,freq){
 filter.type='bandpass';
 if(type==='white'){filter.type='allpass';}
 else if(type==='pink'){filter.frequency.value=600;filter.Q.value=0.5;}
 else if(type==='brown'){filter.type='lowpass';filter.frequency.value=400;}
 else if(type==='rain'){filter.type='bandpass';filter.frequency.value=freq;filter.Q.value=1.2;}
 else if(type==='deep'){filter.type='lowpass';filter.frequency.value=250;}
 }

 toggle(){if(this.maskRunning)this.stop();else this.start();}

 start(){
 try{
 this.maskCtx=new(window.AudioContext||window.webkitAudioContext)();
 this.maskGainNode=this.maskCtx.createGain();
 this.maskFilterNode=this.maskCtx.createBiquadFilter();
 this.maskAnalyser=this.maskCtx.createAnalyser();this.maskAnalyser.fftSize=256;
 const freq=parseInt(E('maskFreqSlider')?.value||1200);
 this.applyFilter(this.maskFilterNode,this.maskNoiseType,freq);
 this.maskSrcNode=this.buildNoise(this.maskCtx,this.maskNoiseType);
 this.maskSrcNode.connect(this.maskFilterNode);this.maskFilterNode.connect(this.maskGainNode);
 this.maskGainNode.connect(this.maskAnalyser);this.maskGainNode.connect(this.maskCtx.destination);
 const vol=parseInt(E('maskVolSlider')?.value||45)/100;
 this.maskGainNode.gain.value=vol;
 this.maskSrcNode.start();
 this.maskRunning=true;
 const btn=E('maskRunBtn');if(btn){btn.textContent='■ إيقاف';btn.classList.add('on');}
 this.saveState();
 stLog(' غرفة الصمت: تشغيل ('+this.maskNoiseType+')');
 this.drawLoop();
 }catch(e){
 stLog(' غرفة الصمت: تعذَّر التشغيل — '+e.message);
 }
 }
 stop(){
 if(this.maskSrcNode){try{this.maskSrcNode.stop();}catch(e){}this.maskSrcNode=null;}
 if(this.maskCtx){try{this.maskCtx.close();}catch(e){}this.maskCtx=null;}
 if(this.maskAnimFrame){cancelAnimationFrame(this.maskAnimFrame);this.maskAnimFrame=null;}
 this.maskRunning=false;
 const btn=E('maskRunBtn');if(btn){btn.textContent='▶ تشغيل غرفة الصمت';btn.classList.remove('on');}
 const cv=E('maskViz');if(cv){const c=cv.getContext('2d');c.clearRect(0,0,cv.width,cv.height);}
 stLog(' غرفة الصمت: إيقاف');
 }
 selectNoise(type,btn){
 this.maskNoiseType=type;
 document.querySelectorAll('.mask-btn').forEach(b=>b.classList.remove('on'));
 if(btn)btn.classList.add('on');
 const fr=E('maskFreqRow');if(fr)fr.style.display=(type==='rain'||type==='pink')?'':'none';
 if(this.maskRunning){
 if(this.maskSrcNode){try{this.maskSrcNode.stop();}catch(e){}}
 const freq=parseInt(E('maskFreqSlider')?.value||1200);
 this.applyFilter(this.maskFilterNode,this.maskNoiseType,freq);
 this.maskSrcNode=this.buildNoise(this.maskCtx,this.maskNoiseType);
 this.maskSrcNode.connect(this.maskFilterNode);
 this.maskSrcNode.start();
 }
 this.saveState();
 }
 updateVolume(v){
 const l=E('maskVolLbl');if(l)l.textContent=v+'%';
 if(this.maskGainNode)this.maskGainNode.gain.value=v/100;
 this.saveState();
 }
 updateFreq(v){
 const l=E('maskFreqLbl');if(l)l.textContent=v+' Hz';
 if(this.maskFilterNode&&(this.maskNoiseType==='rain'||this.maskNoiseType==='pink'))this.maskFilterNode.frequency.value=parseInt(v);
 this.saveState();
 }
 drawLoop(){
 if(!this.maskRunning)return;
 this.maskAnimFrame=requestAnimationFrame(()=>this.drawLoop());
 const cv=E('maskViz');if(!cv||!this.maskAnalyser)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 const data=new Uint8Array(this.maskAnalyser.frequencyBinCount);
 this.maskAnalyser.getByteFrequencyData(data);
 c.clearRect(0,0,w,h);
 const barW=w/data.length*2.5;
 for(let i=0;i<data.length;i++){
 const v=data[i]/255;
 c.fillStyle=`rgba(178,178,178,${0.15+v*0.5})`;
 c.fillRect(i*barW,h-v*h,Math.max(1,barW-1),v*h);
 }
 }
}
const maskingNoise=new MaskingNoise();

function maskToggle(){return maskingNoise.toggle();}
function maskSelectNoise(type,btn){return maskingNoise.selectNoise(type,btn);}
function maskUpdateVolume(v){return maskingNoise.updateVolume(v);}
function maskUpdateFreq(v){return maskingNoise.updateFreq(v);}
maskingNoise.loadState(); // استعادة آخر إعداد (نوع/مستوى/تردد) محفوظ محلياً — بلا تشغيل تلقائي

/* ══════════════════════════════════════════════════════════════════
 SMART BEDTIME — فكرة مُستعادة من ZERO-WAVE-v5.html (toggleBedtime)
 تحسين عن الأصل: الأصل كان يحفظ "الساعة الحالية وقت الضغط" كموعد التشغيل
 (سلوك غير بديهي)، هنا المستخدم يختار الوقت صراحةً عبر<input type="time">
 ويُحفظ محلياً (localStorage) فلا يُفقد بعد إغلاق التطبيق. التشغيل الفعلي
 يستدعي toggleAI({}) — نفس مسار زر التشغيل اليدوي — فيستفيد تلقائياً من
 كل تحسينات المحرك (initAudio، PERSIST، إلخ) دون تكرار منطق التشغيل.

 class تحويل 30 سبتمبر 2026: 4 حقول (bedtimeTimer/bedtimeEnabled/
 bedtimeTime/bedtimeLastFired) + BEDTIME_STORE_KEY + 7 دوال — كلها صفر
 مرجع خارجي (تأكَّد بالتدقيق المزدوج audit+grep) — انضوت في صنف واحد
 BedtimeTimer. toggleBedtime/bedtimeSetTime (onchange في HTML) أبقتا
 غلافين رقيقين بنفس الاسم القديم؛ الباقي طُوي كطرق داخلية محضة.
 ══════════════════════════════════════════════════════════════════ */
class BedtimeTimer{
 constructor(){
 this.bedtimeTimer=null;this.bedtimeEnabled=false;this.bedtimeTime='23:00';this.bedtimeLastFired=null;
 this.BEDTIME_STORE_KEY='zero_bedtime_v1';
 }
 saveState(){try{localStorage.setItem(this.BEDTIME_STORE_KEY,JSON.stringify({enabled:this.bedtimeEnabled,time:this.bedtimeTime}));}catch(e){}}
 loadState(){
 try{
 const raw=localStorage.getItem(this.BEDTIME_STORE_KEY);
 if(raw){
 const d=JSON.parse(raw);
 this.bedtimeTime=d.time||'23:00';
 this.bedtimeEnabled=!!d.enabled;
 const inp=E('bedtimeTimeInp');if(inp)inp.value=this.bedtimeTime;
 const sw=E('sw-bedtime');if(sw)sw.checked=this.bedtimeEnabled;
 this.updateStatus();
 if(this.bedtimeEnabled)this.start();
 }
 }catch(e){}
 }
 updateStatus(){
 const el=E('bedtime-status');if(!el)return;
 el.textContent=this.bedtimeEnabled?(' مُفعّل — سيُشغَّل المحرك تلقائياً عند '+this.bedtimeTime+' يومياً'):'■ متوقف — فعّل المفتاح لجدولة تشغيل تلقائي';
 }
 toggle(chk){
 this.bedtimeEnabled=!!chk.checked;
 this.saveState();this.updateStatus();
 if(this.bedtimeEnabled)this.start();else this.stop();
 if(typeof zVibrate==='function')zVibrate(6);
 }
 setTime(v){
 if(!v)return;
 this.bedtimeTime=v;this.saveState();this.updateStatus();
 if(this.bedtimeEnabled){this.stop();this.start();}
 }
 start(){
 if(this.bedtimeTimer)clearInterval(this.bedtimeTimer);
 this.bedtimeTimer=setInterval(()=>{
 const now=new Date();
 const hh=String(now.getHours()).padStart(2,'0'),mm=String(now.getMinutes()).padStart(2,'0');
 const stamp=now.toDateString()+' '+hh+':'+mm;
 if((hh+':'+mm)===this.bedtimeTime&&!appState.isRun&&this.bedtimeLastFired!==stamp){
 this.bedtimeLastFired=stamp;
 toggleAI({});
 if(typeof stLog==='function')stLog(' Smart Bedtime: تشغيل تلقائي عند '+this.bedtimeTime);
 }
 },15000);
 }
 stop(){if(this.bedtimeTimer){clearInterval(this.bedtimeTimer);this.bedtimeTimer=null;}}
}
const smartBedtime=new BedtimeTimer(); // اسم مختلف عمداً عن الحقل الداخلي this.bedtimeTimer (مقبض setInterval) تفادياً لالتباس القراءة

function toggleBedtime(chk){return smartBedtime.toggle(chk);}
function bedtimeSetTime(v){return smartBedtime.setTime(v);}
smartBedtime.loadState();

/* ══════════════════════════════════════════════════════════════════
 مؤقت النوم (Sleep Timer) — فكرة مُستعادة من ZERO-WAVE-v5.html (toggleSleep/
 setTimer). عدّ تنازلي يدوي: يشغّل المحرك الآن (إن لم يكن يعمل) لمدة محددة،
 ثم يوقفه تلقائياً عند الصفر — يتكامل مع "وضع النوم الذكي" أعلاه (ذاك يبدأ
 عند وقت ثابت يومياً، وهذا يوقف بعد مدة من بدء النوم الفعلي). إلغاء العد
 يدوياً (زر الإيقاف قبل الصفر) لا يوقف المحرك نفسه — فقط يلغي جدولة
 الإيقاف التلقائي، بالضبط كسلوك toggleSleep() الأصلي.

 class تحويل 30 سبتمبر 2026: 4 حقول (sleepTimerId/sleepSecLeft/
 sleepMinutesSel/sleepRunning) + SLEEP_STORE_KEY + 8 دوال — كلها صفر
 مرجع خارجي (تأكَّد بالتدقيق المزدوج audit+grep) — انضوت في صنف واحد
 SleepTimer. sleepSetMinutes/sleepToggle (أزرار onclick في HTML) أبقتا
 غلافين رقيقين بنفس الاسم القديم؛ الباقي طُوي كطرق داخلية محضة.
 ══════════════════════════════════════════════════════════════════ */
class SleepTimer{
 constructor(){
 this.sleepTimerId=null;this.sleepSecLeft=0;this.sleepMinutesSel=30;this.sleepRunning=false;
 this.SLEEP_STORE_KEY='zero_sleeptimer_v1';
 }
 saveState(){try{localStorage.setItem(this.SLEEP_STORE_KEY,JSON.stringify({minutes:this.sleepMinutesSel}));}catch(e){}}
 loadState(){
 try{
 const raw=localStorage.getItem(this.SLEEP_STORE_KEY);
 if(raw){
 const d=JSON.parse(raw);
 if(d.minutes){
 this.sleepMinutesSel=d.minutes;
 document.querySelectorAll('.sleep-preset-btn').forEach(b=>{
 b.classList.toggle('sel',b.textContent.trim()===this.sleepMinutesSel+' د');
 });
 }
 }
 }catch(e){}
 }
 setMinutes(m,btn){
 if(this.sleepRunning)return; // لا تغيير المدة أثناء عدّ فعلي جارٍ
 this.sleepMinutesSel=m;
 document.querySelectorAll('.sleep-preset-btn').forEach(b=>b.classList.remove('sel'));
 if(btn)btn.classList.add('sel');
 this.saveState();
 }
 fmt(s){const m=Math.floor(s/60),ss=s%60;return String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0');}
 updateDisplay(){const d=E('sleepTimerDisp');if(d)d.textContent=this.fmt(this.sleepSecLeft);}
 toggle(){if(this.sleepRunning)this.stop();else this.start();}
 start(){
 this.sleepSecLeft=this.sleepMinutesSel*60;
 this.sleepRunning=true;
 if(!appState.isRun)toggleAI({});
 const d=E('sleepTimerDisp');if(d)d.style.display='block';
 this.updateDisplay();
 const btn=E('sleepTimerBtn');if(btn){btn.textContent='إيقاف المؤقت';btn.classList.add('run');}
 if(typeof stLog==='function')stLog(' مؤقت النوم: '+this.sleepMinutesSel+' دقيقة');
 if(typeof zVibrate==='function')zVibrate(6);
 this.sleepTimerId=setInterval(()=>{
 this.sleepSecLeft--;
 this.updateDisplay();
 if(this.sleepSecLeft<=0){
 this.stop();
 if(appState.isRun)toggleAI({});
 if(typeof stLog==='function')stLog(' مؤقت النوم: انتهت المدة — تم إيقاف المحرك تلقائياً');
 }
 },1000);
 }
 stop(){
 if(this.sleepTimerId){clearInterval(this.sleepTimerId);this.sleepTimerId=null;}
 this.sleepRunning=false;
 const d=E('sleepTimerDisp');if(d)d.style.display='none';
 const btn=E('sleepTimerBtn');if(btn){btn.textContent='بدء مؤقت النوم';btn.classList.remove('run');}
 }
}
const sleepTimer=new SleepTimer();

function sleepSetMinutes(m,btn){return sleepTimer.setMinutes(m,btn);}
function sleepToggle(){return sleepTimer.toggle();}
sleepTimer.loadState();

/* ══════════════════════════════════════════════════════════════════
 فيزياء الإلغاء (Cancellation Physics) — تصوّر تعليمي مُستعاد من
 zero-wave-anc.html/zero-wave-complete.html (drawFanWave/drawAntiWave/
 drawNullWave). الأصل نفسه كان يرسم "الموجة المضادة" كانعكاس تخطيطي
 لنفس عيّنة الميكروفون (وليس بالتقاط مسار صوت منفصل فعلي) — نفس المبدأ
 محفوظ هنا حرفياً. أما "الموجة الصفرية" فتُحسَب هنا عبر استدعاء دالة
 sfEff() الموجودة فعلاً في محرك الرسم الرئيسي (بدل تكرار حساب جديد) —
 فلا تُضاف أي معادلة إلغاء صوت جديدة، هذه طبقة عرض فقط تقرأ من نفس
 المحلّل (ana) الحي دون أي مصدر/التقاط صوت إضافي ودون لمس خط أنابيب DSP.
 ══════════════════════════════════════════════════════════════════ */
window.physAnimFrame=null;
function physDrawWave(canvasId,data,color){
 const cv=E(canvasId);if(!cv)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 c.clearRect(0,0,w,h);
 c.beginPath();c.strokeStyle=color;c.lineWidth=1.5;
 const pts=Math.min(data.length,Math.max(64,Math.floor(w)));
 const stride=Math.max(1,Math.floor(data.length/pts));
 const stepX=w/pts;let x=0,n=0;
 for(let i=0;i<data.length&&n<pts;i+=stride,n++){
 const v=(data[i]-128)/128;const y=h/2-(v*h*0.42);
 if(n===0)c.moveTo(x,y);else c.lineTo(x,y);
 x+=stepX;
 }
 c.stroke();
}
function physDrawLoop(){
 if(!appState.physOpen){physAnimFrame=null;return;}
 physAnimFrame=requestAnimationFrame(physDrawLoop);
 if(!appState.ana||!appState.isRun)return;
 const td=new Uint8Array(appState.ana.fftSize);
 appState.ana.getByteTimeDomainData(td);
 // ① الموجة الأصلية — من الميكروفون مباشرة
 physDrawWave('physFanCv',td,'#707070');
 const fs=E('physFanStat');if(fs)fs.textContent=appState.fanFreq>0?appState.fanFreq.toFixed(0)+' Hz':'— Hz';
 // ② الموجة المضادة — انعكاس تخطيطي 180° لنفس العيّنة (تصوّر تعليمي)
 const anti=new Uint8Array(td.length);
 for(let i=0;i<td.length;i++)anti[i]=Math.max(0,Math.min(255,256-td[i]));
 physDrawWave('physAntiCv',anti,'#9a9a9a');
 const asEl=E('physAntiStat');if(asEl)asEl.textContent=INV.active.size+' نشِط';
 // ③ الموجة الصفرية — نفس sfEff() المستخدَمة فعلياً في drawLoop() الرئيسية (بلا حساب جديد)
 const nullW=sfEff(td);
 physDrawWave('physNullCv',nullW,'#a5a5a5');
 let rms=0;for(let i=0;i<nullW.length;i++){const v=(nullW[i]-128)/128;rms+=v*v;}
 rms=Math.sqrt(rms/nullW.length);
 const ns=E('physNullStat');if(ns)ns.textContent=rms<0.015?'≈ 0':rms.toFixed(3);
}

/* محاكاة تفاعلية رياضية بحتة — بلا صوت وبلا محرك حي، تعمل بمجرد فتح اللوحة (زر تجريبي تعليمي) */
let physSimPhase=180;
function physSimUpdatePhase(v){
 physSimPhase=+v;
 const lbl=E('physSimPhaseLbl');if(lbl)lbl.textContent=v+'°';
 physSimDraw();
}
function physSimDraw(){
 const cv=E('physSimCv');if(!cv)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 c.clearRect(0,0,w,h);
 const phi=physSimPhase*Math.PI/180,cycles=3,N=200,step=w/N;
 // الموجة الأصلية (وهمية — تمثيل تعليمي)
 c.beginPath();c.strokeStyle='#707070';c.lineWidth=1.5;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI,y=h*0.28-Math.sin(t)*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
 // الموجة المضادة (بفارق الطور المُختار)
 c.beginPath();c.strokeStyle='#9a9a9a';c.lineWidth=1.5;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI,y=h*0.28-Math.sin(t+phi)*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
 // المحصّلة (الناتج الفعلي بعد الجمع)
 c.beginPath();c.strokeStyle='#a5a5a5';c.lineWidth=2;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI;const sum=Math.sin(t)+Math.sin(t+phi);const y=h*0.75-sum*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
}
physSimDraw();

window.maskingNoise=maskingNoise; window.maskToggle=maskToggle; window.maskSelectNoise=maskSelectNoise;
window.maskUpdateVolume=maskUpdateVolume; window.maskUpdateFreq=maskUpdateFreq; window.smartBedtime=smartBedtime;
window.toggleBedtime=toggleBedtime; window.bedtimeSetTime=bedtimeSetTime; window.sleepTimer=sleepTimer;
window.sleepSetMinutes=sleepSetMinutes; window.sleepToggle=sleepToggle; window.physAnimFrame=physAnimFrame;
window.physDrawWave=physDrawWave; window.physDrawLoop=physDrawLoop; window.physSimPhase=physSimPhase;
window.physSimUpdatePhase=physSimUpdatePhase; window.physSimDraw=physSimDraw;

})();
/* ── 13-zero-integration-aicore.js ── */

'use strict';
(function(){


/* ══════════════════════════════════════════════════════════════════
 ZERO-v25 INTEGRATION LAYER (مُدمَج الآن داخل index.html نفسه)
 ──────────────────────────────────────────────────────────────────
 طبقة تكامل ZERO-v25: كل ما يمثّل تعامل التطبيق مع تطبيق ZERO-v25
 الأصلي (خدمة الخلفية، الشاشة، الإشعارات) + نواة AI الموحّدة (AICore).

 كان يُحمَّل سابقاً كملف zero-core.js منفصل بعد index.html مباشرة؛ الآن
 وسم<script>مستقل ثانٍ في نفس الملف، بنفس ترتيب التنفيذ تماماً —
 يستخدم كل ثوابت/دوال المحرك المعرَّفة أعلاه (E، isRun، AI_BAN، ...)
 دون تكرارها. الفصل معماري فقط (توثيقي)، لا تنفيذي: index.html بالكامل
 الآن = واجهة المستخدم + محرك الكشف/DSP + تكامل ZERO-v25 + نواة AI،
 في ملف واحد فقط.

 لم يتغيّر أي سطر منطقي هنا عن نسخته داخل index.html — نقل حرفي فقط.
 ══════════════════════════════════════════════════════════════════ */

/* ════════════════════════════════════════════════════
 BACKGROUND MODE — 5-Layer System
 ① Wake Lock — screen stays on, no sleep
 ② Web Worker — precision timer, not throttled
 ③ Service Worker — keep-alive heartbeat
 ④ Notification — live status when tab is hidden
 ⑤ Visibility API — detects + handles bg transitions
════════════════════════════════════════════════════ */

window.bgEnabled=true;window.bgMode=false;let bgStartT=0;window.bgRuns=0;window.bgTotalMs=0;let bgNotifN=0;
const BG_LOG=[];

function bgLog(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 BG_LOG.unshift({msg,t});if(BG_LOG.length>30)BG_LOG.pop();
 if(curTab===6){const el=E('bg-log');if(el)el.innerHTML=BG_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.4)">${l.t}</span> ${l.msg}</div>`).join('');}
 logNN(' BG: '+msg);
}

/* ═══════════════
 ① WAKE LOCK
═══════════════ */
let wakeLock=null,wlOk=false;
// إغلاق الفراغات — نفس نمط سباق initAudio(): reqWL() لها 4 مصادر استدعاء مستقلة تماماً
// (startAll، _exitBG عند العودة من الخلفية، toggleBGMode بلا await، وتجديدها الذاتي أدناه) —
// ولم يكن لها أي حارس تكرار إطلاقاً. wakeLock يبقى null طوال await navigator.wakeLock.
// request(...)؛ نداءان متزامنان (مثلاً toggleBGMode ضُغط مرتين، أو تزامن مع تجديد ذاتي) كانا
// يُنشئان WakeLockSentinel جديدين، وآخر واحد يكتمل يكتب فوق wakeLock العام فيُضيع مرجع الأقدم
// إلى الأبد (لا يمكن استدعاء release() عليه بعدها). كما أن معالج 'release' كان يفحص isRun
// لحظة وقوع الحدث فقط لا لحظة تنفيذ setTimeout بعد ثانية — فقد يُعاد طلب قفل شاشة جديد بعد أن
// يكون المستخدم قد ضغط "إيقاف" فعلاً خلال تلك الثانية، فيبقى القفل عالقاً حياً للأبد رغم التوقف.
let _wlReqPromise=null;
async function reqWL(){
 if(wakeLock)return;
 if(_wlReqPromise)return _wlReqPromise;
 if(!('wakeLock' in navigator)){wlOk=false;updBGUI();return;}
 _wlReqPromise=(async()=>{
 try{
 wakeLock=await navigator.wakeLock.request('screen');
 wlOk=true;
 wakeLock.addEventListener('release',()=>{
 wlOk=false;wakeLock=null;updBGUI();
 // فحص isRun عند التنفيذ الفعلي بعد ثانية، لا عند وقوع الحدث — يمنع تجديداً عالقاً
 // بعد أن يكون المستخدم قد أوقف التطبيق فعلاً خلال هذه الثانية.
 setTimeout(()=>{if(appState.isRun&&!document.hidden)reqWL();},1000);
 });
 updBGUI();bgLog(' Wake Lock acquired — screen stays on');
 }catch(e){wlOk=false;updBGUI();bgLog(' Wake Lock denied: '+e.message);}
 finally{_wlReqPromise=null;}
 })();
 return _wlReqPromise;
}

function relWL(){
 if(wakeLock){wakeLock.release();wakeLock=null;wlOk=false;updBGUI();bgLog(' Wake Lock released');}
}

/* ═══════════════════════════
 ② WEB WORKER — precision timer
 Not throttled when tab hidden
═══════════════════════════ */
const WK_CODE=`
'use strict';
let ti=null,cyc=0;
self.onmessage=function(e){
 const{type,data}=e.data||{};
 if(type==='start'){
 cyc=data.cyc||0;
 if(ti)clearInterval(ti);
 ti=setInterval(()=>{
 cyc++;
 self.postMessage({type:'tick',cyc});
 },350);
 self.postMessage({type:'ready'});
 }else if(type==='sync'){
 cyc=data.cyc||cyc;
 }else if(type==='stop'){
 if(ti)clearInterval(ti);
 ti=null;
 self.postMessage({type:'stopped'});
 }
};
`;
let bgWorker=null,wkOk=false;window.wkCycs=0;

function startBGWorker(){
 if(bgWorker)return;
 try{
 const blob=new Blob([WK_CODE],{type:'application/javascript'});
 const url=URL.createObjectURL(blob);
 bgWorker=new Worker(url);
 bgWorker.onmessage=function(e){
 const{type,cyc}=e.data;
 if(type==='ready'){wkOk=true;updBGUI();}
 else if(type==='tick'){
 wkCycs=cyc;
 // Keep AI engine running even when hidden
 if(appState.isRun&&appState.ana){
 appState.aiCyc=cyc;
 // AudioContext + AnalyserNode continue in background
 if(NN.w1){
 const inp=nnInp();
 const{out}=nnFwd(inp);
 nnCtrlSF(out);
 // Train every 4 worker cycles
 if(cyc%4===0){const rw=appState.silSc>50?(appState.silSc-50)/50:-0.1;nnTrain(inp,rw);}
 }
 // Update bg badge if visible
 if(!document.hidden)syncBGUI();
 else{const bt=E('bgBadgeTxt');if(bt)bt.textContent='BG '+appState.silSc+'%';}
 }
 }
 else if(type==='stopped'){wkOk=false;updBGUI();}
 };
 bgWorker.postMessage({type:'start',data:{cyc:appState.aiCyc}});
 bgLog(' Web Worker started — unthrottled timer running');
 }catch(err){wkOk=false;updBGUI();bgLog(' Worker error: '+err.message);}
}

function stopBGWorker(){
 if(bgWorker){bgWorker.postMessage({type:'stop'});bgWorker.terminate();bgWorker=null;wkOk=false;updBGUI();}
}

/* ═══════════════════════════
 ③ SERVICE WORKER — keep-alive
═══════════════════════════ */
let swOk=false,swReg=null,swT=null;

async function regSW(){
 if(!('serviceWorker' in navigator)){updBGUI();return;}
 const SW=`
self.addEventListener('message',e=>{
 if(e.data==='keepalive'){
 self.clients.matchAll({includeUncontrolled:true}).then(cls=>{
 cls.forEach(c=>c.postMessage({type:'swPing',t:Date.now()}));
 });
 }
});
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
 `;
 try{
 const blob=new Blob([SW],{type:'application/javascript'});
 const swURL=URL.createObjectURL(blob);
 // Try to register — may fail due to blob: scope restrictions
 try{
 swReg=await navigator.serviceWorker.register(swURL,{scope:location.pathname||'/'});
 swOk=true;
 navigator.serviceWorker.addEventListener('message',e=>{
 if(e.data&&e.data.type==='swPing')bgLog(' SW heartbeat: '+new Date(e.data.t).toLocaleTimeString());
 });
 bgLog(' Service Worker registered — keep-alive active');
 }catch(e2){
 // SW can't use blob: URL scope — that's OK, worker covers timing
 swOk=false;
 bgLog(' SW: using Worker fallback (blob scope restriction)');
 }
 // إغلاق الفراغات — نفس نمط تسرب regSW(): كان swT=setInterval(...) يُعاد تعيينه دون تصفية
 // المؤقّت السابق أولاً. toggleBGMode() (المُفعِّل الحقيقي لـ regSW()) غير محمي من التكرار —
 // ضغطتان سريعتان عليه تستدعيان regSW() مرتين، فينشأ مؤقّتا نبض (25 ثانية) بدلاً من واحد،
 // ويُفقد المرجع إلى الأول تماماً (لا يمكن لـ stopSW() تصفيته بعد الآن، لأنها تصفّي فقط swT
 // الحالي)، فيبقى يعمل للأبد حتى بعد إيقاف التطبيق فعلياً — نفس نمط initAudio()/reqWL() تماماً.
 if(swT)clearInterval(swT);
 // Heartbeat every 25s regardless
 swT=setInterval(()=>{
 if(appState.isRun){
 // Keep page active via storage ping
 try{localStorage.setItem('zero-heartbeat',Date.now());}catch(e){}
 if(swReg&&swReg.active)swReg.active.postMessage('keepalive');
 }
 },25000);
 updBGUI();
 }catch(e){swOk=false;updBGUI();bgLog(' SW init failed');}
}

function stopSW(){
 if(swT){clearInterval(swT);swT=null;}
 if(swReg&&swReg.active){try{swReg.unregister();}catch(e){}}
 swOk=false;updBGUI();
}

/* ═══════════════════════════
 ④ NOTIFICATION SYSTEM
═══════════════════════════ */
let notifPerm='default',bgNotif=null,notifRefT=null;

async function reqNotifPerm(){
 if(!('Notification' in window)){updBGUI();return;}
 if(Notification.permission!=='default'){notifPerm=Notification.permission;updBGUI();return;}
 notifPerm=await Notification.requestPermission();
 updBGUI();
 bgLog(' Notification permission: '+notifPerm);
}

function showBGNotif(){
 // عندما يعمل التطبيق داخل ZERO-v25 الأصلي، الإشعار الدائم لـBgService كافٍ وحده —
 // إظهار إشعار متصفح موازٍ هنا كان يُنتج إشعارين متزامنين (تدخل في عمل ZERO-v25)
 if(typeof ZeroAndroid!=='undefined')return;
 if(notifPerm!=='granted'||!appState.isRun)return;
 const body=`Silence: ${appState.silSc}% · Cycle: ${appState.aiCyc} · FreqDB: ${freqDB.size} freqs · NN trained: ${NN.trainN}`;
 if(bgNotif){try{bgNotif.close();}catch(e){}}
 try{
 bgNotif=new Notification('ZERO AI v25 — Running in Background',{
 body,tag:'zero-v25-active',silent:true,requireInteraction:false
 });
 bgNotif.onclick=()=>{window.focus();if(bgNotif)bgNotif.close();bgNotif=null;};
 bgNotifN++;updBGUI();
 // Refresh notification every 15s while in background
 if(notifRefT)clearInterval(notifRefT);
 notifRefT=setInterval(()=>{
 if(document.hidden&&appState.isRun)showBGNotif();
 else{closeBGNotif();}
 },15000);
 }catch(e){bgLog(' Notification blocked: '+e.message);}
}

function closeBGNotif(){
 if(bgNotif){try{bgNotif.close();}catch(e){}bgNotif=null;}
 if(notifRefT){clearInterval(notifRefT);notifRefT=null;}
}

/* ═══════════════════════════
 ⑤ BACKGROUND TRANSITIONS
 المصدر الأساسي: خطافات ZERO-v25 الأصلية — window.onAppBackground/onAppForeground
 (يستدعيها MainActivity.onPause/onResume فعلياً؛ كانت موجودة في الجسر الأصلي
 ولم يكن index.html يستمع لها إطلاقاً، ويعيد اكتشاف الخلفية بنفسه عبر
 Page Visibility API بشكل مواز — هذا هو "التدخل" الذي صُحح هنا).
 المصدر الاحتياطي: Page Visibility API — فقط عند غياب تطبيق ZERO-v25 الأصلي.
═══════════════════════════ */
function _enterBG(){
 if(!appState.isRun)return;
 bgMode=true;bgStartT=Date.now();bgRuns++;
 if(bgWorker)bgWorker.postMessage({type:'sync',data:{cyc:appState.aiCyc}});
 showBGNotif(); // لا يفعل شيئاً فعلياً داخل ZERO-v25 الأصلي (مُحصَّن أعلاه) — يعمل بوضع المتصفح فقط
 const ban=E('bgBanner');if(ban)ban.classList.add('on');
 const badge=E('bgBadge');if(badge)badge.classList.add('on');
 if(appState.drawId){cancelAnimationFrame(appState.drawId);appState.drawId=null;}
 bgLog(`→ BACKGROUND: run #${bgRuns} started`);
 updBGUI();
}
function _exitBG(){
 if(bgMode){
 const elapsed=Date.now()-bgStartT;
 bgTotalMs+=elapsed;
 bgMode=false;
 bgLog(`← FOREGROUND: back after ${(elapsed/1000).toFixed(1)}s · total bg: ${(bgTotalMs/1000).toFixed(0)}s`);
 }
 closeBGNotif();
 const ban=E('bgBanner');if(ban)ban.classList.remove('on');
 if(wkCycs>appState.aiCyc)appState.aiCyc=wkCycs;
 // إعادة WakeLock الويب فقط بوضع المتصفح — داخل ZERO-v25 الأصلي الشاشة تُدار عبر setKeepScreenOn
 if(typeof ZeroAndroid==='undefined'&&appState.isRun&&!wlOk&&bgEnabled)reqWL();
 if(appState.isRun&&!appState.drawId)drawLoop();
 updBGUI();syncBGUI();
}
// يُستدعى فعلياً من MainActivity.onPause()/onResume() عبر evaluateJavascript —
// هذا هو المصدر الصحيح والموثوق لانتقال الخلفية داخل ZERO-v25 الأصلي
window.onAppBackground=function(){_enterBG();};
window.onAppForeground=function(){_exitBG();};
// احتياطي لوضع المتصفح فقط (بدون تطبيق ZERO-v25 الأصلي، لا خطافات أصلية متاحة)
document.addEventListener('visibilitychange',()=>{
 if(typeof ZeroAndroid!=='undefined')return;
 if(document.hidden)_enterBG();else _exitBG();
});

/* ═══════════════════════════
 BACKGROUND MODE CONTROL
═══════════════════════════ */
function toggleBGMode(){
 bgEnabled=!bgEnabled;
 const btn=E('bg-toggle');
 if(btn){btn.className='bg-tgl'+(bgEnabled?'':' off');btn.textContent='BG MODE: '+(bgEnabled?'ON':'OFF');}
 if(bgEnabled&&appState.isRun){
 if(typeof ZeroAndroid!=='undefined'){
 try{ZeroAndroid.setKeepScreenOn(true);}catch(e){}
 startBGWorker();
 }else{
 reqWL();startBGWorker();regSW();reqNotifPerm();
 }
 bgLog(' Background mode ENABLED');
 }else{
 if(typeof ZeroAndroid!=='undefined'){try{ZeroAndroid.setKeepScreenOn(false);}catch(e){}}
 relWL();stopBGWorker();stopSW();closeBGNotif();
 bgLog(' Background mode DISABLED');
 }
 updBGUI();
}

function hideBgBanner(){const el=E('bgBanner');if(el)el.classList.remove('on');}
function openBGTab(){openAIP();setTimeout(()=>openTab(6),80);}

/* ═══════════════════════════
 BG UI UPDATE
═══════════════════════════ */
function updBGUI(){
 // System status badges
 const wl=E('bg-wl');if(wl){wl.className='sy'+(wlOk?' ok':' warn');wl.innerHTML='<div class="syd"></div>WakeLock'+(wlOk?' ✓':' ✗');}
 const wk=E('bg-wk');if(wk){wk.className='sy'+(wkOk?' ok':' warn');wk.innerHTML='<div class="syd"></div>Worker'+(wkOk?' ✓':' ✗');}
 const sw2=E('bg-sw');if(sw2){sw2.className='sy'+(swOk?' ok':' warn');sw2.innerHTML='<div class="syd"></div>SW'+(swOk?' ✓':' ✗');}
 const nf=E('bg-nf');if(nf){const p=notifPerm;nf.className='sy'+(p==='granted'?' ok':p==='denied'?' err':' warn');nf.innerHTML='<div class="syd"></div>Notif'+(p==='granted'?' ✓':p==='denied'?' ✗':' ?');}
 // Stats
 const br=E('bg-runs');if(br)br.textContent=bgRuns;
 const bm=E('bg-ms');if(bm)bm.textContent=bgTotalMs>0?(bgTotalMs/1000).toFixed(0)+'s':'—';
 const bwk=E('bg-wkc');if(bwk)bwk.textContent=wkCycs>0?wkCycs:'—';
 const bn=E('bg-notifs');if(bn)bn.textContent=bgNotifN;
 // Log
 if(curTab===6){const el=E('bg-log');if(el&&BG_LOG.length)el.innerHTML=BG_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.4)">${l.t}</span> ${l.msg}</div>`).join('');}
 // Topbar badge
 const badge=E('bgBadge');if(badge)badge.className='bg-badge'+(bgMode&&appState.isRun?' on':'');
}

function syncBGUI(){
 updBGUI();
 const bbtxt=E('bgBTxt');if(bbtxt)bbtxt.textContent=`Background · Silence: ${appState.silSc}% · Cycle: ${appState.aiCyc} · FreqDB: ${freqDB.size} · NN: ${NN.trainN}`;
 const btxt=E('bgBadgeTxt');if(btxt)btxt.textContent=bgMode?'BG '+appState.silSc+'%':'BG';
}

/* BG + Storage hooks integrated into startAll/stopAll */

// Periodic BG UI sync every 5s
setInterval(()=>{if(appState.isRun)syncBGUI();},5000);

// Initial UI state
updBGUI();
bgLog(' ZERO AI v25 · Background system ready');

/* ═══════════════════════════════════════════════════════════════
 نواة AI — AI CORE
 تجميع معماري لكل أفكار ومنطق ZERO AI v25 (ANC/ENC) في واجهة واحدة.
 هذه واجهة إضافية (façade) فقط — لا تُنقل أي شيفرة فعلياً ولا تُعاد
 كتابتها؛ كل خوارزمية ودالة مختبَرة تبقى كما هي في مكانها الأصلي.
 AICore يوفّر نقطة وصول موحّدة لحالتها ولإجراءاتها كي تُقرأ كـ"نواة"
 واحدة متكاملة، تماماً كما طُلب: تجميع الأفكار والنوافذ السابقة
 (والتي أصبحت الآن نوافذ زجاجية فوق هذه النواة) ضمن نواة AI واحدة.
 ═══════════════════════════════════════════════════════════════ */
const AICore={
 meta:{name:'ZERO AI v25 Core',build:'ANC/ENC',desc:'نواة موحّدة تجمع محرك الكشف، التصنيف، حظر الترددات، مراقبة التداخل، والمراقبة الحرارية/البيئية للجهاز'},

 // ── الحالة الحية (state) — مراجع مباشرة لهياكل البيانات الفعلية،
 // أي تعديل هنا هو نفسه التعديل على الأصل (Map/Object بالمرجع)
 state:{
 get KF(){return KF}, // مرشّح كالمان لتتبّع التردد
 get AI_BAN(){return AI_BAN}, // خريطة الترددات المحظورة (دائم)
 get AI_GATE(){return AI_GATE}, // بوابة الحظر التلقائي
 get THERMAL(){return THERMAL}, // مراقبة حرارة الجهاز
 get PERSIST(){return PERSIST}, // طبقة الحفظ (IndexedDB/localStorage)
 get INTERFERENCE_BAN(){return INTERFERENCE_BAN}, // مراقبة التداخل بين الترددات
 get freqDB(){return freqDB}, // قاعدة بيانات الترددات المرصودة
 get ENV_FP(){return ENV_FP}, // البصمة البيئية
 get SESSION_STAT(){return SESSION_STAT}, // إحصائيات الجلسة
 get NN(){return NN}, // الشبكة العصبية للتصنيف
 // قيم لحظية (أعداد/منطقية) — getters لضمان قراءة القيمة الحيّة دوماً
 get isOn(){return appState.isOn},
 get isRun(){return appState.isRun},
 get execCyc(){return execCyc},
 get aiCyc(){return appState.aiCyc},
 get silSc(){return appState.silSc},
 },

 // ── الإجراءات (actions) — مراجع للدوال الفعلية المختبَرة، بلا تكرار للمنطق
 actions:{
 toggleAI:(e)=>toggleAI(e), // تشغيل/إيقاف محرك AI
 startAll:()=>startAll(),
 stopAll:()=>stopAll(),
 banFreq:(hz,reason,opts)=>banFreq(hz,reason,opts), // حظر تردد يدوياً من الداخل
 unbanFreq:(hz)=>unbanFreq(hz), // رفع حظر تردد
 toggleAllPermBans:()=>toggleAllPermBans(), // تفعيل/إيقاف كل الحظر الدائم
 checkInterference:(hz)=>checkInterference(hz), // فحص تداخل تردد جديد
 dmRefresh:()=>dmRefresh(), // تحديث مراقبة الجهاز
 saveSession:()=>saveSession(), // حفظ/تصدير الجلسة
 },

 // ── النوافذ (windows) — كل نافذة زجاجية تفتح/تغلق فوق النواة نفسها
 windows:{
 menu:{open:()=>openMenu(),close:()=>closeMenu()}, // القائمة الرئيسية (تجمع كل النوافذ أدناه)
 aiBrain:{open:()=>openAIP(),close:()=>closeAIP()}, // دماغ AI (FreqDB/NN/سجلات)
 pipeline:{open:()=>openPipe(),close:()=>closePipe()}, // Pipeline — حالة الخوارزميات اللحظية
 deviceMonitor:{open:()=>openDevMon(),close:()=>closeDevMon()}, // مراقبة الجهاز
 terminal:{open:()=>openTerm(),close:()=>(typeof closeTerm!=='undefined'?closeTerm():null)}, // الطرفية
 settings:{open:()=>openSheet(),close:()=>closeSheet()}, // الإعدادات
 permissions:{open:()=>openZPPanel(),close:()=>closeZPPanel()}, // الأذونات
 closeAll:()=>closeAll(),
 },
};
// كل الأفكار والنوافذ والتفرّعات السابقة مجمّعة الآن داخل AICore —
// الواجهة الرئيسية تضم فقط: زر التشغيل + حضر الترددات الدائمة.
// بقية الأقسام (دماغ AI · Pipeline · مراقبة الجهاز · الطرفية · الإعدادات · الأذونات)
// جُمعت في نافذة القائمة (menuPanel) التي يفتحها زر الهامبرغر أعلى اليسار.
console.log('%c AICore ready','color:#a9a9a9;font-weight:bold',AICore.meta);

/* ══════════════════════════════════════════════════════════════════
 قائمة الحظر المؤكّدة — CONFIRMED BAN PROFILE (جلستان حقيقيتان، مدموجتان)
 ──────────────────────────────────────────────────────────────────
 الدفعة الأولى: 257 تردد + 194 منطقة تداخل (تصدير 2026-09-24 16:27)
 — بعد استبعاد 30 مطابقة لـDEFAULT_BANNED_FREQS: 227 تردد + 194 منطقة.

 الدفعة الثانية: 237 تردد + 171 منطقة تداخل جديدة (تصدير 2026-09-24
 22:28، بعد ~2.5 ساعة استماع فعلي إضافي) — من أصل الـ237، تحقّقنا أن
 34 منها متطابقة أصلاً مع الدفعة الأولى (على الأرجح كان الجهاز وقتها
 يشغّل نسخة أقدم من zero-core.js لم تحتوِ بعد على الدفعة الأولى، فأعاد
 اكتشافها كـ"جديدة")، فاستُبعدت لتفادي التكرار؛ الباقي 203 تردد + 171
 منطقة تداخل حقيقياً جديدة أُضيفت هنا. من ضمنها نطاق ±4Hz حول 158Hz
 (155–162Hz) الذي كان قد صُعِّد فعلياً في التطبيق (منطقة 158Hz مُسجَّلة
 بعدّاد 0 بعد إعادة تعيينه إثر التصعيد) — كل التردد الفردية ضمن ذلك
 النطاق موجودة كإدخالات مستقلة في القائمة أدناه، فالحماية الفعلية
 محفوظة كاملة حتى لو لم يُخزَّن رقم "التوسيع" ±4Hz نفسه هنا (نفس
 المخطط المستخدَم لكل مناطق التداخل الأخرى: hz + count فقط).

 الدفعة الثالثة: 98 تردد + 75 منطقة تداخل جديدة (تصدير 2026-09-25
 00:02، جلسة استماع بتاريخ 2026-09-24 21:02) — كل الـ98/75 تحقّقنا أنها
 جديدة فعلاً (لا تطابق أي شيء في الدفعتين السابقتين ولا DEFAULT_BANNED_FREQS)،
 فأُضيفت كاملة بلا استبعاد. النطاق الجديد بمعظمه امتداد فوق 240.5Hz
 (241–306.5Hz) بالإضافة إلى عدد قليل من الترددات المتفرقة الأعلى
 (449 وحتى 2600.5Hz).

 الدفعة الرابعة: 159 تردد + 113 منطقة تداخل جديدة (تصدير 2026-09-25
 01:23، جلسة استماع بتاريخ 2026-09-24 22:23) — من أصل الـ159، 4 مطابقة
 أصلاً لإدخالات من الدفعة الأولى (128.5/129.5/132/135.5Hz — نفس نمط
 "جهاز بنسخة أقدم" من الدفعات السابقة) فاستُبعدت؛ الباقي 155 تردد
 + 113 منطقة تداخل حقيقياً جديدة أُضيفت. النطاق الجديد يملأ الفجوة بين
 306.5Hz والدفعة السابقة تقريباً حتى ~420Hz بكثافة، مع امتداد متفرق
 حتى 1077.5Hz، إضافة لبضعة ترددات منخفضة (18.5/22.5Hz).

 الإجمالي المدموج الآن: 683 تردد محظور + 553 منطقة تداخل — تُحمَّل
 كخط أساس دائم مع كل تشغيل/تثبيت جديد، بدل الاعتماد فقط على إعادة
 تعلّمها حيّاً من الصفر في كل جلسة.

 index.html يوفّر فقط آلية AI_BAN والعرض العامة (لا علاقة له بأي
 قرار حظر لتردد بعينه) — أما *ما هي الترددات المحظورة فعلياً* فهو
 بيانات تكامل تخص نشر ZERO-v25، لذا تعيش هنا في zero-core.js.
 ══════════════════════════════════════════════════════════════════ */
const CONFIRMED_BANS=[18.5,20,20.5,21,21.5,22,22.5,23,23.5,24,24.5,25,25.5,26,26.5,27,27.5,28,28.5,29,29.5,30,30.5,31,31.5,32,32.5,33,33.5,34,34.5,35,35.5,36,36.5,37,37.5,38,38.5,39,39.5,40,40.5,41,41.5,42,42.5,43,43.5,44,44.5,45,45.5,46,46.5,47,47.5,48,48.5,49,49.5,50.5,51,51.5,52,52.5,53,53.5,54,54.5,55,55.5,56,56.5,57,57.5,58,58.5,59,59.5,60.5,61,61.5,62,62.5,63,63.5,64,64.5,65,65.5,66,66.5,67,67.5,68,68.5,69,69.5,70,70.5,71,71.5,72,72.5,73,73.5,74,74.5,75,75.5,76,76.5,77,77.5,78,78.5,79,79.5,80,80.5,81,81.5,82,82.5,83,83.5,84,84.5,85,85.5,86,86.5,87,87.5,88,88.5,89,89.5,90,90.5,91,91.5,92,92.5,93,93.5,94,94.5,95,95.5,96,96.5,97,97.5,98,98.5,99,99.5,100.5,101,101.5,102,102.5,103,103.5,104,104.5,105,105.5,106,106.5,107,107.5,108,108.5,109,109.5,110,110.5,111,111.5,112,112.5,113,113.5,114,114.5,115,115.5,116,116.5,117,117.5,118,118.5,119,119.5,120.5,121,121.5,122,122.5,123,123.5,124,124.5,125,125.5,126,126.5,127,127.5,128,128.5,129,129.5,130,130.5,131,131.5,132,132.5,133,133.5,134,134.5,135,135.5,136,136.5,137,137.5,138,138.5,139,139.5,140,140.5,141,141.5,142,142.5,143,143.5,144,144.5,145,145.5,146,146.5,147,147.5,148,148.5,149,149.5,150.5,151,151.5,152,152.5,153,153.5,154,154.5,155,155.5,156,156.5,157,157.5,158,158.5,159,159.5,160,160.5,161,161.5,162,162.5,163,163.5,164,164.5,165,165.5,166,166.5,167,167.5,168,168.5,169,169.5,170,170.5,171,171.5,172,172.5,173,173.5,174,174.5,175,175.5,176,176.5,177,177.5,178,178.5,179,179.5,180.5,181,181.5,182,182.5,183,183.5,184,184.5,185,185.5,186,186.5,187,187.5,188,188.5,189,189.5,190,190.5,191,191.5,192,192.5,193,193.5,194,194.5,195,195.5,196,196.5,197,197.5,198,198.5,199,199.5,200.5,201,201.5,202,202.5,203,203.5,204,204.5,205,205.5,206,206.5,207,207.5,208,208.5,209,209.5,210,210.5,211,211.5,212,212.5,213,213.5,214,214.5,215,215.5,216,216.5,217,217.5,218,218.5,219,219.5,220,220.5,221,221.5,222,222.5,223,223.5,224,224.5,225,225.5,226,226.5,227,227.5,228,228.5,229,229.5,230,230.5,231,231.5,232,232.5,233,233.5,234,234.5,235,235.5,236,236.5,237,237.5,238,238.5,239,239.5,240.5,241,241.5,242,242.5,243,243.5,244,244.5,245,245.5,246,246.5,247,247.5,248,248.5,249,249.5,250.5,251,251.5,252,252.5,253,253.5,254,254.5,255,255.5,256,256.5,257,257.5,258,258.5,259,259.5,260,260.5,261,261.5,262,262.5,263,263.5,264,264.5,265,265.5,266,266.5,267,267.5,268,268.5,269,269.5,270,270.5,271,271.5,272,272.5,273,273.5,274,274.5,275,275.5,276,276.5,277,277.5,278,278.5,279,279.5,280.5,281,281.5,282,282.5,283,283.5,284,284.5,285,285.5,286,286.5,287,287.5,288,288.5,289,289.5,290,290.5,291,291.5,292,292.5,293,293.5,294,294.5,295,295.5,296,296.5,297,297.5,298,298.5,299,299.5,300.5,301,301.5,302,302.5,303,303.5,304,304.5,305,305.5,306,306.5,307,307.5,308,308.5,309,309.5,310,310.5,311,311.5,312,312.5,313,313.5,314,314.5,315,315.5,316,316.5,317,317.5,318,318.5,319,319.5,320,320.5,321,321.5,322,322.5,323,323.5,324,324.5,325,325.5,326,326.5,327,327.5,328,328.5,329,329.5,330,331,331.5,332,332.5,333.5,334,334.5,335,336,336.5,337,338.5,340.5,344.5,346,348,350.5,351,351.5,359,360,360.5,361,362,363,368,369,372.5,375.5,380,399,400.5,402,418.5,437,449,451,468.5,478.5,479,479.5,489,500,500.5,541,549.5,550,593.5,599,601.5,649,650,663.5,701,712.5,749.5,750,750.5,780.5,841,922.5,949,950,959,999,1020,1077.5,1079.5,1098.5,1100.5,1255.5,2600.5];
const CONFIRMED_INTERFERENCE=[[19.5,1],[20.5,1],[21,1],[21.5,1],[22,1],[22.5,1],[23.5,1],[24,1],[24.5,1],[25,1],[25.5,1],[26,1],[26.5,1],[27,1],[28,1],[28.5,1],[29,1],[29.5,1],[30,1],[30.5,1],[31,1],[31.5,2],[32.5,1],[33,1],[33.5,1],[34,1],[34.5,1],[35.5,1],[36,1],[36.5,1],[37,1],[37.5,1],[38,1],[38.5,2],[39.5,1],[40,1],[40.5,1],[41.5,1],[42,1],[42.5,1],[43,1],[43.5,1],[44,1],[44.5,1],[45,1],[45.5,1],[46,1],[46.5,1],[47,1],[47.5,1],[48,1],[48.5,1],[49,1],[49.5,1],[50,1],[50.5,2],[51.5,1],[52,1],[52.5,1],[53,1],[53.5,1],[54,1],[54.5,1],[55,1],[55.5,1],[56,1],[56.5,1],[57.5,1],[58,1],[58.5,1],[59,1],[59.5,1],[60,1],[60.5,1],[61,1],[61.5,1],[62,1],[62.5,2],[63.5,1],[64,2],[65.5,1],[66,1],[66.5,1],[67,1],[67.5,1],[68,1],[68.5,2],[69.5,1],[70.5,1],[71,1],[71.5,1],[72,1],[72.5,1],[73,1],[73.5,1],[74,1],[74.5,1],[75,1],[75.5,1],[76,1],[76.5,1],[77,1],[77.5,1],[78,1],[79,1],[79.5,1],[80,1],[80.5,1],[81,2],[82,1],[82.5,1],[83.5,1],[84,1],[84.5,1],[85,1],[86,1],[86.5,1],[87,1],[87.5,1],[88,1],[88.5,1],[89,1],[89.5,1],[90,1],[90.5,1],[91,1],[91.5,1],[92,1],[92.5,1],[93.5,2],[94,1],[94.5,1],[95,1],[95.5,2],[97,1],[97.5,1],[98,1],[98.5,1],[99,1],[99.5,1],[100,1],[100.5,1],[101,1],[101.5,2],[102,1],[103,1],[103.5,1],[104.5,2],[105,1],[105.5,1],[106,2],[107,1],[108,1],[108.5,1],[109,1],[109.5,1],[110.5,2],[111,1],[111.5,1],[112,1],[112.5,1],[113,1],[114,1],[114.5,1],[115,1],[115.5,1],[116,1],[116.5,1],[117,1],[118,1],[118.5,1],[119,1],[119.5,1],[120,1],[120.5,1],[121,1],[121.5,1],[122,1],[122.5,2],[123.5,1],[124,1],[124.5,2],[125.5,1],[126,1],[127,1],[127.5,1],[128,1],[128.5,1],[129,1],[129.5,1],[130,1],[130.5,2],[131.5,1],[132,1],[133,1],[133.5,1],[134,2],[135,1],[135.5,2],[136,1],[136.5,1],[137,1],[137.5,2],[138.5,1],[139,1],[139.5,1],[140,1],[140.5,1],[141,1],[141.5,2],[142.5,1],[143,2],[144,1],[144.5,1],[145.5,1],[146,1],[146.5,1],[147,1],[147.5,1],[148,1],[148.5,1],[149,1],[149.5,1],[150,1],[150.5,2],[151.5,1],[152,2],[153,1],[153.5,2],[154.5,1],[155,2],[155.5,1],[156.5,1],[157,1],[157.5,1],[158,0],[158.5,1],[159,1],[159.5,1],[160.5,1],[161,1],[161.5,1],[162,2],[163,1],[164,1],[164.5,1],[165,1],[165.5,2],[166.5,1],[167,1],[168,1],[168.5,1],[169,1],[169.5,1],[170,1],[170.5,1],[171,1],[171.5,1],[172,1],[172.5,1],[173,1],[173.5,1],[174,1],[174.5,1],[175,1],[175.5,2],[176.5,1],[177.5,1],[178,1],[178.5,1],[179,1],[179.5,1],[180,1],[180.5,2],[181.5,2],[182.5,1],[183,1],[183.5,2],[184.5,2],[185.5,1],[186,1],[186.5,1],[187,2],[188,1],[189,1],[189.5,1],[190,1],[190.5,1],[191,1],[192,1],[192.5,1],[193,1],[193.5,1],[194,1],[194.5,1],[195.5,2],[196,1],[196.5,1],[197,1],[197.5,2],[198.5,1],[199.5,1],[200,1],[200.5,1],[201,1],[201.5,1],[202,1],[202.5,2],[203.5,1],[204,1],[204.5,2],[206,1],[206.5,1],[207,1],[207.5,2],[208.5,1],[209,1],[210,1],[210.5,1],[211,1],[211.5,1],[212,2],[213,1],[213.5,1],[214,2],[215,1],[215.5,1],[216,1],[216.5,1],[217,1],[217.5,1],[218.5,1],[219,1],[219.5,1],[220,1],[220.5,1],[221,1],[221.5,1],[222,1],[222.5,1],[223,1],[223.5,2],[224.5,2],[225.5,1],[226,2],[227,1],[227.5,1],[228,1],[228.5,1],[229,1],[229.5,1],[230,1],[230.5,1],[231,1],[231.5,1],[232,2],[233,1],[233.5,1],[234,1],[234.5,1],[235.5,1],[236,1],[237,1],[237.5,1],[238,1],[238.5,1],[239,1],[239.5,1],[240.5,1],[241,1],[241.5,1],[242,1],[242.5,1],[243,1],[243.5,2],[244,1],[245,1],[245.5,1],[246,1],[247,1],[247.5,1],[248,1],[248.5,1],[249,1],[249.5,1],[250,1],[250.5,1],[251,1],[251.5,1],[252.5,1],[253,1],[253.5,1],[254,1],[255,1],[255.5,1],[256,1],[256.5,1],[257,1],[257.5,1],[258,1],[258.5,1],[259,1],[259.5,1],[260,1],[261,1],[262,1],[262.5,1],[263,1],[263.5,2],[264.5,2],[265.5,1],[266.5,1],[267.5,2],[268,1],[269,2],[270,1],[270.5,1],[271.5,1],[272,1],[272.5,1],[273,1],[273.5,1],[274,1],[274.5,1],[275,1],[275.5,1],[276.5,1],[277,1],[277.5,1],[278,1],[279,1],[279.5,1],[280,1],[280.5,1],[281,1],[281.5,1],[282.5,1],[283,1],[283.5,1],[284,1],[284.5,1],[285.5,1],[286,1],[287,1],[287.5,1],[288.5,1],[289,1],[289.5,1],[290,1],[290.5,1],[291.5,1],[292,1],[293,1],[294,1],[294.5,1],[295,1],[295.5,1],[296,1],[296.5,1],[297,1],[297.5,1],[298,1],[298.5,1],[299,1],[299.5,1],[300.5,2],[301.5,1],[302,1],[302.5,1],[303,1],[303.5,1],[304.5,1],[305,1],[305.5,1],[306,1],[306.5,1],[307,2],[308,1],[308.5,1],[309,1],[309.5,2],[310.5,1],[311.5,1],[312,2],[313,1],[314,1],[314.5,1],[315,1],[315.5,1],[316,1],[316.5,2],[317.5,1],[318,1],[318.5,1],[319,1],[319.5,1],[320,1],[321,1],[321.5,1],[322,1],[322.5,1],[323.5,1],[324,1],[324.5,1],[325,1],[325.5,1],[326,1],[326.5,1],[327.5,1],[328,1],[328.5,1],[329,1],[329.5,1],[330,1],[330.5,1],[331.5,1],[332,1],[332.5,1],[334,1],[334.5,2],[336,1],[336.5,1],[337,1],[339.5,1],[340.5,1],[345.5,1],[347,1],[351,1],[351.5,1],[360,1],[360.5,1],[361,1],[361.5,1],[362.5,1],[368.5,1],[374,1],[399.5,1],[400.5,1],[401,1],[450,1],[479,1],[479.5,1],[500.5,1],[550,1],[599.5,1],[601,1],[649.5,1],[750,1],[750.5,1],[949.5,1],[999.5,1],[1078.5,1],[1099.5,1]];

function loadConfirmedBans(){
 if(typeof AI_BAN==='undefined'||typeof fBin!=='function')return;
 if(typeof PERM_BAN_CATS!=='undefined'&&PERM_BAN_CATS.env)PERM_BAN_CATS.env.enabled=true; // مؤكَّدة فعلياً على الجهاز — الفئة env تُفعَّل
 const reason='مؤكَّد من جلسات استماع حقيقية — 2026-09-24/25 (×4)';
 let added=0;
 CONFIRMED_BANS.forEach(hz=>{
 const bin=fBin(hz);
 if(!AI_BAN.has(bin)){
 // baseline:true — يميّزها كقائمة أساسية مُعاد توليدها في كل تشغيل، فلا
 // تُكرَّر عند حفظ/تصدير الملفات (PERSIST.saveBans و _getBansForExport
 // يركّزان على الجديد فقط ويستبعدان أي مدخل baseline)
 AI_BAN.set(bin,{reason,bannedAt:0,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'env',baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 added++;
 }
 });
 let zonesAdded=0;
 if(typeof INTERFERENCE_BAN!=='undefined'){
 CONFIRMED_INTERFERENCE.forEach(([hz,count])=>{
 const bin=fBin(hz);
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count,widen:0,lastT:0,baseline:true});
 zonesAdded++;
 }
 });
 }
 if(added||zonesAdded){
 if(typeof PERSIST!=='undefined')PERSIST.scheduleSaveBans();
 if(typeof renderBanList==='function')renderBanList();
 if(typeof renderPermSettings==='function')renderPermSettings();
 if(typeof stLog==='function')stLog(' حضر مؤكَّد: '+added+' تردد + '+zonesAdded+' منطقة تداخل مُستعادة (4 جلسات 2026-09-24/25)');
 }
 return{added,zonesAdded};
}
loadConfirmedBans();



/* ── ربط سحب-للإغلاق (drag-to-dismiss) لكل اللوحات ──
 نُقِلت هذه الكتلة إلى هنا (آخر ملف يُحمَّل) أثناء إعادة الهيكلة المعمارية
 (سبتمبر 2026): في الأصل كانت هذه الاستدعاءات (مع كل التعليقات التوضيحية
 الأصلية أدناه) تقع داخل js/04-panels-ui-system.js مباشرة بعد تعريف
 _wireSheetDrag — وكانت تعمل هناك بأمان في الملف الواحد الأصلي لأن كل
 دوال closeXxx (بما فيها closeTerm من ملف الطرفية، وclose{Mask,Phys,
 About,Privacy,LoopDiag}Panel من ملف الميزات المتأخرة) كانت "مرفوعة"
 (hoisted) عبر السكربت الكامل بلا استثناء. بعد التقسيم إلى ملفات<script
 src>متعددة، يقتصر الرفع (hoisting) على كل ملف بمفرده فقط — فاستدعاء
 _wireSheetDrag(tmEl,...,closeTerm) وهو لا يزال في ملف اللوحات (يُحمَّل
 قبل ملف الطرفية) كان سيرمي "closeTerm is not defined" فوراً عند التحميل
 (تأكَّد هذا فعلياً عبر اختبار متصفح حقيقي)، ويوقف تنفيذ بقية استدعاءات
 الملف صامتاً. النقل إلى هنا — بعد كل الملفات الأخرى — يضمن أن كل الدوال
 المُشار إليها مُعرَّفة فعلياً بحلول لحظة التنفيذ، مطابقاً تماماً للسلوك
 الأصلي في الملف الواحد، بلا أي تغيير منطقي. ── */
// تشديد 28 سبتمبر 2026 ("تحويل كل html إلى صيغة أخرى" — القالب المصغَّر index-minimal.template.html
// الجديد لا يتضمّن أياً من هذه اللوحات في DOM إطلاقاً (لا bSheet/aiPanel/zpPanel/termPanel/
// menuPanel/filesPanel/devPanel — الشاشة الرئيسية المصغَّرة فقط)، فتصبح bsEl..dmEl كلها null.
// بلا حراسة، كانت _wireSheetDrag(null,...) سترمي "Cannot read properties of null" فوراً عند
// تحميل الصفحة (هذا الملف كتلة تنفيذ فورية لا دالة)، موقفةً كل التنفيذ اللاحق في هذا الملف —
// أُضيفت نفس حراسة if(el) المستخدمة أصلاً أدناه للوحات الخمس المتأخرة (mask/phys/about/
// privacy/loopDiag)، فتُصبح الحراسة موحَّدة لكل اللوحات، ولا فرق سلوكي إطلاقاً في البناء
// الكامل (zero.html) حيث تبقى كل هذه العناصر موجودة كما هي.
if(bsEl)_wireSheetDrag(bsEl,'.shsc',closeSheet);
if(apEl)_wireSheetDrag(apEl,'.pane',closeAIP);
if(zpEl)_wireSheetDrag(zpEl,'.zp-scr',closeZPPanel);
// اكمال بناء كل النوافذ: النوافذ الأربع التالية (termPanel/menuPanel/filesPanel/devPanel) كانت
// تعرض نفس مقبض السحب المرئي (.phdl/.pbar) الموجود في الثلاث نوافذ أعلاه، لكن بلا أي مستمع لمس
// موصول به إطلاقاً — مقبض السحب كان عنصراً زخرفياً ميتاً فيها، لا يستجيب لأي سحب، ما يجعل بناء
// هذه النوافذ غير مكتمل مقارنةً ببقية التطبيق. الآن تحصل جميعها على نفس السلوك الكامل (حرية
// تمرير المحتوى + سحب بلا جمود بصري) الذي أُصلِح أعلاه.
if(tmEl)_wireSheetDrag(tmEl,'.term-out',closeTerm);
if(mnEl)_wireSheetDrag(mnEl,'.shsc',closeMenu);
if(flEl)_wireSheetDrag(flEl,'.shsc',closeFilesPanel);
if(dmEl)_wireSheetDrag(dmEl,'.dm-scr',closeDevMon);
// لوحتا "غرفة الصمت" و"فيزياء الإلغاء" (أُضيفتا 28 سبتمبر 2026) تحصلان على نفس سلوك السحب
// للإغلاق منذ إنشائهما — بدل أن يتكرر نقص "مقبض سحب بلا استجابة" الذي أُصلِح أعلاه للوحات القديمة.
if(typeof closeMaskPanel!=='undefined'){const mkEl=E('maskPanel');if(mkEl)_wireSheetDrag(mkEl,'.shsc',closeMaskPanel);}
if(typeof closePhysPanel!=='undefined'){const phEl=E('physPanel');if(phEl)_wireSheetDrag(phEl,'.shsc',closePhysPanel);}
if(typeof closeAboutPanel!=='undefined'){const abEl=E('aboutPanel');if(abEl)_wireSheetDrag(abEl,'.shsc',closeAboutPanel);}
if(typeof closePrivacyPanel!=='undefined'){const prEl=E('privacyPanel');if(prEl)_wireSheetDrag(prEl,'.shsc',closePrivacyPanel);}
if(typeof closeLoopDiagPanel!=='undefined'){const ldEl=E('loopDiagPanel');if(ldEl)_wireSheetDrag(ldEl,'.shsc',closeLoopDiagPanel);}

window.bgEnabled=bgEnabled; window.bgMode=bgMode; window.bgStartT=bgStartT;
window.bgRuns=bgRuns; window.bgTotalMs=bgTotalMs; window.bgNotifN=bgNotifN;
window.BG_LOG=BG_LOG; window.bgLog=bgLog; window.wakeLock=wakeLock;
window.wlOk=wlOk; window._wlReqPromise=_wlReqPromise; window.reqWL=reqWL;
window.relWL=relWL; window.WK_CODE=WK_CODE; window.bgWorker=bgWorker;
window.wkOk=wkOk; window.wkCycs=wkCycs; window.startBGWorker=startBGWorker;
window.stopBGWorker=stopBGWorker; window.swOk=swOk; window.swReg=swReg;
window.swT=swT; window.regSW=regSW; window.stopSW=stopSW;
window.notifPerm=notifPerm; window.bgNotif=bgNotif; window.notifRefT=notifRefT;
window.reqNotifPerm=reqNotifPerm; window.showBGNotif=showBGNotif; window.closeBGNotif=closeBGNotif;
window._enterBG=_enterBG; window._exitBG=_exitBG; window.toggleBGMode=toggleBGMode;
window.hideBgBanner=hideBgBanner; window.openBGTab=openBGTab; window.updBGUI=updBGUI;
window.syncBGUI=syncBGUI; window.AICore=AICore; window.CONFIRMED_BANS=CONFIRMED_BANS;
window.CONFIRMED_INTERFERENCE=CONFIRMED_INTERFERENCE; window.loadConfirmedBans=loadConfirmedBans;

})();
