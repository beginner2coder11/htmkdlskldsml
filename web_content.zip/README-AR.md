# N-DAY — رفيق يومي (إعادة بناء جذرية)

هذا مشروع Android Studio كامل يغلّف ملف app.html داخل WebView.

- الحد الأدنى Android 7.0 (API 24)
- الهدف API 34
- افتح المشروع في Android Studio ثم شغّل Gradle Sync وابنِ APK محليًا.
- لا تدّعي منصة RB تجميع APK على الخادم؛ يلزم Android Studio أو أداة بناء خارجية.
