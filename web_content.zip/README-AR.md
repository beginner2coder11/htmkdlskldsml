# محلّل الاحتمالات الرياضي — v4
مشروع Android Studio: افتحه في Android Studio ثم Build > Build APK.
- الحزمة: com.sportsanalyzer.app (v4.0)
- الصلاحيات: INTERNET فقط
- الملف app/src/main/assets/app.html هو التطبيق الكامل.
