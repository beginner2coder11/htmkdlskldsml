# Datenschutz-Kontakt

Für 4.000 WOCHEN Plus X wurde folgende Datenschutz-Kontaktadresse festgelegt:

**4000plus_x@gmx.net**

Diese Adresse ist in der Datenschutzerklärung und den vorbereiteten Play-Store-Unterlagen hinterlegt.

Noch offen: eine öffentlich erreichbare URL, unter der die vollständige Datenschutzerklärung veröffentlicht wird.
