window.ATLAS_CATS=[
 {
  "id": "survival",
  "name": "Hayatta Kalma ve Doğa",
  "description": "Ateş, barınak, yön bulma, doğada güvenlik",
  "icon": "compass"
 },
 {
  "id": "health",
  "name": "Tıp ve İnsan Sağlığı",
  "description": "İlk yardım, anatomi, hijyen ve hastalıklar",
  "icon": "heart-pulse"
 },
 {
  "id": "medicine",
  "name": "İlaç ve Eczacılık",
  "description": "İlaç güvenliği, saklama, etkileşimler ve zehirlenmeler",
  "icon": "pill"
 },
 {
  "id": "agriculture",
  "name": "Tarım ve Hayvancılık",
  "description": "Tohum, toprak, sulama, yetiştiricilik",
  "icon": "sprout"
 },
 {
  "id": "food",
  "name": "Gıda ve Beslenme",
  "description": "Besinler, saklama, hazırlama ve gıda güvenliği",
  "icon": "utensils"
 },
 {
  "id": "water",
  "name": "Su ve Sanitasyon",
  "description": "Su kaynakları, arıtma, hijyen ve atık su",
  "icon": "droplets"
 },
 {
  "id": "shelter",
  "name": "Barınma ve İnşaat",
  "description": "Yapı, yalıtım, onarım ve güvenli barınma",
  "icon": "house"
 },
 {
  "id": "energy",
  "name": "Enerji ve Elektrik",
  "description": "Güneş, rüzgâr, batarya ve elektrik güvenliği",
  "icon": "zap"
 },
 {
  "id": "engineering",
  "name": "Makine ve Mühendislik",
  "description": "Mekanik, motorlar, aletler ve bakım",
  "icon": "settings"
 },
 {
  "id": "geography",
  "name": "Coğrafya ve Navigasyon",
  "description": "Harita, pusula, iklim ve ülkeler",
  "icon": "map"
 },
 {
  "id": "space",
  "name": "Uzay ve Astronomi",
  "description": "Güneş sistemi, yıldızlar ve gözlem",
  "icon": "telescope"
 },
 {
  "id": "science",
  "name": "Bilim ve Matematik",
  "description": "Fizik, kimya, biyoloji ve matematik",
  "icon": "flask"
 },
 {
  "id": "history",
  "name": "Dünya Tarihi",
  "description": "Medeniyetler, dönemler ve tarihsel olaylar",
  "icon": "landmark"
 },
 {
  "id": "philosophy",
  "name": "Felsefe ve İnsanlık",
  "description": "Felsefe, psikoloji, toplum ve etik",
  "icon": "brain"
 },
 {
  "id": "languages",
  "name": "Diller ve İletişim",
  "description": "Diller, alfabeler ve iletişim",
  "icon": "languages"
 },
 {
  "id": "transport",
  "name": "Ulaşım ve Araçlar",
  "description": "Araçlar, yol güvenliği ve temel bakım",
  "icon": "car"
 },
 {
  "id": "technology",
  "name": "Haberleşme ve Teknoloji",
  "description": "Radyo, bilgisayar, elektronik ve ağlar",
  "icon": "radio"
 },
 {
  "id": "disaster",
  "name": "Afet ve Acil Durum",
  "description": "Deprem, yangın, sel, tahliye ve hazırlık",
  "icon": "alarm"
 },
 {
  "id": "economy",
  "name": "Ekonomi ve Toplum",
  "description": "Para, üretim, ticaret ve temel hukuk",
  "icon": "wallet"
 },
 {
  "id": "culture",
  "name": "Sanat ve Kültür",
  "description": "Müzik, sanat, mimari ve edebiyat",
  "icon": "palette"
 },
 {
  "id": "entertainment",
  "name": "Oyunlar ve Eğlence",
  "description": "Bulmacalar, genel kültür ve oyunlar",
  "icon": "gamepad-2"
 },
 {
  "id": "reference",
  "name": "Pratik Başvuru",
  "description": "Ölçüler, tablolar, formüller ve günlük bilgiler",
  "icon": "book-open"
 },
 {
  "id": "cooking",
  "name": "Yemek ve Mutfak",
  "description": "Tarifler, pişirme teknikleri, ekmek, turşu, konserve",
  "icon": "utensils"
 },
 {
  "id": "plants",
  "name": "Bitkiler ve Doğa",
  "description": "Yenilebilir, şifalı ve zehirli bitkiler, mantar uyarıları",
  "icon": "sprout"
 },
 {
  "id": "homerepair",
  "name": "Ev Tamiri ve Tadilat",
  "description": "Tesisat, boya, sıva, alçı, fayans, küçük onarımlar",
  "icon": "house"
 },
 {
  "id": "workshop",
  "name": "Atölye ve El Aletleri",
  "description": "Alet kullanımı, marangozluk, kaynak, bağlantı elemanları",
  "icon": "settings"
 },
 {
  "id": "vehicle",
  "name": "Motor ve Araç Tamiri",
  "description": "Lastik, akü, yağ, arıza belirtileri, bakım",
  "icon": "car"
 },
 {
  "id": "veterinary",
  "name": "Veteriner ve Hayvan Bakımı",
  "description": "Evcil ve çiftlik hayvanı ilk yardımı ve bakımı",
  "icon": "heart-pulse"
 },
 {
  "id": "family",
  "name": "Anne, Çocuk ve Yaşlı Bakımı",
  "description": "Bebek bakımı, gebelik, çocuk hastalıkları, yaşlı bakımı",
  "icon": "heart-pulse"
 },
 {
  "id": "mental",
  "name": "Ruh Sağlığı",
  "description": "Stres, kriz anı, uyku, travma sonrası destek",
  "icon": "brain"
 },
 {
  "id": "law",
  "name": "Hukuk ve Resmî İşler",
  "description": "Temel haklar, dilekçe, sözleşme, resmî başvurular",
  "icon": "landmark"
 },
 {
  "id": "tips",
  "name": "Püf Noktalar",
  "description": "Günlük hayat, temizlik, onarım, pratik çözümler",
  "icon": "book-open"
 },
 {
  "id": "education",
  "name": "Eğitim ve Okuma",
  "description": "Müfredat özetleri, okuma yazma, çocuk eğitimi",
  "icon": "languages"
 },
 {
  "id": "religion",
  "name": "Dini Bilgiler",
  "description": "Namaz, abdest, cenaze, dualar (Latin okunuş), hadisler ve temel bilgiler",
  "icon": "landmark"
 },
 {
  "id": "library",
  "name": "Çevrimdışı Kütüphane",
  "description": "Kiwix ile Vikipedi ve 100 GB+ içeriği internetsiz kullanma rehberi",
  "icon": "book-open"
 }
];
