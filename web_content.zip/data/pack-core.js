(window.ATLAS_PACKS=window.ATLAS_PACKS||[]).push([
 {
  "id": "ATL-0001",
  "category": "disaster",
  "title": "Deprem öncesi aile hazırlığı",
  "summary": "Bir deprem planı, sarsıntı başlamadan önce hazırlanır. Evdeki herkes buluşma yerini, iletişim kişisini ve güvenli çıkışları bilmelidir.",
  "steps": [
   "Aile üyeleriyle ev ve mahalle dışı iki buluşma noktası belirleyin.",
   "Şehir dışında yaşayan bir irtibat kişisi seçin; herkesin numarasını kâğıda da yazın.",
   "Dolap, raf ve ağır eşyaları duvara sabitleyin; yatakların üzerine ağır eşya koymayın.",
   "Su, dayanıklı gıda, el feneri, pil, düdük, ilk yardım malzemesi ve gerekli kişisel ilaçları içeren çanta hazırlayın.",
   "Acil durum çantasını erişilebilir bir yerde tutun; içindekileri düzenli aralıklarla kontrol edin."
  ],
  "note": "Deprem sırasında ve sonrasında koşullar binaya ve bulunduğunuz yere göre değişir. Resmî afet kurumlarının güncel talimatları önceliklidir.",
  "section": "Afet ve Acil Durum",
  "priority": "Yüksek",
  "source": "AFAD ve yerel afet yönetimi rehberleriyle doğrulanmalı; bu makale genel hazırlık bilgisidir.",
  "updated": "2026-11-24",
  "tags": [
   "deprem öncesi aile hazırlığı",
   "afet ve acil durum",
   "disaster"
  ],
  "pack": "core",
  "body": "Bir deprem planı, sarsıntı başlamadan önce hazırlanır. Evdeki herkes buluşma yerini, iletişim kişisini ve güvenli çıkışları bilmelidir."
 },
 {
  "id": "ATL-0002",
  "category": "disaster",
  "title": "Deprem sırasında güvenli davranış",
  "summary": "Sarsıntı sırasında merdivenlere veya asansöre yönelmek tehlikelidir. Amaç, düşen ve devrilen eşyalardan korunmaktır.",
  "steps": [
   "Çök, kapan, tutun: sağlam bir masa gibi koruyucu bir eşyanın yanına/altına geçin.",
   "Başınızı ve ensenizi kollarınızla koruyun; tutunabiliyorsanız mobilyaya tutunun.",
   "Pencerelerden, camlardan, dolaplardan ve devrilebilecek eşyalardan uzak durun.",
   "Sarsıntı bitene kadar içeride kalın; kapıya veya merdivene koşmayın.",
   "Sarsıntı bitince ayakkabı giyin, çevreyi kontrol edin ve hasarlı binayı dikkatle terk edin."
  ],
  "note": "Binanın içinde veya dışında olmanıza göre doğru davranış farklılaşabilir. Kıyı bölgesindeyseniz güçlü/uzun deprem sonrasında tsunami uyarılarını dikkate alın.",
  "section": "Afet ve Acil Durum",
  "priority": "Yüksek",
  "source": "AFAD deprem anı rehberleri; yerel resmî uyarılar.",
  "updated": "2026-11-24",
  "tags": [
   "deprem sırasında güvenli davranış",
   "afet ve acil durum",
   "disaster"
  ],
  "pack": "core",
  "body": "Sarsıntı sırasında merdivenlere veya asansöre yönelmek tehlikelidir. Amaç, düşen ve devrilen eşyalardan korunmaktır."
 },
 {
  "id": "ATL-0003",
  "category": "health",
  "title": "Şiddetli kanamada ilk yaklaşım",
  "summary": "Şiddetli dış kanama yaşamı tehdit edebilir. En önemli adımlar acil yardım çağırmak ve kanamayı doğrudan basıyla kontrol etmektir.",
  "steps": [
   "Güvenliğinizi sağlayın; mümkünse eldiven veya bariyer kullanın.",
   "Türkiye'de 112 Acil Çağrı Merkezi'ni aratın veya birine aratın.",
   "Temiz bez veya gazlı bezle yaranın üzerine kuvvetli ve sürekli doğrudan bası uygulayın.",
   "Kanama durmazsa ilk bez parçasını kaldırıp kontrol etmeyin; üzerine ek bez koyup basıya devam edin.",
   "Uzuvdaki hayatı tehdit eden kanamalarda, eğitimliyseniz ve uygun ekipman varsa turnike uygulayın; uygulama saatini not edin."
  ],
  "note": "Yaraya saplanmış cismi çıkarmayın ve ciddi kanaması olan kişiye yiyecek/içecek vermeyin. Şok belirtilerinde kişiyi sıcak tutun ve acil ekipleri bekleyin.",
  "section": "Sağlık ve İlk Yardım",
  "priority": "Kritik",
  "source": "Türkiye 112; Kızılay ve güncel ilk yardım eğitim materyalleri. Eğitim almak, uygulama güvenliğini artırır.",
  "updated": "2026-11-24",
  "tags": [
   "şiddetli kanamada ilk yaklaşım",
   "sağlık ve i̇lk yardım",
   "health"
  ],
  "pack": "core",
  "body": "Şiddetli dış kanama yaşamı tehdit edebilir. En önemli adımlar acil yardım çağırmak ve kanamayı doğrudan basıyla kontrol etmektir."
 },
 {
  "id": "ATL-0004",
  "category": "health",
  "title": "Yanıkta ilk yardım",
  "summary": "Isı kaynaklı küçük yanıklarda erken soğutma doku hasarını azaltabilir. Ciddi yanıklar tıbbi değerlendirme gerektirir.",
  "steps": [
   "Yanma kaynağından uzaklaşın ve güvenliği sağlayın.",
   "Yanık bölgeyi serin veya ılık akan su altında yaklaşık 20 dakika soğutun.",
   "Yapışmamış yüzük, saat ve dar giysileri şişlik başlamadan çıkarın; deriye yapışan giysiyi çekmeyin.",
   "Yanığı temiz, yapışmayan bir örtüyle gevşekçe kapatın.",
   "Geniş, derin, kimyasal/elektrik kaynaklı veya yüz, el, ayak, genital bölge ve eklem üzerindeki yanıklarda acil tıbbi yardım alın."
  ],
  "note": "Buz, diş macunu, yağ, yoğurt veya krem sürmeyin; kabarcıkları patlatmayın. Kimyasal yanıklarda kirlenmiş giysileri çıkarırken kendinizi koruyun ve acil yardım alın.",
  "section": "Sağlık ve İlk Yardım",
  "priority": "Yüksek",
  "source": "Uluslararası ilk yardım rehberleri ve sağlık otoritelerinin güncel yanık önerileri.",
  "updated": "2026-11-24",
  "tags": [
   "yanıkta ilk yardım",
   "sağlık ve i̇lk yardım",
   "health"
  ],
  "pack": "core",
  "body": "Isı kaynaklı küçük yanıklarda erken soğutma doku hasarını azaltabilir. Ciddi yanıklar tıbbi değerlendirme gerektirir."
 },
 {
  "id": "ATL-0005",
  "category": "water",
  "title": "Acil durumda içme suyu planı",
  "summary": "Su ihtiyacı; sıcaklık, yaş, sağlık durumu ve fiziksel aktiviteye göre değişir. Afet hazırlığında kişi başına günlük en az 3 litre içme ve temel yemek suyu için başlangıç planı yapılabilir; daha fazlası gerekebilir.",
  "steps": [
   "Evde kişi başına birkaç günlük içme suyu stoku bulundurun; mümkünse daha uzun süreye hazırlanın.",
   "Kapalı, gıda temasına uygun kaplar kullanın ve tarihlerini işaretleyin.",
   "Suyu yakıt, pestisit ve temizlik kimyasallarından uzak saklayın.",
   "Resmî kurumların şebeke suyu uyarılarını takip edin; kaynatma her kimyasal kirleticiyi gidermez.",
   "Su stokunu düzenli olarak döndürün ve kapları üretici talimatlarına göre temiz tutun."
  ],
  "note": "Suya yakıt, çözücü, ağır metal veya bilinmeyen kimyasal karışmışsa kaynatmak ya da ev tipi filtre kullanmak suyu güvenli hale getirmeyebilir.",
  "section": "Su ve Sanitasyon",
  "priority": "Yüksek",
  "source": "WHO ve ulusal halk sağlığı kurumlarının içme suyu ve acil durum rehberleri.",
  "updated": "2026-11-24",
  "tags": [
   "acil durumda içme suyu planı",
   "su ve sanitasyon",
   "water"
  ],
  "pack": "core",
  "body": "Su ihtiyacı; sıcaklık, yaş, sağlık durumu ve fiziksel aktiviteye göre değişir. Afet hazırlığında kişi başına günlük en az 3 litre içme ve temel yemek suyu için başlangıç planı yapılabilir; daha fazlası gerekebilir."
 },
 {
  "id": "ATL-0006",
  "category": "water",
  "title": "Suyu kaynatarak mikrobiyolojik açıdan güvenli hale getirme",
  "summary": "Kaynatma, uygun koşullarda birçok hastalık yapıcı mikroorganizmayı etkisizleştirir. Kimyasal kirlenmeyi gidermez.",
  "steps": [
   "Mümkünse berrak su seçin; bulanıksa temiz bir bezden süzerek tortuyu azaltın.",
   "Suyu fokurdayan kaynama noktasına getirin.",
   "Rakım ve yerel sağlık otoritesi talimatlarını dikkate alın; yaygın acil durum önerisi en az 1 dakika fokur kaynatmaktır.",
   "Soğumasını kendi halinde, temiz ve kapalı bir kapta bekletin.",
   "Temiz kapta saklayın; elinizi veya kirli kepçeyi içine sokmayın."
  ],
  "note": "Yakıt, pestisit, ağır metal veya tuz gibi kimyasal kirleticiler kaynatmayla giderilmez; bazıları yoğunlaşabilir. Böyle bir şüphede alternatif güvenli kaynak bulun.",
  "section": "Su ve Sanitasyon",
  "priority": "Yüksek",
  "source": "CDC acil durum su güvenliği rehberi; yerel sağlık otoritesi talimatları.",
  "updated": "2026-11-24",
  "tags": [
   "suyu kaynatarak mikrobiyolojik açıdan güvenli hale getirme",
   "su ve sanitasyon",
   "water"
  ],
  "pack": "core",
  "body": "Kaynatma, uygun koşullarda birçok hastalık yapıcı mikroorganizmayı etkisizleştirir. Kimyasal kirlenmeyi gidermez."
 },
 {
  "id": "ATL-0007",
  "category": "food",
  "title": "Gıda güvenliğinde temel dört kural",
  "summary": "Gıda kaynaklı hastalık riskini azaltmak için temizlik, çiğ-pişmiş ayrımı, yeterli pişirme ve güvenli sıcaklıkta saklama birlikte uygulanır.",
  "steps": [
   "Yemek hazırlamadan önce ve tuvalet sonrası ellerinizi sabunla yıkayın.",
   "Çiğ et ve balığı hazır yiyeceklerden ayırın; ayrı kesme tahtası kullanın.",
   "Et, yumurta ve diğer riskli yiyecekleri güvenli iç sıcaklığa kadar pişirin; mümkünse gıda termometresi kullanın.",
   "Pişmiş yiyecekleri oda sıcaklığında uzun süre bırakmayın; hızla soğutup buzdolabına kaldırın.",
   "Şüpheli koku, küf veya bozulma varsa tadına bakarak test etmeyin."
  ],
  "note": "Elektrik kesintisinde buzdolabı kapağını kapalı tutun. Sıcaklığın ne kadar yükseldiği bilinmiyorsa bozulabilir gıdaları tüketmeyin.",
  "section": "Gıda ve Beslenme",
  "priority": "Yüksek",
  "source": "WHO Beş Anahtar Gıda Güvenliği ve ulusal gıda güvenliği rehberleri.",
  "updated": "2026-11-24",
  "tags": [
   "gıda güvenliğinde temel dört kural",
   "gıda ve beslenme",
   "food"
  ],
  "pack": "core",
  "body": "Gıda kaynaklı hastalık riskini azaltmak için temizlik, çiğ-pişmiş ayrımı, yeterli pişirme ve güvenli sıcaklıkta saklama birlikte uygulanır."
 },
 {
  "id": "ATL-0008",
  "category": "energy",
  "title": "Jeneratör güvenliği",
  "summary": "Jeneratörler karbonmonoksit zehirlenmesi ve elektrik çarpması riski taşır. Yanlış kullanım ölümcül olabilir.",
  "steps": [
   "Jeneratörü asla ev, bodrum, garaj, balkon veya kapalı/yarı kapalı alanda çalıştırmayın.",
   "Dışarıda, kapı ve pencerelerden uzak, üreticinin belirttiği mesafede kullanın.",
   "Egzoz gazını yaşam alanlarından uzağa yönlendirin; karbonmonoksit alarmı bulundurun.",
   "Jeneratörü yağmurdan koruyun; ıslak elle veya ıslak zeminde elektrik bağlantısı yapmayın.",
   "Evin tesisatına doğrudan bağlamayın; transfer şalteri ve bağlantı işini yetkili elektrikçiye yaptırın."
  ],
  "note": "Karbonmonoksit renksiz ve kokusuzdur. Baş ağrısı, baş dönmesi, bulantı veya sersemlik olursa hemen temiz havaya çıkın ve acil yardım çağırın.",
  "section": "Enerji ve Elektrik",
  "priority": "Kritik",
  "source": "CDC karbonmonoksit ve jeneratör güvenliği; üretici kılavuzu; yetkili elektrikçi.",
  "updated": "2026-11-24",
  "tags": [
   "jeneratör güvenliği",
   "enerji ve elektrik",
   "energy"
  ],
  "pack": "core",
  "body": "Jeneratörler karbonmonoksit zehirlenmesi ve elektrik çarpması riski taşır. Yanlış kullanım ölümcül olabilir."
 },
 {
  "id": "ATL-0009",
  "category": "survival",
  "title": "Açık havada yön bulmanın temelleri",
  "summary": "Harita, pusula ve çevresel işaretler birlikte kullanıldığında yön bulmayı kolaylaştırır. Tek bir doğal işarete güvenmek hataya yol açabilir.",
  "steps": [
   "Bulunduğunuz noktayı haritada belirleyin; ölçek ve kuzey işaretini kontrol edin.",
   "Pusulanın manyetik kuzeyi gösterdiğini, harita kuzeyinin ise çoğu haritada gerçek kuzeye göre düzenlendiğini bilin.",
   "Pusulayı metal eşyalardan, mıknatıslardan ve elektronik cihazlardan uzak tutun.",
   "Güzergâhı, su kaynaklarını, belirgin arazi şekillerini ve geri dönüş yolunu önceden işaretleyin.",
   "Kaybolduğunuzu fark edince panikle rastgele ilerlemeyin; güvenli yerde kalıp yardım çağırma imkânlarını değerlendirin."
  ],
  "note": "Telefon GPS'i çevrimdışı haritalar önceden indirilmişse yardımcı olabilir; ancak pil ve cihaz arızası ihtimaline karşı kâğıt harita ve pusula yedeği bulundurun.",
  "section": "Hayatta Kalma ve Doğa",
  "priority": "Orta",
  "source": "Harita-pusula eğitim materyalleri ve açık alan güvenliği rehberleri.",
  "updated": "2026-11-24",
  "tags": [
   "açık havada yön bulmanın temelleri",
   "hayatta kalma ve doğa",
   "survival"
  ],
  "pack": "core",
  "body": "Harita, pusula ve çevresel işaretler birlikte kullanıldığında yön bulmayı kolaylaştırır. Tek bir doğal işarete güvenmek hataya yol açabilir."
 },
 {
  "id": "ATL-0010",
  "category": "agriculture",
  "title": "Tohum saklamanın temel ilkeleri",
  "summary": "Tohumların canlılığını korumak için nem, sıcaklık, ışık ve zararlılardan korunma önemlidir. Her türün saklama ömrü farklıdır.",
  "steps": [
   "Yalnızca olgunlaşmış, sağlıklı ve doğru tanımlanmış bitkilerden tohum alın.",
   "Tohumları türüne göre uygun şekilde tamamen kurutun; nemli tohumu kapalı kaba koymayın.",
   "Kuru tohumu etiketli, hava ve nem geçişini azaltan kapta saklayın.",
   "Serin, kuru ve karanlık bir ortam seçin; sıcaklık dalgalanmasını azaltın.",
   "Tür, çeşit, toplama tarihi ve kaynağı kaydedin; ekim öncesi küçük çimlenme testi yapın."
  ],
  "note": "Tohum saklama koşulları türe göre değişir. Hibrit çeşitlerden alınan tohumlar ana bitkiyle aynı özellikleri vermeyebilir.",
  "section": "Tarım ve Hayvancılık",
  "priority": "Orta",
  "source": "FAO tohum saklama ve genetik kaynak rehberleri; tarımsal yayım kaynakları.",
  "updated": "2026-11-24",
  "tags": [
   "tohum saklamanın temel ilkeleri",
   "tarım ve hayvancılık",
   "agriculture"
  ],
  "pack": "core",
  "body": "Tohumların canlılığını korumak için nem, sıcaklık, ışık ve zararlılardan korunma önemlidir. Her türün saklama ömrü farklıdır."
 },
 {
  "id": "ATL-0011",
  "category": "science",
  "title": "Bilimsel yöntemin temel adımları",
  "summary": "Bilimsel yöntem, gözlem ve kanıt üzerinden açıklamaları sınamaya yarayan sistematik bir yaklaşımdır.",
  "steps": [
   "Bir gözlem veya araştırılabilir soru belirleyin.",
   "Önceki bilgileri inceleyin ve sınanabilir bir hipotez kurun.",
   "Değişkenleri tanımlayıp tekrarlanabilir bir deney veya gözlem planlayın.",
   "Verileri düzenli kaydedin; sonuçları hipotezle karşılaştırın.",
   "Belirsizlikleri, hata kaynaklarını ve alternatif açıklamaları raporlayın."
  ],
  "note": "Tek bir deney genellikle kesin kanıt oluşturmaz. Bulguların bağımsız çalışmalarla tekrarlanması güveni artırır.",
  "section": "Bilim ve Matematik",
  "priority": "Düşük",
  "source": "Bilimsel araştırma yöntemleri ve üniversite açık ders kaynakları.",
  "updated": "2026-11-24",
  "tags": [
   "bilimsel yöntemin temel adımları",
   "bilim ve matematik",
   "science"
  ],
  "pack": "core",
  "body": "Bilimsel yöntem, gözlem ve kanıt üzerinden açıklamaları sınamaya yarayan sistematik bir yaklaşımdır."
 },
 {
  "id": "ATL-0012",
  "category": "space",
  "title": "Güneş sisteminin temel yapısı",
  "summary": "Güneş sistemi; merkezindeki Güneş, sekiz gezegen, cüce gezegenler, uydular, asteroitler ve kuyruklu yıldızlardan oluşur.",
  "steps": [
   "Güneş sisteminin merkezinde yıldız olan Güneş bulunur.",
   "İç gezegenler Merkür, Venüs, Dünya ve Mars'tır; çoğunlukla kayalık yapıdadır.",
   "Dış gezegenler Jüpiter, Satürn, Uranüs ve Neptün'dür; dev gezegenlerdir.",
   "Asteroit kuşağı Mars ile Jüpiter arasındadır.",
   "Cüce gezegenler arasında Plüton ve Ceres bulunur."
  ],
  "note": "Ölçekli bir modelde gezegenlerin boyutlarını ve aralarındaki uzaklıkları aynı anda doğru göstermek zordur; çoğu eğitim görseli ölçekli değildir.",
  "section": "Uzay ve Astronomi",
  "priority": "Düşük",
  "source": "NASA Solar System Exploration ve uluslararası astronomi kaynakları.",
  "updated": "2026-11-24",
  "tags": [
   "güneş sisteminin temel yapısı",
   "uzay ve astronomi",
   "space"
  ],
  "pack": "core",
  "body": "Güneş sistemi; merkezindeki Güneş, sekiz gezegen, cüce gezegenler, uydular, asteroitler ve kuyruklu yıldızlardan oluşur."
 },
 {
  "id": "ATL-0013",
  "category": "reference",
  "title": "Metrik sistemde temel dönüşümler",
  "summary": "Metrik sistem, ondalık tabanlı bir ölçü sistemidir. Birim dönüşümlerinde doğru çarpan kullanmak önemlidir.",
  "steps": [
   "1 kilometre = 1.000 metre.",
   "1 metre = 100 santimetre = 1.000 milimetre.",
   "1 kilogram = 1.000 gram.",
   "1 litre = 1.000 mililitre.",
   "Santigrat ve Fahrenheit dönüşümü: °F = (°C × 9/5) + 32."
  ],
  "note": "Yaklaşık değer ile kesin ölçümü karıştırmayın. Tıbbi doz, mühendislik toleransı ve laboratuvar ölçümünde uygun hassasiyeti kullanın.",
  "section": "Pratik Başvuru",
  "priority": "Düşük",
  "source": "Uluslararası Birimler Sistemi (SI) ve NIST dönüşüm kaynakları.",
  "updated": "2026-11-24",
  "tags": [
   "metrik sistemde temel dönüşümler",
   "pratik başvuru",
   "reference"
  ],
  "pack": "core",
  "body": "Metrik sistem, ondalık tabanlı bir ölçü sistemidir. Birim dönüşümlerinde doğru çarpan kullanmak önemlidir."
 },
 {
  "id": "ATL-0014",
  "category": "entertainment",
  "title": "Sudoku nasıl oynanır?",
  "summary": "Sudoku, mantık ve eleme yoluyla çözülen bir sayı bulmacasıdır. Standart 9×9 tabloda 1'den 9'a kadar rakamlar kullanılır.",
  "steps": [
   "Her satırda 1–9 rakamları birer kez bulunmalıdır.",
   "Her sütunda 1–9 rakamları birer kez bulunmalıdır.",
   "Her 3×3 kutuda 1–9 rakamları birer kez bulunmalıdır.",
   "Bir hücreye gelebilecek rakamları satır, sütun ve kutudaki rakamlara bakarak eleyin.",
   "Tahmin etmek yerine tek olasılıklı hücreleri ve gizli tekleri arayın."
  ],
  "note": "Başlangıç seviyesinde daha az boşluklu bulmacalar seçin. Not alma özelliği aday rakamları takip etmeyi kolaylaştırır.",
  "section": "Oyunlar ve Eğlence",
  "priority": "Düşük",
  "source": "Standart Sudoku kuralları.",
  "updated": "2026-11-24",
  "tags": [
   "sudoku nasıl oynanır?",
   "oyunlar ve eğlence",
   "entertainment"
  ],
  "pack": "core",
  "body": "Sudoku, mantık ve eleme yoluyla çözülen bir sayı bulmacasıdır. Standart 9×9 tabloda 1'den 9'a kadar rakamlar kullanılır."
 }
]);
