JAS LAUNDRY — Student / Regular Auto-Preservation Patch

ഈ ZIP-ൽ ഉൾപ്പെടുത്തിയ മാറ്റങ്ങൾ
--------------------------------
1. Order List-ലെ പഴയ ബില്ലിൽ നിന്ന് “New Bill” എടുക്കുമ്പോൾ ആ ബില്ലിലെ Student / Regular വിഭാഗം അതേപടി പുതിയ ബില്ലിൽ വരും.
2. മുമ്പ് സേവ് ചെയ്ത customer-ന്റെ mobile number അല്ലെങ്കിൽ പേര് തിരിച്ചറിയുമ്പോൾ customer record-ൽ സൂക്ഷിച്ചിരിക്കുന്ന വിഭാഗം സ്വയം തിരഞ്ഞെടുക്കും.
3. പഴയ customer record-ൽ category ഇല്ലെങ്കിൽ ആ customer-ന്റെ ഏറ്റവും പുതിയ bill-ൽ നിന്നുള്ള Student / Regular വിഭാഗം fallback ആയി എടുക്കും.
4. പുതിയ bill save ചെയ്യുമ്പോൾ customer record-ൽ customerType കൂടി സൂക്ഷിക്കും. നിലവിലുള്ള customer fields ഇല്ലാതാക്കുന്നില്ല.
5. Customer type അനുസരിച്ച് item price studentPrice / regular price വീണ്ടും കണക്കാക്കും.

Data safety
-----------
- ഈ HTML patch പഴയ bills, payments, paymentHistory, customer advances, refunds, prices, settings എന്നിവ delete ചെയ്യുകയോ reset ചെയ്യുകയോ ചെയ്യുന്നില്ല.
- Firebase project, Firestore Rules, remote Cloud data എന്നിവ ഇവിടെ നിന്ന് പരിശോധിക്കാനോ live test നടത്താനോ കഴിഞ്ഞിട്ടില്ല. അതിനാൽ cloud sync വിജയിച്ചു എന്ന് ഈ ZIP മാത്രം കൊണ്ട് ഉറപ്പിക്കാനാവില്ല.
- മാറ്റം install ചെയ്യുന്നതിന് മുമ്പ് ആപ്പിലെ Settings → Backup → Download Backup ഉപയോഗിച്ച് JSON backup എടുക്കുക. പഴയ HTML / APK-യും സൂക്ഷിക്കുക.
- Cloud sync ഉപയോഗിക്കുന്നുവെങ്കിൽ backup എടുത്ത ശേഷം Owner account-ൽ login ചെയ്ത് Cloud Sync status പരിശോധിക്കുക. Firestore Rules മാറ്റേണ്ടതില്ല ഈ category fix-നായി.

Static checks നടത്തിയവ
---------------------
- Inline JavaScript syntax: Node.js --check വിജയിച്ചു.
- HTML-ൽ ആവർത്തിക്കുന്ന static id-കൾ കണ്ടെത്തിയില്ല.

ഇനിയും device / APK-യിൽ പരിശോധിക്കേണ്ടത്
---------------------------------------
- Firebase Authentication, Firestore Rules, actual cloud read/write എന്നിവയ്ക്ക് project credentials ഉള്ള ഉപകരണത്തിൽ test ആവശ്യമാണ്.
- WhatsApp Business-ലേക്ക് PDF direct share ചെയ്യാനും Android Downloads notification ഉറപ്പാക്കാനും README_WHATSAPP_NATIVE_SHARE_ML.txt-ൽ പറഞ്ഞ native Android WebView bridge ആവശ്യമാണ്. ഈ ZIP HTML source ആണ്; rebuilt APK അല്ല.
- Appwrite ഭാഗം നിലവിൽ connection ping test മാത്രമാണ്; bills/customers sync ആയി കണക്കാക്കരുത്.

Install ചെയ്യുന്നതിന് മുമ്പ് നിർബന്ധമായും backup എടുക്കുക. ഈ ZIP-ൽ ഉള്ള HTML നിങ്ങളുടെ നിലവിലെ APK-യിൽ സ്വയം update ആകില്ല; HTML-to-APK project-ൽ replace ചെയ്ത് APK വീണ്ടും build ചെയ്യണം.

6. Bill / Order List-ൽ Thermal Print ബട്ടൺ ചേർത്തു. അമർത്തുമ്പോൾ 576px ഹൈ-ക്ലാരിറ്റി PNG receipt preview തുറക്കും.
7. അതേ preview-ൽ Download PNG ബട്ടൺ ഉപയോഗിച്ച് യഥാർത്ഥ PNG ഫയൽ ഡൗൺലോഡ് ചെയ്യാം; Print ബട്ടൺ വഴി print dialog തുറക്കാം.
8. PNG preview/download നിലവിലുള്ള PDF, WhatsApp Business ഫ്ലോ നീക്കം ചെയ്യാതെ ചേർത്തതാണ്.


9. Order List-ൽ ചുവപ്പ് അടയാളപ്പെടുത്തിയ “Download PDF”, “Download Thermal PDF” എന്നീ രണ്ട് ബട്ടണുകൾ നീക്കി. “Thermal Print”, “WhatsApp Business · Thermal Bill PDF”, “Save Thermal Receipt” എന്നിവ ഉൾപ്പെടെയുള്ള മറ്റ് ഓപ്ഷനുകൾ നിലനിർത്തി.

10. Cloud Save Queue hardening (16/11/2026)
------------------------------------------
- Firestore writes from this device are now serialized; a second write waits for the previous write to finish.
- A rapid sequence of saves is queued in order rather than launching overlapping full-document writes.
- Save failures are returned to the bill-save flow and shown as a Cloud Save failure instead of displaying a false Cloud-success message.
- When network connectivity returns, the app pushes the local copy instead of immediately reloading the remote document over potentially unsynced local bills.
- This is a per-device write queue only. It does not prevent two different phones from overwriting each other's whole-document updates at the same time. For strict concurrent multi-device safety, migrate bills/customers/payments to per-record Firestore documents with transactions and deletion tombstones.
- See QA_TEST_REPORT_MALAYALAM.txt for exactly which checks passed and which live/device tests remain outstanding.
