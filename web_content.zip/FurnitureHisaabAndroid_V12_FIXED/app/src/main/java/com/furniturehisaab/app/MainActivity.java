package com.furniturehisaab.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import android.net.Uri;
import android.content.*;
import android.graphics.Bitmap;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> uploadCallback;
    @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false); web.setWebChromeClient(new WebChromeClient(){
        @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){ uploadCallback=cb; Intent i=p.createIntent(); try{startActivityForResult(i,42);}catch(Exception e){cb.onReceiveValue(null);} return true; }
    }); web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/index.html"); setContentView(web); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==42 && uploadCallback!=null){ Uri[] u=null; if(c==RESULT_OK && d!=null){ if(d.getData()!=null) u=new Uri[]{d.getData()}; else if(d.getClipData()!=null){ int n=d.getClipData().getItemCount(); u=new Uri[n]; for(int x=0;x<n;x++)u[x]=d.getClipData().getItemAt(x).getUri(); }} uploadCallback.onReceiveValue(u); uploadCallback=null; }}
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
