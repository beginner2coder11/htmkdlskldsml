# Furniture Hisaab — Mobile PWA Install

## Important
PWA installation requires the app to be served over **HTTPS** (or localhost during development). Do not open `index.html` directly as a `file://` URL.

## Hostinger / any HTTPS hosting
1. Upload the contents of this folder to a web folder/subdomain.
2. Make sure HTTPS/SSL is enabled.
3. Open the app in Chrome on Android.
4. Use the **Install** banner, or Chrome menu → **Install app / Add to Home screen**.
5. Open Furniture Hisaab from the home-screen icon. It will run in standalone app mode.

## Local test
Run a local web server, then open `http://localhost:8080`. PWA installation can be tested on supported browsers.

## Offline
The app shell, JavaScript, CSS, manifest and icons are cached by the service worker. LocalStorage/offline queue continues to work. External CDN libraries used by the current V6 build (Chart.js/Tesseract.js) may require one initial online load unless they are self-hosted; the production build should self-host these libraries for fully offline OCR.
