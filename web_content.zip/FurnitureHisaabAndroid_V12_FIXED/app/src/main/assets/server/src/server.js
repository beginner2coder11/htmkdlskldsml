import express from "express";
import cors from "cors";
import helmet from "helmet";
import multer from "multer";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import {execFile} from "child_process";
import {promisify} from "util";
const execFileAsync=promisify(execFile);
import dotenv from "dotenv";
import {pool,tx} from "./db.js";
import {hashPassword,verifyPassword,signUser,auth,roles} from "./auth.js";
import {volumeCft,effectiveRate,gstSplit} from "./timber.js";
import {extractInvoiceWithAI} from "./ocr.js";
dotenv.config();

const app=express();
app.use(helmet({crossOriginResourcePolicy:false}));
app.use(cors({origin:process.env.CORS_ORIGIN?.split(",")||"*"}));
app.use(express.json({limit:"2mb"}));
const uploadDir=process.env.UPLOAD_DIR||"./uploads";fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({dest:uploadDir,limits:{fileSize:(Number(process.env.MAX_UPLOAD_MB)||15)*1024*1024}});
const audit=async(c,u,action,entity,id,details={})=>c.query("INSERT INTO audit_log(user_id,action,entity,entity_id,details) VALUES($1,$2,$3,$4,$5)",[u,action,entity,id,JSON.stringify(details)]);

app.get("/api/health",async(req,res)=>{try{await pool.query("select 1");res.json({ok:true,version:"6.0.0"})}catch(e){res.status(503).json({ok:false})}});

app.post("/api/auth/register",async(req,res)=>{const {name,email,password}=req.body;if(!name||!email||!password)return res.status(400).json({error:"name,email,password required"});try{const h=await hashPassword(password);const count=(await pool.query("SELECT count(*)::int n FROM users")).rows[0].n;const role=count===0?"OWNER":"STAFF";const r=await pool.query("INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,name,email,role",[name,email.toLowerCase(),h,role]);res.status(201).json(r.rows[0])}catch(e){res.status(409).json({error:"Email already exists"})}});
app.post("/api/auth/login",async(req,res)=>{const {email,password}=req.body;const r=await pool.query("SELECT * FROM users WHERE email=$1 AND active=true",[String(email||"").toLowerCase()]);if(!r.rowCount||!(await verifyPassword(password,r.rows[0].password_hash)))return res.status(401).json({error:"Invalid credentials"});const u=r.rows[0];res.json({token:signUser(u),user:{id:u.id,name:u.name,email:u.email,role:u.role}})});

app.get("/api/parties",auth,async(req,res)=>res.json((await pool.query("SELECT * FROM parties ORDER BY name")).rows));
app.post("/api/parties",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{const {name,type="BOTH",phone,gstin,address,opening_balance=0}=req.body;const r=await pool.query("INSERT INTO parties(name,type,phone,gstin,address,opening_balance) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",[name,type,phone,gstin,address,opening_balance]);res.status(201).json(r.rows[0])});

app.get("/api/rates",auth,async(req,res)=>res.json((await pool.query("SELECT * FROM wood_rates WHERE active=true ORDER BY wood,min_ft")).rows));
app.post("/api/rates",auth,roles("OWNER","ADMIN"),async(req,res)=>{const {wood,min_ft,max_ft,base_rate}=req.body;const r=await pool.query("INSERT INTO wood_rates(wood,min_ft,max_ft,base_rate) VALUES($1,$2,$3,$4) ON CONFLICT(wood,min_ft,max_ft) DO UPDATE SET base_rate=EXCLUDED.base_rate,active=true RETURNING *",[wood,min_ft,max_ft,base_rate]);res.json(r.rows[0])});

app.get("/api/stock",auth,async(req,res)=>{const r=await pool.query(`SELECT wood,length_ft,width_in,thickness_in,SUM(qty_in-qty_out) qty,SUM(cft_in-cft_out) cft,SUM((qty_in-qty_out)*cost_rate) value FROM stock_batches GROUP BY wood,length_ft,width_in,thickness_in ORDER BY wood,length_ft`);res.json(r.rows)});
app.get("/api/ledger",auth,async(req,res)=>res.json((await pool.query(`SELECT j.*,v.voucher_no,v.voucher_date,v.voucher_type FROM journal_entries j JOIN vouchers v ON v.id=j.voucher_id ORDER BY v.voucher_date DESC,j.created_at DESC LIMIT 500`)).rows));

app.post("/api/vouchers/purchase",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{try{
 const b=req.body, lines=b.lines||[]; if(!b.partyId||!b.voucherDate||!lines.length)return res.status(400).json({error:"partyId, voucherDate and lines required"});
 const result=await tx(async c=>{
   const taxable=lines.reduce((s,l)=>s+Number(l.amount||0),0), g=gstSplit(taxable,Number(b.gstRate||0),!!b.interState), total=g.total;
   const dup=await c.query("SELECT id FROM vouchers WHERE voucher_type='PURCHASE' AND reference_no=$1",[b.referenceNo||""]);
   if(b.referenceNo&&dup.rowCount)return {duplicate:true,id:dup.rows[0].id};
   const v=(await c.query(`INSERT INTO vouchers(voucher_no,voucher_type,party_id,voucher_date,taxable_amount,gst_rate,cgst,sgst,igst,total_amount,reference_no,created_by) VALUES($1,'PURCHASE',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[b.voucherNo,b.partyId,b.voucherDate,taxable,b.gstRate||0,g.cgst,g.sgst,g.igst,total,b.referenceNo||null,req.user.sub])).rows[0];
   for(const l of lines){
     const qty=Number(l.qty),cft=Number(l.cft||volumeCft(l.lengthFt,l.widthIn,l.thicknessIn,qty)),rate=Number(l.rate||0);
     await c.query(`INSERT INTO voucher_lines(voucher_id,wood,length_ft,width_in,thickness_in,qty,cft,rate,amount,hsn) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,[v.id,l.wood,l.lengthFt,l.widthIn,l.thicknessIn,qty,cft,rate,Number(l.amount||cft*rate),l.hsn||null]);
     await c.query(`INSERT INTO stock_batches(wood,length_ft,width_in,thickness_in,qty_in,cft_in,cost_rate,source_voucher) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[l.wood,l.lengthFt,l.widthIn,l.thicknessIn,qty,cft,rate,v.id]);
   }
   await c.query("INSERT INTO journal_entries(voucher_id,account_debit,account_credit,amount,party_id) VALUES($1,'Inventory','Accounts Payable',$2,$3)",[v.id,total,b.partyId]);
   await audit(c,req.user.sub,"CREATE","VOUCHER",v.id,{type:"PURCHASE",total,lines:lines.length});
   return {duplicate:false,voucher:v};
 }); res.status(result.duplicate?409:201).json(result);
}catch(e){console.error(e);res.status(500).json({error:"Could not post purchase"})}});

app.post("/api/vouchers/sale",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{try{const b=req.body,lines=b.lines||[];if(!b.partyId||!b.voucherDate||!lines.length)return res.status(400).json({error:"partyId, voucherDate and lines required"});const result=await tx(async c=>{const total=lines.reduce((x,l)=>x+Number(l.amount||0),0);const v=(await c.query(`INSERT INTO vouchers(voucher_no,voucher_type,party_id,voucher_date,taxable_amount,total_amount,reference_no,created_by) VALUES($1,'SALE',$2,$3,$4,$4,$5,$6) RETURNING *`,[b.voucherNo,b.partyId,b.voucherDate,total,b.referenceNo||null,req.user.sub])).rows[0];for(const l of lines){const qty=Number(l.qty),cft=Number(l.cft||volumeCft(l.lengthFt,l.widthIn,l.thicknessIn,qty)),rate=Number(l.rate||0);let needQty=qty,needCft=cft;const batches=(await c.query(`SELECT id,qty_in,qty_out,cft_in,cft_out FROM stock_batches WHERE wood=$1 AND length_ft=$2 AND width_in=$3 AND thickness_in=$4 AND (qty_in-qty_out)>0 ORDER BY created_at FOR UPDATE`,[l.wood,l.lengthFt,l.widthIn,l.thicknessIn])).rows;for(const bth of batches){if(needQty<=0&&needCft<=0)break;const availQty=Number(bth.qty_in)-Number(bth.qty_out),availCft=Number(bth.cft_in)-Number(bth.cft_out),takeQty=Math.min(needQty,availQty),takeCft=Math.min(needCft,availCft);await c.query("UPDATE stock_batches SET qty_out=qty_out+$1,cft_out=cft_out+$2 WHERE id=$3",[takeQty,takeCft,bth.id]);needQty-=takeQty;needCft-=takeCft;}if(needQty>0.0001||needCft>0.0001)throw Object.assign(new Error("Insufficient stock for sale"),{status:409});await c.query(`INSERT INTO voucher_lines(voucher_id,wood,length_ft,width_in,thickness_in,qty,cft,rate,amount,hsn) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[v.id,l.wood,l.lengthFt,l.widthIn,l.thicknessIn,qty,cft,rate,Number(l.amount||cft*rate),l.hsn||null]);}await c.query("INSERT INTO journal_entries(voucher_id,account_debit,account_credit,amount,party_id) VALUES($1,'Accounts Receivable','Sales',$2,$3)",[v.id,total,b.partyId]);await audit(c,req.user.sub,"CREATE","VOUCHER",v.id,{type:"SALE",total,lines:lines.length});return {voucher:v};});res.status(201).json(result)}catch(e){console.error(e);res.status(e.status||500).json({error:e.status?e.message:"Could not post sale"})}});

app.post("/api/ocr/local",auth,roles("OWNER","ADMIN","STAFF"),upload.single("file"),async(req,res)=>{
  if(!req.file)return res.status(400).json({error:"file required"});
  try{
    const ext=path.extname(req.file.originalname||"").toLowerCase(); let text="";
    if(ext==='.pdf'){
      try{const r=await execFileAsync('pdftotext',['-layout',req.file.path,'-'],{maxBuffer:20*1024*1024});text=r.stdout||''}catch{}
      if(text.trim().length<80){
        const prefix=req.file.path+'-page'; await execFileAsync('pdftoppm',['-r','180','-png','-singlefile',req.file.path,prefix],{maxBuffer:5*1024*1024});
        const r=await execFileAsync('tesseract',[prefix+'.png','stdout','-l','eng','--psm','11'],{maxBuffer:20*1024*1024}); text=r.stdout||''; fs.unlink(prefix+'.png',()=>{});
      }
    }else{
      const r=await execFileAsync('tesseract',[req.file.path,'stdout','-l','eng','--psm','11'],{maxBuffer:20*1024*1024}); text=r.stdout||'';
    }
    fs.unlink(req.file.path,()=>{}); res.json({ok:true,text,engine:'tesseract-local',apiCost:0});
  }catch(e){fs.unlink(req.file.path,()=>{});res.status(503).json({error:'Local OCR server engine unavailable. Install tesseract-ocr and poppler-utils for PDF fallback.',code:'LOCAL_OCR_UNAVAILABLE'})}
});

app.post("/api/documents/upload",auth,roles("OWNER","ADMIN","STAFF"),upload.single("file"),async(req,res)=>{if(!req.file)return res.status(400).json({error:"file required"});const hash=crypto.createHash("sha256").update(fs.readFileSync(req.file.path)).digest("hex");const dup=await pool.query("SELECT id FROM documents WHERE sha256=$1",[hash]);if(dup.rowCount){fs.unlinkSync(req.file.path);return res.status(409).json({error:"Duplicate document",documentId:dup.rows[0].id})}const r=await pool.query("INSERT INTO documents(original_name,storage_path,mime_type,sha256,ocr_status,uploaded_by) VALUES($1,$2,$3,$4,'PENDING',$5) RETURNING id,original_name,ocr_status",[req.file.originalname,req.file.path,req.file.mimetype,hash,req.user.sub]);res.status(201).json({...r.rows[0],message:"Document stored. Connect OCR provider to process it."})});

app.get("/api/workers",auth,async(req,res)=>res.json((await pool.query("SELECT * FROM workers WHERE active=true ORDER BY name")).rows));
app.post("/api/workers",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{const {name,phone,daily_wage=0,hourly_ot=0}=req.body;const r=await pool.query("INSERT INTO workers(name,phone,daily_wage,hourly_ot) VALUES($1,$2,$3,$4) RETURNING *",[name,phone,daily_wage,hourly_ot]);res.status(201).json(r.rows[0])});
app.post("/api/attendance",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{const {workerId,workDate,status,overtimeHours=0}=req.body;const r=await pool.query(`INSERT INTO attendance(worker_id,work_date,status,overtime_hours) VALUES($1,$2,$3,$4) ON CONFLICT(worker_id,work_date) DO UPDATE SET status=EXCLUDED.status,overtime_hours=EXCLUDED.overtime_hours RETURNING *`,[workerId,workDate,status,overtimeHours]);res.json(r.rows[0])});

app.get("/api/reports/pnl",auth,async(req,res)=>{const month=req.query.month||new Date().toISOString().slice(0,7);const r=await pool.query(`SELECT voucher_type,SUM(total_amount) total FROM vouchers WHERE to_char(voucher_date,'YYYY-MM')=$1 AND status='POSTED' GROUP BY voucher_type`,[month]);const m=Object.fromEntries(r.rows.map(x=>[x.voucher_type,Number(x.total)]));const revenue=m.SALE||0,purchases=m.PURCHASE||0,expenses=(m.EXPENSE||0)+(m.PAYMENT||0);res.json({month,revenue,purchases,expenses,profit:revenue-purchases-expenses,breakdown:m})});

app.post("/api/documents/:id/process",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{
  try{
    const d=(await pool.query("SELECT * FROM documents WHERE id=$1",[req.params.id])).rows[0];
    if(!d)return res.status(404).json({error:"document not found"});
    if(d.ocr_status==='POSTED')return res.json({id:d.id,ocr_status:d.ocr_status,extracted_json:d.extracted_json});
    await pool.query("UPDATE documents SET ocr_status='PROCESSING' WHERE id=$1",[d.id]);
    const extracted=await extractInvoiceWithAI(d.storage_path,d.mime_type);
    const normalized={vendor:extracted.vendor||null,invoiceNumber:extracted.invoiceNumber||null,date:extracted.date||null,currency:extracted.currency||'INR',lines:Array.isArray(extracted.lines)?extracted.lines:[],subtotal:Number(extracted.subtotal||0),gstRate:Number(extracted.gstRate||0),total:Number(extracted.total||0),confidence:Number(extracted.confidence||0),warnings:Array.isArray(extracted.warnings)?extracted.warnings:[]};
    const r=await pool.query("UPDATE documents SET extracted_json=$1,ocr_status='REVIEW' WHERE id=$2 RETURNING id,ocr_status,extracted_json",[JSON.stringify(normalized),d.id]);
    await audit(pool,req.user.sub,"AI_EXTRACT","DOCUMENT",d.id,{confidence:normalized.confidence,lines:normalized.lines.length});
    res.json(r.rows[0]);
  }catch(e){console.error(e);await pool.query("UPDATE documents SET ocr_status='ERROR' WHERE id=$1",[req.params.id]).catch(()=>{});res.status(e.status||500).json({error:e.message||'OCR processing failed',code:e.code||'OCR_ERROR'})}
});

app.post("/api/documents/:id/extraction",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{const {id}=req.params;const extracted=req.body?.extracted;if(!extracted||typeof extracted!=="object")return res.status(400).json({error:"extracted object required"});const normalized={vendor:extracted.vendor||extracted.supplier||null,invoiceNumber:extracted.invoiceNumber||extracted.invoiceNo||null,date:extracted.date||null,currency:extracted.currency||"INR",lines:Array.isArray(extracted.lines)?extracted.lines.map(x=>({description:x.description||x.name||null,wood:x.wood||null,lengthFt:Number(x.lengthFt||x.length||0)||null,widthIn:Number(x.widthIn||x.width||0)||null,thicknessIn:Number(x.thicknessIn||x.thickness||0)||null,qty:Number(x.qty||x.quantity||0)||null,cft:Number(x.cft||0)||null,rate:Number(x.rate||0)||null,amount:Number(x.amount||0)||null,confidence:Number(x.confidence??0)})):[],subtotal:Number(extracted.subtotal||0),gstRate:Number(extracted.gstRate||0),total:Number(extracted.total||0),confidence:Number(extracted.confidence??0),warnings:Array.isArray(extracted.warnings)?extracted.warnings:[]};const r=await pool.query("UPDATE documents SET extracted_json=$1,ocr_status='REVIEW' WHERE id=$2 RETURNING id,ocr_status,extracted_json",[JSON.stringify(normalized),id]);if(!r.rowCount)return res.status(404).json({error:"document not found"});await audit(pool,req.user.sub,"EXTRACT","DOCUMENT",id,{confidence:normalized.confidence,lines:normalized.lines.length});res.json(r.rows[0])});


app.get("/api/documents/:id",auth,async(req,res)=>{
  const r=await pool.query("SELECT id,original_name,mime_type,ocr_status,extracted_json,created_at FROM documents WHERE id=$1",[req.params.id]);
  if(!r.rowCount)return res.status(404).json({error:"document not found"});
  res.json(r.rows[0]);
});

app.post("/api/documents/:id/approve",auth,roles("OWNER","ADMIN","STAFF"),async(req,res)=>{
  try{
    const result=await tx(async c=>{
      const d=(await c.query("SELECT * FROM documents WHERE id=$1 FOR UPDATE",[req.params.id])).rows[0];
      if(!d)return Object.assign(new Error("document not found"),{status:404});
      if(d.ocr_status==='POSTED')return {alreadyPosted:true};
      const x=typeof d.extracted_json==='string'?JSON.parse(d.extracted_json):d.extracted_json;
      if(!x||!x.lines?.length)throw Object.assign(new Error("No extracted line items"),{status:400});
      const partyName=x.vendor||x.supplier||req.body.party;
      if(!partyName)throw Object.assign(new Error("Vendor is required"),{status:400});
      let pr=await c.query("SELECT * FROM parties WHERE lower(name)=lower($1) LIMIT 1",[partyName]);
      if(!pr.rowCount)pr=await c.query("INSERT INTO parties(name,type) VALUES($1,'VENDOR') RETURNING *",[partyName]);
      const party=pr.rows[0];
      const lines=x.lines.map(l=>({wood:l.wood,lengthFt:Number(l.lengthFt||l.length||0),widthIn:Number(l.widthIn||l.width||4),thicknessIn:Number(l.thicknessIn||l.thickness||1),qty:Number(l.qty||l.quantity||0),cft:Number(l.cft||0),rate:Number(l.rate||0),amount:Number(l.amount||0),hsn:l.hsn||null}));
      for(const l of lines){
        if(!l.wood||l.qty<=0||l.lengthFt<=0||l.widthIn<=0||l.thicknessIn<=0||l.rate<=0)throw Object.assign(new Error("Each timber line needs wood, dimensions, quantity and rate"),{status:400});
        if(!l.cft)l.cft=volumeCft(l.lengthFt,l.widthIn,l.thicknessIn,l.qty);
        if(!l.amount)l.amount=l.cft*l.rate;
      }
      const taxable=lines.reduce((s,l)=>s+l.amount,0);
      const gstRate=Number(x.gstRate||0); const g=gstSplit(taxable,gstRate,false); const total=Number(x.total||g.total);
      const voucherNo=x.invoiceNumber||`PUR-${Date.now()}`;
      const dup=await c.query("SELECT id FROM vouchers WHERE voucher_type='PURCHASE' AND reference_no=$1",[x.invoiceNumber||'']);
      if(x.invoiceNumber&&dup.rowCount)throw Object.assign(new Error("Invoice already posted"),{status:409});
      const v=(await c.query(`INSERT INTO vouchers(voucher_no,voucher_type,party_id,voucher_date,taxable_amount,gst_rate,cgst,sgst,igst,total_amount,reference_no,created_by) VALUES($1,'PURCHASE',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[voucherNo,party.id,x.date||new Date().toISOString().slice(0,10),taxable,gstRate,g.cgst,g.sgst,g.igst,total,x.invoiceNumber||null,req.user.sub])).rows[0];
      for(const l of lines){
        await c.query(`INSERT INTO voucher_lines(voucher_id,wood,length_ft,width_in,thickness_in,qty,cft,rate,amount,hsn) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[v.id,l.wood,l.lengthFt,l.widthIn,l.thicknessIn,l.qty,l.cft,l.rate,l.amount,l.hsn]);
        await c.query(`INSERT INTO stock_batches(wood,length_ft,width_in,thickness_in,qty_in,cft_in,cost_rate,source_voucher) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[l.wood,l.lengthFt,l.widthIn,l.thicknessIn,l.qty,l.cft,l.rate,v.id]);
      }
      await c.query("INSERT INTO journal_entries(voucher_id,account_debit,account_credit,amount,party_id) VALUES($1,'Inventory','Accounts Payable',$2,$3)",[v.id,total,party.id]);
      await c.query("UPDATE documents SET ocr_status='POSTED' WHERE id=$1",[d.id]);
      await audit(c,req.user.sub,"POST","DOCUMENT",d.id,{voucherId:v.id,lines:lines.length,total});
      return {alreadyPosted:false,voucher:v};
    });
    res.status(result.alreadyPosted?200:201).json(result);
  }catch(e){console.error(e);res.status(e.status||500).json({error:e.status?e.message:"Could not approve document"})}
});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Internal server error"})});
app.listen(Number(process.env.PORT)||8080,()=>console.log(`Furniture Hisaab API running on ${process.env.PORT||8080}`));
