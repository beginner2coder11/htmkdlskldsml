
const E={
 uid(prefix="ID"){return prefix+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,7)},
 num(v){return Number(v)||0},
 round(v,n=2){const p=10**n;return Math.round((v+Number.EPSILON)*p)/p},
 slab(wood,length){
   const rates=DB.woodRates[wood]||[];
   return rates.find(x=>length>=x.min-1e-9 && length<=x.max+1e-9)||null
 },
 rate(wood,length,thickness){
   const s=this.slab(wood,length);
   if(!s)return {base:0,surcharge:0,effective:0,slab:null};
   const surcharge=Number(thickness)===2?30:0;
   return {base:s.rate,surcharge,effective:s.rate+surcharge,slab:s};
 },
 volume(length,widthIn,thicknessIn,qty=1){return (length*(widthIn/12)*(thicknessIn/12))*qty},
 amount(wood,length,width,thickness,qty){const r=this.rate(wood,length,thickness),cft=this.volume(length,width,thickness,qty);return {cft,rate:r.effective,base:r.base,surcharge:r.surcharge,total:cft*r.effective}},
 postPurchase(x){
   const item={id:this.uid("STK"),date:x.date,wood:x.wood,length:x.length,width:x.width,thickness:x.thickness,qty:x.qty,cft:x.cft,rate:x.rate,amount:x.amount,type:"IN",ref:x.ref||""};
   DB.inventory.push(item);
   this.journal({date:x.date,ref:x.ref||item.id,description:"Timber purchase",debit:"Inventory",credit:x.party||"Supplier",amount:x.amount,party:x.party||""});
 },
 postSale(x){
   DB.inventory.push({id:this.uid("STK"),date:x.date,wood:x.wood,length:x.length,width:x.width,thickness:x.thickness,qty:x.qty,cft:x.cft,rate:x.rate,amount:x.amount,type:"OUT",ref:x.ref||""});
   this.journal({date:x.date,ref:x.ref||"",description:"Timber/furniture sale",debit:x.party||"Customer",credit:"Sales",amount:x.amount,party:x.party||""});
 },
 journal(x){
   DB.ledger.push({id:this.uid("J"),...x});
 },
 inventoryBalance(){
   const m={};
   for(const x of DB.inventory){
     const key=[x.wood,x.length,x.width,x.thickness].join("|");
     if(!m[key])m[key]={...x,cft:0,qty:0,amount:0};
     const sign=x.type==="OUT"?-1:1;m[key].cft+=sign*this.num(x.cft);m[key].qty+=sign*this.num(x.qty);m[key].amount+=sign*this.num(x.amount);
   }
   return Object.values(m).filter(x=>Math.abs(x.cft)>1e-9);
 },
 partyBalance(name){
   let b=0;
   for(const x of DB.ledger) if(x.party===name){b+=(x.debit===name?x.amount:0);b-=(x.credit===name?x.amount:0)}
   return b;
 },
 workerWages(workerId,from,to){
   const w=DB.workers.find(x=>x.id===workerId);if(!w)return 0;
   let total=0;
   DB.attendance.filter(a=>a.workerId===workerId&&a.date>=from&&a.date<=to).forEach(a=>{
     total += a.status==="P"?w.daily: a.status==="HD"?w.daily/2:0;
     total += this.num(a.overtime)*this.num(w.hourly);
   });
   const adv=DB.advances.filter(a=>a.workerId===workerId&&a.date>=from&&a.date<=to).reduce((s,a)=>s+this.num(a.amount),0);
   return {gross:total,advances:adv,net:total-adv};
 },
 pAndL(month){
   const rows=DB.ledger.filter(x=>!month||x.date.startsWith(month));
   const revenue=rows.filter(x=>x.credit==="Sales").reduce((s,x)=>s+x.amount,0);
   const purchases=rows.filter(x=>x.description==="Timber purchase").reduce((s,x)=>s+x.amount,0);
   const labour=rows.filter(x=>x.description==="Labour wage").reduce((s,x)=>s+x.amount,0);
   const materialUsage=rows.filter(x=>x.description==="Material consumption").reduce((s,x)=>s+x.amount,0);
   const expenses=rows.filter(x=>["Expense","Freight","Labour wage","Material consumption"].includes(x.description)).reduce((s,x)=>s+x.amount,0);
   return {revenue,purchases,labour,materialUsage,expenses,totalExpenses:expenses,profit:revenue-expenses};
 }
};

E.audit=function(action,entity,id,details={}){
  DB.audit.push({id:this.uid("AUD"),ts:new Date().toISOString(),user:"local-user",action,entity,entityId:id,details});
};
E.safeNumber=function(v){const n=Number(v);return Number.isFinite(n)?n:0};
E.invoiceFingerprint=function(x){
  return [String(x.party||"").trim().toLowerCase(),x.date,x.invoiceNo||"",x.amount||0].join("|");
};
E.isDuplicateInvoice=function(x){
  const fp=this.invoiceFingerprint(x);
  return DB.invoices.some(i=>this.invoiceFingerprint(i)===fp);
};
E.postPurchase=function(x){
  const id=this.uid("STK");
  const item={id,date:x.date,wood:x.wood,length:+x.length,width:+x.width,thickness:+x.thickness,
    qty:+x.qty,cft:+x.cft,rate:+x.rate,amount:+x.amount,type:"IN",ref:x.ref||"",
    invoiceNo:x.invoiceNo||"",batchId:this.uid("BATCH"),gstRate:+(x.gstRate||0),gstAmount:+(x.gstAmount||0),totalAmount:+x.totalAmount||(+x.amount||0)+(+x.gstAmount||0)};
  DB.inventory.push(item); DB.stockBatches.push({...item,status:"OPEN"});
  DB.materialMovements=DB.materialMovements||[];
  DB.materialItems=DB.materialItems||[];
  const matName=x.wood||"Timber";
  DB.materialMovements.push({id:this.uid("MAT"),date:x.date,type:"IN",category:"Timber",item:matName,unit:"CFT",qty:+x.cft||0,rate:+x.rate||0,amount:+x.amount||0,party:x.party||"",ref:x.ref||"",invoiceNo:x.invoiceNo||""});
  if(!DB.materialItems.some(i=>i.name===matName&&i.category==="Timber")) DB.materialItems.push({name:matName,category:"Timber",unit:"CFT",active:true});
  this.journal({date:x.date,ref:x.ref||id,description:"Timber purchase",debit:"Inventory",credit:x.party||"Supplier",amount:item.totalAmount,party:x.party||""});
  this.audit("CREATE","PURCHASE",id,item); return id;
};
E.postSale=function(x){
  const id=this.uid("STK");
  const taxable=+x.amount||0, gstAmount=+x.gstAmount||0, totalAmount=+x.totalAmount||taxable+gstAmount;
  const row={id,date:x.date,wood:x.wood,length:+x.length,width:+x.width,thickness:+x.thickness,
    qty:+x.qty,cft:+x.cft,rate:+x.rate,amount:taxable,type:"OUT",ref:x.ref||"",invoiceNo:x.invoiceNo||"",gstRate:+(x.gstRate||0),gstAmount,totalAmount};
  DB.inventory.push(row);
  this.journal({date:x.date,ref:x.ref||id,description:"Timber/furniture sale",debit:x.party||"Customer",credit:"Sales",amount:totalAmount,party:x.party||""});
  this.audit("CREATE","SALE",id,row); return id;
};
E.validateInvoice=function(x){
  const errors=[];
  if(!x.party)errors.push("Vendor is required");
  if(!x.date)errors.push("Invoice date is required");
  if(!x.wood)errors.push("Wood type is required");
  if(!(+x.qty>0))errors.push("Quantity must be greater than zero");
  if(!(+(x.length)>0))errors.push("Length is required");
  if(this.isDuplicateInvoice(x))errors.push("Possible duplicate invoice");
  return errors;
};
E.gst=function(taxable,rate){const r=+rate||0;return {taxable:+taxable,gst:+taxable*r/100,total:+taxable*(1+r/100)}};


// Generic material inventory engine: everything other than dimensioned timber.
E.materialCategories=["Timber","Ply / MDF","Hardware","Paint","Sealer","Lacquer","Thinner","Polish / Finishing","Abrasives","Glass","Packaging","Adhesives","Electrical","Fabric / Upholstery","Other"];
E.materialUnits=["CFT","Piece","Sheet","Pair","Set","Box","Packet","Kg","Litre","Meter","Roll","Sqft","Bundle"];
E.materialKey=function(category,item,unit){return [String(category||"Other"),String(item||"Unnamed"),String(unit||"Piece")].join("|")};
E.postMaterialPurchase=function(x){
  const qty=+x.qty||0, rate=+x.rate||0, amount=x.amount!=null?+x.amount:qty*rate, gstRate=+x.gstRate||0, gstAmount=x.gstAmount!=null?+x.gstAmount:amount*gstRate/100, totalAmount=amount+gstAmount;
  if(!(qty>0)) throw new Error("Purchase quantity must be greater than zero");
  const row={id:this.uid("MAT"),date:x.date||todayISO(),type:"IN",category:x.category||"Other",item:x.item||"Unnamed",unit:x.unit||"Piece",qty,rate,amount,gstRate,gstAmount,totalAmount,party:x.party||"",ref:x.ref||"",invoiceNo:x.invoiceNo||""};
  DB.materialMovements.push(row);
  DB.materialItems=DB.materialItems||[];
  if(!DB.materialItems.some(i=>i.name===row.item&&i.category===row.category)) DB.materialItems.push({name:row.item,category:row.category,unit:row.unit,active:true});
  this.journal({date:row.date,ref:row.ref||row.id,description:"Material purchase",debit:"Inventory",credit:row.party||"Supplier",amount:totalAmount,party:row.party||""});
  this.audit("CREATE","MATERIAL_PURCHASE",row.id,row); return row.id;
};
E.postMaterialUsage=function(x){
  const qty=+x.qty||0;
  if(!(qty>0)) throw new Error("Usage quantity must be greater than zero");
  const bal=this.materialBalance().find(b=>this.materialKey(b.category,b.item,b.unit)===this.materialKey(x.category,x.item,x.unit));
  if(!bal || qty>bal.balance+1e-9) throw new Error(`Insufficient stock. Available ${this.round(bal?.balance||0,3)} ${x.unit||bal?.unit||"unit"}`);
  const rate=+x.rate||bal.avgRate||0, amount=qty*rate;
  const row={id:this.uid("USE"),date:x.date||todayISO(),type:"OUT",category:x.category||"Other",item:x.item||"Unnamed",unit:x.unit||"Piece",qty,rate,amount,job:x.job||"",reference:x.reference||"",notes:x.notes||""};
  DB.materialMovements.push(row);
  this.journal({date:row.date,ref:row.reference||row.id,description:"Material consumption",debit:"Production / Material Usage",credit:"Inventory",amount,party:""});
  this.audit("CREATE","MATERIAL_USAGE",row.id,row); return row.id;
};
E.materialBalance=function(){
  const m={};
  for(const x of (DB.materialMovements||[])){
    const key=this.materialKey(x.category,x.item,x.unit);
    if(!m[key]) m[key]={category:x.category,item:x.item,unit:x.unit,purchased:0,used:0,adjusted:0,purchaseValue:0,usageValue:0};
    if(x.type==="IN"){m[key].purchased+=this.num(x.qty);m[key].purchaseValue+=this.num(x.amount)}
    else if(x.type==="OUT"){m[key].used+=this.num(x.qty);m[key].usageValue+=this.num(x.amount)}
    else {m[key].adjusted+=this.num(x.qty)}
  }
  return Object.values(m).map(x=>({...x,balance:x.purchased-x.used+x.adjusted,avgRate:x.purchased?x.purchaseValue/x.purchased:0,value:(x.purchased-x.used+x.adjusted)*(x.purchased?x.purchaseValue/x.purchased:0)}));
};
E.materialUsageByCategory=function(){
  const m={}; for(const x of (DB.materialMovements||[])) if(x.type==="OUT") m[x.category]=(m[x.category]||0)+this.num(x.amount); return m;
};

// Production / Job Order engine: reserves a material BOM, then atomically consumes it.
E.createProductionJob=function(x){
  DB.productionJobs=DB.productionJobs||[];
  const lines=(x.lines||[]).map(l=>({category:l.category||'Other',item:l.item||'Unnamed',unit:l.unit||'Piece',qty:+l.qty||0,rate:+l.rate||0,cost:(+l.qty||0)*(+l.rate||0)})).filter(l=>l.qty>0);
  if(!x.jobNo) throw new Error('Job / Order No. is required');
  if(!x.product) throw new Error('Product / Furniture name is required');
  if(!lines.length) throw new Error('Add at least one material');
  if(DB.productionJobs.some(j=>String(j.jobNo).trim().toLowerCase()===String(x.jobNo).trim().toLowerCase())) throw new Error('Duplicate job number');
  const plannedCost=lines.reduce((s,l)=>s+l.cost,0);
  const job={id:this.uid('JOB'),jobNo:String(x.jobNo),date:x.date||todayISO(),product:String(x.product),quantity:+x.quantity||1,party:x.party||'',notes:x.notes||'',status:'PLANNED',lines,plannedCost,actualCost:0,labourCost:0,totalCost:0,createdAt:new Date().toISOString()};
  DB.productionJobs.push(job); this.audit('CREATE','PRODUCTION_JOB',job.id,job); return job;
};

E._timberAvailable=function(wood){
  return DB.inventory.filter(x=>x.type==='IN'&&String(x.wood).toLowerCase()===String(wood).toLowerCase()).reduce((s,x)=>s+this.num(x.cft),0)
    + DB.inventory.filter(x=>x.type==='OUT'&&String(x.wood).toLowerCase()===String(wood).toLowerCase()).reduce((s,x)=>s-this.num(x.cft),0);
};

E._consumeTimberCFT=function(wood,cft,jobId,date){
  let need=this.num(cft), cost=0;
  if(need<=0) return 0;
  const available=this._timberAvailable(wood);
  if(need>available+1e-9) throw new Error(`Insufficient ${wood} timber. Available ${this.round(available,3)} CFT, required ${this.round(need,3)} CFT`);
  const batches=DB.inventory.filter(x=>x.type==='IN'&&String(x.wood).toLowerCase()===String(wood).toLowerCase()&&this.num(x.cft)>0).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  for(const b of batches){
    if(need<=1e-9) break;
    const take=Math.min(need,this.num(b.cft));
    const rate=this.num(b.rate);
    DB.inventory.push({id:this.uid('STK'),date:date,type:'OUT',wood:b.wood,length:b.length,width:b.width,thickness:b.thickness,qty:this.num(b.qty)*(take/Math.max(this.num(b.cft),1e-9)),cft:take,rate,amount:take*rate,type:'OUT',ref:jobId,job:jobId});
    cost+=take*rate; need-=take;
  }
  if(need>1e-8) throw new Error(`Unable to allocate ${wood} timber stock`);
  return cost;
};

E.consumeProductionJob=function(jobId){
  DB.productionJobs=DB.productionJobs||[];
  const job=DB.productionJobs.find(j=>j.id===jobId);
  if(!job) throw new Error('Production job not found');
  if(job.status==='CONSUMED') throw new Error('This job is already consumed');

  // Transaction snapshot: a production consumption must be all-or-nothing.
  const snapshot=structuredClone(DB);
  try{
    // Aggregate duplicate BOM lines first. This prevents partial consumption when
    // the same material appears more than once in a job.
    const required=new Map();
    for(const l of (job.lines||[])){
      const qty=+l.qty||0;
      if(!(qty>0)) continue;
      const key=this.materialKey(l.category,l.item,l.unit);
      const existing=required.get(key);
      if(existing) existing.qty+=qty;
      else required.set(key,{category:l.category||'Other',item:l.item||'Unnamed',unit:l.unit||'Piece',qty});
    }
    if(!required.size) throw new Error('Production job has no valid material lines');

    // Validate the complete aggregated requirement before changing anything.
    const balances=this.materialBalance();
    for(const l of required.values()){
      if(l.category==='Timber'){
        if(l.unit!=='CFT') throw new Error(`Timber job line ${l.item} must use CFT`);
        const available=this._timberAvailable(l.item);
        if(l.qty>available+1e-9) throw new Error(`${l.item}: short by ${this.round(l.qty-available,3)} CFT`);
      } else {
        const b=balances.find(x=>this.materialKey(x.category,x.item,x.unit)===this.materialKey(l.category,l.item,l.unit));
        if(!b || l.qty>b.balance+1e-9) throw new Error(`${l.item}: available ${this.round(b?.balance||0,3)} ${l.unit}, required ${this.round(l.qty,3)} ${l.unit}`);
      }
    }

    const usageIds=[]; let actualCost=0;
    for(const l of required.values()){
      let cost=0;
      if(l.category==='Timber'){
        cost=this._consumeTimberCFT(l.item,l.qty,job.id,job.date);
        const rate=l.qty?cost/l.qty:0;
        const uid=this.uid('USE');
        DB.materialMovements.push({id:uid,date:job.date,type:'OUT',category:'Timber',item:l.item,unit:'CFT',qty:l.qty,rate,amount:cost,job:job.jobNo,reference:job.id,notes:'Production Job'});
        this.journal({date:job.date,ref:job.id,description:'Material consumption',debit:'Production / Material Usage',credit:'Inventory',amount:cost,party:job.party||''});
        this.audit('CREATE','MATERIAL_USAGE',uid,{job:job.jobNo,item:l.item,qty:l.qty,unit:l.unit,amount:cost});
        usageIds.push(uid);
      } else {
        const before=this.materialBalance().find(b=>this.materialKey(b.category,b.item,b.unit)===this.materialKey(l.category,l.item,l.unit));
        const rate=before?.avgRate||0;
        const id=this.postMaterialUsage({date:job.date,category:l.category,item:l.item,unit:l.unit,qty:l.qty,rate,job:job.jobNo,reference:job.id,notes:'Production Job'});
        cost=l.qty*rate; usageIds.push(id);
      }
      actualCost+=cost;
    }
    job.status='WIP'; job.actualCost=actualCost; job.consumedAt=new Date().toISOString(); job.usageIds=usageIds; job.labourCost=this.jobLabourCost(job.jobNo); job.totalCost=job.actualCost+job.labourCost;
    this.audit('CONSUME','PRODUCTION_JOB',job.id,{jobNo:job.jobNo,actualCost,usageIds});
    return {job,cost:actualCost,usageIds};
  }catch(err){
    DB=snapshot;
    throw err;
  }
};

// Production lifecycle: PLANNED -> WIP -> READY -> DISPATCHED.
// Labour is linked through attendance.jobNo and is included in finished cost.
E.jobLabourCost=function(jobNo){
  const total=(DB.attendance||[]).filter(a=>String(a.jobNo||'').trim().toLowerCase()===String(jobNo||'').trim().toLowerCase()).reduce((sum,a)=>{
    const w=(DB.workers||[]).find(x=>x.id===a.workerId); if(!w) return sum;
    const base=a.status==='P'?this.num(w.daily):(a.status==='HD'?this.num(w.daily)/2:0);
    return sum+base+this.num(a.overtime)*this.num(w.hourly);
  },0);
  return this.round(total,2);
};
E.refreshJobCost=function(jobId){
  const job=(DB.productionJobs||[]).find(j=>j.id===jobId); if(!job) throw new Error('Production job not found');
  // Once any finished quantity has been dispatched, its production cost is locked.
  // This prevents later labour edits from changing the historical cost of dispatched goods.
  const fg=(DB.finishedGoods||[]).find(x=>x.jobId===job.id);
  if(job.status==='DISPATCHED' || (fg && this.num(fg.availableQty) < this.num(fg.quantity))) {
    job.labourCost=this.num(job.labourCost);
    job.totalCost=this.num(job.actualCost)+this.num(job.labourCost);
    job.unitCost=job.quantity?job.totalCost/job.quantity:job.totalCost;
    return job;
  }
  job.labourCost=this.jobLabourCost(job.jobNo);
  job.totalCost=this.num(job.actualCost)+this.num(job.labourCost);
  job.unitCost=job.quantity?job.totalCost/job.quantity:job.totalCost;
  if(fg && fg.status==='READY'){
    fg.totalCost=job.totalCost;
    fg.unitCost=job.unitCost;
  }
  return job;
};
E.completeProductionJob=function(jobId){
  const job=(DB.productionJobs||[]).find(j=>j.id===jobId); if(!job) throw new Error('Production job not found');
  if(job.status==='DISPATCHED') throw new Error('Job already dispatched');
  if(job.status!=='WIP' && job.status!=='CONSUMED') throw new Error('Consume materials first; job must be WIP');
  this.refreshJobCost(jobId);
  job.status='READY'; job.completedAt=new Date().toISOString();
  DB.finishedGoods=DB.finishedGoods||[];
  const existing=DB.finishedGoods.find(x=>x.jobId===job.id);
  const fg={id:existing?.id||this.uid('FG'),jobId:job.id,jobNo:job.jobNo,product:job.product,quantity:job.quantity||1,availableQty:job.quantity||1,totalCost:job.totalCost,unitCost:job.unitCost,status:'READY',date:job.completedAt.slice(0,10),party:job.party||''};
  if(existing) Object.assign(existing,fg); else DB.finishedGoods.push(fg);
  this.audit('COMPLETE','PRODUCTION_JOB',job.id,{totalCost:job.totalCost,labourCost:job.labourCost,unitCost:job.unitCost});
  return fg;
};
E.dispatchFinishedGood=function(jobId,qty){
  const job=(DB.productionJobs||[]).find(j=>j.id===jobId); if(!job) throw new Error('Production job not found');
  const fg=(DB.finishedGoods||[]).find(x=>x.jobId===job.id); if(!fg) throw new Error('Finished good not found; complete the job first');
  const q=qty==null?fg.availableQty:+qty; if(!(q>0) || q>fg.availableQty+1e-9) throw new Error(`Dispatch quantity exceeds available finished stock (${fg.availableQty})`);
  fg.availableQty-=q; fg.status=fg.availableQty<=1e-9?'DISPATCHED':'READY';
  if(fg.availableQty<=1e-9) job.status='DISPATCHED';
  this.audit('DISPATCH','FINISHED_GOOD',fg.id,{jobNo:job.jobNo,qty:q,remaining:fg.availableQty});
  return {fg,qty:q};
};
E.wipSummary=function(){
  const jobs=(DB.productionJobs||[]).filter(j=>j.status==='WIP'||j.status==='CONSUMED');
  return {count:jobs.length,value:jobs.reduce((s,j)=>s+this.num(j.actualCost)+this.jobLabourCost(j.jobNo),0)};
};
E.finishedGoodsSummary=function(){
  const rows=(DB.finishedGoods||[]); return {count:rows.reduce((s,x)=>s+this.num(x.availableQty),0),value:rows.reduce((s,x)=>s+this.num(x.availableQty)*this.num(x.unitCost),0)};
};

