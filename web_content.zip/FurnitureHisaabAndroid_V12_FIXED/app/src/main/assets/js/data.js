
const seed = {
 settings:{business:"House of Vedha",currency:"₹",wastage:15,gstRate:18,invoicePrefix:"HV",financialYear:"2026-27"},
 woodRates:{
   Mango:[
     {min:1.5,max:2.25,rate:570},{min:2.5,max:3.5,rate:620},{min:3.75,max:4.75,rate:670},
     {min:5,max:5.25,rate:720},{min:5.5,max:6,rate:770}
   ],
   Acacia:[
     {min:1.5,max:2.25,rate:570},{min:2.5,max:3.25,rate:620},{min:3.5,max:4.25,rate:660},
     {min:4.5,max:4.75,rate:710},{min:5,max:5.25,rate:750},{min:5.5,max:6,rate:800}
   ],
   Sheesham:[
     {min:1.5,max:2,rate:750},{min:2.5,max:3,rate:800},{min:3.5,max:4,rate:900},
     {min:4.5,max:5,rate:950},{min:5.5,max:6,rate:1050}
   ],
   Teak:[{min:1.5,max:2,rate:1200},{min:2.5,max:3,rate:1300},{min:3.5,max:4,rate:1400}],
   Ash:[{min:1.5,max:2,rate:850},{min:2.5,max:3,rate:900},{min:3.5,max:4,rate:980}],
   Oak:[{min:1.5,max:2,rate:850},{min:2.5,max:3,rate:900},{min:3.5,max:4,rate:980}]
 },
 inventory:[],
 materialMovements:[],
 materialItems:[
   {name:"Mango",category:"Timber",unit:"CFT",active:true},
   {name:"Acacia / Babul",category:"Timber",unit:"CFT",active:true},
   {name:"Sheesham",category:"Timber",unit:"CFT",active:true},
   {name:"Plywood 18mm",category:"Ply / MDF",unit:"Sheet",active:true},
   {name:"MDF 6mm",category:"Ply / MDF",unit:"Sheet",active:true},
   {name:"Screws",category:"Hardware",unit:"Box",active:true},
   {name:"Hinges",category:"Hardware",unit:"Pair",active:true},
   {name:"Drawer Channels",category:"Hardware",unit:"Pair",active:true},
   {name:"Paint",category:"Paint",unit:"Litre",active:true},
   {name:"Sealer",category:"Sealer",unit:"Litre",active:true},
   {name:"Lacquer",category:"Lacquer",unit:"Litre",active:true},
   {name:"Thinner",category:"Thinner",unit:"Litre",active:true},
   {name:"Polish",category:"Polish / Finishing",unit:"Litre",active:true},
   {name:"Sandpaper",category:"Abrasives",unit:"Packet",active:true},
   {name:"Glass",category:"Glass",unit:"Sqft",active:true},
   {name:"Bubble Wrap",category:"Packaging",unit:"Roll",active:true},
   {name:"Carton",category:"Packaging",unit:"Piece",active:true},
   {name:"Plywood Packing",category:"Packaging",unit:"Sheet",active:true},
   {name:"Foam",category:"Packaging",unit:"Piece",active:true},
   {name:"Glue / Adhesive",category:"Adhesives",unit:"Kg",active:true},
   {name:"Other",category:"Other",unit:"Piece",active:true}
 ],
 parties:[],
 workers:[],
 attendance:[],
 advances:[],
 vouchers:[],
 ledger:[],
 invoices:[],audit:[],stockBatches:[],documents:[],productionJobs:[],finishedGoods:[]
};
function loadDB(){
 const raw=localStorage.getItem("furnitureHisaabDB");
 if(!raw){localStorage.setItem("furnitureHisaabDB",JSON.stringify(seed));return structuredClone(seed)}
 try{return {...structuredClone(seed),...JSON.parse(raw)} }catch(e){return structuredClone(seed)}
}
let DB=loadDB();
function saveDB(){localStorage.setItem("furnitureHisaabDB",JSON.stringify(DB))}
