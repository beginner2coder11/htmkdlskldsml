# Furniture Hisaab V11 — Final Check

Date: 2026-10-02

## Checks completed

- JavaScript syntax check: PASS for all frontend and backend JS files.
- Local engine smoke test: PASS.
- Material inventory: timber + ply/MDF + hardware + lacquer + packaging purchase/usage/balance tested.
- Production Job: material consumption, WIP, Finished Goods, unit cost and dispatch tested.
- OCR parser: supplier-independent categories tested for timber, thinner, lacquer, sealer and hardware.
- PDF text extraction parser tested with Sales-277 and Sales-288.
- Photographed invoice OCR parsing tested with the supplied Nakoda Wood Impex, Marudhar Industries and Marwar Suppliers invoice images using local Tesseract reference output.
- GST handling: CGST + SGST combined rate detection and total calculation tested.
- Duplicate invoice safety remains in the local posting engine.
- Mobile drawer/menu fix retained.
- PWA manifest/service worker retained and versioned to V11.

## Important OCR architecture

There is no paid API key requirement.

1. Browser OCR tries free Tesseract.js from CDN and runs locally on the phone/browser.
2. PDF text is read directly first; scanned PDFs fall back to OCR.
3. If browser OCR cannot load but the optional API/server is configured and logged in, the app can use `/api/ocr/local`.
4. The server OCR endpoint uses the open-source Tesseract binary and Poppler tools; it does not require an AI/API key.

A fully offline first-time browser OCR engine cannot be guaranteed in a static PWA because the OCR WASM engine itself must be downloaded once. The local server fallback removes the paid-API requirement.

## Invoice examples verified

- NAVAL TIMBERS Sales-277: vendor, invoice 277, date 12-09-2026, 3.72 CFT timber, ₹720/CFT, GST 18%, total ₹3,161.
- NAVAL TIMBERS Sales-288: four timber lines, total ₹6,382.
- MARUDHAR INDUSTRIES photographed invoice: invoice 701/26-27, date 21-May-2026, 20 L thinner + 20 L lacquer + 20 L sealer, taxable ₹8,300, GST 18%, total ₹9,794.
- MARWAR SUPPLIERS photographed invoice: invoice 26-27/MS2/1521, date 20-05-2026, two telescopic hardware items, taxable ₹416, GST 18%, total ₹491.
- NAKODA WOOD IMPEX e-invoice: invoice 368, date 19-09-2026, three Mango Wood lines, taxable ₹9,200, GST 18%, total ₹10,856.

All extracted values remain editable and nothing is posted until the user confirms the invoice.
