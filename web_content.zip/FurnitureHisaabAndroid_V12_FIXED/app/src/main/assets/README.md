# Furniture Hisaab V11 — Production + Inventory + Accounts + PWA

# Furniture Hisaab v7.0

Production-oriented offline-first accounting, timber inventory, labour and invoice-ingestion application for a furniture/timber business.

## V7 highlights
- Generic material inventory beyond timber: Ply/MDF, Hardware, Paint, Finishing (Sealer/Lacquer/Thinner/Polish), Abrasives, Glass, Packaging, Adhesives, Electrical, Fabric/Upholstery and Other.
- Material Purchase → Material Usage → live Purchased / Used / Balance tracking.
- Timber purchases are also reflected in the generic Timber CFT balance while dimension-wise timber stock remains available.
- Sales vouchers are no longer the primary material movement; production consumption is recorded through Material Usage.
- Material master and stock adjustment workflow.
- Invoice review supports generic purchase lines as well as dimensioned timber lines.

## V6 highlights
- Zero-API invoice reading: no OpenAI/API key required.
- Local OCR in the browser for invoice photos; PDF text extraction plus local OCR fallback for scanned PDF pages.
- Supplier-independent heuristic parser for vendor, invoice number/date, GST, timber dimensions, quantity, rate, CFT and amount.
- Confidence/warnings + mandatory human review before posting.
- Works without cloud login; if a cloud API is configured, approved local entries can sync and failed syncs enter the offline queue.

## V5 highlights
- Cloud purchase/sale posting to PostgreSQL with transactional stock + double-entry journal updates.
- Offline queue when the API is unavailable.
- Supplier-independent AI invoice ingestion: upload image/PDF → semantic extraction → structured normalized JSON → confidence/warnings → editable review → explicit approval → stock + ledger posting.
- Optional OpenAI Responses API adapter. The API key stays on the server; it is never placed in browser code.
- SHA-256 duplicate document detection and invoice reference duplicate protection.
- Atomic document approval: voucher, voucher lines, stock batches, journal entry and document status update occur in one database transaction.
- Sale stock validation with locked FIFO-style batch allocation. Negative stock is rejected.
- Roles: OWNER / ADMIN / STAFF / VIEWER.
- Timber slab engine, GST, labour/hazri, ledgers, P&L, audit trail and JSON backup retained.

## Timber rules
- Mango and Acacia can use configured quarter-foot slabs.
- Sheesham/Rosewood, Teak, Ash and Oak can use configured half-foot slabs.
- 2-inch thickness adds ₹30/CFT to the matched base slab.
- CFT = length(ft) × width(in)/12 × thickness(in)/12 × quantity.

## Optional cloud setup
1. Copy `server/.env.example` to `server/.env`.
2. Set `DATABASE_URL` and a strong `JWT_SECRET`.
3. **No AI API key is required for V6 invoice reading.** OpenAI configuration from V5 is optional and not used by the local invoice reader.
4. Start PostgreSQL and apply `server/sql/schema.sql`.
5. In `server/`, run `npm install` then `npm start`.
6. Open the web app, set API Base URL, register/login, then use **AI Invoice OCR**.

### AI invoice flow
The original document is stored with a SHA-256 fingerprint. The AI adapter reads the document semantically rather than relying on fixed supplier coordinates. It returns a strict normalized schema with confidence and warnings. The user reviews/edit fields before pressing **Confirm → Stock + Ledger**. The server revalidates required timber fields and performs posting transactionally.

The local invoice reader does not send invoice files to an external AI service. A first-time internet connection may be needed to load the Tesseract.js/PDF.js browser libraries; after the app assets are cached, the workflow can continue offline depending on browser cache/service-worker availability. For difficult/handwritten invoices, review and correction are required.

## Deployment
Run the frontend as a static site and the API/PostgreSQL in a protected server/container. Use HTTPS, strong secrets, restricted CORS, regular PostgreSQL backups, upload retention controls and an admin-only registration/invite workflow before public deployment.

## V6 local invoice flow
Invoice photo/PDF → local OCR → semantic heuristic parsing → confidence/warnings → editable review → approve → local Stock + Ledger → optional cloud sync.

The parser intentionally never invents missing timber dimensions, quantity or rate. When it cannot confidently identify a line, the user must complete it manually before posting.


## V8 Production / Job Orders
- Create a furniture job/order (e.g. HV-102 Bed).
- Add a material BOM: timber CFT, ply sheets, hardware, sealer, lacquer, thinner, polish, glass, packaging, etc.
- Planned material cost is calculated from the selected rates.
- **Consume All** checks every material before changing stock. If any item is short, nothing is consumed.
- Generic materials reduce Material Inventory; timber CFT also reduces dimensioned timber batches using FIFO-style purchase allocation.
- Actual job cost is recorded from the actual stock rates used.
- Job status changes from READY to CONSUMED and usage entries are linked to the job.
- Backup/restore includes production jobs.

## V9 Production Lifecycle
- Production jobs now follow PLANNED → WIP → READY → DISPATCHED.
- Attendance can carry an optional Job / Order No.; linked daily wage + OT is included in job labour cost.
- Finished Goods records are created when a WIP job is marked READY.
- Finished unit cost = actual material cost + linked labour cost, divided by produced quantity.
- Finished Goods / WIP page shows WIP value, ready stock, unit cost and dispatch actions.


## V11 final OCR / zero-API notes

- Browser OCR dynamically loads free Tesseract.js when needed; the app itself does not require an API key.
- PDF text is extracted directly first; scanned PDFs can use OCR.
- If browser OCR cannot load, an optional logged-in local OCR server endpoint `/api/ocr/local` uses open-source Tesseract + Poppler and costs ₹0 in API fees.
- OCR is supplier-independent: timber, ply/MDF, hardware, paint, sealer, lacquer, thinner, polish/finishing, abrasives, glass, packaging, adhesives, electrical and upholstery categories are supported.
- Review remains mandatory before stock/accounting posting.
- See `FINAL-CHECK.md` for the test matrix and invoice examples.
