# Furniture Hisaab Android App

This is a standalone Android WebView wrapper around the Furniture Hisaab V11 web app. It bundles the complete app inside the APK, so the core UI/data does not need a website URL.

## Build APK
Open this folder in Android Studio. Let Gradle sync/download Android SDK components, then choose:
Build > Build APK(s)

The debug APK will be under app/build/outputs/apk/debug/app-debug.apk

## Notes
- The app uses localStorage/IndexedDB-style browser storage inside WebView as supported by the bundled app.
- File upload is enabled for invoice photos/PDFs.
- Internet permission is retained for optional cloud/API functionality.
- No paid API key is embedded.


## V12 FIX
Fixed startup crash caused by missing `salesPage`, restored Sales Voucher UI/binding, added exact-size stock validation, GST capture on sales, and sales audit/ledger posting.
