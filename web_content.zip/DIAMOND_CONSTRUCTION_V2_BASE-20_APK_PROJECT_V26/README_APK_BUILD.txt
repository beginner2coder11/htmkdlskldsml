DIAMOND CONSTRUCTION V2 — BASE-20 APK PROJECT (WRAPPER VERSION 26)

This Android Studio project puts the latest computer software BASE-20 into the same WebView-style Android package used by the earlier APK. The bundled page is BASE-20 with its mobile layout/navigation controls. The app starts from the primary HTTPS route /assets/index.html. The older /web/index.html route is also explicitly served as a fallback, so both paths load the same bundled page. Firebase login and realtime sync use the secure appassets.androidplatform.net origin and Internet permission.

ANDROID APP
- Application ID: com.diamondconstruction.v2 (kept the same for an in-place app update)
- Version code: 26 (higher than wrapper V25)
- Version name: BASE-20-APK-26
- Screen orientation: unspecified, so Android portrait/landscape rotation remains enabled.

BUILD APK (Android Studio)
1. Extract this ZIP.
2. Open the included `project` folder in Android Studio.
3. Allow Gradle Sync to finish and install Android SDK Platform 35 if Android Studio requests it.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates `project/app/build/outputs/apk/debug/app-debug.apk`.

DATA AND INSTALLATION
- This package contains the BASE-20 software page and Android wrapper source; it does not contain the user's business records or Firebase database. V25 mobile layout improvements remain included: content widths are clamped to the viewport, long text wraps, forms and buttons wrap within panels, modal/dialog contents scroll internally, and wide tables scroll horizontally inside their own panel. Smaller phones and landscape screens use compact layouts.
- Keep the current app installed and do not clear its storage before installing an update. First confirm Firebase shows synced and make a separate software backup.
- The package ID and version code are set for an update over wrapper V25. Android also requires a matching signing key to update an installed app; if the installer rejects the APK as incompatible, do not uninstall the old app because that can remove its local WebView data.

CHECKS
- Verified that the bundled app page comes from `DAIY_BASE-20.zip` and includes the established mobile controls.
- Android WebView starts at `/assets/index.html`; `/web/index.html` remains explicitly supported as a fallback route.
- Firebase's HTTPS origin, Internet permission, Android package ID, rotation support, WebView local storage, and physical Back integration are retained. V26 uses `/assets/index.html` as the start page and explicitly maps both `/assets/` and `/web/` page requests to the bundled file.
- This is a build-ready Android Studio project ZIP, not a compiled APK. Android SDK/Android Studio is not available in this workspace to compile it here.
