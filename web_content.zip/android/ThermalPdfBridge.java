package YOUR.APP.PACKAGE;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;

/**
 * Add this bridge to the existing WebView:
 * webView.addJavascriptInterface(new ThermalPdfBridge(activity), "AndroidBridge");
 * Merge these methods into an existing AndroidBridge instead if one already exists.
 */
public class ThermalPdfBridge {
    private final Activity activity;
    private static final String WA_BUSINESS = "com.whatsapp.w4b";

    public ThermalPdfBridge(Activity activity) { this.activity = activity; }

    private File writePdf(String base64, String filename) throws Exception {
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        File dir = new File(activity.getCacheDir(), "shared_pdfs");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create PDF cache");
        String safe = filename == null ? "Thermal-Bill.pdf" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
        File file = new File(dir, safe);
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); out.flush(); }
        return file;
    }

    private Uri contentUri(File file) {
        return FileProvider.getUriForFile(activity,
                activity.getPackageName() + ".fileprovider", file);
    }

    @JavascriptInterface
    public boolean shareThermalPdfToNumber(String base64, String filename, String message, String phone) {
        try {
            File file = writePdf(base64, filename);
            Uri uri = contentUri(file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TEXT, message + "\nCustomer WhatsApp: +" + phone);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.runOnUiThread(() -> {
                try {
                    PackageManager pm = activity.getPackageManager();
                    if (isInstalled(pm, WA_BUSINESS)) {
                        // WhatsApp Business opens with the PDF attached.
                        // User selects/confirms the customer chat and taps Send.
                        send.setPackage(WA_BUSINESS);
                        activity.startActivity(send);
                    } else {
                        activity.startActivity(Intent.createChooser(send, "Share thermal bill PDF"));
                    }
                } catch (Exception e) {
                    Toast.makeText(activity, "WhatsApp Business share failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean openThermalPdf(String base64, String filename) {
        try {
            File file = writePdf(base64, filename);
            Uri uri = contentUri(file);
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri, "application/pdf");
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.runOnUiThread(() -> {
                try { activity.startActivity(Intent.createChooser(view, "Open / Print thermal PDF")); }
                catch (Exception e) {
                    Toast.makeText(activity, "PDF viewer / printer app not installed", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public boolean downloadThermalPdf(String base64, String filename) {
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String safe = filename == null ? "Thermal-Bill.pdf" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues values = new android.content.ContentValues();
                values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                Uri uri = activity.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (java.io.OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                    if (out == null) return false;
                    out.write(bytes);
                    out.flush();
                }
            } else {
                File dir = activity.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
                if (dir == null || (!dir.exists() && !dir.mkdirs())) return false;
                try (FileOutputStream out = new FileOutputStream(new File(dir, safe))) {
                    out.write(bytes);
                    out.flush();
                }
            }
            activity.runOnUiThread(() -> Toast.makeText(activity, "Thermal PDF saved to Downloads", Toast.LENGTH_LONG).show());
            return true;
        } catch (Exception e) { return false; }
    }

    private boolean isInstalled(PackageManager pm, String packageName) {
        try { pm.getPackageInfo(packageName, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }
}
