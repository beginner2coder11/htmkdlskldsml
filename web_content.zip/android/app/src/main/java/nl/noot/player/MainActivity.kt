package nl.noot.player

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage + IndexedDB (bibliotheek, instellingen)
            mediaPlaybackRequiresUserGesture = false
        }

        // Serveert public/noot.html uit de app-assets op https://appassets.androidplatform.net/assets/
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        // Moet vóór de activity STARTED worden aangemaakt (registreert de mapkiezer).
        val bridge = NootNativeBridge(this, webView)
        webView.addJavascriptInterface(bridge, "NootNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                bridge.intercept(request)                       // /media/<id> = jouw muziek
                    ?: assetLoader.shouldInterceptRequest(request.url) // /assets/... = de speler
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/noot.html")
        // Bestaande, eerder gekozen mappen direct weer inladen
        webView.postDelayed({ webView.evaluateJavascript("window.nootScan&&window.nootScan()", null) }, 800)
    }

    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
