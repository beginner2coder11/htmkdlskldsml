package nl.noot.player

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject

/**
 * Past bij het contract van public/noot.html:
 *   JS -> NootNative.requestScan()  : gebruiker kiest een map (SAF), alles eronder wordt gescand
 *   JS -> NootNative.scanAll()      : JSON [{id, n (bestandsnaam), p (pad), d}]
 *   Kotlin -> window.nootScan()     : JS leest scanAll() opnieuw uit
 *   Audio wordt afgespeeld van      : https://appassets.androidplatform.net/media/<id>
 *
 * GEBRUIK (in je MainActivity.onCreate, VOOR setContentView/STARTED):
 *   val bridge = NootNativeBridge(this, webView)
 *   webView.addJavascriptInterface(bridge, "NootNative")
 *   webView.webViewClient = object : WebViewClient() {
 *       override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) =
 *           bridge.intercept(r) ?: super.shouldInterceptRequest(v, r)  // of je assetLoader
 *   }
 */
class NootNativeBridge(
    private val activity: ComponentActivity,
    private val webView: WebView,
) {
    private class Track(val id: Int, val uri: Uri, val name: String, val path: String, val mime: String)

    private val prefs = activity.getSharedPreferences("noot", ComponentActivity.MODE_PRIVATE)
    private val tracks = LinkedHashMap<Int, Track>()
    private val audioExt = Regex(".*\\.(mp3|m4a|aac|wav|ogg|oga|flac|opus|wma)$", RegexOption.IGNORE_CASE)
    private var nextId = 1

    // Moet worden aangemaakt voordat de activity STARTED is (dus in onCreate).
    private val picker = activity.registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val roots = prefs.getStringSet("roots", emptySet())!!.toMutableSet()
            roots.add(uri.toString())
            prefs.edit().putStringSet("roots", roots).apply()
            webView.post { webView.evaluateJavascript("window.nootScan&&window.nootScan()", null) }
        }
    }

    private val audioPerm =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher = activity.registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            prefs.edit().putBoolean("device", true).apply()
            webView.post { webView.evaluateJavascript("window.nootScan&&window.nootScan()", null) }
        }
    }

    /** Hele telefoon scannen (Instellingen > Opnieuw scannen): vraagt eenmalig toestemming voor audio. */
    @JavascriptInterface
    fun requestScan() {
        activity.runOnUiThread {
            if (ContextCompat.checkSelfPermission(activity, audioPerm) == PackageManager.PERMISSION_GRANTED) {
                prefs.edit().putBoolean("device", true).apply()
                webView.evaluateJavascript("window.nootScan&&window.nootScan()", null)
            } else permLauncher.launch(audioPerm)
        }
    }

    /** Eén map kiezen (Hele map toevoegen). */
    @JavascriptInterface
    fun pickFolder() {
        // Opent direct in de map Music; de root van de telefoon mag Android niet laten kiezen.
        activity.runOnUiThread { picker.launch(Uri.parse("content://com.android.externalstorage.documents/document/primary%3AMusic")) }
    }

    @JavascriptInterface
    fun scanAll(): String {
        synchronized(tracks) {
            tracks.clear()
            nextId = 1
            val out = JSONArray()
            if (prefs.getBoolean("device", false) &&
                ContextCompat.checkSelfPermission(activity, audioPerm) == PackageManager.PERMISSION_GRANTED) {
                try { scanDevice(out) } catch (_: Exception) { }
            }
            for (s in prefs.getStringSet("roots", emptySet())!!) {
                val tree = Uri.parse(s)
                // Permissie kan zijn ingetrokken; sla zo'n map dan over.
                if (activity.contentResolver.persistedUriPermissions.none { it.uri == tree }) continue
                val rootId = DocumentsContract.getTreeDocumentId(tree)
                val rootName = rootId.substringAfterLast(':').substringAfterLast('/').ifEmpty { "Muziek" }
                val found = ArrayList<Track>()
                try { walk(tree, rootId, rootName, found) } catch (_: Exception) { }
                for (t in found) {
                    tracks[t.id] = t
                    out.put(JSONObject().put("id", t.id).put("n", t.name).put("p", t.path).put("d", 0))
                }
            }
            return out.toString()
        }
    }

    private fun scanDevice(out: JSONArray) {
        val cols = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.RELATIVE_PATH,
        )
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        activity.contentResolver.query(base, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val uri = ContentUris.withAppendedId(base, c.getLong(0))
                val name = c.getString(1) ?: continue
                val t = Track(nextId++, uri, name, c.getString(5) ?: "", "audio/mpeg")
                tracks[t.id] = t
                out.put(JSONObject().put("id", t.id).put("n", name).put("t", c.getString(2) ?: "")
                    .put("a", c.getString(3) ?: "").put("d", c.getLong(4)).put("p", t.path))
            }
        }
    }

    private fun walk(tree: Uri, docId: String, path: String, out: MutableList<Track>) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE)
        activity.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                if (name.startsWith(".")) continue
                if (mime == Document.MIME_TYPE_DIR) {
                    walk(tree, id, "$path/$name", out)
                } else if (mime.startsWith("audio/") || audioExt.matches(name)) {
                    out += Track(nextId++, DocumentsContract.buildDocumentUriUsingTree(tree, id), name, path, mime)
                }
            }
        }
    }

    /** Serveert /media/<id> met Range-ondersteuning (nodig om te kunnen spoelen). Anders null. */
    fun intercept(req: WebResourceRequest): WebResourceResponse? {
        val u = req.url
        if (u.host != "appassets.androidplatform.net" || !(u.path ?: "").startsWith("/media/")) return null
        val id = u.lastPathSegment?.toIntOrNull() ?: return notFound()
        val t = synchronized(tracks) { tracks[id] } ?: return notFound()
        return try {
            val afd = activity.contentResolver.openAssetFileDescriptor(t.uri, "r") ?: return notFound()
            val total = afd.length
            val mime = if (t.mime.startsWith("audio/")) t.mime else "audio/mpeg"
            val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
            val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
            val stream = afd.createInputStream()
            if (m != null && total > 0) {
                val start = m.groupValues[1].toLongOrNull() ?: 0L
                val end = (m.groupValues[2].toLongOrNull() ?: (total - 1)).coerceAtMost(total - 1)
                stream.skip(start)
                val headers = mapOf(
                    "Accept-Ranges" to "bytes",
                    "Content-Range" to "bytes $start-$end/$total",
                    "Content-Length" to (end - start + 1).toString(),
                )
                WebResourceResponse(mime, null, 206, "Partial Content", headers, stream)
            } else {
                val headers = mutableMapOf("Accept-Ranges" to "bytes")
                if (total > 0) headers["Content-Length"] = total.toString()
                WebResourceResponse(mime, null, 200, "OK", headers, stream)
            }
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), "".byteInputStream())
}
