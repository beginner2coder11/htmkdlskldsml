# Noot voor Android

1. Open de map `android/` in Android Studio (Gradle sync doet de rest; geen sleutels of build-output in deze zip).
2. Run op je telefoon. De speler (`../public/noot.html`) wordt automatisch als asset meegepakt.
3. Tik op "Hele map toevoegen" → kies je muziekmap → "Deze map gebruiken". Alles eronder wordt in één keer toegevoegd.

Muziek wordt afgespeeld via `https://appassets.androidplatform.net/media/<id>` (zie `NootNativeBridge.intercept`).
