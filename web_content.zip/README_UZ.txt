WHISPERING PINES — Android Studio loyihasi (AdMob banner bilan)

MUHIM:
- Loyiha Google Mobile Ads Next-Gen SDK 1.7.0 dan foydalanadi.
- Dastlabki sinovda Google TEST banner ID ishlatiladi. O'z reklamangizni bosmang.
- Siz bergan AdMob App ID loyihaga kiritilgan: ca-app-pub-1275271216332471~7533429441
- Siz bergan banner ID kod ichida izoh sifatida saqlangan:
  ca-app-pub-1275271216332471/7775091694

APK TEST QILISH:
1. ZIPni oching.
2. Android Studio -> Open -> WhisperingPines papkasini tanlang.
3. Android Studio Gradle Sync tugashini kuting. Internet kerak.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. Telefonga o'rnatib o'yin va TEST banner ko'rinishini tekshiring.

O'ZINGIZNING BANNER ID GA O'TISH:
MainActivity.java faylida BANNER_AD_UNIT_ID qiymatini toping.
Hozir u Google test ID:
ca-app-pub-3940256099942544/9214589741
Sinov tugagach, uni o'z banner ID'ingizga almashtiring:
ca-app-pub-1275271216332471/7775091694
So'ng qayta Build qiling. O'z reklamangizni bosib sinamang.

PLAY STORE:
AAB uchun Build -> Generate Signed Bundle / APK -> Android App Bundle.
O'zingizning signing key (.jks) faylingizni xavfsiz saqlang. Keyingi yangilanishlarda
aynan shu key kerak bo'ladi.

Izoh:
- Loyiha to'liq Android Studio source loyihasi; bu ZIPning o'zi APK/AAB emas.
- Google Play'ga chiqarish AdMob siyosatlari, Data safety, privacy policy,
  target API talablari va Play Console tekshiruvlaridan o'tishni talab qiladi.
- Agar Gradle yoki SDK sync xatosi chiqsa, xato matni/skrinshotini yuboring.
