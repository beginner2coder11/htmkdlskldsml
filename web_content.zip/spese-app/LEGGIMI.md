# Le mie spese: come installarla sul telefono Android

L'app è una PWA: una pagina web che si installa come app, ha la sua icona e funziona anche senza internet.
I dati restano **solo sul telefono** (non vanno su nessun server).

## Metodo 1: installazione diretta (consigliato, nessun APK)

1. Carica questa cartella su un hosting gratuito con HTTPS, per esempio:
   - **Netlify Drop** (app.netlify.com/drop): trascini la cartella e ottieni un indirizzo web;
   - oppure **GitHub Pages**.
2. Sul telefono apri l'indirizzo con **Chrome**.
3. Menu ⋮ → **Installa app** (o "Aggiungi a schermata Home").
4. Compare l'icona "Spese" tra le tue app. Si apre a schermo intero e funziona offline.

## Metodo 2: file .apk vero e proprio

Serve l'indirizzo web del Metodo 1.

1. Vai su **pwabuilder.com**, incolla l'indirizzo e premi *Start*.
2. Scegli **Android** → *Download package*.
3. Nello zip trovi l'`.apk`: copialo sul telefono e aprilo
   (va abilitata l'installazione da "origini sconosciute").

## Backup e trasferimento dei dati (per gli aggiornamenti)

Apri ⚙ → **Backup e trasferimento dati**. In cima c'è sempre lo **stato del backup**:

- 🔴 **Nessun backup fatto**: i dati esistono solo sul telefono.
- 🟠 **Modifiche non salvate**: dopo l'ultimo backup hai aggiunto/eliminato/cambiato qualcosa (te lo dice con i numeri).
- 🟢 **Backup aggiornato**: con data, ora e metodo. Compare "✔ Verificato" quando hai controllato che il backup coincide con i dati.

Anche l'ingranaggio ⚙ e la schermata principale mostrano un avviso (pallino arancione / barra gialla) finché ci sono dati non salvati.

**Per salvare:** punto 1 → **Copia i dati** (poi incolla in una nota o in un messaggio a te stesso) oppure **Salva file**. Dopo ogni salvataggio compare un riquadro con l'esito e il passo successivo.
**Per controllare:** punto 2 → **Incolla dagli appunti** (o **Scegli file…**): l'app dice "✔ Il backup è completo" se coincide con i dati, altrimenti spiega cosa differisce.
**Per ripristinare** (nuova versione o nuovo telefono): punto 2 → incolla/scegli → **Sostituisci tutto**. **Unisci ai dati attuali** aggiunge solo i movimenti mancanti, senza duplicati.

**Esporta in CSV** (nelle impostazioni) crea un file apribile con Excel.
Un'app installata sul telefono può perdere i dati se disinstalli l'app o cancelli i dati di Chrome: fai il backup prima di ogni aggiornamento.

## Novità

- **Spese fisse mensili** (bottone rosso in home): imposti una volta mutuo, telefono ecc. con importo e giorno del mese; l'app le registra da sola ogni mese (anche se non apri l'app per un po'). Le spese generate mostrano 🔁 fissa.
- **Movimenti**: si vedono gli ultimi 10, con «Vedi tutte» per il resto.
- **Cerca categoria** quando aggiungi una spesa/entrata: scrivi le prime lettere e compaiono le voci più usate per prime.
- **Periodi**: Giorno, Settimana, Mese, Anno e Totale (tutto il periodo).
- **Budget** (⚙ → Budget mensili): limite per voce, barre in home, avviso all'80% e al superamento.
- **Blocco app** (⚙ → Blocco app): PIN da 4 a 6 cifre e, se il telefono lo permette, impronta digitale.
- **Copie automatiche** (⚙): l'app tiene le ultime 7 copie dei dati; restano nella memoria dell'app, quindi NON sostituiscono il backup su file.
- **Spese fisse annuali** (bollo, assicurazione) oltre a quelle mensili; confronto col mese precedente; ricerca nei movimenti.
- **Asset**: dal pulsante Asset → «Andamento, storico e composizione»: torta per voce, grafico nel tempo e storico (anche con date passate).
- **Salvataggio dati**: «Condividi» e «Invia per email» oltre a Copia e Salva file.
- **Promemoria asset**: ogni mese il 30 (a febbraio il 28) compare un avviso finché non aggiorni gli asset; ⚙ → Storico asset mostra andamento e dettaglio.
- **Inserimento a voce**: nel modulo di una spesa/entrata, tasto 🎤 (o microfono della tastiera): «500 euro per l'affitto», «3.000 euro stipendio», «18,4 euro per la spesa alimentare». I campi si compilano da soli; controlli e premi Salva.
- **Pollici**: nello Storico asset, 👍 o 👎 per l'andamento mensile, annuale e totale (del totale o della singola voce scelta).
- **PIN**: percorso guidato per attivare, cambiare o rimuovere (⚙ → Blocco app); scegli dopo quanto tempo richiederlo.
- **Backup**: un solo pulsante «Fai il backup adesso».
- **Composizione**: torta piena con nome e percentuale dentro gli spicchi; totale in alto a destra.

## Contenuto della cartella

- `index.html`: l'app (tutta la logica e la grafica)
- `manifest.webmanifest`, `sw.js`, `icon*.png/svg`: rendono l'app installabile e utilizzabile offline
