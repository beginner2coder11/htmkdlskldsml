# Department View and Job-title dropdowns

- Employee profiles now offer department-specific job-title dropdowns for Food & Beverage and Kitchen. Other departments retain a generic title list. Changing department resets the title selection so an incompatible title is not accidentally retained.
- Added a Department View tab with live headcounts and employee lists by the requested Food & Beverage and Kitchen sections. Staff are grouped using their saved department and job title. Existing records are not deleted or rewritten. If an existing job title does not match a listed section, it remains in the employee directory but is not counted in one of the named subsections until corrected in the employee profile.
- The web source and Android wrapper's bundled app assets are kept in sync.
