'use strict';
let videoExpanded=false,videoTap=null,remoteRequest=0;
const videoStage=document.createElement('section');videoStage.id='videoStage';videoStage.hidden=true;videoStage.setAttribute('aria-label','Reprodução de vídeo em tela cheia');
const videoExit=document.createElement('button');videoExit.id='videoExit';videoExit.textContent='← Voltar';videoExit.setAttribute('aria-label','Sair do vídeo e voltar à multimídia');
videoStage.append(media,videoExit);document.body.append(videoStage);
let videoReturnFocus=null,videoNativeActive=false;
function setVideoExpanded(on){videoExpanded=on;media.classList.toggle('videoExpanded',on);document.body.classList.toggle('videoFullOpen',on);videoStage.hidden=!on;videoExit.hidden=!on;const main=document.querySelector('main');if(main){main.inert=on;main.setAttribute('aria-hidden',String(on))}if(!on&&typeof scheduleResponsiveLayout==='function')scheduleResponsiveLayout()}
function exitVideo(){const wasExpanded=videoExpanded;if(wasExpanded)media.pause();setVideoExpanded(false);media.hidden=true;if(document.fullscreenElement===videoStage&&document.exitFullscreen)document.exitFullscreen().catch(()=>{});if(videoReturnFocus){videoReturnFocus.focus({preventScroll:true});videoReturnFocus=null}}
function toggleVideoFullscreen(){
 if(!current||tracks.find(t=>t.id===current)?.kind!=='video')return status('Escolha um vídeo primeiro.');
 if(videoExpanded){exitVideo();return}
 if(typeof leaveVuFullscreen==='function')leaveVuFullscreen();
 videoReturnFocus=document.activeElement;media.hidden=false;setVideoExpanded(true);videoExit.focus({preventScroll:true});
 try{if(videoStage.requestFullscreen&&document.body.dataset.manualRotation!=='true'){const result=videoStage.requestFullscreen();if(result&&result.catch)result.catch(()=>{})}}catch{}
}
videoExit.onclick=exitVideo;$('full').onclick=toggleVideoFullscreen;
media.addEventListener('pointerup',e=>{if(e.pointerType==='mouse'||!e.isPrimary)return;const now=performance.now();if(videoTap&&now-videoTap.time<350&&Math.hypot(e.clientX-videoTap.x,e.clientY-videoTap.y)<32){videoTap=null;toggleVideoFullscreen()}else videoTap={time:now,x:e.clientX,y:e.clientY}});
media.addEventListener('dblclick',e=>{if(e.sourceCapabilities?.firesTouchEvents||(e.pointerType&&e.pointerType!=='mouse'))return;toggleVideoFullscreen()});
document.addEventListener('fullscreenchange',()=>{if(document.fullscreenElement===videoStage)videoNativeActive=true;else if(videoNativeActive){videoNativeActive=false;if(videoExpanded)exitVideo()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&videoExpanded)exitVideo()});
media.addEventListener('emptied',()=>{if(!current||tracks.find(t=>t.id===current)?.kind!=='video')exitVideo()});
let remoteConfig={address:'',key:'',remember:false};
try{const saved=JSON.parse(localStorage.getItem('jr-player-remote')||'null');if(saved)Object.assign(remoteConfig,saved)}catch{}
$('remoteAddress').value=remoteConfig.address;$('remoteKey').value=remoteConfig.key;$('remoteRemember').checked=remoteConfig.remember;
$('remoteOpen').onclick=()=>{$('menu').close();$('remoteSettings').showModal()};
function remoteBase(address){const u=new URL(address);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Use um endereço HTTP ou HTTPS do computador.');u.hash='';u.search='';u.pathname=u.pathname.replace(/\/+$/,'')+'/';return u}
$('remoteConnect').onclick=async()=>{
 const request=++remoteRequest,button=$('remoteConnect');button.disabled=true;$('remoteStatus').textContent='Conectando à pasta…';
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),20000);
 try{
  const address=$('remoteAddress').value.trim(),key=$('remoteKey').value.trim(),base=remoteBase(address);
  if(!key)throw Error('Informe a chave mostrada pelo programa no computador.');
  const catalog=new URL('library',base);catalog.searchParams.set('key',key);
  const response=await fetch(catalog.href,{signal:controller.signal,credentials:'omit',cache:'no-store'});
  if(!response.ok)throw Error(response.status===401?'Chave de acesso incorreta.':'O computador não respondeu à pasta ('+response.status+').');
  const data=await response.json();if(!Array.isArray(data.tracks))throw Error('Esse endereço não é uma pasta do JR Player.');
  const incoming=data.tracks.slice(0,20000).map((t,i)=>{
   if(typeof t.path!=='string'||typeof t.name!=='string'||!['audio','video'].includes(t.kind))return null;
   const url=new URL(t.path,base);if(url.origin!==base.origin||!url.pathname.startsWith(new URL('media/',base).pathname))return null;
   url.searchParams.set('key',key);return {id:'remote-'+request+'-'+i,name:t.name.slice(0,500),kind:t.kind,size:Number(t.size)||0,remote:true,url:url.href,favorite:false};
  }).filter(Boolean);
  if(request!==remoteRequest)return;
  if(tracks.find(t=>t.id===current)?.remote)reset();tracks=tracks.filter(t=>!t.remote).concat(incoming);render();
  remoteConfig={address:base.href,key,remember:$('remoteRemember').checked};
  try{if(remoteConfig.remember)localStorage.setItem('jr-player-remote',JSON.stringify(remoteConfig));else localStorage.removeItem('jr-player-remote')}catch{}
  $('remoteStatus').textContent=incoming.length?incoming.length+' arquivos do computador na biblioteca. Escolha um para tocar.':'Conectado. Nenhuma música ou vídeo compatível nessa pasta.';
 }catch(e){if(request===remoteRequest)$('remoteStatus').textContent=e.name==='AbortError'?'O computador demorou para responder. Verifique se está ligado e conectado.':e instanceof TypeError?'Não foi possível conectar. Confira o endereço, a conexão remota e o programa no computador.':e.message}
 finally{clearTimeout(timeout);if(request===remoteRequest)button.disabled=false}
};
$('remoteDisconnect').onclick=()=>{remoteRequest++;$('remoteConnect').disabled=false;if(tracks.find(t=>t.id===current)?.remote)reset();tracks=tracks.filter(t=>!t.remote);render();remoteConfig={address:'',key:'',remember:false};$('remoteKey').value='';$('remoteRemember').checked=false;try{localStorage.removeItem('jr-player-remote')}catch{}$('remoteStatus').textContent='Pasta desconectada.'};
