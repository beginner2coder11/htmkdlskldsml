// Service worker mínimo: solo existe para que el navegador considere el
// sitio "instalable" como app. No cachea nada de forma agresiva, así que
// siempre verás la versión más reciente publicada en Netlify.
self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Solo intervenir en peticiones GET de archivos propios del sitio
  // (mismo origen). Cualquier otra cosa —sobre todo las conexiones en
  // tiempo real de Firestore (Listen/Write) y las de Auth— se deja
  // pasar sin tocar, porque interceptarlas rompe esas conexiones.
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) {
    return;
  }
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
});
