/* ClipVerse service worker – offline support + installability.
   Update flow: new worker waits; the app shows an "Update Karo" button which sends SKIP_WAITING.
   Bump VERSION whenever you deploy a new index.html so users get the update. */
const VERSION = 'v20';
const SHELL_CACHE = 'clipverse-shell-' + VERSION;
const RUNTIME_CACHE = 'clipverse-runtime-' + VERSION;

const SHELL = [
  './',
  './index.html',
  './offline.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-192.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then(cache => cache.addAll(SHELL))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('clipverse-') && k !== SHELL_CACHE && k !== RUNTIME_CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  if (event.data === 'SKIP_WAITING' || (event.data && event.data.type === 'SKIP_WAITING')) self.skipWaiting();
});

// Hosts that must always hit the network (live data, login, uploads).
const NETWORK_ONLY = [
  'firestore.googleapis.com', 'identitytoolkit.googleapis.com', 'securetoken.googleapis.com',
  'firebasestorage.googleapis.com', 'api.cloudinary.com', 'www.googleapis.com',
  'apis.google.com', 'accounts.google.com', 'firebaseapp.com', 'web.app'
];

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (NETWORK_ONLY.some(h => url.hostname === h || url.hostname.endsWith('.' + h))) return;
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  // Never cache partial (range) responses – used by streamed videos.
  if (req.headers.has('range')) return;

  // Page navigations: network-first (so updates arrive immediately), cached app when offline/slow.
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(SHELL_CACHE);
      const isApp = url.pathname === '/' || url.pathname === '/index.html';
      const fromCache = async () => (isApp ? ((await cache.match('./index.html')) || (await cache.match('./'))) : null) || (await cache.match('./offline.html')) || Response.error();
      try {
        const res = await Promise.race([
          fetch(req),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 12000))
        ]);
        if (res && res.ok && (url.pathname === '/' || url.pathname === '/index.html')) cache.put('./index.html', res.clone());
        return res;
      } catch (e) { return fromCache(); }
    })());
    return;
  }

  // Same-origin files: cache-first, then network.
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        if (res && res.ok) { const copy = res.clone(); caches.open(RUNTIME_CACHE).then(c => c.put(req, copy)); }
        return res;
      }))
    );
    return;
  }

  // Cross-origin static files (Firebase JS modules on gstatic, fonts, images, video files):
  // stale-while-revalidate so they keep working offline once loaded.
  event.respondWith((async () => {
    const cache = await caches.open(RUNTIME_CACHE);
    const hit = await cache.match(req);
    const net = fetch(req).then(res => {
      if (res && (res.ok || res.type === 'opaque') && res.status !== 206) cache.put(req, res.clone());
      return res;
    }).catch(() => null);
    if (hit) { event.waitUntil(net); return hit; }
    return (await net) || Response.error();
  })());
});
