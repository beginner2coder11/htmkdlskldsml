var CACHE = 'spoken-sentences-v1';
var FILES = ['./', 'index.html', 'manifest.json', 'css/app.css', 'js/app.js', 'js/data.js',
  'fonts/Poppins-Regular.ttf', 'fonts/Poppins-Medium.ttf', 'fonts/Poppins-Bold.ttf',
  'assets/logo.png', 'assets/logo_white.png', 'assets/author_head.jpg', 'assets/author_portrait.jpg', 'assets/badge.jpg',
  'assets/icon-192.png', 'assets/icon-512.png'];
self.addEventListener('install', function (e) { e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(FILES); })); self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(caches.keys().then(function (k) { return Promise.all(k.filter(function (x) { return x !== CACHE; }).map(function (x) { return caches.delete(x); })); })); });
self.addEventListener('fetch', function (e) { e.respondWith(caches.match(e.request).then(function (r) { return r || fetch(e.request); })); });
