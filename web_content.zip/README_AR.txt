هذا المشروع مبني من ملف دفتر الشيكات المرسل.

الإصلاح:
- النسخة الاحتياطية لا تُحفظ داخل التطبيق كنسخة احتياطية.
- عند الضغط على حفظ/تنزيل النسخة الاحتياطية، يستدعي HTML جسر Android باسم AndroidBackup.
- Android يحفظ ملف JSON فعليًا في مجلد Download باستخدام MediaStore.
- هذا يعالج مشكلة appassets.androidplatform.net التي ظهرت في النسخة السابقة.

لبناء APK:
1) افتح المجلد في Android Studio.
2) نفّذ Gradle Sync.
3) Build > Build APK(s).

ملاحظة: ملف ZIP الأصلي كان يحتوي على index.html فقط، لذلك لا يمكن أن يقوم HTML وحده بكتابة ملف في مجلد Download داخل WebView. هذا المشروع يضيف الجزء الأصلي المطلوب في Android.


إصلاح PDF: تم استبدال رابط afriquia:// القديم بإنشاء PDF حقيقي داخل Android وحفظه مباشرة في مجلد التنزيلات (Downloads).
