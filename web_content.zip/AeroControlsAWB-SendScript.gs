/**
 * Aero Controls AWB — Direct send script
 * Sends the AWB email (number + photos) from YOUR Gmail account,
 * and can email an end-of-shift list of every AWB sent that day.
 *
 * Setup (one time, about 5 minutes):
 *  1. Go to https://script.google.com and click "New project".
 *  2. Delete what's there and paste this whole file in.
 *  3. Change PIN below to your own number. Optionally fill ALLOWED_TO.
 *  4. Click Deploy > New deployment > gear icon > Web app.
 *       Execute as: Me
 *       Who has access: Anyone
 *     Click Deploy, then Authorize access and allow Gmail.
 *  5. Copy the Web app URL (ends in /exec).
 *  6. In the app: email icon > Direct send > paste the URL and the PIN > Test connection.
 *
 * End-of-shift summary (optional):
 *  7. Fill SUMMARY_TO and SUMMARY_HOUR below.
 *  8. Project Settings (gear on the left) > Time zone: pick yours (e.g. Los Angeles).
 *  9. At the top, choose the function "setupDailySummary" and click Run (once).
 *     To test it right away, choose "sendDailySummary" and click Run.
 *
 * If you edit this script later: Deploy > Manage deployments > edit (pencil) >
 * Version: New version > Deploy. The URL stays the same.
 */

// Anyone with the link AND this PIN can send email from your Gmail. Use something hard to guess.
const PIN = '4821';

// Optional safety: only allow these recipients. Leave empty [] to allow any address.
// Example: const ALLOWED_TO = ['receiving@aerocontrols.com', 'shipping@aerocontrols.com'];
const ALLOWED_TO = [];

// End-of-shift summary: who gets it, and the hour it goes out (24-hour clock, 17 = 5 PM).
const SUMMARY_TO = [];          // e.g. ['andrew@aerocontrols.com']
const SUMMARY_HOUR = 17;
const SKIP_EMPTY_SUMMARY = true; // don't email on days with nothing sent

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (String(d.pin) !== PIN) return reply({ ok: false, error: 'Wrong PIN' });

    const to = [].concat(d.to || []).map(String).map(s => s.trim()).filter(Boolean);
    if (!to.length) return reply({ ok: false, error: 'No recipient' });
    if (ALLOWED_TO.length) {
      const allowed = ALLOWED_TO.map(s => s.toLowerCase());
      const bad = to.filter(t => allowed.indexOf(t.toLowerCase()) < 0);
      if (bad.length) return reply({ ok: false, error: 'Not an allowed recipient: ' + bad.join(', ') });
    }

    if (d.test) return reply({ ok: true, test: true });   // connection test, nothing sent

    const files = (d.attachments || []).map(a =>
      Utilities.newBlob(Utilities.base64Decode(a.data), a.type || 'image/jpeg', a.name || 'awb.jpg'));

    const opts = { attachments: files };
    if (d.html) opts.htmlBody = String(d.html);   // Repair Orders: P/N, S/N, Description table
    GmailApp.sendEmail(to.join(','), String(d.subject || ''), String(d.body || ''), opts);
    if (d.log !== false && d.awb) logAwb(d.awb, d.carrier, files.length, d.parts);
    return reply({ ok: true });
  } catch (err) {
    return reply({ ok: false, error: String(err && err.message || err) });
  }
}

function doGet() {
  return reply({ ok: true, info: 'Aero Controls AWB send link is running.' });
}

function reply(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ---------- daily log + summary ----------
function dayKey(date) {
  return 'log-' + Utilities.formatDate(date || new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
}

function logAwb(awb, carrier, photos, parts) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const props = PropertiesService.getScriptProperties();
    const key = dayKey();
    const list = JSON.parse(props.getProperty(key) || '[]');
    list.push({ t: Date.now(), n: String(awb), c: String(carrier || ''), p: photos || 0, pn: [].concat(parts || []).map(String).slice(0, 30) });
    props.setProperty(key, JSON.stringify(list));
  } finally {
    lock.releaseLock();
  }
}

function sendDailySummary() {
  const props = PropertiesService.getScriptProperties();
  const tz = Session.getScriptTimeZone();
  const list = JSON.parse(props.getProperty(dayKey()) || '[]');
  const day = Utilities.formatDate(new Date(), tz, 'EEE, MMM d');
  const subject = 'Receiving summary – ' + day + ' – ' + list.length + ' sent';

  if (SUMMARY_TO.length && (list.length || !SKIP_EMPTY_SUMMARY)) {
    const lines = list.map(x =>
      Utilities.formatDate(new Date(x.t), tz, 'h:mm a') + '   ' + (x.c || '').padEnd(6) + x.n +
      (x.pn && x.pn.length ? '   P/N ' + x.pn.join(', ') : ''));
    GmailApp.sendEmail(SUMMARY_TO.join(','), subject, subject + '\n\n' + (lines.join('\n') || 'Nothing sent today.'));
  }

  // keep the last 14 days of logs, delete older ones
  const keep = {};
  for (let i = 0; i < 14; i++) keep[dayKey(new Date(Date.now() - i * 864e5))] = true;
  Object.keys(props.getProperties()).forEach(k => { if (k.indexOf('log-') === 0 && !keep[k]) props.deleteProperty(k); });
}

function setupDailySummary() {
  ScriptApp.getProjectTriggers()
    .filter(t => t.getHandlerFunction() === 'sendDailySummary')
    .forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('sendDailySummary').timeBased().atHour(SUMMARY_HOUR).everyDays(1).create();
}
