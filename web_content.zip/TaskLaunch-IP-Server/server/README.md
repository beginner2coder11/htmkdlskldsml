# TaskLaunch Windows LAN server

Requires Node.js 18+. In Command Prompt, change to this folder and run `node server.js`. Test on the PC at `http://127.0.0.1:8080/api/status`. Use `ipconfig` to find the PC's active LAN IPv4 address, then enter `IP:8080` in the Android app. Allow Node.js / inbound TCP port 8080 on Windows Firewall for Private networks. Phone and PC must be on the same reachable network. Do not expose this unauthenticated sample server to the public internet.
