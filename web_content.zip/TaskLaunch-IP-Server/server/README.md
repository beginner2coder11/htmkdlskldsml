# Minimal TaskLaunch IP server

Requires Node.js 18 or newer. Run `node server.js` and allow incoming connections through the computer's firewall on TCP port 8080. Find the computer's LAN IPv4 address (for example, `192.168.1.100`) and enter `192.168.1.100:8080` in TaskLaunch settings.

This sample server only provides a status endpoint. It does not execute shell commands or control Android devices.
