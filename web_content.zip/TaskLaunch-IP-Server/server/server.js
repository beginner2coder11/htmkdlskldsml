// Minimal local-network status server for TaskLaunch IP Server.
// Requires Node.js 18+. Run: node server.js
const http = require('http');
const os = require('os');
const PORT = Number(process.env.PORT || 8080);
http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (req.url === '/api/status' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type':'application/json; charset=utf-8'});
    return res.end(JSON.stringify({name:'TaskLaunch Server', message:'Online', platform:os.platform(), hostname:os.hostname(), time:new Date().toISOString()}));
  }
  res.writeHead(404, {'Content-Type':'application/json; charset=utf-8'});
  res.end(JSON.stringify({error:'Not found'}));
}).listen(PORT, '0.0.0.0', () => console.log(`TaskLaunch server listening on port ${PORT}`));
