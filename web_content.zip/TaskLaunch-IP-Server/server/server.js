// TaskLaunch LAN status server. Requires Node.js 18+.
const http = require('http');
const os = require('os');
const PORT = Number(process.env.PORT || 8080);

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  if (req.url === '/api/status' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({
      name: 'TaskLaunch Server',
      message: 'Online',
      platform: os.platform(),
      hostname: os.hostname(),
      time: new Date().toISOString()
    }));
  }
  res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ error: 'Not found', path: req.url }));
});

server.on('error', err => {
  console.error('Server error:', err.message);
  if (err.code === 'EADDRINUSE') console.error(`Port ${PORT} is already in use. Stop the other server or set PORT to another port.`);
  process.exitCode = 1;
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TaskLaunch server listening on http://0.0.0.0:${PORT}`);
  console.log('On the PC, test: http://127.0.0.1:' + PORT + '/api/status');
  console.log('On the phone, enter the PC LAN IPv4 address, e.g. 192.168.1.100:' + PORT);
});
