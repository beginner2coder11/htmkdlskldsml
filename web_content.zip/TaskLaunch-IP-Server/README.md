# TaskLaunch IP Server — fixed connection build (no ADB)

## 1. Start the server on the Windows PC
1. Install Node.js 18 or newer.
2. Open Command Prompt in the extracted `server` folder.
3. Run `node server.js`.
4. On the PC, open `http://127.0.0.1:8080/api/status`. It should show JSON with `"message":"Online"`.
5. Find the PC's LAN IPv4 address by running `ipconfig` in Command Prompt and reading the IPv4 Address under the active Wi-Fi/Ethernet adapter.
6. If Windows Firewall asks, allow Node.js on **Private networks**. If it does not ask, create/allow an inbound TCP rule for port 8080 on Private networks.

## 2. Connect from the Android app
1. Put the phone and PC on the same Wi-Fi/LAN. Guest Wi-Fi or client isolation can block devices from seeing each other.
2. In TaskLaunch open **Server IP** settings.
3. Enter the PC's IPv4 address and port, e.g. `192.168.1.100:8080` (replace with the actual PC address).
4. Tap **Save and connect**. The status should change to **CONNECTED**.

## Troubleshooting
- Do not enter `127.0.0.1` or `localhost` on the phone; those refer to the phone itself.
- If the PC test works but the phone cannot connect, check Windows Firewall, the IP address, Wi-Fi isolation, VPNs, and that both devices are on the same LAN.
- Test from the phone browser by opening `http://PC-IP:8080/api/status`.
- If port 8080 is busy, stop the other process or start with `set PORT=8081` then `node server.js`, and use `PC-IP:8081`.
- This is an IP-only status server. It does not provide ADB, USB debugging, remote shell, or privileged Android control.

## Build APK
Open this project in Android Studio with JDK 17 and Android SDK 35, sync Gradle, then select Build > Build APK(s).
