# TaskLaunch IP Server (no ADB)

This Android WebView project uses a single server address such as `192.168.1.100:8080`. It does not include ADB, Shizuku, USB debugging, wireless debugging, pairing, or privileged Android shell access.

## Build APK
1. Open this folder in Android Studio with JDK 17 and Android SDK 35.
2. Allow Gradle sync.
3. Select Build > Build APK(s).

## Connect
1. Start a compatible HTTP server on your local network.
2. In TaskLaunch, open Server settings and enter the server IP and port, e.g. `192.168.1.100:8080`.
3. Tap Save and connect. The app calls `GET /api/status` and expects JSON, for example `{\"name\":\"TaskLaunch Server\",\"message\":\"Online\"}`.

## Important
This is an IP-only client starter project. A reachable server must implement `/api/status`. It does not magically provide privileged access to Android or execute phone shell commands; those require a separate authorized service and are intentionally not included. HTTP is enabled for local-network IP connections. Do not expose an unauthenticated server to the public internet.
