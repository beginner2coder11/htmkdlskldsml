# إصلاح النسخ الاحتياطي v45

تمت إزالة طريقة `afriquia://savebackup` نهائياً من زر النسخ الاحتياطي.

زر «حفظ نسخة احتياطية في الهاتف» يستدعي جسر Android مباشرة (`AndroidBackup.saveBackup`) ولا يفتح رابطاً أو تطبيقاً خارجياً.

يتم حفظ JSON في Downloads/AfriquiaStock على Android 10+، مع نافذة Android كحل احتياطي عند تعذر الحفظ المباشر.
