Hotel HR Manager — Leave Plans, Swipe Navigation and Refresh Fix

Changes included
- Added a Leave Plans tab for Service and Kitchen.
- Leave plans are stored with existing HR data and included in JSON backups, restore validation and Excel/CSV exports.
- Added Dashboard cards showing Service and Kitchen employees whose approved leave dates include today.
- Added horizontal swipe navigation between tabs on mobile. The horizontal tab bar itself remains independently scrollable.
- Pulling down at the top refreshes records from local storage in place; it does not reload the page or sign the user out.
- A signed-in session survives a page refresh. The Sign out button explicitly clears the session marker. Session state is held in sessionStorage rather than the saved password.
- Mirrored updated web assets into the Android WebView asset folder.

Important behavior
- Only leave plans with status Approved are counted on the Dashboard.
- A leave plan must cover today's date inclusively to be counted.
- Existing employee records are reused; no duplicate employee list is created.
- Department matching is best-effort based on existing department labels. For broad labels such as F&B, select the appropriate department in the Leave Plans form.
- This source ZIP is not itself an APK. Use the included GitHub Actions workflow to build a debug APK. Build and install the APK, then test on the target phone before using it operationally.
- Back up existing HR records before installing an update. If Android reports a signature conflict, do not uninstall or clear app data until a backup has been verified.
