package com.hotelhrmanager.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.content.ClipData
import android.net.Uri
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentValues
import android.webkit.JavascriptInterface
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebResourceRequest
import android.webkit.DownloadListener
import android.util.Base64
import java.io.IOException
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val channelId = "hotel_hr_reminders"
    private var pendingFileBytes: ByteArray? = null
    private var pendingFileMime: String = "application/octet-stream"
    private var pendingFileName: String = "download.bin"
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val saveDocumentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val bytes = pendingFileBytes
        val name = pendingFileName
        pendingFileBytes = null
        val uri = if (result.resultCode == RESULT_OK) result.data?.data else null
        if (uri != null && bytes != null) {
            try {
                contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                    ?: throw IOException("Could not open destination")
                webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(true, ${jsString(name)})", null)
                Toast.makeText(this, "Saved to selected location", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(false, ${jsString(name)})", null)
                Toast.makeText(this, "Could not save file. Choose another folder and try again.", Toast.LENGTH_LONG).show()
            }
        } else {
            webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(false, ${jsString(name)})", null)
        }
    }

    private val openDocumentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = fileChooserCallback
        fileChooserCallback = null
        if (result.resultCode == RESULT_OK && result.data?.data != null) callback?.onReceiveValue(arrayOf(result.data!!.data!!))
        else callback?.onReceiveValue(null)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(
            this,
            if (granted) "Hotel HR Manager notifications enabled" else "Notifications are disabled. You can enable them in Android Settings.",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(HRBridge(), "HRAndroid")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/*", "application/json", "application/pdf", "application/zip", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "image/*", "application/vnd.android.package-archive"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                }
                return try { openDocumentLauncher.launch(intent); true } catch (_: Exception) { fileChooserCallback = null; filePathCallback?.onReceiveValue(null); false }
            }
        }
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Use the in-app download button to save this file", Toast.LENGTH_LONG).show()
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/public/index.html")
        requestNotificationPermissionIfNeeded()
    }

    @Deprecated("Use the system back dispatcher; retained for broad Android compatibility")
    override fun onBackPressed() {
        if (!::webView.isInitialized) {
            super.onBackPressed()
            return
        }
        // First Back from any app section returns to the Dashboard. Back on the
        // Dashboard exits the Activity as normal.
        webView.evaluateJavascript("typeof currentView !== 'undefined' && currentView !== 'dashboard'") { result ->
            if (result == "true") {
                webView.evaluateJavascript("if (typeof go === 'function') go('dashboard', false)", null)
            } else {
                finish()
            }
        }
    }

    private fun jsString(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Open Android Settings to manage this app", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "HR reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Probation, training, appraisal and disciplinary follow-up reminders"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    inner class HRBridge {
        @JavascriptInterface fun saveFile(dataUrl: String, filename: String, mimeType: String) {
            try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0 || dataUrl.length > 40000000) throw IllegalArgumentException("Invalid or oversized file")
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                runOnUiThread {
                    val safeName = filename.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "download.bin" }
                    val safeMime = mimeType.take(120).ifBlank { "application/octet-stream" }
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            val values = ContentValues().apply {
                                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                                put(MediaStore.Downloads.MIME_TYPE, safeMime)
                                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Hotel HR Manager")
                                put(MediaStore.Downloads.IS_PENDING, 1)
                            }
                            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                                ?: throw IOException("Android could not create the download file")
                            try {
                                contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                                    ?: throw IOException("Could not open the download destination")
                                val ready = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                                contentResolver.update(uri, ready, null, null)
                                webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(true, ${jsString(safeName)})", null)
                                Toast.makeText(this@MainActivity, "Saved to Downloads/Hotel HR Manager", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                contentResolver.delete(uri, null, null)
                                throw e
                            }
                        } else {
                            pendingFileBytes = bytes
                            pendingFileMime = safeMime
                            pendingFileName = safeName
                            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = safeMime
                                putExtra(Intent.EXTRA_TITLE, safeName)
                            }
                            saveDocumentLauncher.launch(intent)
                        }
                    } catch (_: Exception) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(false, ${jsString(safeName)})", null)
                            Toast.makeText(this@MainActivity, "Download failed. Check phone storage and try again.", Toast.LENGTH_LONG).show()
                        } else {
                            pendingFileBytes = null
                            webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(false, ${jsString(safeName)})", null)
                            Toast.makeText(this@MainActivity, "Could not open Android save dialog", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Could not prepare this file for saving", Toast.LENGTH_LONG).show() }
            }
        }
        @JavascriptInterface fun shareFile(dataUrl: String, filename: String, mimeType: String) {
            try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0 || dataUrl.length > 40000000) throw IllegalArgumentException("Invalid or oversized file")
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                runOnUiThread {
                    val safeName = filename.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "hr-export.bin" }
                    val safeMime = mimeType.take(120).ifBlank { "application/octet-stream" }
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                            put(MediaStore.Downloads.MIME_TYPE, safeMime)
                            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Hotel HR Manager")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: throw IOException("Android could not prepare the export")
                        try {
                            contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                                ?: throw IOException("Could not write export")
                            contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = safeMime
                                putExtra(Intent.EXTRA_STREAM, uri)
                                putExtra(Intent.EXTRA_SUBJECT, "Hotel HR Manager export: $safeName")
                                putExtra(Intent.EXTRA_TEXT, "Hotel HR Manager export attached: $safeName")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                clipData = ClipData.newUri(contentResolver, safeName, uri)
                            }
                            startActivity(Intent.createChooser(send, "Share export using"))
                            webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(true, ${jsString(safeName)})", null)
                        } catch (e: Exception) {
                            contentResolver.delete(uri, null, null)
                            throw e
                        }
                    } catch (e: Exception) {
                        webView.evaluateJavascript("window.hrNativeFileSaved && window.hrNativeFileSaved(false, ${jsString(safeName)})", null)
                        Toast.makeText(this@MainActivity, "Could not open Android sharing. Try again.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Could not prepare this export for sharing", Toast.LENGTH_LONG).show() }
            }
        }
        @JavascriptInterface fun openAppSettings() { runOnUiThread { this@MainActivity.openAppSettings() } }
        @JavascriptInterface fun requestNotificationPermission() { runOnUiThread { requestNotificationPermissionIfNeeded() } }
        @JavascriptInterface fun testNotification() { runOnUiThread { showTestNotification() } }
        @JavascriptInterface fun scheduleReminder(delayMinutes: Int, title: String, message: String, reminderId: String) {
            if (delayMinutes < 1 || delayMinutes > 525600) return
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("title", title.take(100)); putExtra("message", message.take(240)); putExtra("reminderId", reminderId.take(80))
            }
            val requestCode = reminderId.hashCode() and 0x7fffffff
            val pending = PendingIntent.getBroadcast(this@MainActivity, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMinutes * 60_000L, pending)
        }
    }

    private fun showTestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotificationPermissionIfNeeded()
            return
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Hotel HR Manager")
            .setContentText("Notifications are configured on this device.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify(1001, notification)
    }
}
