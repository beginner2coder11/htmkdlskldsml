package com.hotelhrmanager.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.webkit.JavascriptInterface
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val channelId = "hotel_hr_reminders"

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(
            this,
            if (granted) "Hotel HR Manager notifications enabled" else "Notifications are disabled. You can enable them in Android Settings.",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(HRBridge(), "HRAndroid")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/public/index.html")
        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "HR reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Probation, training, appraisal and disciplinary follow-up reminders"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    inner class HRBridge {
        @JavascriptInterface fun requestNotificationPermission() { runOnUiThread { requestNotificationPermissionIfNeeded() } }
        @JavascriptInterface fun testNotification() { runOnUiThread { showTestNotification() } }
        @JavascriptInterface fun scheduleReminder(delayMinutes: Int, title: String, message: String, reminderId: String) {
            if (delayMinutes < 1 || delayMinutes > 525600) return
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("title", title.take(100)); putExtra("message", message.take(240)); putExtra("reminderId", reminderId.take(80))
            }
            val requestCode = reminderId.hashCode() and 0x7fffffff
            val pending = PendingIntent.getBroadcast(this@MainActivity, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMinutes * 60_000L, pending)
        }
    }

    private fun showTestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotificationPermissionIfNeeded()
            return
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Hotel HR Manager")
            .setContentText("Notifications are configured on this device.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify(1001, notification)
    }
}
