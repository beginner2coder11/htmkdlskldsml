# Hotel HR Manager — Reliability & Security Edition (source project)

This is a source ZIP, not a compiled APK. Build and test it in Android Studio before using it with live HR records.

## Included in this edition
- Native Android WebView wrapper, app label `Hotel HR Manager`, and `POST_NOTIFICATIONS` runtime permission flow for Android 13+.
- Native HR reminder channel, a native notification test action, and a native AlarmManager bridge for scheduled probation/follow-up reminders discovered by the web app when it is opened.
- Demo credentials and demo login hint removed. First launch asks you to create a device-local username/password; the password is SHA-256 hashed in localStorage. This is a basic app gate, **not** strong device encryption or enterprise authentication. Protect the phone with Android screen lock.
- Local HR records are saved as before. Each successful save keeps one previous localStorage snapshot. JSON restore validates core arrays and rejects oversized/invalid files, and downloads a pre-restore backup before applying data.
- Android `allowBackup` is disabled to reduce accidental OS cloud backup of private app data. Continue exporting your own encrypted/safely stored backups.

## Build
1. In your existing app, open Reports & Backup and download a full JSON backup. Confirm it exists outside the app.
2. Open this `android-wrapper` folder in Android Studio, install the requested SDK and sync Gradle.
3. Confirm `applicationId` in `app/build.gradle` matches your current installed APK package ID if you want an in-place update. You must also sign with the same signing key. If either differs, Android may install separately or reject the update.
4. Build > Build APK(s), install the debug APK for testing, then allow notifications.
5. Check Android Settings > Apps > Hotel HR Manager > Notifications and tap the app's Test notification button in Settings.
6. Test reminders using disposable test records, including closing the app and restarting the phone, before relying on reminders.

## Honest limitations
- Native scheduled reminders are created when the app is opened/resumed and upcoming probation/follow-up dates are found. The current version does not yet reschedule alarms after reboot or handle edits/deletions by cancelling old alarms; test carefully. Exact delivery time can be affected by Android battery management and OS policies.
- This does not include Firebase Cloud Messaging or a cloud push backend.
- The password hash is stored in WebView localStorage; it is not a replacement for native encrypted storage or a strong authentication system. Do not treat this as security-certified software.
- Automatic snapshots live inside app storage and are not an independent backup. Export JSON regularly to a safe location. Restore/import only trusted files.
- Some spreadsheet features load XLSX from a CDN and require internet. App data otherwise remains local-first.
- The existing app's localStorage data may not automatically transfer into this native wrapper because Android WebView storage is separate from the browser or prior wrapper. Restore a JSON export into the new app.
- A production-grade encrypted backup, cryptographic integrity signatures, secure keystore-backed authentication, and full automated reminder lifecycle remain recommended follow-up work.
