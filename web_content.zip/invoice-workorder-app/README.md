## Scanning
- **Capture** uses a full-screen camera. Tap the invoice to focus, then capture.
- **Sharp photo** opens the phone's own camera (best focus on a Samsung). Use this if the in-app picture is blurry.
- The app boosts contrast and reads the still photo, then fills supplier, invoice number, and line items. Always review them.

## Back button
Hardware back closes the camera, or returns from a work order to the list. It should not leave the app.

If it still exits after you install a **new** APK built from this zip, the APK wrapper is set to close on back. In the APK builder, set the back button to **history / go back** (not "exit app") and generate the APK again.