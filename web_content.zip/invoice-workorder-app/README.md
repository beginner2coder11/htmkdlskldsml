## Install as App (Phone / Tablet only)

This app is designed to be **installed**, not used in a browser tab.

### Android (S24 Ultra, tablets, etc.) — Recommended
1. Host the folder over HTTPS (Netlify, Vercel, GitHub Pages, or any static host).
2. Open the URL in **Chrome**.
3. Tap the menu (⋮) → **Add to Home screen** or **Install app**.
4. It will appear as a normal app icon. Launch it from the home screen (not the browser).

Once installed:
- Camera works with the document guide frame
- Hardware back button stays inside the app
- Works offline after the first load

### Alternative: True APK
If you prefer a pure APK (no Chrome involved):
1. Zip the folder and upload to a free HTML-to-APK converter (e.g. websitetoapk.com).
2. Install the resulting APK and allow camera permission.