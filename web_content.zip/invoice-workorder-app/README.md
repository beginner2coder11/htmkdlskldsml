# Invoice to Work Order App

A mobile-friendly Progressive Web App for scanning auto parts invoices and turning them into work orders with parts, markup, labor, tax, and totals.

## Features
- **Scan invoices** with phone camera (or file upload)
- Client-side OCR with Tesseract.js (nothing leaves your device)
- **Auto-extract**:
  - Supplier / Vendor (NAPA, Capital City, AutoZone, etc.)
  - Invoice Number
  - Invoice Date
  - Line items: Part Number, Description, Quantity, Unit Cost
- Adjustable markup % per item
- Labor hours + rate
- Auto-calculate subtotal, tax, total
- Multiple work orders saved in browser localStorage
- Mobile-optimized UI + installable as PWA

## How to Use
1. Open `index.html` (best served over HTTPS or localhost for camera).
2. Tap **+ New** to create a work order.
3. Tap **📷 Scan Invoice** → capture or upload photo.
4. Supplier, Invoice #, and Date are filled automatically when detected.
5. Review the OCR text, then tap **Parse & Add Items**.
6. Edit part numbers, quantities, costs, and markup as needed.
7. Add labor hours.
8. Save.

## Notes
- OCR accuracy depends on photo quality. Always review extracted data.
- Parsing is tuned for common NAPA and dealer parts invoices.
- Data stays in your browser's localStorage.