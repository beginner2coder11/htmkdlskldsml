# Invoice to Work Order App

A simple mobile-friendly Progressive Web App for scanning invoices and turning them into work orders with parts, markup, labor, tax, and totals.

## Features
- Scan invoices using your phone camera (or upload photo)
- Client-side OCR with Tesseract.js (no data leaves your device)
- Auto-parse suggested line items (part #, qty, price) — always review & edit
- Adjustable markup % per item (or default)
- Add labor hours + rate
- Auto-calculate subtotal, tax, total
- Multiple work orders saved in browser localStorage
- Mobile-optimized UI

## How to Use
1. Open `index.html` in a modern mobile browser (Chrome, Safari, Edge).
2. For best experience, serve it from a local server or host it (camera requires HTTPS or localhost).
   - Quick local: `python -m http.server 8000` then visit http://localhost:8000
3. Tap **+ New** to create a work order.
4. Tap **Scan Invoice** → allow camera → capture the invoice.
5. Review OCR text, tap **Parse & Add Items**.
6. Edit part numbers, quantities, prices, markup as needed.
7. Enter labor hours.
8. Adjust tax %.
9. Tap **Save**.

## Notes / Limitations
- OCR accuracy depends on photo quality, lighting, and invoice layout. Always double-check extracted data.
- Parsing is heuristic (not AI-powered). Complex or multi-page invoices may need manual entry.
- Data is stored only in your browser's localStorage. Clear browser data = lose work orders.
- For production use, consider integrating a dedicated invoice OCR API (Google Document AI, Azure Form Recognizer, etc.) for higher accuracy.

## Install as App on Android (Samsung S24 Ultra)

### Option 1: Progressive Web App (Recommended – easiest, no APK needed)
1. Serve the files over HTTPS or localhost (camera requires secure context).
   - Easiest: Upload the folder to a free host like Netlify, Vercel, or GitHub Pages, or use a local server on your computer and open from phone.
   - Quick test: Use a tool like `npx serve` or Python http.server, then access via your local IP.
2. Open the app in **Chrome** on your S24 Ultra.
3. Tap the menu (⋮) → **Add to Home screen** or **Install app**.
4. It will appear as a real app icon, work offline for the UI, and have full camera access.

This is the modern recommended way and works great on Android 12+.

### Option 2: True APK
Use a free online converter:
1. Go to https://websitetoapk.com/ or similar HTML-to-APK tools.
2. Upload the `index.html` (or zip the whole folder).
3. Generate and download the APK.
4. On your S24 Ultra, allow “Install unknown apps” for your browser/files app, then install the APK.

**Note:** WebView-based APKs sometimes have camera permission quirks. The PWA method is usually smoother.

### Permissions
When using camera, grant Camera permission when prompted. The app only uses it locally for OCR.
