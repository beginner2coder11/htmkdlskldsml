import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bnp.steelmaking',
  appName: 'SteelMaking With BNP',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
