@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js LTS from https://nodejs.org/ and reopen this file.& pause & exit /b 1)
node server.js
pause
