TASKLAUNCH WINDOWS COMPANION SERVER

1. Install Node.js LTS from https://nodejs.org/ on your Windows PC.
2. Double-click start-server.bat. First run creates server-config.json with a random secret token and a TaskLaunch-Workspace folder in your user profile.
3. Copy the token from server-config.json. Do not share it.
4. Find the PC IPv4 address with ipconfig. Phone and PC must be on the same trusted Wi-Fi/LAN.
5. In TaskLaunch > Settings, enter server URL http://PC-IP:8787 and the token, then Connect.
6. If Windows Firewall asks, allow Node.js only on Private networks. Do not expose port 8787 to the public internet. HTTP is unencrypted; use only on a trusted LAN.

Features: real Windows system status, process list and force-stop, workspace file browsing, server-saved notes, and an allowlisted command prompt (hostname, whoami, ipconfig, tasklist, date, time, systeminfo). File access is deliberately restricted to TaskLaunch-Workspace. No arbitrary shell commands or access outside the workspace.

This is a Windows companion server, not an emulator. Some process termination may require running the server as administrator; avoid doing so unless needed.
