# Night Stage — 2D car race

A small top-down racing game in plain HTML, CSS and JavaScript. No build step, no
dependencies, no internet connection needed once unzipped.

## Run it

Double-click `index.html`. That's it.

Sounds may stay silent until you click once on the page (browsers block audio
until the user interacts). If you prefer a local server:

```bash
python3 -m http.server 8000    # then open http://localhost:8000
```

## Controls

| Action   | Keys                          |
| -------- | ----------------------------- |
| Steer    | `←` `→` or `A` `D`, or drag on the track |
| Throttle | `↑` `W` accelerate, `↓` `S` brake |
| Pause    | `P`                           |
| Restart  | `R`                           |
| Sound    | `M`                           |

## How it plays

Distance is your score. Speed climbs on its own, traffic gets denser as it does,
and fuel drains the whole time — faster when you push harder. Green cans top the
tank back up, rival cars and cones end the run. Your best distance is saved in
the browser.

## Files

```
index.html            page + telemetry card
css/style.css         all styling
js/game.js            loop, physics, spawning, collision, rendering
assets/
  car-player.png      your car
  car-rival-01..03    traffic
  asphalt.png         tiling road texture
  cone.png fuel.png   obstacle and pickup
  sfx/*.wav           crash, pickup, start
```

## Tweaking

The constants at the top of `js/game.js` are the tuning knobs: `START_SPEED`,
`MAX_SPEED`, `STEER`, `FUEL_DRAIN`, `FUEL_PER_CAN`, and the spawn gap inside
`spawn()`. Lower `FUEL_DRAIN` for a gentler run; raise `ACCEL` for a shorter,
sharper one.
