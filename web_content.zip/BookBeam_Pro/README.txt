BOOKBEAM PRO — KDP INTELLIGENCE STUDIO (PERSONAL EDITION)

INSTALL
1. Extract BookBeam_Pro_Personal.zip.
2. Open index.html in a modern browser (Chrome, Firefox, Edge, Safari).
3. No install, API key, account login, or subscription is needed.
4. Internet is needed only when opening public research links.

FEATURES
- Niche Opportunity Lab with transparent weighted score
- Keyword/long-tail idea generation and public research links
- Competition pressure estimator based on manually observed first-page data
- Manual competitor book audit ledger
- Book blueprint, keyword hypotheses, and pre-publication checklist
- Local saved research library
- CSV exports and full JSON backup/restore

IMPORTANT HONESTY / DATA LIMITS
This is a local personal research tool, not an exact replacement for paid BookBeam or Publisher Rocket. It does not connect to private Amazon data, verify Amazon search volume, retrieve live BSR or sales history, estimate actual royalties, or guarantee bestseller probability. Scores are heuristics from your manual observations. Generated keywords are hypotheses, not verified popular terms. Amazon result counts are approximate and results may be personalized.

PRIVACY
The app stores your saved records in this browser's localStorage. There is no app backend and the app does not send your records to a server. Export JSON backups regularly; browser data clearing may erase saved research. External links are subject to the third-party site's privacy policies.

USE THE SCORE CORRECTLY
Use scores to prioritize what to investigate, not as a substitute for evidence. Check autocomplete, first-page relevance, review complaints, publication recency, seasonality, and actual reader needs. For a serious shortlist, audit at least 10 competing books and test a sample with target readers.

DISCLAIMER
Independent personal tool. Not affiliated with Amazon KDP, BookBeam, or Publisher Rocket.
