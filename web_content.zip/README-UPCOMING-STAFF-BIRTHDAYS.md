# Upcoming staff birthdays

Added to the cumulative Hotel HR Manager source.

- New **Birthdays** tab lists employees with a saved birthday, sorted by the next upcoming occurrence.
- Employee profile has an optional **Birthday** date field. Leaving it blank is supported.
- The employee spreadsheet import accepts an optional `Birthday`, `Date of Birth`, `Birth Date`, or `DOB` column. The employee template now includes `Birthday`.
- Birthday date is stored with the existing employee record. Existing records are preserved.
- The same HTML, JavaScript and CSS are copied into the Android WebView assets.

This is a source ZIP; build and test an APK before distribution.
