const express = require('express');
const bitcoin = require('bitcoinjs-lib');
const axios = require('axios');
const app = express();
const port = 3000;

// Configuration
const BITCOIN_TESTNET = true; // Set to false for mainnet
const RPC_USER = 'your_rpc_user';
const RPC_PASS = 'your_rpc_pass';
const RPC_HOST = '127.0.0.1';
const RPC_PORT = 8332; // Mainnet RPC port

// Hardcoded private key for demonstration (DO NOT USE IN PRODUCTION)
// In a real app, this would be derived from a wallet or stored securely
const PRIVATE_KEY = 'L1aW4aubZP7gXkKqJ1y7X5X5X5X5X5X5X5X5X5X5X5X5X5X5X5X5'; 
const ADDRESS = 'mipcBbRg9jns8v8xAfpXhdXseSxD9Usseh'; // Corresponding public address

app.use(express.json());

// Helper: Get current fee rate from Blockstream API
async function getFeeRate() {
    try {
        const response = await axios.get('https://blockstream.info/api/fee-recommended');
        return response.data.fastestFee || 10; // Default to 10 sat/vB if failed
    } catch (error) {
        console.error('Error fetching fee rate:', error);
        return 10;
    }
}

// Helper: Broadcast transaction via Bitcoin Core RPC
async function broadcastTransaction(rawTx) {
    try {
        const response = await axios.post(`http://${RPC_HOST}:${RPC_PORT}`, {
            jsonrpc: '1.0',
            id: 'test',
            method: 'sendrawtransaction',
            params: [rawTx]
        }, {
            auth: `${RPC_USER}:${RPC_PASS}`
        });
        return response.data.result;
    } catch (error) {
        console.error('Error broadcasting:', error.response?.data || error.message);
        throw new Error('Failed to broadcast transaction');
    }
}

// Helper: Get mempool status for an address
async function getMempoolStatus(address) {
    try {
        const response = await axios.get(`https://blockstream.info/api/address/${address}/txs/mempool`);
        return response.data;
    } catch (error) {
        console.error('Error fetching mempool status:', error);
        return [];
    }
}

// POST endpoint to send Bitcoin
app.post('/send', async (req, res) => {
    const { address, amount } = req.body;

    // Validate input
    if (!address || !amount) {
        return res.status(400).json({ error: 'Address and amount are required' });
    }

    try {
        // 1. Get current fee rate
        const feeRate = await getFeeRate();

        // 2. Create a transaction
        const network = BITCOIN_TESTNET ? bitcoin.networks.testnet : bitcoin.networks.bitcoin;
        
        // Note: This is a simplified example. In reality, you need to fetch UTXOs first.
        // For this demo, we assume the sender has enough funds in the hardcoded address.
        
        const tx = new bitcoin.TransactionBuilder(network);
        
        // Add input (UTXO) - You need to fetch UTXOs for the sender address
        // For demo, we'll use a placeholder UTXO
        const utxo = {
            txid: 'your_utxo_txid', // Replace with actual UTXO txid
            vout: 0,
            value: 100000 // 0.001 BTC in satoshis
        };

        tx.addInput(utxo.txid, utxo.vout);

        // Add output (recipient)
        const recipientAmount = Math.floor(amount * 100000000); // Convert BTC to satoshis
        const fee = Math.floor(feeRate * 250); // Estimate fee based on size
        const changeAmount = utxo.value - recipientAmount - fee;

        tx.addOutput(bitcoin.address.toPayment(address), recipientAmount);
        
        // Add change output if applicable
        if (changeAmount > 0) {
            tx.addOutput(bitcoin.address.toPayment(ADDRESS), changeAmount);
        }

        // Sign the transaction
        const keyPair = bitcoin.ECPair.fromPrivateKey(Buffer.from(PRIVATE_KEY, 'hex'));
        tx.sign(0, keyPair);

        // Serialize the transaction
        const rawTx = tx.toHex();

        // 3. Broadcast the transaction
        const txid = await broadcastTransaction(rawTx);

        // 4. Get mempool status for the recipient
        const mempoolTxs = await getMempoolStatus(address);

        // 5. Return response
        res.json({
            success: true,
            txid: txid,
            mempoolLink: `https://blockstream.info/tx/${txid}`,
            mempoolStatus: mempoolTxs.length > 0 ? 'Already in mempool' : 'New transaction'
        });

    } catch (error) {
        console.error('Error sending Bitcoin:', error);
        res.status(500).json({ error: 'Failed to send Bitcoin' });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});