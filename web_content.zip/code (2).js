const plaid = require('plaid');

// Configure Plaid client
const client = new plaid.Client({
  clientId: 'YOUR_PLAIAD_CLIENT_ID',
  secret: 'YOUR_PLAID_SECRET',
  environment: plaid.Environment.Sandbox // Use 'Production' for real money
});

app.post('/api/deposit', async (req, res) => {
    const { accountId, amount, plaidAccessToken } = req.body;

    try {
        // Create an ACH entry via Plaid
        const transferResponse = await client.createACHTransfer({
            access_token: plaidAccessToken,
            account_id: accountId, // Plaid account ID
            amount: amount.toString(),
            description: 'Deposit',
            type: 'credit' // credit = money coming IN
        });

        if (transferResponse.success) {
            // Update local database
            db.run('UPDATE accounts SET balance = balance + ? WHERE id = ?', 
                [amount, accountId]);
            
            res.json({ message: 'Real money deposited!' });
        } else {
            res.status(400).json({ error: 'Plaid transfer failed' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});