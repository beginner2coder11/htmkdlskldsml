# ربط تطبيق AFRIQUIA مع Google Drive

هذه النسخة تحتوي على ربط Google Drive داخل التطبيق باستخدام Google Sign-In وصلاحية `drive.file`.

## الوظائف
- ربط حساب Google من داخل التطبيق.
- إنشاء مجلد `AFRIQUIA Backup` تلقائياً في Google Drive.
- حفظ آخر نسخة باسم `AFRIQUIA-BACKUP-LATEST.json`.
- استرجاع آخر نسخة من Google Drive.
- الاحتفاظ بنسخة الهاتف المحلية أيضاً.
- معالجة طلب موافقة Google Drive لأول مرة وإظهار رسالة واضحة للمستخدم.

## إعداد Google Cloud المطلوب قبل بناء APK
1. افتح مشروع Google Cloud الخاص بالتطبيق.
2. فعّل Google Drive API.
3. أنشئ OAuth Client من نوع Android.
4. استخدم Package Name:
   `com.afriquia.cheques`
5. أضف SHA-1 لشهادة APK التي ستثبتها على الهاتف.
6. تأكد أن حساب Google المستخدم في الهاتف مسموح له باختبار OAuth إذا كان التطبيق في وضع Testing.

## الاستخدام داخل التطبيق
من قسم «نسخة احتياطية»:
1. اضغط «🔵 ربط حساب Google».
2. اختر حساب Gmail.
3. وافق على صلاحية Google Drive عند ظهورها.
4. اضغط «☁️ حفظ في Google Drive».
5. للاسترجاع اضغط «🔄 استرجاع من Google Drive».

ملاحظة: APK الموجود حالياً لا يمكننا ضمان تسجيل OAuth النهائي من دون SHA-1 وشهادة البناء المستخدمة. المشروع مهيأ للكود والـ API، ويبقى إعداد OAuth في Google Cloud مطابقاً لحزمة التطبيق وشهادة APK.
