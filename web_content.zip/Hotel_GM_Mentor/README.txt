HOTEL GM MENTOR — SECURE AI + CURRICULUM UPDATE EDITION

WHAT'S NEW
- Curriculum & app updates panel in Progress.
- Import a JSON curriculum pack, or a ZIP containing curriculum.json or update.json.
- Import a JSON progress backup to restore your learning record.
- Download a curriculum JSON template to create your own future learning tracks.
- APK selection gives Android installation/update instructions; the app cannot silently install or replace its own APK.
- Expanded pathway: Front Office, Revenue Management, Rooms Division & Housekeeping, Sales/Marketing/Distribution, Finance/Accounting, People/Culture/Talent, Engineering/Safety/Security, Strategic F&B Leadership, and Hotel Strategy/GM Readiness.
- Existing secure AI backend scaffold remains included.

CURRICULUM IMPORT FORMAT
1. Tap Progress > Curriculum & app updates > Download curriculum update template.
2. Edit the downloaded JSON. Preserve the schema and lesson array order.
3. Select the edited JSON and tap Validate & apply update.
4. For ZIP import, place curriculum.json or update.json at the root or in a folder inside the ZIP.
5. A pack should have this structure:
   {"type":"hotel-gm-mentor-curriculum","version":1,"tracks":[{"id":"my-track","name":"My Learning Track","icon":"📘","desc":"Short description","lessons":[["Lesson title","Topic","Learning objective",["Teaching point 1","Teaching point 2"],"Key takeaway","Scenario question",["Option A","Correct option","Option C"],1,"Explanation"]]}]}
   Answer index is zero-based: 0 for first option, 1 for second, etc. Each lesson requires 9 fields in that order.

ZIP SUPPORT
- ZIP reading uses JSZip loaded from jsDelivr, so ZIP imports require internet access to load that library. If offline, import the curriculum.json file directly.
- The app validates lesson structure before applying a curriculum pack. Treat imported files as trusted content; only import files you created or trust.

APK / APP-BUILD UPDATES
- Selecting an APK does not install it from inside the web app. On Android, open the trusted APK in Files/Downloads and follow the Android package installer.
- For a true update rather than a separate app install, the APK must use the same Android application ID/package name and be signed with the same signing key as the installed version. Android may require permission to install unknown apps for the source you use.
- ZIP files are for curriculum data updates here, not a way to execute or install a new app build. To update app code, build and install a new app package or deploy the updated web app.

SECURE AI BACKEND
- Requires Node.js 20+.
- Configure OPENAI_API_KEY, APP_PASSWORD and SESSION_SECRET in the hosting environment (see .env.example).
- Run npm install, then npm start. Deploy as a Node.js web service behind HTTPS with frontend and API on the same origin.
- Do not put API keys in frontend JavaScript, JSON curriculum packs, or an APK.
- API usage is billed separately from a ChatGPT subscription.
- Do not enter guest/staff personal data, payment information, passwords, or confidential hotel information into the mentor.

OFFLINE / PROGRESS
- Learning progress is stored in this browser/device. Export a progress backup before clearing browser data or changing devices.
- Curriculum packs imported into the browser are local to that browser unless you export/re-import them or distribute a new app build.
- For a static-only hosting service, the secure AI backend will not run; use the included Node server or another compatible backend host.
