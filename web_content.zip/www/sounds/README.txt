Put notification sound files here, one per sound, named exactly:
  azan.mp3   (🕌 አዛን)
  bell.mp3   (🛎️ ደወል)
  chime.mp3  (🎶 ቺም)
Each file is copied into the APK at build time. If a file is missing,
that sound falls back to the phone's default sound.
