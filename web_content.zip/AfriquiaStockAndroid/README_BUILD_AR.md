# تجهيز وبناء المشروع في Android Studio

هذا هو مشروع Android Studio كامل، ويحتوي على وحدة `app` وملفات Gradle المطلوبة للمزامنة.

## المتطلبات
- Android Studio حديث يدعم Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK Platform 35
- Build Tools التي يقترحها Android Studio
- اتصال بالإنترنت في أول Gradle Sync لتنزيل المكونات

## فتح المشروع
1. فك ضغط الملف.
2. في Android Studio اختر **Open**.
3. اختر المجلد الذي يحتوي على `settings.gradle`.
4. انتظر انتهاء **Gradle Sync**.
5. إذا طلب SDK 35 أو مكونات Gradle، وافق على التثبيت.

## إنشاء APK
من Android Studio:
**Build → Generate App Bundles or APKs → Generate APKs**

سيظهر ملف الإصدار هنا:
`app/build/outputs/apk/release/app-release.apk`

## تشغيل على الهاتف
فعّل USB debugging ثم اضغط Run، أو انسخ APK إلى الهاتف وثبته.

## معلومات المشروع
- Application ID: `com.afriquia.freinszemamra`
- minSdk: 23
- targetSdk: 35
- compileSdk: 35
- Android Gradle Plugin: 8.7.3
- Java: 17

## ملاحظات
- لا يوجد `local.properties` لأن مسار Android SDK يختلف من جهاز لآخر.
- لا يوجد Gradle Wrapper binary داخل النسخة، لذلك يجب أن يكون Gradle متاحاً عبر Android Studio/بيئة البناء.
- وظائف PDF والطباعة وBluetooth/USB موجودة داخل المشروع.
