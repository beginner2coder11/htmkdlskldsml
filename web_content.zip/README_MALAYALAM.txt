JAS LAUNDRY ROOM - FIREBASE PROJECT INIT FIX + CLOUD DATA SAFETY

ഈ build-ൽ പരിഹരിച്ചത്:
1. നിലവിലുള്ള Firebase default app മറ്റൊരു Project-ൽ initialize ചെയ്താലും പുതിയ Config കാരണം login page തടസ്സപ്പെടാതിരിക്കാനായി named Firebase app ഉപയോഗിക്കുന്നു.
2. Config-ന്റെ projectId/appId match ചെയ്യുന്ന Firebase app ഉണ്ടെങ്കിൽ അത് reuse ചെയ്യുന്നു.
3. Auth, Firestore എന്നിവ selected Firebase app-നോട് ബന്ധിപ്പിച്ചിരിക്കുന്നു; project mismatch initialization error ഒഴിവാക്കാൻ.
4. പുതിയ ഫോണിൽ Cloud data നിലവിലുണ്ടെങ്കിൽ local pending data Cloud-നെ നിശ്ശബ്ദമായി overwrite ചെയ്യില്ല. Local data-യുടെ recovery snapshot ഈ device-ൽ localStorage key jasLaundryLocalConflictBackup_<timestamp> ആയി സൂക്ഷിച്ചിട്ട് Cloud data load ചെയ്യും.
5. Original phone-ൽ Owner Cloud Sync connect ചെയ്യുമ്പോൾ local pending data vs Cloud data conflict ഉണ്ടെങ്കിൽ confirmation ചോദിക്കും. OK = Cloud load (local snapshot backup), Cancel = local data Cloud-ിലേക്ക് upload (Cloud data replace ചെയ്യാം).
6. Existing legacy cloud document jasLaundryRooms/JAS_LAUNDRY_ROOM-ൽ data ഉണ്ടെങ്കിൽ പഴയ build-ൽ നിന്ന് V2 document-ിലേക്ക് one-time migration logic നിലനിർത്തിയിരിക്കുന്നു.


APK build ചെയ്യുന്നതിന് മുമ്പ്:
- Original phone-ൽ app open ചെയ്ത് Firebase config projectId/appId ശരിയാണെന്ന് ഉറപ്പാക്കുക.
- Cloud Sync connect ചെയ്യുന്നതിന് മുമ്പ് Backup Download എടുക്കുന്നത് നല്ലതാണ്.
- രണ്ട് ഫോണിലും ഒരേ Firebase Web App Config ഉപയോഗിക്കുക.
- Firebase Authentication-ൽ Owner Email/Password account നിലനിൽക്കണം.
- Firebase Firestore Rules secure ആയിരിക്കണം; public read/write അനുവദിക്കരുത്.
- ഈ build local data/cloud data ഒന്നും delete ചെയ്യുന്നില്ല.

HTML2 APK Converter-ൽ ZIP import ചെയ്ത് index.html entry page ഉപയോഗിച്ച് build ചെയ്യുക.

NOTE: Firebase credentials and Rules were not live-tested in this package; test Cloud sync on two devices before relying on it.


പുതിയ Live Sync മെച്ചപ്പെടുത്തലുകൾ:
7. Firestore local persistence enable ചെയ്യുന്നു. നെറ്റ്‌വർക്ക് ഇല്ലാത്തപ്പോൾ Firestore cache/queued writes പിന്തുണയ്ക്കും (WebView പിന്തുണയ്ക്കുന്നില്ലെങ്കിൽ localStorage + retry തുടരും).
8. Staff app shared business document-ന്റെ onSnapshot listener വഴി Owner/മറ്റു device മാറ്റങ്ങൾ ഉടൻ localStorage-ലും screen-ലും കാണിക്കും.
9. Staff account profile-നും live listener ചേർത്തു. Owner പേര് മാറ്റുകയോ account deactivate ചെയ്യുകയോ ചെയ്താൽ staff app-ൽ ഉടൻ പ്രതിഫലിക്കും.
10. ഓരോ save-ഉം ആദ്യം localStorage-ൽ സൂക്ഷിക്കുന്നു; internet ലഭ്യമായാൽ Cloud-ിലേക്ക് ഉടൻ അയക്കും. Offline ആയാൽ pending ആയി സൂക്ഷിച്ച് online event വന്ന ഉടൻ വീണ്ടും അയക്കും.

ശ്രദ്ധിക്കുക: എല്ലാ ഉപകരണങ്ങളിലും ഒരേ Firebase project/config വേണം. Firestore Rules Owner-നും authenticated staff-നും ആവശ്യമായ read/write അനുവദിക്കണം. Firebase credentials/Rules live ആയി ഈ പരിതസ്ഥിതിയിൽ പരിശോധിച്ചിട്ടില്ല; രണ്ട് ഉപകരണങ്ങളിൽ പരീക്ഷിക്കുക.
