JAS LAUNDRY - SUPABASE CLOUD SYNC BUILD

ഈ ZIP-ൽ നിലവിലുള്ള JAS Laundry app-ന്റെ Local Storage data നിലനിർത്തിക്കൊണ്ട് Supabase Cloud Sync ചേർത്തിട്ടുണ്ട്.

പ്രധാന ഫയലുകൾ:
- index.html: HTML2APK Converter-ൽ import ചെയ്യേണ്ട പ്രധാന ഫയൽ.
- web/index.html: web folder entry copy.
- SUPABASE_SETUP.sql: Supabase SQL Editor-ൽ ഒരിക്കൽ Run ചെയ്യേണ്ട schema + RLS + merge function.
- README_SUPABASE_MALAYALAM.txt: വിശദമായ setup, safety notes.

ആദ്യമായി SUPABASE_SETUP.sql run ചെയ്യാതെ Cloud connect ചെയ്യാനാകില്ല. പഴയ Local Storage ഡാറ്റ നീക്കം ചെയ്യരുത്. ആദ്യം Local Recovery backup ഡൗൺലോഡ് ചെയ്ത് രണ്ട് test devices-ൽ sync പരിശോധിക്കുക.
