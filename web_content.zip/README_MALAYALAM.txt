JAS LAUNDRY - CLOUD SYNC DATA-PRESERVATION PATCH

ഈ ZIP നിലവിലുള്ള HTML app-ന്റെ Cloud Sync ഭാഗത്ത് സുരക്ഷിതമായ merge ശ്രമം ചേർക്കുന്നു.

മാറ്റങ്ങൾ:
- Cloud upload Firestore transaction ഉപയോഗിക്കുന്നു.
- Bills/customers/prices/activities/advances/refunds arrays remote + local records merge ചെയ്യുന്നു; ഒരു device-ന്റെ പഴയ array മറ്റൊരു device-ന്റെ പുതിയ record നേരിട്ട് overwrite ചെയ്യാതിരിക്കാൻ.
- Bill edit-ൽ updatedAt timestamp ചേർക്കുന്നു; merge ചെയ്യുമ്പോൾ പുതുക്കിയ record തിരഞ്ഞെടുക്കാൻ.
- Owner cloud sync ആരംഭിക്കുമ്പോൾ legacy JAS_LAUNDRY_ROOM document-ഉം V2 document-ഉം records merge ചെയ്യുന്നു.
- Bill number next counter merge ചെയ്ത bills-ന്റെ നമ്പറുകൾക്കപ്പുറം കണക്കാക്കുന്നു.

പ്രധാന മുന്നറിയിപ്പ്:
- ഈ ZIP live Firebase project-ൽ test ചെയ്തിട്ടില്ല. Install ചെയ്യുന്നതിനു മുമ്പ് Firebase Console-ൽ backup/export എടുക്കുക.
- Firebase document size limit (1 MiB) കാരണം മുഴുവൻ billing data ഒരു document-ിൽ സൂക്ഷിക്കുന്ന architecture ദീർഘകാലത്തിന് അനുയോജ്യമല്ല; വലിയ dataset-ൽ subcollection migration ആവശ്യമാണ്.
- Bill Number-ന്റെ central transaction allocation ഈ patch ഉൾപ്പെടുത്തിയിട്ടില്ല; രണ്ട് ഫോണുകൾ ഒരേസമയം പുതിയ bill സൃഷ്ടിച്ചാൽ bill-number collision ഇപ്പോഴും സംഭവിക്കാം.
- പഴയ Cloud Data delete ചെയ്യരുത്; Rules-ൽ public read/write അനുവദിക്കരുത്.
- ആദ്യം backup എടുത്ത് test phones-ൽ പരീക്ഷിക്കുക; Live data-യിൽ ആശ്രയിക്കുന്നതിന് മുമ്പ് Owner + Staff test നടത്തുക.

HTML2 APK Converter-ൽ import ചെയ്യേണ്ട entry file: index.html
