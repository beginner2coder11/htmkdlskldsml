JAS LAUNDRY ROOM — NEW APPWRITE BILLING APP
===========================================

ഈ ZIP ഒരു പുതിയ, സ്വതന്ത്ര Billing App ആണ്. Firebase SDK / Firebase Auth / Firestore ഇതിൽ ഉപയോഗിക്കുന്നില്ല. Appwrite Web SDK ആണ് ഉപയോഗിക്കുന്നത്.

പ്രധാന സവിശേഷതകൾ
- Customer, mobile number, due date, item/qty/rate, paid amount എന്നിവ ചേർത്ത് bill സൃഷ്ടിക്കൽ
- Bills, Customers, totals, pending amount
- Print view
- Device-ൽ local backup
- JSON backup download / restore
- Appwrite email/password login
- Appwrite Database-ലേക്ക് sync, Realtime subscription ശ്രമം
- Internet ഇല്ലാത്തപ്പോൾ local save; online വന്നാൽ sync ശ്രമം

പ്രധാന മുന്നറിയിപ്പ്
ഈ ZIP ഒരു പുതിയ തുടക്ക ആപ്പാണ്. പഴയ ആപ്പിലെ എല്ലാ പഴയ modules (thermal print, WhatsApp, staff roles, reports മുതലായവ) ഇതിലേക്ക് ഇതുവരെ മാറ്റിയിട്ടില്ല. പഴയ ഡാറ്റ സ്വയം പുതിയ app-ലേക്ക് വരികയുമില്ല. ആദ്യം പഴയ app-ൽ നിന്ന് backup JSON export ചെയ്യണം; ആ പഴയ app-ൽ JSON export സൗകര്യം ഇല്ലെങ്കിൽ അതിന്റെ പഴയ data export ചെയ്യാനുള്ള പ്രത്യേക migration മാറ്റം വേണം.

APPWRITE CONSOLE SETUP
1. https://cloud.appwrite.io/ തുറന്ന് നിങ്ങളുടെ organization-ൽ നിലവിലുള്ള JAS LAUNDRY ROOM project തുറക്കുക.
2. Project → Overview-ൽ നിന്ന് Project ID എടുക്കുക.
3. Project → Platforms → Add platform → Web App. Hostname ആയി app host ചെയ്യുന്ന domain നൽകുക. APK/WebView-ൽ ഉപയോഗിക്കുന്നതനുസരിച്ച് അനുവദനീയമായ origin ചേർക്കുക. Local testing-ൽ localhost അനുവദിക്കുക.
4. Databases → Create database. ഉദാ. database ID: jas_laundry_db (ID നിങ്ങൾ തന്നെ നൽകാം).
5. Database-ൽ Create collection. ഉദാ. collection ID: billing_records.
6. Collection attributes സൃഷ്ടിക്കുക:
   - recordType : String, size 64, required
   - payload : String, വലിയ payload-ന് പരമാവധി അനുവദിക്കുന്ന size (Appwrite plan/API limit പരിശോധിക്കുക)
   - updatedAt : String, size 40
   - ownerId : String, size 64, required
   ഈ starter build മുഴുവൻ bills JSON ഒരു document payload-ൽ സൂക്ഷിക്കുന്നു. വലിയ ഡാറ്റയ്ക്ക് പിന്നീട് bill/customer വേർതിരിച്ച collections ആക്കുന്നതാണ് നല്ലത്.
7. Collection → Settings / Permissions: authenticated users-ന് Create, Read, Update permissions നൽകുക. Document security ON ആണെങ്കിൽ document-level permissions കൂടി configure ചെയ്യണം. ഈ build-ൽ documents create ചെയ്യുമ്പോൾ explicit permissions നൽകുന്നില്ല; അതിനാൽ തുടക്കത്തിൽ Collection-level authenticated permissions ഉപയോഗിക്കുക.
8. Authentication → Settings-ൽ Email/Password login enable ചെയ്യുക.
9. App തുറന്ന് Endpoint, Project ID, Database ID, Collection ID നൽകി Save Connection ചെയ്യുക. തുടർന്ന് Create Account അല്ലെങ്കിൽ Login ഉപയോഗിക്കുക.

Endpoint സാധാരണയായി https://<REGION>.cloud.appwrite.io/v1 ആയിരിക്കും. നിങ്ങളുടെ Console-ൽ കാണിക്കുന്ന endpoint തന്നെ ഉപയോഗിക്കുക.

പഴയ ഡാറ്റ RECOVERY
A. പഴയ ആപ്പ് അതേ ഫോണിൽ തുറക്കുക.
B. പഴയ ആപ്പിൽ Backup / Export JSON സൗകര്യം ഉണ്ടെങ്കിൽ ആദ്യം JSON backup download ചെയ്യുക.
C. പുതിയ Appwrite app തുറന്ന് അതേ Appwrite project/database/collection കണക്ട് ചെയ്യുക.
D. Login ചെയ്ത ശേഷം Restore Backup JSON തിരഞ്ഞെടുക്കുക.
E. Bills എണ്ണം, മൊത്തം തുക, pending amount എന്നിവ പഴയ app-ുമായി താരതമ്യം ചെയ്യുക. മറ്റൊരു device-ലും login ചെയ്ത് പരിശോധിക്കുക.

വളരെ പ്രധാനപ്പെട്ടത്: പഴയ build-ന്റെ data localStorage key `jasLaundryBillingV2`-ൽ ആണ്. പഴയ app-ന്റെ WebView origin/storage പുതിയ app-ൽ നിന്ന് വേറെയായാൽ പുതിയ app-ന് പഴയ storage നേരിട്ട് വായിക്കാൻ കഴിയില്ല. അതിനാൽ പഴയ app-ൽ നിന്ന് export അല്ലെങ്കിൽ dedicated migration tool ആവശ്യമാണ്. പഴയ ഡാറ്റയുടെ ഒരു copy എടുത്ത് പരിശോധിക്കുന്നതുവരെ പഴയ app uninstall ചെയ്യുകയോ app data clear ചെയ്യുകയോ ചെയ്യരുത്.

SECURITY
- Appwrite API key ഒരിക്കലും HTML/ZIP-ൽ ചേർക്കരുത്. Client-side app-ൽ Project ID മാത്രം ഉപയോഗിക്കുക.
- Authenticated users permissions മാത്രം നൽകുക; public read/write അനുവദിക്കരുത്.
- ഇത് starter version ആണ്; Owner/Staff role-based access control, individual bill documents, audit log, robust conflict resolution എന്നിവ production rollout-ിനു മുമ്പ് ചേർക്കണം.
- Cloud sync-ൽ ഒരു shared JSON document ആണ് ഉപയോഗിക്കുന്നത്; ഒരേ സമയത്ത് രണ്ട് devices update ചെയ്താൽ last-write-wins conflict സാധ്യതയുണ്ട്. Live subscription ആണ് മാറ്റം വന്നാൽ UI data പുതുക്കുന്നത്; production multi-device billing-ിന് record-per-document architecture വേണം.

APK
`index.html` entry page ആയി നിങ്ങളുടെ HTML-to-APK builder-ൽ ZIP import ചെയ്യാം. External Appwrite SDK CDN ലഭിക്കാൻ internet ആവശ്യമാണ്. APK builder-ൽ internet permission / WebView networking enable ചെയ്യുക.
