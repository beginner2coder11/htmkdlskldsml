A3 GUARD – V2, osvježen interfejs

U ZIP-u je index.html za uvoz u HTML-to-APK Builder.

NOVO:
- moderniji tamni interfejs;
- pregled kamere i status;
- jednostavna indikacija promjene slike;
- izbor vremena do crnog prikaza ekrana: 15 s, 30 s, 1, 2 ili 5 min;
- dodir crnog prikaza vraća aplikaciju.

VAŽNO:
Crni prikaz je samo crni sloj unutar aplikacije. Ne gasi fizički ekran telefona i ne garantuje nastavak rada kamere ako Android zaključa ekran ili stavi WebView u pozadinu. HTML-to-APK Builder ne može sam obezbijediti nativni Android foreground servis za kameru sa ugašenim ekranom.

Ova verzija je i dalje samo test interfejsa/kamere i promjene slike. Nema trajnog snimanja, detekcije osoba/vozila, OCR tablica, udaljenog pristupa niti automatskog brisanja nakon 72 sata. Za to treba nativni Android modul i siguran servis/veza.

Kameru koristi samo gdje imaš ovlaštenje za snimanje i uz odgovarajuće obavještenje.
