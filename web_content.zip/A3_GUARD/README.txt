A3 GUARD – HTML početni paket

SADRŽAJ
- index.html: početni interfejs i probni prikaz kamere/pokreta.

KAKO PROBATI
1. Raspakuj ZIP na telefonu ili računaru.
2. U HTML-to-APK Builderu izaberi opciju za učitavanje lokalnog HTML projekta/foldera ili index.html (naziv opcije zavisi od verzije aplikacije).
3. Uključi dozvolu za kameru kada Android zatraži.
4. Pokreni aplikaciju i pritisni "Pokreni probu kamere".

VAŽNA OGRANIČENJA
Ovo NIJE gotov sistem video-nadzora i nije produkcijski APK.
Ovaj HTML paket služi samo kao početni interfejs i test prednje/zadnje kamere i jednostavne promjene slike dok je aplikacija otvorena.
Ne obezbjeđuje:
- kameru sa ugašenim ekranom ili pouzdano izvršavanje u pozadini;
- trajno snimanje video-klipova i upravljanje memorijom;
- detekciju/identifikaciju lica ili pouzdanu klasifikaciju osoba i vozila;
- OCR registarskih tablica;
- udaljeni pristup sa S24 Ultra;
- enkripciju, korisničke naloge ili automatsko brisanje poslije 72 sata.

Za te funkcije potreban je nativni Android modul (npr. Kotlin/Java foreground service, CameraX/Camera2, lokalna baza i sigurna mrežna veza) i zasebna aplikacija ili siguran klijentski interfejs za S24 Ultra. HTML-to-APK konverter sam ne može dodati te Android funkcije.

PRIVATNOST
Kameru koristi samo na prostoru za koji imaš ovlaštenje i obavijesti osobe kada je to potrebno. Ne koristi ovaj probni paket za tajno snimanje.
