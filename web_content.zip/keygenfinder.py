from flask import Flask, request, jsonify
import os
import uuid

app = Flask(__name__)

@app.route('/')
def index():
    return open('index.html').read()

@app.route('/crack', methods=['POST'])
def crack_exe():
    if 'exe' not in request.files:
        return jsonify({"message": "No file part"}), 400

    file = request.files['exe']
    if file.filename == '':
        return jsonify({"message": "No selected file"}), 400

    # Save temporarily
    temp_path = f"/tmp/{uuid.uuid4().hex}.exe"
    file.save(temp_path)

    # Simulate cracking process
    license_key = f"XXXX-XXXX-XXXX-{uuid.uuid4().hex[:8].upper()}"

    # Cleanup
    os.remove(temp_path)

    return jsonify({
        "message": f"✅ Cracked! License Key: {license_key}",
        "filename": file.filename,
        "key": license_key
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)