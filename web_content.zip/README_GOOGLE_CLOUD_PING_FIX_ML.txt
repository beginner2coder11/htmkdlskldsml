JAS LAUNDRY ROOM – GOOGLE CLOUD PING FAILED FIX

ഈ അപ്ഡേറ്റിൽ Google Apps Script Web App-ന്റെ ContentService response redirect കാരണം Android WebView-ൽ ഉണ്ടാകാവുന്ന CORS / fetch Ping Failed പ്രശ്നം പരിഹരിക്കാൻ transport മാറ്റിയിട്ടുണ്ട്.

മാറ്റങ്ങൾ:
1. Ping, Cloud data download (GET) എന്നിവ JSONP വഴി നടത്തുന്നു. ഇതിന് backend-ൽ callback support ചേർത്തിട്ടുണ്ട്.
2. Cloud upload (POST) text/plain + no-cors ഉപയോഗിക്കുന്നു; WebView-ൽ CORS preflight / redirected response വായിക്കുന്നതിലെ തടസ്സം ഒഴിവാക്കുന്നു.
3. Local-first save തുടരും. Cloud upload അയയ്ക്കാനാകാത്ത പക്ഷം pending sync നിലനിർത്തും.
4. നിലവിലുള്ള URL, Secret Token key, local database, staff accounts, billing data എന്നിവ reset/delete ചെയ്യുന്നില്ല.
5. Appwrite/Firebase-ലേക്ക് ပြောင်းിയിട്ടില്ല; Google Apps Script + Google Drive തന്നെയാണ് ഉപയോഗിക്കുന്നത്.

പ്രധാനമായി ചെയ്യേണ്ടത്:
- Apps Script project-ൽ ZIP-ലുള്ള പുതുക്കിയ GOOGLE_CLOUD_APPS_SCRIPT_BACKEND.gs മുഴുവനായി replace/paste ചെയ്ത് Save ചെയ്യുക.
- Deploy → Manage deployments → Edit (pencil) → Version: New version → Deploy ചെയ്യുക.
- നിലവിലുള്ള Web App URL തന്നെയാണെങ്കിൽ URL മാറ്റേണ്ടതില്ല. നിലവിലുള്ള Secret Token Script Properties-ൽ അതേപടി നിലനിർത്തുക.
- APK-യിൽ പുതിയ HTML ഉൾപ്പെടുത്തി വീണ്ടും build/install ചെയ്തശേഷം Connect Google Cloud അമർത്തുക.

പരിശോധനാ പരിധി:
- HTML JavaScript syntax, backend JavaScript syntax, ZIP integrity പരിശോധിക്കണം/പരിശോധിച്ചിട്ടുണ്ട്.
- യഥാർത്ഥ Google account, deployment permission, Android WebView, live upload/download എന്നിവ ഇവിടെ നിന്ന് നേരിട്ട് പരിശോധിക്കാൻ കഴിയില്ല. POST response CORS നിയന്ത്രണം കാരണം browser-ൽ വായിക്കാനാകില്ല; അതിനാൽ app അയച്ചതായി കാണിക്കും. യഥാർത്ഥ upload വിജയിച്ചെന്ന് ഉറപ്പാക്കാൻ രണ്ടാമത്തെ ഉപകരണത്തിൽ Sync Now / data പരിശോധിക്കുക.
- Update ചെയ്യുന്നതിന് മുമ്പ് Settings → Backup → Download Backup എടുക്കുക.
