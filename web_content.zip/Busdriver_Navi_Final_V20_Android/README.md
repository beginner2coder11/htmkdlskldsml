# Busdriver Navi – finale Projektfassung V20 (Teststand)

**Android-Studio-Projekt, keine installierbare APK.** Der Begriff „final“ bezeichnet den zusammengeführten Funktionsstand, nicht eine geprüfte oder für den Fahrbetrieb zugelassene Navigation.

## Enthalten
- Bestehende WestVerkehr-Fahrplandaten, GPX-Referenzstrecken und OpenStreetMap-Kartenansicht
- GPS-Berechtigungsabfrage in Android, GPS-Folgemodus, Tag-/Nachtansicht
- Dienstplan-Scanner mit Bildauswahl, OCR-Versuch (externe Bibliothek/Internet erforderlich), manueller Korrektur
- **Neuer verifizierbarer Musterdienst aus dem vom Nutzer bereitgestellten Foto:** Mo–Do und Freitag getrennt, einschließlich Leerfahrten.
- Dienstzeit Mo–Do 06:19–17:25 = 11h 06min, Fahrt-/Leerfahrtsumme 7h 24min, Zwischenzeiten 3h 42min.
- Dienstzeit Freitag 06:19–16:15 = 9h 56min, Fahrt-/Leerfahrtsumme 6h 16min, Zwischenzeiten 3h 40min.
- Längste Unterbrechung an beiden Tagen 09:05–12:19 = 3h 14min.

## Wichtige Grenzen
- Dienstunterbrechung/Wendezeit ist nicht automatisch gesetzliche Ruhepause.
- OCR ist nicht garantiert korrekt; jede Fahrt, Tagesart und Uhrzeit prüfen.
- Kein vollwertiges Google-Maps-artiges Turn-by-Turn-Routing, keine zertifizierte Busbefahrbarkeit oder dynamische Neuberechnung.
- GPS und Kartenansicht müssen auf dem Zielgerät getestet werden; OSM-Karten benötigen Internet.
- **APK muss noch mit Android Studio oder einem geeigneten Cloud-Build erstellt und getestet werden.**
- Nicht als alleinige Navigation im Busbetrieb einsetzen.
