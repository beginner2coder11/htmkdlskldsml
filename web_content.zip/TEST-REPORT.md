# Test report (only what was actually executed)

## Accounting (run in Node on the app's own calc function)
Scenario: buy 100 @10 paid 400; sell 40 @20 paid 300; expense 50.
- cash -150 expected, -150 actual: PASS
- receivables 500 / 500: PASS
- payables 600 / 600: PASS
- inventory 600 / 600: PASS
- gross profit 400 / 400: PASS
- net profit 350 / 350: PASS
After customer payment 200 and supplier payment 100: cash -50, receivables 300, payables 500: PASS
Soft-deleted sale excluded from gross profit (0): PASS

## Logic tests (run in Node on the app's own functions)
- Library auto-advance: page 1 -> 2 PASS; stale/duplicate call ignored PASS; 2 -> 3 PASS; stays on the last page PASS
- Reminder timing: on time (0 min) PASS; 10 min late (catch-up window is 30 min) PASS; early is negative so does not fire PASS

## Du'a & Qasidah slide navigation (logic run in Node with stubbed page elements)
- Completion indicator shown and page stays for the 2-second wait: PASS
- After 2 s page 1 hidden, page 2 shown, page 3 hidden: PASS
- Page 2 completes -> page 3: PASS
- Page 3 completes -> completion message with restart option: PASS
- Manual Previous: PASS
- Auto-advance switched off in Settings: stays on the page: PASS
(The real animation, tapping the real pages, iPhone/Android and offline were NOT tested.)

## Sales commission (run in Node on calc())
- 40 x 20 at 5% commission = 40: PASS
- Commission does not change net profit (informational): PASS
- Soft-deleted sale excluded from commission: PASS

## Home dashboard (Node smoke test with sample records)
- Recent transactions list shows sales, purchases and expenses from the data: PASS
- Four folder cards rendered: PASS
(Visual appearance, dark theme, font size and presets were NOT looked at on a screen.)

## Unified Du'a & Qasidah card system (23 logic tests run in Node on the app's own code and real card data)
Cards: 62 / 109 (106 counted + 3 notes, incl. the two original page-334 notes, nothing invented) / 116; folder 4 empty.
PASS: open at card 1; target reached marks done; history entry; 2 s wait then next card; position saved; target 3 needs 3 taps; Previous; progress preserved; folders independent; resume; timer; auto-advance off; note cards have no counter; folder-complete message; adding a custom card to folder 4.
NOT tested: the real screen, slide animation, touch, vibration, Android, iPhone, offline.

## Audio sync (card view), logic tests in Node: 11 PASS
Index lookup by time, marking start times (2 decimals), card follows audio (slide for neighbours, direct jump otherwise), follow switch off.
NOT tested: real audio file playback, IndexedDB audio storage, the highlight glow, Android, iPhone.

## Scroll mode with centred auto-scroll (logic tests in Node: 12 PASS)
All 62 / 109 cards listed; each has its own counter; Next, audio-follow and the 2 s auto-advance each centre the right card (scrollIntoView block:center, smooth); tapping selects a card; note cards have no counter; card mode unaffected.
NOT tested: real scrolling on a screen (very tall cards), Android, iPhone.

## Checks done
- JavaScript syntax check of the full app script: PASS
- The three embedded Du'a/Qasidah pages are byte-identical to the uploaded files: PASS

## NOT tested
Islamic sub-folder screens; repeat selector setting the dhikr target; dhikr counter completion advancing to the next page; offline caching; Online/Offline badge;
Real clicks on the Du'a pages (the "I read once" button, audio ending, all salawat ticked) triggering the advance; reminders firing in a real browser or phone; native Android scheduling;
Browser UI, language switching, Arabic RTL, edit/undo screens, backup/restore, notifications, offline mode, PWA install, iPhone, Android device, APK (not built).
