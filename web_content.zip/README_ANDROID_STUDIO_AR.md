# Afriquia Stock — جاهز للبناء في Android Studio

هذا المشروع مجهز ليُفتح مباشرة كمشروع Android Gradle.

## المتطلبات
- Android Studio حديث يدعم Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK Platform 35
- Android SDK Build-Tools المناسبة التي يقترحها Android Studio
- اتصال بالإنترنت في أول مزامنة Gradle لتنزيل مكونات المشروع عند الحاجة

## فتح المشروع
1. فك الضغط عن الملف.
2. افتح **مجلد المشروع الذي يحتوي على `settings.gradle`** في Android Studio.
3. انتظر **Gradle Sync** حتى يكتمل.
4. إذا طلب Android Studio تثبيت SDK أو Build Tools، وافق على التثبيت.
5. من القائمة اختر:
   **Build → Generate App Bundles or APKs → Generate APKs**
6. ملف APK سيكون في:
   `app/build/outputs/apk/release/app-release.apk`

## إعداد الهاتف للتجربة
- فعّل خيارات المطور وUSB debugging.
- أو انسخ APK إلى الهاتف وثبته يدويًا.

## ملاحظات
- `applicationId`: `com.afriquia.freinszemamra`
- `minSdk`: 23
- `targetSdk`: 35
- `compileSdk`: 35
- Android Gradle Plugin: 8.7.3
- المشروع لا يحتوي على `local.properties` حتى لا يرتبط بمسار SDK في جهاز معين.
- لا يتم تضمين Gradle Wrapper binary؛ Android Studio يستطيع إعداد/تنزيل مكونات Gradle المطلوبة أثناء المزامنة.
