DIAMOND CONSTRUCTION V2 FINAL-18 — MOBILE APK READY

This build fixes Android WebView local-page loading.
The app supports both /web/ and /assets/ local asset paths through WebViewAssetLoader.
Use Android Studio to open this project and build the APK.
Do not replace app/src/main/assets/index.html.
