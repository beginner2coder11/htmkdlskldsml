DIAMOND CONSTRUCTION V2 - FINAL APK 2

MOBILE UX / NAVIGATION UPDATE
- Main Dashboard: dedicated 3-dot Main Menu on mobile.
- Any normal section: fixed Back + 3-dot Menu bar.
- Individual Site: Back to Main Dashboard + 3-dot Site Menu.
- Site sections: Back returns to the Individual Site dashboard.
- Android physical Back follows the same navigation hierarchy and closes the mobile drawer/modal first.
- Menu drawer is scrollable and contains all Main Dashboard sections.
- Site drawer contains all Individual Site sections.
- Login, Firebase sync, database structure, calculations and existing FINAL-18 features are preserved.

WEBVIEW
- Local FINAL-18 index.html is loaded from:
  https://appassets.androidplatform.net/assets/index.html
- Firebase/Internet permission is retained.

BUILD
1. Open the 'project' folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Uninstall the older test APK if necessary, then install the new APK.

Do not open index.html directly from a file manager; build/install the Android project.
