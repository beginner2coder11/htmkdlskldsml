DIAMOND CONSTRUCTION V2 - FINAL-18 MOBILE APK

WEBVIEW PATH FIXED
- Local assets are available through both:
  https://appassets.androidplatform.net/assets/index.html
  https://appassets.androidplatform.net/assets/index.html
- Firebase/Internet permission is retained.
- Existing FINAL-18 index.html is kept as the app asset.

BUILD:
1. Open the 'project' folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

Do not open index.html directly from a file manager; build/install the Android project.
