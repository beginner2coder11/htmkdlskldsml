Open index.html in Chrome. Sign in with your role password. Download a backup from Settings regularly.
