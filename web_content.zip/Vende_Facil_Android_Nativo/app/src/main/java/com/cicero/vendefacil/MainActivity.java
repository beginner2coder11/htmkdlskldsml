package com.cicero.vendefacil;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        // Mantém exatamente a origem https://local.file usada pelo APK anterior,
        // preservando a origem do IndexedDB/localStorage entre atualizações assinadas corretamente.
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("local.file")
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new AndroidVendeFacilBridge(), "AndroidVendeFacil");
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        webView.loadUrl("https://local.file/index.html");
    }

    private class AndroidVendeFacilBridge {
        @JavascriptInterface public boolean savePdfBase64(String base64, String filename) {
            try {
                byte[] bytes = decodePdf(base64);
                String safeName = safeFilename(filename);
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Vende Facil");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Não foi possível abrir o arquivo.");
                    out.write(bytes);
                    out.flush();
                } catch (Exception e) {
                    getContentResolver().delete(uri, null, null);
                    throw e;
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "PDF salvo em Downloads/Vende Facil", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Erro ao salvar PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface public boolean sharePdfBase64(String base64, String filename) {
            try {
                byte[] bytes = decodePdf(base64);
                File dir = new File(getCacheDir(), "shared-pdfs");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File file = new File(dir, safeFilename(filename));
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                    out.flush();
                }
                Uri uri = FileProvider.getUriForFile(MainActivity.this,
                        getPackageName() + ".fileprovider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(android.content.ClipData.newUri(getContentResolver(),
                        "Comprovante de venda", uri));
                runOnUiThread(() -> startActivity(Intent.createChooser(send, "Compartilhar comprovante")));
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Erro ao compartilhar PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        private byte[] decodePdf(String base64) {
            if (base64 == null || base64.isEmpty()) throw new IllegalArgumentException("PDF vazio.");
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            if (bytes.length < 5 || bytes[0] != '%' || bytes[1] != 'P' || bytes[2] != 'D' || bytes[3] != 'F' || bytes[4] != '-')
                throw new IllegalArgumentException("O conteúdo gerado não é um PDF válido.");
            return bytes;
        }

        private String safeFilename(String filename) {
            String name = filename == null ? "comprovante-vende-facil.pdf" : filename;
            name = name.replaceAll("[^A-Za-z0-9._-]", "-");
            if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
            return name;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidVendeFacil"); webView.destroy(); }
        super.onDestroy();
    }
}
