# Busdriver Navi V21 – GPX-Fahrtzuordnung

Android-Studio-Quellprojekt (keine APK).

Die originalen WestVerkehr-Guru-Maps-GPX-Tracks wurden mit Linie, Start-/Endzeit und Start-/Endhaltestelle abgeglichen. Nur eindeutige Übereinstimmungen wurden automatisch übernommen. Der zuvor fehlende Track der Linie 409, 07:05–07:40 wurde zugeordnet, sofern im Bericht bestätigt.

Die Karte zeigt Strecken aus GPX/GTFS; dies ist **keine geprüfte Bus-Abbiegenavigation**, keine automatische Neuberechnung, keine garantierte Busbefahrbarkeit. GPS-Funktion und Kartenlayout sind unverändert aus V20. Es wurde kein APK-Build und kein Test auf dem Oukitel durchgeführt.

Statistik: GPX_Zuordnungsbericht.json.
