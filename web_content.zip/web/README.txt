GORDO BURGUER - PROYECTO REAL

Esta versión adapta el proyecto actual al diseño celeste/oscuro acordado:
- fotografías en las tarjetas, sin emojis como imágenes de productos
- categorías y menú
- carrito con cantidades y total
- pedido por WhatsApp
- sin alitas de maracuyá

Para probarlo: abre index.html en un navegador.
Para convertirlo en APK, usa este proyecto como web app/PWA o envuélvelo con Capacitor/Android Studio.
