const PRODUCTS=[
['Hamburguesas','Hamburguesa de carne','Carne + vegetales',10,'burger-carne.jpg'],
['Hamburguesas','Hamburguesa de pollo','Pollo + vegetales',12,'burger-pollo.jpg'],
['Hamburguesas','Hamburguesa mixta','Carne y pollo + vegetales',14,'burger-mixta.jpg'],
['Hamburguesas','Hamburguesa de la casa','Carne + pollo + huevo',20,'burger-casa.jpg'],
['Salchipapas','Salchipapas a lo pobre','Salchicha + papas',10,'papicarne.jpg'],
['Salchipapas','Papicarne a lo pobre','Carne + papas',12,'papicarne.jpg'],
['Salchipapas','Papipollo a lo pobre','Pollo + papas',13,'papipollo.jpg'],
['Salchipapas','Papi-mixto a lo pobre','Mixto + papas',15,'papi-mixto.jpg'],
['Especiales','Club House','Para 2 personas',25,'club-house.jpg'],
['Arroz Chino','Arroz, pollo y jamón','Arroz + pollo + jamón',12,'arroz-pollo-jamon.jpg'],
['Arroz Chino','Arroz, pollo, jamón y camarones','Pollo + jamón + camarones',16,'arroz-mixto.jpg'],
['Lumpias','1 rollo de primavera','1 unidad',5,'lumpia-1.jpg'],
['Lumpias','3 rollos de primavera','3 unidades',12,'lumpia-3.jpg'],
['Alitas Gourmet','4 alitas gourmet','BBQ',15,'alitas-bbq.jpg'],
['Alitas Gourmet','8 alitas gourmet','BBQ picante',20,'alitas-picante.jpg'],
['Alitas Gourmet','16 alitas gourmet','Broaster',35,'alitas-broaster.jpg'],
['Alitas Gourmet','4 alitas gourmet acevichadas','Acevichadas',15,'alitas-acevichadas.jpg']
];
const CAT_IMAGES={
'Hamburguesas':'burger-carne.jpg','Salchipapas':'papicarne.jpg','Alitas Gourmet':'alitas-bbq.jpg','Arroz Chino':'arroz-pollo-jamon.jpg','Lumpias':'lumpia-1.jpg','Especiales':'club-house.jpg'
};
let cart=[];
const $=id=>document.getElementById(id);
const views={home:$('homeView'),menu:$('menuView'),products:$('productsView'),cart:$('cartView')};
function show(v){Object.values(views).forEach(x=>x.classList.add('hidden'));views[v].classList.remove('hidden');document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===v));window.scrollTo(0,0)}
function renderCategories(){
 $('categoryList').innerHTML='';
 ['Hamburguesas','Salchipapas','Alitas Gourmet','Arroz Chino','Lumpias','Especiales'].forEach(cat=>{
  const el=document.createElement('button');el.className='category-card';el.innerHTML=`<img src="assets/${CAT_IMAGES[cat]}" alt=""><span class="cat-name">${cat}</span><span class="arrow">›</span>`;el.onclick=()=>openCategory(cat);$('categoryList').appendChild(el);
 });
}
function openCategory(cat){$('categoryTitle').textContent=cat;$('productList').innerHTML='';PRODUCTS.filter(p=>p[0]===cat).forEach(p=>{
 const el=document.createElement('article');el.className='product-card';el.innerHTML=`<img src="assets/${p[4]}" alt="${p[1]}"><div class="product-info"><h3>${p[1]}</h3><p>${p[2]}</p><div class="price">S/ ${p[3].toFixed(2)}</div><button class="add">+ Agregar</button></div>`;el.querySelector('.add').onclick=()=>add(p);$('productList').appendChild(el);
 });show('products');}
function add(p){const x=cart.find(i=>i[1]===p[1]);x?x[5]++:cart.push([...p,1]);renderCart();}
function renderCart(){
 $('cartBadge').textContent=cart.reduce((n,p)=>n+p[5],0);$('cartItems').innerHTML='';
 let total=0;if(!cart.length){$('cartItems').innerHTML='<p class="empty">Tu carrito está vacío.</p>';$('cartTotal').textContent='0.00';return}
 cart.forEach((p,i)=>{total+=p[3]*p[5];const row=document.createElement('div');row.className='cart-row';row.innerHTML=`<img src="assets/${p[4]}" alt=""><div><h3>${p[1]}</h3><p>S/ ${(p[3]*p[5]).toFixed(2)}</p></div><div class="qty"><button>-</button><b>${p[5]}</b><button>+</button></div>`;const bs=row.querySelectorAll('button');bs[0].onclick=()=>change(i,-1);bs[1].onclick=()=>change(i,1);$('cartItems').appendChild(row)});$('cartTotal').textContent=total.toFixed(2);
}
function change(i,n){cart[i][5]+=n;if(cart[i][5]<=0)cart.splice(i,1);renderCart()}
function sendWhatsApp(){if(!cart.length){alert('Agrega productos al carrito primero.');return}let msg='Hola Gordo Burguer 👋%0AQuiero hacer este pedido:%0A';cart.forEach(p=>msg+=`%0A${p[5]} x ${p[1]} - S/ ${(p[3]*p[5]).toFixed(2)}`);const total=cart.reduce((s,p)=>s+p[3]*p[5],0);msg+=`%0A%0ATotal: S/ ${total.toFixed(2)}%0A%0ANombre:%0ADirección:%0AMétodo de pago:`;window.open('https://wa.me/51955201233?text='+msg,'_blank')}
$('goMenu').onclick=()=>show('menu');$('menuBtn').onclick=()=>show('menu');$('cartBtn').onclick=()=>{renderCart();show('cart')};$('backToMenu').onclick=()=>show('menu');$('backFromCart').onclick=()=>show('menu');$('whatsappBtn').onclick=sendWhatsApp;
document.querySelectorAll('.nav-item').forEach(b=>b.onclick=()=>{if(b.dataset.view==='home')show('home');if(b.dataset.view==='menu')show('menu');if(b.dataset.view==='cart'){renderCart();show('cart')}if(b.dataset.view==='account')alert('Próximamente: Mi cuenta')});
renderCategories();renderCart();
