(function(){
 'use strict';
 function form(data){var pairs=[];Object.keys(data).forEach(function(k){pairs.push(encodeURIComponent(k)+'='+encodeURIComponent(String(data[k])))});return pairs.join('&')}
 function sync(path,data){var x=new XMLHttpRequest();x.open(data?'POST':'GET',path,false);if(data)x.setRequestHeader('Content-Type','application/x-www-form-urlencoded;charset=UTF-8');x.send(data?form(data):null);if(x.status!==200)throw Error(x.responseText||('HTTP '+x.status));return x.responseText}
 function async(path,data,callback){var x=new XMLHttpRequest();x.open('POST',path,true);x.timeout=13000;x.setRequestHeader('Content-Type','application/x-www-form-urlencoded;charset=UTF-8');x.onload=function(){callback(x.status,x.responseText)};x.onerror=function(){callback(0,'Componente Java local sem resposta. Confira a janela do INICIAR_WINDOWS.bat.')};x.ontimeout=function(){callback(0,'Consulta excedeu o tempo limite. Verifique o gerenciador Java da loja.')};x.send(form(data))}
 window.InventoryAndroid={
  loadConfig:function(){return sync('/api/config')},
  saveConfig:function(json){try{sync('/api/config',JSON.parse(json));return true}catch(e){if(window.onNativeStatus)window.onNativeStatus(e.message);return false}},
  queryTerminal:function(json,code,id,test){var c=JSON.parse(json);c.codigo=code;c.test=!!test;async('/api/query',c,function(http,text){if(window.onTerminalResponse)window.onTerminalResponse(id,http===200,text)})}
 };
 function poll(){var x=new XMLHttpRequest();x.open('GET','/api/status',true);x.timeout=2500;x.onload=function(){try{var s=JSON.parse(x.responseText);if(!window.cfg)return;var badge=document.getElementById('queryBadge');if(badge)badge.textContent=window.cfg.terminalName+' • '+(s.connected?'CONECTADO AO GERENCIADOR':'WINDOWS • '+s.message);var area=document.getElementById('windowsStatus');if(area)area.textContent=s.message}catch(e){}};x.send()}
 document.addEventListener('DOMContentLoaded',function(){var e=document.createElement('div');e.id='windowsStatus';e.className='status';e.textContent='Componente Java Windows ativo. Configure o IP do gerenciador na aba Rede.';document.body.appendChild(e);poll();setInterval(poll,2500)});
})();
