# Verificação funcional — 2.3 — 24/10/2026

## Ambiente
Chromium headless real, controlado por Playwright, com IndexedDB real do navegador e ficheiro index.html autónomo servido localmente por interceção de rota. Não houve acesso a contas ou dados do utilizador; apenas dados de teste isolados. Verificação visual das capturas móveis.

## Aprovado
- 32 verificações de cálculos e integridade do núcleo.
- Menu inicial: seis funções, sem dados de compras.
- Cadastro de produto e compressão real de imagem em canvas.
- Compra com caixas, unidades, custo, margem opcional, preço sugerido aplicado, capital, frete e outra despesa.
- Exemplo: 2 caixas × 1.200 Kz, 12 un./caixa, margem 20% → venda 125 Kz; frete 100 + despesa 50 → resultado 450 Kz; capital 5.000 → restante 2.450 Kz.
- Anexo de comprovativo e gravação da compra.
- Geração e descarregamento real de PDF; cabeçalho PDF verificado.
- Nova compra com custo/preço vazios e referência anterior visível; variações; independência dos valores.
- Gravação e recarregamento com preservação dos registos no IndexedDB.
- Histórico com duas compras; relatório por período e PDF.
- Duplicação explícita preserva a compra original; rascunho independente.
- Exportação de backup por download e restauração pelo seletor de ficheiros, preservando imagens, compras e rascunho.
- Apagar todos os dados e recarregar: conteúdo permanece vazio.
- Eliminar definitivamente e recarregar: compra permanece eliminada; cadastro preservado.
- Arquivar/reativar produto.
- PDF longo com 100 linhas e várias páginas, reaberto pela biblioteca PDF.
- Rejeição de backup com estrutura de rascunhos inválida.
- Ecrãs de início e compra nas larguras 320, 390, 768 e 1280 px, sem transbordo horizontal da página.
- Sem erros JavaScript durante o teste completo no navegador.

Testes adicionais em jsdom/fake-indexeddb: mover/restaurar/apagar lixeira, rascunhos separados, falha de gravação preserva dados, confirmação APAGAR aceita espaços/minúsculas, reabertura após limpeza e eventos concorrentes.

## Limites
Não é certificação Android. Não foi compilado nem executado um APK neste ambiente. Transferência/partilha/impressão, seleção de ficheiros e persistência após atualização do APK dependem do conversor e das suas permissões. A pré-visualização de relatório é HTML; a paginação do PDF pode diferir. Não há sincronização entre aparelhos.

## Testes incluídos
- node tests/test-core.cjs
- node tests/test-interface.cjs
- node tests/test-persistence.cjs (requer jsdom e fake-indexeddb)
- node tests/test-browser.cjs (requer Playwright e Chromium; configurar CODEX_PRIMARY_RUNTIME_NODE_MODULES e CHROMIUM_EXECUTABLE conforme o ambiente)
