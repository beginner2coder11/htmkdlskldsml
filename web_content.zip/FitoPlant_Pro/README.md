# FitoPlant Pro

Aplicativo web responsivo preparado para ser empacotado como APK.

## Como configurar
1. Instale Node.js 18+.
2. Execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Coloque a sua chave real em `PLANT_ID_KEY`.
5. Execute `npm start`.
6. Abra `http://localhost:3000`.

## Arquitetura
A chave da API não fica no HTML. O navegador envia a fotografia para `/api/identify`; o servidor chama o serviço de identificação e devolve apenas o resultado necessário.

A secção `MEDICINAL` no `server.js` é a base inicial para benefícios, formas de preparo, partes utilizadas e cuidados. Ela deve ser ampliada com dados fitoterápicos verificados para as espécies que pretende incluir.

## APK
Para transformar em APK, use um WebView/Capacitor apontando para o endereço HTTPS do servidor. Não coloque a chave da API dentro do APK.
