require("dotenv").config();
const express=require("express");
const multer=require("multer");
const path=require("path");
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024}});
app.use(express.static(path.join(__dirname,"public")));

const PORT=process.env.PORT||3000;
const PLANT_ID_URL=process.env.PLANT_ID_URL||"https://api.plant.id/v3/identification";
const PLANT_ID_KEY=process.env.PLANT_ID_KEY||"";

app.get("/api/health",(req,res)=>res.json({configured:!!PLANT_ID_KEY}));

app.post("/api/identify",upload.single("image"),async(req,res)=>{
 try{
   if(!PLANT_ID_KEY)return res.status(503).json({error:"A API de identificação ainda não foi configurada no servidor. Defina PLANT_ID_KEY no arquivo .env."});
   if(!req.file)return res.status(400).json({error:"Nenhuma imagem foi enviada."});

   const base64=req.file.buffer.toString("base64");
   const response=await fetch(PLANT_ID_URL,{
     method:"POST",
     headers:{"Content-Type":"application/json","Api-Key":PLANT_ID_KEY},
     body:JSON.stringify({
       images:[base64],
       similar_images:true,
       health_assessment:false,
       classification_level:"species"
     })
   });
   const raw=await response.text();
   let d; try{d=JSON.parse(raw)}catch{d={}};
   if(!response.ok)return res.status(response.status).json({error:d.message||d.error||"A API externa recusou a solicitação."});

   const s=d.result?.classification?.suggestions?.[0]||d.result?.suggestions?.[0];
   if(!s)return res.status(422).json({error:"Não foi possível identificar a planta na imagem."});

   const scientific=s.name||"";
   const common=s.details?.common_names?.[0]||scientific;

   // Base medicinal local. Deve ser ampliada com fichas verificadas.
   const medicinal=MEDICINAL[scientific]||{benefits:[],preparation:[],parts:[],safety:[]};

   res.json({
     plant:{name:common,scientificName:scientific,confidence:s.probability||0},
     medicinal
   });
 }catch(e){res.status(500).json({error:e.message||"Erro interno do servidor."})}
});

const MEDICINAL={
 "Aloe vera":{
   benefits:["Uso tradicional tópico para cuidados da pele e pequenas irritações.","O gel é tradicionalmente utilizado em preparações cosméticas e dermatológicas."],
   preparation:["Gel fresco para uso tópico, após remoção adequada da parte externa amarela (látex)."],
   parts:["Gel interno da folha."],
   safety:["O látex de Aloe não deve ser confundido com o gel e pode ter efeito laxativo intenso. Evitar uso interno sem orientação profissional."]
 },
 "Zingiber officinale":{
   benefits:["Tradicionalmente utilizado para náuseas e desconforto digestivo.","Utilizado em preparações alimentares e fitoterápicas com finalidade anti-inflamatória tradicional."],
   preparation:["Infusão de rizoma fatiado; também pode ser utilizado fresco em alimentos e bebidas."],
   parts:["Rizoma."],
   safety:["Pode interagir com medicamentos que afetam a coagulação. Uso em doses terapêuticas deve considerar condições individuais."]
 }
};

app.listen(PORT,()=>console.log(`FitoPlant Pro: http://localhost:${PORT}`));