#!/usr/bin/env python3
"""Build a searchable, printable channel-plan page from a radio channel CSV
(e.g. UV32_Useful_Channels_Reference.csv exported from your CHIRP/radio planning).

Expected columns (extra columns are ignored, missing ones are left blank):
  Zone #, Zone Name, Channel #, Name, Technical / Official Name,
  Freq (MHz), Duplex, Offset (MHz), Tone, Mode, Power
"""
import argparse, csv, html, os, time

PINNED = [  # (channel #, why) - shown at the top as the "grab this first" card
    ("10", "Family channel - full power, EMERGENCY use. Monitor on the TOP row."),
    ("40", "Family TEST channel - legal 2 W MURS, use for routine range checks."),
    ("1", "NOAA Weather (WX1-WX7 = ch 1-7, try each)."),
    ("116", "Cherokee County ARES (WB4NWS)."),
    ("117", "Cherokee County EOC (WA4EOC)."),
    ("146", "SATERN / disaster net simplex."),
    ("227", "Georgia statewide Skywarn net control."),
    ("937", "National VHF interop calling (VCALL10) - listen."),
    ("952", "Aviation emergency 121.5 AM - listen."),
    ("953", "Marine ch 16 - listen."),
]


def g(row, *keys):
    for k in keys:
        for rk in row:
            if rk and rk.strip().lower() == k.lower():
                return (row[rk] or "").strip()
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default="UV-32 Go-Bag Radio — Channel Plan")
    a = ap.parse_args()

    rows = []
    with open(a.csv, newline="", encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            rows.append({
                "z": g(r, "Zone #"), "zn": g(r, "Zone Name"), "ch": g(r, "Channel #"),
                "n": g(r, "Name"), "t": g(r, "Technical / Official Name"),
                "f": g(r, "Freq (MHz)"), "d": g(r, "Duplex"), "o": g(r, "Offset (MHz)"),
                "tone": g(r, "Tone"), "m": g(r, "Mode"), "p": g(r, "Power"),
            })
    by_ch = {r["ch"]: r for r in rows}
    zones = []
    for r in rows:
        if not zones or zones[-1][0] != r["z"]:
            zones.append([r["z"], r["zn"], []])
        zones[-1][2].append(r["ch"])

    def tx(r):
        return "RX" if r["d"].lower().startswith("rx") else "TX"

    pinned = []
    for ch, why in PINNED:
        r = by_ch.get(ch)
        if r:
            tone = f" · {html.escape(r['tone'])}" if r["tone"] else ""
            dup = "" if r["d"] in ("Simplex", "RX Only", "") else f" · {html.escape(r['d'])} {html.escape(r['o'])}"
            pinned.append(f"<tr><td class=ch>{ch}</td><td><b>{html.escape(r['n'])}</b></td>"
                          f"<td class=f>{html.escape(r['f'])}{dup}{tone}</td><td>{html.escape(why)}</td></tr>")

    zone_idx = "".join(
        f"<tr><td>{z}</td><td><a href='#z{z}'>{html.escape(zn)}</a></td><td>{chs[0]}–{chs[-1]}</td><td>{len(chs)}</td></tr>"
        for z, zn, chs in zones)
    buttons = "<button data-z='' class=on>All</button>" + "".join(
        f"<button data-z='{z}'>{html.escape(zn)}</button>" for z, zn, _ in zones)

    body = []
    for z, zn, chs in zones:
        body.append(f"<h2 id='z{z}' data-z='{z}'>Zone {z} — {html.escape(zn)} <span class=dim>(ch {chs[0]}–{chs[-1]})</span></h2>"
                    f"<table class=t data-z='{z}'><thead><tr><th>Ch</th><th>Name</th><th>Freq</th><th>Duplex</th>"
                    f"<th>Offset</th><th>Tone</th><th>Mode</th><th>Pwr</th><th></th><th>Notes / official name</th></tr></thead><tbody>")
        for ch in chs:
            r = by_ch[ch]
            k = tx(r)
            body.append(
                f"<tr class='{k.lower()}'><td class=ch>{html.escape(ch)}</td><td><b>{html.escape(r['n'])}</b></td>"
                f"<td class=f>{html.escape(r['f'])}</td><td class=nw>{html.escape(r['d'])}</td><td>{html.escape(r['o'])}</td>"
                f"<td>{html.escape(r['tone'])}</td><td>{html.escape(r['m'])}</td><td>{html.escape(r['p'])}</td>"
                f"<td><span class='b {k.lower()}'>{'LISTEN' if k == 'RX' else 'TX OK'}</span></td>"
                f"<td class=dim>{html.escape(r['t'])}</td></tr>")
        body.append("</tbody></table>")

    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(a.title)}</title>
<style>
body{{margin:0;font:14px/1.4 system-ui,sans-serif;background:#14171a;color:#e6e8eb}}
header{{padding:12px 16px;border-bottom:1px solid #2c323a;display:flex;gap:14px;align-items:baseline;flex-wrap:wrap}}
h1{{font-size:18px;margin:0}} a{{color:#d9a441}} .dim{{color:#9aa3ad;font-size:12px}}
main{{padding:6px 16px 40px}} h2{{font-size:15px;color:#d9a441;margin:22px 0 6px}}
table{{border-collapse:collapse;width:100%;margin:4px 0}} th,td{{padding:4px 6px;border-bottom:1px solid #2c323a;text-align:left;vertical-align:top}}
th{{color:#9aa3ad;font-weight:600;font-size:12px;position:sticky;top:0;background:#14171a}}
.nw{{white-space:nowrap}} .ch{{font-weight:700;font-variant-numeric:tabular-nums}} .f{{font-family:ui-monospace,monospace;white-space:nowrap}}
.b{{font-size:11px;padding:1px 6px;border-radius:9px;white-space:nowrap}} .b.tx{{background:#1f4d2e;color:#9fe3b2}} .b.rx{{background:#4d1f1f;color:#f0a8a8}}
.card{{border:2px solid #d9a441;border-radius:8px;padding:8px 12px;margin:12px 0}} .card h3{{margin:0 0 6px;font-size:15px}}
.warn{{border-color:#c0504d}} input{{font:inherit;color:#e6e8eb;background:#0f1214;border:1px solid #2c323a;border-radius:6px;padding:7px 10px;width:min(360px,90%)}}
.bar{{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}} button{{font:inherit;font-size:12px;background:#1d2227;color:#e6e8eb;border:1px solid #2c323a;border-radius:14px;padding:4px 10px;cursor:pointer}}
button.on{{background:#d9a441;color:#111;border-color:#d9a441}} label{{font-size:13px}}
@media print{{body{{background:#fff;color:#000;font-size:10px}} a{{color:#000}} header .no,.bar,input,label{{display:none}}
 th{{background:#fff;color:#000}} .dim{{color:#333}} h2{{color:#000;page-break-after:avoid}} tr{{page-break-inside:avoid}}
 .b.tx,.b.rx{{background:none;color:#000;border:1px solid #000}} .card{{border-color:#000}}}}
</style></head><body>
<header><h1>{html.escape(a.title)}</h1><span class=dim>{len(rows)} channels · {len(zones)} zones · built {time.strftime('%Y-%m-%d')}</span>
<a class=no href="./">← Library</a><a class=no href="../../">Locator</a><a class=no href="javascript:print()">Print</a></header>
<main>
<div class=card><h3>Grab these first</h3><table>{''.join(pinned)}</table>
<p class=dim>Power-on routine: A/B to TOP row → type 0 1 0 (FRALICK) → A/B to bottom row to browse. Dual Watch keeps family channel live.
SOS: hold SK1 3 s (sends silent alert on the selected channel). Zone change: MENU → Bank → Up/Down → MENU. Scan only covers the current zone.</p></div>
<div class="card warn"><h3>Transmit rules</h3><p class=dim style="font-size:13px;color:#e6e8eb">
<b>LISTEN</b> channels belong to police, fire, hospitals and other licensed systems — do not transmit except a genuine life-safety emergency.
Ham repeaters/simplex need a license except in a real emergency. FRS/GMRS/MURS are set to full power for emergencies only (47 CFR §95.367); use ch 40 for routine testing.
Many county dispatch systems (incl. Cherokee Sheriff/Fire) are digital trunked and cannot be heard on this radio.</p></div>
<h2>Zone index</h2><table><tr><th>#</th><th>Zone</th><th>Channels</th><th>Count</th></tr>{zone_idx}</table>
<div class=bar>{buttons}</div>
<input id=q type=search placeholder="Search name, freq, callsign, city, tone…"> <label><input type=checkbox id=txonly style="width:auto"> transmit-OK only</label>
{''.join(body)}
</main><script>
let Z='';const q=document.getElementById('q'),tx=document.getElementById('txonly');
function f(){{const s=q.value.toLowerCase();
document.querySelectorAll('table.t').forEach(t=>{{const zok=!Z||t.dataset.z===Z;let any=0;
 t.querySelectorAll('tbody tr').forEach(tr=>{{const ok=zok&&(!s||tr.textContent.toLowerCase().includes(s))&&(!tx.checked||tr.classList.contains('tx'));tr.style.display=ok?'':'none';if(ok)any=1;}});
 t.style.display=any?'':'none';document.querySelector('h2[data-z="'+t.dataset.z+'"]').style.display=any?'':'none';}});}}
q.oninput=f;tx.onchange=f;document.querySelectorAll('.bar button').forEach(b=>b.onclick=()=>{{Z=b.dataset.z;
document.querySelectorAll('.bar button').forEach(x=>x.classList.toggle('on',x===b));f();}});
</script></body></html>"""
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write(page)
    print(f"  Channel plan: {len(rows)} channels in {len(zones)} zones -> {a.out}")


if __name__ == "__main__":
    main()
