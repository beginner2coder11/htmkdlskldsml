#!/usr/bin/env python3
"""offgrid-scan: find active radio frequencies with an RTL-SDR dongle (no internet needed).

Sweeps a band with rtl_power, works out the noise floor, and lists frequencies that stood out,
labelled with what they probably are. Results are also saved as CSV in ~/offgrid-scans/.

  offgrid-scan 2m                 # ham 2 m band, 60 s sweep
  offgrid-scan gmrs --time 300    # FRS/GMRS for 5 minutes
  offgrid-scan vhf-ps --watch     # keep sweeping, print new hits as they appear
  offgrid-scan custom 150M:174M   # any range
  offgrid-scan --list             # show presets
"""
import argparse, csv, datetime, os, shutil, statistics, subprocess, sys, tempfile

PRESETS = {
    "noaa":    ("162.375M:162.575M", "12.5k", "NOAA weather radio"),
    "2m":      ("144M:148M", "5k", "Ham 2 m"),
    "1.25m":   ("222M:225M", "5k", "Ham 1.25 m"),
    "70cm":    ("420M:450M", "12.5k", "Ham 70 cm"),
    "gmrs":    ("462.5M:467.8M", "6.25k", "FRS/GMRS"),
    "murs":    ("151.8M:154.65M", "6.25k", "MURS + nearby business"),
    "marine":  ("156M:162.1M", "12.5k", "Marine VHF"),
    "air":     ("118M:137M", "8.33k", "Aviation (AM)"),
    "vhf-ps":  ("150.8M:174M", "6.25k", "VHF public safety / business"),
    "uhf-ps":  ("450M:470M", "6.25k", "UHF public safety / business"),
    "700-800": ("769M:870M", "12.5k", "700/800 MHz trunked systems (control channels)"),
    "cb":      ("26.96M:27.41M", "5k", "CB (needs direct-sampling dongle e.g. RTL-SDR Blog V3/V4)"),
    "fm":      ("88M:108M", "100k", "FM broadcast"),
    "wide":    ("24M:1700M", "100k", "Everything the dongle can hear (slow, coarse)"),
}

BANDS = [  # (lo MHz, hi MHz, label)
    (26.965, 27.405, "CB"), (88, 108, "FM broadcast"), (108, 118, "Aviation navigation"),
    (118, 137, "Aviation voice (AM)"), (137, 138, "Weather satellites (NOAA/Meteor)"),
    (144, 148, "Ham 2 m"), (145.8, 145.81, "ISS voice/APRS downlink"), (144.39, 144.391, "APRS"),
    (148, 150.8, "Military/CAP/federal"), (150.8, 151.8, "VHF business/public safety"),
    (151.82, 151.94, "MURS"), (154.57, 154.6, "MURS"), (151.94, 156, "VHF public safety/business"),
    (156, 157.45, "Marine VHF"), (157.45, 162, "VHF public safety/business/railroad"),
    (162.4, 162.55, "NOAA weather radio"), (162, 174, "Federal/public safety VHF"),
    (222, 225, "Ham 1.25 m"), (225, 400, "Military aviation (UHF AM)"), (406, 406.1, "Emergency beacons (EPIRB/PLB)"),
    (420, 450, "Ham 70 cm"), (450, 462.5, "UHF business/public safety"), (462.55, 462.725, "FRS/GMRS"),
    (462.725, 467.55, "UHF business/public safety"), (467.5625, 467.7125, "FRS/GMRS"),
    (467.7125, 470, "UHF business"), (470, 512, "UHF-T (TV/public safety in some metros)"),
    (764, 776, "700 MHz public safety"), (806, 824, "800 MHz trunked (mobile TX)"),
    (851, 869, "800 MHz trunked (repeater/control)"), (1090, 1090.1, "ADS-B aircraft transponders"),
]


def label(mhz):
    hits = [b for b in BANDS if b[0] <= mhz <= b[1]]
    return min(hits, key=lambda b: b[1] - b[0])[2] if hits else ""


def sweep(rng, step, seconds, gain, ppm):
    tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False).name
    cmd = ["rtl_power", "-f", f"{rng}:{step}", "-i", "2", "-e", f"{seconds}s", "-c", "0.2", tmp]
    if gain is not None:
        cmd[1:1] = ["-g", str(gain)]
    if ppm:
        cmd[1:1] = ["-p", str(ppm)]
    print(f"Sweeping {rng} for {seconds}s …  (Ctrl-C to stop early)", file=sys.stderr)
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    except KeyboardInterrupt:
        pass
    peak = {}
    with open(tmp) as fh:
        for row in csv.reader(fh):
            if len(row) < 7:
                continue
            lo, stepw = float(row[2]), float(row[4])
            for i, v in enumerate(row[6:]):
                try:
                    db = float(v)
                except ValueError:
                    continue
                f = round((lo + stepw * (i + 0.5)) / 1e6, 4)
                if db > peak.get(f, -999):
                    peak[f] = db
    os.unlink(tmp)
    return peak


def find_hits(peak, threshold):
    if not peak:
        return []
    floor = statistics.median(peak.values())
    hits = sorted(((f, db, db - floor) for f, db in peak.items() if db - floor >= threshold),
                  key=lambda x: x[0])
    merged = []  # merge adjacent bins into one signal, keep strongest
    for h in hits:
        if merged and h[0] - merged[-1][0] < 0.015:
            if h[1] > merged[-1][1]:
                merged[-1] = h
        else:
            merged.append(h)
    return merged


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("preset", nargs="?", default="2m")
    ap.add_argument("range", nargs="?", help="for 'custom': e.g. 150M:174M")
    ap.add_argument("--time", type=int, default=60, help="seconds per sweep (default 60)")
    ap.add_argument("--step", help="bin size, e.g. 6.25k")
    ap.add_argument("--threshold", type=float, default=10, help="dB above noise floor (default 10)")
    ap.add_argument("--gain", type=float, help="tuner gain dB (default auto)")
    ap.add_argument("--ppm", type=int, default=0, help="frequency correction")
    ap.add_argument("--watch", action="store_true", help="repeat forever, show new hits")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    if a.list:
        for k, (r, s, d) in PRESETS.items():
            print(f"  {k:9} {r:20} {d}")
        return
    if not shutil.which("rtl_power"):
        sys.exit("rtl_power not found — install with: sudo apt install rtl-sdr")
    if a.preset == "custom":
        if not a.range:
            sys.exit("custom needs a range, e.g. offgrid-scan custom 150M:174M")
        rng, step, desc = a.range, a.step or "12.5k", "custom"
    elif a.preset in PRESETS:
        rng, step, desc = PRESETS[a.preset]
        step = a.step or step
    else:
        sys.exit(f"unknown preset '{a.preset}'. Use --list.")

    outdir = os.path.expanduser("~/offgrid-scans")
    os.makedirs(outdir, exist_ok=True)
    seen = {}
    while True:
        peak = sweep(rng, step, a.time, a.gain, a.ppm)
        hits = find_hits(peak, a.threshold)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
        path = os.path.join(outdir, f"{a.preset}_{stamp}.csv")
        with open(path, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["freq_mhz", "peak_db", "above_floor_db", "probably"])
            for f, db, snr in hits:
                w.writerow([f"{f:.4f}", f"{db:.1f}", f"{snr:.1f}", label(f)])
        new = [h for h in hits if round(h[0], 3) not in seen]
        for h in hits:
            seen[round(h[0], 3)] = h
        print(f"\n{desc}: {len(hits)} active signal(s) {'(' + str(len(new)) + ' new)' if a.watch else ''}  saved {path}")
        print(f"  {'MHz':>10}  {'dB over noise':>13}  probably")
        for f, db, snr in (new if a.watch else hits):
            print(f"  {f:10.4f}  {snr:13.1f}  {label(f)}")
        if not a.watch:
            break
    print("\nTune a hit in gqrx/SDR++ (or type it into a radio) to listen. "
          "Strong steady carriers on 700/800/UHF are often trunking control channels — use SDRTrunk.")


if __name__ == "__main__":
    main()
