#!/usr/bin/env python3
"""Tiny static file server with HTTP Range support (needed for .pmtiles map files)."""
import argparse, os, re
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial


class RangeHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      ".pmtiles": "application/octet-stream", ".js": "text/javascript",
                      ".geojson": "application/geo+json"}

    def send_head(self):
        rng = self.headers.get("Range")
        path = self.translate_path(self.path)
        if not rng or not os.path.isfile(path):
            return super().send_head()
        m = re.match(r"bytes=(\d*)-(\d*)$", rng.strip())
        size = os.path.getsize(path)
        if not m:
            self.send_error(416); return None
        start, end = m.group(1), m.group(2)
        if start == "":
            start, end = max(0, size - int(end)), size - 1
        else:
            start, end = int(start), (int(end) if end else size - 1)
        end = min(end, size - 1)
        if start > end:
            self.send_response(416); self.send_header("Content-Range", f"bytes */{size}")
            self.end_headers(); return None
        f = open(path, "rb"); f.seek(start)
        self._remaining = end - start + 1
        self.send_response(206)
        self.send_header("Content-Type", self.guess_type(path))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(self._remaining))
        self.end_headers()
        return f

    def copyfile(self, src, dst):
        rem = getattr(self, "_remaining", None)
        if rem is None:
            return super().copyfile(src, dst)
        while rem > 0:
            buf = src.read(min(65536, rem))
            if not buf:
                break
            dst.write(buf); rem -= len(buf)
        self._remaining = None

    def end_headers(self):
        self.send_header("Accept-Ranges", "bytes")
        super().end_headers()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=".")
    ap.add_argument("--port", type=int, default=8090)
    ap.add_argument("--bind", default="0.0.0.0")
    a = ap.parse_args()
    httpd = ThreadingHTTPServer((a.bind, a.port), partial(RangeHandler, directory=a.dir))
    print(f"Serving {a.dir} on http://{a.bind}:{a.port}")
    httpd.serve_forever()
