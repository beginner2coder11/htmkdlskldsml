#!/usr/bin/env python3
"""
Build the offline points-of-interest database from filtered OpenStreetMap files.

Reads every *.osm.pbf (or .osm) in --in-dir, classifies features into categories,
keeps those within --radius miles of (--lat, --lon), de-duplicates across state
files, and writes:
    pois.csv       spreadsheet-friendly
    pois.geojson   for GIS / map apps (QGIS, Organic Maps import, etc.)
    pois.js        loaded by the offline finder page (works even from file://)
"""
import argparse, csv, glob, json, math, os, re, sys, time

try:
    import osmium  # only needed when building from OpenStreetMap files
except ImportError:  # the USB builder imports helpers without osmium
    osmium = None

CATEGORIES = {
    "hospital":   "Hospital",
    "urgent_care": "Urgent care",
    "clinic":     "Clinic / doctor",
    "pharmacy":   "Pharmacy",
    "grocery":    "Grocery store",
    "food_dist":  "Food bank / food distribution",
    "gun_shop":   "Gun / hunting shop",
    "armory":     "Armory / National Guard",
    "military":   "Military base / installation",
    "police":     "Police / sheriff",
    "fire":       "Fire station",
    "ems":        "Ambulance / EMS station",
    "repeater":   "Ham / GMRS repeater",
    "broadcast":  "Broadcast transmitter (AM/FM/TV)",
    "media":      "Radio / TV studio / newspaper",
    "comm_tower": "Communication tower",
    "fuel": "Fuel / propane",
    "shelter": "Shelter / community center",
    "hardware": "Hardware / feed & seed",
    "water": "Water source (spring, well, water point)",
    "outdoor": "Sporting goods / outdoor",
    "vet": "Veterinary clinic",
    "auto_parts": "Auto parts",
    "general": "Big-box / dollar / general store",
    "power_plant": "Solar farm / power plant",
    "rv_marine": "RV / boat / marina / golf (batteries, solar)",
    "herbal": "Herbal / health-food / supplement store",
    "health_lab": "Public health, CDC, labs, blood banks, dialysis & medical research",
    "pawn": "Pawn shop",
    "restaurant": "Restaurant / fast food",
    "convenience": "Convenience store",
    "surplus": "Army surplus / second-hand outdoor gear",
    "cave": "Cave / cave entrance",
}
MED_RESEARCH_WORDS = ("medic", "health", "disease", "bio", "pharma", "cancer", "clinical", "lab", "vaccine", "genom", "cdc",
                      "epidemiolog", "infect", "immun", "virus", "neuro", "cardio")

URGENT_WORDS = ("urgent", "immediate care", "walk-in", "walk in", "minuteclinic",
                "minute clinic", "express care", "quickcare", "quick care",
                "after hours", "afterhours", "emergency")
ARMORY_WORDS = ("armory", "armoury", "national guard", "readiness center")
BASE_TYPES = {"base", "airfield", "naval_base", "barracks", "training_area"}


def classify(t):
    """Return a category key for a tag dict, or None."""
    name = (t.get("name") or t.get("official_name") or "").lower()
    amenity, shop, hc = t.get("amenity"), t.get("shop"), t.get("healthcare")
    sf = t.get("social_facility")

    if amenity == "hospital" or hc == "hospital":
        return "hospital"
    if hc == "urgent_care" or t.get("urgent_care") == "yes":
        return "urgent_care"
    if amenity in ("clinic", "doctors") or hc in ("clinic", "doctor", "centre"):
        if any(w in name for w in URGENT_WORDS):
            return "urgent_care"
        return "clinic"
    if amenity == "pharmacy" or hc == "pharmacy":
        return "pharmacy"
    if shop in ("herbalist", "health_food", "nutrition_supplements") or hc == "alternative":
        return "herbal"
    if hc in ("laboratory", "blood_donation", "dialysis") or "centers for disease control" in name:
        return "health_lab"
    if (amenity == "research_institute" or t.get("office") in ("research", "government")) and any(w in name for w in MED_RESEARCH_WORDS):
        return "health_lab"
    if shop in ("supermarket", "grocery", "greengrocer", "wholesale", "food"):
        return "grocery"
    if amenity in ("food_bank", "soup_kitchen", "food_sharing") or sf in ("food_bank", "soup_kitchen"):
        return "food_dist"
    if amenity == "social_facility" and ("food" in name or "pantry" in name):
        return "food_dist"
    if shop in ("weapons", "guns", "hunting"):
        return "gun_shop"
    if t.get("natural") == "cave_entrance" or t.get("geological") == "cave":
        return "cave"
    if shop in ("pawnbroker", "pawn"):
        return "pawn"
    if shop in ("army_surplus", "military_surplus", "surplus"):
        return "surplus"
    if shop == "convenience":
        return "convenience"
    if amenity in ("restaurant", "fast_food"):
        return "restaurant"
    if shop in ("outdoor", "sports", "fishing", "camping"):
        return "outdoor"
    if amenity == "veterinary":
        return "vet"
    if t.get("power") == "plant":
        return "power_plant"
    if shop in ("caravan", "boat", "golf") or t.get("leisure") in ("marina", "golf_course"):
        return "rv_marine"
    if shop in ("car_parts", "tyres"):
        return "auto_parts"
    if shop in ("department_store", "variety_store", "general", "discount", "mall"):
        return "general"
    if amenity == "fuel" or shop in ("gas", "fuel"):
        return "fuel"
    if sf == "shelter" or amenity in ("community_centre", "refugee_site") or t.get("emergency") == "assembly_point" \
            or (amenity == "shelter" and t.get("shelter_type") in ("emergency", "basic_hut", "lean_to")):
        return "shelter"
    if shop in ("hardware", "doityourself", "farm", "agrarian", "trade", "garden_centre"):
        return "hardware"
    if amenity in ("drinking_water", "water_point") or t.get("natural") == "spring" \
            or (t.get("man_made") == "water_well" and t.get("access") not in ("private", "no")):
        return "water"

    if amenity == "police":
        return "police"
    if amenity == "fire_station":
        return "fire"
    if t.get("emergency") == "ambulance_station":
        return "ems"
    if any(k.startswith("communication:amateur_radio") for k in t) and "repeater" in " ".join(
            k + "=" + v for k, v in t.items() if k.startswith("communication")).lower():
        return "repeater"
    if amenity == "studio" or t.get("office") in ("newspaper", "radio", "television") or t.get("studio"):
        return "media"
    if t.get("man_made") == "communications_tower" or (
            t.get("man_made") in ("mast", "tower") and t.get("tower:type") in ("communication", "radio", "broadcast")):
        return "comm_tower"

    is_mil = ("military" in t or t.get("landuse") == "military"
              or t.get("building") == "military" or t.get("office") == "military")
    if is_mil:
        if any(w in name for w in ARMORY_WORDS):
            return "armory"
        if t.get("military") in BASE_TYPES or (t.get("landuse") == "military" and name):
            return "military"
    return None


def haversine(lat1, lon1, lat2, lon2):
    R = 3958.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def bearing(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    deg = (math.degrees(math.atan2(x, y)) + 360) % 360
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int((deg + 22.5) // 45) % 8]


def centroid(noderefs):
    locs = [n.location for n in noderefs]
    pts = [(c.lat, c.lon) for c in locs if c.valid()]
    if not pts:
        return None
    return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)


def address(t):
    line1 = " ".join(x for x in (t.get("addr:housenumber"), t.get("addr:street")) if x)
    parts = [line1, t.get("addr:city"), t.get("addr:state")]
    s = ", ".join(p for p in parts if p)
    if t.get("addr:postcode"):
        s = (s + " " + t["addr:postcode"]).strip()
    return s or t.get("addr:full", "")


def info_for(cat, t):
    if cat == "repeater":
        bits = [t.get(k) for k in ("frequency", "communication:amateur_radio:repeater:frequency", "ref") if t.get(k)]
        return " ".join(bits)
    if cat in ("comm_tower", "broadcast", "media"):
        return t.get("operator", "") or t.get("brand", "")
    if cat == "fuel":
        bits = []
        if t.get("shop") == "gas" or t.get("fuel:lpg") == "yes" or t.get("fuel:propane") == "yes":
            bits.append("propane")
        if t.get("fuel:diesel") == "yes":
            bits.append("diesel")
        if t.get("fuel:kerosene") == "yes":
            bits.append("kerosene")
        if t.get("fuel:e0") == "yes" or t.get("fuel:ethanol_free") == "yes":
            bits.append("ethanol-free")
        return ", ".join(bits)
    if cat == "power_plant":
        src = t.get("plant:source") or t.get("generator:source") or ""
        out = t.get("plant:output:electricity", "")
        return " ".join(x for x in (src, out, t.get("operator", "")) if x)
    if cat == "water":
        bits = [t.get("natural") or t.get("man_made") or t.get("amenity") or ""]
        if t.get("drinking_water") in ("yes", "no"):
            bits.append("drinkable" if t["drinking_water"] == "yes" else "NOT drinkable untreated")
        bits.append("always treat wild water")
        return " · ".join(b for b in bits if b).replace("_", " ")
    if cat == "shelter":
        return t.get("social_facility:for", "") or t.get("operator", "")
    return ""


def dms(hemi, d, m, sec):
    v = float(d) + float(m) / 60 + float(sec) / 3600
    return -v if hemi in ("S", "W") else v


FCC_LL = re.compile(r"\|\s*([NS])\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|\s*([WE])\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|")


def load_fcc(fcc_dir):
    """Parse FCC AM/FM/TV Query pipe-delimited output (list=4). Layout-tolerant: finds the
    N/S d|m|s W/E d|m|s run, the 'US' country field (city/state precede it), and licensee after coords."""
    out, seen = [], set()
    for f in sorted(glob.glob(os.path.join(fcc_dir, "*.txt"))):
        band = os.path.basename(f).split("_")[0].upper()          # am / fm / tv
        for line in open(f, encoding="latin-1"):
            line = re.sub(r"<[^>]+>", "", line)
            m = FCC_LL.search(line)
            if not m or not line.strip().startswith("|"):
                continue
            fields = [x.strip() for x in line.strip().strip("|").split("|")]
            if "LIC" not in fields:            # licensed stations only (skip applications/permits)
                continue
            call, freq, serv = (fields + ["", "", ""])[:3]
            city = state = ""
            if "US" in fields:
                i = fields.index("US")
                city, state = fields[i - 2], fields[i - 1]
            after = line[m.end():].split("|")
            licensee = after[0].strip() if after else ""
            lat = dms(m.group(1), m.group(2), m.group(3), m.group(4))
            lon = dms(m.group(5), m.group(6), m.group(7), m.group(8))
            key = (call, freq)
            if key in seen or not call:
                continue
            seen.add(key)
            label = {"FM": "FM", "AM": "AM", "TV": "TV"}.get(band, band)
            out.append({"name": " ".join(f"{call} {freq} {label}".split()), "lat": lat, "lon": lon,
                        "addr": ", ".join(x for x in (city.title(), state) if x),
                        "info": " · ".join(x for x in (serv, licensee) if x), "src": f"fcc/{call}"})
    return out


def _pick(row, *names):
    low = {k.strip().lower(): v for k, v in row.items() if k}
    for n in names:
        if n in low and str(low[n]).strip():
            return str(low[n]).strip()
    return ""


def load_repeaters(rep_dir):
    """Import repeater CSV exports you downloaded yourself (e.g. RepeaterBook personal-use exports).
    Any CSV with latitude/longitude columns works; frequency/tone/call/city columns are used if present."""
    out = []
    for f in sorted(glob.glob(os.path.join(rep_dir, "*.csv"))):
        with open(f, newline="", encoding="utf-8-sig", errors="replace") as fh:
            for row in csv.DictReader(fh):
                lat = _pick(row, "lat", "latitude")
                lon = _pick(row, "long", "lon", "lng", "longitude")
                try:
                    lat, lon = float(lat), float(lon)
                except ValueError:
                    continue
                freq = _pick(row, "frequency", "output freq", "output", "freq", "downlink")
                inp = _pick(row, "input freq", "input", "uplink")
                off = _pick(row, "offset")
                tone = _pick(row, "uplink tone", "pl", "ctcss", "tone", "access tone", "rtone")
                call = _pick(row, "call", "callsign", "call sign", "name")
                city = _pick(row, "location", "nearest city", "city", "landmark")
                state = _pick(row, "state")
                use = _pick(row, "use", "status", "mode", "modes")
                info = " ".join(x for x in (
                    f"out {freq}" if freq else "", f"in {inp}" if inp else (f"offset {off}" if off else ""),
                    f"tone {tone}" if tone else "", use) if x)
                out.append({"name": " ".join(x for x in (call, freq) if x) or "Repeater", "lat": lat, "lon": lon,
                            "addr": ", ".join(x for x in (city, state) if x), "info": info,
                            "src": "csv/" + os.path.basename(f)})
    return out


def read_pbf(f, lat0, lon0, radius, seen, areas=True):
    """Rows for every classified place in one OSM file within `radius` miles of (lat0, lon0).
    `seen` is shared between files so places on a border that appear in two extracts count once.
    areas=False skips multipolygon relations (much faster; only large campuses drawn as relations are missed)."""
    rows = []
    fp = osmium.FileProcessor(f).with_locations()
    if areas:
        fp = fp.with_areas()
    for o in fp:
        if areas and o.is_area():
            if o.from_way():
                continue  # ways are handled directly below
            key = ("relation", o.orig_id())
        elif o.is_node():
            key = ("node", o.id)
        elif o.is_way():
            key = ("way", o.id)
        else:
            continue  # raw relations (geometry comes from the area)
        if key in seen or len(o.tags) == 0:
            continue
        tags = {t.k: t.v for t in o.tags}
        cat = classify(tags)
        if not cat:
            continue
        if o.is_node():
            if not o.location.valid():
                continue
            lat, lon = o.location.lat, o.location.lon
        elif o.is_way():
            c = centroid(o.nodes)
            if not c:
                continue
            lat, lon = c
        else:
            rings = list(o.outer_rings())
            if not rings:
                continue
            c = centroid(rings[0])
            if not c:
                continue
            lat, lon = c
        miles = haversine(lat0, lon0, lat, lon)
        if miles > radius:
            continue
        seen.add(key)
        rows.append({
            "cat": cat,
            "name": tags.get("name") or tags.get("brand") or tags.get("operator") or {"water": "Water source", "fuel": "Fuel", "shelter": "Shelter"}.get(cat, "(unnamed)"),
            "lat": round(lat, 6), "lon": round(lon, 6),
            "miles": round(miles, 1), "dir": bearing(lat0, lon0, lat, lon),
            "addr": address(tags),
            "phone": tags.get("phone") or tags.get("contact:phone", ""),
            "web": tags.get("website") or tags.get("contact:website", ""),
            "hours": tags.get("opening_hours", ""),
            "osm": f"{key[0]}/{key[1]}",
            "info": info_for(cat, tags),
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--lat", type=float, required=True)
    ap.add_argument("--lon", type=float, required=True)
    ap.add_argument("--radius", type=float, default=500.0, help="miles")
    ap.add_argument("--label", default="")
    ap.add_argument("--fcc-dir", default="")
    ap.add_argument("--repeater-dir", default="")
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.in_dir, "*.osm.pbf")) +
                   glob.glob(os.path.join(a.in_dir, "*.osm")))
    if not files:
        print(f"  (no OSM files found in {a.in_dir})")

    seen, rows = set(), []
    for f in files:
        print(f"  reading {os.path.basename(f)} ...", flush=True)
        rows += read_pbf(f, a.lat, a.lon, a.radius, seen)

    extra = []
    if a.fcc_dir and os.path.isdir(a.fcc_dir):
        extra += [("broadcast", e) for e in load_fcc(a.fcc_dir)]
    if a.repeater_dir and os.path.isdir(a.repeater_dir):
        extra += [("repeater", e) for e in load_repeaters(a.repeater_dir)]
    for cat, e in extra:
        miles = haversine(a.lat, a.lon, e["lat"], e["lon"])
        if miles > a.radius:
            continue
        rows.append({"cat": cat, "name": e["name"], "lat": round(e["lat"], 6), "lon": round(e["lon"], 6),
                     "miles": round(miles, 1), "dir": bearing(a.lat, a.lon, e["lat"], e["lon"]),
                     "addr": e["addr"], "phone": "", "web": "", "hours": "", "osm": e["src"], "info": e["info"]})

    write_outputs(rows, a)


def make_row(cat, tags, lat, lon, osm_ref, home_lat, home_lon):
    """One locator row from OSM-style tags (shared with the USB builder's Overpass import)."""
    return {
        "cat": cat,
        "name": tags.get("name") or tags.get("brand") or tags.get("operator") or {"water": "Water source", "fuel": "Fuel", "shelter": "Shelter"}.get(cat, "(unnamed)"),
        "lat": round(lat, 6), "lon": round(lon, 6),
        "miles": round(haversine(home_lat, home_lon, lat, lon), 1), "dir": bearing(home_lat, home_lon, lat, lon),
        "addr": address(tags),
        "phone": tags.get("phone") or tags.get("contact:phone", ""),
        "web": tags.get("website") or tags.get("contact:website", ""),
        "hours": tags.get("opening_hours", ""),
        "osm": osm_ref,
        "info": info_for(cat, tags),
    }


_GENERIC = {"", "(unnamed)", "water source", "fuel", "shelter"}


def dedupe(items, key=lambda r: (r["cat"], r["name"], r["lat"], r["lon"]), score=None, seen_cells=None):
    """Drop repeats of the same place: same category, same name (ignoring case/punctuation), within ~75 m
    (~30 m for unnamed/generic names). Keeps the entry with the most detail. `seen_cells` (a dict) can be shared
    between calls so later batches are checked against earlier ones. Returns (kept, removed_count)."""
    cells = seen_cells if seen_cells is not None else {}
    kept, removed = [], 0
    for it in items:
        cat, name, lat, lon = key(it)
        nm = re.sub(r"[^a-z0-9]+", "", str(name).lower())
        tol = 0.0003 if nm in {re.sub(r"[^a-z0-9]+", "", g) for g in _GENERIC} else 0.00075   # degrees of latitude
        dup = None
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for other in cells.get((cat, nm, int(lat / 0.001) + dy, int(lon / 0.001) + dx), ()):
                    if abs(other[0] - lat) < tol and abs(other[1] - lon) < tol * 1.2:
                        dup = other
                        break
                if dup:
                    break
            if dup:
                break
        if dup:
            removed += 1
            if score and dup[4] is kept and score(it) > dup[3]:   # same batch and more detail: swap it in
                kept[dup[2]] = it
                dup[3] = score(it)
            continue
        rec = [lat, lon, len(kept), score(it) if score else 0, kept]
        cells.setdefault((cat, nm, int(lat / 0.001), int(lon / 0.001)), []).append(rec)
        kept.append(it)
    return kept, removed


def write_outputs(rows, a):
    """Write pois.csv / pois.geojson / pois.js. `a` needs lat, lon, radius, label, out_dir."""
    rows, _dups = dedupe(rows, score=lambda r: sum(1 for k in ("addr", "phone", "web", "hours", "info") if r.get(k)))
    if _dups:
        print(f"  removed {_dups:,} duplicate places")
    rows.sort(key=lambda r: (r["cat"], r["miles"]))
    os.makedirs(a.out_dir, exist_ok=True)
    fields = ["cat", "name", "miles", "dir", "addr", "info", "phone", "web", "hours", "lat", "lon", "osm"]

    with open(os.path.join(a.out_dir, "pois.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["category"] + fields[1:])
        w.writeheader()
        for r in rows:
            d = {k: r[k] for k in fields[1:]}
            d["category"] = CATEGORIES[r["cat"]]
            w.writerow(d)

    with open(os.path.join(a.out_dir, "pois.geojson"), "w", encoding="utf-8") as fh:
        json.dump({"type": "FeatureCollection", "features": [
            {"type": "Feature",
             "geometry": {"type": "Point", "coordinates": [r["lon"], r["lat"]]},
             "properties": {k: v for k, v in r.items() if k not in ("lat", "lon")}}
            for r in rows]}, fh)

    meta = {"center": [a.lat, a.lon], "radius": a.radius, "label": a.label,
            "built": time.strftime("%Y-%m-%d"), "categories": CATEGORIES}
    with open(os.path.join(a.out_dir, "pois.js"), "w", encoding="utf-8") as fh:
        fh.write("window.POI_META=" + json.dumps(meta) + ";\n")
        fh.write("window.POIS=" + json.dumps(
            [[r["cat"], r["name"], r["lat"], r["lon"], r["miles"], r["dir"],
              r["addr"], r["phone"], r["web"], r["hours"], r["osm"], r["info"]] for r in rows],
            separators=(",", ":")) + ";\n")

    counts = {}
    for r in rows:
        counts[r["cat"]] = counts.get(r["cat"], 0) + 1
    print(f"\n  {len(rows)} places within {a.radius:g} miles:")
    for k, label in CATEGORIES.items():
        print(f"    {label:<32} {counts.get(k, 0):>7}")


if __name__ == "__main__":
    main()
