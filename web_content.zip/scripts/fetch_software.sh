#!/usr/bin/env bash
# Download installers listed in software.tsv into the Library's Software folder.
# Usage: fetch_software.sh <software.tsv> <www/library/Software> <titles_out.tsv>
set -uo pipefail
TSV="$1"; OUT="$2"; TITLES="$3"
UA="Mozilla/5.0 (X11; Linux x86_64) offgrid-installer"
mkdir -p "$OUT"; : > "$TITLES.new"; MAN="$OUT/.manifest"; touch "$MAN"
fails=0

latest_chirp() {   # prints "name url" lines for the newest CHIRP-next build
  local base="https://archive.chirpmyradio.com/chirp_next" rel
  rel=$(curl -fsSL -A "$UA" "$base/" | grep -oE 'next-[0-9]{8}' | sort -u | tail -1) || return 1
  [[ -n "$rel" ]] || return 1
  curl -fsSL -A "$UA" "$base/$rel/" | grep -oE 'href="[^"]+"' | sed 's/href="//;s/"$//' | grep -v '/$' |
    sed 's|.*/||' | sort -u | while read -r f; do echo "$f $base/$rel/$f"; done
}

while IFS=$'\t' read -r title src; do
  [[ -z "${title// }" || "$title" == \#* ]] && continue
  kind="${src%%:*}"; rest="${src#*:}"
  list=""
  case "$kind" in
    github)
      repo="${rest%%:*}"; rx="${rest#*:}"; rel="latest"
      if [[ "$repo" == *@* ]]; then rel="tags/${repo#*@}"; repo="${repo%@*}"; fi
      list=$(curl -fsSL -A "$UA" "https://api.github.com/repos/$repo/releases/$rel" 2>/dev/null |
             jq -r '.assets[]? | .name + " " + .browser_download_url' 2>/dev/null) ;;
    chirp)
      rx="$rest"; list=$(latest_chirp 2>/dev/null) ;;
    url)
      n0="$(basename "${rest%%\?*}")"; list="$n0 $rest"
      rx="^$(printf '%s' "$n0" | sed 's/[.+]/[&]/g')\$" ;;
    *) echo "  ? unknown source: $src"; continue ;;
  esac
  line=$(printf '%s\n' "$list" | awk '{print $1" "$2}' | while read -r n u; do
           [[ -n "$n" ]] && echo "$n" | grep -Eq -- "$rx" && { echo "$n $u"; break; }; done)
  if [[ -z "$line" ]]; then
    # offline or no match: keep whatever we already have
    have=$(awk -F'\t' -v t="$title" '$1==t{print $2}' "$MAN" 2>/dev/null | tail -1)
    [[ -n "$have" && ! -s "$OUT/$have" ]] && have=""
    if [[ -n "$have" ]]; then printf 'Software\t%s\t%s\tlocal\n' "$title" "$have" >> "$TITLES.new"
    else echo "  ✗ $title (not found)"; fails=$((fails+1)); fi
    continue
  fi
  name="${line%% *}"; url="${line#* }"
  if [[ ! -s "$OUT/$name" ]]; then
    echo "  ↓ $title"
    if curl -fL --retry 3 -A "$UA" -o "$OUT/$name.part" "$url"; then
      mv "$OUT/$name.part" "$OUT/$name"
      # remove the older version of this same item (tracked in the manifest)
      old=$(awk -F'\t' -v t="$title" '$1==t{print $2}' "$MAN" 2>/dev/null | tail -1)
      [[ -n "$old" && "$old" != "$name" && "$old" != */* ]] && rm -f "$OUT/$old"
    else
      rm -f "$OUT/$name.part"; echo "  ✗ $title (download failed)"; fails=$((fails+1)); continue
    fi
  fi
  printf 'Software\t%s\t%s\tlocal\n' "$title" "$name" >> "$TITLES.new"
  { grep -v -F "$title"$'\t' "$MAN" 2>/dev/null; printf '%s\t%s\n' "$title" "$name"; } > "$MAN.tmp"; mv "$MAN.tmp" "$MAN"
done < "$TSV"
mv "$TITLES.new" "$TITLES"
echo "  Software downloads done ($fails not available)."
exit 0
