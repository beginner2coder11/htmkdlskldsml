#!/usr/bin/env python3
"""Make the PUBLIC edition zip from this repository: the same builder, with the author's personal pieces removed.

    python3 scripts/make_public.py [--out /path/offgrid-public-v41.zip] [--version v41]

The public edition asks for a ZIP code on the first run and builds the drive around it (map centre, nearby states, regional
topo, bases, cities, lakes). Removed: the author's UV-32 radio plan, his get-home routes and work cities, his name. Added:
BUILD-MY-DRIVE.bat, a public README, edition.json (switches the ZIP prompt on) and the 'Files to add yourself' page.
The personal repository is never modified: this builds a copy in a temp folder.
"""
import argparse, os, re, shutil, sys, tempfile, zipfile

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DROP_DIRS = ["library/My Radio Programming", "library/Getting Home"]
DROP_FILES = ["scripts/build_channels.py", "scripts/make_public.py", "README.md"]
DROP_CATS = ("My Radio Programming", "Getting Home")
SKIP = (".zip", ".pyc")

STUB_ROUTES = '''# -*- coding: utf-8 -*-
"""Get-home routes. The public edition ships none (they are specific to one person's work trips); the builder sets HOME from your ZIP code.
Add your own: ROUTES = [{"key","label","miles","drive","line":[[lat,lon],...],"spots":[{"name","lat","lon","kind"}]}]."""
HOME = {"name": "Home", "lat": 0.0, "lon": 0.0}
ROUTES = []


def _box(lat, lon, miles):
    import math
    dl, dn = miles / 69.0, miles / (69.17 * math.cos(math.radians(lat)))
    return [lon - dn, lat - dl, lon + dn, lat + dl]


def topo_spots(box_miles=11):
    return []


def poi_centers():
    return []
'''

README = """# OFF-GRID SURVIVAL DRIVE builder - public edition ({v})

Builds an offline survival drive for YOUR area: a Command Center (Windows / Mac / Linux, phones via Wi-Fi), a library of
manuals, offline Wikipedia and medical archives, offline AI, maps, topo maps, hospitals, flood zones and checklists.

## Build your own drive
1. Get a USB drive or external SSD (at least 64 GB; 1 TB or more for the full build). Format it exFAT (NTFS is fine for Windows only).
2. Unzip this folder to your computer (NOT onto the drive), for example `C:\\offgrid-builder`.
3. Windows: double-click **BUILD-MY-DRIVE.bat**. Type the drive letter, then your **5-digit ZIP code**. Confirm the town it finds.
   The size of the build is chosen from the free space on the drive. Leave it plugged in; it can take many hours and resumes if stopped.
   Mac / Linux: `python3 usb/usb_builder.py --dest /path/to/OFFGRID --zip 12345`
4. When it finishes, open the drive and double-click **START-HERE.bat** (a window with buttons; START THE DRIVE opens the Command Center).

Everything is built around your ZIP: map centre and street map, topo maps, nearby states' map extracts, cities / bases / lakes
within range, hospitals, weather and flood data. To change it later, run the builder again with a new `--zip`.

## What to add yourself
Open **www/suggested-files.html** on the drive (or the "Files to add yourself" button): manuals the builder cannot fetch,
guides to look up for your state and county, and your personal papers (private inbox, never indexed).
`REPORTS\\DRIVE-CHECKLIST.html` is a live to-do list rewritten on every build.

## Good to know
- Needs internet while building; nothing is needed afterwards. Downloads resume; run the builder again to repair anything missing.
- Some included guides are written for the Southeast US climate (planting calendar, plants, insects). Add your state's extension guides.
- It downloads from the original public sources (government sites, Internet Archive, Kiwix, Geofabrik, OpenStreetMap). Where a site blocks scripts it is
  listed in REPORTS\\NOT-FETCHED-*.txt instead of being bypassed.
- Built and tested by one person on Windows 10/11; treat it as a starting point and check your drive with START-HERE > Check the drive.
- Medical and survival information is for reference, not a substitute for training or professional care.
"""

BAT = '@echo off\r\ncd /d "%~dp0usb"\r\ncall BUILD-USB-WINDOWS.bat %*\r\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    ap.add_argument("--version", default="v81")
    a = ap.parse_args()
    out = a.out or os.path.join(os.path.dirname(REPO), f"offgrid-public-{a.version}.zip")
    tmp = tempfile.mkdtemp()
    stage = os.path.join(tmp, "offgrid-public")
    shutil.copytree(REPO, stage, ignore=lambda d, fs: [f for f in fs if f.endswith(SKIP) or f == "__pycache__"])
    for d in DROP_DIRS:
        shutil.rmtree(os.path.join(stage, d), ignore_errors=True)
    for f in DROP_FILES:
        try:
            os.remove(os.path.join(stage, f))
        except OSError:
            pass
    # manuals.tsv: remove the personal categories and the author's list comments
    tsv = os.path.join(stage, "library", "manuals.tsv")
    keep = []
    for ln in open(tsv, encoding="utf-8"):
        if ln.split("\t")[0] in DROP_CATS:
            continue
        keep.append(re.sub(r"From Josh's repository list", "From the author's repository list", ln))
    open(tsv, "w", encoding="utf-8", newline="").write("".join(keep))
    open(os.path.join(stage, "usb", "routes_data.py"), "w", encoding="utf-8").write(STUB_ROUTES)
    open(os.path.join(stage, "usb", "edition.json"), "w", encoding="utf-8").write('{"public": true, "version": "%s"}\n' % a.version)
    open(os.path.join(stage, "README.md"), "w", encoding="utf-8").write(README.format(v=a.version))
    open(os.path.join(stage, "BUILD-MY-DRIVE.bat"), "w", encoding="utf-8", newline="").write(BAT)
    shutil.copy2(os.path.join(stage, "usb", "suggested-files.html"), os.path.join(stage, "SUGGESTED-FILES.html"))
    # scrub the author's name from comments / docstrings in the code
    for dp, _, fs in os.walk(stage):
        for f in fs:
            if f.endswith((".py", ".ps1", ".sh", ".bat", ".html", ".md", ".txt", ".tsv", ".js")):
                p = os.path.join(dp, f)
                try:
                    t = open(p, encoding="utf-8").read()
                except (OSError, UnicodeDecodeError):
                    continue
                n = t.replace("What's the Fralick channel and its tone?", "What's the family channel and its tone?")
                n = re.sub(r"Josh's", "the author's", n)
                n = re.sub(r"\bJosh\b", "the author", n)
                if n != t:
                    open(p, "w", encoding="utf-8", newline="").write(n)
    # leak check
    bad = []
    for dp, _, fs in os.walk(stage):
        for f in fs:
            p = os.path.join(dp, f)
            try:
                t = open(p, encoding="utf-8").read()
            except (OSError, UnicodeDecodeError):
                continue
            for w in ("Fralick", "Creekshire", "jcfralick", r"\bJosh\b"):
                if re.search(w, t):
                    bad.append((os.path.relpath(p, stage), w))
    if os.path.exists(out):
        os.remove(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, _, fs in os.walk(stage):
            for f in fs:
                p = os.path.join(dp, f)
                z.write(p, os.path.join("offgrid-public", os.path.relpath(p, stage)))
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"{out}  ({os.path.getsize(out) / 1e6:.1f} MB)")
    if bad:
        print("PERSONAL TEXT STILL PRESENT:", bad[:20])
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
