#!/usr/bin/env python3
"""Feed the off-grid repository into Project NOMAD's AI Knowledge Base.

Builds plain-text versions of everything the AI should know about:
  * every original guide in the Library (HTML -> text)
  * the buy list, the UV-32 channel plan, the radio programming notes
  * the locator database: nearest hospitals, pharmacies, fuel, water, shelters, repeaters...
    (one file per category, sorted by distance from home)
  * downloaded manuals (PDF), joined Hesperian books
then uploads them to NOMAD (POST /api/rag/upload, 5 files per request, 100 MB max each).
Files already uploaded (same content) are skipped, so it is safe to re-run after updates.

  python3 nomad_sync.py --base /opt/offgrid                 # build + upload
  python3 nomad_sync.py --base /opt/offgrid --build-only    # just make /opt/offgrid/nomad_kb
  python3 nomad_sync.py --base /opt/offgrid --nomad http://192.168.1.50:8080
"""
import argparse, csv, glob, hashlib, html, html.parser, json, os, re, shutil, sys, urllib.request, uuid

MAX_BYTES = 100 * 1024 * 1024
PER_CAT_LIMIT = {"fuel": 400, "grocery": 400, "general": 300, "comm_tower": 300, "broadcast": 400, "water": 400}
CAT_RADIUS = 150  # miles of locator data put into the AI (the map itself still covers the full radius)


class TextOut(html.parser.HTMLParser):
    BLOCK = {"p", "div", "li", "tr", "h1", "h2", "h3", "h4", "table", "ul", "ol", "br", "section", "figure", "figcaption", "nav", "pre"}

    def __init__(self):
        super().__init__()
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "svg", "nav"):
            self.skip += 1
        elif tag in ("h1", "h2", "h3", "h4"):
            self.out.append("\n\n" + "#" * int(tag[1]) + " ")
        elif tag == "li":
            self.out.append("\n- ")
        elif tag in ("td", "th"):
            self.out.append(" | ")
        elif tag in self.BLOCK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "svg", "nav"):
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)

    def text(self):
        t = html.unescape("".join(self.out))
        t = re.sub(r"[ \t]+", " ", t)
        t = re.sub(r"\n[ |]*\n(\s*\n)+", "\n\n", t)
        return t.strip() + "\n"


def html_to_text(path):
    p = TextOut()
    p.feed(open(path, encoding="utf-8", errors="replace").read())
    return p.text()


def slug(s):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_")[:120]


def write(outdir, name, text):
    path = os.path.join(outdir, slug(name) + ".txt")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path


def build(base, outdir, home_label, include_pdfs=True):
    www = os.path.join(base, "www")
    lib = os.path.join(www, "library")
    if os.path.isdir(outdir):
        shutil.rmtree(outdir)
    os.makedirs(outdir)
    made = []

    # 1. original guides (any .html in the library except index pages and generated plans/lists handled below)
    for f in sorted(glob.glob(os.path.join(lib, "*", "*.html"))):
        name = os.path.basename(f)
        if name in ("index.html", "buy_list.html") or name.endswith("_Channel_Plan.html"):
            continue
        cat = os.path.basename(os.path.dirname(f))
        txt = html_to_text(f)
        title = txt.splitlines()[0][:100] if txt else name
        made.append(write(outdir, f"Guide - {cat} - {os.path.splitext(name)[0]}",
                          f"Off-grid repository guide ({cat}): {title}\nSource file: library/{cat}/{name}\n\n{txt}"))

    # 2. buy list (data lives in the page as a JS array)
    bl = os.path.join(lib, "Buy List", "buy_list.html")
    if os.path.exists(bl):
        src = open(bl, encoding="utf-8").read()
        m = re.search(r"const DATA = (\[.*?\n\]);", src, re.S)
        if m:
            try:
                rows = json.loads(m.group(1))
                pri = {1: "BUY NOW", 2: "NEXT", 3: "LATER"}
                lines = ["Preparedness buy list for the family (Canton, GA). Each item: priority, cost, quantity, why, and where to find it in a crisis.\n"]
                for r in rows:
                    lines.append(f"- [{r[0]}] {r[1]} — {pri.get(r[3], r[3])}; approx {r[4]}; quantity: {r[5]}. Why: {r[2]}. Where to find in a crisis: {r[6]}.")
                made.append(write(outdir, "Buy list - preparedness items and where to find them", "\n".join(lines) + "\n"))
            except ValueError as e:
                print(f"  ! buy list not parsed: {e}")

    # 3. radio channel plans (CSV)
    for f in glob.glob(os.path.join(lib, "*", "*Channels_Reference*.csv")):
        rows = list(csv.DictReader(open(f, encoding="utf-8-sig")))
        lines = [f"Radio channel plan from {os.path.basename(f)} ({len(rows)} channels). Columns: zone, channel number, name, frequency MHz, duplex/offset, tone, mode, power, notes.\n"]
        for r in rows:
            g = lambda k: (r.get(k) or "").strip()
            lines.append(f"Zone {g('Zone #')} {g('Zone Name')} | Ch {g('Channel #')} {g('Name')} | {g('Freq (MHz)')} MHz | {g('Duplex')} {g('Offset (MHz)')} | {g('Tone')} | {g('Mode')} {g('Power')} | {g('Technical / Official Name')}")
        made.append(write(outdir, "Radio - " + os.path.splitext(os.path.basename(f))[0], "\n".join(lines) + "\n"))
    for f in glob.glob(os.path.join(lib, "*", "*.md")):
        made.append(write(outdir, "Notes - " + os.path.splitext(os.path.basename(f))[0], open(f, encoding="utf-8", errors="replace").read()))

    # 4. locator database -> per-category nearest lists
    pois = os.path.join(www, "data", "pois.csv")
    if os.path.exists(pois):
        by = {}
        for r in csv.DictReader(open(pois, encoding="utf-8")):
            by.setdefault(r["category"], []).append(r)
        for cat, rows in sorted(by.items()):
            rows = sorted(rows, key=lambda r: float(r["miles"] or 9999))
            near = [r for r in rows if float(r["miles"] or 9999) <= CAT_RADIUS]
            key = slug(cat).lower()
            lim = next((v for k, v in PER_CAT_LIMIT.items() if k in key), 600)
            near = near[:lim]
            if not near:
                continue
            lines = [f"Locator: {cat} — the {len(near)} closest within {CAT_RADIUS} miles of home ({home_label}), "
                     f"sorted by straight-line distance. Directions are compass bearings FROM home. "
                     f"Total in the 500-mile database: {len(rows)}. For the full list open the locator map.\n"]
            for r in near:
                bits = [f"{r['name']}", f"{r['miles']} mi {r['dir']}"]
                for k in ("addr", "phone", "hours", "info"):
                    if r.get(k):
                        bits.append(r[k])
                bits.append(f"lat {r['lat']}, lon {r['lon']}")
                lines.append("- " + " — ".join(bits))
            made.append(write(outdir, f"Locator - {cat}", "\n".join(lines) + "\n"))

    # 5. PDFs: manuals and joined books (skip Hesperian single chapters when a COMPLETE file exists)
    for f in (sorted(glob.glob(os.path.join(lib, "*", "*.pdf"))) if include_pdfs else []):
        n = os.path.basename(f)
        pre = re.sub(r"_[^_]+\.pdf$", "", n)
        if not n.endswith("_COMPLETE.pdf") and os.path.exists(os.path.join(os.path.dirname(f), pre + "_COMPLETE.pdf")):
            continue
        if os.path.getsize(f) > MAX_BYTES:
            print(f"  - skipping {n} (over 100 MB)")
            continue
        dst = os.path.join(outdir, slug(os.path.basename(os.path.dirname(f)) + " - " + n))
        try:
            os.link(f, dst)
        except OSError:
            shutil.copy2(f, dst)
        made.append(dst)

    # 6. a short index so the AI knows what exists
    idx = ["This knowledge base contains the family's off-grid repository: original survival guides, the buy list, "
           "radio channel plans, nearby-places lists from the offline locator (hospitals, pharmacies, fuel, water, shelters, "
           "police/fire, repeaters, stores), and downloaded manuals. Files:\n"]
    idx += ["- " + os.path.basename(p) for p in made]
    made.append(write(outdir, "00 - Index of the off-grid knowledge base", "\n".join(idx) + "\n"))
    print(f"  Built {len(made)} knowledge files in {outdir}")
    return made


def sha(path):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def post_files(url, field, paths):
    boundary = "----offgrid" + uuid.uuid4().hex
    body = bytearray()
    for p in paths:
        ctype = "application/pdf" if p.lower().endswith(".pdf") else "text/plain"
        body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; filename=\"{os.path.basename(p)}\"\r\n"
                 f"Content-Type: {ctype}\r\n\r\n").encode()
        body += open(p, "rb").read() + b"\r\n"
    body += f"--{boundary}--\r\n".encode()
    req = urllib.request.Request(url, data=bytes(body), method="POST",
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=600) as r:
        return r.status, r.read(400).decode("utf-8", "replace")


def upload(nomad, paths, state_file):
    try:
        state = json.load(open(state_file))
    except (OSError, ValueError):
        state = {}
    todo = [p for p in paths if state.get(os.path.basename(p)) != sha(p)]
    if not todo:
        print("  NOMAD knowledge base already up to date.")
        return True
    url = nomad.rstrip("/") + "/api/rag/upload"
    field, ok, last = None, 0, None
    for cand in ("files", "file"):           # field name differs between NOMAD versions
        try:
            st, _ = post_files(url, cand, todo[:1])
            if 200 <= st < 300:
                field = cand
                state[os.path.basename(todo[0])] = sha(todo[0]); ok = 1
                break
        except Exception as e:                # noqa: BLE001 - report and try the next field name
            last = e
    if not field:
        print(f"  ! NOMAD upload API not reachable/compatible ({last}).")
        return False
    batch = 5 if field == "files" else 1
    rest = todo[1:]
    for i in range(0, len(rest), batch):
        chunk = rest[i:i + batch]
        try:
            st, msg = post_files(url, field, chunk)
            if 200 <= st < 300:
                for p in chunk:
                    state[os.path.basename(p)] = sha(p)
                ok += len(chunk)
            else:
                print(f"  ! upload returned {st}: {msg[:120]}")
        except Exception as e:                # noqa: BLE001
            print(f"  ! upload failed for {[os.path.basename(c) for c in chunk]}: {e}")
        json.dump(state, open(state_file, "w"), indent=0)
    json.dump(state, open(state_file, "w"), indent=0)
    print(f"  Uploaded {ok}/{len(todo)} files to NOMAD — embedding runs in the background (watch the Knowledge Base panel).")
    return ok > 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="/opt/offgrid")
    ap.add_argument("--nomad", default="http://127.0.0.1:8080")
    ap.add_argument("--label", default="ZIP 30115 (Canton, GA)")
    ap.add_argument("--build-only", action="store_true")
    a = ap.parse_args()
    out = os.path.join(a.base, "nomad_kb")
    paths = build(a.base, out, a.label)
    if a.build_only:
        return
    if not upload(a.nomad, paths, os.path.join(a.base, "nomad_kb_state.json")):
        print(f"  Upload these by hand instead: NOMAD → AI Chat → Knowledge Base → upload files from {out}")
        sys.exit(0)


if __name__ == "__main__":
    main()
