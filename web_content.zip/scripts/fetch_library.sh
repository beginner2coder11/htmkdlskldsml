#!/usr/bin/env bash
# Download every document listed in manuals.tsv into <lib-dir>/<Category>/ and rebuild the index.
# Usage: fetch_library.sh <manuals.tsv> <lib-dir> <python>
set -uo pipefail
TSV="$1"; LIB="$2"; PY="${3:-python3}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"
ok=0; skip=0; fail=0; failed=()

while IFS=$'\t' read -r cat title fname url; do
  [[ -z "${cat// }" || "$cat" == \#* || -z "${url:-}" ]] && continue
  dir="$LIB/$cat"; out="$dir/$fname"; mkdir -p "$dir"
  if [[ -s "$out" ]]; then skip=$((skip+1)); continue; fi
  [[ "$url" == "local" ]] && continue
  printf '  - %s\n' "$title"
  if [[ "$url" == archive:* ]]; then   # resolve an archive.org item to its first PDF
    id="${url#archive:}"
    f=$(curl -fsSL -m 60 "https://archive.org/metadata/$id" | "$PY" -c 'import json,sys
d=json.load(sys.stdin); fs=[x["name"] for x in d.get("files",[]) if x.get("name","").lower().endswith(".pdf")]
fs.sort(key=lambda n:("_text" in n, len(n))); print(fs[0] if fs else "")' 2>/dev/null)
    url="https://archive.org/download/$id/$f"
    [[ -z "$f" ]] && url="unresolved:$id"
  fi
  if curl -fsSL --retry 3 --retry-delay 5 -m 300 -A "$UA" -o "$out.part" "$url" \
     && head -c 5 "$out.part" | grep -q '%PDF'; then
    mv "$out.part" "$out"; ok=$((ok+1))
  else
    rm -f "$out.part"; fail=$((fail+1)); failed+=("$title  <$url>")
  fi
done < "$TSV"

# Join multi-part books (e.g. Hesperian chapters "wtnd_01.pdf"...) into one "<prefix>_COMPLETE.pdf"
if command -v pdfunite >/dev/null 2>&1; then
  awk -F'\t' '!/^#/ && $3 ~ /_[a-z0-9]+\.pdf$/ && $4 ~ /hesperian/ {print $1"\t"$3}' "$TSV" |
  awk -F'\t' '{p=$2; sub(/_[^_]+\.pdf$/,"",p); print $1"\t"p"\t"$2}' > /tmp/offgrid_parts.$$
  cut -f1,2 /tmp/offgrid_parts.$$ | sort -u | while IFS=$'\t' read -r c pre; do
    files=(); while IFS=$'\t' read -r c2 p2 f2; do
      [[ "$c2" == "$c" && "$p2" == "$pre" && -s "$LIB/$c/$f2" ]] && files+=("$LIB/$c/$f2"); done < /tmp/offgrid_parts.$$
    whole="$LIB/$c/${pre}_COMPLETE.pdf"
    if (( ${#files[@]} > 1 )) && { [[ ! -s "$whole" ]] || [[ -n "$(find "${files[@]}" -newer "$whole" 2>/dev/null)" ]]; }; then
      pdfunite "${files[@]}" "$whole" 2>/dev/null && echo "  Joined ${#files[@]} parts -> $(basename "$whole")"
    fi
  done
  rm -f /tmp/offgrid_parts.$$
fi

"$PY" "$HERE/build_library.py" --lib-dir "$LIB" --tsv "$TSV"
echo "  Downloaded: $ok   Already had: $skip   Failed: $fail"
if (( fail > 0 )); then
  printf '  Could not fetch (site moved or blocked — download by hand into the folder):\n'
  printf '    %s\n' "${failed[@]}"
  printf '%s\n' "${failed[@]}" > "$LIB/FAILED.txt"
fi
exit 0
