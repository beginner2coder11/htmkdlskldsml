"""Static audit of the builder repo: links between pages, Command Center tiles, manuals.tsv, copy lists, launchers.
    python scripts/audit_repo.py            (run from the repo root; prints problems, exit 1 if any)
Files made at build time (data/, topo/, tiles/ ...) are not checked."""
import glob
import os
import re
import sys
import urllib.parse

R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
U, L = os.path.join(R, "usb"), os.path.join(R, "library")
GEN = ("data/", "topo/", "tiles/", "map/", "guides/", "kiwix", "phone-apps", "platforms/", "search/", "media", "music", "docs.js", "docs-idx.js", "ask-brief.js", "config.js", "topics-data.js",
       "index.html", "library/index.html", "library/", "apps/", "notebook.html", "../", "http", "mailto:", "tel:", "javascript:", "data:", "#", "geo:", "sms:", "vendor/", "ai/", "find-map.html", "ham-calls.html", "programs.html", "openwith.html", "manual.html", "weather.html", "mymaps/", "catalog.js")
problems = []


def bad(msg):
    problems.append(msg)


def refs(text):
    for m in re.finditer(r'(?:href|src)\s*=\s*["\']([^"\']+)["\']', text):
        yield m.group(1)


www_files = {os.path.basename(f) for f in glob.glob(os.path.join(U, "*.html"))} | {"coords.js", "wmm.js", "scen-data.js", "quick-data.js", "instant.js"}
for page in sorted(glob.glob(os.path.join(U, "*.html"))):
    t = open(page, encoding="utf-8", errors="replace").read()
    for r in refs(t):
        r0 = urllib.parse.unquote(r.split("#")[0].split("?")[0])
        if not r0 or r0.startswith(GEN):
            continue
        if r0.startswith("library/"):
            if not os.path.exists(os.path.join(R, r0)) and not r0.endswith((".pdf", "/")):
                bad(f"{os.path.basename(page)}: missing {r}")
        elif "/" not in r0 and r0.endswith((".html", ".js")) and r0 not in www_files:
            bad(f"{os.path.basename(page)}: missing page {r}")
# command.html tiles
t = open(os.path.join(U, "command.html"), encoding="utf-8").read()
for m in re.finditer(r'^\["(\w+)","([^"]+)","([^"]*)","([^"]+)"', t, re.M):
    p = urllib.parse.unquote(m.group(4).split("#")[0])
    if p.startswith(GEN) or p in ("KIWIX",):
        continue
    if p.startswith("library/"):
        if not os.path.exists(os.path.join(R, p)) and not p.endswith(".pdf"):
            bad(f"command.html tile '{m.group(2)}': missing {p}")
    elif p not in www_files and not os.path.exists(os.path.join(U, p)):
        bad(f"command.html tile '{m.group(2)}': missing {p}")
# library pages: links to sibling library pages
for page in glob.glob(os.path.join(L, "**", "*.html"), recursive=True):
    t = open(page, encoding="utf-8", errors="replace").read()
    for r in refs(t):
        r0 = urllib.parse.unquote(r.split("#")[0].split("?")[0])
        if not r0 or r0.startswith(("http", "#", "mailto:", "tel:", "javascript:", "data:", "..", "/")) or r0.endswith((".pdf", "/")):
            continue
        if not os.path.exists(os.path.join(os.path.dirname(page), r0)):
            bad(f"{os.path.relpath(page, R)}: missing {r}")
# manuals.tsv
seen, cats = {}, {}
lib_rows = set()
for i, line in enumerate(open(os.path.join(L, "manuals.tsv"), encoding="utf-8"), 1):
    if not line.strip() or line.startswith("#"):
        continue
    c = line.rstrip("\n").split("\t")
    if len(c) < 3:
        bad(f"manuals.tsv line {i}: fewer than 3 columns"); continue
    cats[c[0]] = cats.get(c[0], 0) + 1
    key = tuple(c[:4])
    if key in seen:
        bad(f"manuals.tsv line {i}: exact duplicate of line {seen[key]} ({c[2]})")
    seen[key] = i
    src = c[3] if len(c) >= 4 else ""
    if src and src != "local" and not src.startswith(("http://", "https://", "archive:")):
        bad(f"manuals.tsv line {i}: unknown source '{src[:30]}' ({c[2]})")
    if src == "local" or not src:
        lib_rows.add((c[0], c[2]))
        if c[2].endswith(".html") and not os.path.exists(os.path.join(L, c[0], c[2])):
            bad(f"manuals.tsv line {i}: original page {c[0]}/{c[2]} not in library/")
    if c[0] == "":
        bad(f"manuals.tsv line {i}: empty category")
for f in glob.glob(os.path.join(L, "*", "*.html")):
    if (os.path.basename(os.path.dirname(f)), os.path.basename(f)) not in lib_rows:
        bad(f"library page not listed in manuals.tsv: {os.path.relpath(f, R)}")
# builder copy list
b = open(os.path.join(U, "usb_builder.py"), encoding="utf-8").read()
m = re.search(r'for f in \("home\.html".*?\):', b)
listed = set(re.findall(r'"([\w\-]+\.(?:html|js))"', m.group(0))) if m else set()
for f in sorted(www_files):
    if f.endswith(".html") and f not in listed and f not in ("media.html", "music.html", "OPEN-ME-NO-INSTALL.html", "SEARCH-EVERYTHING.html", "WHATS-HAPPENING.html"):
        bad(f"usb/{f} is not in the builder's page copy list")
# python compile and launchers
for f in glob.glob(os.path.join(U, "*.py")) + glob.glob(os.path.join(R, "scripts", "*.py")):
    try:
        compile(open(f, encoding='utf-8-sig').read(), f, 'exec')
    except SyntaxError as e:
        bad(f"python error: {e}")
for f in glob.glob(os.path.join(U, "*.bat")):
    d = open(f, "rb").read()
    if b"\r\n" not in d:
        bad(f"{os.path.basename(f)}: not CRLF")
    for ps in re.findall(r"([A-Za-z_][\w\-]*\.ps1)", d.decode("utf-8", "replace").replace("%~dp0", "")):
        if not os.path.exists(os.path.join(U, ps)):
            bad(f"{os.path.basename(f)}: calls missing {ps}")
print(f"{len(cats)} library categories, {sum(cats.values())} rows; {len(www_files)} pages")
for p in problems:
    print("PROBLEM:", p)
print("OK" if not problems else f"{len(problems)} problem(s)")
sys.exit(1 if problems else 0)
