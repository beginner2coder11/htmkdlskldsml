#!/usr/bin/env bash
# offgrid-backup: copy the off-grid repository, Project NOMAD content and AI models to an external drive.
# Usage:  sudo offgrid-backup /media/$USER/MYDRIVE [--full]
#   --full  also copies the raw OpenStreetMap downloads (6-8 GB, only needed to rebuild the locator)
# Re-running only copies what changed. Keep the drive in a Faraday can between backups.
set -uo pipefail
DEST="${1:-}"; FULL=0; [[ "${2:-}" == "--full" ]] && FULL=1
if [[ -z "$DEST" || ! -d "$DEST" ]]; then
  echo "Usage: sudo offgrid-backup /path/to/mounted/drive [--full]"
  echo "Mounted drives:"; lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT | grep -E "/media|/mnt" || echo "  (none found — plug in a drive)"
  exit 1
fi
[[ $EUID -eq 0 ]] || { echo "Run with sudo"; exit 1; }
command -v rsync >/dev/null || apt-get install -y rsync || { echo "rsync is required (sudo apt install rsync)"; exit 1; }
OUT="$DEST/offgrid-backup"; mkdir -p "$OUT"

SRC=(/opt/offgrid)
[[ -d /opt/project-nomad ]] && SRC+=(/opt/project-nomad)
for m in /usr/share/ollama/.ollama /var/lib/ollama /root/.ollama "/home/${SUDO_USER:-nobody}/.ollama"; do
  [[ -d "$m" ]] && SRC+=("$m")
done
EXC=(--exclude 'osm/raw/*.part' --exclude '*.part')
[[ $FULL -eq 0 ]] && EXC+=(--exclude 'osm/raw/')

need=$(du -sc "${SRC[@]}" 2>/dev/null | tail -1 | awk '{print $1}')
have=$(df -k --output=avail "$DEST" | tail -1)
echo "Backing up: ${SRC[*]}"
echo "Size ~$((need/1024/1024)) GB, free on drive ~$((have/1024/1024)) GB (only changes are copied after the first run)"

# Docker data for NOMAD services is under /opt/project-nomad/storage; stop nothing, rsync copies a live snapshot.
for s in "${SRC[@]}"; do
  echo "==> $s"
  rsync -aH --delete-after --info=progress2 "${EXC[@]}" "$s" "$OUT/" || echo "  ! some files in $s could not be copied"
done

# Save package list and the installer's .deb cache description
dpkg --get-selections > "$OUT/installed-packages.txt" 2>/dev/null
cp /etc/os-release "$OUT/os-release.txt" 2>/dev/null
lsblk -o NAME,SIZE,MODEL,FSTYPE,MOUNTPOINT > "$OUT/disks.txt" 2>/dev/null

cat > "$OUT/RESTORE.txt" <<EOF
OFF-GRID BACKUP — made $(date '+%Y-%m-%d %H:%M') on $(hostname)

WHAT'S HERE
  offgrid/          the whole repository: locator, map, library, guides, scripts, saved installers (www/library/Software)
                    and offline .deb packages (software/debs)
  project-nomad/    Project NOMAD (compose files + storage: Wikipedia/ZIMs, maps, Kolibri, knowledge base)
  .ollama/          AI models (if present)
  installed-packages.txt, os-release.txt, disks.txt

QUICK USE WITH NO INSTALL
  Open offgrid/www/library/index.html or offgrid/www/index.html in any browser (the map needs the
  locator service for street tiles, but the search list, guides and PDFs open directly).

RESTORE ON A FRESH UBUNTU (same version: $(. /etc/os-release; echo "$PRETTY_NAME"))
  1. sudo rsync -aH offgrid/ /opt/offgrid/
  2. Offline packages:  sudo apt install /opt/offgrid/software/debs/*.deb   (ignore already-installed errors)
  3. Start the locator + library with no internet:
       python3 /opt/offgrid/scripts/serve.py --dir /opt/offgrid/www --port 8090   → http://localhost:8090
     Repair archives: kiwix-serve --port 8091 /opt/offgrid/zim/*.zim
     With internet, a full reinstall recreates the services:  sudo bash /opt/offgrid/install.sh
  4. NOMAD: install Docker, then sudo rsync -aH project-nomad/ /opt/project-nomad/ and run
     cd /opt/project-nomad && sudo docker compose up -d   (or reinstall NOMAD and copy storage/ back)
  5. AI models: copy .ollama back to where it came from (usually /usr/share/ollama/.ollama),
     sudo chown -R ollama:ollama /usr/share/ollama/.ollama, then sudo systemctl restart ollama
  6. sudo offgrid-ai-sync   to reload the knowledge base if needed

Refresh this backup at least every few months and power the drive once a year.
EOF
sync
echo "Backup complete: $OUT   (see RESTORE.txt). Unmount before unplugging: sudo umount \"$DEST\""
