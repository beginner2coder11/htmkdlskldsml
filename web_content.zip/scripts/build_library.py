#!/usr/bin/env python3
"""Build the offline Library page (www/library/index.html) from manuals.tsv plus any PDFs
dropped into www/library/<Category>/ by hand."""
import argparse, html, os, time, urllib.parse


def read_tsv(path):
    known = {}
    if not os.path.exists(path):
        return known
    for line in open(path, encoding="utf-8"):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 4:
            cat, title, fname, url = parts[:4]
            known[(cat, fname)] = (title, url)
    return known


FORMATS = {".epub": "EPUB e-book copy", ".txt": "plain-text copy (searchable)", ".docx": "Word copy (searchable)",
           ".doc": "Word copy", ".pdf": "second PDF copy", ".htm": "web-page copy", ".html": "web-page copy", ".rtf": "text copy"}


def alt_title(known, cat, f):
    """'vita_handbook2.epub' beside the known 'vita_handbook.pdf' -> '<known title> — EPUB e-book copy'."""
    stem, ext = os.path.splitext(f)
    base = stem.rstrip("0123456789").rstrip("_- ")
    for (c, kf), (t, _) in known.items():
        if c == cat and os.path.splitext(kf)[0] == base and kf != f:
            return f"{t} — {FORMATS.get(ext.lower(), ext.lstrip('.').upper() + ' copy')}"
    return None


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib-dir", required=True)
    ap.add_argument("--tsv", required=True)
    a = ap.parse_args()
    known = read_tsv(a.tsv)
    known.update(read_tsv(os.path.join(os.path.dirname(os.path.abspath(a.tsv)), "software_titles.tsv")))

    cats = {}
    for cat in sorted(os.listdir(a.lib_dir)):
        d = os.path.join(a.lib_dir, cat)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if f.startswith(".") or f.endswith(".part"):
                continue
            p = os.path.join(d, f)
            if not os.path.isfile(p):
                continue
            title, url = known.get((cat, f), (None, ""))
            if title is None:
                title = alt_title(known, cat, f) or os.path.splitext(f)[0].replace("_", " ")
            cats.setdefault(cat, []).append((title, f, os.path.getsize(p), url))

    total = sum(len(v) for v in cats.values())
    out = [f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Off-Grid Library</title>
<style>
body{{margin:0;font:15px/1.45 system-ui,sans-serif;background:#14171a;color:#e6e8eb}}
header{{padding:14px 16px;border-bottom:1px solid #2c323a;display:flex;gap:14px;align-items:baseline;flex-wrap:wrap}}
h1{{font-size:18px;margin:0;letter-spacing:.5px}} a{{color:#d9a441}} .dim{{color:#9aa3ad;font-size:13px}}
input{{font:inherit;color:#e6e8eb;background:#0f1214;border:1px solid #2c323a;border-radius:6px;padding:7px 10px;width:min(420px,90%)}}
main{{padding:8px 16px 40px}} h2{{font-size:15px;color:#d9a441;margin:22px 0 6px;text-transform:uppercase;letter-spacing:.6px}}
li{{padding:6px 0;border-bottom:1px solid #2c323a;list-style:none}} ul{{padding:0;margin:0}} details ul{{padding-left:18px}} summary{{cursor:pointer}}
</style></head><body>
<header><h1>OFF-GRID LIBRARY</h1><span class="dim">{total} documents · built {time.strftime('%Y-%m-%d')}</span>
<a href="../">← Locator</a></header>
<main><input id="q" type="search" placeholder="Filter manuals…">"""]
    if not cats:
        out.append("<p class='dim'>No documents yet. Run the installer while online, or drop PDFs into the library folders.</p>")
    for cat, items in cats.items():
        out.append(f"<h2>{html.escape(cat)}</h2><ul>")
        # books split into many parts ("Title — chapter 3") collapse into one expandable entry
        groups = {}
        for it in items:
            if " — " in it[0]:
                groups.setdefault(it[0].split(" — ")[0], []).append(it)
        big = {k for k, v in groups.items() if len(v) >= 4}
        done = set()

        def li(title, f, size):
            href = urllib.parse.quote(cat) + "/" + urllib.parse.quote(f)
            return f"<li><a href='{href}'>{html.escape(title)}</a> <span class='dim'>· {human(size)}</span></li>"
        for title, f, size, url in items:
            key = title.split(" — ")[0] if " — " in title else None
            if key in big:
                if key in done:
                    continue
                done.add(key)
                parts = groups[key]
                out.append(f"<li><details><summary>{html.escape(key)} <span class='dim'>· {len(parts)} parts</span></summary><ul>"
                           + "".join(li(t.split(' — ', 1)[1], ff, sz) for t, ff, sz, _ in parts) + "</ul></details></li>")
            else:
                out.append(li(title, f, size))
        out.append("</ul>")
    out.append("""</main><script>
document.getElementById('q').addEventListener('input',e=>{const q=e.target.value.toLowerCase();
document.querySelectorAll('li').forEach(li=>li.style.display=li.textContent.toLowerCase().includes(q)?'':'none');});
</script></body></html>""")
    with open(os.path.join(a.lib_dir, "index.html"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    print(f"  Library index: {total} documents in {len(cats)} categories")


if __name__ == "__main__":
    main()
