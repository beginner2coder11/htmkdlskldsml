package com.afriquia.freinszemamra;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CheckNotificationReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        MainActivity.notifyUpcomingChecks(context, true);
    }
}
