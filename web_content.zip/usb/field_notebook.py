"""OFFGRID Field Notebook: the drive's guides, situations and logs as ONE TiddlyWiki file.

TiddlyWiki is a notebook that is a single .html file holding its own notes. With a small app per device it SAVES in place,
which a plain browser page cannot do:  Windows/Mac/Linux = TiddlyDesktop,  Android = Tiddloid,  iPhone = Quine 2.

This builds, from this drive's own contents:
    FIELD-NOTEBOOK.html          at the drive root (links like  www/library/...)
    www\\notebook.html            the same notebook for the drive's web server / Command Center
and copies the Tiddloid app (and its Tiddloid Tweaks plugin, already inside the notebook) next to the other phone apps.

The notebook contains: Home, Situations (the first steps for each, with tick boxes), Checklists and logs (rally points,
radio log, supplies, daily log), Library (every guide and manual, by section, as links), Tools and pages.
Your own notes are saved inside the file. Rebuilding makes a NEW file, so copy your notebook somewhere safe first
(the builder never overwrites a notebook you have changed: it writes FIELD-NOTEBOOK-NEW.html instead).

    python field_notebook.py --dest E:\\OFFGRID
"""
import argparse
import hashlib
import html
import json
import os
import re
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
BASE = os.path.join(HERE, "data", "field-notebook-base.html")
BASE_GZ = BASE + ".gz"      # shipped compressed: antivirus scanners sometimes lock a big TiddlyWiki .html while a zip extracts


def _base_text():
    import gzip
    if os.path.isfile(BASE_GZ):
        return gzip.open(BASE_GZ, "rt", encoding="utf-8").read()
    return open(BASE, encoding="utf-8").read()
STORE = re.compile(r'(<script class="tiddlywiki-tiddler-store" type="application/json">)(.*?)(</script>)', re.S)
DROP = {"$:/status/RequireReloadDueToPluginChange", "$:/StoryList", "$:/config/Navigation/openLinkFromInsideRiver"}
DOC_EXT = (".pdf", ".epub", ".htm", ".html", ".txt", ".docx")
MARK = "<!-- offgrid-notebook-built:"


def _stamp():
    return time.strftime("%Y%m%d%H%M%S") + "000"


def _tid(title, text, tags="", caption="", **extra):
    t = {"title": title, "text": text, "created": _stamp(), "modified": _stamp()}
    if tags:
        t["tags"] = tags
    if caption:
        t["caption"] = caption
    t.update(extra)
    return t


def _clean(s):
    return re.sub(r"\s+", " ", str(s).replace("|", "-").replace("[", "(").replace("]", ")")).strip()


def _url(rel):
    return "/".join(p.replace(" ", "%20").replace("#", "%23") for p in rel.split("/"))


def _scenarios():
    try:
        import survival_guide
        return survival_guide.SCENARIOS
    except Exception:  # noqa: BLE001
        return []


def _library(dest):
    """{category: [(title, relative path under www/)]} from the files really on the drive."""
    root = os.path.join(dest, "www", "library")
    out = {}
    if os.path.isdir(root):
        for cat in sorted(os.listdir(root)):
            cp = os.path.join(root, cat)
            if not os.path.isdir(cp):
                continue
            items = []
            for f in sorted(os.listdir(cp)):
                if f.lower().endswith(DOC_EXT):
                    items.append((_clean(os.path.splitext(f)[0]), f"library/{cat}/{f}"))
            if items:
                out[cat] = items
    return out


def tiddlers(dest, www):
    tids = []
    sc = _scenarios()
    links = []
    for s in sc:
        label = _clean(s["label"])
        title = "Situation: " + label.split("(")[0].strip()
        steps = ""
        for i, step in enumerate(s["now"], 1):
            steps += (f'<$checkbox tiddler="{title}" field="s{i}" checked="yes" unchecked="no" default="no"> {step}</$checkbox>\n\n')
        guide = ""
        if os.path.exists(os.path.join(dest, "www", "guides", s["key"] + ".html")):
            guide = f'<a href="{www}guides/{s["key"]}.html" target="_blank">Open the full printable guide for this situation</a>\n\n'
        text = (f"//{label}//\n\n!! Do this now\n\n{steps}"
                + ("!! Read next\n\n" + guide if guide else "")
                + ("!! Notes\n\n//Write what you did and saw here.//\n"))
        tids.append(_tid(title, text, tags="Situation"))
        links.append(title)
    tids.append(_tid("Situations", "Pick what is happening. Each page has the first steps with tick boxes (they stay ticked).\n\n<<list-links \"[tag[Situation]sort[title]]\">>\n", caption="Situations"))
    lib = _library(dest)
    cats = []
    for cat, items in lib.items():
        body = "".join(f'* <a href="{html.escape(www + _url(p), quote=True)}" target="_blank">{html.escape(t)}</a>\n' for t, p in items)
        tids.append(_tid("Library: " + cat, f"{len(items)} files. Open from the drive.\n\n" + body, tags="Library"))
        cats.append(cat)
    total = sum(len(v) for v in lib.values())
    tids.append(_tid("Library", (f"{total:,} guides and manuals on this drive, by section. Use the search box in the sidebar to find a title.\n\n"
                                 '<<list-links "[tag[Library]sort[title]]">>\n') if cats else
                     "The library is not on this drive yet. Run the drive builder, then rebuild the notebook.\n", caption="Library"))
    tids.append(_tid("$:/DefaultTiddlers", "[[Home]]"))
    # Tiddloid toolbar buttons (Android only; ignored elsewhere). Untested on a real phone: opens the drive's server page
    # in the phone's browser, which only works when the drive is running (Termux) - otherwise the page will not load.
    actions = [{"name": "Command Center", "action": "window.open('http://localhost:8090/command.html','_blank')"},
               {"name": "Search", "action": "window.open('http://localhost:8090/search.html','_blank')"}]
    tids.append(_tid("$:/config/Tiddloid/CustomActions.json", json.dumps(actions, indent=2), type="application/json"))
    return tids


def build_one(dest, out_path, www, root, tids):
    base = _base_text()
    m = STORE.search(base)
    if not m:
        raise RuntimeError("notebook base file has no tiddler store")
    arr = [t for t in json.loads(m.group(2)) if t.get("title") not in DROP]
    have = {t["title"]: i for i, t in enumerate(arr)}
    extra = [dict(t) for t in tids] + [_tid("$:/config/offgrid/www", www), _tid("$:/config/offgrid/root", root)]
    for t in extra:
        if t["title"] in have:
            arr[have[t["title"]]] = t
        else:
            arr.append(t)
    blob = json.dumps(arr, separators=(",", ":"), ensure_ascii=False).replace("<", "\\u003c")
    html_out = base[:m.start()] + m.group(1) + blob + m.group(3) + base[m.end():]
    # never overwrite a notebook the user has been writing in: only replace a file that is still exactly what we wrote last time
    state_p = os.path.join(dest, "tools", "field-notebook-state.json")
    try:
        state = json.load(open(state_p, encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    key = os.path.relpath(out_path, dest).replace("\\", "/")
    target = out_path
    if os.path.exists(out_path):
        cur = hashlib.sha1(open(out_path, "rb").read()).hexdigest()
        if state.get(key) != cur:
            target = out_path.replace(".html", "-NEW.html")
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(target, "w", encoding="utf-8", newline="") as fh:
        fh.write(html_out)
    if target == out_path:
        state[key] = hashlib.sha1(open(out_path, "rb").read()).hexdigest()
        os.makedirs(os.path.dirname(state_p), exist_ok=True)
        with open(state_p, "w", encoding="utf-8") as fh:
            json.dump(state, fh)
    return target


def build(u, dest):
    if not (os.path.isfile(BASE) or os.path.isfile(BASE_GZ)):
        print("  ! Field Notebook: base file missing from the builder (usb/data/field-notebook-base.html.gz)")
        return
    tids = tiddlers(dest, "www/")
    a = build_one(dest, os.path.join(dest, "FIELD-NOTEBOOK.html"), "www/", "", tids)
    b = build_one(dest, os.path.join(dest, "www", "notebook.html"), "", "../", tiddlers(dest, ""))
    # the Tiddloid app (GPL-2.0) next to the other phone apps and in the Android pack
    apps = os.path.join(HERE, "apps")
    n = 0
    if os.path.isdir(apps):
        for f in os.listdir(apps):
            if f.lower().endswith(".apk"):
                for d in (os.path.join(dest, "www", "phone-apps", "android"), os.path.join(dest, "PLATFORMS", "ANDROID", "apk")):
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, f)
                    if not (os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(os.path.join(apps, f))):
                        try:
                            shutil.copyfile(os.path.join(apps, f), dst)
                        except OSError as e:
                            print(f"  ! could not copy {f}: {e}")
                n += 1
    lic = os.path.join(dest, "SOFTWARE", "TiddlyWiki")
    os.makedirs(lic, exist_ok=True)
    print(f"  Field Notebook: {os.path.basename(a)} + www\\notebook.html ({sum(1 for t in tids if t.get('tags') == 'Situation')} situations, "
          f"{sum(1 for t in tids if t.get('tags') == 'Library')} library sections); {n} Tiddloid app copied")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    build(None, os.path.abspath(a.dest))


if __name__ == "__main__":
    main()
