#!/bin/sh
# ===== OFF-GRID SURVIVAL DRIVE on an Android phone or tablet (Termux) =====
# One-time: install Termux (from this drive: Phone apps > Termux), open it, run  termux-setup-storage  and allow access.
# Then each time:  sh /storage/XXXX-XXXX/OFFGRID/PROGRAMS/start-android-termux.sh
#   (XXXX-XXXX = the SD card or USB drive; type  ls /storage  to see it. Tip: Termux's Tab key completes names.)
cd "$(dirname "$0")/.." || exit 1
ROOT=$(pwd)
[ -f www/home.html ] || { echo "This doesn't look like the OFFGRID folder ($ROOT)."; exit 1; }
echo "OFF-GRID SURVIVAL DRIVE — Android ($ROOT)"
PY=python; command -v python >/dev/null 2>&1 || PY=python3
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "Python isn't installed in Termux yet (one time, needs internet):"
  printf "Install it now? [Y/n] "; read -r A
  case "$A" in n|N) echo "Without Python, use the apps (Kiwix, OsmAnd, VLC) and the TEXT-ONLY folder."; exit 1 ;; esac
  pkg install -y python || exit 1
  PY=python
fi
RAM=$(awk '/MemTotal/ {print int($2/1048576)}' /proc/meminfo 2>/dev/null)
AIBIN=$(command -v llama-server 2>/dev/null)
if [ -z "$AIBIN" ] && [ -d ai/models ]; then
  printf "Add the offline AI too? (one-time download of the llama.cpp package, needs internet) [y/N] "; read -r A
  case "$A" in y|Y) pkg install -y llama-cpp && AIBIN=$(command -v llama-server 2>/dev/null) ;; esac
fi
termux-wake-lock 2>/dev/null
if [ -n "$AIBIN" ]; then
  M=$(cat ai/default-model.txt 2>/dev/null)
  if [ "${RAM:-0}" -lt 11 ] || [ ! -f "ai/models/$M" ]; then        # under ~12 GB RAM: the small 3B model
    S=$(ls ai/models/Llama-3.2-3B*.gguf 2>/dev/null | head -1); [ -n "$S" ] && M=$(basename "$S")
  fi
  if [ -f "ai/models/$M" ]; then
    echo "Starting the AI ($M, ${RAM:-?} GB RAM) — the first answer takes a minute..."
    "$AIBIN" -m "ai/models/$M" --host 127.0.0.1 --port 8080 -c 4096 >"${TMPDIR:-/tmp}/offgrid-ai.log" 2>&1 &
  fi
fi
ARGS="--dir www --port 8090 --bind 0.0.0.0 --models ai/models --roles ai/roles.json"
[ -n "$AIBIN" ] && ARGS="$ARGS --ai-bin $AIBIN"
"$PY" tools/serve_usb.py $ARGS >"${TMPDIR:-/tmp}/offgrid-web.log" 2>&1 &
sleep 2
URL=http://localhost:8090/command.html
termux-open-url "$URL" 2>/dev/null || am start -a android.intent.action.VIEW -d "$URL" >/dev/null 2>&1 || echo "Open $URL in Chrome."
IP=$(ip -4 addr show wlan0 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1)
[ -n "$IP" ] && echo "Other phones on the same Wi-Fi / hotspot: http://$IP:8090/command.html"
echo "Wikipedia & the other archives: open them in the Kiwix app (Phone apps). Maps: OsmAnd. Movies/music: VLC."
printf "\nRunning. Leave Termux open (pull down the notification to keep it awake). Press Enter to stop. "
read -r X
kill $(jobs -p) 2>/dev/null; termux-wake-unlock 2>/dev/null
