"""Ask Claude over any working internet connection — satellite, shelter Wi-Fi, a phone hotspot — in a plain text window.

Text-only Claude API calls are tiny (a few KB each way), so this works on links too slow or flaky for a web browser.
Needs: internet, and an Anthropic API key (console.anthropic.com > API keys). Standard library only.

  python ask_claude.py                       chat (asks for the key, never saves it)
  python ask_claude.py "how do I purge air from a diesel fuel line"
  set ANTHROPIC_API_KEY=sk-ant-...           (Windows)  /  export ANTHROPIC_API_KEY=...  (Mac/Linux) to skip the prompt
  python ask_claude.py --key-file V:\\keys\\anthropic.txt   read it from your mounted VeraCrypt vault

Commands while chatting:  /new  start over   /long  allow longer answers   /model sonnet|haiku|opus   /save  write chat to a file   /q  quit
Answers can be wrong; for medical, electrical or legal decisions check the drive's guides and a professional when you can.
"""
import argparse, getpass, json, os, socket, sys, time, urllib.error, urllib.request

API = "https://api.anthropic.com/v1/messages"
MODELS = {"haiku": "claude-haiku-5-5", "sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5"}
SYSTEM = ("The user may be in an emergency or grid-down situation on a slow, expensive or intermittent connection "
          "(satellite, shelter Wi-Fi, phone hotspot). Answer in plain text without markdown tables, lead with what to do, "
          "keep it short unless asked for detail, and say clearly when something needs a doctor, emergency services or an expert. "
          "They have an offline survival drive with guides, manuals, maps and an offline AI; suggest what to look up there when useful.")


def ask(key, model, messages, max_tokens, timeout=90, retries=3):
    body = json.dumps({"model": model, "max_tokens": max_tokens, "system": SYSTEM, "messages": messages}).encode()
    req = urllib.request.Request(API, data=body, headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                                          "content-type": "application/json"})
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read())
            text = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text")
            u = d.get("usage", {})
            return text.strip(), u.get("input_tokens", 0), u.get("output_tokens", 0)
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:300]
            if e.code in (401, 403):
                raise SystemExit("  ! The API key was refused. Check it at console.anthropic.com (API keys, billing).")
            if e.code == 404 and "model" in msg:
                raise SystemExit(f"  ! Model {model} not found — try /model sonnet, or update the drive (newer model names).")
            if e.code in (429, 500, 502, 503, 529) and attempt < retries - 1:
                print(f"  (busy, retrying in {10 * (attempt + 1)} s...)"); time.sleep(10 * (attempt + 1)); continue
            raise SystemExit(f"  ! API error {e.code}: {msg}")
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError) as e:
            if attempt < retries - 1:
                print(f"  (no connection: {getattr(e, 'reason', e)} — retrying in {15 * (attempt + 1)} s...)"); time.sleep(15 * (attempt + 1)); continue
            raise SystemExit("  ! Couldn't reach Claude. Check the internet connection (open any website), then try again.")


def get_key(a):
    k = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not k and a.key_file:
        try:
            k = open(a.key_file, encoding="utf-8").read().strip().split()[0]
        except (OSError, IndexError):
            print(f"  ! couldn't read {a.key_file}")
    if not k:
        print("  Paste your Anthropic API key (it won't show and isn't saved). Get one at console.anthropic.com.")
        k = getpass.getpass("  API key: ").strip()
    if not k.startswith("sk-"):
        print("  (that doesn't look like an API key — they start with sk-ant-)")
    return k


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("question", nargs="*")
    ap.add_argument("--model", default="haiku", help="haiku (fast, cheapest), sonnet (best all-round) or opus (hardest problems), or a full model id")
    ap.add_argument("--max-tokens", type=int, default=700, help="answer length limit (about 0.75 words each)")
    ap.add_argument("--key-file", help="text file with the API key (keep it in your encrypted vault)")
    a = ap.parse_args()
    model = MODELS.get(a.model, a.model)
    key = get_key(a)
    msgs, used_in, used_out, log = [], 0, 0, []
    print(f"\n  ASK CLAUDE ONLINE — model {model}. Short text only, to save bandwidth. /q quits, /new starts over.\n")
    first = " ".join(a.question).strip()
    while True:
        q = first or input("You> ").strip()
        first = ""
        if not q:
            continue
        cmd = q.lower()
        if cmd in ("/q", "/quit", "q", "exit"):
            break
        if cmd == "/new":
            msgs = []; print("  (new conversation)"); continue
        if cmd == "/long":
            a.max_tokens = 2000; print("  (longer answers allowed)"); continue
        if cmd.startswith("/model"):
            m = cmd.split()[-1]; model = MODELS.get(m, m); print(f"  (model: {model})"); continue
        if cmd == "/save":
            fn = time.strftime("claude-chat-%Y%m%d-%H%M.txt")
            with open(fn, "w", encoding="utf-8") as fh:
                fh.write("\n\n".join(log) + "\n")
            print(f"  (saved to {os.path.abspath(fn)})"); continue
        msgs.append({"role": "user", "content": q})
        t0 = time.time()
        text, ti, to = ask(key, model, msgs[-20:], a.max_tokens)
        used_in += ti; used_out += to
        msgs.append({"role": "assistant", "content": text})
        log += [f"You: {q}", f"Claude: {text}"]
        print("\nClaude> " + text + f"\n\n  ({time.time() - t0:.0f} s, ~{(len(json.dumps(msgs)) + len(text)) / 1024:.0f} KB sent+received)\n")
        if a.question:
            break
    if used_in:
        print(f"  Tokens this session: {used_in:,} in / {used_out:,} out.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print()
