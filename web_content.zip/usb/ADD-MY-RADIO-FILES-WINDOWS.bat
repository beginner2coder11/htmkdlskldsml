@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Add your own radio files (CHIRP images, CPS files, manuals, programming software, phone apps) =====
REM 1) Put the files (folders are fine) in MY-RADIO-INBOX in this OFFGRID folder.
REM    From Google Drive: open the folder, click its name > Download, then Extract All into MY-RADIO-INBOX.
REM 2) Run this. No internet needed. Every CHIRP .img becomes a readable channel list in the Library.
cd /d "%~dp0"
title Add my radio files
if not exist "MY-RADIO-INBOX" mkdir "MY-RADIO-INBOX"
set PYTHONUTF8=1
tools\python-win\python.exe tools\builder\usb\usb_builder.py --dest "%~dp0." --my-radio-only
echo.
echo  Open Home ^> Library ^> My Radio Programming. Channel lists end in "- channel list".
pause
