"""Meaning-based search ("find by meaning") for the whole drive - offline.

Every page in the full-text index (every manual page, OCR'd scan, guide section) gets a small "meaning vector" from
Google's EmbeddingGemma 300M model, run by the drive's own llama.cpp. A question is turned into a vector the same way and
the closest pages are found, so "stop bleeding from a leg wound" finds "tourniquet application" even with no shared words.
The Ask page and the search pages mix these results with the normal word search.

Build (resumable, any number of runs; documents already done are skipped, re-done only when their text changed):
    python semantic.py --dest E:\\OFFGRID [--hours 3]
Files:  ai/models/embeddinggemma-300M-Q8_0.gguf   (334 MB)
        www/search/vec/docs/<key>.bin              per document: page numbers + 256 int8 numbers per page
        www/search/vec/all.i8, rows.bin, keys.json packed index; ivf.* = coarse clusters for computers without numpy
"""
import array, glob, json, math, os, re, struct, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
MODEL_URL = "https://huggingface.co/ggml-org/embeddinggemma-300M-GGUF/resolve/main/embeddinggemma-300M-Q8_0.gguf"
MODEL = "embeddinggemma-300M-Q8_0.gguf"
DIM = 256                      # EmbeddingGemma is trained so the first 256 of its 768 numbers still work (Matryoshka)
PORT = 8094
QUERY = "task: search result | query: "
MIN_TEXT = 80                  # pages with less text than this are skipped (covers, blank pages)
CHARS = 1500                   # first part of each page is enough to capture what it is about
BATCH = 32
NCLUSTER = 1024


# ---------------------------------------------------------------- helpers
def _np(dest=None):
    """numpy if it can be loaded (from tools/pylib on the drive, fetched at build time); None otherwise."""
    for d in ([os.path.join(dest, "tools", "pylib", "numpy-" + _plat())] if dest else []):
        if os.path.isdir(d) and d not in sys.path:
            sys.path.insert(0, d)
    try:
        import numpy
        return numpy
    except Exception:  # noqa: BLE001
        return None


def _plat():
    import platform
    m = platform.machine().lower()
    if os.name == "nt":
        return "win_amd64"
    if sys.platform == "darwin":
        return "macosx_arm64" if m in ("arm64", "aarch64") else "macosx_x86_64"
    return "linux_aarch64" if m in ("arm64", "aarch64") else "linux_x86_64"


def get_numpy(u, dest):
    """Fetch the numpy wheel for this Python into tools/pylib/numpy-<platform> (once). Needed to build the index."""
    np = _np(dest)
    if np:
        return np
    tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
    want = {"win_amd64": "win_amd64", "macosx_arm64": "macosx_.*arm64", "macosx_x86_64": "macosx_.*x86_64",
            "linux_x86_64": "manylinux.*x86_64", "linux_aarch64": "manylinux.*aarch64"}[_plat()]
    try:
        meta = json.loads(u.fetch("https://pypi.org/pypi/numpy/json", 60))
        f = next(x for x in meta["urls"] if re.search(rf"-{tag}-{tag}-{want}\.whl$", x["filename"]))
        lib = os.path.join(dest, "tools", "pylib")
        whl = os.path.join(lib, f["filename"])
        if u.download(f["url"], whl, "numpy (for meaning search)"):
            import zipfile
            zipfile.ZipFile(whl).extractall(os.path.join(lib, "numpy-" + _plat()))
            os.remove(whl)
    except Exception as e:  # noqa: BLE001
        print(f"  ! could not get numpy for this Python ({tag}): {e}")
    return _np(dest)


def llama_bin(dest):
    sub = {"win_amd64": ["win", "win-gpu"], "macosx_arm64": ["macos-arm64"], "macosx_x86_64": ["macos-x64"],
           "linux_x86_64": ["linux", "linux-gpu"], "linux_aarch64": []}[_plat()]
    exe = "llama-server.exe" if os.name == "nt" else "llama-server"
    for s in sub:
        for p in glob.glob(os.path.join(dest, "ai", "bin", s, "**", exe), recursive=True):
            return p
    return None


def server_cmd(binp, model, port=PORT):
    threads = max(1, (os.cpu_count() or 2) - 1)       # all cores but one: the computer stays usable
    return [binp, "-m", model, "--embeddings", "--host", "127.0.0.1", "--port", str(port), "-t", str(threads),
            "-c", "8192", "-b", "8192", "-ub", "2048", "--parallel", "4"]    # 4 pages at a time, 2048 tokens each


def _post(port, texts, timeout=300):
    req = urllib.request.Request(f"http://127.0.0.1:{port}/v1/embeddings", data=json.dumps({"input": texts}).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return [d["embedding"] for d in sorted(json.load(r)["data"], key=lambda d: d["index"])]


def _healthy(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=3) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def quantize(v):
    """First 256 numbers, re-normalised, as int8 (-127..127). 256 bytes per page."""
    v = v[:DIM]
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return array.array("b", (max(-127, min(127, int(round(127 * x / n)))) for x in v))


def doc_text(title, txt):
    body = re.sub(r"\s+", " ", txt)[:CHARS]
    return "title: " + title + " | text: " + body


# ---------------------------------------------------------------- build
def _keep_awake(on=True):
    """Windows: stop the computer sleeping while the index is built (the screen may still turn off)."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001 if on else 0x80000000)
        except Exception:  # noqa: BLE001
            pass


def build(u, dest, hours=3.0):
    """hours = 0 means no time limit (overnight run)."""
    u.say("Meaning-based search (EmbeddingGemma) - finds pages by what they mean, not just their words")
    sd = os.path.join(dest, "www", "search")
    if not os.path.exists(os.path.join(sd, "docs.js")):
        print("  (the full-text index is not built yet - this runs after it, next time)")
        return
    model = os.path.join(dest, "ai", "models", MODEL)
    if not os.path.exists(model) and not u.download(MODEL_URL, model, "EmbeddingGemma 300M (meaning search model)"):
        print("  ! could not download the meaning-search model - word search still works; retried next run")
        return
    binp = llama_bin(dest)
    if not binp:
        print("  ! no llama.cpp server for this computer on the drive (the Offline AI step installs it) - skipped")
        return
    np = get_numpy(u, dest)
    from search_cli import Index
    ix = Index(dest)
    vdir = os.path.join(sd, "vec", "docs")
    os.makedirs(vdir, exist_ok=True)
    todo = []
    for d in ix.docs:
        key = d[6]
        tp, vp = os.path.join(sd, "text", key + ".js"), os.path.join(vdir, key + ".bin")
        if not os.path.exists(tp):
            continue
        if os.path.exists(vp) and os.path.getmtime(vp) >= os.path.getmtime(tp):
            continue                                       # done, and its text has not changed since (OCR adds text -> redo)
        todo.append(d)
    todo.sort(key=lambda d: d[1].startswith("zim.html"))    # manuals and guides first, archive articles after
    keys_now = {d[6] for d in ix.docs}
    for p in glob.glob(os.path.join(vdir, "*.bin")):      # documents no longer in the library
        if os.path.splitext(os.path.basename(p))[0] not in keys_now:
            os.remove(p)
    if todo:
        print(f"  {len(todo):,} documents to read for meaning ({len(ix.docs) - len(todo):,} already done); "
              + (f"up to {hours:g} h this run, resumable" if hours else "until finished (resumable)"), flush=True)
        _keep_awake(True)
        log = open(os.path.join(dest, "REPORTS", "meaning-server.log"), "ab")
        proc = subprocess.Popen(server_cmd(binp, model), stdout=log, stderr=log,
                                creationflags=(0x08000000 | 0x00004000) if os.name == "nt" else 0)
        try:
            for _ in range(180):
                if _healthy(PORT) or proc.poll() is not None:
                    break
                time.sleep(1)
            if not _healthy(PORT):
                print("  ! the meaning model would not start (see REPORTS\\meaning-server.log) - skipped this run")
                return
            t0, pages, ndoc = time.time(), 0, 0
            for d in todo:
                if hours and time.time() - t0 > hours * 3600:
                    print(f"\n  time limit reached - {len(todo) - ndoc:,} documents continue next run")
                    break
                key = d[6]
                try:
                    ix.page_text(d, d[3])
                    txts = ix.texts.get(key) or []
                except Exception:  # noqa: BLE001
                    txts = []
                items = [(i, doc_text(d[0], t)) for i, t in enumerate(txts or []) if len((t or "").strip()) >= MIN_TEXT]
                out = bytearray()
                ok = True
                for b in range(0, len(items), BATCH):
                    chunk = items[b:b + BATCH]
                    try:
                        vecs = _post(PORT, [t for _, t in chunk])
                    except Exception as e:  # noqa: BLE001
                        print(f"\n  ! {d[0][:50]}: {e}")
                        ok = False
                        break
                    for (i, _), v in zip(chunk, vecs):
                        out += struct.pack("<H", min(i, 65535)) + quantize(v).tobytes()
                    if len(items) > 150:            # a big manual: show progress inside it, so it never looks stuck
                        el = max(1, time.time() - t0)
                        print(f"\r  meaning: {ndoc:,}/{len(todo):,} documents - now {d[0][:40]}: page {b + len(chunk):,}/{len(items):,} "
                              f"({(pages + b + len(chunk)) * 60 / el:,.0f} pages/min)   ", end="", flush=True)
                if not ok:
                    if proc.poll() is not None:
                        print("  ! the meaning model stopped - finished documents are kept")
                        break
                    continue
                tmp = os.path.join(vdir, key + ".tmp")
                open(tmp, "wb").write(bytes(out))
                os.replace(tmp, os.path.join(vdir, key + ".bin"))
                ndoc += 1
                pages += len(items)
                if ndoc % 10 == 0:
                    el = max(1, time.time() - t0)
                    left = (len(todo) - ndoc) * el / ndoc / 3600       # by documents done so far
                    print(f"\r  meaning: {ndoc:,}/{len(todo):,} documents, {pages:,} pages ({pages * 60 / el:,.0f} pages/min, "
                          f"about {left:.1f} h left)   ", end="", flush=True)
            print()
        finally:
            _keep_awake(False)
            proc.terminate()
            try:
                proc.wait(20)
            except Exception:  # noqa: BLE001
                proc.kill()
    pack(dest, np)


def pack(dest, np=None):
    """Join the per-document vectors into one index (+ clusters for computers without numpy)."""
    sd = os.path.join(dest, "www", "search")
    vd = os.path.join(sd, "vec")
    keys, rows, vecs = [], array.array("i"), bytearray()
    rec = 2 + DIM
    for p in sorted(glob.glob(os.path.join(vd, "docs", "*.bin"))):
        b = open(p, "rb").read()
        if not b:
            continue
        k = len(keys)
        keys.append(os.path.splitext(os.path.basename(p))[0])
        for o in range(0, len(b) - rec + 1, rec):
            rows.append(k * 65536 + struct.unpack_from("<H", b, o)[0])
            vecs += b[o + 2:o + rec]
    n = len(rows)
    if not n:
        return
    open(os.path.join(vd, "all.i8.tmp"), "wb").write(bytes(vecs))
    open(os.path.join(vd, "rows.bin.tmp"), "wb").write(rows.tobytes())
    json.dump(keys, open(os.path.join(vd, "keys.json.tmp"), "w"))
    for f in ("all.i8", "rows.bin", "keys.json"):
        os.replace(os.path.join(vd, f + ".tmp"), os.path.join(vd, f))
    if np is not None and n > 4 * NCLUSTER:               # coarse clusters so a computer WITHOUT numpy can still search fast
        X = np.frombuffer(bytes(vecs), dtype=np.int8).reshape(n, DIM).astype(np.float32)
        rng = np.random.default_rng(1)
        C = X[rng.choice(n, NCLUSTER, replace=False)].copy()
        S = X[rng.choice(n, min(n, 60000), replace=False)]
        for _ in range(8):
            a = np.argmax(S @ C.T, axis=1)
            for c in range(NCLUSTER):
                m = S[a == c]
                if len(m):
                    C[c] = m.mean(0)
            C /= np.linalg.norm(C, axis=1, keepdims=True) + 1e-9
        assign = np.concatenate([np.argmax(X[i:i + 50000] @ C.T, axis=1) for i in range(0, n, 50000)])
        order = np.argsort(assign, kind="stable").astype(np.int32)
        counts = np.bincount(assign, minlength=NCLUSTER).astype(np.int32)
        (np.round(C * 127).clip(-127, 127).astype(np.int8)).tofile(os.path.join(vd, "ivf_c.i8"))
        order.tofile(os.path.join(vd, "ivf_rows.bin"))
        counts.tofile(os.path.join(vd, "ivf_n.bin"))
    print(f"  meaning index: {n:,} pages from {len(keys):,} documents ({len(vecs) / 1e6:.0f} MB)")


# ---------------------------------------------------------------- search (used by the drive's server)
class Searcher:
    def __init__(self, dest):
        self.vd = os.path.join(dest, "www", "search", "vec")
        self.keys = json.load(open(os.path.join(self.vd, "keys.json")))
        self.rows = array.array("i")
        self.rows.frombytes(open(os.path.join(self.vd, "rows.bin"), "rb").read())
        self.np = _np(dest)
        raw = open(os.path.join(self.vd, "all.i8"), "rb").read()
        self.n = len(self.rows)
        if self.np is not None:
            self.X = self.np.frombuffer(raw, dtype=self.np.int8).reshape(self.n, DIM)
        else:
            self.raw = raw
            try:
                self.C = open(os.path.join(self.vd, "ivf_c.i8"), "rb").read()
                o = array.array("i")
                o.frombytes(open(os.path.join(self.vd, "ivf_rows.bin"), "rb").read())
                c = array.array("i")
                c.frombytes(open(os.path.join(self.vd, "ivf_n.bin"), "rb").read())
                self.order, self.starts = o, [0]
                for x in c:
                    self.starts.append(self.starts[-1] + x)
            except OSError:
                self.C = None

    def top(self, qv, k=10):
        """qv: query vector (list of floats). -> [(score, doc_key, page_index)]"""
        q = quantize(qv)
        if self.np is not None:
            s = self.X.astype(self.np.int32) @ self.np.frombuffer(q.tobytes(), dtype=self.np.int8).astype(self.np.int32) \
                if self.n < 200000 else self._np_chunks(q)
            idx = self.np.argpartition(-s, min(k, self.n - 1))[:k]
            best = sorted(((int(s[i]), int(i)) for i in idx), reverse=True)
        else:
            qa = list(q)
            if self.C:
                cs = sorted(range(len(self.starts) - 1), key=lambda c: -sum(
                    a * b for a, b in zip(qa, struct.unpack_from(f"{DIM}b", self.C, c * DIM))))[:8]
                cand = [self.order[j] for c in cs for j in range(self.starts[c], self.starts[c + 1])]
            else:
                cand = range(min(self.n, 20000))
            best = sorted(((sum(a * b for a, b in zip(qa, struct.unpack_from(f"{DIM}b", self.raw, i * DIM))), i)
                           for i in cand), reverse=True)[:k]
        return [(sc / (127 * 127), self.keys[self.rows[i] // 65536], self.rows[i] % 65536) for sc, i in best]

    def _np_chunks(self, q):
        np = self.np
        qq = np.frombuffer(q.tobytes(), dtype=np.int8).astype(np.int32)
        return np.concatenate([self.X[i:i + 100000].astype(np.int32) @ qq for i in range(0, self.n, 100000)])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--hours", type=float, default=3.0, help="time limit for this run; 0 = until finished")
    a = ap.parse_args()
    import usb_builder
    build(usb_builder, a.dest, a.hours)
