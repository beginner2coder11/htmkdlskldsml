@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Search the whole drive in a plain command window - no web browser, no server, no internet =====
REM Same index as the Search page: every guide, every page of every PDF manual, every e-book.
REM If even Python won't run on this computer, it falls back to Windows' own FINDSTR on the TEXT-ONLY folder.
cd /d "%~dp0"
title Search the drive (no browser)
chcp 65001 >nul
set PYTHONUTF8=1
set "PY=tools\python-win\python.exe"
if exist "%PY%" goto run
py -3 -c "import sys" >nul 2>nul && (set "PY=py -3" & goto run)
python -c "import sys" >nul 2>nul && (set "PY=python" & goto run)
goto plain

:run
%PY% tools\builder\usb\search_cli.py --dest "%~dp0." %*
if not errorlevel 1 goto end

:plain
echo.
echo  Using Windows' built-in text search on the TEXT-ONLY folder (plain-text copies of everything).
:again
echo.
set "Q="
set /p "Q=Search words (Enter alone to quit): "
if not defined Q goto end
echo.
echo  Files that contain "%Q%":
findstr /s /i /m /c:"%Q%" "TEXT-ONLY\*.txt"
echo.
echo  To read one:  notepad "TEXT-ONLY\<folder>\<file>.txt"   (then Ctrl+F to jump to the words)
set "N="
set /p "N=Paste a file path from the list to open it in Notepad (or Enter to search again): "
if defined N start "" notepad "%N%"
goto again

:end
pause
