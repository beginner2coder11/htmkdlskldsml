﻿#!/usr/bin/env python3
"""Build a portable OFF-GRID SURVIVAL USB drive - works from Windows, macOS or Linux.

What ends up on the drive (folder OFFGRID on the USB):
  * HOME page with everything linked; START-WINDOWS.bat and start-mac-linux.sh launchers
  * Offline AI: llama.cpp server (Windows, macOS, Linux builds) + GGUF models, with a built-in chat page
    and an "Ask the Library" page that answers from your own guides (search + AI)
  * All original guides, buy list, UV-32 channel plan, sky calculators, the downloaded manuals library
  * The locator: nearest hospitals, pharmacies, fuel, water, shelters, police/fire, stores... (from
    OpenStreetMap via the Overpass API, or copied from the NOMAD machine) + optional offline street map
  * Kiwix archives (medicine, water, food, post-disaster, WikEM, iFixit, Stack Exchange, full Wikipedia,
    Gutenberg, Khan Academy, Wikibooks) with portable kiwix-serve
  * Photo (Gemma 3 vision) and medical (MedGemma) models, Whisper voice input
  * USGS topo GeoPDFs + topo/hillshade map layers + FEMA flood zones (extras.py)
  * Phone apps (OsmAnd, Organic Maps, Kiwix, Meshtastic, ATAK-CIV) + OsmAnd maps, VeraCrypt

Build order (main() runs these top-to-bottom; each step is resumable, skipped by its own --no-* flag,
and wrapped by step() so a failure doesn't stop the rest). The giant downloads are deliberately LAST,
so a build that stops early still leaves a usable drive:
  manuals -> ask-index -> AI models -> military bases -> [pages] -> Kiwix ZIMs -> voice -> street map
  -> terrain/topo/south map-tile layers -> flood zones -> phone apps -> VeraCrypt -> VLC/Sumatra
  -> TOPO GeoPDFs around home -> e-books -> [pages] -> LARGE archives (full Wikipedia, Khan, etc.)
  -> TOPO GeoPDFs for bases/cities/lakes/routes -> [pages].
  NOTE: because the two topo-GeoPDF steps fall after the ~345 GB of archives, a run interrupted during
  the archives never reaches them. ADD-TOPO-MAPS-WINDOWS.bat runs just the topo steps on their own.
  Scanned (picture-only) PDFs are OCR'd right after e-books so their text lands in the search index; it
  is resumable and capped per run (ADD-OCR-WINDOWS.bat runs just that, --no-ocr skips it).

Only uses the Python standard library. On Windows run BUILD-USB-WINDOWS.bat instead of this file -
it fetches a portable Python onto the USB and runs this script with it.

  python usb_builder.py --dest E:\\OFFGRID
  python usb_builder.py --dest /media/me/USB/OFFGRID --models small --no-map
"""
import sys as _sys
_sys.dont_write_bytecode = True      # no __pycache__ folders to tidy up on the drive
import argparse, datetime, glob, io, json, math, os, platform, re, shutil, ssl, subprocess, sys, tarfile, time, urllib.error, urllib.parse, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(REPO, "scripts"))
import build_pois  # noqa: E402  (classify / make_row / write_outputs; osmium not needed)
import nomad_sync   # noqa: E402  (HTML -> text and knowledge files)
sys.path.insert(0, HERE)
import extras       # noqa: E402  (topo maps, map tiles, flood zones, phone apps, vault, voice, big archives)
import search_index # noqa: E402  (full-text search of guides + every PDF page, no AI needed)
import areas        # noqa: E402  (Southern cities, lakes/coast, DoD installation boundaries)
import mymaps       # noqa: E402  (your own MIMs / KML / GPX from MY-MAPS-INBOX)
import media        # noqa: E402  (movies & TV catalog)
import music        # noqa: E402  (music catalog + player)
import radio_img    # noqa: E402  (MY-RADIO-INBOX, CHIRP image -> channel list)
import region       # noqa: E402  (ZIP code -> home, nearby states, regional map area)
import routes_data  # noqa: E402  (get-home routes from work-travel cities back to Canton)
import canada_topo  # noqa: E402  (NRCan 1:50k topo for the Canadian destinations: Toronto, Québec City)
import semantic     # noqa: E402  (meaning-based search, EmbeddingGemma)
import fas_doddir   # noqa: E402  (irp.fas.org/doddir - skips anything already on the drive)
import army_pubs
import kml_fix  # noqa: E402
import kml_export  # noqa: E402
import cities_data  # noqa: E402
import imagery      # noqa: E402  (Eastern US + Canada satellite imagery in MBTiles, phone files)
import map_sheets   # noqa: E402  (printable satellite map PDFs)
import fema_data    # noqa: E402  (FEMA shelters, recovery centers, disaster declarations)
import ienc         # noqa: E402  (USACE river charts for Google Earth)
import xlsx_export  # noqa: E402
import caves  # noqa: E402
import hospitals_data  # noqa: E402
import meds_data  # noqa: E402
import hospitals_hifld  # noqa: E402
import regional_pois  # noqa: E402
import tidy  # noqa: E402
import state_maps
import reading_list
import openwith
import android_pack  # noqa: E402
import platforms  # noqa: E402
import library_extras  # noqa: E402
import field_notebook  # noqa: E402
import joint_doctrine  # noqa: E402
import almanacs
import weather  # noqa: E402  (US Army + Marine Corps publications)
import languages  # noqa: E402  (Spanish/French/sign-language books + gun-manual collection from archive.org)
import fetch_new  # noqa: E402  (monthly: find newer public-domain survival/preparedness manuals online)
import pbf_convert  # noqa: E402  (convert dropped-in OpenStreetMap .pbf extracts into offline map layers)
import offline_software  # noqa: E402  (Windows installers kept on the drive)
import topo_search   # noqa: E402  (find any map on the drive by coordinates)
import more_data    # noqa: E402  (Kolibri, Geofabrik regional maps, FCC ham call signs)
import ocr          # noqa: E402  (OCR scanned PDFs so picture-only manuals become full-text searchable)
import manual        # noqa: E402  (the drive's own instruction manual: how to use it, what not to delete)
import library_inbox  # noqa: E402  (MY-FILES-INBOX -> Library)
import personal_files  # noqa: E402  (MY-PERSONAL-FILES-INBOX -> PERSONAL, private)
import drive_checklist  # noqa: E402  (REPORTS\DRIVE-CHECKLIST)
import launcher     # noqa: E402  (START-HERE menu, PROGRAMS / REPORTS folders)

UA = "OffGridSurvivalUSB/1.2 (personal emergency-preparedness map builder)"
UPDATE = False        # set by --update: replace older versions with newer ones
CHANGES = []          # files newly downloaded this run (for the update summary)


def age_days(path):
    try:
        return (time.time() - os.path.getmtime(path)) / 86400
    except OSError:
        return 1e9


def installed(outdir, want, asset_name):
    """True if a program is installed and (in update mode) is the newest release."""
    if not os.path.exists(os.path.join(outdir, want)):
        return False
    if not UPDATE:
        return True
    try:
        return open(os.path.join(outdir, "VERSION.txt")).read().strip() == asset_name
    except OSError:
        return False


def mark_installed(outdir, asset_name):
    try:
        with open(os.path.join(outdir, "VERSION.txt"), "w") as fh:
            fh.write(asset_name + "\n")
    except OSError:
        pass


def remote_size(url):
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            return int(r.headers.get("Content-Length") or 0)
    except Exception:  # noqa: BLE001
        return 0


def zim_resume_if_short(url, path):
    """v80: an archive smaller than the server's copy is an unfinished download (libzim: 'bad size or corrupted').
    Turn it back into a .part so download() resumes it from where it stopped instead of keeping a broken file."""
    if not os.path.exists(path):
        return
    want, have = remote_size(url), os.path.getsize(path)
    if want and have < want:
        print(f"  {os.path.basename(path)} is unfinished ({have / 1e9:.1f} of {want / 1e9:.1f} GB) - resuming the download")
        part = path + ".part"
        if os.path.exists(part):
            os.remove(part)
        os.replace(path, part)
    elif want and have > want:
        print(f"  ! {os.path.basename(path)} is larger than the server's copy - downloading it again")
        os.remove(path)


def prune_versions(folder, keep):
    """Delete older dated versions (name_YYYY-MM.zim) of the same archive after a newer one arrived."""
    stem = re.sub(r"_\d{4}-\d{2}\.zim$", "", keep)
    for old in glob.glob(os.path.join(folder, stem + "_*.zim")):
        if os.path.basename(old) != keep and re.fullmatch(re.escape(stem) + r"_\d{4}-\d{2}\.zim", os.path.basename(old)):
            print(f"  removing older {os.path.basename(old)}")
            os.remove(old)
RERANK_URL = "https://huggingface.co/gpustack/bge-reranker-v2-m3-GGUF/resolve/main/bge-reranker-v2-m3-Q4_K_M.gguf"
MODELS = {   # name: (url, approx GB, description[, vision projector url])
    "small":  ("https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf", 2.0,
               "Llama 3.2 3B - fast on any laptop with 8 GB RAM"),
    "medium": ("https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf", 4.7,
               "Qwen 2.5 7B - smarter; wants 16 GB RAM"),
    "large":  ("https://huggingface.co/bartowski/Qwen2.5-14B-Instruct-GGUF/resolve/main/Qwen2.5-14B-Instruct-Q4_K_M.gguf", 9.0,
               "Qwen 2.5 14B - best answers; used automatically on computers with 32 GB+ RAM"),
    "vision": ("https://huggingface.co/ggml-org/gemma-3-4b-it-GGUF/resolve/main/gemma-3-4b-it-Q4_K_M.gguf", 3.3,
               "Gemma 3 4B vision - identify plants, mushrooms, parts, wounds from a photo",
               "https://huggingface.co/ggml-org/gemma-3-4b-it-GGUF/resolve/main/mmproj-model-f16.gguf"),
    "medical": ("https://huggingface.co/unsloth/medgemma-4b-it-GGUF/resolve/main/medgemma-4b-it-Q4_K_M.gguf", 3.3,
                "MedGemma 4B - Google's medical model (text + medical photos)",
                "https://huggingface.co/unsloth/medgemma-4b-it-GGUF/resolve/main/mmproj-F16.gguf"),
}
ZIMS = [  # (folder, prefix) on download.kiwix.org/zim/
    ("other", "zimgit-medicine_en"), ("other", "zimgit-water_en"), ("other", "zimgit-food-preparation_en"),
    ("other", "zimgit-post-disaster_en"), ("other", "mdwiki_en_all_maxi"),
    ("other", "appropedia_en_all_maxi"), ("ifixit", "ifixit_en_all"),
    # Stack Exchange: real people answering practical questions
    ("stack_exchange", "diy.stackexchange.com_en_all"), ("stack_exchange", "gardening.stackexchange.com_en_all"),
    ("stack_exchange", "outdoors.stackexchange.com_en_all"), ("stack_exchange", "ham.stackexchange.com_en_all"),
    ("stack_exchange", "electronics.stackexchange.com_en_all"), ("stack_exchange", "cooking.stackexchange.com_en_all"),
    ("stack_exchange", "mechanics.stackexchange.com_en_all"), ("stack_exchange", "woodworking.stackexchange.com_en_all"),
    ("stack_exchange", "sustainability.stackexchange.com_en_all"), ("stack_exchange", "bicycles.stackexchange.com_en_all"),
    # Reference, kids and school (names missing from the server are just reported and skipped)
    ("vikidia", "vikidia_en_all_maxi"), ("phet", "phet_en_all"),
    ("wikisource", "wikisource_en_all_maxi"), ("wikivoyage", "wikivoyage_en_all_maxi"),
    ("libretexts", "libretexts.org_en_med"), ("libretexts", "libretexts.org_en_bio"), ("libretexts", "libretexts.org_en_chem"),
    ("other", "zimgit-knots_en"),
    # Spanish & French: dictionaries, textbooks, encyclopedia (small "mini"/"nopic" builds)
    ("wiktionary", "wiktionary_es_all_nopic"), ("wiktionary", "wiktionary_fr_all_nopic"),
    ("wikibooks", "wikibooks_es_all_maxi"), ("wikibooks", "wikibooks_fr_all_maxi"),
    ("wikipedia", "wikipedia_es_all_mini"), ("wikipedia", "wikipedia_fr_all_mini"),
    ("vikidia", "vikidia_es_all_maxi"), ("vikidia", "vikidia_fr_all_maxi"),
]
# families whose archives share one site name: never "fall back" to a different (possibly 100 GB) archive of theirs
NO_FALLBACK = {"wikipedia", "wiktionary", "wikisource", "wikivoyage", "wikibooks", "vikidia", "phet", "libretexts.org", "gutenberg"}
OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter", "https://overpass.openstreetmap.fr/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"]
QUERIES = {  # Overpass filters per group (around: filter is added automatically)
    "medical": ['[amenity~"^(hospital|clinic|doctors|pharmacy)$"]', '[healthcare~"^(hospital|clinic|doctor|centre|urgent_care|pharmacy)$"]'],
    "health_more": ['[shop~"^(herbalist|health_food|nutrition_supplements)$"]', '[healthcare~"^(alternative|laboratory|blood_donation|dialysis)$"]',
                    '[amenity=research_institute]', '[office=research]',
                    '[office=government][name~"health|disease|CDC|epidemiolog|laboratory",i]', '[name~"Centers for Disease Control",i]'],
    "food": ['[shop~"^(supermarket|grocery|greengrocer|wholesale|food)$"]', '[amenity~"^(food_bank|soup_kitchen|food_sharing)$"]', '[social_facility~"^(food_bank|soup_kitchen|shelter)$"]'],
    "safety": ['[amenity~"^(police|fire_station)$"]', '[emergency~"^(ambulance_station|assembly_point)$"]'],
    "fuel_water_shelter": ['[amenity~"^(fuel|drinking_water|water_point|community_centre|refugee_site)$"]', '[shop~"^(gas|fuel)$"]', '[natural=spring]', '[man_made=water_well]'],
    "stores": ['[shop~"^(hardware|doityourself|farm|agrarian|trade|garden_centre|outdoor|sports|fishing|camping|car_parts|tyres|department_store|variety_store|general|discount|weapons|guns|hunting|caravan|boat|golf)$"]', '[amenity=veterinary]', '[leisure=marina]'],
    "more": ['[shop~"^(pawnbroker|pawn|army_surplus|military_surplus|surplus|convenience)$"]', '[amenity~"^(restaurant|fast_food)$"]', '[natural=cave_entrance]'],
    "comms_military_power": ['[man_made=communications_tower]', '[man_made~"^(mast|tower)$"]["tower:type"~"^(communication|radio|broadcast)$"]',
                             '["communication:amateur_radio:repeater"]', '[amenity=studio]', '[office~"^(newspaper|radio|television|military)$"]',
                             '[military]', '[landuse=military][name]', '[power=plant]'],
}
# Along the get-home routes, fetch just the resupply essentials around each key spot (keeps the query count sane)
ROUTE_POI_GROUPS = ["medical", "food", "safety", "fuel_water_shelter", "stores", "more"]
ROUTE_POI_RADIUS = 20
ROUTE_POI_BUDGET_SEC = 2700  # ~45 min of route resources per run; whatever is left is fetched next run (finished spots are cached)
HOME_POI_BUDGET_SEC = 1200   # same idea for the home locator (a bit more room since it's the primary data)


# ---------------------------------------------------------------------------- helpers
def say(msg):
    print(f"\n==> {msg}", flush=True)


def fetch(url, timeout=120, data=None, headers=None):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": UA, "Accept": "*/*", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


LAST_ERR = [""]       # why the last download() failed: "403", "404", "cert", "net" ... (for the manuals' memory)


def download(url, dest, label=None, retries=3):
    """Resumable download with a progress line. Returns True on success (LAST_ERR says why not)."""
    LAST_ERR[0] = ""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return True
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    sp = urllib.parse.urlsplit(url)        # spaces or other unsafe characters in a link: encode them
    url = urllib.parse.urlunsplit(sp._replace(path=urllib.parse.quote(sp.path, safe="/%:@!$&'()*+,;=~-._"),
                                              query=urllib.parse.quote(sp.query, safe="=&%+:/?,;@!$'()*~-._")))
    attempt, best = 0, -1
    while attempt < retries:
        attempt += 1
        if os.path.exists(part) and os.path.getsize(part) > best:   # a try that made progress doesn't count against the retries
            if best >= 0:
                attempt = 1
            best = os.path.getsize(part)
        try:
            have = os.path.getsize(part) if os.path.exists(part) else 0
            hdr = {"User-Agent": UA}
            if have:
                hdr["Range"] = f"bytes={have}-"
            req = urllib.request.Request(url, headers=hdr)
            with urllib.request.urlopen(req, timeout=120) as r:
                if have and r.status != 206:
                    have = 0
                total = int(r.headers.get("Content-Length") or 0) + have
                mode = "ab" if have else "wb"
                with open(part, mode) as fh:
                    got, t0 = have, time.time()
                    while True:
                        b = r.read(1 << 20)
                        if not b:
                            break
                        fh.write(b); got += len(b)
                        if total:
                            sz = (f"{got / 1e9:.2f}/{total / 1e9:.2f} GB" if total >= 1e9 else f"{got / 1e6:.0f}/{total / 1e6:.0f} MB")
                            print(f"\r  {label or os.path.basename(dest)}: {sz} ({100 * got / total:.0f}%)   ", end="", flush=True)
                    if total:
                        print()             # end the progress line (nothing printed when the size was unknown: no blank line)
            if total and got < total:       # v80: the server closed early - keep the .part and resume, never rename a short file
                raise OSError(f"connection closed at {got / 1e9:.2f} of {total / 1e9:.2f} GB")
            os.replace(part, dest)
            CHANGES.append(os.path.basename(dest))
            return True
        except urllib.error.HTTPError as e:
            print(f"\n  ! {label or url}: {e}")
            LAST_ERR[0] = str(e.code)
            if e.code in (401, 403, 404, 410):      # gone or blocked - retrying won't help
                return False
            time.sleep(5 * attempt)
            continue
        except (urllib.error.URLError, OSError) as e:
            print(f"\n  ! {label or url}: {e} (attempt {attempt}/{retries})")
            LAST_ERR[0] = "cert" if "CERTIFICATE_VERIFY_FAILED" in str(e) else "net"
            if "CERTIFICATE_VERIFY_FAILED" in str(e):   # the site's own certificate is incomplete: retrying can't fix it
                print("    (that site's security certificate is broken on their end; I won't bypass the check - save it by hand if you want it)")
                return False
            time.sleep(5 * attempt)
        except KeyboardInterrupt:
            raise
        except Exception as e:  # noqa: BLE001  - a bad link must never stop the whole build
            print(f"\n  ! {label or url}: {type(e).__name__}: {e}")
            return False
    return False


def gh_asset(repo, pattern):
    """(name, url) of the newest release asset of a GitHub repo whose name matches the regex.
    Checks /releases/latest first, then recent releases (llama.cpp publishes binaries on build tags)."""
    for url in (f"https://api.github.com/repos/{repo}/releases/latest",
                f"https://api.github.com/repos/{repo}/releases?per_page=30"):
        try:
            data = json.loads(fetch(url, 60))
        except Exception as e:  # noqa: BLE001
            print(f"  ! GitHub {repo}: {e}")
            continue
        for rel in (data if isinstance(data, list) else [data]):
            if rel.get("draft"):
                continue
            for a in rel.get("assets", []):
                if re.search(pattern, a["name"], re.I):
                    return a["name"], a["browser_download_url"]
    return None


def extract(archive, dest, want):
    """Unpack zip/tar.gz and copy the folder containing a file named `want` (e.g. llama-server.exe) to dest."""
    tmp = dest + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
    if archive.endswith(".zip"):
        zipfile.ZipFile(archive).extractall(tmp)
    else:
        with tarfile.open(archive) as t:
            try:
                t.extractall(tmp, filter="data")
            except TypeError:                       # Python < 3.12 has no extraction filters
                t.extractall(tmp)
    found = None
    for root, _, files in os.walk(tmp):
        if want in files:
            found = root; break
    if not found:
        shutil.rmtree(tmp, ignore_errors=True)
        return False
    shutil.rmtree(dest, ignore_errors=True)
    shutil.copytree(found, dest)
    shutil.rmtree(tmp, ignore_errors=True)
    return True


def free_gb(path):
    return shutil.disk_usage(path).free / 1e9


def harden_ssl():
    """Make HTTPS certificate checks work on computers whose Python has an old or missing CA set
    (the cause of 'CERTIFICATE_VERIFY_FAILED: unable to get local issuer certificate'). Prefers the
    operating-system trust store (same one the browser uses); otherwise falls back to a current CA
    bundle shipped next to this builder. Verification stays ON - this never disables it."""
    try:
        import truststore          # uses the OS trust store + fetches missing intermediates, like a browser
        truststore.inject_into_ssl()
        print("  (certificates: using this computer's trust store)")
        return
    except Exception:              # noqa: BLE001 - truststore not installed; use the bundled CA file
        pass
    bundle = os.path.join(HERE, "cacert.pem")
    if os.path.exists(bundle):
        os.environ.setdefault("SSL_CERT_FILE", bundle)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", bundle)
        try:
            ssl.create_default_context(cafile=bundle)                       # sanity check the file parses
            ssl._create_default_https_context = lambda *a, **k: ssl.create_default_context(cafile=bundle)
            print("  (certificates: using the up-to-date CA bundle shipped with the builder)")
        except Exception as e:     # noqa: BLE001
            print(f"  (certificates: could not load CA bundle: {e})")


# ---------------------------------------------------------------------------- steps
def copy_repo(dest):
    say("Copying guides, locator page and library from the repository")
    www = os.path.join(dest, "www")
    os.makedirs(os.path.join(www, "library"), exist_ok=True)
    shutil.copy2(os.path.join(REPO, "www", "index.html"), www)
    for d in glob.glob(os.path.join(REPO, "library", "*", "")):
        name = os.path.basename(os.path.dirname(d))
        shutil.copytree(d, os.path.join(www, "library", name), dirs_exist_ok=True)
    os.makedirs(os.path.join(dest, "tools"), exist_ok=True)
    for f in ("serve.py",):
        shutil.copy2(os.path.join(REPO, "scripts", f), os.path.join(dest, "tools", f))
    for f in ("serve_usb.py", "ai_pick.py"):   # ai_pick: START picks the model that fits (v80)
        shutil.copy2(os.path.join(HERE, f), os.path.join(dest, "tools", f))
    with open(os.path.join(www, "config.js"), "w") as fh:
        fh.write("window.OFFGRID={zimPort:8091,nomadUrl:\"8080\",usb:true};\n")


def manuals(dest):
    say("Downloading the manuals library (firearms, radios, vehicles, medical, disasters...)")
    lib = os.path.join(dest, "www", "library")
    tsv = os.path.join(REPO, "library", "manuals.tsv")
    ok = fail = skipped = 0
    hist_p = os.path.join(dest, "tools", "download-history.json")
    try:
        hist = json.load(open(hist_p, encoding="utf-8"))
    except (OSError, ValueError):
        hist = {}
    missed = []
    have = [re.sub(r"[^a-z0-9]+", " ", f.lower()) for _, _, fs in os.walk(lib) for f in fs if f.lower().endswith(".pdf")]
    for line in open(tsv, encoding="utf-8"):
        p = line.rstrip("\n").split("\t")
        if len(p) < 4 or p[0].startswith("#") or p[3] == "local":
            continue
        cat, title, fname, url = p[:4]
        out = os.path.join(lib, cat, fname)
        if os.path.exists(out):
            continue
        # a copy you dropped in yourself (any folder, any file name) counts: match on the key words of the file name
        stem = re.sub(r"[^a-z0-9]+", " ", os.path.splitext(fname)[0].lower()).split()
        key = [w for w in stem if len(w) > 1 and w not in ("pdf", "us", "the", "of")]
        if fname.startswith("erg_") and any(re.search(r"\berg\b|emergency response guidebook", h) for h in have):
            continue
        if len(key) >= 2 and any(all(w in h for w in key[:4]) for h in have):
            continue
        if url.startswith("archive:"):
            try:
                meta = json.loads(fetch(f"https://archive.org/metadata/{url[8:]}", 60))
                pdfs = sorted([f["name"] for f in meta.get("files", []) if f.get("name", "").lower().endswith(".pdf")],
                              key=lambda n: ("_text" in n, len(n)))
                url = f"https://archive.org/download/{url[8:]}/{urllib.parse.quote(pdfs[0])}" if pdfs else ""
            except Exception:  # noqa: BLE001
                url = ""
        h = hist.get(url, {})
        if h.get("fails", 0) >= 3 and time.time() - h.get("last", 0) < 30 * 86400:
            skipped += 1             # failed on 3 builds in a row: rest it for 30 days instead of waiting on it every run
            missed.append((cat, title, url, f"failed {h['fails']} builds ({h.get('why', '?')}); retried after {time.strftime('%Y-%m-%d', time.localtime(h['last'] + 30 * 86400))}"))
            continue
        got = bool(url) and download(url, out, title[:60]) and open(out, "rb").read(5) == b"%PDF-"
        why = LAST_ERR[0] or ("not a PDF" if url else "no link")
        if not got and url and why in ("404", "410", "net", "not a PDF"):
            # the link is gone (not blocked): try the Internet Archive's saved copy of that same link
            if os.path.exists(out):
                os.remove(out)
            try:
                snap = json.loads(fetch("https://archive.org/wayback/available?url=" + urllib.parse.quote(url, safe=""), 30)) \
                    .get("archived_snapshots", {}).get("closest", {})
                if snap.get("available") and snap.get("timestamp"):
                    print(f"  trying the Internet Archive copy of {title[:50]} ...")
                    got = download(f"https://web.archive.org/web/{snap['timestamp']}id_/{url}", out, title[:60]) and \
                        open(out, "rb").read(5) == b"%PDF-"
                    if got:
                        why = ""
            except Exception:  # noqa: BLE001
                pass
        if got:
            ok += 1
            hist.pop(url, None)
        else:
            fail += 1
            if os.path.exists(out) and open(out, "rb").read(5) != b"%PDF-":
                os.remove(out)
            if url:
                hist[url] = {"fails": h.get("fails", 0) + 1, "last": time.time(), "why": why, "title": title}
            reason = {"403": "the site blocks downloads by script - save it in a browser", "401": "needs a login",
                      "cert": "the site's security certificate is broken", "404": "link is gone (no archived copy)",
                      "410": "link is gone (no archived copy)"}.get(why, why)
            missed.append((cat, title, url, reason))
    if shutil.which("pdfunite"):   # join Hesperian chapters if poppler is available (Linux/macOS)
        subprocess.call(["bash", os.path.join(REPO, "scripts", "fetch_library.sh"), tsv, lib, sys.executable],
                        stdout=subprocess.DEVNULL)
    subprocess.call([sys.executable, os.path.join(REPO, "scripts", "build_library.py"), "--lib-dir", lib, "--tsv", tsv])
    try:
        os.makedirs(os.path.dirname(hist_p), exist_ok=True)
        json.dump(hist, open(hist_p, "w", encoding="utf-8"), indent=1)
        os.makedirs(os.path.join(dest, "REPORTS"), exist_ok=True)
        with open(os.path.join(dest, "REPORTS", "NOT-FETCHED-Manuals.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write(f"MANUALS NOT DOWNLOADED - {time.strftime('%Y-%m-%d %H:%M')}\n")
            fh.write("Save any of these in a browser and drop the PDF into MY-FILES-INBOX; the builder then counts it as done.\n")
            fh.write("=" * 70 + "\n")
            for c, t, u_, why in missed:
                fh.write(f"[{c}] {t}\n    {u_}\n    -> {why}\n")
    except OSError:
        pass
    print(f"  manuals: {ok} downloaded, {fail} unavailable" + (f", {skipped} resting after 3 failed builds" if skipped else "") +
          (" - list in REPORTS\\NOT-FETCHED-Manuals.txt" if missed else ""))


def vendor(dest):
    say("Fetching map libraries (Leaflet, Protomaps)")
    v = os.path.join(dest, "www", "vendor")
    os.makedirs(v, exist_ok=True)
    for pkg, files in (("leaflet/-/leaflet-1.9.4.tgz", ("leaflet.js", "leaflet.css", "images/")),
                       ("protomaps-leaflet/-/protomaps-leaflet-5.1.0.tgz", ("protomaps-leaflet.js",))):
        try:
            t = tarfile.open(fileobj=io.BytesIO(fetch("https://registry.npmjs.org/" + pkg)))
            for m in t.getmembers():
                rel = m.name.replace("package/dist/", "", 1)
                if m.isfile() and any(rel == f or (f.endswith("/") and rel.startswith(f)) for f in files):
                    out = os.path.join(v, rel)
                    os.makedirs(os.path.dirname(out), exist_ok=True)
                    with open(out, "wb") as fh:
                        fh.write(t.extractfile(m).read())
        except Exception as e:  # noqa: BLE001
            print(f"  ! {pkg}: {e}")


_OP_GOOD = 0


def _overpass_query(q, label):
    """Run one Overpass query, rotating servers. Returns parsed JSON or None."""
    global _OP_GOOD
    q = q.replace("[timeout:300]", "[timeout:150]")
    body = urllib.parse.urlencode({"data": q})
    for attempt in range(10):
        url = OVERPASS[(_OP_GOOD + attempt) % len(OVERPASS)]
        host = url.split("/")[2]
        try:
            print(f"  {label} via {host} ...", flush=True)
            try:
                raw = fetch(url, 240, data=body.encode(), headers={"Content-Type": "application/x-www-form-urlencoded"})
            except urllib.error.HTTPError as e:
                if e.code != 406:
                    raise
                raw = fetch(url + "?" + body, 240)          # some servers only accept GET
            data = json.loads(raw)
            if "remark" in data and not data.get("elements") and "error" in data["remark"].lower():
                raise RuntimeError(data["remark"][:120])     # server-side timeout/out of memory
            _OP_GOOD = (_OP_GOOD + attempt) % len(OVERPASS)
            return data
        except Exception as e:  # noqa: BLE001
            print(f"  ! {label} ({host}): {str(e)[:120]}; trying the next server")
            time.sleep(4 if attempt < len(OVERPASS) else 40)
    return None


def write_route_topo(dest):
    """Map each get-home route to the topo quad files along it, so a travel copy can take just the destination's.
    Writes www/data/route-topo.json: {key: {label, quads:[www/topo/... rels], gb}}. Safe to call anytime."""
    cat = extras._catalog(dest)
    areas = cat.get("areas", {})
    coordkey, seen = {}, set()
    for r in routes_data.ROUTES:               # same dedup as routes_data.topo_spots(): first name wins per coord
        for s in r["spots"]:
            k = (round(s["lat"], 2), round(s["lon"], 2))
            if k in seen:
                continue
            seen.add(k)
            coordkey[k] = extras._slug("Get-home routes-" + s["name"])
    manifest = {}
    for r in routes_data.ROUTES:
        rels = []
        for s in r["spots"]:
            a = areas.get(coordkey.get((round(s["lat"], 2), round(s["lon"], 2))))
            for q in (a or {}).get("quads", []):
                rel = "www/topo/" + q["rel"]
                if rel not in rels and os.path.exists(os.path.join(dest, *rel.split("/"))):
                    rels.append(rel)
        gb = round(sum(os.path.getsize(os.path.join(dest, *rel.split("/"))) for rel in rels) / 1e9, 2)
        manifest[r["key"]] = {"label": r["label"], "quads": rels, "gb": gb}
    os.makedirs(os.path.join(dest, "www", "data"), exist_ok=True)
    for f in ("medicine.js", "MEDICINE-NOTICE.txt"):
        shutil.copy2(os.path.join(HERE, "data", f), os.path.join(dest, "www", "data", f))
    with open(os.path.join(dest, "www", "data", "route-topo.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh)
    return manifest


def overpass_pois(dest, lat, lon, radius, label, route_centers=None):
    """Fetch places one filter at a time, caching each result so a re-run only fetches what failed.
    route_centers: optional [(lat,lon)] key spots along the get-home routes - the resupply essentials
    are fetched around each and merged in, so the locator shows water/food/medical/shelter the whole way."""
    say(f"Building the locator from OpenStreetMap (Overpass API, {radius:g} miles)")
    meters = int(radius * 1609.34)
    cache = os.path.join(dest, "www", "data", "overpass")
    os.makedirs(cache, exist_ok=True)
    missing = []
    home_start, home_consec, home_stop = time.time(), 0, False
    for group, filters in QUERIES.items():
        if home_stop:
            break
        for k, f in enumerate(filters):
            cf = os.path.join(cache, f"{group}_{k}_{int(radius)}.json")
            if os.path.exists(cf):
                continue
            if time.time() - home_start > HOME_POI_BUDGET_SEC or home_consec >= 8:
                reason = ("The OpenStreetMap (Overpass) servers look down right now" if home_consec >= 8
                          else f"The locator has taken over {HOME_POI_BUDGET_SEC // 60} minutes (OpenStreetMap is slow/overloaded)")
                print(f"\n  ! {reason} - stopping the locator here for now. The places fetched so far are saved;\n"
                      "    re-run the builder later (when the servers are healthy) and it will fetch only what's missing.")
                missing.append(f"{group} {k + 1}")
                home_stop = True
                break
            q = f"[out:json][timeout:300];nwr(around:{meters},{lat},{lon}){f};out center tags;"
            data = _overpass_query(q, f"{group} {k + 1}/{len(filters)}")
            if data is None:
                missing.append(f"{group} {k + 1}")
                home_consec += 1
                continue
            home_consec = 0
            with open(cf, "w", encoding="utf-8") as fh:
                json.dump(data.get("elements", []), fh)
            print(f"    {len(data.get('elements', []))} features")
            time.sleep(5)
    if route_centers:
        say(f"Resources along the get-home routes ({len(route_centers)} key spots, {ROUTE_POI_RADIUS} miles each)")
        rmeters = int(ROUTE_POI_RADIUS * 1609.34)
        consec_fail, down, start = 0, False, time.time()

        def _stop(reason):
            print(f"\n  ! {reason} - skipping the rest of the route resources this run.\n"
                  "    Your home locator and everything else are unaffected. Re-run the builder later (when the\n"
                  "    OpenStreetMap servers are healthy) and it will fetch only these missing route resources.")

        for ci, (rlat, rlon) in enumerate(route_centers):
            if down:
                break
            for group in ROUTE_POI_GROUPS:
                for k, f in enumerate(QUERIES[group]):
                    cf = os.path.join(cache, f"route{ci}_{group}_{k}.json")
                    if os.path.exists(cf):
                        continue
                    if time.time() - start > ROUTE_POI_BUDGET_SEC:   # hard cap: never let a flaky server run away
                        _stop(f"Route resources have taken over {ROUTE_POI_BUDGET_SEC // 60} minutes (OpenStreetMap is slow/overloaded)")
                        down = True
                        missing.append(f"route{ci} {group} {k + 1}")
                        break
                    q = f"[out:json][timeout:300];nwr(around:{rmeters},{rlat},{rlon}){f};out center tags;"
                    data = _overpass_query(q, f"route spot {ci + 1}/{len(route_centers)} {group}")
                    if data is None:
                        missing.append(f"route{ci} {group} {k + 1}")
                        consec_fail += 1
                        if consec_fail >= 10:  # Overpass is clearly down - stop grinding; a later run fetches these
                            _stop("The OpenStreetMap (Overpass) servers look down right now")
                            down = True
                            break
                        continue
                    consec_fail = 0
                    with open(cf, "w", encoding="utf-8") as fh:
                        json.dump(data.get("elements", []), fh)
                    time.sleep(5)
                if down:
                    break
    rows, seen = [], set()
    cfiles = sorted(glob.glob(os.path.join(cache, f"*_{int(radius)}.json")) + glob.glob(os.path.join(cache, "route*_*.json")))
    for cf in cfiles:
        for el in json.load(open(cf, encoding="utf-8")):
            tags = el.get("tags") or {}
            key = (el["type"], el["id"])
            if key in seen or not tags:
                continue
            cat = build_pois.classify(tags)
            la = el.get("lat") or (el.get("center") or {}).get("lat")
            lo = el.get("lon") or (el.get("center") or {}).get("lon")
            if not cat or la is None or lo is None:
                continue
            seen.add(key)
            rows.append(build_pois.make_row(cat, tags, la, lo, f"{el['type']}/{el['id']}", lat, lon))
    a = argparse.Namespace(lat=lat, lon=lon, radius=radius, label=label, out_dir=os.path.join(dest, "www", "data"))
    build_pois.write_outputs(rows, a)
    if missing:
        print(f"\n  ! Still missing (servers busy): {', '.join(missing)}. Run the builder again later - "
              f"only these will be fetched.")
        open(os.path.join(cache, "INCOMPLETE"), "w").write("\n".join(missing))
    else:
        try:
            os.remove(os.path.join(cache, "INCOMPLETE"))
        except OSError:
            pass


def pmtiles_maxzoom(path):
    """Max zoom stored in a PMTiles v3 header (byte 101), or None if unreadable."""
    try:
        with open(path, "rb") as f:
            h = f.read(127)
        return h[101] if h[:7] == b"PMTiles" and len(h) > 101 else None
    except OSError:
        return None


def _pmtiles_setup(dest):
    """Fetch the go-pmtiles CLI and find the newest Protomaps planet build. Returns (tool, src) or (None, None)."""
    sysname = {"Windows": "Windows", "Darwin": "Darwin", "Linux": "Linux"}[platform.system()]
    arch = "arm64" if platform.machine().lower() in ("arm64", "aarch64") else "x86_64"
    asset = gh_asset("protomaps/go-pmtiles", rf"{sysname}_{arch}\.(zip|tar\.gz)$")
    if not asset:
        print("  ! pmtiles tool not found"); return None, None
    tooldir = os.path.join(dest, "tools", "pmtiles")
    arc = os.path.join(tooldir, asset[0])
    exe = "pmtiles.exe" if sysname == "Windows" else "pmtiles"
    if not download(asset[1], arc) or not extract(arc, os.path.join(tooldir, "bin"), exe):
        print("  ! could not get pmtiles"); return None, None
    tool = os.path.join(tooldir, "bin", exe)
    if sysname != "Windows":
        os.chmod(tool, 0o755)
    for i in range(22):
        d = (datetime.datetime.utcnow() - datetime.timedelta(days=i)).strftime("%Y%m%d")
        try:
            urllib.request.urlopen(urllib.request.Request(f"https://build.protomaps.com/{d}.pmtiles", method="HEAD",
                                                          headers={"User-Agent": UA}), timeout=30)
            return tool, f"https://build.protomaps.com/{d}.pmtiles"
        except Exception:  # noqa: BLE001
            continue
    print("  ! no Protomaps build found"); return tool, None


def street_map(dest, lat, lon, radius, maxzoom):
    say(f"Offline street map (zoom 0-{maxzoom}, {radius:g}-mile box)")
    out = os.path.join(dest, "www", "map", "region.pmtiles")
    if os.path.exists(out):
        have = pmtiles_maxzoom(out)
        if have is not None and have >= maxzoom and not (UPDATE and age_days(out) > 180):
            print(f"  already there (zoom 0-{have})"); return
        if have is not None and have >= maxzoom:
            print("  map is over 6 months old - rebuilding from the newest OpenStreetMap data")
        if have is None or have < maxzoom:
            print(f"  existing map only goes to zoom {have} - rebuilding at zoom {maxzoom}")
    tool, src = _pmtiles_setup(dest)
    if not tool or not src:
        print("  ! skipping street map"); return
    dl, dn = radius / 69.0, radius / (69.17 * math.cos(math.radians(lat)))
    bbox = f"{lon - dn:.4f},{lat - dl:.4f},{lon + dn:.4f},{lat + dl:.4f}"
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if subprocess.call([tool, "extract", src, out + ".part", f"--bbox={bbox}", f"--maxzoom={maxzoom}"]) == 0:
        os.replace(out + ".part", out)
    else:
        print("  ! map extract failed (re-run to retry)")


US_BBOX = "-125,24,-66.5,50"       # continental US + southern Canada (covers the Toronto/Québec routes)


def us_street_map(dest, maxzoom=14):
    """Stream the whole US out of the Protomaps planet build into www/map/us.pmtiles (a second base layer).
    pmtiles extract reads only the tiles in the bbox over HTTP range requests - not the whole planet."""
    say(f"Whole-US street map (zoom 0-{maxzoom})")
    out = os.path.join(dest, "www", "map", "us.pmtiles")
    if os.path.exists(out):
        have = pmtiles_maxzoom(out)
        if have is not None and have >= maxzoom and not (UPDATE and age_days(out) > 365):
            print(f"  already there (zoom 0-{have})"); return
    tool, src = _pmtiles_setup(dest)
    if not tool or not src:
        print("  ! skipping US street map"); return
    os.makedirs(os.path.dirname(out), exist_ok=True)
    print(f"  extracting the US (bbox {US_BBOX}) at zoom {maxzoom} - large download, can take a while; resumable")
    if subprocess.call([tool, "extract", src, out + ".part", f"--bbox={US_BBOX}", f"--maxzoom={maxzoom}"]) == 0:
        os.replace(out + ".part", out)
        print(f"  whole-US street map ready ({os.path.getsize(out) / 1e9:.1f} GB)")
    else:
        print("  ! US map extract failed (re-run to retry)")


def kiwix(dest, zims, bins):
    say("Kiwix offline archives and portable readers")
    base = "https://download.kiwix.org/release/kiwix-tools/"
    try:
        listing = fetch(base, 60).decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        listing = ""; print(f"  ! {e}")
    pats = {"win": (r'kiwix-tools_win-x86_64[-0-9.]*\.zip', "kiwix-serve.exe"),
            "linux": (r'kiwix-tools_linux-x86_64[-0-9.]*\.tar\.gz', "kiwix-serve"),
            "macos-arm64": (r'kiwix-tools_macos-arm64[-0-9.]*\.tar\.gz', "kiwix-serve"),
            "macos-x64": (r'kiwix-tools_macos-x86_64[-0-9.]*\.tar\.gz', "kiwix-serve")}
    for osn in bins:
        for key in ([osn] if osn != "mac" else ["macos-arm64", "macos-x64"]):
            rx, want = pats[key]
            names = sorted(set(re.findall(rx, listing)))
            if not names:
                print(f"  - no kiwix-tools build for {key}"); continue
            arc = os.path.join(dest, "kiwix", "dl", names[-1])
            if download(base + names[-1], arc) and extract(arc, os.path.join(dest, "kiwix", "bin", key), want):
                print(f"  kiwix-serve for {key} ready")
    for folder, prefix in zims:
        try:
            lst = fetch(f"https://download.kiwix.org/zim/{folder}/", 60).decode("utf-8", "replace")
        except Exception as e:  # noqa: BLE001
            print(f"  ! {folder}: {e}"); continue
        names = sorted(set(re.findall(rf"{re.escape(prefix)}_\d{{4}}-\d{{2}}\.zim", lst)))
        site = prefix.split("_")[0]
        if not names and site not in NO_FALLBACK:   # renamed or moved (e.g. into zimit/)? look for the same site name
            for alt in dict.fromkeys([folder, "zimit", "other"]):
                try:
                    al = lst if alt == folder else fetch(f"https://download.kiwix.org/zim/{alt}/", 60).decode("utf-8", "replace")
                except Exception:  # noqa: BLE001
                    continue
                cand = sorted(set(re.findall(rf"{re.escape(site)}[\w.-]*?_en_[\w.-]*?_\d{{4}}-\d{{2}}\.zim", al)),
                              key=lambda n: n[-12:])
                if cand:
                    folder, names = alt, cand
                    print(f"  ({prefix} is now {cand[-1]} in {alt}/)")
                    break
        if names:
            zurl, zpath = f"https://download.kiwix.org/zim/{folder}/{names[-1]}", os.path.join(dest, "kiwix", "zim", names[-1])
            zim_resume_if_short(zurl, zpath)
            if download(zurl, zpath, names[-1]):
                prune_versions(os.path.join(dest, "kiwix", "zim"), names[-1])
        else:
            print(f"  - {prefix} not found on the Kiwix server (it may have been retired)")


def ai(dest, models, bins, gpu):
    say("Offline AI: llama.cpp server + models")
    pats = {"win": [r"bin-win-cpu-x64\.zip$"] + ([r"bin-win-vulkan-x64\.zip$"] if gpu else []),
            "linux": [r"bin-ubuntu-x64\.(zip|tar\.gz)$"] + ([r"bin-ubuntu-vulkan-x64\.(zip|tar\.gz)$"] if gpu else []),
            "mac": [r"bin-macos-arm64\.(zip|tar\.gz)$", r"bin-macos-x64\.(zip|tar\.gz)$"]}
    names = {r"bin-win-cpu": "win", r"bin-win-vulkan": "win-gpu", r"bin-ubuntu-x64": "linux",
             r"bin-ubuntu-vulkan": "linux-gpu", r"bin-macos-arm64": "macos-arm64", r"bin-macos-x64": "macos-x64"}
    for osn in bins:
        for pat in pats[osn]:
            asset = gh_asset("ggml-org/llama.cpp", pat)
            if not asset:
                print(f"  - no llama.cpp build matching {pat}"); continue
            key = next(v for k, v in names.items() if re.search(k, asset[0]))
            arc = os.path.join(dest, "ai", "dl", asset[0])
            want = "llama-server.exe" if osn == "win" else "llama-server"
            outdir = os.path.join(dest, "ai", "bin", key)
            if installed(outdir, want, asset[0]):
                continue
            if download(asset[1], arc, asset[0]) and extract(arc, outdir, want):
                mark_installed(outdir, asset[0])
                print(f"  llama-server for {key} ready ({asset[0]})")
            else:
                print(f"  ! llama.cpp {key} failed")
    got, roles = [], {}
    for m in models:
        if m.startswith("http"):
            url, name, proj = m, os.path.basename(m.split("?")[0]), None
        else:
            spec = MODELS[m]
            url, gb, desc = spec[:3]
            proj = spec[3] if len(spec) > 3 else None
            name = os.path.basename(url)
            print(f"  model {m}: {desc} (~{gb} GB)")
        if not download(url, os.path.join(dest, "ai", "models", name), name):
            continue
        got.append(name)
        if proj:
            pname = f"mmproj-{m}.gguf"
            if download(proj, os.path.join(dest, "ai", "models", pname), f"{m} vision projector"):
                roles[m] = {"model": name, "mmproj": pname}
        elif m in MODELS:
            roles[m] = {"model": name}
    if got:
        pref = [os.path.basename(MODELS[k][0]) for k in ("medium", "small", "large")]
        default = next((p for p in pref if p in got), got[0])
        with open(os.path.join(dest, "ai", "default-model.txt"), "w") as fh:
            fh.write(default + "\n")
        big = os.path.basename(MODELS["large"][0])
        if big in got:
            with open(os.path.join(dest, "ai", "large-model.txt"), "w") as fh:
                fh.write(big + "\n")
    old_roles = {}
    try:
        old_roles = json.load(open(os.path.join(dest, "ai", "roles.json")))
    except (OSError, ValueError):
        pass
    with open(os.path.join(dest, "ai", "roles.json"), "w") as fh:
        json.dump({**old_roles, **roles}, fh, indent=1)
    if got or glob.glob(os.path.join(dest, "ai", "models", "*Instruct*.gguf")):   # passage re-sorter for Ask (v78)
        download(RERANK_URL, os.path.join(dest, "ai", "models", os.path.basename(RERANK_URL)), "Reranker (bge-reranker-v2-m3, ~440 MB)")
    shutil.rmtree(os.path.join(dest, "ai", "dl"), ignore_errors=True)


def ask_index(dest, label):
    say("Building the 'Ask the Library' search index")
    tmpbase = os.path.join(dest, ".kbbuild")
    shutil.rmtree(tmpbase, ignore_errors=True)
    os.makedirs(tmpbase)
    paths = nomad_sync.build(dest, os.path.join(tmpbase, "kb"), label, include_pdfs=False)
    chunks = []
    for p in paths:
        if not p.endswith(".txt"):
            continue
        title = os.path.splitext(os.path.basename(p))[0].replace("_", " ")
        txt = open(p, encoding="utf-8").read()
        m = re.search(r"Source file: (library/\S+)", txt)
        src = m.group(1) if m else ""
        paras, cur = re.split(r"\n\s*\n", txt), ""
        for para in paras:
            if len(cur) + len(para) > 1400 and cur:
                chunks.append([title, src, cur.strip()]); cur = cur[-200:]
            cur += "\n\n" + para
        if cur.strip():
            chunks.append([title, src, cur.strip()])
    with open(os.path.join(dest, "www", "docs.js"), "w", encoding="utf-8") as fh:
        fh.write("window.DOCS=" + json.dumps(chunks, separators=(",", ":")) + ";\n")
    try:
        import ask_fast
        print(f"  {ask_fast.write(dest, chunks):,} index terms (instant search)")
    except Exception as e:  # noqa: BLE001  - the page falls back to indexing in the browser
        print(f"  (prebuilt index skipped: {e})")
    shutil.rmtree(tmpbase, ignore_errors=True)
    print(f"  {len(chunks)} searchable passages")


def topics_index(dest):
    """Index every guide section (adding anchors where missing) + manuals + archives for the topic browser."""
    say("Building the topic browser index (What's happening?)")
    import html as _h
    lib = os.path.join(dest, "www", "library")
    strip = lambda t: re.sub(r"\s+", " ", _h.unescape(re.sub(r"<[^>]+>", " ", re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", t)))).strip()
    sections = []
    for f in sorted(glob.glob(os.path.join(lib, "*", "*.html"))):
        if os.path.basename(f) in ("index.html",):
            continue
        rel = os.path.relpath(f, os.path.join(dest, "www")).replace(os.sep, "/")
        src = open(f, encoding="utf-8", errors="replace").read()
        m = re.search(r"(?is)<h1[^>]*>(.*?)</h1>", src)
        gtitle = strip(m.group(1)) if m else os.path.splitext(os.path.basename(f))[0].replace("_", " ")
        used, changed = set(re.findall(r'\bid="([^"]+)"', src)), False

        def add_id(mm):
            nonlocal changed
            tag, attrs = mm.group(1), mm.group(2)
            if re.search(r'\bid=', attrs):
                return mm.group(0)
            base = re.sub(r"[^a-z0-9]+", "-", strip(mm.group(3)).lower()).strip("-")[:40] or "s"
            sid, k = base, 2
            while sid in used:
                sid, k = f"{base}-{k}", k + 1
            used.add(sid); changed = True
            return f'<{tag}{attrs} id="{sid}">{mm.group(3)}'
        segs = re.split(r"(?is)(<script\b.*?</script>)", src)       # never touch headings inside scripts
        src = "".join(sg if sg[:7].lower() == "<script" else re.sub(r"(?is)<(h2)([^>]*)>(.*?)(?=</h2>)", add_id, sg) for sg in segs)
        if changed:
            with open(f, "w", encoding="utf-8") as fh:
                fh.write(src)
        parts = re.split(r"(?is)(<h2[^>]*>.*?</h2>)", re.sub(r"(?is)<script\b.*?</script>", " ", src))
        for i in range(1, len(parts), 2):
            hm = re.search(r'(?is)<h2[^>]*\bid="([^"]+)"[^>]*>(.*?)</h2>', parts[i])
            if not hm:
                continue
            body = strip(parts[i + 1] if i + 1 < len(parts) else "")
            sections.append([gtitle, re.sub(r"^\d+\.\s*", "", strip(hm.group(2))), f"{rel}#{hm.group(1)}", body[:2500]])
        if len(parts) == 1:
            sections.append([gtitle, gtitle, rel, strip(src)[:2500]])
    pdfs, seen = [], set()
    tsv = os.path.join(REPO, "library", "manuals.tsv")
    for line in open(tsv, encoding="utf-8"):
        p = line.rstrip("\n").split("\t")
        if len(p) >= 4 and not p[0].startswith("#") and os.path.exists(os.path.join(lib, p[0], p[2])):
            pdfs.append([p[0], p[1], f"library/{p[0]}/{p[2]}"]); seen.add(os.path.join(lib, p[0], p[2]))
    for f in glob.glob(os.path.join(lib, "*", "*.pdf")) + glob.glob(os.path.join(lib, "Books - *", "*.epub")):
        if f not in seen and "_part" not in f:
            cat = os.path.basename(os.path.dirname(f))
            pdfs.append([cat, os.path.splitext(os.path.basename(f))[0].replace("_", " "),
                         os.path.relpath(f, os.path.join(dest, "www")).replace(os.sep, "/")])
    zims = sorted(os.path.basename(z) for z in glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim")))
    with open(os.path.join(dest, "www", "topics-data.js"), "w", encoding="utf-8") as fh:
        fh.write("window.TOPICS=" + json.dumps({"sections": sections, "pdfs": pdfs, "zims": zims}, separators=(",", ":")) + ";\n")
    print(f"  {len(sections)} guide sections, {len(pdfs)} manuals, {len(zims)} archives")


def launchers(dest):
    """Menu, programs, pages and the drive's own builder copy - quick, so it runs first and again at the end."""
    os.makedirs(os.path.join(dest, "tools"), exist_ok=True)
    more_data.ham_page(dest)
    for f in ("home.html", "suggested-files.html", "workspace.html", "ask.html", "instant.js", "topics.html", "search.html", "coords.js", "calculators.html", "declination.html", "wmm.js", "converter.html", "command.html", "states.html", "radio.html", "scout.html", "grid.html", "medicine.html", "statemaps.html", "places500.html", "online.html", "coords.html", "meds.html", "nomad-wsl2.html", "quick.html", "situation.html", "scen-data.js", "quick-data.js", "readinglist.html", "ai-apps.html", "zim.html", "archives.html", "ai-memory.html"):
        shutil.copy2(os.path.join(HERE, f), os.path.join(dest, "www", f))
    # optional add-on pages: copy a stub only when the add-on is not installed (never overwrite an installed add-on)
    for dp, _, fs in os.walk(os.path.join(HERE, "addons")):
        for f in fs:
            tgt = os.path.join(dest, "www", "addons", os.path.relpath(os.path.join(dp, f), os.path.join(HERE, "addons")))
            if not os.path.exists(tgt):
                os.makedirs(os.path.dirname(tgt), exist_ok=True)
                shutil.copy2(os.path.join(dp, f), tgt)
    # places for the declination finder: home, every Southern city, and the rest of the US
    try:
        opts = json.load(open(os.path.join(dest, "tools", "build-options.json")))
    except (OSError, ValueError):
        opts = {}
    home = [["GA", "Canton (home)", 34.2367, -84.4908]]
    if opts.get("lat") and opts.get("lon") and abs(opts["lat"] - 34.2387) + abs(opts["lon"] + 84.4513) > 0.05:
        home = [["", f"Home - {opts.get('label', 'home')}", opts["lat"], opts["lon"]]]
    os.makedirs(os.path.join(dest, "www", "data"), exist_ok=True)
    with open(os.path.join(dest, "www", "data", "dec-places.js"), "w", encoding="utf-8") as fh:
        fh.write("window.DECPLACES=" + json.dumps(home + [list(c) for c in areas.CITIES + areas.US_EXTRA], separators=(",", ":")) + ";\n")
    with open(os.path.join(dest, "www", "data", "routes.js"), "w", encoding="utf-8") as fh:
        rh = routes_data.HOME
        if opts.get("state"):                       # a home that is not the author's: show it, and no author routes
            rh, routes = {"name": opts.get("label", "Home"), "lat": opts["lat"], "lon": opts["lon"]}, []
        else:
            routes = routes_data.ROUTES
        fh.write("window.ROUTES=" + json.dumps({"home": rh, "routes": routes}, separators=(",", ":")) + ";\n")
    write_route_topo(dest)
    try:
        region.localize(dest, opts)                 # pages say your town, not the author's (no change for the original home)
    except Exception as e:  # noqa: BLE001
        print(f"  ! localizing pages: {e}")
    shutil.copy2(os.path.join(HERE, "README.txt"), os.path.join(dest, "README.txt"))
    shutil.copy2(os.path.join(HERE, "check_usb.py"), os.path.join(dest, "tools", "check_usb.py"))
    shutil.copy2(os.path.join(HERE, "doctor.py"), os.path.join(dest, "tools", "doctor.py"))
    shutil.copy2(os.path.join(HERE, "protect.py"), os.path.join(dest, "tools", "protect.py"))
    for f in ("offgrid-reminder.ps1", "update_drive.ps1"):
        shutil.copy2(os.path.join(HERE, f), os.path.join(dest, "tools", f))
    # a copy of this builder on the drive, so the drive's programs and updates work from any computer
    bdir = os.path.join(dest, "tools", "builder")
    if os.path.realpath(REPO) != os.path.realpath(bdir):
        try:
            shutil.copytree(REPO, bdir, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git", "*.zip"))
        except (OSError, shutil.Error) as e:
            print(f"  ! couldn't copy the builder onto the drive: {e}")
    shutil.copy2(os.path.join(REPO, "library", "manuals.tsv"), os.path.join(dest, "tools", "manuals.tsv"))
    launcher.write(dest, HERE, UPDATE)   # START-HERE menu, READ-ME-FIRST page, PROGRAMS\ and REPORTS\ folders
    try:
        manual.build(dest)               # HOW-TO-USE-THIS-DRIVE: manual.html + the plain-text copy at the root
    except Exception as e:  # noqa: BLE001
        print(f"  ! manual: {type(e).__name__}: {e}")


def finish_light(dest):
    """Quick pass between big steps: launchers, topic index and library pages (so the drive is usable if a later step stops)."""
    say("Writing launchers and home page (quick pass)")
    launchers(dest)
    topics_index(dest)
    subprocess.call([sys.executable, os.path.join(REPO, "scripts", "build_library.py"),
                     "--lib-dir", os.path.join(dest, "www", "library"), "--tsv", os.path.join(REPO, "library", "manuals.tsv")])


def finish(dest):
    say("Writing launchers and home page")
    launchers(dest)
    topics_index(dest)
    u = sys.modules[__name__]
    for name, fn in (("My Maps", mymaps.build), ("Maps by coordinates", topo_search.build), ("My radio files", radio_img.build), ("My documents", library_inbox.build), ("Personal files (private)", personal_files.build), ("GPS files", extras.place_exports), ("Google Earth Pro copies", kml_fix.build), ("US cities list", cities_data.build), ("Excel files", xlsx_export.build), ("Hospital directory", hospitals_data.build), ("Google Earth layers", kml_export.build), ("500-mile places files", regional_pois.build), ("Platform folders", platforms.build), ("Field Notebook", field_notebook.build), ("Travel folders", platforms.refresh), ("State map index", state_maps.build), ("Reading list index", reading_list.build), ("Open-with folders", openwith.build), ("Tidy up", tidy.build), ("Drive checklist", drive_checklist.build)):
        try:
            fn(u, dest)
        except Exception as e:  # noqa: BLE001
            print(f"  ! {name}: {type(e).__name__}: {e}")
    try:
        media.catalog(dest, os.path.join(dest, "www", "media"))
    except Exception as e:  # noqa: BLE001
        print(f"  ! Movies & TV page: {type(e).__name__}: {e}")
    try:
        music.catalog(dest, os.path.join(dest, "www", "music"))
    except Exception as e:  # noqa: BLE001
        print(f"  ! Music page: {type(e).__name__}: {e}")
    try:
        import drive_catalog
        print(f"  Command Center catalog: {drive_catalog.build(dest)} maps, archives and media items")
    except Exception as e:  # noqa: BLE001
        print(f"  ! Command Center catalog: {type(e).__name__}: {e}")
    # library pages last, so e-books, radio channel lists and anything added since the manuals step are listed
    subprocess.call([sys.executable, os.path.join(REPO, "scripts", "build_library.py"),
                     "--lib-dir", os.path.join(dest, "www", "library"), "--tsv", os.path.join(REPO, "library", "manuals.tsv")])
    try:
        import survival_guide
        print(f"  {survival_guide.build_all(dest)} situation guides (Command Center > Survival guides)")
    except Exception as e:  # noqa: BLE001
        print(f"  ! Survival guides: {type(e).__name__}: {e}")
    search_index.build(u, dest)
    try:
        import situation_packs
        n, got = situation_packs.build_all(dest)
        print(f"  Top 20 situations: {n} pages, {got} drive pages gathered (folder: TOP 20 SITUATIONS)")
        import dashboard
        dashboard.build(dest)            # again, now that the Top 20 folder exists
    except Exception as e:  # noqa: BLE001
        print(f"  ! Top 20 situations: {type(e).__name__}: {e}")
    try:
        import drive_guide
        g, b = drive_guide.build(dest)   # the AI's map of the drive (read first on every question)
        print(f"  AI drive guide: {g:,} characters (ai\\memory\\drive-guide.txt)")
    except Exception as e:  # noqa: BLE001
        print(f"  ! AI drive guide: {type(e).__name__}: {e}")
    sizes = {}
    for root, _, files in os.walk(dest):
        top = os.path.relpath(root, dest).split(os.sep)[0]
        if top == "OPEN-WITH":
            continue                    # hard links to files counted elsewhere: they use no extra space
        sizes[top] = sizes.get(top, 0) + sum(os.path.getsize(os.path.join(root, f)) for f in files)
    print("  (OPEN-WITH holds links to the files below and uses no extra space)")
    print("  Space used: " + ", ".join(f"{k} {v / 1e9:.1f} GB" for k, v in sorted(sizes.items()) if v > 1e7))


def _satellite_boxes(a, sites):
    """Areas for the high-detail USGS NAIP layer (tiles/satellite), sized by --imagery-level so it stays reasonable:
    home always to zoom 18 (~0.6 m); route/destination spots to 16 / 17 / 18 at levels 1-2 / 3 / 4; the bases/cities/lakes areas
    only at level 3 (zoom 15) and 4 (zoom 17 — very large). Tiles are deduplicated across overlapping areas by extras.satellite."""
    lv = getattr(a, "imagery_level", 2) or 2
    spot_z, area_z = (16, 0) if lv <= 2 else (17, 15) if lv == 3 else (18, 17)
    kinds = [k.strip() for k in a.areas.split(",") if k.strip()]
    boxes = [(extras._box(a.lat, a.lon, a.topo_radius), 12, 18)]                         # home
    boxes += [(tuple(s["bbox"]), 12, spot_z) for s in routes_data.topo_spots()]          # get-home routes + destinations
    if area_z:                                                                           # bases/cities/lakes: levels 3-4
        boxes += [(tuple(x["bbox"]), 12, area_z) for x in areas.area_list(sites, kinds, a.city_radius, a.base_buffer)]
    return boxes


def _home(a):
    """Home for the printable maps and phone files: the build's home point (works for the public edition too)."""
    try:
        return {"name": f"{a.label or 'Home'} (home)" if "home" not in (a.label or "").lower() else a.label,
                "lat": float(a.lat), "lon": float(a.lon)}
    except (TypeError, ValueError, AttributeError):
        return None


def _imagery_steps(a, step, sites):
    """Eastern US + Canada imagery first (level 1-4, most useful first), then the high-detail NAIP areas,
    then the phone files and the printable map sheets from all of it."""
    u = sys.modules[__name__]
    t0 = time.time()
    if a.imagery_level:
        step("Satellite imagery, Eastern US + Canada", imagery.download, u, a.dest, a.imagery_level, a.imagery_hours, None, _home(a))
    left = a.imagery_hours - (time.time() - t0) / 3600 if a.imagery_hours else 0
    if not a.imagery_hours or left > 0.05:
        step("High-detail aerial photos (USGS NAIP): home, routes, bases, cities", extras.satellite, u, a.dest, _satellite_boxes(a, sites))
    imagery.write_info(a.dest)
    step("Satellite files for phones", imagery.phone_packs, u, a.dest, None, _home(a))
    step("Printable satellite maps", map_sheets.build, u, a.dest, None, _home(a))


PROFILES = {   # drive-size presets: flags set only where the user didn't pass one
    "micro":  dict(models="small", no_big=True, no_software=True, no_areas=True, no_south_tiles=True, no_phone=True, no_vault=True,
                   no_voice=True, no_topo=True, no_flood=True, no_canada=True, maxzoom=12, radius=75),
    "small":  dict(models="small", no_big=True, no_areas=True, no_south_tiles=True, no_phone=True, no_canada=True,
                   topo_radius=25, maxzoom=13),
    "medium": dict(models="small,medium,medical", no_big=True, no_areas=True, no_canada=True),
    "large":  dict(no_big=True),
    "full":   dict(),
}
PROFILE_ZIMS = {   # which archive families each size keeps ("all" = everything in ZIMS)
    "micro": ("zimgit-",),
    "small": ("zimgit-", "mdwiki", "appropedia", "outdoors.", "ham.", "diy.", "libretexts.org_en_med"),
}


def ocr_child(dest, pages):
    """OCR in its own Python process: if a PDF library or Tesseract crashes hard, only OCR stops - the build carries on.
    OCR is page-by-page resumable, so the next run continues where this one ended."""
    print("  (OCR runs in its own process; if it stops, the build carries on and the next run resumes it)", flush=True)
    rc = subprocess.call([sys.executable, os.path.join(HERE, "ocr.py"), "--dest", dest, "--pages", str(pages)],
                         creationflags=0x00004000 if os.name == "nt" else 0)
    if rc != 0:
        hint = {3221225478: "the drive could not be read - it disconnected or had a read error (cable, USB port, power saving)",
                3221225477: "a crash inside a PDF or OCR program", 3221225725: "ran out of memory"}.get(rc & 0xFFFFFFFF, "")
        print(f"  ! OCR stopped early (exit code {rc}{': ' + hint if hint else ''}). Pages done so far are kept; it resumes on the next run.")
        if not os.path.isdir(dest):
            print(f"  !! {dest} is not reachable right now. Check the drive is still connected, then run the builder again.")
            return
        try:
            os.makedirs(os.path.join(dest, "REPORTS"), exist_ok=True)
            with open(os.path.join(dest, "REPORTS", "CRASH-LOG.txt"), "a", encoding="utf-8") as fh:
                fh.write(f"{time.strftime('%Y-%m-%d %H:%M')}  OCR process ended with code {rc} {hint}\n")
        except OSError:
            pass


def geofab(a):
    """Geofabrik regions to download: what was asked for, else the home state's set (any ZIP) or the original Georgia set."""
    if a.geofabrik is not None:
        return a.geofabrik
    if a.state:
        return region.regions(a.state, a.profile)
    return GEOFABRIK_BY_PROFILE.get(a.profile, "")


def area_kw(a):
    """Keyword arguments for areas.area_list: the home region when a ZIP was given, otherwise the original Southern lists."""
    return dict(states=region.area_states(a.state) or areas.SOUTH, home=(a.lat, a.lon)) if a.state else {}


def edition():
    try:
        return json.load(open(os.path.join(HERE, "edition.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def set_home(a, ap):
    """Home from --zip, from the drive's saved settings, or (public edition, first run) by asking for the ZIP code."""
    defaults = [ap.get_default(k) for k in ("lat", "lon", "label")]
    given = [getattr(a, k) for k in ("lat", "lon", "label")] != defaults or a.zip
    if not given:                                   # nothing on the command line: reuse this drive's saved home
        try:
            saved = json.load(open(os.path.join(a.dest, "tools", "build-options.json")))
            if saved.get("lat") is not None and saved.get("label"):
                for k in ("lat", "lon", "label", "zip", "state"):
                    if k in saved:
                        setattr(a, k, saved[k])
                return
        except (OSError, ValueError):
            pass
    if a.zip:
        hit = region.lookup_zip(a.zip.strip())
        if not hit:
            print(f"  ! Could not look up ZIP {a.zip} (no internet?). Give --lat, --lon and --label instead.")
            sys.exit(2)
        a.lat, a.lon, a.state = hit[0], hit[1], hit[3]
        a.label = f"ZIP {a.zip} ({hit[2]}, {hit[3]})"
    elif not given and edition().get("public"):
        if not sys.stdin or not sys.stdin.isatty():
            print("  ! This edition needs your ZIP code. Run BUILD-MY-DRIVE (or add  --zip 12345 ).")
            sys.exit(2)
        a.lat, a.lon, a.label, a.state, a.zip = region.ask_home()
    elif a.state == "" and a.label != ap.get_default("label"):
        m = re.search(r",\s*([A-Z]{2})\)", a.label)
        a.state = m.group(1) if m else ""
    if a.state:                                     # a home that is not the author's: no Toronto / Quebec get-home routes
        a.no_canada = True
        routes_data.ROUTES = []
        routes_data.HOME = {"name": a.label, "lat": a.lat, "lon": a.lon}


def resolve_profile(name, free):
    """'auto' picks a preset from the free space on the drive; otherwise the named preset is used as given."""
    if name != "auto":
        return name
    return "micro" if free < 48 else "small" if free < 120 else "medium" if free < 300 else "large" if free < 700 else "full"


GEOFABRIK_BY_PROFILE = {"small": "georgia", "medium": "georgia",
                        "large": "georgia,tennessee,alabama,north-carolina,south-carolina",
                        "full": "georgia,tennessee,alabama,north-carolina,south-carolina,florida,virginia,kentucky,mississippi"}


def apply_profile(a, ap):
    if a.profile == "auto":       # a resumed build keeps its original size choice, even though free space has shrunk
        try:
            a.profile = json.load(open(os.path.join(a.dest, "tools", "build-options.json"))).get("profile", "auto")
        except (OSError, ValueError):
            pass
    a.profile = resolve_profile(a.profile, free_gb(a.dest))
    for k, v in PROFILES[a.profile].items():
        if getattr(a, k) == ap.get_default(k):
            setattr(a, k, v)
    print(f"  Drive size profile: {a.profile} ({free_gb(a.dest):.0f} GB free). Override any part with the --no-... options.")


def profile_zims(profile):
    keep = PROFILE_ZIMS.get(profile)
    return ZIMS if not keep else [z for z in ZIMS if z[1].startswith(keep)]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True, help="folder on the USB drive, e.g. E:\\OFFGRID")
    ap.add_argument("--profile", default="auto", choices=["auto", *PROFILES],
                    help="drive size: micro (<48 GB) small (<120) medium (<300) large (<700) full (700+ GB). "
                         "auto (default) picks from the free space on the drive")
    ap.add_argument("--lat", type=float, default=34.2387)
    ap.add_argument("--lon", type=float, default=-84.4513)
    ap.add_argument("--label", default="ZIP 30115 (Canton, GA)")
    ap.add_argument("--zip", default="", help="5-digit ZIP code of your home: sets the map centre, the nearby states and the regional map area")
    ap.add_argument("--state", default="", help="two-letter state of home (set automatically from --zip)")
    ap.add_argument("--radius", type=float, default=150, help="miles of places for the locator (default 150)")
    ap.add_argument("--models", default="small,medium,large,vision,medical",
                    help="any of small,medium,large,vision,medical or direct .gguf URLs (comma-separated)")
    ap.add_argument("--gpu", action="store_true", help="also add Vulkan GPU builds of the AI server (Windows/Linux)")
    ap.add_argument("--os", default="win,mac,linux", help="which computers the drive should run on")
    ap.add_argument("--maxzoom", type=int, default=14, choices=range(8, 16), metavar="8-15",
                    help="street map detail (12 = main roads/towns; 14 = every street, default; 15 = buildings, largest)")
    ap.add_argument("--topo-radius", type=float, default=50, help="miles around home for USGS topo quads + topo layer (default 50)")
    ap.add_argument("--meds-only", action="store_true", help="download FDA drug labels and build the Medicine list (uses + warnings)")
    ap.add_argument("--hospitals-only", action="store_true", help="download the US hospitals layer (coordinates, phone, beds, trauma) and rebuild the hospital Excel/KML")
    ap.add_argument("--caves-only", action="store_true", help="list caves within --caves-radius miles (CSV, Excel, KML, GPX) and stop")
    ap.add_argument("--caves-radius", type=float, default=500, help="miles for --caves-only (default 500)")
    ap.add_argument("--places-only", action="store_true",
                    help="build ONLY the wide-area places layer (hospitals, pharmacies, food, gun/pawn shops ... from state map extracts)")
    ap.add_argument("--places-radius", type=float, default=500, help="miles for --places-only (default 500; raise in 100-mile steps)")
    ap.add_argument("--places-states", default="", help="comma list of states for --places-only (default: every state in range)")
    ap.add_argument("--topo-pdf-radius", type=float, default=0,
                    help="miles around home for the printable USGS topo PDF quads only (0 = same as --topo-radius). "
                         "500 = about 12,700 quads, roughly 740 GB; each extra 100 miles adds the outer ring only; keeps 150 GB free")
    ap.add_argument("--flood-radius", type=float, default=40, help="miles around home for FEMA flood zones (default 40)")
    ap.add_argument("--areas", default="bases,cities,water",
                    help="extra topo map areas after everything else: bases (DoD installations in the South + Pendleton/29 Palms), "
                         "cities (major Southern cities + capitals), water (big lakes, bays, sounds, coast). Default: all three")
    ap.add_argument("--city-radius", type=float, default=20, help="miles of topo maps around each city (default 20)")
    ap.add_argument("--base-buffer", type=float, default=5, help="miles of topo maps beyond each base boundary (default 5)")
    ap.add_argument("--no-areas", action="store_true", help="skip the extra city / lake / base topo maps (~250 GB)")
    ap.add_argument("--no-south-tiles", action="store_true", help="skip the South-wide topo map layer (zoom 5-12, ~2 GB)")
    ap.add_argument("--my-files-only", action="store_true", help="just add the files in MY-FILES-INBOX and MY-RADIO-INBOX, rebuild search (no internet)")
    ap.add_argument("--my-radio-only", action="store_true", help="just add the files in MY-RADIO-INBOX, decode CHIRP images, rebuild search (no internet)")
    ap.add_argument("--my-maps-only", action="store_true", help="just add the files in MY-MAPS-INBOX and rebuild the pages (no internet)")
    ap.add_argument("--no-map", action="store_true")
    ap.add_argument("--no-topo", action="store_true", help="skip USGS topo GeoPDFs")
    ap.add_argument("--topo-only", action="store_true",
                    help="download ONLY the topo GeoPDFs (skip the locator, archives, AI, everything else)")
    ap.add_argument("--no-canada", action="store_true",
                    help="skip the Canadian (NRCan) topo sheets for Toronto and Québec City")
    ap.add_argument("--satellite", action="store_true",
                    help="also cache USGS aerial/satellite imagery (NAIP, ~0.6-1 m) for the key areas (large)")
    ap.add_argument("--satellite-only", action="store_true",
                    help="cache ONLY the aerial/satellite imagery (skip everything else)")
    ap.add_argument("--imagery-level", type=int, default=2,
                    help="satellite imagery across the Eastern US + Canada (with --satellite / --satellite-only): 0 region layer off, "
                         "1 overview + routes (~35 GB incl. NAIP detail), 2 + whole region at zoom 13 (~45 GB), "
                         "3 + zoom 14 (~125 GB), 4 + zoom 15 (~450 GB)")
    ap.add_argument("--imagery-hours", type=float, default=0, help="stop the imagery download after this many hours (resumes next run)")
    ap.add_argument("--phone-satellite-only", action="store_true", help="ONLY remake the OsmAnd satellite files for phones (offline)")
    ap.add_argument("--map-sheets-only", action="store_true", help="ONLY remake the printable satellite map PDFs (offline)")
    ap.add_argument("--no-backup", action="store_true", help="don't back up the indexes to BACKUP\\INDEXES at the end")
    ap.add_argument("--fema-only", action="store_true",
                    help="ONLY refresh FEMA shelters / open shelters / recovery centers / disaster declarations and the river charts")
    ap.add_argument("--no-fema", action="store_true", help="skip the FEMA data and river charts")
    ap.add_argument("--ienc-all", action="store_true", help="take every USACE river chart (~109), not just those along the routes")
    ap.add_argument("--us-map", action="store_true",
                    help="also build a whole-US street map layer (streamed from Protomaps; large)")
    ap.add_argument("--us-map-only", action="store_true", help="build ONLY the whole-US street map")
    ap.add_argument("--us-map-zoom", type=int, default=14, help="max zoom for the whole-US street map (default 14)")
    ap.add_argument("--convert-maps-only", action="store_true",
                    help="only convert the OpenStreetMap .pbf files in OSM-MAP-SOURCE into map layers")
    ap.add_argument("--no-tiles", action="store_true", help="skip the topo + hillshade map layers")
    ap.add_argument("--no-flood", action="store_true", help="skip FEMA flood zones")
    ap.add_argument("--no-phone", action="store_true", help="skip phone apps, OsmAnd maps, Meshtastic firmware")
    ap.add_argument("--no-vault", action="store_true", help="skip VeraCrypt")
    ap.add_argument("--no-voice", action="store_true", help="skip whisper speech-to-text")
    ap.add_argument("--no-big", action="store_true", help="skip full Wikipedia, Gutenberg, Khan Academy, Wikibooks (~300 GB)")
    ap.add_argument("--no-zim", action="store_true")
    ap.add_argument("--no-manuals", action="store_true")
    ap.add_argument("--no-ai", action="store_true")
    ap.add_argument("--meaning-hours", type=float, default=3,
                    help="hours per run for the meaning-based search index (resumable; 0 = skip). OCR-OVERNIGHT uses 12+")
    ap.add_argument("--geofabrik", default=None, help="comma list of Geofabrik US regions (e.g. georgia,tennessee); default depends on --profile")
    ap.add_argument("--kolibri-channels", default="", help="Kolibri channel ids to download for offline use (Khan Academy en: c9d7f950ab6b5a1199e3d6c10d7f0103)")
    ap.add_argument("--delete-osm-source", action="store_true", help="(default now) delete each OSM-MAP-SOURCE .pbf once its map layer is built")
    ap.add_argument("--keep-osm-source", action="store_true", help="keep the downloaded .osm.pbf files after they are converted (uses a lot of space)")
    ap.add_argument("--no-mil-pubs", action="store_true", help="skip US Army / Marine Corps publications")
    ap.add_argument("--army-pubs", default="auto", help="auto | all | none | comma list (FM,ADP,ATP,STP,TC,STRAT,TM_CAL,TM_ADMIN,TM_10,TM_1_8,TM_9)")
    ap.add_argument("--no-extras", action="store_true", help="skip DoD Inspector General reports, encyclopedias, TiddlyWiki and Ubuntu")
    ap.add_argument("--no-weather", action="store_true", help="skip the offline weather & almanac page and farmer's almanacs")
    ap.add_argument("--no-languages", action="store_true", help="skip language / sign-language books and gun manuals")
    ap.add_argument("--languages", default="", help="comma list: spanish,french,asl,german,arabic,portuguese,russian,chinese,creole")
    ap.add_argument("--no-software", action="store_true", help="skip the offline program installers (QGIS, LibreOffice, Google Earth...)")
    ap.add_argument("--no-extra-data", action="store_true", help="skip Kolibri, Geofabrik extracts and FCC call signs")
    ap.add_argument("--no-ocr", action="store_true", help="skip OCR of scanned (picture-only) PDFs")
    ap.add_argument("--ham-only", action="store_true", help="just refresh the US + Canadian ham call-sign lookup")
    ap.add_argument("--route-places-only", action="store_true", help="just the places along the get-home routes (incl. Canada), then the guides")
    ap.add_argument("--search-only", action="store_true", help="just rebuild search, the pages, Top 20 and dashboard (offline)")
    ap.add_argument("--ocr-only", action="store_true", help="just OCR scanned PDFs (resumable) and rebuild search")
    ap.add_argument("--ocr-pages", type=int, default=ocr.PER_RUN_DEFAULT,
                    help=f"how many scanned pages to OCR this run (default {ocr.PER_RUN_DEFAULT}; the rest wait, it's resumable)")
    ap.add_argument("--refresh-places", action="store_true", help="re-download all locator places")
    ap.add_argument("--pois-from", help="copy locator data from the NOMAD machine's /opt/offgrid/www/data instead of Overpass")
    ap.add_argument("--no-fetch", action="store_true",
                    help="during a monthly update, skip looking online for newer manuals")
    ap.add_argument("--update", action="store_true",
                    help="monthly update: swap in newer archives, programs, apps and maps; refresh places, flood data and the "
                         "street map when old; retry anything missing. Uses the same options as the last build.")
    a = ap.parse_args()
    sys.modules[__name__].ARGS = a                # for the index backup after main() (any mode)
    if a.satellite_only:
        a.satellite = True
    if a.us_map_only:
        a.us_map = True
    global UPDATE
    UPDATE = a.update

    os.makedirs(a.dest, exist_ok=True)
    set_home(a, ap)
    try:                            # a hard crash (not a normal error) writes where it happened here
        import faulthandler
        os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
        faulthandler.enable(open(os.path.join(a.dest, "REPORTS", "CRASH-LOG.txt"), "a", encoding="utf-8"))
    except Exception:  # noqa: BLE001
        pass
    # The builder must not live inside the drive folder it builds (except the drive's own copy in tools\builder),
    # and the drive folder must not be inside the builder: either way it would copy the drive into itself.
    r, dd = os.path.normcase(os.path.realpath(REPO)), os.path.normcase(os.path.realpath(a.dest))
    own = os.path.normcase(os.path.realpath(os.path.join(a.dest, "tools", "builder")))
    if r != own and (r == dd or r.startswith(dd + os.sep) or dd.startswith(r + os.sep)):
        print(f"\n  !! The builder is in {REPO}, which is inside (or the same as) the drive folder {a.dest}.")
        print("     Windows treats 'offgrid' and 'OFFGRID' as the same folder, so unzipping to E:\\ mixes the builder into the drive.")
        print("     Move the unzipped 'offgrid' folder somewhere else (for example E:\\BUILDER\\offgrid or your laptop's")
        print("     Downloads), delete the builder files it added to the drive (library, scripts, usb, www\\index.html is fine),")
        print("     and run usb\\BUILD-USB-WINDOWS.bat from there.")
        sys.exit(2)
    if a.my_radio_only or a.my_files_only:
        u = sys.modules[__name__]
        radio_img.build(u, a.dest)
        library_inbox.build(u, a.dest)
        personal_files.build(u, a.dest)
        subprocess.call([sys.executable, os.path.join(REPO, "scripts", "build_library.py"),
                         "--lib-dir", os.path.join(a.dest, "www", "library"), "--tsv", os.path.join(REPO, "library", "manuals.tsv")])
        search_index.build(u, a.dest)
        say("Done. Open Home > Library (your files are in their sections; radio channel lists end in '- channel list').")
        return
    if a.my_maps_only:
        say("Adding your maps from MY-MAPS-INBOX")
        mymaps.build(sys.modules[__name__], a.dest)
        try:
            extras.place_exports(sys.modules[__name__], a.dest)
        except Exception as e:  # noqa: BLE001
            print(f"  ! GPS files: {e}")
        search_index.build(sys.modules[__name__], a.dest)
        say("Done. Open www/mymaps/index.html (or Home > My Maps) to see them.")
        return
    opt_file = os.path.join(a.dest, "tools", "build-options.json")
    keep = ("lat", "lon", "label", "zip", "state", "radius", "models", "gpu", "os", "maxzoom", "topo_radius", "topo_pdf_radius", "flood_radius", "areas", "city_radius",
            "base_buffer", "no_areas", "no_south_tiles", "no_map", "no_topo", "profile", "geofabrik", "kolibri_channels", "no_extra_data", "no_software", "no_languages", "no_weather", "no_extras", "languages", "no_mil_pubs", "army_pubs", "delete_osm_source",
            "no_tiles", "no_flood", "no_phone", "no_vault", "no_voice", "no_big", "no_zim", "no_manuals", "no_ai", "no_fema", "ienc_all")
    if a.update:                    # reuse the options of the last full build unless given again on the command line
        try:
            saved = json.load(open(opt_file))
            for k in keep:
                if k in saved and getattr(a, k) == ap.get_default(k):
                    setattr(a, k, saved[k])
        except (OSError, ValueError):
            pass
        apply_profile(a, ap)
        os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
        only = [k for k in ("ham_only", "route_places_only", "search_only", "places_only", "topo_only", "satellite_only", "phone_satellite_only", "map_sheets_only", "fema_only", "us_map_only", "convert_maps_only",
                            "hospitals_only", "caves_only", "meds_only", "ocr_only") if getattr(a, k, False)]
        log = os.path.join(a.dest, "REPORTS", (only[0].upper().replace("_", "-") + "-LOG.txt") if only else "UPDATE-LOG.txt")

        class Tee:
            encoding = getattr(sys.__stdout__, "encoding", None) or "utf-8"
            errors = "replace"
            def isatty(self): return False
            def fileno(self): return sys.__stdout__.fileno()
            def __init__(self, *s): self.s = s
            def write(self, x):
                for st in self.s:
                    try:
                        st.write(x)
                    except Exception:  # noqa: BLE001
                        pass
            def flush(self):
                for st in self.s:
                    try:
                        st.flush()
                    except Exception:  # noqa: BLE001
                        pass
        sys.stdout = Tee(sys.__stdout__, open(log, "w", encoding="utf-8"))
        print(f"OFF-GRID DRIVE UPDATE - {time.strftime('%Y-%m-%d %H:%M')}")
    else:
        apply_profile(a, ap)
        try:                        # keep a log of every build too, so a window that closed can still be read afterwards
            os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
            _lf = open(os.path.join(a.dest, "REPORTS", "BUILD-LOG.txt"), "a", encoding="utf-8", buffering=1)
            _lf.write(f"\n===== BUILD {time.strftime('%Y-%m-%d %H:%M')} =====\n")

            class _Tee:
                encoding = getattr(sys.__stdout__, "encoding", None) or "utf-8"
                errors = "replace"

                def isatty(self):
                    return False

                def fileno(self):
                    return sys.__stdout__.fileno()

                def write(self, x):
                    for st in (sys.__stdout__, _lf):
                        try:
                            st.write(x)
                        except Exception:  # noqa: BLE001
                            pass
                def flush(self):
                    for st in (sys.__stdout__, _lf):
                        try:
                            st.flush()
                        except Exception:  # noqa: BLE001
                            pass
            sys.stdout = _Tee()
        except OSError:
            pass
        try:
            os.makedirs(os.path.dirname(opt_file), exist_ok=True)
            with open(opt_file, "w") as fh:
                json.dump({k: getattr(a, k) for k in keep}, fh, indent=1)
        except OSError:
            pass
    print(f"OFF-GRID USB builder -> {a.dest}   ({free_gb(a.dest):.0f} GB free)")
    harden_ssl()
    need = (0 if a.no_ai else sum(MODELS.get(m, ("", 5))[1] for m in a.models.split(","))) + (0 if a.no_zim else 25) + \
           (0 if a.no_map else 5) + (0 if a.no_manuals else 5) + (0 if a.no_topo else 10) + (0 if a.no_tiles else 2) + \
           (0 if a.no_phone else 2) + (0 if a.no_zim or a.no_big else 300) + (0 if a.no_topo or a.no_areas else 250) + 2
    big_p = a.profile in ("large", "full")
    gf = geofab(a)
    need += (0 if a.no_mil_pubs else {"medium": 10, "large": 40, "full": 120}.get(a.profile, 0)) + \
            (0 if a.no_software else (35 if big_p else 8)) + \
            (0 if a.no_languages or a.no_manuals else {"small": 1, "medium": 2, "large": 6, "full": 12}.get(a.profile, 0)) + \
            (0 if a.no_extra_data else 1.5 * len([x for x in gf.split(",") if x.strip()]) + 1) + (0 if a.no_weather else 1)
    for d in ("MY-FILES-INBOX", "MY-PERSONAL-FILES-INBOX", "MY-MAPS-INBOX", "MY-RADIO-INBOX", "OSM-MAP-SOURCE"):
        try:
            os.makedirs(os.path.join(a.dest, d), exist_ok=True)
        except OSError:
            pass
    if a.places_only:
        print("  Places-only run: building just the regional places layer (no other content).")
    elif a.topo_only:
        print("  Topo-only run: downloading just the USGS topo maps (no locator, archives, AI or other content).")
    elif free_gb(a.dest) < need:
        print(f"  ! You may need about {need:.0f} GB; skip the biggest part with --no-big (~300 GB of Wikipedia/books/videos).")
    else:
        print(f"  Full build is roughly {need:.0f} GB. The first run takes many hours; stop any time and re-run to resume.")
    bins = [b.strip() for b in a.os.split(",") if b.strip()]

    copy_repo(a.dest)
    try:
        launchers(a.dest)        # START-HERE.bat and the drive's programs are usable from the first minute
        print(f"  START-HERE.bat is ready in {a.dest}")
    except Exception as e:  # noqa: BLE001
        print(f"  ! launchers: {type(e).__name__}: {e}")
    vendor(a.dest)
    if a.topo_only or a.places_only or a.caves_only or a.hospitals_only or a.meds_only or a.search_only or a.convert_maps_only or a.route_places_only or a.ham_only \
            or a.phone_satellite_only or a.map_sheets_only or a.satellite_only or a.fema_only:
        pass                                     # topo-only: skip the locator / route-POI (Overpass) fetch entirely
    elif a.pois_from:
        say("Copying locator data"); shutil.copytree(a.pois_from, os.path.join(a.dest, "www", "data"), dirs_exist_ok=True)
    elif (not os.path.exists(os.path.join(a.dest, "www", "data", "pois.js"))
          or not os.path.isdir(os.path.join(a.dest, "www", "data", "overpass"))   # built by an older version
          or os.path.exists(os.path.join(a.dest, "www", "data", "overpass", "INCOMPLETE")) or a.refresh_places
          or any(not os.path.exists(os.path.join(a.dest, "www", "data", "overpass", f"{g}_{k}_{int(a.radius)}.json"))   # a new kind of place
                 for g, fl in QUERIES.items() for k in range(len(fl)))
          or (not a.no_topo and not a.no_areas                                        # resources along the get-home routes not fetched yet
              and any(not os.path.exists(os.path.join(a.dest, "www", "data", "overpass", f"route{ci}_{g}_{k}.json"))
                      for ci in range(len(routes_data.poi_centers())) for g in ROUTE_POI_GROUPS for k in range(len(QUERIES[g]))))
          or (a.update and age_days(os.path.join(a.dest, "www", "data", "pois.js")) > 90)):
        if a.update and not a.refresh_places and age_days(os.path.join(a.dest, "www", "data", "pois.js")) > 90:
            print("  Places list is over 3 months old - refreshing (stores, fuel, clinics change)")
            a.refresh_places = True
        if a.refresh_places:
            shutil.rmtree(os.path.join(a.dest, "www", "data", "overpass"), ignore_errors=True)
        rc = None if (a.no_topo or a.no_areas) else routes_data.poi_centers()
        overpass_pois(a.dest, a.lat, a.lon, a.radius, a.label, route_centers=rc)
    u = sys.modules[__name__]
    failed = []

    def step(name, fn, *args):
        """Run one build step; if it fails, report it and keep going with the rest."""
        try:
            fn(*args)
        except KeyboardInterrupt:
            raise
        except Exception as e:  # noqa: BLE001
            import traceback
            print(f"\n  !! Step '{name}' failed: {type(e).__name__}: {e}")
            print("     " + traceback.format_exc().strip().splitlines()[-3].strip())
            failed.append(name)
            if not os.path.isdir(a.dest):            # the drive itself went away: every later step would fail too
                print(f"\n  !! {a.dest} can no longer be reached - the drive disconnected. Nothing finished is lost.\n"
                      "     Reconnect it (try another USB port or cable, a powered hub for big drives), then run the builder again.")
                sys.exit(3)
            print("     Continuing with the next step - re-run the builder later to retry this one.")

    if a.meds_only:                              # ADD-MEDICINES
        step("Medicine list", meds_data.build, u, a.dest)
        say("Medicines done." if not failed else "Medicines done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.hospitals_only:                         # ADD-HOSPITALS
        step("US hospitals layer", hospitals_hifld.build, u, a.dest)
        step("Hospital Excel + Google Earth files", hospitals_data.build, u, a.dest)
        say("Hospitals done." if not failed else "Hospitals done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.caves_only:                             # ADD-CAVES: one quick query, no other downloads
        step("Caves within %g miles" % a.caves_radius, caves.run, u, a.dest, a.lat, a.lon, a.caves_radius)
        say("Caves done." if not failed else "Caves done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.places_only:                            # ADD-PLACES-500-MILES: just the regional places layer
        step("Places within %g miles" % a.places_radius, regional_pois.run, u, a.dest, a.lat, a.lon, a.places_radius,
             [x.strip() for x in a.places_states.split(",") if x.strip()] or None, a.keep_osm_source)
        step("Pages + search index", finish, a.dest)
        say("Places layer done." if not failed else "Places layer done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.topo_only:                              # ADD-TOPO-MAPS: just the topo GeoPDFs, nothing else
        if not a.no_topo:
            step("Topo GeoPDFs around home", extras.topo_pdfs, u, a.dest, a.lat, a.lon, a.topo_pdf_radius or a.topo_radius)
        if not a.no_topo and not a.no_areas:
            kinds = [k.strip() for k in a.areas.split(",") if k.strip()]
            sites = areas.military(u, a.dest) if "bases" in kinds else []
            step("Topo maps: bases, cities, lakes", extras.topo_areas, u, a.dest,
                 areas.area_list(sites, kinds, a.city_radius, a.base_buffer, **area_kw(a)) + routes_data.topo_spots())
        if not a.no_topo and not a.no_canada:
            step("Canadian topo (Toronto, Québec City)", canada_topo.add_canada_topo, u, a.dest)
        step("Pages + search index", finish, a.dest)
        say("Topo maps done." if not failed else "Topo maps done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.phone_satellite_only or a.map_sheets_only:   # offline: remake from the imagery already on the drive
        if a.phone_satellite_only:
            step("Satellite files for phones", imagery.phone_packs, u, a.dest, None, _home(a))
        if a.map_sheets_only:
            step("Printable satellite maps", map_sheets.build, u, a.dest, None, _home(a))
        say("Done.")
        return

    if a.satellite_only:                         # ADD-SATELLITE-IMAGERY: just the aerial imagery
        sites = areas.military(u, a.dest) if "bases" in a.areas else []
        _imagery_steps(a, step, sites)
        step("Pages + search index", finish, a.dest)
        say("Satellite imagery done." if not failed else "Satellite imagery done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.us_map_only:                            # ADD-US-STREET-MAP: just the whole-US street layer
        step("Whole-US street map", us_street_map, a.dest, a.us_map_zoom)
        step("Pages + search index", finish, a.dest)
        say("US street map done." if not failed else "US street map done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.convert_maps_only:                      # CONVERT-OSM-MAPS: just convert dropped-in .pbf files
        step("Convert OSM map files", pbf_convert.build, u, a.dest, not a.keep_osm_source)
        step("Pages + search index", finish, a.dest)
        say("OSM conversion done." if not failed else "OSM conversion done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.fema_only:                              # UPDATE-FEMA-AND-RIVER-CHARTS
        step("FEMA shelters, recovery centers, declarations", fema_data.build, u, a.dest)
        step("River charts (IENC)", ienc.build, u, a.dest, a.ienc_all)
        step("Printable satellite maps", map_sheets.build, u, a.dest, None, _home(a))   # adds the shelters to the sheets
        step("Pages + search index", finish_light, a.dest)
        say("FEMA data done." if not failed else "FEMA data done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.ham_only:                               # UPDATE-HAM-CALL-SIGNS
        step("FCC ham call signs", more_data.hamcalls, u, a.dest)
        step("Canadian ham call signs", more_data.hamcalls_canada, u, a.dest)
        more_data.ham_page(a.dest)
        say("Call signs done." if not failed else "Call signs done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.route_places_only:                      # ADD-ROUTE-PLACES: places along every get-home route, incl. Canada
        import corridor_pois
        step("Places along the get-home routes", corridor_pois.run, u, a.dest)
        import survival_guide
        step("Survival guides", survival_guide.build_all, a.dest)
        say("Route places done." if not failed else "Route places done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.search_only:                            # REBUILD-SEARCH: re-read files into search, remake pages (offline)
        step("Pages + search index", finish, a.dest)
        say("Search and pages rebuilt." if not failed else "Rebuilt, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.ocr_only:                               # ADD-OCR: just OCR scanned PDFs (resumable), then rebuild search
        step("OCR scanned PDFs", ocr_child, a.dest, a.ocr_pages)
        step("Pages + search index", finish, a.dest)
        if a.meaning_hours > 0:
            step("Meaning-based search", semantic.build, u, a.dest, max(a.meaning_hours, 12))   # overnight: no rush
        say("OCR pass done." if not failed else "OCR pass done, with problems in: " + ", ".join(dict.fromkeys(failed)))
        return

    if a.update and not a.no_fetch and not a.no_manuals:
        step("Find newer manuals online", fetch_new.build, u, a.dest)   # may add rows to manuals.tsv before the download below
    if not a.no_manuals:
        step("Manuals library", manuals, a.dest)
    if not a.no_mil_pubs and not a.no_manuals and a.army_pubs != "none":
        step("US Army & Marine Corps publications", army_pubs.build, u, a.dest, a.profile, a.army_pubs, True)
        step("DoD doctrine from FAS (no duplicates)", fas_doddir.build, u, a.dest, a.profile, "", None, False, REPO)
        if a.profile in ("medium", "large", "full"):
            step("Joint Force & service doctrine", joint_doctrine.build, u, a.dest)
    if not a.no_extras and not a.no_manuals:
        step("Reports, encyclopedias, TiddlyWiki" + (", Ubuntu" if a.profile == "full" else ""), library_extras.build, u, a.dest, a.profile)
    if not a.no_weather:
        step("Offline weather & almanac page", weather.build, u, a.dest)
        if not a.no_manuals:
            step("Farmer's almanacs", almanacs.build, u, a.dest, a.profile)
    if not a.no_languages and not a.no_manuals:
        step("Language & sign-language books", languages.build, u, a.dest, a.profile,
             a.languages or languages.DEFAULT_LANGS, a.profile in ("large", "full"))
    else:
        subprocess.call([sys.executable, os.path.join(REPO, "scripts", "build_library.py"),
                         "--lib-dir", os.path.join(a.dest, "www", "library"), "--tsv", os.path.join(REPO, "library", "manuals.tsv")])
    step("Ask-the-Library index", ask_index, a.dest, a.label)
    if not a.no_ai:
        step("AI", ai, a.dest, [m.strip() for m in a.models.split(",") if m.strip()], bins, a.gpu)
    step("Military bases", areas.military, u, a.dest)
    step("Pages + search index", finish_light, a.dest)           # early, so the drive is usable even if a later step stops
    if not a.no_zim:
        step("Kiwix archives", kiwix, a.dest, profile_zims(a.profile), bins)
        step("Portable Kiwix reader", extras.kiwix_desktop, u, a.dest, bins)
    if not a.no_ai and not a.no_voice:
        step("Voice input", extras.voice, u, a.dest, bins)
    if not a.no_map:
        step("Street map", street_map, a.dest, a.lat, a.lon, a.radius, a.maxzoom)
        if a.us_map:
            step("Whole-US street map", us_street_map, a.dest, a.us_map_zoom)
        if not a.no_extra_data:
            step("Geofabrik regional extracts", more_data.geofabrik, u, a.dest,
                 geofab(a))
        step("Convert dropped-in OSM map files", pbf_convert.build, u, a.dest, not a.keep_osm_source)   # no-op unless OSM-MAP-SOURCE has .pbf
    if not a.no_tiles:
        step("Terrain layer", extras.tiles, u, a.dest, "hillshade", a.lat, a.lon, a.radius, 5, 12)
        step("Topo layer", extras.tiles, u, a.dest, "topo", a.lat, a.lon, a.topo_radius, 8, 15)
        if not a.no_south_tiles:
            step("South topo layer", extras.tiles, u, a.dest, "topo-south", a.lat, a.lon, 0, 5, 12, region.region_bbox(a.lat, a.lon) if a.state else areas.SOUTH_BBOX)
    if not a.no_flood:
        step("Flood zones", extras.flood_zones, u, a.dest, a.lat, a.lon, a.flood_radius)
    if not a.no_phone:
        step("Phone apps", extras.phone_apps, u, a.dest)
    if not a.no_vault:
        step("VeraCrypt", extras.vault_tools, u, a.dest)
    if not a.no_phone:
        step("VLC + SumatraPDF", extras.players, u, a.dest, bins)
    if not a.no_software:
        step("Offline program installers", offline_software.build, u, a.dest, a.profile in ("large", "full"))
    if not a.no_topo:
        step("Topo GeoPDFs", extras.topo_pdfs, u, a.dest, a.lat, a.lon, a.topo_pdf_radius or a.topo_radius)
    if not a.no_manuals:
        step("E-books", extras.ebooks, u, a.dest)
    if not a.no_ocr:
        step("OCR scanned PDFs", ocr_child, a.dest, a.ocr_pages)   # merges into the search index at the next finish
    step("Pages + search index", finish_light, a.dest)
    if not a.no_extra_data:
        step("FCC ham call signs", more_data.hamcalls, u, a.dest)
        step("Canadian ham call signs", more_data.hamcalls_canada, u, a.dest)
        if not a.no_fema:
            step("FEMA shelters, recovery centers, declarations", fema_data.build, u, a.dest)
            step("River charts (IENC)", ienc.build, u, a.dest, a.ienc_all)
        step("Kolibri", more_data.kolibri, u, a.dest, a.kolibri_channels)
        step("Pages + search index", finish_light, a.dest)
    if not a.no_zim and not a.no_big:
        step("Large archives", extras.kiwix_big, u, a.dest)
        step("Pages + search index", finish_light, a.dest)
    if not a.no_topo and not a.no_areas:
        kinds = [k.strip() for k in a.areas.split(",") if k.strip()]
        sites = areas.military(u, a.dest) if "bases" in kinds else []
        step("Topo maps: bases, cities, lakes", extras.topo_areas, u, a.dest,
             areas.area_list(sites, kinds, a.city_radius, a.base_buffer, **area_kw(a)) + routes_data.topo_spots())
        step("Pages + search index", finish_light, a.dest)
    if not a.no_topo and not a.no_canada:
        step("Canadian topo (Toronto, Québec City)", canada_topo.add_canada_topo, u, a.dest)
        step("Pages + search index", finish_light, a.dest)
    if a.satellite:
        sat_sites = areas.military(u, a.dest) if "bases" in a.areas else []
        _imagery_steps(a, step, sat_sites)
        step("Pages + search index", finish_light, a.dest)
    if os.path.exists(os.path.join(a.dest, "www", "data", "corridors", "index.js")) and not a.no_extra_data:
        import corridor_pois                               # route places were added once: keep them current (cached per state)
        step("Places along the get-home routes", corridor_pois.run, u, a.dest)
    step("Pages + search index", finish, a.dest)           # the one full pass: indexes, exports and catalogs, once, at the very end
    if not a.no_ai and a.meaning_hours > 0:
        step("Meaning-based search", semantic.build, u, a.dest, a.meaning_hours)   # after the search index; resumable
    if failed:
        say("Finished with problems in: " + ", ".join(dict.fromkeys(failed)))
        print("  Everything else is done. Re-run the builder to retry those steps (finished files are skipped).")
    if a.update:
        say(f"Update summary: {len(CHANGES)} new or updated files")
        for n in CHANGES[:60]:
            print(f"  + {n}")
        if len(CHANGES) > 60:
            print(f"  ... and {len(CHANGES) - 60} more")
        if not CHANGES:
            print("  Everything was already current.")
        print(f"  Full log: {os.path.join(a.dest, 'REPORTS', 'UPDATE-LOG.txt')}")
        try:
            subprocess.call([sys.executable, os.path.join(HERE, "check_usb.py"), "--dest", a.dest])
        except OSError:
            pass
    say("Done. Plug the drive into any computer and run START-HERE.bat (Windows) or start-here-mac-linux.sh (Mac/Linux).")
    print("  Re-run this builder any time to resume downloads or refresh - finished files are skipped.")


def _auto_backup():
    """After every build / update / -only run: back up the indexes and settings (skipped when nothing changed)."""
    a = globals().get("ARGS")
    if not a or getattr(a, "no_backup", False) or not os.path.isdir(os.path.join(a.dest, "www")):
        return
    try:
        import index_backup
        say("Backing up the indexes (BACKUP\\INDEXES)")
        index_backup.backup(a.dest)
    except Exception as e:  # noqa: BLE001
        print(f"  ! index backup: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
    _auto_backup()          # only after a run that finished (a crash never replaces a good backup with a half-built index)
