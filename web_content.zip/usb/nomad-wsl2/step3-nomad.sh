#!/bin/bash
# Runs inside Ubuntu as user "nomad": the official NOMAD installer, unchanged. Asks you to accept the license.
set -e
sudo apt-get update
sudo apt-get install -y curl
cd ~
curl -fsSL https://raw.githubusercontent.com/Crosstalk-Solutions/project-nomad/refs/heads/main/install/install_nomad.sh -o install_nomad.sh
sudo bash install_nomad.sh
