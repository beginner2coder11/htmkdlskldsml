#!/bin/bash
# Runs inside Ubuntu as root. Turns on systemd + shared mounts (needed by NOMAD) and makes a normal user "nomad".
set -e
WANT=$'[boot]\nsystemd=true\ncommand="mount --make-rshared /"'
if ! grep -q '^systemd=true' /etc/wsl.conf 2>/dev/null || ! grep -q 'make-rshared' /etc/wsl.conf 2>/dev/null; then
  [ -f /etc/wsl.conf ] && cp /etc/wsl.conf /etc/wsl.conf.bak
  printf '%s\n' "$WANT" > /etc/wsl.conf
  CHANGED=1
fi
if ! id nomad >/dev/null 2>&1; then
  useradd -m -s /bin/bash -G sudo nomad
  echo 'nomad ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/nomad
  chmod 440 /etc/sudoers.d/nomad
fi
[ "$CHANGED" = 1 ] && exit 10
exit 0
