#!/bin/bash
# Runs inside Ubuntu as root. Native Docker (not snap, not Docker Desktop).
set -e
export DEBIAN_FRONTEND=noninteractive
if [ "$(ps -p 1 -o comm= 2>/dev/null)" != "systemd" ]; then echo "systemd is not running in this Ubuntu"; exit 20; fi
if command -v snap >/dev/null 2>&1 && snap list 2>/dev/null | grep -q '^docker'; then snap remove --purge docker; fi
if ! command -v docker >/dev/null 2>&1; then
  apt-get update
  apt-get install -y curl ca-certificates
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker
usermod -aG docker nomad
mount --make-rshared / || true
systemctl disable --now ollama 2>/dev/null || true      # NOMAD runs its own Ollama on port 11434
docker info >/dev/null
echo "Docker is running."
