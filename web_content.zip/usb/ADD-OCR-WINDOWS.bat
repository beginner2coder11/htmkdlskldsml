@echo off
REM Make scanned (picture-only) PDFs searchable: run OCR on them and fold the text into search.
REM Skips every other build step. RESUMABLE - it does a few thousand pages at a time and picks up where it
REM left off, so you can close it and run it again (or let the monthly build keep chipping away).
REM The first run on Windows tries to fetch Tesseract + Poppler automatically.
REM Optional: pass the drive letter, e.g.  ADD-OCR-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
echo.
echo  OCR of scanned PDFs on %DRIVE%:\OFFGRID  (nothing else will download)
echo  Picture-only manuals become full-text searchable. Safe to close and re-run - it resumes.
echo  See REPORTS\OCR-REPORT.txt afterward for how many pages are done and how many remain.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --ocr-only
pause
