# -*- coding: utf-8 -*-
"""Printable satellite map sheets: one PDF for home and one per get-home route, in  <drive>\\PRINTABLE MAPS\\.

Each route PDF = an overview page (the whole route with numbered sheet outlines) + strip sheets along the route,
overlapping, in driving order from the work city toward home. Each sheet: satellite imagery from the drive,
the route line, key spots (border crossings, chokepoints, refuel hubs), places along the way from the
"Places along the routes" data (water, hospitals, fuel, shelters...), town names, a lat/long grid with edge labels,
scale bar and north arrow. Letter size, landscape, 200 dpi. Works with nothing but a printer — or no power at all
once printed.

Only uses what is already on the drive (imagery.Reader); areas with no imagery print dark gray.
"""
import csv, glob, json, math, os, re, time

import imagery

DPI = 200
PAGE = (2200, 1700)                    # 11 x 8.5 in at 200 dpi
M_L, M_T, M_R, M_B = 130, 160, 100, 150  # margins: grid labels + title band + legend band
MAP_W, MAP_H = PAGE[0] - M_L - M_R, PAGE[1] - M_T - M_B
ROUTE_Z = 12                           # ~30 m per pixel: about 40 x 28 miles per sheet
CAT = {   # category: (color, letter, legend)
    "hospital": ((230, 60, 60), "H", "Hospital"), "urgent_care": ((230, 110, 90), "U", "Urgent care"),
    "clinic": ((230, 140, 120), "C", "Clinic"), "pharmacy": ((60, 200, 120), "Rx", "Pharmacy"),
    "water": ((70, 170, 255), "W", "Water"), "shelter": ((250, 200, 60), "S", "Shelter"),
    "fuel": ((255, 150, 40), "F", "Fuel"), "grocery": ((160, 220, 90), "G", "Grocery"),
    "food_dist": ((160, 220, 90), "Fd", "Food bank"), "police": ((120, 140, 255), "P", "Police"),
    "fire": ((255, 90, 50), "Fi", "Fire station")}
SPOT = {"border": ((255, 255, 255), "Border"), "choke": ((255, 70, 70), "Chokepoint"),
        "hub": ((90, 220, 255), "Refuel / rest"), "river": ((80, 160, 255), "River crossing")}


# --------------------------------------------------------------------------- projection helpers (global pixel space at zoom z)
def gpx(lat, lon, z):
    n = 256 * 2 ** z
    lat = max(-85.05, min(85.05, lat))
    return (lon + 180) / 360 * n, (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n


def glatlon(px, py, z):
    n = 256 * 2 ** z
    return math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * py / n)))), px / n * 360 - 180


def m_per_px(lat, z):
    return 156543.034 * math.cos(math.radians(lat)) / 2 ** z


def _font(PIL, size, bold=False):
    from PIL import ImageFont
    for f in (("arialbd.ttf" if bold else "arial.ttf"), ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"),
              "C:/Windows/Fonts/" + ("arialbd.ttf" if bold else "arial.ttf"),
              "/usr/share/fonts/truetype/dejavu/" + ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")):
        try:
            return ImageFont.truetype(f, size)
        except OSError:
            pass
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


# --------------------------------------------------------------------------- data on the drive
def towns(dest):
    """[(name, lat, lon, population)] — US towns from the builder's city list + main Canadian cities."""
    out = []
    for p in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "us-cities.csv"),
              os.path.join(dest, "tools", "builder", "usb", "data", "us-cities.csv")):
        if os.path.exists(p):
            with open(p, encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    try:
                        out.append((r["city"], float(r["lat"]), float(r["lng"]), int(float(r["population"] or 0))))
                    except (KeyError, ValueError):
                        pass
            break
    try:
        import survival_guide
        seen = set()
        for name, la, lo in survival_guide.CANADA_CITIES.values():
            if name not in seen:
                seen.add(name)
                out.append((name.split(",")[0], la, lo, 200000))
    except Exception:  # noqa: BLE001
        pass
    return out


def corridor_places(dest, key):
    p = os.path.join(dest, "www", "data", "corridors", key + ".js")
    try:
        txt = open(p, encoding="utf-8").read()
        return json.loads(txt[txt.index("=", txt.index("]")) + 1:].rstrip().rstrip(";"))["rows"]
    except (OSError, ValueError):
        return []


def fema_shelters(dest):
    """FEMA registered shelters (fema_data.py) as place rows: ["shelter", name, lat, lon]."""
    try:
        t = open(os.path.join(dest, "www", "data", "fema.js"), encoding="utf-8").read()
        return [["shelter", "FEMA shelter: " + r[0], r[1], r[2]] for r in json.loads(t[t.index("=") + 1:].rstrip().rstrip(";"))["shelters"]]
    except (OSError, ValueError, KeyError, TypeError):
        return []


# --------------------------------------------------------------------------- one sheet
class Sheet:
    def __init__(self, PIL, rd, cx, cy, z):
        """cx, cy: map centre in global pixels at zoom z."""
        from PIL import Image, ImageDraw
        self.PIL, self.z = PIL, z
        self.x0, self.y0 = cx - MAP_W / 2, cy - MAP_H / 2
        self.img = Image.new("RGB", PAGE, (255, 255, 255))
        mp = Image.new("RGB", (MAP_W, MAP_H), (40, 42, 46))
        tx0, ty0 = int(self.x0 // 256), int(self.y0 // 256)
        tx1, ty1 = int((self.x0 + MAP_W) // 256), int((self.y0 + MAP_H) // 256)
        self.have = self.total = 0
        import io
        for tx in range(tx0, tx1 + 1):
            for ty in range(ty0, ty1 + 1):
                self.total += 1
                if not (0 <= ty < 2 ** z):
                    continue
                data = rd.get(z, tx % 2 ** z, ty)
                if not data:
                    continue
                try:
                    t = Image.open(io.BytesIO(data)).convert("RGB")
                except Exception:  # noqa: BLE001
                    continue
                if t.size != (256, 256):
                    t = t.resize((256, 256))
                mp.paste(t, (int(tx * 256 - self.x0), int(ty * 256 - self.y0)))
                self.have += 1
        self.img.paste(mp, (M_L, M_T))
        self.d = ImageDraw.Draw(self.img)
        self.f = {s: _font(PIL, s) for s in (20, 24, 28, 34)}
        self.fb = {s: _font(PIL, s, True) for s in (22, 26, 30, 44)}

    def xy(self, lat, lon):
        px, py = gpx(lat, lon, self.z)
        return px - self.x0 + M_L, py - self.y0 + M_T

    def inside(self, x, y, pad=0):
        return M_L + pad <= x <= M_L + MAP_W - pad and M_T + pad <= y <= M_T + MAP_H - pad

    def label(self, x, y, text, font, fill=(255, 255, 255), dx=12, dy=-14):
        x, y = x + dx, y + dy
        bb = self.d.textbbox((x, y), text, font=font)
        if bb[2] > M_L + MAP_W:
            x -= (bb[2] - bb[0]) + 2 * dx
            bb = self.d.textbbox((x, y), text, font=font)
        self.d.rectangle((bb[0] - 4, bb[1] - 3, bb[2] + 4, bb[3] + 3), fill=(0, 0, 0))
        self.d.text((x, y), text, font=font, fill=fill)
        return bb

    def line(self, pts, color=(255, 60, 60), width=7):
        xy = [self.xy(a, b) for a, b in pts]
        self.d.line(xy, fill=(255, 255, 255), width=width + 4, joint="curve")
        self.d.line(xy, fill=color, width=width, joint="curve")

    def grid(self):
        """Lat/long lines with labels in the margins (decimal degrees and degrees-minutes)."""
        W, H = PAGE                                  # clip: anything drawn past the map frame is painted over
        for box in ((0, 0, W, M_T - 1), (0, M_T + MAP_H + 1, W, H), (0, 0, M_L - 1, H), (M_L + MAP_W + 1, 0, W, H)):
            self.d.rectangle(box, fill=(255, 255, 255))
        la_t, lo_l = glatlon(self.x0, self.y0, self.z)
        la_b, lo_r = glatlon(self.x0 + MAP_W, self.y0 + MAP_H, self.z)
        span = lo_r - lo_l
        step = next((s for s in (0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.25, 0.5, 1, 2, 5, 10) if span / s <= 8), 20)
        f = self.f[20]

        def dm(v, pos, neg):
            h = pos if v >= 0 else neg
            v = abs(v)
            return f"{int(v)}°{(v - int(v)) * 60:04.1f}'{h}"
        lo = math.ceil(lo_l / step) * step
        while lo < lo_r:
            x, _ = self.xy(la_t, lo)
            self.d.line((x, M_T, x, M_T + MAP_H), fill=(255, 255, 255), width=1)
            for yy in (M_T - 28, M_T + MAP_H + 6):
                self.d.text((x - 50, yy), f"{lo:.3f}", font=f, fill=(0, 0, 0))
            self.d.text((x - 50, M_T + MAP_H + 28), dm(lo, "E", "W"), font=f, fill=(90, 90, 90))
            lo += step
        la = math.ceil(la_b / step) * step
        while la < la_t:
            _, y = self.xy(la, lo_l)
            self.d.line((M_L, y, M_L + MAP_W, y), fill=(255, 255, 255), width=1)
            self.d.text((4, y - 24), f"{la:.3f}", font=f, fill=(0, 0, 0))
            self.d.text((4, y + 2), dm(la, "N", "S")[:-1], font=f, fill=(90, 90, 90))
            self.d.text((M_L + MAP_W + 4, y - 12), f"{la:.2f}", font=f, fill=(0, 0, 0))
            la += step
        self.d.rectangle((M_L, M_T, M_L + MAP_W, M_T + MAP_H), outline=(0, 0, 0), width=3)

    def towns(self, tl, minpop, limit=40):
        boxes, n = [], 0
        for name, la, lo, pop in sorted(tl, key=lambda r: -r[3]):
            if pop < minpop or n >= limit:
                break
            x, y = self.xy(la, lo)
            if not self.inside(x, y, 20):
                continue
            bb = self.d.textbbox((x + 8, y - 12), name, font=self.fb[22])
            if any(not (bb[2] < b[0] or bb[0] > b[2] or bb[3] < b[1] or bb[1] > b[3]) for b in boxes):
                continue
            self.d.ellipse((x - 5, y - 5, x + 5, y + 5), fill=(255, 255, 255), outline=(0, 0, 0))
            boxes.append(self.label(x, y, name, self.fb[22], (255, 255, 210), 8, -12))
            n += 1
        return boxes

    def places(self, rows, taken, limit_labels=30):
        used = set()
        lab = 0
        for row in rows:
            cat, name, la, lo = row[0], row[1], row[2], row[3]
            if cat not in CAT:
                continue
            x, y = self.xy(la, lo)
            if not self.inside(x, y, 10):
                continue
            col, letter, _ = CAT[cat]
            self.d.ellipse((x - 13, y - 13, x + 13, y + 13), fill=col, outline=(0, 0, 0), width=2)
            w = self.d.textlength(letter, font=self.fb[22])
            self.d.text((x - w / 2, y - 13), letter, font=self.fb[22], fill=(0, 0, 0))
            used.add(cat)
            if lab < limit_labels and name and cat in ("hospital", "water", "shelter", "food_dist", "urgent_care"):
                text = name if len(name) <= 26 else name[:25] + "…"
                bb = self.d.textbbox((x + 16, y - 10), text, font=self.f[20])
                if not any(not (bb[2] < b[0] or bb[0] > b[2] or bb[3] < b[1] or bb[1] > b[3]) for b in taken):
                    taken.append(self.label(x, y, text, self.f[20], col, 16, -10))
                    lab += 1
        return used

    def spots(self, spots, taken):
        for s in spots:
            x, y = self.xy(s["lat"], s["lon"])
            if not self.inside(x, y):
                continue
            col = SPOT.get(s.get("kind"), ((255, 255, 255), ""))[0]
            self.d.polygon([(x, y - 18), (x + 16, y + 12), (x - 16, y + 12)], fill=col, outline=(0, 0, 0))
            taken.append(self.label(x, y, s["name"], self.fb[22], col, 18, -32))

    def furniture(self, title, sub, legend_cats=(), spot_kinds=(), credit=""):
        d, W = self.d, PAGE[0]
        d.text((M_L, 22), title, font=self.fb[44], fill=(0, 0, 0))
        d.text((M_L, 78), sub, font=self.f[24], fill=(60, 60, 60))
        # north arrow
        ax, ay = W - M_R - 40, 30
        d.polygon([(ax, ay), (ax + 18, ay + 50), (ax, ay + 38), (ax - 18, ay + 50)], fill=(0, 0, 0))
        d.text((ax - 9, ay + 52), "N", font=self.fb[22], fill=(0, 0, 0))
        # scale bar
        la, _ = glatlon(self.x0 + MAP_W / 2, self.y0 + MAP_H / 2, self.z)
        mpp = m_per_px(la, self.z)
        target = MAP_W * mpp / 5 / 1609.34
        mi = next((s for s in (0.1, 0.25, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500) if s >= target * .6), 1000)
        px = mi * 1609.34 / mpp
        bx, by = W - M_R - px - 260, PAGE[1] - 70
        for i in range(4):
            d.rectangle((bx + px * i / 4, by, bx + px * (i + 1) / 4, by + 14), fill=(0, 0, 0) if i % 2 == 0 else (255, 255, 255),
                        outline=(0, 0, 0))
        d.text((bx, by - 30), "0", font=self.f[20], fill=(0, 0, 0))
        d.text((bx + px - 20, by - 30), f"{mi:g} mi", font=self.f[20], fill=(0, 0, 0))
        km = mi * 1.609
        d.text((bx, by + 18), f"= {km:.1f} km   ·   1 in ≈ {mpp * DPI / 1609.34:.2f} mi", font=self.f[20], fill=(60, 60, 60))
        # legend
        x, y = M_L, PAGE[1] - 108
        for k in spot_kinds:
            col, txt = SPOT[k]
            d.polygon([(x + 12, y), (x + 24, y + 22), (x, y + 22)], fill=col, outline=(0, 0, 0))
            d.text((x + 30, y), txt, font=self.f[20], fill=(0, 0, 0)); x += 60 + d.textlength(txt, font=self.f[20])
        for c in [c for c in CAT if c in legend_cats]:
            col, letter, txt = CAT[c]
            if x > W - 900:
                x, y = M_L, y + 34
            d.ellipse((x, y, x + 24, y + 24), fill=col, outline=(0, 0, 0))
            d.text((x + 30, y), f"{letter} {txt}", font=self.f[20], fill=(0, 0, 0)); x += 60 + d.textlength(f"{letter} {txt}", font=self.f[20])
        d.text((M_L, PAGE[1] - 40), f"Grid: latitude/longitude, WGS84.  Imagery: {credit}.  Made {time.strftime('%Y-%m-%d')} by the OFFGRID drive "
               "— verify on the ground; roads, bridges and places change.", font=self.f[20], fill=(90, 90, 90))


# --------------------------------------------------------------------------- sheet layout along a route
def route_centres(line, z, overlap=0.08):
    """Sheet centres (global px) so consecutive sheets overlap and the route never leaves the inner part."""
    pts = [gpx(a, b, z) for a, b in imagery.dense(line, 1.0)]
    hw, hh = MAP_W * (0.5 - overlap), MAP_H * (0.5 - overlap)
    def ahead(i):          # first route point after i that is ~0.85 of a half-sheet away from point i: the next centre
        for j in range(i + 1, len(pts)):
            if abs(pts[j][0] - pts[i][0]) > hw * .85 or abs(pts[j][1] - pts[i][1]) > hh * .85:
                return j
        return len(pts) - 1
    ci = ahead(0)                                       # the work city sits near the first sheet's edge, not its middle
    out = [pts[ci]]
    i = ci
    while i < len(pts) - 1:
        i += 1
        c = out[-1]
        if abs(pts[i][0] - c[0]) > hw or abs(pts[i][1] - c[1]) > hh:
            ci = ahead(i - 1)
            out.append(pts[ci])
            i = max(i, ci) if ci > i else i
    end = pts[-1]
    c = out[-1]
    if abs(end[0] - c[0]) > MAP_W * .5 - 40 or abs(end[1] - c[1]) > MAP_H * .5 - 40:
        out.append(end)
    return out


def fit_zoom(lats, lons, w=MAP_W, h=MAP_H, zmax=12):
    for z in range(zmax, 2, -1):
        xs = [gpx(a, b, z) for a, b in zip(lats, lons)]
        if max(p[0] for p in xs) - min(p[0] for p in xs) < w * .9 and max(p[1] for p in xs) - min(p[1] for p in xs) < h * .9:
            return z
    return 3


def _save(pages, path):
    if not pages:
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".part.pdf"
    pages[0].save(tmp, "PDF", resolution=DPI, save_all=True, append_images=pages[1:], quality=82)
    os.replace(tmp, path)
    return True


def route_pdf(PIL, rd, dest, r, tl, outdir, extra=()):
    rows = corridor_places(dest, r["key"]) + list(extra)
    centres = route_centres(r["line"], ROUTE_Z)
    lats = [p[0] for p in r["line"]]; lons = [p[1] for p in r["line"]]
    oz = fit_zoom(lats, lons)
    ocx, ocy = gpx((max(lats) + min(lats)) / 2, (max(lons) + min(lons)) / 2, oz)
    ov = Sheet(PIL, rd, ocx, ocy, oz)
    ov.line(r["line"], width=6)
    taken = ov.towns(tl, 150000, 25)
    ov.spots(r.get("spots", []), taken)
    f = 2 ** (oz - ROUTE_Z)
    for i, (cx, cy) in enumerate(centres, 1):
        x0, y0 = (cx - MAP_W / 2) * f - ov.x0 + M_L, (cy - MAP_H / 2) * f - ov.y0 + M_T
        x1, y1 = x0 + MAP_W * f, y0 + MAP_H * f
        ov.d.rectangle((x0, y0, x1, y1), outline=(255, 230, 0), width=3)
        ov.label(x0, y0, str(i), ov.fb[26], (255, 230, 0), 4, 4)
    ov.grid()
    title = f"Get home from {r['label']} — {r.get('miles', '?')} miles, {r.get('drive', '')}"
    ov.furniture(title, f"Overview: sheets 1–{len(centres)} in driving order (yellow boxes). Red line = planned route.",
                 spot_kinds=[k for k in SPOT if any(s.get("kind") == k for s in r.get("spots", []))], credit="see each sheet")
    pages, have = [ov.img], 0
    for i, (cx, cy) in enumerate(centres, 1):
        s = Sheet(PIL, rd, cx, cy, ROUTE_Z)
        have += s.have
        s.line(r["line"])
        taken = s.towns(tl, 2500, 40)
        used = s.places(rows, taken)
        s.spots(r.get("spots", []), taken)
        s.grid()
        la, lo = glatlon(cx, cy, ROUTE_Z)
        s.furniture(f"{r['label']} → home   ·   sheet {i} of {len(centres)}",
                    f"Centre {la:.4f}, {lo:.4f}   ·   overlaps the next sheet   ·   " +
                    ("no imagery on the drive for this area yet" if not s.have else f"imagery {s.have}/{s.total} tiles"),
                    used, [k for k in SPOT if any(s2.get("kind") == k for s2 in r.get("spots", []))],
                    "USGS NAIP / Geospatial Ontario / Esri World Imagery")
        pages.append(s.img)
    name = re.sub(r"[^\w .,'()-]+", "", f"Route - {r['label']} to home").strip()
    _save(pages, os.path.join(outdir, name + ".pdf"))
    return name, len(pages), have


def home_pdf(PIL, rd, dest, home, tl, routes, outdir, extra=()):
    pages, have = [], 0
    for z, sub, minpop in ((16, "Close-up: streets, buildings, tree lines (about 3 x 2 miles)", 0),
                           (14, "Local area (about 12 x 8 miles)", 500),
                           (12, "Wider area (about 45 x 32 miles)", 5000)):
        cx, cy = gpx(home["lat"], home["lon"], z)
        s = Sheet(PIL, rd, cx, cy, z)
        have += s.have
        for r in routes:
            s.line(r["line"], width=5)
        taken = s.towns(tl, minpop, 30)
        used = s.places(list(extra), taken, 15)
        x, y = s.xy(home["lat"], home["lon"])
        star = [(x + 26 * math.cos(math.radians(a)) * (1 if k % 2 == 0 else .45), y + 26 * math.sin(math.radians(a)) * (1 if k % 2 == 0 else .45))
                for k, a in enumerate(range(-90, 270, 36))]
        s.d.polygon(star, fill=(255, 220, 0), outline=(0, 0, 0))
        taken.append(s.label(x, y, "HOME", s.fb[30], (255, 220, 0), 24, -20))
        s.grid()
        s.furniture(f"{home['name']}", f"{sub}   ·   {home['lat']:.4f}, {home['lon']:.4f}" +
                    ("" if s.have else "   ·   no imagery at this zoom yet"), legend_cats=used, credit="USGS NAIP / Esri World Imagery")
        pages.append(s.img)
    _save(pages, os.path.join(outdir, "Home - " + re.sub(r"[^\w .,'()-]+", "", home["name"]) + ".pdf"))
    return len(pages), have


def build(u, dest, routes=None, home=None):
    import routes_data, geopdf_render
    routes = routes_data.ROUTES if routes is None else routes
    home = home or getattr(routes_data, "HOME", None)
    if home and not (home.get("lat") or home.get("lon")):
        home = None                      # public edition placeholder (0, 0)
    u.say("Printable satellite map sheets (PDF)")
    PIL = geopdf_render.get_pillow(u, dest)
    if not PIL:
        print("  ! Pillow is needed to draw the sheets (fetched once with internet) — skipped"); return
    rd = imagery.Reader(dest)
    if not rd.has_any():
        print("  ! no satellite imagery on the drive yet — run ADD-SATELLITE-IMAGERY first"); return
    outdir = os.path.join(dest, "PRINTABLE MAPS")
    os.makedirs(outdir, exist_ok=True)
    tl = towns(dest)
    shel = fema_shelters(dest)
    made = []
    if home:
        n, h = home_pdf(PIL, rd, dest, home, tl, routes, outdir, shel)
        made.append(("Home", n, h)); print(f"  Home: {n} sheets")
    for r in routes:
        name, n, h = route_pdf(PIL, rd, dest, r, tl, outdir, shel)
        made.append((name, n, h)); print(f"  {name}: {n} pages")
    rd.close()
    with open(os.path.join(outdir, "00 - READ ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("PRINTABLE SATELLITE MAPS\r\n\r\n"
                 "Print these now and keep them in the vehicle and go-bag: they work with no power, no phone, no drive.\r\n"
                 "Letter paper, LANDSCAPE, 'Actual size' (not 'fit'), color if you can. Sleeve them or use a gallon zip bag.\r\n\r\n"
                 "Route files: page 1 is the overview with numbered yellow boxes; the rest are the sheets in driving order\r\n"
                 "from the work city toward home. Sheets overlap. Triangles = border crossings, chokepoints, refuel stops.\r\n"
                 "Circles = places found along the route (H hospital, W water, F fuel, S shelter ...).\r\n"
                 "Grid = latitude/longitude (WGS84) - the same numbers a phone GPS or a GPS unit shows.\r\n\r\n"
                 "Rebuild after adding imagery: run MAKE-PRINTABLE-MAPS (or it runs after ADD-SATELLITE-IMAGERY).\r\n\r\n"
                 + "\r\n".join(f"  {n}: {p} pages" for n, p, _ in made) + "\r\n")
    _index(outdir, made)
    print(f"  Saved in {outdir}")


def _index(outdir, made):
    from urllib.parse import quote
    import html as H
    rows = ""
    for f in sorted(glob.glob(os.path.join(outdir, "*.pdf"))):
        n = os.path.basename(f)
        pages = next((p for m, p, _ in made if n.startswith(m) or m in n), "")
        rows += (f"<tr><td><a href='{quote(n)}'>{H.escape(n[:-4])}</a></td><td>{pages}</td>"
                 f"<td>{os.path.getsize(f) / 1e6:.0f} MB</td></tr>")
    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Printable satellite maps</title><style>body{{font:16px/1.5 system-ui,sans-serif;background:#14171a;color:#e6e8eb;margin:0}}
main{{max-width:860px;margin:auto;padding:18px}}a{{color:#d9a441}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #2c323a;padding:6px 8px;text-align:left}}
.tip{{border-left:3px solid #57ab5a;background:#141d16;padding:8px 12px;margin:12px 0}}</style></head><body><main>
<p><a href="../DASHBOARD.html">← Dashboard</a></p><h1>Printable satellite maps</h1>
<p class="tip"><b>Print these now</b> and keep them in the vehicle and go-bag: once on paper they need no power, phone or drive.
Letter paper, <b>landscape</b>, "Actual size" (not "Fit"), color if you can. Sleeve them or use a gallon zip bag.</p>
<table><tr><th>File</th><th>Pages</th><th>Size</th></tr>{rows}</table>
<h2>Reading the sheets</h2><ul>
<li>Route files: page 1 is the overview with numbered yellow boxes; then the sheets in driving order from the work city toward home. Sheets overlap.</li>
<li>Red line = planned route. Triangles = border crossings, chokepoints, refuel / rest stops. Circles = places found along the route
(H hospital, W water, F fuel, S shelter, G grocery, Rx pharmacy ...).</li>
<li>Grid = latitude / longitude (WGS84), the same numbers a phone or GPS shows. Edge labels give decimal degrees and degrees-minutes.</li>
<li>Home file: close-up (about 3 x 2 miles), local (12 x 8 miles) and wider area (45 x 32 miles).</li>
<li>Gray areas = no imagery on the drive there yet: run ADD-SATELLITE-IMAGERY, then MAKE-PRINTABLE-MAPS.</li></ul>
</main></body></html>"""
    open(os.path.join(outdir, "00 - START HERE.html"), "w", encoding="utf-8").write(doc)
