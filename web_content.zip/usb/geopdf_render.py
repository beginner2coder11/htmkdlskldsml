"""Render georeferenced GeoPDF maps (your military MIMs) into offline web-map tiles.

Avenza and QGIS can read a GeoPDF's built-in georeferencing, but Avenza now needs a paid plan to import
your own maps. So instead this bakes each georeferenced GeoPDF in MY-MAPS into map tiles — the same kind the
USGS topo and satellite layers use — placed at the exact right spot on the locator map. No subscription, no
Adobe, no TerraGo: the map image shows in place and you can see where you are on it offline.

How it works: Poppler's pdftoppm renders the PDF page to a bitmap; the GeoPDF's LGIDict georeferencing gives
the pixel->lat/lon mapping; each slippy-map tile is warped out of that bitmap with Pillow. Tiles land in
www/tiles/mymap-<slug>/z/x/y.png with an info.json, and get listed in www/tiles/mymaps-tiles.json so the map
adds a "My maps (map imagery)" overlay.

Needs pdftoppm (bundled by the OCR step) and Pillow (fetched once from PyPI, like pypdf). If either is
missing it skips cleanly — the maps still work as coverage boxes and in QGIS. Resolves UTM GeoPDFs (military
MIMs, most USGS); other projections are left to the coverage-box path.
"""
import glob, json, math, os, re, shutil, subprocess, sys, tempfile, zipfile

TILE = 256
MAXZOOM_CAP = 17
MINZOOM = 10
RENDER_MAX_PX = 7000          # cap the rendered bitmap's long side (memory/runtime bound)
MESH = 8                      # warp mesh granularity per tile (8x8 cells is plenty for one 1:50k sheet)


def _slug(rel):
    return "mymap-" + re.sub(r"[^a-z0-9]+", "-", os.path.splitext(os.path.basename(rel))[0].lower()).strip("-")[:48]


def get_pillow(u, dest):
    """Import Pillow; fetch+extract the matching wheel from PyPI once (binary wheel, so extracted, not zip-imported)."""
    try:
        import PIL.Image  # noqa: F401
        return __import__("PIL")
    except Exception:  # noqa: BLE001
        pass
    libdir = os.path.join(dest, "tools", "pylib")
    for d in sorted(glob.glob(os.path.join(libdir, "_pil_*")), reverse=True):   # a previously extracted wheel
        if os.path.isdir(d):
            sys.path.insert(0, d)
            try:
                import PIL.Image  # noqa: F401
                return __import__("PIL")
            except Exception:  # noqa: BLE001
                sys.path.pop(0)
    tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
    plat = ("win_amd64" if sys.platform.startswith("win") else
            "macosx" if sys.platform == "darwin" else "manylinux")
    try:
        meta = json.loads(u.fetch("https://pypi.org/pypi/pillow/json", 60))
        cand = [x for x in meta["urls"] if x["filename"].endswith(".whl") and tag in x["filename"] and plat in x["filename"]]
        cand = [x for x in cand if "arm64" not in x["filename"] and "aarch64" not in x["filename"]] or cand
        if not cand:
            print("  ! no matching Pillow wheel for this Python — skipping tile rendering"); return None
        whl = os.path.join(libdir, cand[0]["filename"])
        if not os.path.exists(whl) and not u.download(cand[0]["url"], whl, "Pillow (image library for map rendering)"):
            return None
        out = os.path.join(libdir, "_pil_" + tag)
        shutil.rmtree(out, ignore_errors=True)
        zipfile.ZipFile(whl).extractall(out)
        sys.path.insert(0, out)
        import PIL.Image  # noqa: F401
        return __import__("PIL")
    except Exception as e:  # noqa: BLE001
        print(f"  ! could not set up Pillow: {e}")
        return None


def _pdftoppm(dest):
    import ocr  # reuse the OCR step's Poppler locator/fetcher
    return ocr._find_exe("pdftoppm" + (".exe" if sys.platform.startswith("win") else ""),
                         os.path.join(dest, "tools", "poppler"))


# ---- web-mercator helpers (slippy map) ----
def _lonlat_to_px(lon, lat, z):
    n = TILE * 2 ** z
    x = (lon + 180) / 360 * n
    s = math.sin(math.radians(lat))
    y = (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n
    return x, y


def _px_to_lonlat(x, y, z):
    n = TILE * 2 ** z
    lon = x / n * 360 - 180
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lon, lat


def render_map(u, dest, rel, pdfpath, PIL, ppm, mymaps, pypdf):
    """Render one GeoPDF into tiles. Returns a manifest dict for the map, or None if it can't be georeferenced."""
    from PIL import Image, ImageDraw
    r = pypdf.PdfReader(pdfpath)
    page = r.pages[0]
    fr = mymaps.lgi_frame(page)
    if not fr or fr["proj"] not in ("UT", "UTM"):          # only UTM frames render here (military MIMs); others -> box only
        return None
    zone, north = fr["zone"], fr["north"]
    if zone is None:
        return None
    a, b, c, d, e, ff = fr["ctm"]
    ia, ic, ib, id_, _, _ = fr["inv"]                      # inverse of the 2x2 (translation handled below)
    mbw, mbh = fr["mb"][2] - fr["mb"][0], fr["mb"][3] - fr["mb"][1]

    def ll_to_proj(lon, lat):
        return mymaps._ll_to_utm(lon, lat, zone)

    def proj_to_page(X, Y):
        return ia * (X - e) + ic * (Y - ff), ib * (X - e) + id_ * (Y - ff)

    # map's geographic extent from the neatline corners
    lons, lats = [], []
    for xp, yp in fr["neatline"]:
        X, Y = a * xp + c * yp + e, b * xp + d * yp + ff
        lon, lat = mymaps._utm_to_ll(X, Y, zone, north)
        lons.append(lon); lats.append(lat)
    w, s, en, nn = min(lons), min(lats), max(lons), max(lats)
    clat = (s + nn) / 2

    # native resolution -> max zoom
    neat_px = [(a * xp + c * yp + e, b * xp + d * yp + ff) for xp, yp in fr["neatline"]]
    span_m = max(max(p[0] for p in neat_px) - min(p[0] for p in neat_px),
                 max(p[1] for p in neat_px) - min(p[1] for p in neat_px))
    # render DPI bounded by RENDER_MAX_PX on the long side
    long_pts = max(mbw, mbh)
    dpi = min(200, int(RENDER_MAX_PX * 72 / long_pts))
    dpi = max(96, dpi)
    tmp = tempfile.mkdtemp(prefix="offgrid-geopdf-")
    prefix = os.path.join(tmp, "r")
    try:
        subprocess.run([ppm, "-f", "1", "-l", "1", "-r", str(dpi), "-png", "-singlefile", pdfpath, prefix],
                       check=True, capture_output=True, timeout=600)
        img = Image.open(prefix + ".png").convert("RGB")
    except Exception as ex:  # noqa: BLE001
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"    ! could not render {os.path.basename(rel)}: {str(ex)[:100]}")
        return None
    W_px, H_px = img.size
    scale = dpi / 72.0                                     # page points -> rendered pixels

    def page_to_src(xp, yp):
        return xp * scale, (mbh - yp) * scale               # PDF y-up -> image y-down

    def ll_to_src(lon, lat):
        X, Y = ll_to_proj(lon, lat)
        xp, yp = proj_to_page(X, Y)
        return page_to_src(xp, yp)

    # clip to the neatline so the map's surround/margin doesn't bleed across tiles
    mask = Image.new("L", (W_px, H_px), 0)
    ImageDraw.Draw(mask).polygon([page_to_src(xp, yp) for xp, yp in fr["neatline"]], fill=255)
    img.putalpha(mask)

    res_native = span_m / max(W_px, H_px)                  # metres/pixel of the scan
    merc_res = lambda z: 156543.03392 * math.cos(math.radians(clat)) / (2 ** z)
    maxzoom = MINZOOM
    for z in range(MINZOOM, MAXZOOM_CAP + 1):
        if merc_res(z) >= res_native:
            maxzoom = z
    maxzoom = max(MINZOOM, min(MAXZOOM_CAP, maxzoom))

    name = _slug(rel)
    root = os.path.join(dest, "www", "tiles", name)
    shutil.rmtree(root, ignore_errors=True)
    blank = Image.new("RGBA", (TILE, TILE), (0, 0, 0, 0))
    ntiles = 0
    for z in range(MINZOOM, maxzoom + 1):
        x0 = int(_lonlat_to_px(w, nn, z)[0] // TILE)
        x1 = int(_lonlat_to_px(en, s, z)[0] // TILE)
        y0 = int(_lonlat_to_px(w, nn, z)[1] // TILE)
        y1 = int(_lonlat_to_px(en, s, z)[1] // TILE)
        for tx in range(x0, x1 + 1):
            for ty in range(y0, y1 + 1):
                mesh = []
                any_in = False
                for gx in range(MESH):
                    for gy in range(MESH):
                        box = (gx * TILE // MESH, gy * TILE // MESH, (gx + 1) * TILE // MESH, (gy + 1) * TILE // MESH)
                        quad = []
                        for cx, cy in ((box[0], box[1]), (box[0], box[3]), (box[2], box[3]), (box[2], box[1])):
                            lon, lat = _px_to_lonlat(tx * TILE + cx, ty * TILE + cy, z)
                            sx, sy = ll_to_src(lon, lat)
                            quad += [sx, sy]
                            if -2 <= sx <= W_px + 2 and -2 <= sy <= H_px + 2:
                                any_in = True
                        mesh.append((box, tuple(quad)))
                if not any_in:
                    continue
                tile = img.transform((TILE, TILE), Image.MESH, mesh, Image.BILINEAR)
                if not tile.getbbox():                      # fully transparent -> don't write
                    continue
                td = os.path.join(root, str(z), str(tx))
                os.makedirs(td, exist_ok=True)
                tile.save(os.path.join(td, f"{ty}.png"))
                ntiles += 1
    shutil.rmtree(tmp, ignore_errors=True)
    if not ntiles:
        shutil.rmtree(root, ignore_errors=True)
        return None
    with open(os.path.join(root, "info.json"), "w") as fh:
        json.dump({"minzoom": MINZOOM, "maxzoom": maxzoom, "bounds": [round(s, 5), round(w, 5), round(nn, 5), round(en, 5)],
                   "attribution": "Your map"}, fh)
    title = os.path.splitext(os.path.basename(rel))[0].replace("_", " ")
    print(f"    {title}: {ntiles} tiles, z{MINZOOM}-{maxzoom}")
    return {"name": name, "title": title, "bounds": [round(s, 5), round(w, 5), round(nn, 5), round(en, 5)],
            "minzoom": MINZOOM, "maxzoom": maxzoom, "rel": rel}


def build(u, dest):
    """Render every georeferenced GeoPDF in My Maps into offline tiles. Called by the My Maps step."""
    www = os.path.join(dest, "www")
    mroot = os.path.join(www, "mymaps")
    pdfs = sorted(f for f in glob.glob(os.path.join(mroot, "**", "*.pdf"), recursive=True))
    if not pdfs:
        return
    import search_index, mymaps as MM
    ppm = _pdftoppm(dest)
    PIL = get_pillow(u, dest) if ppm else None
    pypdf = search_index.get_pypdf(u, dest) if (ppm and PIL) else None
    if not ppm or not PIL or not pypdf:
        miss = "Poppler (pdftoppm)" if PIL and pypdf and not ppm else "Pillow" if ppm and pypdf and not PIL else \
               "pypdf" if ppm and PIL and not pypdf else "Poppler, Pillow or pypdf"
        print(f"  map-image tiles skipped — {miss} not available (maps still show as coverage boxes and open in QGIS)")
        return
    u.say("Rendering your GeoPDF maps into offline map tiles")
    man_path = os.path.join(www, "tiles", "mymaps-tiles.json")
    try:
        manifest = {m["rel"]: m for m in json.load(open(man_path))}
    except (OSError, ValueError):
        manifest = {}
    done = 0
    for f in pdfs:
        rel = os.path.relpath(f, mroot).replace(os.sep, "/")
        sigfile = os.path.join(www, "tiles", _slug(rel), "info.json")
        if rel in manifest and os.path.exists(sigfile):     # already rendered; skip (delete the tiles folder to redo)
            continue
        try:
            m = render_map(u, dest, rel, f, PIL, ppm, MM, pypdf)
        except Exception as ex:  # noqa: BLE001  (one bad/encrypted map must not stop the others)
            print(f"    ! {os.path.basename(rel)}: skipped ({str(ex)[:90]})")
            m = None
        if m:
            manifest[rel] = m
            done += 1
    manifest = {rel: m for rel, m in manifest.items() if os.path.exists(os.path.join(www, "tiles", m["name"], "info.json"))}
    os.makedirs(os.path.join(www, "tiles"), exist_ok=True)
    with open(man_path, "w") as fh:
        json.dump(list(manifest.values()), fh)
    if done:
        print(f"  {done} map(s) rendered to tiles; {len(manifest)} on the map overlay")
