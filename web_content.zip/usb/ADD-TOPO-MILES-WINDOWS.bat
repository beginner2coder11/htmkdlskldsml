@echo off
REM Download printable USGS topo maps (GeoPDF) in a RADIUS around home. Nothing else downloads.
REM Type 500 the first time; later type 600, 700 ... to add the next 100-mile ring (finished maps are skipped).
REM Rough size: 500 mi = 740 GB, 600 = 1.1 TB, 700 = 1.5 TB, 800 = 2 TB. Nearest maps first; stops when 150 GB is left free.
REM Optional: pass the drive letter, e.g.  ADD-TOPO-MILES-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
set MILES=
set /p MILES= How many miles around home? (500, 600, 700 ... press Enter for 500): 
if "%MILES%"=="" set MILES=500
echo.
echo  Adding topo maps within %MILES% miles of home to %DRIVE%:\OFFGRID  (nothing else will download)
echo  Nearest maps land first. Close this and re-run anytime - finished maps are skipped.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --topo-only --topo-pdf-radius %MILES%
pause
