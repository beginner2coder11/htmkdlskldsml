"""Excel (.xlsx) workbooks with coordinates, written with the standard library only (no Excel or add-ins needed).

EXCEL-READY\\ on the drive:
  US-cities.xlsx          31,000+ US cities and towns: lat, lon, MGRS, DMS, population
  Places-150mi.xlsx       the locator's places (hospitals, pharmacies, food, caves ...), one sheet per category
  Places-wide-area.xlsx   the wide-area places (500+ miles) after ADD-PLACES-MILES, one sheet per category
Columns include Latitude, Longitude, MGRS and DMS so the sheets can be sorted, filtered and mapped.
    python xlsx_export.py --dest E:\\OFFGRID
"""
import argparse
import json
import os
import re
import sys
import zipfile
from xml.sax.saxutils import escape

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
OUT = "EXCEL-READY"
MAXROWS = 1000000
_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _col(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _cell(ref, v, style=0):
    if v is None or v == "":
        return ""
    if isinstance(v, (int, float)):
        return f'<c r="{ref}"{f" s=\"{style}\"" if style else ""}><v>{v}</v></c>'
    return f'<c r="{ref}" t="inlineStr"{f" s=\"{style}\"" if style else ""}><is><t xml:space="preserve">{escape(_BAD.sub("", str(v)))}</t></is></c>'


class Workbook:
    def __init__(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.z = zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED)
        self.sheets = []

    def sheet(self, name, header, rows, widths=None):
        """rows: iterable of lists. Splits at Excel's row limit."""
        base = re.sub(r"[\[\]:*?/\\]", "-", name)[:28]
        part, w, n, cols = 1, None, 0, len(header)

        def open_sheet():
            nonlocal w, n, part
            nm = base if part == 1 else f"{base} {part}"
            idx = len(self.sheets) + 1
            self.sheets.append(nm)
            w = self.z.open(f"xl/worksheets/sheet{idx}.xml", "w")
            w.write(('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                     '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                     '<cols>' + "".join(f'<col min="{i + 1}" max="{i + 1}" width="{(widths or [])[i] if widths and i < len(widths) else 16}" customWidth="1"/>' for i in range(cols))
                     + "</cols><sheetData>").encode("utf-8"))
            w.write(("<row r=\"1\">" + "".join(_cell(f"{_col(i)}1", h, 1) for i, h in enumerate(header)) + "</row>").encode("utf-8"))
            n = 1

        def close_sheet():
            w.write((f'</sheetData><autoFilter ref="A1:{_col(cols - 1)}{n}"/></worksheet>').encode("utf-8"))
            w.close()

        open_sheet()
        for r in rows:
            if n >= MAXROWS:
                close_sheet(); part += 1; open_sheet()
            n += 1
            w.write((f'<row r="{n}">' + "".join(_cell(f"{_col(i)}{n}", v, 2 if isinstance(v, float) else 0) for i, v in enumerate(r)) + "</row>").encode("utf-8"))
        close_sheet()

    def close(self):
        z = self.z
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(self.sheets)))
                   + "</Types>")
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{escape(n)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, n in enumerate(self.sheets)) + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(self.sheets)))
                   + f'<Relationship Id="rId{len(self.sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/styles.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.000000"/></numFmts>'
                   '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
                   '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
                   '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                   '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                   '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
                   '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
        z.close()


def _fmt(la, lo):
    import coords
    return coords.mgrs(la, lo), coords.dms(la, lo)


HEAD_PLACE = ["Name", "Category", "Latitude", "Longitude", "MGRS", "DMS", "Address", "Phone", "Hours", "Info", "Website"]


def _place_rows(rows, cats):
    for r in rows:
        la, lo = r[2], r[3]
        m, d = _fmt(la, lo)
        yield [r[1], cats.get(r[0], r[0]), la, lo, m, d, r[4], r[5], r[7], r[8], r[6]]


def cities(dest):
    import cities_data
    rows = cities_data.load()
    wb = Workbook(os.path.join(dest, OUT, "US-cities.xlsx"))
    wb.sheet("US cities", ["City", "State", "County", "Latitude", "Longitude", "Population", "MGRS", "DMS"],
             ([c[0], c[1], c[2], c[3], c[4], c[5], *_fmt(c[3], c[4])] for c in rows), [26, 7, 22, 12, 12, 12, 18, 30])
    wb.close()
    return len(rows)


def places150(dest):
    p = os.path.join(dest, "www", "data", "pois.js")
    try:
        t = open(p, encoding="utf-8").read()
        meta = json.loads(re.search(r"window\.POI_META=(.*?);\n", t).group(1))
        pois = json.loads(re.search(r"window\.POIS=(.*?);\n", t, re.S).group(1))
    except (OSError, AttributeError, ValueError):
        return 0
    cats = meta.get("categories", {})
    by = {}
    for r in pois:   # [cat,name,lat,lon,miles,dir,addr,phone,web,hours,osm,info]
        by.setdefault(r[0], []).append([r[0], r[1], r[2], r[3], r[6], r[7], r[8], r[9], r[11]])
    wb = Workbook(os.path.join(dest, OUT, "Places-150mi.xlsx"))
    for c, rows in sorted(by.items(), key=lambda kv: cats.get(kv[0], kv[0])):
        wb.sheet(cats.get(c, c), HEAD_PLACE, _place_rows(rows, cats), [34, 24, 12, 12, 18, 30, 34, 16, 22, 24, 30])
    wb.close()
    return len(pois)


def placeswide(dest):
    import glob
    d = os.path.join(dest, "www", "data", "poi500")
    try:
        idx = json.load(open(os.path.join(d, "index.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    cats = idx.get("cats", {})
    by = {}
    for f in sorted(glob.glob(os.path.join(d, "*.js"))):
        if os.path.basename(f) == "index.js":
            continue
        t = open(f, encoding="utf-8").read()
        for r in json.loads(t[t.index('"]=') + 3:].rstrip().rstrip(";")):
            by.setdefault(r[0], []).append(r)
    wb = Workbook(os.path.join(dest, OUT, "Places-wide-area.xlsx"))
    n = 0
    for c, rows in sorted(by.items(), key=lambda kv: cats.get(kv[0], kv[0])):
        n += len(rows)
        wb.sheet(cats.get(c, c), HEAD_PLACE, _place_rows(rows, cats), [34, 24, 12, 12, 18, 30, 34, 16, 22, 24, 30])
    wb.close()
    return n


def run(dest):
    print("\n==> Excel files with coordinates (EXCEL-READY)", flush=True)
    res = {}
    for name, fn in (("cities", cities), ("places150", places150), ("placeswide", placeswide)):
        try:
            res[name] = fn(dest)
        except Exception as e:  # noqa: BLE001
            print(f"  ! {name}: {type(e).__name__}: {e}")
    print(f"  {res.get('cities', 0):,} cities, {res.get('places150', 0):,} nearby places, {res.get('placeswide', 0):,} wide-area places -> {OUT}\\")
    return res


def build(u, dest):
    u.say("Excel files with coordinates")
    run(dest)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dest", required=True)
    run(ap.parse_args().dest)
