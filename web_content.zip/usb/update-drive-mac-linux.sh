#!/bin/sh
# OFF-GRID SURVIVAL DRIVE - monthly update (Mac/Linux). Needs internet and python3.
cd "$(dirname "$0")" || exit 1
exec python3 tools/builder/usb/usb_builder.py --dest "$(pwd)" --update "$@"
