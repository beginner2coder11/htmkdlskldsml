"""More Google Earth Pro layers, made from the maps and data already on the drive.

Writes into GOOGLE-EARTH-READY\\ (same folder as the fixed copies of your own KMLs). Nothing is downloaded.

  01 Home + distance rings (50 / 100 / 250 / 500 / 800 mi)
  02 Military installations (real boundary polygons, grouped by branch)
  03 Get-home routes (corridor lines + choke points, crossings, refuel hubs)
  04 Topo-quad footprints, one file per state: green = PDF is on the drive (click it to open the PDF),
     orange outline = still to download
  05 Topo-quad footprints for the bases / cities / lakes sets
  Places\\ one KML per category (hospitals, fuel, water ...) copied from the locator's GPS export

    python kml_export.py --dest E:\\OFFGRID
"""
import argparse
import html
import json
import math
import os
import re
import shutil
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = "GOOGLE-EARTH-READY"
esc = html.escape
_HDR = '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>\n'
_FTR = "</Document></kml>\n"


def _style(i, line, fill=None, w=2, icon=None):
    s = f'<Style id="{i}"><LineStyle><color>{line}</color><width>{w}</width></LineStyle>'
    s += f"<PolyStyle><color>{fill}</color><fill>1</fill><outline>1</outline></PolyStyle>" if fill else "<PolyStyle><fill>0</fill></PolyStyle>"
    if icon:
        s += f"<IconStyle><scale>1.0</scale><Icon><href>{icon}</href></Icon></IconStyle>"
    return s + "</Style>\n"


def _write(path, name, body, styles=""):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(_HDR + f"<name>{esc(name)}</name>\n" + styles + body + _FTR)


def _circle(lat, lon, miles, n=120):
    pts = []
    for i in range(n + 1):
        a = 2 * math.pi * i / n
        dlat = miles / 69.0 * math.cos(a)
        dlon = miles / (69.17 * math.cos(math.radians(lat))) * math.sin(a)
        pts.append(f"{lon + dlon:.5f},{lat + dlat:.5f},0")
    return " ".join(pts)


def _home(dest):
    try:
        o = json.load(open(os.path.join(dest, "tools", "build-options.json"), encoding="utf-8"))
        if o.get("lat") and o.get("lon"):
            return float(o["lat"]), float(o["lon"]), o.get("label") or "Home"
    except (OSError, ValueError):
        pass
    try:
        h = json.load(open(os.path.join(dest, "www", "topo", "catalog.json"), encoding="utf-8")).get("home")
        if h:
            return h["lat"], h["lon"], "Home"
    except (OSError, ValueError, KeyError):
        pass
    return 34.2367, -84.4908, "Canton, GA (home)"


def rings(dest):
    lat, lon, label = _home(dest)
    body = f'<Placemark><name>{esc(label)}</name><styleUrl>#pin</styleUrl><Point><coordinates>{lon:.5f},{lat:.5f},0</coordinates></Point></Placemark>\n'
    for mi in (50, 100, 250, 500, 800):
        body += (f'<Placemark><name>{mi} miles</name><styleUrl>#ring</styleUrl><LineString><tessellate>1</tessellate>'
                 f'<coordinates>{_circle(lat, lon, mi)}</coordinates></LineString></Placemark>\n')
    st = _style("ring", "ff00d7ff", None, 2) + '<Style id="pin"><IconStyle><scale>1.3</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/red-stars.png</href></Icon></IconStyle></Style>\n'
    _write(os.path.join(dest, OUT, "01-Home-and-distance-rings.kml"), "Home + 50/100/250/500/800 mile rings", body, st)
    return 1


def _ring_xml(ring):
    return "<LinearRing><coordinates>" + " ".join(f"{c[0]:.5f},{c[1]:.5f},0" for c in ring) + "</coordinates></LinearRing>"


def _poly_xml(g):
    polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
    out = []
    for p in polys:
        x = f"<Polygon><outerBoundaryIs>{_ring_xml(p[0])}</outerBoundaryIs>"
        for hole in p[1:]:
            x += f"<innerBoundaryIs>{_ring_xml(hole)}</innerBoundaryIs>"
        out.append(x + "</Polygon>")
    return out[0] if len(out) == 1 else "<MultiGeometry>" + "".join(out) + "</MultiGeometry>"


_COMP = {"usa": "Army", "usn": "Navy", "usaf": "Air Force", "usmc": "Marine Corps", "usar": "Army Reserve", "arng": "Army National Guard",
         "ang": "Air National Guard", "usnr": "Navy Reserve", "usafr": "Air Force Reserve", "usmcr": "Marine Corps Reserve",
         "usss": "Space Force", "ussf": "Space Force", "dla": "Defense Logistics Agency", "whs": "Washington HQ Services"}


def military(dest):
    for p in (os.path.join(dest, "www", "data", "military.geojson"), os.path.join(HERE, "data", "military-bases.geojson")):
        if os.path.exists(p):
            raw = p
            break
    else:
        return 0
    feats = json.load(open(raw, encoding="utf-8")).get("features", [])
    groups = {}
    for f in feats:
        g, pr = f.get("geometry"), f.get("properties") or {}
        if not g or g.get("type") not in ("Polygon", "MultiPolygon"):
            continue
        pv = lambda *ks: next((str(pr[k]) for k in ks if pr.get(k) not in (None, "", " ")), "")  # noqa: E731
        name = pv("FEATURENAME", "featureName", "SITENAME", "siteName") or "Installation"
        comp = pv("SITEREPORTINGCOMPONENT", "siteReportingComponent").lower()
        branch = _COMP.get(comp, comp.upper() or "Other")
        st = pv("STATENAMECODE", "stateNameCode").upper()
        status = pv("SITEOPERATIONALSTATUS", "siteOperationalStatus").lower()
        d = f"{branch} · {st} · {status}" if status else f"{branch} · {st}"
        groups.setdefault(branch, []).append(
            f"<Placemark><name>{esc(name)}</name><description>{esc(d)}</description><styleUrl>#mil</styleUrl>{_poly_xml(g)}</Placemark>\n")
    body = "".join(f"<Folder><name>{esc(b)} ({len(v)})</name>{''.join(v)}</Folder>\n" for b, v in sorted(groups.items()))
    _write(os.path.join(dest, OUT, "02-Military-installations.kml"), "Military installations (DoD)", body,
           _style("mil", "ff2020e0", "302020e0", 2))
    return sum(len(v) for v in groups.values())


def routes(dest):
    try:
        t = open(os.path.join(dest, "www", "data", "routes.js"), encoding="utf-8").read()
        j = json.loads(re.search(r"window\.ROUTES=(.*?);\s*$", t, re.S).group(1))
    except (OSError, AttributeError, ValueError):
        return 0
    body = ""
    for r in j.get("routes", []):
        co = " ".join(f"{p[1]:.5f},{p[0]:.5f},0" for p in r["line"])
        body += f"<Folder><name>{esc(r['label'])} → home · {r.get('miles', '?')} mi · {esc(str(r.get('drive', '')))}</name>"
        body += f'<Placemark><name>{esc(r["label"])} route</name><styleUrl>#route</styleUrl><LineString><tessellate>1</tessellate><coordinates>{co}</coordinates></LineString></Placemark>'
        for s in r.get("spots", []):
            body += (f'<Placemark><name>{esc(s["name"])}</name><description>{esc(s.get("kind", ""))}</description><styleUrl>#spot</styleUrl>'
                     f'<Point><coordinates>{s["lon"]:.5f},{s["lat"]:.5f},0</coordinates></Point></Placemark>')
        body += "</Folder>\n"
    st = _style("route", "ffff8000", None, 4) + '<Style id="spot"><IconStyle><scale>0.9</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/ylw-blank.png</href></Icon></IconStyle></Style>\n'
    _write(os.path.join(dest, OUT, "03-Get-home-routes.kml"), "Get-home routes", body, st)
    return len(j.get("routes", []))


def _quad(r, root, depth):
    bb = r.get("bb")
    if not bb or not bb[2]:
        return None
    have = os.path.exists(os.path.join(root, r["rel"]))
    x0, y0, x1, y1 = bb
    ring = f"{x0:.5f},{y0:.5f},0 {x1:.5f},{y0:.5f},0 {x1:.5f},{y1:.5f},0 {x0:.5f},{y1:.5f},0 {x0:.5f},{y0:.5f},0"
    if have:
        link = "../" * depth + "www/topo/" + urllib.parse.quote(r["rel"])
        d = f'<![CDATA[<a href="{link}">Open this topo PDF</a><br>{r.get("d", "")} mi {r.get("b", "")} of home]]>'
    else:
        d = "Not downloaded yet (run ADD-TOPO-MAPS)"
    return have, (f"<Placemark><name>{esc(r['t'])}</name><description>{d}</description><styleUrl>#{'have' if have else 'miss'}</styleUrl>"
                  f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring}</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>\n")


_QST = _style("have", "ff00aa00", "3000aa00", 1) + _style("miss", "ff0080ff", None, 1)


def topo(dest):
    root = os.path.join(dest, "www", "topo")
    try:
        cat = json.load(open(os.path.join(root, "catalog.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return 0, 0
    n = files = 0
    by = {}
    for r in (cat.get("home") or {}).get("quads", []):
        by.setdefault(r["rel"].split("/")[0] if "/" in r["rel"] else "other", []).append(r)
    folder = os.path.join(dest, OUT, "04-Topo-quads-HOME-by-state")
    for st, rows in sorted(by.items()):
        out = [q for q in (_quad(r, root, 2) for r in rows) if q]
        if out:
            have = sum(1 for h, _ in out if h)
            _write(os.path.join(folder, f"{st}.kml"), f"Topo quads {st} — {have} on drive / {len(out)}", "".join(x for _, x in out), _QST)
            n += len(out); files += 1
    groups = {}
    seen = set()
    for a in (cat.get("areas") or {}).values():
        for r in a.get("quads", []):
            if r["rel"] in seen:
                continue
            seen.add(r["rel"])
            groups.setdefault(a.get("group", "areas"), []).append(r)
    for g, rows in sorted(groups.items()):
        out = [q for q in (_quad(r, root, 1) for r in rows) if q]
        if out:
            nm = re.sub(r"[^A-Za-z0-9]+", "-", g).strip("-")
            _write(os.path.join(dest, OUT, f"05-Topo-quads-{nm}.kml"), f"Topo quads: {g}", "".join(x for _, x in out), _QST)
            n += len(out); files += 1
    return n, files


def places(dest):
    src = os.path.join(dest, "www", "data", "export")
    if not os.path.isdir(src):
        return 0
    k = 0
    for f in sorted(os.listdir(src)):
        if f.lower().endswith(".kml") and not f.startswith("all"):
            d = os.path.join(dest, OUT, "Places", f)
            if not os.path.exists(d) or os.path.getmtime(d) < os.path.getmtime(os.path.join(src, f)):
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copyfile(os.path.join(src, f), d)
            k += 1
    return k


def places500(dest):
    """One KML per category from www/data/poi500 (all states merged; split by state when a category is huge)."""
    import glob as _g
    d = os.path.join(dest, "www", "data", "poi500")
    try:
        idx = json.load(open(os.path.join(d, "index.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    cats = idx.get("cats", {})
    bycat = {}
    for f in sorted(_g.glob(os.path.join(d, "*.js"))):
        st = os.path.basename(f)[:-3]
        if st == "index":
            continue
        t = open(f, encoding="utf-8").read()
        try:
            rows = json.loads(t[t.index('"]=') + 3:].rstrip().rstrip(";"))
        except ValueError:
            continue
        for r in rows:
            bycat.setdefault(r[0], {}).setdefault(st, []).append(r)
    out = os.path.join(dest, OUT, "Places-wide-area")
    shutil.rmtree(out, ignore_errors=True)
    n = 0
    for c, sts in bycat.items():
        title = cats.get(c, c)
        total = sum(len(v) for v in sts.values())
        groups = [(title, [r for v in sts.values() for r in v])] if total <= 25000 else [(f"{title} - {st}", v) for st, v in sorted(sts.items())]
        for t2, rows in groups:
            body = "".join(
                f"<Placemark><name>{esc(r[1][:80])}</name><description>{esc(' · '.join(x for x in (r[4], r[5] and 'Tel ' + r[5], r[7], r[8]) if x))}</description>"
                f"<Point><coordinates>{r[3]:.6f},{r[2]:.6f},0</coordinates></Point></Placemark>\n" for r in rows)
            fn = re.sub(r"[^A-Za-z0-9]+", "-", t2).strip("-") + ".kml"
            _write(os.path.join(out, fn), t2, body)
            n += 1
    return n


def run(dest):
    print("\n==> More Google Earth Pro layers (from the maps already on the drive)", flush=True)
    res = {}
    for name, fn in (("rings", rings), ("military", military), ("routes", routes), ("topo", topo), ("places", places), ("places500", places500)):
        try:
            res[name] = fn(dest)
        except Exception as e:  # noqa: BLE001
            print(f"  ! {name}: {type(e).__name__}: {e}")
    q, qf = res.get("topo", (0, 0)) if isinstance(res.get("topo"), tuple) else (0, 0)
    print(f"  distance rings, {res.get('military', 0)} installations, {res.get('routes', 0)} routes, {q} topo footprints in {qf} files, "
          f"{res.get('places', 0)} place categories -> {OUT}\\")
    with open(os.path.join(dest, OUT, "READ-ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("GOOGLE-EARTH-READY - open any .kml here with Google Earth Pro (File > Open).\n\n"
                 "  01-Home-and-distance-rings.kml     home pin + 50/100/250/500/800 mile rings\n"
                 "  02-Military-installations.kml      installation boundaries by branch\n"
                 "  03-Get-home-routes.kml             your work-city routes home\n"
                 "  04-Topo-quads-HOME-by-state\\        one file per state: green squares = topo PDF is on the drive (click, then the\n"
                 "                                     'Open this topo PDF' link); orange outline = not downloaded yet\n"
                 "  05-Topo-quads-*.kml                same, for base / city / lake topo sets\n"
                 "  Places\\                            hospitals, fuel, water, food... one file each\n"
                 "  Places-wide-area\\                      the same within your chosen radius (after ADD-PLACES-MILES), incl. restaurants, pawn & gun shops\n\n"
                 "Keep this folder where it is: the topo links are relative (..\\www\\topo\\...), so they work from any drive letter.\n"
                 "Files are rebuilt each time the builder finishes. Your own KMLs (fixed for Google Earth) are in this folder too.\n")
    return res


def build(u, dest):
    u.say("More Google Earth Pro layers")
    run(dest)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dest", required=True)
    run(ap.parse_args().dest)
