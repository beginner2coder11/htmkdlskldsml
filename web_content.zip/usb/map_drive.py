#!/usr/bin/env python3
"""Map the whole OFF-GRID drive and check that everything is where it should be. Reads only - changes nothing.

  python map_drive.py --dest E:\\OFFGRID            full map + checks
  python map_drive.py --dest E:\\OFFGRID --no-links skip the page-link scan (faster)

Writes REPORTS\\DRIVE-MAP.html (folder map you can click open + problems) and REPORTS\\DRIVE-MAP.txt.
What "in place" means: the launchers, pages, Command Center tiles, links between pages, library documents (from the
builder's own manuals list) are all on the drive; no half-finished downloads, converted .osm.pbf leftovers, empty files,
duplicate big files, loose reports or stray items at the top of the drive. Needs no internet. Standard library only."""
import argparse, html, os, re, sys, time, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = {"OPEN-WITH", "$RECYCLE.BIN", "System Volume Information", ".Trashes", ".Spotlight-V100"}
ROOT_KNOWN = {"CAVES", "EXCEL-READY", "FIELD-NOTEBOOK.html", "GOOGLE-EARTH-READY", "MY-FILES-INBOX", "MY-PERSONAL-FILES-INBOX", "PERSONAL", "MY-MAPS-INBOX", "MY-RADIO-INBOX",
              "OSM-MAP-SOURCE", "TEXT-ONLY", "USE-ON-PHONE.html", "kiwix", "START-HERE.bat", "start-here-mac-linux.sh", "READ-ME-FIRST.html", "DASHBOARD.html", "TOP 20 SITUATIONS", "PRINTABLE MAPS", "BACKUP", "README.txt", "HOW-TO-USE-THIS-DRIVE.txt",
              "PROGRAMS", "REPORTS", "www", "tools", "ai", "SOFTWARE", "PLATFORMS", "_TIDY-BIN", "OPEN-WITH", "MY-FILES",
              "autorun.inf", "OFFGRID"}
OPTIONAL = ("addons/", "tiles/", "topo/", "map/", "data/", "kiwix", "phone-apps", "platforms/", "media", "music", "apps/", "vendor/", "ai/")
JUNK_EXT = (".part", ".tmp", ".new", ".crdownload")
JUNK_NAMES = {"thumbs.db", "desktop.ini", ".ds_store"}
REPORTY = re.compile(r"(NOT-FETCHED|MISSING-|-REPORT|CHECK-REPORT|UPDATE-LOG|organize-plan)", re.I)
BIG_DUP = 50 * 1024 * 1024
EMPTY_OK = ("py.typed", "__init__.py", "__init__.pyi", ".gitkeep", ".keep", ".nomedia", "INCOMPLETE")
INTENDED_COPIES = ("kiwix/desktop/", "GOOGLE-EARTH-READY/", "EXCEL-READY/", "PLATFORMS/", "REPORTS/", "SOFTWARE/", "_TIDY-BIN/", "TEXT-ONLY/",
                   "www/phone-apps/", "www/data/export/", "tools/")     # places the builder deliberately keeps a second copy
MID_DUP = 1024 * 1024
LINE = []


def out(s=""):
    print(s)
    LINE.append(s)


def human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u in ("B", "KB") else f"{n:.1f} {u}"
        n /= 1024


def builder_usb(d):
    for p in (os.path.join(d, "tools", "builder", "usb"), HERE):
        if os.path.exists(os.path.join(p, "command.html")):
            return p
    return None


def walk(d):
    """One pass over the drive. Returns size/count per folder plus lists of things worth reporting."""
    size, cnt = {}, {}
    junk, zero, osm, loose, dups_mid, dups_big, newest_lib = [], [], [], [], {}, {}, 0.0
    nfiles = 0
    stack = [(d, [])]
    order = []
    while stack:
        p, _ = stack.pop()
        order.append(p)
        try:
            it = list(os.scandir(p))
        except OSError:
            continue
        for e in it:
            try:
                if e.is_symlink():
                    continue
                if e.is_dir(follow_symlinks=False):
                    if (e.name in SKIP_DIRS and p in (d, os.path.join(d, "www"))) or (e.name == "PERSONAL" and p == d):
                        continue          # PERSONAL is private: its file names never go in a report
                    stack.append((e.path, []))
                    continue
                st = e.stat(follow_symlinks=False)
            except OSError:
                continue
            nfiles += 1
            if nfiles % 100000 == 0:
                print(f"  ...{nfiles:,} files", flush=True)
            size[p] = size.get(p, 0) + st.st_size
            cnt[p] = cnt.get(p, 0) + 1
            n, low = e.name, e.name.lower()
            rel = os.path.relpath(e.path, d).replace("\\", "/")
            if low.endswith(JUNK_EXT) or low in JUNK_NAMES or n.startswith("~$"):
                junk.append((rel, st.st_size))
            if st.st_size == 0 and not low.endswith(JUNK_EXT) and n not in EMPTY_OK and not rel.startswith(("tools/pylib/", "tools/planetiler-tmp/", "_TIDY-BIN/")):
                zero.append(rel)
            if low.endswith(".osm.pbf"):
                osm.append((rel, st.st_size))
            top = rel.split("/")[0]
            if REPORTY.search(n) and top not in ("REPORTS", "_TIDY-BIN") and not rel.startswith("tools/builder/"):
                loose.append(rel)
            if rel.startswith("www/library/") and st.st_mtime > newest_lib:
                newest_lib = st.st_mtime
            if st.st_size >= BIG_DUP:
                dups_big.setdefault(st.st_size, []).append(rel)
            elif st.st_size >= MID_DUP and not rel.startswith(("www/map/", "www/tiles/", "www/topo/", "tools/", "ai/")):
                dups_mid.setdefault((st.st_size, low), []).append(rel)
    for p in reversed(order):       # roll child totals up (parents were visited before children)
        par = os.path.dirname(p)
        if p != d:
            size[par] = size.get(par, 0) + size.get(p, 0)
            cnt[par] = cnt.get(par, 0) + cnt.get(p, 0)
    return size, cnt, junk, zero, osm, loose, dups_mid, dups_big, newest_lib, nfiles


def links_check(d, www):
    """Every local href/src in the pages must land on a file or folder on the drive."""
    bad, opt, pages = {}, 0, 0
    for root, ds, fs in os.walk(www):
        ds[:] = [x for x in ds if x not in ("tiles", "topo", "map", "kiwix", "OPEN-WITH")]
        for f in fs:
            if not f.lower().endswith(".html"):
                continue
            pages += 1
            p = os.path.join(root, f)
            try:
                t = open(p, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for m in re.finditer(r'(?:href|src)\s*=\s*(["\'])([^"\']+)\1', t):
                r = m.group(2)
                if r.startswith(("http", "#", "mailto:", "tel:", "javascript:", "data:", "geo:", "sms:", "//", "/")) or "{" in r or "'+" in r or '"+' in r:
                    continue
                r0 = urllib.parse.unquote(r.split("#")[0].split("?")[0])
                if not r0 or r0 == "KIWIX":
                    continue
                tgt = os.path.normpath(os.path.join(root, r0))
                if os.path.exists(tgt):
                    continue
                relp = os.path.relpath(tgt, www).replace("\\", "/")
                if relp.startswith(OPTIONAL):
                    opt += 1
                    continue
                bad.setdefault(os.path.relpath(p, www).replace("\\", "/"), []).append(r)
    return bad, opt, pages


def tiles_check(www, usb):
    miss = []
    try:
        t = open(os.path.join(usb, "command.html"), encoding="utf-8").read()
    except OSError:
        return miss
    for m in re.finditer(r'^\["(\w+)","([^"]+)","([^"]*)","([^"]+)"', t, re.M):
        p = urllib.parse.unquote(m.group(4).split("#")[0].split("?")[0])
        if p.startswith(("http", "../", "KIWIX", "mailto:")) or p.startswith(OPTIONAL):
            continue
        if not os.path.exists(os.path.join(www, p)):
            miss.append(f"{m.group(2)}  ->  {p}")
    return miss


def manuals_check(www, d):
    tsv = None
    for c in (os.path.join(d, "tools", "builder", "library", "manuals.tsv"), os.path.join(os.path.dirname(HERE), "library", "manuals.tsv")):
        if os.path.exists(c):
            tsv = c
            break
    if not tsv:
        return None
    have, miss, seen = 0, {}, set()
    for line in open(tsv, encoding="utf-8"):
        p = line.rstrip("\n").split("\t")
        if len(p) < 4 or p[0].startswith("#") or p[2].endswith("_COMPLETE.pdf") or (p[0], p[2]) in seen:
            continue
        seen.add((p[0], p[2]))
        if os.path.exists(os.path.join(www, "library", p[0], p[2])):
            have += 1
        else:
            miss.setdefault(p[0], []).append(p[2])
    return have, miss


def html_tree(d, size, cnt, depth, maxkids=40):
    def rec(p, lvl):
        try:
            subs = sorted((e.path for e in os.scandir(p) if e.is_dir(follow_symlinks=False) and e.name not in SKIP_DIRS), key=lambda x: -size.get(x, 0))
        except OSError:
            return ""
        s = ""
        for q in subs[:maxkids]:
            lab = f"<b>{html.escape(os.path.basename(q))}</b> &nbsp; {human(size.get(q, 0))} &nbsp; <small>{cnt.get(q, 0):,} files</small>"
            kids = rec(q, lvl + 1) if lvl + 1 < depth else ""
            s += f"<details><summary>{lab}</summary>{kids}</details>" if kids else f"<div class=leaf>{lab}</div>"
        if len(subs) > maxkids:
            s += f"<div class=leaf><small>... {len(subs) - maxkids} more folders</small></div>"
        return s
    return rec(d, 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--no-links", action="store_true")
    a = ap.parse_args()
    d = os.path.abspath(a.dest)
    www = os.path.join(d, "www")
    if not os.path.isdir(www):
        print(f"{d} doesn't look like an OFFGRID drive folder (no www). Use e.g. E:\\OFFGRID")
        sys.exit(1)
    usb = builder_usb(d)
    t0 = time.time()
    out(f"OFF-GRID DRIVE MAP - {d} - {time.strftime('%Y-%m-%d %H:%M')}")
    print("Walking the drive (this can take a while on a big drive)...", flush=True)
    size, cnt, junk, zero, osm, loose, dm, db, newest_lib, nfiles = walk(d)
    problems, notes = [], []
    tot = size.get(d, 0)
    out(f"\n{nfiles:,} files, {human(tot)} (OPEN-WITH shortcuts are hard links and not counted)")

    out("\nFOLDERS (largest first)")
    for e in sorted((e for e in os.scandir(d) if e.is_dir() and e.name not in SKIP_DIRS), key=lambda e: -size.get(e.path, 0)):
        out(f"  {e.name + '/':<22}{human(size.get(e.path, 0)):>10}  {cnt.get(e.path, 0):>10,} files")
        try:
            for c in sorted((c for c in os.scandir(e.path) if c.is_dir() and c.name not in SKIP_DIRS), key=lambda c: -size.get(c.path, 0))[:12]:
                out(f"      {c.name + '/':<30}{human(size.get(c.path, 0)):>10}  {cnt.get(c.path, 0):>10,} files")
        except OSError:
            pass

    # --- expected items
    if not usb:
        problems.append("Builder copy not found on the drive (tools\\builder\\usb) - cannot compare against the expected list")
        miss_l, miss_p = [], []
    else:
        src = open(os.path.join(usb, "launcher.py"), encoding="utf-8", errors="replace").read()
        launchers = sorted(set(re.findall(r'^\s*\(\s*"[\w]+"\s*,\s*"([\w.-]+\.(?:bat|sh))"', src, re.M)))
        miss_l = [f for f in launchers if not os.path.exists(os.path.join(d, "PROGRAMS", f))]
        for f in ("START-HERE.bat", "start-here-mac-linux.sh", "READ-ME-FIRST.html", "README.txt"):
            if not os.path.exists(os.path.join(d, f)):
                miss_l.append(f)
        want = set()
        try:                                            # the builder's own list of pages it puts in www (some pages go elsewhere)
            bsrc = open(os.path.join(usb, "usb_builder.py"), encoding="utf-8-sig", errors="replace").read()
            m = re.search(r'def launchers\(.*?for f in \(([^)]*)\):', bsrc, re.S)
            want = set(re.findall(r'"([\w.-]+\.(?:html|js))"', m.group(1))) if m else set()
        except OSError:
            pass
        if len(want) < 20:
            want = {f for f in os.listdir(usb) if f.endswith(".html")} - {"OPEN-ME-NO-INSTALL.html", "SEARCH-EVERYTHING.html", "WHATS-HAPPENING.html", "media.html", "music.html"}
        miss_p = sorted(f for f in want if os.path.exists(os.path.join(usb, f)) and not os.path.exists(os.path.join(www, f)))
        if miss_l:
            problems.append(f"{len(miss_l)} launchers missing (PROGRAMS / top of drive): " + ", ".join(miss_l[:25]) + "  -> run UPDATE or REPAIR-DRIVE")
        if miss_p:
            problems.append(f"{len(miss_p)} Command Center pages missing from www: " + ", ".join(miss_p[:25]) + "  -> run UPDATE or REPAIR-DRIVE")
        tm = tiles_check(www, usb)
        if tm:
            problems.append(f"{len(tm)} Command Center tiles point at something that isn't on the drive:\n      " + "\n      ".join(tm[:25]))
    for n in ("docs.js", "topics-data.js"):
        if not os.path.exists(os.path.join(www, n)) and not os.path.exists(os.path.join(www, "search", n)):
            problems.append(f"search file missing: {n}  -> run UPDATE-DRIVE")
    dj = os.path.join(www, "search", "docs.js")
    if not os.path.exists(dj):
        dj = os.path.join(www, "docs.js")
    if os.path.exists(dj) and newest_lib and newest_lib - os.path.getmtime(dj) > 86400:
        notes.append("The search index is older than the newest library file - new files may not be searchable yet (run UPDATE-DRIVE or ADD-OCR).")
    wd, wi = os.path.join(www, "docs.js"), os.path.join(www, "docs-idx.js")
    if os.path.exists(wd) and (not os.path.exists(wi) or os.path.getmtime(wi) + 3600 < os.path.getmtime(wd)):
        notes.append("Ask-the-Library has no up-to-date prebuilt index (it still works, just opens slower). Rebuild: tools\\python-win\\python.exe tools\\builder\\usb\\ask_fast.py --dest .")
    if not os.path.exists(os.path.join(d, "REPORTS", "CHECKSUMS.json")):
        notes.append("No saved checksums yet - run VERIFY-DRIVE (menu V) once to protect the big files.")

    # --- library documents
    mc = manuals_check(www, d)
    if mc:
        have, miss = mc
        nm = sum(len(v) for v in miss.values())
        out(f"\nLIBRARY DOCUMENTS (builder's list): {have:,} present, {nm:,} missing")
        for c, v in sorted(miss.items(), key=lambda x: -len(x[1]))[:15]:
            out(f"      {c}: {len(v)} missing")
        if nm:
            notes.append(f"{nm} listed library documents are not on the drive (some sites block automatic downloads) - see REPORTS\\MISSING-MANUALS.html from CHECK-USB-WINDOWS.")

    # --- links
    if not a.no_links:
        print("Checking links between pages...", flush=True)
        bad, opt, pages = links_check(d, www)
        out(f"\nLINKS: {pages:,} pages scanned, {sum(len(v) for v in bad.values()):,} broken in {len(bad)} pages, {opt:,} point at optional add-ons not installed")
        if bad:
            problems.append(f"{len(bad)} pages have links to files that aren't on the drive (first 15 below)")
            for pg, v in sorted(bad.items())[:15]:
                out(f"      {pg}: {len(v)} broken, e.g. {v[0]}")

    # --- housekeeping
    if junk:
        problems.append(f"{len(junk)} half-finished / junk files ({human(sum(s for _, s in junk))}): " + ", ".join(r for r, _ in junk[:8]) + (" ..." if len(junk) > 8 else "") + "  -> TIDY-DRIVE or re-run the builder to finish them")
    if osm:
        problems.append(f"{len(osm)} converted .osm.pbf source files still on the drive ({human(sum(s for _, s in osm))}): " + ", ".join(r for r, _ in osm[:6]) + "  -> TIDY-DRIVE deletes the ones already converted")
    tmpd = os.path.join(d, "tools", "planetiler-tmp")
    if size.get(tmpd, 0) > 1e9:
        problems.append(f"tools/planetiler-tmp holds {human(size[tmpd])} of map-converter scratch files  -> TIDY-DRIVE deletes it")
    if zero:
        problems.append(f"{len(zero)} empty (0-byte) files: " + ", ".join(zero[:8]) + (" ..." if len(zero) > 8 else "") + "  -> failed downloads; REPAIR-DRIVE re-fetches")
    if loose:
        problems.append(f"{len(loose)} report files outside REPORTS: " + ", ".join(loose[:8]) + "  -> move or delete them (they were saved into a library folder)")
    stray = sorted(e.name for e in os.scandir(d) if e.name not in ROOT_KNOWN and e.name not in SKIP_DIRS)
    if stray:
        notes.append("Other items at the top of the drive (yours? nothing from the builder): " + ", ".join(stray[:15]))
    def confirmed(groups):
        """Keep only sets whose files really match (size + the first and last 1 MB), ignoring copies the builder keeps on purpose."""
        res = []
        for k, v in groups:
            v = [x for x in v if not x.startswith(INTENDED_COPIES)]
            if len(v) < 2:
                continue
            by = {}
            for rel in v:
                try:
                    with open(os.path.join(d, *rel.split("/")), "rb") as fh:
                        a = fh.read(1 << 20)
                        sz = os.path.getsize(fh.name)
                        fh.seek(max(0, sz - (1 << 20)))
                        key = (a, fh.read())
                except OSError:
                    continue
                by.setdefault(hash(key), []).append(rel)
            res += [(k, g) for g in by.values() if len(g) > 1]
        return res
    big = confirmed([(k, v) for k, v in db.items() if len(v) > 1])
    mid = confirmed([(k, v) for k, v in dm.items() if len(v) > 1])
    mid = [((k, ""), v) for k, v in mid]
    if big or mid:
        waste = sum(k * (len(v) - 1) for k, v in big) + sum(k[0] * (len(v) - 1) for k, v in mid)
        notes.append(f"{len(big) + len(mid)} sets of identical files (size and content match, deliberate copies skipped), about {human(waste)} could be saved. ORGANIZE-LIBRARY handles library duplicates; others:")
        for k, v in sorted(big, key=lambda x: -x[0] * len(x[1]))[:10]:
            notes.append(f"      {human(k)} x{len(v)}: " + " | ".join(v[:3]))
        for k, v in sorted(mid, key=lambda x: -x[0][0] * len(x[1]))[:10]:
            notes.append(f"      {human(k[0])} x{len(v)}: " + " | ".join(v[:3]))

    out("\n" + ("PROBLEMS" if problems else "NO PROBLEMS FOUND") + (f" ({len(problems)})" if problems else ""))
    for i, p in enumerate(problems, 1):
        out(f"  {i}. {p}")
    if notes:
        out("\nNOTES")
        for n in notes:
            out(f"  - {n}")
    out(f"\nDone in {time.time() - t0:.0f} s. Nothing was changed.")

    rep = os.path.join(d, "REPORTS")
    os.makedirs(rep, exist_ok=True)
    with open(os.path.join(rep, "DRIVE-MAP.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(LINE) + "\n")
    css = ("body{font:15px system-ui,sans-serif;margin:16px auto;max-width:900px;padding:0 12px}details{margin-left:18px}summary{cursor:pointer;padding:2px 0}"
           ".leaf{margin-left:36px;padding:2px 0}.bad{background:#fee;border-left:4px solid #c33;padding:8px 12px;margin:8px 0;white-space:pre-wrap}"
           ".note{background:#ffd;border-left:4px solid #cb0;padding:8px 12px;margin:8px 0;white-space:pre-wrap}.ok{background:#efe;padding:10px}small{color:#666}")
    body = f"<h1>Drive map</h1><p>{html.escape(d)} - {nfiles:,} files, {human(tot)} - {time.strftime('%Y-%m-%d %H:%M')}</p>"
    body += "".join(f"<div class=bad>{html.escape(p)}</div>" for p in problems) if problems else "<div class=ok>Everything checked is in place.</div>"
    body += "".join(f"<div class=note>{html.escape(n)}</div>" for n in notes)
    body += "<h2>Folders</h2>" + html_tree(d, size, cnt, 4)
    with open(os.path.join(rep, "DRIVE-MAP.html"), "w", encoding="utf-8") as fh:
        fh.write(f"<!DOCTYPE html><html><head><meta charset='utf-8'><meta name=viewport content='width=device-width,initial-scale=1'><title>Drive map</title><style>{css}</style></head><body>{body}</body></html>")
    print("\nOpen REPORTS\\DRIVE-MAP.html for the clickable map (REPORTS\\DRIVE-MAP.txt has the same in text).")


if __name__ == "__main__":
    main()
