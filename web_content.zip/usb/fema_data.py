# -*- coding: utf-8 -*-
"""FEMA locations for the Eastern US: shelters, open shelters, Disaster Recovery Centers and disaster declarations.

  Registered shelters   FEMA ESF#6 Shelter System (formerly the National Shelter System, with the Red Cross):
                        every facility listed as a shelter — capacity, ADA, pets, generator, in a flood plain or not.
                        Refreshed every 90 days.
  Open shelters (now)   the same system's currently open shelters — a snapshot, refreshed every run.
  Recovery centers      FEMA's active Disaster Recovery Centers (in-person help after a declared disaster) — snapshot.
  Declared counties     OpenFEMA disaster declarations for the last 2 years, drawn on Census county outlines,
                        with which help each county got (Individual Assistance, Public Assistance, Hazard Mitigation).

Writes www/data/fema.js (map overlays), GOOGLE-EARTH-READY\\FEMA\\*.kml, and REPORTS\\FEMA-DATA.txt.
Also copies FEMA's own online Google Earth tools (Stay Dry, NFHL) into GOOGLE-EARTH-READY\\FEMA\\ONLINE-ONLY —
those draw live from FEMA's servers and need internet.

    python fema_data.py --dest E:\\OFFGRID
"""
import argparse, datetime, glob, html, json, os, re, shutil, sys, time, urllib.parse, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
NSS = "https://gis.fema.gov/arcgis/rest/services/NSS/FEMA_NSS/FeatureServer/5/query"
OPEN = "https://gis.fema.gov/arcgis/rest/services/NSS/OpenShelters/FeatureServer/0/query"
DRC = "https://gis.fema.gov/arcgis/rest/services/FEMA/DRC/FeatureServer/0/query"
DECL = "https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries"
COUNTIES = "https://www2.census.gov/geo/tiger/GENZ2023/kml/cb_2023_us_county_20m.zip"
EAST = ["AL", "FL", "GA", "SC", "NC", "TN", "KY", "VA", "WV", "MD", "DE", "DC", "PA", "NJ", "NY", "CT", "RI", "MA", "VT",
        "NH", "ME", "OH", "MI", "IN", "IL", "WI", "MS"]
FIPS = {"AL": "01", "FL": "12", "GA": "13", "SC": "45", "NC": "37", "TN": "47", "KY": "21", "VA": "51", "WV": "54", "MD": "24",
        "DE": "10", "DC": "11", "PA": "42", "NJ": "34", "NY": "36", "CT": "09", "RI": "44", "MA": "25", "VT": "50", "NH": "33",
        "ME": "23", "OH": "39", "MI": "26", "IN": "18", "IL": "17", "WI": "55", "MS": "28"}
esc = html.escape


def _out(dest):
    return os.path.join(dest, "www", "data", "fema")


def _arcgis(u, url, where, fields, label):
    """All rows of an ArcGIS layer query (paged). -> list of attribute dicts with _lat/_lon."""
    rows, off = [], 0
    while True:
        q = urllib.parse.urlencode({"where": where, "outFields": fields, "returnGeometry": "true", "outSR": 4326,
                                    "resultOffset": off, "resultRecordCount": 2000, "orderByFields": "objectid", "f": "json"})
        j = json.loads(u.fetch(f"{url}?{q}", 120))
        if "error" in j:
            raise RuntimeError(f"{label}: {j['error'].get('message')}")
        fs = j.get("features", [])
        for f in fs:
            a = {k.lower(): v for k, v in (f.get("attributes") or {}).items()}
            g = f.get("geometry") or {}
            a["_lat"] = g.get("y", a.get("latitude"))
            a["_lon"] = g.get("x", a.get("longitude"))
            rows.append(a)
        off += len(fs)
        if not fs or not j.get("exceededTransferLimit"):
            break
    return rows


def _yn(v):
    return "yes" if str(v).strip().upper() in ("Y", "YES", "TRUE", "1") else "no" if str(v).strip().upper() in ("N", "NO", "FALSE", "0") else ""


def shelters(u, dest, cache):
    """Registered shelters in the eastern states. Cached; refreshed after 90 days (or when missing)."""
    p = os.path.join(cache, "nss.json")
    if os.path.exists(p) and (time.time() - os.path.getmtime(p)) / 86400 < 90:
        return json.load(open(p, encoding="utf-8")), "cached"
    where = "state IN (%s)" % ",".join(f"'{s}'" for s in EAST)
    fields = ("shelter_name,address_1,city,county_parish,state,zip,evacuation_capacity,post_impact_capacity,ada_compliant,"
              "wheelchair_accessible,pet_accommodations_desc,generator_onsite,self_sufficient_electricity,in_100_yr_floodplain,"
              "in_500_yr_floodplain,in_surge_slosh_area,org_organization_name,org_main_phone,facility_type,shelter_status_code,objectid")
    rows = _arcgis(u, NSS, where, fields, "FEMA shelters")
    out = []
    for a in rows:
        try:
            la, lo = float(a["_lat"]), float(a["_lon"])
        except (TypeError, ValueError, KeyError):
            continue
        out.append([a.get("shelter_name") or "Shelter", round(la, 5), round(lo, 5), a.get("address_1") or "", a.get("city") or "",
                    a.get("state") or "", a.get("evacuation_capacity") or 0, a.get("post_impact_capacity") or 0,
                    _yn(a.get("ada_compliant")) or _yn(a.get("wheelchair_accessible")), a.get("pet_accommodations_desc") or "",
                    _yn(a.get("generator_onsite")) or _yn(a.get("self_sufficient_electricity")),
                    "100-yr" if _yn(a.get("in_100_yr_floodplain")) == "yes" else "500-yr" if _yn(a.get("in_500_yr_floodplain")) == "yes"
                    else "surge" if _yn(a.get("in_surge_slosh_area")) == "yes" else "",
                    a.get("org_organization_name") or "", a.get("org_main_phone") or "", a.get("facility_type") or ""])
    json.dump(out, open(p, "w", encoding="utf-8"))
    return out, "downloaded"


def snapshot(u, url, label, where="1=1"):
    rows = _arcgis(u, url, where, "*", label)
    return [r for r in rows if r.get("_lat") is not None]


def counties(u, cache):
    """{'SSCCC': [ring, ...]} county outlines (Census 1:20M, simplified)."""
    p = os.path.join(cache, "counties.json")
    if os.path.exists(p):
        return json.load(open(p, encoding="utf-8"))
    zp = os.path.join(cache, "counties.zip")
    if not os.path.exists(zp):
        open(zp, "wb").write(u.fetch(COUNTIES, 300))
    with zipfile.ZipFile(zp) as z:
        kml = z.read(next(n for n in z.namelist() if n.lower().endswith(".kml"))).decode("utf-8", "replace")
    out = {}
    for pm in re.findall(r"<Placemark>(.*?)</Placemark>", kml, re.S):
        sf = re.search(r'name="STATEFP">(\d+)<', pm)
        cf = re.search(r'name="COUNTYFP">(\d+)<', pm)
        if not (sf and cf):
            continue
        rings = []
        for c in re.findall(r"<outerBoundaryIs>\s*<LinearRing>\s*<coordinates>(.*?)</coordinates>", pm, re.S):
            pts = []
            for t in c.split():
                xy = t.split(",")
                pts.append([round(float(xy[0]), 4), round(float(xy[1]), 4)])
            rings.append(pts)
        out[sf.group(1) + cf.group(1)] = rings
    json.dump(out, open(p, "w"))
    os.remove(zp)
    return out


def declarations(u, years=2):
    """Declared counties in the eastern states over the last N years: {'SSCCC': [decl, ...]}."""
    since = (datetime.date.today() - datetime.timedelta(days=365 * years)).isoformat()
    st = ",".join(f"'{s}'" for s in EAST)
    out, skip = {}, 0
    while True:
        q = urllib.parse.urlencode({"$filter": f"declarationDate ge '{since}' and state in ({st})", "$top": 1000, "$skip": skip,
                                    "$orderby": "declarationDate desc"}, safe="$'(),", quote_via=urllib.parse.quote)
        j = json.loads(u.fetch(f"{DECL}?{q}", 120))
        rows = j.get("DisasterDeclarationsSummaries", [])
        for r in rows:
            key = (r.get("fipsStateCode") or "") + (r.get("fipsCountyCode") or "")
            if len(key) != 5 or key.endswith("000"):
                continue                                    # statewide rows have no county to draw
            out.setdefault(key, []).append({
                "id": r.get("femaDeclarationString"), "title": (r.get("declarationTitle") or "").title(),
                "type": r.get("incidentType"), "date": (r.get("declarationDate") or "")[:10],
                "end": (r.get("incidentEndDate") or "")[:10], "closed": bool(r.get("disasterCloseoutDate")),
                "ia": bool(r.get("iaProgramDeclared") or r.get("ihProgramDeclared")), "pa": bool(r.get("paProgramDeclared")),
                "hm": bool(r.get("hmProgramDeclared")), "file_by": (r.get("lastIAFilingDate") or "")[:10],
                "area": r.get("designatedArea"), "state": r.get("state")})
        skip += len(rows)
        if len(rows) < 1000:
            break
    return out


# --------------------------------------------------------------------------- KML
_HDR = '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>\n'


def _kml(path, name, body, styles=""):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(_HDR + f"<name>{esc(name)}</name>\n{styles}{body}</Document></kml>\n")


def _pt_style(i, color, icon):
    return (f'<Style id="{i}"><IconStyle><color>{color}</color><scale>0.9</scale><Icon><href>'
            f'http://maps.google.com/mapfiles/kml/shapes/{icon}.png</href></Icon></IconStyle><LabelStyle><scale>0</scale></LabelStyle></Style>\n')


def _shelter_desc(r):
    name, la, lo, addr, city, st, ev, post, ada, pets, gen, flood, org, phone, ftype = r
    lines = [f"{esc(addr)}, {esc(city)}, {esc(st)}", f"Capacity: {ev or '?'} evacuation / {post or '?'} after the storm",
             f"Accessible: {ada or '?'} · Generator: {gen or '?'} · Pets: {esc(pets) or '?'}",
             f"Run by: {esc(org)} {esc(phone)}"]
    if flood:
        lines.append(f"<b>In a {flood} flood area</b>")
    lines.append("Not every listed shelter opens in every disaster — check local news / 211 / the Red Cross for which are open.")
    return "<br>".join(lines)


def write_kml(dest, data):
    out = os.path.join(dest, "GOOGLE-EARTH-READY", "FEMA")
    os.makedirs(out, exist_ok=True)
    st = _pt_style("sh", "ff00ccff", "homegardenbusiness") + _pt_style("shf", "ff0080ff", "homegardenbusiness")
    by = {}
    for r in data["shelters"]:
        by.setdefault(r[5], []).append(r)
    body = ""
    for s in sorted(by):
        body += f"<Folder><name>{esc(s)} ({len(by[s])})</name><visibility>0</visibility>\n"
        for r in by[s]:
            body += (f"<Placemark><name>{esc(r[0])}</name><visibility>0</visibility><styleUrl>#{'shf' if r[11] else 'sh'}</styleUrl>"
                     f"<description><![CDATA[{_shelter_desc(r)}]]></description><Point><coordinates>{r[2]},{r[1]},0</coordinates></Point></Placemark>\n")
        body += "</Folder>\n"
    _kml(os.path.join(out, "01 FEMA registered shelters (Eastern US).kml"), "FEMA registered shelters — tick a state to show it", body, st)

    st = _pt_style("op", "ff00ff00", "homegardenbusiness") + _pt_style("drc", "ffff8000", "info-i")
    body = f"<description>Snapshot from {esc(data['built'])}. These change daily — re-run the drive update with internet for the latest.</description>\n"
    for a in data["open"]:
        body += (f"<Placemark><name>{esc(a.get('shelter_name') or 'Open shelter')}</name><styleUrl>#op</styleUrl><description><![CDATA["
                 f"{esc(a.get('address_1') or a.get('address') or '')}, {esc(a.get('city') or '')}, {esc(a.get('state') or '')}<br>"
                 f"Status: {esc(str(a.get('shelter_status_code') or 'OPEN'))} · people: {esc(str(a.get('total_population') or '?'))}"
                 f"<br>{esc(a.get('incident_name') or '')}]]></description><Point><coordinates>{a['_lon']},{a['_lat']},0</coordinates></Point></Placemark>\n")
    for a in data["drc"]:
        body += (f"<Placemark><name>DRC: {esc(a.get('drc_name') or 'Recovery center')}</name><styleUrl>#drc</styleUrl><description><![CDATA["
                 f"{esc(a.get('street_1') or '')}, {esc(a.get('city') or '')}, {esc(a.get('state') or '')}<br>"
                 f"Days: {esc(str(a.get('days_open') or '?'))} · Hours: {esc(str(a.get('hours') or '?'))}<br>{esc(str(a.get('notes') or ''))}"
                 f"]]></description><Point><coordinates>{a['_lon']},{a['_lat']},0</coordinates></Point></Placemark>\n")
    _kml(os.path.join(out, "02 Open shelters and Disaster Recovery Centers (snapshot).kml"),
         f"Open shelters + FEMA Disaster Recovery Centers — as of {data['built']}", body, st)

    sty = ('<Style id="ia"><LineStyle><color>ff0000ff</color><width>1.5</width></LineStyle><PolyStyle><color>550000ff</color></PolyStyle></Style>\n'
           '<Style id="pa"><LineStyle><color>ff0080ff</color><width>1.5</width></LineStyle><PolyStyle><color>440080ff</color></PolyStyle></Style>\n'
           '<Style id="old"><LineStyle><color>ff888888</color><width>1</width></LineStyle><PolyStyle><color>22888888</color></PolyStyle></Style>\n')
    body = ""
    for f in data["decl"]["features"]:
        p = f["properties"]
        style = "ia" if p["open_ia"] else "pa" if p["open"] else "old"
        polys = "".join("<Polygon><outerBoundaryIs><LinearRing><coordinates>" + " ".join(f"{x},{y},0" for x, y in ring)
                        + "</coordinates></LinearRing></outerBoundaryIs></Polygon>" for ring in (p_[0] for p_ in f["geometry"]["coordinates"]))
        desc = "<br>".join(f"<b>{esc(d['id'])}</b> {esc(d['title'])} ({esc(d['type'])}), declared {d['date']}: "
                           + ", ".join(x for x, ok in (("Individual help", d["ia"]), ("Public assistance", d["pa"]), ("Hazard mitigation", d["hm"])) if ok)
                           + (f" — apply by {d['file_by']}" if d["ia"] and d["file_by"] else "") for d in p["decls"])
        body += (f"<Placemark><name>{esc(p['name'])}</name><styleUrl>#{style}</styleUrl><description><![CDATA[{desc}<br>"
                 f"Apply / check status: disasterassistance.gov · 1-800-621-3362]]></description><MultiGeometry>{polys}</MultiGeometry></Placemark>\n")
    _kml(os.path.join(out, "03 Disaster-declared counties (last 2 years).kml"),
         "FEMA disaster-declared counties — red: individual help open, orange: other open declarations, gray: older", body, sty)
    for f in glob.glob(os.path.join(HERE, "data", "fema_online", "*.*")):    # FEMA's own live tools (need internet)
        dd = os.path.join(out, "ONLINE-ONLY (needs internet)")
        os.makedirs(dd, exist_ok=True)
        shutil.copy2(f, os.path.join(dd, os.path.basename(f)))
    with open(os.path.join(out, "00 READ ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("FEMA layers for Google Earth Pro (File > Open)\r\n\r\n"
                 "01  Every registered shelter in the eastern states (FEMA ESF#6 Shelter System / Red Cross). Tick a state folder.\r\n"
                 "    Orange icon = the shelter sits in a mapped flood or storm-surge area. Not all shelters open in every event.\r\n"
                 f"02  Shelters that were OPEN and FEMA Disaster Recovery Centers when the drive was last updated ({data['built']}).\r\n"
                 "03  Counties with a FEMA disaster declaration in the last 2 years. Click a county for the declarations and\r\n"
                 "    which help is available; red = individual help (apply at disasterassistance.gov / 1-800-621-3362).\r\n"
                 "ONLINE-ONLY  FEMA's own Stay Dry and NFHL flood-map tools: they draw live from FEMA's servers and need internet.\r\n"
                 "    With no internet, use the drive's own map: Locator map > layers > FEMA flood zones (around home).\r\n")


def build(u, dest):
    u.say("FEMA shelters, recovery centers and disaster declarations (Eastern US)")
    cache = os.path.join(dest, "tools", "fema-cache")
    os.makedirs(cache, exist_ok=True)
    os.makedirs(_out(dest), exist_ok=True)
    old = {}
    try:
        t = open(os.path.join(dest, "www", "data", "fema.js"), encoding="utf-8").read()
        old = json.loads(t[t.index("=") + 1:].rstrip().rstrip(";"))
    except (OSError, ValueError):
        pass
    data = {"built": time.strftime("%Y-%m-%d %H:%M"), "shelters": old.get("shelters", []), "open": old.get("open", []),
            "drc": old.get("drc", []), "decl": old.get("decl", {"type": "FeatureCollection", "features": []})}
    notes = []
    try:
        data["shelters"], how = shelters(u, dest, cache)
        print(f"  registered shelters: {len(data['shelters']):,} ({how})")
    except Exception as ex:  # noqa: BLE001
        notes.append(f"registered shelters: {ex}"); print(f"  ! registered shelters: {ex} — keeping the copy already on the drive")
    st = ",".join(f"'{s}'" for s in EAST)
    for key, url, label, where in (("open", OPEN, "open shelters", f"state IN ({st})"), ("drc", DRC, "Disaster Recovery Centers", f"state IN ({st})")):
        try:
            rows = snapshot(u, url, label, where)
            data[key] = [{k: v for k, v in r.items() if isinstance(v, (str, int, float)) or v is None} for r in rows]
            print(f"  {label} right now: {len(rows):,}")
        except Exception as ex:  # noqa: BLE001
            try:                                                 # the state filter failed: take the whole layer
                rows = snapshot(u, url, label)
                data[key] = [{k: v for k, v in r.items() if isinstance(v, (str, int, float)) or v is None} for r in rows]
                print(f"  {label} right now: {len(rows):,}")
            except Exception as ex2:  # noqa: BLE001
                notes.append(f"{label}: {ex2 or ex}"); print(f"  ! {label}: {ex2} — keeping the older snapshot")
    try:
        dec = declarations(u)
        shapes = counties(u, cache)
        feats = []
        today = datetime.date.today().isoformat()
        for key, ds in dec.items():
            if key not in shapes:
                continue
            ds.sort(key=lambda d: d["date"], reverse=True)
            open_ = [d for d in ds if not d["closed"]]
            open_ia = [d for d in open_ if d["ia"] and (not d["file_by"] or d["file_by"] >= today)]
            feats.append({"type": "Feature", "geometry": {"type": "MultiPolygon", "coordinates": [[r] for r in shapes[key]]},
                          "properties": {"name": f"{ds[0]['area']}, {ds[0]['state']}", "decls": ds[:6],
                                         "open": bool(open_), "open_ia": bool(open_ia)}})
        data["decl"] = {"type": "FeatureCollection", "features": feats}
        print(f"  disaster-declared counties (2 years): {len(feats):,}, individual help still open in {sum(f['properties']['open_ia'] for f in feats):,}")
    except Exception as ex:  # noqa: BLE001
        notes.append(f"declarations: {ex}"); print(f"  ! disaster declarations: {ex} — keeping the older copy")
    if not (data["shelters"] or data["open"] or data["drc"] or data["decl"]["features"]):
        print("  ! nothing could be downloaded — run UPDATE-FEMA-AND-RIVER-CHARTS again with internet")
        return
    with open(os.path.join(dest, "www", "data", "fema.js"), "w", encoding="utf-8") as fh:
        fh.write("window.FEMA=" + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n")
    write_kml(dest, data)
    os.makedirs(os.path.join(dest, "REPORTS"), exist_ok=True)
    with open(os.path.join(dest, "REPORTS", "FEMA-DATA.txt"), "w", encoding="utf-8") as fh:
        fh.write(f"FEMA data — {data['built']}\n  registered shelters {len(data['shelters']):,}\n  open shelters {len(data['open']):,}\n"
                 f"  recovery centers {len(data['drc']):,}\n  declared counties {len(data['decl']['features']):,}\n"
                 + ("".join(f"  ! {n}\n" for n in notes) if notes else ""))


def near(dest, lat, lon, miles):
    """Registered shelters within `miles` (for printable maps / guides): [[name, lat, lon, ...]]."""
    try:
        t = open(os.path.join(dest, "www", "data", "fema.js"), encoding="utf-8").read()
        rows = json.loads(t[t.index("=") + 1:].rstrip().rstrip(";"))["shelters"]
    except (OSError, ValueError, KeyError):
        return []
    dla, dlo = miles / 69.0, miles / 50.0
    return [r for r in rows if abs(r[1] - lat) <= dla and abs(r[2] - lon) <= dlo]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    sys.path.insert(0, HERE)
    import usb_builder
    build(usb_builder, a.dest)
