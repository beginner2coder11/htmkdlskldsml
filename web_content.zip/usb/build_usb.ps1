# Builds the OFF-GRID SURVIVAL DRIVE from a Windows computer.
# Usage: double-click BUILD-USB-WINDOWS.bat   (or: powershell -ExecutionPolicy Bypass -File build_usb.ps1 -Drive E [builder options])
param([string]$Drive = "", [Parameter(ValueFromRemainingArguments = $true)] $Rest)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host " OFF-GRID SURVIVAL DRIVE BUILDER" -ForegroundColor Yellow
Write-Host " ------------------------------"
Get-Volume | Where-Object { $_.DriveLetter -and ($_.DriveType -eq 'Removable' -or $_.DriveType -eq 'Fixed') } |
  Sort-Object DriveLetter | Format-Table DriveLetter, FileSystemLabel, FileSystem, DriveType,
  @{n='SizeGB';e={[math]::Round($_.Size/1GB)}}, @{n='FreeGB';e={[math]::Round($_.SizeRemaining/1GB)}} -AutoSize
if (-not $Drive) { $Drive = Read-Host "Type the USB drive letter (for example E)" }
$Drive = $Drive.Trim().TrimEnd(':', '\').ToUpper()
if ($Drive -eq 'C') { Write-Host "Refusing to use C: - pick the USB drive." -ForegroundColor Red; exit 1 }
$vol = Get-Volume -DriveLetter $Drive
if ($vol.FileSystem -eq 'FAT32') {
  Write-Host "Drive $Drive is FAT32, which can't hold files over 4 GB (AI models and archives)." -ForegroundColor Red
  Write-Host "Back up anything on it, then format it as exFAT: File Explorer > right-click the drive > Format > File system: exFAT."
  Write-Host "(exFAT works on Windows, Mac and Linux.)"
  exit 1
}
Write-Host ("Using {0}: ({1}, {2} GB free)" -f $Drive, $vol.FileSystem, [math]::Round($vol.SizeRemaining / 1GB))
$root = "${Drive}:\OFFGRID"
New-Item -ItemType Directory -Force -Path "$root\tools" | Out-Null

# Portable Python (also used later by the drive's web server on other Windows PCs)
$env:PYTHONUTF8 = "1"
$env:PYTHONDONTWRITEBYTECODE = "1"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }   # show dashes and arrows properly
$py = "$root\tools\python-win\python.exe"
if (-not (Test-Path $py)) {
  Write-Host "Downloading portable Python..."
  $zip = "$env:TEMP\python-embed.zip"
  Invoke-WebRequest -UseBasicParsing -Uri "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip" -OutFile $zip
  Expand-Archive -Force -Path $zip -DestinationPath "$root\tools\python-win"
  Remove-Item $zip
}

# keep the computer awake while building (released automatically when this window closes)
try {
  Add-Type -Namespace OffGrid -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);'
  [void][OffGrid.Power]::SetThreadExecutionState([uint32]"0x80000001")
  Write-Host "Keeping this computer awake until the build finishes (plug it in)." -ForegroundColor Yellow
} catch { Write-Host "Tip: set Sleep to Never while building, or the downloads will pause." }

& $py "$here\usb_builder.py" --dest $root @Rest
if ($LASTEXITCODE -ne 0) { Write-Host "Builder reported a problem - re-run to resume." -ForegroundColor Red }
else {
  Write-Host "`nAll done. Opening the drive and its checklist - double-click START-HERE.bat, then START THE DRIVE." -ForegroundColor Green
  try { Start-Process explorer.exe $root } catch { }
  if (Test-Path "$root\REPORTS\DRIVE-CHECKLIST.html") { try { Start-Process "$root\REPORTS\DRIVE-CHECKLIST.html" } catch { } }
}
