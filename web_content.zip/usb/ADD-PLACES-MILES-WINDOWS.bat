@echo off
REM Add hospitals, pharmacies, food, restaurants, gun shops, pawn shops, fuel, water ... within a RADIUS of home.
REM Type 500 the first time; later type 600, 700 ... to widen it (about 9 GB of state extracts at 500, 15 GB at 800; kept for re-use).
REM Optional: pass the drive letter, e.g.  ADD-PLACES-MILES-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
set MILES=
set /p MILES= How many miles around home? (500, 600, 700 ... press Enter for 500): 
if "%MILES%"=="" set MILES=500
echo.
echo  Building the %MILES%-mile places layer on %DRIVE%:\OFFGRID  (nothing else will download)
echo  Needs about 10 GB free. One state at a time; close and re-run anytime - finished states are kept.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --places-only --places-radius %MILES%
pause
