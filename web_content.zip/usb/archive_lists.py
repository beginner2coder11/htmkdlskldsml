"""Archive contents: a browsable list of what is inside every Kiwix archive (.zim) - articles, books, videos,
exercises - each with a link that opens it through Kiwix.

  www/archives/index.js        all archives: name, description, size, counts by kind
  www/archives/<stem>.js       one archive's items  [title, path, group, kind]   kind: a article, b book file, v video, u audio
  www/archives.html            the page (filter box, kind and group pickers, paging)

Archives up to 400,000 entries are listed whole (Gutenberg's books, Khan Academy's videos and exercises, ...).
Bigger ones (full Wikipedia: ~7 million) list the survival-relevant articles picked by zim_index, grouped by topic;
everything else in them is one search away when the drive is started. Unchanged archives aren't re-read."""
import glob, json, os, re

MAX_LIST = 400000
KIND = (("video/", "v"), ("audio/", "u"), ("application/epub", "b"), ("application/pdf", "b"), ("text/html", "a"))


def _js(var, obj):
    return f"window.{var}=" + json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + ";\n"


def _meta(a, key):
    try:
        return bytes(a.get_metadata(key)).decode("utf-8", "replace")
    except Exception:  # noqa: BLE001
        return ""


def _group(path):
    p = path.split("/")
    return p[0] if len(p) > 1 and len(p[0]) < 40 else ""


def build(dest, label=None):
    import zim_index
    zims = sorted(glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim")))
    out = os.path.join(dest, "www", "archives")
    os.makedirs(out, exist_ok=True)
    try:
        old = json.loads(open(os.path.join(out, "index.json"), encoding="utf-8").read())
    except (OSError, ValueError):
        old = {}
    index, n_new = {}, 0
    have = None
    for z in zims:
        stem = os.path.splitext(os.path.basename(z))[0]
        st = os.stat(z)
        sub = zim_index.subset_file(dest, stem)
        sig = [st.st_size, int(st.st_mtime), os.path.getmtime(sub) if os.path.exists(sub) else 0, 2]
        if stem in old and old[stem].get("sig") == sig and os.path.exists(os.path.join(out, stem + ".js")):
            index[stem] = old[stem]
            continue
        if have is None:
            have = zim_index.ensure_libzim(dest)
        name = (label(stem)[0] if label else stem)
        row = {"sig": sig, "name": name, "desc": "", "gb": round(st.st_size / 1024 ** 3, 2), "counts": {}, "note": "", "listed": 0}
        items = []
        if have:
            try:
                from libzim.reader import Archive
                a = Archive(z)
                row["name"] = _meta(a, "Title") or name
                row["desc"] = _meta(a, "Description")
                if a.entry_count <= MAX_LIST:
                    seen = set()
                    for i in range(a.entry_count):
                        try:
                            e = a._get_entry_by_id(i) if hasattr(a, "_get_entry_by_id") else a.get_entry_by_id(i)
                            if e.is_redirect:
                                continue
                            mt = e.get_item().mimetype
                        except Exception:  # noqa: BLE001
                            continue
                        k = next((c for m, c in KIND if mt.startswith(m)), None)
                        if not k:
                            continue
                        t = (e.title or e.path).strip()
                        if k == "a" and (t, k) in seen:
                            continue
                        seen.add((t, k))
                        items.append([t, e.path, _group(e.path), k])
                        if len(items) % 20000 == 0:
                            print(f"\r  Archive contents: {row['name'][:40]:<40} {len(items):,}", end="", flush=True)
                    row["note"] = "Everything in this archive."
                elif os.path.exists(sub):
                    items = [[t, p, tp, "a"] for t, p, tp in json.load(open(sub, encoding="utf-8"))["items"]]
                    row["note"] = (f"{a.entry_count:,} entries - too many to list. These are the {len(items):,} survival-relevant "
                                   "articles (also in the drive's search and meaning search), by topic. Search for anything else.")
                else:
                    row["note"] = f"{a.entry_count:,} entries - too many to list. Search it from Search everything while the drive is started."
            except Exception as ex:  # noqa: BLE001
                row["note"] = f"Could not read this archive ({type(ex).__name__})."
        else:
            row["note"] = "Not listed yet (the archive reader, python-libzim, needs internet once)."
        items.sort(key=lambda x: (x[2], x[0].lower()))
        for _m, k in KIND:
            row["counts"][k] = sum(1 for x in items if x[3] == k)
        row["listed"] = len(items)
        with open(os.path.join(out, stem + ".js"), "w", encoding="utf-8") as fh:
            fh.write(_js("ZLIST", {"stem": stem, "name": row["name"], "note": row["note"], "items": items}))
        index[stem] = row
        n_new += 1
        if items:
            print(f"\r  Archive contents: {row['name'][:40]:<40} {len(items):,} listed")
    for f in glob.glob(os.path.join(out, "*.js")):           # archives that were removed
        st = os.path.splitext(os.path.basename(f))[0]
        if st not in index and st != "index":
            os.remove(f)
    with open(os.path.join(out, "index.json"), "w", encoding="utf-8") as fh:
        json.dump(index, fh)
    with open(os.path.join(out, "index.js"), "w", encoding="utf-8") as fh:
        fh.write(_js("ZARCH", [dict(stem=k, **{x: v for x, v in r.items() if x != "sig"}) for k, r in index.items()]))
    return len(index), n_new


if __name__ == "__main__":
    import argparse, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    print("  %d archives listed (%d re-read)" % build(ap.parse_args().dest))
