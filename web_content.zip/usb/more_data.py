﻿"""Extra offline data: Kolibri (education), Geofabrik regional map extracts, FCC amateur-radio call signs.

Each function is a builder step: resumable, skips what is already on the drive, never needs AI.
"""
import csv, io, json, os, re, subprocess, sys, time, urllib.request, zipfile

GEOFABRIK = "https://download.geofabrik.de/north-america/us/{}-latest.osm.pbf"
DEFAULT_STATES = "georgia"
KOLIBRI_API = "https://api.github.com/repos/learningequality/kolibri/releases/latest"
KHAN_CHANNEL = "c9d7f950ab6b5a1199e3d6c10d7f0103"     # Khan Academy (English - US curriculum), verified on Studio
FCC_URL = "https://data.fcc.gov/download/pub/uls/complete/l_amat.zip"
CLASS = {"T": "Technician", "G": "General", "A": "Advanced", "E": "Extra", "N": "Novice", "P": "Tech Plus"}


def geofabrik(u, dest, states):
    """Download regional .osm.pbf extracts into OSM-MAP-SOURCE; pbf_convert turns them into offline map layers."""
    src = os.path.join(dest, "OSM-MAP-SOURCE")
    os.makedirs(src, exist_ok=True)
    for s in [x.strip().lower().replace(" ", "-") for x in states.split(",") if x.strip()]:
        if not re.fullmatch(r"[a-z-]+", s):
            print(f"  ! bad region name: {s}")
            continue
        out = os.path.join(src, f"{s}.osm.pbf")
        if os.path.exists(os.path.join(dest, "www", "map", s + ".pmtiles")) and not os.path.exists(out):
            print(f"  {s}: already converted into a map layer (source file was cleaned up)")
            continue
        if os.path.exists(out):
            age = (time.time() - os.path.getmtime(out)) / 86400
            print(f"  {s}: already here ({age:.0f} days old; delete the file to refresh)")
            continue
        print(f"  Geofabrik {s} ...")
        if not u.download(GEOFABRIK.format(s), out, f"{s}.osm.pbf"):
            print(f"  ! {s}: not downloaded (see https://download.geofabrik.de/north-america/us.html for names)")


def kolibri(u, dest, channels=""):
    """Kolibri installers (Windows exe, portable .pex, Android apk) + optional channel content for offline use."""
    kd = os.path.join(dest, "tools", "kolibri")
    os.makedirs(kd, exist_ok=True)
    try:
        rel = json.loads(u.fetch(KOLIBRI_API, timeout=60))
    except Exception as e:  # noqa: BLE001
        print(f"  ! Kolibri release lookup failed: {e}")
        return
    want = (".exe", ".pex", ".apk")
    for asset in rel.get("assets", []):
        n = asset["name"]
        if n.endswith(want) and "pi-image" not in n:
            u.download(asset["browser_download_url"], os.path.join(kd, n), n)
    pex = next((os.path.join(kd, f) for f in os.listdir(kd) if f.endswith(".pex")), None)
    home = os.path.join(dest, "kolibri-data")
    if pex:
        bat = ('@echo off\r\ncd /d "%~dp0"\r\nset KOLIBRI_HOME=%~dp0..\\..\\kolibri-data\r\n'
               'set PEX=' + os.path.basename(pex) + '\r\n'
               'echo Kolibri will open at http://localhost:8080 (close this window to stop it)\r\n'
               'start "" http://localhost:8080\r\n..\\python-win\\python.exe %PEX% start --foreground\r\n')
        with open(os.path.join(kd, "START-KOLIBRI.bat"), "w", newline="") as fh:
            fh.write(bat)
    ids = [c.strip() for c in channels.split(",") if c.strip()]
    py = os.path.join(dest, "tools", "python-win", "python.exe")
    if not os.path.exists(py):
        py = sys.executable
    env = dict(os.environ, KOLIBRI_HOME=home)
    for cid in ids:
        if not pex:
            break
        if not re.fullmatch(r"[0-9a-f]{32}", cid):
            print(f"  ! not a channel id: {cid}")
            continue
        print(f"  Kolibri channel {cid} (large; resumable) ...")
        for cmd in (["manage", "importchannel", "network", cid], ["manage", "importcontent", "--skip-checks", "network", cid]):
            subprocess.call([py, pex] + cmd, env=env)
    with open(os.path.join(kd, "README.txt"), "w") as fh:
        fh.write("Kolibri offline education platform.\r\n"
                 "Windows: run kolibri-*-windows-setup.exe once, or START-KOLIBRI.bat (portable, uses tools\\python-win).\r\n"
                 "Android: install the .apk. Content lives in OFFGRID\\kolibri-data.\r\n"
                 "To add courses: python usb_builder.py --dest <drive> --kolibri-channels " + KHAN_CHANNEL + "\r\n"
                 "  (that id = Khan Academy English; find more ids at https://studio.learningequality.org/)\r\n")


def _fcc_zip(u, dest, offline=False):
    z = os.path.join(dest, "tools", "fcc", "l_amat.zip")
    import glob as _g, shutil as _s                   # one you downloaded yourself and dropped on the drive
    for c in _g.glob(os.path.join(dest, "MY-RADIO-INBOX", "**", "l_amat*.zip"), recursive=True) + \
            _g.glob(os.path.join(dest, "MY-FILES-INBOX", "**", "l_amat*.zip"), recursive=True):
        os.makedirs(os.path.dirname(z), exist_ok=True)
        _s.move(c, z)
        print("  using the l_amat.zip you added")
    if offline:
        return z
    if os.path.exists(z) and time.time() - os.path.getmtime(z) > 45 * 86400:
        os.remove(z)                       # weekly FCC file; refresh when the drive is updated after 45 days
    u.download(FCC_URL, z, "FCC amateur licences")
    return z


def hamcalls(u, dest, offline=False):
    """FCC amateur licences -> searchable offline page (by call sign, or by name / city / ZIP)."""
    out = os.path.join(dest, "www", "data", "ham")
    z = _fcc_zip(u, dest, offline)
    if not os.path.exists(z):
        return
    if os.path.exists(os.path.join(out, "meta.json")) and os.path.getmtime(os.path.join(out, "meta.json")) > os.path.getmtime(z) \
            and os.path.isdir(os.path.join(out, "st")):
        print("  call sign index is current")
        return
    os.makedirs(out, exist_ok=True)

    def rows(zf, name):
        with zf.open(name) as fh:
            for line in io.TextIOWrapper(fh, encoding="latin-1", newline=""):
                yield line.rstrip("\r\n").split("|")

    with zipfile.ZipFile(z) as zf:
        active = {r[4] for r in rows(zf, "HD.dat") if len(r) > 5 and r[5] == "A"}
        cls = {r[4]: CLASS.get(r[5], r[5]) for r in rows(zf, "AM.dat") if len(r) > 5 and r[4] in active}
        recs = {}
        for r in rows(zf, "EN.dat"):
            if len(r) < 19 or r[4] not in active or r[4] in recs:
                continue
            name = (r[7] if r[5] != "I" or not r[10] else f"{r[8]} {r[10]}".strip()) or r[7]
            recs[r[4]] = [r[4], name.strip(), r[16].strip(), r[17].strip(), r[18][:5], cls.get(r[4], "")]
    by_call, by_zip, by_st = {}, {}, {}
    for rec in recs.values():
        by_call.setdefault(rec[0][:2], []).append(rec)
        by_zip.setdefault(rec[4][:3] or "000", []).append(rec)
        if re.fullmatch(r"[A-Z]{2}", rec[3] or ""):
            by_st.setdefault(rec[3], []).append(rec)
    for sub, groups in (("c", by_call), ("z", by_zip), ("st", by_st)):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
        for k, v in groups.items():
            with open(os.path.join(out, sub, k + ".js"), "w", encoding="utf-8") as fh:
                fh.write(f'window.HAM_{sub.upper()}["{k}"]=' + json.dumps(sorted(v), separators=(",", ":")) + ";\n")
    with open(os.path.join(out, "meta.json"), "w") as fh:
        json.dump({"count": len(recs), "built": time.strftime("%Y-%m-%d"), "call2": sorted(by_call), "zip3": sorted(by_zip)}, fh)
    print(f"  {len(recs):,} active amateur licences indexed")
    u.CHANGES.append("ham call signs")


ISED_URL = "http://apc-cap.ic.gc.ca/datafiles/amateur_delim.zip"
ISED_QUAL = ["Basic", "5 WPM", "12 WPM", "Advanced", "Basic+Honours"]


def hamcalls_canada(u, dest, offline=False):
    """Canada's amateur call signs (ISED amateur_delim.zip, ~92,000) -> the same offline lookup: by call sign (VE2..., VA3...)
    or by the first 3 characters of a postal code (H3A, K1P...). Dropped-in copies in MY-RADIO-INBOX are used too."""
    import glob as _g, shutil as _s
    z = os.path.join(dest, "tools", "fcc", "amateur_delim.zip")
    for c in _g.glob(os.path.join(dest, "MY-RADIO-INBOX", "**", "amateur_delim*.zip"), recursive=True) + \
            _g.glob(os.path.join(dest, "MY-FILES-INBOX", "**", "amateur_delim*.zip"), recursive=True):
        os.makedirs(os.path.dirname(z), exist_ok=True)
        _s.move(c, z)
        print("  using the amateur_delim.zip (Canada) you added")
    if not offline:
        if os.path.exists(z) and time.time() - os.path.getmtime(z) > 45 * 86400:
            os.remove(z)
        if not os.path.exists(z):
            u.download(ISED_URL, z, "Canadian amateur call signs (ISED)")
    if not os.path.exists(z):
        return
    out = os.path.join(dest, "www", "data", "ham")
    mp = os.path.join(out, "meta-ca.json")
    if os.path.exists(mp) and os.path.getmtime(mp) > os.path.getmtime(z) and os.path.isdir(os.path.join(out, "st")):
        print("  Canadian call sign index is current")
        return
    by_call, by_post, by_st, n = {}, {}, {}, 0
    with zipfile.ZipFile(z) as zf:
        name = next(x for x in zf.namelist() if x.lower().endswith("amateur_delim.txt"))
        with zf.open(name) as fh:
            for i, line in enumerate(io.TextIOWrapper(fh, encoding="utf-8", errors="replace", newline="")):
                r = line.rstrip("\r\n").split(";")
                if i == 0 or len(r) < 12 or not r[0]:
                    continue
                quals = ", ".join(q for q, f in zip(ISED_QUAL, r[7:12]) if f.strip())
                who = (f"{r[1]} {r[2]}".strip() or r[12]).strip()
                post = r[6].replace(" ", "").upper()
                rec = [r[0].upper(), who, r[4].strip().title(), r[5].strip(), post, quals]
                by_call.setdefault(rec[0][:2], []).append(rec)
                if post[:3]:
                    by_post.setdefault(post[:3], []).append(rec)
                if re.fullmatch(r"[A-Z]{2}", rec[3] or ""):
                    by_st.setdefault(rec[3], []).append(rec)
                n += 1
    for sub, groups in (("c", by_call), ("z", by_post), ("st", by_st)):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
        for k, v in groups.items():
            with open(os.path.join(out, sub, k + ".js"), "w", encoding="utf-8") as fh:
                fh.write(f'window.HAM_{sub.upper()}["{k}"]=' + json.dumps(sorted(v), separators=(",", ":"), ensure_ascii=False) + ";\n")
    with open(mp, "w") as fh:
        json.dump({"count": n, "built": time.strftime("%Y-%m-%d")}, fh)
    print(f"  {n:,} Canadian amateur call signs indexed")
    if hasattr(u, "CHANGES"):
        u.CHANGES.append("Canadian ham call signs")


HAM_PAGE = """<!doctype html><meta charset=utf-8><title>Ham radio call signs</title>
<meta name=viewport content="width=device-width,initial-scale=1">
<style>body{font:16px system-ui;max-width:52rem;margin:1.5rem auto;padding:0 1rem}input,button{font-size:1rem;padding:.4rem}
table{border-collapse:collapse;width:100%;margin-top:1rem}td,th{border-bottom:1px solid #ccc;padding:.3rem;text-align:left}small{color:#666}</style>
<h1>Ham radio call signs (US FCC + Canada ISED)</h1>
<p><input id=q placeholder="call sign (W4ABC, VE2XYZ), ZIP, postal code (G1R), or city, ST (Albany, NY / Quebec, QC)" size=60 autofocus>
<button onclick=go()>Look up</button> <small id=meta></small></p>
<p><small>Type a call sign for one record; a ZIP (or the first 3 digits) lists licensed operators nearby; add a name
after the ZIP to filter, e.g. <code>30114 smith</code>. Canada: the first 3 characters of a postal code, e.g. <code>G1R</code> (Québec City)
or <code>M5V</code> (Toronto). By town: <code>Canton, GA</code>, <code>Montreal, QC</code>, or just <code>QC</code> for a whole
state/province. Canadian classes are Basic, Basic+Honours, Advanced, Morse.</small></p>
<div id=out></div>
<script>
window.HAM_C={};window.HAM_Z={};window.HAM_ST={};
function load(kind,key){return new Promise(function(ok){if(window['HAM_'+kind.toUpperCase()][key])return ok();
var s=document.createElement('script');s.src='data/ham/'+kind+'/'+key+'.js';s.onload=ok;s.onerror=ok;document.head.appendChild(s);});}
fetch('data/ham/meta.json').then(r=>r.json()).then(m=>{document.getElementById('meta').textContent=m.count.toLocaleString()+' US licences ('+m.built+')'}).catch(()=>{});
fetch('data/ham/meta-ca.json').then(r=>r.json()).then(m=>{document.getElementById('meta').textContent+=' · '+m.count.toLocaleString()+' Canadian ('+m.built+')'}).catch(()=>{});
function show(list){var h='<table><tr><th>Call</th><th>Name</th><th>City</th><th>State</th><th>ZIP</th><th>Class</th></tr>';
list.slice(0,300).forEach(function(r){h+='<tr>'+r.map(function(c){return '<td>'+String(c).replace(/[&<]/g,'')+'</td>'}).join('')+'</tr>'});
document.getElementById('out').innerHTML=list.length?h+'</table>'+(list.length>300?'<p>'+list.length+' matches; showing 300 - narrow the search.</p>':''):'<p>No matches.</p>';}
async function go(){var q=document.getElementById('q').value.trim().toUpperCase();if(!q)return;
var m=q.match(/^(.*?)[,\\s]+([A-Z]{2})$/)||q.match(/^()([A-Z]{2})$/);
if(m&&(m[1]||q.length==2)&&!/\\d/.test(q)){await load('st',m[2]);var na=function(t){return String(t).normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toUpperCase().replace(/^(ST|SAINT)[-. ]+/,'SAINT ')};
var city=na(m[1].trim());show((window.HAM_ST[m[2]]||[]).filter(function(r){return !city||na(r[2]).indexOf(city)==0}));return;}
var p=q.split(/\\s+/);
if(/^\\d{3,5}$/.test(p[0])){var k=p[0].slice(0,3);await load('z',k);var l=(window.HAM_Z[k]||[]).filter(function(r){return r[4].indexOf(p[0])==0&&(p.length<2||(r[1]+' '+r[2]).toUpperCase().indexOf(p.slice(1).join(' '))>=0)});show(l);}
else if(/^[A-Z]\\d[A-Z](\\d[A-Z]\\d)?$/.test(p.join(''))){var pc=p.join(''),k=pc.slice(0,3);await load('z',k);var l=(window.HAM_Z[k]||[]).filter(function(r){return r[4].indexOf(pc)==0});
if(l.length){show(l);return;}var c=pc.slice(0,2);await load('c',c);show((window.HAM_C[c]||[]).filter(function(r){return r[0].indexOf(pc)==0}));}
else{var c=p[0].slice(0,2);await load('c',c);show((window.HAM_C[c]||[]).filter(function(r){return r[0].indexOf(p[0])==0}));}}
document.getElementById('q').addEventListener('keydown',function(e){if(e.key=='Enter')go()});
</script>
"""


def ham_page(dest):
    with open(os.path.join(dest, "www", "ham-calls.html"), "w", encoding="utf-8") as fh:
        fh.write(HAM_PAGE)
