"""Tidy the drive: move files that are no longer needed into _TIDY-BIN, never straight to deletion.

Things moved: the old "START HERE" folder and OPEN-THESE-PAGES (the Command Center and START-HERE.bat replace them),
the old top-level update scripts, and leftovers of interrupted runs (*.part, *.tmp, *.new, Thumbs.db, desktop.ini,
.DS_Store, __pycache__). Your own files, the library, maps, archives, notes and MY-*-INBOX folders are never touched.
Bin folders older than 30 days are deleted on the next run. Everything moved is listed in REPORTS\\TIDY-REPORT.txt.

    python tidy.py --dest E:\\OFFGRID            move now
    python tidy.py --dest E:\\OFFGRID --empty    also empty the bin right away
"""
import argparse
import fnmatch
import glob
import json
import os
import re
import shutil
import time

BIN = "_TIDY-BIN"
OLD_DIRS = ["START HERE", "OPEN-THESE-PAGES"]
OLD_FILES = ["UPDATE-DRIVE-WINDOWS.bat", "update-drive-mac-linux.sh",
             "www/library/State Highway Maps/NOT-FETCHED.txt", "www/library/Commandants Reading List/NOT-FETCHED.txt",
             "www/library/Joint & Service Doctrine/NOT-FETCHED.txt"]
JUNK = ("*.part", "*.tmp", "*.new", "*.building", "*.restoring", "*.part.pdf", "Thumbs.db", "desktop.ini", ".DS_Store", "~$*")
# where junk is looked for (not the big library / map / archive folders, which are too large to walk and hold user files)
JUNK_DIRS = ["", "PROGRAMS", "REPORTS", "PLATFORMS", "www", "tools/builder", "tools"]
KEEP_AGE_DAYS = 30


def _move(dest, rel, stamp, log):
    src = os.path.join(dest, *rel.split("/"))
    if not os.path.exists(src):
        return False
    dst = os.path.join(dest, BIN, stamp, *rel.split("/"))
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.exists(dst):
            dst += "." + str(int(time.time()))
        shutil.move(src, dst)
        log.append(rel)
        return True
    except OSError as e:
        log.append(f"{rel}   (could not move: {e})")
        return False


def _dir_gb(p):
    n = 0
    for r, _, fs in os.walk(p):
        for f in fs:
            try:
                n += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return n / 1e9


def _leftovers(dest):
    """Big scratch/source files that are no longer needed once their results are on the drive. Deleted, not binned (too big)."""
    out = []
    tmp = os.path.join(dest, "tools", "planetiler-tmp")                 # map converter scratch (tens of GB after an interrupted run)
    if os.path.isdir(tmp) and not glob.glob(os.path.join(dest, "www", "map", "*.part")):
        gb = _dir_gb(tmp)
        shutil.rmtree(tmp, ignore_errors=True)
        out.append(f"tools/planetiler-tmp  (map-converter scratch, {gb:.1f} GB)")
    try:
        done = json.load(open(os.path.join(dest, "www", "data", "poi500", "index.json"), encoding="utf-8")).get("states", {})
    except (OSError, ValueError):
        done = {}
    for st in done:                                                     # OpenStreetMap extracts already turned into places
        p = os.path.join(dest, "tools", "poi-source", st + ".osm.pbf")
        if os.path.isfile(p):
            try:
                gb = os.path.getsize(p) / 1e9
                os.remove(p)
                out.append(f"tools/poi-source/{st}.osm.pbf  (already converted, {gb:.1f} GB)")
            except OSError:
                pass
    return out


def _stale(p, days=1):
    try:
        return (time.time() - os.path.getmtime(p)) / 86400 > days
    except OSError:
        return False


def _leftovers_v78(dest):
    """Scratch left by interrupted runs in places the junk walk does not reach (deleted; all can be remade)."""
    out = []
    pats = ["www/search/*.building", "www/search/*.tmp", "www/search/vec/docs/*.tmp", "www/tiles/imagery/*-journal",
            "www/tiles/imagery/*.part", "www/phone-apps/satellite/*.part", "PRINTABLE MAPS/*.part.pdf", "ai/memory/*-journal",
            "tools/fema-cache/*.zip", "GOOGLE-EARTH-READY/River charts (IENC)/*.part"]
    for pat in pats:
        for p in glob.glob(os.path.join(dest, *pat.split("/"))):
            if os.path.isfile(p) and _stale(p):
                try:
                    mb = os.path.getsize(p) / 1e6
                    os.remove(p)
                    out.append(f"{os.path.relpath(p, dest)}  (unfinished scratch file, {mb:,.0f} MB)")
                except OSError:
                    pass
    for d in glob.glob(os.path.join(dest, "BACKUP", "INDEXES", "*.partial")) + [os.path.join(dest, "ai", "dl"), os.path.join(dest, ".kbbuild")]:
        if os.path.isdir(d) and _stale(d):
            gb = _dir_gb(d)
            shutil.rmtree(d, ignore_errors=True)
            out.append(f"{os.path.relpath(d, dest)}  (unfinished backup / download / build folder, {gb:.2f} GB)")
    return out


def suggestions(dest):
    """REPORTS\\CLEANUP-SUGGESTIONS.txt: things you may want to delete yourself (never removed automatically)."""
    import hashlib
    lines = [f"CLEANUP SUGGESTIONS - {time.strftime('%Y-%m-%d %H:%M')}", "Nothing here is deleted automatically. Check, then delete what you don't need.", ""]
    # 1. identical files (same content twice) in the library and your own files
    by_size = {}
    for top in ("www/library", "MY-FILES", "library"):
        base = os.path.join(dest, *top.split("/"))
        for r, _d, fs in os.walk(base):
            for f in fs:
                p = os.path.join(r, f)
                try:
                    sz = os.path.getsize(p)
                except OSError:
                    continue
                if sz >= 200_000:
                    by_size.setdefault(sz, []).append(p)
    dups, wasted = [], 0
    for sz, ps in by_size.items():
        if len(ps) < 2:
            continue
        by_hash = {}
        for p in ps:
            h = hashlib.sha256()
            try:
                with open(p, "rb") as fh:
                    for b in iter(lambda: fh.read(1 << 20), b""):
                        h.update(b)
            except OSError:
                continue
            by_hash.setdefault(h.hexdigest(), []).append(p)
        for same in by_hash.values():
            if len(same) > 1:
                dups.append((sz, same))
                wasted += sz * (len(same) - 1)
    lines.append(f"1. SAME FILE MORE THAN ONCE: {len(dups)} sets, {wasted / 1e9:.2f} GB could be freed (keep one of each)")
    for sz, same in sorted(dups, key=lambda x: -x[0] * len(x[1]))[:200]:
        lines.append(f"   {sz / 1e6:,.1f} MB x {len(same)}:")
        lines += [f"      {os.path.relpath(p, dest)}" for p in same]
    # 2. caches that only speed up the next refresh
    lines += ["", "2. DOWNLOAD CACHES (safe to delete; the next refresh downloads them again):"]
    for rel, what in (("tools/corridor-cache", "map extracts used to find places along the routes"),
                      ("tools/poi-source", "map extracts used to find places near home"),
                      ("tools/fema-cache", "FEMA shelter list and county outlines"),
                      ("tools/zim-subsets", "lists of archive articles picked for search (small - keep)"),
                      ("_TIDY-BIN", "files moved by tidy (emptied automatically after 30 days)")):
        p = os.path.join(dest, *rel.split("/"))
        if os.path.isdir(p):
            lines.append(f"   {rel:<24} {_dir_gb(p):7.2f} GB  - {what}")
    # 3. AI models the drive does not use by default
    try:
        used = set()
        for f in ("default-model.txt", "large-model.txt"):
            q = os.path.join(dest, "ai", f)
            if os.path.exists(q):
                used.add(open(q).read().strip())
        roles = json.load(open(os.path.join(dest, "ai", "roles.json")))
        for r in roles.values():
            used |= {r.get("model"), r.get("mmproj")}
        extra = [m for m in glob.glob(os.path.join(dest, "ai", "models", "*.gguf"))
                 if os.path.basename(m) not in used and not re.search(r"embeddinggemma|reranker", m, re.I)]
        if extra:
            lines += ["", "3. AI MODELS NOT SET AS THE MAIN, LARGE, PHOTO OR MEDICAL MODEL (delete if you never pick them):"]
            lines += [f"   {os.path.basename(m):<55} {os.path.getsize(m) / 1e9:5.1f} GB" for m in extra]
    except (OSError, ValueError):
        pass
    # 4. old archive editions next to newer ones
    zims = glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim"))
    stems = {}
    for z in zims:
        stems.setdefault(re.sub(r"_\d{4}-\d{2}\.zim$", "", os.path.basename(z)), []).append(z)
    old = [sorted(v)[:-1] for v in stems.values() if len(v) > 1]
    if any(old):
        lines += ["", "4. OLDER EDITIONS OF ARCHIVES (a newer edition of each is on the drive):"]
        lines += [f"   {os.path.basename(z):<60} {os.path.getsize(z) / 1e9:6.1f} GB" for v in old for z in v]
    os.makedirs(os.path.join(dest, "REPORTS"), exist_ok=True)
    with open(os.path.join(dest, "REPORTS", "CLEANUP-SUGGESTIONS.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(dups), wasted


def _is_running_update(rel):
    return rel in ("PROGRAMS/UPDATE-DRIVE-WINDOWS.bat.new", "PROGRAMS/update-drive-mac-linux.sh.new")


def _empty_old_bins(dest, days):
    b = os.path.join(dest, BIN)
    if not os.path.isdir(b):
        return 0
    n = 0
    for d in sorted(os.listdir(b)):
        p = os.path.join(b, d)
        try:
            age = (time.time() - os.path.getmtime(p)) / 86400
        except OSError:
            continue
        if days == 0 or age > days:
            shutil.rmtree(p, ignore_errors=True)
            n += 1
    if not os.listdir(b):
        os.rmdir(b)
    return n


def run(dest, empty=False):
    dest = os.path.abspath(dest)
    stamp = time.strftime("%Y-%m-%d_%H%M")
    log = []
    for d in OLD_DIRS:
        _move(dest, d, stamp, log)
    for f in OLD_FILES:
        _move(dest, f, stamp, log)
    for sub in JUNK_DIRS:
        base = os.path.join(dest, *sub.split("/")) if sub else dest
        if not os.path.isdir(base):
            continue
        shallow = sub in ("", "tools", "www", "REPORTS")
        for r, dirs, fs in os.walk(base):
            dirs[:] = [x for x in dirs if x not in (BIN, "library", "tiles", "topo", "media", "music", "python-win", "pylib", "phone-apps")]
            for x in list(dirs):
                if x == "__pycache__":                      # a cache Python rebuilds by itself: delete, don't keep in the bin
                    shutil.rmtree(os.path.join(r, x), ignore_errors=True)
                    dirs.remove(x)
            for f in fs:
                if any(fnmatch.fnmatch(f, pat) for pat in JUNK):
                    rel = os.path.relpath(os.path.join(r, f), dest).replace(os.sep, "/")
                    if _is_running_update(rel):
                        continue      # START-HERE swaps these in
                    _move(dest, rel, stamp, log)
            if shallow:
                break
    freed = _leftovers(dest) + _leftovers_v78(dest)
    log += ["DELETED " + x for x in freed]
    gone = _empty_old_bins(dest, 0 if empty else KEEP_AGE_DAYS)
    if log or gone:
        rep = os.path.join(dest, "REPORTS")
        os.makedirs(rep, exist_ok=True)
        with open(os.path.join(rep, "TIDY-REPORT.txt"), "a", encoding="utf-8") as fh:
            fh.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M')}  {len(log)} item(s) moved to {BIN}\\{stamp}; {gone} old bin folder(s) deleted\n")
            fh.write("\n".join("  " + x for x in log) + ("\n" if log else ""))
    for x in freed:
        print(f"  Tidy: deleted {x}")
    print(f"  Tidy: {len(log) - len(freed)} item(s) moved to {BIN}\\{stamp}" + (f", {gone} old bin folder(s) deleted" if gone else "") if log or gone else "  Tidy: nothing to clean up.")
    return len(log)


def build(u, dest):
    u.say("Tidying up")
    n = run(dest)
    try:
        sets, wasted = suggestions(dest)
        print(f"  Cleanup suggestions: {sets} duplicate file sets ({wasted / 1e9:.2f} GB) and caches listed in REPORTS\\CLEANUP-SUGGESTIONS.txt")
    except Exception as e:  # noqa: BLE001
        print(f"  ! cleanup suggestions: {e}")
    return n


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--empty", action="store_true", help="delete the whole tidy bin now")
    a = ap.parse_args()
    run(a.dest, a.empty)
    sets, wasted = suggestions(a.dest)
    print(f"  {sets} duplicate file sets ({wasted / 1e9:.2f} GB) - see REPORTS\\CLEANUP-SUGGESTIONS.txt")
