@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Add your own maps (MIMs, GeoPDFs, KML, GPX, checklists) to this drive =====
REM 1) Put the files (folders are fine) in MY-MAPS-INBOX in this OFFGRID folder.
REM    From Google Drive: open the folder, click its name > Download, then Extract All into MY-MAPS-INBOX.
REM 2) Double-click this file. No internet needed.
cd /d "%~dp0"
title Add my maps
if not exist "MY-MAPS-INBOX" mkdir "MY-MAPS-INBOX"
set PYTHONUTF8=1
tools\python-win\python.exe tools\builder\usb\usb_builder.py --dest "%~dp0." --my-maps-only
echo.
echo  Open Home ^> My Maps to see them, or the Locator map (layer "My maps").
pause
