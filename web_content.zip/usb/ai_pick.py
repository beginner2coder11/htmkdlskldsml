"""Pick the chat model and settings that fit THIS computer (v80).

Called by START-WINDOWS.bat / start-mac-linux.sh before the AI starts. Prints KEY=VALUE lines the launcher reads:
  MODEL, MODELPATH, AIBIN (folder holding llama-server), NGL, CTX, THREADS, LOCALMODELS, SAY1..SAY4
Rules
  * measures total and free memory; never picks a model that would not fit (old 8 GB laptops get the small model)
  * normal: the builder's default model (large one on 30 GB+ machines), stepping down until it fits
  * outage (OFFGRID_MODE=outage): smallest model, shorter memory, half the CPU cores, no graphics card - battery first
  * uses the copy on this computer's own disk (COPY-AI-TO-THIS-COMPUTER) when it matches the drive, else the drive
Stdlib only; never fails the launcher - on any error it prints nothing useful and the launcher falls back to its old logic.
"""
import argparse, ctypes, glob, json, os, platform, subprocess, sys

SKIP = ("mmproj", "embedding", "rerank", "medgemma", "whisper", "ggml-")
GB = 1024 ** 3


def local_root():
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "OFFGRID-AI")
    return os.path.join(os.path.expanduser("~"), ".offgrid-ai")


def memory():
    """(total GB, free GB or None)"""
    try:
        if os.name == "nt":
            class M(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("tot", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                            ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong), ("tv", ctypes.c_ulonglong), ("avv", ctypes.c_ulonglong),
                            ("x", ctypes.c_ulonglong)]
            m = M(); m.l = ctypes.sizeof(M)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.tot / GB, m.av / GB
        if sys.platform == "darwin":
            tot = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])) / GB
            return tot, None                          # macOS frees file cache on demand; total is the useful number
        info = {l.split(":")[0]: int(l.split()[1]) for l in open("/proc/meminfo") if ":" in l}
        return info["MemTotal"] / 1048576, info.get("MemAvailable", info["MemFree"]) / 1048576
    except Exception:  # noqa: BLE001
        return 8.0, None


def chat_models(dest):
    mdir = os.path.join(dest, "ai", "models")
    roles = {}
    try:
        roles = json.load(open(os.path.join(dest, "ai", "roles.json")))
    except (OSError, ValueError):
        pass
    helper = {v.get("model") for k, v in roles.items() if k in ("vision", "medical") and isinstance(v, dict)}
    out = []
    for p in glob.glob(os.path.join(mdir, "*.gguf")):
        n = os.path.basename(p)
        if any(s in n.lower() for s in SKIP) or n in helper:
            continue
        out.append((os.path.getsize(p) / GB, n))
    return sorted(out)                                # smallest first


def need_gb(size, ctx):
    return size * 1.15 + 0.35 + ctx / 8192 * (0.4 + size * 0.12)   # weights + runtime + chat memory (KV cache)


def _read(p):
    try:
        return open(p, encoding="utf-8").read().strip()
    except OSError:
        return ""


def manifest():
    try:
        return json.load(open(os.path.join(local_root(), "manifest.json")))
    except (OSError, ValueError):
        return {}


def local_model(dest, name):
    """Path of this model on the computer's own disk if it is a complete copy of the drive's file."""
    p = os.path.join(local_root(), "models", name)
    try:
        if os.path.getsize(p) == os.path.getsize(os.path.join(dest, "ai", "models", name)):
            return p
    except OSError:
        pass
    return None


def local_bin(dest, bindir):
    """Local copy of the drive's llama.cpp folder (Windows), if it still matches the drive."""
    man = manifest().get("bins", {}).get(bindir)
    src = os.path.join(dest, "ai", "bin", bindir)
    dst = os.path.join(local_root(), "bin", bindir)
    if not man or not os.path.isdir(dst):
        return None
    try:
        for f, size in man.items():
            if os.path.getsize(os.path.join(src, f)) != size or os.path.getsize(os.path.join(dst, f)) != size:
                return None
    except OSError:
        return None
    return dst


def pick(dest, osname, mode="normal", want=""):
    tot, free = memory()
    models = chat_models(dest)
    cores = os.cpu_count() or 4
    r = {"SAY": []}
    if not models:
        return None
    outage = mode == "outage"
    ctx = 2048 if tot < 7 else 4096 if (tot < 12 or outage) else 8192
    budget = tot * 0.72 - 1.2                          # leave room for Windows, the browser and the web server
    if free is not None:
        budget = min(budget, free - 0.6)
    names = [n for _, n in models]
    if want and want in names:
        choice = want
    elif outage:
        choice = names[0]
    else:
        pref = _read(os.path.join(dest, "ai", "default-model.txt"))
        if tot >= 30 and _read(os.path.join(dest, "ai", "large-model.txt")):
            pref = _read(os.path.join(dest, "ai", "large-model.txt"))
        cap = next((s for s, n in models if n == pref), models[-1][0])
        fits = [n for s, n in models if s <= cap + 0.01 and need_gb(s, ctx) <= budget]
        if fits:
            choice = fits[-1]
            if choice != pref and pref:
                r["SAY"].append(f"Low memory ({tot:.0f} GB, {max(free or 0, 0):.1f} GB free): using the smaller model {choice}")
        else:
            choice = names[0]
            ctx = 2048
            r["SAY"].append(f"Very low memory ({tot:.0f} GB): smallest model with short memory - close other programs if the AI is slow")
    size = dict((n, s) for s, n in models)[choice]
    if need_gb(size, ctx) > budget and ctx > 2048:
        ctx = 2048
    # program folder (llama.cpp build)
    if osname == "win":
        gpu = os.path.exists(os.path.join(dest, "ai", "bin", "win-gpu", "llama-server.exe"))
        bindir = "win-gpu" if gpu and not outage else ("win" if os.path.isdir(os.path.join(dest, "ai", "bin", "win")) else "win-gpu")
        aibin = local_bin(dest, bindir) or os.path.join(dest, "ai", "bin", bindir)
        ngl = "-ngl 0" if outage else ("-ngl 99" if bindir == "win-gpu" else "")
        r["LOCALBIN"] = "1" if aibin.startswith(local_root()) else ""
    else:
        aibin, ngl = "", ("-ngl 0" if outage else "-ngl 99")
    lm = local_model(dest, choice)
    r.update(MODEL=choice, MODELPATH=lm or os.path.join(dest, "ai", "models", choice), AIBIN=aibin, NGL=ngl, CTX=str(ctx),
             THREADS=str(max(2, cores // 2)) if outage else "", LOCALMODELS=os.path.join(local_root(), "models") if lm else "")
    if outage:
        r["SAY"].insert(0, f"OUTAGE MODE: small model {choice}, {ctx} memory, {r['THREADS']} CPU cores, graphics card off")
    if lm:
        r["SAY"].append("AI loads from this computer's own disk (faster)")
    elif os.path.isdir(local_root()) and manifest():
        r["SAY"].append("The AI copy on this computer is out of date or lacks this model - run COPY-AI-TO-THIS-COMPUTER again")
    r["RAMGB"] = str(int(round(tot)))
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=".")
    ap.add_argument("--os", default="win" if os.name == "nt" else "unix")
    ap.add_argument("--mode", default=os.environ.get("OFFGRID_MODE", "normal"))
    ap.add_argument("--model", default="")
    ap.add_argument("--sh", action="store_true", help="print shell assignments (Mac/Linux)")
    a = ap.parse_args()
    try:
        r = pick(os.path.abspath(a.dest), a.os, a.mode.lower(), a.model)
    except Exception as e:  # noqa: BLE001
        print(f"SAY1=Model check skipped ({type(e).__name__}) - using the default model")
        return
    if not r:
        return
    says = r.pop("SAY")
    for i, s in enumerate(says[:4], 1):
        r[f"SAY{i}"] = s
    for k, v in r.items():
        if a.sh:
            print(f"{k}='" + str(v).replace("'", "'\\''") + "'")
        else:
            print(f"{k}={v}")


if __name__ == "__main__":
    main()
