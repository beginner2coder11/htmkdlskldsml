#!/bin/sh
# ===== OFF-GRID SURVIVAL DRIVE — macOS / Linux launcher =====
# Run:  sh /path/to/OFFGRID/start-mac-linux.sh      (Ctrl+C stops everything)
cd "$(dirname "$0")" || exit 1
ROOT=$(pwd)
OS=$(uname -s); ARCH=$(uname -m)
case "$OS" in
  Darwin) [ "$ARCH" = "arm64" ] && AB=macos-arm64 || AB=macos-x64; KB=$AB; OPEN=open ;;
  Linux)  AB=linux; [ -d ai/bin/linux-gpu ] && command -v vulkaninfo >/dev/null 2>&1 && AB=linux-gpu; KB=linux; OPEN=xdg-open ;;
  *) echo "Unsupported OS"; exit 1 ;;
esac
T=$(mktemp -d)   # copy binaries off the USB (exFAT has no execute permission)
trap 'kill $(jobs -p) 2>/dev/null; rm -rf "$T"' EXIT INT TERM
case "$OS" in
  Darwin) RAMGB=$(( $(sysctl -n hw.memsize) / 1073741824 )) ;;
  *)      RAMGB=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1048576 )) ;;
esac
MODEL=$(cat ai/default-model.txt 2>/dev/null)
[ "${RAMGB:-0}" -ge 30 ] && [ -f ai/large-model.txt ] && MODEL=$(cat ai/large-model.txt)
[ -n "$1" ] && MODEL=$1
# v80: pick the model that fits this computer's memory, outage mode (OFFGRID_MODE=outage), and the copy on this computer
MODELPATH=""; CTX=8192; NGL="-ngl 99"; THREADS=""; LOCALMODELS=""; SAY1=""; SAY2=""; SAY3=""; SAY4=""
if command -v python3 >/dev/null 2>&1 && [ -f tools/ai_pick.py ]; then
  eval "$(python3 tools/ai_pick.py --dest . --os unix --sh ${1:+--model "$1"} 2>/dev/null)"
fi
[ -n "$MODELPATH" ] || MODELPATH="$ROOT/ai/models/$MODEL"
THR=""; [ -n "$THREADS" ] && THR="-t $THREADS"
EXTRA=""; [ -n "$LOCALMODELS" ] && EXTRA="--models-local $LOCALMODELS"
[ "$OFFGRID_MODE" = outage ] && EXTRA="$EXTRA --lean"
echo "OFF-GRID SURVIVAL DRIVE   (this computer: ${RAMGB} GB RAM)"
for m in "$SAY1" "$SAY2" "$SAY3" "$SAY4"; do [ -n "$m" ] && echo "  $m"; done
if [ -n "$MODEL" ] && [ -d "ai/bin/$AB" ]; then
  cp -R "ai/bin/$AB" "$T/ai"; chmod +x "$T/ai/"* 2>/dev/null
  [ "$OS" = Darwin ] && xattr -dr com.apple.quarantine "$T" 2>/dev/null
  echo "Starting AI model $MODEL ..."
  LD_LIBRARY_PATH="$T/ai" DYLD_LIBRARY_PATH="$T/ai" "$T/ai/llama-server" -m "$MODELPATH" \
    --host 0.0.0.0 --port 8080 -c "$CTX" $NGL $THR >"$T/ai.log" 2>&1 &
else
  echo "AI not found for $AB — skipping."
fi
if [ -d "kiwix/bin/$KB" ] && ls kiwix/zim/*.zim >/dev/null 2>&1; then
  cp -R "kiwix/bin/$KB" "$T/kiwix"; chmod +x "$T/kiwix/"* 2>/dev/null
  [ "$OS" = Darwin ] && xattr -dr com.apple.quarantine "$T/kiwix" 2>/dev/null
  "$T/kiwix/kiwix-serve" --skipInvalid --port 8091 "$ROOT"/kiwix/zim/*.zim >"$T/kiwix.log" 2>&1 &
fi
WARGS=""
if [ "$OS" = Linux ] && [ -d ai/whisper/linux ]; then
  cp -R ai/whisper/linux "$T/whisper"; chmod +x "$T/whisper/"* 2>/dev/null
  W="$T/whisper/whisper-server"; [ -f "$W" ] || W="$T/whisper/server"
  WARGS="--whisper $W --whisper-model $ROOT/ai/whisper/ggml-base.en.bin"
fi
URL="file://$ROOT/www/command.html"
if command -v python3 >/dev/null 2>&1; then
  LD_LIBRARY_PATH="$T/ai:$T/whisper" DYLD_LIBRARY_PATH="$T/ai" python3 tools/serve_usb.py --dir www --port 8090 \
    --ai-bin "$T/ai/llama-server" --models "$ROOT/ai/models" --roles "$ROOT/ai/roles.json" --ngl 99 --logdir "$T" $WARGS $EXTRA \
    >"$T/web.log" 2>&1 &
  URL="http://localhost:8090/command.html"
  i=0; while [ $i -lt 25 ]; do curl -s -o /dev/null "http://localhost:8090/status" 2>/dev/null && break; sleep 1; i=$((i+1)); done
else
  echo "python3 not found — pages open as files (no map tiles; AI chat still works on :8080)."
fi
IP=$( (ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null) | awk '{print $1}')
echo ""
echo "  COMMAND CENTER: $URL"
echo "  Phones:  http://${IP:-<this-computer-ip>}:8090/command.html"
echo "  AI chat: http://localhost:8080    Archives: http://localhost:8091"
# a browser that can open the Command Center as its own app window (no tabs, no address bar)
APPB=""
for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
         "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" "/Applications/Chromium.app/Contents/MacOS/Chromium"; do
  [ -x "$c" ] && APPB="$c" && break
done
if [ -z "$APPB" ]; then
  for c in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge microsoft-edge-stable brave-browser; do
    command -v "$c" >/dev/null 2>&1 && APPB=$(command -v "$c") && break
  done
fi
if [ -n "$APPB" ]; then
  echo "  The Command Center is open in its own window. CLOSE THE WINDOW to stop everything."
  "$APPB" --app="$URL" --user-data-dir="$HOME/.offgrid-window" --window-size=1360,900 --no-first-run --no-default-browser-check >/dev/null 2>&1
  exit 0        # the trap at the top stops the servers and removes the temporary copies
fi
$OPEN "$URL" >/dev/null 2>&1 || echo "Open $URL in a browser"
echo "  Press Ctrl+C to stop."
wait
