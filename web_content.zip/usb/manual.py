#!/usr/bin/env python3
"""Generate the drive's own instruction manual: how to use it, what never to move or delete, how it heals
itself, how to (soft-)lock the important files, and what's safe to delete to save space.

Writes www/manual.html (linked from Home and START HERE) and HOW-TO-USE-THIS-DRIVE.txt at the drive root
(plain text, for a computer with no browser). Regenerated every build so the program list stays current.
"""
import html, os

# (path on the drive, what it is, why you must not move/rename/delete it)
DO_NOT_TOUCH = [
    ("tools\\", "The engine: the portable Python, the web server, the offline-AI servers, the Kiwix reader, the map "
     "tools, and a full copy of the builder.", "Nothing on the drive runs without this. Deleting any of it stops the "
     "programs, the AI, the search and the updates."),
    ("tools\\builder\\", "The complete builder, copied onto the drive.", "This is the master copy. Update, Add, Make-a-"
     "guide, Check and Copy all run from here — and it's what rebuilds anything that gets lost. Your most important folder."),
    ("www\\", "The whole interface and most of the content: Home, Search, Ask, the maps/locator, the Library, and the "
     "data files behind them.", "This is what you see and read. Losing it loses the drive's entire front end."),
    ("www\\data\\", "The locator places, routes, flood and military layers (the .js data files).", "The map and the "
     "'nearest places' lists are built from these."),
    ("kiwix\\ and the .zim files", "The offline archives — Wikipedia, WikEM, medical, iFixit, Gutenberg and the rest "
     "(hundreds of GB).", "Each .zim is one archive. Delete one and that archive is gone until you re-download it."),
    ("ai\\models\\", "The offline AI model files (.gguf).", "The 'Ask the drive' AI can't answer without them."),
    ("START-HERE.bat, start-here-mac-linux.sh, PROGRAMS\\", "The launchers and the menu.",
     "These start everything. Without them you'd have to launch programs by hand."),
    ("library\\manuals.tsv and the library\\ folders", "The manual list and the guides/manuals themselves.",
     "The Library pages and the full-text search are built from these."),
    ("tools\\build-options.json, www\\config.js, catalog.json files", "The drive's settings and map catalogs.",
     "They tell the drive what was built and where things are."),
]

# Things that ARE safe to remove to reclaim space on a finished drive — none are needed to USE it.
SAFE_TO_DELETE = [
    ("OSM-MAP-SOURCE\\ (the .pbf / .osm files you dropped in)", "Only used while converting street maps. Once the "
     "maps are built (www\\map\\*.pmtiles), the giant source files aren't needed — put them back only if you want to "
     "re-convert. Often tens of GB."),
    ("Anything ending in .part", "Half-finished downloads from an interrupted build. Safe to delete; the next "
     "update re-fetches them cleanly."),
    ("tools\\dl\\ and kiwix\\dl\\", "Download scratch folders. Temporary; rebuilt as needed."),
    ("Old files in REPORTS\\", "Past check/doctor/update reports. Keep the latest if you like; the rest are just history."),
]

# Looks like 'extra' but KEEP IT — needed for adding, updating, searching, making guides or copying.
KEEP_EVEN_THOUGH_BIG = [
    ("tools\\builder\\", "Runs every program and rebuilds the drive. Never delete."),
    ("tools\\python-win\\", "The Python that runs the programs, the server and the search."),
    ("tools\\pylib\\ (pypdf, Pillow)", "Needed to add PDFs, OCR scanned manuals, and render your GeoPDF maps."),
    ("tools\\poppler, tools\\tesseract, tools\\pmtiles, tools\\java + planetiler", "The map/OCR tools — needed when you "
     "add maps, OCR manuals or convert OpenStreetMap files. Idle the rest of the time, but keep them for maintenance."),
    ("tools\\builder\\usb\\data\\military-bases.geojson", "The offline copy of the military-base boundaries — used if "
     "the live source is down. Small; keep it."),
]


def _esc(s):
    return html.escape(str(s or ""))


def _rows(items):
    out = []
    for it in items:
        a, b = it[0], it[1]
        cell_c = f"<td>{_esc(it[2])}</td>" if len(it) > 2 else ""
        out.append(f"<tr><td class='mono'>{_esc(a)}</td><td>{_esc(b)}</td>{cell_c}</tr>")
    return "".join(out)


CSS = """body{font:16px/1.6 system-ui,Segoe UI,Roboto,sans-serif;max-width:900px;margin:0 auto;padding:24px;color:#14171a}
h1{font-size:28px;margin:0 0 4px}h2{font-size:21px;margin:30px 0 8px;border-bottom:2px solid #c9771f;padding-bottom:4px;color:#9a5a12}
h3{margin:18px 0 4px}.sub{color:#555;margin:0 0 16px}code,.mono{font-family:ui-monospace,Consolas,monospace;font-size:13.5px;background:#eef2f6;padding:1px 5px;border-radius:4px}
table{border-collapse:collapse;width:100%;font-size:14.5px;margin:8px 0}td,th{border-bottom:1px solid #e3e6ea;padding:7px 8px;text-align:left;vertical-align:top}
th{background:#f3f5f8}ul,ol{margin:6px 0 6px 2px;padding-left:22px}li{margin:4px 0}
.warn{background:#fdeaea;border:1px solid #e7b4b4;border-radius:8px;padding:10px 14px;margin:10px 0}
.ok{background:#eaf6ec;border:1px solid #b4d8bb;border-radius:8px;padding:10px 14px;margin:10px 0}
.note{background:#fff7e9;border:1px solid #f0d9a8;border-radius:8px;padding:10px 14px;margin:10px 0}
@media print{body{max-width:none}a{color:#000}}
@media(prefers-color-scheme:dark){body{background:#14171a;color:#e6e8eb}h2{color:#d9a441;border-color:#8a5a1a}
 .sub{color:#9aa}code,.mono,th{background:#222933;color:#dce3ea}td,th{border-color:#2c323a}
 .warn{background:#2a1a1a;border-color:#5a3030}.ok{background:#16241a;border-color:#2f5a38}.note{background:#241e12;border-color:#5a4a28}}"""


def _program_rows(programs):
    return "".join(f"<tr><td><b>{_esc(label)}</b><br><span class='mono'>{_esc(fn)}</span></td>"
                   f"<td>{_esc(when)}</td><td>{_esc(desc)}</td></tr>"
                   for key, fn, label, when, desc, online in programs)


def build(dest):
    try:
        import launcher
        programs = launcher.PROGRAMS
    except Exception:  # noqa: BLE001
        programs = []
    P = ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">',
         '<meta name="viewport" content="width=device-width,initial-scale=1">',
         f"<title>How to use this drive</title><style>{CSS}</style></head><body>"]
    P.append("<h1>How to use this OFF-GRID drive</h1>")
    P.append("<p class='sub'>Everything you need to run the drive, plus what never to touch and how it fixes itself. "
             "This page is also saved as <code>HOW-TO-USE-THIS-DRIVE.txt</code> at the top of the drive.</p>")

    P.append("<h2>Starting the drive</h2>"
             "<ul>"
             "<li><b>Windows:</b> double-click <code>START-HERE.bat</code> in the OFFGRID folder and press <b>1</b>. The Command Center opens in its own window; "
             "close that window to stop the drive and safely remove it.</li>"
             "<li><b>Mac / Linux:</b> run <code>start-here-mac-linux.sh</code> in the OFFGRID folder.</li>"
             "<li><b>Phone / tablet:</b> open <code>USE-ON-PHONE.html</code> for the app-based way (Kiwix, OsmAnd, a browser).</li>"
             "</ul>"
             "<div class='note'>Everything opens in your web browser at <code>http://localhost:8090</code> while the "
             "drive is running. If the server won't start, use <b>Search with no browser</b> and <b>Read the archives "
             "in Kiwix</b> — they work on their own.</div>")

    P.append("<h2>The six everyday things</h2>"
             "<ol>"
             "<li><b>Start the drive</b> — opens Home: search, maps, library, the AI, movies and music.</li>"
             "<li><b>Search everything</b> — every guide and every page of every manual.</li>"
             "<li><b>Make a survival guide</b> — pick a situation (and a route) and get one printable page built from "
             "the drive: first steps, what to read, the route plan, and the nearest water/fuel/hospitals/shelter.</li>"
             "<li><b>Copy to another drive</b> — make a backup, a travel drive or a phone drive.</li>"
             "<li><b>Check the drive</b> — see what's present, what's missing, and the full layout.</li>"
             "<li><b>All programs</b> — the full menu (below).</li>"
             "</ol>")

    if programs:
        P.append("<h2>All programs</h2><table><tr><th>Program</th><th>When</th><th>What it does</th></tr>"
                 + _program_rows(programs) + "</table>")

    P.append("<h2>Do NOT move, rename or delete these</h2>"
             "<p>These make the drive work. If you're tidying up, leave everything in this list exactly where it is.</p>"
             "<table><tr><th>On the drive</th><th>What it is</th><th>Why it matters</th></tr>"
             + _rows(DO_NOT_TOUCH) + "</table>"
             "<div class='warn'>Rule of thumb: if you didn't put a file there yourself, don't move or delete it. "
             "To add your own things, use the <b>MY-FILES-INBOX</b>, <b>MY-MAPS-INBOX</b> and <b>MY-RADIO-INBOX</b> "
             "folders and the matching Add programs — never drop files straight into <code>www</code> or <code>tools</code>.</div>")

    P.append("<h2>If something gets deleted or broken</h2>"
             "<p>The drive is built to heal itself, so a mistake is rarely permanent:</p>"
             "<ul>"
             "<li><b>Check the drive</b> lists anything missing. <b>Deep health check (doctor)</b> keeps a SHA-256 "
             "fingerprint of your files and flags anything that went missing, changed size, or got corrupted.</li>"
             "<li><b>Update the drive</b> (with internet) re-fetches missing archives, maps, apps and manuals, and "
             "rewrites the launchers, pages and tools — so deleted scaffolding comes back.</li>"
             "<li>Because <code>tools\\builder</code> is a full copy of the builder, the drive can rebuild its own "
             "interface and programs from itself.</li>"
             "</ul>"
             "<div class='ok'>Best habit: run <b>Check the drive</b> after any big copy or cleanup, and keep one other "
             "copy of the drive (see <b>Copy to another drive</b>). Two drives means a slip on one is never a total loss.</div>")

    P.append("<h2>Protecting the important files</h2>"
             "<p>Can the critical files be locked so they can't be messed with? Partly — and it's important to know the limits:</p>"
             "<ul>"
             "<li><b>What works:</b> run <b>PROTECT-FILES</b> (in the menu) to mark the launchers, the pages and the "
             "engine folders <i>read-only</i>. That stops accidental edits and gives a warning before anything in the "
             "set is deleted. Run <b>UNPROTECT-FILES</b> before you Update, Add or Build, then PROTECT again after.</li>"
             "<li><b>What doesn't:</b> a USB drive formatted exFAT (needed for phones) <i>cannot</i> carry true, "
             "unbreakable permissions, and read-only marks do <b>not</b> reliably survive a copy to another drive or "
             "onto a Mac/Linux/phone. There is no setting that hard-locks files across every device. Anyone with the "
             "drive can still override a read-only mark. Treat PROTECT as a guard against accidents, not against a person.</li>"
             "<li><b>The real protection</b> is the self-healing above (keep a second copy; Check/Doctor + Update "
             "restore anything lost) — that works on every device because it's just files.</li>"
             "<li><b>For truly sensitive files</b> (documents, IDs, passwords), use the <b>family document vault</b> "
             "(VeraCrypt): a single encrypted file that needs a password to open. That protection <i>does</i> travel "
             "with the file to any device.</li>"
             "</ul>")

    P.append("<h2>Saving space: what's safe to delete</h2>"
             "<p>Once the drive is finished, these can go to reclaim space — none are needed to use it day to day "
             "(put them back only if you want to re-run that build step):</p>"
             "<table><tr><th>Safe to delete</th><th>What it is</th></tr>" + _rows(SAFE_TO_DELETE) + "</table>"
             "<h3>But keep these, even though they look like extras</h3>"
             "<p>They're idle during everyday use, but you need them to add files, update, search, make guides or copy the drive:</p>"
             "<table><tr><th>Keep</th><th>Why</th></tr>" + _rows(KEEP_EVEN_THOUGH_BIG) + "</table>")

    P.append("<h2>Adding, updating and copying</h2>"
             "<ul>"
             "<li><b>Add your own</b> files, maps or radio files: put them in the matching <b>...-INBOX</b> folder, then "
             "run the matching Add program. They become searchable and show up on Home.</li>"
             "<li><b>Update</b> (monthly, with internet): newer archives, apps and maps, plus retries of anything missing.</li>"
             "<li><b>Copy to another drive</b>: a backup, a smaller travel drive, or a phone drive (it leaves off what "
             "that device can't use). For a phone, format the other drive <b>exFAT</b> first.</li>"
             "</ul>")

    P.append("</body></html>")
    www = os.path.join(dest, "www")
    os.makedirs(www, exist_ok=True)
    with open(os.path.join(www, "manual.html"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(P))
    _write_txt(dest, programs)


def _write_txt(dest, programs):
    L = ["HOW TO USE THIS OFF-GRID DRIVE", "=" * 32, "",
         "STARTING", "  Windows: double-click START-HERE.bat and press 1 (the Command Center opens in its own window; close it to stop).",
         "  Mac/Linux: run start-here-mac-linux.sh.   Phone: open USE-ON-PHONE.html.",
         "  Everything opens in your browser at http://localhost:8090 while the drive runs.",
         "  No server? Use 'Search with no browser' and 'Read the archives in Kiwix'.", ""]
    if programs:
        L.append("PROGRAMS")
        for key, fn, label, when, desc, online in programs:
            L.append(f"  [{key}] {label} ({fn}) - {when}")
        L.append("")
    L.append("DO NOT MOVE, RENAME OR DELETE:")
    for a, b, *rest in DO_NOT_TOUCH:
        L.append(f"  {a}")
        L.append(f"      {b}")
    L += ["", "  Add your own files only through the ...-INBOX folders + the Add programs.",
          "  Never drop files straight into www\\ or tools\\.", "",
          "IF SOMETHING BREAKS:",
          "  Run 'Check the drive' (lists what's missing) and 'Update the drive' (re-fetches and rewrites it).",
          "  tools\\builder is a full copy of the builder, so the drive can rebuild itself. Keep a 2nd copy.", "",
          "LOCKING FILES:",
          "  'PROTECT-FILES' marks the engine read-only (accident guard). 'UNPROTECT-FILES' before Update/Add/Build.",
          "  A USB drive can't carry unbreakable locks across devices - the real safety net is Check/Doctor + Update",
          "  + a second copy. For sensitive documents use the VeraCrypt family vault.", "",
          "SAFE TO DELETE TO SAVE SPACE (none are needed to use the drive):"]
    for a, b in SAFE_TO_DELETE:
        L.append(f"  {a} - {b}")
    L += ["", "KEEP THESE EVEN THOUGH THEY LOOK LIKE EXTRAS (needed to add/update/search/copy):"]
    for a, b in KEEP_EVEN_THOUGH_BIG:
        L.append(f"  {a} - {b}")
    with open(os.path.join(dest, "HOW-TO-USE-THIS-DRIVE.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("\n".join(L) + "\n")
