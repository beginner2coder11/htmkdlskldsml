"""Restore an OFF-GRID drive pack (made by pack_drive.py) onto another drive.

  python restore_pack.py --src F:\\OFFGRID-PACK --dest D:\\OFFGRID [--verify]

--verify first checks every volume against the checksums in MANIFEST.json. Safe to stop and re-run:
finished volumes are skipped and pieces of big files are written at their exact position.
Standard library only.
"""
import argparse, hashlib, json, os, shutil, sys, zipfile

PART = ".__part__"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(8 << 20), b""):
            h.update(b)
    return h.hexdigest()


def safe(dest, rel):
    p = os.path.normpath(os.path.join(dest, *rel.split("/")))
    if not os.path.normcase(p).startswith(os.path.normcase(os.path.abspath(dest)) + os.sep):
        raise ValueError(f"unsafe path in pack: {rel}")
    return p


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", required=True)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--verify", action="store_true")
    a = ap.parse_args()
    man = json.load(open(os.path.join(a.src, "MANIFEST.json"), encoding="utf-8"))
    vols = man["volumes"]
    dest = os.path.abspath(a.dest)
    os.makedirs(dest, exist_ok=True)
    free = shutil.disk_usage(dest).free
    print(f"Restoring {man['files']:,} files ({man['bytes'] / 1e9:,.1f} GB) from {len(vols)} volumes -> {dest}")
    state_p = os.path.join(dest, ".restore-state.json")
    done = set()
    try:
        done = set(json.load(open(state_p)))
    except (OSError, ValueError):
        pass
    if not done and free < man["bytes"] * 1.02:
        print(f"  ! Not enough room: need about {man['bytes'] / 1e9:,.0f} GB, {free / 1e9:,.0f} GB free.")
        if input("  Continue anyway? (y/n) ").lower() != "y":
            sys.exit(1)
    for v in vols:
        if not os.path.exists(os.path.join(a.src, v["file"])):
            sys.exit(f"Missing volume {v['file']} - copy it next to the others and run again.")
    if a.verify:
        for v in vols:
            if v["file"] in done:
                continue
            ok = sha256_file(os.path.join(a.src, v["file"])) == v["sha256"]
            print(f"  check {v['file']}: {'ok' if ok else 'DAMAGED'}")
            if not ok:
                sys.exit(f"{v['file']} is damaged; replace it from another copy and run again.")
    for i, v in enumerate(vols, 1):
        if v["file"] in done:
            continue
        with zipfile.ZipFile(os.path.join(a.src, v["file"])) as z:
            for info in z.infolist():
                name = info.filename
                off = None
                if PART in name:
                    name, o = name.rsplit(PART, 1)
                    off = int(o)
                target = safe(dest, name)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                mode = "r+b" if off else "wb"
                if off and not os.path.exists(target):
                    mode = "wb"
                with z.open(info) as src, open(target, mode) as out:
                    if off:
                        out.seek(off)
                    while True:
                        b = src.read(8 << 20)
                        if not b:
                            break
                        out.write(b)
        done.add(v["file"])
        json.dump(sorted(done), open(state_p, "w"))
        print(f"  restored {v['file']}  ({i}/{len(vols)})", flush=True)
    bad = [r for r, s in man["sizes"].items() if not os.path.exists(safe(dest, r)) or os.path.getsize(safe(dest, r)) != s]
    if bad:
        print(f"  ! {len(bad)} files are missing or the wrong size, for example {bad[0]}")
        sys.exit(1)
    os.remove(state_p)
    print("\nDone. Open START-HERE.bat (Windows) or start-here-mac-linux.sh in the restored folder.")


if __name__ == "__main__":
    main()
