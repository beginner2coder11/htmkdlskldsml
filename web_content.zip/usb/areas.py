"""Extra map areas for the drive: major Southern cities, big lakes / bays / sounds, and military bases.

Used by usb_builder.py to choose which USGS topo quads to download beyond the home radius, and to
build the military-installation overlay (DoD MIRTA boundaries, public data) for the locator map.
Coordinates are city centers (city hall / downtown); the builder adds the radius around each.
"""
import json, math, os, shutil, time, urllib.parse

SOUTH = ["al", "ar", "de", "dc", "fl", "ga", "ky", "la", "md", "ms", "nc", "ok", "sc", "tn", "tx", "va", "wv"]
SOUTH_BBOX = (-106.65, 24.40, -75.00, 40.65)          # west, south, east, north — El Paso to Delaware, Keys to WV

# (state, city, lat, lon) — cities over ~100,000 people plus every state capital
CITIES = [
    ("AL", "Birmingham", 33.5186, -86.8104), ("AL", "Montgomery (capital)", 32.3792, -86.3077),
    ("AL", "Huntsville", 34.7304, -86.5861), ("AL", "Mobile", 30.6954, -88.0399), ("AL", "Tuscaloosa", 33.2098, -87.5692),
    ("AL", "Dothan", 31.2232, -85.3905),
    ("AR", "Little Rock (capital)", 34.7465, -92.2896), ("AR", "Fort Smith", 35.3859, -94.3985),
    ("AR", "Fayetteville", 36.0626, -94.1574), ("AR", "Jonesboro", 35.8423, -90.7043),
    ("DE", "Wilmington", 39.7391, -75.5398), ("DE", "Dover (capital)", 39.1582, -75.5244),
    ("DC", "Washington", 38.9072, -77.0369),
    ("FL", "Jacksonville", 30.3322, -81.6557), ("FL", "Miami", 25.7617, -80.1918), ("FL", "Tampa", 27.9506, -82.4572),
    ("FL", "Orlando", 28.5384, -81.3789), ("FL", "St. Petersburg", 27.7676, -82.6403),
    ("FL", "Tallahassee (capital)", 30.4383, -84.2807), ("FL", "Fort Lauderdale", 26.1224, -80.1373),
    ("FL", "West Palm Beach", 26.7153, -80.0534), ("FL", "Cape Coral / Fort Myers", 26.5629, -81.9495),
    ("FL", "Port St. Lucie", 27.2730, -80.3582), ("FL", "Gainesville", 29.6516, -82.3248),
    ("FL", "Pensacola", 30.4213, -87.2169), ("FL", "Daytona Beach", 29.2108, -81.0228), ("FL", "Lakeland", 28.0395, -81.9498),
    ("FL", "Palm Bay / Melbourne", 28.0345, -80.5887), ("FL", "Sarasota", 27.3364, -82.5307),
    ("FL", "Panama City", 30.1588, -85.6602), ("FL", "Ocala", 29.1872, -82.1401), ("FL", "Naples", 26.1420, -81.7948),
    ("FL", "Key West", 24.5551, -81.7800),
    ("GA", "Atlanta (capital)", 33.7490, -84.3880), ("GA", "Augusta", 33.4735, -82.0105), ("GA", "Columbus", 32.4610, -84.9877),
    ("GA", "Macon", 32.8407, -83.6324), ("GA", "Savannah", 32.0809, -81.0912), ("GA", "Athens", 33.9519, -83.3576),
    ("GA", "Albany", 31.5785, -84.1557), ("GA", "Valdosta", 30.8327, -83.2785), ("GA", "Rome", 34.2570, -85.1647),
    ("GA", "Dalton", 34.7698, -84.9702), ("GA", "Gainesville", 34.2979, -83.8241), ("GA", "Brunswick", 31.1499, -81.4915),
    ("KY", "Louisville", 38.2527, -85.7585), ("KY", "Lexington", 38.0406, -84.5037), ("KY", "Frankfort (capital)", 38.2009, -84.8733),
    ("KY", "Bowling Green", 36.9685, -86.4808), ("KY", "Owensboro", 37.7719, -87.1112), ("KY", "Paducah", 37.0834, -88.6000),
    ("LA", "New Orleans", 29.9511, -90.0715), ("LA", "Baton Rouge (capital)", 30.4515, -91.1871), ("LA", "Shreveport", 32.5252, -93.7502),
    ("LA", "Lafayette", 30.2241, -92.0198), ("LA", "Lake Charles", 30.2266, -93.2174), ("LA", "Monroe", 32.5093, -92.1193),
    ("LA", "Alexandria", 31.3113, -92.4451),
    ("MD", "Baltimore", 39.2904, -76.6122), ("MD", "Annapolis (capital)", 38.9784, -76.4922), ("MD", "Frederick", 39.4143, -77.4105),
    ("MD", "Salisbury", 38.3607, -75.5994),
    ("MS", "Jackson (capital)", 32.2988, -90.1848), ("MS", "Gulfport / Biloxi", 30.3674, -89.0928), ("MS", "Hattiesburg", 31.3271, -89.2903),
    ("MS", "Tupelo", 34.2576, -88.7034), ("MS", "Meridian", 32.3643, -88.7037), ("MS", "Southaven", 34.9889, -90.0126),
    ("NC", "Charlotte", 35.2271, -80.8431), ("NC", "Raleigh (capital)", 35.7796, -78.6382), ("NC", "Greensboro", 36.0726, -79.7920),
    ("NC", "Durham", 35.9940, -78.8986), ("NC", "Winston-Salem", 36.0999, -80.2442), ("NC", "Fayetteville", 35.0527, -78.8784),
    ("NC", "Wilmington", 34.2257, -77.9447), ("NC", "Asheville", 35.5951, -82.5515), ("NC", "Jacksonville", 34.7541, -77.4302),
    ("NC", "Greenville", 35.6127, -77.3664), ("NC", "Hickory", 35.7345, -81.3412),
    ("OK", "Oklahoma City (capital)", 35.4676, -97.5164), ("OK", "Tulsa", 36.1540, -95.9928), ("OK", "Norman", 35.2226, -97.4395),
    ("OK", "Lawton", 34.6036, -98.3959), ("OK", "Enid", 36.3956, -97.8784),
    ("SC", "Columbia (capital)", 34.0007, -81.0348), ("SC", "Charleston", 32.7765, -79.9311), ("SC", "Greenville", 34.8526, -82.3940),
    ("SC", "Spartanburg", 34.9496, -81.9320), ("SC", "Myrtle Beach", 33.6891, -78.8867), ("SC", "Florence", 34.1954, -79.7626),
    ("SC", "Beaufort", 32.4316, -80.6698),
    ("TN", "Nashville (capital)", 36.1627, -86.7816), ("TN", "Memphis", 35.1495, -90.0490), ("TN", "Knoxville", 35.9606, -83.9207),
    ("TN", "Chattanooga", 35.0456, -85.3097), ("TN", "Clarksville", 36.5298, -87.3595), ("TN", "Murfreesboro", 35.8456, -86.3903),
    ("TN", "Jackson", 35.6145, -88.8139), ("TN", "Johnson City / Kingsport", 36.3134, -82.3535), ("TN", "Cookeville", 36.1628, -85.5016),
    ("TX", "Houston", 29.7604, -95.3698), ("TX", "San Antonio", 29.4241, -98.4936), ("TX", "Dallas", 32.7767, -96.7970),
    ("TX", "Austin (capital)", 30.2672, -97.7431), ("TX", "Fort Worth", 32.7555, -97.3308), ("TX", "El Paso", 31.7619, -106.4850),
    ("TX", "Corpus Christi", 27.8006, -97.3964), ("TX", "Laredo", 27.5306, -99.4803), ("TX", "Lubbock", 33.5779, -101.8552),
    ("TX", "Amarillo", 35.2220, -101.8313), ("TX", "Brownsville", 25.9017, -97.4975), ("TX", "McAllen", 26.2034, -98.2300),
    ("TX", "Killeen / Fort Cavazos", 31.1171, -97.7278), ("TX", "Waco", 31.5493, -97.1467), ("TX", "Beaumont", 30.0802, -94.1266),
    ("TX", "Midland", 31.9973, -102.0779), ("TX", "Odessa", 31.8457, -102.3676), ("TX", "Abilene", 32.4487, -99.7331),
    ("TX", "Tyler", 32.3513, -95.3011), ("TX", "College Station", 30.6280, -96.3344), ("TX", "Wichita Falls", 33.9137, -98.4934),
    ("TX", "San Angelo", 31.4638, -100.4370), ("TX", "Galveston", 29.3013, -94.7977), ("TX", "Longview", 32.5007, -94.7405),
    ("TX", "Victoria", 28.8053, -97.0036), ("TX", "Denton", 33.2148, -97.1331), ("TX", "Conroe / The Woodlands", 30.3119, -95.4561),
    ("TX", "New Braunfels", 29.7030, -98.1245), ("TX", "Sherman", 33.6357, -96.6089), ("TX", "Texarkana", 33.4418, -94.0377),
    ("VA", "Richmond (capital)", 37.5407, -77.4360), ("VA", "Virginia Beach", 36.8529, -75.9780), ("VA", "Norfolk", 36.8508, -76.2859),
    ("VA", "Newport News / Hampton", 37.0871, -76.4730), ("VA", "Roanoke", 37.2710, -79.9414), ("VA", "Lynchburg", 37.4138, -79.1422),
    ("VA", "Charlottesville", 38.0293, -78.4767), ("VA", "Fredericksburg", 38.3032, -77.4605), ("VA", "Harrisonburg", 38.4496, -78.8689),
    ("VA", "Winchester", 39.1857, -78.1633), ("VA", "Blacksburg", 37.2296, -80.4139), ("VA", "Danville", 36.5860, -79.3950),
    ("WV", "Charleston (capital)", 38.3498, -81.6326), ("WV", "Huntington", 38.4192, -82.4452), ("WV", "Morgantown", 39.6295, -79.9559),
    ("WV", "Parkersburg", 39.2667, -81.5615), ("WV", "Wheeling", 40.0640, -80.7209), ("WV", "Beckley", 37.7782, -81.1882),
    ("WV", "Martinsburg", 39.4562, -77.9639),
]

# Rest of the US (state capitals + large cities) — used for the declination table and finder
US_EXTRA = [
    ("AK", "Juneau (capital)", 58.30, -134.42), ("AK", "Anchorage", 61.22, -149.90), ("AK", "Fairbanks", 64.84, -147.72),
    ("AZ", "Phoenix (capital)", 33.45, -112.07), ("AZ", "Tucson", 32.22, -110.97), ("AZ", "Flagstaff", 35.20, -111.65),
    ("CA", "Sacramento (capital)", 38.58, -121.49), ("CA", "Los Angeles", 34.05, -118.24), ("CA", "San Francisco", 37.77, -122.42),
    ("CA", "San Diego", 32.72, -117.16), ("CA", "Fresno", 36.74, -119.79), ("CA", "Redding", 40.59, -122.39),
    ("CO", "Denver (capital)", 39.74, -104.99), ("CO", "Grand Junction", 39.06, -108.55), ("CT", "Hartford (capital)", 41.76, -72.68),
    ("HI", "Honolulu (capital)", 21.31, -157.86), ("ID", "Boise (capital)", 43.62, -116.20), ("IL", "Springfield (capital)", 39.80, -89.65),
    ("IL", "Chicago", 41.88, -87.63), ("IN", "Indianapolis (capital)", 39.77, -86.16), ("IA", "Des Moines (capital)", 41.59, -93.62),
    ("KS", "Topeka (capital)", 39.05, -95.68), ("KS", "Wichita", 37.69, -97.34), ("ME", "Augusta (capital)", 44.31, -69.78),
    ("ME", "Bangor", 44.80, -68.77), ("MA", "Boston (capital)", 42.36, -71.06), ("MI", "Lansing (capital)", 42.73, -84.56),
    ("MI", "Detroit", 42.33, -83.05), ("MI", "Marquette", 46.54, -87.40), ("MN", "St. Paul (capital)", 44.95, -93.09),
    ("MN", "Duluth", 46.79, -92.10), ("MO", "Jefferson City (capital)", 38.58, -92.17), ("MO", "St. Louis", 38.63, -90.20),
    ("MO", "Kansas City", 39.10, -94.58), ("MT", "Helena (capital)", 46.59, -112.04), ("MT", "Billings", 45.78, -108.50),
    ("NE", "Lincoln (capital)", 40.81, -96.70), ("NE", "Omaha", 41.26, -95.94), ("NV", "Carson City (capital)", 39.16, -119.77),
    ("NV", "Las Vegas", 36.17, -115.14), ("NH", "Concord (capital)", 43.21, -71.54), ("NJ", "Trenton (capital)", 40.22, -74.76),
    ("NM", "Santa Fe (capital)", 35.69, -105.94), ("NM", "Albuquerque", 35.08, -106.65), ("NY", "Albany (capital)", 42.65, -73.76),
    ("NY", "New York City", 40.71, -74.01), ("NY", "Buffalo", 42.89, -78.88), ("ND", "Bismarck (capital)", 46.81, -100.78),
    ("ND", "Fargo", 46.88, -96.79), ("OH", "Columbus (capital)", 39.96, -83.00), ("OH", "Cleveland", 41.50, -81.69),
    ("OH", "Cincinnati", 39.10, -84.51), ("OR", "Salem (capital)", 44.94, -123.04), ("OR", "Portland", 45.52, -122.68),
    ("OR", "Bend", 44.06, -121.32), ("PA", "Harrisburg (capital)", 40.26, -76.88), ("PA", "Philadelphia", 39.95, -75.17),
    ("PA", "Pittsburgh", 40.44, -80.00), ("RI", "Providence (capital)", 41.82, -71.41), ("SD", "Pierre (capital)", 44.37, -100.35),
    ("SD", "Rapid City", 44.08, -103.23), ("UT", "Salt Lake City (capital)", 40.76, -111.89), ("VT", "Montpelier (capital)", 44.26, -72.58),
    ("WA", "Olympia (capital)", 47.04, -122.90), ("WA", "Seattle", 47.61, -122.33), ("WA", "Spokane", 47.66, -117.43),
    ("WI", "Madison (capital)", 43.07, -89.40), ("WI", "Milwaukee", 43.04, -87.91), ("WY", "Cheyenne (capital)", 41.14, -104.82),
    ("WY", "Casper", 42.87, -106.31), ("PR", "San Juan", 18.47, -66.11),
]

# (state(s), name, lat, lon, radius miles) — big lakes and reservoirs, bays, sounds and coast, with the land around them
WATER = [
    ("GA", "Lake Lanier", 34.25, -83.95, 15), ("GA/AL", "West Point Lake", 33.05, -85.15, 12),
    ("GA/SC", "Lake Hartwell", 34.45, -82.85, 15), ("GA/SC", "Lake Thurmond (Clarks Hill)", 33.70, -82.35, 15),
    ("GA", "Lakes Oconee & Sinclair", 33.30, -83.30, 12), ("GA/FL/AL", "Lake Seminole", 30.78, -84.85, 10),
    ("GA", "Okefenokee Swamp", 30.80, -82.30, 18), ("GA", "Georgia coast & barrier islands", 31.45, -81.30, 25),
    ("AL", "Lake Guntersville", 34.45, -86.20, 18), ("AL", "Wheeler & Wilson Lakes", 34.70, -87.20, 20),
    ("AL", "Lake Martin", 32.75, -85.90, 12), ("AL", "Weiss Lake", 34.15, -85.60, 10), ("AL", "Smith Lake", 34.05, -87.10, 12),
    ("AL", "Mobile Bay & delta", 30.55, -87.95, 22), ("AL/FL", "Gulf Shores & Perdido Bay", 30.30, -87.55, 15),
    ("KY/TN", "Kentucky Lake & Lake Barkley", 36.75, -88.10, 30), ("KY", "Lake Cumberland", 36.90, -84.90, 20),
    ("TN", "Dale Hollow & Center Hill Lakes", 36.40, -85.60, 18), ("TN", "Norris Lake", 36.30, -83.95, 15),
    ("TN", "Watts Bar & Chickamauga Lakes", 35.55, -84.85, 22), ("TN", "Douglas & Cherokee Lakes", 36.10, -83.40, 15),
    ("TN/MS/AL", "Pickwick Lake", 34.95, -88.15, 15), ("TN/AR/MS", "Mississippi River at Memphis", 35.15, -90.10, 15),
    ("AR", "Lake Ouachita", 34.60, -93.30, 15), ("AR/MO", "Bull Shoals & Norfork Lakes", 36.40, -92.55, 20),
    ("AR", "Beaver Lake", 36.35, -93.90, 12), ("AR", "Greers Ferry Lake", 35.55, -92.10, 12),
    ("TX/OK", "Lake Texoma", 33.85, -96.65, 18), ("OK", "Lake Eufaula", 35.25, -95.60, 18),
    ("OK", "Grand Lake o' the Cherokees", 36.55, -94.85, 15), ("OK", "Lake Tenkiller & Fort Gibson", 35.75, -95.10, 15),
    ("TX/LA", "Toledo Bend Reservoir", 31.30, -93.65, 25), ("TX", "Sam Rayburn Reservoir", 31.10, -94.15, 18),
    ("TX", "Lake Livingston", 30.75, -95.10, 15), ("TX", "Lake Travis & Highland Lakes", 30.55, -98.10, 18),
    ("TX", "Falcon Lake", 26.65, -99.20, 12), ("TX", "Amistad Reservoir", 29.55, -101.05, 15),
    ("TX", "Galveston Bay", 29.50, -94.85, 20), ("TX", "Matagorda Bay", 28.55, -96.25, 20), ("TX", "Laguna Madre & Padre Island", 26.90, -97.40, 25),
    ("LA", "Lake Pontchartrain & Maurepas", 30.20, -90.20, 22), ("LA", "Atchafalaya Basin", 30.30, -91.65, 20),
    ("LA", "Barataria & Terrebonne coast", 29.35, -90.40, 25), ("LA", "Calcasieu Lake & Sabine coast", 29.85, -93.40, 18),
    ("MS", "Sardis & Enid Lakes", 34.30, -89.70, 15), ("MS", "Ross Barnett Reservoir", 32.45, -90.00, 10),
    ("MS", "Mississippi Sound", 30.35, -88.70, 20),
    ("FL", "Lake Okeechobee", 26.95, -80.80, 25), ("FL", "Kissimmee chain of lakes", 27.95, -81.25, 15),
    ("FL", "Lake George & St. Johns River", 29.25, -81.60, 12), ("FL", "Apalachicola Bay", 29.70, -84.95, 18),
    ("FL", "Choctawhatchee Bay", 30.45, -86.30, 18), ("FL", "Tampa Bay", 27.75, -82.55, 20), ("FL", "Charlotte Harbor", 26.85, -82.10, 15),
    ("FL", "Indian River Lagoon & Cape Canaveral", 28.45, -80.65, 18), ("FL", "Florida Bay & Upper Keys", 25.10, -80.70, 25),
    ("FL", "Big Bend coast (Cedar Key)", 29.30, -83.05, 18),
    ("SC", "Lakes Marion & Moultrie", 33.40, -80.15, 20), ("SC", "Lake Murray", 34.07, -81.30, 12),
    ("SC/NC", "Lake Wylie & Lake Norman", 35.30, -81.00, 15), ("SC", "Port Royal Sound & Hilton Head", 32.25, -80.70, 18),
    ("NC/VA", "Kerr Lake & Lake Gaston", 36.55, -78.30, 18), ("NC", "Pamlico Sound & Outer Banks", 35.30, -75.90, 35),
    ("NC", "Albemarle Sound", 36.05, -76.30, 25), ("NC", "Fontana Lake", 35.45, -83.70, 12), ("NC", "Lake Gaston & Roanoke River", 36.45, -77.80, 12),
    ("VA", "Smith Mountain Lake", 37.08, -79.60, 12), ("VA", "Lake Anna", 38.05, -77.80, 10),
    ("VA", "Lower Chesapeake Bay & Eastern Shore", 37.30, -76.10, 25), ("MD/VA", "Middle Chesapeake Bay", 38.30, -76.30, 25),
    ("MD", "Upper Chesapeake Bay", 39.15, -76.25, 18), ("MD/VA/DE", "Delmarva coast & Chincoteague", 38.00, -75.30, 20),
    ("DE/NJ", "Delaware Bay", 39.10, -75.20, 20), ("MD/VA/DC", "Potomac River (lower)", 38.25, -76.95, 18),
    ("WV", "Summersville Lake & Gauley River", 38.23, -80.85, 12), ("WV", "Stonewall Jackson & Burnsville Lakes", 38.85, -80.55, 12),
]

COMPONENTS = {"usa": "Army", "usar": "Army Reserve", "armynationalguard": "Army National Guard", "usn": "Navy",
              "usnr": "Navy Reserve", "usmc": "Marine Corps", "usmcr": "Marine Corps Reserve", "usaf": "Air Force",
              "usafr": "Air Force Reserve", "afr": "Air Force Reserve", "airnationalguard": "Air National Guard", "ang": "Air National Guard",
              "whs": "DoD (WHS)", "dla": "Defense Logistics Agency", "ussf": "Space Force", "uscg": "Coast Guard", "other": "Other"}

MIRTA = "https://services7.arcgis.com/n1YM8pTrFmm7L4hs/arcgis/rest/services/mirta/FeatureServer/1/query"
# bases outside the South that the drive should also carry topo for (match on the MIRTA name)
EXTRA_BASES = ("pendleton", "twentynine palms", "29 palms", "miramar", "mountain warfare")


def _bbox(coords, b=None):
    b = b or [999, 999, -999, -999]
    if coords and isinstance(coords[0], (int, float)):
        x, y = coords[0], coords[1]
        b[0], b[1], b[2], b[3] = min(b[0], x), min(b[1], y), max(b[2], x), max(b[3], y)
    else:
        for c in coords:
            _bbox(c, b)
    return b


def military(u, dest, max_age_days=180):
    """Download DoD installation boundaries (all US) once; returns a list of
    {name, site, st, branch, status, joint, bbox:[w,s,e,n], lat, lon}. Writes www/data/military.js for the map."""
    data = os.path.join(dest, "www", "data")
    os.makedirs(data, exist_ok=True)
    raw = os.path.join(data, "military.geojson")
    fresh = os.path.exists(raw) and (time.time() - os.path.getmtime(raw)) / 86400 < max_age_days
    if not fresh:
        u.say("Military installations (DoD MIRTA boundaries)")
        feats, off = [], 0
        while True:
            q = urllib.parse.urlencode({"where": "1=1", "outFields": "FEATURENAME,SITENAME,STATENAMECODE,SITEREPORTINGCOMPONENT,"
                                        "SITEOPERATIONALSTATUS,ISJOINTBASE,COUNTRYNAME", "returnGeometry": "true", "outSR": 4326,
                                        "maxAllowableOffset": 0.0004, "geometryPrecision": 5, "resultOffset": off,
                                        "resultRecordCount": 500, "f": "geojson"})
            try:
                j = json.loads(u.fetch(f"{MIRTA}?{q}", 180))
            except Exception as ex:  # noqa: BLE001
                print(f"  ! DoD MIRTA server: {str(ex)[:120]}")
                feats = None; break
            batch = j.get("features") or []
            feats += batch
            print(f"\r  {len(feats)} installations", end="", flush=True)
            if len(batch) < 500 and not (j.get("properties") or {}).get("exceededTransferLimit"):
                break
            off += len(batch)
        print()
        if feats:
            with open(raw, "w", encoding="utf-8") as fh:
                json.dump({"type": "FeatureCollection", "features": feats}, fh)
        elif not os.path.exists(raw):
            # Offline / server moved: fall back to the authoritative copy bundled with the builder (same NTAD data).
            seed = os.path.join(os.path.dirname(__file__), "data", "military-bases.geojson")
            if os.path.exists(seed):
                print("  (DoD server unreachable — using the bundled offline copy of the installation boundaries)")
                shutil.copyfile(seed, raw)
            else:
                return []
    gj = json.load(open(raw, encoding="utf-8"))
    sites, out_feats = [], []
    for f in gj.get("features", []):
        p, g = f.get("properties") or {}, f.get("geometry")
        if not g:
            continue
        w, s, e, n = _bbox(g["coordinates"])
        pv = lambda *ks: next((p[k] for k in ks if p.get(k) not in (None, "", " ")), "")  # ArcGIS UPPER or NTAD camelCase
        comp = str(pv("SITEREPORTINGCOMPONENT", "siteReportingComponent")).lower()
        site = {"name": pv("FEATURENAME", "featureName", "SITENAME", "siteName") or "?", "site": pv("SITENAME", "siteName"),
                "st": str(pv("STATENAMECODE", "stateNameCode")).upper(), "branch": COMPONENTS.get(comp, comp.upper()),
                "status": {"act": "active", "semi": "semi-active", "inact": "inactive", "clsd": "closed",
                           "care": "caretaker", "excs": "excess", "dsps": "disposed"}.get(
                    str(pv("SITEOPERATIONALSTATUS", "siteOperationalStatus")).lower(), pv("SITEOPERATIONALSTATUS", "siteOperationalStatus")),
                "joint": str(pv("ISJOINTBASE", "isJointBase")).lower() in ("yes", "y", "true", "1"),
                "bbox": [round(w, 4), round(s, 4), round(e, 4), round(n, 4)], "lat": (s + n) / 2, "lon": (w + e) / 2}
        sites.append(site)
        out_feats.append({"type": "Feature", "geometry": g, "properties": {k: site[k] for k in ("name", "site", "st", "branch", "status", "joint")}})
    with open(os.path.join(data, "military.js"), "w", encoding="utf-8") as fh:
        fh.write("window.MILITARY=" + json.dumps({"type": "FeatureCollection", "features": out_feats}, separators=(",", ":")) + ";\n")
    print(f"  {len(sites)} DoD sites on the map overlay")
    return sites


def box(lat, lon, miles):
    dl, dn = miles / 69.0, miles / (69.17 * math.cos(math.radians(lat)))
    return [lon - dn, lat - dl, lon + dn, lat + dl]


def _mi(la1, lo1, la2, lo2):
    return math.hypot((la1 - la2) * 69.0, (lo1 - lo2) * 69.17 * math.cos(math.radians((la1 + la2) / 2)))


def area_list(sites, kinds=("bases", "cities", "water"), city_radius=20, base_buffer=5, states=SOUTH, home=None):
    """home=(lat, lon) switches to the any-region rules: bases / cities in the given states (or bases within 300 miles), lakes and coast within 450 miles."""
    """-> list of {group, name, lat, lon, bbox} in download priority order."""
    out = []
    if "bases" in kinds:
        seen = set()
        for s in sorted(sites, key=lambda s: s["name"]):
            nm = s["name"].lower()
            if s["status"] in ("closed", "inactive"):
                continue
            if home:
                if s["st"].lower() not in states and _mi(s["lat"], s["lon"], home[0], home[1]) > 300:
                    continue
            elif s["st"].lower() not in states and not any(k in nm for k in EXTRA_BASES):
                continue
            w, so, e, n = s["bbox"]
            if (e - w) * (n - so) < 0.0005 and not any(k in nm for k in EXTRA_BASES):
                continue                                    # reserve centers / armories (a city block): covered by the city maps
            if (e - w) * (n - so) > 4:                      # a few huge ranges (e.g. White Sands): just the cantonment area
                w, so, e, n = s["lon"] - .5, s["lat"] - .4, s["lon"] + .5, s["lat"] + .4
            dl, dn = base_buffer / 69.0, base_buffer / (69.17 * math.cos(math.radians(s["lat"])))
            key = (round(s["lat"], 2), round(s["lon"], 2))
            if key in seen:
                continue
            seen.add(key)
            out.append({"group": "Military bases", "name": f"{s['name']} ({s['st']}, {s['branch']})", "lat": s["lat"], "lon": s["lon"],
                        "bbox": [w - dn, so - dl, e + dn, n + dl]})
    if "cities" in kinds:
        for st, name, la, lo in (CITIES + US_EXTRA if home else CITIES):
            if st.lower() in states:
                out.append({"group": "Cities", "name": f"{name}, {st}", "lat": la, "lon": lo, "bbox": box(la, lo, city_radius)})
    if "water" in kinds:
        for st, name, la, lo, r in WATER:
            if home and _mi(la, lo, home[0], home[1]) > 450:
                continue
            out.append({"group": "Lakes, bays & coast", "name": f"{name} ({st})", "lat": la, "lon": lo, "bbox": box(la, lo, r)})
    return out
