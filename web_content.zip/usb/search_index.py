"""Full-text search index for the OFF-GRID SURVIVAL DRIVE — no AI, no server, no install needed.

Indexes every guide section and every page of every PDF manual on the drive, and writes small
JavaScript files that www/search.html loads straight from the drive (it works by double-clicking).

  www/search/docs.js        list of documents  (title, link, category, first page id, page count, anchors)
  www/search/plen.js        number of words on each page (for ranking)
  www/search/idx/<xx>.js    inverted index, split by the first 2 letters of each word (loaded on demand)
  www/search/text/<k>.js    page text of one document (loaded only to show snippets)
  www/search/manifest.json  cache, so re-runs only read new or changed PDFs

PDF text comes from pypdf (pure Python, loaded from its wheel file). Scanned PDFs that are only
pictures have no text to index — they still show up by title.
"""
import array, glob, hashlib, html, json, os, re, shutil, sys, time

STOP = set(("a an and are as at be been by for from has have how i im in is it its of on or our the to was we what when where "
            "which who why with do does my me can you your this that there it's i'm won don didn isn wasn can't won't don't just very "
            "really need help coming now got not no but if so than then them they he she his her him also all any will would should "
            "could may might must shall into out up down over under more most other some such only own same too s t").split())
WORD = re.compile(r"[a-z0-9]+")


def stem(w):
    return re.sub(r"(ing|ed|es|s)$", "", w) if len(w) > 4 else w


def tokens(text):
    return [stem(w) for w in WORD.findall(text.lower()) if len(w) > 1 and w not in STOP and len(w) < 25]


def _js(name, obj):
    return f"{name}({json.dumps(obj, separators=(',', ':'), ensure_ascii=False)});\n"


def _aes_ok():
    """True only if an AES backend pypdf can really use imports (a bare `cryptography` folder without its compiled part does not)."""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        pass
    try:
        from Crypto.Cipher import AES  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _pip_crypto(libdir):
    """pip resolves the compiled pieces properly; install into a private folder on the drive."""
    import subprocess
    out = os.path.join(libdir, "_crypto_pip")
    for pkg in ("pycryptodome", "cryptography"):
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check",
                            "--target", out, pkg], timeout=600, check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:  # noqa: BLE001
            continue
        sys.path.insert(0, out)
        if _aes_ok():
            return True
        sys.path.pop(0)
    return False


def _ensure_crypto(u, dest):
    """Best-effort: make the `cryptography` library importable so pypdf can read AES-encrypted PDFs
    (many TerraGo military GeoPDFs are encrypted with an empty password). Extracted wheel, like Pillow."""
    if _aes_ok():
        return
    import zipfile
    libdir = os.path.join(dest, "tools", "pylib")
    for d in sorted(glob.glob(os.path.join(libdir, "_crypto_*")), reverse=True):
        if os.path.isdir(d):
            sys.path.insert(0, d)
            if _aes_ok():
                return
            sys.path.pop(0)
    if _pip_crypto(libdir):
        return
    plat = ("win_amd64" if sys.platform.startswith("win") else
            "macosx" if sys.platform == "darwin" else "manylinux")
    # `cryptography` needs the compiled cffi module too, which an extracted wheel often lacks; pycryptodome is
    # self-contained and pypdf accepts either as its AES backend, so try it as a fallback.
    for pkg, mod in (("cryptography", "cryptography"), ("pycryptodome", "Crypto")):
        try:
            meta = json.loads(u.fetch(f"https://pypi.org/pypi/{pkg}/json", 60))
            cand = [x for x in meta["urls"] if x["filename"].endswith(".whl") and "abi3" in x["filename"]
                    and plat in x["filename"] and "arm64" not in x["filename"] and "aarch64" not in x["filename"]]
            if not cand:
                continue
            whl = os.path.join(libdir, cand[0]["filename"])
            if not os.path.exists(whl) and not u.download(cand[0]["url"], whl, f"{pkg} (for encrypted PDFs)"):
                continue
            out = os.path.join(libdir, "_crypto_" + pkg)
            shutil.rmtree(out, ignore_errors=True)
            zipfile.ZipFile(whl).extractall(out)
            sys.path.insert(0, out)
            if _aes_ok():
                return
            sys.path.pop(0)
        except Exception:  # noqa: BLE001
            if sys.path and sys.path[0].endswith("_crypto_" + pkg):
                sys.path.pop(0)
    print("  ! no AES library available - encrypted GeoPDFs will be skipped")


def get_pypdf(u, dest):
    """Import pypdf from a wheel kept on the drive (downloaded once from PyPI). Also makes `cryptography`
    available so encrypted GeoPDFs can be read."""
    _ensure_crypto(u, dest)        # MUST run before pypdf is first imported: pypdf picks its AES decoder at import
    if "pypdf" in sys.modules:
        return sys.modules["pypdf"]
    pypdf = None
    try:
        import pypdf  # noqa: F811
    except ImportError:
        libdir = os.path.join(dest, "tools", "pylib")
        whl = sorted(glob.glob(os.path.join(libdir, "pypdf-*.whl")))
        if not whl:
            try:
                meta = json.loads(u.fetch("https://pypi.org/pypi/pypdf/json", 60))
                f = next(x for x in meta["urls"] if x["filename"].endswith("py3-none-any.whl"))
                if u.download(f["url"], os.path.join(libdir, f["filename"]), "pypdf (PDF text reader)"):
                    whl = [os.path.join(libdir, f["filename"])]
            except Exception as e:  # noqa: BLE001
                print(f"  ! could not get pypdf: {e}")
        if whl:
            sys.path.insert(0, whl[-1])
            try:
                import pypdf
                import logging
                logging.getLogger("pypdf").setLevel(logging.ERROR)
            except Exception as e:  # noqa: BLE001
                print(f"  ! pypdf failed to load: {e}")
                pypdf = None
    return pypdf


def _merge_ocr(out, key, pages):
    """Where a PDF page has no real text (a scan), use the OCR'd text for that page if ocr.py produced any."""
    try:
        import ocr
        otext = ocr.ocr_text(out, key)
    except Exception:  # noqa: BLE001
        otext = {}
    if not otext:
        return pages
    pages = list(pages)
    for i, t in otext.items():
        if 0 <= i < len(pages) and len((pages[i] or "").strip()) < 40 and t.strip():
            pages[i] = t
    return pages


def pdf_pages(pypdf, path, limit=1500):
    import logging, warnings
    logging.getLogger("pypdf").setLevel(logging.CRITICAL)
    warnings.filterwarnings("ignore")
    try:
        r = pypdf.PdfReader(path, strict=False)
        if r.is_encrypted:
            try:
                r.decrypt("")
            except Exception:  # noqa: BLE001
                return []
        out = []
        for i, pg in enumerate(r.pages):
            if i >= limit:
                break
            try:
                t = pg.extract_text() or ""
            except Exception:  # noqa: BLE001
                t = ""
            out.append(re.sub(r"\s+", " ", t).strip())
        return out
    except Exception:  # noqa: BLE001
        return []


def _strip(x):
    x = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", x)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", x))).strip()


def other_pages(path, size=3000):
    """Text of an EPUB / DOCX / TXT / HTM copy, split into ~3,000-character 'pages' for the search index."""
    import zipfile
    low = path.lower()
    try:
        if low.endswith(".epub"):
            with zipfile.ZipFile(path) as z:
                names = sorted(n for n in z.namelist() if n.lower().endswith((".xhtml", ".html", ".htm")))
                txt = " ".join(_strip(z.read(n).decode("utf-8", "replace")) for n in names)
        elif low.endswith(".docx"):
            with zipfile.ZipFile(path) as z:
                x = z.read("word/document.xml").decode("utf-8", "replace")
            txt = _strip(re.sub(r"</w:p>", " \n", x))
        elif low.endswith(".htm"):
            txt = _strip(open(path, encoding="utf-8", errors="replace").read())
        else:
            txt = re.sub(r"\s+", " ", open(path, encoding="utf-8", errors="replace").read())
    except Exception:  # noqa: BLE001
        return []
    out, i = [], 0
    while i < len(txt) and len(out) < 1500:
        j = txt.rfind(" ", i, i + size) if i + size < len(txt) else len(txt)
        j = j if j > i else i + size
        out.append(txt[i:j]); i = j
    return out


def alt_title(titles, rel):
    """library/X/name2.epub beside a known library/X/name.pdf -> '<known title> (EPUB copy)'"""
    d, f = rel.rsplit("/", 1)
    stem, ext = os.path.splitext(f)
    base = stem.rstrip("0123456789").rstrip("_- ")
    for k, t in titles.items():
        kd, kf = k.rsplit("/", 1)
        if kd == d and os.path.splitext(kf)[0] == base and kf != f:
            return f"{t} ({ext.lstrip('.').upper()} copy)"
    return None


def guide_sections(path):
    src = open(path, encoding="utf-8", errors="replace").read()
    src = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", src)
    strip = lambda t: re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", t))).strip()  # noqa: E731
    m = re.search(r"(?is)<h1[^>]*>(.*?)</h1>", src)
    title = strip(m.group(1)) if m else os.path.splitext(os.path.basename(path))[0].replace("_", " ")
    parts = re.split(r"(?is)(<h2[^>]*>.*?</h2>)", src)
    intro = strip(parts[0])
    if m:
        intro = intro.split(strip(m.group(1)), 1)[-1].strip()
    pages, anchors = ["Introduction — " + intro[:3000]], [""]
    for i in range(1, len(parts), 2):
        tag = re.match(r"(?is)<h2([^>]*)>(.*?)</h2>", parts[i])
        idm = re.search(r'\bid="([^"]*)"', tag.group(1)) if tag else None
        head = strip(tag.group(2)) if tag else ""
        pages.append((head + " — " + strip(parts[i + 1] if i + 1 < len(parts) else ""))[:20000])
        anchors.append(idm.group(1) if idm else "")
    return title, pages, anchors


def _safe(name):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", name).strip(" .")
    return re.sub(r"\s+", " ", name)[:110] or "untitled"


def media_pages(path):
    """Movies & TV / Music catalogs as searchable text: every title, show, artist and album."""
    raw = open(path, encoding="utf-8").read()
    data = json.loads(raw.split("=", 1)[1].rstrip().rstrip(";"))
    lines = []
    if "items" in data:
        title = "Movies & TV on this drive"
        shows = {}
        for i in data["items"]:
            if "TV" in i["c"]:
                shows.setdefault((i["c"], i.get("show", "")), []).append(f"S{i.get('s', 0):02d}E{i.get('e', 0):02d} {i.get('t', '')}")
            else:
                lines.append(f"Movie: {i.get('t', '')} {i.get('y', '')} ({i['c']})")
        for (c, show), eps in sorted(shows.items()):
            lines.append(f"TV show: {show} ({c}, {len(eps)} episodes): " + "; ".join(eps))
    else:
        title = "Music on this drive"
        al = data.get("albums", [])
        by = {}
        for sg in data.get("songs", []):
            by.setdefault(sg["al"], []).append(sg.get("t", ""))
        for k, a in enumerate(al):
            lines.append(f"Album: {a.get('t', '')} by {a.get('a', '')} {a.get('y', '')} ({a.get('c', '')}): " + "; ".join(by.get(k, [])))
    pages, cur = [], ""
    for ln in lines:
        if len(cur) + len(ln) > 3000 and cur:
            pages.append(cur); cur = ""
        cur += ln + "\n"
    if cur:
        pages.append(cur)
    return title, pages or [title + ": nothing added yet."], None


def text_copy(dest, rel, e, pages, src, keep):
    """TEXT-ONLY/<category>/<title>.txt — readable in Notepad on any computer, no browser or server."""
    if rel.startswith("mymaps/") or "topo" in rel:
        return
    d = os.path.join(dest, "TEXT-ONLY", _safe(e["cat"]))
    base = _safe(e["title"])
    tp = os.path.join(d, base + ".txt")
    k = 2
    while tp in keep:
        tp, k = os.path.join(d, f"{base} ({k}).txt"), k + 1
    keep.add(tp)
    if os.path.exists(tp) and os.path.getmtime(tp) >= os.path.getmtime(src):
        return
    os.makedirs(d, exist_ok=True)
    pdf = rel.lower().endswith(".pdf")
    with open(tp, "w", encoding="utf-8-sig", newline="\r\n") as fh:
        fh.write(f"{e['title']}\nOriginal: OFFGRID\\www\\{rel.replace('/', chr(92))}\n{'=' * 70}\n")
        for i, ptxt in enumerate(pages):
            if len(pages) > 1:
                fh.write(f"\n----- {'page' if pdf else 'part'} {i + 1} -----\n")
            fh.write(re.sub(r"[ \t]{2,}", " ", ptxt).strip() + "\n")


def _zim_label(stem):
    """Friendly archive name + extra search keywords for a .zim filename stem."""
    s = stem.lower()
    table = [
        ("wikipedia", "Wikipedia", "encyclopedia articles reference facts history geography science people places how things work"),
        ("khanacademy", "Khan Academy", "courses lessons school math science education learn teach study videos"),
        ("ifixit", "iFixit repair guides", "repair fix electronics appliances phone laptop teardown broken replace part"),
        ("wikibooks", "Wikibooks", "textbooks how-to manuals books learning cookbook"),
        ("wikisource", "Wikisource", "source documents books texts primary historical"),
        ("wikivoyage", "Wikivoyage", "travel guide cities countries destinations trip"),
        ("gutenberg", "Project Gutenberg", "books literature novels classics reading ebooks"),
        ("mdwiki", "MDWiki (medical)", "medicine clinical disease treatment health doctor symptoms drugs"),
        ("wikem", "WikEM (emergency medicine)", "emergency medicine clinical trauma resuscitation"),
        ("libretexts", "LibreTexts (textbooks)", "textbooks biology chemistry medicine physics science"),
        ("appropedia", "Appropedia", "appropriate technology sustainability diy build homestead low-tech"),
        ("phet", "PhET simulations", "physics chemistry biology math interactive science experiment"),
        ("vikidia", "Vikidia (for kids)", "children kids encyclopedia simple school"),
        ("mechanics.stackexchange", "Mechanics Stack Exchange", "car truck vehicle engine repair mechanic auto"),
        ("diy.stackexchange", "DIY Stack Exchange", "home repair build tools fix plumbing electrical"),
        ("gardening.stackexchange", "Gardening Stack Exchange", "garden plants vegetables grow soil seeds compost"),
        ("ham.stackexchange", "Amateur (Ham) Radio Stack Exchange", "amateur ham radio antenna frequency repeater signal"),
        ("outdoors.stackexchange", "Outdoors Stack Exchange", "hiking camping survival wilderness backpacking"),
        ("cooking.stackexchange", "Cooking Stack Exchange", "cooking food recipe kitchen preserve"),
        ("electronics.stackexchange", "Electronics Stack Exchange", "circuit electronics components voltage solder arduino"),
        ("bicycles.stackexchange", "Bicycles Stack Exchange", "bike bicycle repair gears chain"),
        ("woodworking.stackexchange", "Woodworking Stack Exchange", "wood tools joinery saw finish"),
        ("sustainability.stackexchange", "Sustainability Stack Exchange", "sustainability energy environment solar water"),
        ("zimgit-medicine", "Where There Is No Doctor (medicine)", "medicine first aid doctor health treatment wound"),
        ("zimgit-water", "Drinking water (zimgit)", "water purification filter safe drink boil"),
        ("zimgit-food", "Food preparation (zimgit)", "food cooking preserve storage ration"),
        ("zimgit-knots", "Knots (zimgit)", "knots rope cordage tie lashing hitch"),
        ("zimgit-post-disaster", "Post-disaster survival (zimgit)", "disaster emergency survival shelter sanitation"),
    ]
    for key, name, kw in table:
        if key in s:
            return name, kw
    base = re.split(r"_en[_-]|_all|_maxi|\d{4}-\d{2}", stem)[0].replace("_", " ").replace(".", " ").strip()
    return (base.title() or stem, base.lower())


def write_search_extra(dest):
    """Write www/search/extra.js: the archives (ZIMs -> Kiwix) and topo map sheets (-> PDF) so the main
    search surfaces Wikipedia/Khan/etc. and finds a map sheet by place name. Light data, matched in-browser."""
    out = os.path.join(dest, "www", "search")
    os.makedirs(out, exist_ok=True)
    archives = []
    for z in sorted(glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim"))):
        stem = os.path.splitext(os.path.basename(z))[0]
        name, kw = _zim_label(stem)
        archives.append({"n": name, "f": stem, "kw": kw})
    quads, seen = [], set()
    try:
        c = json.load(open(os.path.join(dest, "www", "topo", "catalog.json"), encoding="utf-8"))
        groups = [(c.get("home") or {}).get("quads", [])] + [a.get("quads", []) for a in (c.get("areas") or {}).values()]
        for g in groups:
            for q in g:
                rel, t = q.get("rel"), q.get("t")
                if rel and t and rel not in seen:
                    seen.add(rel); quads.append({"t": t, "r": "topo/" + rel})
    except (OSError, ValueError):
        pass
    try:
        cc = json.load(open(os.path.join(dest, "www", "topo", "canada", "canada.json"), encoding="utf-8"))
        for m in cc.values():
            for q in m.get("sheets", []):
                rel = "topo/" + q["rel"]
                if rel not in seen:
                    seen.add(rel); quads.append({"t": f"{q['t']} ({m.get('label', 'Canada')})", "r": rel})
    except (OSError, ValueError):
        pass
    with open(os.path.join(out, "extra.js"), "w", encoding="utf-8") as fh:
        fh.write("window.SEARCH_EXTRA=" + json.dumps({"archives": archives, "quads": quads},
                                                     separators=(",", ":"), ensure_ascii=False) + ";\n")
    return len(archives), len(quads)


def build(u, dest):
    u.say("Full-text search index (works with no AI and no server)")
    t0 = time.time()
    www = os.path.join(dest, "www")
    out = os.path.join(www, "search")
    os.makedirs(os.path.join(out, "text"), exist_ok=True)
    try:
        manifest = json.load(open(os.path.join(out, "manifest.json"), encoding="utf-8"))
    except (OSError, ValueError):
        manifest = {}
    titles = {}
    tsv = os.path.join(u.REPO, "library", "manuals.tsv")
    for line in open(tsv, encoding="utf-8"):
        p = line.rstrip("\n").split("\t")
        if len(p) >= 4 and not p[0].startswith("#"):
            titles[f"library/{p[0]}/{p[2]}"] = p[1]
    files = sorted(glob.glob(os.path.join(www, "library", "*", "*.html"))) + \
        sorted(glob.glob(os.path.join(www, "library", "*", "*.pdf"))) + \
        sorted(f for e in ("epub", "txt", "docx", "htm") for f in glob.glob(os.path.join(www, "library", "*", "*." + e))) + \
        sorted(glob.glob(os.path.join(www, "topo", "index.html"))) + \
        sorted(glob.glob(os.path.join(www, "mymaps", "**", "*.pdf"), recursive=True)) + \
        sorted(glob.glob(os.path.join(www, "mymaps", "index.html"))) + \
        [f for f in (os.path.join(www, "media", "catalog.js"), os.path.join(www, "music", "catalog.js")) if os.path.exists(f)]
    files = [f for f in files if not f.endswith("_COMPLETE.pdf") and os.path.basename(f) != "index.html" or "topo" in f or "mymaps" in f]
    try:
        import reports as _rep
        files = _rep.readable(dest, files)               # skip (and list) damaged files instead of stopping the whole index
    except ImportError:
        pass
    pypdf = None
    docs, new_manifest, read = [], {}, 0
    for f in files:
        rel = os.path.relpath(f, www).replace(os.sep, "/")
        st = os.stat(f)
        sig = [st.st_size, int(st.st_mtime)]
        key = hashlib.sha1(rel.encode()).hexdigest()[:14]
        tp = os.path.join(out, "text", key + ".js")
        m = manifest.get(rel)
        if m and m["sig"] == sig and os.path.exists(tp):
            entry = m
        else:
            if f.endswith("catalog.js"):
                title, pages, anchors = media_pages(f)
            elif f.endswith(".pdf"):
                if pypdf is None:
                    pypdf = get_pypdf(u, dest) or False
                pages = pdf_pages(pypdf, f) if pypdf else []
                pages = _merge_ocr(out, key, pages)       # fill scanned (text-less) pages with OCR text, if any
                anchors, title = None, titles.get(rel) or os.path.splitext(os.path.basename(f))[0].replace("_", " ")
                read += 1
                print(f"\r  reading PDFs: {read} ({os.path.basename(f)[:50]:<50})", end="", flush=True)
            elif f.lower().endswith((".epub", ".txt", ".docx", ".htm")):
                pages, anchors = other_pages(f), None
                title = titles.get(rel) or alt_title(titles, rel) or os.path.splitext(os.path.basename(f))[0].replace("_", " ")
            else:
                title, pages, anchors = guide_sections(f)
                if "topo" in rel:
                    title = "Topographic maps (USGS) — list of quads"
                elif "mymaps" in rel:
                    title = "My Maps — military & special maps"
            with open(tp, "w", encoding="utf-8") as fh:
                fh.write(_js("SEARCH_TEXT", [key, [p[:6000] for p in pages]]))
            entry = {"sig": sig, "key": key, "title": title, "n": len(pages), "anchors": anchors,
                     "cat": rel.split("/")[1] if rel.startswith("library/") else "My Maps" if rel.startswith("mymaps/") else "Movies & TV" if rel.startswith("media/") else "Music" if rel.startswith("music/") else "Maps", "chars": sum(len(p) for p in pages)}
        new_manifest[rel] = entry
        docs.append((rel, entry))
    if read:
        print()
    try:                                                   # articles inside the smaller Kiwix archives (.zim)
        import zim_index
        zdocs, znotes = zim_index.docs(dest, out, manifest, new_manifest, _zim_label, _js, u)
        docs += zdocs
        zim_index.write_report(dest, znotes)
        import archive_lists
        n, fresh = archive_lists.build(dest, _zim_label)
        if n:
            print(f"  Archive contents: {n} archives listed ({fresh} re-read) -> www/archives.html")
    except Exception as e:  # noqa: BLE001
        print(f"  ! ZIM articles skipped: {type(e).__name__}: {e}")
    # inverted index (rebuilt from the cached page text: fast); also the plain-text copies in TEXT-ONLY/
    keep_txt = set()
    post, plen, doclist, pid = {}, [], [], 0
    import search_db                                       # fast SQLite FTS5 copy of the same pages (used when the server runs)
    fts = None
    if search_db.available():
        try:
            fts = search_db.Writer(dest)
        except Exception as ex:  # noqa: BLE001
            print(f"  ! fast search database skipped: {ex}")
    else:
        print("  (this Python has no SQLite FTS5 — the fast search database is skipped; search still works)")
    kdb = None
    if fts:
        try:
            import ai_memory                               # the AI's overnight page notes go into the fast index too
            kdb = ai_memory.connect(dest, readonly=True)
        except Exception:  # noqa: BLE001
            kdb = None
    for rel, e in docs:
        try:
            txt = open(os.path.join(out, "text", e["key"] + ".js"), encoding="utf-8").read()
            pages = json.loads(txt[len("SEARCH_TEXT("):-3])[1]
        except (OSError, ValueError):
            continue
        link = rel[:-len("catalog.js")] + "index.html" if rel.endswith("catalog.js") else rel
        if rel.startswith("zim/"):
            link = "zim.html?z=" + e["zim"]                 # article viewer: index text offline, full page via Kiwix
        doclist.append([e["title"], link, e["cat"], pid, len(pages), e.get("anchors"), e["key"]])
        if not rel.startswith("zim/"):                      # archives are not copied to TEXT-ONLY (too many files)
            text_copy(dest, rel, e, pages, os.path.join(out, "text", e["key"] + ".js"), keep_txt)
        pctx = ai_memory.contexts_for_doc(kdb, doclist[-1][6]) if kdb else {}
        for pno, ptxt in enumerate(pages):
            if fts:
                fts.add(pid, len(doclist) - 1, (pctx[pno] + "\n" + ptxt) if pno in pctx else ptxt)
            toks = tokens(ptxt)
            plen.append(len(toks))
            tf = {}
            for w in toks:
                tf[w] = tf.get(w, 0) + 1
            for w, c in tf.items():
                a = post.get(w)
                if a is None:
                    a = post[w] = array.array("I")
                a.append(pid); a.append(min(c, 255))
            pid += 1
    npages = max(1, pid)
    common = sorted(w for w, a in post.items() if len(a) // 2 > max(400, npages * 0.35))
    for w in common:
        del post[w]
    shards = {}
    for w, a in post.items():
        shards.setdefault(w[:2], {})[w] = a.tolist()
    idx = os.path.join(out, "idx")
    os.makedirs(idx, exist_ok=True)
    for old in glob.glob(os.path.join(idx, "*.js")):
        if os.path.splitext(os.path.basename(old))[0] not in shards:
            os.remove(old)
    for k, d in shards.items():
        with open(os.path.join(idx, k + ".js"), "w", encoding="utf-8") as fh:
            fh.write(_js("SEARCH_SHARD", [k, d]))
    tdir = os.path.join(dest, "TEXT-ONLY")
    for old in glob.glob(os.path.join(tdir, "*", "*.txt")):
        if old not in keep_txt:
            os.remove(old)
    if os.path.isdir(tdir):
        with open(os.path.join(tdir, "README.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("PLAIN-TEXT COPIES OF EVERYTHING ON THIS DRIVE\n\nFor a computer with no web browser, a locked-down PC, an e-reader "
                     "or a phone: every guide, every PDF manual and every e-book as a plain .txt file, one folder per library section.\n"
                     "Open any of them in Notepad (or any text app). Pictures, diagrams and tables are not included - see the original "
                     "file named at the top of each.\n\nTo search: run START-HERE.bat in the OFFGRID folder and pick 2, or in a "
                     "command window:  findstr /s /i /m \"tourniquet\" *.txt   (Mac/Linux: grep -ril tourniquet .)\n")
    with open(os.path.join(out, "docs.js"), "w", encoding="utf-8") as fh:
        fh.write("window.SEARCH_DOCS=" + json.dumps(doclist, separators=(",", ":"), ensure_ascii=False) + ";\n")
        fh.write("window.SEARCH_COMMON=" + json.dumps(common) + ";\n")
        fh.write(f"window.SEARCH_BUILT={json.dumps(time.strftime('%Y-%m-%d'))};\n")
    with open(os.path.join(out, "plen.js"), "w") as fh:
        fh.write("window.SEARCH_PLEN=" + json.dumps(plen, separators=(",", ":")) + ";\n")
    if kdb:
        kdb.close()
    if fts:
        try:
            t1 = time.time()
            n = fts.finish(doclist, time.strftime("%Y-%m-%d %H:%M:%S"))
            print(f"  fast search database: {n:,} pages, {os.path.getsize(search_db.path(dest)) / 1e6:,.0f} MB ({time.time() - t1:.0f} s)")
        except Exception as ex:  # noqa: BLE001
            fts.abort()
            print(f"  ! fast search database: {ex} — the regular index still works")
    for rel, e in manifest.items():                       # drop text of documents that are gone
        if rel not in new_manifest:
            try:
                os.remove(os.path.join(out, "text", e["key"] + ".js"))
            except OSError:
                pass
    with open(os.path.join(out, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(new_manifest, fh)
    na, nq = write_search_extra(dest)                     # archives (-> Kiwix) + map sheets (-> PDF) for the search page
    print(f"  + {na} archives and {nq} map sheets added to search")
    empty = sum(1 for r, e in docs if r.endswith(".pdf") and e["chars"] < 200)
    print(f"  {len(doclist)} documents, {pid:,} pages/sections, {len(post):,} words indexed"
          f" ({time.time() - t0:.0f} s){f'; {empty} PDFs have no text layer (scans) — found by title only' if empty else ''}")
