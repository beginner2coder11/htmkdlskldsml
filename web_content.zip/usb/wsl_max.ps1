# Gives WSL2 (and so NOMAD) as much of this PC as it can safely have.
#   (no switch)  write %USERPROFILE%\.wslconfig for maximum memory, then restart WSL to apply
#   -FreeUp      also offer to close big apps (browsers, chat, sync) before the install
#   -Restore     put your previous .wslconfig back
# WSL2 normally gets only half the RAM and 25% swap. On a 16 GB PC that is ~7.5 GB, too little for NOMAD's containers + AI.
param([switch]$FreeUp, [switch]$Restore)
$cfg = Join-Path $env:USERPROFILE ".wslconfig"
$bak = "$cfg.offgrid-backup"
if ($Restore) {
    if (Test-Path $bak) { Copy-Item $bak $cfg -Force; Write-Host "Restored your previous .wslconfig." } else { Remove-Item $cfg -ErrorAction SilentlyContinue; Write-Host "Removed .wslconfig (WSL defaults)." }
    & wsl.exe --shutdown; exit
}
$cs = Get-CimInstance Win32_ComputerSystem
$totalGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
$cores = [int]$cs.NumberOfLogicalProcessors
# leave Windows what it needs to stay alive: 2 GB on small PCs, 3 GB from 24 GB up
$keep = if ($totalGB -ge 24) { 3 } else { 2 }
$mem = [math]::Max(4, [math]::Floor($totalGB - $keep))
$freeC = [math]::Round((Get-PSDrive C).Free / 1GB)
$swap = if ($freeC -gt 150) { 32 } elseif ($freeC -gt 60) { 24 } else { 12 }      # swap = overflow room on disk; only used when RAM runs out
Write-Host "This PC: $totalGB GB RAM, $cores cores, $freeC GB free on C:"
Write-Host "WSL2 will get: $mem GB RAM, $cores cores, $swap GB swap (Windows keeps about $keep GB)."
if ((Test-Path $cfg) -and -not (Test-Path $bak)) { Copy-Item $cfg $bak -Force }
$swapfile = (Join-Path $env:USERPROFILE "wsl-swap.vhdx").Replace("\", "\\")
@"
[wsl2]
memory=${mem}GB
processors=$cores
swap=${swap}GB
swapFile=$swapfile
pageReporting=true
vmIdleTimeout=-1

[experimental]
autoMemoryReclaim=disabled
sparseVhd=true
"@ | Set-Content $cfg -Encoding ASCII
Write-Host "Wrote $cfg"

if ($FreeUp) {
    $heavy = "chrome", "msedge", "firefox", "brave", "opera", "Teams", "ms-teams", "Discord", "Spotify", "Steam", "Slack", "Zoom", "OneDrive", "Dropbox", "Code", "Adobe*"
    $run = Get-Process -ErrorAction SilentlyContinue | Where-Object { $n = $_.ProcessName; $heavy | Where-Object { $n -like $_ } }
    $mb = [math]::Round(($run | Measure-Object WorkingSet64 -Sum).Sum / 1MB)
    if ($run) {
        Write-Host ""; Write-Host "Big apps running (using about $mb MB):" -ForegroundColor Yellow
        $run | Group-Object ProcessName | ForEach-Object { "  {0} ({1} processes)" -f $_.Name, $_.Count }
        if ((Read-Host "Close them now to free memory for the install? Save your work first. Type YES") -eq "YES") {
            $run | Stop-Process -Force -ErrorAction SilentlyContinue; Start-Sleep 3; Write-Host "Closed."
        }
    } else { Write-Host "No big apps found running." }
}
Write-Host "Restarting WSL so the new limits apply..."
& wsl.exe --shutdown
Start-Sleep 8
$free = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1MB, 1)
Write-Host "Free RAM now: $free GB. Done."
