"""Download the US hospitals layer (HIFLD Open: ~7,500 facilities with coordinates, phone, beds, trauma level, helipad).

HIFLD data is US-government public domain. Primary mirror: NASA NCCS ArcGIS server (hifld_open/public_health, layer 0);
fallback: Penn State PASDA HIFLD_FEMA layer 51. Cached in www\\data\\hifld\\hospitals.json; hospitals_data.py merges it
with the SimpleMaps list (emergency-services flag) into EXCEL-READY\\US-hospitals.xlsx and GOOGLE-EARTH-READY\\Hospitals.kml.
Note: these are mirrors of the HIFLD Open layer; the data may be a snapshot, not current. Phone numbers and bed counts can be out of date.
"""
import json
import os
import urllib.parse

SOURCES = [
    "https://maps.nccs.nasa.gov/mapping/rest/services/hifld_open/public_health/MapServer/0/query",
    "https://mapservices.pasda.psu.edu/server/rest/services/pasda/HIFLD_FEMA/MapServer/51/query",
]


def fetch_rows(u, base):
    rows, off, step = [], 0, 2000
    while True:
        q = urllib.parse.urlencode({"where": "1=1", "outFields": "*", "returnGeometry": "false", "f": "json",
                                    "resultOffset": off, "resultRecordCount": step, "orderByFields": "OBJECTID" if "pasda" in base else "objectid"})
        j = json.loads(u.fetch(f"{base}?{q}", 180))
        if "error" in j:
            raise RuntimeError(str(j["error"])[:150])
        feats = j.get("features", [])
        rows += [{k.lower(): v for k, v in (f.get("attributes") or {}).items()} for f in feats]
        print(f"\r  {len(rows):,} hospitals", end="", flush=True)
        if not feats or not (j.get("exceededTransferLimit") or len(feats) >= step):
            break
        off += len(feats)
    print()
    return rows


def build(u, dest):
    u.say("US hospitals layer (HIFLD: coordinates, phone, beds, trauma, helipad)")
    out = os.path.join(dest, "www", "data", "hifld")
    p = os.path.join(out, "hospitals.json")
    if os.path.exists(p) and not getattr(u, "UPDATE", False):
        print("  already downloaded (delete www\\data\\hifld\\hospitals.json to refresh)")
        return True
    for base in SOURCES:
        host = base.split("/")[2]
        try:
            rows = fetch_rows(u, base)
        except Exception as e:  # noqa: BLE001
            print(f"\n  ! {host}: {str(e)[:120]}")
            continue
        if len(rows) > 1000:
            os.makedirs(out, exist_ok=True)
            keep = ("id", "name", "alt_name", "address", "city", "state", "zip", "telephone", "type", "status", "latitude", "longitude",
                    "website", "owner", "beds", "trauma", "helipad", "county", "ttl_staff")
            with open(p, "w", encoding="utf-8") as fh:
                json.dump([{k: r.get(k) for k in keep} for r in rows], fh)
            print(f"  saved {len(rows):,} hospitals from {host}")
            return True
        print(f"  ! {host} returned only {len(rows)} rows - trying the next source")
    print("  ! Could not download the hospitals layer (servers unreachable). The SimpleMaps list is still used.")
    return False
