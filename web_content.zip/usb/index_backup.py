# -*- coding: utf-8 -*-
"""Backups of the drive's indexes and settings, in <drive>\\BACKUP\\INDEXES\\, taken after every build and update.

What is backed up (the things that are slow or impossible to remake — not the big downloads, which re-download):
  search index (www/search: docs, word index, page text, meaning-search vectors, OCR text — not search.db,
  which is rebuilt from the page text in seconds), archive contents lists, ZIM article picks, route places,
  FEMA data, build settings, the manuals list, download history, the drive's own page data (www/data/*.js/json).

Each backup is a folder named by date with one zip per part and MANIFEST.json (size + SHA-256 of every file).
The newest 2 are kept. A backup is skipped when nothing changed since the last one.

    python index_backup.py --dest E:\\OFFGRID                 make a backup now (skips if unchanged)
    python index_backup.py --dest E:\\OFFGRID --check         list missing / damaged index files
    python index_backup.py --dest E:\\OFFGRID --restore       put back missing / damaged files from the newest backup
    python index_backup.py --dest E:\\OFFGRID --restore --all put back everything from the newest backup
    python index_backup.py --dest E:\\OFFGRID --copy-to F:\\   copy the newest backup to another drive or folder
"""
import argparse, glob, hashlib, json, os, shutil, sys, time, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
KEEP = 2
PARTS = {   # part name: (folder or file relative to the drive, files to leave out)
    "search": ("www/search", ("search.db", "search.db.building", ".tmp", ".part")),
    "archives": ("www/archives", ()),
    "zim-picks": ("tools/zim-subsets", ()),
    "route-places": ("www/data/corridors", ()),
    "ai-memory": ("ai/memory", ("knowledge.db-journal",)),
    "page-data": ("www/data", ("corridors/", "ham/", "fema/")),
    "settings": ("tools", ("zim-subsets/", "pylib/", "builder/", "fema-cache/", "corridor-cache/", "python/", "bin/", ".zip", ".exe",
                           ".gguf", ".pbf", ".osm", "cache")),
}
SMALL_ONLY = {"page-data": 50e6, "settings": 20e6}      # skip single files bigger than this in these parts
STORE = (".bin", ".i8", ".gz", ".zip", ".png", ".jpg", ".pdf")   # already compact: store without compressing


def root(dest):
    return os.path.join(dest, "BACKUP", "INDEXES")


def _files(dest, part):
    base, skip = PARTS[part]
    top = os.path.join(dest, *base.split("/"))
    if not os.path.isdir(top):
        return []
    out = []
    for d, dirs, fs in os.walk(top):
        rd = os.path.relpath(d, top).replace(os.sep, "/")
        rd = "" if rd == "." else rd + "/"
        if part == "settings" and rd:          # settings: only the top level of tools/ (small json/tsv files)
            dirs[:] = []
            continue
        for f in fs:
            rel = rd + f
            if any(rel.startswith(s) or rel.endswith(s) or s in rel.split("/")[0] for s in skip):
                continue
            p = os.path.join(d, f)
            try:
                st = os.stat(p)
            except OSError:
                continue
            if part in SMALL_ONLY and st.st_size > SMALL_ONLY[part]:
                continue
            out.append((f"{base}/{rel}", p, st.st_size, int(st.st_mtime)))
    return out


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _sig(dest):
    return {rel: [size, mt] for part in PARTS for rel, _, size, mt in _files(dest, part)}


def latest(dest):
    bs = sorted(d for d in glob.glob(os.path.join(root(dest), "*")) if os.path.exists(os.path.join(d, "MANIFEST.json")))
    return bs[-1] if bs else None


def backup(dest, quiet=False):
    say = (lambda *a: None) if quiet else print
    last = latest(dest)
    sig = _sig(dest)
    if not sig:
        say("  nothing to back up yet")
        return None
    if last:
        try:
            m = json.load(open(os.path.join(last, "MANIFEST.json"), encoding="utf-8"))
            if {k: v[:2] for k, v in m["files"].items()} == {k: [v[0], v[1]] for k, v in sig.items()}:
                say(f"  indexes unchanged since the last backup ({os.path.basename(last)}) — skipped")
                return last
        except (OSError, ValueError, KeyError):
            pass
    t0 = time.time()
    name = time.strftime("%Y-%m-%d_%H%M%S")
    tmp = os.path.join(root(dest), name + ".partial")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    man = {"made": time.strftime("%Y-%m-%d %H:%M:%S"), "parts": {}, "files": {}}
    try:
        for part in PARTS:
            fs = _files(dest, part)
            if not fs:
                continue
            zp = os.path.join(tmp, part + ".zip")
            with zipfile.ZipFile(zp, "w", allowZip64=True) as z:
                for rel, p, size, mt in fs:
                    if rel in man["files"]:
                        continue                                  # a file already in an earlier part (route places)
                    comp = zipfile.ZIP_STORED if p.lower().endswith(STORE) else zipfile.ZIP_DEFLATED
                    z.write(p, rel, compress_type=comp, compresslevel=6 if comp == zipfile.ZIP_DEFLATED else None)
                    man["files"][rel] = [size, mt, _sha(p), part]
            man["parts"][part] = os.path.getsize(zp)
        json.dump(man, open(os.path.join(tmp, "MANIFEST.json"), "w", encoding="utf-8"))
        final = os.path.join(root(dest), name)
        if os.path.exists(final):
            shutil.rmtree(final)
        os.replace(tmp, final)
    except OSError as ex:
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"  ! index backup failed: {ex}")
        return None
    olds = sorted(d for d in glob.glob(os.path.join(root(dest), "*")) if os.path.isdir(d))
    for d in olds:
        if d.endswith(".partial") and d != tmp:
            shutil.rmtree(d, ignore_errors=True)
    olds = [d for d in olds if not d.endswith(".partial")]
    for d in olds[:-KEEP]:
        shutil.rmtree(d, ignore_errors=True)
    _readme(dest)
    say(f"  index backup: {len(man['files']):,} files, {sum(man['parts'].values()) / 1e6:,.0f} MB in BACKUP\\INDEXES\\{name} "
        f"({time.time() - t0:.0f} s; newest {KEEP} kept)")
    return final


def check(dest, deep=False):
    """-> (missing, damaged) relative paths compared with the newest backup.
    damaged = size differs while the file is not newer than the backup (it changed without a rebuild), or (deep) hash differs."""
    last = latest(dest)
    if not last:
        return None, None
    m = json.load(open(os.path.join(last, "MANIFEST.json"), encoding="utf-8"))
    made = os.path.getmtime(os.path.join(last, "MANIFEST.json"))
    missing, damaged = [], []
    for rel, (size, mt, sha, part) in m["files"].items():
        p = os.path.join(dest, *rel.split("/"))
        if not os.path.exists(p):
            missing.append(rel)
            continue
        st = os.stat(p)
        if st.st_mtime > made + 60:
            continue                                          # rebuilt after the backup: newer, not damaged
        if st.st_size != size or (deep and _sha(p) != sha):
            damaged.append(rel)
    # files the pages need that must parse
    for rel in ("www/search/docs.js", "www/search/plen.js"):
        p = os.path.join(dest, *rel.split("/"))
        try:
            t = open(p, encoding="utf-8").read()
            json.loads(t.split("=", 1)[1].split(";\n")[0])
        except (OSError, ValueError, IndexError):
            if rel not in missing and rel not in damaged:
                damaged.append(rel)
    return missing, damaged


def restore(dest, everything=False):
    last = latest(dest)
    if not last:
        print("  No index backup on this drive yet.")
        return 0
    m = json.load(open(os.path.join(last, "MANIFEST.json"), encoding="utf-8"))
    if everything:
        todo = set(m["files"])
    else:
        missing, damaged = check(dest, deep=True)
        todo = set(missing) | set(damaged)
    if not todo:
        print(f"  Everything matches the newest backup ({os.path.basename(last)}) — nothing to restore.")
        if not os.path.exists(os.path.join(dest, "www", "search", "search.db")):
            _rebuild_db(dest)
        return 0
    n = 0
    for part in m["parts"]:
        want = [r for r in todo if m["files"].get(r, [0, 0, 0, ""])[3] == part]
        if not want:
            continue
        with zipfile.ZipFile(os.path.join(last, part + ".zip")) as z:
            for rel in want:
                out = os.path.join(dest, *rel.split("/"))
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with z.open(rel) as src, open(out + ".restoring", "wb") as dst:
                    shutil.copyfileobj(src, dst, 1 << 20)
                os.replace(out + ".restoring", out)
                os.utime(out, (time.time(), m["files"][rel][1]))
                n += 1
    print(f"  Restored {n:,} files from BACKUP\\INDEXES\\{os.path.basename(last)}")
    if any(r.startswith("www/search/") for r in todo):
        _rebuild_db(dest)
    return n


def _rebuild_db(dest):
    """search.db is not backed up: remake it from the restored page text (seconds to minutes)."""
    try:
        sys.path.insert(0, HERE)
        import search_db
        search_db.rebuild_from_text(dest)
    except Exception as ex:  # noqa: BLE001
        print(f"  ! fast search database not remade ({ex}) — the next REBUILD-SEARCH will make it")


def copy_to(dest, target):
    last = latest(dest)
    if not last:
        print("  No index backup yet.")
        return
    out = os.path.join(target, "OFFGRID-INDEX-BACKUP", os.path.basename(last))
    if os.path.exists(out):
        shutil.rmtree(out)
    shutil.copytree(last, out)
    print(f"  Copied to {out}")


def _readme(dest):
    with open(os.path.join(dest, "BACKUP", "README.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("BACKUP\n\nINDEXES\\ holds copies of the drive's search index, meaning-search index, archive lists, route places,\n"
                 "FEMA data and build settings - made automatically after every build and update (newest 2 kept).\n\n"
                 "If search stops working or files were deleted: run PROGRAMS\\RESTORE-INDEXES.bat.\n"
                 "DRIVE-CHECK also reports damaged index files. To keep a copy off this drive: RESTORE-INDEXES.bat, option C.\n\n"
                 "This protects against deleted or damaged files, not against losing the whole drive - for that, copy\n"
                 "BACKUP\\INDEXES to another drive now and then (option C), and keep your MY-FILES originals elsewhere too.\n")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--restore", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--copy-to")
    a = ap.parse_args()
    if a.check:
        mi, da = check(a.dest, deep=True)
        if mi is None:
            print("  No index backup on this drive yet.")
        else:
            print(f"  missing: {len(mi)}   damaged: {len(da)}")
            for r in (mi + da)[:40]:
                print("   ", r)
            sys.exit(1 if mi or da else 0)
    elif a.restore:
        restore(a.dest, a.all)
    elif a.copy_to:
        copy_to(a.dest, a.copy_to)
    else:
        backup(a.dest)
