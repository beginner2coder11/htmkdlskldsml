#!/bin/sh
# ===== OFF-GRID SURVIVAL DRIVE — copy the AI to this computer (macOS / Linux) =====
# Copies the models this computer uses to ~/.offgrid-ai so the AI loads faster. The drive stays the master copy.
#   sh copy-ai-mac-linux.sh          copy (or refresh)
#   sh copy-ai-mac-linux.sh status   show what is copied
#   sh copy-ai-mac-linux.sh remove   delete the copy (the drive is not touched)
cd "$(dirname "$0")" || exit 1
command -v python3 >/dev/null 2>&1 || { echo "python3 is needed for this."; exit 1; }
python3 tools/builder/usb/ai_local.py --dest . "${1:-copy}"
