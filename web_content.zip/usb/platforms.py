"""PLATFORMS\\ (one folder of instructions + scripts per device) and TRAVEL\\ (ready-to-copy "go drive" folders).

PLATFORMS\\{WINDOWS,MAC,LINUX,IPHONE,ANDROID}   plain instructions and the start script for each device.
www\\platforms\\                                 the same instructions as web pages (so the Command Center can open them).
TRAVEL\\<DEVICE>-GO\\OFFGRID                     a complete, correctly laid-out drive for that device, sized to a budget.
                                               Copy the OFFGRID folder inside it to the go drive (copy and paste).

The TRAVEL folders cost almost no extra space: large files are NTFS hard links to the master files, small files are
real copies. Deleting something inside TRAVEL never touches the master drive. On a drive that can't make hard links
(exFAT) the builder writes a copy list instead and tells you to use COPY-TO-ANOTHER-DRIVE.

    python platforms.py --dest E:\\OFFGRID                          write PLATFORMS\\ (also done by the builder)
    python platforms.py --dest E:\\OFFGRID --travel                 build every TRAVEL\\*-GO folder
    python platforms.py --dest E:\\OFFGRID --travel --device android --budget-gb 64
"""
import argparse
import fnmatch
import html
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

DEVICES = ("windows", "mac", "linux", "iphone", "android")
KINDS = DEVICES + ("all",)       # "all" = ONE go drive that works on every device (exFAT)
BUDGET = {"windows": 256, "mac": 256, "linux": 256, "iphone": 64, "android": 64, "all": 256}   # GB defaults for the go drive
MAX_GB = 2000                    # largest go drive offered (2 TB)
SIZES = (32, 64, 128, 256, 512, 1024, 2000)   # drive sizes shown in the budget guide
STATE = "travel-state.json"      # TRAVEL\\travel-state.json remembers what was built, so an update can rebuild it
SMALL = 2 << 20          # files under this are real copies, larger ones hard links

README = {
"WINDOWS": """OFFGRID on Windows
==================
1. Plug the drive in and open the OFFGRID folder.
2. Double-click  START-HERE.bat  and press 1   (starts the search, AI, maps and archives, then opens the Command Center in its own window; close that window to stop).
3. Nothing to install. Everything runs from the drive (tools\\python-win).
Notebook you can write in: FIELD-NOTEBOOK.html (open it in TiddlyDesktop from SOFTWARE\\TiddlyWiki so changes save).
Other doors: 2 - SEARCH EVERYTHING.bat (no browser), 3 - MAKE A SURVIVAL GUIDE.bat, 4 - COPY TO ANOTHER DRIVE.bat.
If a page looks blank, you opened it from the drive without starting it: run option 1 first.
""",
"MAC": """OFFGRID on a Mac
================
1. Plug the drive in (it must be exFAT; a Mac can't write to NTFS but can read it).
2. Open Terminal, type  sh  and a space, drag  start-mac.command  from this folder into the window, press Enter.
   (Or double-click start-mac.command; if macOS blocks it: right-click > Open.)
3. The first time it may ask to install Python (free, from python.org). Say yes, then run it again.
4. The Command Center opens in your browser. Archives open in the Kiwix app (apps are in www/phone-apps/mac if present).
""",
"LINUX": """OFFGRID on Linux
================
1. Plug the drive in and open a terminal in the OFFGRID folder.
2. Run:  sh PLATFORMS/LINUX/start-linux.sh
3. Needs python3 (already on most systems). The Command Center opens in your browser.
4. Archives: install kiwix-desktop (apt install kiwix-desktop) or open .zim files from kiwix/zim.
""",
"IPHONE": """OFFGRID on iPhone / iPad
========================
iPhones cannot run a local server, so the pages that need one (search, maps) only work by joining a laptop's Wi-Fi.
What works on the phone alone:
 - Plug the drive in (USB-C on iPhone 15+, adapter on older). It must be exFAT.
 - Files app > the drive > open PDFs, checklists and the TEXT-ONLY folder.
 - Install BEFORE you go off-grid: Kiwix (Wikipedia and medical archives, add .zim files from kiwix/zim), OsmAnd or
   Organic Maps (maps), VLC (video), Meshtastic (radio text), iTAK (team map), Stellarium Mobile (stars).
 - Everything with search: use a laptop running the drive, join its Wi-Fi or hotspot and open the address it shows in Safari.
""",
}


def _page(title, text):
    return ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>" +
            html.escape(title) + "</title><style>body{font:17px/1.55 system-ui,sans-serif;max-width:46rem;margin:1rem auto;padding:0 1rem;"
            "background:#f6f4ee;color:#1b1b1b}pre{white-space:pre-wrap;background:#fff;border:1px solid #ccc;border-radius:8px;padding:1rem}"
            "a{color:#1a5fb4}</style><h1>" + html.escape(title) + "</h1><pre>" + html.escape(text) + "</pre><p><a href='index.html'>All platforms</a> &middot; "
            "<a href='../command.html'>Command Center</a></p>")


START_MAC = """#!/bin/sh
cd "$(dirname "$0")/../.." || exit 1
exec sh ./start-here-mac-linux.sh
"""
START_LINUX = START_MAC
START_WIN = '@echo off\r\ncall "%~dp0..\\..\\START-HERE.bat"\r\n'


def build(u, dest):
    """Write PLATFORMS\\ and www\\platforms\\ (cheap; the builder runs it every time)."""
    root = os.path.join(dest, "PLATFORMS")
    web = os.path.join(dest, "www", "platforms")
    os.makedirs(web, exist_ok=True)
    scripts = {"WINDOWS": ("start-windows.bat", START_WIN), "MAC": ("start-mac.command", START_MAC), "LINUX": ("start-linux.sh", START_LINUX)}
    for dev, text in README.items():
        d = os.path.join(root, dev)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "README.txt"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        if dev in scripts:
            n, body = scripts[dev]
            with open(os.path.join(d, n), "w", encoding="utf-8", newline="" if n.endswith(".bat") else "\n") as fh:
                fh.write(body)
        with open(os.path.join(web, dev.lower() + ".html"), "w", encoding="utf-8") as fh:
            fh.write(_page("OFFGRID on " + dev.title(), text))
    try:
        import android_pack
        android_pack.build(u, dest)
        a = os.path.join(root, "ANDROID", "START-HERE-ANDROID.html")
        if os.path.isfile(a):
            shutil.copy2(a, os.path.join(web, "android.html"))
            os.makedirs(os.path.join(web, "ANDROID"), exist_ok=True)
        t = os.path.join(root, "ANDROID", "START-HERE-ANDROID.txt")
        if os.path.isfile(t):
            with open(t, encoding="utf-8") as fh:
                txt = fh.read()
            with open(os.path.join(web, "android.html"), "w", encoding="utf-8") as fh:
                fh.write(_page("OFFGRID on Android", txt))
    except Exception as e:  # noqa: BLE001
        print(f"  ! Android pack: {type(e).__name__}: {e}")
    rows = "".join(f"<li><a href='{d.lower()}.html'><b>{d.title()}</b></a></li>" for d in README) + "<li><a href='android.html'><b>Android</b></a></li>"
    overview = ("PLATFORMS - one folder per device\n\nWINDOWS, MAC, LINUX, IPHONE, ANDROID: instructions and the start script for each.\n"
                "TRAVEL\\<DEVICE>-GO\\OFFGRID: a ready-made drive for that device. Copy the OFFGRID folder in it to the go drive.\n"
                "Build the TRAVEL folders with PROGRAMS\\MAKE-TRAVEL-FOLDERS.bat.\n")
    with open(os.path.join(root, "README.txt"), "w", encoding="utf-8") as fh:
        fh.write(overview)
    with open(os.path.join(web, "index.html"), "w", encoding="utf-8") as fh:
        fh.write("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>Platforms</title>"
                 "<style>body{font:18px/1.7 system-ui,sans-serif;max-width:40rem;margin:1rem auto;padding:0 1rem}</style>"
                 "<h1>Which device?</h1><ul>" + rows + "</ul><p>Travel copies: build them with <b>PROGRAMS\\MAKE-TRAVEL-FOLDERS.bat</b>, "
                 "then copy <code>TRAVEL\\&lt;DEVICE&gt;-GO\\OFFGRID</code> to the go drive.</p><p><a href='../command.html'>Command Center</a></p>")
    print("  Platforms: PLATFORMS\\ written")


# ---------------------------------------------------------------- travel folders
def _size(path):
    if os.path.isfile(path):
        return os.path.getsize(path)
    n = 0
    for r, _, fs in os.walk(path):
        for f in fs:
            try:
                n += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return n


_FILES = {}
_SIZES = {}


def _fsize(path):
    n = _SIZES.get(path)
    if n is None:
        try:
            n = os.path.getsize(path)
        except OSError:
            n = 0
        _SIZES[path] = n
    return n


def _files(root, rel):
    """Every file under dest/rel as relative paths ('/' separators)."""
    key = (root, rel)
    if key in _FILES:
        return _FILES[key]
    full = os.path.join(root, *rel.split("/"))
    if os.path.isfile(full):
        out = [rel]
    else:
        out = []
        for r, dirs, fs in os.walk(full):
            dirs[:] = [d for d in dirs if d not in ("__pycache__", "System Volume Information", "$RECYCLE.BIN")]
            rr = os.path.relpath(r, root).replace(os.sep, "/")
            out += [rr + "/" + f for f in fs if not f.endswith(".part")]
    _FILES[key] = out
    return out


def _total(dest, files):
    return sum(_fsize(os.path.join(dest, *f.split("/"))) for f in files)


_COLLECT = {}


def _collect(dest, dev):
    """-> (core files, core bytes, [(label, files, bytes)] in priority order). dev is a device or 'all'."""
    if (dest, dev) in _COLLECT:
        return _COLLECT[(dest, dev)]
    allp = dev == "all"
    try:
        import copy_drive
        skip = [] if allp else list(copy_drive.DEVICE_SKIP.get(dev, []))
    except Exception:  # noqa: BLE001
        skip = []
    skip += ["TRAVEL", "REPORTS", "kiwix/dl", "tools/dl", "OSM-MAP-SOURCE", "tools/planetiler-sources"]
    if not allp:
        skip += ["PLATFORMS/" + o.upper() for o in DEVICES if o != dev]
    exe_skip = [] if allp else {"windows": [], "mac": ["*.exe", "*.bat"], "linux": ["*.exe", "*.bat"], "android": ["*.exe", "*.bat"], "iphone": ["*.exe", "*.bat", "*.apk"]}[dev]
    if dev == "android":
        skip += ["www/phone-apps/ios"]
    elif dev != "all":
        skip.append("www/phone-apps/android")

    def gone(rel):
        return any(rel == q or rel.startswith(q + "/") or fnmatch.fnmatch(rel, q) for q in skip) or \
            any(fnmatch.fnmatch(os.path.basename(rel), q) for q in exe_skip)

    top = [e for e in sorted(os.listdir(dest)) if e not in ("TRAVEL", "$RECYCLE.BIN", "System Volume Information")]
    heavy_www = {"tiles", "topo", "media", "music", "library", "phone-apps", "guides"}
    core = []
    for e in top:
        p = os.path.join(dest, e)
        if e == "www":
            for sub in sorted(os.listdir(p)):
                if sub not in heavy_www:
                    core += _files(dest, "www/" + sub)
            continue
        if e == "tools":
            for sub in sorted(os.listdir(p)):
                if sub == "python-win" and dev not in ("windows", "all"):
                    continue
                if sub == "builder" and dev == "iphone":
                    continue
                if sub in ("python-win", "builder", "pylib") or os.path.isfile(os.path.join(p, sub)):
                    core += _files(dest, "tools/" + sub)
            continue
        if e in ("kiwix", "ai", "SOFTWARE"):
            continue
        if e in ("PLATFORMS", "PROGRAMS", "TEXT-ONLY", "READ-ME-FIRST.html", "DASHBOARD.html", "TOP 20 SITUATIONS", "PRINTABLE MAPS", "USE-ON-PHONE.html",
                 "HOW-TO-USE-THIS-DRIVE.txt", "START-HERE.bat", "start-here-mac-linux.sh") or os.path.isfile(p):
            core += _files(dest, e)
    core = list(dict.fromkeys(c for c in core if not gone(c)))

    def kz(pattern):
        z = os.path.join(dest, "kiwix", "zim")
        out = []
        if os.path.isdir(z):
            for r, _, fs in os.walk(z):
                for f in fs:
                    if f.lower().endswith(".zim") and fnmatch.fnmatch(f.lower(), pattern):
                        out.append(os.path.relpath(os.path.join(r, f), dest).replace(os.sep, "/"))
        return sorted(out)

    paths_groups = [("Guides, manuals and e-books", ["www/library", "www/guides"])]
    med = []
    for pat in ("*wikem*", "*mdwiki*", "*medical*", "*ifixit*", "*wikihow*", "*appropedia*", "*medicine*"):
        med += kz(pat)
    med = sorted(set(med), key=lambda r: _fsize(os.path.join(dest, *r.split("/"))))
    paths_groups.append(("Medical and how-to archives", med))
    paths_groups.append(("Offline maps (tiles)", ["www/tiles"]))
    paths_groups.append(("Phone apps", ["www/phone-apps"]))
    paths_groups.append(("Topographic maps", ["www/topo"]))
    seen = set(med)
    for z in sorted((z for z in kz("*") if z not in seen), key=lambda r: _fsize(os.path.join(dest, *r.split("/")))):
        paths_groups.append(("Archive: " + os.path.basename(z), [z]))
    models = []
    am = os.path.join(dest, "ai", "models")
    if os.path.isdir(am):
        small = sorted((f for f in os.listdir(am) if f.lower().endswith(".gguf")), key=lambda f: os.path.getsize(os.path.join(am, f)))
        if small:
            models.append("ai/models/" + small[0])
        if os.path.isfile(os.path.join(dest, "ai", "default-model.txt")):
            models.append("ai/default-model.txt")
        if os.path.isfile(os.path.join(dest, "ai", "roles.json")):
            models.append("ai/roles.json")
    if dev != "iphone" and models:
        paths_groups.append(("Small offline AI model", models))
    paths_groups.append(("Music", ["www/music"]))
    paths_groups.append(("Movies and TV", ["www/media"]))
    groups = []
    for label, paths in paths_groups:
        fl = []
        for q in paths:
            if os.path.exists(os.path.join(dest, *q.split("/"))):
                fl += [f for f in _files(dest, q) if not gone(f)]
        fl = list(dict.fromkeys(fl))
        if fl:
            groups.append((label, fl, _total(dest, fl)))
    res = (core, _total(dest, core), groups)
    _COLLECT[(dest, dev)] = res
    return res


def _pick(col, budget):
    core, core_bytes, groups = col
    cap = budget * 1e9
    files, used = list(core), core_bytes
    chosen, skipped = [], []
    for label, fl, n in groups:
        if used + n <= cap:
            files += fl
            used += n
            chosen.append((label, n))
        else:
            skipped.append((label, n))
    return list(dict.fromkeys(files)), chosen, skipped, used, core_bytes


def plan(dest, dev, budget):
    """Pick what goes on the go drive: core first, then optional groups in priority order until the budget is used."""
    return _pick(_collect(dest, dev), budget)


def _rmtree(p):
    def bad(fn, path, exc):
        try:
            os.chmod(path, 0o666)
            fn(path)
        except OSError:
            pass
    shutil.rmtree(p, onerror=bad)


def _clamp(budget):
    return max(1.0, min(float(budget), float(MAX_GB)))


def _read_state(dest):
    try:
        with open(os.path.join(dest, "TRAVEL", STATE), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _write_state(dest, kind, budget):
    st = _read_state(dest)
    st[kind] = budget
    os.makedirs(os.path.join(dest, "TRAVEL"), exist_ok=True)
    with open(os.path.join(dest, "TRAVEL", STATE), "w", encoding="utf-8") as fh:
        json.dump(st, fh, indent=1)


def _go_extras(out, dest, kind, budget):
    """Files that make the go drive self-sufficient: what it is, how to update it, which device to start from."""
    with open(os.path.join(out, "GO-DRIVE.json"), "w", encoding="utf-8") as fh:
        json.dump({"device": kind, "budget_gb": budget, "built": time.strftime("%Y-%m-%d"), "from": os.path.abspath(dest)}, fh, indent=1)
    src = os.path.join(HERE, "go_update.py")
    if os.path.isfile(src):
        os.makedirs(os.path.join(out, "PROGRAMS"), exist_ok=True)
        shutil.copy2(src, os.path.join(out, "PROGRAMS", "go_update.py"))
    with open(os.path.join(out, "UPDATE-GO-DRIVE.bat"), "w", encoding="utf-8", newline="") as fh:
        fh.write(GO_UPDATE_BAT)
    with open(os.path.join(out, "update-go-drive.sh"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(GO_UPDATE_SH)
    with open(os.path.join(out, "HOW-TO-UPDATE-THIS-DRIVE.txt"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(GO_UPDATE_TXT)
    if kind == "all":
        with open(os.path.join(out, "START-HERE-WHICH-DEVICE.html"), "w", encoding="utf-8") as fh:
            fh.write(WHICH_DEVICE)


def travel(dest, dev, budget=None, link=True):
    budget = _clamp(budget or BUDGET[dev])
    label = "ALL-DEVICES" if dev == "all" else dev.upper()
    out_root = os.path.join(dest, "TRAVEL", label + "-GO")
    out = os.path.join(out_root, "OFFGRID")
    print(f"\n  {label}-GO: choosing files for a {budget:g} GB go drive ...")
    files, chosen, skipped, used, core = plan(dest, dev, budget)
    if os.path.isdir(out):
        _rmtree(out)
    os.makedirs(out, exist_ok=True)
    mode, bad = ("link" if link else "copy"), 0
    linked = copied = 0
    for i, rel in enumerate(files, 1):
        src, dst = os.path.join(dest, *rel.split("/")), os.path.join(out, *rel.split("/"))
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if mode == "link" and _fsize(src) >= SMALL:
                try:
                    os.link(src, dst)
                    linked += 1
                    continue
                except OSError:
                    mode = "list"          # this drive can't make hard links (exFAT, network share)
            if mode == "list":
                break
            shutil.copy2(src, dst)
            copied += 1
        except OSError:
            bad += 1
        if i % 500 == 0:
            print(f"\r    {i:,} / {len(files):,}", end="", flush=True)
    if mode == "list":
        _rmtree(out)
        os.makedirs(out_root, exist_ok=True)
        with open(os.path.join(out_root, "COPY-LIST.txt"), "w", encoding="utf-8") as fh:
            fh.write("\n".join(files) + "\n")
        note = ("This drive cannot make hard links (it is exFAT or a network share), so no files were duplicated.\n"
                "Use PROGRAMS\\COPY-TO-ANOTHER-DRIVE and pick the device; COPY-LIST.txt shows what this plan would copy.\n")
    else:
        _go_extras(out, dest, dev, budget)
        note = ("HOW TO USE: copy the OFFGRID folder in this folder to the root of the go drive (copy and paste or drag and drop).\n"
                f"{linked:,} large files are links to the master drive (no extra space); {copied:,} small files are real copies.\n"
                "Do not edit files in here: a linked file is the same file as the master. Deleting is safe.\n"
                "Rebuilt automatically when the master drive is updated; copy it to the go drive again afterwards,\n"
                "or run UPDATE-GO-DRIVE on the go drive (see HOW-TO-UPDATE-THIS-DRIVE.txt).\n")
    fmt = ("exFAT. Works on Windows, Mac, Linux and Android phones; iPhone can read the files but cannot run the pages that need a server."
           if dev == "all" else
           ("exFAT" if dev in ("android", "iphone", "mac") else "exFAT (or NTFS for Windows only)"))
    lines = [f"OFFGRID go drive for {'EVERY DEVICE' if dev == 'all' else dev.upper()}", "=" * 40,
             f"Size: about {used / 1e9:,.1f} GB (budget {budget:g} GB)", "", note,
             "Included:", f"  Core (guides pages, scripts, instructions): {core / 1e9:,.1f} GB"]
    lines += [f"  {l}: {n / 1e9:,.1f} GB" for l, n in chosen]
    if skipped:
        lines += ["", "Left out (did not fit; build again with a bigger size to add them):"] + [f"  {l}: {n / 1e9:,.1f} GB" for l, n in skipped[:25]]
    lines += ["", f"Format the go drive as: {fmt}",
              ("After copying, open START-HERE-WHICH-DEVICE.html on the go drive." if dev == "all" else
               "After copying, open PLATFORMS\\" + dev.upper() + "\\README.txt on the go drive.")]
    os.makedirs(out_root, exist_ok=True)
    with open(os.path.join(out_root, "READ-ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    _write_state(dest, dev, budget)
    print(f"\n    {label}-GO: {len(files):,} files, about {used / 1e9:,.1f} GB ({linked:,} linked, {copied:,} copied" +
          (f", {bad} failed" if bad else "") + f") -> {out_root}")
    return out_root


def refresh(u, dest):
    """Called at the end of every builder run (including UPDATE-DRIVE): rebuild the travel folders that were made before,
    at the same sizes, so they always match the master drive. Does nothing if no travel folders were ever made."""
    st = _read_state(dest)
    if not st:
        return
    print("  Rebuilding the travel (go-drive) folders to match the updated drive ...")
    for kind, gb in st.items():
        if kind in KINDS:
            try:
                travel(dest, kind, gb)
            except Exception as e:  # noqa: BLE001
                print(f"  ! {kind}-GO: {type(e).__name__}: {e}")
    guide(dest)


def guide(dest):
    """TRAVEL\\BUDGET-GUIDE.txt/.html and www/platforms/go-drive.html: what fits on 32 GB ... 2 TB, per device."""
    kinds = list(KINDS)
    L = ["GO-DRIVE SIZE GUIDE", "=" * 40,
         "What fits on a go drive of each size, worked out from what is on THIS drive today.",
         "'Core' (pages, search, scripts, instructions) is always included. Everything else is added in the order below",
         "until the drive is full, so a small drive gets the most useful things first.", ""]
    names = {"windows": "Windows", "mac": "Mac", "linux": "Linux", "iphone": "iPhone", "android": "Android", "all": "All devices"}
    for k in kinds:
        col = _collect(dest, k)
        L += [f"{names[k]}", "-" * len(names[k]), f"  Core: {col[1] / 1e9:,.1f} GB (always included)",
              "  Order things are added (and the reverse is what to drop first):"]
        for i, (lab, fl, n) in enumerate(col[2], 1):
            if i <= 12 or not lab.startswith("Archive:"):
                L.append(f"    {i:2d}. {lab}: {n / 1e9:,.1f} GB")
        if sum(1 for g in col[2] if g[0].startswith("Archive:")) > 8:
            L.append("        (and more archives, smallest first)")
        total = col[1] + sum(g[2] for g in col[2])
        L.append(f"  Everything for this device: {total / 1e9:,.1f} GB")
        L.append("  By drive size:")
        for gb in SIZES:
            f, ch, sk, used, _ = _pick(col, gb)
            tag = f"{gb // 1000} TB" if gb >= 1000 else f"{gb} GB"
            gb_used = used / 1e9
            if used > gb * 1e9:
                L.append(f"    {tag:>6}: too small, core alone is {gb_used:,.1f} GB")
            else:
                first = sk[0][0] if sk else "nothing - everything fits"
                L.append(f"    {tag:>6}: uses {gb_used:,.0f} GB; first thing left out: {first}")
        L.append("")
    L += ["Drive formats: Android and iPhone need exFAT. Windows can use NTFS. For a drive that must work on every device, use exFAT.",
          "Go drive up to 2 TB: type 2000 when MAKE-TRAVEL-FOLDERS asks for the size.", ""]
    text = "\n".join(L)
    os.makedirs(os.path.join(dest, "TRAVEL"), exist_ok=True)
    with open(os.path.join(dest, "TRAVEL", "BUDGET-GUIDE.txt"), "w", encoding="utf-8") as fh:
        fh.write(text)
    with open(os.path.join(dest, "TRAVEL", "BUDGET-GUIDE.html"), "w", encoding="utf-8") as fh:
        fh.write(_page("Go-drive size guide", text))
    pd = os.path.join(dest, "www", "platforms")
    if os.path.isdir(pd):
        with open(os.path.join(pd, "go-drive.html"), "w", encoding="utf-8") as fh:
            fh.write(_page("Go-drive size guide", text))
    print("  Size guide: TRAVEL\\BUDGET-GUIDE.html")


GO_UPDATE_BAT = (
    '@echo off\r\ncd /d "%~dp0"\r\n'
    'echo OFFGRID go drive update. Nothing on this drive is ever deleted.\r\necho.\r\n'
    'set PY=python\r\nif exist "tools\\python-win\\python.exe" set PY=tools\\python-win\\python.exe\r\n'
    '%PY% PROGRAMS\\go_update.py --drive "%~dp0." %*\r\npause\r\n')
GO_UPDATE_SH = (
    '#!/bin/sh\n# OFFGRID go drive update (Mac / Linux / Termux). Nothing on this drive is ever deleted.\n'
    'cd "$(dirname "$0")" || exit 1\n'
    'PY=python3; command -v python3 >/dev/null 2>&1 || PY=python\n'
    'exec "$PY" PROGRAMS/go_update.py --drive "$(pwd)" "$@"\n')
GO_UPDATE_TXT = """HOW TO UPDATE THIS GO DRIVE
===========================
Nothing is ever deleted by an update. It only adds new files and replaces files that have a newer version.

WAY 1 - FROM YOUR MAIN OFFGRID DRIVE (no internet needed)
  1. Plug in this go drive and the main OFFGRID drive on the same computer (Windows, Mac or Linux).
  2. Windows: double-click UPDATE-GO-DRIVE.bat on this drive.   Mac/Linux: sh update-go-drive.sh
  3. When asked, type the path of the main drive's OFFGRID folder (example E:\\OFFGRID or /Volumes/MAIN/OFFGRID).
  4. It copies what changed, in the same priority order as the size guide, and stops before the go drive is full.
  Or, on the main drive, run MAKE-TRAVEL-FOLDERS again (it also rebuilds by itself after UPDATE-DRIVE) and copy over the new folder.

WAY 2 - ONLINE (any computer with internet, only if this drive carries the builder: every go drive except iPhone does)
  1. Plug this go drive into a computer with internet.
  2. Run UPDATE-GO-DRIVE and choose the online option (or add the word online:  update-go-drive.sh --online).
  3. It refreshes guides, manuals, indexes and pages only. It does NOT download maps, archives or movies,
     so the drive never grows past its size. For those use WAY 1.

A phone cannot run the update. Use a computer, or Termux (python is needed).
"""

WHICH_DEVICE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OFFGRID - which device?</title>
<style>body{margin:0;background:#101417;color:#e6e8eb;font:18px/1.5 system-ui,sans-serif}main{max-width:720px;margin:0 auto;padding:16px}h1{font-size:26px}
a.b{display:block;background:#1a2025;border:2px solid #3a424b;border-radius:12px;padding:16px;margin:12px 0;color:#8bb8ff;text-decoration:none;font-weight:700}a.b span{display:block;font-weight:400;color:#c6ced6;font-size:16px;margin-top:4px}
.small{font-size:15px;color:#9aa6b2}</style></head><body><main>
<h1>OFFGRID - what are you using?</h1>
<p class="small">Tap your device. Each page tells you step by step how to start. If a page is blank, open the instructions (.txt) instead.</p>
<a class="b" href="PLATFORMS/WINDOWS/README.txt">Windows computer<span>Open the OFFGRID folder, double-click START-HERE.bat, press 1.</span></a>
<a class="b" href="PLATFORMS/MAC/README.txt">Mac<span>Run start-mac.command from PLATFORMS/MAC.</span></a>
<a class="b" href="PLATFORMS/LINUX/README.txt">Linux<span>Run: sh PLATFORMS/LINUX/start-linux.sh</span></a>
<a class="b" href="PLATFORMS/ANDROID/START-HERE-ANDROID.html">Android phone or tablet<span>Install the OFFGRID app or use Termux; plain steps inside.</span></a>
<a class="b" href="PLATFORMS/IPHONE/README.txt">iPhone / iPad<span>Files app plus Kiwix, OsmAnd and VLC. Full pages need a laptop on the same Wi-Fi.</span></a>
<a class="b" href="TEXT-ONLY/">No computer or phone works?<span>The TEXT-ONLY folder has the key guides as plain files that open on anything.</span></a>
<a class="b" href="www/command.html">Already running the drive? Open the Command Center</a>
<p class="small">Keep this drive formatted exFAT. To add newer files later run UPDATE-GO-DRIVE (see HOW-TO-UPDATE-THIS-DRIVE.txt).</p>
</main></body></html>
"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--travel", action="store_true", help="build the TRAVEL\\*-GO folders")
    ap.add_argument("--device", choices=KINDS, help="only this device ('all' = one drive that works on every device)")
    ap.add_argument("--budget-gb", type=float, help=f"size of the go drive, 1 to {MAX_GB} GB")
    ap.add_argument("--copy", action="store_true", help="make real copies instead of links")
    ap.add_argument("--refresh", action="store_true", help="rebuild every travel folder made before, at the same size")
    ap.add_argument("--guide", action="store_true", help="write the go-drive size guide only")
    a = ap.parse_args()
    dest = os.path.abspath(a.dest)
    build(None, dest)
    if a.refresh:
        refresh(None, dest)
    elif a.travel:
        for d in ([a.device] if a.device else list(DEVICES) + ["all"]):
            travel(dest, d, a.budget_gb, link=not a.copy)
        guide(dest)
    elif a.guide:
        guide(dest)


if __name__ == "__main__":
    main()
