@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM Opens the Kiwix archives (Wikipedia, WikEM, MDWiki, iFixit, Stack Exchange...) in the portable
REM Kiwix reader - no web server, no AI, no install. Use File > Open file and pick a .zim in kiwix\zim.
cd /d "%~dp0"
if exist kiwix\desktop\windows\kiwix-desktop.exe (
  start "" kiwix\desktop\windows\kiwix-desktop.exe
  echo  Kiwix opened. In Kiwix: File ^> Open file ^> %~dp0kiwix\zim
) else (
  echo  The portable Kiwix reader isn't on this drive yet - re-run the builder.
)
timeout /t 8 >nul
