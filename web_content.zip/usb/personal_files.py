"""My Personal Files inbox: sorts private family papers into PERSONAL\\ — and keeps them PRIVATE.

Drop files (folders are fine) into  MY-PERSONAL-FILES-INBOX  on the drive, then run the builder / START-HERE.
Each file is MOVED (after the copy is verified) into  PERSONAL\\<category>\\  by its file and folder name.

Unlike MY-FILES-INBOX (library, which is searchable), personal files are never:
  * put in www\\ (so the Command Center, the web server and phone access never show them),
  * read, OCR'd or text-indexed, put in TEXT-ONLY, or given to the AI,
  * copied into OPEN-WITH or the builder reports (only file NAMES appear in PERSONAL\\CHECKLIST.txt).
For real protection, put the PERSONAL folder inside the encrypted family-vault.hc (VeraCrypt) or use BitLocker.

Files named with an expiry, e.g.  Passport exp 2031-05.pdf  or  License-exp-2029-11-03.jpg, are listed in
PERSONAL\\EXPIRING.txt (soonest first) so renewals are not missed.
"""
import datetime, hashlib, os, re, shutil

INBOX = "MY-PERSONAL-FILES-INBOX"
OUT = "PERSONAL"
# (folder, regex on file+folder name, what a complete set should include -> keywords)
CATS = [
    ("Identity", r"passport|driver|licen[sc]e|birth.?cert|social.?sec|ssn|id.?card|green.?card|marriage.?cert|death.?cert|citizenship|dd.?214|military.?id|\bid\b"),
    ("Medical", r"medical|health|vaccin|immuniz|prescri|medication|allerg|blood|dental|doctor|hospital|lab.?result|xray|x-ray|mri|shot.?record"),
    ("Insurance", r"insur|policy|geico|state.?farm|allstate|progressive|usaa|tricare|medicare|medicaid|claim"),
    ("Financial & Tax", r"tax|1040|w-?2|1099|bank|statement|account|retire|401k|ira\b|pension|invest|loan|credit|budget|brokerage|crypto|wallet"),
    ("Home & Property", r"deed|mortgage|title|hoa|closing|survey|plat|appraisal|warranty|lease|rent|home|house|property|utility|permit"),
    ("Vehicles", r"vehicle|car\b|truck|registration|vin\b|auto|boat|trailer|\bmotorcycle|title.*(car|truck)"),
    ("Legal", r"will\b|trust|power.?of.?attorney|poa\b|directive|living.?will|custody|divorce|court|contract|notar|beneficiar|guardian"),
    ("Military & Employment", r"military|va\b|dd.?214|orders|fitrep|evaluation|resume|employ|offer.?letter|payroll|pay.?stub|benefit"),
    ("Education", r"transcript|diploma|degree|school|college|university|certif|training|\bgpa\b|report.?card|iep"),
    ("Family Photos & Records", r"photo|picture|family|genealog|ancestry|album|\.jpe?g$|\.heic$|\.png$|\.cr2$"),
    ("Pets", r"\bpet|\bdog|\bcat\b|vet\b|rabies|kennel|microchip"),
    ("Emergency Contacts & Plans", r"contact|emergency|evacuat|plan|phone.?list|address.?book|meeting.?point|rally"),
]
# a complete set of papers — what to look for by keyword in the file names found in PERSONAL
ESSENTIALS = [
    ("Passport (each person)", r"passport"), ("Driver's license / state ID", r"licen[sc]e|state.?id|\bid.?card"),
    ("Birth certificates", r"birth"), ("Marriage certificate", r"marriage"), ("Social Security cards", r"social|ssn"),
    ("Health insurance card/policy", r"health.*insur|insur.*health|medical.*insur|tricare|medicare"),
    ("Home or auto insurance policy", r"home.*insur|auto.*insur|policy|homeowner"),
    ("Vaccination / medical records", r"vaccin|immuniz|medical|shot"), ("Medication & allergy list", r"medication|prescri|allerg"),
    ("Will / power of attorney / directive", r"will\b|power.?of.?attorney|poa\b|directive"),
    ("Deed / mortgage / title", r"deed|mortgage|title"), ("Vehicle titles & registrations", r"vehicle|registration|title"),
    ("Recent tax returns", r"tax|1040"), ("Bank / account list (no passwords!)", r"bank|account"),
    ("DD-214 / military records", r"dd.?214|military"), ("Family photos (ID photos of kids)", r"photo|picture"),
    ("Emergency contact list", r"contact|emergency"),
]
EXP = re.compile(r"exp(?:ires?|iry|ired)?[ _\-.]*((?:19|20)\d\d)[-_. ]?(\d\d)?[-_. ]?(\d\d)?", re.I)
SKIP = ("README.txt", "desktop.ini", "Thumbs.db", ".DS_Store")


def category(rel):
    name = rel.lower().replace("\\", "/")
    for cat, rx in CATS:
        if re.search(rx, name):
            return cat
    return "Other"


def _sha(p):
    h = hashlib.sha1()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _unique(path):
    if not os.path.exists(path):
        return path
    b, e = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{b} ({n}){e}"):
        n += 1
    return f"{b} ({n}){e}"


def expiry(name):
    m = EXP.search(name)
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2) or 12), int(m.group(3) or 0)
    try:
        if d:
            return datetime.date(y, mo, d)
        nxt = datetime.date(y + (mo == 12), mo % 12 + 1, 1)      # month only: expires at month end
        return nxt - datetime.timedelta(days=1)
    except ValueError:
        return None


def build(u, dest):
    inbox, out = os.path.join(dest, INBOX), os.path.join(dest, OUT)
    os.makedirs(inbox, exist_ok=True)
    rd = os.path.join(inbox, "README.txt")
    if not os.path.exists(rd):
        with open(rd, "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("PRIVATE family papers go here: IDs, passports, medical and insurance records, deeds, wills, tax returns,\n"
                     "vehicle titles, family photos. Folders are fine. Then run START-HERE.bat (or the builder).\n\n"
                     "Each file is MOVED into the PERSONAL folder, sorted by its name (Identity, Medical, Insurance, Financial & Tax,\n"
                     "Home & Property, Vehicles, Legal, Military & Employment, Education, Family Photos & Records, Pets,\n"
                     "Emergency Contacts & Plans, Other). Name files so they sort well: 'Passport - Name exp 2031-05.pdf'.\n\n"
                     "PRIVATE: these files are never put in the Library, the search index, the AI, the Command Center or the\n"
                     "phone/web server, and are never read - only moved. Put the PERSONAL folder inside your encrypted\n"
                     "family-vault.hc (VeraCrypt) or turn on BitLocker for the drive. Do NOT store passwords in plain files;\n"
                     "use the KeePassXC password manager that is on the drive.\n"
                     "Nothing is deleted until its copy is verified; a file that can't be moved stays here.\n")
    moved = dup = left = 0
    seen = {}
    if os.path.isdir(out):                      # hashes of what is already filed, to skip exact duplicates (same size first)
        for r, _, fs in os.walk(out):
            for f in fs:
                p = os.path.join(r, f)
                seen.setdefault(os.path.getsize(p), []).append(p)
    hashes = {}
    for root, dirs, files in os.walk(inbox):
        for f in files:
            if f in SKIP or f.startswith(("~$", ".")):
                continue
            src = os.path.join(root, f)
            rel = os.path.relpath(src, inbox)
            cat = category(rel)
            dst_dir = os.path.join(out, cat)
            sz = os.path.getsize(src)
            try:
                if sz in seen:
                    me = _sha(src)
                    if any(hashes.setdefault(p, _sha(p)) == me for p in seen[sz]):
                        os.remove(src)
                        dup += 1
                        continue
                os.makedirs(dst_dir, exist_ok=True)
                dst = _unique(os.path.join(dst_dir, f))
                shutil.copy2(src, dst)
                if os.path.getsize(dst) != sz or _sha(dst) != _sha(src):
                    os.remove(dst)
                    left += 1
                    continue
                os.remove(src)
                seen.setdefault(sz, []).append(dst)
                moved += 1
            except OSError as e:
                print(f"  ! personal file {f}: {e}")
                left += 1
    for root, dirs, files in os.walk(inbox, topdown=False):      # tidy empty sub-folders (never the inbox itself)
        if root != inbox and not os.listdir(root):
            try:
                os.rmdir(root)
            except OSError:
                pass
    if moved or dup or left:
        u.say(f"Personal files: {moved} filed in PERSONAL\\, {dup} exact duplicates removed" + (f", {left} left in the inbox (see above)" if left else ""))
    report(dest)


def inventory(dest):
    """{category: [file names]} for what is in PERSONAL (names only — contents are never read)."""
    out, inv = os.path.join(dest, OUT), {}
    if os.path.isdir(out):
        for r, _, fs in os.walk(out):
            for f in fs:
                if f in ("CHECKLIST.txt", "EXPIRING.txt", "README.txt"):
                    continue
                inv.setdefault(os.path.relpath(r, out).split(os.sep)[0], []).append(f)
    return inv


def report(dest):
    out = os.path.join(dest, OUT)
    inv = inventory(dest)
    if not inv:
        return
    names = " | ".join(f.lower() for v in inv.values() for f in v)
    today = datetime.date.today()
    lines = ["PERSONAL DOCUMENTS - CHECKLIST (regenerated every builder run; reads file NAMES only)", ""]
    for label, rx in ESSENTIALS:
        lines.append(("  [x] " if re.search(rx, names) else "  [ ] ") + label)
    lines += ["", "Looks missing is a guess from file names - rename files (e.g. 'Birth certificate - Dominic.pdf') so they match.", "",
              "Counts: " + ", ".join(f"{k} {len(v)}" for k, v in sorted(inv.items()))]
    with open(os.path.join(out, "CHECKLIST.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("\n".join(lines) + "\n")
    exp = []
    for cat, fs in inv.items():
        for f in fs:
            d = expiry(f)
            if d:
                exp.append((d, cat, f))
    ep = os.path.join(out, "EXPIRING.txt")
    if exp:
        exp.sort()
        with open(ep, "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("DOCUMENTS WITH AN EXPIRY DATE IN THEIR NAME (soonest first)\n\n")
            for d, cat, f in exp:
                days = (d - today).days
                tag = "EXPIRED" if days < 0 else f"{days} days" + ("  <-- renew soon" if days < 180 else "")
                fh.write(f"  {d}  {tag:<28} {cat}\\{f}\n")
    elif os.path.exists(ep):
        os.remove(ep)


def summary(dest):
    """For the drive checklist: (filed file count, missing essentials, soon-expiring list). Names only."""
    inv = inventory(dest)
    if not inv:
        return 0, None, []
    names = " | ".join(f.lower() for v in inv.values() for f in v)
    missing = [l for l, rx in ESSENTIALS if not re.search(rx, names)]
    soon = []
    for cat, fs in inv.items():
        for f in fs:
            d = expiry(f)
            if d and (d - datetime.date.today()).days < 180:
                soon.append(f"{f} ({d})")
    return sum(len(v) for v in inv.values()), missing, soon


if __name__ == "__main__":
    import argparse, types, sys
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    build(types.SimpleNamespace(say=print), a.dest)
