@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Add your music to this drive (sorted by artist and album, with a player page) =====
REM Step 1 only LOOKS at your songs and shows a plan. Nothing is copied, renamed or deleted until you say so.
cd /d "%~dp0"
title Add music
chcp 65001 >nul
set PYTHONUTF8=1
set "PY=tools\python-win\python.exe"
if not exist "%PY%" set "PY=python"
set "MP=tools\builder\usb\music.py"
echo.
echo  Plug in the drive that has your music.
echo  Type its folder or drive letter, e.g.  F:\Music   or   F:\   (or drag the folder onto this window)
echo  Just press Enter to only rebuild the Music page from what's already on this drive.
echo.
set "SRC="
set /p "SRC=Music folder: "
if not defined SRC goto catalog
set SRC=%SRC:"=%
if "%SRC:~-1%"=="\" set "SRC=%SRC%."
"%PY%" %MP% --dest "%~dp0." --src "%SRC%"
if errorlevel 1 goto end
start "" "REPORTS\MUSIC-PLAN.html"
echo.
echo  The plan is open in your browser. Rows marked "check" have a guessed name: fix them in REPORTS\MUSIC-PLAN.csv
echo  (open it with Excel or Notepad, change the artist/album/year/track/title/kids columns, save) - or leave them.
echo.
echo    C = COPY them onto this drive (your other drive stays as it is)
echo    M = MOVE them (each original is deleted from the other drive after its copy is checked)
echo    N = do nothing now (run this again later; it will re-plan)
echo.
choice /c CMN /n /m "Copy, Move or Nothing? "
if errorlevel 3 goto end
if errorlevel 2 (set "MODE=move") else (set "MODE=copy")
"%PY%" %MP% --dest "%~dp0." --apply %MODE%
:catalog
"%PY%" %MP% --dest "%~dp0." --catalog-only
echo.
echo  Done. Open Home ^> Music (or www\music\index.html). Songs that won't play in the browser (WMA) open in VLC:
echo  tools\vlc\vlc.exe
:end
pause
