"""Find newer survival / preparedness manuals online — for the monthly UPDATE-DRIVE.

Conservative by design. It AUTO-ADDS only documents that carry an explicit public-domain or Creative-Commons
license (safe to keep and redistribute); everything else it merely LISTS in REPORTS/NEW-MANUALS-REVIEW.html
for a human (or Claude) to vet before adding. It never auto-adds copyrighted material, and it dedupes against
the manuals already in library/manuals.tsv.

Source: the Internet Archive full-text search API (archive.org/advancedsearch.php). Only the standard library.
Runs inside UPDATE-DRIVE (monthly). Turn it off with --no-fetch.
"""
import html as _html, json, os, re, time, urllib.parse

QUERIES = [
    "survival manual", "wilderness survival", "emergency preparedness", "disaster preparedness",
    "first aid field manual", "homesteading", "food preservation canning", "water purification",
    "off grid solar power", "field medicine austere", "bushcraft primitive skills",
    "emergency radio communications", "cold weather survival", "shelter building",
]
AUTO_CAP = 15           # at most this many auto-adds per run (keeps a runaway month in check)
PER_QUERY = 30


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _existing_titles(repo):
    titles = set()
    try:
        for line in open(os.path.join(repo, "library", "manuals.tsv"), encoding="utf-8"):
            p = line.rstrip("\n").split("\t")
            if len(p) >= 2 and not p[0].startswith("#"):
                titles.add(_norm(p[1].split("(")[0]))
    except OSError:
        pass
    return titles


def _is_free(lic):
    """True only for an explicit public-domain / Creative-Commons license — safe to keep and redistribute."""
    l = (lic or "").lower()
    return ("creativecommons.org/publicdomain" in l or "/zero/" in l or "/by/" in l
            or "/by-sa/" in l or l.endswith("/mark/1.0/") or "publicdomain" in l)


def search(u):
    docs = []
    for q in QUERIES:
        qs = urllib.parse.urlencode({"q": f"({q}) AND mediatype:texts", "rows": PER_QUERY,
                                     "output": "json", "sort[]": "publicdate desc"}, doseq=True)
        qs += "&fl[]=identifier&fl[]=title&fl[]=year&fl[]=licenseurl&fl[]=publicdate&fl[]=downloads"
        try:
            data = json.loads(u.fetch(f"https://archive.org/advancedsearch.php?{qs}", 60))
            docs += data.get("response", {}).get("docs", [])
        except Exception:  # noqa: BLE001
            continue
    return docs


def build(u, dest):
    u.say("Looking for newer survival / preparedness manuals (archive.org)")
    repo = u.REPO
    existing = _existing_titles(repo)
    seen, auto, review = set(), [], []
    for d in search(u):
        ident, title = d.get("identifier"), d.get("title")
        if not ident or not title or ident in seen:
            continue
        seen.add(ident)
        nt = _norm(str(title).split("(")[0])
        if not nt or len(nt) < 6 or nt in existing:
            continue
        existing.add(nt)                        # also avoid dupes within this run
        rec = {"id": ident, "t": str(title), "y": d.get("year", ""), "lic": d.get("licenseurl"),
               "dl": d.get("downloads", 0)}
        (auto if (_is_free(rec["lic"]) and len(auto) < AUTO_CAP) else review).append(rec)
    if auto:                                    # append the free ones so the manuals step downloads them
        with open(os.path.join(repo, "library", "manuals.tsv"), "a", encoding="utf-8") as fh:
            fh.write(f"\n# ---- auto-added {time.strftime('%Y-%m-%d')} by fetch_new "
                     "(explicit public-domain / Creative-Commons only, from archive.org) ----\n")
            for r in auto:
                fn = (re.sub(r"[^a-z0-9]+", "_", r["t"].lower()).strip("_")[:60] or r["id"]) + ".pdf"
                label = f"{r['t']} ({r['y']})" if r["y"] else r["t"]
                fh.write("\t".join(["New (auto-added)", label, fn, "archive:" + r["id"]]) + "\n")
    rep = os.path.join(dest, "REPORTS")
    os.makedirs(rep, exist_ok=True)
    _write_review(os.path.join(rep, "NEW-MANUALS-REVIEW.html"), auto, review)
    print(f"  auto-added {len(auto)} public-domain/CC manuals; {len(review)} more candidates listed for review"
          f" (REPORTS\\NEW-MANUALS-REVIEW.html)")
    return len(auto), len(review)


def _row(r, added):
    lic = r["lic"] or "—"
    short = lic.replace("http://creativecommons.org/", "CC ").replace("https://creativecommons.org/", "CC ")
    return (f"<tr><td><a href='https://archive.org/details/{_html.escape(r['id'])}' target='_blank'>"
            f"{_html.escape(r['t'])}</a></td><td>{_html.escape(str(r['y']))}</td>"
            f"<td>{_html.escape(short)}</td><td>{r['dl']}</td>"
            f"<td>{'✅ added' if added else 'review'}</td></tr>")


def _write_review(path, auto, review):
    built = time.strftime("%Y-%m-%d")
    rows = "".join(_row(r, True) for r in auto) + "".join(_row(r, False) for r in review)
    page = f"""<!doctype html><meta charset=utf-8><title>New manuals — review</title>
<meta name=viewport content="width=device-width,initial-scale=1">
<style>body{{font:15px/1.5 system-ui,sans-serif;max-width:60rem;margin:1.5rem auto;padding:0 1rem}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #ddd;padding:.4rem .5rem;text-align:left;vertical-align:top}}
th{{background:#f4f2ec}}.box{{background:#f4f2ec;border-left:4px solid #b04a2f;padding:.7rem 1rem;border-radius:4px;margin:1rem 0}}</style>
<h1>New manuals found — {built}</h1>
<div class=box><b>{len(auto)} were auto-added</b> (explicit public-domain / Creative-Commons only; they download on the
next update). <b>{len(review)} more are candidates</b> for review below — open any to check it, then tell Claude
"add &lt;title&gt;" to include it. Nothing in the review list is on your drive yet.</div>
<table><tr><th>Title (opens on archive.org)</th><th>Year</th><th>License</th><th>Downloads</th><th>Status</th></tr>
{rows or '<tr><td colspan=5>Nothing new found this run.</td></tr>'}</table>"""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(page)
