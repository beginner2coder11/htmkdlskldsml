"""Canadian 1:50,000 topographic maps (NRCan CanTopo GeoPDF) for the cross-border travel destinations.

USGS only covers the United States, so Toronto and Québec City — Josh's two Canadian work destinations —
get their topo sheets from Natural Resources Canada instead. NRCan serves print-ready GeoPDFs through an
open HTTP directory, organized by National Topographic System (NTS) sheet:

    https://ftp.maps.canada.ca/pub/nrcan_rncan/raster/topographic/50k/<series>/<letter>/<code>*.pdf

NTS numbering (southern Canada):
  * A 1:250,000 "area" (e.g. 030M) spans 1 deg latitude x 2 deg longitude.
  * It divides into sixteen 1:50,000 blocks of 15' lat x 30' lon, numbered 1..16 in a boustrophedon
    starting at the SOUTHEAST corner: row 0 (south) 1-2-3-4 east->west, row 1 5-6-7-8 west->east,
    row 2 9-10-11-12 east->west, row 3 (north) 13-14-15-16 west->east.
  Example anchors this module is checked against: Toronto = 030M11, Québec City = 021L14.

Only the standard library is used. Downloads go through the builder's own download()/fetch() so they share
its retry, resume and TLS handling.
"""
import os, re, html

FTP50K = "https://ftp.maps.canada.ca/pub/nrcan_rncan/raster/topographic/50k"

# Each Canadian destination metro: the 250k area it sits in (with that area's south edge and east edge),
# and a bounding box (lat_s, lat_n, lon_w, lon_e) to cover. Both metros fit inside a single 250k area.
CA_METROS = {
    "toronto": {"label": "Toronto, ON", "series": "030", "letter": "M",
                "area_lat_s": 43.0, "area_lon_e": -78.0,
                "bbox": (43.45, 43.95, -80.0, -79.0)},
    "quebec":  {"label": "Québec City, QC", "series": "021", "letter": "L",
                "area_lat_s": 46.0, "area_lon_e": -70.0,
                "bbox": (46.55, 47.0, -71.75, -70.85)},
}


def _block(row, col):
    """NTS 1:50k block number (1..16) for a row (0=south..3=north) and col (0=east..3=west)."""
    return row * 4 + (col + 1 if row % 2 == 0 else 4 - col)   # boustrophedon, 1 = SE corner


def sheets_for(metro):
    """List of NTS sheet codes (e.g. '030M11') whose 15'x30' blocks intersect the metro's bbox."""
    lat_s, lat_n, lon_w, lon_e = metro["bbox"]
    r0 = int((lat_s - metro["area_lat_s"]) / 0.25)
    r1 = int((lat_n - metro["area_lat_s"]) / 0.25)
    c0 = int((metro["area_lon_e"] - lon_e) / 0.5)
    c1 = int((metro["area_lon_e"] - lon_w) / 0.5)
    out = []
    for row in range(max(0, r0), min(3, r1) + 1):
        for col in range(max(0, c0), min(3, c1) + 1):
            out.append(f"{metro['series']}{metro['letter']}{_block(row, col):02d}")
    return sorted(set(out))


def _pdf_url(u, code):
    """Find the GeoPDF download URL for one NTS sheet by listing its NRCan directory."""
    series, letter = code[:3], code[3].lower()
    listing_url = f"{FTP50K}/{series}/{letter}/{code[4:6]}/"   # NRCan nests sheets one level deeper: series/letter/block/
    try:
        page = u.fetch(listing_url, 60)
    except Exception:  # noqa: BLE001
        return None
    if isinstance(page, bytes):                 # the directory listing comes back as raw bytes
        page = page.decode("utf-8", "replace")
    want = code.lower()
    hrefs = re.findall(r'href=["\']([^"\']+\.(?:pdf|zip))["\']', page, re.I)
    cands = [h for h in hrefs if want in html.unescape(h).lower()]
    # NRCan now publishes each sheet as a zip (e.g. 030m11_0700_canmatrix_prtpdf.zip) holding the print PDF.
    cands = [h for h in cands if h.lower().endswith(".pdf") or "prtpdf" in h.lower()]
    if not cands:
        return None
    cands.sort(key=lambda h: (0 if "geo" in h.lower() else 1, len(h)))   # prefer a georeferenced PDF
    href = cands[0]
    return href if href.lower().startswith("http") else listing_url + href.lstrip("/").split("/")[-1]


def _unzip_pdf(zp, out):
    """Extract the largest PDF from a NRCan sheet zip to `out`, then delete the zip."""
    import zipfile
    try:
        with zipfile.ZipFile(zp) as z:
            pdfs = [i for i in z.infolist() if i.filename.lower().endswith(".pdf")]
            if not pdfs:
                return False
            with z.open(max(pdfs, key=lambda i: i.file_size)) as src, open(out + ".tmp", "wb") as dst:
                while True:
                    b = src.read(1 << 20)
                    if not b:
                        break
                    dst.write(b)
        os.replace(out + ".tmp", out)
        os.remove(zp)
        return True
    except (OSError, zipfile.BadZipFile):
        return False


def fetch_metro(u, dest, key, metro):
    """Download every NTS sheet for one metro into www/topo/canada/<code>.pdf. Returns (got, quads)."""
    out_dir = os.path.join(dest, "www", "topo", "canada")
    os.makedirs(out_dir, exist_ok=True)
    got, quads = 0, []
    codes = sheets_for(metro)
    print(f"  {metro['label']}: {len(codes)} Canadian topo sheets ({', '.join(codes)})")
    for code in codes:
        out = os.path.join(out_dir, code + ".pdf")
        rel = "canada/" + code + ".pdf"
        if os.path.exists(out) and os.path.getsize(out) > 0:
            got += 1
            quads.append({"t": code, "rel": rel, "metro": key})
            continue
        url = _pdf_url(u, code)
        if not url:
            print(f"  ! {code}: not published by NRCan (open water/no sheet) or server unreachable")
            continue
        if url.lower().endswith(".zip"):
            zp = out + ".zip"
            if not u.download(url, zp, f"CanTopo {code}"):
                continue
            if not _unzip_pdf(zp, out):
                print(f"  ! {code}: no PDF inside the NRCan zip")
                continue
            got += 1
            quads.append({"t": code, "rel": rel, "metro": key})
        elif u.download(url, out, f"CanTopo {code}"):
            got += 1
            quads.append({"t": code, "rel": rel, "metro": key})
    return got, quads


def add_canada_topo(u, dest, keys=None):
    """Download Canadian topo for the given destination metros (default: all) and index them.

    Writes www/topo/canada/canada.json = {metro_key: {label, sheets:[{t,rel}], gb}} so the travel copy
    and the topo index can find and size the Canadian sheets.
    """
    import json
    keys = keys or list(CA_METROS)
    index = {}
    for key in keys:
        metro = CA_METROS.get(key)
        if not metro:
            continue
        got, quads = fetch_metro(u, dest, key, metro)
        if quads:
            total = sum(os.path.getsize(os.path.join(dest, "www", "topo", q["rel"]))
                        for q in quads if os.path.exists(os.path.join(dest, "www", "topo", q["rel"])))
            index[key] = {"label": metro["label"], "sheets": quads, "gb": round(total / 1e9, 3)}
            print(f"  {metro['label']}: {got}/{len(sheets_for(metro))} Canadian sheets on the drive")
    cdir = os.path.join(dest, "www", "topo", "canada")
    if os.path.isdir(cdir):
        with open(os.path.join(cdir, "canada.json"), "w", encoding="utf-8") as fh:
            json.dump(index, fh, indent=1)
        _write_index(cdir, index)
    return index


def _write_index(cdir, index):
    """A simple browsable page listing the Canadian topo sheets with links to each GeoPDF."""
    rows = []
    for key, m in index.items():
        links = " ".join(f'<a href="{html.escape(q["t"])}.pdf">{html.escape(q["t"])}</a>'
                          for q in m.get("sheets", []))
        rows.append(f"<h2>{html.escape(m['label'])} <small>({m.get('gb', 0):.1f} GB)</small></h2>"
                    f"<p class=sheets>{links or '(none downloaded yet)'}</p>")
    body = "\n".join(rows) or "<p>No Canadian topo sheets have been downloaded yet.</p>"
    page = ("<!doctype html><meta charset=utf-8><title>Canadian topo maps</title>"
            "<meta name=viewport content='width=device-width,initial-scale=1'>"
            "<style>body{font:16px/1.5 system-ui,sans-serif;max-width:52rem;margin:2rem auto;padding:0 1rem}"
            "a{display:inline-block;margin:.15rem .4rem .15rem 0}small{color:#666;font-weight:400}"
            ".sheets{margin:.25rem 0 1.25rem}</style>"
            "<h1>Canadian topo maps (NRCan 1:50,000)</h1>"
            "<p>Natural Resources Canada CanTopo sheets for the cross-border travel destinations. "
            "USGS doesn't cover Canada, so these fill that gap. Tap a sheet to open the GeoPDF.</p>"
            + body)
    with open(os.path.join(cdir, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(page)
