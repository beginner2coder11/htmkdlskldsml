"""Copy (mirror) this OFF-GRID drive to another drive — the whole thing, everything but movies and music, or
an automatic "fit this drive" copy for a smaller USB flash drive or microSD card (64 GB, 128 GB, 256 GB, 512 GB, 1 TB ...).

  python copy_drive.py --dest E:\\OFFGRID --target F            asks the device, where you're going, the size, and which copy
  python copy_drive.py --dest E:\\OFFGRID --target F --mode fit  essentials first, then whatever else fits
  python copy_drive.py --dest E:\\OFFGRID --target F --destination toronto --max-gb 128   travel copy for one trip
  python copy_drive.py --dest E:\\OFFGRID --target F --device iphone --mode nomedia       content-only copy for an iPhone

Pick the DEVICE the copy is for (windows/mac/linux/android/iphone) and it leaves out what that device can't run: a phone
gets the content (books, maps, archives, AI models) but not the Windows programs; an iPhone gets the content only.
Mode C ("custom") lets you tick exactly which parts to include, with a running total against the drive's room.

A "travel copy" is a fit copy aimed at one destination: it carries the core plus that city's get-home plan and the
topo quads along that route, and leaves the other cities' route topo (and the big Southern-cities topo) out.
"Fit" always copies the core (every guide, manual, e-book, checklist, map pages, search, programs, plain-text copies,
the AI program itself) and then adds the optional parts below in order of survival value until the drive is full.
Windows uses robocopy (resumable; later runs copy only changes); Mac/Linux use rsync.
"""
import argparse, fnmatch, json, os, platform, shutil, subprocess, sys

# (label, patterns relative to OFFGRID). Order = priority for "fit". A file belongs to the group with the
# longest matching pattern; files in no group are the core and always copied.
GROUPS = [
    ("AI: everyday model (3B, ~2 GB)", ["ai/models/Llama-3.2-3B*"]),
    ("Medical & repair archives (WikEM, MDWiki, iFixit, Appropedia...)", ["kiwix/zim/wikem_*", "kiwix/zim/mdwiki_*", "kiwix/zim/zimgit-*",
                                                                         "kiwix/zim/ifixit_*", "kiwix/zim/appropedia_*"]),
    ("AI: medical model (MedGemma)", ["ai/models/medgemma*"]),
    ("Home street map", ["www/map"]),
    ("Home topo + terrain map layers", ["www/tiles/topo", "www/tiles/hillshade"]),
    ("Home topo quads (printable PDFs)", ["www/topo"]),
    ("Phone apps & state maps (OsmAnd, Kiwix, Meshtastic...)", ["www/phone-apps"]),
    ("Software installers for other computers (CHIRP, radio software...)", ["www/library/Software"]),
    ("Stack Exchange answers (DIY, gardening, ham, mechanics...)", ["kiwix/zim/*stackexchange*"]),
    ("Kids & school: Simple Wikipedia, Vikidia, PhET", ["kiwix/zim/wikipedia_en_simple*", "kiwix/zim/vikidia_*", "kiwix/zim/phet_*"]),
    ("AI: photo model (identify plants, wounds, parts)", ["ai/models/gemma-3*", "ai/models/mmproj*"]),
    ("Voice input (Whisper)", ["ai/whisper"]),
    ("AI: better model (7B)", ["ai/models/Qwen2.5-7B*"]),
    ("Wikibooks (how-to textbooks)", ["kiwix/zim/wikibooks_*"]),
    ("South-wide topo map layer", ["www/tiles/topo-south"]),
    ("Wiktionary, Wikisource, Wikivoyage, LibreTexts", ["kiwix/zim/wiktionary_*", "kiwix/zim/wikisource_*", "kiwix/zim/wikivoyage_*",
                                                        "kiwix/zim/libretexts*"]),
    ("Full Wikipedia with pictures (~110 GB)", ["kiwix/zim/wikipedia_en_all_maxi*"]),
    ("AI: best model (14B, for 32 GB RAM laptops)", ["ai/models/Qwen2.5-14B*"]),
    ("AI: GPU versions of the AI program", ["ai/bin/win-gpu", "ai/bin/linux-gpu"]),
    ("Khan Academy videos", ["kiwix/zim/khan*"]),
    ("Project Gutenberg — every book (~70 GB)", ["kiwix/zim/gutenberg_*"]),
    ("Topo maps of Southern cities, lakes and bases (~250 GB)", ["www/topo/areas"]),
    ("Movies & TV", ["www/media/Movies", "www/media/TV Shows", "www/media/Kids Movies", "www/media/Kids TV"]),
    ("Music", ["www/music/Music", "www/music/Kids Music"]),
]
MEDIA = {"Movies & TV", "Music"}
SKIP_ALWAYS = ["*.part", "kiwix/dl", "tools/dl"]

# Files that are useless on a given device get left out, to save space and clutter. Patterns are relative
# to OFFGRID, same style as the GROUPS patterns.
DEVICE_SKIP = {
    "windows": [],
    "mac":     ["tools/python-win", "tools/sumatra", "PROGRAMS/*.bat"],
    "linux":   ["tools/python-win", "tools/sumatra", "PROGRAMS/*.bat"],
    "android": ["tools/python-win", "tools/sumatra", "tools/veracrypt", "tools/vlc",
                "kiwix/bin", "kiwix/desktop", "ai/bin", "PROGRAMS/*.bat"],
    "iphone":  ["tools/python-win", "tools/sumatra", "tools/veracrypt", "tools/vlc", "tools/pmtiles",
                "tools/java", "kiwix/bin", "kiwix/desktop", "ai/bin", "PROGRAMS"],
}
DEVICE_LABEL = {"windows": "Windows PC", "mac": "Mac", "linux": "Linux",
                "android": "Android phone/tablet", "iphone": "iPhone / iPad"}


def choose_groups(sizes, keep, room, used0):
    """Let the user toggle exactly which optional parts to include, with a running total against the drive."""
    idx = [i for i, (lab, _) in enumerate(GROUPS) if lab not in MEDIA or sizes[i] > 0]
    while True:
        used = used0 + sum(sizes[i] for i in idx if keep[i])
        print("\n  Choose what to include (type a number to toggle, Enter to accept):")
        for n, i in enumerate(idx, 1):
            print(f"    {n:2}. [{'x' if keep[i] else ' '}] {GROUPS[i][0]:<58} {gb(sizes[i]):>9}")
        print(f"       total selected: {gb(used)}  /  room: {gb(room)}" + ("   ! OVER — deselect some" if used > room else ""))
        v = input("  Number to toggle (or Enter to finish): ").strip()
        if not v:
            if used > room:
                print("  Still over the limit — remove something first."); continue
            return
        if v.isdigit() and 1 <= int(v) <= len(idx):
            keep[idx[int(v) - 1]] ^= True


def _match(rel, p):
    if "*" in p:
        return fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(rel, p + "/*")
    return rel == p or rel.startswith(p + "/")


def group_of(rel):
    best, blen = None, -1
    for gi, (_, pats) in enumerate(GROUPS):
        for p in pats:
            if len(p) > blen and _match(rel, p):
                best, blen = gi, len(p)
    return best


def measure(src):
    sizes = [0] * len(GROUPS)
    core, big = 0, []
    for root, dirs, files in os.walk(src):
        relroot = os.path.relpath(root, src).replace(os.sep, "/")
        relroot = "" if relroot == "." else relroot + "/"
        dirs[:] = [d for d in dirs if (relroot + d) not in ("kiwix/dl", "tools/dl", "TRAVEL", "_TIDY-BIN", "OPEN-WITH", "System Volume Information")]
        for f in files:
            if f.endswith(".part"):
                continue
            try:
                n = os.path.getsize(os.path.join(root, f))
            except OSError:
                continue
            rel = relroot + f
            g = group_of(rel)
            if g is None:
                core += n
            else:
                sizes[g] += n
            if n >= 4 * 1024 ** 3:
                big.append(rel)
    return core, sizes, big


def py_mirror(src, out, keep, max_size=None, skip=()):
    """Plain-Python mirror (when rsync isn't installed): copy new/changed files, remove ones no longer on this drive."""
    def excluded(rel):                        # device-skip patterns: a dir prefix, or an fnmatch like PROGRAMS/*.bat
        return any(rel == p or rel.startswith(p + "/") or fnmatch.fnmatch(rel, p) for p in skip)
    seen, n, bad = set(), 0, 0
    for root, dirs, files in os.walk(src):
        relroot = os.path.relpath(root, src).replace(os.sep, "/")
        relroot = "" if relroot == "." else relroot + "/"
        dirs[:] = [d for d in dirs if (relroot + d) not in ("kiwix/dl", "tools/dl", "TRAVEL", "_TIDY-BIN", "OPEN-WITH") and not excluded(relroot + d)]
        for f in files:
            rel = relroot + f
            g = group_of(rel)
            if f.endswith(".part") or (g is not None and not keep[g]) or excluded(rel):
                continue
            sp, dp = os.path.join(root, f), os.path.join(out, *rel.split("/"))
            seen.add(os.path.normcase(dp))
            try:
                st = os.stat(sp)
                if max_size and st.st_size > max_size:
                    continue
                if os.path.exists(dp):
                    dt = os.stat(dp)
                    if dt.st_size == st.st_size and int(dt.st_mtime) >= int(st.st_mtime):
                        continue
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                shutil.copy2(sp, dp); n += 1
                if n % 200 == 0:
                    print(f"\r  {n:,} files copied...", end="", flush=True)
            except OSError as e:
                bad += 1; print(f"\n  ! {rel}: {e}")
    for root, _, files in os.walk(out):
        for f in files:
            p = os.path.join(root, f)
            if os.path.normcase(p) not in seen and f not in ("COPY-CONTENTS.txt", "OFFGRID-COPY-LOG.txt"):
                try:
                    os.remove(p)
                except OSError:
                    pass
    print(f"\n  {n:,} files copied" + (f", {bad} failed" if bad else ""))
    return bad == 0


def fs_type(path):
    if os.name != "nt":
        return ""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(64)
        root = os.path.splitdrive(os.path.abspath(path))[0] + "\\"
        ctypes.windll.kernel32.GetVolumeInformationW(root, None, 0, None, None, None, buf, 64)
        return buf.value
    except Exception:  # noqa: BLE001
        return ""


def gb(n):
    return f"{n / 1e9:,.1f} GB"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True, help="this drive's OFFGRID folder (the source)")
    ap.add_argument("--target", required=True, help="drive letter (Windows) or folder of the other drive")
    ap.add_argument("--mode", choices=("full", "nomedia", "fit"))
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--max-gb", type=float, help="cap the copy at this size, e.g. 64 (for a folder on this computer, or to leave room on the drive)")
    ap.add_argument("--destination", help="get-home route key (e.g. toronto) for a travel copy: takes that route's topo, not the others'")
    ap.add_argument("--device", choices=tuple(DEVICE_SKIP), help="what the copy is for (windows/mac/linux/android/iphone): leaves out files that device can't use")
    a = ap.parse_args()
    src = os.path.abspath(a.dest)
    # get-home route topo manifest (built with the drive): {key: {label, quads, gb}}
    try:
        routetopo = json.load(open(os.path.join(src, "www", "data", "route-topo.json"), encoding="utf-8"))
    except (OSError, ValueError):
        routetopo = {}
    if a.destination and a.destination not in routetopo:
        print(f"  ! Unknown destination '{a.destination}'. Known: {', '.join(routetopo) or '(none built yet)'}"); return 1
    t = a.target.strip().strip('"').rstrip("\\/")
    if os.name == "nt" and len(t.rstrip(":")) == 1:          # a drive letter: copy to X:\OFFGRID
        troot = t.rstrip(":").upper() + ":\\"
        if not os.path.exists(troot):
            print(f"  ! {troot} not found — plug the drive in and check its letter."); return 1
        out = os.path.join(troot, "OFFGRID")
        if os.path.normcase(os.path.splitdrive(src)[0]) == os.path.normcase(os.path.splitdrive(out)[0]):
            print("  ! That's this same drive. Pick the other one (or give a folder)."); return 1
    else:                                                      # a folder, e.g. C:\OFFGRID-64 on this computer
        out = os.path.abspath(t)
        if not os.path.isdir(os.path.dirname(out) or out):
            print(f"  ! {os.path.dirname(out)} doesn't exist."); return 1
        o, sr = os.path.normcase(out), os.path.normcase(src)
        if o == sr or o.startswith(sr + os.sep) or sr.startswith(o + os.sep):
            print("  ! The copy can't go inside this OFFGRID folder (or the other way round). Pick another folder."); return 1
        troot = os.path.dirname(out) or out
    # What's the copy for? A phone can't run the Windows programs, an iPhone can't run any of them, so leave those out.
    if a.device is None and not a.yes:
        print("\n  What will you use this copy on?")
        print("    1. Windows PC       2. Mac       3. Linux       4. Android phone/tablet       5. iPhone / iPad")
        dev = {"1": "windows", "2": "mac", "3": "linux", "4": "android", "5": "iphone"}
        v = input("  Pick a number (Enter = Windows PC): ").strip()
        a.device = dev.get(v, "windows")
    a.device = a.device or "windows"
    # Travel copy: pick where you're going, so the copy takes that route's topo and leaves the other cities' out.
    if routetopo and a.destination is None and not a.yes:
        keys = list(routetopo)
        print("\n  Where are you going? (a travel copy carries that route's maps home; leave others out)")
        for i, k in enumerate(keys, 1):
            print(f"    {i}. {routetopo[k]['label']:<26} route maps {routetopo[k]['gb']:.1f} GB")
        print("    0. Just the home area (no specific trip)")
        v = input("  Pick a number (Enter = home area only): ").strip()
        if v.isdigit() and 1 <= int(v) <= len(keys):
            a.destination = keys[int(v) - 1]
    # Size of the drive you're copying to, so it knows how much to fit.
    if a.max_gb is None and not a.yes:
        print("\n  How big is the drive you're copying to?")
        print("    1. 128 GB flash drive       2. 256 GB        3. 512 GB")
        print("    4. 1 TB hard drive          5. 2 TB          6. a size I'll type")
        print("    0. Just use its free space")
        presets = {"1": 128, "2": 256, "3": 512, "4": 1000, "5": 2000}
        v = input("  Pick a number (Enter = use free space): ").strip()
        if v in presets:
            a.max_gb = float(presets[v])
        elif v == "6":
            g = input("    Size in GB: ").strip()
            a.max_gb = float(g) if g.replace(".", "", 1).isdigit() else None
    print("  Measuring this drive (a minute or two on a big drive)...")
    core, sizes, big = measure(src)
    have = 0
    if os.path.isdir(out):              # a previous copy is replaced, so its space counts as available
        for r, _, fs in os.walk(out):
            for f in fs:
                try:
                    have += os.path.getsize(os.path.join(r, f))
                except OSError:
                    pass
    free = shutil.disk_usage(troot).free
    room = int((free + have) * 0.97)
    if a.max_gb:
        room = min(room, int(a.max_gb * 1e9 * 0.97))
    fstype = fs_type(troot)
    print(f"\n  Copy to {out}: {gb(free)} free{f' (+{gb(have)} of an older copy)' if have else ''}, {fstype or 'file system ?'}"
          + (f", limit {a.max_gb:g} GB" if a.max_gb else ""))
    total = core + sum(sizes)
    nomedia = core + sum(s for (lab, _), s in zip(GROUPS, sizes) if lab not in MEDIA)
    areas_idx = next((i for i, (lab, _) in enumerate(GROUPS) if "cities, lakes and bases" in lab), None)
    dest_quads = routetopo.get(a.destination, {}).get("quads", []) if a.destination else []
    dest_bytes = int(routetopo.get(a.destination, {}).get("gb", 0.0) * 1e9) if a.destination else 0
    # Canadian destinations (Toronto, Québec City) also carry their NRCan topo sheets.
    ca_idx = {}
    if a.destination:
        cjson = os.path.join(src, "www", "topo", "canada", "canada.json")
        if os.path.exists(cjson):
            try:
                ca_idx = json.load(open(cjson, encoding="utf-8")).get(a.destination, {})
            except (OSError, ValueError):
                ca_idx = {}
        dest_bytes += int(ca_idx.get("gb", 0.0) * 1e9)     # reserve room for the Canadian sheets too
    mode = a.mode or ("fit" if a.destination else None)   # a travel copy is always "fit to the drive"
    if not mode:
        print(f"\n    F = everything                                  {gb(total)}")
        print(f"    N = everything except movies, TV and music     {gb(nomedia)}")
        print(f"    A = automatic for a smaller drive (64 GB, 128 GB, 256 GB, 512 GB flash drive...): essentials first, then")
        print(f"        whatever else fits, most useful first. No movies or music.")
        print(f"    C = choose exactly what to include (pick each part yourself, with a running total)")
        c = input("\n  Type F, N, A or C: ").strip().upper()
        mode = {"F": "full", "N": "nomedia", "A": "fit", "C": "custom"}.get(c)
        if not mode:
            return 1
    keep = [True] * len(GROUPS)
    if mode == "nomedia":
        keep = [lab not in MEDIA for lab, _ in GROUPS]
    elif mode in ("fit", "custom"):
        used = core + dest_bytes                          # reserve room for the destination route's own topo quads
        if used > room:
            print(f"  ! Even the core{' + route topo' if dest_bytes else ''} ({gb(used)}) doesn't fit in {gb(room)}. Use a bigger drive."); return 1
        for i, s in enumerate(sizes):
            if a.destination and i == areas_idx:          # take only this trip's quads (added after), not all of Southern topo
                keep[i] = False; continue
            keep[i] = GROUPS[i][0] not in MEDIA and (s == 0 or used + s <= room)   # "fit" = essentials, never movies/music
            if keep[i]:
                used += s
        if mode == "custom" and not a.yes:                # start from what fits, then let the user hand-pick
            choose_groups(sizes, keep, room, core + dest_bytes)
    want = core + dest_bytes + sum(s for k, s in zip(keep, sizes) if k)
    print(f"\n  Core (always): every guide, manual, e-book, checklist, map page, search, programs, text copies   {gb(core)}")
    if a.destination:
        print(f"    [x] Get-home route to {routetopo[a.destination]['label']} (plan + its topo quads){'':<16} {gb(dest_bytes):>11}")
    for (lab, _), s, k in zip(GROUPS, sizes, keep):
        if s:
            print(f"    [{'x' if k else ' '}] {lab:<66} {gb(s):>11}")
    print(f"\n  Copy size: {gb(want)}   room on the other drive: {gb(room)}")
    if want > room:
        print("  ! That's more than fits. Choose A (automatic) or use a bigger drive."); return 1
    fat = fstype.upper().startswith("FAT") and fstype.upper() != "EXFAT"
    if fat:
        print("  ! The other drive is FAT32, which can't hold files over 4 GB (AI models, big archives). Those will be skipped.\n"
              "    Better: reformat it as exFAT (right-click the drive in File Explorer > Format > exFAT), then run this again.")
    elif fstype.upper() == "NTFS":
        if a.device in ("android", "iphone"):
            print(f"  ! STOP: the other drive is NTFS, and a{'n iPhone' if a.device == 'iphone' else ' phone'} CAN'T read NTFS.\n"
                  "    Reformat it as exFAT first (right-click the drive in File Explorer > Format > exFAT), then run\n"
                  "    this again. See USE-ON-PHONE.html. Copying now would make a drive the phone can't open.")
        else:
            print("  ! The other drive is NTFS. Fine for Windows, but a Mac can only read it (not write), and a\n"
                  "    phone can't use it at all. For anything but a Windows drive, reformat it as exFAT first.")
    elif fstype.upper() == "EXFAT":
        print("  (exFAT — works on iPhone, Android, Windows and Mac.)")
    if not a.yes and input("\n  Type YES to start: ").strip().upper() != "YES":
        return 1
    ex_dirs, ex_files = [], []
    for (lab, pats), k in zip(GROUPS, keep):
        if k:
            continue
        for p in pats:
            (ex_files if "*" in os.path.basename(p) else ex_dirs).append(p)
    for p in DEVICE_SKIP.get(a.device, []):               # leave out what this device can't run
        bucket = ex_files if "*" in os.path.basename(p) else ex_dirs
        if p not in bucket:
            bucket.append(p)
    os.makedirs(out, exist_ok=True)
    # parts left out this time may be on the other drive from an earlier, bigger copy: remove them to make room
    gone = 0
    for r, dirs, fs in os.walk(out, topdown=True):
        relroot = os.path.relpath(r, out).replace(os.sep, "/")
        relroot = "" if relroot == "." else relroot + "/"
        for f in fs:
            g = group_of(relroot + f)
            if g is not None and not keep[g]:
                try:
                    gone += os.path.getsize(os.path.join(r, f)); os.remove(os.path.join(r, f))
                except OSError:
                    pass
    if gone:
        print(f"  Removed {gb(gone)} of left-out parts from the older copy on the other drive.")
    print("\n  Copying... the first copy takes a while (a flash drive is slower than a hard drive). Stop and run again to resume.")
    if os.name == "nt":
        cmd = ["robocopy", src, out, "/MIR", "/R:2", "/W:5", "/MT:8", "/XJ", "/NFL", "/NDL", "/XF", "*.part"]
        cmd += [os.path.basename(p) for p in ex_files]
        cmd += ["/XD", os.path.join(src, "kiwix", "dl"), os.path.join(src, "tools", "dl"), os.path.join(src, "TRAVEL"), os.path.join(src, "_TIDY-BIN"), os.path.join(src, "OPEN-WITH")] + [os.path.join(src, *p.split("/")) for p in ex_dirs]
        if fat:
            cmd += ["/MAX:4294967295"]
        cmd += [f"/LOG:{os.path.join(os.path.dirname(out) or out, 'OFFGRID-COPY-LOG.txt')}", "/TEE"]
        rc = subprocess.call(cmd)
        ok = rc < 8
    else:
        cmd = ["rsync", "-a", "--delete", "--delete-excluded", "--info=progress2", "--exclude=*.part", "--exclude=/kiwix/dl", "--exclude=/tools/dl"]
        cmd += ["--exclude=/TRAVEL"] + [f"--exclude=/{p}" for p in ex_dirs + ex_files]
        if fat:
            cmd += ["--max-size=4G"]
        if shutil.which("rsync"):
            rc = subprocess.call(cmd + [src + "/", out + "/"])
            ok = rc == 0
        else:
            ok = py_mirror(src, out, keep, 4 * 1024 ** 3 - 1 if fat else None, skip=ex_dirs + ex_files)
    # Travel copy: put exactly this destination's topo quads on the target (the big Southern-topo folder was left out).
    if a.destination:
        aout = os.path.join(out, "www", "topo", "areas")
        wanted = {os.path.normcase(os.path.join(out, *rel.split("/"))) for rel in dest_quads}
        if os.path.isdir(aout):
            for r, _, fs in os.walk(aout):
                for f in fs:
                    p = os.path.join(r, f)
                    if os.path.normcase(p) not in wanted:
                        try:
                            os.remove(p)
                        except OSError:
                            pass
        added = 0
        for rel in dest_quads:
            sp, dp = os.path.join(src, *rel.split("/")), os.path.join(out, *rel.split("/"))
            if not os.path.exists(sp):
                continue
            try:
                if not (os.path.exists(dp) and os.path.getsize(dp) == os.path.getsize(sp)):
                    os.makedirs(os.path.dirname(dp), exist_ok=True)
                    shutil.copy2(sp, dp); added += 1
            except OSError as e:
                print(f"  ! {rel}: {e}")
        if dest_quads:
            print(f"  {routetopo[a.destination]['label']} route topo: {len(dest_quads)} quads ({added} newly copied)")
        cadded = 0                                         # Canadian sheets for Toronto / Québec City
        for q in ca_idx.get("sheets", []):
            sp, dp = os.path.join(src, "www", "topo", *q["rel"].split("/")), os.path.join(out, "www", "topo", *q["rel"].split("/"))
            if os.path.exists(sp) and not (os.path.exists(dp) and os.path.getsize(dp) == os.path.getsize(sp)):
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                try:
                    shutil.copy2(sp, dp); cadded += 1
                except OSError as e:
                    print(f"  ! {q['rel']}: {e}")
        if ca_idx.get("sheets"):
            print(f"  {ca_idx.get('label', a.destination)} Canadian topo: {len(ca_idx['sheets'])} sheets ({cadded} newly copied)")
    # the AI's default model must be one that was copied
    try:
        mdir = os.path.join(out, "ai", "models")
        names = os.listdir(mdir) if os.path.isdir(mdir) else []
        for pref in ("Qwen2.5-7B", "Llama-3.2-3B", "Qwen2.5-14B"):
            hit = next((n for n in names if n.startswith(pref) and n.endswith(".gguf")), None)
            if hit:
                cur = open(os.path.join(out, "ai", "default-model.txt")).read().strip() if os.path.exists(os.path.join(out, "ai", "default-model.txt")) else ""
                if cur not in names:
                    with open(os.path.join(out, "ai", "default-model.txt"), "w") as fh:
                        fh.write(hit + "\n")
                break
    except OSError:
        pass
    # parts left out: their pages must not list files that aren't there
    labs = {lab for (lab, _), k in zip(GROUPS, keep) if not k}
    try:
        if "Movies & TV" in labs and os.path.isdir(os.path.join(out, "www", "media")):
            with open(os.path.join(out, "www", "media", "catalog.js"), "w", encoding="utf-8") as fh:
                fh.write('window.MEDIA={"items":[],"built":"","gb":0};\n')
        if "Music" in labs and os.path.isdir(os.path.join(out, "www", "music")):
            with open(os.path.join(out, "www", "music", "catalog.js"), "w", encoding="utf-8") as fh:
                fh.write('window.MUSIC={"albums":[],"songs":[],"gb":0};\n')
        with open(os.path.join(out, "COPY-CONTENTS.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write(f"Copied from {src}\n")
            fh.write(f"For: {DEVICE_LABEL.get(a.device, a.device)}\n")
            if DEVICE_SKIP.get(a.device):
                fh.write("  (left out the programs this device can't run: " + ", ".join(DEVICE_SKIP[a.device]) + ")\n")
            if a.destination:
                fh.write(f"Travel copy for: {routetopo[a.destination]['label']} -> Canton (that route's get-home plan and topo)\n")
            dropped = sorted(labs & {lab for (lab, _), s in zip(GROUPS, sizes) if s})
            fh.write("Included: core + " + "; ".join(lab for (lab, _), k, s in zip(GROUPS, keep, sizes) if k and s) +
                     ("\nLeft out (to save space): " + "; ".join(dropped) if dropped else "") + "\n")
    except OSError:
        pass
    if ok:
        if a.device in ("android", "iphone"):
            tip = f"Copy complete. On the phone, open USE-ON-PHONE.html in {out} for how to read it (Kiwix app, a browser, OsmAnd for maps)."
        elif a.device in ("mac", "linux"):
            tip = f"Copy complete. On that computer, open {out} and run start.command (Mac) or start.sh (Linux)."
        else:
            tip = f"Copy complete. Test it: open {out} and run START-HERE.bat."
    else:
        tip = f"Some files could not be copied - see {os.path.join(os.path.dirname(out) or out, 'OFFGRID-COPY-LOG.txt')} (drive full or unplugged?)"
    print("\n  " + tip)
    return 0 if ok else 2


if __name__ == "__main__":
    sys.exit(main())
