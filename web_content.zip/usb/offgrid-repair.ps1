# Weekly repair for the OFF-GRID SURVIVAL DRIVE (installed by SET-WEEKLY-REPAIR-WINDOWS.bat)
$root = Get-PSDrive -PSProvider FileSystem | ForEach-Object { Join-Path $_.Root 'OFFGRID' } |
        Where-Object { Test-Path (Join-Path $_ 'tools\builder\usb\repair_drive.py') } | Select-Object -First 1
if (-not $root) { exit 0 }                      # drive not plugged in: nothing to do
$py = Join-Path $root 'tools\python-win\python.exe'
if (-not (Test-Path $py)) { $py = 'python' }
& $py (Join-Path $root 'tools\builder\usb\repair_drive.py') --dest $root
