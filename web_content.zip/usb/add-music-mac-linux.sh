#!/bin/sh
# ===== Add your music to this drive (Mac / Linux) =====
# Run:  sh /path/to/OFFGRID/PROGRAMS/add-music-mac-linux.sh /path/to/music
cd "$(dirname "$0")" || exit 1
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
MP=tools/builder/usb/music.py
if [ -z "$1" ]; then "$PY" "$MP" --dest "$(pwd)" --catalog-only; exit; fi
"$PY" "$MP" --dest "$(pwd)" --src "$1" || exit 1
echo; echo "Look over MUSIC-PLAN.html (fix names in MUSIC-PLAN.csv if needed)."
printf 'Copy, Move or Nothing? [c/m/N] '; read -r A
case "$A" in c|C) M=copy ;; m|M) M=move ;; *) exit 0 ;; esac
"$PY" "$MP" --dest "$(pwd)" --apply "$M" && "$PY" "$MP" --dest "$(pwd)" --catalog-only
