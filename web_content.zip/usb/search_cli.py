"""Search the OFF-GRID drive with NO web browser — in a plain command window (Windows, Mac, Linux).

Uses the same full-text index as the Search page (every guide section, every PDF page, every e-book),
so results match. Works with the drive's portable Python or any Python 3 already on the computer.

  SEARCH-NO-BROWSER-WINDOWS.bat            (double-click)       sh search-no-browser.sh   (Mac/Linux)
  python search_cli.py --dest E:\\OFFGRID "tourniquet"       one search and exit

At the prompt: type words to search · a result number to read that page right in the window ·
"o 3" to open result 3 in whatever program the computer has (PDF reader, Notepad) · "q" to quit.
Plain-text copies of everything are also in OFFGRID\\TEXT-ONLY\\ for Notepad, an e-reader or a phone.
"""
import argparse, json, math, os, re, shutil, subprocess, sys, textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from search_index import tokens, STOP, WORD  # noqa: E402  same word rules as the index


def load_js(path, prefix):
    s = open(path, encoding="utf-8").read().strip()
    s = s[len(prefix):]
    return json.loads(s.rstrip(";").rstrip(")") if prefix.endswith("(") else s.rstrip(";"))


class Index:
    def __init__(self, dest):
        self.dest = dest
        self.www = os.path.join(dest, "www")
        sd = os.path.join(self.www, "search")
        raw = open(os.path.join(sd, "docs.js"), encoding="utf-8").read()
        self.docs = json.loads(re.search(r"window\.SEARCH_DOCS=(.*?);\n", raw, re.S).group(1))
        self.built = (re.search(r'SEARCH_BUILT="([^"]+)"', raw) or [None, "?"])[1]
        self.plen = json.loads(open(os.path.join(sd, "plen.js")).read().split("=", 1)[1].rstrip().rstrip(";"))
        self.sd, self.shards, self.texts = sd, {}, {}
        self.avg = sum(self.plen) / max(1, len(self.plen))

    def postings(self, w):
        k = w[:2]
        if k not in self.shards:
            p = os.path.join(self.sd, "idx", k + ".js")
            self.shards[k] = load_js(p, "SEARCH_SHARD(")[1] if os.path.exists(p) else {}
        return self.shards[k].get(w, [])

    def doc_of(self, pid):
        lo, hi = 0, len(self.docs) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.docs[mid][3] <= pid:
                lo = mid
            else:
                hi = mid - 1
        return self.docs[lo]

    def page_text(self, doc, pid):
        key = doc[6]
        if key not in self.texts:
            self.texts = {key: load_js(os.path.join(self.sd, "text", key + ".js"), "SEARCH_TEXT(")[1]}
        pages = self.texts[key]
        i = pid - doc[3]
        return pages[i] if 0 <= i < len(pages) else ""

    def _fts_ok(self):
        """The SQLite FTS5 copy, if it exists and matches this index (built in the same run)."""
        if not hasattr(self, "_fts"):
            self._fts = None
            try:
                import search_db
                m = search_db.info(self.dest)
                if m and int(m.get("pages", -1)) == len(self.plen) and int(m.get("docs", -1)) == len(self.docs):
                    self._fts = search_db
            except Exception:  # noqa: BLE001
                pass
        return self._fts

    def search(self, q, limit=15):
        words = list(dict.fromkeys(tokens(q)))
        if not words:
            return []
        sdb = self._fts_ok()
        if sdb:                      # fast path: SQLite FTS5 (same page ids), phrases in "quotes" kept exact
            phrases = re.findall(r'"([^"]+)"', q)
            rest = re.sub(r'"[^"]*"', " ", q)
            groups = [[w] for w in dict.fromkeys(WORD.findall(rest.lower())) if w not in STOP and len(w) > 1]
            rows, _ = sdb.query(self.dest, groups, phrases, limit=400)
            if rows:
                out, per_doc = [], {}
                for _, pid in rows:
                    d = self.doc_of(pid)
                    if per_doc.get(d[1], 0) >= 3:
                        continue
                    per_doc[d[1]] = per_doc.get(d[1], 0) + 1
                    out.append((pid, d))
                    if len(out) >= limit:
                        break
                return out, words
        n = len(self.plen)
        score, hits = {}, {}
        for w in words:
            p = self.postings(w)
            df = len(p) // 2
            if not df:
                continue
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for i in range(0, len(p), 2):
                pid, tf = p[i], p[i + 1]
                L = self.plen[pid] if pid < len(self.plen) else self.avg
                score[pid] = score.get(pid, 0) + idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * L / self.avg))
                hits[pid] = hits.get(pid, 0) + 1
        for pid in score:      # pages with all the words come first
            score[pid] *= 1 + 2 * (hits[pid] - 1) / max(1, len(words) - 1) if len(words) > 1 else 1
        top = sorted(score, key=score.get, reverse=True)
        out, per_doc = [], {}
        for pid in top:
            d = self.doc_of(pid)
            if per_doc.get(d[1], 0) >= 3:      # at most 3 pages from one document
                continue
            per_doc[d[1]] = per_doc.get(d[1], 0) + 1
            out.append((pid, d))
            if len(out) >= limit:
                break
        return out, words

    def where(self, pid, d):
        i = pid - d[3]
        if d[1].lower().endswith(".pdf"):
            return f"page {i + 1}"
        if d[1].startswith("zim.html") and d[5] and i < len(d[5]):
            from urllib.parse import unquote
            return "article: " + unquote(d[5][i].rsplit("/", 1)[-1]).replace("_", " ")
        if d[5] and i < len(d[5]) and d[5][i]:
            return "section #" + d[5][i]
        return f"part {i + 1}" if d[4] > 1 else ""

    def path(self, d):
        return os.path.join(self.www, *d[1].split("/"))


def snippet(text, words, width=230):
    low = text.lower()
    pos = [m.start() for w in words for m in [re.search(r"\b" + re.escape(w), low)] if m]
    start = max(0, min(pos) - 60) if pos else 0
    s = re.sub(r"\s+", " ", text[start:start + width]).strip()
    return ("…" if start else "") + s + "…"


def open_file(path, dest=None):
    sumatra = os.path.join(dest or "", "tools", "sumatra", "SumatraPDF.exe")
    try:
        if os.name == "nt" and path.lower().endswith((".pdf", ".epub")) and os.path.exists(sumatra):
            subprocess.Popen([sumatra, path])   # the drive's own reader — works even with no PDF app installed
        elif os.name == "nt":
            os.startfile(path)  # noqa: S606  — default program for the file type
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        print("  opened:", path)
    except Exception as e:  # noqa: BLE001
        print("  couldn't open it here:", e)
        print("  The file is at:", path)


def show_page(ix, pid, d, words):
    txt = ix.page_text(d, pid)
    w = max(60, min(110, shutil.get_terminal_size((100, 30)).columns - 2))
    rows = shutil.get_terminal_size((100, 30)).lines - 4
    print("\n" + "=" * w + f"\n{d[0]}  —  {ix.where(pid, d)}\n" + "=" * w)
    lines = []
    for para in re.split(r"\s{2,}|(?<=[.:;])\s+(?=[A-Z0-9•\-])", txt):
        lines += textwrap.wrap(para, w) or [""]
    for i in range(0, len(lines), rows):
        print("\n".join(lines[i:i + rows]))
        if i + rows < len(lines) and input("  -- Enter for more, q to stop -- ").strip().lower() == "q":
            break
    print("-" * w + f"\nFile: {ix.path(d)}\n")


def run(ix, q):
    res = ix.search(q)
    if not res or not res[0]:
        print("  No matches. Try fewer or different words (e.g. 'bleeding' instead of 'bleeding badly arm').")
        return []
    res, words = res
    print()
    for n, (pid, d) in enumerate(res, 1):
        print(f"{n:>2}. {d[0][:80]}  [{d[2]}]  {ix.where(pid, d)}")
        print("    " + snippet(ix.page_text(d, pid), words))
    print("\n  Number = read it here · o + number = open the file · new words = search again · q = quit")
    return [(pid, d) for pid, d in res]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", default=os.path.dirname(os.path.dirname(os.path.dirname(HERE))), help="the OFFGRID folder")
    ap.add_argument("query", nargs="*")
    a = ap.parse_args()
    try:
        ix = Index(a.dest)
    except (OSError, ValueError, AttributeError) as e:
        print(f"Search index not found in {a.dest}\\www\\search ({e}).")
        print("Use the plain-text copies in TEXT-ONLY instead, or re-run the builder on a computer with internet.")
        return 1
    print(f"OFF-GRID DRIVE SEARCH (no browser)   {len(ix.docs)} documents, {len(ix.plen):,} pages, index built {ix.built}")
    if a.query:
        run(ix, " ".join(a.query)); return 0
    last = []
    while True:
        try:
            q = input("\nSearch> ").strip()
        except (EOFError, KeyboardInterrupt):
            print(); return 0
        if not q:
            continue
        if q.lower() in ("q", "quit", "exit"):
            return 0
        m = re.fullmatch(r"(o\s*)?(\d+)", q.lower())
        if m and last:
            k = int(m.group(2)) - 1
            if 0 <= k < len(last):
                pid, d = last[k]
                open_file(ix.path(d), ix.dest) if m.group(1) else show_page(ix, pid, d, [])
                continue
        last = run(ix, q) or last


if __name__ == "__main__":
    sys.exit(main())
