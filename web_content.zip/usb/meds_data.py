"""Medicines list: what each drug is used for, plus its warnings (OTC and prescription).

Source: openFDA drug-label download (the FDA's own structured drug labels, public domain).
  https://open.fda.gov/apis/downloads  - zipped JSON partitions listed in https://api.fda.gov/download.json
One entry per active ingredient and kind (OTC / Rx): the name, brand names, route, "uses" (indications), and the
warnings (boxed warning, do-not-use, stop-use, ask-a-doctor, warnings).
Writes www/data/meds/index.js + one shard per first letter (details), and EXCEL-READY\\Medicines.xlsx.
Reference information only - not medical advice.
"""
import json
import os
import re
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
MANIFEST = "https://api.fda.gov/download.json"
USES_MAX, WARN_MAX = 900, 1500
_HEAD = re.compile(r"^\s*(indications?( and|&) usage|indications?|uses?|purpose|warnings?|do not use|stop use( and ask a doctor)?|ask a doctor( or pharmacist)?( before use)?|boxed warning|warnings and precautions)\s*[:\-.]*\s*", re.I)


def _clean(parts, limit):
    if not parts:
        return ""
    t = " ".join(parts) if isinstance(parts, list) else str(parts)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"^\s*\d+(\.\d+)?\s+(?=[A-Za-z])", "", t)          # leading section number "1 INDICATIONS..."
    for _ in range(3):
        n = _HEAD.sub("", t, count=1)
        if n == t:
            break
        t = n
    if len(t) > limit:
        t = t[:limit].rsplit(" ", 1)[0] + " ..."
    return t


def stream_results(fh):
    """Yield the records of an openFDA JSON file one at a time (the files are far too big to json.load on a small PC)."""
    dec = json.JSONDecoder()
    buf, pos, started = "", 0, False
    while True:
        chunk = fh.read(1 << 22)
        if chunk:
            buf += chunk.decode("utf-8", "replace") if isinstance(chunk, bytes) else chunk
        if not started:
            m = re.search(r'"results"\s*:\s*\[', buf)
            if not m:
                if not chunk:
                    return
                buf = buf[-64:]
                continue
            pos, started = m.end(), True
        while True:
            while pos < len(buf) and buf[pos] in " \r\n\t,":
                pos += 1
            if pos >= len(buf):
                break
            if buf[pos] == "]":
                return
            try:
                obj, end = dec.raw_decode(buf, pos)
            except ValueError:
                break                                        # record not complete yet: read more
            yield obj
            pos = end
        buf = buf[pos:]
        pos = 0
        if not chunk:
            return


def _record(r):
    of = r.get("openfda") or {}
    ptype = " ".join(of.get("product_type") or [])
    kind = "OTC" if "OTC" in ptype.upper() or "OVER" in ptype.upper() else ("Rx" if "PRESCRIPTION" in ptype.upper() else "")
    if not kind:
        kind = "OTC" if r.get("purpose") or r.get("do_not_use") else "Rx"
    gen = (of.get("generic_name") or of.get("substance_name") or [""])[0]
    if not gen:
        ai = r.get("active_ingredient") or []
        gen = re.sub(r"\s+\d[\d.,]*\s*(mg|mcg|g|ml|%|unt|\[.*?\]).*$", "", re.sub(r"\s+", " ", ai[0]), flags=re.I).strip() if ai else ""
    brand = [b.title() for b in (of.get("brand_name") or [])]
    if not gen:
        gen = brand[0] if brand else ""
    if not gen:
        return None
    uses = _clean(r.get("indications_and_usage") or r.get("purpose") or r.get("indications_and_usage_table"), USES_MAX)
    purpose = _clean(r.get("purpose"), 200)
    warn = []
    for k, lab in (("boxed_warning", "BOXED WARNING"), ("do_not_use", "Do not use"), ("contraindications", "Contraindications"),
                   ("stop_use", "Stop use and ask a doctor"), ("ask_doctor", "Ask a doctor before use"),
                   ("warnings", "Warnings"), ("warnings_and_cautions", "Warnings"), ("warnings_and_precautions", "Warnings")):
        t = _clean(r.get(k), 600 if k != "boxed_warning" else 700)
        if t and not any(t[:60] == w[1][:60] for w in warn):
            warn.append((lab, t))
    wt = " | ".join(f"{a}: {b}" for a, b in warn)
    if len(wt) > WARN_MAX:
        wt = wt[:WARN_MAX].rsplit(" ", 1)[0] + " ..."
    return {"name": re.sub(r"\s+", " ", gen).strip().title(), "kind": kind, "brands": brand, "route": ", ".join(of.get("route") or []).title(),
            "uses": uses, "purpose": purpose, "warn": wt}


def merge(into, rec):
    key = (rec["name"].lower(), rec["kind"])
    cur = into.get(key)
    if cur is None:
        into[key] = rec
        return
    for b in rec["brands"]:
        if b not in cur["brands"] and len(cur["brands"]) < 10:
            cur["brands"].append(b)
    for f in ("uses", "purpose", "warn", "route"):          # keep the fullest text we have seen
        if len(rec[f]) > len(cur[f]) and (f != "uses" or len(rec[f]) > len(cur[f]) + 40):
            cur[f] = rec[f]


def partitions(u):
    j = json.loads(u.fetch(MANIFEST, 60))
    parts = j["results"]["drug"]["label"]["partitions"]
    return [(p["file"], p.get("size_mb"), p.get("records")) for p in parts]


def build(u, dest):
    src = os.path.join(dest, "tools", "meds-source")
    os.makedirs(src, exist_ok=True)
    try:
        parts = partitions(u)
    except Exception as e:  # noqa: BLE001
        print(f"  ! could not read the openFDA file list ({type(e).__name__}: {e}); need internet")
        return 0
    into, n = {}, 0
    for i, (url, mb, recs) in enumerate(parts, 1):
        fn = os.path.join(src, os.path.basename(url))
        print(f"  part {i}/{len(parts)}  (about {mb or '?'} MB zipped)")
        if not u.download(url, fn, os.path.basename(url)):
            print("  ! download failed; will retry next run")
            continue
        with zipfile.ZipFile(fn) as z:
            for name in z.namelist():
                if not name.endswith(".json"):
                    continue
                with z.open(name) as fh:
                    for r in stream_results(fh):
                        rec = _record(r)
                        if rec and (rec["uses"] or rec["warn"]):
                            merge(into, rec)
                            n += 1
                            if n % 5000 == 0:
                                print(f"\r  {n:,} labels read, {len(into):,} medicines", end="", flush=True)
        print(f"\r  {n:,} labels read, {len(into):,} medicines")
    if not into:
        return 0
    write(dest, into)
    return len(into)


def write(dest, into):
    out = os.path.join(dest, "www", "data", "meds")
    os.makedirs(out, exist_ok=True)
    for f in os.listdir(out):
        if f.endswith(".js"):
            os.remove(os.path.join(out, f))
    items = sorted(into.values(), key=lambda r: (r["name"].lower(), r["kind"]))
    shards, index = {}, []
    for r in items:
        L = r["name"][:1].lower()
        L = L if "a" <= L <= "z" else "0"
        sh = shards.setdefault(L, [])
        sh.append([r["name"], r["kind"], ", ".join(r["brands"]), r["route"], r["uses"], r["purpose"], r["warn"]])
        snippet = ((r["purpose"] + ". " if r["purpose"] else "") + r["uses"])[:200]
        index.append([r["name"], r["kind"], ", ".join(r["brands"])[:80], snippet, L, len(sh) - 1])
    for L, rows in shards.items():
        with open(os.path.join(out, f"meds-{L}.js"), "w", encoding="utf-8") as fh:
            fh.write("window.MEDS=window.MEDS||{};window.MEDS[" + json.dumps(L) + "]=" + json.dumps(rows, ensure_ascii=False, separators=(",", ":")) + ";\n")
    with open(os.path.join(out, "index.js"), "w", encoding="utf-8") as fh:
        fh.write("window.MEDS_INDEX=" + json.dumps(index, ensure_ascii=False, separators=(",", ":")) + ";\n")
    with open(os.path.join(out, "NOTICE.txt"), "w", encoding="utf-8") as fh:
        fh.write("Medicine list built from FDA drug labels (openFDA, public domain). Reference information only; it is not medical advice.\n"
                 "Labels change; check the label on the package and ask a pharmacist or doctor.\n")
    try:
        import xlsx_export
        wb = xlsx_export.Workbook(os.path.join(dest, "EXCEL-READY", "Medicines.xlsx"))
        for kind, nm in (("OTC", "Over the counter"), ("Rx", "Prescription")):
            wb.sheet(nm, ["Medicine", "Brand names", "Route", "Used for", "Purpose (OTC)", "Warnings"],
                     ([r["name"], ", ".join(r["brands"]), r["route"], r["uses"], r["purpose"], r["warn"]] for r in items if r["kind"] == kind),
                     [28, 34, 12, 60, 28, 70])
        wb.close()
    except Exception as e:  # noqa: BLE001
        print(f"  ! Excel file skipped: {type(e).__name__}: {e}")
