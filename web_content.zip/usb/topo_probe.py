"""One-quad topo download probe — finds out WHY topo sheets never persist on the drive.

Downloads a single real USGS topo quad to E:\\OFFGRID\\www\\topo\\_probe\\ using the exact
same method the builder uses (same User-Agent, same urllib streaming, same os.replace), and
reports which of these is happening:

  BLOCK      - the server refuses the request (HTTP 403/404)        -> firewall / security software
  RESET      - the transfer starts then is cut off mid-stream       -> something cutting python's downloads
  SSL        - certificate verification fails                       -> CA bundle problem
  REPLACE    - the file downloads but os.replace() fails            -> the drive/folder is locked or read-only
  VANISH     - the file is written, then disappears on its own      -> antivirus / sync tool deletes it
  OK         - the quad downloads and stays put                     -> the builder path actually works

Run it with the drive's own Python via TOPO-PROBE-WINDOWS.bat.
"""
import os, sys, time, json, ssl, urllib.request, urllib.error, glob

UA = "OffGridSurvivalUSB/1.2 (personal emergency-preparedness map builder)"
HERE = os.path.dirname(os.path.abspath(__file__))


def setup_ssl(root):
    """Mirror the builder's harden_ssl(): prefer the OS trust store, else a shipped cacert.pem."""
    try:
        import truststore
        truststore.inject_into_ssl()
        print("  certificates: using this computer's trust store"); return
    except Exception:
        pass
    for bundle in (os.path.join(HERE, "cacert.pem"),
                   os.path.join(root, "tools", "python-win", "cacert.pem"),
                   os.path.join(root, "cacert.pem")):
        if os.path.exists(bundle):
            os.environ["SSL_CERT_FILE"] = bundle
            os.environ["REQUESTS_CA_BUNDLE"] = bundle
            try:
                ssl.create_default_context(cafile=bundle)
                ssl._create_default_https_context = lambda *a, **k: ssl.create_default_context(cafile=bundle)
                print(f"  certificates: using CA bundle {bundle}"); return
            except Exception as e:
                print(f"  certificates: bundle at {bundle} did not load: {e}")
    print("  certificates: using Python's default (no bundle found)")


def pick_url(root):
    """Grab a real quad (url, title, bbox) from the drive's catalog; fall back to a known GA sheet."""
    cat = os.path.join(root, "www", "topo", "catalog.json")
    try:
        c = json.load(open(cat, encoding="utf-8"))
        quads = list((c.get("home") or {}).get("quads") or [])
        for a in (c.get("areas") or {}).values():
            quads += a.get("quads", [])
        for q in quads:
            if q.get("url"):
                return q["url"], q.get("t", "quad"), q.get("bb")
    except Exception as e:
        print(f"  (could not read catalog.json: {e})")
    return ("https://prd-tnm.s3.amazonaws.com/StagedProducts/Maps/USTopo/PDF/GA/"
            "GA_Canton_20240723_TM_geo.pdf", "Canton, GA (fallback)", [-84.625, 34.1875, -84.5, 34.25])


def fresh_url(title, bb):
    """Ask the USGS National Map API for the CURRENT download URL of this quad (tests a stale catalog)."""
    if not bb:
        return None
    w, s, e, n = bb
    import urllib.parse
    q = urllib.parse.urlencode({"datasets": "US Topo Current",
                                "bbox": f"{w:.4f},{s:.4f},{e:.4f},{n:.4f}", "max": 50, "outputFormat": "JSON"})
    try:
        with urllib.request.urlopen(urllib.request.Request(
                f"https://tnmaccess.nationalmap.gov/api/v1/products?{q}", headers={"User-Agent": UA}), timeout=60) as r:
            items = json.loads(r.read()).get("items", [])
    except Exception as e:
        print(f"  (could not reach USGS API to re-check the URL: {e})")
        return None
    want = (title or "").replace("US Topo 7.5-minute map for ", "").strip().lower()
    best = None
    for it in items:
        u = it.get("downloadURL") or ""
        if not u.lower().endswith(".pdf"):
            continue
        t = it.get("title", "").replace("US Topo 7.5-minute map for ", "").strip().lower()
        if t == want:
            return u
        best = best or u
    return best


def main():
    root = (sys.argv[1] if len(sys.argv) > 1 else r"E:\OFFGRID")
    print("=" * 68)
    print(" TOPO DOWNLOAD PROBE  — testing one sheet, the builder's exact way")
    print("=" * 68)
    print(f"  drive root: {root}")
    setup_ssl(root)

    url, title, bb = pick_url(root)
    out_dir = os.path.join(root, "www", "topo", "_probe")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "probe_" + os.path.basename(url))
    part = out + ".part"
    for p in (out, part):
        if os.path.exists(p):
            os.remove(p)
    print(f"  quad : {title}")
    print(f"  from : {url}")
    print(f"  to   : {out}")
    print("-" * 68)

    # ---- independent check 1: can we write + os.replace on this folder at all? ----
    try:
        t1, t2 = os.path.join(out_dir, "_w.tmp"), os.path.join(out_dir, "_w.ok")
        open(t1, "wb").write(b"x" * 1024)
        os.replace(t1, t2)
        ok = os.path.exists(t2)
        os.remove(t2)
        print(f"  write + os.replace test: {'OK' if ok else 'FAILED (file missing after replace)'}")
    except Exception as e:
        print(f"  write + os.replace test: FAILED -> {type(e).__name__}: {e}")
        print("\n  VERDICT: REPLACE — the drive/folder won't accept a normal file rename.")
        print("           The drive may be read-only, full, or locked by another program.")
        return

    verdict, detail = try_download(url, out, part)

    # ---- if the catalog URL was refused, the catalog may simply be out of date: re-ask USGS ----
    if verdict == "BLOCK":
        print("-" * 68)
        print("  catalog URL was refused — asking USGS for the CURRENT URL of this quad...")
        fu = fresh_url(title, bb)
        if fu and fu != url:
            print(f"  current URL: {fu}")
            v2, d2 = try_download(fu, out, part)
            if v2 == "OK":
                verdict, detail = "STALE", f"catalog URL is dead, but the current one works. Old: {url}"
            else:
                verdict, detail = v2, d2
        elif fu == url:
            print("  USGS returned the SAME URL — so it's a genuine block/refusal, not a stale catalog.")
        else:
            print("  USGS API gave no current URL for this quad (or was unreachable).")

    _report(verdict, detail, part)


def try_download(url, out, part):
    """Download one quad exactly like the builder; return (verdict, detail)."""
    for p in (out, part):
        if os.path.exists(p):
            try: os.remove(p)
            except OSError: pass
    verdict, detail = None, ""
    for attempt in range(3):
        try:
            have = os.path.getsize(part) if os.path.exists(part) else 0
            hdr = {"User-Agent": UA}
            if have:
                hdr["Range"] = f"bytes={have}-"
            req = urllib.request.Request(url, headers=hdr)
            t0 = time.time()
            with urllib.request.urlopen(req, timeout=120) as r:
                if have and r.status != 206:
                    have = 0
                total = int(r.headers.get("Content-Length") or 0) + have
                with open(part, "ab" if have else "wb") as fh:
                    got = have
                    while True:
                        b = r.read(1 << 20)
                        if not b:
                            break
                        fh.write(b); got += len(b)
                        pct = (100 * got / total) if total else 0
                        print(f"\r  downloading: {got/1e6:6.1f} MB"
                              + (f" / {total/1e6:.1f} MB ({pct:3.0f}%)" if total else "")
                              + f"   {got/1e6/max(time.time()-t0,0.1):5.1f} MB/s", end="", flush=True)
            print()
            size = os.path.getsize(part)
            print(f"  stream finished: {size/1e6:.1f} MB in {time.time()-t0:.0f}s")
            os.replace(part, out)                         # the step that should create the final .pdf
            time.sleep(1)
            if not os.path.exists(out):
                verdict, detail = "VANISH", "file written by os.replace, then gone within 1 second"
                break
            time.sleep(3)                                 # watch for a delayed delete (real-time AV scan)
            if not os.path.exists(out):
                verdict, detail = "VANISH", "file survived the write but was deleted ~3s later"
                break
            final = os.path.getsize(out)
            head = open(out, "rb").read(5)
            verdict = "OK"
            detail = f"{final/1e6:.1f} MB on disk, starts with {head!r} (a real PDF starts with b'%PDF-')"
            break
        except urllib.error.HTTPError as e:
            print(f"\n  ! HTTP {e.code} {e.reason}")
            if e.code in (401, 403, 404, 410):
                verdict, detail = "BLOCK", f"server returned HTTP {e.code} {e.reason}"
                break
            detail = f"HTTP {e.code}"; time.sleep(3)
        except ssl.SSLError as e:
            verdict, detail = "SSL", f"{type(e).__name__}: {e}"; break
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            inner = getattr(e, "reason", e)
            print(f"\n  ! transfer error (attempt {attempt+1}/3): {type(e).__name__}: {inner}")
            verdict, detail = "RESET", f"{type(e).__name__}: {inner}"
            time.sleep(3)
        except Exception as e:  # noqa: BLE001
            verdict, detail = "RESET", f"{type(e).__name__}: {e}"
            print(f"\n  ! {type(e).__name__}: {e}"); time.sleep(3)
    return verdict, detail


def _report(verdict, detail, part):
    print("-" * 68)
    msgs = {
        "OK":      "OK — the quad downloaded and stayed put. The builder path works from here;\n"
                   "           if a full build still shows 0, the earlier builds were interrupted before topo.",
        "STALE":   "STALE CATALOG — the saved URL is dead (USGS replaced that edition), but the CURRENT\n"
                   "           URL downloads fine. The fix is to refresh the topo catalog so the builder\n"
                   "           uses today's URLs. Tell me this verdict and I'll ship that fix.",
        "BLOCK":   "BLOCK — the server refused the request even after re-checking the current URL. A\n"
                   "           firewall, security product, VPN or the ISP is blocking the USGS download host.",
        "RESET":   "RESET — the transfer was cut off mid-stream (not a block, not antivirus). Something\n"
                   "           between python.exe and the server is dropping the connection: HTTPS/SSL\n"
                   "           inspection in a security product, a VPN/proxy, or an unstable link.",
        "SSL":     "SSL — certificate verification failed. The CA bundle isn't being picked up.",
        "REPLACE": "REPLACE — the download works but the drive won't keep the renamed file.",
        "VANISH":  "VANISH — the file is written to the drive, then an outside program deletes it\n"
                   "           (antivirus or a cloud-sync client). Add an exclusion for E:\\OFFGRID.",
    }
    print(f"  VERDICT: {msgs.get(verdict, 'UNKNOWN — ' + str(detail))}")
    if detail and verdict not in ("OK",):
        print(f"  detail : {detail}")
    if os.path.exists(part):
        try: os.remove(part)
        except OSError: pass
    print("=" * 68)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  (stopped)")
