"""Home-region helper: turn a ZIP code into the place, the nearby states and the map areas the builder should use.

  python region.py 30115            -> prints what the builder would use (needs internet for the ZIP lookup)

Lookup order (first that works): zippopotam.us, the Census ZIP gazetteer, then asking for 'City, ST' (bundled city list),
then typing latitude, longitude. Nothing is bypassed or guessed: if a step fails the next one is tried and you are shown the answer to confirm.
"""
import csv, io, json, os, re, sys, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
UA = "Mozilla/5.0 (OFFGRID drive builder)"

# abbr: (name, neighbours)
ST = {
 "AL": ("Alabama", "FL GA MS TN"), "AK": ("Alaska", ""), "AZ": ("Arizona", "CA CO NM NV UT"), "AR": ("Arkansas", "LA MO MS OK TN TX"),
 "CA": ("California", "AZ NV OR"), "CO": ("Colorado", "AZ KS NE NM OK UT WY"), "CT": ("Connecticut", "MA NY RI"), "DE": ("Delaware", "MD NJ PA"),
 "DC": ("District of Columbia", "MD VA"), "FL": ("Florida", "AL GA"), "GA": ("Georgia", "AL FL NC SC TN"), "HI": ("Hawaii", ""),
 "ID": ("Idaho", "MT NV OR UT WA WY"), "IL": ("Illinois", "IA IN KY MO WI"), "IN": ("Indiana", "IL KY MI OH"), "IA": ("Iowa", "IL MN MO NE SD WI"),
 "KS": ("Kansas", "CO MO NE OK"), "KY": ("Kentucky", "IL IN MO OH TN VA WV"), "LA": ("Louisiana", "AR MS TX"), "ME": ("Maine", "NH"),
 "MD": ("Maryland", "DE DC PA VA WV"), "MA": ("Massachusetts", "CT NH NY RI VT"), "MI": ("Michigan", "IN OH WI"), "MN": ("Minnesota", "IA ND SD WI"),
 "MS": ("Mississippi", "AL AR LA TN"), "MO": ("Missouri", "AR IA IL KS KY NE OK TN"), "MT": ("Montana", "ID ND SD WY"), "NE": ("Nebraska", "CO IA KS MO SD WY"),
 "NV": ("Nevada", "AZ CA ID OR UT"), "NH": ("New Hampshire", "MA ME VT"), "NJ": ("New Jersey", "DE NY PA"), "NM": ("New Mexico", "AZ CO OK TX UT"),
 "NY": ("New York", "CT MA NJ PA VT"), "NC": ("North Carolina", "GA SC TN VA"), "ND": ("North Dakota", "MN MT SD"), "OH": ("Ohio", "IN KY MI PA WV"),
 "OK": ("Oklahoma", "AR CO KS MO NM TX"), "OR": ("Oregon", "CA ID NV WA"), "PA": ("Pennsylvania", "DE MD NJ NY OH WV"), "RI": ("Rhode Island", "CT MA"),
 "SC": ("South Carolina", "GA NC"), "SD": ("South Dakota", "IA MN MT ND NE WY"), "TN": ("Tennessee", "AL AR GA KY MO MS NC VA"),
 "TX": ("Texas", "AR LA NM OK"), "UT": ("Utah", "AZ CO ID NM NV WY"), "VT": ("Vermont", "MA NH NY"), "VA": ("Virginia", "DC KY MD NC TN WV"),
 "WA": ("Washington", "ID OR"), "WV": ("West Virginia", "KY MD OH PA VA"), "WI": ("Wisconsin", "IA IL MI MN"), "WY": ("Wyoming", "CO ID MT NE SD UT"),
}
NAME2AB = {v[0].lower(): k for k, v in ST.items()}


def _get(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _zip_zippopotam(z):
    j = json.loads(_get(f"https://api.zippopotam.us/us/{z}", 15))
    p = j["places"][0]
    return float(p["latitude"]), float(p["longitude"]), p["place name"], p["state abbreviation"].upper()


def _zip_census(z):
    """Census ZCTA gazetteer: gives the centre point only (no place name); the place name then comes from the nearest bundled city."""
    raw = _get("https://www2.census.gov/geo/docs/maps-data/data/gazetteer/2023_Gazetteer/2023_Gaz_zcta_national.zip", 90)
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        txt = zf.read(zf.namelist()[0]).decode("utf-8", "replace")
    for row in csv.reader(io.StringIO(txt), delimiter="\t"):
        if row and row[0].strip() == z:
            lat, lon = float(row[-2]), float(row[-1])
            c = nearest_city(lat, lon)
            return lat, lon, c[0], c[1]
    raise KeyError(z)


def cities():
    out = []
    try:
        with open(os.path.join(HERE, "data", "us-cities.csv"), encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                try:
                    out.append((r.get("city") or r.get("City") or r[list(r)[0]], (r.get("state_id") or r.get("state") or r[list(r)[1]]).upper(),
                                float(r.get("lat") or r.get("latitude") or r[list(r)[4]]), float(r.get("lng") or r.get("lon") or r.get("longitude") or r[list(r)[5]])))
                except (ValueError, KeyError, IndexError):
                    continue
    except OSError:
        pass
    return out


def nearest_city(lat, lon):
    best = None
    for c, s, la, lo in cities():
        d = (la - lat) ** 2 + ((lo - lon) * 0.8) ** 2
        if best is None or d < best[0]:
            best = (d, c, s)
    return (best[1], best[2]) if best else ("Home", "")


def lookup_zip(z):
    """-> (lat, lon, city, state_abbr) or None."""
    for fn in (_zip_zippopotam, _zip_census):
        try:
            return fn(z)
        except Exception as e:      # noqa: BLE001  network, bad ZIP, format change: try the next source
            print(f"  (ZIP lookup via {fn.__name__[5:]} didn't work: {str(e)[:70]})")
    return None


def lookup_city(text):
    """'Canton, GA' -> (lat, lon, city, ST) from the bundled city list."""
    m = re.match(r"\s*(.+?)\s*,\s*([A-Za-z]{2})\s*$", text or "")
    if not m:
        return None
    nm, st = m.group(1).lower(), m.group(2).upper()
    for c, s, la, lo in cities():
        if s == st and c.lower() == nm:
            return la, lo, c, s
    return None


def ask_home(input_fn=input):
    """Interactive: ZIP code -> confirm -> (lat, lon, label, state). Falls back to 'City, ST' then 'lat, lon'."""
    while True:
        z = input_fn("\nType your 5-digit ZIP code (this is your 'home' - maps, weather, hospitals and guides are built around it): ").strip()
        hit = None
        if re.fullmatch(r"\d{5}", z):
            print("  Looking it up...")
            hit = lookup_zip(z)
        if not hit:
            t = input_fn("  Could not look that ZIP up. Type  City, ST  (for example Canton, GA) or  latitude, longitude  (or Enter to retry): ").strip()
            if not t:
                continue
            hit = lookup_city(t)
            if not hit:
                m = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$", t)
                if m:
                    la, lo = float(m.group(1)), float(m.group(2))
                    c = nearest_city(la, lo)
                    hit = (la, lo, c[0], c[1])
            if hit:
                z = z if re.fullmatch(r"\d{5}", z) else ""
        if not hit:
            print("  Still not found - try again.")
            continue
        lat, lon, city, st = hit
        label = (f"ZIP {z} " if z else "") + f"({city}, {st})"
        print(f"\n  Home = {label}   [{lat:.4f}, {lon:.4f}]   state: {ST.get(st, (st,))[0]}")
        if input_fn("  Is that right? (Y/N): ").strip().lower().startswith("y"):
            return lat, lon, label, st, z


def regions(state, profile):
    """Geofabrik region names for the profile: home state, its neighbours (large), and their neighbours (full, capped at 9)."""
    if state not in ST:
        return ""
    n1 = [s for s in ST[state][1].split()]
    ring = [state] + n1
    if profile == "full":
        n2 = []
        for s in n1:
            for t in ST[s][1].split():
                if t not in ring and t not in n2:
                    n2.append(t)
        ring = (ring + n2)[:9]
    elif profile in ("small", "medium"):
        ring = [state]
    elif profile == "micro":
        return ""
    return ",".join(ST[s][0].lower().replace(" ", "-") for s in ring if s != "AK" and s != "HI") if state not in ("AK", "HI") else ST[state][0].lower()


def area_states(state):
    """Lower-case state abbreviations for the city / base topo-map lists: home, neighbours and their neighbours."""
    if state not in ST:
        return None
    ring = {state, *ST[state][1].split()}
    for s in list(ring):
        ring.update(ST[s][1].split())
    return sorted(s.lower() for s in ring)


def region_bbox(lat, lon, dlat=4.5, dlon=6.0):
    """West, south, east, north of the regional topo layer (about 300 miles each way)."""
    return (max(-170.0, lon - dlon), max(15.0, lat - dlat), min(-60.0, lon + dlon), min(72.0, lat + dlat))


# ---- make the drive's pages say the user's home instead of the author's (only when the home was changed) ------------------
OLD = (34.2367, -84.4908)


def localize(dest, opts):
    """Rewrite the author-home text in the copied pages: 'Canton, GA' etc. Safe to run on every build; no change for the default home."""
    lat, lon = opts.get("lat"), opts.get("lon")
    if lat is None or abs(lat - 34.2387) + abs(lon + 84.4513) < 0.05:
        return 0
    label = opts.get("label") or "Home"
    m = re.search(r"\((.+?),\s*([A-Z]{2})\)", label)
    city, st = (m.group(1), m.group(2)) if m else ("Home", opts.get("state", ""))
    sname = ST.get(st, (st,))[0]
    short = f"{city}, {st}" if st else city
    www = os.path.join(dest, "www")
    n = 0
    subs = [("a family in Canton, Georgia", f"a family in {city}, {sname}" if sname else "a family"),
            ("Home (Canton, GA)", f"Home ({short})"), ('"Canton (home), GA"', json.dumps("Home — " + label, ensure_ascii=False)), ('startsWith("Canton (home)")', 'startsWith("Home —")'), ("Canton, GA", short),
            ("[34.2367,-84.4908]", f"[{lat:.4f},{lon:.4f}]"), ("34.2367, -84.4908", f"{lat:.4f}, {lon:.4f}")]
    for fn in ("ask.html", "coords.html", "declination.html", "calculators.html", "home.html", "command.html", "index.html", "topics.html"):
        p = os.path.join(www, fn)
        try:
            t = open(p, encoding="utf-8").read()
        except OSError:
            continue
        o = t
        for a, b in subs:
            t = t.replace(a, b)
        t = t.replace("(34° in Canton)", f"({round(lat)}° at your home)")
        t = re.sub(r'[ \t]*<a class="card" href="library/Getting Home/getting_home.html">.*?</a>\n?', "", t, flags=re.S)
        t = re.sub(r'[ \t]*\{ t: "🚗 Getting home from a work trip".*?Getting home: pick your city[^\n]*?\] \},?\n?', "", t, flags=re.S)
        t = re.sub(r"Plan to arrive with a quarter tank\.[^<]*?road miles\)\.", "Plan to arrive with a quarter tank.", t)
        if t != o:
            with open(p, "w", encoding="utf-8", newline="") as fh:
                fh.write(t)
            n += 1
    return n


if __name__ == "__main__":
    if len(sys.argv) > 1:
        h = lookup_zip(sys.argv[1])
        print(h)
        if h:
            print(regions(h[3], "full"), area_states(h[3]), region_bbox(h[0], h[1]))
    else:
        print(ask_home())
