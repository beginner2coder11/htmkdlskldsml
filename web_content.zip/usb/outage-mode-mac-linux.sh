#!/bin/sh
# ===== OFF-GRID SURVIVAL DRIVE — OUTAGE MODE (macOS / Linux) =====
# Power is out: start the drive with the smallest AI, shorter AI memory, half the CPU and no graphics card,
# switch to power saving where the system allows it, optionally turn Wi-Fi off. Everything goes back when you stop.
cd "$(dirname "$0")" || exit 1
OS=$(uname -s)
echo "OUTAGE MODE - make the battery last"
if [ "$OS" = Darwin ]; then
  pmset -g batt 2>/dev/null | grep -o '[0-9]*%' | head -1 | sed 's/^/  Battery now: /'
  echo "  Tip: System Settings > Battery > Low Power Mode saves the most (needs your password, so it is not switched here)."
  WIF=$(networksetup -listallhardwareports 2>/dev/null | awk '/Wi-Fi|AirPort/{getline; print $2; exit}')
else
  for b in /sys/class/power_supply/BAT*/capacity; do [ -f "$b" ] && echo "  Battery now: $(cat "$b")%"; done
  OLDPROF=""
  if command -v powerprofilesctl >/dev/null 2>&1; then
    OLDPROF=$(powerprofilesctl get 2>/dev/null)
    powerprofilesctl set power-saver 2>/dev/null && echo "  Power profile: power-saver"
  fi
fi
printf "Turn Wi-Fi OFF to save battery? Phones on this Wi-Fi will lose the drive. Type YES, or press Enter to keep it: "
read W
WIFIOFF=""
if [ "$W" = YES ] || [ "$W" = yes ]; then
  if [ "$OS" = Darwin ] && [ -n "$WIF" ]; then networksetup -setairportpower "$WIF" off && WIFIOFF=1
  elif command -v nmcli >/dev/null 2>&1; then nmcli radio wifi off && WIFIOFF=1
  fi
  [ -n "$WIFIOFF" ] && echo "  Wi-Fi is off." || echo "  Could not switch Wi-Fi off here - use the Wi-Fi menu."
fi
restore() {
  echo "Putting the computer back to normal..."
  [ "$OS" != Darwin ] && [ -n "$OLDPROF" ] && powerprofilesctl set "$OLDPROF" 2>/dev/null
  if [ -n "$WIFIOFF" ]; then
    printf "Turn Wi-Fi back ON? Type YES, or press Enter to leave it off: "; read W
    if [ "$W" = YES ] || [ "$W" = yes ]; then
      if [ "$OS" = Darwin ]; then networksetup -setairportpower "$WIF" on; else nmcli radio wifi on; fi
    fi
  fi
}
trap ':' INT          # Ctrl+C stops the drive below, then this script still puts the computer back
S=PROGRAMS/start-mac-linux.sh; [ -f "$S" ] || S=./start-mac-linux.sh
OFFGRID_MODE=outage sh "$S"
restore
