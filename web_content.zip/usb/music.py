"""Music for downtime: organize a folder (or drive) of songs and build an offline player page.

  1. PLAN    python music.py --dest E:\\OFFGRID --src F:\\Music     (reads only; writes REPORTS\\MUSIC-PLAN.csv + .html)
  2. CHECK   open REPORTS\\MUSIC-PLAN.html; fix names in MUSIC-PLAN.csv if you like (Excel is fine)
  3. APPLY   python music.py --dest E:\\OFFGRID --apply copy         (or "move")
  4. LISTEN  Home ▸ Music  (artists, albums, songs, genres, search, queue, shuffle, playlists)

Names come from the songs' own tags (ID3 in MP3, FLAC, M4A/AAC), then from the folders they're in:
  www\\music\\Music\\Artist\\Album (Year)\\01 - Title.mp3       Kids Music\\…  (from a folder named Kids, Children…)
Album art is saved as cover.jpg in each album folder. Nothing is overwritten; "move" deletes an original only after
its copy is verified. Re-run with --catalog-only after adding songs by hand. Standard library only.
"""
import argparse, csv, html, json, os, re, shutil, struct, sys, time, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from media import copy_file, safe, KIDS  # noqa: E402

AUDIO = {".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wav", ".wma", ".alac", ".aiff", ".aif", ".mka"}
WEB_OK = {".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wav"}
CATS = ("Music", "Kids Music")
COVERS = ("cover.jpg", "folder.jpg", "front.jpg", "albumart.jpg", "cover.png", "folder.png", "albumartsmall.jpg")
GENERIC = re.compile(r"(?i)^(music|my music|mp3s?|songs|audio|itunes( media| music)?|media|downloads?|new folder|unknown( artist| album)?|various|cd ?\d*|disc ?\d*|unsorted|untagged|misc|other|collection|library|music library|albums?|artists?)$")


# --------------------------------------------------------------------------- tags (no add-ons needed)
def _txt(b, enc):
    codec = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(enc, "latin-1")
    try:
        s = b.decode(codec, "replace")
    except LookupError:
        s = b.decode("latin-1", "replace")
    return s.split("\x00")[0].strip("\ufeff ").strip()


def id3(path):
    tags, art = {}, None
    with open(path, "rb") as f:
        h = f.read(10)
        if len(h) == 10 and h[:3] == b"ID3":
            ver, flags = h[3], h[5]
            size = (h[6] << 21) | (h[7] << 14) | (h[8] << 7) | h[9]
            data = f.read(size)
            if flags & 0x40 and ver == 3 and len(data) > 4:       # extended header
                data = data[4 + struct.unpack(">I", data[:4])[0]:]
            i = 0
            names = {"TIT2": "title", "TPE1": "artist", "TPE2": "albumartist", "TALB": "album", "TRCK": "track", "TPOS": "disc",
                     "TYER": "year", "TDRC": "year", "TCON": "genre", "TT2": "title", "TP1": "artist", "TP2": "albumartist",
                     "TAL": "album", "TRK": "track", "TYE": "year", "TCO": "genre", "TPA": "disc"}
            while i < len(data) - 10:
                if ver == 2:
                    fid, fs, hl = data[i:i + 3].decode("latin-1"), int.from_bytes(data[i + 3:i + 6], "big"), 6
                else:
                    fid = data[i:i + 4].decode("latin-1", "replace")
                    raw = data[i + 4:i + 8]
                    fs = ((raw[0] << 21) | (raw[1] << 14) | (raw[2] << 7) | raw[3]) if ver == 4 else struct.unpack(">I", raw)[0]
                    hl = 10
                if not fid.strip("\x00") or fs <= 0 or i + hl + fs > len(data):
                    break
                body = data[i + hl:i + hl + fs]
                if fid in names and body:
                    tags.setdefault(names[fid], _txt(body[1:], body[0]))
                elif fid in ("APIC", "PIC") and art is None and body:
                    enc = body[0]
                    if fid == "PIC":
                        rest = body[5:]
                    else:
                        z = body.index(b"\x00", 1)
                        rest = body[z + 2:]                     # skip mime + picture type
                    term = b"\x00\x00" if enc in (1, 2) else b"\x00"
                    k = rest.find(term)
                    if enc in (1, 2):
                        while k >= 0 and k % 2:
                            k = rest.find(term, k + 1)
                    img = rest[k + len(term):] if k >= 0 else b""
                    if img[:3] == b"\xff\xd8\xff" or img[:8] == b"\x89PNG\r\n\x1a\n":
                        art = img
                i += hl + fs
        if not tags.get("title"):
            try:
                f.seek(-128, 2)
                t = f.read(128)
                if t[:3] == b"TAG":
                    g = lambda a, b: t[a:b].split(b"\x00")[0].decode("latin-1").strip()  # noqa: E731
                    tags = {"title": g(3, 33), "artist": g(33, 63), "album": g(63, 93), "year": g(93, 97), **tags}
                    if t[125] == 0 and t[126]:
                        tags.setdefault("track", str(t[126]))
            except OSError:
                pass
    return {k: v for k, v in tags.items() if v}, art


def flac(path):
    tags, art = {}, None
    with open(path, "rb") as f:
        if f.read(4) != b"fLaC":
            return tags, art
        last = False
        while not last:
            h = f.read(4)
            if len(h) < 4:
                break
            last, kind, n = bool(h[0] & 0x80), h[0] & 0x7F, int.from_bytes(h[1:4], "big")
            body = f.read(n)
            if kind == 4:   # VORBIS_COMMENT
                vl = struct.unpack("<I", body[:4])[0]; p = 4 + vl
                cnt = struct.unpack("<I", body[p:p + 4])[0]; p += 4
                for _ in range(cnt):
                    ln = struct.unpack("<I", body[p:p + 4])[0]; p += 4
                    k, _, v = body[p:p + ln].decode("utf-8", "replace").partition("="); p += ln
                    k = {"TITLE": "title", "ARTIST": "artist", "ALBUMARTIST": "albumartist", "ALBUM ARTIST": "albumartist", "ALBUM": "album",
                         "TRACKNUMBER": "track", "DISCNUMBER": "disc", "DATE": "year", "YEAR": "year", "GENRE": "genre"}.get(k.upper())
                    if k and v:
                        tags.setdefault(k, v.strip())
            elif kind == 6 and art is None:   # PICTURE
                p = 4
                ml = struct.unpack(">I", body[p:p + 4])[0]; p += 4 + ml
                dl = struct.unpack(">I", body[p:p + 4])[0]; p += 4 + dl + 16
                il = struct.unpack(">I", body[p:p + 4])[0]; p += 4
                art = body[p:p + il]
    return tags, art


def mp4(path):
    tags, art = {}, None
    want = {b"\xa9nam": "title", b"\xa9ART": "artist", b"aART": "albumartist", b"\xa9alb": "album", b"\xa9day": "year",
            b"\xa9gen": "genre", b"trkn": "track", b"disk": "disc", b"covr": "art"}
    with open(path, "rb") as f:
        end = os.path.getsize(path)

        def walk(start, stop, depth):
            nonlocal art
            pos = start
            while pos + 8 <= stop and depth < 8:
                f.seek(pos)
                h = f.read(8)
                if len(h) < 8:
                    return
                size, typ = struct.unpack(">I", h[:4])[0], h[4:8]
                hl = 8
                if size == 1:
                    size, hl = struct.unpack(">Q", f.read(8))[0], 16
                elif size == 0:
                    size = stop - pos
                if size < hl:
                    return
                if typ in (b"moov", b"udta", b"ilst", b"trak", b"mdia"):
                    walk(pos + hl, pos + size, depth + 1)
                elif typ == b"meta":
                    walk(pos + hl + 4, pos + size, depth + 1)
                elif typ in want and size < 20_000_000:
                    f.seek(pos + hl)
                    blob = f.read(size - hl)
                    j = blob.find(b"data")
                    if j >= 4:
                        val = blob[j + 12:j - 4 + struct.unpack(">I", blob[j - 4:j])[0]]
                        k = want[typ]
                        if k == "art":
                            art = art or val
                        elif k in ("track", "disc") and len(val) >= 4:
                            tags.setdefault(k, str(struct.unpack(">H", val[2:4])[0]))
                        else:
                            tags.setdefault(k, val.decode("utf-8", "replace").strip())
                pos += size
        try:
            walk(0, end, 0)
        except (OSError, struct.error):
            pass
    return {k: v for k, v in tags.items() if v and v != "0"}, art


def read_tags(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".mp3":
            return id3(path)
        if ext == ".flac":
            return flac(path)
        if ext in (".m4a", ".aac", ".alac", ".mp4"):
            return mp4(path)
    except (OSError, ValueError, struct.error, IndexError):
        pass
    return {}, None


# --------------------------------------------------------------------------- guessing from names and folders
def _num(s):
    m = re.match(r"\s*(\d+)", str(s or ""))
    return int(m.group(1)) if m else 0


def parse(path, root):
    rel = os.path.relpath(path, root).split(os.sep)
    folders, fname = rel[:-1], rel[-1]
    stem, ext = os.path.splitext(fname)
    tags, art = read_tags(path)
    kids = any(KIDS.match(x.strip()) or re.match(r"(?i)^kids? music$", x.strip()) for x in folders)
    real = [x for x in folders if not GENERIC.match(x.strip()) and not KIDS.match(x.strip()) and not re.match(r"(?i)^kids? music$", x.strip())]
    disc_dir = real and re.match(r"(?i)^(cd|disc|disk)\s*(\d+)$", real[-1])
    if disc_dir:
        real = real[:-1]
    # file name: "01 - Artist - Title", "01. Title", "Artist - Title"
    n = re.match(r"^\s*(\d{1,3})(?:[\s._-]+|$)(.*)$", stem)
    ftrack, rest = (int(n.group(1)), n.group(2)) if n and int(n.group(1)) < 200 else (0, stem)
    rest = re.sub(r"[_]+", " ", rest).strip(" -.")
    fartist, ftitle = "", rest
    if " - " in rest:
        a, _, b = rest.partition(" - ")
        fartist, ftitle = a.strip(), b.strip()
    album_dir = real[-1] if real else ""
    artist_dir = real[-2] if len(real) >= 2 else ""
    ad = re.match(r"^(.*?)\s+[-–]\s+(.+)$", album_dir) if album_dir else None
    if ad and (not artist_dir or ad.group(1).lower() == artist_dir.lower()):   # "Artist - Album" folder
        artist_dir, album_dir = ad.group(1), ad.group(2)
    ym = re.search(r"[\[(]?((?:19|20)\d\d)[\])]?", album_dir)
    dyear = ym.group(1) if ym else ""
    album_clean = re.sub(r"\s*[\[(]\s*(?:19|20)\d\d\s*[\])]\s*|^\s*(?:19|20)\d\d\s*[-–.]\s*", " ", album_dir).strip()
    it = {
        "artist": tags.get("albumartist") or tags.get("artist") or artist_dir or fartist or "Unknown Artist",
        "trackartist": tags.get("artist") or fartist or "",
        "album": tags.get("album") or album_clean or "Singles",
        "year": (re.search(r"(19|20)\d\d", tags.get("year", "")) or [dyear])[0] if tags.get("year") else dyear,
        "track": str(_num(tags.get("track")) or ftrack or ""),
        "disc": str(_num(tags.get("disc")) or (int(disc_dir.group(2)) if disc_dir else "") or ""),
        "title": tags.get("title") or ftitle or stem,
        "genre": re.sub(r"^\((\d+)\)$", "", tags.get("genre", "")),
        "kids": "yes" if kids else "", "source": path, "ext": ext.lower(), "note": "",
    }
    if not tags:
        it["note"] = "no tags: named from folders" if folders else "check: no tags or folders"
    if it["artist"] == "Unknown Artist":
        it["note"] = "check: artist"
    return it, art


def target(it, lib):
    kids = str(it.get("kids", "")).lower() in ("yes", "y", "1", "true", "x")
    artist = safe(it["artist"])[:80]
    album = safe(it["album"])[:80]
    if it.get("year") and it["album"] != "Singles":
        album = f"{album} ({it['year']})"
    t = _num(it.get("track"))
    d = _num(it.get("disc"))
    pre = (f"{d}-" if d > 1 else "") + (f"{t:02d} - " if t else "")
    ta = it.get("trackartist", "")
    title = safe(it["title"])[:100]
    if ta and ta != it["artist"] and it["artist"].lower() in ("various artists", "various", "soundtrack"):
        title = safe(f"{ta} - {it['title']}")[:110]
    ext = it.get("ext") or os.path.splitext(it["source"])[1].lower()
    return os.path.join(lib, "Kids Music" if kids else "Music", artist, album, pre + title + ext)


FIELDS = ["action", "artist", "album", "year", "disc", "track", "title", "trackartist", "genre", "kids", "note", "size_mb", "source", "target"]


def scan(src, skip):
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not d.startswith((".", "$")) and d.lower() != "system volume information"
                   and os.path.realpath(os.path.join(root, d)) not in skip]
        for f in files:
            if os.path.splitext(f)[1].lower() in AUDIO and not f.startswith("._"):
                yield os.path.join(root, f)


def plan(src, dest, lib, out):
    rows, seen = [], {}
    n = 0
    for p in scan(src, {os.path.realpath(lib)}):
        it, _ = parse(p, src)
        size = os.path.getsize(p)
        it["size_mb"] = f"{size / 1e6:.1f}"
        it["target"] = target(it, lib)
        it["action"] = "skip" if os.path.exists(it["target"]) and os.path.getsize(it["target"]) == size else "add"
        if it["action"] == "skip":
            it["note"] = "already on the drive"
        elif it["target"] in seen:
            it["note"] = "check: same name as another song"
        seen[it["target"]] = 1
        rows.append(it)
        n += 1
        if n % 500 == 0:
            print(f"\r  read {n:,} songs…", end="", flush=True)
    if n >= 500:
        print()
    years = {}                                   # songs of one album without a year tag join the album's folder
    for r in rows:
        if r["year"]:
            years.setdefault((r["artist"].lower(), r["album"].lower()), r["year"])
    for r in rows:
        y = years.get((r["artist"].lower(), r["album"].lower()))
        if not r["year"] and y and r["action"] == "add":
            r["year"] = y
            r["target"] = target(r, lib)
    rows.sort(key=lambda r: (r["artist"].lower(), r["album"].lower(), _num(r["disc"]), _num(r["track"]), r["title"].lower()))
    with open(out + ".csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, FIELDS, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    add = [r for r in rows if r["action"] == "add"]
    gb = sum(float(r["size_mb"]) for r in add) / 1000
    chk = [r for r in rows if "check" in r["note"]]
    artists = len({r["artist"] for r in add}); albums = len({(r["artist"], r["album"]) for r in add})
    free = shutil.disk_usage(dest).free / 1e9
    show = sorted(rows, key=lambda r: "check" not in r["note"])[:3000]
    tr = "".join(f"<tr class='{'chk' if 'check' in r['note'] else ''}'><td>{html.escape(r['note'])}</td>"
                 f"<td>{html.escape(os.path.relpath(r['target'], lib))}</td><td>{html.escape(r['source'])}</td></tr>" for r in show)
    with open(out + ".html", "w", encoding="utf-8") as fh:
        fh.write(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Music plan</title><style>
body{{font:14px/1.45 system-ui;background:#14171a;color:#e6e8eb;padding:14px}}td,th{{border-bottom:1px solid #2c323a;padding:4px 6px;text-align:left;vertical-align:top}}
table{{border-collapse:collapse;width:100%}}.chk td:first-child{{color:#f0b429;font-weight:600}}.warn{{background:#3a2a10;padding:8px;border-radius:6px}}</style></head><body>
<h1>Music — what will happen</h1>
<p><b>{len(add):,}</b> songs on <b>{albums:,}</b> albums by <b>{artists:,}</b> artists to add ({gb:,.1f} GB). Drive has {free:,.0f} GB free.
{len(rows) - len(add):,} already on the drive. <b>{len(chk)}</b> marked <span style="color:#f0b429">check</span> (listed first).</p>
{"<p class='warn'>Not enough space for all of it — set some rows' action to skip in MUSIC-PLAN.csv.</p>" if gb > free - 10 else ""}
<p>To fix names: open <b>REPORTS\\MUSIC-PLAN.csv</b> in Excel or Notepad, change <i>artist, album, year, track, title</i> or <i>kids</i>
(yes / blank), or set <i>action</i> to <i>skip</i>, and save as CSV. The new location is rebuilt from your changes.</p>
<table><tr><th>Note</th><th>Will be saved as</th><th>From</th></tr>{tr}</table>
{"<p>(first 3,000 rows shown — all of them are in the CSV)</p>" if len(rows) > 3000 else ""}</body></html>""")
    print(f"  {len(add):,} songs, {albums:,} albums, {artists:,} artists to add ({gb:,.1f} GB; {free:,.0f} GB free). {len(chk)} to check.")
    print(f"  Plan: {out}.html")


def apply(csv_path, lib, mode, dest):
    rows = [r for r in csv.DictReader(open(csv_path, encoding="utf-8-sig")) if r.get("action", "add").strip().lower() not in ("skip", "no", "")]
    need = sum(os.path.getsize(r["source"]) for r in rows if os.path.exists(r["source"]))
    if mode == "copy" and need / 1e9 > shutil.disk_usage(dest).free / 1e9 - 10:
        print(f"  ! needs {need / 1e9:,.1f} GB, only {shutil.disk_usage(dest).free / 1e9:,.0f} GB free (keeping 10 GB spare)."); return
    ok = bad = 0
    log = open(os.path.join(lib, "organize-log.txt"), "a", encoding="utf-8")
    for i, r in enumerate(rows, 1):
        src = r["source"]
        if not os.path.exists(src):
            continue
        r["ext"] = os.path.splitext(src)[1].lower()
        dst = target(r, lib)
        size = os.path.getsize(src)
        if os.path.exists(dst):
            if os.path.getsize(dst) == size:
                continue
            b, e = os.path.splitext(dst); k = 2
            while os.path.exists(f"{b} ({k}){e}"):
                k += 1
            dst = f"{b} ({k}){e}"
        try:
            copy_file(src, dst, size)
            adir = os.path.dirname(dst)
            if not any(os.path.exists(os.path.join(adir, c)) for c in COVERS):
                sdir = os.path.dirname(src)
                found = next((os.path.join(sdir, c) for c in os.listdir(sdir) if c.lower() in COVERS), None)
                if found:
                    shutil.copy2(found, os.path.join(adir, "cover" + os.path.splitext(found)[1].lower()))
                else:
                    _, art = read_tags(src)
                    if art:
                        with open(os.path.join(adir, "cover.png" if art[:4] == b"\x89PNG" else "cover.jpg"), "wb") as fh:
                            fh.write(art)
            if mode == "move":
                os.remove(src)
            log.write(f"{time.strftime('%Y-%m-%d %H:%M')}\t{mode}\t{src}\t{dst}\n")
            ok += 1
            if ok % 100 == 0:
                print(f"\r  {ok:,} of {len(rows):,} songs…", end="", flush=True)
        except OSError as e:
            bad += 1
            print(f"\n  ! {src}: {e}")
    log.close()
    print(f"\n  {ok:,} songs {'moved' if mode == 'move' else 'copied'}{f', {bad} failed' if bad else ''}.")


def catalog(dest, lib):
    """www/music/catalog.js + index.html from the Music and Kids Music folders."""
    www = os.path.join(dest, "www")
    page_dir = os.path.join(www, "music")
    os.makedirs(page_dir, exist_ok=True)
    inside = os.path.realpath(lib).startswith(os.path.realpath(www) + os.sep)

    def href(p):
        if inside:
            return urllib.parse.quote(os.path.relpath(p, page_dir).replace(os.sep, "/"))
        return "file:///" + urllib.parse.quote(os.path.abspath(p).replace(os.sep, "/").lstrip("/"))
    cache_p = os.path.join(page_dir, "tags-cache.json")
    try:
        cache = json.load(open(cache_p, encoding="utf-8"))
    except (OSError, ValueError):
        cache = {}
    newcache, albums, songs, gb = {}, [], [], 0.0
    for cat in CATS:
        base = os.path.join(lib, cat)
        if not os.path.isdir(base):
            continue
        for root, _, files in os.walk(base):
            tracks = sorted(f for f in files if os.path.splitext(f)[1].lower() in AUDIO)
            if not tracks:
                continue
            rel = os.path.relpath(root, base).split(os.sep)
            artist = rel[0] if rel[0] != "." else "Unknown Artist"
            alb = rel[1] if len(rel) > 1 else "Singles"
            m = re.search(r"\((\d{4})\)$", alb)
            cover = next((c for c in files if c.lower() in COVERS), None)
            ai = len(albums)
            albums.append({"a": artist, "t": alb[:m.start()].strip() if m else alb, "y": m.group(1) if m else "", "c": cat,
                           "art": href(os.path.join(root, cover)) if cover else ""})
            for f in tracks:
                p = os.path.join(root, f)
                st = os.stat(p)
                key = os.path.relpath(p, lib)
                sig = f"{st.st_size}:{int(st.st_mtime)}"
                c = cache.get(key)
                if not c or c.get("sig") != sig:
                    tg, _ = read_tags(p)
                    c = {"sig": sig, "title": tg.get("title", ""), "genre": tg.get("genre", ""), "artist": tg.get("artist", "")}
                newcache[key] = c
                stem = os.path.splitext(f)[0]
                nm = re.match(r"^(?:(\d+)-)?(\d{1,3}) - (.*)$", stem)
                title = c["title"] or (nm.group(3) if nm else stem)
                gb += st.st_size / 1e9
                s = {"al": ai, "t": title, "n": int(nm.group(2)) if nm else 0, "d": int(nm.group(1) or 1) if nm else 1,
                     "p": href(p), "w": 1 if os.path.splitext(f)[1].lower() in WEB_OK else 0}
                if c["genre"]:
                    s["g"] = c["genre"]
                if c["artist"] and c["artist"] != artist:
                    s["ar"] = c["artist"]
                songs.append(s)
    with open(cache_p, "w", encoding="utf-8") as fh:
        json.dump(newcache, fh)
    with open(os.path.join(page_dir, "catalog.js"), "w", encoding="utf-8") as fh:
        fh.write("window.MUSIC=" + json.dumps({"albums": albums, "songs": songs, "gb": round(gb, 1), "built": time.strftime("%Y-%m-%d")},
                                               separators=(",", ":"), ensure_ascii=False) + ";\n")
    shutil.copy2(os.path.join(HERE, "music.html"), os.path.join(page_dir, "index.html"))
    print(f"  Music catalog: {len(songs):,} songs, {len(albums):,} albums ({gb:,.1f} GB) → www/music/index.html")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True, help="the OFFGRID folder")
    ap.add_argument("--src", help="folder or drive with your music, e.g. F:\\Music")
    ap.add_argument("--library", help="where organized songs go (default OFFGRID\\www\\music)")
    ap.add_argument("--apply", choices=("copy", "move"))
    ap.add_argument("--catalog-only", action="store_true")
    a = ap.parse_args()
    lib = os.path.abspath(a.library or os.path.join(a.dest, "www", "music"))
    os.makedirs(lib, exist_ok=True)
    os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
    out = os.path.join(a.dest, "REPORTS", "MUSIC-PLAN")
    if a.apply:
        if not os.path.exists(out + ".csv"):
            print("  No MUSIC-PLAN.csv yet — run the plan step first (with --src)."); return 1
        apply(out + ".csv", lib, a.apply, a.dest)
    elif a.src and not a.catalog_only:
        if not os.path.isdir(a.src):
            print(f"  ! {a.src} isn't a folder"); return 1
        print(f"  Reading {a.src} (nothing is changed in this step)…")
        plan(os.path.abspath(a.src), a.dest, lib, out)
        return 0
    catalog(a.dest, lib)
    return 0


if __name__ == "__main__":
    sys.exit(main())
