# -*- coding: utf-8 -*-
"""Fast full-text search: one SQLite FTS5 file, www/search/search.db, built alongside the JavaScript index.

The JavaScript index (search/idx/*.js) still works with no program running (double-click search.html).
When the drive's server is running (START-HERE / Command Center), the Search page, the Ask-the-AI page, the
Top 20 situations tool and search_cli use this file instead: millisecond queries across millions of pages,
"exact phrases", word* prefixes, and every word (the JS index drops the most common ones).

Rows are the same page ids (pid) as the JS index, so results open the same document and page.
The table is contentless (the page text itself stays in search/text/*.js), which keeps the file small.
If this computer's Python has no FTS5, nothing breaks: everything falls back to the JS index.
"""
import os, re, sqlite3, time

WORD = re.compile(r"[a-z0-9]+")
NAME = "search.db"


def path(dest):
    return os.path.join(dest, "www", "search", NAME)


def available():
    try:
        db = sqlite3.connect(":memory:")
        db.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
        db.close()
        return True
    except sqlite3.Error:
        return False


class Writer:
    """Fill a new database next to the old one while the JS index is built; swap it in at the end."""

    def __init__(self, dest):
        self.final = path(dest)
        self.tmp = self.final + ".building"
        for p in (self.tmp, self.tmp + "-journal"):
            if os.path.exists(p):
                os.remove(p)
        self.db = sqlite3.connect(self.tmp)
        self.db.execute("PRAGMA journal_mode=OFF")
        self.db.execute("PRAGMA synchronous=OFF")
        self.db.execute("CREATE VIRTUAL TABLE fts USING fts5(body, content='', tokenize='porter unicode61 remove_diacritics 2')")
        self.db.execute("CREATE TABLE pages (pid INTEGER PRIMARY KEY, doc INTEGER)")
        self.db.execute("CREATE TABLE docs (doc INTEGER PRIMARY KEY, cat TEXT, key TEXT, title TEXT)")
        self.db.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        self.n, self.buf = 0, []

    def add(self, pid, doc, text):
        self.buf.append((pid, doc, text))
        if len(self.buf) >= 2000:
            self._flush()

    def _flush(self):
        self.db.executemany("INSERT INTO fts(rowid, body) VALUES (?, ?)", [(p, t) for p, _, t in self.buf])
        self.db.executemany("INSERT INTO pages VALUES (?, ?)", [(p, d) for p, d, _ in self.buf])
        self.n += len(self.buf)
        self.buf = []

    def finish(self, doclist, stamp):
        self._flush()
        self.db.executemany("INSERT INTO docs VALUES (?, ?, ?, ?)", [(i, d[2], d[6], d[0]) for i, d in enumerate(doclist)])
        self.db.executemany("INSERT INTO meta VALUES (?, ?)", [("pages", str(self.n)), ("docs", str(len(doclist))), ("built", stamp)])
        self.db.execute("INSERT INTO fts(fts) VALUES ('optimize')")
        self.db.commit()
        self.db.close()
        os.replace(self.tmp, self.final)
        return self.n

    def abort(self):
        try:
            self.db.close()
            os.remove(self.tmp)
        except (OSError, sqlite3.Error):
            pass


def rebuild_from_text(dest, say=print):
    """Remake search.db from search/text/*.js (+ the AI's page context notes), without re-reading the library.
    Used after a restore and after the overnight context-notes job."""
    import json
    if not available():
        return 0
    raw = open(os.path.join(dest, "www", "search", "docs.js"), encoding="utf-8").read()
    docs = json.loads(raw.split("=", 1)[1].split(";\n")[0])
    kdb = None
    try:
        import ai_memory
        kdb = ai_memory.connect(dest, readonly=True)
    except Exception:  # noqa: BLE001
        pass
    w = Writer(dest)
    try:
        for i, d in enumerate(docs):
            try:
                t = open(os.path.join(dest, "www", "search", "text", d[6] + ".js"), encoding="utf-8").read()
                pages = json.loads(t[t.index("(") + 1:t.rindex(")")])[1]
            except (OSError, ValueError):
                pages = []
            ctx = ai_memory.contexts_for_doc(kdb, d[6]) if kdb else {}
            for k in range(d[4]):
                txt = pages[k] if k < len(pages) else ""
                w.add(d[3] + k, i, (ctx[k] + "\n" + txt) if k in ctx else txt)
        n = w.finish(docs, time.strftime("%Y-%m-%d %H:%M:%S"))
    except Exception:
        w.abort()
        raise
    finally:
        if kdb:
            kdb.close()
    say(f"  Fast search database remade: {n:,} pages")
    return n


def _open(dest):
    p = path(dest)
    if not os.path.exists(p):
        return None
    try:
        return sqlite3.connect(f"file:{p}?mode=ro", uri=True, check_same_thread=False)
    except sqlite3.Error:
        return None


def _term(w, prefix):
    w = re.sub(r"[^a-z0-9]", "", w.lower())
    return f'"{w}"' + ("*" if prefix and len(w) >= 3 else "") if w else ""


def expression(groups, phrases=(), excludes=(), any_word=False):
    """groups: [[word, synonym, ...], ...] (each group = one query word and its alternatives)."""
    parts = []
    for g in groups:
        ts = [t for t in (_term(w, i == 0) for i, w in enumerate(g)) if t]
        if ts:
            parts.append("(" + " OR ".join(dict.fromkeys(ts)) + ")")
    expr = (" OR " if any_word else " AND ").join(parts)
    for ph in phrases:
        ws = WORD.findall(ph.lower())
        if ws:
            expr = (expr + " AND " if expr else "") + '"' + " ".join(ws) + '"'
    if expr:
        for x in excludes:
            t = _term(x, False)
            if t:
                expr += f" NOT {t}"
    return expr


def query(dest, groups, phrases=(), excludes=(), cats=(), limit=2000, db=None, _any=False):
    """-> (rows [(score, pid)], mode) best first. mode 'all' = every word matched, 'any' = fell back to any word."""
    own = db is None
    db = db or _open(dest)
    if not db:
        return None, ""
    try:
        for mode in (("any",) if _any else ("all", "any")):
            expr = expression(groups, phrases, excludes, mode == "any")
            if not expr or (mode == "any" and len(groups) < 2):
                continue
            sql = "SELECT -bm25(fts), fts.rowid FROM fts"
            args = [expr]
            if cats:
                sql += " JOIN pages p ON p.pid = fts.rowid JOIN docs d ON d.doc = p.doc WHERE fts MATCH ? AND d.cat IN (%s)" % ",".join("?" * len(cats))
                args += list(cats)
            else:
                sql += " WHERE fts MATCH ?"
            rows = db.execute(sql + " ORDER BY bm25(fts) LIMIT ?", args + [limit]).fetchall()
            if rows and mode == "all" and len(rows) < 60 and len(groups) > 1 and not phrases:
                more, _ = query(dest, groups, phrases, excludes, cats, limit, db=db, _any=True)
                seen = {p for _, p in rows}
                rows += [(sc * .3, p) for sc, p in (more or []) if p not in seen]   # then pages with some of the words
            if rows:
                return rows, mode
        return [], ""
    except sqlite3.Error:
        return None, ""
    finally:
        if own:
            db.close()


def info(dest):
    db = _open(dest)
    if not db:
        return {}
    try:
        return dict(db.execute("SELECT k, v FROM meta").fetchall())
    except sqlite3.Error:
        return {}
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    t = time.time()
    rows, mode = query(sys.argv[1], [[w] for w in sys.argv[2:]])
    print(mode, len(rows or []), f"{(time.time() - t) * 1000:.0f} ms", (rows or [])[:5])
