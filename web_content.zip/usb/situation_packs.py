#!/usr/bin/env python3
"""TOP 20 SITUATIONS — one printable page per situation, gathered ONLY from what is on this drive.

The 20 were picked from what US households actually face most (Census American Housing Survey: about 1 in 4
homes lost power in a year; Red Cross: home fires are its most common disaster call; FEMA/Ready.gov hazard list)
plus the high-consequence events this drive is built for (fallout, chemical release, grid-down, no comms).

For each situation the page has:
  1. Do this now        — the checked first steps (same as the Command Center's "What's happening?" cards)
  2. What you need      — a kit / supplies list for that situation
  3. How to handle it   — the best pages ON THIS DRIVE: every manual, guide and archive page in the full-text
                          index is scored with several focused searches; the top pages are listed with a snippet
                          and a link that opens the PDF at that page. Uses meaning search too when it is running.
  4. Warnings found     — "do not / never / caution" sentences pulled from those pages
  5. Guides, archives and nearest real places (hospital, fuel, shelter…) from the locator

Writes  <drive>\\TOP 20 SITUATIONS\\00 - START HERE.html  and  01 - ... .html  … 20 - ... .html
Fully offline, uses the drive's own Python. Never changes the sources.

  python situation_packs.py --dest D:\\OFFGRID            # rebuild all 20
  python situation_packs.py --dest D:\\OFFGRID --only fire
"""
import argparse, glob, html, json, os, re, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
FOLDER = "TOP 20 SITUATIONS"

# ---- the 20 -------------------------------------------------------------------------------------------------
# id = card id in scen-data.js (first steps and guide links come from there); q = focused full-text searches;
# need = what to have / grab; zim = archive name hints; why = how common or how serious.
TOP20 = [
    {"id": "power", "t": "Power out for days", "why": "Most common: about 1 in 4 US homes lose power each year.",
     "q": ["power outage", "generator carbon monoxide", "blackout food refrigerator", "heat home without power",
           "battery lantern"],
     "need": ["Flashlights/headlamps + spare batteries (no candles near kids)", "Battery or crank NOAA weather radio",
              "Water: 1 gallon per person per day, 3+ days", "No-cook food, manual can opener",
              "Power bank / solar charger for phones", "Generator used OUTDOORS 20+ ft from doors and windows, fuel, heavy cords",
              "Battery CO alarm", "Cooler and ice; fridge thermometer", "Cash (card readers go down)",
              "Backup power for medical devices; list of meds that need cold"],
     "zim": ["wikipedia", "appropedia", "post-disaster"]},
    {"id": "tornado", "t": "Tornado / severe storm", "why": "Severe storms cause most US weather damage every year.",
     "q": ["tornado shelter", "severe thunderstorm lightning", "tornado warning basement interior room",
           "storm damage debris"],
     "need": ["Weather radio with alerts", "Helmets and sturdy shoes for everyone", "Shelter spot picked: basement or lowest interior room",
              "Flashlight, whistle", "First-aid kit", "Work gloves for debris", "Phone charged"],
     "zim": ["wikipedia"]},
    {"id": "fire", "t": "House fire", "why": "Home fires are the disaster the Red Cross answers most.",
     "q": ["house fire escape", "smoke alarm", "fire extinguisher", "smoke inhalation", "grease fire"],
     "need": ["Working smoke alarms on every level", "Fire extinguisher (ABC) in kitchen and garage",
              "Two ways out of every room; escape ladder for upstairs", "Meeting spot outside",
              "Shoes and flashlight by the bed", "Copies of IDs and documents off-site / on this drive"],
     "zim": ["wikipedia"]},
    {"id": "flood", "t": "Flooding / water rising", "why": "Floods are the most common and costly US natural disaster.",
     "q": ["flood", "flash flood driving", "floodwater contamination", "after flood mold cleanup"],
     "need": ["Go-bag ready by the door", "Waterproof bags for documents and phones", "Rubber boots, gloves",
              "Life jackets if near water", "Bleach for cleanup", "Sandbags / plastic sheeting", "Route to higher ground"],
     "zim": ["wikipedia", "post-disaster"]},
    {"id": "cold", "t": "Winter storm / extreme cold", "why": "Ice storms bring long outages and hypothermia risk.",
     "q": ["hypothermia", "frostbite", "winter storm", "heat home without power", "carbon monoxide heater"],
     "need": ["Layers, hats, gloves, sleeping bags rated cold", "Safe indoor heat (vented) + CO alarm",
              "Extra fuel / firewood", "Pipes: know the main shut-off; let taps drip", "Rock salt / sand, shovel",
              "Car kit: blanket, scraper, food, water"],
     "zim": ["wikem", "wikipedia", "mdwiki"]},
    {"id": "heat", "t": "Extreme heat / heat stroke", "why": "Heat kills more Americans than any other weather.",
     "q": ["heat stroke", "heat exhaustion", "dehydration oral rehydration", "cooling body"],
     "need": ["Water + electrolytes / oral rehydration salts", "Cool room or cooling center location",
              "Spray bottle, wet towels, ice", "Light loose clothing, hat, shade", "Thermometer",
              "Check list: elderly, kids, pets"],
     "zim": ["wikem", "mdwiki", "wikipedia"]},
    {"id": "hurricane", "t": "Hurricane coming", "why": "Days of warning — the time to act is before landfall.",
     "q": ["hurricane", "storm surge evacuation", "hurricane shelter preparation", "after hurricane"],
     "need": ["Fuel in vehicles and cans", "Water: 1 gal/person/day for 7+ days", "Food for 7+ days, can opener",
              "Plywood / shutters, tarps, rope", "Meds refilled", "Documents in waterproof bag", "Cash",
              "Evacuation route and place to stay"],
     "zim": ["wikipedia", "post-disaster"]},
    {"id": "bleed", "t": "Someone is bleeding badly", "why": "Bleeding is the top preventable cause of trauma death.",
     "q": ["tourniquet", "hemorrhage control", "wound packing", "pressure dressing", "shock treatment"],
     "need": ["Tourniquet (CAT/SOF-T) — 1 per person in the kit", "Hemostatic or plain gauze for packing",
              "Pressure bandage (Israeli)", "Gloves", "Trauma shears", "Marker to write tourniquet time",
              "Emergency blanket for shock"],
     "zim": ["wikem", "mdwiki", "wikipedia"]},
    {"id": "cpr", "t": "Not breathing / cardiac arrest", "why": "Minutes matter: CPR doubles or triples survival.",
     "q": ["cardiopulmonary resuscitation", "rescue breathing", "choking airway obstruction", "defibrillator"],
     "need": ["Know hands-only CPR: center of chest, 2 inches deep, 100–120 a minute", "CPR face shield",
              "AED location (work, church, store)", "Phone for 911 on speaker"],
     "zim": ["wikem", "mdwiki"]},
    {"id": "sick", "t": "Sick, fever, outbreak — no doctor", "why": "Pandemics and stomach bugs hit every household.",
     "q": ["fever treatment", "diarrhea dehydration", "oral rehydration", "infection antibiotic",
           "isolation quarantine", "pandemic influenza"],
     "need": ["Thermometer", "Fever reducers (acetaminophen, ibuprofen)", "Oral rehydration salts (or salt + sugar)",
              "Masks, gloves, bleach, soap", "Separate room / bathroom for the sick person",
              "Med list and doses for everyone", "Bucket + bags if plumbing fails"],
     "zim": ["mdwiki", "wikem", "medline", "wikipedia"]},
    {"id": "water", "t": "No safe water / boil-water notice", "why": "Water fails in almost every long emergency.",
     "q": ["water purification", "boil water", "chlorine bleach drinking water", "water filter", "water storage"],
     "need": ["Stored water: 1 gal/person/day", "Unscented bleach + dropper", "Pot and fuel to boil",
              "Filter (Sawyer/LifeStraw/ceramic)", "Clean containers marked DRINKING", "Coffee filters / cloth to pre-filter",
              "Know your water heater drain (≈40 gallons inside)"],
     "zim": ["water", "appropedia", "wikipedia"]},
    {"id": "evac", "t": "We need to leave — now", "why": "Fire, flood, chemical or storm can force you out fast.",
     "q": ["evacuation", "go bag", "bug out", "evacuation route vehicle"],
     "need": ["Go-bag for each person (water, food, light, meds, clothes)", "Documents, IDs, cash, chargers",
              "Paper maps + this drive", "Full fuel tank", "Pets: carrier, leash, food", "Meeting place and out-of-area contact"],
     "zim": ["wikivoyage", "wikipedia"]},
    {"id": "car", "t": "Stranded away from home", "why": "Breakdowns and closed roads strand people every storm.",
     "q": ["vehicle emergency kit", "jump start battery", "stranded vehicle winter", "tire change", "navigation map compass"],
     "need": ["Jumper cables / jump pack", "Spare tire, jack, tire plug kit", "Water, snacks, blanket",
              "Flashlight, flares/triangles", "Walking shoes", "Paper map", "Phone charger cable"],
     "zim": ["ifixit", "wikivoyage", "wikipedia"]},
    {"id": "lost", "t": "Lost / no GPS or signal", "why": "Navigation without a phone is a core survival skill.",
     "q": ["land navigation compass", "map reading", "navigation stars sun", "signaling rescue", "lost survival"],
     "need": ["Compass + paper map of the area", "Whistle, signal mirror", "Headlamp", "Water and a way to purify",
              "Fire starter", "Emergency blanket", "Tell someone your plan before you go"],
     "zim": ["wikipedia"]},
    {"id": "chem", "t": "Gas leak / chemical spill", "why": "Train, truck and plant releases happen in every state.",
     "q": ["hazardous materials", "shelter in place chemical", "chemical exposure decontamination",
           "emergency response guidebook", "gas leak"],
     "need": ["Plastic sheeting + duct tape for one room", "Wet cloth for breathing if caught outside",
              "Battery radio for instructions", "Change of clothes / bags for contaminated ones",
              "Know the wind direction; go up-wind and uphill"],
     "zim": ["wikipedia"]},
    {"id": "nuke", "t": "Nuclear alert / fallout", "why": "Low chance, huge consequence — the right first hour saves lives.",
     "q": ["fallout shelter", "radiation exposure", "nuclear detonation", "potassium iodide", "decontamination radiation"],
     "need": ["Know the nearest thick-walled shelter (basement, center of large building)",
              "Water and food for 24–72 hours inside", "Battery radio", "Potassium iodide (only if told to take it)",
              "Plastic bags for contaminated clothing", "Radiation meter if you have one"],
     "zim": ["wikipedia"]},
    {"id": "unrest", "t": "Unrest / break-in / threat", "why": "When police are overwhelmed, home security is on you.",
     "q": ["home security", "civil unrest", "self defense", "situational awareness", "safe room"],
     "need": ["Locks, door bars, lights", "Safe room with phone/radio", "Family code word and rally point",
              "Fire extinguisher", "First-aid / trauma kit", "Low profile: lights and noise discipline"],
     "zim": ["wikipedia"]},
    {"id": "comms", "t": "Can't reach family (no cell)", "why": "Networks jam or fail in nearly every disaster.",
     "q": ["radio communication", "amateur radio repeater", "GMRS FRS", "emergency communication plan", "text message"],
     "need": ["Written contact list (phones die)", "Out-of-area contact everyone checks in with",
              "GMRS/FRS or ham radios + batteries", "Channel/frequency plan and check-in times",
              "Meeting places: near home and out of the neighborhood"],
     "zim": ["wikipedia"]},
    {"id": "emp", "t": "Grid down long-term (EMP / solar storm)", "why": "Rare, but it would remove power, phones and supply for months.",
     "q": ["electromagnetic pulse", "solar storm", "long term food storage", "grid down", "faraday cage"],
     "need": ["Food stored for months; garden seeds", "Water source + filtration", "Hand tools", "Faraday-stored radio and spares",
              "Paper references (this drive's printouts)", "Medical supplies", "Community / neighbors plan"],
     "zim": ["appropedia", "wikipedia", "post-disaster", "food"]},
    {"id": "burn", "t": "Burns and serious injury", "why": "Burns, breaks and bites come with every other emergency.",
     "q": ["burn treatment", "fracture splint", "snake bite", "wound infection", "dislocation"],
     "need": ["Clean water to cool burns", "Non-stick dressings, plastic wrap", "SAM splint / padding",
              "Pain relievers", "Antibiotic ointment", "Elastic bandages"],
     "zim": ["wikem", "mdwiki", "wikipedia"]},
]
EXTRA_CARDS = {
    "fire": {"t": "House fire", "loc": "hospital,fire", "kw": "house home fire smoke alarm escape extinguisher burn grease flames trapped",
             "call": "Get out first, then call 911 from outside.",
             "s": ["Yell FIRE, get everyone out. Don't stop for belongings.",
                   "Crawl low under smoke. Feel doors with the back of your hand — hot means use another way.",
                   "Close doors behind you to slow the fire. Meet at your outside meeting spot and count heads.",
                   "Never go back inside. Tell firefighters who is missing and where they sleep.",
                   "Clothes on fire: stop, drop and roll. Grease fire: cover with a lid and turn off the heat — never water.",
                   "Trapped: close the door, block the gap with cloth, signal from the window with a light or sheet."],
             "l": []},
}


# ---- reading the drive --------------------------------------------------------------------------------------
def load_cards(path):
    """Parse scen-data.js (a small JS literal) into Python dicts."""
    t = open(path, encoding="utf-8").read()
    head = "window.SCEN_DATA=(function(){"
    body = t[t.index(head) + len(head):t.rindex("return {SCEN")]
    body = re.sub(r"(?m)^\s*//.*$", "", body)
    body = re.sub(r"/\*.*?\*/", "", body, flags=re.S)
    ns = {}
    for m in re.finditer(r"const\s+(.*?);\s*\n", body, re.S):
        decl = m.group(1)
        if decl.startswith("SCEN"):
            continue
        for part in re.split(r",\s*\n?\s*(?=[A-Z]{1,4}\s*=)", decl):
            k, v = part.split("=", 1)
            ns[k.strip()] = eval(v, {"__builtins__": {}}, ns)   # our own file: string constants only
    arr = body[body.index("const SCEN = [") + len("const SCEN = "):]
    arr = arr[:arr.rindex("];") + 1]
    arr = re.sub(r"([{,]\s*)([a-zA-Z_]\w*)\s*:", lambda m: m.group(1) + '"' + m.group(2) + '":', arr)
    return {c["id"]: c for c in eval(arr, {"__builtins__": {}}, ns)}


def _load_js(path, var):
    try:
        t = open(path, encoding="utf-8").read()
        i = t.index("=", t.index("window." + var)) + 1
        return json.JSONDecoder().raw_decode(t[i:].lstrip())[0]
    except Exception:  # noqa: BLE001
        return None


def _esc(s):
    return html.escape(html.unescape(str(s or "")), quote=True)   # index titles may already hold &amp;


def _href(path):
    from urllib.parse import quote
    return quote(path.replace("\\", "/"), safe="/#=?&")


class Gather:
    def __init__(self, dest):
        self.dest = dest
        self.ix = None
        try:
            import search_cli
            self.ix = search_cli.Index(dest)
            self.snippet = search_cli.snippet
        except Exception as e:  # noqa: BLE001
            print(f"  ! Top 20: full-text index not readable ({type(e).__name__}) — pages will list first steps and kits only")
        self.sem, self.port = None, None
        try:                              # meaning search only if its server is already running (no model load at build)
            import semantic
            port = 8094
            if os.path.exists(os.path.join(dest, "www", "search", "vec", "all.i8")) and semantic._healthy(port):
                self.sem, self.port, self.semantic = semantic.Searcher(dest), port, semantic
        except Exception:  # noqa: BLE001
            self.sem = None

    def pages(self, queries, n=12):
        """Best pages across several searches: a page found by more than one search ranks higher."""
        if not self.ix:
            return []
        score, info = {}, {}
        for qi, q in enumerate(queries):
            try:
                hits, words = self.ix.search(q, 25)
            except Exception:  # noqa: BLE001
                continue
            for rank, (pid, d) in enumerate(hits):
                score[pid] = score.get(pid, 0) + (25 - rank) / 25 + (0.3 if qi == 0 else 0)
                info.setdefault(pid, (d, words))
        if self.sem:
            bykey = {d[6]: d for d in self.ix.docs}
            for q in queries[:3]:
                try:
                    qv = self.semantic._post(self.port, [self.semantic.QUERY + q], 60)[0]
                    for rank, (sc, key, pg) in enumerate(self.sem.top(qv, 15)):
                        d = bykey.get(key)
                        if d:
                            pid = d[3] + pg
                            score[pid] = score.get(pid, 0) + (15 - rank) / 15
                            info.setdefault(pid, (d, re.findall(r"\w+", q.lower())))
                except Exception:  # noqa: BLE001
                    break
        out, per = [], {}
        for pid in sorted(score, key=score.get, reverse=True):
            d, words = info[pid]
            if per.get(d[1], 0) >= 2:                      # at most 2 pages from one document
                continue
            try:
                text = self.ix.page_text(d, pid)
            except Exception:  # noqa: BLE001
                text = ""
            if len(text.strip()) < 80:                      # skip blank / title-only pages
                continue
            per[d[1]] = per.get(d[1], 0) + 1
            out.append({"title": d[0], "path": d[1], "where": self.ix.where(pid, d), "link": self._link(pid, d),
                        "snip": self.snippet(text, words), "text": text, "words": words})
            if len(out) >= n:
                break
        return out

    @staticmethod
    def _link(pid, d):
        i = pid - d[3]
        if d[1].lower().endswith(".pdf"):
            return _href(d[1]) + f"#page={i + 1}"
        return _href(d[1]) + (("#" + d[5][i]) if d[5] and i < len(d[5]) and d[5][i] else "")


WARN = re.compile(r"\b(do not|don't|never|warning|caution|danger|avoid)\b", re.I)


def warnings(pages, kws, others=(), n=6):
    """Short caution sentences from the gathered pages that mention the situation's own words.
    Skips pages about a different situation (e.g. a snake-bite page's "no tourniquet" on the bleeding page)."""
    seen, out = set(), []
    for p in pages:
        head = re.findall(r"[a-z]+", (p["title"] + " " + p["where"]).lower())
        if any(w in others for w in head) and not any(w.startswith(k[:5]) for w in head for k in kws):
            continue
        for s in re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", p["text"])):
            if not (40 <= len(s) <= 220) or not WARN.search(s):
                continue
            low = s.lower()
            if sum(1 for k in kws if re.search(r"\b" + re.escape(k), low)) < 2:
                continue                                    # needs two of the situation's own words, so it is on topic
            key = re.sub(r"\W+", "", low)[:60]
            if key in seen:
                continue
            seen.add(key)
            out.append((s, p))
            break                                           # one per page keeps it varied
        if len(out) >= n:
            break
    return out


CSS = """body{font:16px/1.5 system-ui,Segoe UI,Roboto,sans-serif;max-width:880px;margin:0 auto;padding:22px;color:#15181b}
h1{font-size:26px;margin:0} h2{font-size:19px;margin:24px 0 8px;border-bottom:2px solid #c9771f;color:#9a5a12;padding-bottom:3px}
.sub{color:#555;margin:2px 0 12px} .now li{margin:7px 0;font-weight:600} .call{background:#fde8e8;border:1px solid #f2b8b8;border-radius:8px;padding:8px 12px;font-weight:700}
.kit{columns:2;column-gap:28px} .kit li{break-inside:avoid;margin:3px 0} a{color:#1a5db8;text-decoration:none} a:hover{text-decoration:underline}
.card{border:1px solid #e0e3e7;border-radius:8px;padding:8px 12px;margin:7px 0;background:#fafbfc}
.src{color:#666;font-size:13px} .tag{background:#eef2f6;border-radius:4px;padding:0 6px;font-size:12px;color:#445;margin-left:6px}
.warn{border-left:4px solid #d9534f;padding:4px 10px;margin:6px 0;background:#fff6f6}
.note{background:#fff7e9;border:1px solid #f0d9a8;border-radius:8px;padding:8px 12px;font-size:14px}
table{border-collapse:collapse;width:100%;font-size:14px} td{border-bottom:1px solid #e6e9ec;padding:4px 6px;vertical-align:top}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px} .grid a{display:block;border:1px solid #dde2e7;border-radius:10px;padding:12px;background:#fafbfc;color:inherit}
.grid b{display:block;font-size:16px} .n{color:#c9771f;font-weight:800;margin-right:6px}
@media print{a{color:#000}.card,.warn{break-inside:avoid}h2{break-after:avoid}body{max-width:none}.kit{columns:2}}
@media(prefers-color-scheme:dark){body{background:#14171a;color:#e6e8eb}.card,.grid a{background:#1b1f24;border-color:#2c323a}
 h2{color:#d9a441;border-color:#8a5a1a}.src{color:#9aa}a{color:#6db0ff}.note{background:#241e12;border-color:#5a4a28}
 .call{background:#3a1d1d;border-color:#6a2c2c}.warn{background:#2a1a1a}.tag{background:#222933;color:#bcd}td{border-color:#2c323a}}"""


def _fname(i, title):
    name = re.sub(r"[^\w \-]+", "", title.replace("/", " - ").replace("—", " - "))
    return f"{i:02d} - " + re.sub(r"( - )+", " - ", re.sub(r"\s+", " ", name)).strip(" -") + ".html"


def build_page(dest, i, sit, card, g, zims, pois, cats, home, others=()):
    W = "../www/"
    kws = sorted({w for w in (card.get("kw", "") + " " + " ".join(sit["q"])).lower().split() if len(w) > 3})
    pages = g.pages(sit["q"])
    P = ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
         f"<title>{i:02d} {_esc(sit['t'])}</title><style>{CSS}</style></head><body>",
         f"<p class='src'><a href='00 - START HERE.html'>&larr; Top 20 situations</a></p>",
         f"<h1>{i}. {_esc(sit['t'])}</h1><p class='sub'>{_esc(sit['why'])}</p>"]
    if card.get("call"):
        P.append(f"<div class='call'>{_esc(card['call'])}</div>")
    P.append("<h2>1. Do this now</h2><ol class='now'>" + "".join(f"<li>{_esc(s)}</li>" for s in card.get("s", [])) + "</ol>")
    P.append("<h2>2. What you need</h2><ul class='kit'>" + "".join(f"<li>{_esc(s)}</li>" for s in sit["need"]) + "</ul>")

    P.append("<h2>3. How to handle it — best pages on this drive</h2>")
    if pages:
        P.append("<p class='src'>Found by searching every manual, guide and archive page on the drive for: "
                 + _esc(" · ".join(sit["q"])) + ". Click to open at that page.</p>")
        for p in pages:
            P.append(f"<div class='card'><a href='{W}{p['link']}'><b>{_esc(p['title'])}</b></a>"
                     f"<span class='tag'>{_esc(p['where'])}</span><div class='src'>{_esc(p['snip'])}</div></div>")
    else:
        P.append("<p class='note'>The search index isn't built yet — run the builder (or OCR + rebuild), then rebuild this page. "
                 f"Meanwhile use <a href='{W}search.html'>Search everything</a>.</p>")

    warn = warnings(pages, kws, set(others) - set(kws))
    if warn:
        P.append("<h2>4. Warnings found in those pages</h2>")
        P += [f"<div class='warn'>{_esc(s)} <span class='src'>— <a href='{W}{p['link']}'>{_esc(p['title'])}, {_esc(p['where'])}</a></span></div>"
              for s, p in warn]

    P.append("<h2>5. More on this drive</h2><ul>")
    P += [f"<li><a href='{W}{_href(href)}'>{_esc(label)}</a> <span class='tag'>guide</span></li>" for href, label in card.get("l", [])]
    hint = [z for z in zims if any(h in os.path.basename(z).lower() for h in sit["zim"])][:5]
    P += [f"<li>{_esc(os.path.basename(z))} <span class='tag'>archive</span> <span class='src'>open with Read the archives (Kiwix)</span></li>"
          for z in hint]
    P.append(f"<li><a href='{W}search.html'>Search everything</a> · <a href='{W}ask.html'>Ask the drive</a> · "
             f"<a href='{W}command.html'>Command Center</a></li></ul>")

    loc = [c for c in (card.get("loc") or "").split(",") if c]
    near = [(c, [r for r in pois if r[0] == c][:3]) for c in loc]
    near = [(c, rows) for c, rows in near if rows]
    if near:
        P.append("<h2>6. Nearest places" + (f" to {_esc(home)}" if home else "") + "</h2><table>")
        for c, rows in near:
            for r in rows:
                P.append(f"<tr><td><b>{_esc(r[1])}</b> <span class='tag'>{_esc(cats.get(c, c))}</span><br>"
                         f"<span class='src'>{_esc(r[6] if len(r) > 6 else '')}</span></td><td>{_esc(r[4])} mi {_esc(r[5])}</td>"
                         f"<td>{_esc(r[7] if len(r) > 7 else '')}</td><td class='src'>{r[2]:.4f}, {r[3]:.4f}</td></tr>")
        P.append("</table>")
    P.append(f"<p class='src'>Made from this drive {time.strftime('%Y-%m-%d')}. First steps follow Red Cross / Ready.gov / CDC guidance; "
             "everything else is pulled from your own files — OCR text can have errors, so open the source for anything critical. "
             "Rebuild after adding files: PROGRAMS\\TOP-20-SITUATIONS.bat (or the Rebuild Top 20 button in START-HERE), or <span class='src'>python situation_packs.py --dest &lt;drive&gt;</span>.</p></body></html>")
    return "\n".join(P), len(pages)


def build_all(dest, only=None):
    cards = load_cards(os.path.join(dest, "www", "scen-data.js")) if os.path.exists(os.path.join(dest, "www", "scen-data.js")) \
        else load_cards(os.path.join(HERE, "scen-data.js"))
    cards.update({k: dict(v, id=k) for k, v in EXTRA_CARDS.items() if k not in cards})
    g = Gather(dest)
    zims = sorted(glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim")))
    pdata = os.path.join(dest, "www", "data", "pois.js")
    pois = _load_js(pdata, "POIS") or []
    meta = _load_js(pdata, "POI_META") or {}
    out = os.path.join(dest, FOLDER)
    os.makedirs(out, exist_ok=True)
    tiles, total = [], 0
    allkw = {sid: {w for w in c.get("kw", "").lower().split() if len(w) > 3} for sid, c in cards.items()}
    for i, sit in enumerate(TOP20, 1):
        card = cards.get(sit["id"], {})
        fn = _fname(i, sit["t"])
        if not only or sit["id"] in only:
            try:
                others = set().union(*(v for k, v in allkw.items() if k != sit["id"]))
                doc, n = build_page(dest, i, sit, card, g, zims, pois, meta.get("categories", {}), meta.get("label", ""), others)
                for old in glob.glob(os.path.join(out, f"{i:02d} - *.html")):
                    if os.path.basename(old) != fn:
                        os.remove(old)                     # a renamed situation: drop its old page (ours only)
                with open(os.path.join(out, fn), "w", encoding="utf-8") as fh:
                    fh.write(doc)
                total += n
            except Exception as e:  # noqa: BLE001
                print(f"  ! Top 20 {sit['id']}: {type(e).__name__}: {e}")
        tiles.append(f"<a href='{_esc(_href(fn))}'><b><span class='n'>{i}</span>{_esc(sit['t'])}</b>"
                     f"<span class='src'>{_esc(sit['why'])}</span></a>")
    idx = ('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
           f"<title>Top 20 situations</title><style>{CSS}</style></head><body><h1>Top 20 situations</h1>"
           "<p class='sub'>Pick what is happening. Each page: what to do now, what you need, and the best pages on this drive "
           "for handling it — all offline, all from this drive. Print the ones that matter to your family.</p>"
           "<div class='grid'>" + "".join(tiles) + "</div>"
           "<p class='src' style='margin-top:18px'><a href='../DASHBOARD.html'>Dashboard</a> · Something else? <a href='../www/search.html'>Search everything</a> · "
           "<a href='../www/topics.html'>What's happening?</a> · <a href='../www/command.html'>Command Center</a></p></body></html>")
    with open(os.path.join(out, "00 - START HERE.html"), "w", encoding="utf-8") as fh:
        fh.write(idx)
    return len(TOP20), total


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", default=os.path.abspath(os.path.join(HERE, "..", "..", "..")))
    ap.add_argument("--only", nargs="*", help="situation ids to rebuild (e.g. fire power)")
    ap.add_argument("--open", action="store_true", help="open the start page when done")
    a = ap.parse_args()
    n, pages = build_all(a.dest, a.only)
    p = os.path.join(a.dest, FOLDER, "00 - START HERE.html")
    print(f"  Top 20 situations: {n} pages, {pages} drive pages gathered -> {p}")
    if a.open:
        import webbrowser
        webbrowser.open("file:///" + p.replace("\\", "/"))


if __name__ == "__main__":
    main()
