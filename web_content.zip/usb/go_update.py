"""Update an OFFGRID go drive. Pure standard library; runs from the go drive itself.

    python go_update.py --drive <go drive OFFGRID folder>              asks which way
    python go_update.py --drive X --from E:\\OFFGRID                    copy what changed from the main drive (no internet)
    python go_update.py --drive X --online                             refresh guides, manuals and pages from the internet

Nothing on the go drive is ever deleted. Files are only added or replaced by a newer version, and copying stops
before the go drive is full.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time

RESERVE = 500 * 1024 * 1024       # always leave this much free on the go drive


def _info(drive):
    try:
        with open(os.path.join(drive, "GO-DRIVE.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def from_main(drive, main, budget=None):
    main = os.path.abspath(main)
    if not os.path.isfile(os.path.join(main, "www", "command.html")):
        print(f"  That does not look like the main OFFGRID folder (no www\\command.html in {main}).")
        return 1
    info = _info(drive)
    kind = info.get("device") or ""
    if kind not in ("windows", "mac", "linux", "android", "iphone", "all"):
        kind = (input("  Which device is this go drive for (windows, mac, linux, android, iphone, all)? ").strip().lower() or "all")
    gb = budget or info.get("budget_gb")
    if not gb:
        gb = shutil.disk_usage(drive).total / 1e9
    sys.path.insert(0, os.path.join(main, "tools", "builder", "usb"))
    files = None
    try:
        import platforms
        files = platforms.plan(main, kind, gb)[0]
    except Exception as e:  # noqa: BLE001
        print(f"  Could not read the main drive's plan ({type(e).__name__}: {e}).")
        print("  Falling back to updating only the files that are already on this go drive.")
    if files is None:
        files = []
        for r, _, fs in os.walk(drive):
            for f in fs:
                files.append(os.path.relpath(os.path.join(r, f), drive).replace(os.sep, "/"))
    free = shutil.disk_usage(drive).free
    new = upd = same = lack = bad = 0
    nbytes = 0
    log = []
    for i, rel in enumerate(files, 1):
        src = os.path.join(main, *rel.split("/"))
        dst = os.path.join(drive, *rel.split("/"))
        if not os.path.isfile(src):
            continue
        try:
            ss = os.stat(src)
            if os.path.isfile(dst):
                ds = os.stat(dst)
                if ds.st_size == ss.st_size and ds.st_mtime + 2 >= ss.st_mtime:
                    same += 1
                    continue
                need = max(0, ss.st_size - ds.st_size)
                kindword = "updated"
            else:
                need = ss.st_size
                kindword = "new"
            if need + RESERVE > free:
                lack += 1
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + ".part"
            shutil.copy2(src, tmp)
            os.replace(tmp, dst)
            free -= need
            nbytes += ss.st_size
            if kindword == "new":
                new += 1
            else:
                upd += 1
            log.append(f"{kindword}: {rel}")
        except OSError as e:
            bad += 1
            log.append(f"FAILED: {rel} ({e})")
        if i % 500 == 0:
            print(f"\r    checked {i:,} / {len(files):,}", end="", flush=True)
    print(f"\n  Done. {new:,} new, {upd:,} updated, {same:,} already current ({nbytes / 1e9:,.2f} GB copied).")
    if lack:
        print(f"  {lack:,} files did not fit and were skipped (the go drive is nearly full).")
    if bad:
        print(f"  {bad:,} files could not be copied (see the log).")
    _log(drive, "from " + main, log, new, upd, same, lack, bad)
    return 0


def online(drive):
    b = os.path.join(drive, "tools", "builder", "usb", "usb_builder.py")
    if not os.path.isfile(b):
        print("  This go drive does not carry the builder, so it cannot update itself online.")
        print("  Use the main drive instead (run this again and choose the main drive), or run UPDATE-DRIVE on the main drive.")
        return 1
    free = shutil.disk_usage(drive).free
    if free < 2 * 1024 ** 3:
        print("  Less than 2 GB is free on this go drive; free some space before updating online.")
        return 1
    py = os.path.join(drive, "tools", "python-win", "python.exe")
    if not os.path.isfile(py):
        py = sys.executable
    # text-and-pages refresh only: no maps, archives, AI, movies, software or big downloads, so the drive never outgrows itself
    skip = ["--no-map", "--no-topo", "--no-tiles", "--no-big", "--no-zim", "--no-ai", "--no-phone", "--no-areas", "--no-south-tiles",
            "--no-software", "--no-extra-data", "--no-ocr", "--no-vault", "--no-voice", "--no-flood", "--no-canada", "--no-mil-pubs", "--no-extras"]
    cmd = [py, b, "--dest", drive, "--update"] + skip
    print("  Running the builder in guides-and-pages-only mode. This needs internet.")
    env = dict(os.environ, PYTHONUTF8="1")
    rc = subprocess.call(cmd, env=env)
    _log(drive, "online", [f"builder exit code {rc}"], 0, 0, 0, 0, 0 if rc == 0 else 1)
    return rc


def _log(drive, how, lines, new, upd, same, lack, bad):
    try:
        d = os.path.join(drive, "REPORTS")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "GO-UPDATE-LOG.txt"), "a", encoding="utf-8") as fh:
            fh.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M')}  update {how}: {new} new, {upd} updated, {same} current, {lack} no room, {bad} failed\n")
            fh.write("\n".join(lines[:2000]) + "\n")
    except OSError:
        pass


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--drive", required=True, help="the go drive's OFFGRID folder")
    ap.add_argument("--from", dest="src", help="the main drive's OFFGRID folder")
    ap.add_argument("--online", action="store_true")
    ap.add_argument("--budget-gb", type=float)
    a = ap.parse_args()
    drive = os.path.abspath(a.drive)
    if a.src:
        return from_main(drive, a.src, a.budget_gb)
    if a.online:
        return online(drive)
    print("  1 = copy updates from my main OFFGRID drive (no internet)")
    print("  2 = online: refresh guides, manuals and pages (needs internet)")
    c = input("  Choose 1 or 2: ").strip()
    if c == "2":
        return online(drive)
    m = input("  Path of the main drive's OFFGRID folder (example E:\\OFFGRID): ").strip().strip('"')
    return from_main(drive, m, a.budget_gb)


if __name__ == "__main__":
    sys.exit(main() or 0)
