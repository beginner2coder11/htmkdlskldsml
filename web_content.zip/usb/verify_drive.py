"""Checksum the big files on the OFF-GRID drive (archives, AI models, map layers, topo maps, tiles) and
check them again later to catch a bad copy, a failing drive or a half-finished download.

  python verify_drive.py --dest E:\\OFFGRID --create     write/refresh REPORTS\\CHECKSUMS.json (incremental:
                                                         files whose size+date didn't change are not re-read)
  python verify_drive.py --dest E:\\OFFGRID --verify     re-read everything and compare (slow but thorough)
  python verify_drive.py --dest E:\\OFFGRID --quick      compare sizes and dates only (seconds)
  add --repair to delete files that fail, so the next builder run downloads them again

Covers: every file of 50 MB or more (not your movies/music unless --include-media) plus every map tile.
Standard library only; stop it any time (progress is saved) and re-run.
"""
import argparse, hashlib, json, os, sys, time
from concurrent.futures import ThreadPoolExecutor

BIG = 50 * 1024 * 1024
SKIP_TOP = {"__pycache__"}
SKIP_PARTS = {".part", ".tmp"}
MEDIA = ("www/media/", "www/music/")
TILES = "www/tiles/"


def rel_of(dest, path):
    return os.path.relpath(path, dest).replace("\\", "/")


def scan(dest, include_media):
    for root, dirs, files in os.walk(dest):
        dirs[:] = [d for d in dirs if d not in SKIP_TOP]
        for f in files:
            if f.endswith(tuple(SKIP_PARTS)):
                continue
            p = os.path.join(root, f)
            rel = rel_of(dest, p)
            if rel.startswith("REPORTS/"):
                continue
            if not include_media and rel.startswith(MEDIA):
                continue
            try:
                st = os.stat(p)
            except OSError:
                continue
            if st.st_size >= BIG or rel.startswith(TILES):
                yield rel, p, st.st_size, st.st_mtime_ns


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb", buffering=0) as fh:
        while True:
            b = fh.read(8 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def load(man):
    try:
        return json.load(open(man, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save(man, data):
    tmp = man + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, separators=(",", ":"))
    os.replace(tmp, man)


def run_hashes(items, workers, data, man, label):
    done, total, last = 0, len(items), time.time()
    gb = sum(i[2] for i in items) / 1e9
    print(f"  {label}: {total:,} files, {gb:,.1f} GB to read")
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(sha256, p): (rel, size, mt) for rel, p, size, mt in items}
        from concurrent.futures import as_completed
        for fu in as_completed(futs):
            rel, size, mt = futs[fu]
            try:
                data[rel] = [size, mt, fu.result()]
            except OSError as e:
                print(f"  ! could not read {rel}: {e}")
            done += 1
            if time.time() - last > 20:
                save(man, data)
                last = time.time()
                print(f"    {done:,}/{total:,} files", flush=True)
    save(man, data)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--create", action="store_true")
    g.add_argument("--verify", action="store_true")
    g.add_argument("--quick", action="store_true")
    ap.add_argument("--repair", action="store_true", help="delete files that fail so the builder re-downloads them")
    ap.add_argument("--include-media", action="store_true", help="also cover Movies & Music")
    ap.add_argument("--workers", type=int, default=3)
    a = ap.parse_args()
    man = os.path.join(a.dest, "REPORTS", "CHECKSUMS.json")
    os.makedirs(os.path.dirname(man), exist_ok=True)
    data = load(man)
    files = list(scan(a.dest, a.include_media))
    current = {rel: (size, mt) for rel, _, size, mt in files}

    if a.create or not (a.verify or a.quick):
        todo = [f for f in files if f[0] not in data or data[f[0]][0] != f[2] or data[f[0]][1] != f[3]]
        for rel in [r for r in data if r not in current]:
            del data[rel]
        print(f"OFF-GRID checksums — {a.dest}")
        if todo:
            run_hashes(todo, a.workers, data, man, "hashing new or changed files")
        save(man, data)
        print(f"  Done: {len(data):,} files recorded in {man}")
        return

    if not data:
        print("  No checksum list yet. Run with --create first (on a drive you know is good).")
        sys.exit(2)
    print(f"OFF-GRID drive check — {'quick (size/date)' if a.quick else 'full (re-reading every file)'}")
    bad, missing, new = [], [], []
    for rel in data:
        if rel not in current:
            missing.append(rel)
        elif data[rel][0] != current[rel][0]:
            bad.append((rel, "size changed"))
    new = [rel for rel in current if rel not in data]
    if a.verify:
        chk = [f for f in files if f[0] in data and data[f[0]][0] == f[2]]
        fresh = {}
        run_hashes(chk, a.workers, fresh, os.path.join(a.dest, "REPORTS", "CHECKSUMS.verify.tmp"), "re-reading")
        for rel, (size, mt, h) in fresh.items():
            if h != data[rel][2]:
                bad.append((rel, "contents differ (corrupt)"))
        try:
            os.remove(os.path.join(a.dest, "REPORTS", "CHECKSUMS.verify.tmp"))
        except OSError:
            pass
    lines = [f"Checked {len(data):,} files: {len(bad)} bad, {len(missing)} missing, {len(new)} not yet recorded"]
    lines += [f"  BAD      {r} — {why}" for r, why in bad[:200]]
    lines += [f"  MISSING  {r}" for r in missing[:200]]
    if new:
        lines.append(f"  ({len(new)} new files since --create; run --create to record them)")
    print("\n".join(lines))
    with open(os.path.join(a.dest, "REPORTS", "VERIFY-REPORT.txt"), "w", encoding="utf-8") as fh:
        fh.write(time.strftime("%Y-%m-%d %H:%M") + "\n" + "\n".join(lines) + "\n")
    if a.repair and bad:
        rebuildable = ("kiwix/", "ai/", "www/tiles/", "www/map/", "www/topo/", "www/phone-apps/", "tools/", "www/data/")
        for rel, _ in bad:
            if not rel.startswith(rebuildable):       # your own files can't be re-downloaded: never delete them
                print(f"  kept {rel} (not something the builder can re-download)")
                continue
            try:
                os.remove(os.path.join(a.dest, *rel.split("/")))
                data.pop(rel, None)
                print(f"  removed {rel} — the builder will download it again")
            except OSError as e:
                print(f"  ! could not remove {rel}: {e}")
        save(man, data)
    sys.exit(1 if (bad or missing) else 0)


if __name__ == "__main__":
    main()
