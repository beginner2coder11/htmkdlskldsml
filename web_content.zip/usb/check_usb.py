#!/usr/bin/env python3
"""Check an OFF-GRID SURVIVAL USB drive: what's installed, what's missing, and (optionally) whether the AI starts.

  python check_usb.py --dest E:\\OFFGRID            # inventory report
  python check_usb.py --dest E:\\OFFGRID --test-ai  # also start the AI briefly and ask it a question
Writes REPORTS\\CHECK-REPORT.txt and REPORTS\\MISSING-MANUALS.html / .txt.
"""
import argparse, glob, json, os, platform, re, shutil, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
TSV_CANDIDATES = [os.path.join(os.path.dirname(HERE), "library", "manuals.tsv"), os.path.join(HERE, "manuals.tsv")]
MODEL_MIN_GB = {"Llama-3.2-3B": 1.8, "Qwen2.5-7B": 4.4, "Qwen2.5-14B": 8.5, "gemma-3-4b": 2.3, "medgemma-4b": 2.3, "mmproj": 0.7}

lines, problems = [], []


def out(s=""):
    print(s); lines.append(s)


def ok(label, good, detail="", fix=""):
    mark = "OK " if good else "-- "
    out(f"  [{mark}] {label}{(' — ' + detail) if detail else ''}")
    if not good:
        problems.append(f"{label}{(': ' + fix) if fix else ''}")


def gb(path):
    return os.path.getsize(path) / 1e9 if os.path.exists(path) else 0


def folder_gb(path):
    t = 0
    for r, _, fs in os.walk(path):
        for f in fs:
            try:
                t += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return t / 1e9


def _human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return (f"{int(n)} B" if unit == "B" else f"{n:.1f} {unit}")
        n /= 1024


LAYOUT_DEPTH = 3     # show folders down to this depth; deeper (tile z/x/y pyramids, per-file) is summarised into the count
LAYOUT_MAXKIDS = 40  # cap folders listed under one parent so a huge fan-out can't flood the report


def layout(d):
    """Append a folder tree (size + file count per folder) so the uploaded report shows the drive's build layout."""
    size, nfiles, ndirs = {}, {}, {}
    for r, ds, fs in os.walk(d, topdown=False):   # one bottom-up pass: roll child totals up into each folder
        s = 0
        for f in fs:
            try:
                s += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
        tot, cnt = s, len(fs)
        for sub in ds:
            p = os.path.join(r, sub)
            tot += size.get(p, 0); cnt += nfiles.get(p, 0)
        size[r], nfiles[r], ndirs[r] = tot, cnt, len(ds)
    out("\nDRIVE LAYOUT (folders, total size, files within)")
    out(f"  OFFGRID/   {_human(size.get(d, 0))}   ({nfiles.get(d, 0):,} files)")

    def walk(path, depth, prefix):
        try:
            subs = sorted((e.path for e in os.scandir(path) if e.is_dir()), key=lambda p: -size.get(p, 0))
        except OSError:
            return
        shown = subs[:LAYOUT_MAXKIDS]
        for p in shown:
            name = os.path.basename(p)
            out(f"  {prefix}{name}/   {_human(size.get(p, 0))}   ({nfiles.get(p, 0):,} files)")
            if depth + 1 < LAYOUT_DEPTH:
                walk(p, depth + 1, prefix + "   ")
        if len(subs) > LAYOUT_MAXKIDS:
            rest = sum(size.get(p, 0) for p in subs[LAYOUT_MAXKIDS:])
            out(f"  {prefix}… {len(subs) - LAYOUT_MAXKIDS} more folders   {_human(rest)}")

    walk(d, 0, "   ")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--test-ai", action="store_true")
    a = ap.parse_args()
    d = a.dest
    if not os.path.isdir(os.path.join(d, "www")):
        print(f"{d} doesn't look like an OFFGRID drive folder (no www). Use e.g. E:\\OFFGRID"); sys.exit(1)
    www = os.path.join(d, "www")
    out(f"OFF-GRID USB CHECK — {d} — {time.strftime('%Y-%m-%d %H:%M')}")

    out("\nLAUNCHERS & CORE")
    for f in ("START-HERE.bat", "start-here-mac-linux.sh", "READ-ME-FIRST.html", "DASHBOARD.html", "README.txt", "PROGRAMS/START-WINDOWS.bat",
              "PROGRAMS/start-mac-linux.sh", "PROGRAMS/ARCHIVES-NO-SERVER-WINDOWS.bat", "PROGRAMS/UPDATE-DRIVE-WINDOWS.bat"):
        ok(f, os.path.exists(os.path.join(d, f)), fix="re-run the builder (written at the very end)")
    for f in ("home.html", "ask.html", "topics.html", "topics-data.js", "search.html", "search/docs.js", "search/plen.js", "docs.js", "index.html", "config.js"):
        ok(f"www/{f}", os.path.exists(os.path.join(www, f)), fix="re-run the builder")
    ok("Builder copy on the drive (for updates)", os.path.exists(os.path.join(d, "tools", "builder", "usb", "usb_builder.py")),
       fix="run BUILD-USB-WINDOWS.bat from the laptop once")
    ul = os.path.join(d, "REPORTS", "UPDATE-LOG.txt")
    if os.path.exists(ul):
        days = (time.time() - os.path.getmtime(ul)) / 86400
        ok("Last update", days < 45, f"{time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(ul)))} ({days:.0f} days ago)",
           "START-HERE menu 7 (monthly)")
    ok("Portable Python (Windows)", os.path.exists(os.path.join(d, "tools", "python-win", "python.exe")))
    ok("Web server", os.path.exists(os.path.join(d, "tools", "serve_usb.py")))
    for f in ("leaflet.js", "protomaps-leaflet.js"):
        ok(f"Map library {f}", os.path.exists(os.path.join(www, "vendor", f)))
    gh = glob.glob(os.path.join(www, "library", "Getting Home", "get_home_*.html"))
    if os.path.isdir(os.path.join(www, "library", "Getting Home")):
        ok("Get-home route plans", len(gh) >= 6, f"{len(gh)} city plans + map layer", "re-run the builder")
    if os.path.exists(os.path.join(www, "docs.js")):
        try:
            n = open(os.path.join(www, "docs.js"), encoding="utf-8").read().count('],["')
            ok("Ask-the-Library index", n > 50, f"{n + 1} passages")
        except OSError:
            pass

    try:                                                   # index backup (BACKUP\INDEXES) + damaged/missing index files
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import index_backup, search_db
        last = index_backup.latest(d)
        ok("Index backup", bool(last), os.path.basename(last) if last else "none yet", "made at the end of every build / update")
        if last:
            mi, da = index_backup.check(d)
            ok("Index files intact", not (mi or da), f"{len(mi)} missing, {len(da)} damaged" if (mi or da) else "match the backup",
               "run PROGRAMS\\RESTORE-INDEXES.bat")
        gp = os.path.join(d, "ai", "memory", "drive-guide.txt")
        ok("AI drive guide", os.path.exists(gp), "ai\\memory\\drive-guide.txt" if os.path.exists(gp) else "missing", "REBUILD-SEARCH makes it")
        try:
            import ai_memory
            h = ai_memory.history(d, 1)
            ok("AI memory", True, f"{len(h.get('notes', []))} notes, {h.get('context_pages', 0):,} pages with AI notes",
               "AI-LEARN-THE-DRIVE-OVERNIGHT adds page notes")
        except Exception:  # noqa: BLE001
            pass
        rr = os.path.exists(os.path.join(d, "ai", "models", "bge-reranker-v2-m3-Q4_K_M.gguf"))
        ok("Answer re-sorter (reranker)", rr, "installed" if rr else "not yet", "downloaded with the offline AI (UPDATE-DRIVE)")
        m = search_db.info(d)
        ok("Fast search database", bool(m), f"{int(m.get('pages', 0)):,} pages" if m else "not built",
           "REBUILD-SEARCH (needs a Python with SQLite FTS5)")
    except Exception as ex:  # noqa: BLE001
        out(f"  ? index backup check: {ex}")

    out("\nOFFLINE AI")
    for key, exe in (("win", "llama-server.exe"), ("win-gpu", "llama-server.exe"), ("linux", "llama-server"),
                     ("macos-arm64", "llama-server"), ("macos-x64", "llama-server")):
        p = os.path.join(d, "ai", "bin", key, exe)
        if key.endswith("gpu") and not os.path.isdir(os.path.dirname(p)):
            continue
        ok(f"AI server for {key}", os.path.exists(p), fix="re-run the builder (AI step)")
    models = sorted(glob.glob(os.path.join(d, "ai", "models", "*.gguf")))
    ok("AI models present", bool(models), f"{len(models)} found", "re-run the builder")
    for m in models:
        size = gb(m)
        need = next((v for k, v in MODEL_MIN_GB.items() if k in os.path.basename(m)), 0.5)
        ok(f"  {os.path.basename(m)}", size >= need, f"{size:.1f} GB", "incomplete download — re-run the builder")
    for part in glob.glob(os.path.join(d, "ai", "models", "*.part")):
        ok(f"  {os.path.basename(part)}", False, f"{gb(part):.1f} GB partial", "re-run the builder to finish")
    dm = os.path.join(d, "ai", "default-model.txt")
    default = open(dm).read().strip() if os.path.exists(dm) else ""
    ok("Default model set", bool(default) and os.path.exists(os.path.join(d, "ai", "models", default)), default)
    try:
        roles = json.load(open(os.path.join(d, "ai", "roles.json")))
    except (OSError, ValueError):
        roles = {}
    for role, label in (("large", "Big model for 32 GB+ computers (Qwen 14B)"), ("vision", "Photo model (Gemma 3 vision)"),
                        ("medical", "Medical model (MedGemma)")):
        spec = roles.get(role) or {}
        files = [spec.get("model"), spec.get("mmproj")] if role != "large" else [spec.get("model")]
        good = all(f and os.path.exists(os.path.join(d, "ai", "models", f)) for f in files)
        ok(label, good, fix="re-run the builder (AI step)")
    for key, exe in (("win", "whisper-server.exe"), ("linux", "whisper-server")):
        ok(f"Voice input server for {key}", os.path.exists(os.path.join(d, "ai", "whisper", key, exe)), fix="re-run the builder (voice step)")
    wm = os.path.join(d, "ai", "whisper", "ggml-base.en.bin")
    ok("Voice model (Whisper base.en)", gb(wm) > 0.1, f"{gb(wm) * 1000:.0f} MB" if os.path.exists(wm) else "", "re-run the builder")

    out("\nLOCATOR (nearby places)")
    pj = os.path.join(www, "data", "pois.js")
    if os.path.exists(pj):
        txt = open(pj, encoding="utf-8").read()
        try:
            meta = json.loads(re.search(r"window\.POI_META=(.*?);\s*window\.POIS=", txt, re.S).group(1))
            rows = json.loads(re.search(r"window\.POIS=(.*?);\s*$", txt, re.S).group(1))
        except (AttributeError, ValueError):
            meta, rows = {}, []
        counts = {}
        for r in rows:
            counts[r[0]] = counts.get(r[0], 0) + 1
        ok("Places database", len(rows) > 1000, f"{len(rows):,} places within {meta.get('radius')} mi, built {meta.get('built')}")
        for k, label in meta.get("categories", {}).items():
            c = counts.get(k, 0)
            note = "" if c or k in ("repeater", "broadcast") else "  ← none (re-run builder later if this should have places)"
            if k in ("repeater", "broadcast") and not c:
                note = "  (normal on the USB — comes from FCC/RepeaterBook on the NOMAD machine)"
            out(f"        {label:<45} {c:>6}{note}")
    else:
        ok("Places database", False, fix="re-run the builder (locator step)")
    inc = os.path.join(www, "data", "overpass", "INCOMPLETE")
    if os.path.exists(inc):
        ok("All place categories downloaded", False, open(inc).read().replace("\n", ", "), "re-run the builder later")
    m = os.path.join(www, "map", "region.pmtiles")
    z = None
    try:
        with open(m, "rb") as f:
            h = f.read(127)
        z = h[101] if h[:7] == b"PMTiles" else None
    except OSError:
        pass
    ok("Street map", gb(m) > 0.05, (f"{gb(m):.2f} GB, zoom 0-{z}" if z is not None else f"{gb(m):.2f} GB") if os.path.exists(m) else "not built",
       "re-run the builder (map step) or skip with --no-map")
    if z is not None and z < 14:
        out(f"        note: zoom {z} shows main roads only; re-run the builder (default zoom 14) for every street")
    if os.path.exists(m + ".part"):
        ok("Street map download", False, "partial file present", "re-run the builder")

    out("\nMAPS")
    for name, label in (("topo", "Topo map layer (USGS)"), ("topo-south", "South-wide topo layer"), ("hillshade", "Terrain shading layer")):
        try:
            inf = json.load(open(os.path.join(www, "tiles", name, "info.json")))
            n = sum(len(fs) for _, _, fs in os.walk(os.path.join(www, "tiles", name)))
            ok(label, inf.get("complete", False), f"zoom {inf.get('minzoom')}-{inf.get('maxzoom')}, {n:,} tiles",
               "some tiles failed — re-run the builder")
        except (OSError, ValueError):
            ok(label, False, "not built", "re-run the builder (or --no-tiles)")
    fz = os.path.join(www, "data", "flood.js")
    ok("FEMA flood zones", gb(fz) > 0.00001, f"{gb(fz) * 1000:.1f} MB" if os.path.exists(fz) else "not built", "re-run the builder")
    # free space on the drive — the usual reason topo quads don't download
    try:
        free_gb = shutil.disk_usage(d).free / 1e9
    except OSError:
        free_gb = None
    try:
        cat = json.load(open(os.path.join(www, "topo", "catalog.json"), encoding="utf-8"))
    except (OSError, ValueError):
        cat = None
    pdfs = glob.glob(os.path.join(www, "topo", "*", "*.pdf"))
    # home quads: how many were found (catalogued) vs actually downloaded, and whether the drive has room
    home_q = (cat or {}).get("home") or {}
    home_found = home_q.get("quads") or []
    home_need = sum(q.get("gb", 0) for q in home_found if not os.path.exists(os.path.join(www, "topo", q["rel"])))
    if pdfs:
        ok("USGS topo GeoPDFs (home)", True, f"{len(pdfs)} quads, {sum(gb(x) for x in pdfs):.1f} GB")
    elif home_found and free_gb is not None and free_gb < home_need + 5:
        ok("USGS topo GeoPDFs (home)", False,
           f"0 of {len(home_found)} quads — DRIVE FULL (needs ~{home_need:.0f} GB, only {free_gb:.0f} GB free)",
           "free up space (remove some movies/archives, or copy them off) then re-run the builder")
    elif home_found:
        ok("USGS topo GeoPDFs (home)", False,
           f"0 of {len(home_found)} quads found but not downloaded ({free_gb:.0f} GB free)",
           "re-run the builder — the download step was interrupted; it resumes where it left off")
    else:
        ok("USGS topo GeoPDFs (home)", False, "0 quads (not catalogued yet)",
           "re-run the builder; if it keeps failing the USGS map service may have been down")
    if free_gb is not None:
        tight = free_gb < 30
        ok("Free space on this drive", not tight, f"{free_gb:.0f} GB free",
           "topo quads and updates need room — free up space or use a bigger drive" if tight else "")
    try:
        for g in ("Military bases", "Cities", "Lakes, bays & coast"):
            ar = [x for x in (cat or {}).get("areas", {}).values() if x["group"] == g]
            if not ar:
                continue
            tot = sum(len(x["quads"]) for x in ar)
            have = sum(1 for x in ar for q in x["quads"] if os.path.exists(os.path.join(www, "topo", q["rel"])))
            need = sum(q.get("gb", 0) for x in ar for q in x["quads"] if not os.path.exists(os.path.join(www, "topo", q["rel"])))
            fix = ("free up space — these need ~%.0f GB but only %.0f GB is free" % (need, free_gb)) if (free_gb is not None and have == 0 and free_gb < need) \
                  else "re-run the builder (the extra areas download last, after the big archives)"
            ok(f"Topo quads: {g}", have >= tot * 0.98, f"{len(ar)} areas, {have:,} of {tot:,} quads", fix)
    except (OSError, ValueError, AttributeError):
        ok("Topo quads: cities / lakes / bases", False, "not built yet", "re-run the builder (or --no-areas)")
    mil = os.path.join(www, "data", "military.js")
    ok("Military installations overlay", gb(mil) > 0.00001, f"{gb(mil) * 1000:.1f} MB" if os.path.exists(mil) else "not built",
       "re-run the builder")
    mine = [f for r, _, fs in os.walk(os.path.join(www, "mymaps")) for f in fs if not f.startswith("_") and f != "index.html"]
    out(f"  {'My Maps':<34} {len(mine)} files" + ("" if mine else " — add yours: put files in MY-MAPS-INBOX, START-HERE menu 5"))
    gpx = os.path.join(www, "data", "export", "all-places.gpx")
    ok("GPS files (GPX/KML)", os.path.exists(gpx), f"{gb(gpx) * 1000:.1f} MB" if os.path.exists(gpx) else "", "re-run the builder")

    out("\nPHONE APPS & VAULT")
    for app in ("OsmAnd", "Organic Maps", "Kiwix", "Meshtastic", "F-Droid", "ATAK-CIV"):
        apks = glob.glob(os.path.join(www, "phone-apps", "android", app, "*.apk"))
        ok(f"Android app: {app}", bool(apks), f"{gb(apks[0]) * 1000:.0f} MB" if apks else "", "re-run the builder")
    obfs = glob.glob(os.path.join(www, "phone-apps", "osmand-maps", "*.obf"))
    ok("OsmAnd state maps", len(obfs) >= 5, f"{len(obfs)} of 5", "re-run the builder")
    fw = glob.glob(os.path.join(www, "phone-apps", "meshtastic-firmware", "*", "*.zip"))
    ok("Meshtastic firmware", bool(fw), f"{len(fw)} packs", "re-run the builder")
    vc = glob.glob(os.path.join(d, "tools", "veracrypt", "*", "*"))
    ok("VeraCrypt installers", len(vc) >= 3, f"{len(vc)} files", "re-run the builder")
    ok("Family vault created", os.path.exists(os.path.join(d, "family-vault.hc")), "",
       "optional: create family-vault.hc with VeraCrypt (see the Family document vault guide)")

    out("\nARCHIVES (Kiwix)")
    for key, exe in (("win", "kiwix-serve.exe"), ("linux", "kiwix-serve"), ("macos-arm64", "kiwix-serve"), ("macos-x64", "kiwix-serve")):
        p = os.path.join(d, "kiwix", "bin", key, exe)
        if os.path.exists(p) or key in ("win", "linux"):
            ok(f"Kiwix reader for {key}", os.path.exists(p), fix="re-run the builder (archives step)")
    ok("Portable Kiwix reader (no server needed)", os.path.exists(os.path.join(d, "kiwix", "desktop", "windows", "kiwix-desktop.exe")),
       fix="re-run the builder (archives step)")
    zims = sorted(glob.glob(os.path.join(d, "kiwix", "zim", "*.zim")))
    ok("Archives (.zim)", bool(zims), f"{len(zims)} files, {sum(gb(z) for z in zims):.1f} GB")
    for z in zims:
        out(f"        {os.path.basename(z):<55} {gb(z):6.2f} GB")
    for z in glob.glob(os.path.join(d, "kiwix", "zim", "*.part")):
        ok(f"  {os.path.basename(z)}", False, "partial", "re-run the builder to finish")

    sd = os.path.join(www, "search", "docs.js")
    if os.path.exists(sd):
        try:
            sdocs = json.loads(re.search(r"window\.SEARCH_DOCS=(.*?);\n", open(sd, encoding="utf-8").read(), re.S).group(1))
            ok("Full-text search index", bool(sdocs), f"{len(sdocs)} documents, {sum(x[4] for x in sdocs):,} pages")
        except (AttributeError, ValueError, OSError):
            ok("Full-text search index", False, "unreadable", "re-run the builder")
    else:
        ok("Full-text search index", False, "not built", "re-run the builder (built at the end)")

    out("\nLIBRARY (manuals & guides)")
    tsv = next((t for t in TSV_CANDIDATES if os.path.exists(t)), None)
    have_n = 0
    missing = {}        # (category, file) -> (category, title, [every URL tried])
    if tsv:
        for line in open(tsv, encoding="utf-8"):
            p = line.rstrip("\n").split("\t")
            if len(p) < 4 or p[0].startswith("#"):
                continue
            cat, title, fname, url = p[:4]
            if fname.endswith("_COMPLETE.pdf"):
                continue
            if url.startswith("archive:"):
                url = "https://archive.org/details/" + url[8:]
            key = (cat, fname)
            if os.path.exists(os.path.join(www, "library", cat, fname)):
                have_n += 1
            elif key in missing:
                if url != "local":
                    missing[key][2].append(url)
            else:
                missing[key] = (cat, title, [url] if url != "local" else [])
        miss_n = len(missing)
        ok("Library documents", miss_n == 0, f"{have_n} present, {miss_n} missing")
        os.makedirs(os.path.join(d, "REPORTS"), exist_ok=True)
        mm = os.path.join(d, "REPORTS", "MISSING-MANUALS.html")
        mt = os.path.join(d, "REPORTS", "MISSING-MANUALS.txt")
        if missing:
            import html as _h
            import urllib.parse as _up
            rows, mlines = [], []
            for (cat, fname), (_, title, urls) in sorted(missing.items()):
                q = _up.quote_plus(f'"{re.sub(r" [(—].*", "", title)[:80]}" filetype:pdf')
                links = " ".join(f"<a href='{_h.escape(x)}' target='_blank'>{'link ' + str(i + 1) if len(urls) > 1 else 'open'}</a>"
                                 for i, x in enumerate(urls)) or "<i>written for this library — re-run the builder</i>"
                rows.append(f"<tr><td>{_h.escape(title)}</td><td>{links} · <a href='https://duckduckgo.com/?q={q}' target='_blank'>search the web</a>"
                            f" · <a href='https://archive.org/search?query={_up.quote_plus(title[:80])}' target='_blank'>archive.org</a></td>"
                            f"<td><code>OFFGRID\\www\\library\\{_h.escape(cat)}\\</code></td><td><code>{_h.escape(fname)}</code></td></tr>")
                mlines.append(f"[{cat}] {title}\n    file: {fname}\n" + "".join(f"    tried: {x}\n" for x in urls))
            with open(mm, "w", encoding="utf-8") as fh:
                fh.write("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Missing manuals</title><style>"
                         "body{font:15px/1.5 system-ui;background:#14171a;color:#e6e8eb;padding:16px;max-width:1200px;margin:auto}"
                         "a{color:#d9a441}td,th{border-bottom:1px solid #2c323a;padding:6px;text-align:left;vertical-align:top}"
                         "table{border-collapse:collapse;width:100%}code{background:#0f1214;padding:1px 4px}</style></head><body>"
                         f"<h1>{miss_n} manuals the builder couldn't download</h1><p>Most of these sites block automatic downloads but work "
                         "in a normal browser. With internet on: click <b>open</b>, save the PDF into the folder shown with the file name shown "
                         "(rename it if needed), then re-run the builder so it's added to the library and search. If the link is dead, try "
                         "<b>search the web</b> or <b>archive.org</b> — any copy of the same document works.</p><p>Or send "
                         "<b>MISSING-MANUALS.txt</b> (next to this file) to Claude to look for other sources; working links get added to the "
                         "builder so the next run fetches them on its own.</p>"
                         f"<table><tr><th>Manual</th><th>Get it</th><th>Save into</th><th>File name</th></tr>{''.join(rows)}</table></body></html>")
            with open(mt, "w", encoding="utf-8", newline="\r\n") as fh:
                fh.write(f"MISSING MANUALS ({miss_n}) - checked {time.strftime('%Y-%m-%d')}\n\n" + "\n".join(mlines))
            out(f"      Clickable list with folders, file names and web-search links: {mm}")
            out(f"      Plain list to send for other sources: {mt}")
            for (cat, fname), (_, title, urls) in sorted(missing.items()):
                out(f"        - [{cat}] {title}")
        else:
            for f in (mm, mt):
                if os.path.exists(f):
                    os.remove(f)
    else:
        out("  (manuals.tsv not found next to this checker — run it from the repository's usb folder)")
    extra = [f for f in glob.glob(os.path.join(www, "library", "*", "*")) if os.path.isfile(f)]
    out(f"      Files in library folders: {len(extra)} ({folder_gb(os.path.join(www, 'library')):.2f} GB)")
    txt = glob.glob(os.path.join(d, "TEXT-ONLY", "*", "*.txt"))
    ok(f"Plain-text copies for no-browser computers (TEXT-ONLY): {len(txt)}", len(txt) > 20, "", "re-run the builder")
    ok("No-browser search (SEARCH-NO-BROWSER-WINDOWS.bat)", os.path.exists(os.path.join(d, "PROGRAMS", "SEARCH-NO-BROWSER-WINDOWS.bat")))
    ok("Portable VLC player (tools\\vlc)", os.path.exists(os.path.join(d, "tools", "vlc", "vlc.exe")), "", "re-run the builder with internet")
    ok("Portable PDF/e-book reader (tools\\sumatra)", os.path.exists(os.path.join(d, "tools", "sumatra", "SumatraPDF.exe")), "", "re-run the builder with internet")
    try:
        mc = open(os.path.join(www, "media", "catalog.js"), encoding="utf-8").read()
        mi = json.loads(mc[len("window.MEDIA="):].rstrip().rstrip(";"))["items"]
        if not mi:
            raise ValueError
        out(f"  [OK ] Movies & TV: {sum(1 for i in mi if 'Movies' in i['c'])} movies, {sum(1 for i in mi if 'TV' in i['c'])} episodes")
    except (OSError, ValueError, KeyError):
        out("  [-- ] Movies & TV: none yet (optional) — START-HERE menu 4")
    try:
        mc = open(os.path.join(www, "music", "catalog.js"), encoding="utf-8").read()
        md = json.loads(mc[len("window.MUSIC="):].rstrip().rstrip(";"))
        if not md["songs"]:
            raise ValueError
        out(f"  [OK ] Music: {len(md['songs']):,} songs, {len(md['albums']):,} albums")
    except (OSError, ValueError, KeyError):
        out("  [-- ] Music: none yet (optional) — START-HERE menu M")
    imgs = glob.glob(os.path.join(www, "library", "My Radio Programming", "*.img"))
    lists = glob.glob(os.path.join(www, "library", "My Radio Programming", "* - channel list.html"))
    if imgs or os.path.isdir(os.path.join(www, "library", "My Radio Programming")):
        ok(f"Radio CHIRP images: {len(imgs)}, readable channel lists: {len(lists)}", len(lists) >= len(imgs) > 0, "",
           "START-HERE menu P (put files in MY-RADIO-INBOX first)")
    else:
        out("  [-- ] Radio: none yet (optional) - put your radio's CHIRP .img / manual in MY-RADIO-INBOX, then menu P")
    books = glob.glob(os.path.join(www, "library", "Books - *", "*.epub"))
    ok(f"E-books (Bible, history, classics, children's): {len(books)} of about 40", len(books) >= 34)

    if a.test_ai and models:
        out("\nAI TEST")
        key = {"Windows": "win", "Linux": "linux"}.get(platform.system(), "macos-arm64" if platform.machine() == "arm64" else "macos-x64")
        exe = os.path.join(d, "ai", "bin", key, "llama-server.exe" if key == "win" else "llama-server")
        model = os.path.join(d, "ai", "models", default or os.path.basename(models[0]))
        if not os.path.exists(exe):
            ok("AI test", False, f"no server for {key}")
        else:
            proc = subprocess.Popen([exe, "-m", model, "--host", "127.0.0.1", "--port", "8089", "-c", "2048"],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            t0, ready = time.time(), False
            while time.time() - t0 < 240 and proc.poll() is None:
                try:
                    if json.loads(urllib.request.urlopen("http://127.0.0.1:8089/health", timeout=5).read()).get("status") == "ok":
                        ready = True; break
                except Exception:  # noqa: BLE001
                    pass
                time.sleep(3)
            ok("AI server starts and loads the model", ready, f"{time.time() - t0:.0f} s")
            if ready:
                body = json.dumps({"messages": [{"role": "user", "content": "In one sentence: how do you purify creek water?"}],
                                   "max_tokens": 60}).encode()
                t1 = time.time()
                try:
                    r = json.loads(urllib.request.urlopen(urllib.request.Request(
                        "http://127.0.0.1:8089/v1/chat/completions", data=body, headers={"Content-Type": "application/json"}), timeout=300).read())
                    ans = r["choices"][0]["message"]["content"].strip().replace("\n", " ")
                    ok("AI answers", bool(ans), f"{time.time() - t1:.0f} s: {ans[:150]}")
                except Exception as e:  # noqa: BLE001
                    ok("AI answers", False, str(e)[:120])
            proc.terminate()

    out("\nSUMMARY")
    out(f"  Drive folder size: {folder_gb(d):.1f} GB")
    if problems:
        out(f"  {len(problems)} item(s) need attention:")
        for p in problems:
            out(f"   - {p}")
    else:
        out("  Everything checked is in place.")
    try:
        layout(d)
    except Exception as e:  # noqa: BLE001
        out(f"\nDRIVE LAYOUT — could not build ({str(e)[:100]})")
    os.makedirs(os.path.join(d, "REPORTS"), exist_ok=True)
    rep = os.path.join(d, "REPORTS", "CHECK-REPORT.txt")
    with open(rep, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"\nReport saved to {rep}")


if __name__ == "__main__":
    main()
