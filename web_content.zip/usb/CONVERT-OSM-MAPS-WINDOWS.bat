@echo off
REM Convert the OpenStreetMap .pbf files you dropped in the drive's  OSM-MAP-SOURCE  folder into
REM offline, scrollable map layers (pmtiles). First run downloads a small Java runtime + Planetiler.
REM Big files take a while and a lot of temp space; it's resumable (a finished layer is skipped).
REM Optional: pass the drive letter, e.g.  CONVERT-OSM-MAPS-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
echo.
echo  Converting OpenStreetMap files in %DRIVE%:\OFFGRID\OSM-MAP-SOURCE into map layers.
echo  Put your *.osm.pbf files in that folder first. Large files can take a while.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --convert-maps-only
pause
