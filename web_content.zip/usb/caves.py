"""Caves within N miles of home, with coordinates - one quick OpenStreetMap query (minutes, no big downloads).

Writes CAVES\\ on the drive:  Caves-<N>mi.xlsx / .csv / .kml / .gpx  (name, miles, direction, latitude, longitude,
MGRS, DMS, state-less notes: access, fee, description, website, OSM link).
    python caves.py --dest E:\\OFFGRID --radius 500      (or run ADD-CAVES-WINDOWS.bat)
Cave entrances are volunteer-mapped in OpenStreetMap: many well-known caves are missing and some are gated, on
private land or closed to protect bats. Always confirm access before going.
"""
import argparse
import csv
import html
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "scripts"))
OUT = "CAVES"


def _query_filters():
    return ['["natural"="cave_entrance"]', '["geological"="cave"]', '["tourism"="attraction"]["name"~"[Cc]avern|[Cc]ave\\b"]["natural"!="cave_entrance"]']


def fetch_caves(u, lat, lon, radius):
    """Return a list of dicts. Tries one radius query per filter; falls back to four quadrant boxes if the server balks."""
    meters = int(radius * 1609.34)
    els = {}
    for f in _query_filters()[:2]:
        q = f"[out:json][timeout:300];nwr(around:{meters},{lat},{lon}){f};out center tags;"
        d = u._overpass_query(q, "caves")
        if d is None:                                   # fall back: four boxes, exact distance filtered below
            dl, dn = radius / 69.0, radius / (69.17 * math.cos(math.radians(lat)))
            d = {"elements": []}
            for s_, n_ in ((lat - dl, lat), (lat, lat + dl)):
                for w_, e_ in ((lon - dn, lon), (lon, lon + dn)):
                    p = u._overpass_query(f"[out:json][timeout:300];nwr({s_:.4f},{w_:.4f},{n_:.4f},{e_:.4f}){f};out center tags;", "caves (part)")
                    if p is None:
                        return None
                    d["elements"] += p.get("elements", [])
        for e in d.get("elements", []):
            els[(e["type"], e["id"])] = e
    return list(els.values())


def _miles(a, b, c, d):
    r = math.radians
    x = math.sin(r(c - a) / 2) ** 2 + math.cos(r(a)) * math.cos(r(c)) * math.sin(r(d - b) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(x))


def _dir(a, b, c, d):
    r = math.radians
    p = r(d - b)
    deg = (math.degrees(math.atan2(math.sin(p) * math.cos(r(c)), math.cos(r(a)) * math.sin(r(c)) - math.sin(r(a)) * math.cos(r(c)) * math.cos(p))) + 360) % 360
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int((deg + 22.5) // 45) % 8]


def rows_from(els, lat0, lon0, radius):
    import coords
    out = []
    for e in els:
        la, lo = e.get("lat"), e.get("lon")
        if la is None and e.get("center"):
            la, lo = e["center"]["lat"], e["center"]["lon"]
        if la is None:
            continue
        mi = _miles(lat0, lon0, la, lo)
        if mi > radius:
            continue
        t = e.get("tags") or {}
        name = t.get("name") or t.get("alt_name") or "(unnamed cave entrance)"
        notes = "; ".join(x for x in (
            ("access: " + t["access"]) if t.get("access") else "", ("fee: " + t["fee"]) if t.get("fee") else "",
            t.get("description", ""), ("ele " + t["ele"] + " m") if t.get("ele") else "", ("length " + t["length"]) if t.get("length") else "",
            ("operator: " + t["operator"]) if t.get("operator") else "") if x)
        out.append({"name": name, "miles": round(mi, 1), "dir": _dir(lat0, lon0, la, lo), "lat": round(la, 6), "lon": round(lo, 6),
                    "mgrs": coords.mgrs(la, lo), "dms": coords.dms(la, lo), "notes": notes,
                    "web": t.get("website") or t.get("contact:website") or t.get("url") or "", "osm": f"https://www.openstreetmap.org/{e['type']}/{e['id']}"})
    out.sort(key=lambda r: r["miles"])
    return out


def write(dest, rows, radius):
    import xlsx_export
    out = os.path.join(dest, OUT)
    os.makedirs(out, exist_ok=True)
    stem = f"Caves-{radius:g}mi"
    cols = ["name", "miles", "dir", "lat", "lon", "mgrs", "dms", "notes", "web", "osm"]
    heads = ["Name", "Miles from home", "Direction", "Latitude", "Longitude", "MGRS", "DMS", "Notes", "Website", "OpenStreetMap"]
    with open(os.path.join(out, stem + ".csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(heads)
        for r in rows:
            w.writerow([r[c] for c in cols])
    wb = xlsx_export.Workbook(os.path.join(out, stem + ".xlsx"))
    wb.sheet("Caves", heads, ([r[c] for c in cols] for r in rows), [34, 10, 9, 12, 12, 18, 30, 40, 30, 36])
    wb.close()
    esc = html.escape
    pm = ""
    for r in rows:
        d = f"{r['miles']} mi {r['dir']} of home. MGRS {r['mgrs']}. {r['notes']}"
        pm += (f"<Placemark><name>{esc(r['name'])}</name><description>{esc(d)}</description>"
               f"<Point><coordinates>{r['lon']},{r['lat']},0</coordinates></Point></Placemark>\n")
    open(os.path.join(out, stem + ".kml"), "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>' + stem + "</name>\n" + pm + "</Document></kml>\n")
    wp = "".join(f'<wpt lat="{r["lat"]}" lon="{r["lon"]}"><name>{esc(r["name"])}</name><desc>{esc(r["notes"])} MGRS {r["mgrs"]}</desc><sym>Cave</sym></wpt>\n' for r in rows)
    open(os.path.join(out, stem + ".gpx"), "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="OFF-GRID drive" xmlns="http://www.topografix.com/GPX/1/1">\n' + wp + "</gpx>\n")
    return out


def run(u, dest, lat, lon, radius=500):
    u.say(f"Caves within {radius:g} miles")
    els = fetch_caves(u, lat, lon, radius)
    if els is None:
        print("  ! The OpenStreetMap servers did not answer. Try again later (nothing was changed).")
        return 0
    rows = rows_from(els, lat, lon, radius)
    out = write(dest, rows, radius)
    named = sum(1 for r in rows if not r["name"].startswith("("))
    print(f"  {len(rows):,} cave entrances ({named:,} named) within {radius:g} miles -> {out}")
    return len(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--lat", type=float, default=34.2367)
    ap.add_argument("--lon", type=float, default=-84.4908)
    ap.add_argument("--radius", type=float, default=500)
    a = ap.parse_args()
    import usb_builder as u
    run(u, a.dest, a.lat, a.lon, a.radius)
