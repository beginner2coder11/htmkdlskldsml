﻿"""Tidy the Library: give every document a clean title-based name, sort loose files into the right section and
move exact duplicates aside - without breaking search.

  python organize_drive.py --dest E:\\OFFGRID            preview only (writes REPORTS\\organize-plan.txt, changes nothing)
  python organize_drive.py --dest E:\\OFFGRID --apply    do it (every move is logged; nothing is deleted)
  python organize_drive.py --dest E:\\OFFGRID --undo     put everything back exactly as it was

What it touches: documents in www\\library\\<section>\\ (PDF, EPUB, Word, text ...).
What it leaves alone: the built-in manuals list (library\\manuals.tsv) and downloader-managed folders (Army - ..., Language - ...,
Archive.org gun manuals, Marine Corps, radio programming), because the downloaders find their files by name and would fetch them again.
Duplicates (byte-identical files) are MOVED to REPORTS\\organize-duplicates\\, never deleted.
Search stays intact: the text already read (and any OCR) is carried over to each new name, so nothing has to be re-read.
"""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import library_inbox  # noqa: E402  (section rules)

DOC_EXT = {".pdf", ".epub", ".mobi", ".azw3", ".txt", ".doc", ".docx", ".rtf", ".odt", ".djvu"}
MANAGED = ("army - ", "almanacs - ", "language - ", "firearms - archive.org", "marine corps", "my radio programming", "buy list", "books - ")
SMALL = {"a", "an", "and", "as", "at", "by", "for", "in", "of", "on", "or", "the", "to", "vs", "with"}
JUNK_TITLE = re.compile(r"^(microsoft word|untitled|document\d*|scan|new document|powerpoint)|\.(docx?|pdf|indd|qxd|pptx?|tmp)$|^\W*$", re.I)


def _key(rel):
    return hashlib.sha1(rel.encode()).hexdigest()[:14]          # same key search_index / ocr use


def clean_name(stem):
    s = re.sub(r"(?i)[\s_.-]*\(?z-?lib(\.org)?\)?|[\s_-]*\(?libgen[^)]*\)?", "", stem)
    for _ in range(3):
        s = re.sub(r"(?i)[\s_-]*copy$|\s*\(\d{1,2}\)$|\s*\[\d\]$", "", s)
    if "_" in s and " " not in s:
        s = s.replace("_", " ")
    elif "+" in s and " " not in s:
        s = s.replace("+", " ")
    elif " " not in s and s.count("-") >= 3:
        s = s.replace("-", " ")
    s = re.sub(r"\s+", " ", s).strip(" .-_")
    if s and not re.search(r"[A-Z]", s):
        s = " ".join(w if (i and w in SMALL) else w.capitalize() for i, w in enumerate(s.split(" ")))
    return s


def looks_junk(s):
    if len(s) < 4 or JUNK_TITLE.search(s):
        return True
    if " " not in s and (len(s) > 14 or sum(c.isdigit() for c in s) > len(s) / 2):
        return True
    return bool(re.match(r"^(ARN\d+|IMG|DSC|SCAN|DOC)[\d_-]", s, re.I))


def safe_filename(s):
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", s)
    s = re.sub(r"\s+", " ", s).strip(" .")
    return s[:130].strip(" .") or "untitled"


def pdf_title(pypdf, path):
    if not pypdf or not path.lower().endswith(".pdf"):
        return ""
    try:
        t = (pypdf.PdfReader(path).metadata or {}).get("/Title") or ""
    except Exception:  # noqa: BLE001
        return ""
    t = re.sub(r"\s+", " ", str(t)).strip()
    return "" if looks_junk(t) or len(t) > 150 else t


def new_stem(path, pypdf):
    stem = os.path.splitext(os.path.basename(path))[0]
    c = clean_name(stem)
    if not looks_junk(c):
        return c or stem
    meta = pdf_title(pypdf, path)
    m = re.match(r"(?i)ARN\d+-([A-Z]+)_([\d.]+(?:-\d+)*?)-000", stem)       # Army ARN file names: ARN38160-FM_3-90-000-WEB-1
    num = f"{m.group(1).upper()} {m.group(2)}" if m else ""
    if meta:
        return clean_name(meta if not num or num.lower() in meta.lower() else f"{num} {meta}")
    return c or stem


def _sha(path):
    return library_inbox._sha(path)


def collect(lib, tsv_paths):
    docs = []
    for sec in sorted(os.listdir(lib)):
        d = os.path.join(lib, sec)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            ext = os.path.splitext(f)[1].lower()
            if os.path.isfile(p) and ext in DOC_EXT and not f.endswith("_COMPLETE.pdf") and f != "index.html":
                managed = sec.lower().startswith(MANAGED) or f"library/{sec}/{f}" in tsv_paths
                docs.append({"path": p, "sec": sec, "name": f, "managed": managed, "size": os.path.getsize(p)})
    return docs


def make_plan(dest, rename=True, resort=True, dups=True, pypdf=None):
    lib = os.path.join(dest, "www", "library")
    tsv = set()
    tp = os.path.join(HERE, "..", "library", "manuals.tsv")
    if os.path.exists(tp):
        for line in open(tp, encoding="utf-8"):
            p = line.rstrip("\n").split("\t")
            if len(p) >= 4 and not p[0].startswith("#"):
                tsv.add(f"library/{p[0]}/{p[2]}")
    docs = collect(lib, tsv)
    plan, taken = [], {d["path"].lower() for d in docs}
    moved_away = set()
    if dups:
        by_size = {}
        for d in docs:
            by_size.setdefault(d["size"], []).append(d)
        for group in by_size.values():
            if len(group) < 2 or group[0]["size"] == 0:
                continue
            by_hash = {}
            for d in group:
                by_hash.setdefault(_sha(d["path"]), []).append(d)
            for same in by_hash.values():
                if len(same) < 2:
                    continue
                same.sort(key=lambda d: (not d["managed"], bool(re.search(r"(?i)copy|\(\d\)|\[\d\]", d["name"])), d["sec"] == "My Files", len(d["name"])))
                for d in same[1:]:
                    if d["managed"]:
                        continue
                    dp = os.path.join(dest, "REPORTS", "organize-duplicates", d["sec"], d["name"])
                    plan.append({"op": "dup", "src": d["path"], "dst": dp, "why": "same as " + os.path.relpath(same[0]["path"], lib)})
                    moved_away.add(d["path"])
    for d in docs:
        if d["managed"] or d["path"] in moved_away:
            continue
        sec, ext = d["sec"], os.path.splitext(d["name"])[1]
        stem = safe_filename(new_stem(d["path"], pypdf)) if rename else os.path.splitext(d["name"])[0]
        if resort and sec == "My Files":
            guess = library_inbox.section_for(stem + ext)
            if guess != "My Files":
                sec = guess
        dst = os.path.join(lib, sec, stem + ext)
        if dst == d["path"]:
            continue
        base, k = dst, 2
        while dst.lower() in taken and dst.lower() != d["path"].lower():
            dst = f"{os.path.splitext(base)[0]} ({k}){ext}"
            k += 1
        if dst == d["path"]:
            continue
        taken.discard(d["path"].lower())
        taken.add(dst.lower())
        what = []
        if os.path.basename(dst) != d["name"]:
            what.append("rename")
        if sec != d["sec"]:
            what.append("move")
        plan.append({"op": "+".join(what), "src": d["path"], "dst": dst, "why": ""})
    return plan, len(docs)


def write_plan(dest, plan):
    rd = os.path.join(dest, "REPORTS")
    os.makedirs(rd, exist_ok=True)
    out = os.path.join(rd, "organize-plan.txt")
    lib = os.path.join(dest, "www", "library")
    with open(out, "w", encoding="utf-8-sig", newline="\r\n") as fh:
        for p in plan:
            a = os.path.relpath(p["src"], lib) if p["src"].startswith(lib) else p["src"]
            b = os.path.relpath(p["dst"], lib) if p["dst"].startswith(lib) else os.path.relpath(p["dst"], dest)
            fh.write(f"[{p['op']}] {a}\n      -> {b}" + (f"   ({p['why']})" if p["why"] else "") + "\n")
    return out


def _rel(dest, p):
    return os.path.relpath(p, os.path.join(dest, "www")).replace(os.sep, "/")


def migrate_search(dest, pairs):
    """Carry the already-read text and OCR over to the new names so the search index does not have to re-read anything."""
    sdir = os.path.join(dest, "www", "search")
    mpath = os.path.join(sdir, "manifest.json")
    if not os.path.exists(mpath):
        return 0
    man = json.load(open(mpath, encoding="utf-8"))
    ocr_state_path = os.path.join(sdir, "ocr", "state.json")
    try:
        ocr_state = json.load(open(ocr_state_path, encoding="utf-8"))
    except (OSError, ValueError):
        ocr_state = {}
    n = 0
    for old, new in pairs:
        e = man.pop(old, None)
        if not e:
            continue
        ok, nk = e.get("key") or _key(old), _key(new)
        for sub, ext in (("text", ".js"), ("ocr", ".json")):
            a, b = os.path.join(sdir, sub, ok + ext), os.path.join(sdir, sub, nk + ext)
            if os.path.exists(a):
                if sub == "text":
                    s = open(a, encoding="utf-8").read().replace(f'"{ok}"', f'"{nk}"', 1)
                    open(b, "w", encoding="utf-8").write(s)
                else:
                    shutil.copy2(a, b)
                try:
                    os.remove(a)
                except OSError:
                    pass
        e["key"] = nk
        e["title"] = os.path.splitext(os.path.basename(new))[0]
        if new.startswith("library/"):
            e["cat"] = new.split("/")[1]
        man[new] = e
        if old in ocr_state:
            s = ocr_state.pop(old)
            s["key"] = nk
            ocr_state[new] = s
        n += 1
    json.dump(man, open(mpath, "w", encoding="utf-8"))
    if ocr_state:
        json.dump(ocr_state, open(ocr_state_path, "w", encoding="utf-8"))
    return n


def reindex(dest):
    print("  rebuilding the Library pages, topic index and search index ...")
    subprocess.call([sys.executable, os.path.join(HERE, "usb_builder.py"), "--dest", dest, "--my-files-only"])
    try:
        import usb_builder
        usb_builder.topics_index(dest)
    except Exception as ex:  # noqa: BLE001
        print(f"  (topic index not refreshed: {str(ex)[:80]})")


def apply_plan(dest, plan):
    ts = time.strftime("%Y%m%d-%H%M%S")
    log = os.path.join(dest, "REPORTS", f"organize-undo-{ts}.jsonl")
    os.makedirs(os.path.dirname(log), exist_ok=True)
    pairs, done = [], 0
    with open(log, "a", encoding="utf-8") as lf:
        for p in plan:
            try:
                os.makedirs(os.path.dirname(p["dst"]), exist_ok=True)
                dst = p["dst"]
                k = 2
                while os.path.exists(dst) and dst.lower() != p["src"].lower():
                    b, x = os.path.splitext(p["dst"])
                    dst, k = f"{b} ({k}){x}", k + 1
                os.replace(p["src"], dst)
            except OSError as ex:
                print(f"  ! {os.path.basename(p['src'])}: {ex}")
                continue
            lf.write(json.dumps({"src": p["src"], "dst": dst}) + "\n")
            lf.flush()
            pairs.append((_rel(dest, p["src"]), _rel(dest, dst)))
            done += 1
    in_lib = [(a, b) for a, b in pairs if b.startswith("library/")]
    gone = [a for a, b in pairs if not b.startswith("library/")]
    migrate_search(dest, in_lib)
    if gone:
        mp = os.path.join(dest, "www", "search", "manifest.json")
        if os.path.exists(mp):
            m = json.load(open(mp, encoding="utf-8"))
            for a in gone:
                m.pop(a, None)
            json.dump(m, open(mp, "w", encoding="utf-8"))
    print(f"  {done} file(s) changed. Undo log: {log}")
    return done


def undo(dest, which=None):
    rd = os.path.join(dest, "REPORTS")
    logs = sorted(f for f in os.listdir(rd) if f.startswith("organize-undo-")) if os.path.isdir(rd) else []
    if not logs:
        print("  nothing to undo (no organize-undo log found)")
        return 0
    path = which or os.path.join(rd, logs[-1])
    rows = [json.loads(x) for x in open(path, encoding="utf-8") if x.strip()]
    pairs = []
    for r in reversed(rows):
        try:
            os.makedirs(os.path.dirname(r["src"]), exist_ok=True)
            os.replace(r["dst"], r["src"])
            pairs.append((_rel(dest, r["dst"]), _rel(dest, r["src"])))
        except OSError as ex:
            print(f"  ! {os.path.basename(r['dst'])}: {ex}")
    migrate_search(dest, [(a, b) for a, b in pairs if a.startswith("library/") and b.startswith("library/")])
    os.replace(path, path + ".undone")
    print(f"  restored {len(pairs)} file(s)")
    return len(pairs)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--undo", action="store_true")
    ap.add_argument("--no-rename", action="store_true")
    ap.add_argument("--no-resort", action="store_true")
    ap.add_argument("--no-dups", action="store_true")
    ap.add_argument("--no-reindex", action="store_true")
    a = ap.parse_args()
    if a.undo:
        if undo(a.dest) and not a.no_reindex:
            reindex(a.dest)
        return
    pypdf = None
    try:
        import pypdf  # noqa: F811
    except ImportError:
        try:
            import search_index
            pypdf = search_index.get_pypdf(__import__("usb_builder"), a.dest) or None
        except Exception:  # noqa: BLE001
            pypdf = None
    plan, total = make_plan(a.dest, not a.no_rename, not a.no_resort, not a.no_dups, pypdf)
    cnt = {}
    for p in plan:
        cnt[p["op"]] = cnt.get(p["op"], 0) + 1
    print(f"  {total} documents checked; {len(plan)} would change: " + (", ".join(f"{k} {v}" for k, v in sorted(cnt.items())) or "none"))
    if plan:
        print(f"  full list: {write_plan(a.dest, plan)}")
        for p in plan[:8]:
            print(f"    {os.path.basename(p['src'])[:55]:<55} -> {os.path.basename(p['dst'])[:60]}")
    if not a.apply:
        if plan:
            print("  Preview only - nothing was changed. Run again with --apply to do it.")
        return
    if plan and apply_plan(a.dest, plan) and not a.no_reindex:
        reindex(a.dest)


if __name__ == "__main__":
    main()
