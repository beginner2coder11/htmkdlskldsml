﻿"""Language-learning books, sign language and the archive.org gun-manual collection, plus a book finder.

Build step (needs internet, only fetches what is missing):
  * Spanish, French and American Sign Language first (more with --languages): dictionaries, phrasebooks,
    courses and sign-language guides from the Internet Archive. Auto-downloads only items that are public-domain /
    Creative-Commons or a US-government work (Foreign Service Institute, Defense Language Institute, Peace Corps,
    US Army) - anything else is left out.
  * The archive.org "collectionofgunmanuals" collection (large / full drives), size-capped.
Everything lands under www\\library\\<category> so the drive's full-text search indexes it.

Book finder (any time you have internet):
  python languages.py --dest E:\\OFFGRID --search "spanish grammar" --lang spa
Lists matching PDF / EPUB books on archive.org and downloads the ones you pick into library\\My Books\\.
"""
import argparse, html as _html, json, os, re, sys, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

LANGS = {   # key -> (display name, library folder, queries)
    "spanish": ("Spanish", "Language - Spanish", ["spanish english dictionary", "learn spanish", "FSI spanish basic course",
                                                  "spanish phrasebook", "spanish for medical emergencies"]),
    "french": ("French", "Language - French", ["french english dictionary", "learn french", "FSI french basic course",
                                               "french phrasebook", "french for travelers"]),
    "asl": ("American Sign Language", "Language - Sign Language", ["american sign language", "sign language dictionary",
                                                                  "fingerspelling manual alphabet", "sign language basic course",
                                                                  "emergency sign language"]),
    "german": ("German", "Language - German", ["german english dictionary", "FSI german basic course", "german phrasebook"]),
    "arabic": ("Arabic", "Language - Arabic", ["arabic english dictionary", "FSI arabic basic course", "arabic phrasebook"]),
    "portuguese": ("Portuguese", "Language - Portuguese", ["portuguese english dictionary", "FSI portuguese course"]),
    "russian": ("Russian", "Language - Russian", ["russian english dictionary", "FSI russian basic course"]),
    "chinese": ("Chinese", "Language - Chinese", ["chinese english dictionary", "FSI chinese basic course"]),
    "creole": ("Haitian Creole", "Language - Haitian Creole", ["haitian creole english", "creole phrasebook"]),
}
DEFAULT_LANGS = "spanish,french,asl"
PER_LANG = {"small": 6, "medium": 10, "large": 20, "full": 40}
GUN_CAP = {"large": 150, "full": 900}   # new PDFs per run; the whole item is ~830 PDFs / 1.6 GB
FILE_CAP = 150e6
GOV = re.compile(r"foreign service institute|defense language|defence language|peace corps|department of the army|"
                 r"united states\.? (army|navy|air force|marine|war department|department)|\bFSI\b|\bDLI\b|u\.s\. army", re.I)


def _p(msg):
    enc = sys.stdout.encoding or "ascii"
    print(str(msg).encode(enc, "replace").decode(enc))


def _free(lic):
    l = (lic or "").lower()
    return "publicdomain" in l or "/zero/" in l or "/by/" in l or "/by-sa/" in l or l.endswith("/mark/1.0/")


def _safe(s, n=90):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", s).strip(" .")[:n] or "item"


def _search(u, q, rows=30, extra="", sort="downloads desc"):
    qs = urllib.parse.urlencode({"q": f"({q}) AND mediatype:texts{extra}", "rows": rows, "output": "json",
                                 "sort[]": sort}, doseq=True)
    qs += "&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=year&fl[]=licenseurl&fl[]=downloads&fl[]=language"
    try:
        return json.loads(u.fetch("https://archive.org/advancedsearch.php?" + qs, 60)).get("response", {}).get("docs", [])
    except Exception:  # noqa: BLE001
        return []


def _pick_file(u, ident):
    """Best book file of an archive.org item as (name, size, ext), or None (borrow-only items have none)."""
    try:
        files = json.loads(u.fetch(f"https://archive.org/metadata/{ident}", 60)).get("files", [])
    except Exception:  # noqa: BLE001
        return None
    cands = []
    for f in files:
        n = f.get("name", "")
        ext = n.rsplit(".", 1)[-1].lower() if "." in n else ""
        try:
            sz = int(f.get("size") or 0)
        except ValueError:
            sz = 0
        if ext in ("pdf", "epub") and 0 < sz <= FILE_CAP and "_text.pdf" not in n.lower() and not re.search(r"lcp|encrypt", n, re.I):
            cands.append((0 if ext == "pdf" else 1, -sz, n, sz, ext))
    if not cands:
        return None
    cands.sort()
    _, _, n, sz, ext = cands[0]
    return n, sz, ext


def _fetch_item(u, ident, title, folder):
    got = _pick_file(u, ident)
    if not got:
        return None
    n, sz, ext = got
    os.makedirs(folder, exist_ok=True)
    out = os.path.join(folder, _safe(title) + "." + ext)
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out, sz, False
    url = f"https://archive.org/download/{ident}/{urllib.parse.quote(n)}"
    try:
        u.download(url, out, title[:60], retries=2)
    except Exception as e:  # noqa: BLE001
        _p(f"  ! {title[:60]}: {e}")
        return None
    return (out, sz, True) if os.path.exists(out) and os.path.getsize(out) > 0 else None


def build(u, dest, profile="large", langs=DEFAULT_LANGS, guns=True):
    cap = PER_LANG.get(profile, 0)
    if cap:
        u.say("Language, sign-language and translation books (archive.org)")
        for key in [k.strip().lower() for k in langs.split(",") if k.strip()]:
            if key not in LANGS:
                print(f"  ! unknown language '{key}' (choices: {', '.join(LANGS)})")
                continue
            name, sub, queries = LANGS[key]
            folder = os.path.join(dest, "www", "library", sub)
            seen, added = set(), 0
            for q in queries:
                tq = "title:(" + " AND ".join(re.findall(r"[\w']+", q)) + ")"   # title match keeps results on-topic
                for d in _search(u, tq, rows=40):
                    ident = d.get("identifier")
                    title = d.get("title") if isinstance(d.get("title"), str) else (ident or "")
                    creator = d.get("creator") if isinstance(d.get("creator"), str) else " ".join(d.get("creator") or [])
                    if not ident or ident in seen or added >= cap:
                        continue
                    seen.add(ident)
                    if not (_free(d.get("licenseurl")) or GOV.search(f"{title} {creator}")):
                        continue
                    r = _fetch_item(u, ident, title, folder)
                    if r:
                        added += 1
                        if r[2]:                         # only show new downloads; ones already on the drive stay quiet
                            _p(f"  {name}: new - {title[:70]}")
            print(f"  {name}: {added} book(s) on the drive" + ("" if added else " (none free to redistribute found - "
                  "use FIND-BOOKS to browse and pick your own)"))
    if guns and GUN_CAP.get(profile):
        u.say("Gun manuals (archive.org item: collectionofgunmanuals)")
        folder = os.path.join(dest, "www", "library", "Firearms - Archive.org Gun Manuals")
        n = _fetch_all_pdfs(u, "collectionofgunmanuals", folder, GUN_CAP[profile])
        print(f"  {n} gun manual PDF(s) on the drive")


def _fetch_all_pdfs(u, ident, folder, cap):
    """Download up to `cap` new PDFs (each <= FILE_CAP) of one archive.org item that is a bundle of many PDFs."""
    try:
        files = json.loads(u.fetch(f"https://archive.org/metadata/{ident}", 120)).get("files", [])
    except Exception as e:  # noqa: BLE001
        print(f"  ! {ident}: {e}")
        return 0
    pdfs = [f for f in files if f.get("name", "").lower().endswith(".pdf") and "/" not in f["name"]
            and 0 < int(f.get("size") or 0) <= FILE_CAP and "_text.pdf" not in f["name"].lower()]
    os.makedirs(folder, exist_ok=True)
    have = new = 0
    for f in sorted(pdfs, key=lambda x: x["name"].lower()):
        out = os.path.join(folder, _safe(f["name"], 150))
        if os.path.exists(out) and os.path.getsize(out) > 0:
            have += 1
            continue
        if new >= cap:
            continue
        try:
            u.download(f"https://archive.org/download/{ident}/{urllib.parse.quote(f['name'])}", out, f["name"][:60], retries=2)
            new += 1
        except Exception as e:  # noqa: BLE001
            print(f"  ! {f['name']}: {e}")
    if new >= cap and len(pdfs) > have + new:
        print(f"  {len(pdfs) - have - new} more available ? re-run later to continue.")
    return have + new


def finder(u, dest, query, lang, fmt, limit):
    lang_q = f" AND language:({lang})" if lang else ""
    docs = _search(u, query, rows=limit, extra=lang_q)
    if not docs:
        print("No results (are you online?)")
        return
    for i, d in enumerate(docs, 1):
        t = d.get("title") if isinstance(d.get("title"), str) else d.get("identifier")
        tag = "free" if _free(d.get("licenseurl")) else "check rights"
        _p(f"{i:3}. {t[:80]}  [{d.get('year', '?')}] ({tag})")
    pick = input("\nNumbers to download (e.g. 1,3,5), 'all', or Enter to quit: ").strip().lower()
    if not pick:
        return
    idx = range(len(docs)) if pick == "all" else [int(x) - 1 for x in re.findall(r"\d+", pick) if 0 < int(x) <= len(docs)]
    folder = os.path.join(dest, "www", "library", "My Books")
    for i in idx:
        d = docs[i]
        t = d.get("title") if isinstance(d.get("title"), str) else d["identifier"]
        r = _fetch_item(u, d["identifier"], t, folder)
        _p(("  ok: " if r else "  no downloadable PDF/EPUB: ") + t[:70])
    print("Done. Run the builder (or the search index step) so the new books become searchable.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--search")
    ap.add_argument("--lang", default="")
    ap.add_argument("--limit", type=int, default=25)
    ap.add_argument("--languages", default=DEFAULT_LANGS)
    ap.add_argument("--profile", default="large")
    a = ap.parse_args()
    import usb_builder as u
    if a.search:
        finder(u, a.dest, a.search, a.lang, "pdf,epub", a.limit)
    else:
        build(u, a.dest, a.profile, a.languages)


if __name__ == "__main__":
    main()
