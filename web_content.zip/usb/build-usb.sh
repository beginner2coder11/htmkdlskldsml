#!/bin/sh
# Build the OFF-GRID SURVIVAL DRIVE from Linux or macOS:  sh build-usb.sh /media/<you>/<USB>   [builder options]
[ -z "$1" ] && { echo "Usage: sh build-usb.sh /path/to/usb [--models small,medium] [--no-map] ..."; exit 1; }
DEST="$1/OFFGRID"; shift
exec python3 "$(dirname "$0")/usb_builder.py" --dest "$DEST" "$@"
