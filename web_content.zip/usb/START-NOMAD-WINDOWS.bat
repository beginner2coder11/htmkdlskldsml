@echo off
REM Starts NOMAD again after a Windows restart (WSL2 install), keeps it running in the background, and opens it.
REM Leave the small minimized window open while you use NOMAD.
start "NOMAD keep-alive" /min wsl.exe -d Ubuntu-24.04 -u root -- sleep infinity
timeout /t 8 >nul
wsl.exe -d Ubuntu-24.04 -u root -- bash -c "mount --make-rshared / ; systemctl start docker ; [ -f /opt/project-nomad/start_nomad.sh ] && bash /opt/project-nomad/start_nomad.sh"
start "" http://localhost:8080
pause
