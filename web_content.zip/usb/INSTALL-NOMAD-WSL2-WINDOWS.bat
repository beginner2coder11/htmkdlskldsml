@echo off
REM Installs Project N.O.M.A.D. on this Windows PC through WSL2 (Ubuntu + Docker). Needs internet; about 100 GB free on C:.
REM Asks for Administrator. If Windows asks for a restart, restart and run this again.
REM To let other devices on your network open it, run:  INSTALL-NOMAD-WSL2-WINDOWS.bat -Lan
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0nomad_wsl2.ps1" %*
pause
