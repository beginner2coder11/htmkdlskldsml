"""OPEN-WITH\\ : one folder per program, so you never have to guess what opens what.

Each folder holds (hard links to) the drive's files that program can open, plus a READ-ME.txt that says
what the program is, where to get it, and exactly how to open the files.  Nothing is copied or moved: a hard
link is the same file under a second name, so it uses no extra space (Explorer may show the size twice).
On exFAT drives hard links aren't possible, so large files are only listed in WHERE-THE-FILES-ARE.txt.
Safe to re-run; it never deletes your files.   python openwith.py --dest E:\\OFFGRID
"""
import argparse
import fnmatch
import os

OUT = "OPEN-WITH"
CAP = 12000         # most links per folder
SMALL = 2 << 20     # files under 2 MB are copied when hard links aren't possible

# folder, [glob patterns relative to the drive root, ** = any depth], tree folders to mention, text
PROGRAMS = [
 ("1 Google Earth Pro", ["GOOGLE-EARTH-READY/*.kml", "GOOGLE-EARTH-READY/*.kmz"], [],
  "Google Earth Pro (free desktop app, earth.google.com/earth/versions).\n"
  "Your KML/KMZ map files, already fixed so the shapes show colour instead of white.\n"
  "HOW: double-click a file here, or open Google Earth Pro and use File > Open."),
 ("2 Phone maps - OsmAnd (Android and iPhone)", ["www/phone-apps/osmand-maps/*.obf", "www/phone-apps/osmand-maps/*.zip"], ["www/phone-apps"],
  "OsmAnd: offline maps with turn-by-turn navigation. The app installers are in www\\phone-apps (open the Phone Apps page).\n"
  "HOW (Android): copy the .obf file(s) to the phone's Download folder, then OsmAnd > Menu > Maps & Resources > Local > the three dots > Import.\n"
  "HOW (iPhone): AirDrop or Files app > share the .obf to OsmAnd."),
 ("3 Phone maps - Organic Maps", ["www/phone-apps/**/*.mwm", "MY-FILES-INBOX/**/*.mwm"], ["www/phone-apps"],
  "Organic Maps: simple offline maps and hiking. It downloads its own maps when online; .mwm files placed here can be loaded from the app's Maps folder.\n"
  "If this folder is empty, there are no .mwm files on the drive yet; use OsmAnd (folder 2) instead."),
 ("4 QGIS - desktop GIS (big map data)", ["www/map/*.pmtiles", "OSM-MAP-SOURCE/*.pbf", "www/topo/**/*.gpkg", "www/topo/**/*.tif", "www/topo/**/*.geojson"], ["www/topo"],
  "QGIS (free, qgis.org) opens the drive's raw map data: the vector tiles (.pmtiles, needs QGIS 3.32 or newer) and OpenStreetMap extracts (.pbf).\n"
  "HOW: QGIS > Layer > Add Layer > Add Vector Tile Layer (for .pmtiles) or Add Vector Layer (for .pbf and .gpkg).\n"
  "Most people never need this: the Command Center Maps tab already shows these maps."),
 ("5 Topo maps (GeoPDF) - Avenza Maps or Adobe Reader", ["www/topo/**/*.pdf"], ["www/topo"],
  "USGS topographic maps as GeoPDFs: they open in any PDF reader, and in Avenza Maps (phone) they show your GPS position.\n"
  "HOW (computer): double-click. HOW (phone): copy a PDF to the phone, open it in Avenza Maps.\n"
  "The whole set is browsable by place in the Command Center > Maps > Topo finder."),
 ("6 Map tiles - the Command Center map", [], ["www/tiles", "www/map"],
  "Nothing to open here. The map tiles (USGS topo, satellite, hillshade, Army map sheets) and the vector street map are shown by\n"
  "the Command Center > Maps tab, including offline. Their files live in www\\tiles and www\\map, and the browser reads them for you.\n"
  "To use the same tiles in another program, see folder 4 (QGIS)."),
 ("7 Kiwix - Wikipedia, medicine and how-to archives", ["kiwix/*.zim"], ["kiwix"],
  "Kiwix reader (free: phone app or desktop, kiwix.org). .zim files are whole offline websites.\n"
  "HOW: the Command Center > Library > Archives tile opens them in your browser with no install. In the Kiwix app, choose Open file and pick a .zim."),
 ("8 Offline AI models", ["ai/**/*.gguf"], ["ai"],
  "These are the AI brain files. You don't open them yourself: START-HERE.bat > 1 starts the AI and the Command Center uses them.\n"
  "Other apps that read .gguf: LM Studio, Jan, Off Grid AI."),
 ("9 Radio files - CHIRP and Baofeng", ["MY-RADIO-INBOX/**/*"], ["MY-RADIO-INBOX"],
  "CHIRP (free, chirpmyradio.com) loads and saves radio channel lists (.csv, .img) for the Baofeng UV-32 and most handhelds.\n"
  "HOW: connect the radio with its cable, open CHIRP > File > Open, pick the file here, then Radio > Upload To Radio."),
 ("A Phone app installers (Android)", ["www/phone-apps/android/*.apk", "www/phone-apps/meshtastic-firmware/*"], ["www/phone-apps"],
  "Android installer files (.apk) for OsmAnd, Organic Maps, Kiwix, Meshtastic, ATAK-CIV and F-Droid, plus Meshtastic radio firmware.\n"
  "HOW: open the Phone Apps page from the phone (see USE-ON-PHONE.html), or copy an .apk to the phone and tap it (allow installs from this source)."),
 ("B Movies and music - VLC", ["www/media/**/*.mp4", "www/media/**/*.mkv", "www/media/**/*.mp3", "www/music/**/*.mp3", "www/music/**/*.flac"], ["www/media", "www/music"],
  "VLC (free, videolan.org) plays everything. HOW: double-click a file, or drag it into VLC."),
 ("C Spreadsheets - Excel, Numbers, Google Sheets", ["EXCEL-READY/*.xlsx", "CAVES/*.xlsx", "CAVES/*.csv"], ["EXCEL-READY", "CAVES"],
  "Excel, LibreOffice Calc, Apple Numbers or Google Sheets open these (US cities, hospitals, places within 150 and 500 miles, caves, the medicine list).\n"
  "HOW: double-click. Phone: copy the file to the phone and open it in Excel or Sheets. Use the filter arrows on the top row to search; every place has latitude, longitude and MGRS."),
 ("D GPS waypoints - Garmin, OsmAnd, Gaia, ATAK (GPX)", ["www/data/export/*.gpx", "CAVES/*.gpx"], ["www/data/export", "CAVES"],
  "GPX files hold waypoints (hospitals, water, fuel, shelters, caves, military bases) that GPS devices and map apps read.\n"
  "HOW: Garmin - copy to the device's GPX folder, or open in BaseCamp. OsmAnd/Organic Maps/Gaia (phone) - share the file to the app. ATAK - import as a data package or GPX."),
 ("E E-books - phone and computer readers", ["www/library/**/*.epub", "MY-FILES-INBOX/**/*.epub"], ["www/library"],
  "E-books (.epub) open in Apple Books, Google Play Books, Moon+ Reader, KOReader or Calibre.\n"
  "The PDFs and guides are in www\\library, sorted by subject. Open the Command Center > Library for the indexed list."),
 ("F Notes - TiddlyWiki (Field Notebook)", ["FIELD-NOTEBOOK*.html"], ["SOFTWARE/TiddlyWiki"],
  "The Field Notebook is a notes file you can write in. Open it in TiddlyDesktop (computer) or Tiddloid / Quine (Android) so changes save back into the file.\n"
  "In an ordinary browser it opens read-only."),
 ("G Medical and poison references - Southeast US", ["www/library/Medical/**/*.pdf", "www/library/Southeast US/**/*.pdf"], ["www/library/Medical", "www/library/Southeast US"],
  "First-aid, medicine, poison, plant and snake references (UGA and Auburn plant guides, Georgia DNR snakes, Army and Marine first-aid manuals, Hesperian books).\n"
  "HOW: any PDF reader. On a phone, copy this folder to the phone's Files and open in the Files app, Google Drive PDF viewer or Adobe Reader. See also the Command Center > Quick response."),
 ("H Survival and disaster manuals - PDF readers", ["www/library/Survival/**/*.pdf", "www/library/Disasters/**/*.pdf", "www/library/Military Manuals/**/*.pdf"], ["www/library/Survival", "www/library/Disasters", "www/library/Military Manuals"],
  "Army, Marine, FEMA and civil-defense survival and disaster manuals, in any PDF reader. Phone tip: copy only the ones you want, since the set is large."),
]

CHEAT = [  # file type, what it is, opens with
 (".kml  .kmz", "Map overlay or placemarks", "Google Earth Pro (folder 1)"),
 (".pmtiles", "Whole-region vector street map", "The Command Center Maps tab, or QGIS 3.32+ (folder 4)"),
 (".pbf  (.osm.pbf)", "Raw OpenStreetMap data", "QGIS, or OsmAnd/Organic Maps converters (folder 4)"),
 (".obf", "OsmAnd phone map", "OsmAnd (folder 2)"),
 (".mwm", "Organic Maps phone map", "Organic Maps (folder 3)"),
 (".pdf  (GeoPDF topo)", "USGS topographic map sheet", "Any PDF reader; Avenza Maps on a phone (folder 5)"),
 ("Map tiles (www\\tiles)", "Picture tiles for zoomable maps", "The Command Center Maps tab (folder 6)"),
 (".zim", "Offline website (Wikipedia, medicine)", "Kiwix, or Command Center > Archives (folder 7)"),
 (".gguf", "AI model", "START-HERE.bat > 1 (folder 8)"),
 (".csv  .img  (radio)", "Radio channel list / memory image", "CHIRP (folder 9)"),
 (".gpx", "GPS track or waypoints", "OsmAnd, Organic Maps, Google Earth Pro, Garmin BaseCamp"),
 (".apk", "Android app", "Tap it on an Android phone (folder A)"),
 (".mp4  .mkv  .mp3", "Video and music", "VLC (folder B)"),
 (".epub", "E-book", "Any e-reader app; Calibre on a computer (folder E)"),
 (".xlsx  .csv", "Spreadsheet (cities, hospitals, places, caves, medicines)", "Excel, Numbers, Google Sheets (folder C)"),
]


def _walk_glob(dest, pattern):
    """Yield files matching pattern (forward slashes, ** = any depth)."""
    parts = pattern.split("/")
    base = dest
    i = 0
    while i < len(parts) and "*" not in parts[i] and "?" not in parts[i]:
        base = os.path.join(base, parts[i])
        i += 1
    if not os.path.isdir(base) and i < len(parts):
        return
    rest = parts[i:]
    if not rest:
        if os.path.isfile(base):
            yield base
        return
    recursive = rest[0] == "**"
    name_pat = rest[-1]
    if recursive:
        for r, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if not d.startswith(("_", "."))]
            for f in files:
                if fnmatch.fnmatch(f.lower(), name_pat.lower()):
                    yield os.path.join(r, f)
    else:
        try:
            for f in os.listdir(base):
                p = os.path.join(base, f)
                if os.path.isfile(p) and fnmatch.fnmatch(f.lower(), name_pat.lower()):
                    yield p
        except OSError:
            return


def _put(src, dst):
    """Hard-link, else copy if small. Returns 'link' | 'copy' | 'skip' | 'have'."""
    if os.path.exists(dst):
        return "have"
    try:
        os.link(src, dst)
        return "link"
    except OSError:
        pass
    try:
        if os.path.getsize(src) < SMALL:
            import shutil
            shutil.copy2(src, dst)
            return "copy"
    except OSError:
        pass
    return "skip"


def build_program(dest, spec):
    name, globs, trees, text = spec
    folder = os.path.join(dest, OUT, name)
    os.makedirs(folder, exist_ok=True)
    n = {"link": 0, "copy": 0, "skip": 0, "have": 0}
    skipped = []
    seen = set()
    for g in globs:
        for src in _walk_glob(dest, g):
            if sum(n.values()) >= CAP:
                break
            b = os.path.basename(src)
            dst = os.path.join(folder, b)
            k = 1
            while dst in seen or (os.path.exists(dst) and not os.path.samefile(src, dst)):
                stem, ext = os.path.splitext(b)
                dst = os.path.join(folder, f"{stem} ({k}){ext}")
                k += 1
            seen.add(dst)
            r = _put(src, dst)
            n[r] += 1
            if r == "skip":
                skipped.append(os.path.relpath(src, dest))
    lines = [name[2:] if len(name) > 2 and name[1] == " " else name, "=" * 50, "", text, ""]
    if trees:
        lines += ["Where the files really live on the drive:"] + [f"  {t.replace('/', os.sep)}" for t in trees] + [""]
    total = n["link"] + n["copy"] + n["have"]
    if globs:
        lines.append(f"{total} file(s) are in this folder (same files as elsewhere on the drive, no extra space used)." if total else "No matching files on the drive yet.")
    if skipped:
        lines += ["", "These large files could not be linked here (this drive is exFAT or FAT). Open them from their real location:"] + [f"  {s}" for s in skipped[:200]]
    with open(os.path.join(folder, "READ-ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return total, len(skipped)


def write_cheat(dest):
    root = os.path.join(dest, OUT)
    os.makedirs(root, exist_ok=True)
    rows = "".join(f"<tr><td><b>{a}</b></td><td>{b}</td><td>{c}</td></tr>" for a, b, c in CHEAT)
    folders = "".join(f"<li><b>{p[0]}</b> - {p[3].splitlines()[0]}</li>" for p in PROGRAMS)
    html = ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>What opens what</title>"
            "<style>body{font:16px system-ui;max-width:860px;margin:auto;padding:14px;background:#101417;color:#e6e8eb}td,th{border-bottom:1px solid #2c323a;padding:6px 10px;text-align:left}"
            "table{border-collapse:collapse;width:100%}h1,h2{margin:.6em 0 .2em}a{color:#7fb6ff}</style>"
            "<h1>What opens what</h1><p>Each folder next to this page is named for a program. Open the folder, read its READ-ME.txt, double-click the file.</p>"
            f"<h2>By file type</h2><table><tr><th>File</th><th>What it is</th><th>Opens with</th></tr>{rows}</table>"
            f"<h2>The folders</h2><ul>{folders}</ul><p><a href='../START-HERE.bat'>Back to START-HERE</a></p>")
    with open(os.path.join(root, "WHAT-OPENS-WHAT.html"), "w", encoding="utf-8") as fh:
        fh.write(html)
    if os.path.isdir(os.path.join(dest, "www")):
        with open(os.path.join(dest, "www", "openwith.html"), "w", encoding="utf-8") as fh:
            fh.write(html.replace("<a href='../START-HERE.bat'>Back to START-HERE</a>", "<a href='command.html'>Back to the Command Center</a>"))
    with open(os.path.join(root, "READ-ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("OPEN-WITH: one folder per program.\n\nOpen WHAT-OPENS-WHAT.html first. Then open the folder for the program you want; its READ-ME.txt explains how.\n"
                 "The files here are second names for files stored elsewhere on the drive (nothing is duplicated and nothing is deleted).\n\n"
                 + "\n".join(f"  {p[0]}" for p in PROGRAMS) + "\n")


def run(dest):
    os.makedirs(os.path.join(dest, OUT), exist_ok=True)
    for spec in PROGRAMS:
        total, sk = build_program(dest, spec)
        print(f"  {spec[0]}: {total} file(s)" + (f", {sk} not linkable" if sk else ""))
    write_cheat(dest)


def build(u, dest):
    run(dest)


if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--dest", required=True)
    run(a.parse_args().dest)
