@echo off
REM Double-click to test ONE topo map download and find out why topo sheets don't stay on the drive.
REM Optional: pass the drive letter, e.g.  TOPO-PROBE-WINDOWS.bat F
setlocal
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
set DRIVE=%DRIVE::=%
set ROOT=%DRIVE%:\OFFGRID
set PY=%ROOT%\tools\python-win\python.exe

if not exist "%PY%" (
  echo Could not find the drive's Python at "%PY%".
  echo Make sure the OFF-GRID drive is plugged in as %DRIVE%: and has been built at least once.
  pause
  exit /b 1
)

set PYTHONUTF8=1
"%PY%" "%~dp0topo_probe.py" "%ROOT%"
echo.
pause
