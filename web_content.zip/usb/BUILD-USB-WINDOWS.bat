@echo off
chcp 65001 >nul
REM Double-click to build the OFF-GRID SURVIVAL DRIVE on a USB drive (needs internet while building).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %*
pause
