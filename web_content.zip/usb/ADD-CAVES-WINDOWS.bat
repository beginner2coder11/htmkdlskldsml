@echo off
REM List caves (cave entrances) within a radius of home with coordinates: CSV, Excel, Google Earth KML and GPX in OFFGRID\CAVES.
REM One quick query - takes a few minutes, nothing else downloads. Type 500 (Enter) or another number of miles.
REM Optional: pass the drive letter, e.g.  ADD-CAVES-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
set MILES=
set /p MILES= How many miles around home? (Enter for 500): 
if "%MILES%"=="" set MILES=500
echo.
echo  Finding caves within %MILES% miles of home...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --caves-only --caves-radius %MILES%
pause
