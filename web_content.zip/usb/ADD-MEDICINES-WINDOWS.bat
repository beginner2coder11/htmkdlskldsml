@echo off
REM Download the FDA drug labels and build the Medicine list (what each OTC and prescription drug is used for, plus warnings).
REM One-time download of about 1-2 GB (kept in tools\meds-source so a re-run does not download again); takes a while.
REM Also writes EXCEL-READY\Medicines.xlsx. Optional: pass the drive letter, e.g.  ADD-MEDICINES-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --meds-only
pause
