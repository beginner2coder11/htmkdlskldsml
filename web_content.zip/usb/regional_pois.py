"""Places (hospitals, pharmacies, food, restaurants, gun & pawn shops, fuel, water ...) out to 800 miles (set with --radius).

The online query service (Overpass) cannot return a 800-mile area, so this reads state map extracts
instead (Geofabrik .osm.pbf, ~9 GB at 500 miles, ~15 GB at 800, deleted after each state is read) with the same place
classifier as the 150-mile locator. Resumable: a finished state is skipped on the next run.

Output (all under www\\data\\poi500\\): one small .js file per state + index.js, read by places500.html,
and one KML per category in GOOGLE-EARTH-READY\\Places-wide-area\\.

    python regional_pois.py --dest E:\\OFFGRID --lat 34.2367 --lon -84.4908 --radius 800
"""
import argparse
import glob
import html
import io
import json
import math
import os
import re
import sys
import time
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (os.path.join(os.path.dirname(HERE), "scripts"), os.path.join(HERE, "scripts")):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.append(_p)
GEOFABRIK = "https://download.geofabrik.de/north-america/us/{}-latest.osm.pbf"
OUTDIR = os.path.join("www", "data", "poi500")

# south, west, north, east (approximate) of the states that can be within ~800 miles of north Georgia
STATES = {
    "georgia": (30.36, -85.61, 35.00, -80.84), "alabama": (30.22, -88.47, 35.01, -84.89),
    "florida": (24.40, -87.63, 31.00, -80.03), "south-carolina": (32.03, -83.35, 35.22, -78.54),
    "north-carolina": (33.84, -84.32, 36.59, -75.46), "tennessee": (34.98, -90.31, 36.68, -81.65),
    "mississippi": (30.17, -91.65, 35.00, -88.10), "virginia": (36.54, -83.68, 39.47, -75.17),
    "kentucky": (36.50, -89.57, 39.15, -81.96), "west-virginia": (37.20, -82.64, 40.64, -77.72),
    "arkansas": (33.00, -94.62, 36.50, -89.64), "louisiana": (28.93, -94.04, 33.02, -88.82),
    "ohio": (38.40, -84.82, 41.98, -80.52), "indiana": (37.77, -88.10, 41.76, -84.78),
    "illinois": (36.97, -91.51, 42.51, -87.50), "missouri": (35.99, -95.77, 40.61, -89.10),
    "maryland": (37.91, -79.49, 39.72, -75.05), "pennsylvania": (39.72, -80.52, 42.27, -74.69),
    "kansas": (36.99, -102.05, 40.00, -94.59), "nebraska": (39.99, -104.05, 43.00, -95.31),
    "wisconsin": (42.49, -92.89, 47.08, -86.25), "michigan": (41.70, -90.42, 48.31, -82.12),
    "minnesota": (43.50, -97.24, 49.38, -89.49), "new-york": (40.50, -79.76, 45.02, -71.86),
    "new-jersey": (38.93, -75.56, 41.36, -73.89), "delaware": (38.45, -75.79, 39.84, -75.05),
    "connecticut": (40.98, -73.73, 42.05, -71.79), "massachusetts": (41.24, -73.51, 42.89, -69.93),
    "district-of-columbia": (38.79, -77.12, 38.99, -76.91), "texas": (25.84, -106.65, 36.50, -93.51),
    "oklahoma": (33.62, -103.00, 37.00, -94.43), "iowa": (40.38, -96.64, 43.50, -90.14),
}


def _miles(la1, lo1, la2, lo2):
    r = math.radians
    a = math.sin(r(la2 - la1) / 2) ** 2 + math.cos(r(la1)) * math.cos(r(la2)) * math.sin(r(lo2 - lo1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(a))


def states_for(lat, lon, radius):
    """States whose bounding box comes within `radius` miles of home (slightly generous on purpose)."""
    out = []
    for st, (s, w, n, e) in STATES.items():
        if _miles(lat, lon, min(max(lat, s), n), min(max(lon, w), e)) <= radius:
            out.append(st)
    return out


def get_osmium(u, dest):
    """Import pyosmium, fetching its wheel from PyPI into tools\\pylib the first time."""
    try:
        import osmium  # noqa: F401
        return osmium
    except ImportError:
        pass
    libdir = os.path.join(dest, "tools", "pylib", "osmium-pkg")
    if not glob.glob(os.path.join(libdir, "osmium*")):
        tag = f"cp{sys.version_info[0]}{sys.version_info[1]}"
        plat = {"win32": "win_amd64", "darwin": "macosx"}.get(sys.platform, "manylinux")
        try:
            meta = json.loads(u.fetch("https://pypi.org/pypi/osmium/json", 60))
            files = [f for f in meta["urls"] if f["filename"].endswith(".whl") and plat in f["filename"]
                     and (f"-{tag}-" in f["filename"] or "abi3" in f["filename"])]
            if sys.platform not in ("win32", "darwin"):
                files = [f for f in files if "x86_64" in f["filename"] or "aarch64" in f["filename"]]
            if not files:
                print(f"  ! no pyosmium build for Python {tag} on {sys.platform}")
                return None
            f = files[0]
            data = u.fetch(f["url"], 300)
            os.makedirs(libdir, exist_ok=True)
            zipfile.ZipFile(io.BytesIO(data)).extractall(libdir)
        except Exception as e:  # noqa: BLE001
            print(f"  ! could not get pyosmium (the OpenStreetMap reader): {e}")
            return None
    sys.path.insert(0, libdir)
    try:
        import osmium
        return osmium
    except Exception as e:  # noqa: BLE001
        print(f"  ! pyosmium would not load: {e}")
        return None


def _sig(p):
    return [os.path.getsize(p), int(os.path.getmtime(p))] if os.path.exists(p) else None


def _score(row):
    return sum(1 for x in row[4:9] if x)


def dedupe_states(out, order):
    """Remove repeats across every finished state file (border places, a point + building for the same shop).
    Earlier states in `order` win. Rewrites the .js files; returns {state: new count} and the number removed."""
    import build_pois
    cells, counts, removed = {}, {}, 0
    for st in order:
        fp = os.path.join(out, st + ".js")
        try:
            txt = open(fp, encoding="utf-8").read()
            data = json.loads(txt[txt.index('"]=') + 3:].rstrip().rstrip(";"))
        except (OSError, ValueError):
            continue
        kept, n = build_pois.dedupe(data, key=lambda r: (r[0], r[1], r[2], r[3]), score=_score, seen_cells=cells)
        if n:
            with open(fp, "w", encoding="utf-8") as fh:
                fh.write(f'(window.POIR=window.POIR||{{}})["{st}"]=' + json.dumps(kept, separators=(",", ":")) + ";\n")
            removed += n
        counts[st] = len(kept)
    return counts, removed


def run(u, dest, lat, lon, radius=500, only=None, keep_source=False, areas=False):
    import build_pois
    u.say(f"Places within {radius:g} miles (hospitals, pharmacies, food, restaurants, gun & pawn shops, fuel, water ...)")
    sts = [s for s in (only or states_for(lat, lon, radius)) if s in STATES]
    print("  states: " + ", ".join(sts))
    out = os.path.join(dest, OUTDIR)
    os.makedirs(out, exist_ok=True)
    ip = os.path.join(out, "index.json")
    try:
        idx = json.load(open(ip, encoding="utf-8"))
    except (OSError, ValueError):
        idx = {}
    if idx.get("radius") != radius or [idx.get("lat"), idx.get("lon")] != [lat, lon]:
        idx = {"states": {}}                                     # a new center/radius: start over
    idx.update({"lat": lat, "lon": lon, "radius": radius})
    done = idx.setdefault("states", {})
    todo = [s for s in sts if s not in done]
    src = os.path.join(dest, "tools", "poi-source")
    if not keep_source:                                          # leftovers of states that are already converted
        for st in done:
            for old in (os.path.join(src, st + ".osm.pbf"),):
                if os.path.exists(old):
                    try:
                        gb = os.path.getsize(old) / 1e9
                        os.remove(old)
                        print(f"  removed leftover {st}.osm.pbf ({gb:.1f} GB freed)")
                    except OSError:
                        pass
    if not todo:
        print("  all states already done")
    else:
        osmium = get_osmium(u, dest)
        if not osmium:
            print("  ! Cannot read OpenStreetMap files without pyosmium. The 150-mile locator is unaffected.")
            return 0
        build_pois.osmium = osmium
        src = os.path.join(dest, "tools", "poi-source")
        os.makedirs(src, exist_ok=True)
        seen = set()
        need_gb = 10
        if u.free_gb(dest) < need_gb:
            print(f"  ! only {u.free_gb(dest):.0f} GB free; need about {need_gb} GB while it runs")
            return 0
        for n, st in enumerate(todo, 1):
            pbf = os.path.join(src, st + ".osm.pbf")
            shared = os.path.join(dest, "OSM-MAP-SOURCE", st + ".osm.pbf")      # already downloaded for the street maps? reuse it
            own = not os.path.exists(pbf) and os.path.exists(shared)
            if own:
                pbf = shared
            print(f"\n  [{n}/{len(todo)}] {st}")
            if not os.path.exists(pbf) and not u.download(GEOFABRIK.format(st), pbf, f"{st}.osm.pbf"):
                print(f"  ! {st}: download failed, will retry next run")
                continue
            t0 = time.time()
            try:
                rows = build_pois.read_pbf(pbf, lat, lon, radius, seen, areas=areas)
            except Exception as e:  # noqa: BLE001
                print(f"  ! {st}: {type(e).__name__}: {e}")
                continue
            rows.sort(key=lambda r: (r["cat"], r["miles"]))
            data = [[r["cat"], r["name"], r["lat"], r["lon"], r["addr"], r["phone"], r["web"], r["hours"], r["info"]] for r in rows]
            with open(os.path.join(out, st + ".js"), "w", encoding="utf-8") as fh:
                fh.write(f'(window.POIR=window.POIR||{{}})["{st}"]=' + json.dumps(data, separators=(",", ":")) + ";\n")
            done[st] = len(rows)
            print(f"    {len(rows):,} places in {(time.time() - t0) / 60:.1f} min")
            json.dump(idx, open(ip, "w", encoding="utf-8"))      # progress is saved after every state
            if not keep_source and not own:           # (OSM-MAP-SOURCE files belong to the street-map converter)
                try:
                    os.remove(pbf)
                except OSError:
                    pass
    counts, dups = dedupe_states(out, [s for s in STATES if s in done])
    if dups:
        print(f"  removed {dups:,} duplicate places (repeats across states and same shop mapped twice)")
        done.update(counts)
    idx["cats"] = build_pois.CATEGORIES
    idx["bbox"] = {k: STATES[k] for k in done if k in STATES}
    idx["built"] = time.strftime("%Y-%m-%d")
    json.dump(idx, open(ip, "w", encoding="utf-8"))
    with open(os.path.join(out, "index.js"), "w", encoding="utf-8") as fh:
        fh.write("window.POIR_INDEX=" + json.dumps(idx, separators=(",", ":")) + ";\n")
    total = sum(done.values())
    print(f"\n  {total:,} places in {len(done)} states -> www\\data\\poi500\\  (open Places 800 from the Command Center)")
    try:
        import kml_export
        kml_export.places500(dest)
        import xlsx_export
        xlsx_export.run(dest)
        import hospitals_data
        hospitals_data.build(sys.modules.get("usb_builder") or u, dest)
    except Exception as e:  # noqa: BLE001
        print(f"  ! Google Earth/Excel files: {type(e).__name__}: {e}")
    return total


def build(u, dest):
    """Finish-loop hook: only refreshes the KMLs/index when wide-area data already exists."""
    if os.path.exists(os.path.join(dest, OUTDIR, "index.json")):
        import kml_export
        kml_export.places500(dest)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--lat", type=float, default=34.2367)
    ap.add_argument("--lon", type=float, default=-84.4908)
    ap.add_argument("--radius", type=float, default=500)
    ap.add_argument("--only", default="", help="comma list of states (default: every state in range)")
    ap.add_argument("--delete-source", action="store_true", help="delete each state extract after reading it (saves ~15 GB; raising the radius later re-downloads)")
    a = ap.parse_args()
    import usb_builder as u
    run(u, a.dest, a.lat, a.lon, a.radius, [x for x in a.only.split(",") if x] or None, not a.delete_source)
