@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Add your movies and TV shows to this drive (organized, searchable, plays in the browser) =====
REM Step 1 only LOOKS at your files and shows a plan. Nothing is copied, renamed or deleted until you say so.
cd /d "%~dp0"
title Add movies and shows
chcp 65001 >nul
set PYTHONUTF8=1
set "PY=tools\python-win\python.exe"
if not exist "%PY%" set "PY=python"
set "MP=tools\builder\usb\media.py"
echo.
echo  Plug in the drive that has your movies and shows.
echo  Type its folder or drive letter, e.g.  F:\   or   F:\Movies   (or drag the folder onto this window)
echo  Just press Enter to only rebuild the Movies ^& TV page from what's already on this drive.
echo.
set "SRC="
set /p "SRC=Movies/shows folder: "
if not defined SRC goto catalog
set SRC=%SRC:"=%
if "%SRC:~-1%"=="\" set "SRC=%SRC%."
"%PY%" %MP% --dest "%~dp0." --src "%SRC%"
if errorlevel 1 goto end
start "" "REPORTS\MEDIA-PLAN.html"
echo.
echo  The plan is open in your browser. Rows marked "check" have a guessed name: fix them in REPORTS\MEDIA-PLAN.csv
echo  (open it with Excel or Notepad, change the title/year/kind/season/episode/kids columns, save) - or leave them.
echo.
echo    C = COPY them onto this drive (your other drive stays as it is)
echo    M = MOVE them (each original is deleted from the other drive after its copy is checked)
echo    N = do nothing now (run this again later; it will re-plan)
echo.
choice /c CMN /n /m "Copy, Move or Nothing? "
if errorlevel 3 goto end
if errorlevel 2 (set "MODE=move") else (set "MODE=copy")
"%PY%" %MP% --dest "%~dp0." --apply %MODE%
:catalog
"%PY%" %MP% --dest "%~dp0." --catalog-only
echo.
echo  Done. Open Home ^> Movies ^& TV (or www\media\index.html). Files that won't play in the browser open in VLC:
echo  tools\vlc\vlc.exe
:end
pause
