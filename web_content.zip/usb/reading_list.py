"""Commandant's Professional Reading List (FY26, ALMAR 024/25): download the legally free titles and
build the checklist page (readinglist.html).

Free: Marine Corps University Press / History Division open-access books, Project Gutenberg public-domain
books, and the Marine Corps doctrine (MCDP/MCWP/MCRP) from the Marine Corps Publications Electronic Library.
Everything else on the list is a commercial book: it appears on the checklist with a link to find it at a
library, nothing is downloaded.   python reading_list.py --dest E:\\OFFGRID
"""
import argparse
import json
import os
import re
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import joint_doctrine as jd  # noqa: E402
import state_maps as sm  # noqa: E402  (page fetch + pdf link finder)

FOLDER = "Commandants Reading List"
MCUP = "https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/Books-by-topic/MCUP-Titles-A-Z/"
MCPEL = "https://www.marines.mil/News/Publications/MCPEL/"

# (category, title, author, free-key or "")
LIST = [
 ("Commandant's Choice", "Once an Eagle", "Anton Myrer", ""),
 ("Heritage", "How the Few Became the Proud: Crafting the Marine Corps Mystique, 1874-1918", "Heather Venable", ""),
 ("Heritage", "Lejeune: A Marine's Life, 1867-1942", "Merrill L. Bartlett", ""),
 ("Heritage", "First to Fight: An Inside View of the U.S. Marine Corps", "Victor H. Krulak", ""),
 ("Heritage", "Always Faithful: 250 Years of Remarkable Stories from the Collections of the National Museum of the Marine Corps", "Owen Conner", "always"),
 ("Heritage", "Semper Fidelis: 250 Years of U.S. Marine Corps Honor, Courage, and Commitment", "Marine Corps History Division", "semper"),
 ("Heritage", "With the Old Breed: At Peleliu and Okinawa", "Eugene B. Sledge", ""),
 ("Heritage", "Delivering Destruction: American Firepower and Amphibious Assault from Tarawa to Iwo Jima", "Chris K. Hemler", ""),
 ("Heritage", "This Kind of War: The Classic Korean War History", "T.R. Fehrenbach", ""),
 ("Heritage", "The Marines of Montford Point: America's First Black Marines", "Melton A. McLaurin", ""),
 ("Heritage", "Code Talker", "Chester Nez and Judith Avila", ""),
 ("Heritage", "Corps Competency?: III Marine Amphibious Force Headquarters in Vietnam", "Michael F. Morris", ""),
 ("Heritage", "Targeted: Beirut: The 1983 Marine Barracks Bombing and the Untold Story of the War on Terror", "Jack Carr and James M. Scott", ""),
 ("Heritage", "Echo in Ramadi: The Firsthand Story of US Marines in Iraq's Deadliest City", "Scott A. Huesing", ""),
 ("Heritage", "The American War in Afghanistan: A History", "Carter Malkasian", ""),
 ("Heritage", "On Contested Shores: The Evolving Role of Amphibious Operations in the History of Warfare (Vols. I & II)", "Heck, Friedman, Mills (eds.)", "shores"),
 ("Innovation", "Learning War: The Evolution of Fighting Doctrine in the U.S. Navy, 1898-1945", "Trent Hone", ""),
 ("Innovation", "A Game of Birds and Wolves", "Simon Parkin", ""),
 ("Innovation", "Playing War: Wargaming and U.S. Navy Preparations for World War II", "John M. Lillard", ""),
 ("Innovation", "Neptune's Inferno: The U.S. Navy at Guadalcanal", "James D. Hornfischer", ""),
 ("Innovation", "A New Conception of War: John Boyd, the U.S. Marines, and Maneuver Warfare", "Ian T. Brown", ""),
 ("Innovation", "Where Good Ideas Come From", "Steven Johnson", ""),
 ("Innovation", "The Origins of Victory", "Andrew F. Krepinevich Jr.", ""),
 ("Innovation", "Evolution on Demand: The Changing Roles of the U.S. Marine Corps in Twenty-first Century Conflicts and Beyond", "Joanna Siekiera (ed.)", "evolution"),
 ("Innovation", "7 Seconds to Die", "John F. Antal", ""),
 ("Innovation", "Next War: Reimagining How We Fight", "John F. Antal", ""),
 ("Innovation", "The Fourth Industrial Revolution", "Klaus Schwab", ""),
 ("Innovation", "Soft-Wired", "Michael Merzenich", ""),
 ("Innovation", "Co-Intelligence: Living and Working with AI", "Ethan Mollick", ""),
 ("Innovation", "Generative AI for Leaders", "Amir Husain", ""),
 ("Innovation", "The Arms of the Future", "Jack Watling", ""),
 ("Leadership", "Make Your Bed", "Admiral William H. McRaven", ""),
 ("Leadership", "You Are Worth It", "Kyle Carpenter", ""),
 ("Leadership", "The White Donkey: Terminal Lance", "Maximilian Uriarte", ""),
 ("Leadership", "On Killing", "LtCol Dave Grossman", ""),
 ("Leadership", "Wisdom of the Bullfrog", "Admiral William H. McRaven", ""),
 ("Leadership", "Matterhorn", "Karl Marlantes", ""),
 ("Leadership", "The Yompers: With 45 Commando in the Falklands War", "Ian R. Gardiner", ""),
 ("Leadership", "Generals and Admirals, Criminals and Crooks", "Jeffrey Matthews", ""),
 ("Leadership", "Leadership Strategy and Tactics: Field Manual", "Jocko Willink", ""),
 ("Leadership", "The Greatest U.S. Marine Corps Stories Ever Told", "Iain C. Martin", ""),
 ("Leadership", "Call Sign Chaos: Learning to Lead", "Jim Mattis and Bing West", ""),
 ("Leadership", "Risk: A User's Guide", "Stanley McChrystal", ""),
 ("Leadership", "Nimitz at War", "Craig L. Symonds", ""),
 ("Leadership", "Five Generations at Work", "Rebecca Robins and Patrick Dunne", ""),
 ("Leadership", "Essentialism: The Disciplined Pursuit of Less", "Greg McKeown", ""),
 ("Strategy", "The Closing of the American Mind", "Allan Bloom", ""),
 ("Strategy", "The Defence of Duffer's Drift", "Ernest Dunlop Swinton", "duffer"),
 ("Strategy", "Ender's Game", "Orson Scott Card", ""),
 ("Strategy", "Legacy: 15 Lessons in Leadership", "James Kerr", ""),
 ("Strategy", "The Infinite Game", "Simon Sinek", ""),
 ("Strategy", "Turn the Ship Around!", "L. David Marquet", ""),
 ("Strategy", "On Grand Strategy", "John Lewis Gaddis", ""),
 ("Strategy", "Speed Kills: Leveraging John Boyd's OODA Loop to Build Organizations That Win", "Alex Vohr", ""),
 ("Strategy", "The New Makers of Modern Strategy", "Hal Brands (ed.)", ""),
 ("Strategy", "Ground Combat: Puncturing the Myths of Modern War", "Ben Connable", ""),
 ("Strategy", "The Generals' War", "Michael Gordon and Bernard Trainor", ""),
 ("Strategy", "Command: The Politics of Military Operations from Korea to Ukraine", "Lawrence Freedman", ""),
 ("Strategy", "The Russian Way of Deterrence", "Dmitry Adamsky", ""),
 ("Strategy", "The Long Game: China's Grand Strategy to Displace American Order", "Rush Doshi", ""),
 ("Strategy", "Fleet Tactics and Naval Operations, 3rd ed.", "Wayne Hughes and Robert Girrier", ""),
 ("Strategy", "Chinese Amphibious Warfare: Prospects for a Cross-Straits Invasion", "Erickson, Kennedy, Martinson", ""),
 ("Foundation", "Constitution of the United States of America", "James Madison, et al.", "constitution"),
 ("Foundation", "Warfighting (MCDP 1)", "United States Marine Corps", "mcdp1"),
 ("Foundation", "Competing (MCDP 1-4)", "United States Marine Corps", "mcdp14"),
 ("Foundation", "Intelligence (MCDP 2)", "United States Marine Corps", "mcdp2"),
 ("Foundation", "Expeditionary Operations (MCDP 3)", "United States Marine Corps", "mcdp3"),
 ("Foundation", "Logistics (MCDP 4)", "United States Marine Corps", "mcdp4"),
 ("Foundation", "Learning (MCDP 7)", "United States Marine Corps", "mcdp7"),
 ("Foundation", "Leading Marines (MCWP 6-11)", "United States Marine Corps", "mcwp611"),
 ("Foundation", "Sustaining the Transformation (MCRP 6-11D)", "United States Marine Corps", "mcrp611d"),
]
# free-key -> how to fetch.  ("pdf", url) direct; ("page", url) find PDFs on a page; ("gut", id) Gutenberg epub;
# ("mcpel", search-word, slug-regex) Marine Corps Publications Electronic Library.
FREE = {
 "always": ("page", MCUP + "Always-Faithful/"),
 "semper": ("pdf", "https://www.usmcu.edu/Portals/218/Semper%20Fidelis_web.pdf"),
 "shores": ("page", MCUP + "On-Contested-Shores/", "https://www.usmcu.edu/Portals/218/OnContestedShores%20vol%202_web.pdf"),
 "evolution": ("pdf", "https://www.usmcu.edu/Portals/218/Evolution%20on%20Demand%20web2.pdf"),
 "duffer": ("gut", 24842),
 "constitution": ("gut", 5),
 "mcdp1": ("mcpel", "warfighting", r"/mcdp-1/?$"),
 "mcdp14": ("mcpel", "competing", r"mcdp-1-4"),
 "mcdp2": ("mcpel", "intelligence", r"/mcdp-2/?$"),
 "mcdp3": ("mcpel", "expeditionary", r"/mcdp-3/?$"),
 "mcdp4": ("mcpel", "logistics", r"/mcdp-4/?$"),
 "mcdp7": ("mcpel", "learning", r"/mcdp-7/?$"),
 "mcwp611": ("mcpel", "leading marines", r"mcwp-6-11/?$"),
 "mcrp611d": ("mcpel", "sustaining", r"mcrp-6-11d"),
}


def _safe(s):
    return re.sub(r'[<>:"/\\|?*]', "", s).strip()[:110]


def _pdf_links(page_url):
    html = sm._get(page_url)
    out = []
    for u in sm._pdfs(page_url, html):
        if "usmcu.edu" in u or "marines.mil" in u:
            out.append(u)
    return out


def _mcpel_pdf(word, rx):
    html = sm._get(MCPEL + "Search/" + urllib.parse.quote(word) + "/")
    for m in re.finditer(r"""href\s*=\s*["']([^"']*Electronic-Library-Display[^"']*)["']""", html, re.I):
        pg = urllib.parse.urljoin(MCPEL, m.group(1).replace("&amp;", "&"))
        if re.search(rx, pg, re.I):
            pdfs = _pdf_links(pg)
            if pdfs:
                return pdfs[0]
    return ""


def _fetch(key, base, folder):
    """Return the list of saved file names."""
    spec = FREE[key]
    got = []
    def grab(url, name, epub=False):
        out = os.path.join(folder, name)
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            return True
        if epub:
            tmp = out + ".part"
            if jd._curl_file(url, tmp) and os.path.getsize(tmp) > 1000:
                os.replace(tmp, out)
                return True
            try:
                import army_pubs as ap
                return bool(ap._fetch_file(url, out))
            except Exception:  # noqa: BLE001
                return False
        return jd._grab(url, out, quick=True)
    kind = spec[0]
    if kind == "pdf":
        if grab(spec[1], base + ".pdf"):
            got.append(base + ".pdf")
    elif kind == "gut":
        if grab(f"https://www.gutenberg.org/ebooks/{spec[1]}.epub3.images", base + ".epub", epub=True):
            got.append(base + ".epub")
    elif kind == "page":
        urls = []
        for u in _pdf_links(spec[1]):
            if re.search(r"web|full|vol|always|shores", u, re.I) and u not in urls:
                urls.append(u)
        urls += [u for u in spec[2:] if u not in urls]
        for i, u in enumerate(urls[:3]):
            n = base + (f" ({i + 1})" if i else "") + ".pdf"
            if grab(u, n):
                got.append(n)
    elif kind == "mcpel":
        u = _mcpel_pdf(spec[1], spec[2])
        if u and grab(u, base + ".pdf"):
            got.append(base + ".pdf")
    return got


def write_index(dest):
    folder = os.path.join(dest, "www", "library", FOLDER)
    files = sorted(os.listdir(folder)) if os.path.isdir(folder) else []
    rows = []
    for cat, title, author, key in LIST:
        base = _safe(f"{title} - {author}")
        mine = [f for f in files if f.startswith(base[:60])]
        rows.append({"cat": cat, "title": title, "author": author, "free": bool(key), "files": mine,
                     "find": "https://search.worldcat.org/search?q=" + urllib.parse.quote(title.split(":")[0] + " " + author.split(" and ")[0])})
    os.makedirs(os.path.join(dest, "www", "data"), exist_ok=True)
    with open(os.path.join(dest, "www", "data", "reading-list.js"), "w", encoding="utf-8") as fh:
        fh.write("window.READING=" + json.dumps({"folder": "library/" + FOLDER, "items": rows}, separators=(",", ":")) + ";\n")


def run(dest):
    folder = os.path.join(dest, "www", "library", FOLDER)
    os.makedirs(folder, exist_ok=True)
    miss = []
    for cat, title, author, key in LIST:
        if not key:
            continue
        base = _safe(f"{title} - {author}")
        have = [f for f in os.listdir(folder) if f.startswith(base[:60])]
        got = have or _fetch(key, base, folder)
        print(f"  {'ok  ' if got else 'MISS'} {title[:70]}")
        if not got:
            miss.append((title, key))
    write_index(dest)
    import reports
    reports.drop_legacy(dest, "www/library/" + FOLDER + "/NOT-FETCHED.txt")
    with open(reports.not_fetched(dest, "Reading-List"), "w", encoding="utf-8") as fh:
        fh.write("Free titles that could not be fetched automatically (try again online, or download by hand and drop the file in www\\library\\Commandants Reading List\\):\n\n" if miss
                 else "Every free title was fetched.\n")
        for t, k in miss:
            fh.write(f"{t}\n    {FREE[k][1] if FREE[k][0] in ('pdf', 'page') else MCPEL if FREE[k][0] == 'mcpel' else 'https://www.gutenberg.org/ebooks/' + str(FREE[k][1])}\n")
    print(f"\n{sum(1 for x in LIST if x[3]) - len(miss)} of {sum(1 for x in LIST if x[3])} free titles on the drive.")


def build(u, dest):
    write_index(dest)


if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--dest", required=True)
    run(a.parse_args().dest)
