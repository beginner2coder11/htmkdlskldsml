"""Official state highway maps (one free PDF per state + DC) for the drive.

For each state it looks at that state DOT's map page (a short built-in list, edit LINKS below or
tools\\state-map-links.json on the drive), and when a state has no known page it searches the web for one.
It picks the newest PDF that looks like the official state map and saves it to
www\\library\\State Highway Maps\\.  Whatever can't be fetched is listed in REPORTS\\NOT-FETCHED-State-Maps.txt with a link to
try by hand.  Safe to re-run: states you already have are skipped (use --refresh to replace them).

    python state_maps.py --dest E:\\OFFGRID            all states
    python state_maps.py --dest E:\\OFFGRID --state GA,FL,TN
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import army_pubs as ap  # noqa: E402
import joint_doctrine as jd  # noqa: E402
import reports  # noqa: E402

FOLDER = "State Highway Maps"
STATES = [("AL", "Alabama"), ("AK", "Alaska"), ("AZ", "Arizona"), ("AR", "Arkansas"), ("CA", "California"), ("CO", "Colorado"),
          ("CT", "Connecticut"), ("DE", "Delaware"), ("DC", "District of Columbia"), ("FL", "Florida"), ("GA", "Georgia"),
          ("HI", "Hawaii"), ("ID", "Idaho"), ("IL", "Illinois"), ("IN", "Indiana"), ("IA", "Iowa"), ("KS", "Kansas"),
          ("KY", "Kentucky"), ("LA", "Louisiana"), ("ME", "Maine"), ("MD", "Maryland"), ("MA", "Massachusetts"),
          ("MI", "Michigan"), ("MN", "Minnesota"), ("MS", "Mississippi"), ("MO", "Missouri"), ("MT", "Montana"),
          ("NE", "Nebraska"), ("NV", "Nevada"), ("NH", "New Hampshire"), ("NJ", "New Jersey"), ("NM", "New Mexico"),
          ("NY", "New York"), ("NC", "North Carolina"), ("ND", "North Dakota"), ("OH", "Ohio"), ("OK", "Oklahoma"),
          ("OR", "Oregon"), ("PA", "Pennsylvania"), ("RI", "Rhode Island"), ("SC", "South Carolina"), ("SD", "South Dakota"),
          ("TN", "Tennessee"), ("TX", "Texas"), ("UT", "Utah"), ("VT", "Vermont"), ("VA", "Virginia"), ("WA", "Washington"),
          ("WV", "West Virginia"), ("WI", "Wisconsin"), ("WY", "Wyoming")]
# State DOT pages seen to list the official map. States not listed here are found by web search.
LINKS = {
    "WI": ["https://wisconsindot.gov/Pages/travel/road/hwy-maps/default.aspx"],
    "OH": ["https://www.dot.state.oh.us/maps/Pages/OfficialTransportationMaps.aspx"],
    "MO": ["https://www.modot.org/official-state-highway-map"],
    "TN": ["https://www.tn.gov/tdot/driver-how-do-i/look-at-or-order-state-maps/maps/state-maps.html"],
    "WA": ["https://wsdot.wa.gov/travel/printable-maps"],
    "FL": ["https://fdot.gov/gis/floridatransportationmaparchive.shtm"],
    "WV": ["https://transportation.wv.gov/IT/GIS/MAPS/Pages/purchaseMaps.aspx"],
    "GA": ["https://www.dot.ga.gov/GDOT/Pages/Maps.aspx"],
    "NC": ["https://www.ncdot.gov/travel-maps/maps/Pages/state-transportation-map.aspx"],
    "SC": ["https://info2.scdot.org/GISMapping/Pages/OrderMaps.aspx"],
    "VA": ["http://www.virginiadot.org/travel/maps-state.asp"],
}
POS = (("map", 3), ("highway", 2), ("transportation", 2), ("official", 2), ("state", 1))
NEG = ("county", "counties", "city", "cities", "bike", "bicycle", "milepost", "order", "form", "braille", "rail", "aviation",
       "airport", "traffic", "workzone", "work-zone", "school", "district", "region", "historic", "tourism", "transit",
       "freight", "truck", "scenic", "byway", "evacuation", "ferry", "adopt", "application", "request", "brochure")


def _get(url, timeout=40):
    """Page text, or '' (tries urllib, then curl)."""
    try:
        req = urllib.request.Request(url, headers=ap.UA)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read(3_000_000).decode("utf-8", "replace")
    except Exception:  # noqa: BLE001
        pass
    exe = shutil.which("curl.exe") or shutil.which("curl")
    if exe:
        try:
            p = subprocess.run([exe, "-sSL", "--max-time", str(timeout), "-A", ap.UA["User-Agent"], url], capture_output=True, timeout=timeout + 10)
            return p.stdout[:3_000_000].decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            pass
    return _browser_dom(url, timeout)


def _browser_dom(url, timeout=40):
    """Last resort: let a real headless Edge/Chrome load the page (runs its JavaScript) and return the HTML."""
    exes = [shutil.which(n) for n in ("msedge", "chrome", "google-chrome", "chromium", "chromium-browser")]
    for base in (os.environ.get("ProgramFiles(x86)", ""), os.environ.get("ProgramFiles", "")):
        exes += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                 os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    for exe in exes:
        if exe and os.path.isfile(exe):
            try:
                p = subprocess.run([exe, "--headless=new", "--disable-gpu", "--virtual-time-budget=15000", "--dump-dom", url],
                                   capture_output=True, timeout=timeout + 20)
                if p.stdout:
                    return p.stdout[:3_000_000].decode("utf-8", "replace")
            except Exception:  # noqa: BLE001
                continue
    return ""


def search_url(name):
    return "https://duckduckgo.com/?q=" + urllib.parse.quote(f"{name} official state highway map pdf DOT")


def _search(name, ab):
    """Candidate DOT pages for a state, best first."""
    q = urllib.parse.quote(f"{name} department of transportation official state highway map pdf")
    urls = []
    # several search engines, in turn, until one gives results
    for eng, pat in (("https://html.duckduckgo.com/html/?q=", r'uddg=([^"&]+)'), ("https://www.bing.com/search?q=", r'<a href="(https?://[^"]+)"[^>]*h="ID'),
                     ("https://search.brave.com/search?q=", r'href="(https?://[^"]+)"')):
        html = _get(eng + q)
        urls = [urllib.parse.unquote(m.group(1)) for m in re.finditer(pat, html)]
        urls = [u for u in urls if not re.search(r"(bing|brave|duckduckgo|microsoft)\.", urllib.parse.urlparse(u).netloc.lower())]
        if urls:
            break
    out = []
    for u in urls:
        h = urllib.parse.urlparse(u).netloc.lower()
        good = h.endswith((".gov", ".us")) or "dot" in h or f".{ab.lower()}." in h
        if good and u not in out and not re.search(r"(facebook|youtube|twitter|wikipedia)", h):
            out.append(u)
    return out[:4]


def _score(url):
    path = urllib.parse.unquote(urllib.parse.urlparse(url).path).lower()
    s = sum(w for k, w in POS if k in path) - sum(4 for k in NEG if k in path)
    yrs = [int(y) for y in re.findall(r"(?<!\d)(20[12]\d)(?!\d)", path)]
    if yrs:
        s += (max(yrs) - 2018) * 0.5
    if re.search(r"(?<!\d)(19\d\d|200\d|201[0-6])(?!\d)", path) and not yrs:
        s -= 5
    return s if "map" in path or "highway" in path or "transportation" in path else -1


def _pdfs(page_url, html):
    found = []
    for m in re.finditer(r"""href\s*=\s*["']([^"']+?\.pdf[^"']*)["']""", html, re.I):
        u = urllib.parse.urljoin(page_url, m.group(1).replace("&amp;", "&"))
        if u not in found:
            found.append(u)
    return found


def candidates(ab, name, extra):
    pages = list(extra.get(ab) or LINKS.get(ab) or [])
    if not pages:
        pages = _search(name, ab)
    best = []
    for pg in pages:
        if pg.lower().split("?")[0].endswith(".pdf"):
            best.append((_score(pg) + 1, pg, pg))
            continue
        for u in _pdfs(pg, _get(pg)):
            sc = _score(u)
            if sc > 0:
                best.append((sc, u, pg))
        if len([b for b in best if b[0] >= 5]) >= 1:
            break
    best.sort(key=lambda b: -b[0])
    seen, out = set(), []
    for sc, u, pg in best:
        if u not in seen:
            seen.add(u)
            out.append((u, pg))
    return out[:3]


def run(dest, only=None, refresh=False):
    folder = os.path.join(dest, "www", "library", FOLDER)
    os.makedirs(folder, exist_ok=True)
    extra = {}
    try:
        extra = json.load(open(os.path.join(dest, "tools", "state-map-links.json"), encoding="utf-8"))
    except (OSError, ValueError):
        pass
    have, missing, src = {}, [], []
    for ab, name in STATES:
        if only and ab not in only:
            continue
        pre = sorted(f for f in os.listdir(folder) if f.startswith(ab + " ") and f.lower().endswith(".pdf"))
        if pre and not refresh:
            have[ab] = pre
            print(f"  {ab} {name}: already have it")
            continue
        got = []
        cands = candidates(ab, name, extra)
        for u, pg in cands:
            out = os.path.join(folder, f"{ab} {name} Official Highway Map{' (' + str(len(got) + 1) + ')' if got else ''}.pdf")
            if jd._grab(u, out, quick=True):
                got.append(os.path.basename(out))
                src.append(f"{ab}\t{u}\t(found on {pg})")
                print(f"  {ab} {name}: {os.path.basename(out)}")
                if len(got) >= 2:
                    break
        if got:
            have[ab] = got
        else:
            missing.append((ab, name, (extra.get(ab) or LINKS.get(ab) or [search_url(name)])[0]))
            print(f"  {ab} {name}: not found")
    # files already present for states we did not touch
    for f in os.listdir(folder):
        ab = f[:2]
        if f.lower().endswith(".pdf") and ab in dict(STATES) and f not in have.get(ab, []):
            have.setdefault(ab, []).append(f)
    write_index(dest, have)
    missing = [(ab, n, (extra.get(ab) or LINKS.get(ab) or [search_url(n)])[0]) for ab, n in STATES if ab not in have]
    if only is None or src:
        with open(os.path.join(folder, "SOURCES.txt"), "a", encoding="utf-8") as fh:
            fh.write("\n".join(src) + ("\n" if src else ""))
    reports.drop_legacy(dest, "www/library/" + FOLDER + "/NOT-FETCHED.txt")
    with open(reports.not_fetched(dest, "State-Maps"), "w", encoding="utf-8") as fh:
        if missing:
            fh.write("These states' official maps could not be fetched automatically.\nOpen the link, download the map PDF, and drop it in www\\library\\State Highway Maps\\ named like  XX State Official Highway Map.pdf\n\n")
            fh.write("\n".join(f"{ab}  {n}\n    {u}" for ab, n, u in missing) + "\n")
        else:
            fh.write("Every state was fetched.\n")
    print(f"\n{len(have)} of {len(STATES)} states on the drive; {len(missing)} not fetched (see REPORTS\\NOT-FETCHED-State-Maps.txt).")
    return len(have), len(missing)


def write_index(dest, have=None):
    """www/data/state-maps.js for statemaps.html (what is on the drive + where to look online)."""
    folder = os.path.join(dest, "www", "library", FOLDER)
    if have is None:
        have = {}
        for f in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
            if f.lower().endswith(".pdf") and f[:2] in dict(STATES):
                have.setdefault(f[:2], []).append(f)
    rows = [{"ab": ab, "name": n, "files": have.get(ab, []), "page": (LINKS.get(ab) or [""])[0], "search": search_url(n)} for ab, n in STATES]
    os.makedirs(os.path.join(dest, "www", "data"), exist_ok=True)
    with open(os.path.join(dest, "www", "data", "state-maps.js"), "w", encoding="utf-8") as fh:
        fh.write("window.STATEMAPS=" + json.dumps({"folder": "library/" + FOLDER, "states": rows}, separators=(",", ":")) + ";\n")


def build(u, dest):
    """Builder hook: refresh the index only (downloads are done by ADD-STATE-MAPS.bat)."""
    write_index(dest)


if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--dest", required=True)
    a.add_argument("--state", help="comma-separated postal codes, e.g. GA,FL")
    a.add_argument("--refresh", action="store_true")
    o = a.parse_args()
    run(o.dest, set(o.state.upper().split(",")) if o.state else None, o.refresh)
