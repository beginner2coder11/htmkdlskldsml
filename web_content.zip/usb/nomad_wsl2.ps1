# Installs Project N.O.M.A.D. on Windows through WSL2 (Ubuntu 24.04 + native Docker), following the community WSL2 guide
# https://www.projectnomad.us/install/wsl2 . Needs internet and about 100 GB free on C:. Safe to re-run: it skips what is done.
#   -Lan    also let other devices on your network open NOMAD (ports 8080, 8090, 8300)
param([switch]$Lan, [switch]$NoTune, [string]$Distro = "Ubuntu-24.04")
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Say($t) { Write-Host ""; Write-Host "== $t" -ForegroundColor Cyan }
function Wsl-List { ((& wsl.exe -l -q 2>$null) -join "`n") -replace "`0", "" }
function Wsl-Run($user, $script) {
    $p = (& wsl.exe -d $Distro -u root -- wslpath -a ($script -replace '\\', '/')).Trim()
    $pr = Start-Process wsl.exe -ArgumentList "-d $Distro -u $user -- bash `"$p`"" -NoNewWindow -Wait -PassThru
    return [int]$pr.ExitCode
}

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Write-Host "Asking for Administrator rights..."
    $a = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$($MyInvocation.MyCommand.Path)`"")
    if ($Lan) { $a += "-Lan" }
    if ($NoTune) { $a += "-NoTune" }
    Start-Process powershell -Verb RunAs -ArgumentList $a
    exit
}

Say "Checking this PC"
$ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$free = [math]::Round((Get-PSDrive C).Free / 1GB)
Write-Host "RAM: $ram GB   Free space on C: $free GB"
if ($ram -lt 16) { Write-Host "! NOMAD's guide suggests 16 GB or more. The installer itself has no RAM check, so this PC is fine: WSL2 is given nearly all of it below. Close other apps while it installs." -ForegroundColor Yellow }
if (-not $NoTune) { Say "Giving WSL2 nearly all RAM, all cores and a big swap file"; & (Join-Path $here "wsl_max.ps1") -FreeUp }
if ($free -lt 100) { Write-Host "! The guide asks for about 100 GB free. Less will work for a small install." -ForegroundColor Yellow }
if (Get-NetTCPConnection -LocalPort 11434 -State Listen -ErrorAction SilentlyContinue) {
    Write-Host "! Something already uses port 11434 (Ollama for Windows?). Quit it from the system tray, or NOMAD's AI Assistant cannot start." -ForegroundColor Yellow
}

Say "1/5  WSL2 and Ubuntu 24.04"
if ((Wsl-List) -notmatch [regex]::Escape($Distro)) {
    & wsl.exe --install -d $Distro --no-launch
    if ((Wsl-List) -notmatch [regex]::Escape($Distro)) {
        Write-Host ""
        Write-Host "Windows needs a restart to finish turning on WSL2." -ForegroundColor Yellow
        Write-Host "Restart the PC, then run this installer again (it continues from here)."
        exit 0
    }
}
& wsl.exe --set-version $Distro 2 2>$null | Out-Null
Write-Host "Ubuntu is installed."

Say "2/5  Turning on systemd and the settings NOMAD needs"
$rc = Wsl-Run "root" (Join-Path $here "nomad-wsl2\step1-system.sh")
if ($rc -eq 10) {
    Write-Host "Settings changed - restarting WSL (this is required)."
    & wsl.exe --shutdown
    Start-Sleep -Seconds 8
} elseif ($rc -ne 0) { Write-Host "Step failed (code $rc)." -ForegroundColor Red; exit 1 }

Say "3/5  Installing Docker inside Ubuntu"
if ((Wsl-Run "root" (Join-Path $here "nomad-wsl2\step2-docker.sh")) -ne 0) { Write-Host "Docker step failed. See the messages above." -ForegroundColor Red; exit 1 }
& wsl.exe --terminate $Distro; Start-Sleep -Seconds 5      # so the docker group applies to user nomad

Say "4/5  Installing NOMAD (accept the license when asked; about 5 minutes)"
if ((Wsl-Run "nomad" (Join-Path $here "nomad-wsl2\step3-nomad.sh")) -ne 0) { Write-Host "NOMAD installer reported a problem. See the messages above." -ForegroundColor Red; exit 1 }

Say "5/5  Finishing"
if ($Lan) {
    foreach ($p in 8080, 8090, 8300) {
        & netsh.exe interface portproxy add v4tov4 listenport=$p listenaddress=0.0.0.0 connectport=$p connectaddress=127.0.0.1 | Out-Null
        if (-not (Get-NetFirewallRule -DisplayName "NOMAD $p" -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName "NOMAD $p" -Direction Inbound -Protocol TCP -LocalPort $p -Action Allow | Out-Null
        }
    }
    Write-Host "Other devices on your network can now open  http://<this PC's IP>:8080  (NOMAD has no password - use only on a network you trust)."
}
Write-Host ""
Write-Host "Done. Open  http://localhost:8080  in your browser." -ForegroundColor Green
Write-Host "After a Windows restart, run START-NOMAD-WINDOWS.bat to bring it back up."
Start-Process "http://localhost:8080"
