"""Find any map on the drive by coordinates.

Indexes every georeferenced PDF under www/topo (USGS quads, Canadian sheets, base/city maps) and www/mymaps
(your MIMs and special maps): the extent comes from the catalog when known, otherwise it is read from the
GeoPDF itself. Writes www/data/geo-index.js and www/find-map.html, where you type a latitude/longitude,
UTM or MGRS grid and get every map that covers that point (largest scale first), or the nearest ones.
"""
import json, os, re


def _title(rel):
    s = os.path.splitext(os.path.basename(rel))[0]
    return re.sub(r"[_]+", " ", s).strip()


def _nts_bbox(rel):
    """Extent of a Canadian 1:50k sheet from its NTS code, for the metros we know (used when the PDF has no readable bounds)."""
    try:
        import canada_topo as ct
    except ImportError:
        return None
    code = os.path.splitext(os.path.basename(rel))[0].upper()
    for m in ct.CA_METROS.values():
        if code[:4] == m["series"] + m["letter"] and code[4:6].isdigit():
            for row in range(4):
                for col in range(4):
                    if ct._block(row, col) == int(code[4:6]):
                        s = m["area_lat_s"] + row * 0.25
                        e = m["area_lon_e"] - col * 0.5
                        return [e - 0.5, s, e, s + 0.25]
    return None


def _kmz(path, rows):
    import zipfile
    from xml.sax.saxutils import escape as esc
    folders = {"topo": "Topo maps (USGS / Canada / base)", "mymaps": "My maps"}
    body = ""
    for key, title in folders.items():
        pm = ""
        for rel, name, w, s_, e, n, sub in rows:
            if sub != key:
                continue
            pm += (f"<Placemark><name>{esc(name)}</name><description>{esc('On the drive: www/' + rel)}</description>"
                   f"<Style><LineStyle><color>ff2f4ab0</color><width>2</width></LineStyle><PolyStyle><fill>0</fill></PolyStyle></Style>"
                   f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{w},{s_},0 {e},{s_},0 {e},{n},0 {w},{n},0 {w},{s_},0"
                   f"</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>")
        if pm:
            body += f"<Folder><name>{title}</name>{pm}</Folder>"
    doc = ('<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
           f"<name>OFF-GRID map coverage</name>{body}</Document></kml>")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("doc.kml", doc)


def build(u, dest):
    www = os.path.join(dest, "www")
    cat = u.extras._catalog(dest)
    known = {}
    groups = [cat.get("home") or {}] + list((cat.get("areas") or {}).values())
    for g in groups:
        for q in g.get("quads", []):
            if q.get("bb") and any(q["bb"]):
                known["topo/" + q["rel"]] = (q.get("t") or _title(q["rel"]), q["bb"])
    cp = os.path.join(www, "data", "_geo-cache.json")
    try:
        cache = json.load(open(cp, encoding="utf-8"))
    except (OSError, ValueError):
        cache = {}
    pypdf, rows, unread = None, [], 0
    for sub in ("topo", "mymaps"):
        base = os.path.join(www, sub)
        for root, _, files in os.walk(base):
            for f in files:
                if not f.lower().endswith(".pdf") or f.startswith("_"):
                    continue
                p = os.path.join(root, f)
                rel = sub + "/" + os.path.relpath(p, base).replace(os.sep, "/")
                if rel in known:
                    title, bb = known[rel]
                else:
                    sig = [os.path.getsize(p), int(os.path.getmtime(p))]
                    c = cache.get(rel)
                    if c and c.get("sig") == sig:
                        bb = c.get("bb")
                    else:
                        if pypdf is None:
                            try:
                                pypdf = u.search_index.get_pypdf(u, dest) or False
                            except Exception:  # noqa: BLE001
                                pypdf = False
                        bb = u.mymaps.geopdf_bbox(pypdf, p) if pypdf else None
                        if not bb and sub == "topo":
                            bb = _nts_bbox(rel)
                        if pypdf:
                            cache[rel] = {"sig": sig, "bb": bb}
                    title = _title(rel)
                if bb and len(bb) == 4 and bb[2] > bb[0] and bb[3] > bb[1]:
                    rows.append([rel, title, round(bb[0], 5), round(bb[1], 5), round(bb[2], 5), round(bb[3], 5), sub])
                else:
                    unread += 1
    os.makedirs(os.path.join(www, "data"), exist_ok=True)
    with open(cp, "w", encoding="utf-8") as fh:
        json.dump(cache, fh)
    rows.sort(key=lambda r: r[0].lower())
    with open(os.path.join(www, "data", "geo-index.js"), "w", encoding="utf-8") as fh:
        fh.write("window.GEOINDEX=" + json.dumps(rows, separators=(",", ":")) + ";\n")
    exp = os.path.join(www, "data", "export")
    os.makedirs(exp, exist_ok=True)
    _kmz(os.path.join(exp, "map-coverage.kmz"), rows)
    with open(os.path.join(www, "find-map.html"), "w", encoding="utf-8") as fh:
        fh.write(PAGE)
    print(f"  map-by-coordinates index: {len(rows)} maps" + (f" ({unread} PDFs without readable georeferencing)" if unread else ""))


PAGE = """<!doctype html><meta charset=utf-8><title>Find a map by coordinates</title>
<meta name=viewport content="width=device-width,initial-scale=1">
<style>body{font:16px system-ui;max-width:56rem;margin:1.5rem auto;padding:0 1rem}input,button{font-size:1rem;padding:.4rem}
table{border-collapse:collapse;width:100%;margin-top:1rem}td,th{border-bottom:1px solid #ccc;padding:.35rem;text-align:left;vertical-align:top}
small,.dim{color:#666}.box{background:#f4f2ec;padding:.6rem .8rem;border-left:4px solid #b04a2f;margin:1rem 0}</style>
<h1>Find a map by coordinates</h1>
<p><input id=q size=46 placeholder="34.2367, -84.4908   or   16S GJ 123 456   or   34&deg;14'12&quot;N 84&deg;29'27&quot;W" autofocus>
<button onclick=go()>Find maps</button></p>
<p><small id=meta></small></p><div id=conv></div><div id=out></div>
<script src="coords.js"></script><script src="data/geo-index.js"></script>
<script>
var G=window.GEOINDEX||[];
document.getElementById('meta').textContent=G.length+' georeferenced maps indexed (USGS and Canadian topo quads, base and city maps, your own maps). Accepts decimal degrees, degrees-minutes-seconds, UTM or MGRS.';
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function area(r){return (r[4]-r[2])*(r[5]-r[3])}
function dist(r,la,lo){var cy=(r[3]+r[5])/2,cx=(r[2]+r[4])/2,dy=(cy-la)*69,dx=(cx-lo)*69*Math.cos(la*Math.PI/180);return Math.sqrt(dx*dx+dy*dy)}
function row(r,note){var href=encodeURI(r[0]);return '<tr><td><a href="'+href+'">'+esc(r[1])+'</a><br><small>'+esc(r[0])+'</small></td><td>'+note+'</td><td><small>'+(r[6]=='mymaps'?'My map':'Topo')+'</small></td></tr>'}
function go(){var s=document.getElementById('q').value.trim();if(!s)return;var p=window.COORDS&&COORDS.parseAny(s);
if(!p){document.getElementById('out').innerHTML='<p>Could not read that. Try <code>34.2367, -84.4908</code> or an MGRS grid like <code>16S GJ 12345 67890</code>.</p>';return}
var la=p[0],lo=p[1],a=COORDS.all(la,lo);location.hash=encodeURIComponent(s);
document.getElementById('conv').innerHTML='<div class=box>'+esc(a.dd)+' &nbsp;|&nbsp; '+esc(a.dms)+' &nbsp;|&nbsp; UTM '+esc(a.utm)+' &nbsp;|&nbsp; MGRS '+esc(a.mgrs)+'</div>';
var hit=G.filter(function(r){return lo>=r[2]&&lo<=r[4]&&la>=r[3]&&la<=r[5]}).sort(function(x,y){return area(x)-area(y)});
var h;if(hit.length){h='<p><b>'+hit.length+' map'+(hit.length>1?'s':'')+' cover this point</b> (most detailed first)</p><table><tr><th>Map</th><th>Coverage</th><th>Type</th></tr>'+hit.map(function(r,i){return row(r,i==0?'best detail':'covers')}).join('')+'</table>'}
else{var near=G.slice().sort(function(x,y){return dist(x,la,lo)-dist(y,la,lo)}).slice(0,8);
h='<p><b>No map covers this point.</b> Nearest maps:</p><table><tr><th>Map</th><th>Distance</th><th>Type</th></tr>'+near.map(function(r){return row(r,'about '+dist(r,la,lo).toFixed(0)+' mi')}).join('')+'</table>'}
document.getElementById('out').innerHTML=h}
document.getElementById('q').addEventListener('keydown',function(e){if(e.key=='Enter')go()});
if(location.hash.length>1){document.getElementById('q').value=decodeURIComponent(location.hash.slice(1));go()}
</script>
"""
