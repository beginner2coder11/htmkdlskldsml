"""DoD doctrine from the FAS Intelligence Resource Program library (https://irp.fas.org/doddir/).

Sections: Department of Defense, Army, Navy, Marine Corps, Air Force, Military Medicine (the NSA Rainbow Series page is
HTML only and is skipped). Saved to  www/library/DoD Doctrine (FAS) - <section>/.

NEVER DOWNLOADS THE SAME THING TWICE:
  * every URL it has fetched is remembered in tools/fas-doddir.json (also the ones that failed, retried after 30 days);
  * every publication is reduced to its number (ATP 3-50.21, FM 21-76, AFH 10-644, NWP 1-14M ...) and skipped when that
    number is already anywhere in the library - from armypubs.army.mil, the Marine Corps list, the manuals list or
    MY-FILES-INBOX - or was already taken from an earlier FAS section (FAS lists many documents twice);
  * older editions FAS keeps next to the current one share the same number, so only the first (current) listing is taken.
Run alone:   python fas_doddir.py --dest E:\\OFFGRID [--sections army,usmc] [--max-gb 20] [--dry-run]
"""
import html as _html, json, os, re, sys, time, urllib.parse

BASE = "https://irp.fas.org/doddir/"
SECTIONS = {"milmed": "Military Medicine", "usmc": "Marine Corps", "army": "Army", "dod": "Department of Defense",
            "navy": "Navy", "usaf": "Air Force"}
BY_PROFILE = {"medium": ["milmed"], "large": ["milmed", "usmc", "army", "dod"], "full": list(SECTIONS)}
PREFIX = (r"da\s*pam|adrp|adp|attp|atp|fm|fmfrp|fmfm|tc|tm|ar|pam|stp|gta|mcwp|mcrp|mctp|mcdp|mcip|mcbul|nwp|nttp|ntrp|navmed|"
          r"afh|afi|afman|afdp|afdd|afttp|afpd|jp|dodi|dodd|dodm|dod\s*[0-9]|cjcsi|cjcsm|ttp")
PUB = re.compile(r"(?<![a-z])(" + PREFIX + r")[\s_\-.]*(\d+[a-z]?(?:[\s_\-.]+\d+[a-z]?){0,4})", re.I)
LINK = re.compile(r'<a\s[^>]*href\s*=\s*["\']([^"\']+\.pdf)["\'][^>]*>(.*?)</a>', re.I | re.S)


def pub_key(text):
    """'ATP 3-50.21 Survival' / 'atp3-50-21.pdf' / 'us_army_atp_3_50_21_survival.pdf' -> 'atp 3-50-21' (None if no number)."""
    t = re.sub(r"\.pdf$", "", (text or "").lower())
    m = PUB.search(t.replace("_", " "))
    if not m:
        return None
    pre = re.sub(r"\s+", "", m.group(1))
    nums = re.split(r"[\s_\-.]+", m.group(2).strip())
    if len(nums) > 1 and re.fullmatch(r"(19|20)\d\d", nums[-1]):      # 'atp2-22-9-2017' = an edition year, not part of the number
        nums = nums[:-1]
    return pre + " " + "-".join(n.lstrip("0") or "0" for n in nums)


def _load(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def have_keys(dest, repo=None):
    """Publication numbers already on the drive (any library folder, any source) and in the manuals list."""
    keys = set()
    for _, _, fs in os.walk(os.path.join(dest, "www", "library")):
        for f in fs:
            if f.lower().endswith(".pdf"):
                k = pub_key(f)
                if k:
                    keys.add(k)
    for tsv in ([os.path.join(repo, "library", "manuals.tsv")] if repo else []):
        try:
            for ln in open(tsv, encoding="utf-8"):
                p = ln.split("\t")
                if len(p) >= 3:
                    for x in (p[1], p[2]):
                        k = pub_key(x)
                        if k:
                            keys.add(k)
        except OSError:
            pass
    return keys


def _safe(s, n=110):
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", s)
    return re.sub(r"\s+", " ", s).strip(" .")[:n] or "document"


def listing(u, sec):
    """[(url, title, key)] in page order, first listing of each publication number only."""
    page = u.fetch(f"{BASE}{sec}/index.html", 90).decode("utf-8", "replace")
    out, seen = [], set()
    for href, txt in LINK.findall(page):
        url = urllib.parse.urljoin(f"{BASE}{sec}/", _html.unescape(href))
        if "irp.fas.org/" not in url:
            continue
        title = re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", " ", txt))).strip()
        key = pub_key(title) or pub_key(os.path.basename(urllib.parse.urlsplit(url).path))
        tag = key or url
        if tag in seen:
            continue
        seen.add(tag)
        out.append((url, title, key))
    return out


def build(u, dest, profile="large", sections="", max_gb=None, dry=False, repo=None):
    secs = [s for s in (sections.split(",") if sections else BY_PROFILE.get(profile, [])) if s in SECTIONS]
    if not secs:
        return
    u.say("DoD doctrine from FAS (irp.fas.org/doddir) - skipping anything already on the drive")
    hist_p = os.path.join(dest, "tools", "fas-doddir.json")
    hist = _load(hist_p)                        # url -> {"ok": file} or {"fail": n, "last": t, "why": ...}
    have = have_keys(dest, repo)
    budget = (max_gb if max_gb is not None else {"medium": 3, "large": 15, "full": 40}.get(profile, 10)) * 1e9
    got_b, new, dup, rest, missed = 0, 0, 0, 0, []
    for sec in secs:
        try:
            items = listing(u, sec)
        except Exception as e:  # noqa: BLE001
            print(f"  ! {SECTIONS[sec]} list unavailable: {str(e)[:100]}")
            continue
        folder = os.path.join(dest, "www", "library", f"DoD Doctrine (FAS) - {SECTIONS[sec]}")
        sn = sd = sf = streak = 0
        for url, title, key in items:
            h = hist.get(url, {})
            if h.get("ok") or (key and key in have):
                dup += 1
                sd += 1
                continue
            if h.get("fail", 0) >= 2 and time.time() - h.get("last", 0) < 30 * 86400:
                rest += 1
                continue
            name = _safe(title if key and pub_key(title) else (title or os.path.basename(url))) + ".pdf"
            out = os.path.join(folder, name)
            if dry:
                print(f"  would get: {SECTIONS[sec]} / {name}")
                sn += 1
                continue
            if got_b > budget:
                print(f"  (size limit for this run reached - the rest is fetched next run)")
                break
            os.makedirs(folder, exist_ok=True)
            got = u.download(url, out, name[:60])
            ok = got and open(out, "rb").read(5) == b"%PDF-"
            if ok:
                streak = 0
                got_b += os.path.getsize(out)
                hist[url] = {"ok": os.path.relpath(out, dest)}
                if key:
                    have.add(key)
                sn += 1
                new += 1
            else:
                if os.path.exists(out):
                    os.remove(out)
                why = getattr(u, "LAST_ERR", [""])[0] or ("the site sent a web page, not the PDF" if got else "?")
                sf += 1
                streak += 1
                hist[url] = {"fail": h.get("fail", 0) + 1, "last": time.time(), "why": why}
                missed.append(f"[{SECTIONS[sec]}] {title}\n    {url}\n    -> {why}")
                if why == "403" or streak >= 15:
                    print(f"\n  ! {SECTIONS[sec]}: the site is refusing or sending web pages instead of PDFs (a robot check) - "
                          "stopping this section, not working around it. It is retried on a later run.")
                    break
            time.sleep(1)                       # be polite to a small non-profit site
        print(f"  {SECTIONS[sec]}: {sn} new, {sd} already on the drive" + (f", {sf} could not be fetched (see REPORTS)" if sf else ""), flush=True)
    if not dry:
        os.makedirs(os.path.dirname(hist_p), exist_ok=True)
        json.dump(hist, open(hist_p, "w", encoding="utf-8"), indent=0)
        try:
            import reports
            with open(reports.not_fetched(dest, "FAS-DoD"), "w", encoding="utf-8", newline="\r\n") as fh:
                fh.write(f"FAS DoD DOCTRINE NOT DOWNLOADED - {time.strftime('%Y-%m-%d %H:%M')}\n")
                fh.write("Save by hand into MY-FILES-INBOX if you need them.\n" + "=" * 60 + "\n" + "\n".join(missed) + "\n")
        except Exception:  # noqa: BLE001
            pass
    print(f"  FAS doctrine: {new} new ({got_b / 1e9:.1f} GB), {dup} skipped as already on the drive"
          + (f", {rest} resting after failures" if rest else ""))


if __name__ == "__main__":
    import argparse
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--sections", default=",".join(SECTIONS), help="comma list: " + ",".join(SECTIONS))
    ap.add_argument("--max-gb", type=float, default=40)
    ap.add_argument("--dry-run", action="store_true", help="list what would be downloaded, change nothing")
    a = ap.parse_args()
    import usb_builder
    build(usb_builder, a.dest, "full", a.sections, a.max_gb, a.dry_run, usb_builder.REPO)
