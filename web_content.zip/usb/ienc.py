# -*- coding: utf-8 -*-
"""US Army Corps of Engineers Inland Electronic Navigational Charts (IENC) as Google Earth files.

From https://ienccloud.us/ienc_kml.html — one .kmz per river section (channel, river miles, locks and dams,
bridges, docks and landings, hazards). Public U.S. government data.

By default only the sections the get-home routes cross or run beside (Toronto route: the Ohio River at Cincinnati,
the Tennessee River from Chattanooga to Knoxville and the lower Clinch near I-40/I-75). --ienc-all takes all ~109.
The page's MD5 checksums are checked. Saved in GOOGLE-EARTH-READY\\River charts (IENC)\\. Also pulls the locks, dams,
bridges, ramps and landings out of those charts into one small file you can open first.

    python ienc.py --dest E:\\OFFGRID [--all]
"""
import argparse, hashlib, html, os, re, sys, time, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = "https://ienccloud.us/ienc_kml.html"
URL = "https://ienccloud.us/ienc/products/files/u37/ienc_kml/{}.kmz"
ROUTE_CELLS = {   # cell: why it is on the drive by default
    "U37OH439": "Ohio River, Meldahl L&D to Markland — Cincinnati / I-75 crossing (Toronto route)",
    "U37TN450": "Tennessee River, Raccoon Mtn to Town Creek — Chattanooga (Toronto route, ~100 mi from home)",
    "U37TN518": "Tennessee River, Town Creek to River Knobs — beside I-75 north of Chattanooga",
    "U37TN564": "Tennessee River, River Knobs to Donaldson Light — Watts Bar / Loudon, beside I-75",
    "U37TN606": "Tennessee River, Donaldson Light to Knoxville (head of navigation) — I-40 / I-75",
    "U37CL007": "Clinch River, Kingston to Clinton — I-40 / I-75 crossings west of Knoxville",
}
KEEP = re.compile(r"\b(lock|dam|bridge|ramp|landing|ferry|marina|mooring|terminal|dock|harbor|fleeting)\b", re.I)
OUT = os.path.join("GOOGLE-EARTH-READY", "River charts (IENC)")


def cells(u):
    """[(cell, description, md5 or '')] from the page; falls back to the route list if the page can't be read."""
    try:
        txt = u.fetch(PAGE, 60).decode("utf-8", "replace")
    except Exception as ex:  # noqa: BLE001
        print(f"  ! IENC page: {ex}")
        return [(c, d, "") for c, d in ROUTE_CELLS.items()]
    out = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", txt, re.S | re.I):
        m = re.search(r"\b(U37[A-Z]{2}\d{3})\b", row)
        if not m:
            continue
        tds = [re.sub(r"<[^>]+>", " ", t) for t in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        tds = [html.unescape(re.sub(r"\s+", " ", t)).strip() for t in tds]
        md5 = re.search(r"\b([0-9a-fA-F]{32})\b", row)
        desc = " · ".join(t for t in tds if t and t != m.group(1) and not re.fullmatch(r"[0-9a-fA-F]{32}", t))[:160]
        out.append((m.group(1), desc, md5.group(1).lower() if md5 else ""))
    return out or [(c, d, "") for c, d in ROUTE_CELLS.items()]


def _points(kmz):
    """Locks, dams, bridges, landings ... (name, lat, lon) from one chart."""
    pts = []
    try:
        with zipfile.ZipFile(kmz) as z:
            for n in z.namelist():
                if not n.lower().endswith(".kml"):
                    continue
                k = z.read(n).decode("utf-8", "replace")
                for pm in re.findall(r"<Placemark\b.*?</Placemark>", k, re.S):
                    nm = re.search(r"<name>(.*?)</name>", pm, re.S)
                    pt = re.search(r"<Point>.*?<coordinates>\s*([-\d.]+),([-\d.]+)", pm, re.S)
                    if nm and pt:
                        name = html.unescape(re.sub(r"<!\[CDATA\[|\]\]>", "", nm.group(1))).strip()
                        if KEEP.search(name):
                            pts.append((name[:90], float(pt.group(2)), float(pt.group(1))))
    except (zipfile.BadZipFile, OSError, ValueError):
        pass
    return pts


def build(u, dest, every=False):
    u.say("River charts (USACE IENC) for Google Earth" + (" — all rivers" if every else " — sections along the routes"))
    out = os.path.join(dest, OUT)
    os.makedirs(out, exist_ok=True)
    rows = cells(u)
    if not every:
        rows = [r for r in rows if r[0] in ROUTE_CELLS]
    got, bad, pts = [], [], []
    for cell, desc, md5 in rows:
        p = os.path.join(out, f"{cell}.kmz")
        fresh = os.path.exists(p) and (time.time() - os.path.getmtime(p)) / 86400 < 90
        if not fresh:
            try:
                data = u.fetch(URL.format(cell), 300)
                open(p + ".part", "wb").write(data)
                try:
                    zipfile.ZipFile(p + ".part").testzip()
                except zipfile.BadZipFile:
                    os.remove(p + ".part")
                    print(f"  ! {cell}: download is damaged — not saved (re-run later)"); bad.append(cell); continue
                if md5 and hashlib.md5(data).hexdigest() != md5:
                    print(f"  ! {cell}: MD5 differs from the one on the page (kept; it opens fine)")
                os.replace(p + ".part", p)
            except Exception as ex:  # noqa: BLE001
                print(f"  ! {cell}: {ex}"); bad.append(cell); continue
        got.append((cell, ROUTE_CELLS.get(cell) or desc))
        pts += [(n, la, lo, cell) for n, la, lo in _points(p)]
    if pts:
        e = html.escape
        body = "".join(f"<Placemark><name>{e(n)}</name><description>{e(c)}</description><Point><coordinates>{lo},{la},0</coordinates></Point></Placemark>\n"
                       for n, la, lo, c in pts)
        with open(os.path.join(out, "00 Locks, dams, bridges and landings.kml"), "w", encoding="utf-8") as fh:
            fh.write('<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
                     f"<name>River locks, dams, bridges, landings (IENC)</name>\n{body}</Document></kml>\n")
    with open(os.path.join(out, "00 READ ME.txt"), "w", encoding="utf-8") as fh:
        fh.write("RIVER CHARTS - US Army Corps of Engineers Inland Electronic Navigational Charts (IENC), Google Earth versions.\r\n"
                 "Open any .kmz with Google Earth Pro. They show the navigation channel, river miles, locks and dams, bridges,\r\n"
                 "docks, landings, ramps and hazards. Useful when a bridge on the route is closed: other crossings, lock-and-dam\r\n"
                 "sites, river miles to give rescuers, and boat landings.\r\n\r\n"
                 + "".join(f"  {c}  {w}\r\n" for c, w in got)
                 + ("\r\nNot fetched this time: " + ", ".join(bad) + "\r\n" if bad else "")
                 + "\r\nSource: https://ienccloud.us/ienc_kml.html  (refreshed every 90 days by the drive update)\r\n")
    print(f"  {len(got)} river charts on the drive" + (f", {len(pts)} locks/dams/bridges/landings pulled out" if pts else "")
          + (f" ({len(bad)} not fetched)" if bad else ""))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    sys.path.insert(0, HERE)
    import usb_builder
    build(usb_builder, a.dest, a.all)
