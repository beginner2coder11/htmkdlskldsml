"""Drive doctor — a deep health report for the OFF-GRID drive.

Checks four things and writes REPORTS/DOCTOR-REPORT.txt:
  1. Integrity   — a SHA-256 manifest; on the next run it flags files that are missing, resized, or CORRUPTED.
  2. Duplicates  — identical files (same content) wasting space, within the library and inboxes.
  3. Missing/links — manuals listed but not downloaded, topo sheets in the catalog but not on disk, and
                     local links in the web pages that point at files that aren't there.
  4. Freshness   — how old the locator/POI data, search index and topo catalog are (hospitals, fuel, water
                   go stale), so you know when to run a monthly UPDATE-DRIVE.

Only the Python standard library. Large files (ZIM archives, AI models, imagery) are tracked by size+date
rather than content-hashed every run, so a normal run is quick; pass --full to content-hash everything.

Run:  tools\\python-win\\python.exe tools\\doctor.py --dest "<OFFGRID folder>" [--full]
"""
import argparse, hashlib, json, os, re, time
from html.parser import HTMLParser

CAP = 200 * 1024 ** 2                       # content-hash files up to this size by default
SKIP_DIRS = {"__pycache__", "python-win", ".git", "pmtiles", "sumatra", "veracrypt", "vlc", "bin", "TRAVEL", "_TIDY-BIN", "OPEN-WITH"}
FRESH_DAYS = 185                            # locator/POI data older than ~6 months gets flagged
HASH_AREAS = ("www/library", "MY-FILES-INBOX", "MY-MAPS-INBOX", "MY-RADIO-INBOX", "TEXT-ONLY")


def human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def sha256(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for b in iter(lambda: f.read(1 << 20), b""):
                h.update(b)
    except OSError:
        return None
    return h.hexdigest()


def iter_files(root):
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in SKIP_DIRS]
        for fn in fns:
            if fn.endswith(".part"):
                continue
            yield os.path.join(dp, fn)


def rel(root, p):
    return os.path.relpath(p, root).replace(os.sep, "/")


def build_manifest(root, full, log):
    """{rel: {s:size, m:mtime, h:sha or None}} — hashes small files (and everything if full)."""
    man, n, hashed, hv = {}, 0, 0, 0
    for p in iter_files(root):
        try:
            st = os.stat(p)
        except OSError:
            continue
        r = rel(root, p)
        e = {"s": st.st_size, "m": int(st.st_mtime)}
        if full or st.st_size <= CAP:
            e["h"] = sha256(p)
            hashed += 1
            hv += st.st_size
            if hashed % 200 == 0:
                print(f"\r  hashing: {hashed:,} files ({human(hv)})", end="", flush=True)
        man[r] = e
        n += 1
    if hashed:
        print()
    log.append(f"  inventory: {n:,} files, {human(sum(e['s'] for e in man.values()))}; content-hashed {hashed:,}")
    return man


def verify(old, new):
    """Compare a previous manifest to the current one."""
    missing = sorted(set(old) - set(new))
    added = sorted(set(new) - set(old))
    corrupted, resized, touched = [], [], []
    for r in set(old) & set(new):
        o, c = old[r], new[r]
        if o["s"] != c["s"]:
            resized.append(r)
        elif o.get("h") and c.get("h") and o["h"] != c["h"]:
            corrupted.append(r)                 # same size, different content = corruption or edit
        elif not o.get("h") and o["m"] != c["m"]:
            touched.append(r)                   # big file, not content-checked, date changed
    return missing, added, corrupted, resized, touched


def find_duplicates(root, man):
    """Identical files (same sha) under the library/inboxes — real redundancy worth cleaning."""
    by_hash = {}
    for r, e in man.items():
        if e.get("h") and e["s"] > 4096 and any(r.startswith(a) for a in HASH_AREAS):
            by_hash.setdefault(e["h"], []).append((r, e["s"]))
    dupes = [v for v in by_hash.values() if len(v) > 1]
    wasted = sum(sz * (len(v) - 1) for v in dupes for _, sz in [v[0]])
    return sorted(dupes, key=lambda v: -v[0][1]), wasted


class _Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        for k, v in attrs:
            if k in ("href", "src") and v:
                self.links.append(v)


def find_broken(root, log):
    """Local links in web pages that point at missing files; manuals not downloaded; topo sheets missing."""
    broken, checked = [], 0
    www = os.path.join(root, "www")
    for dp, dns, fns in os.walk(www):
        dns[:] = [d for d in dns if d not in SKIP_DIRS]
        for fn in fns:
            if not fn.endswith((".html", ".htm")):
                continue
            fp = os.path.join(dp, fn)
            try:
                P = _Links()
                P.feed(open(fp, encoding="utf-8", errors="ignore").read())
            except Exception:  # noqa: BLE001
                continue
            for href in P.links:
                if re.match(r"^(https?:|mailto:|data:|javascript:|#|//)", href) or not href:
                    continue
                tgt = href.split("#")[0].split("?")[0]
                if not tgt:
                    continue
                from urllib.parse import unquote
                dest_p = os.path.normpath(os.path.join(dp, unquote(tgt)))
                checked += 1
                if not os.path.exists(dest_p):
                    broken.append(f"{rel(root, fp)}  ->  {href}")
    log.append(f"  checked {checked:,} local links in web pages")
    # manuals listed but not downloaded
    missing_manuals = []
    tsv = os.path.join(root, "tools", "manuals.tsv")
    if os.path.exists(tsv):
        for line in open(tsv, encoding="utf-8"):
            p = line.rstrip("\n").split("\t")
            if len(p) >= 4 and not p[0].startswith("#"):
                if not os.path.exists(os.path.join(www, "library", p[0], p[2])):
                    missing_manuals.append(f"{p[0]} / {p[1]}")
    # topo sheets in the catalog but not on disk
    missing_topo = 0
    cat = os.path.join(www, "topo", "catalog.json")
    if os.path.exists(cat):
        try:
            c = json.load(open(cat, encoding="utf-8"))
            quads = list((c.get("home") or {}).get("quads", []))
            for a in (c.get("areas") or {}).values():
                quads += a.get("quads", [])
            missing_topo = sum(1 for q in quads if q.get("rel") and not os.path.exists(os.path.join(www, "topo", q["rel"])))
        except (OSError, ValueError):
            pass
    return broken, missing_manuals, missing_topo


def freshness(root):
    out = []
    now = time.time()
    checks = [("Locator / POI data (hospitals, fuel, water, stores)", "www/data/pois.js", True),
              ("Search index", "www/search/docs.js", False),
              ("Topo catalog", "www/topo/catalog.json", False),
              ("Military installations", "www/data/military.js", False)]
    for label, r, flag in checks:
        p = os.path.join(root, *r.split("/"))
        if os.path.exists(p):
            days = (now - os.path.getmtime(p)) / 86400
            stale = flag and days > FRESH_DAYS
            out.append((label, days, stale))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=r"E:\OFFGRID")
    ap.add_argument("--full", action="store_true", help="content-hash every file, including the big archives (slow)")
    a = ap.parse_args()
    root = a.dest
    rep_dir = os.path.join(root, "REPORTS")
    os.makedirs(rep_dir, exist_ok=True)
    print("=" * 70)
    print(" OFF-GRID DRIVE DOCTOR")
    print("=" * 70)
    log = []

    man = build_manifest(root, a.full, log)
    man_path = os.path.join(rep_dir, "manifest.sha256.json")
    prev = None
    if os.path.exists(man_path):
        try:
            prev = json.load(open(man_path, encoding="utf-8"))
        except (OSError, ValueError):
            prev = None

    R = ["OFF-GRID DRIVE DOCTOR — " + time.strftime("%Y-%m-%d %H:%M"), "=" * 60, ""]
    R += log + [""]

    R.append("INTEGRITY (since the last doctor run)")
    if prev is None:
        R.append("  First run — saved a baseline manifest. Re-run after any update to detect")
        R.append("  missing, resized or CORRUPTED files.")
    else:
        missing, added, corrupted, resized, touched = verify(prev, man)
        R.append(f"  corrupted (same size, changed content): {len(corrupted)}")
        for r in corrupted[:40]:
            R.append(f"    !! {r}")
        R.append(f"  missing since last run: {len(missing)}")
        for r in missing[:40]:
            R.append(f"    -  {r}")
        R.append(f"  resized (changed): {len(resized)}   new files: {len(added)}   dates changed: {len(touched)}")
        if not (corrupted or missing):
            R.append("  No corruption or lost files. ✓")
    R.append("")

    dupes, wasted = find_duplicates(root, man)
    R.append(f"DUPLICATES (identical files in the library/inboxes): {len(dupes)} sets, {human(wasted)} wasted")
    for grp in dupes[:30]:
        R.append(f"  {human(grp[0][1])} x{len(grp)}:")
        for r, _ in grp:
            R.append(f"      {r}")
    R.append("")

    broken, missing_manuals, missing_topo = find_broken(root, log)
    R.append("MISSING FILES & BROKEN LINKS")
    R.append(f"  manuals listed but not downloaded: {len(missing_manuals)}")
    for m in missing_manuals[:40]:
        R.append(f"    -  {m}")
    if len(missing_manuals) > 40:
        R.append(f"    …and {len(missing_manuals) - 40} more (see REPORTS\\MISSING-MANUALS.html from CHECK-DRIVE)")
    R.append(f"  topo sheets in the catalog but not on disk: {missing_topo}")
    R.append(f"  broken local links in web pages: {len(broken)}")
    for b in broken[:40]:
        R.append(f"    x  {b}")
    R.append("")

    R.append("FRESHNESS")
    for label, days, stale in freshness(root):
        R.append(f"  {'! ' if stale else '  '}{label}: {days:.0f} days old" + ("  <-- consider a monthly UPDATE-DRIVE" if stale else ""))
    R.append("")

    # save the new manifest for next time
    try:
        json.dump(man, open(man_path, "w", encoding="utf-8"), separators=(",", ":"))
        R.append(f"Baseline saved to REPORTS\\manifest.sha256.json ({len(man):,} files).")
    except OSError as e:
        R.append(f"(could not save manifest: {e})")

    report = "\n".join(R) + "\n"
    with open(os.path.join(rep_dir, "DOCTOR-REPORT.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write(report)
    print()
    print(report)
    print("=" * 70)
    print(f" Full report: {os.path.join(rep_dir, 'DOCTOR-REPORT.txt')}")
    print("=" * 70)


if __name__ == "__main__":
    main()
