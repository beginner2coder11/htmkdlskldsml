# -*- coding: utf-8 -*-
"""The AI's own memory on the drive: ai/memory/knowledge.db (SQLite), read before anything else when you ask.

  notes     answers you marked right (👍), your corrections (👎 + "the right answer is ..."), and notes you add.
            Searched first on every question and handed to the AI as "your verified notes" — they win over the library.
  asked     every question asked on the Ask page, with the sources used and the answer (for 👍/👎 and the history page).
  demoted   sources you marked wrong for a kind of question: pushed down next time a similar question comes up.
  context   1–2 sentence "where this page sits" notes written overnight by the local AI (context_notes.py); they make
            search find the right page (Contextual Retrieval) and help the AI read a page cut out of a long manual.

All local, all on the drive, included in the index backup (BACKUP\\INDEXES). Nothing leaves the computer.
"""
import json, os, re, sqlite3, threading, time

WORD = re.compile(r"[a-z0-9]+")
STOP = set("a an and are as at be by for from how i in is it of on or the to what when where which who why with do does my me can "
           "you your this that should would could".split())
_LOCK = threading.Lock()


def path(dest):
    return os.path.join(dest, "ai", "memory", "knowledge.db")


def _fts_ok(db):
    try:
        db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS _t USING fts5(x)")
        db.execute("DROP TABLE _t")
        return True
    except sqlite3.Error:
        return False


def connect(dest, readonly=False):
    p = path(dest)
    if readonly:
        if not os.path.exists(p):
            return None
        return sqlite3.connect(f"file:{p}?mode=ro", uri=True, check_same_thread=False, timeout=10)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    db = sqlite3.connect(p, check_same_thread=False, timeout=30)
    db.execute("PRAGMA journal_mode=DELETE")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, kind TEXT, q TEXT, text TEXT, sources TEXT,
                                          made TEXT, asked_id INTEGER, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS asked (id INTEGER PRIMARY KEY, ts TEXT, q TEXT, mode TEXT, sources TEXT, answer TEXT,
                                          vote INTEGER DEFAULT 0, correction TEXT);
        CREATE TABLE IF NOT EXISTS demoted (q TEXT, src TEXT, made TEXT);
        CREATE TABLE IF NOT EXISTS context (doc TEXT, page INTEGER, ctx TEXT, model TEXT, made TEXT, PRIMARY KEY (doc, page));
        CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
    """)
    if _fts_ok(db):
        db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(q, text, content='notes', content_rowid='id', "
                   "tokenize='porter unicode61 remove_diacritics 2')")
        db.executescript("""
            CREATE TRIGGER IF NOT EXISTS notes_ai AFTER INSERT ON notes BEGIN
              INSERT INTO notes_fts(rowid, q, text) VALUES (new.id, new.q, new.text); END;
            CREATE TRIGGER IF NOT EXISTS notes_ad AFTER DELETE ON notes BEGIN
              INSERT INTO notes_fts(notes_fts, rowid, q, text) VALUES ('delete', old.id, old.q, old.text); END;
            CREATE TRIGGER IF NOT EXISTS notes_au AFTER UPDATE ON notes BEGIN
              INSERT INTO notes_fts(notes_fts, rowid, q, text) VALUES ('delete', old.id, old.q, old.text);
              INSERT INTO notes_fts(rowid, q, text) VALUES (new.id, new.q, new.text); END;
        """)
    db.commit()
    return db


def _words(q):
    return [w for w in dict.fromkeys(WORD.findall((q or "").lower())) if w not in STOP and len(w) > 1]


def _now():
    return time.strftime("%Y-%m-%d %H:%M")


# --------------------------------------------------------------------------- questions and votes (Ask page)
def log_question(dest, q, mode, sources, answer):
    with _LOCK:
        db = connect(dest)
        cur = db.execute("INSERT INTO asked (ts, q, mode, sources, answer) VALUES (?,?,?,?,?)",
                         (_now(), q[:1000], mode, json.dumps(sources or [])[:20000], (answer or "")[:8000]))
        db.commit()
        i = cur.lastrowid
        db.close()
    return i


def vote(dest, asked_id, v, correction=""):
    """v = 1 (right) or -1 (wrong). Right -> verified note. Wrong + correction -> correction note.
    Wrong -> its sources are demoted for questions like this one."""
    with _LOCK:
        db = connect(dest)
        row = db.execute("SELECT q, sources, answer FROM asked WHERE id=?", (asked_id,)).fetchone()
        if not row:
            db.close()
            return False
        q, sources, answer = row
        db.execute("UPDATE asked SET vote=?, correction=? WHERE id=?", (v, (correction or "")[:4000], asked_id))
        db.execute("UPDATE notes SET active=0 WHERE asked_id=?", (asked_id,))          # a re-vote replaces the earlier note
        if v != 0 and (v > 0 or (correction or "").strip()):                          # newest answer for the same question wins
            key = sorted(_words(q))
            for nid, nq in db.execute("SELECT id, q FROM notes WHERE active=1 AND kind IN ('verified','correction')").fetchall():
                if sorted(_words(nq)) == key:
                    db.execute("UPDATE notes SET active=0 WHERE id=?", (nid,))
        if v > 0:
            db.execute("INSERT INTO notes (kind, q, text, sources, made, asked_id) VALUES ('verified',?,?,?,?,?)",
                       (q, answer, sources, _now(), asked_id))
        elif v < 0:
            if (correction or "").strip():
                db.execute("INSERT INTO notes (kind, q, text, sources, made, asked_id) VALUES ('correction',?,?,?,?,?)",
                           (q, correction.strip(), "[]", _now(), asked_id))
            for s in json.loads(sources or "[]")[:6]:
                src = s[1] if isinstance(s, list) and len(s) > 1 else str(s)
                db.execute("INSERT INTO demoted VALUES (?,?,?)", (q, src, _now()))
        db.commit()
        db.close()
    return True


def add_note(dest, q, text, kind="note"):
    with _LOCK:
        db = connect(dest)
        db.execute("INSERT INTO notes (kind, q, text, sources, made) VALUES (?,?,?,?,?)", (kind, q[:500], text[:8000], "[]", _now()))
        db.commit()
        db.close()


def delete_note(dest, nid):
    with _LOCK:
        db = connect(dest)
        db.execute("DELETE FROM notes WHERE id=?", (nid,))
        db.commit()
        db.close()


def notes_for(dest, q, k=3):
    """Active notes that match the question best: [(id, kind, q, text, made)]."""
    db = connect(dest, readonly=True)
    if not db:
        return []
    ws = _words(q)
    if not ws:
        return []
    try:
        try:
            expr = " OR ".join(f'"{w}"' + ("*" if len(w) > 3 else "") for w in ws)
            rows = db.execute("SELECT n.id, n.kind, n.q, n.text, n.made, bm25(notes_fts, 3.0, 1.0) AS s FROM notes_fts "
                              "JOIN notes n ON n.id = notes_fts.rowid WHERE notes_fts MATCH ? AND n.active=1 ORDER BY s LIMIT 12",
                              (expr,)).fetchall()
            # keep notes that share at least half of the question's words (or 2) — loose matches are noise
            out = []
            for r in rows:
                have = set(WORD.findall((r[2] + " " + r[3]).lower()))
                hit = sum(1 for w in ws if any(h.startswith(w[:5]) for h in have))
                if hit >= max(1, min(2, len(ws)), len(ws) // 2):
                    out.append(r[:5])
            return out[:k]
        except sqlite3.Error:                         # no FTS5 on this Python: simple word match
            rows = db.execute("SELECT id, kind, q, text, made FROM notes WHERE active=1").fetchall()
            sc = sorted(((sum(w in (r[2] + " " + r[3]).lower() for w in ws), r) for r in rows), reverse=True)
            return [r for s, r in sc if s >= max(1, len(ws) // 2)][:k]
    finally:
        db.close()


def demoted_for(dest, q):
    """Sources marked wrong for questions that share most words with this one."""
    db = connect(dest, readonly=True)
    if not db:
        return set()
    try:
        ws = set(_words(q))
        out = set()
        for oq, src in db.execute("SELECT q, src FROM demoted").fetchall():
            ow = set(_words(oq))
            if ws and ow and len(ws & ow) >= max(1, (len(ws | ow) + 1) // 2):
                out.add(src)
        return out
    except sqlite3.Error:
        return set()
    finally:
        db.close()


def history(dest, n=200):
    db = connect(dest, readonly=True)
    if not db:
        return {"asked": [], "notes": []}
    try:
        asked = [dict(zip(("id", "ts", "q", "mode", "vote", "correction", "answer"), r)) for r in db.execute(
            "SELECT id, ts, q, mode, vote, correction, substr(answer,1,600) FROM asked ORDER BY id DESC LIMIT ?", (n,))]
        notes = [dict(zip(("id", "kind", "q", "text", "made"), r)) for r in db.execute(
            "SELECT id, kind, q, text, made FROM notes WHERE active=1 ORDER BY id DESC")]
        ctx = db.execute("SELECT COUNT(*) FROM context").fetchone()[0]
        return {"asked": asked, "notes": notes, "context_pages": ctx}
    finally:
        db.close()


# --------------------------------------------------------------------------- page context notes (context_notes.py)
def contexts_for_doc(db, doc_key):
    try:
        return {p: c for p, c in db.execute("SELECT page, ctx FROM context WHERE doc=?", (doc_key,))}
    except sqlite3.Error:
        return {}


def context_of(dest, doc_key, page):
    db = connect(dest, readonly=True)
    if not db:
        return ""
    try:
        r = db.execute("SELECT ctx FROM context WHERE doc=? AND page=?", (doc_key, page)).fetchone()
        return r[0] if r else ""
    except sqlite3.Error:
        return ""
    finally:
        db.close()
