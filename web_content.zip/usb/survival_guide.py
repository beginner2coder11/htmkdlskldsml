#!/usr/bin/env python3
"""Make a quick, printable survival guide for ONE situation, built from THIS drive's own sources.

Pick a situation (get home, shelter in place, water, medical, power out, winter storm, comms down, evacuate)
and — for the travel ones — a route. It compiles into one self-contained page:
  * the immediate "do this now" steps for that situation,
  * the most relevant sections from your guides and the manuals to read next (links into the library),
  * the offline archives worth opening (Wikipedia/WikEM/iFixit…),
  * for a route: the get-home plan with its chokepoints, each spot's coordinates/MGRS, and map links,
  * the nearest real places from the locator (water, fuel, hospitals, shelter, pharmacy…).

Runs on the drive's own Python, fully offline. Reads www/topics-data.js, www/data/pois.js and the route plans.
Writes www/guides/<situation>.html and opens it. The original sources are never changed.

  python survival_guide.py --dest E:\\OFFGRID                 # interactive: pick a situation (and route)
  python survival_guide.py --dest E:\\OFFGRID --scenario water
  python survival_guide.py --dest E:\\OFFGRID --scenario get-home --route toronto
"""
import argparse, html, json, os, re, sys, time, webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # so coords/routes_data import under the drive's Python
try:
    import coords
except Exception:  # noqa: BLE001
    coords = None
try:
    import routes_data
    ROUTES = routes_data.ROUTES
except Exception:  # noqa: BLE001
    ROUTES = []

# Each situation: what to rank the library by, which archives and locator categories matter, and the
# authoritative first steps (these are written here, not pulled, so the top of the guide is always sound).
SCENARIOS = [
    {"key": "get-home", "label": "Get home (stuck away, need to travel back)", "route": True,
     "kw": ["evacuat", "navigat", "route", "vehicle", "car ", "fuel", "map", "compass", "walk", "foot", "shelter", "water", "signal"],
     "zim": ["wikivoyage", "wikipedia", "zimgit-post-disaster"],
     "pois": ["fuel", "water", "hospital", "shelter", "police", "general"],
     "now": ["Stop and think for 60 seconds before moving. Note where you are (grid/landmark) and the direction home.",
             "Top off fuel, water and phone charge NOW while they're available; fill every container.",
             "Pick the route and the big chokepoints to avoid (see the plan below). Tell someone your plan if any comms work.",
             "Travel light but carry water, a way to purify it, warmth, light, a knife and your maps.",
             "Move in daylight, avoid crowds and chokepoints, keep off the main arteries if they're jammed."]},
    {"key": "shelter-in-place", "label": "Shelter in place (stay put, ride it out)", "route": False,
     "kw": ["shelter", "water", "food", "storage", "sanitation", "heat", "warm", "power", "cook", "hygiene", "ventilat"],
     "zim": ["zimgit-post-disaster", "zimgit-water", "zimgit-food", "appropedia", "wikipedia"],
     "pois": ["water", "grocery", "fuel", "pharmacy", "hardware"],
     "now": ["Account for everyone. Close up the house; conserve heat/cool. Fill tubs and containers with water now.",
             "Ration water first (1 gal/person/day minimum), then food. Keep the fridge/freezer shut.",
             "Set up one warm (or cool) room. Ventilate any flame or generator to the outside — never run fuel indoors.",
             "Set a sanitation plan (bagged waste, designated bucket) before you need it.",
             "Check on neighbors if safe. Keep a radio on for official word."]},
    {"key": "water", "label": "Water (find, filter, make it safe)", "route": False,
     "kw": ["water", "purif", "filter", "boil", "disinfect", "chlorin", "iodine", "spring", "well", "rain", "cholera", "dehydrat", "distill"],
     "zim": ["zimgit-water", "appropedia", "wikipedia", "mdwiki"],
     "pois": ["water", "grocery", "hardware", "fuel"],
     "now": ["Find water: tap/stored first, then rain, spring, moving stream — avoid stagnant, salty or chemical sources.",
             "Make it safe: filter out dirt through cloth, then BOIL 1 minute (3 min above 6,500 ft), OR use unscented bleach (see the guide for drops/gallon), OR a proper filter.",
             "Store in clean, covered containers. Keep dirty and clean containers separate.",
             "Don't ration your body's water to the point of harm — drink when thirsty; conserve by resting in shade."]},
    {"key": "medical", "label": "Medical / injury", "route": False,
     "kw": ["first aid", "bleed", "wound", "trauma", "tourniquet", "cpr", "burn", "fracture", "splint", "shock", "infection", "antibiotic", "triage"],
     "zim": ["mdwiki", "zimgit-medicine", "libretexts.org_en_med", "wikipedia"],
     "pois": ["hospital", "urgent_care", "pharmacy", "clinic", "ems"],
     "now": ["Make sure the scene is safe before you help. Stop life threats first.",
             "Severe bleeding: direct firm pressure; a tourniquet high and tight on a limb if it won't stop. Note the time.",
             "Not breathing / no pulse: start CPR — hard and fast chest compressions.",
             "Keep them warm and still; treat for shock. Clean and cover wounds to prevent infection.",
             "Get to the nearest hospital/urgent care below if you can reach one."]},
    {"key": "power-outage", "label": "Power outage", "route": False,
     "kw": ["power", "electric", "generator", "battery", "solar", "fuel", "heat", "cold", "food", "freezer", "candle", "carbon monoxide"],
     "zim": ["zimgit-post-disaster", "appropedia", "ifixit", "wikipedia"],
     "pois": ["fuel", "hardware", "grocery", "general", "rv_marine"],
     "now": ["Keep fridge and freezer shut — a full freezer holds ~48 hours closed.",
             "Run generators OUTSIDE only, away from windows — carbon monoxide kills indoors.",
             "Unplug sensitive electronics to protect them from the surge when power returns.",
             "Light with LED/battery, not open flame where possible. Conserve phone battery.",
             "In cold: close off one room and warm it; in heat: stay low, shaded and hydrated."]},
    {"key": "winter-storm", "label": "Winter storm / extreme cold", "route": False,
     "kw": ["cold", "hypothermia", "frostbite", "heat", "warm", "snow", "ice", "shelter", "layer", "fire", "stranded", "vehicle"],
     "zim": ["zimgit-post-disaster", "mdwiki", "wikipedia", "appropedia"],
     "pois": ["fuel", "shelter", "hardware", "grocery", "hospital"],
     "now": ["Stay inside and dry. Layer clothing; cover head and hands. Warm one room.",
             "Watch for hypothermia (shivering, confusion, slurred speech) and frostbite (white, numb skin) — rewarm gradually.",
             "Never heat with a stove/oven or run a generator indoors (carbon monoxide).",
             "If stranded in a vehicle: stay in it, run the engine ~10 min/hour with the window cracked and the exhaust pipe clear, make yourself visible."]},
    {"key": "comms-down", "label": "Communications down", "route": False,
     "kw": ["radio", "antenna", "frequency", "repeater", "gmrs", "ham", "baofeng", "chirp", "meshtastic", "signal", "nvis", "morse", "beacon"],
     "zim": ["ham.stackexchange", "wikipedia", "zimgit-post-disaster"],
     "pois": ["repeater", "broadcast", "media", "comm_tower"],
     "now": ["Try text before voice — it gets through weak signal when calls won't. Try again from high ground.",
             "Switch on the plan: your programmed radios and the family channel. Monitor local repeaters and NOAA/weather.",
             "Set a schedule (e.g. listen at the top of each hour) to save battery and sync with others.",
             "Keep antennas high and clear. Have a fallback meeting place and time if all comms fail."]},
    {"key": "evacuate", "label": "Evacuate / bug out", "route": True,
     "kw": ["evacuat", "bug out", "go bag", "bag", "navigat", "route", "vehicle", "fuel", "shelter", "water", "document"],
     "zim": ["zimgit-post-disaster", "wikivoyage", "wikipedia"],
     "pois": ["fuel", "water", "shelter", "hospital", "general", "police"],
     "now": ["Leave early if you can — the roads are clearest before an order becomes mandatory.",
             "Grab the go-bag, water, meds, documents (IDs, deeds, insurance), cash, chargers, and your maps.",
             "Pick the route and a backup; note fuel stops and chokepoints below. Fuel up before you go.",
             "Tell someone your destination and route. Leave a note if you expect others to follow.",
             "Shut off utilities if told to. Take pets, carriers and their food/water."]},
]
SMAP = {s["key"]: s for s in SCENARIOS}


def _load_js(path, var):
    """Read one `window.<var> = <json>;` assignment, even with other assignments in the same file."""
    try:
        t = open(path, encoding="utf-8").read()
        i = t.index("=", t.index("window." + var)) + 1
        obj, _ = json.JSONDecoder().raw_decode(t[i:].lstrip())   # parses exactly one value, ignores the rest
        return obj
    except Exception:  # noqa: BLE001
        return None


def _score(text, kws):
    t = text.lower()
    return sum(t.count(k) for k in kws)


def _rank_sections(topics, kws, n=12):
    scored = []
    for sec in topics.get("sections", []):
        g, title, link, body = (sec + ["", "", "", ""])[:4]
        s = _score(title, kws) * 3 + _score(body, kws)
        if s:
            scored.append((s, g, title, link, body))
    scored.sort(key=lambda x: -x[0])
    return scored[:n]


def _rank_pdfs(topics, kws, n=10):
    scored = [(_score(f"{cat} {title}", kws), cat, title, link) for cat, title, link in topics.get("pdfs", [])]
    scored = [x for x in scored if x[0] > 0]
    scored.sort(key=lambda x: -x[0])
    return scored[:n]


CANADA_CITIES = {"toronto": ("Toronto, ON", 43.653, -79.383), "montreal": ("Montréal, QC", 45.502, -73.567),
                 "quebec city": ("Québec City, QC", 46.814, -71.208), "quebec": ("Québec City, QC", 46.814, -71.208),
                 "ottawa": ("Ottawa, ON", 45.421, -75.697), "windsor": ("Windsor, ON", 42.317, -83.036),
                 "kingston": ("Kingston, ON", 44.231, -76.486), "london": ("London, ON", 42.984, -81.246),
                 "sherbrooke": ("Sherbrooke, QC", 45.404, -71.893), "trois-rivieres": ("Trois-Rivières, QC", 46.343, -72.543),
                 "hamilton": ("Hamilton, ON", 43.256, -79.869), "niagara falls": ("Niagara Falls, ON", 43.090, -79.085)}
WX = [("WX1", "162.550"), ("WX2", "162.400"), ("WX3", "162.475"), ("WX4", "162.425"), ("WX5", "162.450"), ("WX6", "162.500"), ("WX7", "162.525")]
ESSENTIAL = ["hospital", "urgent_care", "pharmacy", "fuel", "grocery", "water", "shelter", "police", "hardware", "auto_parts"]


def _mi(la1, lo1, la2, lo2):
    import math
    r = math.radians
    a = math.sin(r(la2 - la1) / 2) ** 2 + math.cos(r(la1)) * math.cos(r(la2)) * math.sin(r(lo2 - lo1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(min(1, a)))


def _bearing(la1, lo1, la2, lo2):
    import math
    r = math.radians
    y = math.sin(r(lo2 - lo1)) * math.cos(r(la2))
    x = math.cos(r(la1)) * math.sin(r(la2)) - math.sin(r(la1)) * math.cos(r(la2)) * math.cos(r(lo2 - lo1))
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int(((math.degrees(math.atan2(y, x)) + 360) % 360 + 22.5) // 45) % 8]


def find_place(dest, text):
    """'Montreal', 'Albany, NY', 'quebec' (a route), or '45.5, -73.6' -> (label, lat, lon) or None. Offline."""
    t = (text or "").strip()
    if not t:
        return None
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$", t)
    if m:
        return (f"{float(m.group(1)):.4f}, {float(m.group(2)):.4f}", float(m.group(1)), float(m.group(2)))
    low = t.lower()
    for r in ROUTES:
        if low in (r["key"], r["label"].lower()) or r["label"].lower().startswith(low):
            return (r["label"], r["line"][0][0], r["line"][0][1])
    name = re.split(r",", low)[0].strip()
    if name in CANADA_CITIES:
        return CANADA_CITIES[name]
    st = (re.split(r",", low) + [""])[1].strip().upper()
    best = None
    for path in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "us-cities.csv"),
                 os.path.join(dest, "tools", "builder", "usb", "data", "us-cities.csv")):
        try:
            import csv
            for row in csv.DictReader(open(path, encoding="utf-8")):
                if row["city"].lower() == name and (not st or row["state_id"] == st):
                    pop = int(float(row.get("population") or 0))
                    if not best or pop > best[0]:
                        best = (pop, f"{row['city']}, {row['state_id']}", float(row["lat"]), float(row["lng"]))
            break
        except OSError:
            continue
    return best[1:] if best else None


def _all_places(dest, la, lo, radius=60):
    """Every place within `radius` miles of (la, lo) from the home locator, the route corridors and the 500-mile layer."""
    www = os.path.join(dest, "www", "data")
    out, seen = [], set()

    def add(cat, name, pla, plo, addr="", phone=""):
        if abs(pla - la) > radius / 60 or abs(plo - lo) > radius / 40:
            return
        k = (cat, name, round(pla, 3), round(plo, 3))
        if k in seen:
            return
        d = _mi(la, lo, pla, plo)
        if d <= radius:
            seen.add(k)
            out.append([cat, name, pla, plo, round(d, 1), _bearing(la, lo, pla, plo), addr, phone])
    for r in _load_js(os.path.join(www, "pois.js"), "POIS") or []:
        add(r[0], r[1], r[2], r[3], r[6], r[7])
    import glob as _g
    for f in _g.glob(os.path.join(www, "corridors", "*.js")):
        if f.endswith("index.js"):
            continue
        t = open(f, encoding="utf-8").read()
        try:
            obj = json.loads(t[t.index("]=") + 2:].rstrip().rstrip(";"))
        except ValueError:
            continue
        for r in obj.get("rows", []):
            add(r[0], r[1], r[2], r[3], r[4], r[5])
    idx = _load_js(os.path.join(www, "poi500", "index.js"), "POIR_INDEX") or {}
    for stt, (s_, w_, n_, e_) in (idx.get("bbox") or {}).items():
        if s_ - 1 <= la <= n_ + 1 and w_ - 1.3 <= lo <= e_ + 1.3:
            t = open(os.path.join(www, "poi500", stt + ".js"), encoding="utf-8").read()
            for r in json.loads(t[t.index("]=") + 2:].rstrip().rstrip(";")):
                add(r[0], r[1], r[2], r[3], r[4], r[5])
    out.sort(key=lambda x: (x[0], x[4]))
    return out


def _corridor(dest, key):
    t = os.path.join(dest, "www", "data", "corridors", key + ".js")
    try:
        s_ = open(t, encoding="utf-8").read()
        return json.loads(s_[s_.index("]=") + 2:].rstrip().rstrip(";"))
    except (OSError, ValueError):
        return None


def _nearby(pois, cats, per=3):
    out = []
    for c in cats:
        rows = [r for r in pois if r[0] == c][:per]           # POIS already sorted by (cat, miles)
        if rows:
            out.append((c, rows))
    return out


def _esc(s):
    return html.escape(str(s or ""))


CSS = """body{font:16px/1.55 system-ui,Segoe UI,Roboto,sans-serif;max-width:860px;margin:0 auto;padding:24px;color:#14171a}
h1{font-size:26px;margin:0 0 2px} h2{font-size:19px;margin:26px 0 8px;border-bottom:2px solid #c9771f;padding-bottom:3px;color:#9a5a12}
h3{font-size:16px;margin:14px 0 4px} .sub{color:#555;margin:0 0 14px} ul{margin:6px 0 6px 2px;padding-left:20px} li{margin:3px 0}
.now li{margin:7px 0;font-weight:600} a{color:#1a5db8;text-decoration:none} a:hover{text-decoration:underline}
.card{border:1px solid #e0e3e7;border-radius:8px;padding:10px 14px;margin:8px 0;background:#fafbfc}
.src{color:#666;font-size:13px} .mono{font-family:ui-monospace,Consolas,monospace;font-size:13px}
.tag{display:inline-block;background:#eef2f6;border-radius:4px;padding:0 6px;font-size:12px;color:#445;margin-left:6px}
table{border-collapse:collapse;width:100%;font-size:14px;margin:4px 0} td,th{border-bottom:1px solid #e6e9ec;padding:4px 6px;text-align:left;vertical-align:top}
.note{background:#fff7e9;border:1px solid #f0d9a8;border-radius:8px;padding:8px 12px;font-size:14px}
@media print{a{color:#000}.card{break-inside:avoid}h2{break-after:avoid}body{max-width:none}}
@media(prefers-color-scheme:dark){body{background:#14171a;color:#e6e8eb}.card{background:#1b1f24;border-color:#2c323a}
 h2{color:#d9a441;border-color:#8a5a1a}.src{color:#9aa}a{color:#6db0ff}.note{background:#241e12;border-color:#5a4a28}
 td,th{border-color:#2c323a}.tag{background:#222933;color:#bcd}}"""


def build_guide(dest, key, route_key=None, start=None):
    """start = (label, lat, lon): where you are now (default: home, or the route's start city)."""
    sc = SMAP[key]
    www = os.path.join(dest, "www")
    topics = _load_js(os.path.join(www, "topics-data.js"), "TOPICS") or {"sections": [], "pdfs": [], "zims": []}
    pois = _load_js(os.path.join(www, "data", "pois.js"), "POIS") or []
    meta = _load_js(os.path.join(www, "data", "pois.js"), "POI_META") or {}
    cats = meta.get("categories", {})
    secs = _rank_sections(topics, sc["kw"])
    pdfs = _rank_pdfs(topics, sc["kw"])
    zims = [z for z in topics.get("zims", []) if any(h in z.lower() for h in sc["zim"])]
    route = next((r for r in ROUTES if r["key"] == route_key), None) if (sc["route"] and route_key) else None
    if route and not start:
        start = (route["label"], route["line"][0][0], route["line"][0][1])
    away = None
    if start:
        hl, ho = meta.get("lat"), meta.get("lon")
        if hl is None or _mi(start[1], start[2], hl, ho) > 15:
            away = _all_places(dest, start[1], start[2])
    corr = _corridor(dest, route["key"]) if route else None

    P = ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">',
         '<meta name="viewport" content="width=device-width,initial-scale=1">',
         f"<title>Survival guide — {_esc(sc['label'])}</title><style>{CSS}</style></head><body>"]
    P.append(f"<h1>Survival guide: {_esc(sc['label'])}</h1>")
    where = meta.get("label", "")
    P.append(f"<p class='sub'>Made from this drive on {time.strftime('%Y-%m-%d %H:%M')}"
             + (f" · home area: {_esc(where)}" if where else "")
             + (f" · route: {_esc(route['label'])}" if route else "")
             + (f" · starting from: {_esc(start[0])}" if start and not route else "") + "</p>")
    P.append("<div class='note'>Quick reference compiled from this drive's own guides, manuals, archives, maps and "
             "locator. OCR and summaries can contain errors — open the linked source for anything critical.</div>")

    # 1) do this now
    P.append("<h2>Do this now</h2><ul class='now'>")
    P += [f"<li>{_esc(step)}</li>" for step in sc["now"]]
    P.append("</ul>")

    # 2) route plan + maps
    if route:
        P.append(f"<h2>Getting home from {_esc(route['label'])}</h2>")
        P.append(f"<p>About <b>{route['miles']} miles</b>, roughly <b>{route.get('drive', '?')}</b> driving. "
                 f"Open the route on the <a href='../index.html#route={_esc(route['key'])}'>locator map</a> "
                 "(turn on the Topo and Satellite layers to study the terrain and chokepoints).</p>")
        P.append("<table><tr><th>Waypoint</th><th>Type</th><th>Coordinates</th><th>MGRS</th></tr>")
        for sp in route.get("spots", []):
            la, lo = sp["lat"], sp["lon"]
            mg = coords.mgrs(la, lo) if coords else ""
            P.append(f"<tr><td>{_esc(sp['name'])}</td><td>{_esc(sp.get('kind', ''))}</td>"
                     f"<td class='mono'>{la:.4f}, {lo:.4f}</td><td class='mono'>{_esc(mg)}</td></tr>")
        P.append("</table>")

    # 3) from your library
    if secs or pdfs:
        P.append("<h2>Read these (from your library)</h2>")
        for s, g, title, link, body in secs:
            snip = re.sub(r"\s+", " ", body)[:200]
            P.append(f"<div class='card'><a href='../{_esc(link)}'><b>{_esc(title)}</b></a> "
                     f"<span class='tag'>{_esc(g)}</span><div class='src'>{_esc(snip)}…</div></div>")
        if pdfs:
            P.append("<h3>Manuals</h3><ul>")
            P += [f"<li><a href='../{_esc(link)}'>{_esc(title)}</a> <span class='tag'>{_esc(cat)}</span></li>"
                  for _, cat, title, link in pdfs]
            P.append("</ul>")

    # 4) archives
    if zims:
        P.append("<h2>Archives to open</h2><ul>")
        P += [f"<li><a href='../../kiwix/' >{_esc(z)}</a> <span class='src'>— open in Kiwix (Read the archives)</span></li>" for z in zims]
        P.append("</ul>")

    # 5a) where you are now (away from home), and along the way home
    if start and away is not None:
        cats_here = list(dict.fromkeys(sc["pois"] + ["hospital", "pharmacy", "fuel", "police"]))
        here = _nearby(away, cats_here)
        P.append(f"<h2>Nearest places to {_esc(start[0])}</h2>")
        if here:
            P.append("<p class='src'>Straight-line distance and direction from there. From the route corridors, the 500-mile layer "
                     "and the home locator on this drive.</p>")
            for c, rows in here:
                P.append(f"<h3>{_esc(cats.get(c, c))}</h3><table>")
                for r in rows:
                    P.append(f"<tr><td><b>{_esc(r[1])}</b><br><span class='src'>{_esc(r[6])}</span></td>"
                             f"<td class='mono'>{r[4]} mi {_esc(r[5])}</td><td>{_esc(r[7])}</td>"
                             f"<td class='mono'>{coords.mgrs(r[2], r[3]) if coords else f'{r[2]:.4f},{r[3]:.4f}'}</td></tr>")
                P.append("</table>")
        else:
            P.append("<div class='note'>No places for that area are on the drive yet. Run <b>ADD-ROUTE-PLACES</b> (with internet) "
                     "to load hospitals, fuel, food, water and repeaters along every get-home route, including Canada.</div>")
    if route:
        P.append(f"<h2>Along the way home from {_esc(route['label'])}</h2>")
        if corr and corr.get("rows"):
            rows = corr["rows"]
            P.append("<p class='src'>Nearest essentials within 25 miles of each waypoint (miles from the start city, then off the road).</p>"
                     "<table><tr><th>Waypoint</th>" + "".join(f"<th>{_esc(cats.get(c, c))}</th>" for c in ("hospital", "fuel", "pharmacy", "grocery", "water")) + "</tr>")
            for sp in [{"name": route["label"] + " (start)", "lat": route["line"][0][0], "lon": route["line"][0][1]}] + route.get("spots", []):
                cells = []
                for c in ("hospital", "fuel", "pharmacy", "grocery", "water"):
                    cand = sorted((_mi(sp["lat"], sp["lon"], r[2], r[3]), r) for r in rows if r[0] == c and abs(r[2] - sp["lat"]) < 0.5 and abs(r[3] - sp["lon"]) < 0.7)
                    cells.append(f"<b>{_esc(cand[0][1][1])}</b><br><span class='src'>{cand[0][0]:.0f} mi {_bearing(sp['lat'], sp['lon'], cand[0][1][2], cand[0][1][3])}"
                                 f"{' · ' + _esc(cand[0][1][5]) if cand[0][1][5] else ''}</span>" if cand and cand[0][0] <= 25 else "<span class='src'>none on file</span>")
                P.append(f"<tr><td>{_esc(sp['name'])}</td>" + "".join(f"<td>{c}</td>" for c in cells) + "</tr>")
            P.append("</table>")
            if corr.get("missing"):
                P.append(f"<p class='src'>Not loaded yet: {_esc(', '.join(corr['missing']))} - run ADD-ROUTE-PLACES again with internet.</p>")
        else:
            P.append("<div class='note'>Places along this route aren't on the drive yet. Run <b>ADD-ROUTE-PLACES</b> (with internet) - it "
                     "loads hospitals, fuel, food, water, shelters and ham repeaters within 25 miles of the road, including Canada.</div>")

    # 5b) radio for the trip
    if route or start:
        canada = bool((route and any(sp.get("kind") == "border" for sp in route.get("spots", [])))
                      or (start and (re.search(r", (ON|QC)$", start[0]) or (start[1] > 45.02 and -80 < start[2] < -60))))
        P.append("<h2>Radio for this trip</h2><ul>")
        P.append("<li><b>Weather radio (US):</b> program all seven: " + ", ".join(f"{a} {f}" for a, f in WX) +
                 " MHz and use weather-scan - the nearest NOAA transmitter (about 40 miles range) comes in as you travel.</li>")
        if canada:
            P.append("<li><b>Canada:</b> Environment Canada's Weatheradio broadcasts have been shut down. Use local AM/FM news "
                     "(CBC/Radio-Canada) and official alerts until you are back in the US.</li>"
                     "<li><b>Ham radio in Canada:</b> a US licence works there under the US–Canada reciprocal agreement - no permit. "
                     "Sign your call followed by the area: <b>/VE2</b> in Quebec, <b>/VE3</b> in Ontario (e.g. KN4ABC/VE2), carry your "
                     "licence and proof of US citizenship, and follow Canadian band rules.</li>")
        reps = [r for r in ((corr or {}).get("rows") or []) if r[0] == "repeater"]
        if not reps and away:
            reps = [r for r in away if r[0] == "repeater"]
        if reps:
            P.append("<li><b>Ham / GMRS repeaters mapped along the way</b> (from OpenStreetMap - incomplete; check before relying on one):"
                     "<table><tr><th>Name</th><th>Details</th><th>Where</th></tr>" +
                     "".join(f"<tr><td>{_esc(r[1])}</td><td class='mono'>{_esc(r[8] if len(r) > 8 else r[6])}</td>"
                             f"<td class='mono'>{('mile ' + str(r[9])) if len(r) > 9 else (str(r[4]) + ' mi ' + r[5])}</td></tr>" for r in reps[:40]) +
                     "</table></li>")
        P.append("<li>For a full repeater list, export one for your route from a repeater directory before the trip and drop it in "
                 "MY-RADIO-INBOX; your channel plan and radio manuals are on the <a href='../radio.html'>Radio hub</a>.</li></ul>")

    # 5c) nearby real places (home)
    near = _nearby(pois, sc["pois"])
    if near and not (start and away is not None):
        P.append("<h2>Nearest places" + (f" to {_esc(where)}" if where else "") + "</h2>")
        P.append("<p class='src'>From the locator. Distances/bearings are straight-line from home. "
                 "Open the <a href='../index.html'>locator map</a> to route to any of them"
                 + (" or to find places along the way home." if route else ".") + "</p>")
        for c, rows in near:
            P.append(f"<h3>{_esc(cats.get(c, c))}</h3><table>")
            for r in rows:
                name, la, lo, mi, dr, addr, phone = r[1], r[2], r[3], r[4], r[5], r[6], r[7]
                P.append(f"<tr><td><b>{_esc(name)}</b><br><span class='src'>{_esc(addr)}</span></td>"
                         f"<td class='mono'>{mi} mi {_esc(dr)}</td><td>{_esc(phone)}</td>"
                         f"<td class='mono'>{coords.mgrs(la, lo) if coords else f'{la:.4f},{lo:.4f}'}</td></tr>")
            P.append("</table>")

    P.append("<h2>More</h2><ul>"
             "<li><a href='../search.html'>Search everything</a> — every guide and every page of every manual.</li>"
             "<li><a href='../ask.html'>Ask the drive</a> — the offline AI.</li>"
             "<li><a href='../topics.html'>What's happening?</a> — other situations and first steps.</li></ul>")
    P.append(f"<p class='src'>Generated by MAKE-A-GUIDE on this OFF-GRID drive. Situation: {_esc(key)}"
             + (f", route {_esc(route_key)}" if route else "") + ".</p></body></html>")

    outdir = os.path.join(www, "guides")
    os.makedirs(outdir, exist_ok=True)
    import unicodedata
    plain = unicodedata.normalize("NFKD", start[0]).encode("ascii", "ignore").decode().lower() if start else ""
    fn = key + (f"-{route_key}" if route else "") + (("-" + re.sub(r"[^a-z0-9]+", "-", plain).strip("-")) if start and not route else "") + ".html"
    path = os.path.join(outdir, fn)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(P))
    _write_index(outdir)
    return path, len(secs), len(pdfs), len(zims), sum(len(r) for _, r in near)


def _write_index(outdir):
    """A small landing page listing the guides made so far."""
    items = sorted(f for f in os.listdir(outdir) if f.endswith(".html") and f != "index.html")
    li = []
    for f in items:
        title = os.path.splitext(f)[0].replace("-", " ").title()
        li.append(f"<li><a href='{_esc(f)}'>{_esc(title)}</a></li>")
    html_doc = (f"<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>"
                f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
                f"<title>Survival guides</title><style>{CSS}</style></head><body>"
                "<h1>Survival guides</h1><p class='sub'>Quick situation guides made from this drive. "
                "Run MAKE-A-GUIDE to add more.</p><ul>" + "".join(li) + "</ul></body></html>")
    with open(os.path.join(outdir, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(html_doc)


def build_all(dest):
    """Make every situation guide (and each route) at build time so the Command Center's Survival guides tile always opens."""
    n = 0
    for sc in SCENARIOS:
        for rk in ([None] + [r["key"] for r in ROUTES] if sc["route"] else [None]):
            try:
                build_guide(dest, sc["key"], rk)
                n += 1
            except Exception as e:  # noqa: BLE001
                print(f"  ! guide {sc['key']} {rk or ''}: {type(e).__name__}: {e}")
    return n


def _interactive():
    print("\n  MAKE A SURVIVAL GUIDE — pick a situation:\n")
    for i, s in enumerate(SCENARIOS, 1):
        print(f"    {i:2}. {s['label']}")
    v = input("\n  Number: ").strip()
    if not (v.isdigit() and 1 <= int(v) <= len(SCENARIOS)):
        print("  Cancelled."); return None, None, None
    sc = SCENARIOS[int(v) - 1]
    rk = None
    if sc["route"] and ROUTES:
        print("\n  Which route (where are you coming home from)?\n")
        for i, r in enumerate(ROUTES, 1):
            print(f"    {i:2}. {r['label']}  ({r['miles']} mi)")
        rv = input("\n  Number (Enter to skip the route): ").strip()
        if rv.isdigit() and 1 <= int(rv) <= len(ROUTES):
            rk = ROUTES[int(rv) - 1]["key"]
    st = None
    if not rk:
        print("\n  Where are you now? Press Enter for home, or type a city (Montreal / Albany, NY) or lat, lon:")
        w = input("  Location: ").strip()
        if w:
            st = find_place(DEST, w)
            print(f"  -> {st[0]}" if st else "  Not found - using home.")
    return sc["key"], rk, st


DEST = "."


def main():
    ap = argparse.ArgumentParser(description="Make a printable survival guide from this drive's own sources.")
    ap.add_argument("--dest", required=True, help="the OFFGRID folder, e.g. E:\\OFFGRID")
    ap.add_argument("--scenario", choices=[s["key"] for s in SCENARIOS], help="situation key (interactive if omitted)")
    ap.add_argument("--route", help="route key for get-home/evacuate (e.g. toronto, richmond)")
    ap.add_argument("--where", help="where you are now: a city ('Montreal', 'Albany, NY') or 'lat, lon' (default: home)")
    ap.add_argument("--no-open", action="store_true", help="don't open the guide when done")
    a = ap.parse_args()
    global DEST
    DEST = a.dest
    if a.scenario:
        key, route, st = a.scenario, a.route, (find_place(a.dest, a.where) if a.where else None)
    else:
        key, route, st = _interactive()
    if not key:
        return 1
    path, ns, npd, nz, npl = build_guide(a.dest, key, route, st)
    print(f"\n  Guide saved: {path}")
    print(f"  Pulled in {ns} guide sections, {npd} manuals, {nz} archives, {npl} nearby places.")
    if not a.no_open:
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # noqa: S606
            else:
                import subprocess
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", path])
        except Exception:  # noqa: BLE001
            print("  Open it in your browser from the path above.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
