# -*- coding: utf-8 -*-
"""Satellite / aerial imagery for the whole Eastern US and Eastern Canada, stored in a few MBTiles files.

Why MBTiles and not one file per tile: a region-wide layer is millions of small tiles. On a big exFAT drive
each tiny file can take a 128 KB cluster (6x the real size) and Windows crawls over millions of files.
One SQLite file per zoom band avoids both, and MBTiles opens in many map apps as-is.

Where the pictures come from (tried in this order for each tile, by where the tile is):
  US states       USGS NAIP aerial photos (public domain)            -> Esri World Imagery if missing
  Ontario         Geospatial Ontario imagery (mostly Open Gov. Licence) -> Esri World Imagery if missing
  everywhere else Esri World Imagery (Maxar/Earthstar; Esri's terms only allow offline use in Esri apps —
                  the user chose to cache it anyway for emergencies)
A source that refuses scripts (403/429 again and again) is dropped for the run and listed in
REPORTS\\NOT-FETCHED-IMAGERY.txt — no workarounds.

Layers, in the order they download (most useful first):
  overview   zoom 6-12 over every eastern state and province (towns, highways, lakes, big fields)
  corridors  along each get-home route: zoom 13-15 within 15 miles, zoom 16 within 2 miles;
             home and each route's start city: zoom 13-16 within 12 miles
  z13 / z14 / z15   the whole region at that zoom (level 2 / 3 / 4 — bigger and slower each step)

Phones: phone_packs() copies home + each route into OsmAnd .sqlitedb files (www/phone-apps/satellite).
The drive's server serves /imagery/{z}/{x}/{y} from these files plus the older NAIP folder, so the map
has one "Satellite" layer that covers everything.
"""
import concurrent.futures as cf
import glob, json, math, os, queue, shutil, sqlite3, threading, time, urllib.error

SOURCES = {
    "naip": ("https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}",
             "USGS NAIP aerial imagery (public domain)"),
    "ontario": ("https://ws.lioservices.lrc.gov.on.ca/arcgis1071a/rest/services/LIO_Imagery/Ontario_Imagery_Web_Map_Service/MapServer/tile/{z}/{y}/{x}",
                "Geospatial Ontario imagery (Open Government Licence – Ontario)"),
    "esri": ("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
             "Esri World Imagery (Esri, Maxar, Earthstar Geographics)"),
}

# (south, west, north, east) — rough boxes, used to skip open ocean and pick the source
US = {"AL": (30.1, -88.5, 35.0, -84.9), "FL": (24.4, -87.6, 31.0, -80.0), "GA": (30.3, -85.6, 35.0, -80.8),
      "SC": (32.0, -83.4, 35.2, -78.5), "NC": (33.8, -84.3, 36.6, -75.4), "TN": (34.9, -90.3, 36.7, -81.6),
      "KY": (36.5, -89.6, 39.15, -81.9), "VA": (36.5, -83.7, 39.5, -75.2), "WV": (37.2, -82.7, 40.6, -77.7),
      "MD": (37.9, -79.5, 39.73, -75.0), "DE": (38.4, -75.8, 39.85, -75.0), "PA": (39.7, -80.6, 42.3, -74.7),
      "NJ": (38.9, -75.6, 41.36, -73.9), "NY": (40.5, -79.8, 45.02, -71.85), "CT": (40.95, -73.73, 42.05, -71.78),
      "RI": (41.1, -71.9, 42.02, -71.1), "MA": (41.2, -73.5, 42.9, -69.9), "VT": (42.7, -73.45, 45.02, -71.46),
      "NH": (42.7, -72.56, 45.31, -70.6), "ME": (43.0, -71.1, 47.47, -66.9), "OH": (38.4, -84.82, 42.0, -80.5),
      "MI": (41.7, -90.42, 48.3, -82.4), "IN": (37.77, -88.1, 41.77, -84.78), "IL": (36.97, -91.52, 42.51, -87.0),
      "WI": (42.49, -92.9, 47.1, -86.8), "MS": (30.17, -91.66, 35.0, -88.1)}
CA = {"ON": (41.6, -95.2, 50.5, -74.3), "QC": (44.99, -79.6, 49.3, -64.0), "NB": (44.6, -69.06, 48.07, -63.77),
      "NS": (43.4, -66.4, 47.04, -59.68), "PE": (45.95, -64.42, 47.07, -61.95), "NL": (46.6, -59.5, 51.7, -52.6)}

BANDS = [("overview", 6, 12), ("corridors", 13, 16), ("z13", 13, 13), ("z14", 14, 14), ("z15", 15, 15)]
LEVEL_BANDS = {1: ["overview", "corridors"], 2: ["overview", "corridors", "z13"],
               3: ["overview", "corridors", "z13", "z14"], 4: ["overview", "corridors", "z13", "z14", "z15"]}
KB_PER_TILE = {6: 18, 7: 18, 8: 18, 9: 18, 10: 18, 11: 18, 12: 20, 13: 22, 14: 24, 15: 26, 16: 28}
BLANK_BYTES = 1500          # a 256px JPEG this small is one flat color: "no imagery here" — try the next source
FREE_GB_STOP = 20           # leave room on the drive


# --------------------------------------------------------------------------- tile math
def tile_xy(lat, lon, z):
    n = 2 ** z
    lat = max(-85.05, min(85.05, lat))
    x = int((lon + 180) / 360 * n)
    y = int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
    return min(n - 1, max(0, x)), min(n - 1, max(0, y))


def tile_center(z, x, y):
    n = 2 ** z
    lon = (x + .5) / n * 360 - 180
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + .5) / n))))
    return lat, lon


def _in(box, lat, lon):
    return box[0] <= lat <= box[2] and box[1] <= lon <= box[3]


def chain(z, x, y):
    """Sources to try for this tile, best first."""
    lat, lon = tile_center(z, x, y)
    us = any(_in(b, lat, lon) for b in US.values())
    on = _in(CA["ON"], lat, lon)
    out = (["naip"] if us else []) + (["ontario"] if on else []) + ["esri"]
    return out


def _box_tiles(box, z):
    s, w, n, e = box
    x0, y0 = tile_xy(n, w, z)
    x1, y1 = tile_xy(s, e, z)
    return x0, y0, x1, y1


def region_tiles(z):
    """Every tile at zoom z inside one of the state/province boxes, as {x: (ymin, ymax) ranges...}."""
    cols = {}
    for box in list(US.values()) + list(CA.values()):
        x0, y0, x1, y1 = _box_tiles(box, z)
        for x in range(x0, x1 + 1):
            cols.setdefault(x, []).append((y0, y1))
    for x, rs in cols.items():                     # merge overlapping y ranges per column
        rs.sort()
        m = [list(rs[0])]
        for a, b in rs[1:]:
            if a <= m[-1][1] + 1:
                m[-1][1] = max(m[-1][1], b)
            else:
                m.append([a, b])
        cols[x] = m
    return cols


def _mi(la1, lo1, la2, lo2):
    r = math.radians
    a = math.sin(r(la2 - la1) / 2) ** 2 + math.cos(r(la1)) * math.cos(r(la2)) * math.sin(r(lo2 - lo1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(min(1, a)))


def dense(line, step=2.0):
    out = []
    for (a, b), (c, d) in zip(line, line[1:]):
        k = max(1, int(_mi(a, b, c, d) / step))
        out += [(a + (c - a) * i / k, b + (d - b) * i / k) for i in range(k)]
    return out + [tuple(line[-1])]


def near_tiles(points, miles, z):
    """Tiles at zoom z within ~miles of any of the points."""
    out = set()
    for lat, lon in points:
        dla = miles / 69.0
        dlo = miles / (69.0 * max(.2, math.cos(math.radians(lat))))
        x0, y0, x1, y1 = _box_tiles((lat - dla, lon - dlo, lat + dla, lon + dlo), z)
        for x in range(x0, x1 + 1):
            for y in range(y0, y1 + 1):
                out.add((x, y))
    return out


def corridor_tiles(routes, home):
    """{z: set((x, y))} for the corridors band."""
    out = {z: set() for z in range(13, 17)}
    cities = [(home["lat"], home["lon"])] if home else []
    for r in routes:
        pts = dense(r["line"], 2.0)
        cities.append(tuple(r["line"][0]))
        for z in (13, 14, 15):
            out[z] |= near_tiles(pts[::3] if z == 13 else pts, 15, z)
        out[16] |= near_tiles(pts, 2, 16)
    for z in range(13, 17):
        out[z] |= near_tiles(cities, 12, z)
    return out


# --------------------------------------------------------------------------- MBTiles store
def folder(dest):
    return os.path.join(dest, "www", "tiles", "imagery")


def open_db(path, name="", minz=0, maxz=0):
    db = sqlite3.connect(path, timeout=60, check_same_thread=False)
    db.execute("PRAGMA journal_mode=DELETE")
    db.execute("PRAGMA synchronous=NORMAL")
    db.execute("CREATE TABLE IF NOT EXISTS metadata (name text, value text)")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS md ON metadata (name)")
    db.execute("CREATE TABLE IF NOT EXISTS tiles (zoom_level integer, tile_column integer, tile_row integer, tile_data blob)")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS tile_index ON tiles (zoom_level, tile_column, tile_row)")
    db.execute("CREATE TABLE IF NOT EXISTS misses (z integer, x integer, y integer, PRIMARY KEY (z, x, y))")
    if name:
        md = {"name": f"OFFGRID satellite — {name}", "format": "jpg", "type": "baselayer", "version": "1",
              "minzoom": str(minz), "maxzoom": str(maxz), "bounds": "-95.2,24.4,-52.6,51.7",
              "attribution": "; ".join(v[1] for v in SOURCES.values()),
              "description": "Eastern US and Eastern Canada imagery cached by the OFFGRID builder"}
        db.executemany("INSERT OR REPLACE INTO metadata VALUES (?, ?)", md.items())
        db.commit()
    return db


def _have_col(db, z, x):
    """y values (XYZ numbering) already stored or known missing in column x at zoom z."""
    n = 2 ** z
    got = {n - 1 - r for (r,) in db.execute("SELECT tile_row FROM tiles WHERE zoom_level=? AND tile_column=?", (z, x))}
    got |= {y for (y,) in db.execute("SELECT y FROM misses WHERE z=? AND x=?", (z, x))}
    return got


def _free_gb(path):
    try:
        return shutil.disk_usage(path).free / 1e9
    except OSError:
        return 9e9


class Fetcher:
    """Tries each source for a tile; drops a source that keeps refusing scripts."""

    def __init__(self, u, dest):
        self.u, self.dest = u, dest
        self.dead, self.refused, self.lock = {}, {}, threading.Lock()
        self.used = {}
        self.errs_in_a_row = 0

    def reachable(self):
        """One test tile from each server; None if at least one answers, else the reason."""
        why = []
        for src, (url, _) in SOURCES.items():
            try:
                self.u.fetch(url.format(z=6, x=17, y=25), 30)
                return None
            except urllib.error.HTTPError as ex:
                if ex.code in (400, 404):
                    return None
                why.append(f"{src}: HTTP {ex.code}")
            except Exception as ex:  # noqa: BLE001
                why.append(f"{src}: {str(ex)[:80]}")
        return "; ".join(why)

    def get(self, z, x, y):
        for src in chain(z, x, y):
            if src in self.dead:
                continue
            try:
                data = self.u.fetch(SOURCES[src][0].format(z=z, x=x, y=y), 45)
            except urllib.error.HTTPError as ex:
                if ex.code in (403, 429):
                    with self.lock:
                        self.refused[src] = self.refused.get(src, 0) + 1
                        if self.refused[src] >= 40 and src not in self.dead:
                            self.dead[src] = f"HTTP {ex.code} again and again"
                            print(f"\n  ! {src}: the server keeps refusing ({ex.code}) — not using it for the rest of this run")
                    continue
                if ex.code in (400, 404):
                    continue
                return "err"
            except Exception:  # noqa: BLE001
                return "err"
            with self.lock:
                self.refused[src] = 0
            if len(data) < BLANK_BYTES:
                continue
            with self.lock:
                self.used[src] = self.used.get(src, 0) + 1
            return data
        return None


def _run_jobs(u, db, jobs_iter, total, label, fetcher, deadline):
    """Fetch jobs [(z,x,y)] with 6 threads, write from this thread. Returns (ok, miss, err, stopped)."""
    st = {"ok": 0, "miss": 0, "err": 0}
    done, last, pending = 0, time.time(), 0
    q = queue.Queue()

    def work(job):
        z, x, y = job
        for attempt in range(2):
            r = fetcher.get(z, x, y)
            if r != "err":
                break
            time.sleep(2 + 3 * attempt)
        q.put((z, x, y, r))

    stopped = ""
    with cf.ThreadPoolExecutor(6) as ex:
        futs = set()
        for job in jobs_iter:
            futs.add(ex.submit(work, job))
            if len(futs) >= 600:
                cdone, futs = cf.wait(futs, return_when=cf.FIRST_COMPLETED)
            while not q.empty():
                z, x, y, r = q.get()
                done += 1
                if r == "err":
                    st["err"] += 1
                    fetcher.errs_in_a_row += 1
                elif r is None:
                    st["miss"] += 1
                    fetcher.errs_in_a_row = 0
                    db.execute("INSERT OR IGNORE INTO misses VALUES (?,?,?)", (z, x, y))
                else:
                    st["ok"] += 1
                    fetcher.errs_in_a_row = 0
                    db.execute("INSERT OR REPLACE INTO tiles VALUES (?,?,?,?)", (z, x, 2 ** z - 1 - y, sqlite3.Binary(r)))
                pending += 1
            if pending >= 500:
                db.commit(); pending = 0
            if fetcher.errs_in_a_row >= 300:
                stopped = "300 tiles in a row failed - the internet connection dropped?"; break
            if time.time() - last > 15:
                last = time.time()
                print(f"\r  {label}: {done:,}/{total:,} tiles ({st['ok']:,} saved, {st['miss']:,} no imagery, {st['err']:,} errors)   ",
                      end="", flush=True)
                if deadline and time.time() > deadline:
                    stopped = "time limit reached"; break
                if _free_gb(os.path.dirname(db_path(db))) < FREE_GB_STOP:
                    stopped = f"less than {FREE_GB_STOP} GB free on the drive"; break
                if len(fetcher.dead) == len(SOURCES):
                    stopped = "every imagery server refused"; break
        cf.wait(futs)
    while not q.empty():
        z, x, y, r = q.get()
        done += 1
        if r == "err":
            st["err"] += 1
        elif r is None:
            st["miss"] += 1
            db.execute("INSERT OR IGNORE INTO misses VALUES (?,?,?)", (z, x, y))
        else:
            st["ok"] += 1
            db.execute("INSERT OR REPLACE INTO tiles VALUES (?,?,?,?)", (z, x, 2 ** z - 1 - y, sqlite3.Binary(r)))
    db.commit()
    print(f"\r  {label}: {done:,}/{total:,} tiles ({st['ok']:,} saved, {st['miss']:,} no imagery, {st['err']:,} errors)   ")
    return st, stopped


def db_path(db):
    return db.execute("PRAGMA database_list").fetchone()[2]


def _region_jobs(db, z):
    cols = region_tiles(z)
    total = sum(b - a + 1 for rs in cols.values() for a, b in rs)

    def gen():
        for x in sorted(cols):
            have = _have_col(db, z, x)
            for a, b in cols[x]:
                for y in range(a, b + 1):
                    if y not in have:
                        yield (z, x, y)
    return gen(), total


def _set_jobs(db, z, xy):
    by = {}
    for x, y in xy:
        by.setdefault(x, []).append(y)

    def gen():
        for x in sorted(by):
            have = _have_col(db, z, x)
            for y in sorted(by[x]):
                if y not in have:
                    yield (z, x, y)
    return gen(), len(xy)


def estimate(level, routes=(), home=None):
    """-> (tiles, GB) for a level, for the menu."""
    n, gb = 0, 0.0
    for band in LEVEL_BANDS[level]:
        if band == "corridors":
            for z, s in corridor_tiles(routes, home).items():
                n += len(s); gb += len(s) * KB_PER_TILE[z] / 1e6
            continue
        _, a, b = next(x for x in BANDS if x[0] == band)
        for z in range(a, b + 1):
            c = sum(bb - aa + 1 for rs in region_tiles(z).values() for aa, bb in rs)
            n += c; gb += c * KB_PER_TILE[z] / 1e6
    return n, gb


def download(u, dest, level=2, hours=0, routes=None, home=None):
    """Download imagery for the chosen level (1-4). Resumable: tiles already saved are skipped."""
    import routes_data
    routes = routes_data.ROUTES if routes is None else routes
    home = home or getattr(routes_data, "HOME", None)
    if home and not (home.get("lat") or home.get("lon")):
        home = None                      # public edition placeholder (0, 0)
    level = max(1, min(4, int(level or 2)))
    n, gb = estimate(level, routes, home)
    u.say(f"Satellite imagery, Eastern US + Canada — level {level}: up to {n:,} tiles, about {gb:.0f} GB when complete")
    print("  Saved as it goes; stop any time (close the window) and run it again to continue where it left off.")
    os.makedirs(folder(dest), exist_ok=True)
    deadline = time.time() + hours * 3600 if hours else 0
    fetcher = Fetcher(u, dest)
    why = fetcher.reachable()
    if why:
        print(f"  ! can't reach any imagery server ({why}) — skipped; run it again with internet")
        return
    summary, stopped = [], ""
    for band in LEVEL_BANDS[level]:
        _, a, b = next(x for x in BANDS if x[0] == band)
        db = open_db(os.path.join(folder(dest), f"{band}.mbtiles"), band, a, b)
        try:
            if band == "corridors":
                for z, xy in sorted(corridor_tiles(routes, home).items()):
                    jobs, total = _set_jobs(db, z, xy)
                    st, stopped = _run_jobs(u, db, jobs, total, f"Routes + home, zoom {z}", fetcher, deadline)
                    summary.append((f"routes z{z}", st))
                    if stopped:
                        break
            else:
                for z in range(a, b + 1):
                    jobs, total = _region_jobs(db, z)
                    st, stopped = _run_jobs(u, db, jobs, total, f"Whole region, zoom {z}", fetcher, deadline)
                    summary.append((f"region z{z}", st))
                    if stopped:
                        break
        finally:
            db.close()
        if stopped:
            print(f"  Stopped: {stopped}. Run it again to continue.")
            break
    write_info(dest)
    _report(dest, level, summary, fetcher, stopped)


def write_info(dest):
    """tiles/imagery/info.json for the map page: the zoom range across all files + the old NAIP folder."""
    zs, files = [], []
    for p in sorted(glob.glob(os.path.join(folder(dest), "*.mbtiles"))):
        try:
            db = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
            r = db.execute("SELECT MIN(zoom_level), MAX(zoom_level), COUNT(*) FROM tiles").fetchone()
            db.close()
        except sqlite3.Error:
            continue
        if r and r[2]:
            zs += [r[0], r[1]]
            files.append({"file": os.path.basename(p), "minzoom": r[0], "maxzoom": r[1], "tiles": r[2]})
    try:
        sat = json.load(open(os.path.join(dest, "www", "tiles", "satellite", "info.json")))
        zs += [sat["minzoom"], sat["maxzoom"]]
    except (OSError, ValueError, KeyError):
        pass
    if not files:
        return
    os.makedirs(folder(dest), exist_ok=True)
    json.dump({"minzoom": min(zs), "maxzoom": max(zs), "files": files, "updated": time.strftime("%Y-%m-%d"),
               "attribution": "USGS NAIP · Geospatial Ontario · Esri World Imagery (Maxar, Earthstar)"},
              open(os.path.join(folder(dest), "info.json"), "w"))


def _report(dest, level, summary, fetcher, stopped):
    rep = os.path.join(dest, "REPORTS")
    os.makedirs(rep, exist_ok=True)
    lines = [f"Satellite imagery — {time.strftime('%Y-%m-%d %H:%M')} — level {level}" + (f" — stopped: {stopped}" if stopped else ""), ""]
    for name, st in summary:
        lines.append(f"  {name:<14} {st['ok']:>10,} saved  {st['miss']:>9,} no imagery  {st['err']:>7,} errors")
    lines += ["", "Tiles by source this run: " + ", ".join(f"{k} {v:,}" for k, v in fetcher.used.items()), ""]
    for p in sorted(glob.glob(os.path.join(folder(dest), "*.mbtiles"))):
        lines.append(f"  {os.path.basename(p):<20} {os.path.getsize(p) / 1e9:6.1f} GB")
    rp = os.path.join(rep, "SATELLITE-IMAGERY.txt")
    try:
        old = open(rp, encoding="utf-8").read().split("\n\n=====\n\n")[:19]
    except OSError:
        old = []
    with open(rp, "w", encoding="utf-8") as fh:              # newest run first, last 20 runs kept
        fh.write("\n\n=====\n\n".join(["\n".join(lines)] + old))
    nf = os.path.join(rep, "NOT-FETCHED-IMAGERY.txt")
    if fetcher.dead:
        with open(nf, "w", encoding="utf-8") as fh:
            fh.write("Imagery servers that refused this run (not worked around):\n")
            for src, why in fetcher.dead.items():
                fh.write(f"  {src}: {why} — {SOURCES[src][0].split('/tile/')[0]}\n")
    elif os.path.exists(nf) and fetcher.used:
        os.remove(nf)


# --------------------------------------------------------------------------- reading tiles back (server, phone packs, map sheets)
class Reader:
    """Look up a tile in every imagery file, then the older NAIP folder (tiles/satellite)."""

    def __init__(self, dest):
        self.dest = dest
        self.dbs = []
        for p in sorted(glob.glob(os.path.join(folder(dest), "*.mbtiles")), key=lambda p: ("overview" in p, p)):
            try:
                self.dbs.append(sqlite3.connect(f"file:{p}?mode=ro", uri=True, check_same_thread=False))
            except sqlite3.Error:
                pass
        self.naip = os.path.join(dest, "www", "tiles", "satellite")

    def get(self, z, x, y):
        f = os.path.join(self.naip, str(z), str(x), f"{y}.png")      # the older high-detail NAIP cache wins where it exists
        if z >= 15 and os.path.exists(f):
            return open(f, "rb").read()
        for db in self.dbs:
            try:
                r = db.execute("SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
                               (z, x, 2 ** z - 1 - y)).fetchone()
            except sqlite3.Error:
                continue
            if r:
                return bytes(r[0])
        if os.path.exists(f):
            return open(f, "rb").read()
        return None

    def has_any(self):
        for db in self.dbs:
            try:
                if db.execute("SELECT 1 FROM tiles LIMIT 1").fetchone():
                    return True
            except sqlite3.Error:
                pass
        return os.path.isdir(self.naip) and any(os.scandir(self.naip))

    def close(self):
        for db in self.dbs:
            db.close()


# --------------------------------------------------------------------------- phone packs (OsmAnd .sqlitedb)
def _osmand_db(path, minz, maxz):
    if os.path.exists(path):
        os.remove(path)
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE tiles (x int, y int, z int, s int, image blob, PRIMARY KEY (x, y, z, s))")
    db.execute("CREATE TABLE info (minzoom int, maxzoom int, url text, ellipsoid int, inverted_y int, timecolumn text, "
               "tilenumbering text, expireminutes int, rule text, referer text)")
    db.execute("INSERT INTO info VALUES (?, ?, '', 0, 0, 'no', 'simple', -1, '', '')", (minz, maxz))
    return db


def phone_packs(u, dest, routes=None, home=None):
    """Home + one file per route, as OsmAnd satellite layers (.sqlitedb), from imagery already on the drive."""
    import routes_data
    routes = routes_data.ROUTES if routes is None else routes
    home = home or getattr(routes_data, "HOME", None)
    if home and not (home.get("lat") or home.get("lon")):
        home = None                      # public edition placeholder (0, 0)
    u.say("Satellite imagery for phones (OsmAnd files)")
    rd = Reader(dest)
    out = os.path.join(dest, "www", "phone-apps", "satellite")
    os.makedirs(out, exist_ok=True)
    packs = []
    if home:
        packs.append(("Satellite - Home", [(home["lat"], home["lon"])], {10: 40, 11: 40, 12: 30, 13: 15, 14: 12, 15: 8, 16: 5, 17: 2, 18: 1}))
    for r in routes:
        pts = dense(r["line"], 2.0)
        packs.append((f"Satellite - {r['label'].split(',')[0]} route", pts, {8: 60, 9: 40, 10: 25, 11: 15, 12: 10, 13: 6, 14: 3, 15: 1.5}))
    rows = []
    for name, pts, zr in packs:
        path = os.path.join(out, name + ".sqlitedb")
        db = _osmand_db(path + ".part", min(zr), max(zr))
        n = 0
        for z, miles in sorted(zr.items()):
            for x, y in sorted(near_tiles(pts, miles, z)):
                t = rd.get(z, x, y)
                if t:
                    db.execute("INSERT OR REPLACE INTO tiles VALUES (?,?,?,0,?)", (x, y, z, sqlite3.Binary(t)))
                    n += 1
        db.commit(); db.close()
        if n:
            os.replace(path + ".part", path)
            rows.append((name, n, os.path.getsize(path)))
            print(f"  {name}: {n:,} tiles, {os.path.getsize(path) / 1e6:,.0f} MB")
        else:
            os.remove(path + ".part")
            print(f"  {name}: no imagery on the drive yet — run ADD-SATELLITE-IMAGERY first")
    rd.close()
    _phone_page(dest, rows)
    return rows


def _phone_page(dest, rows):
    out = os.path.join(dest, "www", "phone-apps", "satellite")
    li = "".join(f"<tr><td><a href='{n}.sqlitedb' download>{n}</a></td><td>{c:,}</td><td>{s / 1e6:,.0f} MB</td></tr>" for n, c, s in rows)
    html = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Satellite maps for phones</title><style>body{{font:16px/1.5 system-ui,sans-serif;background:#14171a;color:#e6e8eb;margin:0}}
main{{max-width:760px;margin:auto;padding:16px}}a{{color:#d9a441}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #2c323a;padding:6px}}
.tip{{border-left:3px solid #57ab5a;background:#141d16;padding:8px 12px}}</style></head><body><main>
<p><a href="../">← Phone apps</a></p><h1>Satellite maps for phones</h1>
<p>Aerial imagery of home and each get-home route, made for <b>OsmAnd</b> (its installer is on the Phone apps page). Optional —
only copy what you want on the phone; everything stays on the drive either way.</p>
<table><tr><th>File</th><th>Tiles</th><th>Size</th></tr>{li or "<tr><td colspan=3>None yet — run ADD-SATELLITE-IMAGERY, then MAKE-PHONE-SATELLITE.</td></tr>"}</table>
<h2>Put one on an Android phone</h2><ol>
<li>Download the file above (on the phone, from the drive's Wi-Fi page) or copy it over USB.</li>
<li>Open it with OsmAnd (tap the file, "Open with OsmAnd"), or copy it into <code>Android/data/net.osmand.plus/files/tiles/</code>.</li>
<li>In OsmAnd: Menu → Configure map → Map source → pick the file's name. Works with no signal.</li></ol>
<p class="tip">Locus Map, Guru Maps and QGIS can also open the drive's big <code>tiles/imagery/*.mbtiles</code> files directly.</p>
</main></body></html>"""
    open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(html)
