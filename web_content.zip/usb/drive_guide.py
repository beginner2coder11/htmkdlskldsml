# -*- coding: utf-8 -*-
"""The AI's map of the drive: what is on it and where — read by the AI before every question.

Writes ai/memory/drive-guide.txt (the full guide, also shown on the AI memory page) and www/ask-brief.js
(window.BRIEF: a shorter version that goes at the start of the AI's instructions). Because the brief only changes when
the drive is rebuilt, the AI server reads it once and reuses it, so it costs nothing per question.

    python drive_guide.py --dest E:\\OFFGRID
"""
import argparse, glob, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
BRIEF_MAX = 2400


def _js(p, default):
    try:
        t = open(p, encoding="utf-8").read()
        return json.loads(t[t.index("=") + 1:].split(";\n")[0].rstrip().rstrip(";"))
    except (OSError, ValueError):
        return default


def _sections(dest):
    """[(title, [lines])] — every part of the drive the AI should know about."""
    S = []
    docs = _js(os.path.join(dest, "www", "search", "docs.js"), [])
    cats = {}
    for d in docs:
        if str(d[1]).startswith("zim.html"):
            continue
        cats.setdefault(d[2], []).append(d[0])
    if cats:
        lines = []
        for c, ts in sorted(cats.items(), key=lambda x: -len(x[1])):
            ex = "; ".join(re.sub(r"\s+", " ", t)[:44] for t in ts[:3])
            lines.append(f"{c} ({len(ts)}): {ex}")
        S.append(("Library (Search page / Command Center > Library), by section: documents, examples", lines))
    arch = _js(os.path.join(dest, "www", "archives", "index.js"), [])
    if arch:
        S.append(("Offline archives (Kiwix; Archive contents page)",
                  [f"{a.get('name', a.get('stem'))}: {a.get('listed', 0):,} items listed" for a in arch]))
    try:
        sys.path.insert(0, HERE)
        import situation_packs
        S.append(("TOP 20 SITUATIONS folder (one page each: what to do, what you need, best pages)",
                  ["; ".join(s["t"] for s in situation_packs.TOP20)]))
    except Exception:  # noqa: BLE001
        pass
    maps = []
    w = os.path.join(dest, "www")
    if glob.glob(os.path.join(w, "map", "*.pmtiles")):
        maps.append("street maps (Locator map)")
    if os.path.exists(os.path.join(w, "tiles", "imagery", "info.json")) or os.path.isdir(os.path.join(w, "tiles", "satellite")):
        maps.append("satellite imagery (Eastern US + Canada)")
    if os.path.isdir(os.path.join(w, "tiles", "topo")) or os.path.isdir(os.path.join(w, "topo")):
        maps.append("USGS topo maps")
    if os.path.exists(os.path.join(w, "data", "flood.js")):
        maps.append("FEMA flood zones around home")
    if os.path.exists(os.path.join(w, "data", "fema.js")):
        maps.append("FEMA shelters, open shelters, recovery centers, disaster-declared counties")
    if os.path.exists(os.path.join(w, "data", "corridors", "index.js")):
        maps.append("places along each get-home route (water, hospitals, fuel, shelters)")
    if os.path.isdir(os.path.join(dest, "PRINTABLE MAPS")):
        maps.append("PRINTABLE MAPS folder (route and home sheets)")
    if maps:
        S.append(("Maps and places", ["; ".join(maps)]))
    try:
        import routes_data
        if routes_data.ROUTES:
            S.append(("Get-home routes (survival guides, printable maps)",
                      ["; ".join(f"{r['label']} ({r.get('miles', '?')} mi)" for r in routes_data.ROUTES)]))
    except Exception:  # noqa: BLE001
        pass
    radio = []
    if os.path.isdir(os.path.join(w, "data", "ham")):
        radio.append("US + Canadian ham call-sign lookup (by call, ZIP, town)")
    if glob.glob(os.path.join(dest, "www", "library", "My Radio Programming", "*")):
        radio.append("the family radio channel plan (My Radio Programming)")
    radio.append("repeater and NOAA weather frequencies on the radio pages")
    S.append(("Radio", ["; ".join(radio)]))
    other = ["medicine and poison guides (Medicine page)", "checklists", "Field Notebook (your own notes)",
             "MY-FILES (the family's own documents, searchable)", "GOOGLE-EARTH-READY (layers for Google Earth Pro)",
             "PROGRAMS folder (every tool; START-HERE opens them)"]
    S.append(("Also on the drive", ["; ".join(other)]))
    return S


def build(dest):
    S = _sections(dest)
    full = ["THIS DRIVE (OFFGRID) — what is on it and where", ""]
    for t, lines in S:
        full += [t + ":"] + [" - " + x for x in lines] + [""]
    full.append("When a question asks WHERE something is, name the section/folder/page above. When the excerpts don't cover a "
                "question, say which part of the drive is most likely to have it.")
    txt = "\n".join(full)
    os.makedirs(os.path.join(dest, "ai", "memory"), exist_ok=True)
    with open(os.path.join(dest, "ai", "memory", "drive-guide.txt"), "w", encoding="utf-8") as fh:
        fh.write(txt + "\n")
    # brief: the same, trimmed to fit (library sections cut to the first 18; archives to 12)
    br = ["What is on this drive (name these places when pointing the user somewhere):"]
    for t, lines in sorted(S, key=lambda x: x[0].startswith(("Library", "Offline"))):   # long lists last: trimmed first
        lim = 18 if t.startswith("Library") else 12
        br.append(f"{t.split(' (')[0]}: " + " | ".join(x[:110] if t.startswith(("Library", "Offline")) else x[:420] for x in lines[:lim]))
    brief = "\n".join(br)
    if len(brief) > BRIEF_MAX:
        brief = brief[:BRIEF_MAX].rsplit(" | ", 1)[0] + " | …"
    with open(os.path.join(dest, "www", "ask-brief.js"), "w", encoding="utf-8") as fh:
        fh.write("window.BRIEF=" + json.dumps(brief, ensure_ascii=False) + ";\n")
    return len(txt), len(brief)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    print("guide %d chars, brief %d chars" % build(a.dest))
