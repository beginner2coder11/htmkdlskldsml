@echo off
chcp 65001 >nul
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== OFF-GRID SURVIVAL DRIVE - monthly update =====
REM Run this from the drive about once a month while you have internet. It downloads newer versions of
REM the archives (Wikipedia, WikEM...), AI programs, phone apps, OsmAnd maps and USGS topo maps, refreshes
REM nearby places and flood data when they are old, retries anything missing, then checks the drive.
REM Finished files are kept; old versions are removed only after the new one has fully downloaded.
cd /d "%~dp0"
title OFF-GRID DRIVE UPDATE
if not exist tools\python-win\python.exe (
  echo  Portable Python is missing - run BUILD-USB-WINDOWS.bat from the offgrid folder on your laptop instead.
  pause & exit /b 1
)
if not exist tools\builder\usb\usb_builder.py (
  echo  The builder copy is missing - run BUILD-USB-WINDOWS.bat from the offgrid folder on your laptop once.
  pause & exit /b 1
)
echo.
echo  Updating the drive in %~dp0
echo  Close the drive's START-WINDOWS.bat window first if it is open.
echo  This can take from a few minutes to many hours (new Wikipedia versions are about 110 GB).
echo  You can stop at any time (close this window) and run it again later - it picks up where it left off.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\update_drive.ps1" %*
echo.
echo  Done. See REPORTS\UPDATE-LOG.txt and REPORTS\CHECK-REPORT.txt.
pause
