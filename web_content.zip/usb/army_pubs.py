"""US Army (armypubs.army.mil) and Marine Corps (MCPEL) publications.

Army: crawls the publication lists (FM, ADP, ATP, STP, TC, strategic documents and the TM series), opens each
record and keeps only the manuals that have a public PDF (many equipment TMs are login-only and are skipped).
The record -> PDF map is cached in tools\\armypubs-index.json, so re-runs only fetch what is new or missing.
Marines: crawls marines.mil/News/Publications/MCPEL, keeps every publication PDF except the MCO (orders) series.

Files go to www\\library\\<Category>\\ (one folder level, so the drive's full-text search indexes them).
Run any time you have internet:  python army_pubs.py --dest E:\\OFFGRID --collections FM,ADP --marines
"""
import argparse, concurrent.futures as cf, html as _html, json, os, re, sys, threading, time, urllib.error, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

BASE = "https://armypubs.army.mil/ProductMaps/PubForm/"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
      "Accept": "text/html,application/xhtml+xml,application/pdf,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.9",
      "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "none", "Upgrade-Insecure-Requests": "1"}

# key -> (page, library folder, label)
COLLECTIONS = {
    "FM": ("FM.aspx", "Army - Field Manuals (FM)", "Field Manuals"),
    "ADP": ("ADP.aspx", "Army - Doctrine (ADP-ATP-STP-TC)", "Army Doctrine Publications"),
    "ATP": ("ATP.aspx", "Army - Doctrine (ADP-ATP-STP-TC)", "Army Techniques Publications"),
    "STP": ("STP.aspx", "Army - Soldier Training (STP-TC)", "Soldier Training Publications"),
    "TC": ("TC.aspx", "Army - Soldier Training (STP-TC)", "Training Circulars"),
    "STRAT": ("StrategicDocuments.aspx", "Army - Doctrine (ADP-ATP-STP-TC)", "Strategic Documents"),
    "TM_CAL": ("TM_Cal.aspx", "Army - Technical Manuals (TM)", "TM calibration"),
    "TM_ADMIN": ("TM_Admin.aspx", "Army - Technical Manuals (TM)", "TM administrative"),
    "TM_1_8": ("TM_1_8.aspx", "Army - Technical Manuals (TM)", "TM 1 to 8 series"),
    "TM_10": ("TM_10.aspx", "Army - Technical Manuals (TM)", "TM 10 series (supply, food, fuel, water)"),
    "TM_9": ("TM_9.aspx", "Army - Technical Manuals (TM)", "TM 9 series (weapons, vehicles, ammunition)"),
    "NEW": ("../../News/NewReleases.aspx", "Army - New Releases", "New releases"),
}
BY_PROFILE = {   # collections each drive size keeps
    "micro": [],
    "small": [],
    "medium": ["FM", "ADP", "ATP", "STP", "TC", "STRAT", "TM_CAL"],
    "large": ["FM", "ADP", "ATP", "STP", "TC", "STRAT", "TM_CAL", "TM_ADMIN", "TM_10", "TM_1_8"],
    "full": list(COLLECTIONS),
}
RUN_GB = {"medium": 8, "large": 40, "full": 120}   # new downloads per run; re-run to continue
CRAWL_SEC = 2400                                    # record look-ups per run (cached, so later runs go faster)
MARINE_PROFILES = ("medium", "large", "full")
MARINE_ROOT = "https://www.marines.mil/News/Publications/MCPEL/"
MARINE_DIR = "Marine Corps Publications (no MCO)"
_lock = threading.Lock()


def _save(index, path):
    with _lock:
        snap = dict(index)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(snap, fh)


def _curl(url, out=None, timeout=90):
    """Windows 10+ ships curl.exe (Schannel TLS); sites that block Python's TLS often let it through."""
    import shutil
    import subprocess
    exe = shutil.which("curl.exe") or shutil.which("curl")
    if not exe:
        return None
    cmd = [exe, "-sSL", "--max-time", str(timeout), "-A", UA["User-Agent"], "-H", "Accept-Language: en-US,en;q=0.9",
           "-H", "Accept: text/html,application/xhtml+xml,application/pdf,*/*;q=0.8", "-e", url.split("/News/")[0] + "/"]
    if out:
        cmd += ["-C", "-", "-o", out]
    cmd.append(url)
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout + 30)
    except Exception:  # noqa: BLE001
        return None
    return r.stdout if r.returncode == 0 else None


def _get(url, timeout=60, binary=False):
    last = None
    for i in range(3):
        try:
            data = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout).read()
            return data if binary else data.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (403, 404):
                break
        except Exception as e:  # noqa: BLE001
            last = e
        time.sleep(2 + 3 * i)
    if getattr(last, "code", 0) == 403:
        for alt in (url, "https://web.archive.org/web/2024id_/" + url):
            data = _curl(alt, timeout=timeout)
            if data and len(data) > 500:
                return data if binary else data.decode("utf-8", "replace")
    raise last


def _safe(s, n=110):
    s = _html.unescape(s or "").replace("`", "'")
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", re.sub(r"\s+", " ", s)).strip(" .")[:n] or "item"


def _p(msg):
    enc = sys.stdout.encoding or "ascii"
    print(str(msg).encode(enc, "replace").decode(enc), flush=True)


def _fetch_file(url, out):
    """Download url -> out (resumable .part). Returns bytes written, or 0 on failure."""
    part = out + ".part"
    have = os.path.getsize(part) if os.path.exists(part) else 0
    h = dict(UA)
    if have:
        h["Range"] = f"bytes={have}-"
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=90)
        mode = "ab" if have and r.status == 206 else "wb"
        with open(part, mode) as f:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                f.write(b)
        size = os.path.getsize(part)
        if size < 1000:
            os.remove(part)
            return 0
        os.replace(part, out)
        return size
    except Exception:  # noqa: BLE001
        pass
    _curl(url, part, 180)
    try:
        if os.path.getsize(part) > 1000:
            os.replace(part, out)
            return os.path.getsize(out)
        os.remove(part)
    except OSError:
        pass
    return 0


def _load(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _rows(page_html):
    rows = []
    for m in re.finditer(r'href="(?:\.\./PubForm/|/ProductMaps/PubForm/)?(Details\.aspx\?PUB_ID=(\d+))"[^>]*>([^<]+)</a>\s*</td>'
                         r'<td[^>]*>[^<]*</td><td[^>]*>([^<]*)</td><td[^>]*>([^<]*)</td>', page_html):
        rows.append({"id": m.group(2), "n": _html.unescape(m.group(3)).strip(), "d": m.group(4).strip(),
                     "t": _html.unescape(m.group(5)).strip()})
    if not rows:   # other layouts: at least the record links
        for m in re.finditer(r'Details\.aspx\?PUB_ID=(\d+)"[^>]*>([^<]+)</a>', page_html):
            rows.append({"id": m.group(1), "n": _html.unescape(m.group(2)).strip(), "d": "", "t": ""})
    seen, out = set(), []
    for r in rows:
        if r["id"] not in seen:
            seen.add(r["id"])
            out.append(r)
    return out


def _record_pdfs(pub_id):
    d = _get(f"{BASE}Details.aspx?PUB_ID={pub_id}", 60)
    i = d.find("tblContainer1")
    t = d[i:d.find("</table>", i)] if i >= 0 else d
    urls = []
    for h in re.findall(r"href=['\"]([^'\"]+)['\"]", t):
        h = h.strip()
        if h.lower().split("?")[0].endswith(".pdf") and "/epubs/" in h and "MISC_CAC" not in h and "_CAC" not in h:
            urls.append(urllib.parse.urljoin(BASE + "Details.aspx", h))
    return list(dict.fromkeys(urls))


def army(dest, keys, run_gb, workers=3):
    root = os.path.join(dest, "www", "library")
    idx_path = os.path.join(dest, "tools", "armypubs-index.json")
    os.makedirs(os.path.dirname(idx_path), exist_ok=True)
    index = _load(idx_path)
    fail_path = os.path.join(dest, "tools", "armypubs-fails.json")       # url -> times it failed; after 3 it is listed, not retried every run
    fails = _load(fail_path)
    t0 = time.time()
    budget = run_gb * 1e9
    got = 0
    try:
        import reports
        os.remove(reports.not_fetched(dest, "Army"))      # rewritten below from this run
    except OSError:
        pass
    for key in keys:
        page, folder, label = COLLECTIONS[key]
        print(f"\n==> {label if label.startswith('Army') else 'Army ' + label}", flush=True)
        try:
            rows = _rows(_get(urllib.parse.urljoin(BASE, page), 180))
        except Exception as e:  # noqa: BLE001
            print(f"  ! list unavailable: {e}")
            continue
        todo = [r for r in rows if r["id"] not in index or (r["d"] and index[r["id"]].get("d") != r["d"])]
        print(f"  {len(rows)} publications listed" + (f", {len(todo)} new to look up" if todo else ""), flush=True)

        def look(r):
            if time.time() - t0 > CRAWL_SEC:
                return
            try:
                urls = _record_pdfs(r["id"])
            except Exception:  # noqa: BLE001
                return
            with _lock:
                index[r["id"]] = {"n": r["n"], "t": r["t"], "d": r["d"], "u": urls}

        with cf.ThreadPoolExecutor(workers) as ex:
            for k, _ in enumerate(ex.map(look, todo), 1):
                if k % 200 == 0:
                    print(f"  checked {k}/{len(todo)}", flush=True)
                    _save(index, idx_path)
        _save(index, idx_path)
        if time.time() - t0 > CRAWL_SEC:
            print("  time budget reached for record look-ups — re-run to continue.")
        avail = [r for r in rows if index.get(r["id"], {}).get("u")]
        print(f"  {len(avail)} of {len(rows)} have a public PDF", flush=True)
        outdir = os.path.join(root, folder)
        os.makedirs(outdir, exist_ok=True)
        jobs, gave_up = [], []
        try:                                         # the same publication may already be here from FAS or your own files
            import fas_doddir
            have = fas_doddir.have_keys(dest)
        except Exception:  # noqa: BLE001
            fas_doddir, have = None, set()
        for r in avail:
            us = index[r["id"]]["u"]
            for n, u_ in enumerate(us):
                name = _safe(f"{r['n']} {r['t']}") + (f" (part {n + 1})" if len(us) > 1 else "") + ".pdf"
                out = os.path.join(outdir, name)
                if not (os.path.exists(out) and os.path.getsize(out) > 1000):
                    if fails.get(u_, 0) >= 3:
                        if fas_doddir and fas_doddir.pub_key(r["n"]) in have:
                            continue                 # refused here, but the drive already has it from another source
                        gave_up.append((out, u_))
                    else:
                        jobs.append((u_, out))
        print(f"  {len(jobs)} to download" + (f"; {len(gave_up)} the Army site refused 3 times (not retried; listed in REPORTS\\NOT-FETCHED-Army.txt)"
              if gave_up else ""), flush=True)
        done = 0
        stop = False

        def dl(j):
            nonlocal got, stop
            if stop:
                return
            n = _fetch_file(*j)
            with _lock:
                if n:
                    fails.pop(j[0], None)
                else:
                    fails[j[0]] = fails.get(j[0], 0) + 1
                got += n
                if got > budget:
                    stop = True
            return n

        with cf.ThreadPoolExecutor(workers) as ex:
            for n in ex.map(dl, jobs):
                done += 1
                if done % 50 == 0:
                    print(f"  downloaded {done}/{len(jobs)}  ({got / 1e9:.1f} GB this run)", flush=True)
        _save(fails, fail_path)
        stuck = [(os.path.basename(o), u_) for o, u_ in gave_up] + [(os.path.basename(o), u_) for u_, o in jobs if fails.get(u_, 0) >= 3]
        if stuck:
            try:
                import reports
                rp = reports.not_fetched(dest, "Army")
                with open(rp, "a", encoding="utf-8") as fh:
                    fh.write(f"== {label}: listed as public but the site would not serve these after 3 tries (retried only if you delete tools\\armypubs-fails.json)\n")
                    fh.writelines(f"  {n_}\n    {u_}\n" for n_, u_ in stuck)
                if len(stuck) > len(gave_up):
                    print(f"  {len(stuck) - len(gave_up)} more could not be downloaded - listed in REPORTS\\NOT-FETCHED-Army.txt")
            except Exception:  # noqa: BLE001
                pass
        if stop:
            print(f"  run size limit ({run_gb} GB) reached — re-run later to continue.")
            return got
    return got


_PDF_RE = re.compile(r'href="([^"]+\.pdf[^"]*)"', re.I)
_ART_RE = re.compile(r'href="([^"]*/Electronic-Library-Display/Article/\d+[^"]*)"', re.I)


def marines(dest, max_pages=60):
    folder = os.path.join(dest, "www", "library", MARINE_DIR)
    os.makedirs(folder, exist_ok=True)
    print("\n==> Marine Corps publications (MCPEL, MCOs excluded)", flush=True)
    pdfs, arts = {}, {}
    for pg in range(1, max_pages + 1):
        try:
            s = _get(MARINE_ROOT + (f"?Page={pg}" if pg > 1 else ""), 60)
        except Exception as e:  # noqa: BLE001
            if pg == 1:
                print(f"  ! marines.mil did not answer ({e}). It blocks some networks/automation — try again from a "
                      "different connection, or save the PDFs by hand into the folder below:\n  " + folder)
                return 0
            break
        new = 0
        for h in _PDF_RE.findall(s):
            u_ = urllib.parse.urljoin(MARINE_ROOT, _html.unescape(h))
            if u_ not in pdfs:
                pdfs[u_] = ""
                new += 1
        for h in _ART_RE.findall(s):
            u_ = urllib.parse.urljoin(MARINE_ROOT, _html.unescape(h))
            if u_ not in arts:
                arts[u_] = ""
                new += 1
        if not new:
            break
    for a in list(arts)[:4000]:   # article pages hold the actual PDF link
        try:
            s = _get(a, 60)
        except Exception:  # noqa: BLE001
            continue
        for h in _PDF_RE.findall(s):
            pdfs.setdefault(urllib.parse.urljoin(a, _html.unescape(h)), "")
    n_new = 0
    for u_ in pdfs:
        name = urllib.parse.unquote(u_.split("?")[0].rsplit("/", 1)[-1])
        if re.match(r"(?i)^(mco|marine corps order)[ _%0-9-]", name) or re.match(r"(?i)^mco\b", name):
            continue
        out = os.path.join(folder, _safe(name, 150))
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            continue
        if _fetch_file(u_, out):
            n_new += 1
    print(f"  {n_new} new Marine Corps publication(s); {len([f for f in os.listdir(folder) if f.lower().endswith('.pdf')])} on the drive")
    return n_new


def build(u, dest, profile="large", collections="", marine=True):
    keys = BY_PROFILE.get(profile, []) if not collections or collections == "auto" else \
        (list(COLLECTIONS) if collections == "all" else [] if collections == "none" else
         [c.strip().upper() for c in collections.split(",") if c.strip().upper() in COLLECTIONS])
    if keys:
        u.say("US Army publications (armypubs.army.mil)")
        army(dest, keys, RUN_GB.get(profile, 40))
    if marine and profile in MARINE_PROFILES:
        u.say("US Marine Corps publications (MCPEL)")
        marines(dest)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--profile", default="full")
    ap.add_argument("--collections", default="", help="auto | all | none | comma list of " + ",".join(COLLECTIONS))
    ap.add_argument("--marines", action="store_true", help="also fetch Marine Corps publications")
    ap.add_argument("--gb", type=float, default=0, help="max new downloads this run (GB)")
    a = ap.parse_args()
    import usb_builder as u
    keys = BY_PROFILE[a.profile] if a.collections in ("", "auto") else \
        list(COLLECTIONS) if a.collections == "all" else \
        [c.strip().upper() for c in a.collections.split(",") if c.strip().upper() in COLLECTIONS]
    if keys:
        army(a.dest, keys, a.gb or RUN_GB.get(a.profile, 40))
    if a.marines:
        marines(a.dest)


if __name__ == "__main__":
    main()
