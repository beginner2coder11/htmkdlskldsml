@echo off
REM Download ONLY the USGS aerial/satellite imagery (NAIP, ~0.6-1 m) for your key areas:
REM home, the get-home routes and destinations, and the bases/cities/lakes your topo already covers.
REM This is LARGE (likely 150 GB+) and can take many hours. It's resumable - re-run anytime to continue.
REM Optional: pass the drive letter, e.g.  ADD-SATELLITE-IMAGERY-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
echo.
echo  Adding USGS aerial/satellite imagery to %DRIVE%:\OFFGRID  (nothing else will download)
echo  This is a big download (150 GB+). You can close this and re-run it anytime to continue.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --satellite-only
pause
