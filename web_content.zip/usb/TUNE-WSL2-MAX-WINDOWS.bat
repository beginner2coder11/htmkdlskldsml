@echo off
REM Gives WSL2 (NOMAD) nearly all of this PC's RAM, all CPU cores and a big swap file. Safe to re-run.
REM   TUNE-WSL2-MAX-WINDOWS.bat            apply
REM   TUNE-WSL2-MAX-WINDOWS.bat -FreeUp    apply, and offer to close big apps first
REM   TUNE-WSL2-MAX-WINDOWS.bat -Restore   go back to the Windows defaults
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0wsl_max.ps1" %*
pause
