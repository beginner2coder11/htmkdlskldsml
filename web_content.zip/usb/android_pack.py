"""PLATFORMS\\ANDROID - everything an Android phone needs, in one folder, with plain instructions.

Why this exists: on Android, tapping an .html file in the Files app opens it WITHOUT its neighbours
(scripts, data, other pages), so most pages on the drive come up blank or with dead links. Pages only work
properly when something serves the drive as a website. This pack gives three ways to do that, plus
single-file copies of the pages that can work with no helper at all.

Creates, inside the drive folder:
    PLATFORMS/ANDROID/START-HERE-ANDROID.html   the instructions (one self-contained file; also .txt)
    PLATFORMS/ANDROID/START-HERE-ANDROID.txt
    PLATFORMS/ANDROID/offgrid-termux.sh         one script: finds the drive, sets up, starts everything
    PLATFORMS/ANDROID/app-source/               the app's source code (build it with GitHub Actions)
    PLATFORMS/ANDROID/apk/                      the OFFGRID Command Center app (.apk) if you have built it
    PLATFORMS/ANDROID/single-file-pages/        calculators, declination ... each one a single file that works
                                                when tapped in Files (no server needed)

    python android_pack.py --dest E:\\OFFGRID
"""
import argparse
import glob
import html
import os
import re
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join("PLATFORMS", "ANDROID")
# pages that work standalone once their scripts are folded in (no links to sibling files needed)
STANDALONE = [("converter.html", "Unit converter"), ("calculators.html", "Calculators"), ("declination.html", "Compass declination")]


def _read(p):
    with open(p, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def inline_page(src_html, base_dir):
    """Fold <script src> and <link rel=stylesheet href> into the page so it is one file."""
    text = _read(src_html)

    def script(m):
        p = os.path.join(base_dir, m.group(1))
        if not os.path.isfile(p):
            return m.group(0)
        return "<script>" + _read(p).replace("</script", "<\\/script") + "</script>"

    def css(m):
        p = os.path.join(base_dir, m.group(1))
        return "<style>" + _read(p) + "</style>" if os.path.isfile(p) else m.group(0)

    text = re.sub(r"""<script[^>]*\ssrc=["']([^"']+)["'][^>]*>\s*</script>""", script, text)
    text = re.sub(r"""<link[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>""", css, text)
    return text


STEPS_TXT = """OFFGRID DRIVE ON ANDROID - START HERE
=====================================

THE ONE THING TO KNOW
Tapping an .html file in the Files app opens it alone, without the scripts and
data beside it, so most pages show blank or have dead links. That is not a
broken drive. Pages need to be served like a website. Pick ONE way below.

BEFORE ANYTHING: THE DRIVE MUST BE exFAT
Android cannot read NTFS (the usual format of big drives). Use a drive or SD
card formatted exFAT. On the PC, COPY-TO-ANOTHER-DRIVE, choose "Android".

WAY 1 (EASIEST): THE OFFGRID COMMAND CENTER APP
 1. Install apk\\offgrid-commandcenter.apk (tap it; allow "install unknown apps").
 2. Plug the drive in (USB-C or OTG adapter).
 3. Open the app, tap "Choose OFFGRID folder", pick the OFFGRID folder, tap Use.
 4. Done. Next time: plug in, open the app. Tabs: Home, Library, Places, Notebook, More.
It reads straight from the drive and copies no library files onto the phone. Your notes are kept inside the app
(use Export on the Notes tab to copy them out; uninstalling the app deletes them). The app has no internet permission.
(If apk\\ is empty the app has not been added yet: its source is in app-source\\ and has to be built first - see
app-source\\README.txt - or use Way 2 or 3.)

WAY 2: TERMUX (works on most phones, needs a one-time setup)
 1. Install Termux (apk on the drive: www/phone-apps/android).
 2. Open Termux and paste this ONE line, then press Enter:
      sh $(ls -d /storage/*/OFFGRID/PLATFORMS/ANDROID/offgrid-termux.sh | head -1)
 3. Answer Y to the questions. The browser opens on the drive's home page.
 4. Next time just open Termux and type:  offgrid
 5. One tap: install the free Termux:Widget app (F-Droid), add its widget to the home
    screen, and pick OFFGRID. A tap starts everything and opens the Command Center.
    (Android does not let a file or web page start Termux by itself, so this
    one-time widget is the closest to a single tap.)
If it says it cannot read the drive: newer Android versions block Termux from
USB drives. Use Way 1, or let the script copy the small pages to the phone
(it offers this).

NOTEBOOK YOU CAN WRITE IN: install apk\\Tiddloid-2.5.4.apk, open Tiddloid, tap + and open FIELD-NOTEBOOK.html from the
drive. Situations with tick boxes, rally points, radio log and supplies save inside the file.

WAY 3: NO HELPER (limited)
 - PDFs: tap them in Files; they open in your PDF reader.
 - Wikipedia and other archives: Kiwix app -> Open file -> kiwix/zim.
 - Maps: OsmAnd / Organic Maps (see www/phone-apps).
 - Movies and music: VLC.
 - single-file-pages\\ : converter, calculators and declination work with a single tap.
Search, the home page and maps need Way 1 or 2.

IF SOMETHING GOES WRONG
 - Blank page / dead links: you tapped it in Files. Use Way 1 or 2.
 - Drive not shown: it is NTFS. Re-copy to exFAT.
 - Maps blank in Way 2: wait 10 seconds and reload; keep Termux open.
 - Video will not play: open it in VLC (Share -> VLC).
 - PDF will not open: install a PDF reader (apk in www/phone-apps/android).
 - Termux closed by Android: Settings -> Battery -> Termux -> Unrestricted.

BEFORE YOU GO OFF-GRID (needs internet, once)
 Install the apps from www/phone-apps/android: Kiwix, OsmAnd, VLC, a PDF
 reader, Termux. Keep a power bank. Airplane mode saves battery.
"""


def _html():
    body = html.escape(STEPS_TXT)
    return f"""<!doctype html><html lang=en><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>OFFGRID on Android - start here</title>
<style>body{{font:17px/1.55 system-ui,sans-serif;margin:0;padding:1rem;background:#f6f4ee;color:#1b1b1b}}
h1{{font-size:1.4rem;margin:.2rem 0 1rem}}pre{{white-space:pre-wrap;word-wrap:break-word;font:15px/1.5 ui-monospace,monospace;
background:#fff;border:1px solid #ccc;border-radius:8px;padding:1rem}}.top{{background:#b04a2f;color:#fff;padding:.8rem 1rem;border-radius:8px;margin-bottom:1rem}}</style>
<div class=top><b>Page shows blank or links are dead?</b> You opened it by tapping it in Files. Follow Way 1 or Way 2 below - it takes two minutes.</div>
<h1>OFFGRID drive on Android</h1><pre>{body}</pre></html>"""


TERMUX_SH = r"""#!/bin/sh
# ===== OFFGRID drive on Android (Termux): finds the drive, sets up, starts everything. =====
# First time:   sh $(ls -d /storage/*/OFFGRID/PLATFORMS/ANDROID/offgrid-termux.sh | head -1)
# After that:   offgrid
SELF="$0"
find_root() {
  for d in /storage/*/OFFGRID "$HOME"/storage/external-1/OFFGRID /sdcard/OFFGRID "$HOME"/OFFGRID; do
    [ -f "$d/www/home.html" ] && { echo "$d"; return 0; }
  done
  return 1
}
ROOT=$(find_root)
if [ -z "$ROOT" ]; then
  echo "Can't see the OFFGRID folder."
  echo " - Is the drive plugged in and exFAT (not NTFS)?"
  echo " - Run  termux-setup-storage  once and allow access, then try again."
  echo " - Newer Android blocks Termux from USB drives: use the OFFGRID Command Center app instead."
  exit 1
fi
echo "OFFGRID found: $ROOT"
# one-time: the short command
mkdir -p "$HOME/bin" 2>/dev/null
if [ ! -f "$HOME/bin/offgrid" ]; then
  printf '#!/bin/sh\nexec sh "$(ls -d /storage/*/OFFGRID/PLATFORMS/ANDROID/offgrid-termux.sh "$HOME"/OFFGRID/PLATFORMS/ANDROID/offgrid-termux.sh 2>/dev/null | head -1)"\n' > "$HOME/bin/offgrid"
  chmod +x "$HOME/bin/offgrid" 2>/dev/null
  grep -q 'HOME/bin' "$HOME/.profile" 2>/dev/null || echo 'export PATH="$HOME/bin:$PATH"' >> "$HOME/.profile"
  echo "Next time just type:  offgrid"
fi
# one-tap home-screen button (needs the free Termux:Widget app from F-Droid; harmless if it is not installed)
if [ ! -f "$HOME/.shortcuts/OFFGRID" ]; then
  mkdir -p "$HOME/.shortcuts" 2>/dev/null
  printf '#!/bin/sh\nexec "$HOME/bin/offgrid"\n' > "$HOME/.shortcuts/OFFGRID" 2>/dev/null && chmod +x "$HOME/.shortcuts/OFFGRID" 2>/dev/null
  echo "Home-screen button ready: add the Termux:Widget widget and pick OFFGRID."
fi
if [ -f "$ROOT/PROGRAMS/start-android-termux.sh" ]; then
  exec sh "$ROOT/PROGRAMS/start-android-termux.sh"
fi
echo "PROGRAMS/start-android-termux.sh is missing - run the drive's Check/Update."
exit 1
"""


def build(u, dest):
    out = os.path.join(dest, OUT)
    os.makedirs(os.path.join(out, "apk"), exist_ok=True)
    with open(os.path.join(out, "START-HERE-ANDROID.txt"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(STEPS_TXT)
    with open(os.path.join(out, "START-HERE-ANDROID.html"), "w", encoding="utf-8") as fh:
        fh.write(_html())
    with open(os.path.join(out, "offgrid-termux.sh"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(TERMUX_SH)
    # the Command Center app, if it has been built and put next to the builder (apk\*.apk)
    n_apk = 0
    for p in glob.glob(os.path.join(HERE, "apk", "*.apk")) + glob.glob(os.path.join(HERE, "offgrid-commandcenter*.apk")):
        shutil.copy2(p, os.path.join(out, "apk", "offgrid-commandcenter.apk" if "commandcenter" in p.lower() else os.path.basename(p)))
        n_apk += 1
    with open(os.path.join(out, "apk", "README.txt"), "w", encoding="utf-8") as fh:
        fh.write("Put offgrid-commandcenter.apk here (the builder copies it from its own apk folder).\n"
                 "Tap it on the phone to install. See ../START-HERE-ANDROID.html, Way 1.\n")
    # source of the app (Kotlin project; has to be built into an .apk with GitHub Actions)
    srcdir = os.path.join(out, "app-source")
    for z in glob.glob(os.path.join(HERE, "android-app", "*.zip")):
        os.makedirs(srcdir, exist_ok=True)
        shutil.copy2(z, os.path.join(srcdir, os.path.basename(z)))
    if os.path.isdir(srcdir):
        with open(os.path.join(srcdir, "README.txt"), "w", encoding="utf-8") as fh:
            fh.write("The OFFGRID Command Center Android app, as source code. It has NOT been compiled or tested yet.\n"
                     "1. Unzip offgrid-android-source.zip.\n"
                     "2. Upload the CONTENTS of the offgrid-android folder to a new GitHub repository.\n"
                     "3. Actions > Build APK > Run workflow. Download the offgrid-debug-apk artifact.\n"
                     "4. Put app-debug.apk in ../apk/ and install it on the phone.\n"
                     "Details and the acceptance checklist are in the README inside the zip.\n")
    # single-file pages
    www = os.path.join(dest, "www")
    sp = os.path.join(out, "single-file-pages")
    done = []
    for name, title in STANDALONE:
        src = os.path.join(www, name)
        if not os.path.isfile(src):
            src = os.path.join(HERE, name)
        if not os.path.isfile(src):
            continue
        base = www if os.path.isfile(os.path.join(www, name)) else HERE
        os.makedirs(sp, exist_ok=True)
        with open(os.path.join(sp, name), "w", encoding="utf-8") as fh:
            fh.write(inline_page(src, base))
        done.append(title)
    print(f"  Android pack: PLATFORMS\\ANDROID ({n_apk} app, {len(done)} single-file pages)")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    build(None, os.path.abspath(a.dest))


if __name__ == "__main__":
    main()
