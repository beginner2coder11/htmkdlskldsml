# Called by UPDATE-DRIVE-WINDOWS.bat on the drive. Keeps the computer awake and runs the builder in update mode.
param([Parameter(ValueFromRemainingArguments = $true)] $Rest)
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
try {
  Add-Type -Namespace OffGrid -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);'
  [void][OffGrid.Power]::SetThreadExecutionState([uint32]"0x80000001")
} catch { Write-Host "Tip: set Sleep to Never while updating, or the downloads will pause." }
$env:PYTHONUTF8 = "1"
& "$root\tools\python-win\python.exe" "$root\tools\builder\usb\usb_builder.py" --dest $root --update @Rest
