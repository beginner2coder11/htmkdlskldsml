"""COPY-AI-TO-THIS-COMPUTER (v80): copy the drive's AI onto this computer's own disk so it loads faster.

The drive stays the master copy. START uses the local copy only while it matches the drive file for file;
when the drive is updated, START falls back to the drive by itself and says to run this again.
  copy    copy the program + the models this computer would use (+ the small one for outage mode, + search helpers)
  status  what is copied and how much space it uses
  remove  delete the local copy (the drive is not touched)
Windows: %LOCALAPPDATA%\\OFFGRID-AI     Mac/Linux: ~/.offgrid-ai
"""
import argparse, json, os, shutil, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ai_pick  # noqa: E402

GB = 1024 ** 3
HELPERS = ("bge-reranker-v2-m3-Q4_K_M.gguf", "embeddinggemma-300M-Q8_0.gguf")


def _copy(src, dst):
    """Copy with a progress line; written as .part first so a pulled drive never leaves a half file that looks whole."""
    size = os.path.getsize(src)
    if os.path.exists(dst) and os.path.getsize(dst) == size:
        print(f"    already there: {os.path.basename(dst)}")
        return
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    tmp = dst + ".part"
    done, t0, last = 0, time.time(), 0
    with open(src, "rb") as fi, open(tmp, "wb") as fo:
        while True:
            b = fi.read(8 * 1024 * 1024)
            if not b:
                break
            fo.write(b)
            done += len(b)
            if time.time() - last > 1 or done == size:
                last = time.time()
                rate = done / max(0.1, last - t0) / 1048576
                print(f"\r    {os.path.basename(dst)}: {done / GB:.2f} / {size / GB:.2f} GB  ({rate:.0f} MB/s)   ", end="", flush=True)
    print()
    if os.path.getsize(tmp) != size:
        os.remove(tmp)
        raise OSError(f"copy of {os.path.basename(src)} is incomplete")
    os.replace(tmp, dst)


def plan(dest):
    osn = "win" if os.name == "nt" else "unix"
    want = set()
    for mode in ("normal", "outage"):
        r = ai_pick.pick(dest, osn, mode) or {}
        if r.get("MODEL"):
            want.add(r["MODEL"])
    mdir = os.path.join(dest, "ai", "models")
    want |= {h for h in HELPERS if os.path.exists(os.path.join(mdir, h))}
    bins = []
    if os.name == "nt":
        bins = [b for b in ("win-gpu", "win") if os.path.isdir(os.path.join(dest, "ai", "bin", b))]
    return sorted(want), bins


def status(dest):
    root = ai_pick.local_root()
    man = ai_pick.manifest()
    if not man:
        print(f"  No AI copy on this computer yet ({root}).")
        return
    used = 0
    for dp, _d, fs in os.walk(root):
        used += sum(os.path.getsize(os.path.join(dp, f)) for f in fs)
    print(f"  Local copy: {root}   ({used / GB:.1f} GB, made {man.get('made', '?')})")
    for m in man.get("models", {}):
        ok = ai_pick.local_model(dest, m)
        print(f"    {'OK      ' if ok else 'OUTDATED'}  {m}")
    for b in man.get("bins", {}):
        print(f"    {'OK      ' if ai_pick.local_bin(dest, b) else 'OUTDATED'}  program folder ai\\bin\\{b}")


def copy(dest):
    root = ai_pick.local_root()
    models, bins = plan(dest)
    mdir = os.path.join(dest, "ai", "models")
    need = sum(os.path.getsize(os.path.join(mdir, m)) for m in models)
    need += sum(os.path.getsize(os.path.join(dp, f)) for b in bins for dp, _d, fs in os.walk(os.path.join(dest, "ai", "bin", b)) for f in fs)
    have = sum(os.path.getsize(os.path.join(dp, f)) for dp, _d, fs in os.walk(root) for f in fs) if os.path.isdir(root) else 0
    os.makedirs(root, exist_ok=True)
    free = shutil.disk_usage(root).free
    print(f"  Copying to {root}")
    print(f"  Models: {', '.join(models)}")
    print(f"  Needs about {need / GB:.1f} GB; this disk has {free / GB:.1f} GB free.")
    if need - have > free - 3 * GB:
        print("  Not enough free space (keeping 3 GB spare for Windows). Nothing copied.")
        return 1
    man = ai_pick.manifest()
    man.setdefault("models", {}); man.setdefault("bins", {})
    for b in bins:
        print(f"  program folder ai\\bin\\{b}")
        src = os.path.join(dest, "ai", "bin", b)
        sizes = {}
        for dp, _d, fs in os.walk(src):
            for f in fs:
                rel = os.path.relpath(os.path.join(dp, f), src)
                _copy(os.path.join(src, rel), os.path.join(root, "bin", b, rel))
                sizes[rel] = os.path.getsize(os.path.join(src, rel))
        man["bins"][b] = sizes
    for m in models:
        _copy(os.path.join(mdir, m), os.path.join(root, "models", m))
        man["models"][m] = os.path.getsize(os.path.join(mdir, m))
    # drop models this computer no longer uses (an older edition after a drive update)
    for f in os.listdir(os.path.join(root, "models")):
        if f not in models and f.endswith((".gguf", ".part")):
            os.remove(os.path.join(root, "models", f))
            man["models"].pop(f, None)
    man["made"] = time.strftime("%Y-%m-%d %H:%M")
    man["drive"] = os.path.abspath(dest)
    with open(os.path.join(root, "manifest.json"), "w") as fh:
        json.dump(man, fh, indent=1)
    print("\n  Done. START THE DRIVE now loads the AI from this computer (the drive must still be plugged in).")
    return 0


def remove():
    root = ai_pick.local_root()
    if not os.path.isdir(root):
        print("  Nothing to remove.")
        return 0
    shutil.rmtree(root, ignore_errors=True)
    print(f"  Removed {root}. The drive was not touched.")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=".")
    ap.add_argument("action", nargs="?", default="copy", choices=("copy", "status", "remove"))
    a = ap.parse_args()
    dest = os.path.abspath(a.dest)
    if a.action == "status":
        status(dest)
        return 0
    if a.action == "remove":
        return remove()
    return copy(dest)


if __name__ == "__main__":
    sys.exit(main() or 0)
