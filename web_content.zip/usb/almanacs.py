"""Farmer's almanacs and planting guides (public domain / free licence, from archive.org) -> www\\library\\Almanacs."""
import os
import re

import languages as L

FOLDER = "Almanacs - Farmer and Planting"
CAP = {"small": 6, "medium": 12, "large": 30, "full": 60}
QUERIES = [
    "old farmer's almanac", "farmers almanac", "farmer's almanac", "poor richard almanack", "country almanac",
    "planting guide vegetable garden", "home vegetable gardening", "victory garden", "canning and preserving food",
    "kitchen garden", "weather folklore forecasting", "farmers' bulletin",
]
PD_YEAR = 1930   # US works published before this are public domain


def _ok(d, title, creator):
    try:
        year = int(str(d.get("year") or 0)[:4])
    except ValueError:
        year = 0
    return (0 < year < PD_YEAR) or L._free(d.get("licenseurl")) or bool(
        re.search(r"u\.?s\.? department of agriculture|usda|extension service|agricultural extension", f"{title} {creator}", re.I))


def build(u, dest, profile="large"):
    cap = CAP.get(profile, 0)
    if not cap:
        return
    u.say("Farmer's almanacs and planting guides (archive.org)")
    folder = os.path.join(dest, "www", "library", FOLDER)
    seen, added = set(), 0
    for q in QUERIES:
        if added >= cap:
            break
        tq = "title:(" + " AND ".join(re.findall(r"[\w']+", q)) + ")"
        for d in L._search(u, tq, rows=25):
            ident = d.get("identifier")
            title = d.get("title") if isinstance(d.get("title"), str) else (ident or "")
            creator = d.get("creator") if isinstance(d.get("creator"), str) else " ".join(d.get("creator") or [])
            if not ident or ident in seen or added >= cap:
                continue
            seen.add(ident)
            if not _ok(d, title, creator):
                continue
            r = L._fetch_item(u, ident, title, folder)
            if r:
                added += 1
                if r[2]:                                   # only say something when a new file arrived
                    L._p(f"  almanac: + {title[:70]}")
    print(f"  {added} almanac/planting book(s) on the drive (all public domain, free-licensed or US government)")
