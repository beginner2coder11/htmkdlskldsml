#!/usr/bin/env python3
"""DASHBOARD.html at the top of the drive: the one page anyone can double-click.

Big tiles for the things people need first (Top 20 situations, Command Center, search, library, maps, medicine,
radio), the home area and when the drive was last built, and how to start the AI/map server.
Plain HTML, no server, no scripts needed. Rewritten every builder or update run (launcher.write calls it).
Web pages cannot run programs, so programs stay in START-HERE; this page says so.
"""
import html, json, os, time

TILES = [
    # (href from the drive root, title, line, style)  style: hot = big gold, main = blue, '' = normal
    ("TOP 20 SITUATIONS/00 - START HERE.html", "Top 20 situations", "Power out, fire, flood, bleeding, no water, evacuate — what to do now, what you need, best pages", "hot"),
    ("www/command.html", "Command Center", "Everything on the drive: maps, library, radio, tools, media, devices", "main"),
    ("www/topics.html", "What's happening?", "Pick a situation, get first steps and what to read", ""),
    ("www/search.html", "Search everything", "Every guide, manual page and book — works with no server", ""),
    ("www/library/index.html", "Library", "Guides, field manuals and books by subject", ""),
    ("www/archives.html", "Archive contents", "Every book, video and article in Wikipedia, Gutenberg, Khan Academy and the rest", ""),
    ("www/index.html", "Locator map", "Nearest hospitals, fuel, water, shelter (full map after START-HERE 1)", ""),
    ("PRINTABLE MAPS/00 - START HERE.html", "Printable satellite maps", "Home and every get-home route as print-ready sheets — they work with no power (ADD-SATELLITE-IMAGERY makes them)", ""),
    ("www/medicine.html", "Medicine & first aid", "Remedies, cautions and what fits which problem", ""),
    ("www/radio.html", "Radio hub", "Channel plan, call signs, radio manuals", ""),
    ("www/manual.html", "How to use this drive", "What each part does, what to keep, what never to touch", ""),
    ("REPORTS/DRIVE-CHECKLIST.html", "Drive checklist", "What the drive still needs", ""),
    ("FIELD-NOTEBOOK.html", "Field Notebook", "Your notes, logs and checklists — saved on this drive", ""),
    ("READ-ME-FIRST.html", "Programs list", "Every START-HERE program and when to use it", ""),
]

CSS = """*{box-sizing:border-box;margin:0;padding:0}
body{font-family:"Segoe UI",system-ui,Roboto,Arial,sans-serif;background:#14171a;color:#e6e8eb;min-height:100vh}
header{background:#1b1f24;border-bottom:3px solid #c9771f;padding:22px 20px;text-align:center}
header h1{font-size:30px;letter-spacing:1px;color:#d9a441} header p{color:#aab3bd;margin-top:4px}
.wrap{max-width:1150px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}
a.t{display:block;text-decoration:none;color:inherit;background:#1f242b;border:1px solid #2c323a;border-radius:14px;padding:20px;transition:transform .15s,background .15s}
a.t:hover,a.t:focus{transform:translateY(-4px);background:#283039;outline:none;border-color:#d9a441}
a.t b{display:block;font-size:20px;color:#6db0ff;margin-bottom:6px} a.t span{color:#aab3bd;font-size:14px;line-height:1.4}
a.hot{grid-column:1/-1;background:#3a2a0f;border-color:#c9771f} a.hot b{color:#ffc65a;font-size:26px} a.hot span{color:#e8d4ac;font-size:16px}
a.main{grid-column:span 2;background:#16283d;border-color:#2f5d8f} a.main b{font-size:24px}
.start{margin-top:22px;background:#1b1f24;border:1px solid #2c323a;border-radius:12px;padding:16px 18px;line-height:1.6}
.start b{color:#d9a441} code{background:#0f1215;border-radius:4px;padding:1px 6px;color:#e6e8eb}
footer{text-align:center;color:#7d8791;font-size:13px;padding:22px}
@media(max-width:600px){a.main{grid-column:auto}}
@media print{body{background:#fff;color:#000}a.t{border:1px solid #999;background:#fff}a.t b,a.t span{color:#000}}"""


def _home(dest):
    try:
        t = open(os.path.join(dest, "www", "data", "pois.js"), encoding="utf-8").read()
        i = t.index("=", t.index("window.POI_META")) + 1
        return json.JSONDecoder().raw_decode(t[i:].lstrip())[0].get("label", "")
    except Exception:  # noqa: BLE001
        return ""


def build(dest):
    from urllib.parse import quote
    e = html.escape
    home = _home(dest)
    tiles = []
    for href, title, line, cls in TILES:
        missing = not os.path.exists(os.path.join(dest, *href.split("/")))
        note = " (made at the end of the next builder run)" if missing else ""
        tiles.append(f"<a class='t {cls}' href='{e(quote(href))}'><b>{e(title)}</b><span>{e(line + note)}</span></a>")
    sub = "Offline survival drive" + (f" · home area: {e(home)}" if home else "") + f" · updated {time.strftime('%Y-%m-%d')}"
    doc = ("<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
           f"<title>OFFGRID Dashboard</title><style>{CSS}</style></head><body>"
           f"<header><h1>OFFGRID DASHBOARD</h1><p>{sub}</p></header><div class='wrap'><div class='grid'>"
           + "".join(tiles) + "</div>"
           "<div class='start'><b>For the AI, the full street map and the Wikipedia / medical archives:</b> double-click "
           "<code>START-HERE.bat</code> on this drive (Mac / Linux: <code>start-here-mac-linux.sh</code>) and choose "
           "<b>START THE DRIVE</b>. Programs run from there — a web page can't start them. Everything above works "
           "without it.<br>On a phone: open <code>USE-ON-PHONE.html</code>.</div></div>"
           "<footer>Runs straight from this drive · nothing is installed · rewritten each time the builder runs</footer></body></html>")
    with open(os.path.join(dest, "DASHBOARD.html"), "w", encoding="utf-8") as fh:
        fh.write(doc)
    return os.path.join(dest, "DASHBOARD.html")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    print(build(ap.parse_args().dest))
