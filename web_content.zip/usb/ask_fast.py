"""Prebuilt speed-ups for Ask-the-Library, made once at build time so the page does no heavy work when it opens.

  www/docs-idx.js    ready-made BM25 index (term -> postings; each posting = gap*8 + count-1), so ask.html no longer tokenizes every passage on load
  www/ask-brief.js   a short, fixed 'what is on this drive' briefing that goes at the start of the AI's instructions;
                     because it never changes, the AI server processes it once and reuses it for every question

Run on its own to rebuild both from an existing www\\docs.js:  python ask_fast.py --dest E:\\OFFGRID"""
import argparse, json, math, os, re, sys

STOP = set("a an and are as at be by for from how i in is it of on or the to what when where which who why with do does my me can you your near nearest closest this that".split())
TOK = re.compile(r"[a-z0-9.]+")


def tok(s):
    return [w for w in TOK.findall(s.lower()) if len(w) > 1 and w not in STOP]


def build_index(chunks):
    post, dl = {}, []
    for i, (title, _src, text) in enumerate(chunks):
        t = tok(title + " " + title + " " + text)
        dl.append(len(t))
        tf = {}
        for w in t:
            if len(w) <= 25:
                tf[w] = tf.get(w, 0) + 1
        for w, f in tf.items():
            post.setdefault(w, []).append((i, f))
    flat = {}
    for w, lst in post.items():
        out, prev = [], 0
        for i, f in lst:
            out.append((i - prev) * 8 + min(f, 8) - 1)     # one number per posting: gap in the high bits, term count (1-8) in the low 3
            prev = i
        flat[w] = out
    n = max(1, len(chunks))
    return {"N": len(chunks), "avg": round(sum(dl) / n, 2), "dl": dl, "p": flat}


def build_brief(chunks, limit=1800):
    cats = {}
    for title, src, _ in chunks:
        m = re.match(r"library/([^/]+)/", src or "")
        if not m:
            continue
        d = cats.setdefault(m.group(1), [])
        t = re.sub(r"\s+", " ", title).strip()
        if t and t not in d:
            d.append(t)
    lines = []
    for c, ts in sorted(cats.items(), key=lambda x: -len(x[1])):
        lines.append(f"- {c} ({len(ts)}): " + "; ".join(x[:48] for x in ts[:4]))
    s = ("This family's offline library holds, by section (number of documents, examples):\n" + "\n".join(lines))[:limit]
    return s + "\nThe drive also has maps, a nearby-places database, radio frequency lists, medicine and poison guides, and checklists for emergencies."


def write(dest, chunks):
    w = os.path.join(dest, "www")
    idx = build_index(chunks)
    with open(os.path.join(w, "docs-idx.js"), "w", encoding="utf-8") as fh:
        fh.write("window.DIDX=" + json.dumps(idx, separators=(",", ":")) + ";\n")
    with open(os.path.join(w, "ask-brief.js"), "w", encoding="utf-8") as fh:
        fh.write("window.BRIEF=" + json.dumps(build_brief(chunks)) + ";\n")
    return len(idx["p"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    p = os.path.join(a.dest, "www", "docs.js")
    if not os.path.exists(p):
        print("No www\\docs.js yet - run the builder first."); sys.exit(1)
    raw = open(p, encoding="utf-8").read()
    chunks = json.loads(raw[raw.index("=") + 1:].rstrip().rstrip(";"))
    print(f"{len(chunks):,} passages -> {write(a.dest, chunks):,} terms")
