"""Joint Force, Air Force, Army, Navy, Marine and Space Force doctrine for the drive.

Reads the Marine Corps University "JADO - Military Doctrine" research guide
(https://grc-usmcu.libguides.com/JADO/doctrine), follows every link and keeps the PDFs that are public.
Links that need a CAC (JDEIS pages), or sites that block automation, are retried through curl and the
Internet Archive; whatever still can't be fetched is listed in REPORTS\\NOT-FETCHED-Joint-Doctrine.txt so you can drop it in by hand.

Files go flat into www\\library\\Joint & Service Doctrine so search finds them.
    python joint_doctrine.py --dest E:\\OFFGRID
"""
import argparse
import html as _html
import os
import re
import shutil
import subprocess
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import army_pubs as ap  # noqa: E402

GUIDE = "https://grc-usmcu.libguides.com/JADO/doctrine"
FOLDER = "Joint & Service Doctrine"
SKIP = ("youtu", "safelinks", "sharepoint", "libguides.com", "libapps", "springshare", "cloudfront", "twitter", "facebook")
# Pages that list many public PDFs; every PDF found is kept.
HUBS = [
    "https://www.jcs.mil/Doctrine/Joint-Doctrine-Pubs/",
    "https://www.doctrine.af.mil/Doctrine-Publications/",
    "https://www.starcom.spaceforce.mil/Resources/Digital-Library/",
]
INSECURE_HOSTS = ("jdeis.js.mil",)      # DoD-signed certificate that Python/curl bundles don't trust; public PDFs only


def _pdf_ok(path):
    try:
        with open(path, "rb") as f:
            return f.read(5) == b"%PDF-"
    except OSError:
        return False


def _curl_file(url, out, insecure=False):
    exe = shutil.which("curl.exe") or shutil.which("curl")
    if not exe:
        return False
    cmd = [exe, "-sSL", "--max-time", "240", "-A", ap.UA["User-Agent"]] + (["-k"] if insecure else []) + ["-o", out, url]
    try:
        subprocess.run(cmd, capture_output=True, timeout=270)
    except Exception:  # noqa: BLE001
        return False
    return os.path.exists(out)


def _grab(url, out, quick=False):
    """Try direct, curl, then the Internet Archive. True only when a real PDF is saved."""
    host = urllib.parse.urlparse(url).netloc.lower()
    if os.path.exists(out) and _pdf_ok(out):
        return True
    tries = [("direct", None), ("curl", False)]
    if host in INSECURE_HOSTS:
        tries.append(("curl-k", True))
    if not quick:
        tries.append(("archive", "wb"))
    for kind, flag in tries:
        tmp = out + ".part"
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
            if kind == "direct":
                ap._fetch_file(url, tmp)
                if os.path.exists(out + ".part.part"):
                    os.remove(out + ".part.part")
            elif kind.startswith("curl"):
                _curl_file(url, tmp, flag)
            else:
                _curl_file("https://web.archive.org/web/2id_/" + url, tmp)
        except Exception:  # noqa: BLE001
            continue
        # _fetch_file renames .part -> final name `tmp`'s base, so look in both places
        got = tmp if os.path.exists(tmp) else (out if os.path.exists(out) else "")
        if got and _pdf_ok(got):
            if got != out:
                os.replace(got, out)
            return True
        for p in (tmp, out + ".part.part"):
            if os.path.exists(p):
                os.remove(p)
        if os.path.exists(out) and not _pdf_ok(out):
            os.remove(out)
    return False


def _page(url):
    for u in (url, "https://web.archive.org/web/2id_/" + url):
        try:
            return ap._get(u, 45)
        except Exception:  # noqa: BLE001
            continue
    return ""


def _links(page, base):
    out = []
    for m in re.finditer(r'href="(https?://[^"]+|/[^"]+)"[^>]*>(.*?)</a>', page, re.S | re.I):
        u_ = urllib.parse.urljoin(base, _html.unescape(m.group(1)))
        t = re.sub(r"<[^>]+>|\s+", " ", _html.unescape(m.group(2))).strip()
        if not any(s in u_.lower() for s in SKIP):
            out.append((t, u_))
    return out


def _jdeis_guess(title):
    """'JP 3-0 Joint Campaigns...' -> the public JDEIS file names. Newer JPs carry a change suffix
    (jp3_01ch1.pdf, jp3_31ch2.pdf), so try the plain name and the common suffixes."""
    m = re.match(r"JP\s+(\d)(?:-(\d+))?(?:\s*Vol\s*(\d))?", title)
    if not m or "APP" in title:
        return []
    a, b, v = m.groups()
    stem = f"jp{a}" + (f"_{b}" if b else "") + (f"_vol{v}" if v else "")
    return [f"https://jdeis.js.mil/jdeis/new_pubs/{stem}{suf}.pdf" for suf in ("", "ch1", "ch2", "ch3")]


def _clean(t):
    t = re.sub(r"\s*This link opens.*$|\s*CAC, DOD ID.*$", "", t or "").strip()
    return t


def _archive_copy(title, folder):
    """Public JPs are login-gated on JDEIS; fall back to an (often older) copy on archive.org."""
    import json
    m = re.match(r"JP\s+(\d(?:-\d+(?:\.\d+)?)?)", title)
    if not m:
        return False
    num = m.group(1)
    q = urllib.parse.quote(f'title:("joint publication {num}") AND mediatype:texts')
    try:
        docs = json.loads(ap._get("https://archive.org/advancedsearch.php?q=" + q +
                                  "&fl[]=identifier&fl[]=title&rows=10&output=json", 40))["response"]["docs"]
        for d in docs:
            if not re.search(r"(?<![\d-])" + re.escape(num) + r"(?![\d.-])", d.get("title", "")):
                continue
            meta = json.loads(ap._get("https://archive.org/metadata/" + d["identifier"], 40))
            pdfs = [x for x in meta.get("files", []) if x.get("name", "").lower().endswith(".pdf")]
            if pdfs:
                pdfs.sort(key=lambda x: -int(x.get("size", 0) or 0))
                url = f"https://archive.org/download/{d['identifier']}/{urllib.parse.quote(pdfs[0]['name'])}"
                out = os.path.join(folder, ap._safe(title.split(" - ")[0] + " (archive.org copy)", 100) + ".pdf")
                if _grab(url, out):
                    return True
    except Exception:  # noqa: BLE001
        pass
    return False


def _name(title, url):
    t = ap._safe(title, 100) or os.path.basename(urllib.parse.urlparse(url).path)
    return t if t.lower().endswith(".pdf") else t + ".pdf"


# ---- Public Joint Publications straight from the JCS list of current publications -------------------------------
STATUS_URL = "https://www.jcs.mil/Portals/36/Documents/Doctrine/pubs/status.pdf"
JDEIS = "https://jdeis.js.mil/jdeis/new_pubs/"
# Every JP the reference guide names (number -> title). Newest public edition of each is fetched.
WANTED = {
    "1": "Joint Warfighting (Vol 1)", "1_vol2": "The Joint Force (Vol 2)", "1_0": "Joint Personnel Support", "2_0": "Joint Intelligence",
    "2_01": "Joint and National Intelligence Support to Military Operations", "2_01_3": "Joint Intelligence Preparation of the Operational Environment",
    "2_03": "Geospatial Intelligence Support to Joint Operations", "3_0": "Joint Campaigns and Operations",
    "3_01": "Countering Air and Missile Threats", "3_02": "Amphibious Operations", "3_03": "Joint Interdiction", "3_05": "Joint Special Operations",
    "3_08": "Interorganizational Cooperation", "3_09": "Joint Fire Support", "3_12": "Cyberspace Operations", "3_13": "Information Operations",
    "3_14": "Space Operations", "3_15": "Barriers, Obstacles, and Mine Warfare", "3_20": "Security Cooperation", "3_27": "Homeland Defense",
    "3_28": "Defense Support of Civil Authorities", "3_30": "Joint Air Operations", "3_31": "Joint Land Operations", "3_32": "Joint Maritime Operations",
    "3_33": "Joint Task Force Headquarters", "3_50": "Personnel Recovery", "3_52": "Joint Airspace Control", "3_60": "Joint Targeting",
    "3_61": "Public Affairs", "4_0": "Joint Logistics", "4_01": "Joint Logistics Over-the-Shore", "4_02": "Joint Health Services",
    "4_03": "Joint Bulk Petroleum and Water Support", "4_09": "Distribution Operations", "4_10": "Operational Contract Support",
    "5_0": "Joint Planning", "6_0": "Joint Communications System",
}
EXTRA_FILES = [  # other public JCS/JDEIS documents named in the guide
    ("DOD Dictionary of Military and Associated Terms", JDEIS + "dictionary.pdf"),
    ("CJCSM 5120.01B Joint Doctrine Development Process", "https://www.jcs.mil/Portals/36/Documents/Doctrine/pubs/cjcsm5120.01b.pdf"),
]
# file names seen on the JCS publications list (used when the list itself cannot be read)
KNOWN = ("jp1_0 jp2_0ch1 jp3_0 jp4_0 jp5_0ch1 jp6_0 jp3_01ch1 jp3_02 jp3_03 jp3_04 jp3_05 jp3_06 jp3_08 jp3_14 jp3_15 jp3_16ch1 jp3_18ch1 "
         "jp3_20ch1 jp3_22 jp3_23 jp3_24 jp3_26 jp3_27 jp3_28 jp3_29 jp3_30 jp3_31ch2 jp3_32 jp3_33ch1 jp3_34 jp3_36 jp3_40 jp3_13_4 jp3_55").split()


def _stem_key(stem):
    """'jp3_31ch2' -> ('3_31', 2); 'jp5_0ch1' -> ('5_0', 1); 'jp3_07sig' / 'jp335sig_v2' are ignored."""
    m = re.fullmatch(r"jp(\d(?:_\d+(?:_\d+)?)?(?:_vol\d)?)(?:ch(\d+))?", stem.lower())
    return (m.group(1), int(m.group(2) or 0)) if m else None


def _listed_stems():
    """File names the JCS says are current: read status.pdf (links inside it) and fall back to KNOWN."""
    stems = set(KNOWN)
    try:
        import zlib
        data = ap._get(STATUS_URL, 60, binary=True)
        blobs = [data]
        for m in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
            try:
                blobs.append(zlib.decompress(m.group(1)))
            except Exception:  # noqa: BLE001
                pass
        for b in blobs:
            for m in re.finditer(rb"new_pubs/(jp[0-9_a-z]+)\.pdf", b, re.I):
                stems.add(m.group(1).decode().lower())
    except Exception:  # noqa: BLE001
        print("  (could not read the JCS publications list; using the built-in list)")
    return stems


def direct_jps(folder):
    """Fetch the newest public edition of every JP in WANTED. Returns ({key: path}, [key not found])."""
    stems = _listed_stems()
    best = {}
    for st in stems:
        k = _stem_key(st)
        if k and (k[0] not in best or k[1] > best[k[0]][1]):
            best[k[0]] = (st, k[1])
    got, notfound = {}, []
    for key, title in WANTED.items():
        num = key.replace("_vol", " Vol ").replace("_", "-", 1).replace("_", ".")
        out = os.path.join(folder, ap._safe(f"JP {num} {title} (JCS)", 110) + ".pdf")
        if os.path.exists(out) and _pdf_ok(out):
            got[key] = out
            continue
        urls = []
        if key in best:
            urls.append(JDEIS + best[key][0] + ".pdf")
        if not urls:
            urls += [f"{JDEIS}jp{key}{suf}.pdf" for suf in ("", "ch1", "ch2", "ch3")]
        ok = False
        for i, u_ in enumerate(urls):
            if _grab(u_, out, quick=(i < len(urls) - 1 and key not in best)):
                ok = True
                break
        if ok:
            got[key] = out
            print(f"  JP {num}: {os.path.basename(urls[i])}", flush=True)
        else:
            notfound.append(key)
    for title, url in EXTRA_FILES:
        out = os.path.join(folder, ap._safe(title, 100) + ".pdf")
        if not (os.path.exists(out) and _pdf_ok(out)):
            _grab(url, out)
    return got, notfound


def run(dest):
    folder = os.path.join(dest, "www", "library", FOLDER)
    os.makedirs(folder, exist_ok=True)
    print("\n==> Joint Force & service doctrine (MCU JADO guide and linked sites)", flush=True)
    g = _page(GUIDE)
    items = _links(g, GUIDE) if g else []
    if not items:
        print("  ! couldn't read the guide page; trying the doctrine hub pages only.")
    seen_pdf, missed, got = set(), [], 0

    def keep(title, url):
        nonlocal got
        if url in seen_pdf:
            return True
        seen_pdf.add(url)
        out = os.path.join(folder, _name(title, url))
        had = os.path.exists(out) and _pdf_ok(out)
        ok = _grab(url, out)
        if ok and not had:
            got += 1
        return ok

    jobs = items + [("", h) for h in HUBS]
    for n, (title, url) in enumerate(jobs, 1):
        low = url.lower()
        title = _clean(title) or os.path.basename(urllib.parse.urlparse(url).path)
        if (re.search(r"FOIA|Resources$|Quantico|^MCB |SFB|^https?:", title) or title.rstrip("/") in HUBS) and url not in HUBS:
            continue
        if "PUB_ID=" in url and "armypubs" in low:
            pid = re.search(r"PUB_ID=(\d+)", url).group(1)
            try:
                pdfs = ap._record_pdfs(pid)
            except Exception:  # noqa: BLE001
                pdfs = []
            ok = any(keep(title if i == 0 else f"{title} ({i + 1})", p) for i, p in enumerate(pdfs[:1]))
        elif low.split("?")[0].endswith(".pdf"):
            ok = keep(title, url)
        elif "jdeis.js.mil" in low:
            ok = any(keep(title, g_) for g_ in _jdeis_guess(title)) or _archive_copy(title, folder)
        elif title and any(x in low for x in ("marines.mil", "doctrine.af.mil", "tradoc.army.mil", "history.army.mil",
                                               "navy.mil", "jcs.mil", "starcom", "fdlp.gov")):
            sub = _page(url)
            cand = [(t, u_) for t, u_ in _links(sub, url) if u_.lower().split("?")[0].endswith(".pdf")] if sub else []
            hub = (title, url) in [("", h) for h in HUBS] or url in HUBS
            ok = False
            for i, (t, u_) in enumerate(cand[: (60 if hub else 1)]):
                nm = _clean(t) if hub else title
                if hub and (not nm or len(nm) < 6 or re.search(r"FOIA|Resources|Vision", nm)):
                    nm = os.path.splitext(os.path.basename(urllib.parse.unquote(urllib.parse.urlparse(u_).path)))[0]
                ok = keep(nm, u_) or ok
        else:
            continue
        if not ok and title and url not in HUBS:
            missed.append(f"{title}\t{url}")
        if n % 10 == 0:
            print(f"  checked {n}/{len(jobs)} links, {got} new PDF(s)", flush=True)
    # the exact public JDEIS file names from the JCS publications list (the index pages above need a CAC)
    try:
        jgot, jmiss = direct_jps(folder)
        got += len(jgot)
        have = {re.sub(r"[^a-z0-9]", "", ("jp" + k).lower()) for k in jgot}
        def still_missing(line):
            m = re.match(r"JP\s+([\d]+(?:-\d+)?)(?:\s+Vol\s*(\d))?", line)
            if not m or " APP" in line.split("\t")[0]:
                return True
            n = m.group(1).replace("-", "")
            k = re.sub(r"[^a-z0-9]", "", "jp" + n + ("vol" + m.group(2) if m.group(2) else ""))
            return not any(h == k or h == "jp" + n for h in have)
        missed = [x for x in missed if still_missing(x)]
        if jmiss:
            missed += [f"JP {k.replace('_vol', ' Vol ').replace('_', '-', 1).replace('_', '.')} {WANTED[k]}\thttps://www.jcs.mil/Doctrine/Joint-Doctrine-Pubs/" for k in jmiss]
    except Exception as e:  # noqa: BLE001
        print(f"  ! direct JP fetch: {type(e).__name__}: {e}")
    import reports
    reports.drop_legacy(dest, "www/library/" + FOLDER + "/NOT-FETCHED.txt")
    note = reports.not_fetched(dest, "Joint-Doctrine")
    if missed:
        with open(note, "w", encoding="utf-8") as f:
            f.write("These need a CAC/DoD account or blocked automated download. Save the PDFs by hand into www\\library\\Joint & Service Doctrine\\,\n"
                    "then run the 'Add my documents & books' step (menu L) to index them.\n\n" + "\n".join(missed) + "\n")
    elif os.path.exists(note):
        os.remove(note)
    print(f"  {got} new doctrine PDF(s); {len([f for f in os.listdir(folder) if f.lower().endswith('.pdf')])} on the drive; "
          f"{len(missed)} not available publicly (listed in REPORTS\\NOT-FETCHED-Joint-Doctrine.txt)")
    return got


def build(u, dest):
    u.say("Joint Force & service doctrine")
    return run(dest)


if __name__ == "__main__":
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument("--dest", required=True)
    run(a.parse_args().dest)
