"""Your own radio files on the drive: import them, and turn every CHIRP image (.img) into a readable channel list.

  OFFGRID\\MY-RADIO-INBOX\\   drop anything from your radio projects here (folders are fine), then START-HERE > P:
     .img .dat .csv .chirp .md .txt .pdf .docx   → www\\library\\My Radio Programming\\
     .zip .exe .msi                             → www\\library\\Software\\
     .apk                                       → www\\phone-apps\\android\\Radio programming\\  (and Software)
  Every .img in My Radio Programming gets "<name> - channel list.html": searchable, printable, by zone, with tones,
  offsets and narrow/wide — readable with no CHIRP and no radio. It also says what changed from the main plan image.

Decoder: Baofeng UV-32 (and similar BF "UVs Pro" radios): 1,024 channels x 32 bytes, BCD frequencies, 100 channels
per zone, zone names after the channels. Other radios' images are still copied and listed, just not decoded.
"""
import base64, hashlib, html, json, os, re, shutil, time

INBOX = "MY-RADIO-INBOX"
LIB = ("www", "library", "My Radio Programming")
SOFT = ("www", "library", "Software")
APK = ("www", "phone-apps", "android", "Radio programming")
DOC_EXT = {".img", ".dat", ".csv", ".chirp", ".md", ".txt", ".pdf", ".docx", ".xlsx", ".html", ".htm", ".json", ".kml", ".gpx"}
SOFT_EXT = {".zip", ".exe", ".msi", ".7z"}
MAIN_PLAN = "UV32_Useful_Channels.img"
MAGIC = b"\x00\xffchirp\xeeimg\x00\x01"


def _bcd(b):
    if b in (b"\xff\xff\xff\xff", b"\x00\x00\x00\x00"):
        return None
    s = "".join(f"{x:02x}" for x in reversed(b))
    if not s.isdigit():
        raise ValueError
    return int(s) / 100000


def _tone(b):
    v = b[0] | (b[1] << 8)
    if v in (0, 0xFFFF):
        return ""
    if v & 0x8000:                             # DCS: octal code digits, bit 14 = inverted
        return f"D{v & 0x3FFF:03o}{'I' if v & 0x4000 else 'N'}"
    return f"{v / 10:.1f}"


def decode(path):
    """→ {model, zones:[names], channels:[{ch, zone, name, rx, tx, duplex, offset, rxtone, txtone, mode}]} or None"""
    d = open(path, "rb").read()
    meta = {}
    i = d.find(MAGIC)
    if i >= 0:
        try:
            meta = json.loads(base64.b64decode(d[i + len(MAGIC):]))
        except (ValueError, TypeError):
            meta = {}
        d = d[:i]
    model = f"{meta.get('vendor', '')} {meta.get('model', '')}".strip()
    if meta and "UV-32" not in meta.get("model", "") and "UVS" not in meta.get("rclass", "").upper() and "UV32" not in meta.get("rclass", ""):
        return {"model": model or "unknown radio", "zones": [], "channels": None}
    if len(d) < 1024 * 32:
        return {"model": model or "unknown radio", "zones": [], "channels": None}
    zones = []
    zo = 33408
    if len(d) >= zo + 160:
        for k in range(10):
            nm = d[zo + 16 * k:zo + 16 * (k + 1)].rstrip(b"\xff\x00").decode("latin-1", "replace")
            zones.append(nm if nm.isprintable() else "")
    chans = []
    for k in range(1024):
        r = d[k * 32:(k + 1) * 32]
        if r[:4] == b"\xff" * 4:
            continue
        try:
            rx, tx = _bcd(r[0:4]), _bcd(r[4:8])
        except ValueError:
            continue
        if not rx:
            continue
        name = r[20:32].split(b"\xff")[0].rstrip(b"\x00").decode("latin-1", "replace").strip()
        rt, tt = _tone(r[8:10]), _tone(r[10:12])
        if tx is None:
            dup, off = "RX only", ""
        elif abs(tx - rx) < 1e-6:
            dup, off = "", ""
        else:
            dup, off = ("+" if tx > rx else "-"), f"{abs(tx - rx):.4f}".rstrip("0").rstrip(".")
            if abs(tx - rx) > 20:
                dup, off = "split", f"{tx:.4f}"
        mode = "AM" if 108 <= rx < 137 else ("NFM" if r[15] & 0x40 else "FM")
        z = k // 100
        chans.append({"ch": k + 1, "zone": zones[z] if z < len(zones) and zones[z] else (f"Zone {z + 1}" if z < 10 else "Extra"),
                      "zn": z + 1, "name": name, "rx": rx, "tx": tx, "duplex": dup, "offset": off, "rxtone": rt, "txtone": tt, "mode": mode})
    return {"model": model or "Baofeng UV-32", "zones": zones, "channels": chans}


def _tone_text(c):
    rt, tt = c["rxtone"], c["txtone"]
    if rt and tt and rt == tt:
        return f"TSQL {rt}"
    out = []
    if tt:
        out.append(f"Tone {tt}")
    if rt:
        out.append(f"RX {rt}")
    return " / ".join(out)


def _diff(a, b):
    """What changed from image a to image b (by channel number)."""
    A = {c["ch"]: c for c in a}
    B = {c["ch"]: c for c in b}
    key = lambda c: (c["name"], round(c["rx"], 5), round(c["tx"] or 0, 5), c["rxtone"], c["txtone"], c["mode"])  # noqa: E731
    added = [B[k] for k in sorted(B) if k not in A]
    removed = [A[k] for k in sorted(A) if k not in B]
    changed = [(A[k], B[k]) for k in sorted(A) if k in B and key(A[k]) != key(B[k])]
    return added, removed, changed


def _page(title, info, chans, src_name, diff=None):
    e = html.escape
    rows = "".join(
        f"<tr data-z='{c['zn']}'><td>{c['ch']}</td><td><b>{e(c['name'])}</b></td><td>{c['rx']:.4f}</td><td>{e(c['duplex'])}</td>"
        f"<td>{e(c['offset'])}</td><td>{e(_tone_text(c))}</td><td>{c['mode']}</td><td>{e(c['zone'])}</td></tr>" for c in chans)
    zones = sorted({(c["zn"], c["zone"]) for c in chans})
    zbtn = "".join(f"<button data-z='{n}'>{n}. {e(z)}</button>" for n, z in zones)
    dif = ""
    if diff:
        added, removed, changed = diff
        li = lambda c: f"<li>{c['ch']} <b>{e(c['name'])}</b> {c['rx']:.4f} {e(c['duplex'])}{e(c['offset'])} {e(_tone_text(c))}</li>"  # noqa: E731
        dif = (f"<details open><summary><b>Compared with the main plan ({MAIN_PLAN})</b>: {len(added)} added, {len(removed)} removed, "
               f"{len(changed)} changed</summary>"
               + (f"<h3>Added</h3><ul>{''.join(li(c) for c in added[:400])}</ul>" if added else "")
               + (f"<h3>Removed</h3><ul>{''.join(li(c) for c in removed[:400])}</ul>" if removed else "")
               + (f"<h3>Changed (main plan → this one)</h3><ul>{''.join('<li>' + li(a)[4:-5] + ' → ' + li(b)[4:-5] + '</li>' for a, b in changed[:400])}</ul>" if changed else "")
               + "</details>")
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(title)}</title><style>
body{{font:14px/1.4 system-ui,Segoe UI,Roboto,sans-serif;background:#14171a;color:#e6e8eb;margin:0;padding:14px}}a{{color:#d9a441}}
h1{{font-size:20px;margin:.2em 0}}.sub{{color:#9aa3ad}}table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #2c323a;padding:4px 6px;text-align:left}}
th{{position:sticky;top:0;background:#1c2025}}input{{font:inherit;font-size:16px;padding:8px 10px;width:100%;max-width:420px;background:#0f1214;color:#e6e8eb;border:1px solid #d9a441;border-radius:8px}}
button{{font:inherit;background:#1c2025;color:#e6e8eb;border:1px solid #2c323a;border-radius:7px;padding:4px 8px;margin:2px;cursor:pointer}}button.on{{background:#d9a441;color:#111}}
details{{background:#1c2025;border:1px solid #2c323a;border-radius:8px;padding:8px 12px;margin:10px 0}}h3{{font-size:15px;margin:.6em 0 .2em}}
@media print{{body{{background:#fff;color:#000;font-size:10px}}input,button,.noprint{{display:none}}th{{background:#eee}}td,th{{border-color:#bbb}}details{{display:none}}}}
</style></head><body>
<p class="noprint"><a href="../index.html">← Library</a></p>
<h1>{e(title)}</h1>
<p class="sub">{e(info)} — decoded from <code>{e(src_name)}</code> on {time.strftime('%Y-%m-%d')}. To put it on a radio: open the .img in CHIRP (Software ▸ CHIRP), then Radio ▸ Upload.
Transmitting on ham, GMRS or public-safety channels needs the right license except in a real emergency; listening is always fine.</p>
{dif}
<p class="noprint"><input id="q" placeholder="Search name, frequency, tone…" autocomplete="off"></p>
<p class="noprint"><button data-z="" class="on">All zones</button>{zbtn}</p>
<table><thead><tr><th>Ch</th><th>Name</th><th>RX MHz</th><th>Duplex</th><th>Offset</th><th>Tone</th><th>Mode</th><th>Zone</th></tr></thead><tbody id="t">{rows}</tbody></table>
<script>
let z = "";
const rows = [...document.querySelectorAll("#t tr")];
function f() {{ const q = document.getElementById("q").value.toLowerCase().split(/\\s+/).filter(Boolean);
  rows.forEach(r => {{ const t = r.textContent.toLowerCase(); r.style.display = (!z || r.dataset.z === z) && q.every(w => t.includes(w)) ? "" : "none"; }}); }}
document.getElementById("q").oninput = f;
document.querySelectorAll("button[data-z]").forEach(b => b.onclick = () => {{ z = b.dataset.z;
  document.querySelectorAll("button[data-z]").forEach(x => x.classList.toggle("on", x === b)); f(); }});
</script></body></html>"""


def _sha(path, n=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(n), b""):
            h.update(b)
    return h.hexdigest()


def _same(a, b):
    try:
        return os.path.getsize(a) == os.path.getsize(b) and _sha(a) == _sha(b)
    except OSError:
        return False


def _prune_empty(inbox):
    """Remove now-empty subfolders left after files are moved out (keep the inbox root)."""
    for root, _, _ in os.walk(inbox, topdown=False):
        if os.path.abspath(root) == os.path.abspath(inbox):
            continue
        try:
            if not os.listdir(root):
                os.rmdir(root)
        except OSError:
            pass


def import_inbox(dest):
    """Move everything from MY-RADIO-INBOX into the library (never overwrites a different file; adds ' (2)').

    An original is deleted only after every copy it maps to is verified. Returns (added, moved, kept)."""
    inbox = os.path.join(dest, INBOX)
    os.makedirs(inbox, exist_ok=True)
    rd = os.path.join(inbox, "README.txt")
    if not os.path.exists(rd):
        with open(rd, "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("Put your own radio files here (folders are fine): CHIRP images (.img), CPS files (.dat), channel spreadsheets "
                     "(.csv), manuals (.pdf), programming software (.zip/.exe) and phone apps (.apk).\nThen run START-HERE.bat and pick "
                     "P (Add my radio files). They're sorted into the Library (My Radio Programming, Software) and every .img gets a "
                     "readable channel list.\nEach file is MOVED: the original is removed from this inbox once its copy is verified, so "
                     "the inbox empties as it sorts (this README stays). A file is only left here if it couldn't be stored or verified.\n")
    n = 0
    moved = kept = 0
    for root, _, files in os.walk(inbox):
        for f in files:
            if f == "README.txt" or f.startswith((".", "~$")):
                continue
            src = os.path.join(root, f)
            ext = os.path.splitext(f)[1].lower()
            if f.lower().startswith("amateur_delim") and ext == ".zip":   # Canada's call-sign list (ISED)
                try:
                    import more_data, sys as _sys, types as _t
                    more_data.hamcalls_canada(_sys.modules.get("usb_builder") or _t.SimpleNamespace(CHANGES=[]), dest, offline=True)
                    moved += 1
                except Exception as e:  # noqa: BLE001
                    print(f"  ! amateur_delim.zip: {type(e).__name__}: {e}")
                continue
            if f.lower().startswith("l_amat") and ext == ".zip":    # FCC licence database: goes to the call-sign lookup
                try:
                    os.makedirs(os.path.join(dest, "tools", "fcc"), exist_ok=True)
                    import shutil
                    shutil.move(src, os.path.join(dest, "tools", "fcc", "l_amat.zip"))
                    import more_data, sys as _sys, types as _t
                    more_data.hamcalls(_sys.modules.get("usb_builder") or _t.SimpleNamespace(CHANGES=[]), dest, offline=True)
                    moved += 1
                except Exception as e:  # noqa: BLE001
                    print(f"  ! l_amat.zip: {type(e).__name__}: {e}")
                continue
            dests = []
            if ext in DOC_EXT:
                dests = [LIB]
            elif ext in SOFT_EXT:
                dests = [SOFT]
            elif ext == ".apk":
                dests = [APK, SOFT]
            if not dests:
                continue  # unknown type: leave it in the inbox
            ok = True
            for dpath in dests:
                out_dir = os.path.join(dest, *dpath)
                os.makedirs(out_dir, exist_ok=True)
                out = os.path.join(out_dir, f)
                if os.path.exists(out):
                    if _same(out, src):
                        continue  # identical copy already present: this destination is satisfied
                    b, x = os.path.splitext(out); k = 2
                    while os.path.exists(f"{b} ({k}){x}"):
                        k += 1
                    out = f"{b} ({k}){x}"
                try:
                    shutil.copy2(src, out)
                except OSError:
                    ok = False
                    continue
                n += 1
                if not _same(out, src):
                    ok = False
            if ok:
                try:
                    os.remove(src); moved += 1
                except OSError:
                    kept += 1
            else:
                kept += 1
    _prune_empty(inbox)
    return n, moved, kept


def build(u, dest):
    u.say("Your radio files: MY-RADIO-INBOX → Library, CHIRP images → channel lists")
    n, moved, kept = import_inbox(dest)
    lib = os.path.join(dest, *LIB)
    if not os.path.isdir(lib):
        return
    main = os.path.join(lib, MAIN_PLAN)
    base = decode(main) if os.path.exists(main) else None
    for f in os.listdir(lib):                       # older pages linked to a library page that isn't in this folder
        if f.endswith(" - channel list.html"):
            fp = os.path.join(lib, f)
            try:
                t = open(fp, encoding="utf-8").read()
                if '<a href="index.html">← Library</a>' in t:
                    open(fp, "w", encoding="utf-8").write(t.replace('<a href="index.html">← Library</a>', '<a href="../index.html">← Library</a>'))
            except OSError:
                pass
    pages = 0
    for f in sorted(os.listdir(lib)):
        if not f.lower().endswith(".img"):
            continue
        p = os.path.join(lib, f)
        out = os.path.join(lib, os.path.splitext(f)[0] + " - channel list.html")
        if os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(p) and \
                (not os.path.exists(main) or os.path.getmtime(out) >= os.path.getmtime(main)):
            continue
        try:
            r = decode(p)
        except OSError as e:
            print(f"  ! {f}: {e}"); continue
        if not r or r["channels"] is None:
            print(f"  - {f}: {r['model'] if r else 'unknown'} image — copied, not decoded (only UV-32 images are)"); continue
        ch = r["channels"]
        title = f"{os.path.splitext(f)[0].replace('_', ' ')} — {len(ch)} channels"
        info = f"{r['model']}, {len({c['zn'] for c in ch})} zones"
        diff = _diff(base["channels"], ch) if base and base.get("channels") and f != MAIN_PLAN else None
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(_page(title, info, ch, f, diff))
        pages += 1
        print(f"  {f}: {len(ch)} channels" + (f" (vs main plan: +{len(diff[0])} / -{len(diff[1])} / ~{len(diff[2])})" if diff else ""))
    print(f"  {n} new file(s) from {INBOX}, {pages} channel list(s) written")
    if moved or kept:
        print(f"  {moved} file(s) removed from {INBOX} after sorting" +
              (f"; {kept} left in place (could not verify or remove)" if kept else ""))
