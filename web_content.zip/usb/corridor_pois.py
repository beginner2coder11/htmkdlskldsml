"""Places along each get-home route (routes_data.ROUTES): hospitals, clinics, pharmacies, food, fuel, water, shelter,
police, fire, hardware, auto parts and ham repeaters within 25 miles of the road, plus 40 miles around the start city -
including Canada (Ontario, Quebec).

Reads OpenStreetMap extracts (Geofabrik .osm.pbf) with the same classifier as the locator. States already read for the
500-mile places layer are reused (no download). Canadian province extracts are kept in OSM-MAP-SOURCE, so
CONVERT-OSM-MAPS can also turn them into street maps; US extracts are deleted after reading. Resumable per extract.

Output: www/data/corridors/<route>.js  window.CORRIDOR[<route>] = {label, start, rows:[[cat, name, lat, lon, addr,
phone, web, hours, info, mile_along, miles_off_road]]}  (rows sorted by mile_along from the START city)
Used by MAKE-A-GUIDE (survival_guide.py) and the Places-near-anywhere page (www/nearby.html).
"""
import glob, json, math, os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (os.path.join(os.path.dirname(HERE), "scripts"), os.path.join(HERE, "scripts")):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.append(_p)

ROAD_MILES = 25
CITY_MILES = 40
KEEP = {"hospital", "urgent_care", "clinic", "pharmacy", "grocery", "food_dist", "fuel", "water", "shelter", "police", "fire",
        "ems", "hardware", "auto_parts", "repeater", "general", "convenience", "outdoor", "vet", "rv_marine", "surplus"}
CANADA = {"ontario": (41.6, -95.2, 56.9, -74.3), "quebec": (44.9, -79.8, 62.6, -57.1)}
CA_URL = "https://download.geofabrik.de/north-america/canada/{}-latest.osm.pbf"
VERSION = 1


def _mi(la1, lo1, la2, lo2):
    r = math.radians
    a = math.sin(r(la2 - la1) / 2) ** 2 + math.cos(r(la1)) * math.cos(r(la2)) * math.sin(r(lo2 - lo1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(min(1, a)))


def _dense(line, step=5.0):
    """The route polyline resampled every ~5 miles: [(lat, lon, miles from start)]."""
    pts, along = [], 0.0
    for (a1, o1), (a2, o2) in zip(line, line[1:]):
        d = _mi(a1, o1, a2, o2)
        n = max(1, int(d / step))
        for k in range(n):
            f = k / n
            pts.append((a1 + (a2 - a1) * f, o1 + (o2 - o1) * f, along + d * f))
        along += d
    pts.append((line[-1][0], line[-1][1], along))
    return pts


def _grid(pts):
    g = {}
    for p in pts:
        g.setdefault((int(p[0] * 2 // 1), int(p[1] * 2 // 1)), []).append(p)
    return g


def _near(grid, la, lo):
    """(miles off the road, mile along) to the nearest resampled point - fine at 5-mile spacing for a 25-mile band."""
    best = (1e9, 0)
    ci, cj = int(la * 2 // 1), int(lo * 2 // 1)
    for di in (-1, 0, 1):
        for dj in (-2, -1, 0, 1, 2):
            for pa, po, al in grid.get((ci + di, cj + dj), ()):
                d = _mi(pa, po, la, lo)
                if d < best[0]:
                    best = (d, al)
    return best


def extracts_for(routes):
    import regional_pois
    boxes = dict(regional_pois.STATES)
    boxes.update(CANADA)
    need = set()
    for r in routes:
        for la, lo, _ in _dense(r["line"], 10):
            for name, (s, w, n, e) in boxes.items():
                if s - 0.1 <= la <= n + 0.1 and w - 0.1 <= lo <= e + 0.1:
                    need.add(name)
    return sorted(need)


def run(u, dest, routes=None):
    import build_pois, regional_pois
    if routes is None:
        import routes_data
        routes = routes_data.ROUTES
    if not routes:
        print("  No get-home routes set (routes_data.py) - nothing to do.")
        return 0
    u.say("Places along the get-home routes (25 miles each side, 40 miles around each start city, incl. Canada)")
    dense = {r["key"]: _dense(r["line"]) for r in routes}
    grids = {k: _grid(v) for k, v in dense.items()}
    need = extracts_for(routes)
    print("  extracts: " + ", ".join(need))
    cache = os.path.join(dest, "tools", "corridor-cache")
    os.makedirs(cache, exist_ok=True)
    sig = json.dumps([[r["key"], r["line"]] for r in routes]) + str(VERSION)
    p500 = os.path.join(dest, regional_pois.OUTDIR)
    try:
        pidx = json.load(open(os.path.join(p500, "index.json"), encoding="utf-8"))
    except (OSError, ValueError):
        pidx = {}

    def whole(ex):
        """The 500-mile layer has ALL of this state only if every corner of it is inside that layer's radius."""
        bb = regional_pois.STATES.get(ex)
        if not bb or not pidx.get("radius") or ex not in (pidx.get("states") or {}):
            return False
        return all(_mi(pidx["lat"], pidx["lon"], la, lo) <= pidx["radius"] for la in (bb[0], bb[2]) for lo in (bb[1], bb[3]))
    osmium = None
    need.sort(key=lambda ex: not whole(ex))   # reuse what is already on the drive first
    for n, ex in enumerate(need, 1):
        cf = os.path.join(cache, ex + ".json")
        try:
            if json.load(open(cf, encoding="utf-8")).get("sig") == sig:
                continue
        except (OSError, ValueError):
            pass
        rows = None
        js500 = os.path.join(p500, ex + ".js")
        if whole(ex) and os.path.exists(js500):               # already read in full for the 500-mile layer: reuse it
            t = open(js500, encoding="utf-8").read()
            data = json.loads(t[t.index("=", t.index("]=")) + 1:].rstrip().rstrip(";"))
            rows = [{"cat": d[0], "name": d[1], "lat": d[2], "lon": d[3], "addr": d[4], "phone": d[5], "web": d[6],
                     "hours": d[7], "info": d[8]} for d in data]
            print(f"  [{n}/{len(need)}] {ex}: reusing the 500-mile places ({len(rows):,})")
        else:
            if osmium is None:
                osmium = regional_pois.get_osmium(u, dest) or False
                build_pois.osmium = osmium
            if not osmium:
                print(f"  ! {ex}: cannot read OpenStreetMap files without pyosmium - skipped")
                continue
            canada = ex in CANADA
            folder = os.path.join(dest, "OSM-MAP-SOURCE" if canada else os.path.join("tools", "poi-source"))
            os.makedirs(folder, exist_ok=True)
            pbf = os.path.join(folder, ex + ("-latest.osm.pbf" if canada else ".osm.pbf"))
            shared = os.path.join(dest, "OSM-MAP-SOURCE", ex + ".osm.pbf")
            if not os.path.exists(pbf) and os.path.exists(shared):
                pbf = shared
            print(f"  [{n}/{len(need)}] {ex}")
            url = CA_URL.format(ex) if canada else regional_pois.GEOFABRIK.format(ex)
            if not os.path.exists(pbf) and not u.download(url, pbf, os.path.basename(pbf)):
                print(f"  ! {ex}: download failed, will retry next run")
                continue
            t0 = time.time()
            try:
                s, w, nn, e = (CANADA.get(ex) or regional_pois.STATES[ex])
                c_la, c_lo = (s + nn) / 2, (w + e) / 2
                rows = build_pois.read_pbf(pbf, c_la, c_lo, 2500, set(), areas=False)
            except Exception as ex2:  # noqa: BLE001
                print(f"  ! {ex}: {type(ex2).__name__}: {ex2}")
                continue
            print(f"    read in {(time.time() - t0) / 60:.1f} min")
            if not canada and os.path.dirname(pbf) != os.path.join(dest, "OSM-MAP-SOURCE"):
                try:
                    os.remove(pbf)
                except OSError:
                    pass
        keep = {}
        for r in rows:
            if r["cat"] not in KEEP:
                continue
            for key, pts in dense.items():
                start = pts[0]
                off, along = _near(grids[key], r["lat"], r["lon"])
                if off <= ROAD_MILES or _mi(start[0], start[1], r["lat"], r["lon"]) <= CITY_MILES:
                    keep.setdefault(key, []).append([r["cat"], r["name"], r["lat"], r["lon"], r.get("addr", ""), r.get("phone", ""),
                                                     r.get("web", ""), r.get("hours", ""), r.get("info", ""), round(along, 1), round(off, 1)])
        json.dump({"sig": sig, "rows": keep}, open(cf, "w", encoding="utf-8"))
        print(f"    {sum(len(v) for v in keep.values()):,} places kept along the routes")
    # combine the extracts per route
    out = os.path.join(dest, "www", "data", "corridors")
    os.makedirs(out, exist_ok=True)
    total = 0
    for r in routes:
        rows, seen = [], set()
        for ex in need:
            try:
                c = json.load(open(os.path.join(cache, ex + ".json"), encoding="utf-8"))
            except (OSError, ValueError):
                continue
            for row in c["rows"].get(r["key"], []):
                k = (row[0], row[1], round(row[2], 3), round(row[3], 3))
                if k not in seen:
                    seen.add(k)
                    rows.append(row)
        rows.sort(key=lambda x: (x[9], x[10]))
        total += len(rows)
        data = {"label": r["label"], "start": r["line"][0], "home": r["line"][-1], "built": time.strftime("%Y-%m-%d"),
                "missing": [ex for ex in need if not os.path.exists(os.path.join(cache, ex + ".json"))], "rows": rows}
        with open(os.path.join(out, r["key"] + ".js"), "w", encoding="utf-8") as fh:
            fh.write(f'(window.CORRIDOR=window.CORRIDOR||{{}})["{r["key"]}"]=' + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n")
        print(f"  {r['label']}: {len(rows):,} places along the way")
    with open(os.path.join(out, "index.js"), "w", encoding="utf-8") as fh:
        fh.write("window.CORRIDOR_INDEX=" + json.dumps([[r["key"], r["label"], r["line"][0]] for r in routes]) + ";\n")
    return total
