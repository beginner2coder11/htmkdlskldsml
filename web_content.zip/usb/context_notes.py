# -*- coding: utf-8 -*-
"""AI LEARN THE DRIVE (overnight): the drive's own AI reads every page and writes a 1-2 sentence note saying what the
page covers and where it sits in its document ("Contextual Retrieval").

Why: a page cut out of a 300-page manual often never says what it is about ("Step 4: tighten until bleeding stops").
With the note in front of it, search finds it for "tourniquet" and the AI understands it when it is handed that page.
The notes go into ai/memory/knowledge.db; search.db is remade with them at the end of each run.

Order: your library first (medical, survival, disasters, water, food, comms first), then the archive articles.
Resumable: stop any time, run again and it carries on. Works offline. Keeps the computer awake.
Speed depends on the computer: roughly 1-4 seconds a page with the small model on a normal CPU, much faster with a
graphics card — the library takes a night or two, the archives weeks of nights (run it whenever the computer is free).

    python context_notes.py --dest E:\\OFFGRID [--hours 8] [--model Llama-3.2-3B-Instruct-Q4_K_M.gguf]
"""
import argparse, concurrent.futures as cf, glob, json, os, re, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PORT = 8096
MIN_TEXT = 120
PAGE_CHARS = 1400
FIRST = ["Medical", "First Aid", "Survival", "Disasters", "Water", "Food", "Top 20", "Checklists", "Comms", "Radio reference",
         "My Radio Programming", "Home Systems", "Homestead", "Security", "Vehicles", "Military Manuals", "Navigation & Sky"]
PREFER = ["Llama-3.2-3B", "Qwen2.5-3B", "Phi", "gemma-3-4b", "Qwen2.5-7B", "Llama-3.1-8B", "Qwen2.5-14B"]
SKIP = ("embeddinggemma", "reranker", "mmproj", "medgemma", "whisper")
SYS = "You write short index notes for pages of an offline survival library. Plain text, no preamble, no lists."


def pick_model(dest, want=""):
    ms = [m for m in glob.glob(os.path.join(dest, "ai", "models", "*.gguf")) if not any(s in os.path.basename(m).lower() for s in SKIP)]
    if want:
        ms = [m for m in ms if want.lower() in os.path.basename(m).lower()] or ms
    for p in PREFER:                                   # smallest good model first: this job is about speed
        for m in ms:
            if p.lower() in os.path.basename(m).lower():
                return m
    return min(ms, key=os.path.getsize) if ms else None


def _post(prompt, timeout=180):
    body = {"messages": [{"role": "system", "content": SYS}, {"role": "user", "content": prompt}],
            "temperature": 0, "max_tokens": 90, "cache_prompt": True}
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}/v1/chat/completions", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        t = json.load(r)["choices"][0]["message"]["content"]
    t = re.sub(r"\s+", " ", re.sub(r"^(note|index note|summary)\s*:\s*", "", t.strip(), flags=re.I))
    return t[:400]


def prompt_for(d, i, n, text, section):
    return (f"Document: {d[0]}\nLibrary section: {d[2]}\nPage {i + 1} of {n}" + (f" — part: {section}" if section else "")
            + f"\n\nPage text (start):\n{text[:PAGE_CHARS]}\n\n"
            "In one or two sentences (at most 45 words), say what this page covers and where it fits in the document "
            "(chapter or topic). Include the key terms someone would search for.")


def order(docs):
    def k(d):
        zim = str(d[1]).startswith("zim.html")
        cat = d[2] or ""
        pri = next((i for i, c in enumerate(FIRST) if c.lower() in cat.lower()), len(FIRST))
        return (zim, pri, d[4])                       # library before archives; important sections first; short docs first
    return sorted(docs, key=k)


def run(dest, hours=0, want_model=""):
    import ai_memory, semantic, search_db
    from search_cli import Index
    print("AI LEARN THE DRIVE - the drive's AI writes a short note for every page (offline, resumable)\n")
    if not os.path.exists(os.path.join(dest, "www", "search", "docs.js")):
        print("  The search index is not built yet - run REBUILD-SEARCH (or a drive update) first.")
        return
    model = pick_model(dest, want_model)
    binp = semantic.llama_bin(dest)
    gpu = next(iter(glob.glob(os.path.join(dest, "ai", "bin", "win-gpu" if os.name == "nt" else "linux-gpu", "**",
                                           "llama-server.exe" if os.name == "nt" else "llama-server"), recursive=True)), None)
    if not model or not binp:
        print("  No offline AI on this drive yet (the builder's Offline AI step installs it).")
        return
    ix = Index(dest)
    db = ai_memory.connect(dest)
    have = {}
    for doc, page in db.execute("SELECT doc, page FROM context"):
        have.setdefault(doc, set()).add(page)
    docs = order(ix.docs)
    total = sum(d[4] for d in docs)
    done0 = sum(len(v) for v in have.values())
    print(f"  model: {os.path.basename(model)}")
    print(f"  {len(docs):,} documents, {total:,} pages; {done0:,} pages already have notes"
          + (f"; stopping after {hours:g} h" if hours else "; running until finished (close the window to stop)"), flush=True)
    log = open(os.path.join(dest, "REPORTS", "ai-learn-server.log"), "ab")
    threads = max(1, (os.cpu_count() or 2) - 1)

    def start(exe, ngl):
        cmd = [exe, "-m", model, "--host", "127.0.0.1", "--port", str(PORT), "-c", "8192", "--parallel", "2", "-t", str(threads)]
        p = subprocess.Popen(cmd + (["-ngl", "99"] if ngl else []), stdout=log, stderr=log,
                             creationflags=(0x08000000 | 0x00004000) if os.name == "nt" else 0)
        for _ in range(300):
            if semantic._healthy(PORT) or p.poll() is not None:
                break
            time.sleep(1)
        return p
    proc = start(gpu, True) if gpu else None                 # graphics card first (much faster), then the plain build
    if proc is None or not semantic._healthy(PORT):
        if proc:
            proc.kill()
        proc = start(binp, False)
    else:
        print("  using the graphics card")
    semantic._keep_awake(True)
    t0, made, stop = time.time(), 0, ""
    try:
        if not semantic._healthy(PORT):
            print("  ! the AI would not start (see REPORTS\\ai-learn-server.log - not enough memory?)")
            return
        with cf.ThreadPoolExecutor(2) as ex:
            for d in docs:
                if hours and time.time() - t0 > hours * 3600:
                    stop = "time limit reached"
                    break
                done = have.get(d[6], set())
                if len(done) >= d[4]:
                    continue
                try:
                    ix.page_text(d, d[3])
                    pages = ix.texts.get(d[6]) or []
                except Exception:  # noqa: BLE001
                    pages = []
                if len(ix.texts) > 40:
                    ix.texts.clear()
                anchors = d[5] or []
                jobs = []
                for i, t in enumerate(pages):
                    if i in done or len((t or "").strip()) < MIN_TEXT:
                        continue
                    sec = anchors[i] if i < len(anchors) and anchors[i] else ""
                    jobs.append((i, ex.submit(_post, prompt_for(d, i, d[4], t, sec))))
                for i, fut in jobs:
                    try:
                        note = fut.result()
                    except Exception as e:  # noqa: BLE001
                        if proc.poll() is not None:
                            stop = "the AI stopped (see REPORTS\\ai-learn-server.log)"
                            break
                        print(f"\n  ! {d[0][:40]} page {i + 1}: {e}")
                        continue
                    if note:
                        db.execute("INSERT OR REPLACE INTO context VALUES (?,?,?,?,?)",
                                   (d[6], i, note, os.path.basename(model), time.strftime("%Y-%m-%d %H:%M")))
                        made += 1
                    if note and made % 20 == 0:
                        db.commit()
                        el = max(1, time.time() - t0)
                        rate = made / el
                        left = (total - done0 - made) / rate / 3600 if rate else 0
                        print(f"\r  {done0 + made:,}/{total:,} pages have notes  ({rate * 60:,.0f} pages/min; about {left:,.1f} h "
                              f"left for everything) - now: {d[0][:38]:<38}", end="", flush=True)
                db.commit()
                if stop:
                    break
        print()
    except KeyboardInterrupt:
        stop = "stopped"
    finally:
        db.commit()
        db.close()
        semantic._keep_awake(False)
        proc.terminate()
        try:
            proc.wait(20)
        except Exception:  # noqa: BLE001
            proc.kill()
    el = (time.time() - t0) / 3600
    print(f"\n  {made:,} new page notes this run ({el:.1f} h)" + (f" - {stop}" if stop else "") + ".")
    if made:
        print("  Adding the notes to the fast search ...")
        try:
            search_db.rebuild_from_text(dest)
        except Exception as e:  # noqa: BLE001
            print(f"  ! {e} - the next REBUILD-SEARCH adds them")
    with open(os.path.join(dest, "REPORTS", "AI-LEARN-THE-DRIVE.txt"), "a", encoding="utf-8") as fh:
        fh.write(f"{time.strftime('%Y-%m-%d %H:%M')}  +{made:,} page notes in {el:.1f} h ({done0 + made:,}/{total:,} pages)"
                 + (f" - {stop}" if stop else "") + f"  model {os.path.basename(model)}\n")
    try:
        import index_backup
        index_backup.backup(dest)
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--hours", type=float, default=0)
    ap.add_argument("--model", default="")
    a = ap.parse_args()
    run(a.dest, a.hours, a.model)
