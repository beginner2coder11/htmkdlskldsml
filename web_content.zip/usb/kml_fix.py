"""Make KML/KMZ files display correctly in Google Earth Pro.

Two things turn polygons solid white in Google Earth Pro:
  1. files exported from Google Earth web/mobile that use <gx:CascadingStyle kml:id=...> (Pro ignores it);
  2. polygons with no style at all (many NTAD / GIS state-boundary exports).
Your originals are never touched. Fixed copies are written to GOOGLE-EARTH-READY\\ on the drive
(outside www\\, so the map pages don't import them twice).

    python kml_fix.py --dest E:\\OFFGRID
"""
import argparse
import io
import os
import re
import sys
import zipfile

SRC_DIRS = [os.path.join("www", "mymaps"), "MY-MAPS-INBOX", "MY-FILES-INBOX"]
OUT = "GOOGLE-EARTH-READY"
STYLE_ID = "offgrid_default"
STYLE = (f'<Style id="{STYLE_ID}"><LineStyle><color>ff2f6bff</color><width>2</width></LineStyle>'
         '<PolyStyle><color>402f6bff</color><fill>1</fill><outline>1</outline></PolyStyle></Style>\n')
_CASC = re.compile(r'<gx:CascadingStyle\s+(?:kml:)?id="([^"]+)"\s*>(.*?)</gx:CascadingStyle>', re.S)
_PM = re.compile(r"<Placemark\b.*?</Placemark>", re.S)
_GEOM = re.compile(r"<(Polygon|MultiGeometry|LineString|LinearRing)\b")
_DOC = re.compile(r"<Document\b[^>]*>")


def fix_text(t):
    """Return (new_text, changes)."""
    n = 0

    def casc(m):
        nonlocal n
        n += 1
        inner = re.sub(r"<ex:extension>.*?</ex:extension>\s*", "", m.group(2), flags=re.S)
        inner = inner.strip()
        if inner.startswith("<Style>"):
            return f'<Style id="{m.group(1)}">' + inner[len("<Style>"):]
        return f'<Style id="{m.group(1)}">{inner}</Style>'

    t = _CASC.sub(casc, t)
    t = re.sub(r'\bkml:id=', "id=", t)

    added = 0

    def pm(m):
        nonlocal added
        s = m.group(0)
        if "<styleUrl" in s or re.search(r"<Style[\s>]", s):
            return s
        g = _GEOM.search(s)
        if not g:
            return s
        added += 1
        return s[:g.start()] + f"<styleUrl>#{STYLE_ID}</styleUrl>" + s[g.start():]

    t2 = _PM.sub(pm, t)
    if added:
        d = _DOC.search(t2)
        if d:
            t2 = t2[:d.end()] + "\n" + STYLE + t2[d.end():]
            t, n = t2, n + added
        else:
            n += 0   # no <Document> to hold the shared style: leave unstyled placemarks alone
    return t, n


def _fix_kmz(data):
    zin = zipfile.ZipFile(io.BytesIO(data))
    buf = io.BytesIO()
    changes = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            b = zin.read(it.filename)
            if it.filename.lower().endswith(".kml"):
                new, c = fix_text(b.decode("utf-8", "replace"))
                changes += c
                b = new.encode("utf-8")
            zout.writestr(it, b)
    return buf.getvalue(), changes


def run(dest):
    out = os.path.join(dest, OUT)
    done = fixed = 0
    print("\n==> Google Earth Pro copies of your KML/KMZ files (white-polygon fix)", flush=True)
    seen = set()
    for rel in SRC_DIRS:
        root = os.path.join(dest, rel)
        for dp, _, fs in os.walk(root):
            for f in fs:
                if not f.lower().endswith((".kml", ".kmz")):
                    continue
                p = os.path.join(dp, f)
                key = (f.lower(), os.path.getsize(p))
                if key in seen:
                    continue
                seen.add(key)
                done += 1
                dst = os.path.join(out, f)
                if os.path.exists(dst) and os.path.getmtime(dst) >= os.path.getmtime(p):
                    fixed += 1
                    continue
                try:
                    raw = open(p, "rb").read()
                    if f.lower().endswith(".kmz"):
                        data, c = _fix_kmz(raw)
                    else:
                        s, c = fix_text(raw.decode("utf-8", "replace"))
                        data = s.encode("utf-8")
                except (OSError, zipfile.BadZipFile) as e:
                    print(f"  ! {f}: {e}")
                    continue
                if c:
                    os.makedirs(out, exist_ok=True)
                    with open(dst, "wb") as fh:
                        fh.write(data)
                    fixed += 1
    print(f"  {done} KML/KMZ file(s) checked; {fixed} Google Earth Pro-ready copies in {OUT}\\")
    return fixed


def build(u, dest):
    u.say("Google Earth Pro copies of your KML/KMZ files")
    return run(dest)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dest", required=True)
    run(ap.parse_args().dest)
