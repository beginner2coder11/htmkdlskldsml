/* Instant answers: match a typed question to the ready-made situations and quick-response cards (no AI needed).
   Needs scen-data.js and quick-data.js first. window.INSTANT.match(q) -> {sc:[{t,call,s,l,id}], qt:[{t,first,drive,src}]} */
window.INSTANT=(function(){
var SYN={bleed:"bleeding blood wound tourniquet hemorrhage",cut:"wound laceration bleeding",hurt:"injury wound first aid",injured:"injury wound trauma first aid",broken:"fracture splint",bone:"fracture splint",fever:"illness infection fever",sick:"illness fever medicine",kid:"child children pediatric",baby:"infant baby newborn",outage:"blackout power grid",electricity:"power blackout generator solar",lights:"power blackout",freezing:"cold hypothermia winter",frozen:"cold winter pipes",hot:"heat",thirsty:"water drinking",creek:"water purify stream",drink:"water purify",food:"food stockpile calories",hungry:"food foraging hunting",gas:"fuel gasoline propane",petrol:"fuel gasoline",lost:"navigation compass",gps:"navigation",phone:"communications radio",cell:"communications radio",radio:"radio channel frequency",signal:"signal whistle mirror flashlight ground air",defend:"self defense awareness",protect:"self defense safe room family plan",bomb:"nuclear detonation",radiation:"fallout radiation nuclear",storm:"storm weather tornado",wind:"tornado hurricane",car:"vehicle",truck:"vehicle",start:"battery starter",sleep:"shelter",house:"home shelter",warm:"heat cold fire",smoke:"fire",leave:"evacuate bag",attack:"security defense",scared:"morale mental health",panic:"morale mental health calm",snake:"snake bite venom",poison:"poison plant toxic",ate:"poison plant toxic",swallowed:"poison toxic ingestion",pill:"medicine overdose poison",plant:"plant poison identify"};
var STOP=new Set("a an and are as at be been by for from has have how i im in is it its of on or our the to was we what when where which who why with do does my me can you your this that there it's i'm won don didn isn wasn can't won't don't just very really need help coming now got".split(" "));
var stem=function(w){return w.length>4?w.replace(/(ing|ed|es|s)$/,""):w};
var tok=function(s){return(s.toLowerCase().match(/[a-z0-9]+/g)||[]).filter(function(w){return w.length>1&&!STOP.has(w)}).map(stem)};
function expand(q){var raw=q.toLowerCase().match(/[a-z0-9]+/g)||[],ex=raw.join(" ");raw.forEach(function(w){if(SYN[w])ex+=" "+SYN[w]});return Array.from(new Set(tok(ex)))}
function kw(text,qs){var k=new Set(tok(text));return qs.reduce(function(a,w){return a+(k.has(w)?1:0)},0)}
function match(q){
 var SC=(window.SCEN_DATA||{SCEN:[]}).SCEN,Q=window.QUICK||{D:{env:[],dur:[],thr:[]}},qs=expand(q||" ");
 if(!q||qs.length<1)return{sc:[],qt:[]};
 var sc=SC.map(function(s){return[kw(s.kw+" "+s.t,qs)*2,s]}).filter(function(r){return r[0]>=4}).sort(function(a,b){return b[0]-a[0]});
 if(sc.length){var b=sc[0][0];sc=sc.filter(function(r){return r[0]>=b*.6})}
 var all=[].concat(Q.D.env,Q.D.dur,Q.D.thr);
 var qt=all.map(function(t){return[kw(t.t+" "+t.s+" "+t.first.join(" "),qs),t]}).filter(function(r){return r[0]>=4}).sort(function(a,b){return b[0]-a[0]});
 return{sc:sc.slice(0,1).map(function(r){return r[1]}),qt:qt.slice(0,1).map(function(r){return r[1]})};
}
return{match:match};
})();
