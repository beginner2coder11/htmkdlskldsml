@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== OFF-GRID SURVIVAL DRIVE - Windows launcher =====
REM Starts the offline AI (llama.cpp), the library/locator web server and the Kiwix archives,
REM then opens the home page. The photo model, medical model and voice input start by themselves
REM the first time you use them. Press a key in this window to stop everything.
cd /d "%~dp0"
title OFF-GRID SURVIVAL DRIVE

set RAMGB=8
for /f %%m in ('powershell -NoProfile -Command "[int]((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB)"') do set RAMGB=%%m

set MODEL=
if exist ai\default-model.txt set /p MODEL=<ai\default-model.txt
if %RAMGB% GEQ 30 if exist ai\large-model.txt set /p MODEL=<ai\large-model.txt
if not "%~1"=="" set MODEL=%~1
set AIBIN=ai\bin\win
set NGL=
set NGLARG=
if exist ai\bin\win-gpu\llama-server.exe (
  set AIBIN=ai\bin\win-gpu
  set NGL=-ngl 99
  set NGLARG=--ngl 99
)
REM v80: pick the model that fits this computer's memory, outage mode, and the AI copy on this computer's disk
set MODELPATH=
set CTX=8192
set THREADS=
set LOCALMODELS=
set LOCALBIN=
set SAY1=
set SAY2=
set SAY3=
set SAY4=
set PICKARG=
if not "%~1"=="" set PICKARG=--model "%~1"
if exist tools\python-win\python.exe if exist tools\ai_pick.py (
  for /f "usebackq tokens=1,* delims==" %%a in (`tools\python-win\python.exe tools\ai_pick.py --dest . --os win %PICKARG%`) do set "%%a=%%b"
)
if defined MODELPATH (
  set NGLARG=
  if defined NGL set NGLARG=--ngl 99
)
if not defined MODELPATH set MODELPATH=ai\models\%MODEL%
set THR=
if defined THREADS set THR=-t %THREADS%
set EXTRA=
if defined LOCALMODELS set EXTRA=--models-local "%LOCALMODELS%"
if /i "%OFFGRID_MODE%"=="outage" set EXTRA=%EXTRA% --lean
set WHISPER=ai\whisper\win\whisper-server.exe
if not exist %WHISPER% set WHISPER=ai\whisper\win\server.exe

set ALREADY=
powershell -NoProfile -Command "try{(Invoke-WebRequest -UseBasicParsing http://localhost:8090/status -TimeoutSec 2)|Out-Null;exit 0}catch{exit 1}" >nul 2>&1
if %errorlevel%==0 set ALREADY=1
if defined ALREADY goto openwindow

echo.
echo  OFF-GRID SURVIVAL DRIVE      (this computer: %RAMGB% GB RAM)
echo  -----------------------
if defined SAY1 echo  %SAY1%
if defined SAY2 echo  %SAY2%
if defined SAY3 echo  %SAY3%
if defined SAY4 echo  %SAY4%
if defined MODEL if exist "%AIBIN%\llama-server.exe" (
  echo  Starting AI model %MODEL% ...
  start "offgrid-ai" /min "%AIBIN%\llama-server.exe" -m "%MODELPATH%" --host 0.0.0.0 --port 8080 -c %CTX% %NGL% %THR%
) else (
  echo  AI not found on this drive - skipping.
)

if exist tools\python-win\python.exe (
  start "offgrid-web" /min tools\python-win\python.exe tools\serve_usb.py --dir www --port 8090 --ai-bin "%AIBIN%\llama-server.exe" --models ai\models --roles ai\roles.json --whisper "%WHISPER%" --whisper-model ai\whisper\ggml-base.en.bin %NGLARG% %EXTRA%
) else (
  echo  Portable Python missing - opening pages as files instead.
)

if exist kiwix\bin\win\kiwix-serve.exe (
  setlocal enabledelayedexpansion
  set ZIMS=
  for %%z in (kiwix\zim\*.zim) do set ZIMS=!ZIMS! "%%z"
  if not "!ZIMS!"=="" start "offgrid-kiwix" /min kiwix\bin\win\kiwix-serve.exe --skipInvalid --port 8091 !ZIMS!
  endlocal
)

:openwindow
set URL=http://localhost:8090/command.html
if not exist tools\python-win\python.exe set URL=file:///%~dp0www/command.html

REM wait (up to 25 s) until the drive's web server answers, instead of guessing
if not defined ALREADY for /l %%i in (1,1,25) do (
  powershell -NoProfile -Command "try{(Invoke-WebRequest -UseBasicParsing http://localhost:8090/status -TimeoutSec 1)|Out-Null;exit 0}catch{exit 1}" >nul 2>&1
  if not errorlevel 1 goto serverup
  timeout /t 1 /nobreak >nul
)
:serverup

REM find a browser that can open the Command Center as its own app window (Edge ships with Windows 10 and 11)
set APPEXE=
for %%p in ("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe") do if not defined APPEXE if exist %%p set APPEXE=%%~p

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do set IP=%%a
echo.
echo  COMMAND CENTER:  %URL%
echo  From phones on the same Wi-Fi:  http://%IP: =%:8090/command.html
echo     (phones can install the offline apps from the "Phone apps" page)
echo  AI chat:     http://localhost:8080      Archives: http://localhost:8091
echo  Other AI apps (Jan, AnythingLLM, Open WebUI): Base URL http://%IP: =%:8080/v1   (see Command Center ^> Connect AI apps)
echo  (Allow access if Windows Firewall asks. The AI takes 10-60 s to load the model.)
echo.

if defined ALREADY if /i "%OFFGRID_MODE%"=="outage" echo  The drive is already running in normal mode. To switch to OUTAGE MODE close the Command Center window first, then run OUTAGE MODE again.
if defined ALREADY (
  echo  The drive is already running. Opening another Command Center window...
  if defined APPEXE ( start "" "%APPEXE%" --app="%URL%" --user-data-dir="%LOCALAPPDATA%\OFFGRID-window" --window-size=1360,900 --no-first-run --no-default-browser-check ) else ( start "" "%URL%" )
  exit /b 0
)

if defined APPEXE (
  echo  The Command Center is open in its own window.
  echo  CLOSE THAT WINDOW to stop everything and safely remove the drive.
  start "" /wait "%APPEXE%" --app="%URL%" --user-data-dir="%LOCALAPPDATA%\OFFGRID-window" --window-size=1360,900 --no-first-run --no-default-browser-check
  goto stopall
)

start "" "%URL%"
echo  Press any key to STOP everything and safely remove the drive...
pause >nul

:stopall
echo  Stopping the drive...
taskkill /fi "WINDOWTITLE eq offgrid-web*" /f >nul 2>&1
taskkill /im llama-server.exe /f >nul 2>&1
taskkill /im whisper-server.exe /f >nul 2>&1
taskkill /im server.exe /f >nul 2>&1
taskkill /im kiwix-serve.exe /f >nul 2>&1
echo  Stopped. You can now eject the drive.
timeout /t 3 >nul
