@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM Adds a monthly reminder on THIS computer (1st of each month, 7 PM). If the OFF-GRID drive is
REM plugged in, it offers to run the update right away. To remove it: SET-MONTHLY-REMINDER-WINDOWS.bat off
set DIR=%LOCALAPPDATA%\OffGridDrive
if /i "%~1"=="off" (
  schtasks /delete /tn "OffGrid Drive Monthly Update" /f
  echo  Reminder removed.
  pause & exit /b
)
if not exist "%DIR%" mkdir "%DIR%"
copy /y "%~dp0tools\offgrid-reminder.ps1" "%DIR%\offgrid-reminder.ps1" >nul
schtasks /create /tn "OffGrid Drive Monthly Update" /sc monthly /d 1 /st 19:00 /f /tr "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%DIR%\offgrid-reminder.ps1\""
echo.
echo  Monthly reminder set (1st of every month at 7 PM). To remove it run:  SET-MONTHLY-REMINDER-WINDOWS.bat off
pause
