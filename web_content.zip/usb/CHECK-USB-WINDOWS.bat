@echo off
REM Checks the OFF-GRID USB drive and lists what installed and what is missing.
REM Add  --test-ai  after the drive letter prompt option to also start the AI and ask it a question.
cd /d "%~dp0"
set /p DRV=Type the USB drive letter (for example E): 
set DRV=%DRV::=%
set PY=%DRV%:\OFFGRID\tools\python-win\python.exe
if not exist "%PY%" set PY=python
set /p AIT=Also test the AI? It takes 1-3 minutes (y/n): 
set EXTRA=
if /i "%AIT%"=="y" set EXTRA=--test-ai
"%PY%" "%~dp0check_usb.py" --dest %DRV%:\OFFGRID %EXTRA%
echo.
echo Report saved as %DRV%:\OFFGRID\CHECK-REPORT.txt
pause
