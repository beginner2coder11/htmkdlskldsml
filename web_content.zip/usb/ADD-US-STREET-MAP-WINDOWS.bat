@echo off
REM Add a WHOLE-US street map layer to the drive's map, streamed out of the Protomaps planet build.
REM You do NOT need your downloaded .pbf files for this. It's a large download (tens of GB) and resumable.
REM Optional: pass the drive letter, e.g.  ADD-US-STREET-MAP-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
echo.
echo  Adding a whole-US street map layer to %DRIVE%:\OFFGRID  (nothing else will download)
echo  Large download (tens of GB). You can close this and re-run it anytime.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --us-map-only
pause
