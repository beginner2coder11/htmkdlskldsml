"""One place for every "could not fetch" list: REPORTS\\NOT-FETCHED-<topic>.txt (never inside a content folder)."""
import os

LEGACY = ["www/library/State Highway Maps/NOT-FETCHED.txt", "www/library/Commandants Reading List/NOT-FETCHED.txt",
          "www/library/Joint & Service Doctrine/NOT-FETCHED.txt"]


def not_fetched(dest, topic):
    """Path of the report for a topic (REPORTS created); also removes that topic's old in-folder copy."""
    rep = os.path.join(dest, "REPORTS")
    os.makedirs(rep, exist_ok=True)
    return os.path.join(rep, f"NOT-FETCHED-{topic}.txt")


def drop_legacy(dest, rel):
    p = os.path.join(dest, *rel.split("/"))
    try:
        if os.path.isfile(p):
            os.remove(p)
    except OSError:
        pass


def readable(dest, paths):
    """Drop files Windows cannot read (a damaged file system entry, error 1392) and list them in REPORTS\\UNREADABLE-FILES.txt,
    so one damaged file can't stop OCR or the search index. Fix the drive with:  chkdsk E: /f"""
    import os, time
    ok, bad = [], []
    for f in paths:
        try:
            os.stat(f)
            ok.append(f)
        except OSError as e:
            bad.append((f, e))
    rp0 = os.path.join(dest, "REPORTS", "UNREADABLE-FILES.txt")
    if not bad and os.path.exists(rp0):
        try:
            os.remove(rp0)                               # fixed (chkdsk ran): clear the old report
        except OSError:
            pass
    if bad:
        try:
            rp = os.path.join(dest, "REPORTS", "UNREADABLE-FILES.txt")
            os.makedirs(os.path.dirname(rp), exist_ok=True)
            with open(rp, "w", encoding="utf-8", newline="\r\n") as fh:
                fh.write(f"FILES WINDOWS COULD NOT READ - {time.strftime('%Y-%m-%d %H:%M')}\n"
                         "The drive's file system is damaged here (often after the drive disconnected while writing).\n"
                         "Fix: close everything using the drive, open Command Prompt as administrator and run   chkdsk E: /f\n"
                         "(use your drive letter). Then run the builder again: missing downloads are fetched again.\n\n")
                fh.writelines(f"{f}\n    {e}\n" for f, e in bad)
        except OSError:
            pass
        print(f"  ! {len(bad)} file(s) on the drive are damaged and unreadable - skipped; see REPORTS\\UNREADABLE-FILES.txt "
              "(fix with  chkdsk <drive>: /f )")
    return ok
