﻿"""Convert OpenStreetMap .pbf extracts you downloaded into offline map layers (pmtiles).

Drop any `*.osm.pbf` files into the  OSM-MAP-SOURCE  folder at the top of the drive. On the next build (or
run CONVERT-OSM-MAPS-WINDOWS.bat) this converts each one with Planetiler into www/map/<name>.pmtiles and
registers it as a selectable base layer in the locator map - fully scrollable/zoomable, offline.

Needs Java (a small portable runtime is downloaded into tools/java the first time) and planetiler.jar.
Big files take a while and a lot of temp space; it's resumable (a finished .pmtiles is skipped).
Only the standard library here; the heavy lifting is Planetiler.
"""
import json, os, tempfile, platform, re, shutil, subprocess, tarfile, time, zipfile

SRC = "OSM-MAP-SOURCE"


def _ram_gb():
    """(total, available) RAM in GB, available None if unknown. Stdlib only, best-effort per platform."""
    try:
        if platform.system() == "Windows":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(m)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys / 1e9, m.ullAvailPhys / 1e9
        if platform.system() == "Linux":
            info = {}
            for line in open("/proc/meminfo"):
                k, _, v = line.partition(":")
                info[k] = int(v.split()[0]) * 1024
            return info.get("MemTotal", 0) / 1e9, info.get("MemAvailable") and info["MemAvailable"] / 1e9
        if platform.system() == "Darwin":
            total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]).strip()) / 1e9
            return total, None
    except Exception:  # noqa: BLE001
        pass
    return 0.0, None


def _plan_resources():
    """Pick a Java heap size and thread count that fit this computer (mmap storage offloads the rest to disk)."""
    total, avail = _ram_gb()
    base = avail if avail else (total or 8)
    heap = int(max(2, min(base * 0.6, 24)))          # leave room for the OS and the mmap page cache
    threads = 3 if total and total < 8 else 6 if total and total < 16 else 8
    return heap, threads, total, avail
README = ("Drop OpenStreetMap extracts here to turn them into offline map layers.\r\n\r\n"
          "* Put *.osm.pbf files in this folder (for example us.osm.pbf, canada.osm.pbf).\r\n"
          "* Then run the builder, or double-click CONVERT-OSM-MAPS-WINDOWS.bat.\r\n"
          "* Each file becomes a layer in the Locator map (Show map -> layer control, top right).\r\n\r\n"
          "Raw .osm (XML) files are NOT converted here - convert them to .osm.pbf first. The whole-planet\r\n"
          "file is far too big; use country/region .pbf extracts (Geofabrik) instead.\r\n")


def _unpack_jre(archive, dest):
    """Unpack a full JRE and return the path to its java executable (keeps the whole runtime tree)."""
    tmp = dest + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        (zipfile.ZipFile(archive).extractall if archive.endswith(".zip")
         else (lambda d: tarfile.open(archive).extractall(d)))(tmp)
    except Exception:  # noqa: BLE001
        shutil.rmtree(tmp, ignore_errors=True)
        return None
    exe = "java.exe" if platform.system() == "Windows" else "java"
    for root, _, files in os.walk(tmp):
        if exe in files and os.path.basename(root) == "bin":
            shutil.rmtree(dest, ignore_errors=True)
            shutil.move(os.path.dirname(root), dest)       # move the JRE root (parent of bin)
            shutil.rmtree(tmp, ignore_errors=True)
            return os.path.join(dest, "bin", exe)
    shutil.rmtree(tmp, ignore_errors=True)
    return None


def _java_and_jar(u, dest):
    """Ensure a portable JRE and planetiler.jar are present. Returns (java_exe, jar) or (None, None)."""
    tools = os.path.join(dest, "tools")
    jdir = os.path.join(tools, "java")
    exe = "java.exe" if platform.system() == "Windows" else "java"
    java = os.path.join(jdir, "bin", exe)
    if not os.path.exists(java):
        osn = {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}[platform.system()]
        arch = "aarch64" if platform.machine().lower() in ("arm64", "aarch64") else "x64"
        url = f"https://api.adoptium.net/v3/binary/latest/21/ga/{osn}/{arch}/jre/hotspot/normal/eclipse"
        arc = os.path.join(jdir, "jre.zip" if osn == "windows" else "jre.tgz")
        os.makedirs(jdir, exist_ok=True)
        print("  getting a small Java runtime (one-time, ~45 MB)...")
        if not u.download(url, arc, "Java runtime"):
            print("  ! could not download Java - skipping OSM conversion"); return None, None
        java = _unpack_jre(arc, jdir)
        try:
            os.remove(arc)
        except OSError:
            pass
        if not java or not os.path.exists(java):
            print("  ! could not unpack Java - skipping OSM conversion"); return None, None
        if platform.system() != "Windows":
            os.chmod(java, 0o755)
    jar = os.path.join(tools, "planetiler.jar")
    if not os.path.exists(jar):
        asset = u.gh_asset("onthegomap/planetiler", r"planetiler\.jar$")
        if not asset or not u.download(asset[1], jar, "Planetiler"):
            print("  ! could not download Planetiler - skipping OSM conversion"); return None, None
    return java, jar


BASE_FILES = {   # Planetiler's base datasets; fetched ourselves (resumable, retried) because its own size check times out
    "water-polygons-split-3857.zip": "https://osmdata.openstreetmap.de/download/water-polygons-split-3857.zip",
    "natural_earth_vector.sqlite.zip": "https://naciscdn.org/naturalearth/packages/natural_earth_vector.sqlite.zip",
}


# Tiny Monaco-only stand-in (valid format). Used only when the real ocean file's server is down: maps still build,
# just without ocean fill (lakes/rivers/coast lines come from OpenStreetMap itself). The real file replaces it later.
WATER_STUBS = ["https://github.com/onthegomap/planetiler/raw/main/planetiler-core/src/test/resources/water-polygons-split-3857.zip",
               "https://cdn.jsdelivr.net/gh/onthegomap/planetiler@main/planetiler-core/src/test/resources/water-polygons-split-3857.zip"]


def _prefetch_bases(u, srcdir):
    """Returns (all_cached, water_path_override). water_path_override is set only when the stand-in is used."""
    ok, water_override = True, None
    for name, url in BASE_FILES.items():
        path = os.path.join(srcdir, name)
        if os.path.exists(path) and os.path.getsize(path) > 0:
            continue
        for _ in range(2):
            if u.download(url, path, name, retries=3):
                break
            time.sleep(10)
        else:
            if name.startswith("water-polygons"):
                stub = os.path.join(srcdir, "water-polygons-STUB.zip")
                if any(u.download(w, stub, "water-polygons stand-in") for w in WATER_STUBS):
                    print("  ! ocean-polygon server unreachable: using a small stand-in (no ocean fill). "
                          "Re-run later and these maps are rebuilt with the real file.")
                    water_override = stub
                    continue
            ok = False
    return ok, water_override


def _drop_source(pbf, out, clean):
    """--delete-osm-source: remove a source .pbf once its finished, non-empty map layer exists."""
    if clean and os.path.exists(out) and os.path.getsize(out) > 1e6:
        try:
            gb = os.path.getsize(pbf) / 1e9
            os.remove(pbf)
            print(f"    removed source {os.path.basename(pbf)} ({gb:.1f} GB freed)")
        except OSError as ex:
            print(f"    ! could not remove {os.path.basename(pbf)}: {ex}")


def _layer_name(fn):
    stem = re.sub(r"\.osm\.pbf$|\.pbf$", "", fn, flags=re.I)
    stem = re.sub(r"[-_]?\d{6,8}$", "", stem)              # drop a trailing date stamp
    words = [w for w in re.split(r"[-_ ]+", stem.strip()) if w]
    return " ".join(w.upper() if w.lower() in ("us", "usa", "uk", "nw", "ne", "sw", "se") else w.title()
                    for w in words) or stem


def build(u, dest, clean=False):
    src_dir = os.path.join(dest, SRC)
    os.makedirs(src_dir, exist_ok=True)
    rp = os.path.join(src_dir, "READ-ME.txt")
    if not os.path.exists(rp):
        open(rp, "w", encoding="utf-8", newline="").write(README)
    pbfs = sorted(f for f in os.listdir(src_dir) if f.lower().endswith((".osm.pbf", ".pbf")))
    if not pbfs:
        return                                             # nothing to do; silent no-op
    u.say(f"Converting {len(pbfs)} OpenStreetMap file(s) into offline map layers (Planetiler)")
    java, jar = _java_and_jar(u, dest)
    if not java or not jar:
        return
    mapdir = os.path.join(dest, "www", "map")
    os.makedirs(mapdir, exist_ok=True)
    tmpdir = os.path.join(dest, "tools", "planetiler-tmp")
    big = max(os.path.getsize(os.path.join(src_dir, f)) for f in pbfs)
    try:                          # random-access scratch files are 10-50x faster on the computer's own disk than on a USB drive
        loc = os.path.join(os.environ.get("OFFGRID_TMP") or tempfile.gettempdir(), "offgrid-planetiler-tmp")
        os.makedirs(loc, exist_ok=True)
        if shutil.disk_usage(loc).free > big * 4 + 20e9:
            tmpdir = loc
            print(f"  scratch space: {loc} (fast local disk; deleted afterwards)")
        else:
            print("  scratch space: on the drive (the computer's disk lacks room) ? big extracts will be SLOW; "
                  "use smaller regional .pbf files or set OFFGRID_TMP to a fast disk with ~4x the file size free.")
    except OSError:
        pass
    os.makedirs(tmpdir, exist_ok=True)
    srcdir = os.path.join(dest, "tools", "planetiler-sources")   # base shapefiles (water, lakes, natural earth)
    os.makedirs(srcdir, exist_ok=True)                           # fetched once, then reused by every conversion
    have_bases, water_stub = _prefetch_bases(u, srcdir)
    heap, threads, total, avail = _plan_resources()
    print(f"  computer: {total:.0f} GB RAM" + (f" ({avail:.0f} GB free)" if avail else "")
          + f" - giving Java {heap} GB and {threads} threads. Close other big apps for the fastest, safest run.")
    layers = []
    for fn in pbfs:
        pbf = os.path.join(src_dir, fn)
        stem = re.sub(r"\.osm\.pbf$|\.pbf$", "", fn, flags=re.I)
        slug = re.sub(r"[^a-z0-9]+", "-", stem.lower()).strip("-")
        out = os.path.join(mapdir, slug + ".pmtiles")
        name = _layer_name(fn)
        mark = out + ".stub"       # built with the ocean stand-in: redo once the real file is available
        if os.path.exists(mark) and not water_stub:
            os.remove(mark)
            os.remove(out) if os.path.exists(out) else None
        if os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(pbf):
            print(f"  {name}: already converted"); layers.append({"name": name, "file": slug + ".pmtiles"})
            _drop_source(pbf, out, clean)
            continue
        if os.path.getsize(pbf) > 8e9:
            print(f"  ! {name}: {os.path.getsize(pbf)/1e9:.0f} GB is a whole-continent file ? expect many hours/days on one PC. "
                  "Regional extracts (Geofabrik state/province files) convert in minutes.")
        print(f"  {name}: converting {fn} ({os.path.getsize(pbf) / 1e9:.1f} GB) - this can take a while...")
        part = os.path.join(mapdir, slug + ".tmp.pmtiles")

        def run(h, th):
            # With every base file already on disk, skip --download so Planetiler never needs the (often
            # unreachable) size check against the base-data servers.
            dl = ["--download"] if not have_bases else []
            if water_stub:
                dl = dl + ["--water-polygons-path=" + water_stub]
            cmd = [java, f"-Xmx{h}g", "-jar", jar, "--osm-path=" + pbf, "--output=" + part, "--force",
                   "--tmpdir=" + tmpdir, *dl, "--download-dir=" + srcdir,
                   "--storage=mmap", "--nodemap-storage=mmap", f"--threads={th}",
                   "--http-timeout=600s", "--http-retries=8",   # base-file servers can be slow to even report size
                   "--download-osm-tile-weights=false"]
            return subprocess.call(cmd) == 0 and os.path.exists(part)

        okrun = run(heap, threads)
        if not okrun and have_bases:
            have_bases = False                       # a base file we didn't cache is needed: let Planetiler fetch it
            okrun = run(heap, threads)
        if not okrun and heap > 2:                   # out of memory? retry once lean: small heap, few threads
            print(f"  {name}: first attempt failed - retrying in low-memory mode (2 GB, 2 threads, slower)...")
            try:
                os.remove(part)
            except OSError:
                pass
            okrun = run(2, 2)
        if okrun:
            os.replace(part, out)
            if water_stub:
                open(mark, "w").close()
            layers.append({"name": name, "file": slug + ".pmtiles"})
            shutil.rmtree(tmpdir, ignore_errors=True) if tmpdir != os.path.join(dest, "tools", "planetiler-tmp") else None
            print(f"  {name}: done ({os.path.getsize(out) / 1e9:.1f} GB)")
            if not water_stub:
                _drop_source(pbf, out, clean)
        else:
            print(f"  ! {name}: conversion failed (re-run to retry). Close other apps first; a very large extract "
                  "(like the whole US) needs several GB of free RAM and lots of free disk.")
            try:
                os.remove(part)
            except OSError:
                pass
    shutil.rmtree(tmpdir, ignore_errors=True)
    with open(os.path.join(mapdir, "osm-layers.json"), "w", encoding="utf-8") as fh:
        json.dump(layers, fh)
    print(f"  {len(layers)} OSM layer(s) available in the map")
