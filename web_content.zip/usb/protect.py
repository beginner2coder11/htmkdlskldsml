#!/usr/bin/env python3
"""Soft-lock the drive's critical engine files read-only (a guard against ACCIDENTS), or unlock them.

  python protect.py --dest E:\\OFFGRID            # lock (read-only)
  python protect.py --dest E:\\OFFGRID --unlock   # unlock before Update / Add / Build

This only marks the launchers, the web pages/config and the engine folders (tools, builder) read-only so they
can't be edited by accident and give a warning before deletion. It deliberately skips the big content
(archives, AI models, library, media) — those are large, re-downloadable, and not something you edit by hand.

Honest limits: a USB drive (especially exFAT, needed for phones) can't carry unbreakable permissions, read-only
marks don't reliably survive a copy to another device, and anyone can override them. The real safety net is
Check/Doctor + Update + keeping a second copy. For truly sensitive files use the VeraCrypt family vault.
"""
import argparse, os

CRITICAL_FILES = ["START-HERE.bat", "start-here-mac-linux.sh", "READ-ME-FIRST.html", "DASHBOARD.html",
                  "USE-ON-PHONE.html", "HOW-TO-USE-THIS-DRIVE.txt"]
CRITICAL_DIRS = ["PROGRAMS", "tools/python-win", "tools/builder"]


def _apply(path, lock):
    try:
        m = os.stat(path).st_mode
        os.chmod(path, (m & ~0o222) if lock else (m | 0o200))   # on Windows this toggles the read-only attribute
        return True
    except OSError:
        return False


def _targets(dest):
    for f in CRITICAL_FILES:
        p = os.path.join(dest, f)
        if os.path.isfile(p):
            yield p
    for d in CRITICAL_DIRS:
        base = os.path.join(dest, *d.split("/"))
        for r, _, fs in os.walk(base) if os.path.isdir(base) else []:
            for f in fs:
                yield os.path.join(r, f)
    tools = os.path.join(dest, "tools")                          # loose scripts directly in tools\
    if os.path.isdir(tools):
        for f in os.listdir(tools):
            if f.endswith((".py", ".ps1")) and os.path.isfile(os.path.join(tools, f)):
                yield os.path.join(tools, f)
    www = os.path.join(dest, "www")                              # entry pages + config at the top of www\
    if os.path.isdir(www):
        for f in os.listdir(www):
            if f.endswith((".html", ".js")) and os.path.isfile(os.path.join(www, f)):
                yield os.path.join(www, f)


def main():
    ap = argparse.ArgumentParser(description="Soft-lock (read-only) or unlock the drive's critical files.")
    ap.add_argument("--dest", required=True)
    ap.add_argument("--unlock", action="store_true", help="remove the read-only mark (do this before Update/Add/Build)")
    a = ap.parse_args()
    lock = not a.unlock
    n = ok = 0
    for p in _targets(a.dest):
        n += 1
        ok += _apply(p, lock)
    verb = "Locked (read-only)" if lock else "Unlocked"
    print(f"\n  {verb} {ok} of {n} critical files.")
    if lock:
        print("  These are now a guard against accidental edits/deletes. Run this with --unlock (UNPROTECT-FILES)")
        print("  before you Update, Add files or Build — then run PROTECT-FILES again afterward.")
    else:
        print("  You can now Update / Add / Build. Run PROTECT-FILES again when you're done to re-lock them.")
    print("  Note: this is an accident guard only — it does not travel reliably to other drives/phones, and")
    print("  anyone can override it. Your real safety net is Check/Doctor + Update + a second copy.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
