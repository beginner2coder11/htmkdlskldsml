#!/bin/sh
# ===== Search the whole drive in a terminal - no web browser, no server, no internet (Mac / Linux) =====
# Run:  sh /path/to/OFFGRID/search-no-browser.sh  [words]
cd "$(dirname "$0")" || exit 1
for PY in python3 python; do
  if command -v "$PY" >/dev/null 2>&1 && "$PY" -c "import sys; sys.exit(sys.version_info < (3, 6))" 2>/dev/null; then
    exec "$PY" tools/builder/usb/search_cli.py --dest "$(pwd)" "$@"
  fi
done
echo "No Python 3 here - using grep on the plain-text copies in TEXT-ONLY/."
while :; do
  printf '\nSearch words (Enter alone to quit): '; read -r Q || exit 0
  [ -z "$Q" ] && exit 0
  grep -ril -- "$Q" TEXT-ONLY | sort
  echo "  Read one with:  less \"TEXT-ONLY/<folder>/<file>.txt\"   (type /word to jump, q to quit)"
done
