"""Extra build steps for the OFF-GRID SURVIVAL USB (called from usb_builder.py).

  topo_pdfs     USGS US Topo 7.5-minute GeoPDF quads around home (print or open in any PDF app / Avenza)
  tiles         USGS Topo + shaded-relief map tiles for the locator map (works offline in the browser)
  flood_zones   FEMA flood hazard areas (100-yr / 500-yr / floodway) as a map overlay
  phone_apps    Android installers (OsmAnd, Organic Maps, Kiwix, Meshtastic, ATAK-CIV, F-Droid),
                OsmAnd state maps and Meshtastic firmware — served to phones from the drive
  vault_tools   VeraCrypt (Windows portable, macOS, Ubuntu) for the encrypted family-document vault
  voice         whisper.cpp speech-to-text server + English model (Windows, Linux)
  kiwix_big     Full Wikipedia with images, Project Gutenberg, Khan Academy, Wikibooks (largest files)

All public-domain / openly licensed sources. Every step is resumable: finished files are skipped.
"""
import concurrent.futures as cf, glob, html, json, math, os, re, shutil, threading, time, urllib.error, urllib.parse, urllib.request, zipfile

_VANISHED = []   # quads that downloaded and wrote successfully but were removed right after (external deletion)


def _box(lat, lon, miles):
    dl, dn = miles / 69.0, miles / (69.17 * math.cos(math.radians(lat)))
    return lon - dn, lat - dl, lon + dn, lat + dl          # west, south, east, north


def _miles(lat1, lon1, lat2, lon2):
    r = math.radians
    a = math.sin(r(lat2 - lat1) / 2) ** 2 + math.cos(r(lat1)) * math.cos(r(lat2)) * math.sin(r(lon2 - lon1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(a))


def _bearing(lat1, lon1, lat2, lon2):
    r = math.radians
    y = math.sin(r(lon2 - lon1)) * math.cos(r(lat2))
    x = math.cos(r(lat1)) * math.sin(r(lat2)) - math.sin(r(lat1)) * math.cos(r(lat2)) * math.cos(r(lon2 - lon1))
    return "N NE E SE S SW W NW".split()[int(((math.degrees(math.atan2(y, x)) + 360) % 360 + 22.5) // 45) % 8]


def _page(title, body):
    return ("<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>{html.escape(title)}</title><style>body{{margin:0;font:16px/1.5 system-ui,sans-serif;background:#14171a;color:#e6e8eb}}"
            "main{max-width:980px;margin:0 auto;padding:16px}a{color:#d9a441}h1{font-size:22px}h2{font-size:17px;color:#d9a441;margin-top:26px}"
            "table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid #2c323a;padding:6px;text-align:left}"
            ".dim{color:#9aa3ad;font-size:14px}code{background:#0f1214;padding:1px 5px;border-radius:4px}li{margin:4px 0}</style></head>"
            f"<body><main><p><a href='/home.html'>&larr; Home</a></p><h1>{html.escape(title)}</h1>{body}</main></body></html>")


def _keep_latest(folder, keep):
    """Delete older versions in an app folder after a newer file arrived. Resilient: a locked or read-only
    item (or an older *folder*) is cleared if possible and skipped if not — never crashes the build step."""
    for f in glob.glob(os.path.join(folder, "*")):
        if os.path.basename(f) == keep or f.endswith(".part"):
            continue
        for attempt in (1, 2):
            try:
                shutil.rmtree(f) if os.path.isdir(f) else os.remove(f)
                break
            except OSError:
                try:
                    os.chmod(f, 0o666)     # clear a read-only mark, then retry once
                except OSError:
                    break


# --------------------------------------------------------------------------- USGS topo GeoPDFs
def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "area"


def _tnm(u, bbox, cache, max_age=90):
    """USGS National Map product search for one box -> {title: item}, cached on the drive."""
    if os.path.exists(cache) and not (getattr(u, "UPDATE", False) and (time.time() - os.path.getmtime(cache)) / 86400 > max_age):
        try:
            return json.load(open(cache, encoding="utf-8"))
        except ValueError:
            pass
    w, s, e, n = bbox
    api = "https://tnmaccess.nationalmap.gov/api/v1/products"
    items, offset, total = {}, 0, None
    while total is None or offset < total:
        q = urllib.parse.urlencode({"datasets": "US Topo Current", "bbox": f"{w:.4f},{s:.4f},{e:.4f},{n:.4f}",
                                    "max": 100, "offset": offset, "outputFormat": "JSON"})
        try:
            j = json.loads(u.fetch(f"{api}?{q}", 120))
        except Exception as ex:  # noqa: BLE001
            print(f"  ! USGS National Map API: {str(ex)[:100]}")
            return None
        total = j.get("total", 0)
        batch = j.get("items", [])
        if not batch:
            break
        for it in batch:
            url = it.get("downloadURL") or ""
            if not url.lower().endswith(".pdf"):
                continue
            key = it.get("title", url)
            if key not in items or it.get("publicationDate", "") > items[key].get("publicationDate", ""):
                items[key] = {k: it.get(k) for k in ("title", "downloadURL", "publicationDate", "sizeInBytes", "boundingBox")}
        offset += len(batch)
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    with open(cache, "w", encoding="utf-8") as fh:
        json.dump(items, fh)
    return items


def _quad_path(dest, url, sub=""):
    st = url.rstrip("/").split("/")[-2] if "/PDF/" in url else "other"
    return os.path.join(dest, "www", "topo", *([sub] if sub else []), st, os.path.basename(url))


def _fresh_quad(u, title, bb):
    """Current USGS download URL for a quad whose saved URL was refused (editions get replaced and the
    old S3 key then returns 403/404). Looks it up again by map name within the quad's own bounding box."""
    if not bb:
        return None
    w, s, e, n = bb
    q = urllib.parse.urlencode({"datasets": "US Topo Current",
                                "bbox": f"{w:.4f},{s:.4f},{e:.4f},{n:.4f}", "max": 50, "outputFormat": "JSON"})
    try:
        items = json.loads(u.fetch(f"https://tnmaccess.nationalmap.gov/api/v1/products?{q}", 60)).get("items", [])
    except Exception:  # noqa: BLE001
        return None
    want = (title or "").replace("US Topo 7.5-minute map for ", "").strip().lower()
    best = None
    for it in items:
        url = it.get("downloadURL") or ""
        if not url.lower().endswith(".pdf"):
            continue
        t = it.get("title", "").replace("US Topo 7.5-minute map for ", "").strip().lower()
        if t == want:
            return url
        best = best or url
    return best


def _get_quad(u, url, out, title, bb=None, row=None):
    lbl = title.replace("US Topo 7.5-minute map for ", "Topo: ")[:60]
    ok = u.download(url, out, lbl)
    if not ok and bb:                             # saved URL refused — USGS may have replaced that edition
        fresh = _fresh_quad(u, title, bb)
        if fresh and fresh != url and u.download(fresh, out, lbl):
            ok = True
            if row is not None:
                row["url"] = fresh                # self-correct the catalog so the next run is clean
    if not ok:
        return False
    if not os.path.exists(out):                   # download wrote it, then it was gone a moment later
        _VANISHED.append(out)                     # => an outside process removed it (antivirus / cloud-sync),
        print(f"\n  !! {os.path.basename(out)} downloaded and saved, then VANISHED immediately — "
              f"an outside program deleted it (antivirus or a sync tool), not the builder")
        return False                              # not the builder: download() + os.replace both reported success
    stem = re.sub(r"_\d{8}_TM_geo\.pdf$", "", os.path.basename(out))
    keep = os.path.normpath(out)                  # normalize: rel uses '/', glob returns OS '\' on Windows
    for older in glob.glob(os.path.join(os.path.dirname(out), stem + "_*_TM_geo.pdf")):
        if os.path.normpath(older) != keep and re.fullmatch(re.escape(stem) + r"_\d{8}_TM_geo\.pdf", os.path.basename(older)):
            try:
                os.remove(older)                  # a different (older) edition of this quad — replace it
            except OSError:
                pass
    return True


def _catalog(dest):
    p = os.path.join(dest, "www", "topo", "catalog.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except (OSError, ValueError):
        return {"home": None, "areas": {}}


def _save_catalog(dest, cat):
    os.makedirs(os.path.join(dest, "www", "topo"), exist_ok=True)
    with open(os.path.join(dest, "www", "topo", "catalog.json"), "w", encoding="utf-8") as fh:
        json.dump(cat, fh)
    _topo_index(dest, cat)


def _qrow(dest, it, sub=""):
    url = it["downloadURL"]
    bb = it.get("boundingBox") or {}
    return {"t": it.get("title", "").replace("US Topo 7.5-minute map for ", ""), "url": url,
            "rel": os.path.relpath(_quad_path(dest, url, sub), os.path.join(dest, "www", "topo")).replace(os.sep, "/"),
            "bb": [round(bb.get("minX", 0), 4), round(bb.get("minY", 0), 4), round(bb.get("maxX", 0), 4), round(bb.get("maxY", 0), 4)] if bb else None,
            "gb": (it.get("sizeInBytes") or 6e7) / 1e9}


def _vanished_report():
    """If any quad was deleted right after a successful write, say so plainly and stop quietly failing."""
    if not _VANISHED:
        return
    n = len(_VANISHED)
    print(f"\n  !! {n} topo sheet{'s' if n != 1 else ''} downloaded and saved correctly, then were DELETED by an\n"
          "     outside program within moments of being written. The builder's download succeeded every time;\n"
          "     something on the PC is removing the finished PDFs from the drive. This is almost always\n"
          "     antivirus/security software or a cloud-sync client (OneDrive/Dropbox) watching the drive.\n"
          "     FIX: in your security software, add an EXCLUSION for the whole E:\\OFFGRID folder, then re-run.\n"
          "     If you use a third-party antivirus (Norton, McAfee, Avast, Bitdefender, Malwarebytes, etc.),\n"
          "     check ITS quarantine/history — Windows Defender's history will be empty in that case.")
    _VANISHED.clear()


def _home_items(u, dest, lat, lon, radius):
    """TNM quads for the home area. Up to 100 miles: one box. Larger: a fixed grid of ~100-mile cells centered on
    home (each cached on the drive under the same name whatever the radius, so raising the radius later only
    searches the new outer cells); only quads whose center is inside the circle are kept."""
    q = os.path.join(dest, "www", "topo", "_query")
    if radius <= 100:
        return _tnm(u, _box(lat, lon, radius), os.path.join(q, f"home-{radius:g}.json"))
    dl = 100.0 / 69.0
    dn = 100.0 / (69.17 * math.cos(math.radians(lat)))
    n = math.ceil(radius / 100.0 + 0.5)                          # cells run -n..n around the center cell
    cells = [(iy, ix) for iy in range(-n, n + 1) for ix in range(-n, n + 1)]
    items, failed, k = {}, 0, 0
    for iy, ix in cells:
        cy, cx = lat + iy * dl, lon + ix * dn                     # cell center; cell is +-50 miles around it
        if _miles(lat, lon, cy, cx) > radius + 75:               # cell entirely outside the circle
            continue
        k += 1
        print(f"\r  finding quads: area {k}   ", end="", flush=True)
        got = _tnm(u, (cx - dn / 2, cy - dl / 2, cx + dn / 2, cy + dl / 2), os.path.join(q, f"home-grid-{iy}-{ix}.json"))
        if got is None:
            failed += 1
            if failed >= 5:
                print("\n  ! USGS search keeps failing — will finish the rest on the next run"); break
            continue
        items.update(got)
    print()
    if not items:
        return None
    keep = {}
    for t, it in items.items():
        bb = it.get("boundingBox") or {}
        if not bb:
            keep[t] = it; continue
        d = _miles(lat, lon, (bb.get("minY", 0) + bb.get("maxY", 0)) / 2, (bb.get("minX", 0) + bb.get("maxX", 0)) / 2)
        if d <= radius:
            keep[t] = it
    return keep


def topo_pdfs(u, dest, lat, lon, radius, reserve_gb=None):
    """USGS 7.5-minute topo quads around home (downloaded first, closest first). Over 100 miles it is a true
    circle, and the download stops when only `reserve_gb` of free space is left (default 150 GB for big radii)."""
    if reserve_gb is None:
        reserve_gb = 5 if radius <= 100 else 150
    u.say(f"USGS topographic maps (7.5-minute GeoPDF quads, {radius:g}-mile {'box' if radius <= 100 else 'radius'} around home)")
    items = _home_items(u, dest, lat, lon, radius)
    if not items:
        print("  - no topo quads found (API unreachable?) — re-run later"); return
    rows = []
    for it in items.values():
        r = _qrow(dest, it)
        clat, clon = ((r["bb"][1] + r["bb"][3]) / 2, (r["bb"][0] + r["bb"][2]) / 2) if r["bb"] else (lat, lon)
        r["d"], r["b"] = round(_miles(lat, lon, clat, clon), 1), _bearing(lat, lon, clat, clon)
        rows.append(r)
    rows.sort(key=lambda r: r["d"])
    need = sum(r["gb"] for r in rows if not os.path.exists(os.path.join(dest, "www", "topo", r["rel"])))
    print(f"  {len(rows)} quads, {need:.1f} GB still to download (drive has {u.free_gb(dest):.0f} GB free; "
          f"stops with {reserve_gb:g} GB left)")
    if need > max(0, u.free_gb(dest) - reserve_gb):
        print("  ! Not everything will fit: the closest quads come first and it stops when the reserve is reached.")
    tried = fails = 0
    for r in rows:
        out = os.path.join(dest, "www", "topo", r["rel"])
        if not os.path.exists(out) and u.free_gb(dest) - r["gb"] < reserve_gb:
            print(f"  ! only {reserve_gb:g} GB left free — stopped (closest quads are done first)"); break
        if not os.path.exists(out):
            tried += 1
            if not _get_quad(u, r["url"], out, r["t"], r.get("bb"), r):
                fails += 1
    cat = _catalog(dest)
    cat["home"] = {"lat": lat, "lon": lon, "radius": radius, "quads": rows}
    _save_catalog(dest, cat)
    got = sum(1 for r in rows if os.path.exists(os.path.join(dest, "www", "topo", r["rel"])))
    print(f"  topo maps around home: {got}")
    _vanished_report()
    if rows and got == 0 and fails:
        print("  ! None of the printable topo sheets downloaded. They come from USGS's Amazon S3 server\n"
              "    (prd-tnm.s3.amazonaws.com). The errors just above (lines starting with '!') say why — usually a\n"
              "    firewall, antivirus/security software, VPN, or the ISP blocking that one host. The topo MAP LAYER\n"
              "    on the locator still works; only these downloadable PDF sheets are affected.")


def topo_areas(u, dest, areas, reserve_gb=25):
    """Topo quads for extra areas (bases, cities, lakes). Stored under www/topo/areas/ so a smaller travel
    copy can leave them out. Quads already in the home set are linked, not downloaded twice."""
    u.say(f"USGS topo quads for {len(areas)} more areas (military bases, Southern cities, lakes & coast)")
    cat = _catalog(dest)
    home = {q["t"]: q for q in (cat.get("home") or {}).get("quads", [])}
    have_home = {t for t, q in home.items() if os.path.exists(os.path.join(dest, "www", "topo", q["rel"]))}
    plan, fails = [], 0
    for i, a in enumerate(areas):
        key = _slug(a["group"] + "-" + a["name"])
        print(f"\r  finding quads: {i + 1}/{len(areas)} {a['name'][:50]:<50}", end="", flush=True)
        items = _tnm(u, a["bbox"], os.path.join(dest, "www", "topo", "_query", key + ".json"))
        if items is None:
            fails += 1
            if fails >= 5:
                print("\n  ! USGS search keeps failing — will finish the rest on the next run"); break
            continue
        rows = []
        for it in items.values():
            t = it.get("title", "").replace("US Topo 7.5-minute map for ", "")
            r = home[t] if t in have_home else _qrow(dest, it, "areas")
            r = dict(r)
            if r.get("bb"):
                r["d"] = round(_miles(a["lat"], a["lon"], (r["bb"][1] + r["bb"][3]) / 2, (r["bb"][0] + r["bb"][2]) / 2), 1)
                r["b"] = _bearing(a["lat"], a["lon"], (r["bb"][1] + r["bb"][3]) / 2, (r["bb"][0] + r["bb"][2]) / 2)
            rows.append(r)
        rows.sort(key=lambda r: r.get("d", 0))
        cat["areas"][key] = {"group": a["group"], "name": a["name"], "lat": a["lat"], "lon": a["lon"], "quads": rows}
        plan.append(key)
    print()
    _save_catalog(dest, cat)
    todo, seen = [], set()
    for key in plan:
        for r in cat["areas"][key]["quads"]:
            out = os.path.join(dest, "www", "topo", r["rel"])
            if r["rel"] not in seen and not os.path.exists(out):
                seen.add(r["rel"]); todo.append((r, out))
    need = sum(r["gb"] for r, _ in todo)
    print(f"  {len(todo)} more quads to download, about {need:.0f} GB (free: {u.free_gb(dest):.0f} GB)")
    if need > u.free_gb(dest) - reserve_gb:
        print(f"  ! not all will fit — downloading in order (bases, then cities, then lakes) and keeping {reserve_gb} GB free")
    got = 0
    for n, (r, out) in enumerate(todo):
        if u.free_gb(dest) - r["gb"] < reserve_gb:
            print(f"  ! stopped with {reserve_gb} GB left free; {len(todo) - n} quads not downloaded"); break
        if _get_quad(u, r["url"], out, r["t"], r.get("bb"), r):
            got += 1
        if got and got % 100 == 0:
            _save_catalog(dest, cat)                       # keep the index page current on long runs
    _save_catalog(dest, cat)
    _vanished_report()


def _topo_index(dest, cat):
    """www/topo/index.html (grouped list) + www/topo/quads.js (footprints for the locator map)."""
    root = os.path.join(dest, "www", "topo")
    ok = lambda r: os.path.exists(os.path.join(root, r["rel"]))  # noqa: E731
    foot, total = {}, 0

    def table(rows, show_d=True):
        nonlocal total
        trs = []
        for r in rows:
            if not ok(r):
                continue
            if r.get("bb"):
                foot[r["rel"]] = [r["t"], *r["bb"]]
            trs.append(f"<tr><td><a href='{html.escape(urllib.parse.quote(r['rel']))}'>{html.escape(r['t'])}</a></td>"
                       + (f"<td>{r.get('d', 0):.0f} mi {r.get('b', '')}</td>" if show_d else "") + f"<td>{r['gb'] * 1000:.0f} MB</td></tr>")
        return trs

    parts = []
    h = cat.get("home")
    if h:
        trs = table(h["quads"])
        parts.append(f"<h2 id='home'>Around home ({len(trs)} quads, {h['radius']:g}-mile box)</h2>"
                     f"<table><tr><th>Quad</th><th>From home</th><th>Size</th></tr>{''.join(trs)}</table>")
    groups = {}
    for key, a in (cat.get("areas") or {}).items():
        groups.setdefault(a["group"], []).append((key, a))
    toc = []
    for g in ("Military bases", "Cities", "Lakes, bays & coast"):
        if g not in groups:
            continue
        gid = _slug(g)
        blocks, n_on = [], 0
        for key, a in sorted(groups[g], key=lambda x: x[1]["name"]):
            trs = table(a["quads"])
            if not trs:
                blocks.append(f"<p class='dim' id='{key}'>{html.escape(a['name'])} — not downloaded yet</p>")
                continue
            n_on += 1
            blocks.append(f"<details id='{key}'><summary><b>{html.escape(a['name'])}</b> <span class='dim'>— {len(trs)} quads · "
                          f"{a['lat']:.4f}, {a['lon']:.4f}</span></summary><table><tr><th>Quad</th><th>From center</th><th>Size</th></tr>"
                          f"{''.join(trs)}</table></details>")
        toc.append(f"<a href='#{gid}'>{g}</a> ({n_on})")
        parts.append(f"<h2 id='{gid}'>{g}</h2>" + "".join(blocks))
    total = len(foot)
    body = ("<p class='dim'>USGS US Topo 7.5-minute quadrangles (1:24,000): contour lines, creeks, trails, power lines, "
            "buildings, woodland and roads, with a 1,000-meter UTM grid (the same grid as MGRS). Each one prints well on 11x17 or "
            "as 4 letter pages. On a phone, open them in Avenza Maps or any PDF app; GeoPDF-aware apps show your GPS position.</p>"
            f"<p><b>{total:,} quads on this drive.</b> " + " · ".join(["<a href='#home'>Around home</a>"] + toc) +
            " · <a href='/index.html#topoindex'>Click a spot on the map to find its quad</a></p>"
            "<p class='dim'>How to read them, take bearings and correct for declination: "
            "<a href='/library/Navigation%20%26%20Sky/sky_navigation_weather.html#topo'>Using the USGS topo maps</a> · "
            "Supplies: <a href='/library/Buy%20List/buy_list.html'>buy list → Navigation</a> · "
            "Military installation maps: <a href='/mymaps/index.html'>My Maps</a></p>" + "".join(parts))
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(_page("Topographic maps (USGS)", body))
    with open(os.path.join(root, "quads.js"), "w", encoding="utf-8") as fh:
        fh.write("window.TOPO_QUADS=" + json.dumps([[k, *v] for k, v in foot.items()], separators=(",", ":")) + ";\n")


# --------------------------------------------------------------------------- map tiles
TILESETS = {   # name: (url template {z}/{y}/{x}, attribution)
    "topo": ("https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}",
             "USGS The National Map"),
    "topo-south": ("https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}",
                   "USGS The National Map"),
    "hillshade": ("https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/tile/{z}/{y}/{x}",
                  "USGS The National Map: 3DEP shaded relief"),
    "satellite": ("https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}",
                  "USGS NAIP aerial imagery (The National Map)"),
}


def _tile(lat, lon, z):
    n = 2 ** z
    x = int((lon + 180) / 360 * n)
    y = int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def tiles(u, dest, name, lat, lon, radius, zmin, zmax, bbox=None):
    tpl, attr = TILESETS[name]
    u.say(f"Map layer '{name}' (USGS tiles, zoom {zmin}-{zmax}, " + ("whole region" if bbox else f"{radius:g}-mile box") + ")")
    root = os.path.join(dest, "www", "tiles", name)
    info_p = os.path.join(root, "info.json")
    want = {"minzoom": zmin, "maxzoom": zmax, "lat": round(lat, 3), "lon": round(lon, 3), "radius": radius}
    if bbox:
        want = {"minzoom": zmin, "maxzoom": zmax, "bbox": list(bbox)}
    try:
        info = json.load(open(info_p))
        if info.get("complete") and all(info.get(k) == v for k, v in want.items()):
            print("  already there"); return
    except (OSError, ValueError):
        pass
    w, s, e, n = bbox or _box(lat, lon, radius)
    jobs = []
    for z in range(zmin, zmax + 1):
        x0, y0 = _tile(n, w, z)
        x1, y1 = _tile(s, e, z)
        for x in range(x0, x1 + 1):
            for y in range(y0, y1 + 1):
                p = os.path.join(root, str(z), str(x), f"{y}.png")
                if not os.path.exists(p):
                    jobs.append((z, x, y, p))
    print(f"  {len(jobs):,} tiles to fetch")
    if jobs:
        z, x, y, _ = jobs[len(jobs) // 2]
        try:
            u.fetch(tpl.format(z=z, x=x, y=y), 60)
        except urllib.error.HTTPError as ex:
            if ex.code not in (400, 404):
                print(f"  ! USGS tile server answered {ex.code} — skipping this layer for now (re-run later)"); return
        except Exception as ex:  # noqa: BLE001
            print(f"  ! USGS tile server not reachable ({ex}) — skipping this layer for now (re-run later)"); return
    stats = {"ok": 0, "miss": 0, "err": 0}
    lock = threading.Lock()

    def get(job):
        z, x, y, p = job
        for attempt in range(3):
            try:
                data = u.fetch(tpl.format(z=z, x=x, y=y), 60)
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, "wb") as fh:
                    fh.write(data)
                k = "ok"; break
            except urllib.error.HTTPError as ex:
                if ex.code in (400, 404):
                    k = "miss"; break
                k = "err"; time.sleep(2 * (attempt + 1))
            except Exception:  # noqa: BLE001
                k = "err"; time.sleep(2 * (attempt + 1))
        with lock:
            stats[k] += 1
            done = sum(stats.values())
            if done % 250 == 0 or done == len(jobs):
                print(f"\r  {done:,}/{len(jobs):,} tiles ({stats['err']} errors)", end="", flush=True)

    with cf.ThreadPoolExecutor(8) as ex:
        list(ex.map(get, jobs))
    print()
    os.makedirs(root, exist_ok=True)
    with open(info_p, "w") as fh:
        json.dump({**want, "bounds": [s, w, n, e], "attribution": attr, "complete": stats["err"] <= max(20, len(jobs) // 200)}, fh)
    if stats["err"] > max(20, len(jobs) // 200):
        print("  ! some tiles failed — re-run the builder to fill them in")


def satellite(u, dest, boxes):
    """Cache USGS aerial/satellite imagery (NAIP, ~0.6-1 m) for many areas into www/tiles/satellite.

    boxes: list of ((w, s, e, n), zmin, zmax). Tiles are deduplicated across all boxes (overlapping
    areas are fetched once), so this scales to home + routes + destinations + bases/cities in one pass.
    """
    tpl, attr = TILESETS["satellite"]
    root = os.path.join(dest, "www", "tiles", "satellite")
    seen, jobs = set(), []
    zmin_all, zmax_all = 99, 0
    for (w, s, e, n), zmin, zmax in boxes:
        zmin_all, zmax_all = min(zmin_all, zmin), max(zmax_all, zmax)
        for z in range(zmin, zmax + 1):
            x0, y0 = _tile(n, w, z)
            x1, y1 = _tile(s, e, z)
            for x in range(x0, x1 + 1):
                for y in range(y0, y1 + 1):
                    key = (z, x, y)
                    if key in seen:
                        continue
                    seen.add(key)
                    p = os.path.join(root, str(z), str(x), f"{y}.png")
                    if not os.path.exists(p):
                        jobs.append((z, x, y, p))
    u.say(f"Satellite/aerial imagery: {len(boxes)} areas, {len(seen):,} tiles ({len(jobs):,} new to fetch, zoom {zmin_all}-{zmax_all})")
    if jobs:                                        # probe one tile first — skip the layer cleanly if the server is down
        z, x, y, _ = jobs[len(jobs) // 2]
        try:
            u.fetch(tpl.format(z=z, x=x, y=y), 60)
        except urllib.error.HTTPError as ex:
            if ex.code not in (400, 404):
                print(f"  ! USGS imagery server answered {ex.code} — skipping for now (re-run later)"); return
        except Exception as ex:  # noqa: BLE001
            print(f"  ! USGS imagery server not reachable ({ex}) — skipping for now (re-run later)"); return
    stats = {"ok": 0, "miss": 0, "err": 0}
    lock = threading.Lock()

    def get(job):
        z, x, y, p = job
        for attempt in range(3):
            try:
                data = u.fetch(tpl.format(z=z, x=x, y=y), 60)
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, "wb") as fh:
                    fh.write(data)
                k = "ok"; break
            except urllib.error.HTTPError as ex:
                if ex.code in (400, 404):
                    k = "miss"; break
                k = "err"; time.sleep(2 * (attempt + 1))
            except Exception:  # noqa: BLE001
                k = "err"; time.sleep(2 * (attempt + 1))
        with lock:
            stats[k] += 1
            done = sum(stats.values())
            if done % 500 == 0 or done == len(jobs):
                print(f"\r  {done:,}/{len(jobs):,} tiles ({stats['err']} errors)", end="", flush=True)

    if jobs:
        with cf.ThreadPoolExecutor(8) as ex:
            list(ex.map(get, jobs))
        print()
    os.makedirs(root, exist_ok=True)
    complete = stats["err"] <= max(20, len(jobs) // 200)
    with open(os.path.join(root, "info.json"), "w") as fh:
        json.dump({"minzoom": zmin_all, "maxzoom": zmax_all, "attribution": attr, "complete": complete}, fh)
    if not complete:
        print("  ! some imagery tiles failed — re-run to fill them in")


# --------------------------------------------------------------------------- FEMA flood zones
NFHL = "https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28/query"


def flood_zones(u, dest, lat, lon, radius):
    u.say(f"FEMA flood zones (National Flood Hazard Layer, {radius:g}-mile box)")
    cache = os.path.join(dest, "www", "data", "flood")
    os.makedirs(cache, exist_ok=True)
    old = glob.glob(os.path.join(cache, "c_*.json"))
    if u.UPDATE and old and min(u.age_days(f) for f in old) > 180:
        print("  flood data is over 6 months old — refreshing from FEMA")
        for f in old:
            os.remove(f)
    w, s, e, n = _box(lat, lon, radius)
    step, cells = 0.2, []
    y = s
    while y < n:
        x = w
        while x < e:
            cells.append((round(x, 3), round(y, 3), round(min(x + step, e), 3), round(min(y + step, n), 3)))
            x += step
        y += step
    where = "SFHA_TF='T' OR ZONE_SUBTY LIKE '0.2 PCT%'"
    bad = streak = 0
    for i, c in enumerate(cells, 1):
        cp = os.path.join(cache, "c_%s_%s.json" % (c[0], c[1]))
        if os.path.exists(cp):
            continue
        feats, off, ok = [], 0, True
        while True:
            q = urllib.parse.urlencode({"where": where, "geometry": "%s,%s,%s,%s" % c, "geometryType": "esriGeometryEnvelope",
                                        "inSR": 4326, "spatialRel": "esriSpatialRelIntersects", "outSR": 4326,
                                        "outFields": "FLD_ZONE,ZONE_SUBTY,SFHA_TF", "returnGeometry": "true",
                                        "geometryPrecision": 5, "maxAllowableOffset": 0.00008,
                                        "resultOffset": off, "resultRecordCount": 1000, "f": "geojson"})
            try:
                j = json.loads(u.fetch(f"{NFHL}?{q}", 180))
            except Exception as ex:  # noqa: BLE001
                print(f"\n  ! FEMA cell {i}: {ex}"); ok = False; break
            if "error" in j:
                print(f"\n  ! FEMA cell {i}: {j['error'].get('message')}"); ok = False; break
            fs = j.get("features", [])
            feats += fs
            if not (j.get("exceededTransferLimit") or (j.get("properties") or {}).get("exceededTransferLimit")) and len(fs) < 1000:
                break
            if not fs:
                break
            off += len(fs)
        if ok:
            with open(cp, "w") as fh:
                json.dump(feats, fh, separators=(",", ":"))
            streak = 0
        else:
            bad += 1; streak += 1
            if streak >= 3:
                print("\n  ! FEMA server not answering — skipping flood zones for now (re-run later)"); break
        print(f"\r  area {i}/{len(cells)}", end="", flush=True)
    print()
    seen, out = set(), []
    for cp in glob.glob(os.path.join(cache, "c_*.json")):
        for f in json.load(open(cp)):
            fid = f.get("id") or json.dumps(f["geometry"])[:200]
            if fid in seen:
                continue
            seen.add(fid)
            p = f.get("properties") or {}
            kind = "floodway" if "FLOODWAY" in (p.get("ZONE_SUBTY") or "") else ("100" if p.get("SFHA_TF") == "T" else "500")
            out.append({"type": "Feature", "geometry": f["geometry"], "properties": {"z": p.get("FLD_ZONE"), "k": kind}})
    if not out and bad:
        print("  - no flood data yet (re-run later)"); return
    with open(os.path.join(dest, "www", "data", "flood.js"), "w") as fh:
        fh.write("window.FLOOD=" + json.dumps({"type": "FeatureCollection", "features": out}, separators=(",", ":")) + ";\n")
    print(f"  {len(out):,} flood areas saved" + (f" ({bad} areas failed — re-run to retry)" if bad else ""))


# --------------------------------------------------------------------------- phone apps
APPS = [  # (folder, description, source, pattern)
    ("OsmAnd", "Offline maps + turn-by-turn navigation (load the state maps below)", "fdroid", "net.osmand.plus"),
    ("Organic Maps", "Simple offline maps (downloads its own maps while online — set it up before you need it)",
     "github", ("organicmaps/organicmaps", r"OrganicMaps-\d+-web-release\.apk$")),
    ("Kiwix", "Reads the .zim archives (WikEM, medicine, Wikipedia...) on the phone",
     "github", ("kiwix/kiwix-android", r"universal-standalone\.apk$")),
    ("Meshtastic", "Text and share GPS positions over cheap LoRa radios — no cell service needed",
     "github", ("meshtastic/Meshtastic-Android", r"fdroid-universal-release\.apk$")),
    ("VLC", "Plays every movie and show on the drive (any file type, subtitles)", "fdroid", "org.videolan.vlc"),
    ("KOReader", "E-book and PDF reader (the Bible, history and kids' books on the drive)", "fdroid", "org.koreader.launcher.fdroid"),
    ("Termux", "Runs the whole drive on the tablet: Home page, search, calculators, players and the AI (see the phones & tablets guide)",
     "fdroid", "com.termux"),
    ("Briar", "Private text messages between phones with no internet (Bluetooth or Wi-Fi)", "fdroid", "org.briarproject.briar.android"),
    ("Sideband", "Reticulum messenger: encrypted texts over LoRa (RNode), Wi-Fi or packet radio, stores messages until the other person is in range",
     "github", ("markqvist/Sideband", r"(?i)(arm64|universal)[^/]*\.apk$")),
    ("Sky Map", "Find stars, planets and the direction you are facing, with no internet", "fdroid", "com.google.android.stardroid"),
    ("OpenTracks", "Records your route, distance and elevation with the GPS, saved offline", "fdroid", "de.dennisguse.opentracks"),
    ("F-Droid", "Open-source app store (to update these apps while internet is up)", "url", "https://f-droid.org/F-Droid.apk"),
    ("ATAK-CIV", "Team map: share positions, mark points, chat (older developer build from the DoD GitHub; "
     "install the current one from Google Play while you can)", "atak", ("deptofdefense/AndroidTacticalAssaultKit-CIV", r"atak-civ-sdk.*\.zip$")),
]
OSMAND_STATES = ["georgia", "alabama", "tennessee", "north-carolina", "south-carolina"]


def phone_apps(u, dest):
    u.say("Phone apps (Android installers), OsmAnd state maps, Meshtastic firmware")
    base = os.path.join(dest, "www", "phone-apps")
    rows = []
    for folder, desc, kind, src in APPS:
        d = os.path.join(base, "android", folder)
        name = url = None
        try:
            if kind == "fdroid":
                code = json.loads(u.fetch(f"https://f-droid.org/api/v1/packages/{src}", 60))["suggestedVersionCode"]
                name, url = f"{src}_{code}.apk", f"https://f-droid.org/repo/{src}_{code}.apk"
            elif kind in ("github", "atak"):
                a = u.gh_asset(*src)
                if a:
                    name, url = a
            else:
                name, url = os.path.basename(src), src
        except Exception as ex:  # noqa: BLE001
            print(f"  ! {folder}: {ex}")
        if not url:
            print(f"  - {folder}: not found")
        elif kind == "atak":
            apk = os.path.join(d, "atak-civ.apk")
            if not os.path.exists(apk):
                z = os.path.join(base, "dl", name)
                if u.download(url, z, "ATAK-CIV SDK"):
                    try:
                        with zipfile.ZipFile(z) as zf:          # closed before the folder is deleted (Windows)
                            m = next((i for i in zf.namelist() if re.search(r"(^|/)atak[^/]*\.apk$", i, re.I)), None)
                            if m:
                                os.makedirs(d, exist_ok=True)
                                with zf.open(m) as src_f, open(apk + ".part", "wb") as out_f:
                                    shutil.copyfileobj(src_f, out_f)
                                os.replace(apk + ".part", apk)
                            else:
                                print("  - ATAK-CIV: no APK inside the SDK zip")
                    except zipfile.BadZipFile:
                        print("  ! ATAK-CIV zip damaged — re-run")
                shutil.rmtree(os.path.join(base, "dl"), ignore_errors=True)
        elif u.download(url, os.path.join(d, name), f"{folder} app"):
            _keep_latest(d, name)
        for f in glob.glob(os.path.join(d, "*.apk")):
            rows.append((folder, desc, os.path.relpath(f, base).replace(os.sep, "/"), os.path.getsize(f) / 1e6))
    maps = []
    for st in OSMAND_STATES:
        obf = os.path.join(base, "osmand-maps", f"Us_{st}_northamerica.obf")
        if not os.path.exists(obf) or (u.UPDATE and u.age_days(obf) > 30):   # OsmAnd publishes new maps monthly
            z = obf + ".zip"
            if u.download(f"https://download.osmand.net/download?standard=yes&file=Us_{st}_northamerica_2.obf.zip", z,
                          f"OsmAnd map: {st}"):
                ok = False
                try:
                    with zipfile.ZipFile(z) as zf:              # must be closed before deleting the zip (Windows)
                        m = next((i for i in zf.namelist() if i.endswith(".obf")), None)
                        if m:
                            with zf.open(m) as a, open(obf + ".part", "wb") as b:
                                shutil.copyfileobj(a, b)
                            os.replace(obf + ".part", obf)
                            ok = True
                except zipfile.BadZipFile:
                    pass
                if not ok:
                    print(f"  ! OsmAnd {st}: download wasn't a valid map file — re-run later")
                try:
                    os.remove(z)
                except OSError:
                    pass
        if os.path.exists(obf):
            maps.append((st, os.path.relpath(obf, base).replace(os.sep, "/"), os.path.getsize(obf) / 1e6))
    fw = []
    for chip in ("nrf52840", "esp32s3", "esp32"):
        a = u.gh_asset("meshtastic/firmware", rf"^firmware-{chip}-[\w.]+\.zip$")
        if a:
            d = os.path.join(base, "meshtastic-firmware", chip)
            if u.download(a[1], os.path.join(d, a[0]), f"Meshtastic firmware {chip}"):
                _keep_latest(d, a[0])
        for f in glob.glob(os.path.join(base, "meshtastic-firmware", chip, "*.zip")):
            fw.append((chip, os.path.relpath(f, base).replace(os.sep, "/"), os.path.getsize(f) / 1e6))
    t = lambda r: "".join(r)  # noqa: E731
    body = (
        "<p class='dim'>Phones on the same Wi-Fi as this drive can tap a link to download and install. Android: allow "
        "<b>Install unknown apps</b> for your browser when asked. Install and set these up <b>now</b>, while you can still "
        "look things up.</p><h2>Android apps</h2><table><tr><th>App</th><th>What it's for</th><th>Size</th></tr>"
        + t(f"<tr><td><a href='{html.escape(p)}'>{html.escape(a)}</a></td><td>{html.escape(d)}</td><td>{s:.0f} MB</td></tr>"
            for a, d, p, s in rows) + "</table>"
        "<h2>OsmAnd offline maps (Georgia + neighbors)</h2><p class='dim'>Android: download the .obf file, then open it with OsmAnd "
        "(or copy it into Android/data/net.osmand.plus/files/). iPhone (OsmAnd from the App Store): save to Files &rarr; "
        "On My iPhone &rarr; OsmAnd Maps &rarr; Resources, then restart OsmAnd.</p><ul>"
        + t(f"<li><a href='{html.escape(p)}'>{html.escape(s.replace('-', ' ').title())}</a> &middot; {mb:.0f} MB</li>" for s, p, mb in maps)
        + "</ul><h2>Waypoints for GPS, OsmAnd and ATAK</h2><p class='dim'>Every hospital, pharmacy, fuel station, water point, "
        "shelter, military base and map area as GPX/KML files, with MGRS grids: <a href='/data/export/index.html'>GPS files</a>. "
        "Your own maps and waypoints: <a href='/mymaps/index.html'>My Maps</a>.</p>"
        "<h2>Satellite maps for phones</h2><p class='dim'>Aerial imagery of home and each get-home route for OsmAnd: "
        "<a href='satellite/index.html'>Satellite maps for phones</a> (made by ADD-SATELLITE-IMAGERY).</p>"
        "<h2>Meshtastic radio firmware</h2><p class='dim'>For flashing LoRa radios with no internet. <b>nRF52840</b> boards "
        "(RAK4631, LilyGO T-Echo, many handhelds): unzip, double-tap the radio's reset button so it shows up as a USB drive, and "
        "copy the matching <code>.uf2</code> file onto it. <b>ESP32</b> boards (Heltec V3, T-Beam) need a flashing tool, so "
        "flash and test them now with the Meshtastic web flasher while you have internet. Set every family radio to the same "
        "channel name and key.</p><ul>"
        + t(f"<li><a href='{html.escape(p)}'>{html.escape(c)}</a> &middot; {mb:.0f} MB</li>" for c, p, mb in fw)
        + "</ul><h2>Run the whole drive on Android (Termux)</h2><p class='dim'>Install Termux above, open it, type <code>termux-setup-storage</code> "
          "and allow access. Then <code>sh /storage/XXXX-XXXX/OFFGRID/PROGRAMS/start-android-termux.sh</code> (type <code>ls /storage</code> to find "
          "XXXX-XXXX). It starts the drive's own pages (and the AI if you let it add llama.cpp) and opens Home. Full steps: "
          "<a href='/library/Computer%20%26%20Case/phones_and_tablets.html'>Phones &amp; tablets guide</a>.</p>"
          "<h2>iPhone &amp; iPad</h2><p class='dim'>iPhones and iPads can't install apps from files — install these from the App Store <b>now</b>, "
          "while you have internet: <b>Kiwix</b> (opens this drive's .zim archives), <b>OsmAnd Maps</b> (state maps above), <b>VLC</b> (movies and "
          "music), <b>Meshtastic</b>, <b>iTAK</b>, and an offline AI app such as <b>PocketPal AI</b> (load a .gguf model from the drive's ai\\models "
          "folder). PDFs and e-books open in Files and Books. Or simply join the laptop's Wi-Fi/hotspot and open the address the launcher shows — "
          "everything works in Safari that way.</p>")
    os.makedirs(base, exist_ok=True)
    with open(os.path.join(base, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(_page("Phone apps, maps and radio firmware", body))
    print(f"  {len(rows)} apps, {len(maps)} state maps, {len(fw)} firmware packs")


# --------------------------------------------------------------------------- VeraCrypt
def vault_tools(u, dest):
    u.say("VeraCrypt for the encrypted family-document vault")
    d = os.path.join(dest, "tools", "veracrypt")
    for label, pat in (("Windows (portable, no install)", r"^VeraCrypt\.Portable\.[\d.]+\.exe$"),
                       ("Windows installer", r"^VeraCrypt\.Setup\.[\d.]+\.exe$"),
                       ("macOS (FUSE-T)", r"^VeraCrypt_FUSE-T_[\d.]+\.dmg$"),
                       ("Ubuntu 24.04", r"^veracrypt-[\d.]+-Ubuntu-24\.04-amd64\.deb$")):
        a = u.gh_asset("veracrypt/VeraCrypt", pat)
        if not a:
            print(f"  - VeraCrypt {label}: not found"); continue
        sub = os.path.join(d, re.sub(r"\W+", "-", label.split(" (")[0]).strip("-").lower())
        if u.download(a[1], os.path.join(sub, a[0]), f"VeraCrypt {label}"):
            _keep_latest(sub, a[0])


# --------------------------------------------------------------------------- voice (whisper.cpp)
def voice(u, dest, bins):
    u.say("Voice input: whisper.cpp speech-to-text")
    pats = {"win": (r"^whisper-bin-x64\.zip$", ("whisper-server.exe", "server.exe")),
            "linux": (r"^whisper-bin-ubuntu-x64\.tar\.gz$", ("whisper-server", "server"))}
    for osn in bins:
        if osn not in pats:
            print(f"  - no ready-made whisper build for {osn} (voice input works on Windows/Linux)"); continue
        pat, wants = pats[osn]
        outdir = os.path.join(dest, "ai", "whisper", osn)
        if not u.UPDATE and any(os.path.exists(os.path.join(outdir, w)) for w in wants):
            continue
        a = u.gh_asset("ggml-org/whisper.cpp", pat)
        if not a:
            print(f"  - whisper.cpp {osn}: not found"); continue
        if u.installed(outdir, wants[0], a[0]):
            continue
        arc = os.path.join(dest, "ai", "dl", a[0])
        if u.download(a[1], arc, a[0]) and any(u.extract(arc, outdir, w) for w in wants):
            if not os.path.exists(os.path.join(outdir, wants[0])):      # older builds call it server(.exe)
                shutil.copy2(os.path.join(outdir, wants[1]), os.path.join(outdir, wants[0]))
            u.mark_installed(outdir, a[0])
            print(f"  whisper server for {osn} ready")
        else:
            print(f"  ! whisper {osn} failed")
    shutil.rmtree(os.path.join(dest, "ai", "dl"), ignore_errors=True)
    u.download("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin",
               os.path.join(dest, "ai", "whisper", "ggml-base.en.bin"), "Whisper English model")


# --------------------------------------------------------------------------- big Kiwix archives
BIG_ZIMS = [  # (folder, regex, label) — newest match is downloaded
    ("wikibooks", r"wikibooks_en_all_maxi_\d{4}-\d{2}\.zim", "Wikibooks (how-to textbooks)"),
    ("wikipedia", r"wikipedia_en_all_maxi_\d{4}-\d{2}\.zim", "Wikipedia, all articles with images (~110 GB)"),
    ("gutenberg", r"gutenberg_en_all_\d{4}-\d{2}\.zim", "Project Gutenberg English books (~70 GB)"),
]
KHAN_FOLDERS = ("other", "videos", "mooc")


def _head_size(u, url):
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": u.UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            return int(r.headers.get("Content-Length") or 0) / 1e9
    except Exception:  # noqa: BLE001
        return 0


def zim_get(u, dest, url, name, label):
    out = os.path.join(dest, "kiwix", "zim", name)
    if os.path.exists(out):
        return True
    gb = _head_size(u, url)
    if gb and u.free_gb(dest) - gb < 15:
        print(f"  ! skipping {label}: needs {gb:.0f} GB, only {u.free_gb(dest):.0f} GB free"); return False
    ok =u.download(url, out, f"{label[:40]} {gb:.1f} GB" if gb else label[:50])
    if ok:   # remove superseded versions of the same archive
        for old in glob.glob(os.path.join(dest, "kiwix", "zim", re.sub(r"_\d{4}-\d{2}\.zim$", "_*.zim", name))):
            if os.path.basename(old) != name and not old.endswith(".part"):
                os.remove(old)
    return ok


def kiwix_big(u, dest):
    u.say("Large archives: Wikibooks, full Wikipedia, Project Gutenberg, Khan Academy")
    listings = {}

    def listing(folder):
        if folder not in listings:
            try:
                listings[folder] = u.fetch(f"https://download.kiwix.org/zim/{folder}/", 60).decode("utf-8", "replace")
            except Exception as ex:  # noqa: BLE001
                print(f"  ! {folder}: {ex}"); listings[folder] = ""
        return listings[folder]

    for folder, rx, label in BIG_ZIMS:
        names = sorted(set(re.findall(rx, listing(folder))))
        if names:
            zim_get(u, dest, f"https://download.kiwix.org/zim/{folder}/{names[-1]}", names[-1], label)
        else:
            print(f"  - {label}: not found")
    # Khan Academy: one full English archive if published, otherwise every English Khan archive
    found = {}
    for folder in KHAN_FOLDERS:
        for nm in set(re.findall(r'khan[-_]?academy[\w.-]*?_\d{4}-\d{2}\.zim', listing(folder), re.I)):
            if "_en_" not in nm.lower():
                continue
            key = re.sub(r"_\d{4}-\d{2}\.zim$", "", nm)
            if key not in found or nm > found[key][1]:
                found[key] = (folder, nm)
    full = {k: v for k, v in found.items() if "_en_all" in k.lower()}
    pick = full or found
    if not pick:
        print("  - Khan Academy: not found")
    for key, (folder, nm) in sorted(pick.items()):
        zim_get(u, dest, f"https://download.kiwix.org/zim/{folder}/{nm}", nm, "Khan Academy " + key.split("_en_")[-1])


# --------------------------------------------------------------------------- Kiwix Desktop (no-server reader)
def kiwix_desktop(u, dest, bins):
    """Portable Kiwix reader app: opens the .zim archives with no web server (Windows zip, Linux AppImage)."""
    u.say("Portable Kiwix reader (reads the archives without the launcher)")
    base = "https://download.kiwix.org/release/kiwix-desktop/"
    try:
        listing = u.fetch(base, 60).decode("utf-8", "replace")
    except Exception as ex:  # noqa: BLE001
        print(f"  ! {ex}"); return
    vkey = lambda n: [int(x) for x in re.findall(r"\d+", n)]  # noqa: E731
    for osn, rx, want in (("win", r"kiwix-desktop_windows_x64_[\d.-]+\.zip", "kiwix-desktop.exe"),
                          ("linux", r"kiwix-desktop_x86_64_[\d.-]+\.appimage", None)):
        if osn not in bins:
            continue
        names = sorted(set(re.findall(rx, listing)), key=vkey)
        if not names:
            print(f"  - no Kiwix Desktop build for {osn}"); continue
        outdir = os.path.join(dest, "kiwix", "desktop", "windows" if osn == "win" else "linux")
        if want:
            if u.installed(outdir, want, names[-1]):
                continue
            arc = os.path.join(dest, "kiwix", "dl", names[-1])
            if u.download(base + names[-1], arc, names[-1]) and u.extract(arc, outdir, want):
                u.mark_installed(outdir, names[-1])
                print("  Kiwix Desktop for Windows ready")
            shutil.rmtree(os.path.join(dest, "kiwix", "dl"), ignore_errors=True)
        elif u.download(base + names[-1], os.path.join(outdir, names[-1]), names[-1]):
            _keep_latest(outdir, names[-1])


# --------------------------------------------------------------------------- GPS files (GPX / KML) of every place
def place_exports(u, dest):
    """www/data/export/: every locator place, military base and map area as GPX (Garmin, OsmAnd, ATAK) and KML
    (Google Earth, ATAK, OsmAnd), all-in-one and one file per category. Descriptions carry MGRS + DMS."""
    import coords, areas  # noqa: E401  (same folder)
    u.say("GPS files of every place (GPX + KML, with MGRS)")
    data = os.path.join(dest, "www", "data")
    out = os.path.join(data, "export")
    os.makedirs(out, exist_ok=True)
    groups = {}                                                   # file key -> (title, [(name, lat, lon, desc)])
    try:
        txt = open(os.path.join(data, "pois.js"), encoding="utf-8").read()
        meta = json.loads(re.search(r"window\.POI_META=(.*?);\n", txt).group(1))
        pois = json.loads(re.search(r"window\.POIS=(.*?);\n", txt, re.S).group(1))
    except (OSError, AttributeError, ValueError):
        meta, pois = {"categories": {}}, []
    cats = meta.get("categories", {})
    for p in pois:
        cat, name, la, lo = p[0], p[1], p[2], p[3]
        desc = " · ".join(x for x in (cats.get(cat, cat), p[6], p[7] and "Tel " + p[7], p[11]) if x)
        groups.setdefault(cat, (cats.get(cat, cat), []))[1].append((name, la, lo, desc))
    raw = os.path.join(data, "military.geojson")
    if os.path.exists(raw):
        for s in areas.military(u, dest, max_age_days=10 ** 6):
            groups.setdefault("military-bases", ("Military installations (DoD)", []))[1].append(
                (s["name"], s["lat"], s["lon"], f"{s['branch']} · {s['st']} · {s['status']} (center of the installation)"))
    for st, name, la, lo in areas.CITIES:
        groups.setdefault("cities", ("Major Southern cities", []))[1].append((f"{name}, {st}", la, lo, "City center"))
    for name, la, lo in (("Toronto, ON", 43.6532, -79.3832), ("Qu?bec City, QC", 46.8139, -71.2080)):
        groups.setdefault("cities", ("Major Southern cities", []))[1].append((name, la, lo, "City center (Canada)"))
    for st, name, la, lo, r in areas.WATER:
        groups.setdefault("lakes-coast", ("Lakes, bays & coast", []))[1].append((f"{name} ({st})", la, lo, f"Center; topo maps cover {r} mi around"))
    esc = html.escape

    def gpx(items):
        w = "".join(f'<wpt lat="{la:.6f}" lon="{lo:.6f}"><name>{esc(n[:60])}</name><desc>{esc(d)} · MGRS {coords.mgrs(la, lo)} · '
                    f'{esc(coords.dms(la, lo))}</desc><sym>Flag, Blue</sym></wpt>\n' for n, la, lo, d in items)
        return ('<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="OFF-GRID drive" '
                'xmlns="http://www.topografix.com/GPX/1/1">\n' + w + "</gpx>\n")

    def kmz(path, text):
        import zipfile
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("doc.kml", text)

    def kml(folders):
        body = ""
        for title, items in folders:
            body += f"<Folder><name>{esc(title)}</name>" + "".join(
                f"<Placemark><name>{esc(n)}</name><description>{esc(d)}\nMGRS {coords.mgrs(la, lo)}\n{esc(coords.dms(la, lo))}</description>"
                f"<Point><coordinates>{lo:.6f},{la:.6f},0</coordinates></Point></Placemark>" for n, la, lo, d in items) + "</Folder>\n"
        return ('<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
                f"<name>OFF-GRID places</name>{body}</Document></kml>\n")

    rows = []
    for key, (title, items) in groups.items():
        fn = re.sub(r"[^a-z0-9-]+", "-", key.lower())
        open(os.path.join(out, fn + ".gpx"), "w", encoding="utf-8").write(gpx(items))
        open(os.path.join(out, fn + ".kml"), "w", encoding="utf-8").write(kml([(title, items)]))
        rows.append(f"<tr><td>{esc(title)}</td><td>{len(items):,}</td><td><a href='{fn}.gpx' download>GPX</a> · "
                    f"<a href='{fn}.kml' download>KML</a></td></tr>")
    allitems = [i for _, (_, its) in groups.items() for i in its]
    open(os.path.join(out, "all-places.gpx"), "w", encoding="utf-8").write(gpx(allitems))
    open(os.path.join(out, "all-places.kml"), "w", encoding="utf-8").write(kml([g for g in groups.values()]))
    kmz(os.path.join(out, "all-places.kmz"), kml([g for g in groups.values()]))
    cov = ("<p><a href='map-coverage.kmz' download>Map coverage (KMZ)</a> ? outlines of every topo sheet and your own map on "
           "this drive, for Google Earth.</p>") if os.path.exists(os.path.join(out, "map-coverage.kmz")) else ""
    body = ("<p class='dim'>Every place on the locator as GPS waypoints. Each one has its MGRS grid and degrees-minutes-seconds in "
            "the description. <b>GPX</b>: Garmin (BaseCamp, or copy to the GPS's Garmin/GPX folder), OsmAnd (Menu ▸ My places ▸ "
            "Import), Organic Maps, ATAK (Import ▸ Local SD). <b>KML</b>: Google Earth, ATAK, OsmAnd. Garmin handhelds slow "
            "down past a few thousand waypoints — load just the categories you need.</p>"
            f"<p><a href='all-places.gpx' download>Everything (GPX, {len(allitems):,} points)</a> · "
            "<a href='all-places.kml' download>Everything (KML, folders by category)</a> ? "
            "<a href='all-places.kmz' download>KMZ</a></p>"
            f"{cov}<table><tr><th>Category</th><th>Places</th><th>Download</th></tr>{''.join(rows)}</table>")
    open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(_page("GPS files — every place as GPX / KML", body))
    print(f"  {len(allitems):,} waypoints in {len(groups)} categories → www/data/export/")


# --------------------------------------------------------------------------- free e-books (Project Gutenberg)
EBOOKS = {  # folder in www/library/ -> [(Gutenberg id, file name)]
    "Books - Bible & Faith": [(10, "King_James_Bible"), (131, "Pilgrims_Progress_Bunyan")],
    "Books - History & Founding Documents": [
        (1, "Declaration_of_Independence"), (5, "United_States_Constitution"), (1404, "The_Federalist_Papers"),
        (147, "Common_Sense_Paine"), (23, "Narrative_of_the_Life_of_Frederick_Douglass"), (4367, "Personal_Memoirs_of_U_S_Grant"),
        (132, "The_Art_of_War_Sun_Tzu")],
    "Books - Classics & Adventure": [
        (521, "Robinson_Crusoe"), (120, "Treasure_Island"), (215, "The_Call_of_the_Wild"), (1727, "The_Odyssey"),
        (16328, "Beowulf"), (2701, "Moby_Dick"), (1342, "Pride_and_Prejudice"), (84, "Frankenstein"),
        (1661, "The_Adventures_of_Sherlock_Holmes"), (98, "A_Tale_of_Two_Cities"), (74, "Tom_Sawyer"), (76, "Huckleberry_Finn"),
        (29558, "Boy_Scouts_Handbook_1911")],
    "Books - Leadership & Psychology": [
        (445, "The_Crowd_Le_Bon"), (24518, "Extraordinary_Popular_Delusions_and_the_Madness_of_Crowds"),
        (2680, "Meditations_Marcus_Aurelius"), (1232, "The_Prince_Machiavelli"), (1170, "Anabasis_Xenophon")],
    "Books - Children": [
        (11, "Alice_in_Wonderland"), (12, "Through_the_Looking_Glass"), (55, "The_Wonderful_Wizard_of_Oz"),
        (236, "The_Jungle_Book"), (271, "Black_Beauty"), (45, "Anne_of_Green_Gables"), (2591, "Grimms_Fairy_Tales"),
        (1597, "Andersens_Fairy_Tales"), (14838, "The_Tale_of_Peter_Rabbit"), (19994, "The_Aesop_for_Children"),
        (113, "The_Secret_Garden"), (16, "Peter_Pan"), (289, "The_Wind_in_the_Willows")],
}


def ebooks(u, dest, delay=3):
    """A small shelf of public-domain books as EPUB files (open in any e-reader app, Calibre, or Kiwix's Gutenberg
    archive). They're also full-text searchable from the home page. One at a time, politely spaced."""
    u.say("Free e-books: Bible, history, classics, children's books (Project Gutenberg)")
    import time
    got = 0
    for folder, books in EBOOKS.items():
        for gid, name in books:
            out = os.path.join(dest, "www", "library", folder, name + ".epub")
            if os.path.exists(out) and os.path.getsize(out) > 0:
                continue
            for url in (f"https://www.gutenberg.org/ebooks/{gid}.epub3.images", f"https://www.gutenberg.org/ebooks/{gid}.epub.images",
                        f"https://www.gutenberg.org/cache/epub/{gid}/pg{gid}-images-3.epub"):
                if u.download(url, out, name.replace("_", " ")[:50], retries=1):
                    with open(out, "rb") as fh:
                        ok = fh.read(2) == b"PK"
                    if ok:
                        got += 1; break
                    os.remove(out)
            else:
                print(f"  ! couldn't get {name} (gutenberg.org/ebooks/{gid})")
            time.sleep(delay)
    print(f"  e-books: {got} new")


# --------------------------------------------------------------------------- players for computers with no browser
def players(u, dest, bins):
    """Portable VLC (plays every movie/show, any format) and SumatraPDF (reads PDFs and EPUBs) for Windows —
    both run straight from the drive with no install, so a bare or locked-down PC can still read and watch."""
    if "win" not in bins:
        return
    u.say("Portable VLC player and SumatraPDF reader (Windows, no install)")
    jobs = []
    try:
        base = "https://download.videolan.org/pub/videolan/vlc/last/win64/"
        names = sorted(set(re.findall(r"vlc-[\d.]+-win64\.zip", u.fetch(base, 60).decode("utf-8", "replace"))))
        if names:
            jobs.append((base + names[-1], names[-1], os.path.join(dest, "tools", "vlc"), "vlc.exe"))
    except Exception as ex:  # noqa: BLE001
        print(f"  ! VLC: {ex}")
    ver = "3.5.2"
    try:
        page = u.fetch("https://www.sumatrapdfreader.org/download-free-pdf-viewer", 60).decode("utf-8", "replace")
        vs = sorted(set(re.findall(r"SumatraPDF-(\d+\.\d+(?:\.\d+)?)-64\.zip", page)), key=lambda v: [int(x) for x in v.split(".")])
        ver = vs[-1] if vs else ver
    except Exception:  # noqa: BLE001
        pass
    jobs.append((f"https://www.sumatrapdfreader.org/dl/rel/{ver}/SumatraPDF-{ver}-64.zip", f"SumatraPDF-{ver}-64.zip",
                 os.path.join(dest, "tools", "sumatra"), None))
    for url, name, outdir, want in jobs:
        if os.path.isdir(outdir) and (u.installed(outdir, want, name) if want else os.path.exists(os.path.join(outdir, "VERSION.txt"))):
            continue
        arc = os.path.join(dest, "tools", "dl", name)
        if not u.download(url, arc, name):
            continue
        if want:
            ok = u.extract(arc, outdir, want)
        else:   # SumatraPDF zip holds one exe with a version in its name
            import zipfile
            os.makedirs(outdir, exist_ok=True)
            with zipfile.ZipFile(arc) as z:
                exe = next((n for n in z.namelist() if n.lower().endswith(".exe")), None)
                ok = bool(exe)
                if exe:
                    with z.open(exe) as fi, open(os.path.join(outdir, "SumatraPDF.exe"), "wb") as fo:
                        shutil.copyfileobj(fi, fo)
            with open(os.path.join(outdir, "SumatraPDF-settings.txt"), "a"):
                pass   # its presence makes Sumatra portable: settings stay on the drive
        if ok:
            u.mark_installed(outdir, name)
            print(f"  {os.path.basename(outdir)} ready")
        shutil.rmtree(os.path.join(dest, "tools", "dl"), ignore_errors=True)
