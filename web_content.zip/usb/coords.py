"""Lat/lon -> DMS, UTM and MGRS (WGS84), and MGRS -> lat/lon. Standard library only.

Same math as www/coords.js (used by the locator map), so printed lists, GPX/KML files and the
map all show identical grid references.
"""
import math, re

_A, _F, _K0 = 6378137.0, 1 / 298.257223563, 0.9996
_E2 = _F * (2 - _F)
_EP2 = _E2 / (1 - _E2)
_SET_COL = ("ABCDEFGH", "JKLMNPQR", "STUVWXYZ")
_SET_ROW = ("ABCDEFGHJKLMNPQRSTUV", "FGHJKLMNPQRSTUVABCDE")
_BANDS = "CDEFGHJKLMNPQRSTUVWXX"


def dms(lat, lon):
    def one(v, pos, neg):
        h = pos if v >= 0 else neg
        v = abs(v)
        d = int(v); m = int((v - d) * 60); s = (v - d - m / 60) * 3600
        if s >= 59.95:
            s = 0; m += 1
        if m == 60:
            m = 0; d += 1
        return f"{d}°{m:02d}'{s:04.1f}\"{h}"
    return f"{one(lat, 'N', 'S')} {one(lon, 'E', 'W')}"


def _zone(lat, lon):
    z = int((lon + 180) / 6) + 1
    if z > 60:
        z = 60
    if 56 <= lat < 64 and 3 <= lon < 12:
        z = 32
    if 72 <= lat < 84:
        for lo, hi, zz in ((0, 9, 31), (9, 21, 33), (21, 33, 35), (33, 42, 37)):
            if lo <= lon < hi:
                z = zz
    return z


def _M(phi):
    e2 = _E2
    return _A * ((1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * phi
                 - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * math.sin(2 * phi)
                 + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * math.sin(4 * phi)
                 - (35 * e2 ** 3 / 3072) * math.sin(6 * phi))


def utm(lat, lon):
    """-> (zone, band letter, easting, northing)"""
    z = _zone(lat, lon)
    phi, lam = math.radians(lat), math.radians(lon)
    lam0 = math.radians((z - 1) * 6 - 180 + 3)
    N = _A / math.sqrt(1 - _E2 * math.sin(phi) ** 2)
    T = math.tan(phi) ** 2
    C = _EP2 * math.cos(phi) ** 2
    A = math.cos(phi) * (lam - lam0)
    e = _K0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * _EP2) * A ** 5 / 120) + 500000
    n = _K0 * (_M(phi) + N * math.tan(phi) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24
                                             + (61 - 58 * T + T * T + 600 * C - 330 * _EP2) * A ** 6 / 720))
    if lat < 0:
        n += 10000000
    band = _BANDS[max(0, min(20, int((lat + 80) // 8)))] if -80 <= lat <= 84 else "Z"
    return z, band, e, n


def utm_str(lat, lon):
    z, b, e, n = utm(lat, lon)
    return f"{z}{b} {int(e):06d}E {int(n):07d}N"


def mgrs(lat, lon, digits=5):
    z, b, e, n = utm(lat, lon)
    col = _SET_COL[(z - 1) % 3][int(e // 100000) - 1]
    row = _SET_ROW[(z - 1) % 2][int(n // 100000) % 20]
    f = 10 ** (5 - digits)
    return f"{z}{b} {col}{row} {int(e % 100000) // f:0{digits}d} {int(n % 100000) // f:0{digits}d}"


def utm_to_latlon(z, north, e, n):
    if not north:
        n -= 10000000
    e1 = (1 - math.sqrt(1 - _E2)) / (1 + math.sqrt(1 - _E2))
    mu = n / _K0 / (_A * (1 - _E2 / 4 - 3 * _E2 ** 2 / 64 - 5 * _E2 ** 3 / 256))
    p = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * math.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * math.sin(4 * mu)
         + (151 * e1 ** 3 / 96) * math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * math.sin(8 * mu))
    N1 = _A / math.sqrt(1 - _E2 * math.sin(p) ** 2)
    T1 = math.tan(p) ** 2
    C1 = _EP2 * math.cos(p) ** 2
    R1 = _A * (1 - _E2) / (1 - _E2 * math.sin(p) ** 2) ** 1.5
    D = (e - 500000) / (N1 * _K0)
    lat = p - (N1 * math.tan(p) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * _EP2) * D ** 4 / 24
                                         + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * _EP2 - 3 * C1 * C1) * D ** 6 / 720)
    lon = (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * _EP2 + 24 * T1 * T1) * D ** 5 / 120) / math.cos(p)
    return math.degrees(lat), (z - 1) * 6 - 180 + 3 + math.degrees(lon)


def parse_mgrs(s):
    """'16S GC 12345 67890' (spaces optional, 1-5 digit pairs) -> (lat, lon) of the square's SW corner + half."""
    m = re.fullmatch(r"(\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\d*)", re.sub(r"\s", "", s.upper()))
    if not m or len(m.group(5)) % 2:
        raise ValueError("not an MGRS reference")
    z, band, c, r, d = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
    k = len(d) // 2
    f = 10 ** (5 - k)
    e = (_SET_COL[(z - 1) % 3].index(c) + 1) * 100000 + (int(d[:k] or 0) * f) + f / 2
    n100 = _SET_ROW[(z - 1) % 2].index(r) * 100000 + (int(d[k:] or 0) * f) + f / 2
    # the band gives the approximate northing; pick the 2,000 km cycle that lands inside it
    blat = -80 + _BANDS.index(band) * 8
    north = band >= "N"
    nmin = utm(blat, (z - 1) * 6 - 177)[3]
    n = n100
    while n < nmin - 100000:
        n += 2000000
    return utm_to_latlon(z, north, e, n)


def all_formats(lat, lon):
    return {"dd": f"{lat:.5f}, {lon:.5f}", "dms": dms(lat, lon), "utm": utm_str(lat, lon), "mgrs": mgrs(lat, lon)}
