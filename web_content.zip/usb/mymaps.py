"""Your own maps on the drive: military installation maps (MIMs), special maps, KML/GPX, checklists.

Put files (any folders inside) in either of these and run the builder or ADD-MY-MAPS-WINDOWS.bat:
    <drive>\\OFFGRID\\MY-MAPS-INBOX\\         (easiest: unzip a Google Drive download here; emptied as it sorts)
    <builder>\\library\\My Maps\\             (built-in source; left as it is)
Inbox files are MOVED to www/mymaps/ (original removed after its copy is verified); builder "My Maps" files
are copied. Both are kept in the same folders, listed on mymaps/index.html, put in the
no-AI search, and drawn on the locator map: GeoPDF coverage boxes (read from the PDF itself, or
from a KML index such as TerraGo's indexgrids.kml) and waypoints from KML/GPX files.
"""
import html, json, math, os, re, shutil, urllib.parse
import xml.etree.ElementTree as ET

KEEP = {".pdf", ".kml", ".gpx", ".gdb", ".doc", ".docx", ".xls", ".xlsx", ".csv", ".txt", ".jpg", ".jpeg", ".png",
        ".tif", ".tiff", ".geotiff", ".kmz", ".mbtiles", ".sqlitedb", ".img", ".ozf", ".map"}
NOTES = {
    ".gdb": "Garmin MapSource/BaseCamp waypoint database. To see these points on the map and in phone apps: open it in "
            "Garmin BaseCamp → File → Export → GPX, and drop the .gpx in MY-MAPS-INBOX.",
    ".kmz": "Zipped KML (Google Earth). Opens in Google Earth, OsmAnd and ATAK.",
    ".doc": "Word document", ".docx": "Word document", ".xls": "Excel spreadsheet", ".xlsx": "Excel spreadsheet",
}


def _same(a, b):
    try:
        sa, sb = os.stat(a), os.stat(b)
        return sa.st_size == sb.st_size and int(sa.st_mtime) <= int(sb.st_mtime)
    except OSError:
        return False


def _prune_empty(inbox):
    """Remove now-empty subfolders left after files are moved out (keep the inbox root)."""
    for root, _, _ in os.walk(inbox, topdown=False):
        if os.path.abspath(root) == os.path.abspath(inbox):
            continue
        try:
            if not os.listdir(root):
                os.rmdir(root)
        except OSError:
            pass


def sources(u, dest):
    inbox = os.path.join(dest, "MY-MAPS-INBOX")
    os.makedirs(inbox, exist_ok=True)
    readme = os.path.join(inbox, "README.txt")
    if not os.path.exists(readme):
        with open(readme, "w", newline="\r\n", encoding="utf-8") as fh:
            fh.write("Put your own maps here (folders are fine), then run START-HERE.bat in the OFFGRID folder and pick 5 (Add my maps).\n\n"
                     "From Google Drive: open the folder in a browser, click the folder name > Download. Drive makes a .zip;\n"
                     "right-click it > Extract All, and pick this MY-MAPS-INBOX folder.\n\n"
                     "Good file types: GeoPDF maps (.pdf), Google Earth (.kml/.kmz), GPS waypoints (.gpx), checklists (.doc/.pdf).\n"
                     "Each file is MOVED: the original is removed from this inbox once its copy is verified, so the inbox empties\n"
                     "as it sorts (this README stays). A file is only left here if it couldn't be stored or verified.\n")
    return [os.path.join(u.REPO, "library", "My Maps"), inbox]


def import_files(u, dest):
    out = os.path.join(dest, "www", "mymaps")
    os.makedirs(out, exist_ok=True)
    inbox = os.path.join(dest, "MY-MAPS-INBOX")
    empty, n, moved, kept = [], 0, 0, 0
    for src in sources(u, dest):
        if not os.path.isdir(src):
            continue
        from_inbox = os.path.abspath(src) == os.path.abspath(inbox)
        for root, _, files in os.walk(src):
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                if ext not in KEEP or f == "README.txt":
                    continue
                p = os.path.join(root, f)
                rel = os.path.relpath(p, src)
                if os.path.getsize(p) == 0:
                    empty.append(rel); continue
                q = os.path.join(out, rel)
                if not _same(p, q):
                    os.makedirs(os.path.dirname(q), exist_ok=True)
                    shutil.copy2(p, q); n += 1
                    getattr(u, "CHANGES", []).append("My Maps: " + rel)
                # move, not copy: only files that came from the inbox, and only once the copy is verified
                if from_inbox:
                    if os.path.exists(q) and os.path.getsize(q) == os.path.getsize(p):
                        try:
                            os.remove(p); moved += 1
                        except OSError:
                            kept += 1
                    else:
                        kept += 1
    if moved or kept:
        print(f"  {moved} file(s) removed from MY-MAPS-INBOX after sorting" +
              (f"; {kept} left in place (could not verify or remove)" if kept else ""))
    _prune_empty(inbox)
    return n, empty


# ---------------------------------------------------------------- reading coverage + waypoints
def _utm_to_ll(E, N, zone, north=True):
    """Inverse UTM -> (lon, lat) on WGS84 (Snyder/USGS closed form, sub-metre). Pure Python, no deps."""
    a, f, k0 = 6378137.0, 1 / 298.257223563, 0.9996
    e2 = f * (2 - f)
    ep2 = e2 / (1 - e2)
    if not north:
        N -= 1e7
    M = N / k0
    mu = M / (a * (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 ** 3 / 256))
    e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
    phi = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * math.sin(2 * mu)
           + (21 * e1 * e1 / 16 - 55 * e1 ** 4 / 32) * math.sin(4 * mu)
           + (151 * e1 ** 3 / 96) * math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * math.sin(8 * mu))
    C1 = ep2 * math.cos(phi) ** 2
    T1 = math.tan(phi) ** 2
    N1 = a / math.sqrt(1 - e2 * math.sin(phi) ** 2)
    R1 = a * (1 - e2) / (1 - e2 * math.sin(phi) ** 2) ** 1.5
    D = (E - 500000) / (N1 * k0)
    lat = phi - (N1 * math.tan(phi) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D ** 4 / 24
          + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D ** 6 / 720)
    lon = ((D - (1 + 2 * T1 + C1) * D ** 3 / 6
            + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D ** 5 / 120) / math.cos(phi))
    return math.degrees(math.radians(zone * 6 - 183) + lon), math.degrees(lat)


def _ll_to_utm(lon, lat, zone):
    """Forward WGS84 -> UTM (E, N) in metres (Snyder/USGS). Pure Python, no deps."""
    a, f, k0 = 6378137.0, 1 / 298.257223563, 0.9996
    e2 = f * (2 - f)
    ep2 = e2 / (1 - e2)
    lon0 = math.radians(zone * 6 - 183)
    la, lo = math.radians(lat), math.radians(lon)
    N = a / math.sqrt(1 - e2 * math.sin(la) ** 2)
    T = math.tan(la) ** 2
    C = ep2 * math.cos(la) ** 2
    A = (lo - lon0) * math.cos(la)
    M = a * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 ** 3 / 256) * la
             - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 ** 3 / 1024) * math.sin(2 * la)
             + (15 * e2 * e2 / 256 + 45 * e2 ** 3 / 1024) * math.sin(4 * la)
             - (35 * e2 ** 3 / 3072) * math.sin(6 * la))
    E = k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 500000
    Nn = k0 * (M + N * math.tan(la) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24
               + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720))
    if lat < 0:
        Nn += 1e7
    return E, Nn


def lgi_frame(page):
    """Parse a GeoPDF page's georeferencing into a reusable frame, or None.
    Returns {ctm, inv, proj, zone, north, neatline(page pts), mb} for pixel<->lon/lat mapping (used by the tile renderer)."""
    lgi = page.get("/LGIDict")
    lgi = lgi.get_object() if lgi is not None else None
    if lgi is None:
        return None
    for fr in (lgi if isinstance(lgi, list) else [lgi]):
        d = fr.get_object()
        ctm = [float(x) for x in (d.get("/CTM").get_object() if d.get("/CTM") is not None else [])]
        if len(ctm) != 6:
            continue
        a, b, c, dd, e, ff = ctm
        det = a * dd - b * c
        if not det:
            continue
        proj = d.get("/Projection") or d.get("/Display") or {}
        proj = proj.get_object() if hasattr(proj, "get_object") else proj
        ptype = str(proj.get("/ProjectionType") or "").upper()
        zone = proj.get("/Zone")
        nl = [float(x) for x in (d.get("/Neatline").get_object() if d.get("/Neatline") is not None else [])]
        mb = [float(x) for x in page.mediabox]
        return {"ctm": ctm, "inv": (dd / det, -c / det, -b / det, a / det, e, ff),
                "proj": ptype, "zone": int(zone) if zone is not None else None,
                "north": str(proj.get("/Hemisphere") or "N").upper().startswith("N"),
                "neatline": list(zip(nl[0::2], nl[1::2])) if len(nl) >= 8 else
                            [(mb[0], mb[1]), (mb[2], mb[1]), (mb[2], mb[3]), (mb[0], mb[3])], "mb": mb}


def _lgidict_bbox(page):
    """Older OGC/TerraGo GeoPDF georeferencing (/LGIDict): military MIMs, older USGS. -> [w,s,e,n] or None.
    Reads the map frame (Neatline) in page points, applies the CTM to projected coords, and inverts UTM
    (or reads geographic coords directly) to lon/lat. Other projections fall through to None."""
    lgi = page.get("/LGIDict")
    lgi = lgi.get_object() if lgi is not None else None
    if lgi is None:
        return None
    frames = lgi if isinstance(lgi, list) else [lgi]
    mb = [float(x) for x in page.mediabox]
    lons, lats = [], []
    for fr in frames:
        d = fr.get_object()
        ctm = [float(x) for x in (d.get("/CTM").get_object() if d.get("/CTM") is not None else [])]
        if len(ctm) != 6:
            continue
        proj = (d.get("/Projection") or d.get("/Display") or {})
        proj = proj.get_object() if hasattr(proj, "get_object") else proj
        ptype = str(proj.get("/ProjectionType") or "").upper()
        zone = proj.get("/Zone")
        north = str(proj.get("/Hemisphere") or "N").upper().startswith("N")
        nl = [float(x) for x in (d.get("/Neatline").get_object() if d.get("/Neatline") is not None else [])]
        pts = list(zip(nl[0::2], nl[1::2])) if len(nl) >= 8 else [(mb[0], mb[1]), (mb[2], mb[1]), (mb[2], mb[3]), (mb[0], mb[3])]
        a, b, c, dd, e, ff = ctm
        for px, py in pts:
            X, Y = a * px + c * py + e, b * px + dd * py + ff      # page points -> projected coords
            if ptype in ("UT", "UTM") and zone is not None:
                lon, lat = _utm_to_ll(X, Y, int(zone), north)
            elif ptype in ("GEOGRAPHIC", "GEODETIC", "LL", "LONG/LAT", "LATLONG"):
                lon, lat = X, Y
            else:
                continue                                           # projection we don't invert (State Plane, Lambert…)
            lons.append(lon); lats.append(lat)
    if lons and all(-90 <= a <= 90 for a in lats) and all(-180 <= o <= 180 for o in lons):
        return [round(min(lons), 5), round(min(lats), 5), round(max(lons), 5), round(max(lats), 5)]
    return None


def geopdf_bbox(pypdf, path):
    """Geographic extent of a GeoPDF -> [w,s,e,n] or None. Handles both the ISO 32000 encoding
    (/VP → /Measure → /GPTS, used by newer USGS/Esri) and the older OGC/TerraGo /LGIDict (military MIMs)."""
    try:
        r = pypdf.PdfReader(path)
        lats, lons = [], []
        for page in r.pages[:3]:
            for vp in page.get("/VP") or []:
                vp = vp.get_object()
                m = vp.get("/Measure")
                m = m.get_object() if m is not None else None
                g = m.get("/GPTS") if m is not None else None
                if g:
                    vals = [float(x) for x in g.get_object()]
                    lats += vals[0::2]; lons += vals[1::2]
            if lats:
                break
        if lats and all(-90 <= a <= 90 for a in lats) and all(-180 <= o <= 180 for o in lons):
            return [round(min(lons), 5), round(min(lats), 5), round(max(lons), 5), round(max(lats), 5)]
        for page in r.pages[:3]:                                   # fall back to the older TerraGo encoding
            bb = _lgidict_bbox(page)
            if bb:
                return bb
    except Exception:  # noqa: BLE001
        pass
    return None


def _tag(e):
    return e.tag.rsplit("}", 1)[-1]


def read_kml(path):
    """-> (polygons [(name, [w,s,e,n])], points [(name, lat, lon)])"""
    polys, pts = [], []
    try:
        tree = ET.parse(path)
    except (ET.ParseError, OSError):
        return polys, pts
    for pm in tree.iter():
        if _tag(pm) != "Placemark":
            continue
        name = ""
        for c in pm:
            if _tag(c) == "name":
                name = (c.text or "").strip()
        for g in pm.iter():
            if _tag(g) == "coordinates" and g.text:
                xy = []
                for tok in g.text.split():
                    p = tok.split(",")
                    if len(p) >= 2:
                        try:
                            xy.append((float(p[0]), float(p[1])))
                        except ValueError:
                            pass
                if len(xy) >= 3:
                    xs, ys = [a for a, _ in xy], [b for _, b in xy]
                    polys.append((name, [round(min(xs), 5), round(min(ys), 5), round(max(xs), 5), round(max(ys), 5)]))
                elif len(xy) == 1:
                    pts.append((name, round(xy[0][1], 6), round(xy[0][0], 6)))
                break
    return polys, pts


def read_gpx(path):
    pts = []
    try:
        tree = ET.parse(path)
    except (ET.ParseError, OSError):
        return pts
    for w in tree.iter():
        if _tag(w) in ("wpt", "rtept"):
            name = next((c.text or "" for c in w if _tag(c) == "name"), "")
            try:
                pts.append((name.strip() or "waypoint", float(w.get("lat")), float(w.get("lon"))))
            except (TypeError, ValueError):
                pass
    return pts


def _stem(s):
    return re.sub(r"[^a-z0-9]", "", os.path.splitext(os.path.basename(s))[0].lower())


def build(u, dest):
    u.say("My Maps (your own military installation maps, KML, GPX, checklists)")
    n, empty = import_files(u, dest)
    root = os.path.join(dest, "www", "mymaps")
    files = []
    for r, _, fs in os.walk(root):
        for f in fs:
            if f == "index.html" or f.startswith("_") or f.endswith(".part"):
                continue
            files.append(os.path.relpath(os.path.join(r, f), root).replace(os.sep, "/"))
    files.sort(key=str.lower)
    if not files:
        print("  - none yet. Put maps in MY-MAPS-INBOX on the drive (see README.txt there) and run START-HERE.bat > 5 (Add my maps)")
    cache_p = os.path.join(root, "_coverage.json")
    try:
        cache = json.load(open(cache_p, encoding="utf-8"))
    except (OSError, ValueError):
        cache = {}
    polys, points = {}, []
    for rel in files:
        ext = os.path.splitext(rel)[1].lower()
        p = os.path.join(root, rel)
        if ext == ".kml":
            pl, pt = read_kml(p)
            for name, bb in pl:
                polys.setdefault(_stem(name.split("::")[-1]), bb)
            names = {_stem(nm) for nm, _ in pl}
            points += [(nm, la, lo, rel) for nm, la, lo in pt if _stem(nm) not in names]
        elif ext == ".gpx":
            points += [(nm, la, lo, rel) for nm, la, lo in read_gpx(p)]
    pypdf = None
    maps = []
    for rel in files:
        if not rel.lower().endswith(".pdf"):
            continue
        p = os.path.join(root, rel)
        sig = [os.path.getsize(p), int(os.path.getmtime(p))]
        c = cache.get(rel)
        if c and c.get("sig") == sig:
            bb = c.get("bb")
        else:
            if pypdf is None:
                try:
                    pypdf = u.search_index.get_pypdf(u, dest) or False
                except Exception:  # noqa: BLE001
                    pypdf = False
            bb = geopdf_bbox(pypdf, p) if pypdf else None
            cache[rel] = {"sig": sig, "bb": bb}
        bb = bb or polys.get(_stem(rel))
        if bb:
            maps.append([rel, os.path.splitext(os.path.basename(rel))[0], *bb])
    with open(cache_p, "w", encoding="utf-8") as fh:
        json.dump(cache, fh)
    os.makedirs(os.path.join(dest, "www", "data"), exist_ok=True)
    with open(os.path.join(dest, "www", "data", "mymaps.js"), "w", encoding="utf-8") as fh:
        fh.write("window.MYMAPS=" + json.dumps({"maps": maps, "points": [list(x) for x in points]}, separators=(",", ":")) + ";\n")
    _page(u, dest, files, {m[0]: m[2:] for m in maps}, points, empty)
    print(f"  {len(files)} files ({n} new), {len(maps)} maps with known coverage, {len(points)} waypoints")
    try:                                   # render georeferenced GeoPDFs into offline map tiles (best-effort)
        import geopdf_render
        geopdf_render.build(u, dest)
    except Exception as ex:  # noqa: BLE001
        print(f"  (map-image tiles skipped: {str(ex)[:100]})")
    if empty:
        print(f"  ! {len(empty)} empty (0-byte) files skipped — re-download them: " + ", ".join(empty[:6]))


def _page(u, dest, files, cover, points, empty):
    from coords import mgrs  # noqa: E402  (same folder)
    groups = {}
    for rel in files:
        if rel.startswith("_"):
            continue
        groups.setdefault(rel.rsplit("/", 1)[0] if "/" in rel else "(top folder)", []).append(rel)
    root = os.path.join(dest, "www", "mymaps")
    parts = []
    for g in sorted(groups, key=lambda x: (x == "(top folder)", x.lower())):
        trs = []
        for rel in groups[g]:
            ext = os.path.splitext(rel)[1].lower()
            mb = os.path.getsize(os.path.join(root, rel)) / 1e6
            note = ""
            if rel in cover:
                w, s, e, n = cover[rel]
                note = (f"GeoPDF · center {mgrs((s + n) / 2, (w + e) / 2, 4)} · "
                        f"<a href='/index.html#mymap={urllib.parse.quote(rel)}'>show on map</a>")
            elif ext in NOTES:
                note = NOTES[ext]
            elif ext in (".kml", ".gpx"):
                k = sum(1 for p in points if p[3] == rel)
                note = (f"{k} waypoints · " if k else "") + "<a href='/index.html#mymaps'>show on map</a> · opens in Google Earth, OsmAnd, ATAK"
            trs.append(f"<tr><td><a href='{html.escape(urllib.parse.quote(rel))}'>{html.escape(rel.rsplit('/', 1)[-1])}</a></td>"
                       f"<td>{mb:.1f} MB</td><td class='dim'>{note}</td></tr>")
        parts.append(f"<h2>{html.escape(g)}</h2><table><tr><th>File</th><th>Size</th><th>Notes</th></tr>{''.join(trs)}</table>")
    if points:
        rows = "".join(f"<tr><td>{html.escape(nm)}</td><td>{mgrs(la, lo, 5)}</td><td>{la:.5f}, {lo:.5f}</td><td class='dim'>{html.escape(f)}</td></tr>"
                       for nm, la, lo, f in points[:2000])
        parts.append(f"<h2 id='wpts'>Waypoints</h2><table><tr><th>Name</th><th>MGRS</th><th>Lat, lon</th><th>From</th></tr>{rows}</table>")
    warn = ("<p style='color:#f0883e'>These files were empty (0 bytes) where they came from, so they weren't added — the upload "
            "probably failed. Download them again: " + ", ".join(html.escape(e) for e in empty) + "</p>") if empty else ""
    body = ("<p class='dim'>Your own maps: military installation maps (MIMs, 1:50,000 with the MGRS grid), special maps, "
            "aerial photo maps, waypoints and checklists. GeoPDFs open in any PDF app; in <b>Avenza Maps</b> (free, phone) or "
            "<b>QGIS</b> (free, desktop) they show your live GPS position on the map, fully offline. The drive reads each GeoPDF's "
            "built-in georeferencing itself, so you do <b>not</b> need Adobe or the TerraGo GeoPDF plug-ins — the coverage box and "
            "MGRS center below come straight from the map file. Coverage boxes and waypoints are on the "
            "<a href='/index.html#mymaps'>locator map</a> (layer \"My maps\").</p>" + warn + ("".join(parts) or "<p>None yet.</p>") +
            "<h2 id='add'>Adding more maps</h2><ol>"
            "<li>Copy the files (folders are fine) into <code>MY-MAPS-INBOX</code> in the OFFGRID folder on the drive. "
            "From Google Drive: open the folder in a browser, click the folder name ▸ <b>Download</b>, then right-click the .zip ▸ "
            "<b>Extract All</b> into MY-MAPS-INBOX.</li>"
            "<li>Run <code>START-HERE.bat</code> in the OFFGRID folder and pick <b>5 Add my maps</b> (a minute or two; no internet needed). "
            "Each file is moved out of the inbox once its copy is verified, so the inbox empties itself as it sorts. "
            "The monthly update does this too.</li>"
            "<li>Garmin <code>.gdb</code> waypoint files: export them to <code>.gpx</code> from Garmin BaseCamp first so they show on the map.</li>"
            "<li>Where to find more: installation maps are often issued by the base's range control / training support center "
            "(ask for the current MIM GeoPDF); USGS topo quads for any base are already on this drive under "
            "<a href='/topo/index.html#military-bases'>Topo maps → Military bases</a>.</li></ol>")
    with open(os.path.join(root, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(u.extras._page("My Maps — military & special maps", body))
