@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Copy (mirror) this OFF-GRID drive to another drive: a backup, a travel drive or a USB flash drive =====
REM It asks WHAT DEVICE the copy is for (Windows / Mac / Linux / Android / iPhone), WHERE YOU'RE GOING (a work-travel
REM city), and the SIZE of the target drive (128 GB, 1 TB...), then makes a copy sized to fit. Choosing a phone leaves out
REM the programs that phone can't run (an iPhone gets the content only); a travel city adds that route's get-home plan and topo.
REM Then F = everything   N = everything except movies, TV and music   A = automatic fit for a smaller drive (64 GB+)
REM   C = choose exactly what to include yourself, with a running total.  Run it again after updates: only changes are copied.
REM For a phone, the other drive must be exFAT (an iPhone can't read NTFS). FAT32 can't hold files over 4 GB.
cd /d "%~dp0"
title Copy OFF-GRID drive
chcp 65001 >nul
set PYTHONUTF8=1
echo.
echo  This drive: %~d0
set "T="
echo  Copy to another drive: type its letter (e.g. F).
echo  Or make a smaller copy in a folder on this computer: type the folder (e.g. C:\OFFGRID-64).
set /p "T= Drive letter or folder: "
if not defined T exit /b 1
tools\python-win\python.exe tools\builder\usb\copy_drive.py --dest "%~dp0." --target "%T%"
pause
