OFF-GRID SURVIVAL DRIVE
=======================

START HERE
  WINDOWS:  double-click START-HERE.bat - a numbered menu of every program on this drive.
            Press 1 to start everything (AI, maps, archives); the Command Center opens in its own window.
            Close that window to stop the drive.
  MAC:      open Terminal, type  sh   then drag start-here-mac-linux.sh into the window, press Enter
  LINUX:    sh /media/<you>/<drive>/OFFGRID/start-here-mac-linux.sh
  READ-ME-FIRST.html  explains every program and folder, and opens Home, What's happening?, Search,
            Library, Maps and Movies with one click - even when nothing is running.

THE MENU (START-HERE.bat)                                   the programs themselves are in PROGRAMS\
  1  Start the drive                 every time - use this first
  2  Search with no web browser      bare, broken or locked-down computer
  3  Read the archives in Kiwix      if 1 won't run
  4  Add movies and TV shows         plan first (names), then copy or move; Home > Movies & TV
  M  Add music                       by artist / album from the songs' tags, with album art; Home > Music
  5  Add my maps                     after putting files in MY-MAPS-INBOX
  L  Add my documents & books       after putting files in MY-FILES-INBOX (sorted by folder; duplicates skipped)
  P  Add my radio files              after putting files in MY-RADIO-INBOX (CHIRP .img -> channel lists)
  C  Ask Claude online             when any internet works: text-only chat, tiny data use (needs API key)
  6  Check the drive                 writes REPORTS\CHECK-REPORT.txt and REPORTS\MISSING-MANUALS.html/.txt
  7  Update the drive                monthly, needs internet; retries anything missing
  8  Copy to another drive           F everything, N no movies/music, A auto-fit a smaller drive, microSD or a folder on a PC (64 GB+)
  9  Monthly update reminder         once, on your main computer
  H Home page   W What's happening?   S Search page   I Instructions   T Plain-text copies   R Reports

WHAT'S HERE
  www/home.html     start page with everything linked
  www/ask.html      "Ask the Library": AI answers from your own guides, buy list, radio plan, nearby places
  ai/               offline AI (llama.cpp) for Windows, macOS, Linux + models (.gguf):
                    3B / 7B / 14B chat (14B used automatically with 32 GB+ RAM), Gemma 3 photo model,
                    MedGemma medical model, Whisper voice input. To force a model: PROGRAMS\START-WINDOWS.bat <model.gguf>
  www/library/      guides and manuals        www/index.html  locator + maps (street, topo, terrain, flood)
  www/library/Books - */  e-books (.epub): KJV Bible, founding documents, history, classics, children's books.
                    Open with any e-reader app (Calibre, Google Play Books, Apple Books, Lithium) or Kiwix.
  www/topo/         printable USGS topo quads: home, Southern cities (20 mi), lakes/coast, military bases
  www/mymaps/       YOUR maps (MIMs etc). Add more: put files in MY-MAPS-INBOX, menu 5
  www/data/export/  GPS files (GPX/KML with MGRS) of every place, base, city and lake
  www/phone-apps/   Android apps, OsmAnd state maps, Meshtastic firmware (phones install from the drive)
  kiwix/            archives (.zim): Wikipedia, WikEM, MDWiki, iFixit, Stack Exchange, Gutenberg, Khan Academy,
                    Simple English Wikipedia, Vikidia (kids), PhET science sims, Wiktionary, Wikisource, LibreTexts
  tools/            portable Python, the small web server, VeraCrypt, VLC player (tools/vlc), SumatraPDF reader (tools/sumatra)
  www/media/        your movies & shows (Home > Movies & TV). Add: menu 4
  www/music/        your music (Home > Music: artists, albums, genres, playlists, shuffle). Add: menu M
  TEXT-ONLY/        every guide, manual and e-book as plain .txt - for Notepad, an e-reader, a phone
  family-vault.hc   your encrypted family documents (create it - see the Family document vault guide)

PHONES & TABLETS: see Library > Computer & Case > Phones & Tablets (Android, iPhone, iPad).
        Android can run the whole drive with Termux: PROGRAMS/start-android-termux.sh
        Or connect to the same Wi-Fi (or the laptop's hotspot) and open http://<laptop-ip>:8090/home.html
        (the launcher window shows the address). Allow access if the firewall asks.

AI SPEED: small model ~ fine on any laptop with 8 GB RAM; medium wants 16 GB. First answer takes longer
        while the model loads. Answers can be wrong - check doses, wiring and safety in the cited source.

KEEP IT SAFE: store the drive in a Faraday bag or metal can; refresh it every few months by re-running
        the builder (only new/changed files download). Make two - one for the go-bag, one elsewhere.

NO BROWSER, OR A LOCKED-DOWN COMPUTER?
  Menu 2 (PROGRAMS\SEARCH-NO-BROWSER-WINDOWS.bat)  search everything in a plain command window; read results right there,
                                  or open them (PDFs/e-books open in the drive's own SumatraPDF).
  PROGRAMS/search-no-browser.sh   the same on Mac/Linux.
  If programs won't run at all: open TEXT-ONLY in File Explorer, double-click any .txt (Notepad),
  or search it with Windows' built-in FINDSTR (menu 2 does this for you when Python can't run).
  READ-ME-FIRST.html works in any browser with nothing running (no server).



MAINTENANCE TOOLS (menu V, R, Z)
  V  verify_drive.py  - SHA-256 check of Kiwix archives, AI models and map tiles (REPORTS\VERIFY-REPORT.txt)
  R  repair_drive.py  - delete damaged big files and re-download only what is missing (SET-WEEKLY-REPAIR-WINDOWS.bat schedules it)
  Z  pack_drive.py    - compress the whole drive into checksummed volumes; restore with restore_pack.py / RESTORE-WINDOWS.bat
  usb_builder.py --profile micro|small|medium|large|full|auto picks how much is built for the drive size.

EXTRA DATA (more_data.py; skip all with --no-extra-data)
  FCC ham call signs -> Home > Ham call signs (www\ham-calls.html), refreshed after 45 days
  Geofabrik state extracts -> OSM-MAP-SOURCE\*.osm.pbf, converted to map layers; choose with --geofabrik georgia,tennessee (default depends on --profile)
  Kolibri -> tools\kolibri (Windows/Android/portable); add courses with --kolibri-channels c9d7f950ab6b5a1199e3d6c10d7f0103 (Khan Academy, very large)
