"""Movies & TV for downtime: organize a folder (or a whole drive) of video files and build a searchable
catalog page that plays them in the browser — all offline.

  1. PLAN    python media.py --dest E:\\OFFGRID --src F:\\            (reads only; writes REPORTS\\MEDIA-PLAN.csv + .html)
  2. CHECK   open MEDIA-PLAN.html; fix anything marked "check" by editing MEDIA-PLAN.csv (Excel is fine)
  3. APPLY   python media.py --dest E:\\OFFGRID --apply copy          (or "move" to free the other drive)
  4. WATCH   Home ▸ Movies & TV   (search, Kids filter, seasons, resume where you left off)

Files are named the way Plex, Jellyfin and Kodi expect, so a NAS or media server can use the same folders later:
  Movies/Title (Year)/Title (Year).mp4      TV Shows/Show/Season 01/Show - S01E02.mkv
  Kids Movies/…  Kids TV/…   (anything that came from a folder named Kids, Children, Family, Cartoons, Disney…)
Nothing is ever overwritten or deleted except the originals in "move" mode, after a verified copy.
Just re-run with --catalog-only after adding files to the media folders by hand.
"""
import argparse, csv, html, json, os, re, shutil, sys, time, urllib.parse

VIDEO = {".mp4", ".m4v", ".mkv", ".avi", ".mov", ".wmv", ".webm", ".mpg", ".mpeg", ".ts", ".m2ts", ".flv", ".divx", ".ogv", ".3gp"}
WEB_OK = {".mp4", ".m4v", ".webm", ".mov", ".ogv"}           # play in any browser; .mkv often plays in Chrome/Edge
SUBS = {".srt", ".vtt", ".sub", ".idx", ".ass", ".ssa"}
CATS = ("Movies", "TV Shows", "Kids Movies", "Kids TV")
KIDS = re.compile(r"(?i)^(kids?|children|childrens|child|family|cartoons?|animated|animation|disney|pixar|dreamworks|kid movies|kids movies|kids tv|kids shows)$")
JUNK = re.compile(r"(?i)[\s(\[]*\b(480p|576p|720p|1080[pi]|2160p|4k|uhd|hdr\d*|dv|sdr|x\.?26[45]|h\.?26[45]|hevc|avc|xvid|divx|bluray|blu-ray|"
                  r"bdrip|brrip|bdremux|remux|web[ .-]?dl|webrip|web|hdtv|hdrip|dvdrip|dvdscr|dvd|amzn|nf|hulu|dsnp|hmax|atvp|aac\d?|ac3|eac3|"
                  r"dts(-hd)?|truehd|ddp?\d?(\.\d)?|5\.1|7\.1|2\.0|atmos|proper|repack|extended|unrated|uncut|directors cut|imax|remastered|"
                  r"yify|yts|rarbg|eztv|10bit|8bit|multi|dubbed|subbed|internal|limited)\b.*$")
TV_RX = [re.compile(r"(?i)\bS(\d{1,2})[ ._-]*E(\d{1,3})(?:[ ._-]*-?E?(\d{1,3}))?\b"),
         re.compile(r"(?i)\b(\d{1,2})x(\d{2,3})\b"),
         re.compile(r"(?i)\bseason[ ._-]*(\d{1,2})[ ._-]*(?:episode|ep)[ ._-]*(\d{1,3})\b")]
SEASON_DIR = re.compile(r"(?i)^(?:season|series|s)[ ._-]*(\d{1,2})\b")
YEAR = re.compile(r"(?<!\d)(19[2-9]\d|20[0-4]\d)(?!\d)")
GENERIC = re.compile(r"(?i)^(movies?|films?|videos?|tv|tv shows?|shows?|series|media|downloads?|new folder|complete|season.*|specials?|extras?)$")


def clean(s):
    s = re.sub(r"\[[^\]]*\]|\{[^}]*\}", " ", s)
    s = re.sub(r"[._]+", " ", s)
    s = JUNK.sub("", s)
    s = re.sub(r"\(\s*\)|\s+-\s*$|^\s*-\s+", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" -_.([")
    return s[:1].upper() + s[1:] if s.islower() else s


def safe(s):
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", s).replace("  ", " ").strip(" .")
    return s or "Unknown"


def show_year(show):
    """"Show 2019" / "Show.2019" -> "Show (2019)": servers use the year to tell remakes apart."""
    ym = YEAR.search(show)
    if ym and ym.start() > 0:
        return f"{show[:ym.start()].strip(' (')} ({ym.group(1)})"
    return show


def parse(path, root):
    """Guess what a video file is from its name and its folders."""
    rel = os.path.relpath(path, root)
    parts = rel.split(os.sep)
    folders, fname = parts[:-1], parts[-1]
    stem, ext = os.path.splitext(fname)
    kids = any(KIDS.match(f.strip()) for f in folders)
    it = {"kind": "movie", "title": "", "year": "", "season": "", "episode": "", "episode2": "", "eptitle": "", "kids": "yes" if kids else "",
          "note": "", "source": path, "ext": ext.lower()}
    for rx in TV_RX:
        m = rx.search(stem)
        if m:
            it.update(kind="tv", season=str(int(m.group(1))), episode=str(int(m.group(2))),
                      episode2=str(int(m.group(3))) if m.lastindex and m.lastindex >= 3 and m.group(3) else "")
            show = clean(stem[:m.start()])
            sd = [f for f in folders if not SEASON_DIR.match(f) and not GENERIC.match(clean(f))]
            if not show and sd:
                show = clean(sd[-1])
            show = show_year(show)
            it["title"] = show or "Unknown show"
            it["eptitle"] = clean(stem[m.end():]).strip(" -")
            if not show:
                it["note"] = "check: show name"
            return it
    # episode in a "Season N" folder with a name like "03 - Pilot.mp4" or "Episode 3"
    if folders and SEASON_DIR.match(folders[-1]):
        m = re.search(r"(?i)(?:^|\b(?:e|ep|episode)[ ._-]*)(\d{1,3})\b", stem)
        if m:
            show = show_year(next((clean(f) for f in reversed(folders[:-1]) if not GENERIC.match(clean(f))), ""))
            it["eptitle"] = clean(stem[m.end():]).strip(" -")
            it.update(kind="tv", season=str(int(SEASON_DIR.match(folders[-1]).group(1))), episode=str(int(m.group(1))),
                      title=show or "Unknown show", note="" if show else "check: show name")
            return it
    name = stem
    years = list(YEAR.finditer(name))
    if years and years[-1].start() > 0:
        y = years[-1]
        it["title"], it["year"] = clean(name[:y.start()]), y.group(1)
    else:
        parent = next((f for f in reversed(folders) if not GENERIC.match(clean(f)) and not KIDS.match(f.strip())), "")
        py = list(YEAR.finditer(parent)) if parent else []
        if py and py[-1].start() > 0 and clean(parent[:py[-1].start()]).lower()[:6] in clean(name).lower():
            it["title"], it["year"] = clean(parent[:py[-1].start()]), py[-1].group(1)
        else:
            it["title"] = clean(name)
            it["note"] = "check: no year"
    if not it["title"]:
        it["title"], it["note"] = clean(stem) or stem, "check: title"
    if re.fullmatch(r"(?i)(cd|disc|part|pt)\s*\d", it["title"]) or len(it["title"]) < 2:
        it["note"] = "check: title"
    return it


def target(it, lib):
    t, ext = safe(it["title"]), it.get("ext") or os.path.splitext(it["source"])[1].lower()
    kids = str(it.get("kids", "")).lower() in ("yes", "y", "1", "true", "x")
    if it["kind"] == "tv":
        s, e = int(it["season"] or 1), int(it["episode"] or 0)
        e2 = f"-E{int(it['episode2']):02d}" if it.get("episode2") else ""
        et = safe(it.get("eptitle") or "")[:80] if it.get("eptitle") else ""
        return os.path.join(lib, "Kids TV" if kids else "TV Shows", t, f"Season {s:02d}", f"{t} - S{s:02d}E{e:02d}{e2}{' - ' + et if et else ''}{ext}")
    name = f"{t} ({it['year']})" if it.get("year") else t
    return os.path.join(lib, "Kids Movies" if kids else "Movies", name, name + ext)


def scan(src, skip):
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not d.startswith((".", "$")) and d.lower() not in ("system volume information", "recycler")
                   and os.path.realpath(os.path.join(root, d)) not in skip]
        for f in files:
            p = os.path.join(root, f)
            if os.path.splitext(f)[1].lower() in VIDEO:
                try:
                    size = os.path.getsize(p)
                except OSError:
                    continue
                if re.search(r"(?i)\bsample\b", f) and size < 300e6:
                    continue
                yield p, size


FIELDS = ["action", "kind", "title", "year", "season", "episode", "episode2", "eptitle", "kids", "note", "size_gb", "source", "target"]


def plan(src, dest, lib, out):
    skip = {os.path.realpath(lib)}
    rows = []
    for p, size in scan(src, skip):
        it = parse(p, src)
        it["size_gb"] = f"{size / 1e9:.2f}"
        it["target"] = target(it, lib)
        it["action"] = "skip" if os.path.exists(it["target"]) and os.path.getsize(it["target"]) == size else "add"
        if it["action"] == "skip":
            it["note"] = "already on the drive"
        rows.append(it)
    seen = {}
    for r in rows:                                   # two files that would land in the same place
        if r["target"] in seen and r["action"] == "add":
            r["note"] = (r["note"] + "; " if r["note"] else "") + "check: duplicate of another file"
        seen[r["target"]] = 1
    rows.sort(key=lambda r: (r["kind"], r["title"].lower(), int(r["season"] or 0), int(r["episode"] or 0)))
    with open(out + ".csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, FIELDS, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    add = [r for r in rows if r["action"] == "add"]
    gb = sum(float(r["size_gb"]) for r in add)
    chk = [r for r in rows if r["note"].startswith("check") or "; check" in r["note"]]
    movies = len({r["target"] for r in add if r["kind"] == "movie"})
    shows = len({(r["kids"], r["title"]) for r in add if r["kind"] == "tv"})
    eps = sum(1 for r in add if r["kind"] == "tv")
    free = shutil.disk_usage(dest).free / 1e9
    tr = "".join(f"<tr class='{'chk' if r in chk else ''}'><td>{html.escape(r['note'])}</td><td>{'TV' if r['kind'] == 'tv' else 'Movie'}"
                 f"{' · Kids' if r['kids'] else ''}</td><td>{html.escape(os.path.relpath(r['target'], lib))}</td>"
                 f"<td>{html.escape(r['source'])}</td><td>{r['size_gb']}</td></tr>" for r in sorted(rows, key=lambda r: r not in chk))
    with open(out + ".html", "w", encoding="utf-8") as fh:
        fh.write(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Movies & TV plan</title><style>
body{{font:14px/1.45 system-ui;background:#14171a;color:#e6e8eb;padding:14px}}td,th{{border-bottom:1px solid #2c323a;padding:4px 6px;text-align:left;vertical-align:top}}
table{{border-collapse:collapse;width:100%}}.chk td:first-child{{color:#f0b429;font-weight:600}}.warn{{background:#3a2a10;padding:8px;border-radius:6px}}</style></head><body>
<h1>Movies &amp; TV — what will happen</h1>
<p><b>{movies}</b> movies and <b>{eps}</b> episodes of <b>{shows}</b> shows to add ({gb:,.0f} GB). Drive has {free:,.0f} GB free.
{len(rows) - len(add)} already on the drive. <b>{len(chk)}</b> marked <span style="color:#f0b429">check</span> (listed first).</p>
{"<p class='warn'>Not enough space for all of it — remove some rows from MEDIA-PLAN.csv (or set action to skip), or use another drive.</p>" if gb > free - 10 else ""}
<p>To fix a row: open <b>MEDIA-PLAN.csv</b> in Excel or Notepad and change <i>title</i>, <i>year</i>, <i>kind</i> (movie / tv), <i>season</i>,
<i>episode</i> or <i>kids</i> (yes / blank), or set <i>action</i> to <i>skip</i>. Save it as CSV. The target name is rebuilt from your changes.
Then run the APPLY step (copy keeps the originals; move deletes each original after its copy is verified).</p>
<table><tr><th>Note</th><th>Type</th><th>Will be saved as</th><th>From</th><th>GB</th></tr>{tr}</table></body></html>""")
    print(f"  {movies} movies, {eps} episodes of {shows} shows to add ({gb:,.0f} GB; {free:,.0f} GB free). {len(chk)} to check.")
    print(f"  Plan: {out}.html   (edit {out}.csv to fix names)")
    return rows


def copy_file(src, dst, size):
    tmp = dst + ".part"
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    done, t0 = 0, time.time()
    with open(src, "rb") as fi, open(tmp, "wb") as fo:
        while True:
            b = fi.read(8 << 20)
            if not b:
                break
            fo.write(b); done += len(b)
            if size > 200e6:
                rate = done / max(0.1, time.time() - t0) / 1e6
                print(f"\r    {done * 100 // max(1, size):3d}%  {rate:5.0f} MB/s", end="", flush=True)
    if size > 200e6:
        print("\r" + " " * 30 + "\r", end="")
    if os.path.getsize(tmp) != size:
        os.remove(tmp); raise OSError("copy size mismatch")
    shutil.copystat(src, tmp)
    os.replace(tmp, dst)


def apply(csv_path, lib, mode, dest):
    rows = list(csv.DictReader(open(csv_path, encoding="utf-8-sig")))
    todo = [r for r in rows if r.get("action", "add").strip().lower() not in ("skip", "no", "")]
    need = sum(os.path.getsize(r["source"]) for r in todo if os.path.exists(r["source"]))
    if mode == "copy" and need / 1e9 > shutil.disk_usage(dest).free / 1e9 - 10:
        print(f"  ! needs {need / 1e9:,.0f} GB but only {shutil.disk_usage(dest).free / 1e9:,.0f} GB free (keeping 10 GB spare)."
              " Set some rows to skip in the CSV and run again."); return
    log = open(os.path.join(lib, "organize-log.txt"), "a", encoding="utf-8")
    ok = bad = 0
    for i, r in enumerate(todo, 1):
        src = r["source"]
        if not os.path.exists(src):
            print(f"  - gone: {src}"); continue
        r["kind"] = "tv" if r.get("kind", "").strip().lower() in ("tv", "show", "episode", "series") else "movie"
        r["ext"] = os.path.splitext(src)[1].lower()
        dst = target(r, lib)
        size = os.path.getsize(src)
        if os.path.exists(dst):
            if os.path.getsize(dst) == size:
                continue
            base, ext = os.path.splitext(dst)
            k = 2
            while os.path.exists(f"{base} ({k}){ext}"):
                k += 1
            dst = f"{base} ({k}){ext}"
        print(f"  [{i}/{len(todo)}] {os.path.relpath(dst, lib)}")
        try:
            copy_file(src, dst, size)
            sb = os.path.splitext(src)[0]                    # subtitles that belong to it: Name.srt, Name.en.srt
            sdir = os.path.dirname(src)
            for f in os.listdir(sdir):
                fp = os.path.join(sdir, f)
                if os.path.splitext(f)[1].lower() in SUBS and fp.lower().startswith(sb.lower() + "."):
                    sd = os.path.splitext(dst)[0] + fp[len(sb):]
                    if not os.path.exists(sd):
                        shutil.copy2(fp, sd)
                    if mode == "move":
                        os.remove(fp)
            if mode == "move":
                os.remove(src)
            log.write(f"{time.strftime('%Y-%m-%d %H:%M')}\t{mode}\t{src}\t{dst}\n")
            ok += 1
        except OSError as e:
            bad += 1
            print(f"  ! {src}: {e}")
    log.close()
    print(f"  {ok} files {'moved' if mode == 'move' else 'copied'}{f', {bad} failed' if bad else ''}.")


def srt_to_vtt(srt, vtt):
    try:
        raw = open(srt, "rb").read()
        txt = raw.decode("utf-8-sig") if raw[:3] == b"\xef\xbb\xbf" else raw.decode("utf-8", "replace") if b"\xc3" in raw else raw.decode("cp1252", "replace")
        txt = re.sub(r"(\d\d:\d\d:\d\d),(\d\d\d)", r"\1.\2", txt.replace("\r\n", "\n"))
        with open(vtt, "w", encoding="utf-8") as fh:
            fh.write("WEBVTT\n\n" + txt)
        return True
    except OSError:
        return False


def catalog(dest, lib):
    """Build www/media/catalog.js + index.html from whatever is in the four media folders."""
    www = os.path.join(dest, "www")
    page_dir = os.path.join(www, "media")
    os.makedirs(page_dir, exist_ok=True)
    inside = os.path.realpath(lib).startswith(os.path.realpath(www) + os.sep)

    def href(p):
        if inside:
            return urllib.parse.quote(os.path.relpath(p, page_dir).replace(os.sep, "/"))
        return "file:///" + urllib.parse.quote(os.path.abspath(p).replace(os.sep, "/").lstrip("/"))
    items, gb = [], 0
    for cat in CATS:
        base = os.path.join(lib, cat)
        if not os.path.isdir(base):
            continue
        for root, _, files in os.walk(base):
            for f in sorted(files):
                stem, ext = os.path.splitext(f)
                if ext.lower() not in VIDEO:
                    continue
                p = os.path.join(root, f)
                size = os.path.getsize(p)
                gb += size / 1e9
                rel = os.path.relpath(p, base).split(os.sep)
                subs = []
                for g in files:
                    gs, ge = os.path.splitext(g)
                    if gs.startswith(stem) and ge.lower() in (".srt", ".vtt"):
                        vt = os.path.join(root, gs + ".vtt")
                        if ge.lower() == ".srt" and not os.path.exists(vt):
                            srt_to_vtt(os.path.join(root, g), vt)
                        if os.path.exists(vt):
                            lang = gs[len(stem):].strip(".") or "en"
                            subs.append([lang, href(vt)])
                subs = list({s[1]: s for s in subs}.values())
                e = {"c": cat, "p": href(p), "f": os.path.relpath(p, os.path.dirname(os.path.abspath(dest))), "z": round(size / 1e9, 2), "x": ext.lower().lstrip("."),
                     "w": 1 if ext.lower() in WEB_OK else 2 if ext.lower() == ".mkv" else 0}
                if subs:
                    e["sub"] = subs
                if "TV" in cat:
                    m = re.search(r"S(\d+)E(\d+)", stem)
                    e.update(show=rel[0], s=int(m.group(1)) if m else 0, e=int(m.group(2)) if m else 0,
                             t=re.sub(r"^.* - S\d+E\d+(-E\d+)?(\s*-\s*)?", "", stem) or (f"Episode {int(m.group(2))}" if m else stem))
                else:
                    m = re.search(r"\((\d{4})\)$", stem)
                    e.update(t=stem[:m.start()].strip() if m else stem, y=m.group(1) if m else "")
                items.append(e)
    with open(os.path.join(page_dir, "catalog.js"), "w", encoding="utf-8") as fh:
        fh.write("window.MEDIA=" + json.dumps({"items": items, "built": time.strftime("%Y-%m-%d"), "gb": round(gb)}, separators=(",", ":"),
                                               ensure_ascii=False) + ";\n")
    here = os.path.dirname(os.path.abspath(__file__))
    shutil.copy2(os.path.join(here, "media.html"), os.path.join(page_dir, "index.html"))
    nm = sum(1 for i in items if "Movies" in i["c"])
    print(f"  Movies & TV catalog: {nm} movies, {len(items) - nm} episodes ({gb:,.0f} GB) → www/media/index.html")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True, help="the OFFGRID folder")
    ap.add_argument("--src", help="folder or drive with your movies and shows, e.g. F:\\")
    ap.add_argument("--library", help="where the organized files go (default OFFGRID\\www\\media)")
    ap.add_argument("--apply", choices=("copy", "move"), help="do what MEDIA-PLAN.csv says")
    ap.add_argument("--catalog-only", action="store_true", help="just rebuild the catalog page")
    a = ap.parse_args()
    lib = os.path.abspath(a.library or os.path.join(a.dest, "www", "media"))
    os.makedirs(lib, exist_ok=True)
    os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
    out = os.path.join(a.dest, "REPORTS", "MEDIA-PLAN")
    if a.apply:
        if not os.path.exists(out + ".csv"):
            print("  No MEDIA-PLAN.csv yet — run the plan step first (with --src)."); return 1
        apply(out + ".csv", lib, a.apply, a.dest)
    elif a.src and not a.catalog_only:
        if not os.path.isdir(a.src):
            print(f"  ! {a.src} isn't a folder"); return 1
        print(f"  Looking through {a.src} (nothing is changed in this step)…")
        plan(os.path.abspath(a.src), a.dest, lib, out)
        return 0
    catalog(a.dest, lib)
    return 0


if __name__ == "__main__":
    sys.exit(main())
