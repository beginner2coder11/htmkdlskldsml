"""Your own documents and books: drop them in OFFGRID\\MY-FILES-INBOX (folders are fine), then START-HERE > L.

Each file is sorted into a Library section by the name of the folder it's in (or the file's own name):
  "Medical First Aid" -> Medical,  "Food Preservation" -> Food preservation,  "Hunting, Trapping" -> Survival,
  "Gardening", "Homesteading", "Rope, Knots" -> Homestead,  "Prepping & Disaster" -> Disasters, ... anything else -> My Files.
Exact duplicates of files already on the drive are dropped, so a big downloaded collection doesn't fill the drive twice.
Files are MOVED: each original is removed from the inbox once its copy is verified, so the inbox empties as it sorts.
Everything added is searchable from the home page and goes in TEXT-ONLY.
"""
import hashlib, os, re, shutil

INBOX = "MY-FILES-INBOX"
EXT = {".pdf", ".epub", ".mobi", ".azw3", ".txt", ".doc", ".docx", ".rtf", ".odt", ".htm", ".html", ".md", ".csv", ".xls", ".xlsx",
       ".jpg", ".jpeg", ".png", ".gif", ".mp3", ".m4a", ".mp4", ".m4v", ".djvu", ".cbz"}
RULES = [  # (regex on folder/file name, Library section) — first match wins
    (r"radio|ham\b|gmrs|antenna|comms?\b|communication", "Radios"),
    (r"medic|first.?aid|doctor|nurs|herbal|remed|pharm|dental|trauma|surgery|health", "Medical"),
    (r"preserv|canning|curing|smok|dehydrat|pickl|ferment|food.?stor", "Food preservation"),
    (r"water|well|filter|purif", "Water"),
    (r"garden|farm|seed|soil|compost|livestock|chicken|goat|homestead|rope|knot|cordage|blacksmith|woodwork|craft|build", "Homestead"),
    (r"solar|power|electric|battery|generator|energy", "Home Systems"),
    (r"weapon|firearm|gun|rifle|pistol|ammo|ammunition|reload", "Firearms"),
    (r"self.?defen|security|defen|martial|combat|fitness", "Security"),
    (r"vehicle|car\b|truck|engine|mechanic|motor", "Vehicles"),
    (r"prep|disaster|emergency|nuclear|pandemic|evacuat|grid", "Disasters"),
    (r"map|compass|navigat|star|weather", "Navigation & Sky"),
    (r"hunt|trap|fish|snare|game|forag|edible|wild.?food|plant|mushroom|bushcraft|fire|shelter|primitive|survival|wilderness|tracking", "Survival"),
    (r"army|military|marine|navy|field.?manual|\bfm[ _-]?\d|\btm[ _-]?\d", "Military Manuals"),
    (r"bible|scripture", "Books - Bible & Faith"),
    (r"child|kids|fairy", "Books - Children"),
    (r"history", "Books - History & Founding Documents"),
]


def section_for(rel):
    parts = rel.replace("\\", "/").split("/")
    for name in parts[:-1][::-1] + [parts[-1]]:            # nearest folder first, then the file name
        n = re.sub(r"^\s*\d+\s*[).:-]\s*|\(\d+\)\s*$", "", name).lower()
        for rx, sec in RULES:
            if re.search(rx, n):
                return sec
    return "My Files"


def _sha(path, n=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        while True:
            b = f.read(n)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _prune_empty(inbox):
    """Remove now-empty subfolders left behind after files are moved out (keep the inbox root)."""
    for root, _, _ in os.walk(inbox, topdown=False):
        if os.path.abspath(root) == os.path.abspath(inbox):
            continue
        try:
            if not os.listdir(root):
                os.rmdir(root)
        except OSError:
            pass


def build(u, dest):
    inbox = os.path.join(dest, INBOX)
    os.makedirs(inbox, exist_ok=True)
    rd = os.path.join(inbox, "README.txt")
    if not os.path.exists(rd):
        with open(rd, "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("Put your own documents and books here (folders are fine): PDFs, e-books, Word files, pictures.\n"
                     "Then run START-HERE.bat and pick L (Add my documents). They're sorted into the Library by folder name\n"
                     "(Medical, Survival, Homestead, Food preservation...), duplicates of files already on the drive are skipped,\n"
                     "and everything becomes searchable. Each file is MOVED into the Library once its copy is verified,\n"
                     "so this inbox empties itself as it sorts (this README stays). A file is only left here if it\n"
                     "couldn't be read/sorted or the copy couldn't be verified. Nothing is deleted until it's safely stored.\n")
    todo = []
    for root, _, files in os.walk(inbox):
        for f in files:
            if f == "README.txt" or f.startswith((".", "~$")) or os.path.splitext(f)[1].lower() not in EXT:
                continue
            todo.append(os.path.join(root, f))
    if not todo:
        return
    u.say(f"Your documents: {INBOX} → Library")
    lib = os.path.join(dest, "www", "library")
    by_size = {}
    for root, _, files in os.walk(lib):
        for f in files:
            p = os.path.join(root, f)
            try:
                by_size.setdefault(os.path.getsize(p), []).append(p)
            except OSError:
                pass
    added = dup = kept = 0
    counts = {}
    for src in sorted(todo):
        size = os.path.getsize(src)
        hs = _sha(src)
        same = by_size.get(size, [])
        if same and any(_sha(p) == hs for p in same):
            # already on the drive: it's sorted, so drop the inbox copy
            dup += 1
            try:
                os.remove(src)
            except OSError:
                kept += 1
            continue
        rel = os.path.relpath(src, inbox)
        sec = section_for(rel)
        out_dir = os.path.join(lib, sec)
        os.makedirs(out_dir, exist_ok=True)
        name = re.sub(r'[<>:"|?*]', "", os.path.basename(src))
        out = os.path.join(out_dir, name)
        b, x = os.path.splitext(out)
        k = 2
        while os.path.exists(out):
            out = f"{b} ({k}){x}"; k += 1
        shutil.copy2(src, out)
        by_size.setdefault(size, []).append(out)
        added += 1
        counts[sec] = counts.get(sec, 0) + 1
        # move, not copy: remove the original only after the copy is verified
        if os.path.getsize(out) == size and _sha(out) == hs:
            try:
                os.remove(src)
            except OSError:
                kept += 1
        else:
            kept += 1
    _prune_empty(inbox)
    moved = added + dup - kept
    print(f"  {added} added" + (f", {dup} already on the drive" if dup else "") +
          (": " + ", ".join(f"{s} {n}" for s, n in sorted(counts.items())) if counts else ""))
    print(f"  {moved} file(s) removed from {INBOX} after sorting" +
          (f"; {kept} left in place (could not verify or remove)" if kept else ""))
