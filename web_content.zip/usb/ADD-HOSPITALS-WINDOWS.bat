@echo off
REM Download the US hospitals layer (about 7,500 facilities: exact coordinates, phone, beds, trauma level, helipad)
REM and rebuild EXCEL-READY\US-hospitals.xlsx and GOOGLE-EARTH-READY\Hospitals.kml. Small download, a few minutes.
REM Optional: pass the drive letter, e.g.  ADD-HOSPITALS-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --hospitals-only
pause
