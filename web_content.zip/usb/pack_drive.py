"""Pack the whole OFF-GRID drive into compressed, checksummed volumes you can copy to ANY drive, or a stack
of flash drives, and unpack onto another computer's drive in a survival situation.

  python pack_drive.py --dest E:\\OFFGRID --out F:\\OFFGRID-PACK
      --volume-gb 4        size of each volume (default 4 = fits FAT32 flash drives; use 50-100 for big drives)
      --exclude movies,music,topo,khan   leave out the biggest optional parts (names or folder prefixes)
      --level 6            compression for text-like files (already-compressed files are stored as they are)
  Stop any time (Ctrl+C) and re-run the same command: it resumes at the last finished volume.

The output folder gets offgrid-0001.zip, offgrid-0002.zip ..., MANIFEST.json (checksums), restore_pack.py and
RESTORE-WINDOWS.bat. To restore on another computer (needs only Python 3):

  python restore_pack.py --src F:\\OFFGRID-PACK --dest D:\\OFFGRID --verify

Files bigger than a volume are split into pieces and reassembled on restore. Standard library only.
"""
import argparse, hashlib, json, os, shutil, sys, time, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
STORED_EXT = {".zim", ".pdf", ".mp4", ".mkv", ".avi", ".mov", ".m4v", ".webm", ".mp3", ".m4a", ".flac", ".ogg", ".opus",
              ".jpg", ".jpeg", ".png", ".gif", ".webp", ".zip", ".7z", ".gz", ".bz2", ".xz", ".tgz", ".gguf", ".pmtiles",
              ".pbf", ".apk", ".jar", ".whl", ".exe", ".msi", ".epub", ".docx", ".xlsx", ".hc"}
SHORTCUTS = {"movies": "www/media/", "music": "www/music/", "topo": "www/topo/", "khan": "kiwix/zim/khanacademy",
             "wikipedia": "kiwix/zim/wikipedia", "osm": "OSM-MAP-SOURCE/"}
SKIP_DIRS = {"__pycache__"}
SKIP_TOP = ("travel/", "backup/")   # hard-linked go-drive folders: never packed twice; index backups remade on the new drive
SKIP_EXT = (".part", ".tmp")
MARGIN = 16 << 20
CHUNK = 8 << 20


def gather(dest, excludes):
    out = []
    for root, dirs, files in os.walk(dest):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for f in sorted(files):
            if f.endswith(SKIP_EXT):
                continue
            p = os.path.join(root, f)
            rel = os.path.relpath(p, dest).replace("\\", "/")
            if rel.lower().startswith(SKIP_TOP) or any(rel.lower().startswith(x.lower()) for x in excludes):
                continue
            try:
                out.append((rel, p, os.path.getsize(p)))
            except OSError:
                pass
    return out


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(8 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True, help="the drive's OFFGRID folder")
    ap.add_argument("--out", required=True, help="folder for the pack volumes")
    ap.add_argument("--volume-gb", type=float, default=4.0)
    ap.add_argument("--exclude", default="", help="comma list: " + ", ".join(SHORTCUTS) + " or folder prefixes like www/media/")
    ap.add_argument("--level", type=int, default=6, choices=range(1, 10))
    a = ap.parse_args()
    excl = [SHORTCUTS.get(x.strip().lower(), x.strip().replace("\\", "/")) for x in a.exclude.split(",") if x.strip()]
    os.makedirs(a.out, exist_ok=True)
    if os.path.realpath(a.out).startswith(os.path.realpath(a.dest)):
        sys.exit("The output folder must not be inside the drive folder being packed.")
    limit = int(a.volume_gb * 1e9)
    files = gather(a.dest, excl)
    total = sum(f[2] for f in files)
    print(f"Packing {len(files):,} files, {total / 1e9:,.1f} GB -> {a.out}  (volumes of {a.volume_gb:g} GB)")
    state_p = os.path.join(a.out, "PACK-STATE.json")
    sig = {"n": len(files), "total": total, "vol": limit, "level": a.level, "excl": excl}
    st = {"sig": sig, "vol": 0, "idx": 0, "off": 0, "volumes": []}
    if os.path.exists(state_p):
        try:
            old = json.load(open(state_p))
            if old.get("sig") == sig:
                st = old
                print(f"  resuming after volume {st['vol']} (file {st['idx']:,} of {len(files):,})")
        except (OSError, ValueError):
            pass
    for f in os.listdir(a.out):
        if f.startswith("offgrid-") and f.endswith(".zip") and int(f[8:12]) > st["vol"]:
            os.remove(os.path.join(a.out, f))

    def save():
        tmp = state_p + ".tmp"
        json.dump(st, open(tmp, "w"))
        os.replace(tmp, state_p)

    t0 = time.time()
    done_bytes = sum(f[2] for f in files[:st["idx"]]) + st["off"]
    zf = None
    vpath = None
    vol_no = st["vol"]

    def new_volume():
        nonlocal zf, vol_no
        vol_no += 1
        path = os.path.join(a.out, f"offgrid-{vol_no:04d}.zip")
        zf = zipfile.ZipFile(path, "w", allowZip64=True)
        return path

    def close_volume():
        nonlocal zf
        zf.close()
        zf = None
        st["vol"] = vol_no
        st["volumes"].append({"file": os.path.basename(vpath), "bytes": os.path.getsize(vpath), "sha256": sha256_file(vpath)})
        save()
        print(f"  volume {vol_no:04d} done - {100 * done_bytes / max(1, total):.1f}% "
              f"({done_bytes / 1e9:,.1f}/{total / 1e9:,.1f} GB), {(time.time() - t0) / 60:.0f} min", flush=True)

    try:
        while st["idx"] < len(files):
            rel, p, size = files[st["idx"]]
            ext = os.path.splitext(rel)[1].lower()
            method = zipfile.ZIP_STORED if (ext in STORED_EXT or size < 512) else zipfile.ZIP_DEFLATED
            mtime = time.localtime(max(os.path.getmtime(p), 315532800))[:6]
            with open(p, "rb") as src:
                src.seek(st["off"])
                while True:
                    if zf is None:
                        vpath = new_volume()
                    used = zf.fp.tell()
                    room = limit - MARGIN - used
                    remaining = size - st["off"]
                    if room < (4 << 20) and used > 0 and remaining > room:
                        close_volume()
                        continue
                    take = min(remaining, max(room, 4 << 20))
                    whole = st["off"] == 0 and take == size
                    name = rel if whole else f"{rel}.__part__{st['off']}"
                    zi = zipfile.ZipInfo(name, mtime)
                    zi.compress_type = method
                    zi._compresslevel = a.level
                    with zf.open(zi, "w", force_zip64=True) as dst:
                        left = take
                        while left:
                            b = src.read(min(CHUNK, left))
                            if not b:
                                raise OSError(f"{rel} changed while packing")
                            dst.write(b)
                            left -= len(b)
                            done_bytes += len(b)
                    st["off"] += take
                    if st["off"] >= size:
                        break
                    close_volume()
            st["idx"] += 1
            st["off"] = 0
            if zf is not None and zf.fp.tell() >= limit - MARGIN:
                close_volume()
        if zf is not None:
            close_volume()
    except KeyboardInterrupt:
        print("\n  Stopped. Re-run the same command to resume at the last finished volume.")
        sys.exit(130)
    manifest = {"created": time.strftime("%Y-%m-%d %H:%M"), "files": len(files), "bytes": total,
                "volumes": st["volumes"], "sizes": {rel: s for rel, _, s in files}}
    with open(os.path.join(a.out, "MANIFEST.json"), "w", encoding="utf-8") as fh2:
        json.dump(manifest, fh2, separators=(",", ":"))
    shutil.copy2(os.path.join(HERE, "restore_pack.py"), os.path.join(a.out, "restore_pack.py"))
    with open(os.path.join(a.out, "RESTORE-WINDOWS.bat"), "w", newline="") as bat:
        bat.write('@echo off\r\ncd /d "%~dp0"\r\nset /p DST=Type the folder to restore into (for example D:\\OFFGRID): \r\n'
                  'python restore_pack.py --src "%~dp0." --dest "%DST%" --verify\r\npause\r\n')
    with open(os.path.join(a.out, "RESTORE-README.txt"), "w") as rd:
        rd.write("OFF-GRID DRIVE PACK\r\n\r\nTo restore: install Python 3 (or use any computer that has it), then run\r\n"
                 "  python restore_pack.py --src <this folder> --dest <new drive>\\OFFGRID --verify\r\n"
                 "Then open <new drive>\\OFFGRID\\START-HERE.bat (Windows) or start-here-mac-linux.sh.\r\n"
                 "If a restore stops, run it again: finished volumes are skipped.\r\n"
                 "Keep ALL offgrid-*.zip files and MANIFEST.json together.\r\n")
    try:
        os.remove(state_p)
    except OSError:
        pass
    tot = sum(v["bytes"] for v in st["volumes"])
    print(f"\nDone: {len(st['volumes'])} volumes, {tot / 1e9:,.1f} GB ({100 * tot / max(1, total):.0f}% of the original).")


if __name__ == "__main__":
    main()
