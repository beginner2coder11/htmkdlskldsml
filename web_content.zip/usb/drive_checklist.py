"""What the drive still needs: REPORTS\\DRIVE-CHECKLIST.txt / .html, regenerated at the end of every builder run.

Everything that can be checked from the drive's own files is checked (ticked or not); the rest are physical or
manual jobs that only you can confirm - those stay as an open list. Read-only: nothing on the drive is changed.
    python drive_checklist.py --dest E:\\OFFGRID
"""
import glob, html, json, os, re, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def _any(dest, *pats):
    return any(glob.glob(os.path.join(dest, *p.split("/")), recursive=True) for p in pats)


def _have(dest, rx):
    """True if any PDF in the library has a file name matching the regex (case-insensitive, any folder)."""
    r = re.compile(rx, re.I)
    for _, _, fs in os.walk(os.path.join(dest, "www", "library")):
        if any(f.lower().endswith(".pdf") and r.search(f) for f in fs):
            return True
    return False


def _count(dest, pat):
    return len(glob.glob(os.path.join(dest, *pat.split("/"))))


def _not_fetched(dest):
    n, names = 0, []
    for p in glob.glob(os.path.join(dest, "REPORTS", "NOT-FETCHED-*.txt")):
        try:
            k = sum(1 for ln in open(p, encoding="utf-8", errors="replace") if ln.strip() and not ln.startswith(("#", "=", "-")))
        except OSError:
            continue
        if k > 3:                   # header lines only -> nothing missing
            n += 1
            names.append(os.path.basename(p))
    return names


def items(dest):
    """[(section, text, state, how)] state: True done / False needed / None manual (only you can confirm)."""
    L = []
    add = lambda sec, text, st, how="": L.append((sec, text, st, how))
    lib = "www/library/**/"
    # --- documents that are not free to download by script
    add("Documents to place by hand", "Emergency Response Guidebook (ERG 2024) PDF", _have(dest, r"\bERG|erg_?20|emergency.?response.?guidebook"),
        "PHMSA refuses scripted downloads: save it from phmsa.dot.gov into MY-FILES-INBOX (Survival), then run the builder.")
    add("Documents to place by hand", "FCC amateur licence database (l_amat.zip)", _any(dest, "tools/fcc/l_amat*", "www/radio/**/l_amat*", "radio/**/l_amat*", "www/**/l_amat.zip"),
        "Download l_amat.zip from the FCC (data.fcc.gov) in a browser and put it in MY-RADIO-INBOX.")
    add("Documents to place by hand", "Survival & Austere Medicine (3rd ed., free PDF)", _have(dest, r"austere"),
        "Free from the authors / survivalblog links; put the PDF in MY-FILES-INBOX (it sorts to Medical).")
    add("Documents to place by hand", "Fallout shelter plans (FEMA H-12 / OCD family shelter designs)", _have(dest, r"fallout.?shelter|expedient.?shelter|H-?12"),
        "Public-domain civil defense plans on archive.org; add to MY-FILES-INBOX (Disasters).")
    # --- build output present
    add("Drive health", "Full-text search index built", os.path.exists(os.path.join(dest, "www", "search", "docs.js")), "Run the builder (the final step builds it).")
    add("Drive health", "Instant Ask index (docs-idx.js)", os.path.exists(os.path.join(dest, "www", "docs-idx.js")), "Runs in the 'Ask the Library index' step of the builder.")
    add("Drive health", "Meaning-based search index (find pages by meaning)", os.path.exists(os.path.join(dest, "www", "search", "vec", "all.i8")),
        "Built after the search index by the builder or OCR-OVERNIGHT (a few hours the first time, resumable).")
    add("Drive health", "AI model present", _count(dest, "ai/models/*.gguf") > 0, "Run the builder with AI enabled (not --no-ai).")
    add("Drive health", "Integrity checksums (REPORTS\\CHECKSUMS.json)", os.path.exists(os.path.join(dest, "REPORTS", "CHECKSUMS.json")), "Run VERIFY-DRIVE once to create them, then monthly.")
    add("Drive health", "Latest drive map", os.path.exists(os.path.join(dest, "REPORTS", "DRIVE-MAP.txt")), "Run MAP-DRIVE.bat.")
    bad = os.path.join(dest, "REPORTS", "UNREADABLE-FILES.txt")
    add("Drive health", "No damaged (unreadable) files on the drive", not os.path.exists(bad),
        "Windows reported damaged files (REPORTS\\UNREADABLE-FILES.txt). Close everything using the drive, open Command Prompt "
        "as administrator, run  chkdsk E: /f  (your drive letter), then run the builder again.")
    nf = _not_fetched(dest)
    add("Drive health", "No items skipped by the downloaders" + (f" ({len(nf)} report(s): {', '.join(nf)})" if nf else ""), not nf,
        "Open the NOT-FETCHED-*.txt files in REPORTS\\ ; most are sites that block scripts - save by hand.")
    # --- family
    vault = os.path.exists(os.path.join(dest, "family-vault.hc"))
    add("Family & personal", "Encrypted family vault (family-vault.hc) created", vault, "Create it with VeraCrypt (Family document vault guide) and keep PERSONAL\\ inside it.")
    try:
        import personal_files
        n, missing, soon = personal_files.summary(dest)
    except Exception:       # noqa: BLE001
        n, missing, soon = 0, None, []
    add("Family & personal", f"Personal papers filed in PERSONAL\\ ({n} files)", n > 0, "Drop files in MY-PERSONAL-FILES-INBOX and run the builder.")
    if missing:
        for m in missing:
            add("Family & personal", "Have on file: " + m, False, "Add it to MY-PERSONAL-FILES-INBOX (name the file so it contains the keyword).")
    for s in soon:
        add("Family & personal", "RENEW SOON: " + s, False, "See PERSONAL\\EXPIRING.txt.")
    # --- manual / physical (only you can confirm)
    for t, how in (
        ("Tested START-HERE / Command Center on the real Windows PC after the last build", "Builder and downloaders are untested outside your PC."),
        ("A second copy of the drive kept somewhere else (other house, fireproof box)", "COPY-TO-ANOTHER-DRIVE-WINDOWS.bat"),
        ("Spare microSD / small flash drive with the essentials (Micro pack) and card reader + USB-C/USB-A adapters", "Drive can't be read without a port that fits."),
        ("Printed one-page 'how to start' taped to the drive case or stored with it", "HOW-TO-USE-THIS-DRIVE has a printable page."),
        ("Drive stored in a Faraday bag / metal can (EMP/static protection) and away from magnets", "Optional but cheap."),
        ("Passwords kept in KeePassXC (not plain files) and the master password written down in a safe place", "Tools\\KeePassXC is on the drive."),
        ("Monthly reminder and weekly repair tasks turned on (SET-MONTHLY-REMINDER / SET-WEEKLY-REPAIR)", "Windows scheduled tasks."),
    ):
        add("Only you can confirm", t, None, how)
    return L


def write(dest):
    L = items(dest)
    rep = os.path.join(dest, "REPORTS")
    os.makedirs(rep, exist_ok=True)
    stamp = time.strftime("%Y-%m-%d %H:%M")
    open_n = sum(1 for _, _, s, _ in L if s is False)
    lines = [f"DRIVE CHECKLIST - what the drive still needs   (updated {stamp})", f"{open_n} item(s) still open that the builder can see; "
             "'[?]' items are yours to confirm.", ""]
    body, sec = [], None
    for s, t, st, how in L:
        if s != sec:
            sec = s
            lines += ["", s.upper()]
            body.append(f"<h2>{html.escape(s)}</h2>")
        mark = "[x]" if st else "[?]" if st is None else "[ ]"
        lines.append(f"  {mark} {t}" + (f"\n        -> {how}" if how and st is not True else ""))
        cls = "ok" if st else "man" if st is None else "todo"
        body.append(f'<div class="{cls}"><b>{mark}</b> {html.escape(t)}' + (f"<small>{html.escape(how)}</small>" if how and st is not True else "") + "</div>")
    with open(os.path.join(rep, "DRIVE-CHECKLIST.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("\n".join(lines) + "\n")
    page = ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>Drive checklist</title>"
            "<style>body{font:15px system-ui;max-width:800px;margin:1em auto;padding:0 1em}h2{margin:1.2em 0 .3em}div{padding:.35em .6em;border-left:4px solid #999;margin:.2em 0;background:#f6f6f6}"
            ".ok{border-color:#2a8;color:#555}.todo{border-color:#c33}.man{border-color:#c90}small{display:block;color:#666}</style>"
            f"<h1>Drive checklist</h1><p>Updated {stamp}. Rewritten at the end of every builder run. Green = done, red = the drive needs it, amber = only you can confirm.</p>"
            + "".join(body))
    with open(os.path.join(rep, "DRIVE-CHECKLIST.html"), "w", encoding="utf-8") as fh:
        fh.write(page)
    return open_n


def build(u, dest):
    n = write(dest)
    print(f"  Drive checklist: {n} open item(s) - see REPORTS\\DRIVE-CHECKLIST.html")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    a = ap.parse_args()
    print(write(a.dest), "open items")
