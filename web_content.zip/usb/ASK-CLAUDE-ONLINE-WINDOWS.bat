@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Ask Claude online over any internet connection (satellite, shelter Wi-Fi, phone hotspot) =====
REM Plain text, tiny data use. Needs an Anthropic API key (console.anthropic.com) - keep it in your password manager or vault.
cd /d "%~dp0"
title Ask Claude online
chcp 65001 >nul
set PYTHONUTF8=1
set "PY=tools\python-win\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" tools\builder\usb\ask_claude.py %*
pause
