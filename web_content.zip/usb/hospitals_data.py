"""US hospital directory (5,768 hospitals: emergency services yes/no, bed count, ownership) with coordinates.

The SimpleMaps basic hospital file has NO coordinates, so they are added here:
  * exact (OpenStreetMap)  - the hospital's own OSM point, matched by name within 30 miles of its city
  * city center            - the city's center from the cities list (a few miles off; flagged "approx")
Writes EXCEL-READY\\US-hospitals.xlsx and GOOGLE-EARTH-READY\\Hospitals.kml. Private-use data: the SimpleMaps
license forbids publishing it in bulk, so do not put these files on a public website or share the drive publicly.
"""
import csv
import glob
import html
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_STOP = {"hospital", "medical", "center", "centre", "the", "of", "and", "health", "regional", "memorial", "community", "system", "campus", "inc"}


def _toks(s):
    return {t for t in re.sub(r"[^a-z0-9 ]+", " ", s.lower()).split() if t not in _STOP and len(t) > 1}


def _miles(a, b, c, d):
    r = math.radians
    x = math.sin(r(c - a) / 2) ** 2 + math.cos(r(a)) * math.cos(r(c)) * math.sin(r(d - b) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(x))


def _osm_hospitals(dest):
    out = []
    try:
        t = open(os.path.join(dest, "www", "data", "pois.js"), encoding="utf-8").read()
        for r in json.loads(re.search(r"window\.POIS=(.*?);\n", t, re.S).group(1)):
            if r[0] == "hospital":
                out.append((r[1], r[2], r[3]))
    except (OSError, AttributeError, ValueError):
        pass
    for f in glob.glob(os.path.join(dest, "www", "data", "poi500", "*.js")):
        if os.path.basename(f) == "index.js":
            continue
        try:
            t = open(f, encoding="utf-8").read()
            out += [(r[1], r[2], r[3]) for r in json.loads(t[t.index('"]=') + 3:].rstrip().rstrip(";")) if r[0] == "hospital"]
        except (OSError, ValueError):
            pass
    return out


def load(dest):
    import cities_data, kml_export
    home = kml_export._home(dest)
    cities = {}
    for c in cities_data.load():
        k = (c[0].lower(), c[1])
        if k not in cities or c[5] > cities[k][2]:
            cities[k] = (c[3], c[4], c[5])
    osm = _osm_hospitals(dest)
    grid = {}
    for n, la, lo in osm:
        grid.setdefault((int(la), int(lo)), []).append((n, la, lo, _toks(n)))
    rows, exact = [], 0
    with open(os.path.join(HERE, "data", "us-hospitals.csv"), encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            cc = cities.get((r["city"].lower(), r["state_id"]))
            lat = lon = None
            q = "no coordinates"
            if cc:
                lat, lon, q = cc[0], cc[1], "approx (city center)"
                tk = _toks(r["hospital"]) | _toks(r["hospital_alt"])
                best = None
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        for n, la, lo, t2 in grid.get((int(cc[0]) + dy, int(cc[1]) + dx), []):
                            if _miles(cc[0], cc[1], la, lo) > 30 or not tk or not t2:
                                continue
                            sc = len(tk & t2) / max(1, min(len(tk), len(t2)))
                            if sc >= 0.67 and (best is None or sc > best[0]):
                                best = (sc, la, lo)
                if best:
                    lat, lon, q = round(best[1], 6), round(best[2], 6), "exact (OpenStreetMap)"
                    exact += 1
            rows.append({**r, "lat": lat, "lon": lon, "q": q, "miles": round(_miles(home[0], home[1], lat, lon), 1) if lat is not None else None})
    rows.sort(key=lambda r: (r["miles"] is None, r["miles"] or 0))
    return rows, exact


def _hifld(dest):
    try:
        return json.load(open(os.path.join(dest, "www", "data", "hifld", "hospitals.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _num(v):
    try:
        v = float(v)
        return int(v) if v > 0 else None
    except (TypeError, ValueError):
        return None


def merged(dest):
    """Rows for the sheet: HIFLD facilities (real coordinates, phone, trauma) with the SimpleMaps emergency flag added,
    plus any SimpleMaps hospitals HIFLD did not match (placed from OpenStreetMap or city center)."""
    base, exact = load(dest)
    hf = _hifld(dest)
    if not hf:
        blank = {"phone": "", "type": "", "status": "", "trauma": "", "helipad": "", "web": "", "er": "", "ownership_type": "", "beds": None,
                 "address": "", "city": "", "state_id": "", "zip": "", "hospital_alt": ""}
        out = []
        for r in base:      # the SimpleMaps list has no phone/trauma/helipad/web: fill them so the sheet and KML still build
            d = {**blank, **r, "src": "SimpleMaps"}
            d["er"] = d["er"] or ("Yes" if d.get("emergency_services") == "TRUE" else "No" if d.get("emergency_services") else "")
            d["beds"] = _num(d.get("bed_count")) or d["beds"]
            out.append(d)
        return out, exact, 0
    home = __import__("kml_export")._home(dest)
    byzip = {}
    for i, r in enumerate(base):
        byzip.setdefault((r["zip"] or "")[:5], []).append(i)
    used, rows = set(), []
    for h in hf:
        if str(h.get("status") or "").upper() == "CLOSED":
            continue
        try:
            la, lo = float(h["latitude"]), float(h["longitude"])
        except (TypeError, ValueError, KeyError):
            continue
        if not (-90 <= la <= 90 and -180 <= lo <= 180) or (la == 0 and lo == 0):
            continue
        tk = _toks(h.get("name") or "") | _toks(h.get("alt_name") or "")
        er = ownership = ""
        beds = _num(h.get("beds"))
        best = None
        for i in byzip.get(str(h.get("zip") or "")[:5], []):
            if i in used:
                continue
            t2 = _toks(base[i]["hospital"]) | _toks(base[i]["hospital_alt"])
            sc = len(tk & t2) / max(1, min(len(tk), len(t2))) if tk and t2 else 0
            if sc >= 0.5 and (best is None or sc > best[0]):
                best = (sc, i)
        if best:
            used.add(best[1])
            b = base[best[1]]
            er = "Yes" if b["emergency_services"] == "TRUE" else "No"
            ownership = b["ownership_type"]
            beds = beds or _num(b["bed_count"])
        rows.append({"hospital": h.get("name") or "", "hospital_alt": h.get("alt_name") or "", "address": h.get("address") or "", "city": h.get("city") or "",
                     "state_id": h.get("state") or "", "zip": h.get("zip") or "", "phone": h.get("telephone") if h.get("telephone") not in ("NOT AVAILABLE", None) else "",
                     "type": h.get("type") or "", "status": h.get("status") or "", "beds": beds, "trauma": h.get("trauma") if h.get("trauma") not in ("NOT AVAILABLE", None) else "",
                     "helipad": h.get("helipad") or "", "web": h.get("website") if h.get("website") not in ("NOT AVAILABLE", None) else "", "er": er, "ownership_type": ownership,
                     "lat": la, "lon": lo, "q": "exact (HIFLD)", "src": "HIFLD" + (" + SimpleMaps" if best else ""), "miles": round(_miles(home[0], home[1], la, lo), 1)})
    for i, b in enumerate(base):
        if i in used:
            continue
        rows.append({"hospital": b["hospital"], "hospital_alt": b["hospital_alt"], "address": b["address"], "city": b["city"], "state_id": b["state_id"], "zip": b["zip"],
                     "phone": "", "type": "", "status": "", "beds": _num(b["bed_count"]), "trauma": "", "helipad": "", "web": "",
                     "er": "Yes" if b["emergency_services"] == "TRUE" else "No", "ownership_type": b["ownership_type"], "lat": b["lat"], "lon": b["lon"],
                     "q": b["q"], "src": "SimpleMaps only", "miles": b["miles"]})
    rows.sort(key=lambda r: (r["miles"] is None, r["miles"] or 0))
    return rows, exact, len(used)


def build(u, dest):
    if not os.path.exists(os.path.join(HERE, "data", "us-hospitals.csv")):
        return
    u.say("Hospital directory (phone, ER, beds, trauma, coordinates)")
    import coords, xlsx_export
    rows, exact, matched = merged(dest)
    wb = xlsx_export.Workbook(os.path.join(dest, "EXCEL-READY", "US-hospitals.xlsx"))
    heads = ["Hospital", "Phone", "Miles from home", "Emergency services", "Beds", "Trauma level", "Helipad", "Type", "Ownership", "Latitude", "Longitude",
             "Location quality", "MGRS", "Address", "City", "State", "ZIP", "Website", "Also known as", "Data source"]

    def gen():
        for r in rows:
            yield [r["hospital"], r["phone"], r["miles"], r["er"], r["beds"], r["trauma"], r["helipad"], r["type"], r["ownership_type"], r["lat"], r["lon"], r["q"],
                   coords.mgrs(r["lat"], r["lon"]) if r["lat"] is not None else "", r["address"], r["city"], r["state_id"], r["zip"], r["web"], r["hospital_alt"], r["src"]]
    wb.sheet("Hospitals (nearest first)", heads, gen(), [40, 15, 10, 11, 8, 14, 9, 22, 20, 12, 12, 20, 18, 30, 18, 7, 8, 28, 28, 18])
    wb.close()
    esc = html.escape
    pm = ""
    for r in rows:
        if r["lat"] is None:
            continue
        er = {"Yes": "ER", "No": "no ER"}.get(r["er"], "")
        d = (f"{r['address']}, {r['city']} {r['state_id']} {r['zip']}" + (f" - Tel {r['phone']}" if r["phone"] else "") + (f" - {er}" if er else "") +
             (f", {r['beds']} beds" if r["beds"] else "") + (f", trauma {r['trauma']}" if r["trauma"] else "") + (", helipad" if str(r["helipad"]).upper() == "Y" else "") + f" - {r['q']}")
        pm += (f"<Placemark><name>{esc(r['hospital'])}{f' ({er})' if er else ''}</name><description>{esc(d)}</description>"
               f"<Point><coordinates>{r['lon']},{r['lat']},0</coordinates></Point></Placemark>\n")
    p = os.path.join(dest, "GOOGLE-EARTH-READY", "Hospitals.kml")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write('<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>US hospitals</name>\n' + pm + "</Document></kml>\n")
    if _hifld(dest):
        print(f"  {len(rows):,} hospitals ({matched:,} HIFLD facilities matched to the ER list); coordinates exact for HIFLD rows")
    else:
        print(f"  {len(rows):,} hospitals; {exact:,} placed exactly from OpenStreetMap, the rest at their city center (run ADD-HOSPITALS for exact coordinates + phone)")
