#!/usr/bin/env python3
"""USB web server for the OFF-GRID SURVIVAL DRIVE.

* static files with Range support (map tiles, APK downloads)
* /v1/*, /health      -> main AI (llama.cpp on :8080, started by the launcher)
* /vision/v1/*        -> photo model (Gemma 3 vision) — started on first use on :8081
* /medical/v1/*       -> MedGemma — started on first use on :8082
* /stt                -> whisper.cpp speech-to-text — started on first use on :8083
* /status             -> which features this drive/computer has (used by the Ask page)
* /zim-search?q=     -> live full-text search inside every Kiwix archive (incl. full Wikipedia) via kiwix-serve
                         on :8091, merged with the drive index on the Search and Ask pages
* /ai-target          -> use a bigger AI on ANOTHER computer (Jan, LM Studio, AnythingLLM, Ollama, another OFFGRID
                         drive...) instead of this drive's model: GET shows it, POST {"url": ...} sets it (this computer
                         only), {"url": ""} goes back to the drive's own AI. Kept in ai/remote-ai.json. If that computer
                         stops answering, questions fall back to the drive's own AI.

Helper models start only when someone uses them and stop after 20 idle minutes, and only one
helper model runs at a time, so a 16 GB laptop doesn't run out of memory.
Works from phones on the same Wi-Fi (except the microphone, which browsers only allow on localhost)."""
import argparse, json, os, re, signal, subprocess, sys, threading, time, urllib.error, urllib.request
from functools import partial
from http.server import ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serve import RangeHandler  # noqa: E402

AI = "http://127.0.0.1:8080"
CFG = {}
HELPERS = {"vision": 8081, "medical": 8082, "stt": 8083, "embed": 8094, "rerank": 8095}
RERANK_MODEL = "bge-reranker-v2-m3-Q4_K_M.gguf"   # re-sorts passages by how well they answer (ai_memory.py, v78)
PROCS, LAST = {}, {}
LOCK = threading.Lock()
IDLE = 20 * 60


KIWIX = "http://127.0.0.1:8091"


def _xml_items(xml):
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return []
    out = []
    for it in root.iter("item"):
        g = lambda tag: (it.findtext(tag) or "").strip()  # noqa: E731
        book = it.find("book")
        out.append({"t": g("title"), "link": g("link"), "snip": re.sub(r"<[^>]+>", "", g("description")),
                    "book": (book.findtext("title") if book is not None else "") or ""})
    return out


def zim_search(dest, q, n=8):
    """Kiwix full-text search across the archives. One multi-archive request first; if that server refuses
    (language mix or its archive limit), ask each archive separately (in parallel)."""
    from urllib.parse import quote
    from concurrent.futures import ThreadPoolExecutor

    def get(url, t=8):
        with urllib.request.urlopen(url, timeout=t) as r:
            return r.read()
    base = f"{KIWIX}/search?format=xml&pattern={quote(q)}"
    try:
        items = _xml_items(get(f"{base}&books.filter.lang=eng&pageLength={n}"))
        if items:
            return items[:n]
    except Exception:  # noqa: BLE001
        pass
    import glob as _g
    stems = [os.path.splitext(os.path.basename(z))[0] for z in sorted(_g.glob(os.path.join(dest, "kiwix", "zim", "*.zim")))][:24]
    if not stems:
        return []
    def one(stem):
        try:
            return _xml_items(get(f"{base}&books.name={quote(stem)}&pageLength=2", 6))
        except Exception:  # noqa: BLE001
            return []
    with ThreadPoolExecutor(8) as ex:
        res = list(ex.map(one, stems))
    out = [x for pair in zip(*[r + [None] * 2 for r in res]) for x in pair if x]   # round-robin: best of each archive first
    return out[:n]


def zim_text(link, limit=1800):
    """Plain text of a Kiwix article (for the AI's excerpts)."""
    try:
        with urllib.request.urlopen(KIWIX + link, timeout=8) as r:
            h = r.read().decode("utf-8", "replace")
        h = re.sub(r"(?is)<(script|style|nav|footer)[^>]*>.*?</\1>", " ", h)
        import html as _h
        return re.sub(r"\s+", " ", _h.unescape(re.sub(r"<[^>]+>", " ", h))).strip()[:limit]
    except Exception:  # noqa: BLE001
        return ""


def _remote_file():
    return os.path.join(os.path.dirname(CFG.get("www", ".")), "ai", "remote-ai.json")


def remote(key=False):
    """(base url without /v1, model id) of the other computer's AI, or (None, None) for the drive's own."""
    try:
        r = json.load(open(_remote_file(), encoding="utf-8"))
        out = (r.get("url") or None), r.get("model") or None
        return out + ((r.get("key") or ""),) if key else out
    except (OSError, ValueError):
        return (None, None, "") if key else (None, None)


def _hdr(key):
    return {"Authorization": "Bearer " + key} if key else {}


def _lan_ok(url):
    """Only home-network or this-computer addresses: this setting must never send questions to the internet."""
    import ipaddress, socket
    from urllib.parse import urlparse
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        return False
    try:
        infos = socket.getaddrinfo(u.hostname, u.port or 80, proto=socket.IPPROTO_TCP)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not (ip.is_private or ip.is_loopback or ip.is_link_local):
            return False
    return True


def set_remote(url, model="", key=""):
    url = (url or "").strip().rstrip("/")
    if url.endswith("/v1"):
        url = url[:-3]
    if url and "://" not in url:
        url = "http://" + url
    path = _remote_file()
    if not url:
        try:
            os.remove(path)
        except OSError:
            pass
        return {"ok": True, "url": "", "note": "Using this drive's own AI."}
    if not _lan_ok(url):
        return {"ok": False, "error": "Use an address on your own network (like 192.168.1.20:1234) — never an internet address."}
    try:
        with urllib.request.urlopen(urllib.request.Request(url + "/v1/models", headers=_hdr(key)), timeout=8) as r:
            ids = [m.get("id") for m in json.load(r).get("data", []) if m.get("id")]
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"No AI answered at {url}/v1 ({type(e).__name__}). Is the app's server on and allowed on the network?"}
    model = model if model in ids else (ids[0] if ids else "")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"url": url, "model": model, "models": ids, "key": key}, fh)
    return {"ok": True, "url": url, "model": model, "models": ids}


def _alive(role):
    p = PROCS.get(role)
    return p is not None and p.poll() is None


def _healthy(port, path="/health"):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=3) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def _stop(role):
    p = PROCS.pop(role, None)
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(10)
        except subprocess.TimeoutExpired:
            p.kill()


def available():
    roles = CFG.get("roles", {})
    out = {"main": True}
    for r in ("vision", "medical"):
        spec = roles.get(r) or {}
        out[r] = bool(CFG.get("ai_bin") and spec.get("mmproj")
                      and os.path.exists(os.path.join(CFG["models"], spec.get("model", "")))
                      and os.path.exists(os.path.join(CFG["models"], spec["mmproj"])))
    out["embed"] = bool(CFG.get("ai_bin") and os.path.exists(os.path.join(CFG["models"], "embeddinggemma-300M-Q8_0.gguf"))
                        and os.path.exists(os.path.join(CFG.get("www", "www"), "search", "vec", "all.i8")))
    out["rerank"] = bool(CFG.get("ai_bin") and os.path.exists(os.path.join(CFG["models"], RERANK_MODEL)))
    out["stt"] = bool(CFG.get("whisper") and os.path.exists(CFG["whisper"]) and os.path.exists(CFG.get("whisper_model") or ""))
    return out


def _mp(name):
    """Model path: the copy on this computer's own disk (COPY-AI-TO-THIS-COMPUTER, v80) when complete, else the drive."""
    drive = os.path.join(CFG["models"], name)
    loc = CFG.get("models_local")
    if loc:
        p = os.path.join(loc, name)
        try:
            if os.path.getsize(p) == os.path.getsize(drive):
                return p
        except OSError:
            pass
    return drive


def ensure(role):
    """Start a helper server if needed; returns (port, error)."""
    port = HELPERS[role]
    with LOCK:
        LAST[role] = time.time()
        if _alive(role):
            pass
        else:
            if not available().get(role):
                return None, f"{role} is not installed on this drive (re-run the builder)"
            if role in ("vision", "medical"):           # one helper model at a time
                for other in ("vision", "medical"):
                    if other != role:
                        _stop(other)
                spec = CFG["roles"][role]
                cmd = [CFG["ai_bin"], "-m", _mp(spec["model"]),
                       "--mmproj", _mp(spec["mmproj"]),
                       "--host", "127.0.0.1", "--port", str(port), "-c", "4096"] + CFG.get("ngl", [])
            elif role == "rerank":                          # passage re-sorter (~440 MB), started on first Ask
                thr = str(max(1, (os.cpu_count() or 2) - 1))
                cmd = [CFG["ai_bin"], "-m", _mp(RERANK_MODEL), "--embedding", "--pooling", "rank",
                       "--reranking", "--host", "127.0.0.1", "--port", str(port), "-c", "8192", "-b", "8192", "-ub", "8192",
                       "-t", thr] + CFG.get("ngl", [])
            elif role == "embed":                           # meaning-search model: small (334 MB), started on first use
                import semantic
                cmd = semantic.server_cmd(CFG["ai_bin"], _mp(semantic.MODEL), port)
            else:
                cmd = [CFG["whisper"], "-m", CFG["whisper_model"], "--host", "127.0.0.1", "--port", str(port)]
            log = open(os.path.join(CFG.get("logdir", "."), f"offgrid-{role}.log"), "ab")
            flags = 0x08000000 if os.name == "nt" else 0   # CREATE_NO_WINDOW
            try:
                PROCS[role] = subprocess.Popen(cmd, stdout=log, stderr=log, creationflags=flags)
            except OSError as e:
                return None, f"could not start {role}: {e}"
    path = "/health" if role != "stt" else "/"
    for _ in range(240):                                 # model load can take a few minutes on a slow CPU
        if _healthy(port, path):
            return port, None
        if not _alive(role):
            return None, f"{role} server stopped while loading (see offgrid-{role}.log; not enough memory?)"
        time.sleep(1)
    return None, f"{role} server is still loading — try again in a minute"


def reaper():
    while True:
        time.sleep(60)
        with LOCK:
            for role in list(PROCS):
                if time.time() - LAST.get(role, 0) > IDLE:
                    _stop(role)


# One-click programs for the Workspace page. Only these ids can be started, only from this computer.
# value = glob (relative to the drive folder) of the thing to open: a program, a script, or a folder.
ACTIONS = {
    "install": "SOFTWARE/INSTALL-MENU.bat", "software": "SOFTWARE",
    "vlc": "tools/vlc/vlc.exe", "sumatra": "tools/sumatra/SumatraPDF.exe", "kiwix-desktop": "kiwix/desktop/*/kiwix-desktop.exe",
    "kolibri": "tools/kolibri/START-KOLIBRI.bat", "check": "PROGRAMS/CHECK-DRIVE.bat", "doctor": "PROGRAMS/DRIVE-DOCTOR.bat",
    "verify": "PROGRAMS/VERIFY-DRIVE.bat", "repair": "PROGRAMS/REPAIR-DRIVE.bat", "update": "PROGRAMS/UPDATE-DRIVE-WINDOWS.bat",
    "add-maps": "PROGRAMS/ADD-MY-MAPS-WINDOWS.bat", "add-files": "PROGRAMS/ADD-MY-FILES-WINDOWS.bat",
    "add-movies": "PROGRAMS/ADD-MOVIES-AND-SHOWS-WINDOWS.bat", "add-music": "PROGRAMS/ADD-MUSIC-WINDOWS.bat",
    "add-radio": "PROGRAMS/ADD-MY-RADIO-FILES-WINDOWS.bat", "guide": "PROGRAMS/MAKE-A-GUIDE.bat", "pack": "PROGRAMS/PACK-DRIVE.bat",
    "copy": "PROGRAMS/COPY-TO-ANOTHER-DRIVE-WINDOWS.bat", "search-nobrowser": "PROGRAMS/SEARCH-NO-BROWSER-WINDOWS.bat",
    "protect": "PROGRAMS/PROTECT-FILES.bat", "unprotect": "PROGRAMS/UNPROTECT-FILES.bat",
    "drive-folder": ".", "reports": "REPORTS", "maps-inbox": "MY-MAPS-INBOX", "files-inbox": "MY-FILES-INBOX",
    "radio-inbox": "MY-RADIO-INBOX", "text-only": "TEXT-ONLY",
}


def _action_path(root, key):
    import glob
    pat = ACTIONS.get(key)
    if not pat:
        return None
    hits = sorted(glob.glob(os.path.join(root, *pat.split("/"))))
    return hits[0] if hits else None


def _open(path):
    if os.name == "nt":
        os.startfile(path)  # noqa: S606  (the drive's own file, picked from the allowlist above)
    elif os.path.isdir(path) or not path.endswith((".sh", ".bat")):
        subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", path])
    elif path.endswith(".sh"):
        subprocess.Popen(["sh", path], cwd=os.path.dirname(path))


_FT = {}
_SEM = {}


def _rerank(q, cands, demoted=()):
    """Re-sort [title, link, text] by how well each answers q (bge-reranker via llama-server). None if not available."""
    if len(cands) < 2 or not available().get("rerank"):
        return None
    try:
        port, err = ensure("rerank")
        if err:
            return None
        body = {"query": q, "documents": [(c[0] + "\n" + c[2])[:1600] for c in cands], "top_n": len(cands)}
        req = urllib.request.Request(f"http://127.0.0.1:{port}/v1/rerank", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as r:
            res = json.load(r).get("results", [])
        sc = {x["index"]: x.get("relevance_score", 0) for x in res}
        LAST["rerank"] = time.time()
        return [c for _, c in sorted(((sc.get(i, -99) - (5 if c[1] in demoted else 0), c) for i, c in enumerate(cands)),
                                     key=lambda t: -t[0])]
    except Exception:  # noqa: BLE001
        return None


def _meaning(dest, q, k=8):
    """[(score, doc, page_index)] closest in meaning to q, or [] when meaning search is not available."""
    if not available().get("embed"):
        return []
    try:
        import semantic
        if "s" not in _SEM:
            _SEM["s"] = semantic.Searcher(dest)
        port, err = ensure("embed")
        if err:
            return []
        qv = semantic._post(port, [semantic.QUERY + q], 60)[0]
        ix = _fulltext(dest)
        bykey = {d[6]: d for d in ix.docs} if ix else {}
        return [(sc, bykey[key], pg) for sc, key, pg in _SEM["s"].top(qv, k) if key in bykey]
    except Exception:  # noqa: BLE001
        return []


def _builder_path(dest):
    for d in (os.path.dirname(os.path.abspath(__file__)), os.path.join(dest, "tools", "builder", "usb")):
        if os.path.isdir(d) and d not in sys.path:
            sys.path.insert(0, d)       # search_cli / search_index / ai_memory live with the builder copy on the drive


def _fulltext(dest):
    """The full-text index (same files as the Search page), loaded once, on first use."""
    if "ix" not in _FT:
        try:
            _builder_path(dest)
            from search_cli import Index
            _FT["ix"] = Index(dest)
        except Exception:      # noqa: BLE001
            _FT["ix"] = None
    return _FT["ix"]


_IMG, _IMG_LOCK = {}, threading.Lock()


def _img_sig(dest):
    try:
        return os.path.getmtime(os.path.join(dest, "www", "tiles", "imagery", "info.json"))
    except OSError:
        return 0


class Handler(RangeHandler):
    def _api(self):
        """/api/actions (what exists on this drive) and /api/run?id=... ? this computer only."""
        if self.client_address[0] not in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            return self._send(403, b'{"error":"only from the computer the drive is plugged into"}')
        root = os.path.dirname(os.path.abspath(self.directory))
        path, _, query = self.path.partition("?")
        if path == "/api/actions":
            return self._send(200, json.dumps({k: bool(_action_path(root, k)) for k in ACTIONS}).encode())
        key = dict(p.split("=", 1) for p in query.split("&") if "=" in p).get("id", "")
        target = _action_path(root, key)
        if not target:
            return self._send(404, json.dumps({"error": "not on this drive yet"}).encode())
        try:
            _open(target)
        except Exception as e:  # noqa: BLE001
            return self._send(500, json.dumps({"error": str(e)[:200]}).encode())
        self._send(200, b'{"ok":true}')

    def _send(self, code, data, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _main(self, method):
        """Main-AI request: the other computer's AI when one is set (falls back to the drive's own if it is down)."""
        url, model, key = remote(key=True)
        body = self.rfile.read(int(self.headers.get("Content-Length") or 0)) if method == "POST" else None
        if url and self.path.startswith("/v1/"):
            b = body
            if b and model:
                try:
                    j = json.loads(b)
                    j["model"] = model                       # their server needs its own model name
                    for k in ("cache_prompt", "n_probs", "slot_id"):
                        j.pop(k, None)                       # llama.cpp-only options
                    b = json.dumps(j).encode()
                except ValueError:
                    pass
            try:
                urllib.request.urlopen(urllib.request.Request(url + "/v1/models", headers=_hdr(key)), timeout=4).close()
                return self._proxy(method, url, self.path, b, _hdr(key))
            except Exception:  # noqa: BLE001
                pass                                         # that computer is off: use the drive's own AI
        if url and self.path.startswith("/health"):
            try:
                urllib.request.urlopen(urllib.request.Request(url + "/v1/models", headers=_hdr(key)), timeout=4).close()
                return self._send(200, b'{"status":"ok","remote":true}')
            except Exception:  # noqa: BLE001
                pass
        return self._proxy(method, AI, self.path, body)

    def _target(self, method):
        if method == "GET":
            url, model = remote()
            return self._send(200, json.dumps({"url": url or "", "model": model or ""}).encode())
        if self.client_address[0] not in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            return self._send(403, b'{"ok":false,"error":"Change this on the computer the drive is plugged into."}')
        try:
            j = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        except ValueError:
            j = {}
        return self._send(200, json.dumps(set_remote(j.get("url", ""), j.get("model", ""), j.get("key", ""))).encode())

    def _proxy(self, method, base, path, body=None, extra=None):
        if method == "POST" and body is None:
            body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        req = urllib.request.Request(base + path, data=body, method=method,
                                     headers={"Content-Type": self.headers.get("Content-Type", "application/json"), **(extra or {})})
        try:
            with urllib.request.urlopen(req, timeout=1800) as r:
                ct = r.headers.get("Content-Type", "application/json")
                if ct.startswith("text/event-stream"):      # streamed answer: pass each piece on as it arrives
                    self.send_response(r.status)
                    self.send_header("Content-Type", ct)
                    self.send_header("Cache-Control", "no-cache")
                    self.end_headers()
                    while True:
                        piece = r.readline()
                        if not piece:
                            break
                        self.wfile.write(piece)
                        self.wfile.flush()
                    return
                self._send(r.status, r.read(), ct)
        except urllib.error.HTTPError as e:
            self._send(e.code, e.read() or b"{}")
        except Exception as e:  # noqa: BLE001
            self._send(502, json.dumps({"error": f"AI server not reachable: {e}"}).encode())

    def _helper(self, method, role, path):
        port, err = ensure(role)
        if err:
            if method == "POST":
                self.rfile.read(int(self.headers.get("Content-Length") or 0))
            return self._send(503, json.dumps({"error": err}).encode())
        LAST[role] = time.time()
        self._proxy(method, f"http://127.0.0.1:{port}", path)
        LAST[role] = time.time()

    def _ask_search(self):
        """Passages for the Ask page, best first:
        1. your verified notes and corrections (ai/memory/knowledge.db) - always first
        2. candidates from the fast full-text index + meaning search (12 + 8), sources you marked wrong pushed down
        3. re-sorted by the reranker model when it is installed, each page with the AI's own note on where it sits
        4. + up to 2 live archive articles (Kiwix) for archives that are not in the drive index"""
        from urllib.parse import urlparse, parse_qs
        q = (parse_qs(urlparse(self.path).query).get("q") or [""])[0][:300]
        dest = os.path.dirname(os.path.abspath(self.directory))
        out = []
        try:
            _builder_path(dest)
            import ai_memory
            for nid, kind, nq, text, made in ai_memory.notes_for(dest, q, 2):
                label = {"verified": "Your verified answer", "correction": "Your correction", "note": "Your note"}.get(kind, "Your note")
                out.append([f"{label} ({made[:10]}) - asked: {nq[:80]}", f"NOTE:{nid}", text[:1800]])
            demoted = ai_memory.demoted_for(dest, q)
        except Exception:  # noqa: BLE001
            ai_memory, demoted = None, set()
        try:
            ix = _fulltext(dest)
            if not ix or not q.strip():
                return self._send(200, json.dumps(out).encode())
            res = ix.search(q, 12)
            hits, words = res if res else ([], [])
            sem = [(d[3] + pg, d) for _, d, pg in _meaning(dest, q, 8)]
            mixed, seen = [], set()
            for pair in [x for t in zip(hits + [None] * 12, sem + [None] * 12) for x in t if x]:
                if pair[0] not in seen:
                    seen.add(pair[0])
                    mixed.append(pair)
            cands = []
            kdb = ai_memory.connect(dest, readonly=True) if ai_memory else None
            for pid, d in mixed[:16]:
                txt = ix.page_text(d, pid)
                if not txt:
                    continue
                i = pid - d[3]
                link = d[1] + (f"#page={i + 1}" if d[1].lower().endswith(".pdf") else
                               ("#" + d[5][i]) if d[5] and i < len(d[5]) and d[5][i] else "")
                ctx = ""
                if kdb:
                    try:
                        r = kdb.execute("SELECT ctx FROM context WHERE doc=? AND page=?", (d[6], i)).fetchone()
                        ctx = r[0] if r else ""
                    except Exception:  # noqa: BLE001
                        pass
                cands.append([d[0] + " (" + ix.where(pid, d) + ")", link, (f"[About this page: {ctx}]\n" if ctx else "") + txt[:1800]])
            if kdb:
                kdb.close()
            cands.sort(key=lambda c: c[1] in demoted or c[1].split("#")[0] in demoted)    # marked-wrong sources last
            cands = _rerank(q, cands, demoted) or cands
            out += cands[:5]
            if len(ix.shards) > 80:
                ix.shards.clear()
            try:                                    # + best live Kiwix articles (full Wikipedia etc.) when it is running
                indexed = {d[1].split("z=", 1)[1] for d in ix.docs if d[1].startswith("zim.html?z=")}
                for z in zim_search(dest, q, 6):
                    stem = z["link"].split("/content/", 1)[-1].split("/", 1)[0]
                    if len(out) >= 8 or stem in indexed:      # that archive is already in the drive index
                        continue
                    txt = zim_text(z["link"])
                    if len(txt) > 200:
                        out.append([f"{z['t']} ({z['book'] or 'archive'})", "KIWIX:" + z["link"], txt])
            except Exception:  # noqa: BLE001
                pass
            return self._send(200, json.dumps(out).encode())
        except Exception:      # noqa: BLE001  never break Ask because the index is missing or unreadable
            return self._send(200, json.dumps(out).encode())

    def _memory(self, method):
        """/memory/... : the AI's notebook (ai_memory.py). Asking and voting work from any device on the drive's Wi-Fi."""
        dest = os.path.dirname(os.path.abspath(self.directory))
        _builder_path(dest)
        import ai_memory
        path = self.path.split("?")[0]
        body = {}
        if method == "POST":
            try:
                body = json.loads(self.rfile.read(min(int(self.headers.get("Content-Length") or 0), 200000)) or b"{}")
            except ValueError:
                return self._send(400, b'{"error":"bad request"}')
        try:
            if path == "/memory/log":
                i = ai_memory.log_question(dest, str(body.get("q", "")), str(body.get("mode", "")), body.get("sources") or [],
                                           str(body.get("answer", "")))
                return self._send(200, json.dumps({"id": i}).encode())
            if path == "/memory/vote":
                ok = ai_memory.vote(dest, int(body.get("id", 0)), int(body.get("v", 0)), str(body.get("correction", "")))
                return self._send(200, json.dumps({"ok": ok}).encode())
            if path == "/memory/note":
                ai_memory.add_note(dest, str(body.get("q", "")), str(body.get("text", "")))
                return self._send(200, b'{"ok":true}')
            if path == "/memory/delete":
                ai_memory.delete_note(dest, int(body.get("id", 0)))
                return self._send(200, b'{"ok":true}')
            if path == "/memory/list":
                return self._send(200, json.dumps(ai_memory.history(dest)).encode())
            if path == "/memory/guide":
                p = os.path.join(dest, "ai", "memory", "drive-guide.txt")
                return self._send(200, open(p, "rb").read() if os.path.exists(p) else b"", "text/plain; charset=utf-8")
        except Exception as e:  # noqa: BLE001
            return self._send(500, json.dumps({"error": str(e)[:200]}).encode())
        return self.send_error(404)

    def _imagery(self):
        """/imagery/{z}/{x}/{y}: one satellite layer from tiles/imagery/*.mbtiles + the NAIP folder (see imagery.py)."""
        try:
            z, x, y = (int(v) for v in self.path.split("?")[0].split("/")[2:5])
        except ValueError:
            return self.send_error(404)
        dest = os.path.dirname(os.path.abspath(self.directory))
        with _IMG_LOCK:
            key = _img_sig(dest)
            if _IMG.get("sig") != key:
                if _IMG.get("r"):
                    _IMG["r"].close()
                d = os.path.join(dest, "tools", "builder", "usb")
                if os.path.isdir(d) and d not in sys.path:
                    sys.path.insert(0, d)
                import imagery
                _IMG.update(sig=key, r=imagery.Reader(dest))
            data = _IMG["r"].get(z, x, y)
        if not data:
            return self.send_error(404)
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg" if data[:2] == b"\xff\xd8" else "image/png")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/imagery/"):
            return self._imagery()
        if self.path.startswith("/api/"):
            return self._api()
        if self.path.startswith("/meaning"):
            from urllib.parse import urlparse, parse_qs
            q = (parse_qs(urlparse(self.path).query).get("q") or [""])[0][:300]
            dest = os.path.dirname(os.path.abspath(self.directory))
            ix = _fulltext(dest)
            out = []
            for sc, d, pg in (_meaning(dest, q, 12) if q.strip() else []):
                pid = d[3] + pg
                link = d[1] + (f"#page={pg + 1}" if d[1].lower().endswith(".pdf") else "")
                out.append({"t": d[0], "where": ix.where(pid, d), "href": link, "s": round(sc, 3),
                            "snip": (ix.page_text(d, pid) or "")[:240]})
            return self._send(200, json.dumps(out).encode())
        if self.path.startswith("/memory/"):
            return self._memory("GET")
        if self.path.startswith("/ask-search"):
            return self._ask_search()
        if self.path == "/status":
            st = available()
            st["running"] = [r for r in PROCS if _alive(r)]
            st["fulltext"] = os.path.exists(os.path.join(self.directory, "search", "docs.js"))
            url, model = remote()
            st["remote"] = {"url": url or "", "model": model or ""}
            st["outage"] = bool(CFG.get("lean"))
            return self._send(200, json.dumps(st).encode())
        for role in ("vision", "medical"):
            if self.path.startswith(f"/{role}/"):
                return self._helper("GET", role, self.path[len(role) + 1:])
        if self.path.startswith("/ai-target"):
            return self._target("GET")
        if self.path.startswith("/fts?"):            # fast full-text search (SQLite FTS5) for the Search page
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(self.path).query)
            dest = os.path.dirname(os.path.abspath(self.directory))
            try:
                ix = _fulltext(dest)
                import search_db
                groups = [[w for w in g.split("|") if w][:8] for g in (qs.get("g") or [""])[0].split(",") if g][:12]
                rows, mode = search_db.query(dest, groups, qs.get("ph", [])[:4], (qs.get("ex") or [""])[0].split(",")[:8] if qs.get("ex") else (),
                                             [c for c in (qs.get("cat") or []) if c][:30], 3000)
                meta = search_db.info(dest)
                return self._send(200, json.dumps({"rows": rows, "mode": mode, "pages": int(meta.get("pages", -1)),
                                                   "ok": rows is not None and bool(ix)}).encode())
            except Exception as ex:  # noqa: BLE001
                return self._send(200, json.dumps({"ok": False, "error": str(ex)[:200]}).encode())
        if self.path.startswith("/zim-search"):
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(self.path).query)
            q = (qs.get("q") or [""])[0][:200]
            n = min(20, int((qs.get("n") or ["8"])[0] or 8))
            dest = os.path.dirname(os.path.abspath(self.directory))
            return self._send(200, json.dumps(zim_search(dest, q, n) if q.strip() else []).encode())
        if self.path.startswith(("/v1/", "/health")):
            return self._main("GET")
        if self.path.startswith("/props"):
            return self._proxy("GET", AI, self.path)
        return super().do_GET()

    def do_POST(self):
        if self.path.startswith("/api/run"):
            return self._api()
        for role in ("vision", "medical"):
            if self.path.startswith(f"/{role}/"):
                return self._helper("POST", role, self.path[len(role) + 1:])
        if self.path.startswith("/stt"):
            return self._helper("POST", "stt", "/inference")
        if self.path.startswith("/ai-target"):
            return self._target("POST")
        if self.path.startswith("/memory/"):
            return self._memory("POST")
        if self.path.startswith("/v1/"):
            return self._main("POST")
        if self.path.startswith("/completion"):
            return self._proxy("POST", AI, self.path)
        self.send_error(404)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="www")
    ap.add_argument("--port", type=int, default=8090)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--ai-bin", help="llama-server executable (for the photo and medical models)")
    ap.add_argument("--models", default="ai/models")
    ap.add_argument("--roles", default="ai/roles.json")
    ap.add_argument("--ngl", default="", help="e.g. 99 to put helper models on the GPU")
    ap.add_argument("--models-local", default="", help="copy of the models on this computer's disk (used when complete)")
    ap.add_argument("--lean", action="store_true", help="outage mode: no model preloading, helpers on the CPU")
    ap.add_argument("--whisper", help="whisper-server executable")
    ap.add_argument("--whisper-model", default="ai/whisper/ggml-base.en.bin")
    ap.add_argument("--logdir", default=os.environ.get("TEMP") or os.environ.get("TMPDIR") or "/tmp")
    a = ap.parse_args()
    try:
        roles = json.load(open(a.roles))
    except (OSError, ValueError):
        roles = {}
    CFG["www"] = os.path.abspath(a.dir)
    CFG.update(ai_bin=a.ai_bin if a.ai_bin and os.path.exists(a.ai_bin) else None, models=a.models, roles=roles,
               ngl=["-ngl", a.ngl] if a.ngl else [], whisper=a.whisper, whisper_model=a.whisper_model, logdir=a.logdir,
               models_local=a.models_local, lean=a.lean)
    if a.lean:
        CFG["ngl"] = []
    threading.Thread(target=reaper, daemon=True).start()
    if available().get("embed") and not a.lean:     # load the small meaning-search model now, so the first search is quick
        threading.Thread(target=lambda: ensure("embed"), daemon=True).start()
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))      # launcher stopping us -> stop helper models too
    srv = ThreadingHTTPServer((a.bind, a.port), partial(Handler, directory=os.path.abspath(a.dir)))
    print(f"Off-grid USB server: http://localhost:{a.port}/home.html  (Ctrl+C to stop)")
    print("  features:", ", ".join(k for k, v in available().items() if v))
    try:
        srv.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        for r in list(PROCS):
            _stop(r)
