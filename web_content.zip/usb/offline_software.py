"""Offline program installers (Windows) for a computer that doesn't have them.

Everything is downloaded once while you have internet into  <drive>\\SOFTWARE\\<category>\\  and works with no
internet afterwards. SOFTWARE\\INSTALL-MENU.bat lists what is on the drive and installs the ones you pick.
Only free / open-source programs, plus Google Earth Pro (free) for the KMZ files.
"""
import glob, html, json, os, re, shutil

# (category, name, what it is for, source, approx MB, big)   source: ("gh", repo, regex) | ("url", url, filename) | ("fn", name)
CATALOG = [
    ("Maps and navigation", "QGIS", "Full desktop mapping: opens the GeoPDFs, GeoTIFFs, KML/KMZ and the drive's map layers, with live GPS.",
     ("fn", "qgis"), 1500, True),
    ("Maps and navigation", "Google Earth Pro", "Opens the KMZ/KML files (map coverage, military bases, every place). Needs its own imagery cache for offline use.",
     ("url", "https://dl.google.com/dl/earth/client/advanced/current/googleearthprowin-7.3.6-x64.exe", "GoogleEarthPro-Setup.exe"), 70, False),
    ("Maps and navigation", "Stellarium", "Planetarium: find north, time and latitude from the stars and moon with no internet.",
     ("gh", "Stellarium/stellarium", r"win64.*\.exe$"), 250, False),
    ("Calculators and tools", "Qalculate!", "Powerful calculator with unit and currency-free conversions, dates, bases and equations.",
     ("gh", "Qalculate/qalculate-gtk", r"qalculate.*x64\.msi$"), 40, False),
    ("Calculators and tools", "7-Zip", "Opens .zip, .7z, .tar, .iso and the drive's compressed packs.",
     ("gh", "ip7z/7zip", r"7z\d+-x64\.exe$"), 2, False),
    ("Calculators and tools", "Notepad++", "Text editor for the plain-text copies, GPX/KML files and scripts.",
     ("gh", "notepad-plus-plus/notepad-plus-plus", r"Installer\.x64\.exe$"), 5, False),
    ("Calculators and tools", "KeePassXC", "Offline password manager for the family vault.",
     ("gh", "keepassxreboot/keepassxc", r"Win64\.msi$"), 20, False),
    ("Documents and reading", "LibreOffice", "Word processor, spreadsheet and slides. Opens Word/Excel files and prints guides.",
     ("fn", "libreoffice"), 350, True),
    ("Documents and reading", "Calibre", "E-book reader and converter for the Gutenberg library and your own books.",
     ("gh", "kovidgoyal/calibre", r"calibre-64bit-.*\.msi$"), 150, False),
    ("Documents and reading", "Tesseract OCR", "Makes scanned (picture-only) PDFs searchable. The drive's OCR step uses it.",
     ("gh", "UB-Mannheim/tesseract", r"w64-setup.*\.exe$"), 50, False),
    ("Documents and reading", "DocFetcher", "Offline full-text search of the library, PDFs, Office files and e-mail with no AI (index a folder once, then search).",
     ("url", "https://downloads.sourceforge.net/project/docfetcher/docfetcher/1.1.27/DocFetcher-1.1.27-Windows-64bit-Setup.exe", "DocFetcher-1.1.27-Windows-64bit-Setup.exe"), 122, False),
    ("AI apps", "Jan", "Free, open-source offline AI chat app. Can use this drive's AI (Settings > Model Providers) or run its own models; see Connect AI apps.",
     ("gh", "janhq/jan", r"x64[-_]setup\.exe$"), 150, False),
    ("AI apps", "AnythingLLM Desktop", "Free, open-source chat over your own documents. Point it at this drive's AI (Generic OpenAI); install for current user only. Unsigned, Defender may warn.",
     ("url", "https://cdn.anythingllm.com/latest/AnythingLLMDesktop.exe", "AnythingLLMDesktop.exe"), 350, False),
    ("Web browser", "Firefox ESR", "A browser for the drive's Home page on a computer that has none.",
     ("url", "https://download.mozilla.org/?product=firefox-esr-latest&os=win64&lang=en-US", "Firefox-ESR-Setup.exe"), 90, False),
]
# Not installed by the Windows menu: run-from-drive (portable) copies for each system, kept under SOFTWARE\\Portable\\
EXTRA = [("DocFetcher Windows portable", "https://downloads.sourceforge.net/project/docfetcher/docfetcher/1.1.27/DocFetcher-1.1.27-Windows-64bit-Portable.zip"),
         ("DocFetcher Linux portable", "https://downloads.sourceforge.net/project/docfetcher/docfetcher/1.1.27/DocFetcher-1.1.27-Linux-64bit-Portable.zip"),
         ("DocFetcher macOS portable", "https://downloads.sourceforge.net/project/docfetcher/docfetcher/1.1.27/DocFetcher-1.1.27-macOS-64bit-Portable.dmg")]
NOT_PROGRAMS = ("Medical, food, power and navigation calculators are built into the drive's Home page "
                "(calculators.html), and medical references are in the Kiwix archives, so they need no installer.")


def _qgis(u):
    page = u.fetch("https://qgis.org/downloads/", 60).decode("utf-8", "replace")
    names = set(re.findall(r"QGIS-OSGeo4W-[\d.]+-\d+\.msi", page))
    if not names:
        return None
    key = lambda n: [int(x) for x in re.findall(r"\d+", n)]  # noqa: E731
    n = max(names, key=key)
    return n, "https://qgis.org/downloads/" + n


def _libreoffice(u):
    base = "https://download.documentfoundation.org/libreoffice/stable/"
    vers = re.findall(r'href="(\d+\.\d+\.\d+)/"', u.fetch(base, 60).decode("utf-8", "replace"))
    if not vers:
        return None
    v = max(vers, key=lambda s: [int(x) for x in s.split(".")])
    n = f"LibreOffice_{v}_Win_x86-64.msi"
    return n, f"{base}{v}/win/x86_64/{n}"


FN = {"qgis": _qgis, "libreoffice": _libreoffice}


def _resolve(u, src):
    if src[0] == "gh":
        return u.gh_asset(src[1], src[2])
    if src[0] == "url":
        return src[2], src[1]
    return FN[src[1]](u)


def _bat_text(s):
    return re.sub(r"[&()<>|^%!\"]", " ", s)


def _write_menu(root, items):
    L = ["@echo off", 'cd /d "%~dp0"', "title Install offline programs", ":menu", "cls",
         "echo.", "echo   Install programs from this drive (no internet needed)", "echo   ======================================",
         "echo   Windows may ask permission for each one.", "echo."]
    for i, (cat, name, desc, rel) in enumerate(items, 1):
        L.append(f"echo   {i:>2}  {_bat_text(name)}  -  {_bat_text(desc)[:70]}")
    L += ["echo    A  Install everything above", "echo    0  Quit", "echo.", "set N=", "set /p N=Type a number: "]
    L += ["if /i \"%N%\"==\"0\" exit /b", "if /i \"%N%\"==\"A\" goto all"]
    for i, (_, _, _, rel) in enumerate(items, 1):
        L.append(f'if "%N%"=="{i}" call :inst "%~dp0{rel.replace("/", chr(92))}"')
    L += ["pause", "goto menu", ":all"]
    for _, _, _, rel in items:
        L.append(f'call :inst "%~dp0{rel.replace("/", chr(92))}"')
    L += ["pause", "goto menu", ":inst",
          'if not exist %1 (echo   missing %1 & goto :eof)',
          'echo   Installing %~nx1 ...',
          'if /i "%~x1"==".msi" (msiexec /i %1) else (start /wait "" %1)', "goto :eof"]
    with open(os.path.join(root, "INSTALL-MENU.bat"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("\n".join(L) + "\n")


def _write_readme(root, items):
    rows = "".join(f"<tr><td>{html.escape(cat)}</td><td><a href='{html.escape(rel)}'>{html.escape(name)}</a></td>"
                   f"<td>{html.escape(desc)}</td></tr>" for cat, name, desc, rel in items)
    with open(os.path.join(root, "README.html"), "w", encoding="utf-8") as fh:
        fh.write("<!doctype html><meta charset=utf-8><title>Offline programs</title>"
                 "<style>body{font:16px system-ui;max-width:60rem;margin:1.5rem auto;padding:0 1rem}td,th{border-bottom:1px solid #ccc;padding:.4rem;text-align:left;vertical-align:top}</style>"
                 "<h1>Offline programs</h1><p>Windows installers that work with no internet. Double-click "
                 "<b>INSTALL-MENU.bat</b> to pick and install, or open an installer directly. Mac/Linux: use your package "
                 "manager, or the QGIS, LibreOffice, Kiwix and Stellarium downloads for those systems while online.</p>"
                 f"<table><tr><th>Group</th><th>Program</th><th>For</th></tr>{rows}</table><p>{html.escape(NOT_PROGRAMS)}</p>")


def _adopt_inbox(dest, root):
    """Programs you drop in MY-FILES-INBOX (installers, portable zips/dmgs) are moved into SOFTWARE\\ and listed."""
    inbox = os.path.join(dest, "MY-FILES-INBOX")
    mine = []
    if not os.path.isdir(inbox):
        return mine
    for f in sorted(glob.glob(os.path.join(inbox, "*"))):
        low = os.path.basename(f).lower()
        if not os.path.isfile(f) or low.endswith(".part"):
            continue
        ext = os.path.splitext(low)[1]
        if ext in (".exe", ".msi"):
            sub = "My programs"
        elif ext in (".dmg", ".appimage", ".deb", ".rpm") or (ext == ".zip" and re.search(r"portable|nonportable|windows|linux|macos", low)):
            sub = "Portable"
        else:
            continue
        folder = os.path.join(root, sub)
        os.makedirs(folder, exist_ok=True)
        target = os.path.join(folder, os.path.basename(f))
        try:
            if os.path.exists(target):
                os.remove(f)
            else:
                shutil.move(f, target)
        except OSError as ex:
            print(f"  ! could not move {os.path.basename(f)}: {ex}")
            continue
        print(f"  moved {os.path.basename(f)} from MY-FILES-INBOX to SOFTWARE\\{sub}")
    for f in glob.glob(os.path.join(root, "My programs", "*")):
        if f.lower().endswith((".exe", ".msi")):
            name = re.sub(r"(?i)[ _-]*(setup|installer|v?\d[\d.]*)", " ", os.path.splitext(os.path.basename(f))[0]).strip() or os.path.basename(f)
            mine.append(("My programs", name, "Added by you (MY-FILES-INBOX).", os.path.relpath(f, root).replace(os.sep, "/")))
    return mine


def build(u, dest, big=True):
    u.say("Offline program installers (Windows)")
    root = os.path.join(dest, "SOFTWARE")
    os.makedirs(root, exist_ok=True)
    have, new = [], 0
    mine = _adopt_inbox(dest, root)
    for cat, name, desc, src, mb, is_big in CATALOG:
        if is_big and not big:
            continue
        folder = os.path.join(root, re.sub(r"[^A-Za-z0-9 ]+", "", cat).strip())
        try:
            found = _resolve(u, src)
        except Exception as ex:  # noqa: BLE001
            print(f"  ! {name}: {str(ex)[:100]}")
            found = None
        stem = {"7-Zip": "7z", "Notepad++": "npp", "Tesseract OCR": "tesseract"}.get(name) or re.sub(r"[^a-z0-9]+", "", name.lower())
        existing = [f for f in glob.glob(os.path.join(folder, "*")) if os.path.isfile(f) and not f.endswith(".part")
                    and stem in re.sub(r"[^a-z0-9]+", "", os.path.basename(f).lower())]
        if found:
            fname, url = found
            target = os.path.join(folder, fname)
            if u.download(url, target, f"{name} (~{mb} MB)"):
                new += 0 if target in existing else 1
                for old in existing:
                    if os.path.abspath(old) != os.path.abspath(target):
                        try:
                            os.remove(old)
                        except OSError:
                            pass
                existing = [target]
        if existing:
            have.append((cat, name, desc, os.path.relpath(max(existing, key=os.path.getmtime), root).replace(os.sep, "/")))
        else:
            print(f"  - {name}: not available this run (re-run later)")
    if big:
        pdir = os.path.join(root, "Portable")
        os.makedirs(pdir, exist_ok=True)
        for label, url in EXTRA:
            target = os.path.join(pdir, url.rsplit("/", 1)[1])
            if not os.path.exists(target) and not u.download(url, target, f"{label} (~120 MB)"):
                print(f"  - {label}: not available this run (re-run later)")
    have += mine
    if have:
        _write_menu(root, have)
        _write_readme(root, have)
    print(f"  {len(have)} programs ready in SOFTWARE\\ ({new} new)")
