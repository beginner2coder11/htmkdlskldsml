"""Periodic repair: re-run ONLY what is missing or broken on the OFF-GRID drive.

  1. quick-checks the big files against REPORTS\\CHECKSUMS.json (deletes damaged re-downloadable ones),
  2. re-runs the builder with the same options as the original build — it skips everything already finished
     and downloads just what is missing (route places that timed out, interrupted archives, new OCR pages...),
  3. refreshes the checksum list and writes REPORTS\\REPAIR-LOG.txt.

  python repair_drive.py --dest E:\\OFFGRID          (needs internet; safe to stop and re-run)
  python repair_drive.py --dest E:\\OFFGRID --offline   only the checks, no downloads

The scheduled task from SET-WEEKLY-REPAIR-WINDOWS.bat runs this whenever the drive is plugged in.
"""
import argparse, json, os, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
VALUE_OPTS = ("lat", "lon", "label", "radius", "models", "os", "maxzoom", "topo_radius", "topo_pdf_radius", "flood_radius", "areas",
              "city_radius", "base_buffer", "profile", "geofabrik", "kolibri_channels", "languages", "army_pubs")
FLAG_OPTS = ("gpu", "no_areas", "no_south_tiles", "no_map", "no_topo", "no_tiles", "no_flood", "no_phone", "no_vault",
             "no_voice", "no_big", "no_zim", "no_manuals", "no_ai", "no_extra_data", "no_software", "no_languages", "no_mil_pubs", "no_weather", "delete_osm_source")


def online():
    try:
        urllib.request.urlopen("https://download.kiwix.org/", timeout=10).close()
        return True
    except Exception:  # noqa: BLE001
        return False


def builder_args(dest):
    try:
        saved = json.load(open(os.path.join(dest, "tools", "build-options.json")))
    except (OSError, ValueError):
        saved = {}
    args = []
    for k in VALUE_OPTS:
        if saved.get(k) not in (None, ""):
            args += ["--" + k.replace("_", "-"), str(saved[k])]
    args += ["--" + k.replace("_", "-") for k in FLAG_OPTS if saved.get(k)]
    return args


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", required=True)
    ap.add_argument("--offline", action="store_true")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.dest, "REPORTS"), exist_ok=True)
    log = open(os.path.join(a.dest, "REPORTS", "REPAIR-LOG.txt"), "w", encoding="utf-8")

    def run(title, cmd):
        line = f"\n=== {title} ({time.strftime('%H:%M')}) ==="
        print(line); log.write(line + "\n")
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace")
        for out in p.stdout:
            print(out, end=""); log.write(out); log.flush()
        return p.wait()

    py = sys.executable
    man = os.path.join(a.dest, "REPORTS", "CHECKSUMS.json")
    if os.path.exists(man):
        run("Quick check of big files", [py, os.path.join(HERE, "verify_drive.py"), "--dest", a.dest, "--quick", "--repair"])
    if a.offline or not online():
        if not a.offline:
            print("\n  No internet — skipping downloads. Run again when you are online.")
    else:
        run("Re-running the builder (only missing items download)",
            [py, os.path.join(HERE, "usb_builder.py"), "--dest", a.dest, *builder_args(a.dest)])
    run("Refreshing checksums", [py, os.path.join(HERE, "verify_drive.py"), "--dest", a.dest, "--create"])
    run("Health report", [py, os.path.join(HERE, "check_usb.py"), "--dest", a.dest])
    log.close()


if __name__ == "__main__":
    main()
