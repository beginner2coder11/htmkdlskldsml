# Monthly reminder for the OFF-GRID SURVIVAL DRIVE (installed by SET-MONTHLY-REMINDER-WINDOWS.bat)
Add-Type -AssemblyName PresentationFramework
$bat = Get-PSDrive -PSProvider FileSystem | ForEach-Object { Join-Path $_.Root 'OFFGRID\PROGRAMS\UPDATE-DRIVE-WINDOWS.bat'; Join-Path $_.Root 'OFFGRID\UPDATE-DRIVE-WINDOWS.bat' } |
       Where-Object { Test-Path $_ } | Select-Object -First 1
if ($bat) {
  $r = [System.Windows.MessageBox]::Show("Time for the monthly OFF-GRID drive update.`n`nRun it now? It needs internet and can take a while; you can stop it and resume later.", "OFF-GRID drive", "YesNo", "Question")
  if ($r -eq "Yes") { Start-Process -FilePath $bat -WorkingDirectory (Split-Path $bat) }
} else {
  [void][System.Windows.MessageBox]::Show("Monthly reminder: plug in the OFF-GRID drive and run START-HERE.bat > 7 (Update the drive).", "OFF-GRID drive", "OK", "Information")
}
