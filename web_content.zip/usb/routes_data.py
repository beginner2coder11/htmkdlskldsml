# -*- coding: utf-8 -*-
"""Get-home routes from Josh's work-travel cities back to Canton, GA.

Each route has:
  line  — ordered [lat, lon] waypoints that draw the corridor on the locator map (approximate; follows the interstates)
  spots — key points (chokepoints, border/river crossings, refuel/rest hubs). These get detailed 7.5' topo quads
          and a resource search (water/food/medical/shelter/fuel) around them.
Coordinates are approximate town/junction centers — good enough to show the corridor and place map markers.
Used by usb_builder.py: writes www/data/routes.js for the map, adds topo areas, and fetches POIs along the way.
"""
HOME = {"name": "Canton, GA (home)", "lat": 34.237, "lon": -84.491}

# kind: choke | border | river | hub   (hub = refuel/rest waypoint)
ROUTES = [
 {"key": "richmond", "label": "Richmond, VA", "miles": 525, "drive": "~8 hr",
  "line": [[37.541,-77.436],[37.228,-77.401],[36.520,-78.090],[35.994,-78.899],[36.073,-79.792],
           [35.227,-80.843],[35.072,-81.650],[34.852,-82.394],[34.146,-83.595],[33.902,-84.270],[34.237,-84.491]],
  "spots": [
    {"name":"Petersburg, VA — I-85 start / refuel","lat":37.228,"lon":-77.401,"kind":"hub"},
    {"name":"Roanoke River crossing (VA/NC line)","lat":36.520,"lon":-78.090,"kind":"river"},
    {"name":"Charlotte, NC — bypass on I-485","lat":35.227,"lon":-80.843,"kind":"choke"},
    {"name":"Atlanta, GA — bypass north on I-285/I-575","lat":33.902,"lon":-84.270,"kind":"choke"}]},

 {"key": "manassas", "label": "Manassas, VA", "miles": 575, "drive": "~9 hr",
  "line": [[38.751,-77.475],[38.918,-78.195],[38.449,-78.869],[38.149,-79.072],[37.784,-79.443],
           [37.271,-79.941],[36.955,-81.092],[35.913,-80.760],[35.227,-80.843],[34.852,-82.394],
           [33.902,-84.270],[34.237,-84.491]],
  "spots": [
    {"name":"Front Royal, VA — I-66 meets I-81","lat":38.918,"lon":-78.195,"kind":"hub"},
    {"name":"Roanoke, VA — valley pinch-point","lat":37.271,"lon":-79.941,"kind":"choke"},
    {"name":"Wytheville, VA — I-81 meets I-77","lat":36.955,"lon":-81.092,"kind":"hub"},
    {"name":"Charlotte, NC — bypass on I-485","lat":35.227,"lon":-80.843,"kind":"choke"},
    {"name":"Atlanta, GA — bypass north on I-285/I-575","lat":33.902,"lon":-84.270,"kind":"choke"}]},

 {"key": "leesburg", "label": "Leesburg, VA", "miles": 590, "drive": "~9.5 hr",
  "line": [[39.116,-77.564],[38.918,-78.195],[38.449,-78.869],[38.149,-79.072],[37.271,-79.941],
           [36.955,-81.092],[35.913,-80.760],[35.227,-80.843],[34.852,-82.394],[33.902,-84.270],[34.237,-84.491]],
  "spots": [
    {"name":"Front Royal, VA — get west to I-81","lat":38.918,"lon":-78.195,"kind":"hub"},
    {"name":"Roanoke, VA — valley pinch-point","lat":37.271,"lon":-79.941,"kind":"choke"},
    {"name":"Wytheville, VA — I-81 meets I-77","lat":36.955,"lon":-81.092,"kind":"hub"},
    {"name":"Charlotte, NC — bypass on I-485","lat":35.227,"lon":-80.843,"kind":"choke"},
    {"name":"Atlanta, GA — bypass north on I-285/I-575","lat":33.902,"lon":-84.270,"kind":"choke"}]},

 {"key": "dulles", "label": "Washington Dulles (IAD)", "miles": 585, "drive": "~9 hr",
  "line": [[38.953,-77.456],[38.918,-78.195],[38.449,-78.869],[38.149,-79.072],[37.271,-79.941],
           [36.955,-81.092],[35.913,-80.760],[35.227,-80.843],[34.852,-82.394],[33.902,-84.270],[34.237,-84.491]],
  "spots": [
    {"name":"Front Royal, VA — I-66 west to I-81","lat":38.918,"lon":-78.195,"kind":"hub"},
    {"name":"Roanoke, VA — valley pinch-point","lat":37.271,"lon":-79.941,"kind":"choke"},
    {"name":"Wytheville, VA — I-81 meets I-77","lat":36.955,"lon":-81.092,"kind":"hub"},
    {"name":"Charlotte, NC — bypass on I-485","lat":35.227,"lon":-80.843,"kind":"choke"},
    {"name":"Atlanta, GA — bypass north on I-285/I-575","lat":33.902,"lon":-84.270,"kind":"choke"}]},

 {"key": "toronto", "label": "Toronto, ON", "miles": 875, "drive": "~14 hr",
  "line": [[43.653,-79.383],[42.984,-81.246],[42.317,-83.040],[41.664,-83.555],[39.759,-84.192],
           [39.103,-84.512],[38.041,-84.504],[35.961,-83.921],[35.046,-85.310],[34.237,-84.491]],
  "spots": [
    {"name":"Windsor–Detroit border crossing","lat":42.317,"lon":-83.040,"kind":"border"},
    {"name":"Detroit, MI — cross and keep moving south","lat":42.331,"lon":-83.046,"kind":"choke"},
    {"name":"Cincinnati, OH — I-75 squeeze","lat":39.103,"lon":-84.512,"kind":"choke"},
    {"name":"Knoxville, TN — I-75 / I-40 hub","lat":35.961,"lon":-83.921,"kind":"hub"},
    {"name":"Chattanooga, TN — refuel before GA","lat":35.046,"lon":-85.310,"kind":"hub"},
    {"name":"Atlanta, GA — branch to I-575 before downtown","lat":33.902,"lon":-84.270,"kind":"choke"}]},

 {"key": "quebec", "label": "Québec City, QC", "miles": 1300, "drive": "~20 hr",
  "line": [[46.814,-71.208],[45.502,-73.567],[45.080,-73.370],[44.699,-73.452],[42.652,-73.757],
           [43.048,-76.147],[41.409,-75.663],[40.273,-76.886],[39.642,-77.720],[38.449,-78.869],
           [36.955,-81.092],[35.227,-80.843],[33.902,-84.270],[34.237,-84.491]],
  "spots": [
    {"name":"Lacolle–Champlain border crossing","lat":45.080,"lon":-73.370,"kind":"border"},
    {"name":"Albany, NY — cut WEST on I-90 (avoid NYC)","lat":42.652,"lon":-73.757,"kind":"choke"},
    {"name":"Syracuse, NY — pick up I-81 South","lat":43.048,"lon":-76.147,"kind":"hub"},
    {"name":"Scranton, PA — I-81 funnel","lat":41.409,"lon":-75.663,"kind":"choke"},
    {"name":"Harrisburg, PA — I-81 funnel","lat":40.273,"lon":-76.886,"kind":"choke"},
    {"name":"Wytheville, VA — I-81 meets I-77","lat":36.955,"lon":-81.092,"kind":"hub"},
    {"name":"Atlanta, GA — branch to I-575 before downtown","lat":33.902,"lon":-84.270,"kind":"choke"}]},
]

def _box(lat, lon, miles):
    import math
    dlat = miles / 69.0
    dlon = miles / (69.0 * max(0.1, math.cos(math.radians(lat))))
    return [round(lon - dlon, 4), round(lat - dlat, 4), round(lon + dlon, 4), round(lat + dlat, 4)]

def _route_points(r):
    """A route's key spots PLUS the destination city itself (line[0]) — so the place you're
    actually traveling to gets its own topo coverage and resource search, not just the waypoints."""
    dest = {"name": f"{r['label']} — destination area", "lat": r["line"][0][0], "lon": r["line"][0][1]}
    return [dest] + list(r["spots"])


def topo_spots(box_miles=11):
    """-> [{group,name,lat,lon,bbox}] for extras.topo_areas (deduped by rounded coords)."""
    out, seen = [], set()
    for r in ROUTES:
        for s in _route_points(r):
            k = (round(s["lat"], 2), round(s["lon"], 2))
            if k in seen:
                continue
            seen.add(k)
            out.append({"group": "Get-home routes", "name": s["name"],
                        "lat": s["lat"], "lon": s["lon"], "bbox": _box(s["lat"], s["lon"], box_miles)})
    return out

def poi_centers():
    """-> [(lat, lon)] unique key-spot centers to search for resources along the routes."""
    out, seen = [], set()
    for r in ROUTES:
        for s in _route_points(r):
            k = (round(s["lat"], 2), round(s["lon"], 2))
            if k not in seen:
                seen.add(k); out.append((s["lat"], s["lon"]))
    return out
