// Lat/lon <-> DMS, UTM, MGRS (WGS84). Same math as tools/builder/usb/coords.py.
(function (g) {
  const A = 6378137, F = 1 / 298.257223563, K0 = 0.9996, E2 = F * (2 - F), EP2 = E2 / (1 - E2);
  const COL = ["ABCDEFGH", "JKLMNPQR", "STUVWXYZ"], ROW = ["ABCDEFGHJKLMNPQRSTUV", "FGHJKLMNPQRSTUVABCDE"];
  const BANDS = "CDEFGHJKLMNPQRSTUVWXX", R = Math.PI / 180;
  function dms(lat, lon) {
    const one = (v, p, n) => {
      const h = v >= 0 ? p : n; v = Math.abs(v);
      let d = Math.floor(v), m = Math.floor((v - d) * 60), s = (v - d - m / 60) * 3600;
      if (s >= 59.95) { s = 0; m++; } if (m === 60) { m = 0; d++; }
      return `${d}°${String(m).padStart(2, "0")}'${s.toFixed(1).padStart(4, "0")}"${h}`;
    };
    return one(lat, "N", "S") + " " + one(lon, "E", "W");
  }
  function zone(lat, lon) {
    let z = Math.floor((lon + 180) / 6) + 1; if (z > 60) z = 60;
    if (lat >= 56 && lat < 64 && lon >= 3 && lon < 12) z = 32;
    if (lat >= 72 && lat < 84) for (const [lo, hi, zz] of [[0, 9, 31], [9, 21, 33], [21, 33, 35], [33, 42, 37]]) if (lon >= lo && lon < hi) z = zz;
    return z;
  }
  const M = p => A * ((1 - E2 / 4 - 3 * E2 ** 2 / 64 - 5 * E2 ** 3 / 256) * p - (3 * E2 / 8 + 3 * E2 ** 2 / 32 + 45 * E2 ** 3 / 1024) * Math.sin(2 * p)
    + (15 * E2 ** 2 / 256 + 45 * E2 ** 3 / 1024) * Math.sin(4 * p) - (35 * E2 ** 3 / 3072) * Math.sin(6 * p));
  function utm(lat, lon) {
    const z = zone(lat, lon), p = lat * R, l = lon * R, l0 = ((z - 1) * 6 - 180 + 3) * R;
    const N = A / Math.sqrt(1 - E2 * Math.sin(p) ** 2), T = Math.tan(p) ** 2, C = EP2 * Math.cos(p) ** 2, a = Math.cos(p) * (l - l0);
    const e = K0 * N * (a + (1 - T + C) * a ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * EP2) * a ** 5 / 120) + 500000;
    let n = K0 * (M(p) + N * Math.tan(p) * (a * a / 2 + (5 - T + 9 * C + 4 * C * C) * a ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * EP2) * a ** 6 / 720));
    if (lat < 0) n += 10000000;
    const band = lat >= -80 && lat <= 84 ? BANDS[Math.max(0, Math.min(20, Math.floor((lat + 80) / 8)))] : "Z";
    return [z, band, e, n];
  }
  const pad = (v, k) => String(Math.floor(v)).padStart(k, "0");
  function utmStr(lat, lon) { const [z, b, e, n] = utm(lat, lon); return `${z}${b} ${pad(e, 6)}E ${pad(n, 7)}N`; }
  function mgrs(lat, lon, digits = 5) {
    const [z, b, e, n] = utm(lat, lon), f = 10 ** (5 - digits);
    return `${z}${b} ${COL[(z - 1) % 3][Math.floor(e / 100000) - 1]}${ROW[(z - 1) % 2][Math.floor(n / 100000) % 20]} ` +
      `${pad(Math.floor(e % 100000) / f, digits)} ${pad(Math.floor(n % 100000) / f, digits)}`;
  }
  function utmToLatLon(z, north, e, n) {
    if (!north) n -= 10000000;
    const e1 = (1 - Math.sqrt(1 - E2)) / (1 + Math.sqrt(1 - E2));
    const mu = n / K0 / (A * (1 - E2 / 4 - 3 * E2 ** 2 / 64 - 5 * E2 ** 3 / 256));
    const p = mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * Math.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * Math.sin(4 * mu)
      + (151 * e1 ** 3 / 96) * Math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * Math.sin(8 * mu);
    const N1 = A / Math.sqrt(1 - E2 * Math.sin(p) ** 2), T1 = Math.tan(p) ** 2, C1 = EP2 * Math.cos(p) ** 2;
    const R1 = A * (1 - E2) / (1 - E2 * Math.sin(p) ** 2) ** 1.5, D = (e - 500000) / (N1 * K0);
    const lat = p - (N1 * Math.tan(p) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * EP2) * D ** 4 / 24
      + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * EP2 - 3 * C1 * C1) * D ** 6 / 720);
    const lon = (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * EP2 + 24 * T1 * T1) * D ** 5 / 120) / Math.cos(p);
    return [lat / R, (z - 1) * 6 - 180 + 3 + lon / R];
  }
  function parseMgrs(s) {
    const m = s.toUpperCase().replace(/\s/g, "").match(/^(\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\d*)$/);
    if (!m || m[5].length % 2) return null;
    const z = +m[1], band = m[2], d = m[5], k = d.length / 2, f = 10 ** (5 - k);
    const ci = COL[(z - 1) % 3].indexOf(m[3]), ri = ROW[(z - 1) % 2].indexOf(m[4]);
    if (ci < 0 || ri < 0) return null;
    const e = (ci + 1) * 100000 + (+d.slice(0, k) || 0) * f + f / 2;
    let n = ri * 100000 + (+d.slice(k) || 0) * f + f / 2;
    const nmin = utm(-80 + BANDS.indexOf(band) * 8, (z - 1) * 6 - 177)[3];
    while (n < nmin - 100000) n += 2000000;
    return utmToLatLon(z, band >= "N", e, n);
  }
  // "34.2387, -84.4513" or "34 14 19.3 N 84 27 04.7 W" or an MGRS reference -> [lat, lon] or null
  function parseAny(s) {
    s = s.trim();
    const g1 = parseMgrs(s); if (g1) return g1;
    const dd = s.match(/^(-?\d+(?:\.\d+)?)[,\s]+(-?\d+(?:\.\d+)?)$/); if (dd) return [+dd[1], +dd[2]];
    const parts = s.toUpperCase().match(/(\d+(?:\.\d+)?)\D+(\d+(?:\.\d+)?)?\D*(\d+(?:\.\d+)?)?\D*?([NS])\W*(\d+(?:\.\d+)?)\D+(\d+(?:\.\d+)?)?\D*(\d+(?:\.\d+)?)?\D*?([EW])/);
    if (parts) {
      const v = (d, m, s2, h) => ((+d) + (+m || 0) / 60 + (+s2 || 0) / 3600) * (h === "S" || h === "W" ? -1 : 1);
      return [v(parts[1], parts[2], parts[3], parts[4]), v(parts[5], parts[6], parts[7], parts[8])];
    }
    return null;
  }
  function parseUtm(s) { // "16S 713000E 3790000N" / "16S 713000 3790000"
    const m = s.trim().toUpperCase().match(/^(\d{1,2})\s*([C-HJ-NP-X])\s+(\d{5,7})(?:\.\d+)?\s*E?[\s,]+(\d{6,8})(?:\.\d+)?\s*N?$/);
    return m ? utmToLatLon(+m[1], m[2] >= "N", +m[3], +m[4]) : null;
  }
  g.COORDS = { dms, utm, utmStr, mgrs, parseMgrs, parseAny, parseUtm, utmToLatLon, all: (la, lo) => ({ dd: `${la.toFixed(5)}, ${lo.toFixed(5)}`, dms: dms(la, lo), utm: utmStr(la, lo), mgrs: mgrs(la, lo) }) };
})(typeof window !== "undefined" ? window : globalThis);
