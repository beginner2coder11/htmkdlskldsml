"""Make scanned PDFs searchable by running OCR on them.

Many survival and military manuals are scans — pictures of pages with no text layer — so full-text search
can only find them by their title. This renders each scanned page to an image and runs Tesseract (the OCR
engine) on it, then saves the recognised text so the search index picks it up like any other page.

It is RESUMABLE and chips away a bit at a time: a queue tracks which pages still need OCR, and progress is
saved page by page. Stop it (or lose power) and re-run — finished pages are skipped. Each run does up to a
few thousand pages by default so one build never drags on; the rest wait for the next build or run.

Needs two things, both offline once set up:
  * an OCR engine — Tesseract (found on PATH, bundled in tools/tesseract, or fetched once on Windows), and
  * a way to turn a PDF page into an image — Poppler's pdftoppm (on PATH or fetched into tools/poppler on
    Windows), or PyMuPDF if it happens to be importable.
If neither can be arranged it skips cleanly: search still works, just title-only for scanned PDFs, exactly
as before — nothing is lost, and re-running later once Tesseract is installed fills them in.

Standard library only here; the heavy lifting is Tesseract and Poppler.
"""
import glob, hashlib, json, os, platform, re, shutil, subprocess, sys, tarfile, tempfile, time, zipfile

LOW = 0x00004000 if os.name == "nt" else 0     # BELOW_NORMAL priority on Windows: the PC stays usable while OCR runs

MIN_CHARS = 40            # a page with less real text than this is treated as a scan that needs OCR
DPI = 300                 # render resolution for OCR (300 is the Tesseract sweet spot)
BLANK_INK = 0.0005         # a page with less than 0.05% dark pixels (at a quick 40-dpi look) is blank: no OCR needed
PER_RUN_DEFAULT = 4000    # pages to OCR per run; the rest wait in the queue for next time
LANG = "eng"
WIN = platform.system() == "Windows"
EXE = ".exe" if WIN else ""

# Windows: portable builds we can fetch and unpack without running an installer.
# No dependable portable Tesseract zip exists on GitHub, so we don't auto-fetch it — if it isn't on PATH or
# bundled, OCR skips with a one-line note to install the UB-Mannheim build once. Poppler does ship a portable zip.
TESS_WIN = []
POPPLER_WIN = [("oschwartz10612/poppler-windows", r"Release-.*\.zip$")]


def _key(rel):
    return hashlib.sha1(rel.encode()).hexdigest()[:14]        # same key search_index uses, so text merges 1:1


def _find_exe(name, *roots):
    """Find an executable on PATH or anywhere under the given folders."""
    p = shutil.which(name)
    if p:
        return p
    for root in roots:
        for r, _, fs in os.walk(root) if os.path.isdir(root) else []:
            if name in fs:
                hit = os.path.join(r, name)
                if not WIN:
                    try:
                        os.chmod(hit, 0o755)
                    except OSError:
                        pass
                return hit
    return None


def _unpack(u, archive, into):
    shutil.rmtree(into, ignore_errors=True)
    os.makedirs(into, exist_ok=True)
    try:
        (zipfile.ZipFile(archive).extractall if archive.endswith(".zip")
         else (lambda d: tarfile.open(archive).extractall(d)))(into)
        return True
    except Exception as e:  # noqa: BLE001
        print(f"  ! could not unpack {os.path.basename(archive)}: {e}")
        shutil.rmtree(into, ignore_errors=True)
        return False


def _fetch_tool(u, dest, name, candidates, exe):
    """Download+unpack the first candidate GitHub asset that works; return the exe path, or None."""
    tdir = os.path.join(dest, "tools", name)
    for repo, pat in candidates:
        try:
            asset = u.gh_asset(repo, pat)
        except Exception:  # noqa: BLE001
            asset = None
        if not asset:
            continue
        fn, url = asset
        arc = os.path.join(tdir, fn)
        os.makedirs(tdir, exist_ok=True)
        print(f"  getting {name} ({repo})…")
        if not u.download(url, arc, name):
            continue
        ok = _unpack(u, arc, os.path.join(tdir, "unpacked"))
        try:
            os.remove(arc)
        except OSError:
            pass
        if ok:
            hit = _find_exe(exe, tdir)
            if hit:
                return hit
    return None


def _install_tess_win(u, tdir):
    """Windows: fetch the UB-Mannheim Tesseract installer and run it silently into tools/tesseract (once)."""
    base = "https://digi.bib.uni-mannheim.de/tesseract/"
    try:
        names = sorted(set(re.findall(r'tesseract-ocr-w64-setup-[\d.]+\.exe', u.fetch(base, 60).decode("utf-8", "replace"))),
                       key=lambda n: [int(x) for x in re.findall(r"\d+", n)])
    except Exception as e:  # noqa: BLE001
        print(f"  ! could not reach the Tesseract download page: {e}"); return None
    if not names:
        return None
    setup = os.path.join(os.path.dirname(tdir), "tesseract-setup.exe")
    print("  getting the Tesseract OCR engine (one-time, ~50 MB; accept the Windows permission prompt if it appears)…")
    if not u.download(base + names[-1], setup, "Tesseract OCR"):
        return None
    # The installer's manifest asks for admin, but it only writes into our own folder: telling Windows to run it
    # "as invoker" skips the elevation prompt. If that is refused, fall back to the normal UAC prompt.
    env = dict(os.environ, __COMPAT_LAYER="RunAsInvoker")
    try:
        subprocess.run([setup, "/S", "/D=" + tdir], timeout=900, env=env)
    except Exception as e:  # noqa: BLE001
        print(f"  (no-prompt install failed: {e}; asking Windows for permission)")
    if not _find_exe("tesseract.exe", tdir):
        try:
            ps = f"Start-Process -FilePath '{setup}' -ArgumentList '/S','/D={tdir}' -Verb RunAs -Wait"
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], timeout=900)
        except Exception as e:  # noqa: BLE001
            print(f"  ! Tesseract installer did not run: {e}")
    try:
        os.remove(setup)
    except OSError:
        pass
    return _find_exe("tesseract.exe", tdir)


def _tesseract(u, dest):
    """Locate (or fetch) the Tesseract OCR engine and make sure an English language file is present."""
    tdir = os.path.join(dest, "tools", "tesseract")
    exe = "tesseract" + EXE
    hit = _find_exe(exe, tdir)
    if not hit and WIN:
        # Already installed on this PC? Use it instead of running the installer (which would offer to uninstall it).
        for root in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA")):
            for sub in ("Tesseract-OCR", os.path.join("Programs", "Tesseract-OCR")):
                p = os.path.join(root or "", sub, "tesseract.exe")
                if os.path.exists(p):
                    hit = p
                    break
            if hit:
                break
    if not hit and WIN:
        hit = _fetch_tool(u, dest, "tesseract", TESS_WIN, exe) if TESS_WIN else _install_tess_win(u, tdir)
    if not hit:
        if not WIN:
            print("  ! Tesseract not found. Install it (Linux: apt install tesseract-ocr; Mac: brew install tesseract) "
                  "and re-run: scanned PDFs are found by title only until then.")
        return None
    # Tesseract needs its tessdata/eng.traineddata. A portable build ships it; make sure the engine can see it.
    tessdata = None
    search_roots = [tdir] if os.path.isdir(tdir) else []
    search_roots.append(os.path.dirname(os.path.dirname(hit)))   # a PATH install keeps tessdata next to bin
    for root in search_roots:
        for r, _, _ in os.walk(root) if os.path.isdir(root) else []:
            if os.path.basename(r) == "tessdata" and glob.glob(os.path.join(r, LANG + ".traineddata")):
                tessdata = r
                break
        if tessdata:
            break
    env = dict(os.environ)
    env["OMP_THREAD_LIMIT"] = "1"          # one core per page: Tesseract's own threading pegs every core (heat, freezes) for no real gain
    if tessdata:
        env["TESSDATA_PREFIX"] = tessdata
    # Prove it actually runs with the eng data before we commit to using it.
    try:
        out = subprocess.run([hit, "--list-langs"], capture_output=True, text=True, env=env, timeout=60)
        if LANG not in (out.stdout + out.stderr):
            print(f"  ! Tesseract has no '{LANG}' language data — skipping OCR. "
                  "Install the English data (eng.traineddata) and re-run."); return None
    except Exception as e:  # noqa: BLE001
        print(f"  ! Tesseract found but would not run ({e}) — skipping OCR."); return None
    return (hit, env)


def _renderer(u, dest):
    """Return render(pdf, page1based, out_png_prefix)->png_path|None, using pdftoppm or PyMuPDF."""
    pdir = os.path.join(dest, "tools", "poppler")
    ppm = _find_exe("pdftoppm" + EXE, pdir)
    if not ppm and WIN:
        ppm = _fetch_tool(u, dest, "poppler", POPPLER_WIN, "pdftoppm" + EXE)
    if ppm:
        def render(pdf, page, prefix):
            try:
                subprocess.run([ppm, "-f", str(page), "-l", str(page), "-r", str(DPI), "-png", "-singlefile",
                                pdf, prefix], check=True, capture_output=True, timeout=180, creationflags=LOW)
            except Exception:  # noqa: BLE001
                return None
            return prefix + ".png" if os.path.exists(prefix + ".png") else None
        return render, "pdftoppm"
    try:
        import fitz  # PyMuPDF  # noqa: F401

        def render(pdf, page, prefix):
            try:
                doc = fitz.open(pdf)
                pix = doc[page - 1].get_pixmap(dpi=DPI)
                pix.save(prefix + ".png")
                doc.close()
            except Exception:  # noqa: BLE001
                return None
            return prefix + ".png" if os.path.exists(prefix + ".png") else None
        return render, "PyMuPDF"
    except Exception:  # noqa: BLE001
        return None, None


def _native_text(u, dest, pdf):
    """Per-page text already in the PDF (so we only OCR the pages that are scans).
    Poppler's pdftotext first: a separate program with a time limit, so one huge or broken PDF can't hang or crash OCR."""
    ptt = _find_exe("pdftotext" + EXE, os.path.join(dest, "tools", "poppler"))
    if ptt:
        try:
            r = subprocess.run([ptt, "-q", "-enc", "UTF-8", pdf, "-"], capture_output=True, timeout=120, creationflags=LOW)
            if r.returncode == 0:
                pages = r.stdout.decode("utf-8", "replace").split("\f")
                if len(pages) > 1 and not pages[-1].strip():
                    pages = pages[:-1]
                return pages
        except subprocess.TimeoutExpired:
            return None                                   # skip this one PDF this run (listed as unreadable)
        except Exception:  # noqa: BLE001
            pass
    try:
        import search_index as S
        pypdf = S.get_pypdf(u, dest)
        return S.pdf_pages(pypdf, pdf) if pypdf else None
    except Exception:  # noqa: BLE001
        return None


def save_json(path, obj, sync=False, **kw):
    """Crash-safe save: write a temp file, keep the previous copy as .bak, then swap. A closed window can never leave a
    half-written progress file (that is what lost the OCR progress before v47)."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, **kw)
        if sync:                                # only the progress file: forcing every page to disk wears on USB drives
            fh.flush()
            os.fsync(fh.fileno())
    if os.path.exists(path):
        try:
            os.replace(path, path + ".bak")
        except OSError:
            pass
    os.replace(tmp, path)


def load_json(path):
    for p in (path, path + ".bak", path + ".tmp"):
        try:
            return json.load(open(p, encoding="utf-8"))
        except (OSError, ValueError):
            continue
    return {}


def _recover(out, key, scans, d):
    """Fill missing OCR pages from the search index's stored text for this document: a scanned page that has real text
    there can only have got it from an earlier OCR run. Returns the number of pages recovered."""
    try:
        t = open(os.path.join(out, "text", key + ".js"), encoding="utf-8").read()
        pages = json.loads(t[t.index("(") + 1:t.rindex(")")])[1]
    except (OSError, ValueError):
        return 0
    n = 0
    for i in scans:
        if str(i) not in d and i < len(pages) and (pages[i] or "").strip():
            d[str(i)] = pages[i]
            n += 1
    return n


def _invalidate(out, rel):
    """Drop this doc from the search manifest so the index rebuilds it and merges the new OCR text."""
    mf = os.path.join(out, "manifest.json")
    try:
        m = json.load(open(mf, encoding="utf-8"))
        if rel in m:
            del m[rel]
            json.dump(m, open(mf, "w", encoding="utf-8"))
    except (OSError, ValueError):
        pass


def ocr_text(out, key):
    """OCR text for a document as {page_index(int): text}, or {} — used by the search index to fill scans."""
    try:
        return {int(k): v for k, v in json.load(open(os.path.join(out, "ocr", key + ".json"), encoding="utf-8")).items()}
    except (OSError, ValueError):
        return {}


def build(u, dest, per_run=PER_RUN_DEFAULT):
    u.say("OCR scanned PDFs (makes picture-only manuals searchable)")
    www = os.path.join(dest, "www")
    out = os.path.join(www, "search")
    ocdir = os.path.join(out, "ocr")
    os.makedirs(ocdir, exist_ok=True)
    reports = os.path.join(dest, "REPORTS")
    os.makedirs(reports, exist_ok=True)

    render, rname = _renderer(u, dest)
    tess = _tesseract(u, dest) if render else None
    if not render or not tess:
        missing = "an OCR engine (Tesseract)" if render and not tess else \
                  "a PDF renderer (Poppler/pdftoppm)" if tess and not render else \
                  "Tesseract and a PDF renderer"
        msg = (f"  OCR skipped — {missing} not available.\n"
               "  Scanned PDFs still appear in search by title. To enable full-text OCR:\n"
               + ("    * Windows: it tries to fetch these automatically; if that failed, install Tesseract\n"
                  "      (UB-Mannheim build) and re-run.\n" if WIN else
                  "    * Linux:  sudo apt-get install tesseract-ocr poppler-utils\n"
                  "    * macOS:  brew install tesseract poppler\n")
               + "  Then run this again — it will fill in the scanned manuals.\n")
        print(msg)
        with open(os.path.join(reports, "OCR-REPORT.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
            fh.write("OCR REPORT\n\nOCR did not run on this build.\n\n" + msg)
        return
    tess_exe, tess_env = tess
    print(f"  engine: Tesseract + {rname}")

    state_path = os.path.join(ocdir, "state.json")
    state = load_json(state_path)

    pdfs = sorted(f for f in glob.glob(os.path.join(www, "library", "*", "*.pdf")) if not f.endswith("_COMPLETE.pdf"))
    import reports as _rep
    pdfs = _rep.readable(dest, pdfs)                     # a damaged file must not stop OCR for everything else
    # Build the work list: scanned pages not yet OCR'd, re-scanning any PDF whose bytes changed.
    work, scanned_docs, total_scanned, total_done = [], 0, 0, 0
    fresh = sum(1 for f in pdfs if (state.get(os.path.relpath(f, www).replace(os.sep, "/")) or {}).get("sig") !=
                [os.stat(f).st_size, int(os.stat(f).st_mtime)])
    if fresh:
        print(f"  Checking {fresh:,} new or changed PDFs for picture-only pages first (saved as it goes; a re-run skips the ones done)...",
              flush=True)
    checked, t_chk, recovered = 0, time.time(), 0
    for f in pdfs:
        rel = os.path.relpath(f, www).replace(os.sep, "/")
        key = _key(rel)
        st = os.stat(f)
        sig = [st.st_size, int(st.st_mtime)]
        old = state.get(rel)
        s = old
        if not old or old.get("sig") != sig:            # new or changed file: (re)detect which pages are scans
            native = _native_text(u, dest, f)
            checked += 1
            if checked % 25 == 0 or checked == fresh:
                print(f"\r  checked {checked:,}/{fresh:,} PDFs ({time.time() - t_chk:.0f} s)   ", end="", flush=True)
            if checked % 200 == 0:
                save_json(state_path, state, sync=True)
            if native is None:
                continue
            scans = [i for i, t in enumerate(native) if len(t) < MIN_CHARS]
            s = {"sig": sig, "key": key, "pages": len(native), "scanned": scans, "done": []}
            state[rel] = s
        if s.get("rec", 0) < 2:                             # once per document: take back OCR text whose progress was lost
            docjson = os.path.join(ocdir, key + ".json")
            d = {} if (old and old.get("sig") and old.get("sig") != sig) else load_json(docjson)   # a really changed PDF starts over
            n = _recover(out, key, s["scanned"], d)
            recovered += n
            s["done"] = sorted(set(s.get("done", [])) | {int(k) for k, v in d.items() if (v or "").strip() and int(k) in set(s["scanned"])})
            s["rec"] = 2
            if n:
                save_json(docjson, d, ensure_ascii=False)
        if s.get("v") != 2:                              # older runs could store an empty page after a read error: redo those once
            s["v"] = 2
            if s.get("done"):
                try:
                    d0 = json.load(open(os.path.join(ocdir, key + ".json"), encoding="utf-8"))
                except (OSError, ValueError):
                    d0 = {}
                s["done"] = [i for i in s["done"] if (d0.get(str(i)) or "").strip()]
        if s["scanned"]:
            scanned_docs += 1
        total_scanned += len(s["scanned"])
        total_done += len([i for i in s["scanned"] if i in set(s["done"])])
        todo = [i for i in s["scanned"] if i not in set(s["done"])]
        for i in todo:
            work.append((rel, key, f, i))
    if checked:
        print()
    if recovered:
        print(f"  Recovered {recovered:,} already-OCR'd pages from the search index (no need to OCR them again)")
    save_json(state_path, state, sync=True)

    if not work:
        done_now = total_done
        line = (f"  All scanned pages are OCR'd: {done_now:,} pages across {scanned_docs} manuals. Nothing to do." if total_scanned
                else "  No scanned (picture-only) PDFs found — every manual already has a text layer.")
        print(line)
        _write_report(reports, scanned_docs, total_scanned, total_done, rname)
        return

    cap = min(len(work), max(1, per_run))
    print(f"  {total_scanned:,} scanned pages in {scanned_docs} manuals; {total_done:,} already done, "
          f"{len(work):,} to go. OCR-ing up to {cap:,} this run (resumable).")
    t0, did, touched, pending = time.time(), 0, {}, set()
    workers = max(1, min(4, (os.cpu_count() or 2) - 2))      # several pages at once, one core each; 2 cores left free for you
    print(f"  {workers} pages at a time (below-normal priority - the computer stays usable)", flush=True)
    tmp = tempfile.mkdtemp(prefix="offgrid-ocr-")

    ppm = _find_exe("pdftoppm" + EXE, os.path.join(dest, "tools", "poppler"))

    def blank(f, page, prefix):
        """Quick 40-dpi grey look at the page: True when there is essentially no ink (blank sheet, cover back)."""
        if not ppm:
            return False
        try:
            subprocess.run([ppm, "-f", str(page), "-l", str(page), "-r", "40", "-gray", "-singlefile", f, prefix],
                           check=True, capture_output=True, timeout=60, creationflags=LOW)
            b = open(prefix + ".pgm", "rb").read()
            hdr = b.split(maxsplit=4)
            w, h = int(hdr[1]), int(hdr[2])
            px = hdr[4][-w * h:]
            return sum(1 for v in px if v < 200) < BLANK_INK * len(px)
        except Exception:  # noqa: BLE001
            return False
        finally:
            try:
                os.remove(prefix + ".pgm")
            except OSError:
                pass

    def one(job):
        n, (rel, key, f, page) = job
        prefix = os.path.join(tmp, f"p{n}")
        if blank(f, page + 1, prefix + "lo"):
            return rel, key, page, "", True
        png = render(f, page + 1, prefix)                  # pdftoppm/fitz are 1-based pages
        if not png:
            return rel, key, page, "", False
        try:
            r = subprocess.run([tess_exe, png, "stdout", "-l", LANG, "--psm", "6"],   # UTF-8, not the Windows code page
                               capture_output=True, encoding="utf-8", errors="replace", env=tess_env, timeout=180,
                               creationflags=LOW)
            return rel, key, page, re.sub(r"[ \t]+", " ", r.stdout or "").strip(), r.returncode == 0
        except Exception:  # noqa: BLE001
            return rel, key, page, "", False
        finally:
            try:
                os.remove(png)
            except OSError:
                pass

    def checkpoint():
        if not os.path.isdir(ocdir):
            raise OSError(f"the drive went away ({ocdir} is gone) - reconnect it and run again; finished pages are kept")
        save_json(state_path, state, sync=True)
        for rel_ in pending:                               # search re-reads these with their new OCR text - as it goes,
            _invalidate(out, rel_)                         # so a window that closes loses nothing
        pending.clear()

    try:
        import concurrent.futures as cf
        with cf.ThreadPoolExecutor(workers) as ex:
            for rel, key, page, text, ok in ex.map(one, enumerate(work[:cap])):
                did += 1
                if ok:                                     # a failed page stays queued for the next run
                    docjson = os.path.join(ocdir, key + ".json")
                    d = load_json(docjson)
                    d[str(page)] = text
                    save_json(docjson, d, ensure_ascii=False)
                    state[rel]["done"].append(page)
                    touched[rel] = True
                    pending.add(rel)
                if did % 25 == 0 or did == cap:
                    checkpoint()
                    rate = did / max(1e-6, time.time() - t0)
                    left = (cap - did) / max(rate, 1e-6) / 3600
                    print(f"\r  OCR: {did:,}/{cap:,} pages ({rate:.1f}/s, about {left:.1f} h left this run)   ", end="", flush=True)
        print()
    finally:
        checkpoint()
        shutil.rmtree(tmp, ignore_errors=True)

    remaining = len(work) - did
    print(f"  Done this run: {did:,} pages." + (f" {remaining:,} still queued for next time." if remaining else " Queue empty."))
    _write_report(reports, scanned_docs, total_scanned, total_done + did, rname, remaining)


def _write_report(reports, docs, total, done, engine, remaining=0):
    with open(os.path.join(reports, "OCR-REPORT.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("OCR REPORT — making scanned PDFs searchable\n")
        fh.write("=" * 48 + "\n\n")
        fh.write(f"Engine: Tesseract + {engine}\n")
        fh.write(f"Scanned (picture-only) manuals found: {docs}\n")
        fh.write(f"Scanned pages total:   {total:,}\n")
        fh.write(f"Pages OCR'd so far:     {done:,}\n")
        fh.write(f"Pages still queued:     {remaining:,}\n\n")
        if remaining:
            fh.write("OCR is resumable and does a chunk each run. Re-run the builder (or ADD-OCR) to continue;\n"
                     "finished pages are skipped. The recognised text is already in search for the pages done.\n")
        else:
            fh.write("All scanned pages have been OCR'd. Their text is now in the full-text search.\n")
        fh.write("\nNote: OCR of a scan is not perfect — odd characters are normal. The original PDF is unchanged;\n"
                 "this only adds searchable text behind the scenes.\n")


if __name__ == "__main__":
    # Run by the builder as a separate process, so a crash inside a PDF library can only end OCR, never the whole build.
    import argparse, types
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    ap.add_argument("--pages", type=int, default=PER_RUN_DEFAULT)
    a = ap.parse_args()
    import usb_builder
    build(usb_builder, a.dest, a.pages)
