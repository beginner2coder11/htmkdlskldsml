"""Offline Southeast climate & almanac page (www\\weather.html).

Built from NOAA/NCEI 1991-2020 Climate Normals (public domain): monthly temperature, rain, snow, hot/freeze days and the
frost dates / growing season of every first-order weather station in the Southeast, plus Census ZIP-code centroids so a ZIP
code finds its nearest station. The page itself uses no internet: own stylesheet, own SVG charts, system fonts.
Moon phase and sunrise/sunset are computed in the browser.
"""
import csv
import io
import json
import math
import os
import zipfile

NORMALS = "https://www.ncei.noaa.gov/data/normals-monthly/1991-2020/"
ANNUAL = "https://www.ncei.noaa.gov/data/normals-annualseasonal/1991-2020/access/"
INVENTORY = NORMALS + "doc/inventory_30yr.txt"
GAZ = "https://www2.census.gov/geo/docs/maps-data/data/gazetteer/2023_Gazetteer/2023_Gaz_zcta_national.zip"
STATES = {"GA", "FL", "AL", "SC", "NC", "TN", "MS", "LA", "VA", "KY", "AR"}
ZIP3 = [(270, 299), (300, 319), (320, 349), (350, 369), (370, 385), (386, 397), (398, 399), (700, 729), (400, 427), (201, 246)]
MONTHLY = {"tmax": "MLY-TMAX-NORMAL", "tmin": "MLY-TMIN-NORMAL", "prcp": "MLY-PRCP-NORMAL", "snow": "MLY-SNOW-NORMAL",
           "wet": "MLY-PRCP-AVGNDS-GE010HI", "hot": "MLY-TMAX-AVGNDS-GRTH090", "frz": "MLY-TMIN-AVGNDS-LSTH032"}
FROST = {"ls32": "ANN-TMIN-PRBLST-T32FP50", "fs32": "ANN-TMIN-PRBFST-T32FP50", "gs32": "ANN-TMIN-PRBGSL-T32FP50",
         "ls32e": "ANN-TMIN-PRBLST-T32FP10", "ls32l": "ANN-TMIN-PRBLST-T32FP90",
         "fs32e": "ANN-TMIN-PRBFST-T32FP10", "fs32l": "ANN-TMIN-PRBFST-T32FP90",
         "ls28": "ANN-TMIN-PRBLST-T28FP50", "fs28": "ANN-TMIN-PRBFST-T28FP50"}


def _num(s):
    s = (s or "").strip()
    try:
        v = float(s)
    except ValueError:
        return s if "/" in s else None
    return None if v <= -7777 else v


def _read(text):
    rows = list(csv.reader(io.StringIO(text)))
    return rows[0], rows[1:]


def _get(u, url, timeout=120):
    data = u.fetch(url, timeout)
    return data.decode("utf-8", "replace") if isinstance(data, bytes) else data


def _one(u, sid, info):
    mh, mrows = _read(_get(u, NORMALS + "access/" + sid + ".csv"))
    idx = {k: mh.index(v) for k, v in MONTHLY.items() if v in mh}
    months = {}
    for r in mrows:
        try:
            m = int(r[mh.index("month")]) - 1
        except (ValueError, IndexError):
            continue
        for k, i in idx.items():
            months.setdefault(k, [None] * 12)[m] = _num(r[i])
    ah, arows = _read(_get(u, ANNUAL + sid + ".csv"))
    frost = {}
    if arows:
        for k, c in FROST.items():
            if c in ah:
                frost[k] = _num(arows[0][ah.index(c)])
    info.update(months)
    info.update({k: v for k, v in frost.items() if v is not None})
    return info


def _zips(u):
    z = zipfile.ZipFile(io.BytesIO(u.fetch(GAZ, 180)))
    text = z.read(z.namelist()[0]).decode("utf-8", "replace")
    out = []
    for r in csv.reader(io.StringIO(text), delimiter="\t"):
        if len(r) < 7 or not r[0].strip().isdigit():
            continue
        zc = r[0].strip()
        p3 = int(zc[:3])
        if any(a <= p3 <= b for a, b in ZIP3):
            try:
                out.append([zc, round(float(r[5]), 2), round(float(r[6]), 2)])
            except ValueError:
                pass
    return out


def build(u, dest):
    u.say("Offline weather & almanac page")
    ddir = os.path.join(dest, "www", "data")
    os.makedirs(ddir, exist_ok=True)
    cache = os.path.join(ddir, "weather-stations.json")
    stations = {}
    if os.path.exists(cache):
        try:
            stations = json.load(open(cache, encoding="utf-8"))
        except (OSError, ValueError):
            stations = {}
    if not stations or "--refresh" in os.environ.get("WEATHER_OPTS", ""):
        try:
            inv = _get(u, INVENTORY, 120)
        except Exception as e:  # noqa: BLE001
            print(f"  ! NOAA station list unavailable ({e}); weather page skipped this run")
            return
        wanted = {}
        for line in inv.splitlines():
            if len(line) < 41:
                continue
            sid, st = line[:11].strip(), line[38:40].strip()
            if sid.startswith("USW") and st in STATES:
                try:
                    wanted[sid] = {"n": line[41:71].strip().title(), "st": st, "lat": float(line[12:20]),
                                   "lon": float(line[21:30]), "el": float(line[31:37])}
                except ValueError:
                    pass
        print(f"  {len(wanted)} NOAA stations in the Southeast")
        done = 0
        for sid, info in sorted(wanted.items()):
            try:
                stations[sid] = _one(u, sid, info)
                done += 1
                if done % 10 == 0:
                    print(f"    {done}/{len(wanted)} stations")
            except Exception as e:  # noqa: BLE001
                print(f"    ! {info['n']}: {e}")
        if stations:
            json.dump(stations, open(cache, "w", encoding="utf-8"), separators=(",", ":"))
    if not stations:
        print("  ! no station data; weather page not written")
        return
    zips = []
    zc = os.path.join(ddir, "weather-zips.json")
    if os.path.exists(zc):
        try:
            zips = json.load(open(zc, encoding="utf-8"))
        except (OSError, ValueError):
            zips = []
    if not zips:
        try:
            zips = _zips(u)
            json.dump(zips, open(zc, "w", encoding="utf-8"), separators=(",", ":"))
        except Exception as e:  # noqa: BLE001
            print(f"  ! ZIP centroid list unavailable ({e}); the page will use the station picker only")
    page = TEMPLATE.replace("__STATIONS__", json.dumps(stations, separators=(",", ":"))) \
                   .replace("__ZIPS__", json.dumps(zips, separators=(",", ":")))
    with open(os.path.join(dest, "www", "weather.html"), "w", encoding="utf-8") as fh:
        fh.write(page)
    print(f"  weather.html written: {len(stations)} stations, {len(zips)} ZIP codes")


def main():
    import argparse
    import usb_builder as u
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    build(u, ap.parse_args().dest)


TEMPLATE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Southeast weather &amp; almanac (offline)</title>
<style>
:root{--bg:#0f1b14;--card:#172a1f;--ink:#e9f1ea;--mut:#9db4a2;--acc:#7bd88f;--hot:#ff8a5c;--cold:#6cb8ff;--rain:#5aa7ff}
*{box-sizing:border-box}body{margin:0;font:15px/1.45 system-ui,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--ink)}
header{padding:14px 18px;background:#0b140f;border-bottom:1px solid #264033;display:flex;flex-wrap:wrap;gap:10px;align-items:center}
header h1{font-size:19px;margin:0 12px 0 0}a{color:var(--acc)}
input,select,button{font:inherit;padding:7px 10px;border-radius:7px;border:1px solid #2f5140;background:#10231a;color:var(--ink)}
button{background:#235a3a;cursor:pointer}main{max-width:1100px;margin:auto;padding:14px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:12px 0}
.card{background:var(--card);border:1px solid #264033;border-radius:10px;padding:12px}
.card b{display:block;font-size:22px}.card span{color:var(--mut);font-size:13px}
h2{font-size:16px;margin:20px 0 6px;color:var(--acc)}table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:4px 6px;text-align:right;border-bottom:1px solid #223a2d}th:first-child,td:first-child{text-align:left}
svg{width:100%;height:auto;background:var(--card);border-radius:10px;border:1px solid #264033}
.note{color:var(--mut);font-size:12.5px}.pill{display:inline-block;padding:2px 8px;border-radius:99px;background:#1f4a32;margin:2px;font-size:12.5px}
.bar{height:16px;background:#1d3327;border-radius:4px;position:relative;margin:3px 0}.bar i{position:absolute;top:0;bottom:0;border-radius:4px;background:#3c9a5f}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px}
</style></head><body>
<header><h1>🌦 Southeast weather &amp; almanac</h1>
<form id="f" onsubmit="go();return false"><input id="zip" placeholder="ZIP code" maxlength="5" size="7"> <button>Find</button></form>
<select id="st" onchange="pick(this.value)"></select><a href="home.html">⌂ Home</a></header>
<main>
<div id="where" class="note"></div>
<div class="grid" id="stats"></div>
<h2>Temperature &amp; rainfall by month (1991–2020 normals)</h2><div class="two"><svg id="tc" viewBox="0 0 520 260"></svg><svg id="pc" viewBox="0 0 520 260"></svg></div>
<table id="tbl"></table>
<h2>Frost dates &amp; growing season</h2><div id="frost"></div>
<h2>Planting calendar (from your frost dates)</h2><div id="plant"></div>
<h2>Today's almanac</h2><div class="grid" id="alm"></div>
<h2>Storm &amp; hazard calendar (general Southeast pattern)</h2>
<div class="note">Atlantic hurricane season June 1 – Nov 30, peaking about Aug 20 – Oct 10; Gulf and Atlantic coast landfalls carry the highest risk, inland areas get remnant flooding.
Tornado/severe storms: Mar–May (peak) and a second Nov–Dec peak in the Deep South; flash floods can happen any month. Heat peaks Jun–Aug, hard freezes are rare south of I-10 but possible every winter inland.
This is general knowledge, not station data.</div>
<h2>About this data</h2><div class="note">Source: NOAA NCEI U.S. Climate Normals 1991–2020 (public domain), nearest first-order station to the ZIP code you enter (distance is shown).
Station values are for an airport and can differ from your exact location by several degrees, especially in hills, valleys and cities. Frost dates are the 50 % probability dates for 32 °F (and the 10 %/90 % range).
Moon phase and sun times are calculated on this device. Nothing on this page needs internet.</div>
</main>
<script>
const S=__STATIONS__,Z=__ZIPS__;const M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MD=[31,28,31,30,31,30,31,31,30,31,30,31];let cur=null;
const $=i=>document.getElementById(i);
const sum=a=>a&&a.every(x=>x!=null)?a.reduce((p,c)=>p+c,0):null;
const avg=a=>sum(a)==null?null:sum(a)/a.length;
const f1=x=>x==null?"–":x.toFixed(1);
function hav(a,b,c,d){const r=Math.PI/180,x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 3959*2*Math.asin(Math.sqrt(x))}
function doy(s){if(typeof s!=="string")return null;const [m,d]=s.split("/").map(Number);let n=d;for(let i=0;i<m-1;i++)n+=MD[i];return n}
function fromDoy(n){if(n==null)return "–";n=Math.round(n);for(let i=0;i<12;i++){if(n<=MD[i])return M[i]+" "+n;n-=MD[i]}return "–"}
function init(){const sel=$("st");const ids=Object.keys(S).sort((a,b)=>(S[a].st+S[a].n).localeCompare(S[b].st+S[b].n));
sel.innerHTML='<option value="">Pick a station…</option>'+ids.map(i=>`<option value="${i}">${S[i].st} – ${S[i].n}</option>`).join("");
const q=new URLSearchParams(location.search).get("zip");const z=q||localStorage.getItem("wzip")||"30301";$("zip").value=z;if(!go())pick(ids[0])}
function go(){const z=$("zip").value.trim();const r=Z.find(x=>x[0]===z)||Z.find(x=>x[0].slice(0,3)===z.slice(0,3));if(!r){$("where").textContent=Z.length?"ZIP "+z+" isn't in the Southeast list — pick a station instead.":"ZIP list not built — pick a station.";return false}
let best=null,bd=1e9;for(const id in S){const d=hav(r[1],r[2],S[id].lat,S[id].lon);if(d<bd){bd=d;best=id}}
localStorage.setItem("wzip",z);pick(best,"ZIP "+z+" → nearest station, "+bd.toFixed(0)+" miles away");return true}
function pick(id,msg){if(!id||!S[id])return;cur=S[id];$("st").value=id;$("where").textContent=(msg?msg+". ":"")+cur.n+", "+cur.st+" • elevation "+Math.round(cur.el*3.28084)+" ft";draw()}
function draw(){const s=cur;const mean=s.tmax&&s.tmin?avg(s.tmax.map((h,i)=>(h+s.tmin[i])/2)):null;
const card=(v,l)=>`<div class="card"><b>${v}</b><span>${l}</span></div>`;
$("stats").innerHTML=card(f1(mean)+"°F","average temperature")+card(f1(sum(s.prcp))+" in","rain per year")+card(f1(sum(s.snow))+" in","snow per year")+
card(f1(sum(s.hot)),"days ≥ 90°F")+card(f1(sum(s.frz)),"days with a freeze (≤ 32°F)")+card(f1(sum(s.wet)),"days with ≥ 0.1 in rain")+
card(s.gs32?Math.round(s.gs32)+" days":"–","frost-free growing season");
lines("tc",s.tmax,s.tmin);bars("pc",s.prcp);
let h="<tr><th>Month</th><th>High °F</th><th>Low °F</th><th>Rain in</th><th>Rain days</th><th>Snow in</th><th>Freeze days</th><th>≥90° days</th></tr>";
for(let i=0;i<12;i++)h+=`<tr><td>${M[i]}</td><td>${f1(s.tmax&&s.tmax[i])}</td><td>${f1(s.tmin&&s.tmin[i])}</td><td>${f1(s.prcp&&s.prcp[i])}</td><td>${f1(s.wet&&s.wet[i])}</td><td>${f1(s.snow&&s.snow[i])}</td><td>${f1(s.frz&&s.frz[i])}</td><td>${f1(s.hot&&s.hot[i])}</td></tr>`;
$("tbl").innerHTML=h;frostPanel();plantPanel();almanac()}
function lines(id,hi,lo){const sv=$(id);if(!hi||!lo){sv.innerHTML="";return}const all=hi.concat(lo).filter(x=>x!=null);const mn=Math.min(...all)-5,mx=Math.max(...all)+5;
const X=i=>45+i*(450/11),Y=v=>230-(v-mn)/(mx-mn)*200;let o="";
for(let t=Math.ceil(mn/10)*10;t<=mx;t+=10)o+=`<line x1="45" x2="495" y1="${Y(t)}" y2="${Y(t)}" stroke="#2a4a38"/><text x="4" y="${Y(t)+4}" fill="#9db4a2" font-size="11">${t}°</text>`;
const p=a=>a.map((v,i)=>(i?"L":"M")+X(i)+","+Y(v)).join(" ");
o+=`<path d="${p(hi)}" fill="none" stroke="#ff8a5c" stroke-width="3"/><path d="${p(lo)}" fill="none" stroke="#6cb8ff" stroke-width="3"/>`;
M.forEach((m,i)=>o+=`<text x="${X(i)-8}" y="250" fill="#9db4a2" font-size="11">${m}</text>`);
o+=`<text x="50" y="18" fill="#ff8a5c" font-size="12">avg high</text><text x="120" y="18" fill="#6cb8ff" font-size="12">avg low</text>`;sv.innerHTML=o}
function bars(id,v){const sv=$(id);if(!v){sv.innerHTML="";return}const mx=Math.max(...v)*1.1;let o="";
v.forEach((x,i)=>{const h=x/mx*200;o+=`<rect x="${50+i*37}" y="${230-h}" width="28" height="${h}" fill="#5aa7ff" rx="3"/><text x="${50+i*37}" y="${224-h}" fill="#e9f1ea" font-size="10">${x.toFixed(1)}</text><text x="${50+i*37}" y="250" fill="#9db4a2" font-size="11">${M[i]}</text>`});
o+=`<text x="50" y="18" fill="#5aa7ff" font-size="12">inches of rain per month</text>`;sv.innerHTML=o}
function frostPanel(){const s=cur;const ls=doy(s.ls32),fs=doy(s.fs32);if(ls==null&&fs==null){$("frost").innerHTML='<div class="note">This station almost never freezes — no frost dates.</div>';return}
const r=(a,b,l,c)=>a==null?"":`<div>${l}: <b>${fromDoy(a)}</b> <span class="note">(range ${fromDoy(Math.min(b[0],b[1]))} – ${fromDoy(Math.max(b[0],b[1]))})</span></div>`;
$("frost").innerHTML=r(ls,[doy(s.ls32e),doy(s.ls32l)],"Last spring 32°F freeze (50 % chance)")+r(fs,[doy(s.fs32e),doy(s.fs32l)],"First fall 32°F freeze (50 % chance)")+
(s.ls28?`<div>Last spring hard freeze (28°F): <b>${fromDoy(doy(s.ls28))}</b>; first fall: <b>${fromDoy(doy(s.fs28))}</b></div>`:"")+
`<div class="note">Plant tender crops after the last-frost date; the earlier end of the range is a gamble, the later end is the safe bet.</div>`}
const CROPS=[["Peas, spinach, lettuce, kale, onions","cool",-6],["Potatoes, carrots, beets, cabbage, broccoli","cool",-4],["Corn, beans (bush/pole)","warm",0],
["Tomatoes, peppers, eggplant (transplants)","warm",1],["Squash, cucumbers, melons","warm",2],["Okra, sweet potatoes, southern peas, peanuts","hot",3],
["Fall garden: collards, turnips, kale, broccoli","fall",-12],["Garlic and onion sets","late",-4]];
function plantPanel(){const ls=doy(cur.ls32),fs=doy(cur.fs32);if(ls==null||fs==null){$("plant").innerHTML='<div class="note">Frost-free area: most crops can be planted nearly year-round; avoid the hottest months for cool-season crops.</div>';return}
let h="";for(const [n,t,w] of CROPS){let a,b;
if(t==="fall"){a=fs+w*7;b=fs+w*7+21}else if(t==="late"){a=fs-21;b=fs+14}else{a=ls+w*7;b=a+(t==="cool"?28:42);if(b>fs-30)b=fs-30}
h+=`<div>${n}: <b>${fromDoy(a)} – ${fromDoy(b)}</b><div class="bar"><i style="left:${a/365*100}%;width:${Math.max(2,(b-a)/365*100)}%"></i></div></div>`}
$("plant").innerHTML=h+'<div class="note">Rule-of-thumb windows from your station’s frost dates. Check your county extension office tables when you can.</div>'}
function moon(d){const syn=29.530588853,ref=Date.UTC(2000,0,6,18,14);const age=(((d-ref)/864e5)%syn+syn)%syn;const ph=age<1.85?"New moon 🌑":age<5.54?"Waxing crescent 🌒":age<9.23?"First quarter 🌓":age<12.92?"Waxing gibbous 🌔":age<16.61?"Full moon 🌕":age<20.3?"Waning gibbous 🌖":age<23.99?"Last quarter 🌗":age<27.68?"Waning crescent 🌘":"New moon 🌑";return [age,ph,(1-Math.cos(2*Math.PI*age/syn))/2]}
function sun(lat,lon,d){const r=Math.PI/180,start=Date.UTC(d.getUTCFullYear(),0,0),n=Math.floor((d-start)/864e5),g=2*Math.PI/365*(n-1);
const eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g));
const dc=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);
const c=Math.cos(90.833*r)/(Math.cos(lat*r)*Math.cos(dc))-Math.tan(lat*r)*Math.tan(dc);if(c>1||c<-1)return null;const ha=Math.acos(c)/r;
const mk=m=>new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate())+m*6e4);return [mk(720-4*(lon+ha)-eq),mk(720-4*(lon-ha)-eq),ha*8/60]}
function almanac(){const now=new Date(),[age,ph,il]=moon(now),sn=sun(cur.lat,cur.lon,now);const card=(v,l)=>`<div class="card"><b>${v}</b><span>${l}</span></div>`;
const t=x=>x.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
const mo=age<14.77?"Waxing (new → full): plant above-ground crops that bear fruit above ground — leafy greens, tomatoes, beans, corn.":"Waning (full → new): plant root crops, bulbs and perennials; good time to prune, weed and harvest for storage.";
$("alm").innerHTML=card(ph,"moon phase, "+Math.round(il*100)+" % lit (age "+age.toFixed(1)+" days)")+(sn?card(t(sn[0]),"sunrise (this device’s clock zone)")+card(t(sn[1]),"sunset")+card(sn[2].toFixed(1)+" h","daylight"):"")+
`<div class="card" style="grid-column:1/-1"><span>Old-almanac planting-by-moon tradition: ${mo} (folk practice, not proven science; frost dates above matter far more.)</span></div>`}
init();
</script></body></html>
"""


if __name__ == "__main__":
    main()
