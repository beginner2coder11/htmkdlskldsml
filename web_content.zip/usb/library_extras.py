"""More for the library: DoD Inspector General reports, public-domain encyclopedias (Britannica 1911 and others),
the Ubuntu live/installer ISO, and TiddlyWiki (a single-file notebook that works on Android).

Everything is fetched resumably and logged; whatever can't be fetched is written to REPORTS\\LIBRARY-EXTRAS-NOT-FETCHED.txt
(with the link) so you can drop the file in by hand. Safe to re-run: finished files are skipped.

  python library_extras.py --dest E:\\OFFGRID                        everything below
  python library_extras.py --dest E:\\OFFGRID --only dodig --max 500  just the Inspector General reports
  python library_extras.py --dest E:\\OFFGRID --only ubuntu           the Ubuntu ISO (about 6 GB)
        --only choices (comma separated): dodig, reference, ubuntu, tiddlywiki

Britannica note: the current Encyclopaedia Britannica is a paid product and is NOT copied. The 1911 edition (public
domain), Chambers's and similar public-domain encyclopedias are fetched from archive.org; Wikipedia, Wikibooks and
Simple English are already in the Kiwix archives.
"""
import argparse
import html as _html
import json
import os
import re
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import army_pubs as ap  # noqa: E402
import languages as L  # noqa: E402

DODIG_FOLDER = "DoD Inspector General Reports"
REF_FOLDER = "Encyclopedias (public domain)"
LIST_URL = "https://www.dodig.mil/reports.html/?Page={}"
ART = re.compile(r"/reports\.html/Article/(\d+)/([A-Za-z0-9\-]+)/?", re.I)
PDF = re.compile(r"https?://media\.defense\.gov/[^\"'\s<>]+?\.pdf", re.I)
NOTES = []


def _note(msg):
    NOTES.append(msg)
    L._p("  ! " + msg)


def _index(dest):
    p = os.path.join(dest, "tools", "dodig-index.json")
    try:
        with open(p, encoding="utf-8") as fh:
            return p, json.load(fh)
    except (OSError, ValueError):
        return p, {"articles": {}, "pages_done": 0}


def _save(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p + ".tmp", "w", encoding="utf-8") as fh:
        json.dump(d, fh)
    os.replace(p + ".tmp", p)


def dodig(u, dest, cap=400, max_pages=260):
    """Crawl dodig.mil/reports.html page by page, open each report page, keep the public PDF."""
    u.say("DoD Inspector General reports")
    folder = os.path.join(dest, "www", "library", DODIG_FOLDER)
    os.makedirs(folder, exist_ok=True)
    ip, idx = _index(dest)
    arts = idx["articles"]                       # id -> {slug, pdf, file}
    # 1. list pages (newest first). Re-read page 1-3 every run to pick up new reports, then continue where we stopped.
    start = list(range(1, 4)) + list(range(max(4, idx.get("pages_done", 0) + 1), max_pages + 1))
    empty = 0
    for n in start:
        try:
            page = ap._get(LIST_URL.format(n), timeout=60)
        except Exception as e:  # noqa: BLE001
            _note(f"dodig.mil list page {n}: {e}")
            empty += 1
            if empty >= 3:
                break
            continue
        found = ART.findall(page)
        if not found:
            empty += 1
            if empty >= 2:
                break
            continue
        empty = 0
        for aid, slug in found:
            arts.setdefault(aid, {"slug": slug})
        idx["pages_done"] = max(idx.get("pages_done", 0), n)
        if n % 10 == 0:
            _save(ip, idx)
            L._p(f"  report list: page {n}, {len(arts):,} reports found")
    _save(ip, idx)
    # 2. each report page -> PDF link -> download
    got = new = 0
    for aid, a in sorted(arts.items(), key=lambda kv: -int(kv[0])):
        name = ap._safe(a["slug"].replace("-", " ").title(), 110) + ".pdf"
        out = os.path.join(folder, name)
        if a.get("file") and os.path.exists(os.path.join(folder, a["file"])):
            got += 1
            continue
        if a.get("none"):
            continue
        if new >= cap:
            break
        if not a.get("pdf"):
            try:
                page = ap._get(f"https://www.dodig.mil/reports.html/Article/{aid}/{a['slug']}/", timeout=60)
            except Exception as e:  # noqa: BLE001
                a["err"] = str(e)[:80]
                continue
            m = PDF.findall(page)
            m = [x for x in m if "dodig" in x.lower() or "report" in x.lower()] or m
            if not m:
                a["none"] = True            # classified / no public PDF
                continue
            a["pdf"] = _html.unescape(m[0]).replace(" ", "%20")
        n = ap._fetch_file(a["pdf"], out)
        if n:
            a["file"] = name
            new += 1
            got += 1
            L._p(f"  + {name[:90]}")
        if new % 20 == 0:
            _save(ip, idx)
    _save(ip, idx)
    left = sum(1 for a in arts.values() if not a.get("file") and not a.get("none"))
    print(f"  DoD IG: {got:,} reports on the drive ({new} new this run)" + (f", about {left:,} more to fetch - run again" if left else ""))


REFERENCE_QUERIES = [
    ("encyclopaedia britannica 11th edition 1911", "britannica"),
    ("encyclopaedia britannica eleventh edition", "britannica"),
    ("chambers's encyclopaedia", "chambers"),
    ("new international encyclopedia 1905", "nie"),
    ("american cyclopaedia", "cyclopaedia"),
    ("the book of knowledge", "knowledge"),
    ("the practical encyclopedia", "practical"),
]


def reference(u, dest, cap=40):
    """Public-domain encyclopedias from archive.org (published before 1930, or a free licence)."""
    u.say("Encyclopedias (public domain)")
    folder = os.path.join(dest, "www", "library", REF_FOLDER)
    seen, added = set(), 0
    for q, _ in REFERENCE_QUERIES:
        if added >= cap:
            break
        tq = "title:(" + " AND ".join(re.findall(r"[\w']+", q)) + ")"
        for d in L._search(u, tq, rows=40, extra=" AND date:[1700-01-01 TO 1929-12-31]", sort="downloads desc"):
            ident = d.get("identifier")
            title = d.get("title") if isinstance(d.get("title"), str) else (ident or "")
            if not ident or ident in seen or added >= cap:
                continue
            seen.add(ident)
            if not re.search(r"encyclop|cyclop|knowledge", title, re.I):
                continue
            r = L._fetch_item(u, ident, title, folder)
            if r:
                added += 1
                if r[2]:                                   # only say something when a new file arrived
                    L._p(f"  encyclopedia: + {title[:70]}")
    print(f"  {added} public-domain encyclopedia volume(s) in the library")
    if not added:
        _note("No encyclopedia volumes could be fetched (archive.org unreachable or files are borrow-only). "
              "Kiwix already has Wikipedia; Britannica 1911 is at https://archive.org/search?query=encyclopaedia+britannica+1911")


UBUNTU_BOOT = """BOOTING UBUNTU FROM A USB DRIVE
================================
Ubuntu is a full operating system you can run from a USB stick without touching the computer's own disk.
It is useful when Windows will not start, to rescue files, or to use a clean computer.

What you need: a SEPARATE USB stick of 8 GB or more (this OFFGRID drive is not bootable) and one working computer.
1. Get a tool that writes the ISO to the stick: Rufus (Windows, in SOFTWARE if present) or balenaEtcher or, on Linux, `dd`.
2. Open the tool, choose the Ubuntu .iso file from this folder, choose the stick, press Start. This ERASES the stick.
3. Plug the stick into the computer to rescue/use, turn it on, and press the one-time boot-menu key at once:
   F12 (Dell, Lenovo), F9 (HP), Esc or F8 (ASUS), F10 (Acer), hold Option (Mac). Choose the USB stick.
4. Choose "Try Ubuntu" (not Install) to run without changing anything. Your files are under "Other locations".
5. Secure Boot: Ubuntu normally boots with it on. If it refuses, turn Secure Boot off in the BIOS and try again.
To check the download, compare the checksum with SHA256SUMS in this folder.
"""


def ubuntu(u, dest):
    """Latest Ubuntu LTS desktop ISO into SOFTWARE\\Ubuntu (about 6 GB)."""
    u.say("Ubuntu (bootable live system)")
    out = os.path.join(dest, "SOFTWARE", "Ubuntu")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "HOW-TO-BOOT-UBUNTU.txt"), "w", encoding="utf-8") as fh:
        fh.write(UBUNTU_BOOT)
    try:
        top = u.fetch("https://releases.ubuntu.com/", 60).decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        _note(f"Ubuntu: releases.ubuntu.com unreachable ({e}). Download the desktop ISO from https://ubuntu.com/download/desktop into {out}")
        return
    vers = sorted({m for m in re.findall(r'href="(\d\d\.04(?:\.\d+)?)/"', top)}, key=lambda v: [int(x) for x in v.split(".")], reverse=True)
    lts = [v for v in vers if int(v.split(".")[0]) % 2 == 0]
    for v in lts[:3]:
        base = f"https://releases.ubuntu.com/{v}/"
        try:
            page = u.fetch(base, 60).decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            continue
        m = re.search(r'href="(ubuntu-[\d.]+-desktop-amd64\.iso)"', page)
        if not m:
            continue
        iso = m.group(1)
        dst = os.path.join(out, iso)
        for extra in ("SHA256SUMS",):
            try:
                d = u.fetch(base + extra, 60)
                with open(os.path.join(out, extra), "wb") as fh:
                    fh.write(d)
            except Exception:  # noqa: BLE001
                pass
        if os.path.exists(dst) and os.path.getsize(dst) > 1 << 30:
            print(f"  Ubuntu {v}: already on the drive")
            return
        try:
            if u.download(base + iso, dst, f"Ubuntu {v} desktop (about 6 GB)", retries=3):
                print(f"  Ubuntu {v} ISO downloaded to SOFTWARE\\Ubuntu")
                return
            _note("Ubuntu ISO download did not finish; re-run to resume")
            return
        except Exception as e:  # noqa: BLE001
            _note(f"Ubuntu ISO download failed ({e}); re-run to resume")
            return
    _note("Ubuntu: could not find an LTS desktop ISO on releases.ubuntu.com")


TW_README = """TIDDLYWIKI - a notebook in ONE file
====================================
Your ready-made notebook is FIELD-NOTEBOOK.html in the drive's main folder (situations with tick boxes, rally points,
radio log, supplies, a library of every guide). index.html here is the complete TiddlyWiki website; empty.html is a blank
notebook. A wiki is one .html file that
holds your notes inside itself, so it copies anywhere. The catch is SAVING, which differs by device:

  Windows / Mac / Linux : TiddlyDesktop (official) or TiddlyDesktopRS. Open the .html file in it; it saves in place with backups.
                          Installers are in the folders beside this file when they could be downloaded.
  Android               : Tiddloid, or TiddlyDesktopRS (it has an Android app). Open the .html file with it; saves in place.
                          Without an app, Chrome can read it but every save becomes a new download.
  iPhone / iPad         : Quine 2 (App Store, about $4.99, unofficial but widely used). Opens, edits and saves wikis stored in
                          the Files app. Install it BEFORE you go off-grid: iPhone apps cannot be installed from this drive.
  Any device with Termux: the Node.js server version saves automatically (advanced).

Put TiddlyDesktop (the Windows .zip) in the folder beside this file; the Tiddloid app (Android) is in www/phone-apps/android.
Make your own copy first: never edit the only copy of something important.
"""

GH = (("TiddlyWiki/TiddlyDesktop", "official-desktop", (r"win(32|64).*\.zip$", r"mac.*\.zip$", r"linux.*\.zip$")),
      ("burningtreec/tiddlydesktop-rs", "desktoprs", (r"\.(exe|msi)$", r"\.apk$", r"\.(AppImage|deb)$", r"\.dmg$")))


def _github_apps(u, out):
    """Newest release files of the TiddlyWiki desktop/Android apps (a few tens of MB each)."""
    got = 0
    have_desktop = any(f.lower().startswith("tiddlydesktop-win") and f.lower().endswith(".zip")
                       for r, _, fs in os.walk(out) for f in fs)
    for repo, sub, pats in GH:
        if have_desktop and sub == "official-desktop":
            got += 1                       # you already put TiddlyDesktop on the drive yourself
            continue
        try:
            rel = json.loads(u.fetch(f"https://api.github.com/repos/{repo}/releases/latest", 60))
        except Exception as e:  # noqa: BLE001
            _note(f"TiddlyWiki apps: {repo} release list unreachable ({e}). Get it from https://github.com/{repo}/releases")
            continue
        for pat in pats:
            for asset in rel.get("assets", []):
                n = asset.get("name", "")
                if re.search(pat, n, re.I) and not re.search(r"sig$|sha256|blockmap|\.yml$|arm|aarch", n, re.I):
                    dst = os.path.join(out, sub, n)
                    try:
                        if u.download(asset["browser_download_url"], dst, n[:50], retries=2):
                            got += 1
                    except Exception as e:  # noqa: BLE001
                        _note(f"TiddlyWiki app {n}: {e}")
                    break
    # the Android APK also goes where the phone-app page and the Android pack look for it
    apk_dir = os.path.join(os.path.dirname(os.path.dirname(out)), "www", "phone-apps", "android")
    for r, _, fs in os.walk(os.path.join(out, "desktoprs")):
        for f in fs:
            if f.lower().endswith(".apk"):
                os.makedirs(apk_dir, exist_ok=True)
                try:
                    import shutil
                    shutil.copy2(os.path.join(r, f), os.path.join(apk_dir, "tiddlydesktop-rs-" + f))
                except OSError:
                    pass
    return got


def tiddlywiki(u, dest):
    u.say("TiddlyWiki (single-file notebook) and its apps")
    out = os.path.join(dest, "SOFTWARE", "TiddlyWiki")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "README.txt"), "w", encoding="utf-8") as fh:
        fh.write(TW_README)
    ok = 0
    for url, name in (("https://tiddlywiki.com/empty.html", "empty.html"), ("https://tiddlywiki.com/index.html", "index.html")):
        p = os.path.join(out, name)
        if os.path.exists(p) and os.path.getsize(p) > 100000:
            ok += 1
            continue
        try:
            if u.download(url, p, "TiddlyWiki " + name, retries=2):
                ok += 1
            else:
                _note(f"TiddlyWiki {name} did not download (get it from {url})")
        except Exception as e:  # noqa: BLE001
            _note(f"TiddlyWiki {name}: {e}  (get it from {url})")
    apps = _github_apps(u, out)
    _note("TiddlyWiki on iPhone: install Quine 2 from the App Store (paid, cannot be copied to the drive).")
    print(f"  TiddlyWiki: {ok} of 2 files, {apps} app installer(s) on the drive")


def build(u, dest, profile="large", only=None, cap=400):
    only = set(only or ("dodig", "reference", "tiddlywiki") + (("ubuntu",) if profile == "full" else ()))
    steps = (("dodig", lambda: dodig(u, dest, cap)), ("reference", lambda: reference(u, dest)),
             ("tiddlywiki", lambda: tiddlywiki(u, dest)), ("ubuntu", lambda: ubuntu(u, dest)))
    for name, fn in steps:
        if name in only:
            try:
                fn()
            except KeyboardInterrupt:
                raise
            except Exception as e:  # noqa: BLE001
                _note(f"{name}: {type(e).__name__}: {e}")
    if NOTES:
        rep = os.path.join(dest, "REPORTS")
        os.makedirs(rep, exist_ok=True)
        with open(os.path.join(rep, "LIBRARY-EXTRAS-NOT-FETCHED.txt"), "w", encoding="utf-8") as fh:
            fh.write("\n".join(NOTES) + "\n")


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--dest", required=True)
    a.add_argument("--only", default="")
    a.add_argument("--max", type=int, default=400, help="new Inspector General reports per run")
    a.add_argument("--profile", default="large")
    x = a.parse_args()
    import usb_builder as u
    only = [s.strip() for s in x.only.split(",") if s.strip()] or (["dodig", "reference", "tiddlywiki", "ubuntu"])
    build(u, os.path.abspath(x.dest), x.profile, only, x.max)


if __name__ == "__main__":
    main()
