@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
@echo off
REM Sets up a weekly check on THIS computer (Sundays 7 PM). If the OFF-GRID drive is plugged in and the
REM computer is online, it quietly re-runs only what is missing. Remove with: SET-WEEKLY-REPAIR-WINDOWS.bat off
set DIR=%LOCALAPPDATA%\OffGridDrive
if /i "%~1"=="off" (
  schtasks /delete /tn "OffGrid Drive Weekly Repair" /f
  echo  Weekly repair removed.
  pause & exit /b
)
if not exist "%DIR%" mkdir "%DIR%"
copy /y "%~dp0tools\offgrid-repair.ps1" "%DIR%\offgrid-repair.ps1" >nul
schtasks /create /tn "OffGrid Drive Weekly Repair" /sc weekly /d SUN /st 19:00 /f /tr "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%DIR%\offgrid-repair.ps1\""
echo.
echo  Weekly repair set. Remove it with:  SET-WEEKLY-REPAIR-WINDOWS.bat off
pause
