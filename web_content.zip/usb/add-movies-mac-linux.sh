#!/bin/sh
# ===== Add your movies and TV shows to this drive (Mac / Linux) =====
# Run:  sh /path/to/OFFGRID/add-movies-mac-linux.sh /path/to/movies
cd "$(dirname "$0")" || exit 1
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
MP=tools/builder/usb/media.py
if [ -z "$1" ]; then "$PY" "$MP" --dest "$(pwd)" --catalog-only; exit; fi
"$PY" "$MP" --dest "$(pwd)" --src "$1" || exit 1
echo; echo "Look over MEDIA-PLAN.html (fix names in MEDIA-PLAN.csv if needed)."
printf 'Copy, Move or Nothing? [c/m/N] '; read -r A
case "$A" in c|C) M=copy ;; m|M) M=move ;; *) exit 0 ;; esac
"$PY" "$MP" --dest "$(pwd)" --apply "$M" && "$PY" "$MP" --dest "$(pwd)" --catalog-only
