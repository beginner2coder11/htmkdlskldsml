@echo off
REM Download ONLY the USGS topo maps (home area first, then bases/cities/lakes/routes) onto the drive.
REM Skips every other build step, so topo isn't stuck behind the big archives. Resumable - finished maps are skipped.
REM Optional: pass the drive letter, e.g.  ADD-TOPO-MAPS-WINDOWS.bat F
cd /d "%~dp0"
set DRIVE=%1
if "%DRIVE%"=="" set DRIVE=E
echo.
echo  Adding USGS topo maps to %DRIVE%:\OFFGRID  (nothing else will download)
echo  The maps around home land first; the base/city/lake set (larger) fills in after.
echo  You can close this and re-run it anytime - it picks up where it left off.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_usb.ps1" %DRIVE% --topo-only
pause
