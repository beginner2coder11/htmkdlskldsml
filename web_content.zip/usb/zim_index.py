"""Put the ARTICLES inside the Kiwix archives (.zim) into the drive's own search index (and so meaning search,
Ask and the Top 20 pages) - with no server running.

* Smaller archives (medicine, water, MDWiki, Appropedia, iFixit, Stack Exchange, Wikivoyage, LibreTexts...): every article.
* Giant archives (full Wikipedia, Gutenberg, Wikisource, big Wikibooks): only the survival-relevant part, picked with the
  archive's OWN full-text index - a few hundred searches (TOPICS below: first aid, water, food, farming, shelter,
  radio, power, tools, CBRN...) keep the best matches: up to 100,000 Wikipedia articles, 2,000 Gutenberg books.
* Videos / exercises / dictionaries (Khan Academy, PhET, TED, Wiktionary): not indexed - listed on the Archive
  contents page and searched live through Kiwix (serve_usb /zim-search).
Each hit opens zim.html (index text offline; full page with pictures through Kiwix when the drive is started).
Reads ZIMs with python-libzim, unpacked once into tools\\pylib\\_libzim-<platform>. Unchanged archives aren't re-read."""
import glob, hashlib, html, json, os, re, sys

MAX_GB = float(os.environ.get("OFFGRID_ZIM_MAX_GB", "6"))      # bigger archives: live Kiwix search only
MAX_ART = 40000                                                 # articles per archive
CHUNK = 600                                                     # articles per index "document" (keeps each text file small)
SKIP = ("wikipedia_", "khanacademy", "gutenberg", "phet", "ted_", "youtube", "_videos", "crashcourse", "wikisource",
        "wiktionary", "openstreetmap", "_nopic_maxi")          # live search only
VERSION = 3


def _ok():
    try:
        import libzim.reader  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _plat():
    import platform
    m = platform.machine().lower()
    if os.name == "nt":
        return "win_amd64", r"win_amd64"
    if sys.platform == "darwin":
        return ("macos_arm64", r"macosx_.*arm64") if m in ("arm64", "aarch64") else ("macos_x64", r"macosx_.*x86_64")
    return ("linux_arm64", r"manylinux.*aarch64") if m in ("arm64", "aarch64") else ("linux_x64", r"manylinux.*x86_64")


def ensure_libzim(dest, u=None):
    """python-libzim from a wheel kept on the drive: tools/pylib/_libzim-<platform> (the drive's Python has no pip).
    Downloaded once from PyPI, then works offline on every computer of that type."""
    if _ok():
        return True
    key, want = _plat()
    lib = os.path.join(dest, "tools", "pylib", "_libzim-" + key)
    if os.path.isdir(lib):
        sys.path.insert(0, lib)
        if _ok():
            return True
        sys.path.pop(0)
    ver = sys.version_info.minor
    try:
        fetch = (lambda url: u.fetch(url, 60)) if u else (lambda url: __import__("urllib.request").request.urlopen(url, timeout=60).read())
        meta = json.loads(fetch("https://pypi.org/pypi/libzim/json"))
        cands = []
        for x in meta["urls"]:
            m = re.search(r"-cp3(\d+)-(abi3|cp3\d+)-(.+)\.whl$", x["filename"])
            if not m or not re.search(want, m.group(3)):
                continue
            built = int(m.group(1))
            if (m.group(2) == "abi3" and built <= ver) or m.group(2) == f"cp3{ver}":
                cands.append((m.group(2) != "abi3", built, x))
        if not cands:
            print(f"  ! ZIM articles: no python-libzim build for Python 3.{ver} on {key}")
            return False
        x = max(cands, key=lambda c: (c[0], c[1]))[2]
        whl = os.path.join(dest, "tools", "pylib", x["filename"])
        os.makedirs(os.path.dirname(whl), exist_ok=True)
        if u:
            if not u.download(x["url"], whl, "python-libzim (reads the Kiwix archives)"):
                return False
        else:
            open(whl, "wb").write(fetch(x["url"]))
        import shutil, zipfile
        shutil.rmtree(lib, ignore_errors=True)
        zipfile.ZipFile(whl).extractall(lib)
        os.remove(whl)
    except Exception as e:  # noqa: BLE001
        print(f"  ! ZIM articles: could not get python-libzim ({type(e).__name__}: {str(e)[:100]})")
        return False
    sys.path.insert(0, lib)
    if _ok():
        return True
    try:
        import libzim.reader  # noqa: F401  (show why it would not load)
    except Exception as e:  # noqa: BLE001
        print(f"  ! ZIM articles: python-libzim did not load ({type(e).__name__}: {str(e)[:120]})")
    return False


def _wanted_old(path):
    low = os.path.basename(path).lower()
    if any(s in low for s in SKIP):
        return False, "searched live through Kiwix (too big to copy into the index)"
    try:
        if os.path.getsize(path) > MAX_GB * 1024 ** 3:
            return False, f"over {MAX_GB:g} GB - searched live through Kiwix"
    except OSError:
        return False, "unreadable"
    return True, ""


def _strip(x):
    x = re.sub(r"(?is)<(script|style|nav|footer|table class=\"navbox)[^>]*>.*?</\1>", " ", x)
    x = re.sub(r"(?is)<(br|p|li|h\d|tr|div)\b", r" <\1", x)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", x))).strip()


# What "survival relevant" means for the giant archives: each line is searched in the archive's own full-text index and
# the best matches are kept (Wikipedia: ~300 per line). Grouped by topic for the Archive contents page.
TOPICS = {
    "First aid & trauma": ["first aid", "bleeding hemorrhage", "tourniquet", "wound care", "burn injury", "fracture splint",
                           "cardiopulmonary resuscitation", "choking", "shock circulatory", "concussion head injury", "triage", "sprain dislocation"],
    "Illness & medicine": ["infection treatment", "antibiotic", "fever", "dehydration oral rehydration", "diarrhea", "cholera", "dysentery",
                           "influenza pandemic", "pneumonia", "sepsis", "diabetes emergency", "asthma attack", "allergic reaction anaphylaxis",
                           "pain medication", "childbirth", "dental emergency", "eye injury", "medicinal plant", "herbal medicine",
                           "tuberculosis", "malaria", "tetanus", "rabies", "lyme disease", "measles", "vaccine", "pharmacology drug interaction"],
    "Poisons, bites & stings": ["venomous snake", "snakebite", "spider bite", "scorpion sting", "poisonous plant", "mushroom poisoning",
                                "carbon monoxide poisoning", "food poisoning", "botulism", "insect sting"],
    "Environment & weather": ["hypothermia", "frostbite", "heat stroke", "heat exhaustion", "lightning", "tornado", "hurricane", "flood",
                              "flash flood", "wildfire", "earthquake", "tsunami", "blizzard", "drought", "weather forecasting", "cloud types",
                              "volcanic eruption", "landslide", "ice storm", "dust storm"],
    "Water": ["water purification", "drinking water", "water filter", "boiling water", "chlorination", "well water", "rainwater harvesting",
              "waterborne disease", "desalination", "spring water", "water storage"],
    "Food & foraging": ["edible plants", "foraging", "edible mushroom", "food preservation", "canning", "smoking food", "drying food",
                        "salting curing meat", "fermentation food", "pemmican", "hardtack", "root cellar", "nutrition deficiency",
                        "scurvy", "vitamin", "acorn", "cattail", "dandelion", "wild onion", "nuts edible", "berries edible"],
    "Farming & animals": ["gardening", "vegetable", "seed saving", "crop rotation", "composting", "soil fertility", "irrigation",
                          "chicken poultry", "goat", "rabbit raising", "beekeeping", "livestock", "dairy cattle", "veterinary medicine",
                          "butchering slaughter", "fodder", "aquaponics", "orchard fruit tree", "permaculture"],
    "Hunting, fishing & trapping": ["hunting", "fishing", "trapping", "snare", "fishing knot", "game animal", "field dressing deer",
                                    "tanning hide", "bow and arrow", "archery", "slingshot", "white-tailed deer", "wild turkey"],
    "Shelter & fire": ["survival shelter", "lean-to", "fire making", "fire starter", "ferrocerium", "flint and steel", "bow drill",
                       "tinder", "campfire", "log cabin", "adobe", "insulation building", "stove wood", "chimney", "tent",
                       "emergency shelter", "earth sheltering"],
    "Navigation": ["navigation", "compass", "map reading", "topographic map", "orienteering", "celestial navigation", "north star",
                   "dead reckoning", "latitude longitude", "sun navigation", "global positioning system"],
    "Tools, craft & repair": ["knot", "rope", "axe", "knife sharpening", "saw", "blacksmith", "forge welding", "woodworking",
                              "carpentry", "masonry", "plumbing", "pottery", "weaving", "spinning textiles", "sewing", "leather",
                              "soap making", "candle making", "glass", "basket weaving", "lumber", "metalworking", "lathe"],
    "Energy & power": ["solar panel", "photovoltaic", "battery", "lead-acid battery", "lithium battery", "electric generator",
                       "inverter", "wind turbine", "water wheel", "hydropower", "wood gas", "biogas", "biodiesel", "fuel storage",
                       "kerosene", "propane", "electrical wiring", "electric power transmission", "power outage"],
    "Radio & communication": ["amateur radio", "radio", "shortwave", "citizens band radio", "repeater", "antenna", "morse code",
                              "radio propagation", "frequency modulation", "single-sideband", "walkie-talkie", "satellite phone",
                              "emergency communication", "signal mirror", "semaphore"],
    "Vehicles & machines": ["internal combustion engine", "diesel engine", "small engine", "car battery", "tire", "bicycle",
                            "motorcycle", "brake", "transmission", "carburetor", "chainsaw", "electromagnetic pulse"],
    "Security & defense": ["self-defense", "home security", "firearm", "rifle", "shotgun", "handgun", "ammunition", "gun safety",
                           "body armor", "situational awareness", "civil unrest", "crowd"],
    "Hazards (CBRN)": ["nuclear fallout", "radiation sickness", "fallout shelter", "potassium iodide", "nuclear weapon effects",
                       "chemical weapon", "nerve agent", "biological weapon", "hazardous materials", "decontamination", "gas mask",
                       "chemical spill", "industrial accident"],
    "Sanitation & hygiene": ["sanitation", "latrine", "composting toilet", "hand washing", "disinfectant", "bleach", "waste disposal",
                             "sewage", "lice", "bed bug", "mosquito control", "pest control", "rodent"],
    "Chemistry & science basics": ["chemistry", "lye", "potash", "charcoal", "distillation", "ethanol", "vinegar", "saltpeter",
                                   "lime mortar", "clay", "physics simple machine", "lever pulley"],
    "Emergency management": ["emergency management", "disaster preparedness", "evacuation", "civil defense", "survival skills",
                             "bug-out bag", "emergency kit", "search and rescue", "mass casualty incident", "pandemic response"],
    "Animals & plants (identify)": ["wild mammal north america", "bird north america", "venomous", "tree identification", "oak", "pine",
                                    "maple syrup", "black bear", "coyote", "feral hog", "alligator", "tick", "poison ivy"],
}
FAMILIES = {   # giant archives: (per-search hits, article cap, pages per article)
    "wikipedia_en": (300, 100000, 3), "gutenberg_en": (12, 2000, 40), "wikisource_en": (20, 6000, 10), "wikibooks_en": (60, 15000, 6),
}
LIVE_ONLY = ("khanacademy", "phet", "ted_", "youtube", "_videos", "crashcourse", "wiktionary", "openstreetmap")
NON_EN = re.compile(r"_(es|fr|de|it|pt|ru|zh|ar|ja|pl|nl|sv)_")


def plan(path):
    """('all', pages per article) for archives read whole; ('subset', hits, cap, pages); ('skip', why)."""
    low = os.path.basename(path).lower()
    if any(s in low for s in LIVE_ONLY):
        return ("skip", "videos/exercises or dictionary - listed in Archive contents, searched live through Kiwix")
    fam = next((f for f in FAMILIES if low.startswith(f)), None)
    try:
        size = os.path.getsize(path)
    except OSError:
        return ("skip", "unreadable")
    if fam is None and size <= MAX_GB * 1024 ** 3:
        return ("all", 2)
    if NON_EN.search(low):
        return ("skip", "large non-English archive - searched live through Kiwix")
    return ("subset",) + (FAMILIES[fam] if fam else (60, 20000, 3))


def _pages(title, txt, maxp):
    out, i = [], 0
    while i < len(txt) and len(out) < maxp:
        part = txt[i:i + 3900]
        if i + 3900 < len(txt):                              # cut at a sentence end
            k = part.rfind(". ")
            if k > 2000:
                part = part[:k + 1]
        out.append((title if not out else title + " (cont.)") + " — " + part.strip())
        i += len(part)
    return out


def _read(e, title=None):
    if e.is_redirect:
        e = e.get_redirect_entry()
    it = e.get_item()
    if not it.mimetype.startswith("text/html"):
        return None
    txt = _strip(bytes(it.content).decode("utf-8", "replace"))
    title = (title or e.title or e.path).strip()
    for _ in range(3):                                      # <title> and <h1> repeat the name
        if txt.lower().startswith(title.lower()):
            txt = txt[len(title):].strip()
    return (e.path, title, txt) if len(txt) >= 200 else None


PDF_PAGES = 400                                                 # pages read from each PDF inside an archive


def _pypdf():
    """pypdf, already loaded by the library indexer (search_index.get_pypdf) - or importable here."""
    m = sys.modules.get("pypdf")
    if m:
        return m
    try:
        import pypdf
        return pypdf
    except Exception:  # noqa: BLE001
        return None


def _pdf(e):
    """Text of a PDF stored inside the archive (zimgit / nautilus collections: Where There Is No Doctor, knots,
    water, food preparation, post-disaster...), as ~3,900-character pages. v80: these used to index as 0 articles."""
    import io, logging, warnings
    pypdf = _pypdf()
    if not pypdf:
        return None
    logging.getLogger("pypdf").setLevel(logging.CRITICAL)
    warnings.filterwarnings("ignore")
    try:
        r = pypdf.PdfReader(io.BytesIO(bytes(e.get_item().content)), strict=False)
        if r.is_encrypted:
            r.decrypt("")
        title = (e.title or os.path.basename(e.path)).strip()
        if title.lower().endswith(".pdf"):
            title = title[:-4].replace("_", " ").replace("-", " ").strip()
        out, buf = [], ""
        for i, pg in enumerate(r.pages):
            if i >= PDF_PAGES:
                break
            try:
                t = re.sub(r"\s+", " ", pg.extract_text() or "").strip()
            except Exception:  # noqa: BLE001
                t = ""
            buf = (buf + " " + t).strip()
            if len(buf) >= 3000:
                out.append(buf[:3900]); buf = buf[3900:]
        if buf:
            out.append(buf)
        out = [x for x in out if len(x) >= 100]
        return (e.path, title, [(title if not k else f"{title} (cont.)") + " — " + x for k, x in enumerate(out)]) if out else None
    except Exception:  # noqa: BLE001
        return None


def _articles(path, maxp):
    from libzim.reader import Archive
    a = Archive(path)
    n = 0
    for i in range(a.entry_count):
        if n >= MAX_ART:
            break
        try:
            e = a._get_entry_by_id(i) if hasattr(a, "_get_entry_by_id") else a.get_entry_by_id(i)
            if e.is_redirect:
                continue
            mt = e.get_item().mimetype
            if mt == "application/pdf":
                r = _pdf(e)
                if r:
                    n += 1
                    for t in r[2]:
                        yield r[0], r[1], t
                continue
            r = _read(e)
        except Exception:  # noqa: BLE001
            continue
        if r:
            n += 1
            for t in _pages(r[1], r[2], maxp):
                yield r[0], r[1], t


def damaged(path):
    """Why libzim cannot open this archive ('' if it opens). A ZIM of 'bad size' is an unfinished download."""
    try:
        from libzim.reader import Archive
        Archive(path)
        return ""
    except Exception as ex:  # noqa: BLE001
        m = str(ex)
        if "bad size" in m or "corrupt" in m.lower():
            return "incomplete or damaged download"
        return f"{type(ex).__name__}: {m[:80]}"


def select(path, hits, cap):
    """Survival subset of a giant archive through its own full-text index: {path: (title, topic)} in topic order."""
    from libzim.reader import Archive
    from libzim.search import Query, Searcher
    a = Archive(path)
    if not a.has_fulltext_index:
        return None
    sr, chosen = Searcher(a), {}
    for topic, qs in TOPICS.items():
        for q in qs:
            if len(chosen) >= cap:
                return chosen
            try:
                res = sr.search(Query().set_query(q)).get_results(0, hits)
            except Exception:  # noqa: BLE001
                continue
            for r in res:
                p = getattr(r, "path", r)
                if p in chosen:
                    continue
                try:
                    e = a.get_entry_by_path(p)
                    if e.is_redirect:
                        e = e.get_redirect_entry()
                    if e.path in chosen:
                        continue
                    chosen[e.path] = (e.title or e.path, topic)
                except Exception:  # noqa: BLE001
                    continue
                if len(chosen) >= cap:
                    break
        print(f"\r  choosing survival articles: {len(chosen):,} ({topic[:30]})          ", end="", flush=True)
    return chosen


def _subset_articles(path, chosen, maxp):
    from libzim.reader import Archive
    a = Archive(path)
    for p, (title, _topic) in chosen.items():
        try:
            r = _read(a.get_entry_by_path(p), title)
        except Exception:  # noqa: BLE001
            continue
        if r:
            for t in _pages(r[1], r[2], maxp):
                yield r[0], r[1], t


def subset_file(dest, stem):
    return os.path.join(dest, "tools", "zim-subsets", stem + ".json")


def docs(dest, out, manifest, new_manifest, label, js, u=None):
    """Index entries [(rel, entry)] for the archives; writes text/<key>.js like the other documents."""
    zims = sorted(glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim")))
    if not zims:
        return [], []
    result, notes, have = [], [], None
    qsig = hashlib.sha1(json.dumps(TOPICS, sort_keys=True).encode()).hexdigest()[:8]
    for z in zims:
        stem = os.path.splitext(os.path.basename(z))[0]
        how = plan(z)
        if how[0] == "skip":
            notes.append(f"{stem}: {how[1]}")
            continue
        st = os.stat(z)
        sig = [st.st_size, int(st.st_mtime), VERSION] + ([qsig] if how[0] == "subset" else [])
        old = sorted((r for r in manifest if r.startswith(f"zim/{stem}/")), key=lambda r: int(r.rsplit("/", 1)[1]))
        if old and all(manifest[r]["sig"] == sig and os.path.exists(os.path.join(out, "text", manifest[r]["key"] + ".js")) for r in old):
            for r in old:
                new_manifest[r] = manifest[r]
                result.append((r, manifest[r]))
            notes.append(f"{stem}: unchanged ({len({a for r in old for a in manifest[r]['anchors']}):,} articles)")
            continue
        if have is None:
            have = ensure_libzim(dest, u)
            if not have:
                print("  ! ZIM articles: archives stay live-search only this run (python-libzim needs internet once)")
        if not have:
            notes.append(f"{stem}: not indexed (python-libzim missing)")
            continue
        name, _kw = label(stem)
        bad = damaged(z)
        if bad:
            print(f"  ! {stem}: {bad} - UPDATE-DRIVE (internet) re-downloads the missing part; Kiwix skips it until then")
            notes.append(f"{stem}: NOT READABLE ({bad}). Run UPDATE-DRIVE with internet to finish it.")
            continue
        if how[0] == "subset":
            print(f"  ZIM: {name} is a giant archive - picking its survival-relevant articles with its own search index")
            try:
                chosen = select(z, how[1], how[2])
            except Exception as ex:  # noqa: BLE001
                chosen = None
                print(f"\n  ! {stem}: {type(ex).__name__}: {str(ex)[:100]}")
            print()
            if not chosen:
                notes.append(f"{stem}: no full-text index inside - searched live through Kiwix only")
                continue
            os.makedirs(os.path.dirname(subset_file(dest, stem)), exist_ok=True)
            with open(subset_file(dest, stem), "w", encoding="utf-8") as fh:
                json.dump({"sig": sig, "items": [[t, p, tp] for p, (t, tp) in chosen.items()]}, fh)
            source = _subset_articles(z, chosen, how[3])
        else:
            source = _articles(z, how[1])
        chunk, part, total, arts, last = [], 0, 0, 0, None

        def flush():
            nonlocal chunk, part
            if not chunk:
                return
            rel = f"zim/{stem}/{part}"
            key = hashlib.sha1(rel.encode()).hexdigest()[:14]
            with open(os.path.join(out, "text", key + ".js"), "w", encoding="utf-8") as fh:
                fh.write(js("SEARCH_TEXT", [key, [c[2] for c in chunk]]))
            e = {"sig": sig, "key": key, "title": name, "n": len(chunk), "anchors": [c[0] for c in chunk],
                 "cat": "Archives (Kiwix)", "chars": sum(len(c[2]) for c in chunk), "zim": stem}
            new_manifest[rel] = e
            result.append((rel, e))
            chunk, part = [], part + 1

        try:
            for p, t, txt in source:
                if p != last:
                    arts, last = arts + 1, p
                chunk.append((p, t, txt))
                total += 1
                if total % 500 == 0:
                    print(f"\r  ZIM articles: {name[:40]:<40} {arts:,} articles, {total:,} pages", end="", flush=True)
                if len(chunk) >= CHUNK:
                    flush()
            flush()
            print(f"\r  ZIM articles: {name[:40]:<40} {arts:,} articles, {total:,} pages indexed")
            notes.append(f"{stem}: {arts:,} articles indexed" + (" (survival-relevant subset)" if how[0] == "subset" else ""))
        except Exception as ex:  # noqa: BLE001
            notes.append(f"{stem}: stopped ({type(ex).__name__}: {str(ex)[:80]})")
            print(f"\n  ! ZIM {stem}: {type(ex).__name__}")
    return result, notes


def write_report(dest, notes):
    if not notes:
        return
    d = os.path.join(dest, "REPORTS")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "ZIM-ARTICLES-INDEXED.txt"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("Kiwix archives and the drive's own search index\n"
                 "Indexed = every article shows up in Search everything, Ask, meaning search and the Top 20 pages, even with no server.\n"
                 "Live = searched through Kiwix while the drive is started (START-HERE), and shown under 'From the archives'.\n\n")
        fh.write("\n".join(notes) + "\n")
