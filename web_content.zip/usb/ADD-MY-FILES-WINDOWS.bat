@echo off
if exist "%~dp0usb_builder.py" (
  echo.
  echo  This is the builder's copy of the program. Run it from the drive instead:
  echo    double-click START-HERE.bat in the OFFGRID folder on the drive ^(for example E:\OFFGRID^) and pick it from the menu.
  echo.
  pause
  exit /b 1
)
REM ===== Add your own documents and books (PDFs, e-books, Word files...) to the Library =====
REM 1) Put them (folders are fine) in MY-FILES-INBOX in this OFFGRID folder. A downloaded Google Drive folder: Extract All into it.
REM 2) Run this. No internet needed. Files are sorted by folder name; duplicates of files already on the drive are skipped.
cd /d "%~dp0"
title Add my documents
if not exist "MY-FILES-INBOX" mkdir "MY-FILES-INBOX"
set PYTHONUTF8=1
tools\python-win\python.exe tools\builder\usb\usb_builder.py --dest "%~dp0." --my-files-only
echo.
echo  Open Home ^> Library. Anything that didn't match a section is in "My Files".
pause
