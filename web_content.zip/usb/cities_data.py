"""US cities gazetteer (31,000+ places with coordinates) for the coordinate converter and Excel export.

Source file shipped with the builder: data/us-cities.csv (SimpleMaps US Cities database, basic edition; the
free edition asks for attribution to simplemaps.com - see the notice written next to the data).
Writes www/data/us-cities.js : window.CITIES=[[city,state,county,lat,lng,population],...]
"""
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def load():
    p = os.path.join(HERE, "data", "us-cities.csv")
    rows = []
    with open(p, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            try:
                rows.append([r["city"], r["state_id"], r["county_name"], round(float(r["lat"]), 4), round(float(r["lng"]), 4),
                             int(float(r["population"] or 0)), r["state_name"]])
            except (ValueError, KeyError):
                continue
    return rows


def build(u, dest):
    u.say("US cities with coordinates (for the coordinate converter)")
    if not os.path.exists(os.path.join(HERE, "data", "us-cities.csv")):
        print("  (us-cities.csv not found next to the builder - skipped)")
        return
    rows = load()
    out = os.path.join(dest, "www", "data")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "us-cities.js"), "w", encoding="utf-8") as fh:
        fh.write("window.CITIES=" + json.dumps([r[:6] for r in rows], separators=(",", ":"), ensure_ascii=False) + ";\n")
    with open(os.path.join(out, "US-CITIES-NOTICE.txt"), "w", encoding="utf-8") as fh:
        fh.write("City names and coordinates: SimpleMaps US Cities database (basic edition), https://simplemaps.com/data/us-cities\n"
                 "The free edition requires attribution to simplemaps.com. Coordinates are city centers, not street addresses.\n")
    print(f"  {len(rows):,} cities -> www\\data\\us-cities.js")
