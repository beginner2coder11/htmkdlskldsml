"""Tidy drive layout: one menu at the top of the drive, every program in PROGRAMS, every report in REPORTS.

  OFFGRID\\
    START-HERE.bat              numbered menu of everything (Windows)      start-here-mac-linux.sh  (Mac/Linux)
    READ-ME-FIRST.html          what each program does and when to use it; buttons open the pages
    README.txt
    PROGRAMS\\                   every .bat / .sh (each still works on its own by double-click)
    REPORTS\\                    drive check, missing manuals, movie plan
    www\\  ai\\  kiwix\\  tools\\  TEXT-ONLY\\  MY-MAPS-INBOX\\   (content — no need to open these)

Browsers aren't allowed to run programs from a page (a security rule), so the page explains and the menu runs.
"""
import html, os, re, shutil

# key, file, title, when, what it does, needs internet
PROGRAMS = [
    ("1", "START-WINDOWS.bat", "Start the drive", "Every time - use this first",
     "Starts the offline AI, the maps and the Wikipedia/medical archives, then opens the Home page. Leave its window open; "
     "press a key in it to stop everything.", False),
    ("2", "SEARCH-NO-BROWSER-WINDOWS.bat", "Search with no web browser", "A bare, broken or locked-down computer",
     "Searches every guide, manual page and e-book in a plain black window. Type a number to read that page, "
     "o + number to open the file.", False),
    ("3", "ARCHIVES-NO-SERVER-WINDOWS.bat", "Read the archives in Kiwix", "If START won't run",
     "Opens the portable Kiwix reader for Wikipedia, WikEM, MDWiki, iFixit, Gutenberg and the rest — no server, no AI.", False),
    ("4", "ADD-MOVIES-AND-SHOWS-WINDOWS.bat", "Add movies and TV shows", "When you have new videos",
     "Looks through another drive or folder, shows a plan of names first, then copies or moves them into Movies, TV Shows, "
     "Kids Movies and Kids TV and updates Home > Movies & TV.", False),
    ("M", "ADD-MUSIC-WINDOWS.bat", "Add music", "When you have new songs",
     "Reads your songs' tags, shows a plan first, then copies or moves them into Music\\Artist\\Album folders (Kids Music too), "
     "saves album art and updates Home > Music.", False),
    ("5", "ADD-MY-MAPS-WINDOWS.bat", "Add my maps", "After putting files in MY-MAPS-INBOX",
     "Adds your MIMs, GeoPDFs, KML and GPX files to Home > My Maps and the locator map.", False),
    ("L", "ADD-MY-FILES-WINDOWS.bat", "Add my documents & books", "After putting files in MY-FILES-INBOX",
     "Adds your own PDFs, e-books and documents to the Library, sorted into sections by folder name (Medical, Survival, "
     "Homestead...). Exact duplicates of files already on the drive are skipped. Everything becomes searchable.", False),
    ("P", "ADD-MY-RADIO-FILES-WINDOWS.bat", "Add my radio files", "After putting files in MY-RADIO-INBOX",
     "Adds your CHIRP images, CPS files, radio manuals, programming software and phone apps to the Library, and turns every "
     "CHIRP .img into a searchable, printable channel list (with what changed from the main plan).", False),
    ("C", "ASK-CLAUDE-ONLINE-WINDOWS.bat", "Ask Claude online", "When ANY internet works (satellite, shelter Wi-Fi, hotspot)",
     "A plain text chat with Claude that uses very little data, for slow or expensive links. Needs your Anthropic API key "
     "(paste it when asked; it isn't saved). See Library > Computer & Case > Reaching Claude online.", True),
    ("G", "MAKE-A-GUIDE.bat", "Make a survival guide", "Before a trip, or during a situation",
     "Pick a situation — get home, shelter in place, water, medical, power out, winter storm, comms down, evacuate — and where you are now (a city like Montreal, or lat, lon), "
     "and, for the travel ones, a route. Builds ONE printable page from this drive: the first steps, the guide "
     "sections and manuals to read, the archives to open, the route plan with chokepoints and map links, and the "
     "nearest water, fuel, hospitals and shelter. Saved in www\\guides and opened for you.", False),
    ("T", "MAKE-TRAVEL-FOLDERS.bat", "Make travel (go-drive) folders", "Before a trip - then copy and paste to the go drive",
     "Builds TRAVEL\\ANDROID-GO, IPHONE-GO, MAC-GO, LINUX-GO, WINDOWS-GO and ALL-DEVICES-GO (one drive that works on every device, "
     "for emergencies): each is a ready, correctly laid-out drive sized to your go drive, up to 2 TB, using almost no extra space on this one. "
     "Drag the OFFGRID folder inside to the go drive. They rebuild by themselves after UPDATE-DRIVE. BUDGET-GUIDE.html shows what fits at each size.", False),
    ("J", "ADD-JOINT-PUBS.bat", "Add Joint Publications (JP 1 - JP 6)", "With internet",
     "Fetches the newest public edition of each Joint Publication (JP 1, 2-0, 3-0, 3-01 ... 6-0, the DoD Dictionary, CJCSM 5120.01B) "
     "straight from the Joint Staff's public list, and puts them in the library (run UPDATE-DRIVE or menu L afterwards so search finds them). Anything that needs a CAC is listed in "
     "REPORTS\\NOT-FETCHED-Joint-Doctrine.txt.", False),
    ("E", "ADD-STATE-MAPS.bat", "Add state highway maps (all 50 states + DC)", "With internet",
     "Finds each state DOT's official highway map and saves the newest PDF to www\\library\\State Highway Maps. States it can't fetch are listed with a link in REPORTS\\NOT-FETCHED-State-Maps.txt there.", False),
    ("F", "OCR-OVERNIGHT.bat", "OCR all scanned PDFs (overnight)", "Once, before bed - works offline",
     "Reads every picture-only PDF so search can find words inside it. Does ALL pages in one go (can take many hours), optionally shuts the PC down when done. "
     "Then builds the meaning-based search (finds pages by what they mean). Resumable: stop it any time and run it again.", False),
    ("0", "ADD-READING-LIST.bat", "Add the Commandant's Reading List", "With internet",
     "Downloads the free titles on the Commandant's Professional Reading List (Marine Corps University Press books, doctrine, public-domain classics) into the library.", False),
    ("Y", "TIDY-DRIVE.bat", "Tidy the drive", "Now and then",
     "Moves leftovers and old files (the old START HERE folder, stray .part/.tmp files) into _TIDY-BIN, never straight to deletion. "
     "Your library, maps, archives and notes are never touched. Bin folders older than 30 days are deleted automatically. "
     "Also lists duplicate files, download caches and unused AI models you could delete (REPORTS\\CLEANUP-SUGGESTIONS.txt).", False),
    ("X", "ADD-LIBRARY-EXTRAS.bat", "Add reports, encyclopedias, Ubuntu", "With internet",
     "DoD Inspector General reports, public-domain encyclopedias (Britannica 1911), TiddlyWiki and the Ubuntu boot ISO. "
     "Resumable; anything it cannot fetch is listed in REPORTS\\LIBRARY-EXTRAS-NOT-FETCHED.txt.", True),
    ("6", "CHECK-DRIVE.bat", "Check the drive", "After building or updating, and every few months",
     "Tests every part of the drive and writes REPORTS\\MISSING-MANUALS.html (clickable links to get anything missing) "
     "and MISSING-MANUALS.txt (send it to Claude to find other sources).", False),
    ("D", "DRIVE-DOCTOR.bat", "Deep health check (doctor)", "Monthly, or after a big copy",
     "Deeper than Check: a SHA-256 integrity manifest that catches corruption on the next run, a duplicate-file "
     "finder, broken-link and missing-file lists, and freshness ages. Writes REPORTS\\DOCTOR-REPORT.txt.", False),
    ("7", "UPDATE-DRIVE-WINDOWS.bat", "Update the drive", "Monthly, with internet",
     "Gets newer archives, programs, phone apps and maps, retries anything missing, then runs the check. "
     "Can take hours; stop and resume any time.", True),
    ("8", "COPY-TO-ANOTHER-DRIVE-WINDOWS.bat", "Copy to another drive", "Backup, travel or flash drive",
     "Mirrors this OFFGRID folder to another drive, built for the device you pick. It asks WHAT DEVICE it's for "
     "(Windows / Mac / Linux / Android / iPhone) and leaves out the programs that device can't run (a phone gets the "
     "content, not the Windows apps); WHERE YOU'RE GOING (a work-travel city), adding that route's get-home plan and topo; "
     "and the SIZE of the drive (128 GB, 1 TB...), sizing the copy to fit. Then F = everything, "
     "N = everything except movies/shows/music, A = automatic fit for a smaller drive, or C = choose exactly what to "
     "include yourself. Shows the sizes before it starts; after the first time only changes are copied.", False),
    ("9", "SET-MONTHLY-REMINDER-WINDOWS.bat", "Monthly update reminder", "Once, on your main computer",
     "Puts a reminder on the 1st of each month that offers to run the update when the drive is plugged in.", False),
    ("B", "FIND-BOOKS.bat", "Find & download books (needs internet)", "Any time you are online",
     "Search the Internet Archive for PDF/EPUB books (language courses, sign language, manuals), pick the ones you want "
     "and they are saved to the library and become searchable.", False),
    ("A", "ARMY-PUBS.bat", "Download Army, Marine & DoD manuals (needs internet)", "Any time you are online",
     "Fetches public US Army field manuals, technical manuals, ATPs, TCs and Marine Corps publications (no MCOs), then the FAS DoD doctrine "
     "library (irp.fas.org/doddir: Army, USMC, Navy, Air Force, DoD, military medicine) - skipping every publication already on the drive "
     "by its number. Resumable - run again to continue.", False),
    ("O", "ORGANIZE-LIBRARY.bat", "Tidy the library (names, sections, duplicates)", "After adding lots of files",
     "Previews, then (if you say yes) renames documents to their titles, sorts loose files into the right section and moves exact "
     "duplicates aside. Search keeps working and everything can be undone.", False),
    ("W", "MAP-DRIVE.bat", "Map the whole drive & check everything is in place", "After building or updating, or any time something seems missing",
     "Walks every folder, draws a clickable map and checks that launchers, pages, Command Center tiles, links between pages and "
     "library documents are all there - and lists half-finished downloads, leftover .osm.pbf files, empty files, duplicates and "
     "loose reports. Changes nothing. Writes REPORTS\\DRIVE-MAP.html and .txt. Needs no internet.", False),
    ("V", "VERIFY-DRIVE.bat", "Verify big files (checksums)", "After copying or building, every few months",
     "Checks the Kiwix archives, AI models and map tiles against saved checksums and lists anything damaged. "
     "Writes REPORTS\\VERIFY-REPORT.txt. Needs no internet.", False),
    ("R", "REPAIR-DRIVE.bat", "Repair missing downloads", "With internet, as often as you like",
     "Deletes damaged big files, re-runs the builder with your saved options so only what is missing downloads, "
     "then refreshes checksums. Stop and resume any time.", True),
    ("N", "INSTALL-SOFTWARE.bat", "Install offline programs", "On a computer that lacks QGIS, LibreOffice, Google Earth...",
     "Lists the Windows installers kept in the SOFTWARE folder (maps, documents, calculators, browser, OCR) and installs "
     "the ones you pick. Needs no internet.", False),
    ("Z", "PACK-DRIVE.bat", "Pack the drive into compressed volumes", "To store or carry the whole drive",
     "Compresses the whole OFFGRID folder into checksummed volumes (4 GB each by default) that restore onto any other "
     "computer with RESTORE-WINDOWS.bat. Resumable.", False),    ("H", "HOW-TO-USE.bat", "How to use this drive", "Read me — especially first time",
     "Opens the instruction manual: how to run the drive, what never to move or delete, how it heals itself, "
     "how to lock the important files, and what's safe to delete to save space. Also at www\\manual.html and "
     "HOW-TO-USE-THIS-DRIVE.txt.", False),
    ("I", "ADD-MY-PERSONAL-FILES.bat", "Add my PERSONAL family papers (private)", "After putting files in MY-PERSONAL-FILES-INBOX",
     "Sorts IDs, medical, insurance, deeds, wills, tax and family photos into PERSONAL\\ (Identity, Medical, Insurance...). PRIVATE: never put in the "
     "Library, search, the AI or the Command Center, and never read. Writes PERSONAL\\CHECKLIST.txt (which essential papers look present) and "
     "PERSONAL\\EXPIRING.txt (files named like 'Passport exp 2031-05.pdf', soonest first). Keep PERSONAL inside your VeraCrypt vault.", False),
    ("K", "PROTECT-FILES.bat", "Lock the important files", "When the drive is finished / going into the field",
     "Marks the launchers, pages and engine folders read-only so they can't be edited or deleted by accident. "
     "A guard against mistakes, not against a person, and it doesn't travel to other drives. Run UNPROTECT first "
     "if you need to update or add.", False),
    ("U", "UNPROTECT-FILES.bat", "Unlock the important files", "Before updating, adding or building",
     "Removes the read-only mark that PROTECT-FILES set, so Update, the Add programs and Build can write again. "
     "Re-run PROTECT-FILES afterward if you want them locked.", False),
]
SH = [("1", "start-mac-linux.sh", "Start the drive"), ("2", "search-no-browser.sh", "Search with no web browser"),
      ("4", "add-movies-mac-linux.sh", "Add movies and TV shows (give the folder)"), ("M", "add-music-mac-linux.sh", "Add music (give the folder)"), ("7", "update-drive-mac-linux.sh", "Update the drive (internet)")]
SH_EXTRA = ["start-android-termux.sh", "outage-mode-mac-linux.sh", "copy-ai-mac-linux.sh"]   # copied into PROGRAMS, not on the Mac/Linux menu
LEGACY_ROOT = [p[1] for p in PROGRAMS] + [s[1] for s in SH] + ["OPEN-ME-NO-INSTALL.html", "WHATS-HAPPENING.html", "SEARCH-EVERYTHING.html"]
REPORT_FILES = ["MISSING-MANUALS.html", "MISSING-MANUALS.txt", "MEDIA-PLAN.html", "MEDIA-PLAN.csv", "CHECK-REPORT.txt", "UPDATE-LOG.txt"]
CHECK_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\check_usb.py --dest "%~dp0." %*\r\npause\r\n'
DOCTOR_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\doctor.py --dest "%~dp0." %*\r\npause\r\n'
GUIDE_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\survival_guide.py --dest "%~dp0." %*\r\npause\r\n'
PROTECT_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\protect.py --dest "%~dp0." %*\r\npause\r\n'
UNPROTECT_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\protect.py --dest "%~dp0." --unlock %*\r\npause\r\n'
BOOKS_BAT = ('@echo off\r\ncd /d "%~dp0"\r\nset /p Q=What are you looking for (e.g. spanish grammar, sign language, field manual)? \r\n'
             'set /p L=Language code (spa, fre, ger ... or Enter for any)? \r\n'
             'tools\\python-win\\python.exe tools\\builder\\usb\\languages.py --dest "%~dp0." --search "%Q%" --lang "%L%"\r\npause\r\n')
ARMY_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\army_pubs.py --dest "%~dp0." --profile full --marines\r\n'
            'echo.\r\necho Now the FAS DoD doctrine library (Army, USMC, Navy, Air Force, DoD, military medicine) - anything already on the drive is skipped.\r\n'
            'tools\\python-win\\python.exe tools\\builder\\usb\\fas_doddir.py --dest "%~dp0."\r\npause\r\n')
ORGANIZE_BAT = ('@echo off\r\ncd /d "%~dp0"\r\nset P=tools\\python-win\\python.exe tools\\builder\\usb\\organize_drive.py --dest "%~dp0."\r\n'
                '%P%\r\necho.\r\necho Full list: REPORTS\\organize-plan.txt\r\nset /p A=Apply these changes now? (Y = yes, U = undo the last run, anything else = no) \r\n'
                'if /i "%A%"=="Y" %P% --apply\r\nif /i "%A%"=="U" %P% --undo\r\npause\r\n')
VERIFY_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\verify_drive.py --dest "%~dp0." --verify %*\r\npause\r\n'
MAP_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\map_drive.py --dest "%~dp0." %*\r\nif exist REPORTS\\DRIVE-MAP.html start "" REPORTS\\DRIVE-MAP.html\r\npause\r\n'
REPAIR_BAT = '@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\repair_drive.py --dest "%~dp0." %*\r\npause\r\n'
PACK_BAT = '@echo off\r\ncd /d "%~dp0"\r\nset /p OUT=Folder to write the pack into (not on this drive, e.g. F:\\OFFGRID-PACK): \r\ntools\\python-win\\python.exe tools\\builder\\usb\\pack_drive.py --dest "%~dp0." --out "%OUT%" %*\r\npause\r\n'
INSTALL_SW_BAT = '@echo off\r\nif not exist "%~dp0SOFTWARE\\INSTALL-MENU.bat" (echo No programs on the drive yet - run the builder or REPAIR-DRIVE with internet. & pause & exit /b)\r\ncall "%~dp0SOFTWARE\\INSTALL-MENU.bat"\r\n'
TRAVEL_BAT = ('@echo off\r\ncd /d "%~dp0"\r\necho Make a go-drive folder. Copy it to your go drive afterwards (drag and drop).\r\n'
              'echo Devices: windows, mac, linux, iphone, android, ALL (one drive that works on every device)\r\n'
              'set /p D=Device (Enter = build every one): \r\n'
              'echo Go-drive size in GB: 32, 64, 128, 256, 512, 1000 or 2000 (2 TB is the largest).\r\n'
              'set /p G=Size in GB (Enter = the default for that device): \r\n'
              'set X=\r\nif not "%D%"=="" set X=--device %D%\r\nif not "%G%"=="" set X=%X% --budget-gb %G%\r\n'
              'tools\\python-win\\python.exe tools\\builder\\usb\\platforms.py --dest "%~dp0." --travel %X%\r\n'
              'echo.\r\necho Done. Open TRAVEL\\BUDGET-GUIDE.html to see what fits at each size.\r\npause\r\n')
JOINT_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\joint_doctrine.py --dest "%~dp0."\r\necho.\r\necho Done. To make the new PDFs searchable run  UPDATE-DRIVE  or  Add my documents and books (menu L).\r\npause\r\n')
STATE_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\state_maps.py --dest "%~dp0." %*\r\necho.\r\necho Done. Open the Command Center - Maps - State highway maps. Anything missing is listed in REPORTS\\NOT-FETCHED-State-Maps.txt\r\npause\r\n')
OCR_BAT = ('@echo off\r\ncd /d "%~dp0"\r\n'
           'echo OCR every scanned PDF on the drive, then rebuild search. Resumable: if it stops, run it again.\r\n'
           'echo Set Windows to never sleep while plugged in, and leave the drive connected.\r\n'
           'set /p S=Shut the computer down when finished? Type YES, or press Enter to stay on: \r\n'
           'tools\\python-win\\python.exe tools\\builder\\usb\\usb_builder.py --dest "%~dp0." --ocr-only --ocr-pages 100000000\r\n'
           'echo.\r\necho OCR finished. Progress is in REPORTS\\OCR-REPORT.txt\r\n'
           'if /i "%S%"=="YES" shutdown /s /t 90 /c "OFFGRID OCR finished - shutting down in 90 seconds (shutdown /a cancels)"\r\n'
           'pause\r\n')
MEANING_BAT = ('@echo off\r\ncd /d "%~dp0"\r\n'
               'echo Builds the meaning-based search for every page on the drive (finds pages by what they mean).\r\n'
               'echo Works offline. Resumable: if it stops, run it again - finished documents are kept.\r\n'
               'echo Leave the drive connected; the computer is kept awake while it runs.\r\n'
               'set /p S=Shut the computer down when finished? Type YES, or press Enter to stay on: \r\n'
               'tools\\python-win\\python.exe tools\\builder\\usb\\semantic.py --dest "%~dp0." --hours 0\r\n'
               'echo.\r\necho Meaning search finished.\r\n'
               'if /i "%S%"=="YES" shutdown /s /t 90 /c "OFFGRID meaning search finished - shutting down in 90 seconds (shutdown /a cancels)"\r\n'
               'pause\r\n')
AI_LEARN_BAT = ('@echo off\r\ncd /d "%~dp0"\r\nset PYTHONUTF8=1\r\n'
                'echo ================================================================\r\n'
                'echo   AI LEARN THE DRIVE  -  run overnight\r\n'
                'echo ================================================================\r\n'
                'echo The drive\'s own AI reads every page and writes a short note on what it covers and where it\r\n'
                'echo sits, so search finds the right page and the AI understands what it is handed.\r\n'
                'echo Works offline. Resumable: close the window any time, run it again later and it carries on.\r\n'
                'echo Your library goes first (medical, survival, disasters, water, food, comms), archives after.\r\n'
                'echo The library takes a night or two on a normal computer; the archives take many nights.\r\n'
                'echo Leave the drive connected; the computer is kept awake while it runs.\r\necho.\r\n'
                'set H=\r\nset /p H=How many hours tonight? Type a number, or press Enter to run until finished: \r\n'
                'if "%H%"=="" set H=0\r\n'
                'set /p S=Shut the computer down when it stops? Type YES, or press Enter to stay on: \r\n'
                'tools\\python-win\\python.exe tools\\builder\\usb\\context_notes.py --dest "%~dp0." --hours %H%\r\n'
                'echo.\r\necho Finished for now. Progress: REPORTS\\AI-LEARN-THE-DRIVE.txt\r\n'
                'if /i "%S%"=="YES" shutdown /s /t 90 /c "OFFGRID AI learning stopped - shutting down in 90 seconds (shutdown /a cancels)"\r\n'
                'pause\r\n')
READ_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\reading_list.py --dest "%~dp0."\r\necho.\r\necho Done. Open the Command Center - Library - Commandant\'s Reading List.\r\npause\r\n')
TIDY_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\tidy.py --dest "%~dp0."\r\necho.\r\n'
            'if exist REPORTS\\CLEANUP-SUGGESTIONS.txt start "" notepad REPORTS\\CLEANUP-SUGGESTIONS.txt\r\n'
            'set /p E=Delete the tidy bin right now too? Type YES to delete, or just press Enter to keep it for 30 days: \r\n'
            'if /i "%E%"=="YES" tools\\python-win\\python.exe tools\\builder\\usb\\tidy.py --dest "%~dp0." --empty\r\npause\r\n')
EXTRAS_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\library_extras.py --dest "%~dp0." %*\r\npause\r\n')
PERSONAL_BAT = ('@echo off\r\ncd /d "%~dp0"\r\ntools\\python-win\\python.exe tools\\builder\\usb\\personal_files.py --dest "%~dp0."\r\n'
                'echo.\r\nif exist PERSONAL\\CHECKLIST.txt start "" notepad PERSONAL\\CHECKLIST.txt\r\npause\r\n')
TOP20_BAT = ('@echo off\r\ncd /d "%~dp0"\r\necho Rebuilding the Top 20 situations pages from everything now on the drive...\r\n'
             'tools\\python-win\\python.exe tools\\builder\\usb\\situation_packs.py --dest "%~dp0." --open\r\npause\r\n')
def _mk(intro, cmds, after="Done.", ask=None):
    """A drive-side program: runs the drive's own Python and builder copy (paths are fixed for PROGRAMS\\ later)."""
    L = ['@echo off', 'cd /d "%~dp0"', 'set PYTHONUTF8=1', 'set PY=tools\\python-win\\python.exe', 'set B=tools\\builder\\usb']
    L += ["echo " + x if x else "echo." for x in intro] + ["echo."]
    if ask:
        L += ask
    L += cmds + ["echo.", "echo " + after, "pause"]
    return "\r\n".join(L) + "\r\n"


_U = '%PY% %B%\\usb_builder.py --dest "%~dp0." --update '
# Programs with a button in the START-HERE window's "More programs" section (the text menu has no letters left; its
# R > P opens this folder instead). (file, title, when, what it does, needs internet, group, text)
MORE = [
    ("REBUILD-SEARCH.bat", "Rebuild search and pages", "After adding or changing files by hand",
     "Re-reads the library, PDFs, archives and your files into search, then remakes the pages, the Top 20 situations and the dashboard. Offline.",
     False, "Refresh (no internet)", _mk(["Rebuilding search and every page from what is on the drive now. Offline.",
                                          "Large drives take a while - unchanged files are not re-read."], [_U + "--search-only"])),
    ("RESTORE-INDEXES.bat", "Check / restore the search indexes", "If search breaks or files were deleted",
     "Checks the search index, archive lists, route places, FEMA data and settings against the backup in BACKUP\\INDEXES "
     "(made after every build and update) and puts back anything missing or damaged. Can also copy the backup to another drive. Offline.",
     False, "Refresh (no internet)", _mk([
        "Backups of the indexes are in BACKUP\\INDEXES (made after every build and update, newest 2 kept).", "",
        "  K = check only            R = restore missing or damaged files  [usual]",
        "  A = restore everything    B = make a backup now",
        "  C = copy the newest backup to another drive or folder"],
        ['if "%CH%"=="" set CH=R',
         'if /i "%CH%"=="K" %PY% %B%\\index_backup.py --dest "%~dp0." --check',
         'if /i "%CH%"=="R" %PY% %B%\\index_backup.py --dest "%~dp0." --restore',
         'if /i "%CH%"=="A" %PY% %B%\\index_backup.py --dest "%~dp0." --restore --all',
         'if /i "%CH%"=="B" %PY% %B%\\index_backup.py --dest "%~dp0."',
         'if /i "%CH%"=="C" set /p TO= Copy to which drive or folder (e.g. F:\\): ',
         'if /i "%CH%"=="C" %PY% %B%\\index_backup.py --dest "%~dp0." --copy-to "%TO%"'],
        ask=["set CH=", "set /p CH= Choose K, R, A, B or C - press Enter for R: "])),
    ("REFRESH-PAGES.bat", "Refresh pages only (fast)", "After small changes",
     "Remakes the dashboard, drive checklist, drive catalog, Ask speed-ups, Field Notebook and Top 20 pages without rebuilding search. Offline.",
     False, "Refresh (no internet)", _mk(["Refreshing the dashboard, checklist, catalog, Ask speed-ups, Field Notebook and Top 20 pages..."],
                                          [f'%PY% %B%\\{m}.py --dest "%~dp0."' for m in ("drive_catalog", "drive_checklist", "ask_fast", "field_notebook", "dashboard", "situation_packs")])),
    ("REFRESH-GOOGLE-EARTH-AND-EXCEL.bat", "Remake Google Earth + Excel files", "After new places or maps",
     "Rewrites GOOGLE-EARTH-READY (KML layers, fixed so polygons show) and EXCEL-READY (workbooks with coordinates) from the data on the drive. Offline.",
     False, "Refresh (no internet)", _mk(["Remaking the Google Earth and Excel files from the drive's data..."],
                                          [f'%PY% %B%\\{m}.py --dest "%~dp0."' for m in ("kml_export", "kml_fix", "xlsx_export")])),
    ("CONVERT-OSM-MAPS.bat", "Convert OpenStreetMap files", "After putting .osm.pbf files in OSM-MAP-SOURCE",
     "Turns OpenStreetMap downloads in OSM-MAP-SOURCE into map layers and places for the locator. Offline.",
     False, "Refresh (no internet)", _mk(["Put .osm.pbf files from download.geofabrik.de in the OSM-MAP-SOURCE folder first."], [_U + "--convert-maps-only"])),
    ("ADD-PLACES.bat", "Add places farther from home", "With internet - widen the places radius",
     "Hospitals, pharmacies, food, fuel, water, gun and pawn shops... out to the miles you choose (500, then 600, 700...). About 10 GB of state extracts at 500 miles. Resumable.",
     True, "Add maps and places (internet)", _mk(["Places around home out to a radius you choose. Finished states are kept; close and re-run any time."],
        [_U + "--places-only --places-radius %MILES%"], ask=["set MILES=", "set /p MILES= How many miles around home? 500, 600, 700 ... press Enter for 500: ", 'if "%MILES%"=="" set MILES=500'])),
    ("ADD-ROUTE-PLACES.bat", "Add places along the get-home routes", "With internet - before travel",
     "Hospitals, clinics, pharmacies, food, fuel, water, shelters, police and ham repeaters within 25 miles of every get-home "
     "route and 40 miles around each start city - including Ontario and Quebec. Then remakes the survival guides so 'get home "
     "from Quebec' lists what is near Quebec and along the way. Reuses the 500-mile places; keeps the Canadian map files in "
     "OSM-MAP-SOURCE so CONVERT-OSM-MAPS can make street maps of them. Resumable.",
     True, "Add maps and places (internet)", _mk(["Places along every get-home route, including Canada. Downloads state/province map extracts;",
                                                  "finished ones are kept - close and re-run any time."], [_U + "--route-places-only"])),
    ("UPDATE-HAM-CALL-SIGNS.bat", "Update ham call signs (US + Canada)", "With internet - monthly",
     "Downloads the FCC (US) and ISED (Canada) amateur licence lists and rebuilds the offline lookup: search by call sign, ZIP, "
     "Canadian postal code, or town (Canton, GA / Quebec, QC). UPDATE-DRIVE does this too.",
     True, "Add maps and places (internet)", _mk(["Downloading the US and Canadian ham licence lists..."], [_U + "--ham-only"])),
    ("ADD-TOPO-MAPS.bat", "Add topo maps", "With internet",
     "USGS topo map sheets (GeoPDF) around home, the bases, cities and lakes on your list, and the Canadian work cities. Resumable.",
     True, "Add maps and places (internet)", _mk(["Downloads USGS topo sheets. Press Enter to use the radius from the last build."],
        ['if "%MILES%"=="" (%PY% %B%\\usb_builder.py --dest "%~dp0." --update --topo-only) else (%PY% %B%\\usb_builder.py --dest "%~dp0." --update --topo-only --topo-pdf-radius %MILES%)'],
        ask=["set MILES=", "set /p MILES= Miles around home for topo sheets - press Enter for the usual: "])),
    ("ADD-SATELLITE-IMAGERY.bat", "Add satellite imagery (Eastern US + Canada)", "With internet - large, run overnight",
     "Satellite imagery for every eastern state and province, extra detail along the get-home routes and home, then the phone "
     "files and the printable map PDFs. Pick a level 1-4. Resumable: stop any time, run again to continue.",
     True, "Add maps and places (internet)", _mk([
        "Satellite imagery for the Eastern US and Eastern Canada. Saved as it goes - close the window any time,",
        "run it again later and it carries on. Then it makes the phone files and the printable map PDFs.",
        "Order: whole region first, then routes and home, then building-level photos of home, routes, bases, cities.",
        "", "  1 = whole region overview + routes and home in detail          (~35 GB, a day or two)",
        "  2 = level 1 + whole region at town-and-road detail (zoom 13)   (~45 GB)  [usual]",
        "  3 = level 2 + zoom 14 everywhere, more detail at bases/cities  (~125 GB, several days)",
        "  4 = level 3 + zoom 15 everywhere, the most detail everywhere   (~450 GB, weeks)"],
        ['if "%LV%"=="" set LV=2',
         'if "%HRS%"=="" (%PY% %B%\\usb_builder.py --dest "%~dp0." --update --satellite-only --imagery-level %LV%) '
         'else (%PY% %B%\\usb_builder.py --dest "%~dp0." --update --satellite-only --imagery-level %LV% --imagery-hours %HRS%)'],
        ask=["set LV=", "set /p LV= Level 1-4 - press Enter for 2: ", "set HRS=",
             "set /p HRS= Stop after how many hours? - press Enter to run until done: "])),
    ("MAKE-PRINTABLE-MAPS.bat", "Make printable satellite maps", "After adding imagery - offline",
     "Remakes the PDFs in PRINTABLE MAPS: home (3 zoom levels) and every get-home route as overlapping sheets with the route, "
     "border crossings, chokepoints, water, hospitals, fuel, towns and a lat/long grid. Offline.",
     False, "Refresh (no internet)", _mk(["Making the printable satellite map PDFs from the imagery on the drive. Offline."], [_U + "--map-sheets-only"])),
    ("MAKE-PHONE-SATELLITE.bat", "Make satellite files for phones", "After adding imagery - offline",
     "Remakes the OsmAnd satellite files for home and each route (Phone apps > Satellite maps for phones). Offline.",
     False, "Refresh (no internet)", _mk(["Making the OsmAnd satellite files for phones from the imagery on the drive. Offline."], [_U + "--phone-satellite-only"])),
    ("ADD-US-STREET-MAP.bat", "Add the whole-US street map", "With internet - very large",
     "Streams a street map of the whole United States into the locator (zoom 14 is well over 100 GB). Resumable.",
     True, "Add maps and places (internet)", _mk(["The whole-US street map is VERY large. Make sure the drive has the space. Resumable."], [_U + "--us-map-only"])),
    ("UPDATE-FEMA-AND-RIVER-CHARTS.bat", "Update FEMA shelters, recovery centers + river charts", "With internet - before a storm, after a disaster",
     "Every registered shelter in the eastern states, which shelters and FEMA Disaster Recovery Centers are open right now, "
     "disaster-declared counties (2 years), and the Corps of Engineers river charts along the routes. Map layers + GOOGLE-EARTH-READY\\FEMA.",
     True, "Add maps and places (internet)", _mk(["Refreshing FEMA shelters, open shelters, recovery centers, disaster declarations and river charts..."],
                                                [_U + "--fema-only"])),
    ("ADD-HOSPITALS.bat", "Update hospitals", "With internet",
     "Downloads the national hospitals layer (phone, beds, trauma level) and remakes its Excel and Google Earth files.",
     True, "Add maps and places (internet)", _mk(["Updating the hospitals layer..."], [_U + "--hospitals-only"])),
    ("ADD-CAVES.bat", "Find caves near home", "With internet - quick",
     "One quick OpenStreetMap query: caves within the miles you choose, as CSV, Excel, Google Earth and GPS files.",
     True, "Add maps and places (internet)", _mk(["Caves around home."], [_U + "--caves-only --caves-radius %MILES%"],
        ask=["set MILES=", "set /p MILES= How many miles around home? press Enter for 500: ", 'if "%MILES%"=="" set MILES=500'])),
    ("ADD-MEDICINES.bat", "Update the medicine list", "With internet",
     "Downloads the FDA drug labels and rebuilds the Medicine page (uses and warnings).",
     True, "Add maps and places (internet)", _mk(["Updating the medicine list from FDA labels..."], [_U + "--meds-only"])),
    ("UPDATE-WEATHER-PAGE.bat", "Update the weather & almanac page", "With internet, once a year",
     "Rebuilds the offline climate and almanac page (NOAA 1991-2020 normals) for your area.",
     True, "Add maps and places (internet)", _mk(["Rebuilding the weather and almanac page..."], ['%PY% %B%\\weather.py --dest "%~dp0."'])),
    ("MAKE-ANDROID-FOLDER.bat", "Make the Android folder", "Before copying to a phone or SD card",
     "Rebuilds PLATFORMS\\ANDROID: the apps, maps and pages an Android phone needs, with plain setup steps. Offline.",
     False, "Tools", _mk(["Rebuilding PLATFORMS\\ANDROID..."], ['%PY% %B%\\android_pack.py --dest "%~dp0."'])),
    ("REBUILD-OPEN-WITH.bat", "Rebuild OPEN-WITH folders", "If you want one folder per program",
     "One folder per program with links to the files it opens. Uses no extra space on this drive, but plain copy tools (robocopy, Explorer) copy the links as full files - delete OPEN-WITH before copying the drive.",
     False, "Tools", _mk(["Making OPEN-WITH. Delete that folder before copying the drive to another one."], ['%PY% %B%\\openwith.py --dest "%~dp0."'])),
    ("TOPO-DOWNLOAD-TEST.bat", "Test one topo download", "If topo maps don't stay on the drive",
     "Downloads a single topo sheet and reports why sheets may not be kept (antivirus, permissions, full drive).",
     True, "Tools", _mk(["Testing one topo map download..."], ['%PY% %B%\\topo_probe.py "%~dp0."'])),
    ("MEANING-OVERNIGHT.bat", "Meaning search - build overnight", "Once, overnight - works offline",
     "Builds the find-by-meaning index for every page on the drive, with no time limit. Offline, resumable, keeps the computer awake; can shut down when done.",
     False, "", None),
    ("AI-LEARN-THE-DRIVE-OVERNIGHT.bat", "AI learn the drive - run overnight", "Overnight, as many nights as you like - works offline",
     "The drive's AI reads every page and writes a short note on what it covers, so search and Ask find the right page. "
     "Library first, archives after. Offline, resumable, keeps the computer awake; can shut down when done.",
     False, "", None),
    ("OUTAGE-MODE.bat", "OUTAGE MODE - start on battery", "Power is out - use instead of Start",
     "Starts the drive with the smallest AI, shorter AI memory, half the CPU and no graphics card; switches to the power-saving "
     "plan, dims the screen and can turn Wi-Fi off. Puts everything back when you close the Command Center. Offline.",
     False, "", None),
    ("COPY-AI-TO-THIS-COMPUTER.bat", "Copy the AI to this computer (faster)", "Once, on a computer you use often",
     "Copies the AI program and the models this computer uses onto its own disk so the AI loads faster. The drive stays the "
     "master copy; START falls back to the drive if the copy is out of date. Remove it any time. Offline.",
     False, "", None),
    ("TOP-20-SITUATIONS.bat", "Rebuild Top 20 situations", "After adding manuals, OCR or meaning search",
     "Re-gathers the 20 situation pages from everything now on the drive and opens them.", False, "", None),
]
OUTAGE_BAT = "\r\n".join([
    '@echo off', 'cd /d "%~dp0"', 'title OFFGRID - OUTAGE MODE',
    'echo ================================================================',
    'echo   OUTAGE MODE  -  power is out, make the battery last',
    'echo ================================================================',
    'echo Starts the drive with the SMALLEST AI model, shorter AI memory, half the CPU',
    'echo cores and the graphics card left off. Switches Windows to its power-saving plan and',
    'echo dims the screen; both go back to normal when you close the Command Center window.',
    'echo.',
    'set BATT=',
    'for /f %%b in (\'powershell -NoProfile -Command "$b=Get-CimInstance Win32_Battery -EA 0|Select -First 1; if($b){$b.EstimatedChargeRemaining}"\') do set BATT=%%b',
    'if defined BATT echo  Battery now: %BATT% percent',
    'if not defined BATT echo  No battery found - this looks like a desktop. Outage mode still uses less power.',
    'REM remember the current power plan and screen brightness so they can be put back',
    'set OLDPLAN=',
    'for /f "tokens=2 delims=:(" %%g in (\'powercfg /getactivescheme\') do for /f %%h in ("%%g") do set OLDPLAN=%%h',
    'powercfg /setactive a1841308-3541-4fab-bc81-f71556f20b4a >nul 2>&1',
    'if errorlevel 1 (echo  Power saver plan not available here - use the battery icon slider: Best battery life.) else (echo  Power plan: Power saver)',
    'set OLDBRIGHT=',
    'for /f %%v in (\'powershell -NoProfile -Command "try{(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -EA Stop|Select -First 1).CurrentBrightness}catch{}"\') do set OLDBRIGHT=%%v',
    'if defined OLDBRIGHT powershell -NoProfile -Command "try{(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,30)}catch{}" >nul 2>&1',
    'if defined OLDBRIGHT echo  Screen dimmed to 30 percent (was %OLDBRIGHT%)',
    'echo.',
    'set W=',
    'set /p W=Turn Wi-Fi OFF to save battery? Phones on this Wi-Fi will lose the drive. Type YES, or press Enter to keep it: ',
    'set WIFIOFF=',
    'if /i "%W%"=="YES" powershell -NoProfile -Command "$a=Get-NetAdapter -Physical -EA 0|?{$_.PhysicalMediaType -match \'802.11\' -and $_.Status -ne \'Disabled\'}; if(-not $a){exit 2}; try{$a|Disable-NetAdapter -Confirm:$false -EA Stop; exit 0}catch{exit 1}" >nul 2>&1',
    'if /i "%W%"=="YES" if errorlevel 2 (echo  No Wi-Fi adapter found.) else if errorlevel 1 (echo  Windows needs administrator rights for that - opening Wi-Fi settings: switch Wi-Fi off there. & start "" ms-settings:network-wifi) else (set WIFIOFF=1& echo  Wi-Fi is off.)',
    'echo.',
    'set OFFGRID_MODE=outage',
    'call "%~dp0PROGRAMS\\START-WINDOWS.bat"',
    'set OFFGRID_MODE=',
    'echo.',
    'echo Putting the computer back to normal...',
    'if defined OLDPLAN powercfg /setactive %OLDPLAN% >nul 2>&1',
    'if defined OLDBRIGHT powershell -NoProfile -Command "try{(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,%OLDBRIGHT%)}catch{}" >nul 2>&1',
    'if defined WIFIOFF set /p W=Turn Wi-Fi back ON? Type YES, or press Enter to leave it off: ',
    'if defined WIFIOFF if /i "%W%"=="YES" powershell -NoProfile -Command "Get-NetAdapter -Physical -EA 0|?{$_.PhysicalMediaType -match \'802.11\'}|Enable-NetAdapter -Confirm:$false" >nul 2>&1',
    'echo Done.', 'timeout /t 5 >nul', ''])
COPY_AI_BAT = _mk([
    "COPY THE AI TO THIS COMPUTER  -  makes the AI load and answer faster on a computer you use often.",
    "The drive stays the master copy and must still be plugged in. After a drive update START uses the",
    "drive again by itself until you run this again. Copies to this computer's user folder (LOCALAPPDATA).", "",
    "  C = copy (or refresh) the AI to this computer  [usual]",
    "  S = show what is copied",
    "  R = remove the copy from this computer (the drive is not touched)"],
    ['if "%CH%"=="" set CH=C',
     'if /i "%CH%"=="C" %PY% %B%\\ai_local.py --dest "%~dp0." copy',
     'if /i "%CH%"=="S" %PY% %B%\\ai_local.py --dest "%~dp0." status',
     'if /i "%CH%"=="R" %PY% %B%\\ai_local.py --dest "%~dp0." remove'],
    ask=["set CH=", "set /p CH= Choose C, S or R - press Enter for C: "])
HOWTO_BAT = '@echo off\r\nstart "" "%~dp0www\\manual.html"\r\n'

def _bat_for_programs(src):
    """A root .bat rewritten to run from PROGRAMS\\ (paths point one folder up)."""
    s = src.replace("\r\n", "\n")
    s = s.replace("%~dp0", "%OG%\\").replace("%OG%\\.", "%OG%")
    s = re.sub(r"(?im)^@echo off\n", '@echo off\nfor %%I in ("%~dp0..") do set "OG=%%~fI"\n', s, count=1)
    return s.replace("\n", "\r\n")


def _sh_for_programs(src):
    return src.replace('cd "$(dirname "$0")" || exit 1', 'cd "$(dirname "$0")/.." || exit 1')


RUNNING = ("UPDATE-DRIVE-WINDOWS.bat", "update-drive-mac-linux.sh")   # may be the script running this very update


def _put(path, text, updating):
    """Write only if changed. A batch file that is running must not change under it (cmd reads it as it goes),
    so during an update the update script is written next to itself as .new and START-HERE swaps it in later."""
    if path.endswith(".bat") and text.startswith("@echo off\r\n") and "chcp" not in text[:60]:
        text = "@echo off\r\nchcp 65001 >nul\r\n" + text[len("@echo off\r\n"):]     # show dashes and arrows, not '-'
    try:
        if open(path, encoding="utf-8", newline="").read() == text:
            return
    except OSError:
        pass
    if updating and os.path.exists(path) and (os.path.basename(path) in RUNNING or path.endswith((".bat", ".sh"))):
        path += ".new"
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


def write(dest, here, updating=False):
    # Run from the drive's own builder copy (Update, Repair, OCR overnight, Add-...): one of these programs may be the one
    # running right now, so changed programs are written as .new and START-HERE swaps them in next time it opens.
    try:
        updating = updating or os.path.normcase(os.path.realpath(here)).startswith(os.path.normcase(os.path.realpath(dest)) + os.sep)
    except (OSError, ValueError):
        pass
    prog = os.path.join(dest, "PROGRAMS")
    rep = os.path.join(dest, "REPORTS")
    os.makedirs(prog, exist_ok=True)
    os.makedirs(rep, exist_ok=True)
    for key, f, *_ in PROGRAMS:
        gen = {"CHECK-DRIVE.bat": CHECK_BAT, "DRIVE-DOCTOR.bat": DOCTOR_BAT, "MAKE-A-GUIDE.bat": GUIDE_BAT,
               "PROTECT-FILES.bat": PROTECT_BAT, "UNPROTECT-FILES.bat": UNPROTECT_BAT, "HOW-TO-USE.bat": HOWTO_BAT, "ADD-MY-PERSONAL-FILES.bat": PERSONAL_BAT,
               "VERIFY-DRIVE.bat": VERIFY_BAT, "MAP-DRIVE.bat": MAP_BAT, "FIND-BOOKS.bat": BOOKS_BAT, "MAKE-TRAVEL-FOLDERS.bat": TRAVEL_BAT, "ADD-LIBRARY-EXTRAS.bat": EXTRAS_BAT, "ADD-JOINT-PUBS.bat": JOINT_BAT, "ADD-STATE-MAPS.bat": STATE_BAT, "OCR-OVERNIGHT.bat": OCR_BAT, "ADD-READING-LIST.bat": READ_BAT, "TIDY-DRIVE.bat": TIDY_BAT, "ARMY-PUBS.bat": ARMY_BAT, "ORGANIZE-LIBRARY.bat": ORGANIZE_BAT, "REPAIR-DRIVE.bat": REPAIR_BAT, "PACK-DRIVE.bat": PACK_BAT, "INSTALL-SOFTWARE.bat": INSTALL_SW_BAT}
        src = gen[f] if f in gen else open(os.path.join(here, f), encoding="utf-8", newline="").read()
        _put(os.path.join(prog, f), _bat_for_programs(src), updating)
    for f in SH_EXTRA:
        _put(os.path.join(prog, f), _sh_for_programs(open(os.path.join(here, f), encoding="utf-8").read()).replace("\r\n", "\n"), updating)
    for _, f, _ in SH:
        _put(os.path.join(prog, f), _sh_for_programs(open(os.path.join(here, f), encoding="utf-8").read()).replace("\r\n", "\n"), updating)
    # old layout: these used to sit at the top of the drive — remove our own copies, move reports.
    # (During an update the old update script may be the one running: START-HERE removes it next time.)
    for f in LEGACY_ROOT:
        p = os.path.join(dest, f)
        if os.path.isfile(p) and not (updating and f in RUNNING):
            os.remove(p)
    for f in REPORT_FILES:
        p = os.path.join(dest, f)
        if os.path.isfile(p):
            try:
                if f == "UPDATE-LOG.txt" and os.path.exists(os.path.join(rep, f)):   # keep both logs
                    with open(os.path.join(rep, f), "a", encoding="utf-8", errors="replace") as fo:
                        fo.write(open(p, encoding="utf-8", errors="replace").read())
                    os.remove(p)
                else:
                    shutil.move(p, os.path.join(rep, f))
            except OSError:
                pass
    # extra program with a button in the START-HERE window only (the text menu has no letters left)
    for f, *_r, text in MORE:
        text = text or {"MEANING-OVERNIGHT.bat": MEANING_BAT, "TOP-20-SITUATIONS.bat": TOP20_BAT,
                        "AI-LEARN-THE-DRIVE-OVERNIGHT.bat": AI_LEARN_BAT,
                        "OUTAGE-MODE.bat": OUTAGE_BAT, "COPY-AI-TO-THIS-COMPUTER.bat": COPY_AI_BAT}[f]
        _put(os.path.join(prog, f), _bat_for_programs(text), updating)
    _menu_bat(dest)
    _gui_ps1(dest)
    try:
        os.remove(os.path.join(dest, "PROGRAMS", "ORGANIZE-OTHER-FILES.bat"))   # removed in v54
    except OSError:
        pass
    _menu_sh(dest)
    for path, root in ((os.path.join(dest, "READ-ME-FIRST.html"), "www/"), (os.path.join(dest, "www", "programs.html"), "")):
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(_page(root))
    with open(os.path.join(dest, "USE-ON-PHONE.html"), "w", encoding="utf-8") as fh:
        fh.write(_phone_page())
    try:
        import dashboard
        dashboard.build(dest)            # DASHBOARD.html at the top of the drive: the double-click front page
    except Exception as e:  # noqa: BLE001
        print(f"  ! Dashboard: {type(e).__name__}: {e}")


def _phone_page():
    """A self-contained guide (opens from a phone's Files app, no server needed): what to install and what to copy, for Android and iPhone."""
    return """<!doctype html><meta charset=utf-8><title>Using this drive on a phone</title>
<meta name=viewport content="width=device-width,initial-scale=1">
<style>body{font:16px/1.6 system-ui,-apple-system,sans-serif;max-width:46rem;margin:1.5rem auto;padding:0 1rem;color:#1a1a1a}
h1{font-size:1.5rem}h2{margin-top:1.8rem;border-bottom:2px solid #ccc;padding-bottom:.2rem}
.box{background:#f4f2ec;border-left:4px solid #b04a2f;padding:.8rem 1rem;margin:1rem 0;border-radius:4px}
code{background:#eee;padding:.1rem .3rem;border-radius:3px}li{margin:.35rem 0}td,th{border-bottom:1px solid #ccc;padding:.3rem .5rem;text-align:left;vertical-align:top}</style>
<h1>Using the drive on a phone or tablet</h1>
<div class=box><b>Android: open <code>PLATFORMS/ANDROID/START-HERE-ANDROID.html</code> first.</b> It has the two-minute setup that makes the pages, search and maps work. Tapping pages in Files alone shows them blank.</div>
<div class=box><b>Drive format: exFAT.</b> iPhones and many Android phones cannot read NTFS (the format a big external drive
usually comes in). Make a phone-ready copy onto an exFAT flash drive or SD card with <b>COPY-TO-ANOTHER-DRIVE</b> and pick
<i>Android</i> or <i>iPhone</i>.</div>
<div class=box><b>Do this BEFORE you go off-grid:</b> app stores need internet. Android apps can be installed from this drive
(below). iPhone apps cannot - install them from the App Store while you are online.</div>

<h2>What you need on the phone</h2>
<table><tr><th>Job</th><th>App</th><th>Android</th><th>iPhone</th></tr>
<tr><td>Wikipedia, medicine, how-to archives</td><td>Kiwix</td><td>APK on the drive</td><td>App Store (free)</td></tr>
<tr><td>Offline maps, GPS, routes</td><td>OsmAnd / Organic Maps</td><td>APK on the drive</td><td>App Store (OsmAnd free tier)</td></tr>
<tr><td>Books and PDFs</td><td>KOReader</td><td>APK on the drive</td><td>Files + Books (built in)</td></tr>
<tr><td>Videos and music</td><td>VLC</td><td>APK on the drive</td><td>App Store (free)</td></tr>
<tr><td>Text with no cell service (LoRa radios)</td><td>Meshtastic</td><td>APK on the drive</td><td>App Store (free)</td></tr>
<tr><td>Private messages without internet (Bluetooth / Wi-Fi)</td><td>Briar</td><td>APK on the drive</td><td>not available</td></tr>
<tr><td>Team map and positions</td><td>ATAK-CIV / iTAK</td><td>APK on the drive</td><td>iTAK, App Store</td></tr>
<tr><td>Stars and direction</td><td>Sky Map</td><td>APK on the drive</td><td>Stellarium Mobile (App Store)</td></tr>
<tr><td>Record tracks and distance</td><td>OpenTracks</td><td>APK on the drive</td><td>use OsmAnd</td></tr>
<tr><td>The whole drive menu, search and offline AI</td><td>Termux</td><td>APK on the drive</td><td>not possible - use a laptop on the same Wi-Fi</td></tr>
<tr><td>Offline AI chat</td><td>PocketPal AI</td><td>Play Store / Termux</td><td>App Store (load a .gguf model from <code>ai/models</code>)</td></tr>
</table>

<h2>Android - install from the drive</h2>
<ol>
<li>Plug the drive in (USB-C, or an OTG adapter). Open a file manager and go to <code>www/phone-apps/android</code>.</li>
<li>Tap an <code>.apk</code>. The first time, Android asks to allow installs from this source - allow it, then tap Install.
Install <b>F-Droid</b> first if you want to update the apps later.</li>
<li><b>No cable?</b> On a computer running the drive, a phone on the same Wi-Fi can open the address the launcher shows plus
<code>/phone-apps/</code> and tap the links to download.</li>
<li><b>Kiwix:</b> open the app, choose <i>Open file</i> and pick a <code>.zim</code> from <code>kiwix/zim</code>.
For a phone, copy the smaller archives to the phone first (it reads them faster from internal storage).</li>
<li><b>Maps:</b> copy the <code>.obf</code> files from <code>www/phone-apps/osmand-maps</code> into
<code>Android/data/net.osmand.plus/files/</code> (or open them with OsmAnd). Organic Maps downloads its own maps while online.</li>
<li><b>Whole menu:</b> install Termux, run <code>termux-setup-storage</code>, then
<code>sh /storage/XXXX-XXXX/OFFGRID/PROGRAMS/start-android-termux.sh</code> (<code>ls /storage</code> shows the drive name).</li>
</ol>

<h2>iPhone / iPad</h2>
<ol>
<li>Install Kiwix, OsmAnd (or Organic Maps), VLC, Meshtastic, iTAK and Stellarium Mobile from the App Store now.</li>
<li>Plug the drive in (USB-C on iPhone 15 and newer, Lightning adapter on older) and open <b>Files</b> &rarr; the drive.</li>
<li>Guides, checklists and topo maps are PDFs - tap to open. <b>TEXT-ONLY</b> has plain-text copies.</li>
<li>Kiwix: add the <code>.zim</code> files from <code>kiwix/zim</code>. OsmAnd: save a map to Files &rarr; On My iPhone &rarr; OsmAnd &rarr; Resources.</li>
<li>The search box, menu and AI need a small local server, which iOS does not allow. Use a laptop, then join its Wi-Fi/hotspot
and open the address it shows in Safari - everything works that way.</li>
</ol>

<h2>How much room the phone needs</h2>
<ul>
<li><b>About 16 GB:</b> the guides and PDFs, a medical archive, two state maps, the apps.</li>
<li><b>About 64 GB:</b> add Wikipedia (small version), more maps, books and a small AI model.</li>
<li><b>128 GB or an SD card:</b> add the larger archives and movies.</li>
</ul>
<p>Keep a power bank and a USB-C cable with the phone. Keep the phone in airplane mode to save battery.</p>"""


def _menu_bat(dest):
    L = ["@echo off", "REM ===== OFF-GRID SURVIVAL DRIVE - start here. Every program on the drive, by number. =====",
         'cd /d "%~dp0"', "title OFF-GRID DRIVE - START HERE", "chcp 65001 >nul",
         "REM finish an update: swap in the new update script, remove the old top-level copies",
         'for %%F in ("PROGRAMS\\*.new") do move /y "%%~fF" "%%~dpnF" >nul',
         'if exist "PROGRAMS\\update-drive-mac-linux.sh.new" move /y "PROGRAMS\\update-drive-mac-linux.sh.new" "PROGRAMS\\update-drive-mac-linux.sh" >nul',
         'if exist "UPDATE-DRIVE-WINDOWS.bat" del "UPDATE-DRIVE-WINDOWS.bat"',
         'if exist "update-drive-mac-linux.sh" del "update-drive-mac-linux.sh"',
         "REM a window with buttons if PowerShell can open one; 'START-HERE.bat text' (or any problem) gives the numbered menu below",
         'if /i "%~1"=="text" goto menu',
         'if not exist "PROGRAMS\\START-HERE-GUI.ps1" goto menu',
         'where powershell >nul 2>&1 || goto menu',
         'powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0PROGRAMS\\START-HERE-GUI.ps1"',
         'if not errorlevel 1 exit /b 0',
         'echo  The button window could not open here - using the text menu.',
         ":menu", "cls",
         "echo.", "echo   OFF-GRID SURVIVAL DRIVE  -  type a number or letter", "echo   ============================================="]
    for key, f, title, when, *_ in PROGRAMS:
        L.append(f"echo    {key}  {title:<30} ({when})".replace("&", "^&").replace(">", "^>").replace("(", "^(").replace(")", "^)"))
    pk = [p[0] for p in PROGRAMS]
    fixed = [(c, t) for c, t in (("H", "Open the Home page without starting anything"), ("W", "What's happening? - pick a situation"),
                                 ("S", "Search page / PROGRAMS folder ^(every program^) / Reports"), ("I", "Instructions: what each program does"),
                                 ("T", "Plain-text copies folder ^(Notepad^)"), ("R", "Folders: reports, ALL programs, plain text"),
                                 ("Q", "Quit")) if c not in pk]      # choice rejects a letter listed twice
    L += ["echo."] + [f"echo    {c}  {t}" for c, t in fixed] + ["echo.",
          "choice /c " + "".join(pk) + "".join(c for c, _ in fixed) + " /n /m \"Choice: \"",
          "set N=%errorlevel%"]
    keys = pk + [c for c, _ in fixed]
    for i, k in enumerate(keys, 1):
        L.append(f"if %N%=={i} goto k{k}")
    L.append("goto menu")
    for key, f, title, *_ in PROGRAMS:
        L += [f":k{key}", f'start "{title}" "%~dp0PROGRAMS\\{f}"', "goto menu"]
    tail = {"H": 'start "" "%~dp0www\\home.html"', "W": 'start "" "%~dp0www\\topics.html"', "S": 'echo.& echo    S  Search page   P  PROGRAMS folder - every program, incl. ones not on this menu   R  Reports& '
                 'choice /c SPR /n /m "Which: "& if errorlevel 3 (start "" explorer "%~dp0REPORTS") else if errorlevel 2 '
                 '(start "" explorer "%~dp0PROGRAMS") else (start "" "%~dp0www\\search.html")',
            "I": 'start "" "%~dp0READ-ME-FIRST.html"',
            "T": 'if exist "%~dp0TEXT-ONLY" (start "" explorer "%~dp0TEXT-ONLY") else (echo  Not built yet & timeout /t 3 >nul)',
            "R": 'echo.& echo    R  Reports   P  PROGRAMS folder - every program, incl. ones not on this menu   T  Plain-text copies& '
                 'choice /c RPT /n /m "Folder: "& if errorlevel 3 (start "" explorer "%~dp0TEXT-ONLY") else if errorlevel 2 '
                 '(start "" explorer "%~dp0PROGRAMS") else (start "" explorer "%~dp0REPORTS")', "Q": "exit /b"}
    for c, _ in fixed:
        L += [f":k{c}", tail[c]] + ([] if c == "Q" else ["goto menu"])
    p, text = os.path.join(dest, "START-HERE.bat"), "\r\n".join(L) + "\r\n"
    try:
        if open(p, encoding="utf-8", newline="").read() == text:
            return                  # unchanged: never rewrite a menu that may be open right now
    except OSError:
        pass
    with open(p, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


# button window: (heading, program keys in order). A program not listed lands under "More".
GUI_GROUPS = [("Use the drive", ["2", "3", "G", "H"]), ("Add my own files", ["L", "I", "4", "M", "5", "P", "0"]),
              ("Check and repair", ["6", "W", "D", "V", "R", "Y", "O"]),
              ("Update and online", ["7", "B", "A", "J", "E", "X", "C", "F", "T"]),
              ("Copy, back up, protect", ["8", "Z", "9", "K", "U", "N"])]


def _gui_ps1(dest):
    """START-HERE-GUI.ps1: a Windows Forms window - big START button (opens the Command Center) and one button per program.
    Each button starts the same PROGRAMS\\*.bat the text menu does, so nothing else changes. Closes with exit code 0."""
    q = lambda t: "'" + t.replace("'", "''") + "'"
    by = {k: (f, t, w, d, n) for k, f, t, w, d, n in PROGRAMS}
    used = {"1"}
    L = ["# OFF-GRID drive - button window (generated by the builder). Text menu: START-HERE.bat text",
         "$ErrorActionPreference = 'Stop'",
         "try {",
         "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing",
         "$root = Split-Path $PSScriptRoot -Parent",
         "try { Add-Type -Name W -Namespace OG -MemberDefinition '[DllImport(\"kernel32.dll\")] public static extern IntPtr GetConsoleWindow(); [DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h, int c);'; [void][OG.W]::ShowWindow([OG.W]::GetConsoleWindow(), 0) } catch {}",
         "$tip = New-Object System.Windows.Forms.ToolTip; $tip.AutoPopDelay = 30000; $tip.InitialDelay = 300",
         "function Run($rel) { $p = Join-Path $root $rel; if (Test-Path $p) { Start-Process -FilePath $p -WorkingDirectory $root } else { [void][System.Windows.Forms.MessageBox]::Show(\"Not found: $rel\", 'Off-grid drive') } }",
         "$f = New-Object System.Windows.Forms.Form; $f.Text = 'OFF-GRID SURVIVAL DRIVE'; $f.StartPosition = 'CenterScreen'; $f.Width = 820; $f.Height = 720; $f.BackColor = [System.Drawing.Color]::FromArgb(20,23,26); $f.Font = New-Object System.Drawing.Font('Segoe UI', 10)",
         "$pn = New-Object System.Windows.Forms.FlowLayoutPanel; $pn.Dock = 'Fill'; $pn.AutoScroll = $true; $pn.Padding = New-Object System.Windows.Forms.Padding(14); $pn.FlowDirection = 'TopDown'; $pn.WrapContents = $false; $f.Controls.Add($pn)",
         "function Head($t) { $l = New-Object System.Windows.Forms.Label; $l.Text = $t; $l.AutoSize = $true; $l.ForeColor = [System.Drawing.Color]::FromArgb(217,164,65); $l.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 12); $l.Margin = New-Object System.Windows.Forms.Padding(0,14,0,4); $pn.Controls.Add($l) }",
         "function Row() { $r = New-Object System.Windows.Forms.FlowLayoutPanel; $r.AutoSize = $true; $r.WrapContents = $true; $r.Width = 760; $r.Margin = New-Object System.Windows.Forms.Padding(0); $pn.Controls.Add($r); return $r }",
         "function Btn($row, $text, $rel, $tipText, $w, $h, $back) { $b = New-Object System.Windows.Forms.Button; $b.Text = $text; $b.Tag = $rel; $b.Width = $w; $b.Height = $h; $b.UseMnemonic = $false; $b.FlatStyle = 'Flat'; $b.ForeColor = [System.Drawing.Color]::White; $b.BackColor = $back; $b.Margin = New-Object System.Windows.Forms.Padding(0,0,8,8); $b.Add_Click({ param($s,$e) Run $s.Tag }); $tip.SetToolTip($b, $tipText); $row.Controls.Add($b) }",
         "$dark = [System.Drawing.Color]::FromArgb(44,50,58); $green = [System.Drawing.Color]::FromArgb(40,120,70); $gold = [System.Drawing.Color]::FromArgb(150,105,20)",
         "Head 'Start here'"]
    f, t, w, d, n = by["1"]
    L.append(f"$r = Row; Btn $r {q('START THE DRIVE  -  opens the Command Center')} {q('PROGRAMS/' + f)} {q(d)} 752 64 $green")
    L.append("$r = Row")
    L.append(f"Btn $r {q('OUTAGE MODE  -  power is out, start on battery')} {q('PROGRAMS/OUTAGE-MODE.bat')} {q('Smallest AI, power-saving plan, dimmer screen, Wi-Fi off if you want. Everything goes back to normal when you close the Command Center.')} 560 44 $gold")
    L.append(f"Btn $r {q('Copy AI to this PC')} {q('PROGRAMS/COPY-AI-TO-THIS-COMPUTER.bat')} {q('Copies the AI onto this computer so it loads faster. The drive stays the master copy.')} 184 44 $dark")
    L.append("$r = Row")
    L.append(f"Btn $r {q('DASHBOARD  -  big-tile front page (no server needed)')} {q('DASHBOARD.html')} {q('The page anyone can double-click: Top 20 situations, Command Center, search, library, maps, medicine, radio.')} 752 40 $dark")
    L.append("$r = Row")
    L.append(f"Btn $r {q('TOP 20 SITUATIONS  -  what to do, what you need, best pages')} {q('TOP 20 SITUATIONS/00 - START HERE.html')} {q('Power out, fire, flood, bleeding, no water, evacuate... one page each, gathered from this drive. Print the ones that matter.')} 560 44 $gold")
    L.append(f"Btn $r {q('Rebuild Top 20')} {q('PROGRAMS/TOP-20-SITUATIONS.bat')} {q('Re-gathers the 20 pages after you add manuals, OCR or meaning search.')} 184 44 $dark")
    L.append(f"Btn $r {q('Drive checklist (what it still needs)')} {q('REPORTS/DRIVE-CHECKLIST.html')} {q('Rewritten every builder run: what is done, what is missing, what only you can confirm.')} 368 40 $gold")
    L.append(f"Btn $r {q('Search with no server')} {q('www/search.html')} {q('Full-text search of every guide, manual page and book. Works by double-click.')} 368 40 $dark")
    L.append(f"Btn $r {q('Meaning search - build overnight')} {q('PROGRAMS/MEANING-OVERNIGHT.bat')} {q('Builds the find-by-meaning index for every page on the drive, with no time limit. Offline, resumable, keeps the computer awake; can shut down when done.')} 368 40 $dark")
    L.append("$r = Row")
    L.append(f"Btn $r {q('AI LEARN THE DRIVE  -  run overnight')} {q('PROGRAMS/AI-LEARN-THE-DRIVE-OVERNIGHT.bat')} {q('The AI reads every page and writes a short note on what it covers, so search and Ask find the right page. Offline, resumable, keeps the computer awake; can shut down when done.')} 368 40 $gold")
    L.append(f"Btn $r {q('Files to add yourself (ideas)')} {q('www/suggested-files.html')} {q('Manuals the builder cannot fetch, local guides to look up for your area, and your personal files.')} 368 40 $dark")
    for head, keys in GUI_GROUPS:
        ks = [k for k in keys if k in by]
        used.update(ks)
        if not ks:
            continue
        L.append(f"Head {q(head)}; $r = Row")
        for k in ks:
            f, t, w, d, n = by[k]
            L.append(f"Btn $r {q(t + (' (internet)' if n else ''))} {q('PROGRAMS/' + f)} {q(w + chr(10) + chr(10) + d)} 368 40 $dark")
    rest = [k for k in by if k not in used]
    if rest:
        L.append("Head 'More'; $r = Row")
        for k in rest:
            f, t, w, d, n = by[k]
            L.append(f"Btn $r {q(t)} {q('PROGRAMS/' + f)} {q(w + chr(10) + chr(10) + d)} 368 40 $dark")
    groups = {}
    for f, t, w, d, n, g, _x in MORE:
        if g:
            groups.setdefault(g, []).append((f, t, w, d, n))
    for g, items in groups.items():
        L.append(f"Head {q('More programs - ' + g)}; $r = Row")
        for f, t, w, d, n in items:
            L.append(f"Btn $r {q(t + (' (internet)' if n else ''))} {q('PROGRAMS/' + f)} {q(w + chr(10) + chr(10) + d)} 368 40 $dark")
    L += ["Head 'Other'; $r = Row",
          "Btn $r 'PROGRAMS folder (every program)' 'PROGRAMS' 'Every program on the drive; each works by double-click.' 368 40 $dark",
          "Btn $r 'Reports folder' 'REPORTS' 'Drive check, drive map, checklist, logs.' 368 40 $dark",
          "Btn $r 'Text menu (numbered)' 'START-HERE.bat' 'The old numbered menu, in a black window. Use it if anything here misbehaves.' 368 40 $dark",
          "$f.Add_Shown({ $f.Activate() }); [void]$f.ShowDialog(); exit 0",
          "} catch { exit 1 }"]
    # the text-menu button must pass the word 'text'
    ps = "\n".join(L)
    ps = ps.replace("Btn $r 'Text menu (numbered)' 'START-HERE.bat'", "Btn $r 'Text menu (numbered)' 'PROGRAMS/START-HERE-TEXT.bat'")
    os.makedirs(os.path.join(dest, "PROGRAMS"), exist_ok=True)
    with open(os.path.join(dest, "PROGRAMS", "START-HERE-GUI.ps1"), "w", encoding="utf-8-sig", newline="\r\n") as fh:
        fh.write(ps + "\n")
    with open(os.path.join(dest, "PROGRAMS", "START-HERE-TEXT.bat"), "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write('@echo off\ncall "%~dp0..\\START-HERE.bat" text\n')


def _menu_sh(dest):
    rows = "\n".join(f'  echo "   {k}  {t}"' for k, _, t in sorted(SH + [("6", "", "Check the drive")]))
    cases = "\n".join(f'    {k}) sh PROGRAMS/{f} ;;' for k, f, _ in SH)
    s = f'''#!/bin/sh
# ===== OFF-GRID SURVIVAL DRIVE - start here (Mac / Linux).  Run:  sh /path/to/OFFGRID/start-here-mac-linux.sh =====
cd "$(dirname "$0")" || exit 1
case "$(uname -s)" in Darwin) OPEN=open ;; *) OPEN=xdg-open ;; esac
for f in UPDATE-DRIVE-WINDOWS.bat update-drive-mac-linux.sh; do
  [ -f "PROGRAMS/$f.new" ] && mv -f "PROGRAMS/$f.new" "PROGRAMS/$f"; rm -f "$f"
done
for n in PROGRAMS/*.new; do [ -f "$n" ] && mv -f "$n" "${{n%.new}}"; done
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
while :; do
  echo; echo "   OFF-GRID SURVIVAL DRIVE  -  type a number or letter"; echo "   ============================================="
{rows}
  echo "   H  Home page (no server)      I  Instructions      Q  Quit"
  printf "Choice: "; read -r C || exit 0
  case "$C" in
{cases}
    6) "$PY" tools/check_usb.py --dest "$(pwd)" ;;
    h|H) $OPEN www/home.html ;;
    i|I) $OPEN READ-ME-FIRST.html ;;
    q|Q) exit 0 ;;
    4) printf "Folder with your movies/shows: "; read -r M; sh PROGRAMS/add-movies-mac-linux.sh "$M" ;;
    m|M) printf "Folder with your music: "; read -r M; sh PROGRAMS/add-music-mac-linux.sh "$M" ;;
  esac
done
'''
    # "4" needs the folder: put its own case first so it wins
    s = s.replace("    4) sh PROGRAMS/add-movies-mac-linux.sh ;;\n", "").replace("    M) sh PROGRAMS/add-music-mac-linux.sh ;;\n", "")
    with open(os.path.join(dest, "start-here-mac-linux.sh"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(s)


def _page(root):
    e = html.escape
    rows = "".join(
        f"<tr><td class='k'>{k}</td><td><b>{e(t)}</b>{' <span class=net>needs internet</span>' if net else ''}<br><span class=w>{e(w)}</span></td>"
        f"<td>{e(d)}</td><td><code>PROGRAMS\\{e(f)}</code></td></tr>" for k, f, t, w, d, net in PROGRAMS)
    more = "".join(
        f"<tr><td class='k'>+</td><td><b>{e(t)}</b>{' <span class=net>needs internet</span>' if net else ''}<br><span class=w>{e(w)}</span></td>"
        f"<td>{e(d)}</td><td><code>PROGRAMS\\{e(f)}</code></td></tr>" for f, t, w, d, net, _g, _x in MORE)
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Read me first — Off-grid drive</title><style>
body{{font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#14171a;color:#e6e8eb;margin:0;padding:18px}}
main{{max-width:1050px;margin:auto}}h1{{margin:.2em 0}}h2{{margin-top:1.6em;border-bottom:1px solid #2c323a;padding-bottom:4px}}a{{color:#d9a441}}
.btns{{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px}}
.btns a{{display:block;background:#1c2025;border:1px solid #2c323a;border-radius:10px;padding:12px 14px;text-decoration:none;color:#e6e8eb}}
.btns a:hover{{border-color:#d9a441}}.btns b{{display:block;color:#d9a441}}.btns span{{font-size:14px;color:#9aa3ad}}
.big{{background:#1f1a10;border:1px solid #d9a441;border-radius:12px;padding:14px 16px;margin:12px 0}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #2c323a;padding:8px 6px;text-align:left;vertical-align:top}}
td.k{{font-size:22px;font-weight:700;color:#d9a441;width:34px}}.w{{color:#9aa3ad;font-size:14px}}
.net{{font-size:12px;background:#2a3038;color:#f0c674;border-radius:8px;padding:1px 6px}}code{{background:#0f1214;padding:1px 5px;border-radius:4px;font-size:13px}}
pre{{background:#0f1214;padding:10px;border-radius:8px;overflow:auto;font-size:14px}}.note{{color:#9aa3ad}}
</style></head><body><main>
<h1>Off-grid survival drive — read me first</h1>
<div class="big"><b>Windows:</b> double-click <b>START-HERE.bat</b> in the OFFGRID folder. It opens a window with a button for every program —
click the big green <b>START THE DRIVE</b> button (it opens the Command Center). If the window can't open, you get the numbered text menu instead (press <b>1</b>). <br><b>Mac / Linux:</b> open Terminal, type <code>sh </code> and drag <b>start-here-mac-linux.sh</b> into the window, press Enter.
<p class="note" style="margin:.5em 0 0">Web pages can't start programs (browsers block that for safety), so the buttons below open pages and
the menu runs programs. Each program is also in the <b>PROGRAMS</b> folder and works on its own by double-click.</p></div>

<h2 id="home">Open now — works with nothing running</h2>
<div class="btns">
<a href="{root}home.html" data-live="home.html"><b>🏠 Home</b><span>Everything on the drive, one page</span></a>
<a href="{root}topics.html" data-live="topics.html"><b>🧭 What's happening?</b><span>Bleeding, tornado, power out… first steps and what to read</span></a>
<a href="{root}search.html" data-live="search.html"><b>🔎 Search everything</b><span>Every guide and every page of every manual (no AI)</span></a>
<a href="{root}library/index.html" data-live="library/index.html"><b>📚 Library</b><span>All guides, manuals and e-books</span></a>
<a href="{root}index.html" data-live="index.html"><b>📍 Locator + maps</b><span>Nearest hospitals, fuel, water, stores; map layers</span></a>
<a href="{root}media/index.html" data-live="media/index.html"><b>🎬 Movies &amp; TV</b><span>Your movies and shows</span></a>
<a href="{root}music/index.html" data-live="music/index.html"><b>🎵 Music</b><span>Your songs: artists, albums, playlists, shuffle</span></a>
</div>
<p class="note">The AI, the street map and the Wikipedia/medical archives need the drive started first (menu <b>1</b>). When it's running these
buttons use it automatically.</p>

<h2>Programs (START-HERE menu numbers)</h2>
<table><tr><th></th><th>Program</th><th>What it does</th><th>File</th></tr>{rows}</table>
<h2>More programs (buttons in the START-HERE window; text menu: S then P opens the folder)</h2>
<table><tr><th></th><th>Program</th><th>What it does</th><th>File</th></tr>{more}</table>
<p class="note">Mac / Linux: <code>PROGRAMS/start-mac-linux.sh</code> (1), <code>search-no-browser.sh</code> (2), <code>add-movies-mac-linux.sh</code> (4),
<code>add-music-mac-linux.sh</code> (M), <code>update-drive-mac-linux.sh</code> (7); check the drive with <code>python3 tools/check_usb.py --dest .</code> (6).</p>

<h2>What's in each folder</h2>
<pre>OFFGRID\\
  START-HERE.bat          the menu (Windows)         start-here-mac-linux.sh   the menu (Mac / Linux)
  DASHBOARD.html          big-tile front page        (double-click: Top 20, Command Center, search, library)
  READ-ME-FIRST.html      this page                  README.txt                the same, as plain text
  PROGRAMS\\               every program the menu runs
  REPORTS\\                drive check, MISSING-MANUALS (links to get them), MEDIA-PLAN (movie names)
  MY-MAPS-INBOX\\          drop your own maps here, then menu 5
  MY-FILES-INBOX\\         drop your own documents and books here, then menu L
  MY-PERSONAL-FILES-INBOX\\  PRIVATE family papers (IDs, medical, insurance, deeds): sorted into PERSONAL\\, never indexed or shown
  MY-RADIO-INBOX\\         drop your radio files here (CHIRP .img, CPS, manuals, software), then menu P
  TEXT-ONLY\\              every guide, manual and e-book as plain .txt — Notepad, e-readers, phones
  www\\                    the pages, library, maps, movies (www\\media), music (www\\music)
  kiwix\\                  Wikipedia, medical, Gutenberg, Khan Academy and other archives
  ai\\                     the offline AI models
  tools\\                  portable Python, web server, VLC, SumatraPDF, VeraCrypt, the builder (for updates)
  family-vault.hc         your encrypted documents (if you made one)</pre>

<h2>If something won't work</h2>
<ul><li><b>Locked-down or borrowed computer (programs blocked):</b> use the buttons above — they work as plain files. For text only, open the
<b>TEXT-ONLY</b> folder and double-click any file.</li>
<li><b>No web browser:</b> menu <b>2</b> (search in a black window). Videos: <code>tools\\vlc\\vlc.exe</code>. PDFs and e-books: <code>tools\\sumatra\\SumatraPDF.exe</code>.</li>
<li><b>AI or maps missing:</b> menu <b>6</b> checks the drive and says what to fix.</li>
<li><b>Phones:</b> start the drive on a laptop (menu 1); the launcher window shows the address to open on the same Wi-Fi.</li></ul>
</main>
<script>
// use the drive's web server if it's running (AI, maps and archives work there), otherwise open the files directly
fetch("http://localhost:8090/home.html", {{ mode: "no-cors", cache: "no-store" }}).then(() => {{
  document.querySelectorAll("a[data-live]").forEach(a => a.href = "http://localhost:8090/" + a.dataset.live);
}}).catch(() => {{}});
</script></body></html>
"""
