"""One catalog of everything on the drive that is NOT already in the library search list: map layers, topo sheets,
phone maps, GPS files, Kiwix archives, movies, TV and music - plus drive totals. Written to www/data/catalog.js and merged
into the Command Center's Library (filter chips), its search box and its Maps tab. Read-only; safe to run any time.
    python drive_catalog.py --dest E:\\OFFGRID
"""
import glob, json, os, re, shutil, time


def _gb(p):
    try:
        return round(os.path.getsize(p) / 1e9, 2)
    except OSError:
        return 0


def _pretty(stem):
    return re.sub(r"[_-]+", " ", stem).strip().title()


def _load_js(path, var):
    try:
        t = open(path, encoding="utf-8").read()
        return json.loads(re.search(r"window\." + var + r"=(.*?);\s*$", t, re.S).group(1))
    except (OSError, AttributeError, ValueError):
        return None


def build(dest):
    www = os.path.join(dest, "www")
    items = []          # [kind, title, href (relative to www, or KIWIX:name), sub, gb]
    add = lambda *x: items.append(list(x))
    # ---- maps
    for p in sorted(glob.glob(os.path.join(www, "map", "*.pmtiles"))):
        add("Maps", "Street map layer: " + _pretty(os.path.splitext(os.path.basename(p))[0]), "index.html",
            "Opens in the locator map (works on any device through the drive's server)", _gb(p))
    try:
        cat = json.load(open(os.path.join(www, "topo", "catalog.json"), encoding="utf-8"))
        n = sum(len(v.get("quads", v) if isinstance(v, dict) else v) for v in cat.get("areas", {}).values())
        if cat.get("areas"):
            add("Maps", f"USGS topo sheets ({len(cat['areas'])} areas, {n} sheets)", "topo/index.html",
                "Printable GeoPDF topo maps - also open in Avenza / PDF Maps on a phone", 0)
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    for p in sorted(glob.glob(os.path.join(www, "phone-apps", "osmand-maps", "*.obf"))):
        add("Maps", "Phone map (OsmAnd): " + _pretty(os.path.splitext(os.path.basename(p))[0]),
            os.path.relpath(p, www).replace(os.sep, "/"), "Copy to the phone and open with OsmAnd - full offline GPS navigation", _gb(p))
    for p in sorted(glob.glob(os.path.join(www, "data", "export", "*.kml")) + glob.glob(os.path.join(www, "data", "export", "*.gpx"))):
        add("Maps", "GPS file: " + _pretty(os.path.splitext(os.path.basename(p))[0]) + " (" + p[-3:].upper() + ")",
            os.path.relpath(p, www).replace(os.sep, "/"), "Google Earth, OsmAnd, Gaia, Garmin BaseCamp, QGIS", _gb(p))
    if os.path.isdir(os.path.join(www, "mymaps")):
        add("Maps", "My maps (your own files)", "mymaps/index.html", "Maps you added through MY-MAPS-INBOX", 0)
    # ---- archives
    for p in sorted(glob.glob(os.path.join(dest, "kiwix", "zim", "*.zim"))):
        stem = os.path.splitext(os.path.basename(p))[0]
        add("Archives", _pretty(re.sub(r"_\d{4}-\d{2}$", "", stem)), "KIWIX:" + stem,
            "Kiwix archive - opens with the drive started (or the Kiwix app)", _gb(p))
    # ---- media
    m = _load_js(os.path.join(www, "media", "catalog.js"), "MEDIA") or {}
    shows = {}
    for e in m.get("items", []):
        if e.get("show"):
            shows.setdefault((e["c"], e["show"]), 0)
            shows[(e["c"], e["show"])] += 1
        else:
            add("Movies & TV", e.get("t", "?") + (f" ({e['y']})" if e.get("y") else ""), "media/index.html#" + e.get("p", ""), e.get("c", ""), e.get("z", 0))
    for (c, s), n in sorted(shows.items()):
        add("Movies & TV", s, "media/index.html", f"{c} - {n} episodes", 0)
    mu = _load_js(os.path.join(www, "music", "catalog.js"), "MUSIC") or {}
    for al in mu.get("albums", [])[:3000]:
        if isinstance(al, dict):
            add("Music", (al.get("t") or al.get("title") or "?") + (" - " + al["ar"] if al.get("ar") else ""), "music/index.html", "Album", 0)
    try:
        du = shutil.disk_usage(dest)
        drive = {"used_gb": round((du.total - du.free) / 1e9), "free_gb": round(du.free / 1e9), "total_gb": round(du.total / 1e9)}
    except OSError:
        drive = {}
    try:
        opts = json.load(open(os.path.join(dest, "tools", "build-options.json"), encoding="utf-8"))
        drive["home"] = opts.get("label", "")
    except (OSError, ValueError):
        pass
    drive["built"] = time.strftime("%Y-%m-%d %H:%M")
    os.makedirs(os.path.join(www, "data"), exist_ok=True)
    with open(os.path.join(www, "data", "catalog.js"), "w", encoding="utf-8") as fh:
        fh.write("window.CATALOG=" + json.dumps({"items": items, "drive": drive}, separators=(",", ":"), ensure_ascii=False) + ";\n")
    return len(items)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", required=True)
    print(build(ap.parse_args().dest), "items")
