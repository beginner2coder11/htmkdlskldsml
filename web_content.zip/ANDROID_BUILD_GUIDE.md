# دليل تحويل المشروع إلى تطبيق أندرويد حقيقي (APK / AAB)
مشروع: Apktozip

هذه الحزمة جاهزة للتحويل المباشر إلى تطبيق أندرويد حقيقي. اختر الطريقة الأنسب لك:

## الطريقة 1: التحويل الفوري السحابي (الأسهل والأسرع)
1. افتح منصة تحويل الويب إلى أندرويد مثل [VoltBuilder](https://volt.build/) أو [AppsGeyser](https://appsgeyser.com/).
2. ارفع ملف الـ ZIP هذا مباشرة.
3. اضغط "Build APK" وقم بتنزيل ملف التطبيق على هاتفك وتثبيته!

## الطريقة 2: عبر إطار عمل Capacitor (Native Android Studio)
1. تأكد من تثبيت Node.js على حاسوبك.
2. قم بإنشاء مشروع جديد:
   `npm install @capacitor/core @capacitor/cli @capacitor/android`
3. ضع ملف `index.html` داخل مجلد `www`.
4. أضف منصة أندرويد:
   `npx cap add android`
   `npx cap sync`
   `npx cap open android`
5. سيفتح المشروع في Android Studio لتوليد ملف الـ APK النهائي.

تم إنشاء هذا الكود بواسطة Nexus Android AI Studio.