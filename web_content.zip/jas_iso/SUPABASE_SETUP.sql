-- JAS Laundry: secure Supabase cloud snapshot + realtime setup
-- Run this whole script in Supabase Dashboard > SQL Editor.

create table if not exists public.jas_laundry_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','staff')),
  created_at timestamptz not null default now()
);

create table if not exists public.jas_laundry_cloud (
  id text primary key check (id = 'main'),
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by text
);

alter table public.jas_laundry_members enable row level security;
alter table public.jas_laundry_cloud enable row level security;

create or replace function public.is_jas_laundry_member()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.jas_laundry_members m
    where m.user_id = auth.uid()
  );
$$;

revoke all on function public.is_jas_laundry_member() from public;
grant execute on function public.is_jas_laundry_member() to authenticated;

drop policy if exists "JAS members can read their membership" on public.jas_laundry_members;
create policy "JAS members can read their membership"
on public.jas_laundry_members for select to authenticated
using (user_id = auth.uid());

drop policy if exists "JAS members can read cloud data" on public.jas_laundry_cloud;
create policy "JAS members can read cloud data"
on public.jas_laundry_cloud for select to authenticated
using (public.is_jas_laundry_member());

drop policy if exists "JAS members can insert cloud data" on public.jas_laundry_cloud;
create policy "JAS members can insert cloud data"
on public.jas_laundry_cloud for insert to authenticated
with check (public.is_jas_laundry_member());

drop policy if exists "JAS members can update cloud data" on public.jas_laundry_cloud;
create policy "JAS members can update cloud data"
on public.jas_laundry_cloud for update to authenticated
using (public.is_jas_laundry_member())
with check (public.is_jas_laundry_member());

grant select on public.jas_laundry_members to authenticated;
grant select, insert, update on public.jas_laundry_cloud to authenticated;

-- Enable Postgres Changes (Realtime) for the cloud snapshot table.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'jas_laundry_cloud'
  ) then
    alter publication supabase_realtime add table public.jas_laundry_cloud;
  end if;
end $$;

-- AFTER creating the Supabase Owner login in the app and confirming its email,
-- replace YOUR_OWNER_EMAIL with that exact email and run this separately:
-- insert into public.jas_laundry_members (user_id, role)
-- select id, 'owner' from auth.users
-- where lower(email) = lower('YOUR_OWNER_EMAIL')
-- on conflict (user_id) do update set role = excluded.role;
