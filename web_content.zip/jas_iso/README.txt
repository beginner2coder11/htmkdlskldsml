JAS LAUNDRY ROOM - SUPABASE CLOUD SYNC BUILD

Android Studio project with the existing JAS Laundry HTML app and native Android bridge.

SUPABASE ONE-TIME SETUP
1. Open https://supabase.com/dashboard/project/upafuznajpobvigidicy
2. Go to SQL Editor > New query.
3. Run the complete SUPABASE_SETUP.sql file included in this project.
4. Build/install the app on the original phone and log in as the existing local Owner.
5. Open Settings & Backup > Supabase Cloud Sync.
6. Enter the Owner app password and press Create Supabase Owner Login.
7. Confirm the email if Supabase email confirmation is enabled.
8. In Supabase SQL Editor, run the membership INSERT statement in SUPABASE_SETUP_MALAYALAM.txt, replacing YOUR_OWNER_EMAIL with the Owner email.
9. Return to the app, enter the same password and press Connect & Enable Live Sync.
10. On other phones, install this APK and sign in with the same Supabase Owner email/password.

SECURITY
- The app includes only the Supabase project URL and publishable key.
- Never put a Supabase secret/service_role key in the Android app.
- Row Level Security is enabled. Only users explicitly added to jas_laundry_members can access the cloud snapshot.

SYNC DESIGN / LIMITATIONS
- Existing app data is preserved locally and uploaded as one JSON snapshot to public.jas_laundry_cloud.
- Realtime Postgres Changes subscription is enabled by the SQL setup.
- LocalStorage keeps changes on the device; a debounced sync and retry on internet restoration are included.
- This is whole-snapshot sync, not per-bill/per-record merge. Avoid editing different records simultaneously on multiple phones; the latest snapshot can replace earlier concurrent changes. Download a backup before first sync and keep periodic backups.
- First connection and auth require internet. Staff accounts remain device-local in this version; cross-device cloud login is for the Owner account.

BUILD
1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Note: the supplied ISO image did not contain a Gradle wrapper JAR, so open/build with Android Studio's installed Gradle tooling.
