Hotel HR Manager cumulative fixes

- Sign-in state is now stored in localStorage, so the app stays signed in after closing and reopening until the user presses Sign out. Sign out clears both persistent and temporary session flags. Existing active sessions are migrated to persistent sign-in on launch.
- Department View is available as a navigation tab and now also has a visible shortcut on the Dashboard Quick actions. It shows department totals and the requested F&B and Kitchen sections.
- Both web source and Android wrapper assets are updated.

Build the Android APK from the android-wrapper Gradle project. This ZIP is source and has not itself been compiled into an APK.
