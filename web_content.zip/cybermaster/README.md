# Cybermaster: Dream of Destiny — playable build

## Play
Open `index.html` in a browser. It is fully self-contained (sprites are embedded);
it only needs an internet connection to load Three.js and the fonts from their CDNs.

## Host online (to test on a phone)
Upload `index.html` to any static host (itch.io HTML game, Netlify, GitHub Pages, Cloudflare Pages).
On itch.io: zip `index.html` on its own, upload as an HTML game, tick "This file will be played in the browser".
Play in landscape.

## Folder
- `index.html` — the complete game in one file
- `src/` — the source split into parts, plus `build.py`
- `assets/sprites/` — the cut-out character sprite sheets (Lee, Sam, Ash, Matt, Voltix, mysterious man)

## Rebuild after editing
    python3 src/build.py
Parts are joined in this order: p1 core & test-area world · p2 characters & data · p3 dialogue, menus, saves, settings ·
p4 test-area stations & dev panel · p5 battle system · p7 story (Chunk 1 opening; all dialogue lines are in the SCRIPT block at the top) ·
p8 Sand Town Part 1 · p9 school · p6 input, title flow & main loop.

## Developer controls
On the title screen, tap the CYBERMASTER logo five times to toggle the DEV button (test area only).
