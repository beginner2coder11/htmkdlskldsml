
/* ================= HUD helpers ================= */
let noteT=null;
function note(text,kind){const n=$('note');n.textContent=text;n.className=kind?'show '+kind:'show';clearTimeout(noteT);noteT=setTimeout(()=>n.className=kind||'',1900);}
function updateMoney(){$('money').textContent=G.money+' G';}
let state={run:false};
function setRun(v){state.run=v;if(G)G.run=v;const b=$('run');b.classList.toggle('on',v);b.textContent=v?'Run':'Walk';b.setAttribute('aria-pressed',v);}
let mode='title',busy=false;

/* ================= Dialogue ================= */
const dlgEl=$('dlg'),logEl=$('log'),port=$('port'),choicesEl=$('choices');
const dlg={open:false,queue:[],hist:[],choosing:false,onEnd:null,noSkip:false};
const WHO={lee:()=>LEE,sam:()=>NPC.sam,ash:()=>NPC.ash,matt:()=>NPC.matt,keeper:()=>NPC.keeper,shop:()=>NPC.shop,carolin:()=>NPC.carolin};
const OBJ=n=>({name:n,col:'#e8e2c8'});
function resolveWho(w){return typeof w==='string'?(WHO[w]?WHO[w]():OBJ(w)):w;}
function paintPortrait(who){const pc=port.getContext('2d');pc.clearRect(0,0,128,160);
  if(who.sheet&&who.sheet.ready){port.style.visibility='visible';pc.drawImage(who.sheet.img,0,0,who.sheet.fw,186,0,0,128,160);}
  else if(who.cv&&!who.sheet){port.style.visibility='visible';blobArt(pc,who.col,0,0.5,false,who.angry);}
  else port.style.visibility='hidden';}
function startDialog(nodes,onEnd,opts={}){dlg.open=true;dlg.queue=nodes.slice();dlg.hist=[];dlg.onEnd=onEnd;dlg.choosing=false;dlg.noSkip=!!opts.noSkip;
  $('skipBtn').title=dlg.noSkip?'This scene cannot be skipped':'';
  dlgEl.classList.add('open');$('dim').classList.add('open');stopJoy();nextLine();}
function nextLine(){if(dlg.choosing)return;hush();const n=dlg.queue.shift();if(!n){endDialog(false);return;}
  if(n.fn){n.fn();nextLine();return;}
  if(n.choices)showChoices(n);else showLine(n);}
function showLine(n){const who=resolveWho(n.who);
  const w=dlgEl.querySelector('.who');w.textContent=who.name;w.style.color=who.tagCol||who.col;
  dlgEl.querySelector('.txt').textContent=n.text;choicesEl.innerHTML='';$('skipBtn').disabled=dlg.noSkip;dlgEl.querySelector('.more').style.visibility='visible';
  dlg.hist.push([who,n.text]);paintPortrait(who);speak(n.text);}
function showChoices(n){dlg.choosing=true;
  const w=dlgEl.querySelector('.who');w.textContent=n.prompt?resolveWho(n.who||'lee').name:'Lee';w.style.color=LEE.col;
  dlgEl.querySelector('.txt').textContent=n.prompt||'What do you say?';$('skipBtn').disabled=true;dlgEl.querySelector('.more').style.visibility='hidden';
  paintPortrait(LEE);choicesEl.innerHTML='';
  n.choices.forEach((c,i)=>{const b=document.createElement('button');b.textContent=(i+1)+'. '+c.text;b.onclick=e=>{e.stopPropagation();pick(c);};choicesEl.appendChild(b);});
  choicesEl.firstChild&&choicesEl.firstChild.focus({preventScroll:true});}
function pick(c){if(!dlg.choosing)return;dlg.choosing=false;choicesEl.innerHTML='';sfx('select');
  const pre=c.silent?[]:[{who:'lee',text:c.text}];dlg.queue=pre.concat(c.reply||[],dlg.queue);c.fn&&c.fn();nextLine();}
function endDialog(skipped){hush();dlg.open=false;dlg.choosing=false;dlgEl.classList.remove('open');logEl.classList.remove('open');$('dim').classList.remove('open');
  const cb=dlg.onEnd;dlg.onEnd=null;cb&&cb(skipped);}
function closeDialogSilently(){hush();dlg.open=false;dlg.onEnd=null;dlgEl.classList.remove('open');logEl.classList.remove('open');$('dim').classList.remove('open');}
dlgEl.addEventListener('pointerdown',e=>{e.stopPropagation();if(e.target.closest('button')||dlg.choosing)return;nextLine();});
$('skipBtn').onclick=e=>{e.stopPropagation();if(!dlg.choosing&&!dlg.noSkip){dlg.queue=dlg.queue.filter(n=>n.fn);dlg.queue.forEach(n=>n.fn());endDialog(true);}};
$('logBtn').onclick=e=>{e.stopPropagation();const L=$('logList');L.innerHTML='';
  dlg.hist.forEach(([who,line])=>{const p=document.createElement('p'),b=document.createElement('b');b.textContent=who.name;b.style.color=who.tagCol||who.col;p.append(b,document.createTextNode(line));L.appendChild(p);});
  logEl.classList.add('open');L.scrollTop=1e6;};
$('logClose').onclick=()=>logEl.classList.remove('open');
logEl.addEventListener('pointerdown',e=>e.stopPropagation());

/* ================= Generic menu ================= */
const menuEl=$('menu'),card=$('menuCard');let menuName='';
function openMenu(title,items,text,name){
  menuName=name||title;card.innerHTML='';const h=document.createElement('h2');h.textContent=title;card.appendChild(h);
  if(text){const p=document.createElement('p');p.textContent=text;card.appendChild(p);}
  const mk=it=>{const b=document.createElement('button');const s=document.createElement('span');s.textContent=it.label;b.appendChild(s);
    if(it.sub!=null){const sm=document.createElement('small');sm.textContent=it.sub;b.appendChild(sm);}
    if(it.cls)b.className=it.cls;b.disabled=!!it.disabled;b.onclick=()=>{sfx('select');it.on&&it.on();};return b;};
  items.forEach(it=>{
    if(it.row){const r=document.createElement('div');r.className='row';it.row.forEach(x=>r.appendChild(mk(x)));card.appendChild(r);}
    else if(it.range){const R=it.range,l=document.createElement('label');l.className='range';const top=document.createElement('span');const a=document.createElement('b');a.textContent=R.label;const v=document.createElement('small');v.textContent=R.fmt?R.fmt(R.value):R.value;top.append(a,v);
      const inp=document.createElement('input');inp.type='range';inp.min=R.min;inp.max=R.max;inp.step=R.step||1;inp.value=R.value;inp.setAttribute('aria-label',R.label);
      inp.oninput=()=>{v.textContent=R.fmt?R.fmt(+inp.value):inp.value;R.on(+inp.value);};inp.onchange=()=>R.done&&R.done();l.append(top,inp);card.appendChild(l);}
    else if(it.stat){const d=document.createElement('div');d.className='stat';const a=document.createElement('span');a.textContent=it.stat;d.appendChild(a);
      if(it.bar!=null){const bar=document.createElement('div');bar.className='bar';const i=document.createElement('i');i.style.width=clamp(it.bar,0,1)*100+'%';if(it.barCol)i.style.background=it.barCol;bar.appendChild(i);d.appendChild(bar);}
      const b=document.createElement('small');b.textContent=it.val;d.appendChild(b);card.appendChild(d);}
    else if(it.text){const p=document.createElement('p');p.textContent=it.text;card.appendChild(p);}
    else card.appendChild(mk(it));});
  menuEl.classList.add('open');const f=card.querySelector('button:not(:disabled),input');f&&f.focus({preventScroll:true});
}
function closeMenu(){menuEl.classList.remove('open');menuName='';}
menuEl.addEventListener('pointerdown',e=>e.stopPropagation());

/* ================= Field menus ================= */
function pauseMenu(){mode='menu';stopJoy();if(window.__tutPause)window.__tutPause();
  openMenu('Paused',[{label:'Resume',on:resume},{label:'Party',sub:'Status · equipment · mastery',on:()=>partyMenu(pauseMenu)},{label:'Items',on:()=>itemsMenu(pauseMenu)},
    {label:'Save',on:()=>slotMenu('save',pauseMenu)},{label:'Settings',on:()=>settingsMenu(pauseMenu)},
    {label:'Main menu',on:()=>dirty?openMenu('Leave without saving?',[{row:[{label:'Leave',cls:'danger',on:()=>{closeMenu();burst(showTitle);}},{label:'Cancel',on:pauseMenu}]}],'You have unsaved progress. It will be lost.'):(closeMenu(),burst(showTitle))}],
    'Loading is only available from the main menu.','pause');}
function resume(){closeMenu();mode='play';if(window.__tutResume)window.__tutResume();}
function partyMenu(back){openMenu('Party',G.members.map(id=>{const m=G.party[id];return {label:m.name+'  Lv '+m.lvl,sub:m.ko?'Knocked out':('HP '+m.hp+'/'+stat(m,'mhp')+' · MP '+m.mp+'/'+stat(m,'mmp')),on:()=>memberMenu(id,back)};}).concat([{label:'Back',on:back}]));}
function memberMenu(id,back){const m=G.party[id];const ab=[...KIT[id].magic,...KIT[id].special];
  const gearRow=slot=>{const cur=ITEMS[m.gear[slot]];const opts=Object.keys(G.inv).filter(k=>ITEMS[k].type===slot&&ITEMS[k].owner===id);
    return {label:(slot==='weapon'?'Weapon: ':'Armour: ')+(cur?cur.name:'None'),sub:opts.length?'Tap to swap ('+opts.length+')':'No other '+slot+' for '+m.name,disabled:!opts.length,
      on:()=>{const nx=opts[0];addItem(nx,-1);if(m.gear[slot])addItem(m.gear[slot],1);m.gear[slot]=nx;fixCaps(m);touch();memberMenu(id,back);}};};
  const items=[{stat:'Level '+m.lvl,bar:m.xp/xpNeed(m.lvl),val:m.xp+'/'+xpNeed(m.lvl)+' XP'},
    {stat:'HP',bar:m.hp/stat(m,'mhp'),barCol:'#7dff9e',val:m.hp+'/'+stat(m,'mhp')},{stat:'MP',bar:m.mp/stat(m,'mmp'),barCol:'#7cb8ff',val:m.mp+'/'+stat(m,'mmp')},
    {text:['atk','mag','def','spd'].map(k=>STATN[k]+' '+stat(m,k)).join(' · ')+' · Destiny Points '+m.dp},
    gearRow('weapon'),gearRow('armour'),{text:'Ability mastery (fixed ability set):'}];
  ab.forEach(a=>{const v=m.mastery[a]||0;items.push({stat:ABIL[a].name,bar:v/100,barCol:v>=100?'#f2c14e':null,val:v>=100?'MAX':v+'%'});});
  items.push({label:'Back',on:()=>partyMenu(back)});
  openMenu(m.name,items,'Gear belongs to '+m.name+' only.');}
function fixCaps(m){m.hp=Math.min(m.hp,stat(m,'mhp'));m.mp=Math.min(m.mp,stat(m,'mmp'));}
function itemsMenu(back){const list=Object.keys(G.inv).sort((a,b)=>ITEMS[a].type.localeCompare(ITEMS[b].type));
  openMenu('Items',list.map(k=>({label:ITEMS[k].name+' ×'+G.inv[k],sub:ITEMS[k].type==='use'?ITEMS[k].desc:ITEMS[k].type,disabled:ITEMS[k].type!=='use',on:()=>useItemMenu(k,back)})).concat([{label:'Back',on:back}]),list.length?'Stacks cap at 99.':'Your bag is empty.');}
function useItemMenu(k,back){const it=ITEMS[k];
  openMenu('Use '+it.name,G.members.map(id=>{const m=G.party[id];const ok=itemValid(it,m);
    return {label:m.name,sub:m.ko?'Knocked out':'HP '+m.hp+'/'+stat(m,'mhp')+' · MP '+m.mp,disabled:!ok,on:()=>{applyItem(it,m);addItem(k,-1);touch();sfx('heal');note(it.name+' used on '+m.name);G.inv[k]?useItemMenu(k,back):itemsMenu(back);}};})
    .concat([{label:'Back',on:()=>itemsMenu(back)}]),it.desc);}
function itemValid(it,m){if(it.revive)return m.ko;if(m.ko)return false;if(it.heal)return m.hp<stat(m,'mhp');if(it.mp)return m.mp<stat(m,'mmp');if(it.cure)return !!(m.status&&Object.keys(m.status).length);return false;}
function applyItem(it,m){if(it.revive){m.ko=false;m.hp=Math.round(stat(m,'mhp')*it.revive);}if(it.heal)m.hp=Math.min(stat(m,'mhp'),m.hp+it.heal);if(it.mp)m.mp=Math.min(stat(m,'mmp'),m.mp+it.mp);if(it.cure)m.status={};}
function healAll(){G.members.forEach(id=>{const m=G.party[id];m.ko=false;m.hp=stat(m,'mhp');m.mp=stat(m,'mmp');m.status={};});}

/* ================= Save / load ================= */
function fmtSlot(d){try{return new Date(d.time).toLocaleString([], {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})+' · Lv '+d.party.lee.lvl+' · '+d.money+' G';}catch(e){return 'Saved';}}
function slotMenu(kind,back){
  const items=[1,2,3].map(i=>{const d=store.get(SLOT_KEY(i));
    return {label:'Slot '+i,sub:d?fmtSlot(d):'Empty',disabled:!store.ok||(kind==='load'&&!d),
      on:()=>kind==='save'?(d?openMenu('Overwrite slot '+i+'?',[{row:[{label:'Overwrite',cls:'danger',on:()=>doSave(i,back)},{label:'Cancel',on:()=>slotMenu(kind,back)}]}],'The save in slot '+i+' will be replaced.'):doSave(i,back)):doLoad(i)};});
  items.push({label:'Back',on:back});
  openMenu(kind==='save'?'Save game':'Load game',items,store.ok?(kind==='save'?'No autosave — save manually.':null):'Saving is unavailable in this browser.');}
function snapshot(){G.pos=[LEE.pos.x,LEE.pos.y];G.look=[LEE.lookT.x,LEE.lookT.y];G.yaw=yaw;G.run=state.run;return Object.assign(JSON.parse(JSON.stringify(G)),{time:Date.now()});}
function doSave(i,back){if(store.set(SLOT_KEY(i),snapshot())){dirty=false;sfx('buy');note('Saved to slot '+i);back();}
  else openMenu('Save failed',[{label:'Back',on:back}],'This browser blocked storage, so the game could not be saved.');}
function doLoad(i){const d=store.get(SLOT_KEY(i));if(!d)return;closeMenu();startGame(d);}
function lastSaveSlot(){let best=0,t=0;[1,2,3].forEach(i=>{const d=store.get(SLOT_KEY(i));if(d&&d.time>t){t=d.time;best=i;}});return best;}

/* ================= Settings ================= */
const QUAL={auto:'Auto',high:'High',low:'Low'},CAM={near:'Near',normal:'Normal',far:'Far'},CAMD={near:5.2,normal:6.8,far:8.6},TS={1:'Normal',1.2:'Large',1.4:'Extra large'};
function settingsMenu(back){
  const cyc=(o,k)=>{const ks=Object.keys(o);return ks[(ks.indexOf(String(k))+1)%ks.length];};
  const save=()=>store.set(SETTINGS_KEY,settings);
  const set=(k,v)=>{settings[k]=v;save();applySettings();settingsMenu(back);};
  const vol=(k,label,extra)=>({range:{label:label+(extra||''),value:settings[k],min:0,max:100,step:5,fmt:v=>v+'%',on:v=>{settings[k]=v;},done:()=>{save();k==='voiceVol'?speak('Voice volume test.'):sfx('select');}}});
  openMenu('Settings',[
    {label:'Text size',sub:TS[settings.textSize],on:()=>set('textSize',+cyc(TS,settings.textSize))},
    {label:'Dyslexia-friendly font',sub:settings.dys?'On (Lexend)':'Off',on:()=>set('dys',!settings.dys)},
    {label:'Voice-over (AI, dialogue only)',sub:'speechSynthesis' in window?(settings.voice?'On':'Off'):'Not supported here',disabled:!('speechSynthesis' in window),on:()=>set('voice',!settings.voice)},
    vol('master','Master volume'),vol('music','Music volume',' (no music yet)'),vol('sfx','Sound effects'),vol('voiceVol','Voice volume'),
    {range:{label:'Brightness',value:settings.bright,min:70,max:130,step:5,fmt:v=>v+'%',on:v=>{settings.bright=v;applyBrightness();},done:save}},
    {label:'Graphics',sub:settings.quality==='auto'?'Auto (detected '+QUAL[DETECTED]+')':QUAL[settings.quality],on:()=>set('quality',cyc(QUAL,settings.quality))},
    {label:'Camera distance',sub:CAM[settings.camera],on:()=>set('camera',cyc(CAM,settings.camera))},
    {label:'Control hints',sub:settings.hints?'On':'Off',on:()=>set('hints',!settings.hints)},
    {label:'Back',on:back}],'Settings are shared by all save slots and saved automatically.');}
function applyBrightness(){cv.style.filter=settings.bright===100?'':'brightness('+settings.bright/100+')';}
function applyText(){document.documentElement.style.setProperty('--ts',settings.textSize);document.body.classList.toggle('dys',!!settings.dys);}
