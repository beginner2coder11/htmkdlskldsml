
/* ================= Billboard characters ================= */
function sheet(src,fw,frames,opt){const S=Object.assign({fw,fh:386,frames,img:new Image(),ready:false},opt||{});S.img.onload=()=>{S.ready=true;};S.img.src=src;return S;}
const LEE_SHEET=sheet('__LEE_SHEET__',149,{front:0,tq:1,side:2,back:3,btq:4});
const SAM_SHEET=sheet('__SAM_SHEET__',151,{front:0,tq:1,side:2,back:3,sideL:4});
const MATT_SHEET=sheet('__MATT_SHEET__',153,{front:0,tq:1,side:2,back:3,sideL:4});
const MAN_SHEET=sheet('__MAN_SHEET__',151,{tq:0,side:1,back:2},{faceLeft:true});   // mysterious man: art faces left, no straight-on front
const VOLTIX_SHEET=sheet('__VOLTIX_SHEET__',187,{front:0,side:1,back:2});   // front / side / back only
const ASH_SHEET=sheet('__ASH_SHEET__',141,{front:0,tq:1,btq:2,back:3,btqL:4});   // no side profile: tq/btq cover 90°
const tagsEl=$('tags');
function makeChar(c){
  c.zone=c.zone||'test';c.hidden=!!c.hidden;
  c.cv=document.createElement('canvas');c.cv.width=c.sheet?c.sheet.fw:128;c.cv.height=c.sheet?c.sheet.fh:160;c.ctx=c.cv.getContext('2d');
  c.scale=c.scale||1;c.bh=(c.sheet?1.92:1.56)*c.scale;c.bw=c.sheet?c.sheet.fw/c.sheet.fh*c.bh:1.25*c.scale;
  c.tex=new THREE.CanvasTexture(c.cv);
  c.spr=new THREE.Sprite(new THREE.SpriteMaterial({map:c.tex,transparent:true,opacity:c.alpha||1}));c.spr.scale.set(c.bw,c.bh,1);scene.add(c.spr);
  c.sh=new THREE.Mesh(new THREE.CircleGeometry(0.46*c.scale,20),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.28,depthWrite:false}));c.sh.rotation.x=-Math.PI/2;scene.add(c.sh);
  c.pos=new THREE.Vector2(c.x,c.z);c.home=c.pos.clone();c.look=new THREE.Vector2(0,1);c.lookT=new THREE.Vector2(0,1);
  c.blinkAt=1+Math.random()*3;c.blink=0;c.walk=0;c.key='';c.visible=true;
  if(c.tagged!==false){c.tag=document.createElement('div');c.tag.className='tag';c.tag.textContent=c.name;c.tag.style.color=c.tagCol||c.col;tagsEl.appendChild(c.tag);}
  return c;
}
function refreshChar(c){const v=c.zone===Z.name&&!c.hidden;c.visible=v;c.spr.visible=v;c.sh.visible=v;if(c.tag&&!v)c.tag.style.display='none';}
function setVisible(c,v){c.hidden=!v;refreshChar(c);}
let yaw=0,pitch=0.34;
const camF=()=>[-Math.sin(yaw),-Math.cos(yaw)],camR=()=>[Math.cos(yaw),-Math.sin(yaw)];
function screenLook(v){const f=camF(),r=camR();return [v.x*r[0]+v.y*r[1],-(v.x*f[0]+v.y*f[1])];}
function drawSheet(c){
  const S=c.sheet;if(!S.ready)return;
  const sl=screenLook(c.look),a=Math.atan2(Math.abs(sl[0]),sl[1])*180/Math.PI;
  // pick the nearest view the sheet actually has (front 0°, three-quarter 45°, side 90°, back three-quarter 135°, back 180°)
  const F=S.frames,left=sl[0]<-0.05;
  let best=null;[['front',0],['tq',45],['side',90],['btq',135],['back',180]].forEach(o=>{if(F[o[0]]==null)return;
    if(!best||Math.abs(a-o[1])<Math.abs(a-best[1])||(Math.abs(a-o[1])===Math.abs(a-best[1])&&o[1]>best[1]))best=o;});
  const k=best[0];let f=F[k],flip=false;
  if(left&&(k==='tq'||k==='side'||k==='btq')){if(k==='side'&&F.sideL!=null)f=F.sideL;else if(k==='btq'&&F.btqL!=null&&a>=112.5)f=F.btqL;else flip=true;}
  if(S.faceLeft&&(k==='tq'||k==='side'||k==='btq'))flip=!flip;
  const key=f+'|'+flip;if(key===c.key)return;c.key=key;
  const g=c.ctx;g.clearRect(0,0,S.fw,S.fh);g.save();if(flip){g.translate(S.fw,0);g.scale(-1,1);}
  g.drawImage(S.img,f*S.fw,0,S.fw,S.fh,0,0,S.fw,S.fh);g.restore();c.tex.needsUpdate=true;
}
function blobArt(g,col,lx,ly,blink,angry){
  g.clearRect(0,0,128,160);
  g.beginPath();g.moveTo(14,140);g.lineTo(14,62);g.arc(64,62,50,Math.PI,0);g.lineTo(114,140);
  g.quadraticCurveTo(114,150,104,150);g.lineTo(24,150);g.quadraticCurveTo(14,150,14,140);g.closePath();
  g.fillStyle=col;g.fill();g.lineWidth=6;g.strokeStyle='#15171c';g.stroke();
  g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(42,36,14,8,-0.5,0,Math.PI*2);g.fill();
  const ox=lx*5,oy=ly*5;
  [[46,72,1],[82,72,-1]].forEach(([ex,ey,s])=>{ex+=ox*0.6;ey+=oy*0.4;
    if(blink){g.beginPath();g.moveTo(ex-12,ey);g.lineTo(ex+12,ey);g.lineWidth=5;g.strokeStyle='#15171c';g.stroke();}
    else{g.beginPath();g.ellipse(ex,ey,13,17,0,0,Math.PI*2);g.fillStyle='#fff';g.fill();g.lineWidth=4;g.strokeStyle='#15171c';g.stroke();
      g.beginPath();g.arc(ex+ox,ey+oy,7,0,Math.PI*2);g.fillStyle='#15171c';g.fill();g.beginPath();g.arc(ex+ox-2.5,ey+oy-3,2.2,0,Math.PI*2);g.fillStyle='#fff';g.fill();}
    if(angry){g.beginPath();g.moveTo(ex-16,ey-24-s*6);g.lineTo(ex+16,ey-24+s*6);g.lineWidth=7;g.strokeStyle='#15171c';g.stroke();}});
}
function drawBlob(c){const sl=screenLook(c.look),lx=Math.round(sl[0]*4)/4,ly=Math.round(sl[1]*4)/4,bl=c.blink>0;
  const key=lx+'|'+ly+'|'+bl;if(key===c.key)return;c.key=key;blobArt(c.ctx,c.col,lx,ly,bl,c.angry);c.tex.needsUpdate=true;}
const draw=c=>c.sheet?drawSheet(c):drawBlob(c);

const LEE=makeChar({id:'lee',name:'Lee',col:'#f4f4f0',x:0,z:27.5,sheet:LEE_SHEET});
const NPC={
  sam:makeChar({id:'sam',name:'Sam',col:'#44474f',tagCol:'#c7cbd4',x:SOC.x-2.5,z:SOC.z-1.5,sheet:SAM_SHEET}),
  ash:makeChar({id:'ash',name:'Ash',col:'#8a4fd6',tagCol:'#c9a2ff',x:SOC.x+1,z:SOC.z-1.8,sheet:ASH_SHEET}),
  matt:makeChar({id:'matt',name:'Matt',col:'#3fae5a',tagCol:'#ffd27a',x:SOC.x+3.2,z:SOC.z+0.5,sheet:MATT_SHEET}),
  keeper:makeChar({id:'keeper',name:'Groundskeeper',col:'#b98b5e',x:IC.x+0.5,z:IC.z+0.4}),
  shop:makeChar({id:'shop',name:'Shopkeeper',col:'#e0843f',x:SH.x-3,z:SH.z-2.3}),
  carolin:makeChar({id:'carolin',name:'Carolin',col:'#f3dc8a',x:LB.x-2,z:LB.z-1.2})
};
Object.values(NPC).forEach(n=>n.lookT.set(0,1));

/* ================= Game data (test values — not final balance) ================= */
const MEMBERS=['lee','sam','ash','matt'];
const NAMES={lee:'Lee',sam:'Sam',ash:'Ash',matt:'Matt'};
const BASE={lee:{mhp:120,mmp:20,atk:14,mag:6,def:9,spd:10},sam:{mhp:90,mmp:40,atk:8,mag:14,def:6,spd:9},
  ash:{mhp:100,mmp:18,atk:13,mag:5,def:6,spd:14},matt:{mhp:95,mmp:30,atk:10,mag:10,def:7,spd:11}};
const DPINC={mhp:10,mmp:5,atk:1,mag:1,def:1,spd:1},STATN={mhp:'Max HP',mmp:'Max MP',atk:'Attack',mag:'Magic',def:'Defence',spd:'Speed'};
const ABIL={
  slash:{name:'Saber Beam',kind:'special',mp:6,target:'enemy',power:2.3,stat:'atk'},
  spark:{name:'Spark',kind:'magic',mp:4,target:'enemy',power:2.4,stat:'mag',elem:'spark'},
  fire:{name:'Fire',kind:'magic',mp:4,target:'enemy',power:2.6,stat:'mag',elem:'fire'},
  cure:{name:'Cure',kind:'magic',mp:5,target:'ally',heal:3,stat:'mag'},
  sweep:{name:'Staff Sweep',kind:'special',mp:6,target:'all',power:1.25,stat:'atk'},
  twin:{name:'Twin Blades',kind:'special',mp:5,target:'enemy',hits:2,power:1.15,stat:'atk'},
  round:{name:'Healing Round',kind:'special',mp:6,target:'ally',heal:3.2,stat:'mag'}
};
const KIT={lee:{magic:['spark'],special:['slash']},sam:{magic:['fire','cure'],special:['sweep']},ash:{magic:['spark'],special:['twin']},matt:{magic:['cure'],special:['round']}};
const ITEMS={
  potion:{name:'Potion',type:'use',price:20,heal:60,desc:'Restores 60 HP'},
  ether:{name:'Ether',type:'use',price:40,mp:25,desc:'Restores 25 MP'},
  tonic:{name:'Revival Tonic',type:'use',price:80,revive:0.5,desc:'Revives a knocked-out ally at 50% HP'},
  antidote:{name:'Antidote',type:'use',price:15,cure:true,desc:'Clears status effects'},
  blobcore:{name:'Blob Core',type:'key',price:0,desc:'Guaranteed boss item (test)'}
};
[['lee','Training Sword','Steel Sword','atk'],['sam','Oak Staff','Crystal Staff','mag'],['ash','Twin Knives','Twin Sabres','atk'],['matt','Pellet Pistol','Charm Revolver','atk']].forEach(([o,w1,w2,k])=>{
  ITEMS[o+'_w1']={name:w1,type:'weapon',owner:o,price:60,bonus:{[k]:2}};
  ITEMS[o+'_w2']={name:w2,type:'weapon',owner:o,price:200,bonus:{[k]:6}};
  ITEMS[o+'_a1']={name:'Light Guard ('+NAMES[o]+')',type:'armour',owner:o,price:50,bonus:{def:2}};
  ITEMS[o+'_a2']={name:'Padded Guard ('+NAMES[o]+')',type:'armour',owner:o,price:150,bonus:{def:5}};
  ITEMS.cybersaber={name:'Cyber Saber',type:'weapon',owner:'lee',price:0,bonus:{atk:4},key:true};
  ITEMS[o+'_friend']={name:NAMES[o]+"'s Friendship Token",type:'friend',price:0,desc:'Level 10 friendship reward (test). Kept in New Game+.'};
});
const SHOP_STOCK=['potion','ether','tonic','antidote','lee_w2','sam_w2','ash_w2','matt_w2','lee_a2','sam_a2','ash_a2','matt_a2'];
const ENEMIES={
  slime:{name:'Goo Slime',hp:48,atk:9,mag:4,def:3,spd:8,xp:14,money:[8,16],drops:[['potion',.35],['antidote',.2]],col:'#e0843f',weak:['fire'],inflict:['poison',.25]},
  bat:{name:'Static Bat',hp:34,atk:8,mag:6,def:2,spd:15,xp:12,money:[6,14],drops:[['ether',.25]],col:'#6f5fd6',weak:['fire'],resist:['spark'],inflict:['para',.2]},
  moth:{name:'Dream Moth',hp:40,atk:7,mag:8,def:2,spd:11,xp:13,money:[7,15],drops:[['potion',.3]],col:'#d6b85f',weak:['spark'],inflict:['sleep',.3]},
  voltix:{name:'Voltix',hp:9999,atk:11,mag:0,def:60,spd:10,xp:0,money:[0,0],drops:[],col:'#8b1a1a',boss:true,unbeatable:true,sheet:VOLTIX_SHEET},
  golem:{name:'Test Golem',hp:9999,atk:999,mag:0,def:99,spd:13,xp:0,money:[0,0],drops:[],col:'#555a66',note:'Party-defeat test'},
  blob:{name:'Blob',hp:640,atk:15,mag:10,def:4,spd:9,xp:180,money:[150,150],drops:[],guaranteed:'blobcore',col:'#58d68d',boss:true,weakMagic:true,alpha:.85}
};
const WORLD_ENEMIES=[
  {id:'e1',type:'slime',x:-4,z:-21,group:['slime']},
  {id:'e2',type:'bat',x:4,z:-20,group:['bat']},
  {id:'e3',type:'moth',x:3.5,z:-26,group:['moth']},
  {id:'pack',type:'slime',x:-5,z:-27,group:['slime','bat','moth'],scale:1.25,label:'Pack ×3'},
  {id:'golem',type:'golem',x:7,z:-30.5,group:['golem'],scale:1.5,fixed:true},
  {id:'boss',type:'blob',x:0,z:-31,group:['blob'],scale:2.6,fixed:true,boss:true,intro:[{who:'Blob',text:'The gelatinous mass rises and blocks the way.'},{who:'Blob',text:'(Unskippable boss intro — placeholder. Unique boss music would start here; no audio yet.)'}]}
];
WORLD_ENEMIES.forEach(w=>{const d=ENEMIES[w.type];w.c=makeChar({enemy:true,id:w.id,name:w.label||d.name,col:d.col,x:w.x,z:w.z,scale:w.scale||0.8,angry:true,alpha:d.alpha,tagCol:'#ff8c8c'});
  w.alive=true;w.wait=Math.random()*2;w.tgt=new THREE.Vector2(w.x,w.z);});
const ALLC=[LEE,...Object.values(NPC),...WORLD_ENEMIES.map(w=>w.c)];

/* ================= Game state ================= */
function newMember(id){return {id,name:NAMES[id],lvl:1,xp:0,base:Object.assign({},BASE[id]),dp:0,spent:{mhp:0,mmp:0,atk:0,mag:0,def:0,spd:0},
  gear:{weapon:id+'_w1',armour:id+'_a1'},mastery:{},hp:BASE[id].mhp,mp:BASE[id].mmp,ko:false};}
let G=null;
function freshState(){return {v:2,pos:[0,27.5],look:[0,-1],yaw:0,run:false,money:120,inv:{potion:5,ether:2,tonic:2,antidote:2},
  party:Object.fromEntries(MEMBERS.map(id=>[id,newMember(id)])),members:['lee','sam','ash'],rel:{sam:0,ash:0,matt:0},
  flags:{chest:false,bossDown:false,scene10:{}},stats:{battles:0,wins:0,escapes:0}};}
function stat(m,k){let v=m.base[k]+DPINC[k]*(m.spent[k]||0);['weapon','armour'].forEach(s=>{const it=ITEMS[m.gear[s]];if(it&&it.bonus&&it.bonus[k])v+=it.bonus[k];});return v;}
const xpNeed=l=>30*l*l+20;
function addItem(id,n=1){const cur=G.inv[id]||0;const next=clamp(cur+n,0,99);G.inv[id]=next;if(!next)delete G.inv[id];return next-cur;}
let dirty=false;const touch=()=>{dirty=true;};
