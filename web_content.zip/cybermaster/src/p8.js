
/* =====================================================================
   SAND TOWN — Part 1 (built from Lee's map; 1 world unit = 12 map pixels)
   ===================================================================== */
const PX=(px,py)=>[(px-760)/12,(py-470)/12];
const P=pts=>pts.map(([x,y])=>PX(x,y));
function pip(x,z,poly){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const [xi,zi]=poly[i],[xj,zj]=poly[j];
  if(((zi>z)!==(zj>z))&&(x<(xj-xi)*(z-zi)/(zj-zi)+xi))c=!c;}return c;}
function walkOK(x,z){if(!Z.walk)return true;const r=0.35;return [[0,0],[r,0],[-r,0],[0,r],[0,-r]].every(([dx,dz])=>Z.walk.some(p=>pip(x+dx,z+dz,p)));}
function solidAt(x,y,z){return (Z.solids||[]).some(s=>y<s.h+0.3&&pip(x,z,s.poly));}
function extrude(poly,h,col,y0=0){const sh=new THREE.Shape();poly.forEach(([x,z],i)=>i?sh.lineTo(x,-z):sh.moveTo(x,-z));
  const geo=new THREE.ExtrudeGeometry(sh,{depth:h,bevelEnabled:false});const m=new THREE.Mesh(geo,mat(col));m.rotation.x=-Math.PI/2;m.position.y=y0;
  m.castShadow=true;m.receiveShadow=true;BZ.group.add(m);return m;}
function flatPoly(poly,col,y=0.03){const sh=new THREE.Shape();poly.forEach(([x,z],i)=>i?sh.lineTo(x,-z):sh.moveTo(x,-z));
  const m=new THREE.Mesh(new THREE.ShapeGeometry(sh),mat(col));m.rotation.x=-Math.PI/2;m.position.y=y;m.receiveShadow=true;BZ.group.add(m);return m;}
function building(poly,h,wall,roof){extrude(poly,h,wall);extrude(poly,0.35,roof,h);BZ.solids.push({poly,h:h+0.35});}
// a flat panel (door / window / sign) standing on the edge a→b at fraction t, pushed slightly outward
function onEdge(a,b,t,w,h,y,col,out=0.08,tex){const x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t,ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
  const nx=Math.sin(ang),nz=-Math.cos(ang);
  const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,0.12),tex?new THREE.MeshLambertMaterial({map:tex}):(col&&col.isMaterial?col:mat(col)));
  m.position.set(x+nx*out,y,z+nz*out);m.rotation.y=-ang;BZ.group.add(m);return {x:x+nx*out,z:z+nz*out,nx,nz};}

const TOWN=buildZone('sandtown',{sky:0xcfe3f2,fog:[45,120],bounds:[-58,54,-36,45]},z=>{
  z.solids=[];BZ.solids=z.solids;
  groundPlane(0xa9b07a,260);
  // walkable streets and square (from the map)
  z.walk=[P([[628,422],[722,376],[722,333],[805,333],[805,373],[1043,348],[1325,212],[1347,265],[1067,398],[887,417],[887,597],[1012,652],[1132,652],[1132,578],[1205,578],[1205,708],[1380,790],[1372,850],[1145,730],[957,733],[957,883],[698,727],[672,727],[672,703],[647,703],[627,568],[290,840],[248,802],[575,540],[575,465],[318,310],[353,258]])];
  flatPoly(z.walk[0],0xd8cfb8);
  flatPoly(P([[730,57],[792,57],[792,204],[730,204]]),0xd8cfb8);             // road north, behind the hidden entrance
  const plaza=new THREE.Mesh(new THREE.CircleGeometry(4.2,8),mat(0xc2b79c));plaza.rotation.x=-Math.PI/2;plaza.position.set(...[PX(760,480)].map(p=>[p[0],0.05,p[1]])[0]);BZ.group.add(plaza);
  // kerbs along the street edges
  const W=z.walk[0];for(let i=0;i<W.length;i++){const a=W[i],b=W[(i+1)%W.length],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(len<0.8)continue;
    const k=new THREE.Mesh(new THREE.BoxGeometry(len,0.18,0.3),mat(0xa8a08a));k.position.set((a[0]+b[0])/2,0.09,(a[1]+b[1])/2);k.rotation.y=-Math.atan2(b[1]-a[1],b[0]-a[0]);BZ.group.add(k);}
  // --- School ---
  const SCH=P([[110,208],[188,113],[367,235],[298,333]]);
  building(SCH,7,0xc97b5d,0x6e4234);
  z.schoolDoor=onEdge(SCH[2],SCH[3],0.45,2.4,3,1.5,0x4f3526,0.1);
  [0.15,0.3,0.62,0.8].forEach(t=>{onEdge(SCH[2],SCH[3],t,1.3,1.1,2.4,0xa8d8f0,0.1);onEdge(SCH[2],SCH[3],t,1.3,1.1,5,0xa8d8f0,0.1);});
  onEdge(SCH[2],SCH[3],0.45,1.3,1.1,5,0xa8d8f0,0.1);
  // --- Low-poly buildings block (a cluster of different heights) ---
  const LPB=P([[82,577],[358,338],[467,402],[467,487],[203,715]]);
  building(LPB,4.5,0xb9a58c,0x5d4b3c);
  [[[250,520],3.4,0xcdb89c],[[380,430],2,0xa99479],[[170,615],2.6,0xd6c3a5]].forEach(([p,h,c])=>{const [x,zz]=PX(...p);box(5.5,h,5.5,x,4.85+h/2,zz,c,false);});
  [0.2,0.4,0.6,0.8].forEach(t=>{onEdge(LPB[1],LPB[2],t*1.0,1,1,2.6,0xa8d8f0,0.1);});
  [0.15,0.35,0.55,0.75].forEach(t=>onEdge(LPB[4],LPB[0],t,1,1,2.6,0xa8d8f0,0.1));
  // --- Hidden entrance (to the Library and Book World) ---
  const HID=P([[632,204],[895,204],[895,330],[632,330]]);
  building(HID,5.5,0x7d7f8a,0x4a4c56);
  z.hidDoor=onEdge(HID[2],HID[3],0.5,2.2,2.8,1.4,new THREE.MeshLambertMaterial({color:0x2a2233,emissive:0x2a1f55}),0.1);
  onEdge(HID[2],HID[3],0.5,2.8,0.35,2.95,0xc9a24a,0.14);
  // --- Item shop ---
  const SHP=P([[998,426],[1335,426],[1335,575],[998,575]]);
  building(SHP,4.5,0x6a86b8,0x2d3a5a);
  z.shopDoor=onEdge(SHP[2],SHP[3],(1335-1168)/337,2,2.6,1.3,0x2a3350,0.1);
  const aw=onEdge(SHP[2],SHP[3],(1335-1168)/337,4,0.25,3.1,0xd23a3a,0.7);
  const shopSign=canvasTex(256,64,(g,w,h)=>{g.fillStyle='#f4f1e8';g.fillRect(0,0,w,h);g.fillStyle='#2d3a5a';g.font='bold 38px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('ITEM SHOP',w/2,h/2+2);});
  onEdge(SHP[2],SHP[3],(1335-1168)/337,4,1,3.9,null,0.1,shopSign);
  [0.12,0.3,0.7,0.88].forEach(t=>onEdge(SHP[2],SHP[3],t,1.6,1.2,2,0xa8d8f0,0.1));
  // --- Town house (Lee's home) ---
  const TH=P([[290,840],[627,568],[647,703],[622,705],[622,727],[290,990]]);
  building(TH,5.5,0xd9b98a,0x7a4a3a);
  z.homeDoor=onEdge(TH[1],TH[2],0.82,1.6,2.5,1.25,0x3b5a8a,0.1);
  [0.2,0.45,0.7].forEach(t=>{onEdge(TH[0],TH[1],t,1.2,1.1,2.2,0xa8d8f0,0.1);onEdge(TH[0],TH[1],t,1.2,1.1,4.3,0xa8d8f0,0.1);});
  // --- backdrop: seeded low-poly houses and trees outside the streets ---
  let s=1999;const rr=()=>(s=(s*16807)%2147483647)/2147483647;
  const clear=(x,zz,m)=>!z.walk.some(p=>[[0,0],[m,0],[-m,0],[0,m],[0,-m],[m,m],[-m,-m],[m,-m],[-m,m]].some(([dx,dz])=>pip(x+dx,zz+dz,p)))&&!z.solids.some(q=>[[0,0],[m,0],[-m,0],[0,m],[0,-m]].some(([dx,dz])=>pip(x+dx,zz+dz,q.poly)));
  let placed=0,tries=0;
  while(placed<46&&tries<1500){tries++;const x=-70+rr()*140,zz=-48+rr()*110;if(!clear(x,zz,4.6))continue;
    if(rr()<0.62){const w=3.5+rr()*3,d=3.5+rr()*3,h=2.5+rr()*3.5,c=[0xd9b98a,0xc9a27a,0xe0cfb0,0xb88f6a][Math.floor(rr()*4)];
      box(w,h,d,x,h/2,zz,c,false);const rf=add(new THREE.ConeGeometry(Math.max(w,d)*0.75,1.6,4),[0x7a4a3a,0x5d4b3c,0x6e4234][Math.floor(rr()*3)],x,h+0.8,zz);rf.rotation.y=Math.PI/4;}
    else tree(x,zz,0.9+rr()*0.4);placed++;}
  // name signs above the key buildings
  label('School',...(()=>{const [x,zz]=PX(250,230);return [x,zz];})(),9.5,'#f2c14e');
  label('Item Shop',...PX(1166,500),7.2,'#7cf5ff');
  z.marks=[[...PX(333,284),'#f2c14e'],[...PX(763,333),'#8a5cff'],[...PX(1168,578),'#7cf5ff'],[...PX(644,686),'#ff6fa8']];
  z.exits=[{p:PX(1336,238),name:'Town 2'},{p:PX(1376,820),name:'Town 3'}];
  z.label=()=>{const [x,zz]=[LEE.pos.x,LEE.pos.y];const d=(px,py)=>{const q=PX(px,py);return Math.hypot(x-q[0],zz-q[1]);};
    if(d(760,470)<9)return 'Town square';if(d(330,300)<9)return 'School';if(d(1168,600)<7)return 'Item shop';if(d(763,345)<6)return 'Sand Town';if(d(700,700)<9)return 'Home';return 'Sand Town';};
});
BZ.solids=null;

/* ---------- interactions ---------- */
const doorAt=(d,dist=1.2)=>({x:d.x+d.nx*dist,z:d.z+d.nz*dist});
{const d=doorAt(TOWN.schoolDoor);INTERACT.push({zone:'sandtown',x:d.x,z:d.z,r:2,label:'School',fn:()=>startDialog([{who:'School',text:'The school doors. (Chunk 2 continues from here.)'}])});}
{const d=doorAt(TOWN.hidDoor);INTERACT.push({zone:'sandtown',x:d.x,z:d.z,r:2,label:'Hidden entrance',fn:()=>startDialog([{who:'Hidden entrance',text:'A hidden way into the Library and Book World.'},{who:'Hidden entrance',text:'(The Library and Book World are the next build.)'}])});}
{const d=doorAt(TOWN.shopDoor);INTERACT.push({zone:'sandtown',x:d.x,z:d.z,r:2,label:'Item Shop',fn:()=>shopMenu()});}
{const d=doorAt(TOWN.homeDoor);INTERACT.push({zone:'sandtown',x:d.x,z:d.z,r:1.8,label:'Home',fn:()=>startDialog([{who:'Home',text:'Home. (The inside of the house isn’t built yet.)'}])});}
let exitCool=0;
TOWN.update=dt=>{if(exitCool>0)exitCool-=dt;if(mode!=='play'||exitCool>0)return;
  for(const e of TOWN.exits){if(Math.hypot(LEE.pos.x-e.p[0],LEE.pos.y-e.p[1])<3){exitCool=2;note(e.name+' isn’t built yet','gold');
    const c=PX(760,470),dx=c[0]-LEE.pos.x,dz=c[1]-LEE.pos.y,d=Math.hypot(dx,dz);LEE.pos.x+=dx/d*2.5;LEE.pos.y+=dz/d*2.5;break;}}};

/* ---------- getting there: straight after Lee wakes up ---------- */
const TOWN_SPAWN=PX(690,700);
function enterSandTown(fromSave){
  const place=fromSave&&G.story.place==='school'?'school':'sandtown';G.story.place=place;
  setZone(place);['ash','sam','matt','voltix','man'].forEach(k=>{S[k].hidden=true;refreshChar(S[k]);});
  LEE.hidden=false;LEE.lie=0;LEE.lieY=0;LEE.noTag=false;refreshChar(LEE);
  if(!fromSave){LEE.pos.set(TOWN_SPAWN[0],TOWN_SPAWN[1]);const c=PX(760,470);LEE.lookT.set(c[0]-LEE.pos.x,c[1]-LEE.pos.y).normalize();LEE.look.copy(LEE.lookT);
    yaw=Math.atan2(-LEE.lookT.x,-LEE.lookT.y);}
  cine.active=false;camTgt.set(LEE.pos.x,1.2,LEE.pos.y);curDist=CAMD[settings.camera];pitch=0.34;
  G.story.stage='town';G.members=['lee'];mode='play';hudFor(true);
  const el=$('tut');el.firstElementChild.textContent='Objective';$('tutText').textContent=place==='school'?'Explore the school.':'Explore Sand Town.';el.classList.add('open');
  hintShown=true;updateHint();}
