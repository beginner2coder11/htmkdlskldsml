(function(){
'use strict';
const $=id=>document.getElementById(id);
const TOUCH=matchMedia('(pointer: coarse)').matches;
const CALM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.floor(rnd(a,b+1)),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

/* ================= Storage + settings (shared across slots) ================= */
const store={
  ok:(()=>{try{localStorage.setItem('cm.t','1');localStorage.removeItem('cm.t');return true;}catch(e){return false;}})(),
  get(k){try{const v=localStorage.getItem(k);return v?JSON.parse(v):null;}catch(e){return null;}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
};
const SETTINGS_KEY='cybermaster.test.settings',SLOT_KEY=i=>'cybermaster.test.slot'+i;
const DETECTED=(!TOUCH||((navigator.hardwareConcurrency||4)>=6&&(window.devicePixelRatio||1)<=3))?'high':'low';
const settings=Object.assign({quality:'auto',camera:'normal',hints:true,textSize:1,dys:false,voice:false,master:80,music:70,sfx:80,voiceVol:80,bright:100},store.get(SETTINGS_KEY)||{});
const DEV=/[?&]dev=1/.test(location.search)||store.get('cybermaster.test.dev')===true;
let devOn=DEV;

/* ================= Audio: simple synthesized SFX + optional voice-over ================= */
let actx=null;
function audio(){if(!actx){try{actx=new (window.AudioContext||window.webkitAudioContext)();}catch(e){}}if(actx&&actx.state==='suspended')actx.resume();return actx;}
function sfx(kind){const a=audio();if(!a)return;const vol=settings.master/100*settings.sfx/100;if(vol<=0)return;
  const seq={select:[[660,.06]],hit:[[140,.09],[90,.08]],heal:[[520,.07],[780,.1]],win:[[523,.1],[659,.1],[784,.18]],bad:[[220,.15],[160,.2]],buy:[[880,.06],[1175,.08]]}[kind]||[[440,.05]];
  let t=a.currentTime;seq.forEach(([f,d])=>{const o=a.createOscillator(),g=a.createGain();o.type=kind==='hit'?'square':'triangle';o.frequency.value=f;
    g.gain.setValueAtTime(0.18*vol,t);g.gain.exponentialRampToValueAtTime(0.0001,t+d);o.connect(g).connect(a.destination);o.start(t);o.stop(t+d+0.02);t+=d*0.9;});}
function speak(text){if(!settings.voice||!('speechSynthesis' in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text.replace(/[()…]/g,' '));
  u.volume=clamp(settings.master/100*settings.voiceVol/100,0,1);u.rate=1;speechSynthesis.speak(u);}catch(e){}}
function hush(){try{'speechSynthesis' in window&&speechSynthesis.cancel();}catch(e){}}

/* ================= Renderer + scene ================= */
const cv=$('c');
const renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true});
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
const camera=new THREE.PerspectiveCamera(50,1,0.1,220);
const scene=new THREE.Scene();
scene.background=new THREE.Color(0xbfd9f0);scene.fog=new THREE.Fog(0xbfd9f0,40,95);
scene.add(new THREE.HemisphereLight(0xffffff,0x5d6e4c,0.8));
const sun=new THREE.DirectionalLight(0xffffff,0.7);
sun.position.set(14,26,16);sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-40,right:40,top:40,bottom:-40,far:90});scene.add(sun);

/* ================= World: test area ================= */
const zones={};
function zone(name,opt){const g=new THREE.Group();g.visible=false;scene.add(g);return zones[name]=Object.assign({name,group:g,col:[],bounds:[-30,30,-30,30],sky:0xbfd9f0,fog:[40,95],marks:[],label:null},opt||{});}
let BZ=zone('test',{bounds:[-33.4,33.4,-37.4,31.4]});   // zone currently being built
let Z=BZ;                                                // zone currently active
const mat=(c,o)=>new THREE.MeshLambertMaterial(Object.assign({color:c,flatShading:true},o||{}));
function add(geo,m,x,y,z,shadow=true){const mesh=new THREE.Mesh(geo,(m&&m.isMaterial)||Array.isArray(m)?m:mat(m));mesh.position.set(x,y,z);mesh.castShadow=shadow;mesh.receiveShadow=true;BZ.group.add(mesh);return mesh;}
function box(w,h,d,x,y,z,c,solid=true,shadow=true){const m=add(new THREE.BoxGeometry(w,h,d),c,x,y,z,shadow);if(solid)BZ.col.push({b:1,x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2,top:y+h/2});return m;}
function circ(x,z,r,top=3){BZ.col.push({c:1,x,z,r,top});}
function canvasTex(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);return new THREE.CanvasTexture(c);}
function facedBox(w,h,d,x,y,z,sideCol,frontTex,solid=true){const side=mat(sideCol),front=new THREE.MeshLambertMaterial({map:frontTex});return box(w,h,d,x,y,z,[side,side,side,side,front,side],solid);}
function flat(w,d,x,z,c,y=0.02){box(w,0.04,d,x,y,z,c,false,false);}
function label(text,x,z,y=4.4,color='#7cf5ff'){
  const t=canvasTex(512,96,(g,w,h)=>{g.fillStyle='rgba(12,14,22,.85)';g.beginPath();g.roundRect?g.roundRect(4,8,w-8,h-16,18):g.rect(4,8,w-8,h-16);g.fill();
    g.strokeStyle=color;g.lineWidth=5;g.stroke();g.fillStyle='#fff';g.font='bold 40px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(text,w/2,h/2+2);});
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true}));s.scale.set(5.4,1,1);s.position.set(x,y,z);BZ.group.add(s);return s;}
function tree(x,z,s=1){add(new THREE.CylinderGeometry(0.22,0.3,1.6,6),0x6b4a30,x,0.8,z);add(new THREE.IcosahedronGeometry(1.3*s,0),0x4f8a3c,x,1.6+1.2*s,z);circ(x,z,0.45);}
function post(x,z,h=1.6,c=0x6b6f78){add(new THREE.CylinderGeometry(0.08,0.08,h,8),c,x,h/2,z);}
function signBoard(x,z,text,sub,face=0){const tx=canvasTex(256,112,(g,w,h)=>{g.fillStyle='#1f4d3a';g.fillRect(0,0,w,h);g.strokeStyle='#e8e2c8';g.lineWidth=6;g.strokeRect(6,6,w-12,h-12);
  g.fillStyle='#f4f1e8';g.textAlign='center';g.font='bold 30px sans-serif';g.fillText(text,w/2,52);g.font='20px sans-serif';g.fillText(sub||'',w/2,86);});
  post(x-1.3,z,2.4);post(x+1.3,z,2.4);const m=facedBox(3,1.3,0.15,x,1.95,z,0x1f4d3a,tx,false);m.rotation.y=face;BZ.col.push({b:1,x0:x-1.5,x1:x+1.5,z0:z-0.25,z1:z+0.25,top:2.6});}

function groundPlane(c,size=140){const g=new THREE.Mesh(new THREE.PlaneGeometry(size,size),mat(c));g.rotation.x=-Math.PI/2;g.receiveShadow=true;BZ.group.add(g);return g;}
groundPlane(0x8fb46a);
// perimeter hedge
box(68,1.4,1,0,0.7,-38,0x3f7a36);box(68,1.4,1,0,0.7,32,0x3f7a36);box(1,1.4,70,-34,0.7,-3,0x3f7a36);box(1,1.4,70,34,0.7,-3,0x3f7a36);
// central plaza + paths
const plaza=new THREE.Mesh(new THREE.CircleGeometry(7,32),mat(0xcfc6b0));plaza.rotation.x=-Math.PI/2;plaza.position.y=0.03;plaza.receiveShadow=true;BZ.group.add(plaza);
const fountain=add(new THREE.CylinderGeometry(1.6,1.8,0.7,16),0xbdb6a4,0,0.35,0);circ(0,0,1.8);
add(new THREE.CylinderGeometry(1.3,1.3,0.1,16),new THREE.MeshLambertMaterial({color:0x7cc8ff,emissive:0x245a80}),0,0.71,0,false);
const PATH=0xd8cfb8;
flat(3,8,0,-11,PATH);flat(3,8,0,11,PATH);flat(12,3,-11,0,PATH);flat(12,3,11,0,PATH);
[[-45],[45],[135],[-135]].forEach(([a])=>{const r=a*Math.PI/180,m=box(3,0.04,12,Math.sin(r)*12,0.02,-Math.cos(r)*12,PATH,false,false);m.rotation.y=-r;});

// --- Entrance + movement lane (south) ---
[-2,2].forEach(x=>box(0.6,3,0.6,x,1.5,29.5,0x9aa0a8));box(4.8,0.5,0.6,0,3.2,29.5,0x9aa0a8,false);
flat(12,16,0,17,0xc9c0a8);
box(0.5,1.8,16,-6.2,0.9,17,0xb89b72);box(0.5,1.8,16,6.2,0.9,17,0xb89b72);
box(8.2,1.8,0.5,-2,0.9,21,0xb89b72);            // S-bend wall 1 (gap on the right)
box(8.2,1.8,0.5,2,0.9,16,0xb89b72);             // S-bend wall 2 (gap on the left)
box(5.3,1.8,0.5,-3.45,0.9,11.5,0xb89b72);box(5.3,1.8,0.5,3.45,0.9,11.5,0xb89b72); // narrow passage (1.6 wide)
[[-3.5,24.5],[3,18.5],[-3,13.8]].forEach(([x,z])=>box(0.9,0.9,0.9,x,0.45,z,0xa0703a));
circ(2.8,23.6,0.4);add(new THREE.CylinderGeometry(0.4,0.4,1.6,10),0x9aa0a8,2.8,0.8,23.6);
label('Movement lane',0,26,3.6);

// --- Combat arena (north) ---
const ARENA={x:0,z:-25,r:10};
const arenaFloor=new THREE.Mesh(new THREE.CircleGeometry(ARENA.r,40),mat(0xb99a6e));arenaFloor.rotation.x=-Math.PI/2;arenaFloor.position.set(ARENA.x,0.03,ARENA.z);arenaFloor.receiveShadow=true;BZ.group.add(arenaFloor);
flat(3,6,0,-13,PATH);
for(let i=0;i<48;i++){const a=i/48*Math.PI*2;if(Math.abs(Math.atan2(Math.sin(a),Math.cos(a)))<0.2)continue;
  const x=ARENA.x+Math.sin(a)*ARENA.r,z=ARENA.z+Math.cos(a)*ARENA.r;add(new THREE.CylinderGeometry(0.3,0.36,1.5,6),0x7a5c3e,x,0.75,z);circ(x,z,0.34,1.6);}
const pen=[[6.2,-31.4],[8.4,-31.4]];box(0.2,0.6,3.6,5.4,0.3,-30,0xd23a3a,false);box(3.2,0.6,0.2,7,0.3,-28.2,0xd23a3a,false);
label('Combat arena',0,-14.5,3.8,'#e5173f');

// --- Social room (north-west) ---
const SOC={x:-20,z:-14};
flat(10,8,SOC.x,SOC.z,0xa7876a);flat(6,4,SOC.x,SOC.z,0x7a2f4a,0.05);
box(10,2,0.4,SOC.x,1,SOC.z-4.2,0xe8d9c0);box(0.4,2,8.8,SOC.x-5.2,1,SOC.z,0xe8d9c0);
box(2.4,0.5,0.7,SOC.x+1,0.25,SOC.z-2.8,0x8a5a3a);
flat(3,10,-11,-8,PATH);
label('Dialogue & social',SOC.x,SOC.z+3,3.8,'#ff6fa8');

// --- Interaction corner (west) ---
const IC={x:-24,z:2};
flat(9,9,IC.x,IC.z,0xc9c0a8);
signBoard(IC.x+2,IC.z+4,'SIGN','Interaction test');
box(4,3.6,0.5,IC.x-2,1.8,IC.z-3.6,0xc97b5d);box(1.6,2.6,0.1,IC.x-2,1.3,IC.z-3.3,0x4f3526,false,false);
const boardTex=canvasTex(256,160,(g,w,h)=>{g.fillStyle='#b3824f';g.fillRect(0,0,w,h);g.strokeStyle='#5a3a24';g.lineWidth=10;g.strokeRect(5,5,w-10,h-10);
  [[24,22,70,56,'#f4f1e8'],[108,30,60,70,'#f2c14e'],[182,20,54,50,'#a8d8f0'],[40,92,80,48,'#ffb3c8'],[140,104,86,40,'#f4f1e8']].forEach(([x,y,pw,ph,c])=>{g.fillStyle=c;g.fillRect(x,y,pw,ph);g.fillStyle='rgba(0,0,0,.25)';for(let l=y+14;l<y+ph-6;l+=8)g.fillRect(x+6,l,pw-12,2);});});
post(IC.x+2.2,IC.z-3.4,2.4,0x5a3a24);post(IC.x+4.6,IC.z-3.4,2.4,0x5a3a24);
facedBox(2.8,1.7,0.15,IC.x+3.4,1.75,IC.z-3.4,0x5a3a24,boardTex,false);BZ.col.push({b:1,x0:IC.x+2,x1:IC.x+4.8,z0:IC.z-3.6,z1:IC.z-3.2,top:2.6});
const chestBase=box(1.2,0.7,0.8,IC.x-3.2,0.35,IC.z+2.4,0x8a5a3a);
const chestLid=add(new THREE.BoxGeometry(1.24,0.3,0.84),0xd9b44a,IC.x-3.2,0.85,IC.z+2.4);
label('Interaction corner',IC.x,IC.z+5.5,3.8);

// --- Shop & rest (north-east) ---
const SH={x:20,z:-13};
flat(12,10,SH.x,SH.z,0xc9c0a8);flat(3,10,11,-8,PATH);
box(4,1.1,1,SH.x-3,0.55,SH.z-1,0x8a5a3a);box(4.4,0.2,2.2,SH.x-3,2.8,SH.z-1.4,0xd23a3a,false);
[[-5,-2.4],[-1,-2.4]].forEach(([dx,dz])=>post(SH.x+dx,SH.z+dz,2.8,0xcfd4dc));
box(5,4,4,SH.x+3.5,2,SH.z-3.5,0x6a86b8);box(1.6,2.4,0.1,SH.x+3.5,1.2,SH.z-1.46,0x2a3350,false,false);
box(2.4,0.5,0.7,SH.x-3.5,0.25,SH.z+3.4,0x8a5a3a);
const crystal=add(new THREE.OctahedronGeometry(0.6,0),new THREE.MeshLambertMaterial({color:0x7cf5ff,emissive:0x2a8fa0,flatShading:true}),SH.x+3.5,1.4,SH.z+2.6);circ(SH.x+3.5,SH.z+2.6,0.5);
label('Shop & rest',SH.x,SH.z+5.2,3.8,'#f2c14e');

// --- Library / Book World (east) ---
const LB={x:25,z:3};
flat(10,9,LB.x-1,LB.z,0xc9c0a8);
box(5,4.4,7,LB.x+2.5,2.2,LB.z,0x3a2e52);
const roof=add(new THREE.ConeGeometry(1,2,4),0x1c1530,LB.x+2.5,5.4,LB.z);roof.rotation.y=Math.PI/4;roof.scale.set(5.6/1.414,1,7.6/1.414);
box(0.1,2.6,1.6,LB.x-0.02,1.3,LB.z-1.6,0xf2c14e,false,false);
const bookArch=new THREE.Group();bookArch.position.set(LB.x-2.5,0,LB.z+3.2);BZ.group.add(bookArch);
[-0.9,0.9].forEach(dx=>{const p=new THREE.Mesh(new THREE.BoxGeometry(0.3,2.6,0.3),new THREE.MeshLambertMaterial({color:0x8a5cff,emissive:0x3a1f7a}));p.position.set(dx,1.3,0);bookArch.add(p);circ(LB.x-2.5+dx,LB.z+3.2,0.25);});
const archTop=new THREE.Mesh(new THREE.BoxGeometry(2.4,0.3,0.4),new THREE.MeshLambertMaterial({color:0x8a5cff,emissive:0x3a1f7a}));archTop.position.y=2.7;bookArch.add(archTop);
const archGlow=new THREE.Mesh(new THREE.PlaneGeometry(1.5,2.4),new THREE.MeshBasicMaterial({color:0x7cf5ff,transparent:true,opacity:.35,side:THREE.DoubleSide}));archGlow.position.y=1.25;bookArch.add(archGlow);
label('Library · Book World',LB.x-1,LB.z+5.4,3.8,'#8a5cff');

// --- Portal & map (south-east) — phase 2 ---
const PM={x:18,z:17};
flat(10,8,PM.x,PM.z,0xc9c0a8);
function ring(x,z,c,lit){const g=new THREE.Group();g.position.set(x,1.7,z);BZ.group.add(g);
  g.add(new THREE.Mesh(new THREE.TorusGeometry(1.3,0.15,8,32),new THREE.MeshBasicMaterial({color:c})));
  if(lit)g.add(new THREE.Mesh(new THREE.CircleGeometry(1.2,32),new THREE.MeshBasicMaterial({color:0x8a5cff,transparent:true,opacity:.5,side:THREE.DoubleSide})));circ(x,z,0.4);return g;}
const portalA=ring(PM.x-2.5,PM.z-1,0x7cf5ff,true),portalB=ring(PM.x+2.5,PM.z-1,0x555a66,false);
label('Portals & map · next',PM.x,PM.z+4,3.8,'#7a8090');

// --- Journal kiosk (south-west) — phase 2 ---
const JK={x:-18,z:17};
flat(8,7,JK.x,JK.z,0xc9c0a8);box(1.4,2,1,JK.x,1,JK.z-1,0x445066);box(1.2,0.8,0.1,JK.x,1.5,JK.z-0.46,0x7cf5ff,false,false);
label('Journal kiosk · next',JK.x,JK.z+3.5,3.8,'#7a8090');

// scenery
[[-30,-30],[-28,24],[30,-30],[28,26],[-12,24],[12,25],[-30,10],[30,-2],[10,-32],[-10,-33],[-8,-18],[10,8],[-12,8],[26,-24],[-26,-24]].forEach(([x,z],i)=>tree(x,z,0.9+(i%3)*0.15));
signBoard(4.5,5.4,'TEST AREA','Stations all round',0);
