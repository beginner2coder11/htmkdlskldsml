
/* ================= Stations ================= */
function relTalk(id){
  const lines={
    sam:[["Want to hang out after school?",2,"Yeah… I'd like that."],["How's it going?",1,"Okay, I guess. Thanks for asking."],["Whatever.",0,"Oh… okay."]],
    ash:[["Your blades are impressive.",2,"Tch. Obviously."],["Hey, Ash.",1,"What do you want?"],["Bet I could beat you.",0,"Keep dreaming."]],
    matt:[["Hotdogs later?",2,"Now you're speaking my language!"],["You alright?",1,"Always!"],["That joke was bad.",0,"Hey! Rude."]]
  }[id];
  const nm=NAMES[id];
  startDialog([{who:id,text:'Relationship with '+nm+': level '+G.rel[id]+'/10.'},
    {prompt:'Talk, or spend time together?',choices:[
      {text:'Talk',silent:true,reply:[{choices:lines.map(([t,d,r])=>({text:t,reply:[{who:id,text:r}],fn:()=>gainRel(id,d)}))}]},
      {text:'Spend time together',silent:true,reply:[{who:'lee',text:'Want to hang out for a bit?'},{who:id,text:'Sure.'}],fn:()=>gainRel(id,1)},
      {text:'Leave',silent:true}]}],()=>checkRel10(id));}
function gainRel(id,d){if(d<=0){note(NAMES[id]+': no change','love');return;}const before=G.rel[id];G.rel[id]=Math.min(10,before+d);touch();
  note(NAMES[id]+' +'+(G.rel[id]-before)+'  ♥ '+G.rel[id]+'/10','love');}
function checkRel10(id){if(G.rel[id]>=10&&!G.flags.scene10[id]){G.flags.scene10[id]=true;addItem(id+'_friend',1);touch();
  startDialog([{who:'Scene',text:NAMES[id]+' seems different around you now.'},{who:id,text:'…Thanks, Lee. For everything.'},
    {who:'Reward',text:ITEMS[id+'_friend'].name+' received. (Placeholder level 10 scene.)'}],null,{noSkip:true});}}

function shopMenu(tab='buy'){mode='menu';
  const buy=SHOP_STOCK.map(k=>{const it=ITEMS[k],have=G.inv[k]||0;
    return {label:it.name,sub:it.price+' G · have '+have+(it.owner?' · '+NAMES[it.owner]+' only':''),disabled:G.money<it.price||have>=99,
      on:()=>{G.money-=it.price;addItem(k,1);touch();sfx('buy');updateMoney();shopMenu('buy');}};});
  const sellable=Object.keys(G.inv).filter(k=>ITEMS[k].price>0&&!ITEMS[k].key);
  const sell=sellable.map(k=>{const it=ITEMS[k],v=Math.floor(it.price*0.5);
    return {label:it.name+' ×'+G.inv[k],sub:'Sell for '+v+' G (50%)',on:()=>{addItem(k,-1);G.money+=v;touch();sfx('buy');updateMoney();shopMenu('sell');}};});
  openMenu('Shop · '+G.money+' G',[{row:[{label:'Buy'+(tab==='buy'?' ◆':''),on:()=>shopMenu('buy')},{label:'Sell'+(tab==='sell'?' ◆':''),on:()=>shopMenu('sell')}]}]
    .concat(tab==='buy'?buy:(sell.length?sell:[{text:'Nothing to sell. Equipped gear and special items cannot be sold.'}]),[{label:'Leave',on:resume}]),
    tab==='buy'?'Stacks cap at 99. Gear is character-specific.':'Items sell for half their price.');}
function destinyMenu(back){
  openMenu('Book of Destiny',G.members.map(id=>{const m=G.party[id];const sp=Object.values(m.spent).reduce((a,b)=>a+b,0);
    return {label:m.name,sub:m.dp+' DP free · '+sp+' spent',on:()=>destinyChar(id,back)};}).concat([{label:'Back',on:back}]),'Spend Destiny Points to raise stats beyond levelling.');}
function destinyChar(id,back){const m=G.party[id];const sp=Object.values(m.spent).reduce((a,b)=>a+b,0),fee=sp*25;
  const rows=Object.keys(DPINC).map(k=>({label:STATN[k]+' '+stat(m,k),sub:'+'+DPINC[k]+' for 1 DP'+(m.spent[k]?' · '+m.spent[k]+' spent':''),disabled:m.dp<1,
    on:()=>{m.dp--;m.spent[k]++;if(k==='mhp')m.hp+=DPINC[k];if(k==='mmp')m.mp+=DPINC[k];touch();sfx('heal');destinyChar(id,back);}}));
  rows.push({label:'Respec '+m.name,sub:sp?'Refund '+sp+' DP for '+fee+' G':'Nothing to refund',cls:'danger',disabled:!sp||G.money<fee,
    on:()=>openMenu('Respec '+m.name+'?',[{row:[{label:'Pay '+fee+' G',cls:'danger',on:()=>{G.money-=fee;m.dp+=sp;Object.keys(m.spent).forEach(k=>m.spent[k]=0);fixCaps(m);touch();updateMoney();destinyChar(id,back);}},{label:'Cancel',on:()=>destinyChar(id,back)}]}],'Each character has their own respec fee (25 G per point here).')});
  rows.push({label:'Back',on:()=>destinyMenu(back)});
  openMenu(m.name+' · '+m.dp+' DP',rows);}
function bookWorldMenu(){mode='menu';openMenu('Book World',[{label:'Rest',sub:'Free · full recovery',on:()=>{healAll();touch();sfx('heal');note('Party fully recovered');bookWorldMenu();}},
  {label:'Party & equipment',on:()=>partyMenu(bookWorldMenu)},{label:'Book of Destiny',on:()=>destinyMenu(bookWorldMenu)},{label:'Leave',on:resume}],'A safe hub out of sync with the other worlds. (Phase 1: menu hub, no separate scene yet.)');}
function nextBuild(what){startDialog([{who:'Test note',text:what+' arrives in the next build of the test area.'}]);}

const INTERACT=[
  {x:4.5,z:6.4,r:1.9,label:'Read sign',fn:()=>startDialog([{who:'Test area',text:'North: combat arena. North-east: shop & rest. East: Library and Book World.'},{who:'Test area',text:'West: interaction corner. North-west: dialogue & social. South: movement lane. South-east and south-west arrive next build.'}])},
  {x:IC.x+2,z:IC.z+4.9,r:1.9,label:'Read sign',fn:()=>startDialog([{who:'Sign',text:'Interaction test: prompts should only appear when you are in range.'}])},
  {x:IC.x-2,z:IC.z-2.8,r:1.8,label:'Try the door',fn:()=>startDialog([{who:'Door',text:'It’s locked. (Building transitions come with the portal station.)'}])},
  {x:IC.x+3.4,z:IC.z-2.6,r:1.9,label:'Read noticeboard',fn:()=>startDialog([{who:'Noticeboard',text:'Notices are pinned all over the board.'},{who:'Noticeboard',text:'(Notice text to be written.)'}])},
  {x:IC.x-3.2,z:IC.z+3.3,r:1.8,label:'Open chest',fn:()=>{if(G.flags.chest){startDialog([{who:'Chest',text:'It’s empty.'}]);return;}
    G.flags.chest=true;touch();chestLid.rotation.x=-1.1;chestLid.position.z=IC.z+2.1;chestLid.position.y=1.05;addItem('potion',3);addItem('tonic',1);G.money+=50;updateMoney();sfx('win');
    startDialog([{who:'Chest',text:'Found 3 Potions, a Revival Tonic and 50 G.'}]);}},
  {char:NPC.keeper,r:1.9,label:'Talk',fn:()=>startDialog([{who:'keeper',text:'Morning. This corner is for testing signs, doors, boards and chests.'},
    {choices:[{text:'Thanks.',reply:[{who:'keeper',text:'Any time.'}]},{text:'What’s in the chest?',reply:[{who:'keeper',text:'Open it and see.'}]}]}])},
  {char:NPC.sam,r:1.9,label:'Talk to Sam',fn:()=>relTalk('sam')},
  {char:NPC.ash,r:1.9,label:'Talk to Ash',fn:()=>relTalk('ash')},
  {char:NPC.matt,r:1.9,label:'Talk to Matt',fn:()=>relTalk('matt')},
  {char:NPC.shop,r:2.4,label:'Shop',fn:()=>shopMenu()},
  {x:SH.x+3.5,z:SH.z-0.9,r:1.8,label:'Inn (30 G)',fn:()=>startDialog([{choices:[
    {text:'Stay the night (30 G)',silent:true,fn:()=>{if(G.money<30){note('Not enough money');return;}G.money-=30;updateMoney();healAll();touch();sfx('heal');note('Rested at the inn · full recovery');}},
    {text:'Not now',silent:true}],prompt:'The inn restores the whole party.'}])},
  {x:SH.x-3.5,z:SH.z+4.3,r:1.8,label:'Rest (free)',fn:()=>{healAll();touch();sfx('heal');note('Rested on the bench · full recovery');}},
  {x:SH.x+3.5,z:SH.z+3.6,r:1.9,label:'Save point',fn:()=>{mode='menu';slotMenu('save',resume);}},
  {char:NPC.carolin,r:1.9,label:'Talk to Carolin',fn:()=>startDialog([{who:'carolin',text:'Welcome! Want to open the Book of Destiny?'},
    {choices:[{text:'Yes, please.',silent:true,fn:()=>setTimeout(()=>{mode='menu';destinyMenu(resume);},0)},{text:'Not right now.',reply:[{who:'carolin',text:'Come back any time!'}]}]}])},
  {x:LB.x-2.5,z:LB.z+4,r:1.9,label:'Enter Book World',fn:()=>burst(bookWorldMenu)},
  {x:LB.x-0.7,z:LB.z-1.6,r:1.6,label:'Library door',fn:()=>nextBuild('The Library interior')},
  {x:PM.x-2.5,z:PM.z,r:2,label:'Portal (open)',fn:()=>nextBuild('Portal travel, the full map and fast travel')},
  {x:PM.x+2.5,z:PM.z,r:2,label:'Portal (locked)',fn:()=>startDialog([{who:'Portal',text:'This portal is locked. Story progress unlocks it. (Test portal.)'}])},
  {x:JK.x,z:JK.z,r:2,label:'Journal kiosk',fn:()=>nextBuild('The journal, bestiary and statistics kiosk')},
  {x:0,z:-14.2,r:1.9,label:'Arena sign',fn:()=>startDialog([{who:'Arena',text:'Touch an enemy to start a battle. Singles, a pack of three, a boss, and a Test Golem that always wins.'},{who:'Arena',text:'Leave the arena and come back to respawn regular enemies. Bosses stay defeated.'}])}
];

/* ================= Developer panel ================= */
function devMenu(){mode='menu';
  const rel=id=>({row:[{label:NAMES[id]+' +1',on:()=>{gainRel(id,1);devMenu();}},{label:NAMES[id]+' → 9',on:()=>{G.rel[id]=9;touch();devMenu();}}]});
  openMenu('Developer',[
    {label:'Matt in party',sub:G.members.includes('matt')?'Yes':'No',on:()=>{G.members=G.members.includes('matt')?G.members.filter(x=>x!=='matt'):[...G.members,'matt'];touch();devMenu();}},
    rel('sam'),rel('ash'),rel('matt'),
    {row:[{label:'Level +1 all',on:()=>{G.members.forEach(id=>gainXp(G.party[id],xpNeed(G.party[id].lvl)-G.party[id].xp));devMenu();}},{label:'+5 DP all',on:()=>{G.members.forEach(id=>G.party[id].dp+=5);devMenu();}}]},
    {row:[{label:'+500 G',on:()=>{G.money+=500;updateMoney();devMenu();}},{label:'+10 each item',on:()=>{['potion','ether','tonic','antidote'].forEach(k=>addItem(k,10));devMenu();}}]},
    {row:[{label:'Full HP/MP',on:()=>{healAll();devMenu();}},{label:'All 1 HP',on:()=>{G.members.forEach(id=>{G.party[id].hp=1;});devMenu();}},{label:'All 0 MP',on:()=>{G.members.forEach(id=>{G.party[id].mp=0;});devMenu();}}]},
    {row:['poison','sleep','para'].map(s=>({label:'Lee: '+s,sub:devStatus===s?'next battle':'',on:()=>{devStatus=s;devMenu();}}))},
    {row:[{label:'Spawn slime here',on:()=>{spawnNear('slime');resume();}},{label:'Spawn pack here',on:()=>{spawnNear('pack');resume();}}]},
    {row:[{label:'Respawn arena',on:()=>{respawnArena(true);devMenu();}},{label:'Reset boss',on:()=>{G.flags.bossDown=false;respawnArena(true);devMenu();}}]},
    {text:'Not in phase 1: story flags, time of day, discovered areas, bestiary.'},
    {label:'Close',on:resume}],'Test build only. Also available in battle: Win / Lose.');}
let devStatus=null;
