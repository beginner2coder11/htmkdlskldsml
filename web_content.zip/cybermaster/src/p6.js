
/* ================= World enemies ================= */
let invuln=0,arenaOutside=true;
const inArena=(x,z,r)=>Math.hypot(x-ARENA.x,z-ARENA.z)<r;
function respawnArena(force){WORLD_ENEMIES.forEach(w=>{if(w.spawned)return;if(w.boss&&G.flags.bossDown){w.alive=false;setVisible(w.c,false);return;}
  if(!w.alive||force){w.alive=true;w.c.pos.set(w.x,w.z);setVisible(w.c,true);}});}
const spawned=[];
function spawnNear(kind){const f=camF();const x=LEE.pos.x-f[0]*-3,z=LEE.pos.y-f[1]*-3;
  const w={id:'sp'+spawned.length,type:kind==='pack'?'slime':'slime',x,z,group:kind==='pack'?['slime','bat','moth']:['slime'],spawned:true,scale:kind==='pack'?1.1:0.8,label:kind==='pack'?'Pack ×3':null};
  const d=ENEMIES.slime;w.c=makeChar({enemy:true,zone:'test',id:w.id,name:w.label||d.name,col:d.col,x,z,scale:w.scale,angry:true,tagCol:'#ff8c8c'});w.alive=true;w.wait=1;w.tgt=new THREE.Vector2(x,z);w.free=true;
  WORLD_ENEMIES.push(w);ALLC.push(w.c);if(mode!=='title')tagsEl.classList.remove('hidden');}
function updateEnemies(dt){
  if(invuln>0)invuln-=dt;if(Z.name!=='test')return;
  const inside=inArena(LEE.pos.x,LEE.pos.y,ARENA.r+0.5);
  if(!inside&&!inArena(LEE.pos.x,LEE.pos.y,ARENA.r+3))arenaOutside=true;
  if(inside&&arenaOutside){arenaOutside=false;respawnArena(false);}
  WORLD_ENEMIES.forEach(w=>{if(!w.alive)return;const c=w.c;
    if(!w.fixed){const toLee=Math.hypot(LEE.pos.x-c.pos.x,LEE.pos.y-c.pos.y);
      const leeIn=w.free?toLee<7:inArena(LEE.pos.x,LEE.pos.y,ARENA.r);
      if(leeIn&&toLee<5&&invuln<=0)w.tgt.set(LEE.pos.x,LEE.pos.y);
      else{w.wait-=dt;if(w.wait<=0){w.wait=1.5+Math.random()*2.5;const a=Math.random()*6.283,r=Math.random()*3;w.tgt.set(w.x+Math.cos(a)*r,w.z+Math.sin(a)*r);}}
      const dx=w.tgt.x-c.pos.x,dz=w.tgt.y-c.pos.y,d=Math.hypot(dx,dz);
      if(d>0.1){const s=Math.min(d,(leeIn&&toLee<5?2.4:1.2)*dt);c.pos.x+=dx/d*s;c.pos.y+=dz/d*s;c.lookT.set(dx,dz).normalize();c.walk+=dt;}else c.walk=0;
      if(!w.free&&!inArena(c.pos.x,c.pos.y,ARENA.r-1.2)){const a=Math.atan2(c.pos.x-ARENA.x,c.pos.y-ARENA.z);c.pos.set(ARENA.x+Math.sin(a)*(ARENA.r-1.2),ARENA.z+Math.cos(a)*(ARENA.r-1.2));}
    }else c.lookT.set(LEE.pos.x-c.pos.x,LEE.pos.y-c.pos.y).normalize();
    const reach=0.55+0.4*(w.scale||0.8);
    if(invuln<=0&&!dlg.open&&Math.hypot(LEE.pos.x-c.pos.x,LEE.pos.y-c.pos.y)<reach){startBattle(w);}});
}

/* ================= Transition (image only, no area name) ================= */
const fade=$('fade'),burstEl=$('burst');
function burst(mid){
  busy=true;fade.style.visibility='visible';stopJoy();
  burstEl.animate(CALM?[{opacity:0,transform:'scale(5)'},{opacity:1,transform:'scale(5)'}]:[{transform:'scale(.04) rotate(-40deg)'},{transform:'scale(5) rotate(0deg)'}],{duration:CALM?250:480,easing:'cubic-bezier(.6,0,.9,.5)',fill:'forwards'});
  setTimeout(()=>{try{mid&&mid();}catch(e){console.error(e);}
    const out=burstEl.animate([{opacity:1,transform:'scale(5)'},{opacity:0,transform:'scale(7) rotate(12deg)'}],{duration:380,easing:'ease-in',fill:'forwards'});
    out.onfinish=()=>{fade.style.visibility='hidden';busy=false;};},CALM?450:620);
}

/* ================= Title flow ================= */
function hasSaves(){return [1,2,3].some(i=>store.get(SLOT_KEY(i)));}
function showTitle(){mode='title';cine.active=false;setZone('test');$('tut').classList.remove('open');hush();closeDialogSilently();closeMenu();$('title').classList.remove('hidden');$('hud').classList.add('hidden');tagsEl.classList.add('hidden');
  $('tCont').disabled=!hasSaves();setTimeout(()=>$('tNew').focus({preventScroll:true}),50);}
function startGame(save){
  if(save&&save.zone&&save.zone!=='test'){resumeStory(save);return;}
  burst(()=>{
    G=save?Object.assign(freshState(),save):freshState();G.zone='test';setZone('test');LEE.hidden=false;refreshChar(LEE);
    MEMBERS.forEach(id=>{const m=G.party[id];m.status={};});
    LEE.pos.set(G.pos[0],G.pos[1]);LEE.lookT.set(G.look[0],G.look[1]);LEE.look.copy(LEE.lookT);yaw=G.yaw||0;setRun(!!G.run);
    chestLid.rotation.x=G.flags.chest?-1.1:0;chestLid.position.set(IC.x-3.2,G.flags.chest?1.05:0.85,G.flags.chest?IC.z+2.1:IC.z+2.4);
    for(let i=WORLD_ENEMIES.length-1;i>=0;i--){const w=WORLD_ENEMIES[i];if(w.spawned){setVisible(w.c,false);scene.remove(w.c.spr,w.c.sh);w.c.tag&&w.c.tag.remove();WORLD_ENEMIES.splice(i,1);}}
    respawnArena(true);arenaOutside=true;invuln=1;
    updateMoney();camTgt.set(LEE.pos.x,1.2,LEE.pos.y);curDist=CAMD[settings.camera];
    $('title').classList.add('hidden');$('hud').classList.remove('hidden');tagsEl.classList.remove('hidden');$('devBtn').classList.toggle('hidden',!devOn);
    closeMenu();closeDialogSilently();mode='play';dirty=false;hintShown=false;updateHint();
  });
}
$('tNew').onclick=()=>{audio();if(!busy)startStory();};
$('tTest').onclick=()=>{audio();if(!busy)startGame(null);};
$('tCont').onclick=()=>{audio();if(!busy)slotMenu('load',closeMenu);};
$('tSet').onclick=()=>{audio();if(!busy)settingsMenu(closeMenu);};
let logoTaps=0,logoT=0;
$('logo').addEventListener('click',()=>{const now=Date.now();logoTaps=now-logoT<700?logoTaps+1:1;logoT=now;
  if(logoTaps>=5){logoTaps=0;devOn=!devOn;store.set('cybermaster.test.dev',devOn);note(devOn?'Developer controls on':'Developer controls off','gold');}});
$('pause').onclick=()=>{if(mode==='play'&&!dlg.open&&!busy)pauseMenu();};
$('devBtn').onclick=()=>{if(mode==='play'&&!dlg.open&&!busy)devMenu();};
['pause','devBtn','run','act'].forEach(id=>$(id).addEventListener('pointerdown',e=>e.stopPropagation()));

/* ================= Input ================= */
const keys={};let joy={on:false,id:null,ox:0,oy:0,x:0,y:0},drag={on:false,id:null,x:0,y:0},manualCam=0;
const joyEl=$('joy'),knob=$('knob');
function stopJoy(){joy.on=false;joy.id=null;joy.x=joy.y=0;joyEl.style.display='none';drag.on=false;drag.id=null;for(const k in keys)keys[k]=false;}
cv.addEventListener('pointerdown',e=>{audio();
  if(busy)return;
  if(dlg.open){if(!dlg.choosing&&!logEl.classList.contains('open'))nextLine();return;}
  if(mode!=='play')return;
  if(e.clientX<innerWidth*0.5&&!joy.on){joy={on:true,id:e.pointerId,ox:e.clientX,oy:e.clientY,x:0,y:0};
    joyEl.style.left=e.clientX+'px';joyEl.style.top=e.clientY+'px';joyEl.style.display='block';knob.style.transform='translate(-50%,-50%)';}
  else if(!drag.on)drag={on:true,id:e.pointerId,x:e.clientX,y:e.clientY};});
addEventListener('pointermove',e=>{
  if(joy.on&&e.pointerId===joy.id){let dx=e.clientX-joy.ox,dy=e.clientY-joy.oy;const d=Math.hypot(dx,dy),m=48;
    if(d>m){dx*=m/d;dy*=m/d;}joy.x=dx/m;joy.y=dy/m;knob.style.transform=`translate(calc(-50% + ${dx}px),calc(-50% + ${dy}px))`;}
  if(drag.on&&e.pointerId===drag.id){yaw-=(e.clientX-drag.x)*0.009;pitch=clamp(pitch+(e.clientY-drag.y)*0.004,0.12,0.9);drag.x=e.clientX;drag.y=e.clientY;manualCam=2.5;camUsed=true;}});
const endPtr=e=>{if(e.pointerId===joy.id){joy.on=false;joy.id=null;joy.x=joy.y=0;joyEl.style.display='none';}if(e.pointerId===drag.id){drag.on=false;drag.id=null;}};
addEventListener('pointerup',endPtr);addEventListener('pointercancel',endPtr);addEventListener('blur',stopJoy);
addEventListener('keydown',e=>{const k=e.key.toLowerCase();audio();
  if(k==='escape'){if(logEl.classList.contains('open'))logEl.classList.remove('open');else if(mode==='play'&&!dlg.open&&!busy)pauseMenu();else if(mode==='menu'&&menuName==='pause')resume();return;}
  const onButton=document.activeElement&&['BUTTON','INPUT'].includes(document.activeElement.tagName);
  if(mode==='battle'&&B.choosing&&/^[1-9]$/.test(k)){const b=bCmd.querySelectorAll('button')[+k-1];b&&b.click();return;}
  if(busy)return;
  if(dlg.open){if(dlg.choosing&&/^[1-9]$/.test(k)){const b=choicesEl.children[+k-1];b&&b.click();}
    else if(!dlg.choosing&&!onButton&&[' ','enter','e'].includes(k)){e.preventDefault();nextLine();}return;}
  if(mode!=='play')return;
  keys[k]=true;
  if((k==='r'||k==='shift')&&!e.repeat)setRun(!state.run);
  if(k==='q')manualCam=2.5;
  if([' ','enter','e'].includes(k)&&!onButton){e.preventDefault();if(near)near.fn();}});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;});
$('run').onclick=()=>setRun(!state.run);
const actBtn=$('act');actBtn.onclick=()=>{if(mode==='play'&&!dlg.open&&!busy&&near)near.fn();};
let hintShown=false;
function updateHint(){const h=$('hint');h.textContent=TOUCH?'Left: move · Right: drag to look · Walk/Run toggles':'WASD: move · J/L or right-drag: camera · R: run · E: interact · Esc: pause';
  h.style.opacity=settings.hints&&!hintShown?1:0;}

/* ================= Settings application ================= */
function resize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();}
function applySettings(){const q=settings.quality==='auto'?DETECTED:settings.quality;
  renderer.setPixelRatio(q==='high'?Math.min(window.devicePixelRatio||1,2):1);
  const sh=q==='high';if(renderer.shadowMap.enabled!==sh){renderer.shadowMap.enabled=sh;scene.traverse(o=>{if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.needsUpdate=true);});}
  sun.castShadow=sh;applyText();applyBrightness();updateHint();resize();}
addEventListener('resize',resize);

/* ================= Minimap ================= */
const mini=$('mini').getContext('2d');
const MAPMARKS=[[0,-25,'#e5173f'],[SH.x,SH.z,'#f2c14e'],[LB.x,LB.z,'#8a5cff'],[PM.x,PM.z,'#7a8090'],[JK.x,JK.z,'#7a8090'],[IC.x,IC.z,'#7cf5ff'],[SOC.x,SOC.z,'#ff6fa8'],[0,17,'#b89b72']];
function drawMini(){const S=208,s=3.2,BD=Z.bounds;mini.clearRect(0,0,S,S);mini.save();mini.translate(S/2,S/2);mini.rotate(yaw);mini.scale(s,s);mini.translate(-LEE.pos.x,-LEE.pos.y);
  mini.fillStyle=Z.name==='test'?'#6f9450':'#4f6a3c';mini.fillRect(BD[0]-1,BD[2]-1,BD[1]-BD[0]+2,BD[3]-BD[2]+2);
  if(Z.walk){mini.fillStyle='#d8cfb8';Z.walk.forEach(poly=>{mini.beginPath();poly.forEach(([x,z],i)=>i?mini.lineTo(x,z):mini.moveTo(x,z));mini.closePath();mini.fill();});
    mini.fillStyle='rgba(20,22,30,.6)';(Z.solids||[]).forEach(s=>{mini.beginPath();s.poly.forEach(([x,z],i)=>i?mini.lineTo(x,z):mini.moveTo(x,z));mini.closePath();mini.fill();});}
  if(!Z.hideMapWalls){mini.fillStyle='rgba(20,22,30,.55)';Z.col.forEach(k=>{if(k.b)mini.fillRect(k.x0,k.z0,k.x1-k.x0,k.z1-k.z0);});}
  (Z.name==='test'?MAPMARKS:Z.marks).forEach(([x,z,c])=>{mini.fillStyle=c;mini.beginPath();mini.arc(x,z,1.6,0,7);mini.fill();});
  WORLD_ENEMIES.forEach(w=>{if(!w.alive||Z.name!=='test')return;mini.fillStyle='#ff4040';mini.beginPath();mini.arc(w.c.pos.x,w.c.pos.y,0.8,0,7);mini.fill();});
  mini.restore();
  const sl=screenLook(LEE.look),a=Math.atan2(sl[1],sl[0]);mini.save();mini.translate(S/2,S/2);mini.rotate(a);
  mini.fillStyle='#fff';mini.strokeStyle='#111';mini.lineWidth=2;mini.beginPath();mini.moveTo(11,0);mini.lineTo(-7,-7);mini.lineTo(-3,0);mini.lineTo(-7,7);mini.closePath();mini.fill();mini.stroke();mini.restore();}

/* ================= Main loop ================= */
const camTgt=new THREE.Vector3(0,1.2,27.5);let curDist=CAMD[settings.camera];
const v3=new THREE.Vector3();let near=null,last=performance.now(),t=0;
const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
function camBlocked(x,y,z){if(Z.solids&&solidAt(x,y,z))return true;for(const k of Z.col){if(k.b&&y<k.top+0.3&&x>k.x0-0.3&&x<k.x1+0.3&&z>k.z0-0.3&&z<k.z1+0.3)return true;}return false;}
const AREAS=[[ARENA.x,ARENA.z,11,'Combat arena'],[SH.x,SH.z,7,'Shop & rest'],[LB.x,LB.z,7,'Library · Book World'],[PM.x,PM.z,6,'Portals & map (next)'],[JK.x,JK.z,6,'Journal kiosk (next)'],
  [IC.x,IC.z,6,'Interaction corner'],[SOC.x,SOC.z,6,'Dialogue & social'],[0,0,8,'Central plaza']];
function areaName(){if(Z.label)return Z.label();if(LEE.pos.y>9&&Math.abs(LEE.pos.x)<7)return 'Movement lane';for(const [x,z,r,n] of AREAS)if(Math.hypot(LEE.pos.x-x,LEE.pos.y-z)<r)return n;return 'Test area';}
let lastArea='';
function updatePlay(dt){
  if(keys['j'])yaw+=dt*2,manualCam=2.5,camUsed=true;if(keys['l'])yaw-=dt*2,manualCam=2.5,camUsed=true;if(manualCam>0)manualCam-=dt;
  let ix=(keys['d']||keys['arrowright']?1:0)-(keys['a']||keys['arrowleft']?1:0)+joy.x;
  let iz=(keys['s']||keys['arrowdown']?1:0)-(keys['w']||keys['arrowup']?1:0)+joy.y;
  const im=Math.hypot(ix,iz);if(im>1){ix/=im;iz/=im;}
  const px0=LEE.pos.x,pz0=LEE.pos.y;
  if(!dlg.open&&im>0.08){const f=camF(),r=camR(),mx=r[0]*ix-f[0]*iz,mz=r[1]*ix-f[1]*iz,sp=state.run?7.2:4;
    LEE.pos.x+=mx*sp*dt;LEE.pos.y+=mz*sp*dt;LEE.lookT.set(mx,mz).normalize();LEE.walk+=dt*(state.run?1.5:1);touch();
    const fd=(mx*f[0]+mz*f[1])/Math.max(0.001,Math.hypot(mx,mz));
    if(fd>-0.35&&manualCam<=0){const target=Math.atan2(-mx,-mz);yaw+=wrap(target-yaw)*Math.min(1,dt*(0.4+2.6*Math.max(0,fd))*Math.min(1,im));}
    if(!hintShown){hintShown=true;updateHint();}
  }else LEE.walk=0;
  resolve(LEE.pos,0.45);
  if(Z.walk&&!walkOK(LEE.pos.x,LEE.pos.y)){const nx=LEE.pos.x,nz=LEE.pos.y;
    if(walkOK(nx,pz0))LEE.pos.set(nx,pz0);else if(walkOK(px0,nz))LEE.pos.set(px0,nz);else LEE.pos.set(px0,pz0);}
  ALLC.forEach(n=>{if(n===LEE||!n.visible||n.enemy)return;const dx=LEE.pos.x-n.pos.x,dz=LEE.pos.y-n.pos.y,d=Math.hypot(dx,dz);
    if(d<0.9&&d>1e-4){LEE.pos.x+=dx/d*(0.9-d);LEE.pos.y+=dz/d*(0.9-d);}
    if(d<5)n.lookT.set(dx,dz).normalize();});
  updateEnemies(dt);
  if(Z.update)Z.update(dt);if(mode!=='play')return;
  const an=areaName();if(an!==lastArea){lastArea=an;$('area').textContent=an;}
  near=null;
  if(!dlg.open){let bd=1e9;INTERACT.forEach(it=>{if((it.zone||'test')!==Z.name||(it.char&&!it.char.visible)||(it.when&&!it.when()))return;const x=it.char?it.char.pos.x:it.x,z=it.char?it.char.pos.y:it.z,dd=Math.hypot(LEE.pos.x-x,LEE.pos.y-z);if(dd<it.r&&dd<bd){bd=dd;near=it;}});}
  if(near){actBtn.style.display='block';actBtn.textContent=near.label;}else actBtn.style.display='none';
}
function resolve(p,r){
  for(const k of Z.col){
    if(k.b){const cx=clamp(p.x,k.x0,k.x1),cz=clamp(p.y,k.z0,k.z1);const dx=p.x-cx,dz=p.y-cz,d=Math.hypot(dx,dz);
      if(d<r){if(d>1e-4){p.x+=dx/d*(r-d);p.y+=dz/d*(r-d);}
        else{const o=[[p.x-k.x0,-1,0],[k.x1-p.x,1,0],[p.y-k.z0,0,-1],[k.z1-p.y,0,1]].sort((a,b)=>a[0]-b[0])[0];p.x+=o[1]*(o[0]+r);p.y+=o[2]*(o[0]+r);}}}
    else{const dx=p.x-k.x,dz=p.y-k.z,d=Math.hypot(dx,dz),m=r+k.r;if(d<m&&d>1e-4){p.x+=dx/d*(m-d);p.y+=dz/d*(m-d);}}}
  p.x=clamp(p.x,Z.bounds[0],Z.bounds[1]);p.y=clamp(p.y,Z.bounds[2],Z.bounds[3]);}

function drawTags(){ALLC.forEach(c=>{if(!c.tag)return;if(!c.visible||c.noTag||(c.spr.material.opacity<0.3)){c.tag.style.display='none';return;}v3.set(c.pos.x,c.bh+0.25,c.pos.y);
  if(v3.distanceTo(camera.position)>26){c.tag.style.display='none';return;}v3.project(camera);
  if(v3.z>1){c.tag.style.display='none';return;}c.tag.style.display='block';
  c.tag.style.transform=`translate(${(v3.x+1)/2*innerWidth}px,${(1-v3.y)/2*innerHeight}px) translate(-50%,-100%)`;});}
function step(now){
  const dt=Math.min((now-last)/1000,0.05);last=now;t+=dt;
  if(mode==='play'&&!busy)updatePlay(dt);else actBtn.style.display='none';
  if(mode==='battle'&&!busy)battleUpdate(Math.min(dt,0.05));
  updateTweens(dt);
  ALLC.forEach(c=>{if(!c.visible)return;c.look.lerp(c.lookT,Math.min(1,dt*10));
    c.blinkAt-=dt;if(c.blinkAt<=0){c.blink=0.13;c.blinkAt=2+Math.random()*4;}if(c.blink>0)c.blink-=dt;draw(c);
    const bob=c.walk>0?Math.abs(Math.sin(c.walk*12))*(c.sheet?0.07:0.14*c.scale):Math.sin(t*2+c.home.x)*0.015*c.scale;
    const lie=c.lie||0;c.spr.material.rotation=lie*Math.PI/2;c.spr.position.set(c.pos.x,(c.bh/2+bob)*(1-lie)+(c.bw/2+(c.lieY||0))*lie,c.pos.y);c.sh.position.set(c.pos.x,0.04,c.pos.y);
    if(c===LEE&&Z.name==='test')c.spr.material.opacity=invuln>0?0.5+0.5*Math.abs(Math.sin(t*12)):1;});
  crystal.rotation.y+=dt;crystal.position.y=1.4+Math.sin(t*2)*0.12;portalA.rotation.z+=dt*0.8;archGlow.material.opacity=0.3+Math.sin(t*2.5)*0.1;
  if(mode==='title'){const a=0.6*Math.sin(t*0.1);camera.position.set(Math.sin(a)*26,9,6+Math.cos(a)*22);camera.lookAt(0,1.5,-8);}
  else if(cine.active){cineStep(dt);drawTags();}
  else{camTgt.lerp(v3.set(LEE.pos.x,1.2,LEE.pos.y),Math.min(1,dt*8));
    const want=CAMD[settings.camera];let dist=want;const cp=Math.cos(pitch),sp=Math.sin(pitch);
    for(;dist>1.6;dist-=0.25){if(!camBlocked(camTgt.x+Math.sin(yaw)*cp*dist,camTgt.y+sp*dist,camTgt.z+Math.cos(yaw)*cp*dist))break;}
    curDist=dist<curDist?dist:curDist+(dist-curDist)*Math.min(1,dt*3);
    camera.position.set(camTgt.x+Math.sin(yaw)*cp*curDist,camTgt.y+sp*curDist,camTgt.z+Math.cos(yaw)*cp*curDist);camera.lookAt(camTgt);
    drawTags();
    if(mode!=='title')drawMini();}
  renderer.render(scene,camera);
  requestAnimationFrame(step);
}
let camUsed=false;
G=freshState();applySettings();setRun(false);updateMoney();showTitle();
requestAnimationFrame(step);
})();
