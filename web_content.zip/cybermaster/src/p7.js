
/* =====================================================================
   STORY — Chunk 1: Opening Dream
   All spoken lines are in the SCRIPT block below. Lines marked (given)
   are Lee's exact wording; the rest are placeholders to be replaced.
   ===================================================================== */
const SCRIPT={
  ash_river:"Where the hell am I? How did I get here?",                       // given
  matt_gates:"I was catching some Z's. What is this place?",                   // given
  lee_forest:"Did I fall out of bed and die or something?",                    // given
  lee_questions:["Hey! Who are you? Where is this place?"],                    // placeholder
  man_reply:"…",                                                               // placeholder (no line given)
  ash_mean:["What are you looking at, shorty?"],                               // placeholder
  sam_reply:"N-nothing…",                                                      // placeholder
  lee_defends:"Hey. Leave him alone.",                                         // placeholder
  ash_back:"Tch.",                                                             // placeholder
  matt_scream:"AAAAAAAAAHHHH!!!",                                              // placeholder wording
  man_destiny:["You were all brought here for a reason.","You are destined to save this world from the Cybermaster."], // placeholder wording
  matt_joke:"The Cybermaster? What, like the master of cyber sex?",            // placeholder wording
  man_saber:"Lee. This is the Cyber Saber. It is yours now.",                  // placeholder
  ash_annoyed:"Why does HE get the sword?",                                    // placeholder
  voltix_enter:"So these are the new Destined.",                               // placeholder
  tut_start:["Lee, listen to me. Each of you acts when your gauge fills.","When a gauge is full, time stops while you choose. Start with Attack."], // placeholder
  tut_attack:["Good. The saber can focus cyber energy. Use Special."],          // placeholder
  tut_special:["That is Voltix. He was Destined once, before you… and he made the wrong choice.","He is about to strike. Defend!"], // placeholder
  voltix_finish:"Is that all the new Destined can do?",                        // placeholder
  mum:"LEE! Get out of that bed right now, or I'm coming up there with the wooden spoon!" // placeholder wording
};

/* ---------- zone switching ---------- */
function setZone(name){Z=zones[name];Object.values(zones).forEach(z=>{z.group.visible=(z===Z);});
  scene.background=new THREE.Color(Z.sky);scene.fog=new THREE.Fog(Z.sky,Z.fog[0],Z.fog[1]);
  LEE.zone=name;ALLC.forEach(refreshChar);lastArea='';$('area').textContent=areaName();
  $('money').classList.toggle('hidden',name!=='test');}
function buildZone(name,opt,fn){const z=zone(name,opt),prev=BZ;BZ=z;fn(z);BZ=prev;return z;}
const V=(x,y,z)=>({x,y,z});

/* ---------- Scene 2: river ---------- */
buildZone('river',{sky:0xe9eef2,fog:[5,32],bounds:[-40,40,-40,40]},z=>{
  groundPlane(0x7fa06a,120);
  const water=new THREE.Mesh(new THREE.PlaneGeometry(120,7),new THREE.MeshLambertMaterial({color:0x5b9bd0,emissive:0x1a3a58}));water.rotation.x=-Math.PI/2;water.position.set(0,0.05,-4.5);BZ.group.add(water);
  flat(120,1.1,0,-0.6,0x8a7a5a,0.03);flat(120,1.1,0,-8.4,0x8a7a5a,0.03);
  for(let i=0;i<14;i++){const x=-24+i*3.7;add(new THREE.DodecahedronGeometry(0.3+(i%3)*0.18,0),0x9aa0a8,x,0.2,-0.8-(i%2)*0.5);
    add(new THREE.CylinderGeometry(0.04,0.04,1+(i%3)*0.3,4),0x6f8f3a,x+1.4,0.5,-0.4);}
  [[-12,6],[-6,9],[7,8],[14,5],[-15,-14],[-4,-15],[9,-13],[18,-12]].forEach(([x,zz],i)=>tree(x,zz,0.9+(i%3)*0.2));
});
/* ---------- Scene 3: city gates ---------- */
buildZone('gates',{sky:0xd6dae3,fog:[8,42],bounds:[-40,40,-40,40]},z=>{
  groundPlane(0x6f7480,120);flat(8,30,0,6,0x8a8f99,0.03);
  box(26,9,2,-17,4.5,-8,0x555a66,false);box(26,9,2,17,4.5,-8,0x555a66,false);box(8,2,2,0,8,-8,0x555a66,false);
  [-5.6,5.6].forEach(x=>box(3.2,12,3.2,x,6,-8,0x4a4f5a,false));
  for(let i=-14;i<=14;i++){if(Math.abs(i)<3)continue;box(1,1,2.2,i*2,9.5,-8,0x4a4f5a,false);}
  const glow=new THREE.Mesh(new THREE.PlaneGeometry(8,7),new THREE.MeshBasicMaterial({color:0xfff6dc,transparent:true,opacity:0.2}));glow.position.set(0,3.5,-9);BZ.group.add(glow);z.glow=glow;
  z.doors=[-4,4].map(px=>{const p=new THREE.Group();p.position.set(px,3.5,-7.2);BZ.group.add(p);
    const d=new THREE.Mesh(new THREE.BoxGeometry(4,7,0.5),mat(0x3b2a1e));d.position.x=px<0?2:-2;d.castShadow=true;p.add(d);
    const band=new THREE.Mesh(new THREE.BoxGeometry(4,0.3,0.55),mat(0x2a2a2a));band.position.set(d.position.x,1.8,0);p.add(band);
    const band2=band.clone?band.clone():new THREE.Mesh(new THREE.BoxGeometry(4,0.3,0.55),mat(0x2a2a2a));band2.position.set(d.position.x,-1.8,0);p.add(band2);return p;});
});
/* ---------- Scene 4: desert ---------- */
buildZone('desert',{sky:0xf2dfb8,fog:[12,58],bounds:[-40,40,-40,40]},z=>{
  groundPlane(0xe3c98c,160);
  [[-10,-12,6],[8,-16,8],[18,-6,5],[-20,-4,7],[2,-28,10],[-14,10,5],[14,12,6]].forEach(([x,zz,r])=>{const d=add(new THREE.SphereGeometry(r,12,6),0xd9bd7c,x,0,zz);d.scale.y=0.3;});
  const sunM=new THREE.Mesh(new THREE.SphereGeometry(4,16,10),new THREE.MeshBasicMaterial({color:0xfff4c0,fog:false}));sunM.position.set(22,30,-70);BZ.group.add(sunM);
});
/* ---------- Scene 5–8: forest, maze and the Sand Hills clearing ---------- */
const FOREST=buildZone('forest',{sky:0xdfe7df,fog:[9,42],bounds:[-22,22,-42.5,40.5],hideMapWalls:true},z=>{
  groundPlane(0x5d7d46,170);
  flat(24,22,0,29,0x6b8a50,0.03);
  function hedge(x0,z0,x1,z1){const h=x0===x1,len=h?Math.abs(z1-z0):Math.abs(x1-x0),cx=(x0+x1)/2,cz=(z0+z1)/2;
    box(h?1.2:len+1.2,3,h?len+1.2:1.2,cx,1.5,cz,0x2f5a2a);
    const n=Math.max(1,Math.round(len/3));for(let i=0;i<n;i++){const f=(i+0.5)/n;const px=h?x0:x0+(x1-x0)*f,pz=h?z0+(z1-z0)*f:z0;
      add(new THREE.IcosahedronGeometry(1.35,0),0x3f7a36,px,3.2,pz,false);}}
  // start area and clearing boundaries
  hedge(-12,18,-12,40);hedge(12,18,12,40);hedge(-12,40,12,40);
  hedge(-12,-42,-12,-18);hedge(12,-42,12,-18);hedge(-12,-42,12,-42);
  // fixed maze (seeded so it's the same every time)
  const MC=7,MR=6,CS=6,MX=-21,MZ=-18;let seed=20260929;const r=()=>(seed=(seed*16807)%2147483647)/2147483647;
  const east=[...Array(MC)].map(()=>Array(MR).fill(true)),south=[...Array(MC)].map(()=>Array(MR).fill(true)),seen=[...Array(MC)].map(()=>Array(MR).fill(false));
  const stack=[[3,MR-1]];seen[3][MR-1]=true;
  while(stack.length){const [c,rw]=stack[stack.length-1];
    const nb=[[c+1,rw],[c-1,rw],[c,rw+1],[c,rw-1]].filter(([a,b])=>a>=0&&a<MC&&b>=0&&b<MR&&!seen[a][b]);
    if(!nb.length){stack.pop();continue;}const [a,b]=nb[Math.floor(r()*nb.length)];
    if(a>c)east[c][rw]=false;else if(a<c)east[a][rw]=false;else if(b>rw)south[c][rw]=false;else south[c][b]=false;
    seen[a][b]=true;stack.push([a,b]);}
  for(let c=0;c<MC;c++){if(c!==3){hedge(MX+c*CS,MZ,MX+(c+1)*CS,MZ);hedge(MX+c*CS,MZ+MR*CS,MX+(c+1)*CS,MZ+MR*CS);}}
  hedge(MX,MZ,MX,MZ+MR*CS);hedge(MX+MC*CS,MZ,MX+MC*CS,MZ+MR*CS);
  for(let c=0;c<MC;c++)for(let rw=0;rw<MR;rw++){
    if(c<MC-1&&east[c][rw])hedge(MX+(c+1)*CS,MZ+rw*CS,MX+(c+1)*CS,MZ+(rw+1)*CS);
    if(rw<MR-1&&south[c][rw])hedge(MX+c*CS,MZ+(rw+1)*CS,MX+(c+1)*CS,MZ+(rw+1)*CS);}
  // start-area trees and the tutorial marker
  [[-8,36],[-5,38],[6,37],[9,34],[-9,24],[8,22]].forEach(([x,zz])=>tree(x,zz,1));
  z.marker=add(new THREE.OctahedronGeometry(0.5,0),new THREE.MeshLambertMaterial({color:0x7cf5ff,emissive:0x2a8fa0,flatShading:true}),4,1,26,false);circ(4,26,0.5);
  // Sand Hills clearing
  const sand=new THREE.Mesh(new THREE.CircleGeometry(10,32),mat(0xd9c48f));sand.rotation.x=-Math.PI/2;sand.position.set(0,0.04,-30);sand.receiveShadow=true;BZ.group.add(sand);
  [[-8,-36,2.4],[7,-37,2.8],[-9,-24,1.6],[9,-25,1.8]].forEach(([x,zz,rr])=>{const d=add(new THREE.SphereGeometry(rr,10,6),0xcdb57a,x,0,zz);d.scale.y=0.4;});
  z.label=()=>LEE.pos.y>18?'Forest':LEE.pos.y>-18?'Forest maze':'Sand Hills';
});
/* ---------- Scene 9: bedroom ---------- */
const BED=buildZone('bedroom',{sky:0x1a1c24,fog:[20,40],bounds:[-3.6,3.6,-3.6,3.6]},z=>{
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(8,8),mat(0x8a6a4a));fl.rotation.x=-Math.PI/2;fl.receiveShadow=true;BZ.group.add(fl);
  const wm=new THREE.MeshLambertMaterial({color:0xc9d6e8});
  [[0,-4,0],[-4,0,Math.PI/2],[4,0,-Math.PI/2],[0,4,Math.PI]].forEach(([x,zz,r])=>{const p=new THREE.Mesh(new THREE.PlaneGeometry(8,4),wm);p.position.set(x,2,zz);p.rotation.y=r;BZ.group.add(p);});
  box(2.2,0.5,3.6,-2.2,0.25,-1.6,0x6b4a30,false);box(2,0.3,3.4,-2.2,0.6,-1.6,0xf4f1e8,false);
  box(2.06,0.14,2.3,-2.2,0.82,-1.0,0x4a7fd6,false);box(1.4,0.26,0.6,-2.2,0.88,-3.0,0xffffff,false);
  box(2,1.4,0.06,1,2.3,-3.96,new THREE.MeshLambertMaterial({color:0xfff4c0,emissive:0xb8a060}),false,false);
  box(1.8,0.9,0.8,2.5,0.45,-3.3,0x8a5a3a,false);box(0.06,2.4,1.2,3.96,1.2,1.5,0x6b4a30,false,false);
  const light=new THREE.PointLight(0xffe7b0,0.8,12);light.position.set(1,2.6,-2.5);BZ.group.add(light);
  const saber=new THREE.Group();saber.position.set(-1.5,0.98,-0.3);saber.rotation.y=0.5;BZ.group.add(saber);
  const blade=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.04,1.5),new THREE.MeshLambertMaterial({color:0x9ff6ff,emissive:0x2a9fb0}));blade.position.z=-0.55;saber.add(blade);
  const guard=new THREE.Mesh(new THREE.BoxGeometry(0.42,0.08,0.1),mat(0x3a3f4a));guard.position.z=0.22;saber.add(guard);
  const hilt=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.08,0.4),mat(0x22252c));hilt.position.z=0.47;saber.add(hilt);
});

/* ---------- story cast ---------- */
const S={
  ash:makeChar({id:'s_ash',name:'Ash',col:'#8a4fd6',tagCol:'#c9a2ff',zone:'river',x:0,z:1.5,sheet:ASH_SHEET}),
  matt:makeChar({id:'s_matt',name:'Matt',col:'#3fae5a',tagCol:'#ffd27a',zone:'gates',x:0,z:-1,sheet:MATT_SHEET}),
  sam:makeChar({id:'s_sam',name:'Sam',col:'#44474f',tagCol:'#c7cbd4',sheet:SAM_SHEET,zone:'desert',x:0,z:0}),
  man:makeChar({id:'s_man',name:'Mysterious man',col:'#8a8fa8',tagCol:'#d8dcef',zone:'forest',x:0,z:-34,scale:1.2,sheet:MAN_SHEET}),
  voltix:makeChar({id:'s_voltix',name:'Voltix',col:'#8b1a1a',tagCol:'#ffb0a0',zone:'forest',x:0,z:-44,scale:1.25,hidden:true,sheet:VOLTIX_SHEET})
};
ALLC.push(...Object.values(S));
WHO.man=()=>S.man;WHO.voltix=()=>S.voltix;WHO.mum=()=>({name:'Mum',col:'#f4b6c2'});
function placeChar(c,x,z,fx=0,fz=1,zoneName){if(zoneName)c.zone=zoneName;c.pos.set(x,z);c.lookT.set(fx,fz);c.look.set(fx,fz);c.hidden=false;c.walk=0;c.spr.material.opacity=1;refreshChar(c);}
function face(c,x,z){c.lookT.set(x,z).normalize();}
function faceTo(c,o){face(c,o.pos.x-c.pos.x,o.pos.y-c.pos.y);}

/* ---------- cutscene tools ---------- */
const wait=s=>new Promise(r=>setTimeout(r,s*1000));
const tweens=[];
function walkTo(c,x,z,speed=2.2){return new Promise(res=>tweens.push({k:'walk',c,x,z,speed,res}));}
function fadeTo(c,to,dur){return new Promise(res=>tweens.push({k:'fade',c,from:c.spr.material.opacity,to,dur,t:0,res}));}
function lieTo(c,to,dur){return new Promise(res=>tweens.push({k:'lie',c,from:c.lie||0,to,dur,t:0,res}));}
function animate(dur,fn){return new Promise(res=>tweens.push({k:'fn',dur,t:0,fn,res}));}
function updateTweens(dt){for(let i=tweens.length-1;i>=0;i--){const w=tweens[i];let done=false;
  if(w.k==='walk'){const c=w.c,dx=w.x-c.pos.x,dz=w.z-c.pos.y,d=Math.hypot(dx,dz);
    if(d<0.05){c.walk=0;done=true;}else{const s=Math.min(d,w.speed*dt);c.pos.x+=dx/d*s;c.pos.y+=dz/d*s;c.lookT.set(dx,dz).normalize();c.walk+=dt*(w.speed>4?1.6:1);}}
  else{w.t+=dt;const k=Math.min(1,w.t/w.dur);if(w.k==='fade')w.c.spr.material.opacity=w.from+(w.to-w.from)*k;else if(w.k==='lie')w.c.lie=w.from+(w.to-w.from)*k;else w.fn(k);done=k>=1;}
  if(done){tweens.splice(i,1);w.res();}}}
const cine={active:false,pc:V(0,5,10),lc:V(0,0,0),p0:V(0,0,0),l0:V(0,0,0),p1:V(0,0,0),l1:V(0,0,0),t:0,dur:0,shake:0};
function shot(p,l,dur=0){cine.active=true;if(dur>0){cine.p0=Object.assign({},cine.pc);cine.l0=Object.assign({},cine.lc);cine.p1=p;cine.l1=l;cine.t=0;cine.dur=dur;}else{cine.pc=Object.assign({},p);cine.lc=Object.assign({},l);cine.dur=0;}}
function cineStep(dt){if(cine.dur>0){cine.t+=dt;const k=Math.min(1,cine.t/cine.dur),e=k*k*(3-2*k);
    ['x','y','z'].forEach(a=>{cine.pc[a]=cine.p0[a]+(cine.p1[a]-cine.p0[a])*e;cine.lc[a]=cine.l0[a]+(cine.l1[a]-cine.l0[a])*e;});if(k>=1)cine.dur=0;}
  const sh=cine.shake?()=>rnd(-cine.shake,cine.shake):()=>0;
  camera.position.set(cine.pc.x+sh(),cine.pc.y+sh(),cine.pc.z+sh());camera.lookAt(cine.lc.x,cine.lc.y,cine.lc.z);
  yaw=Math.atan2(cine.pc.x-cine.lc.x,cine.pc.z-cine.lc.z);}
function sayAll(nodes){return new Promise(r=>startDialog(nodes,()=>r(),{noSkip:true}));}
const say=(who,text)=>sayAll([{who,text}]);
const mistIn=async()=>{$('mist').classList.add('on');await wait(1.9);};
const mistOut=async()=>{$('mist').classList.remove('on');await wait(1.9);};
async function flash(){const m=$('mist');m.style.transition='opacity .12s';m.classList.add('on');await wait(0.15);m.classList.remove('on');await wait(0.35);m.style.transition='';}
function hudFor(play){$('hud').classList.toggle('hidden',!play);$('devBtn').classList.toggle('hidden',!devOn||Z.name!=='test');if(!play){actBtn.style.display='none';$('tut').classList.remove('open');}}

/* ---------- Scene 1: opening credits ---------- */
async function credits(){const el=$('credits'),ln=$('credLine');el.classList.add('open');
  const show=async(html,hold)=>{ln.innerHTML=html;await wait(0.1);ln.classList.add('show');await wait(1.2+hold);ln.classList.remove('show');await wait(1.3);};
  await wait(1);
  await show('Developed by Vertex Multimedia',1.4);
  await show('Powered by Claude AI',1.4);
  await show('Written and created by<br>L. M. Janes and Edgar Foxx',1.8);
  ln.innerHTML='<span class="logo">CYBERMASTER</span><span class="dd">Dream of Destiny</span>';await wait(0.1);ln.classList.add('show');
  await wait(8);
  $('mist').classList.add('on');await wait(2);ln.classList.remove('show');el.classList.remove('open');}

/* ---------- New Game ---------- */
function freshStory(){const s=freshState();s.zone='forest';s.money=0;s.inv={};s.members=['lee'];s.party.lee.gear={weapon:null,armour:null};
  s.pos=[0,30];s.look=[0,-1];s.story={chunk:1,stage:'forest',tut:0,marker:false};return s;}
function startStory(){closeMenu();G=freshStory();setRun(false);dirty=false;mode='cutscene';hudFor(false);
  $('title').classList.add('hidden');tagsEl.classList.remove('hidden');playOpening().catch(e=>console.error(e));}
function forestSetup(){placeChar(S.man,0,-34,0,1,'forest');['ash','sam','matt'].forEach(k=>{S[k].zone='forest';S[k].hidden=true;refreshChar(S[k]);});
  S.voltix.hidden=true;refreshChar(S.voltix);FOREST.marker.visible=true;}
async function playOpening(){
  await credits();
  // Scene 2 — Ash at the river
  setZone('river');LEE.hidden=true;refreshChar(LEE);placeChar(S.ash,0,1.5,0,1,'river');
  shot(V(0,2.6,8.5),V(0,1.2,0.5));await mistOut();await wait(0.6);
  face(S.ash,-1,0.3);await wait(0.9);face(S.ash,1,0.3);await wait(0.9);face(S.ash,0,1);await wait(0.4);
  await say('ash',SCRIPT.ash_river);
  walkTo(S.ash,12,3,2.4);await wait(2.2);await mistIn();
  // Scene 3 — Matt at the city gates
  setZone('gates');placeChar(S.matt,0,-1,0,1,'gates');zones.gates.doors.forEach(d=>d.rotation.y=0);zones.gates.glow.material.opacity=0.2;
  shot(V(0,3,9.5),V(0,3,-4));await mistOut();await wait(0.6);
  face(S.matt,-0.5,1);await wait(0.6);
  await say('matt',SCRIPT.matt_gates);
  face(S.matt,0,-1);cine.shake=0.06;
  animate(2.8,k=>{const e=k*k*(3-2*k);zones.gates.doors[0].rotation.y=-1.35*e;zones.gates.doors[1].rotation.y=1.35*e;zones.gates.glow.material.opacity=0.2+0.8*e;});
  await wait(1.8);cine.shake=0;face(S.matt,0,1);await wait(0.3);
  walkTo(S.matt,10,13,7.5);await wait(1.2);await mistIn();
  // Scene 4 — Sam in the desert
  setZone('desert');placeChar(S.sam,0,0,0,1,'desert');shot(V(0,2.6,8),V(0,1.3,0));await mistOut();await wait(0.8);
  for(const [x,zz] of [[-1,0.2],[1,0.2],[0,-1],[0,1]]){face(S.sam,x,zz);await wait(1.1);}
  await wait(0.5);await mistIn();
  // Scene 5 — Lee in the forest
  setZone('forest');forestSetup();LEE.hidden=false;LEE.pos.set(0,30);LEE.lie=1;LEE.lieY=0;LEE.lookT.set(0,1);LEE.look.set(0,1);refreshChar(LEE);
  shot(V(2.4,1.6,33.5),V(0,0.4,30));await mistOut();await wait(1.2);
  shot(V(0,2.3,35.5),V(0,1.2,30),1.6);await lieTo(LEE,0,1.2);await wait(0.3);
  face(LEE,-1,0.2);await wait(0.8);face(LEE,1,0.2);await wait(0.8);face(LEE,0,1);await wait(0.3);
  await say('lee',SCRIPT.lee_forest);
  face(LEE,0,-1);beginForestPlay();
}

/* ---------- Scene 5 tutorial: movement, interaction, menu (no battles) ---------- */
const TUT=[
  {text:()=>TOUCH?'Move: drag on the left side of the screen.':'Move: W A S D or the arrow keys.',done:()=>tutMoved>3},
  {text:()=>TOUCH?'Look around: drag on the right side of the screen.':'Look around: J / L, or drag on the right side.',done:()=>camUsed},
  {text:()=>TOUCH?'Tap Walk to switch to running.':'Press R to switch between walking and running.',done:()=>state.run},
  {text:()=>'Walk to the glowing stone and tap the button that appears.',done:()=>G.story.marker},
  {text:()=>TOUCH?'Open the menu with ❚❚, then choose Resume.':'Open the menu with Esc, then choose Resume.',done:()=>tutMenuDone}
];
let tutMoved=0,tutMenuOpened=false,tutMenuDone=false,tutLast=null;
window.__tutPause=()=>{if(G&&G.story&&G.story.stage==='forest'&&G.story.tut===4)tutMenuOpened=true;};
window.__tutResume=()=>{if(tutMenuOpened)tutMenuDone=true;};
function tutShow(){const el=$('tut'),i=G.story.tut;
  if(i<TUT.length){el.firstElementChild.textContent='Tutorial '+(i+1)+'/'+TUT.length;$('tutText').textContent=TUT[i].text();}
  else{el.firstElementChild.textContent='Objective';$('tutText').textContent='Find a way through the forest.';}
  el.classList.add('open');}
function beginForestPlay(){cine.active=false;camTgt.set(LEE.pos.x,1.2,LEE.pos.y);curDist=CAMD[settings.camera];pitch=0.34;
  tutMoved=0;tutMenuOpened=false;tutMenuDone=false;tutLast=null;camUsed=false;setRun(false);
  G.story.stage='forest';mode='play';hudFor(true);tutShow();hintShown=true;updateHint();}
FOREST.update=dt=>{if(!G||!G.story||G.story.stage!=='forest')return;
  if(tutLast)tutMoved+=Math.hypot(LEE.pos.x-tutLast.x,LEE.pos.y-tutLast.y);tutLast={x:LEE.pos.x,y:LEE.pos.y};
  const i=G.story.tut;if(i<TUT.length&&TUT[i].done()){G.story.tut++;touch();sfx('select');note(i+1<TUT.length?'Done!':'Tutorial complete','gold');tutShow();}
  FOREST.marker.rotation.y+=dt*1.2;
  if(LEE.pos.y<-22.5&&Math.abs(LEE.pos.x)<11)playClearing().catch(e=>console.error(e));};
INTERACT.push({zone:'forest',x:4,z:26,r:1.9,label:'Examine',fn:()=>startDialog([{who:'Glowing stone',text:'The stone pulses with a soft light. (Tutorial marker.)'}],()=>{G.story.marker=true;})});

/* ---------- Scenes 6–8: the clearing, the mysterious man, Voltix ---------- */
async function playClearing(){
  if(G.story.stage!=='forest')return;G.story.stage='clearing';mode='cutscene';stopJoy();hudFor(false);setRun(false);LEE.walk=0;
  face(S.man,0,1);
  shot(V(LEE.pos.x+4,3,LEE.pos.y+5),V(LEE.pos.x,1.2,LEE.pos.y));shot(V(6,3,-24),V(0,1.3,-30),2.2);
  await walkTo(LEE,0,-27.5,2.4);faceTo(LEE,S.man);await wait(0.4);
  await sayAll([...SCRIPT.lee_questions.map(t=>({who:'lee',text:t})),{who:'man',text:SCRIPT.man_reply}]);
  // Ash and Sam arrive from different directions
  placeChar(S.ash,-11.5,-31,1,0,'forest');placeChar(S.sam,11.5,-31,-1,0,'forest');
  shot(V(0,4.2,-19),V(0,1.2,-29.5),1.2);
  faceTo(LEE,S.ash);await Promise.all([walkTo(S.ash,-3.2,-29.6,2.6),walkTo(S.sam,3.2,-29.6,2.1)]);
  faceTo(S.ash,S.sam);faceTo(S.sam,S.ash);faceTo(LEE,S.ash);await wait(0.3);
  await sayAll([...SCRIPT.ash_mean.map(t=>({who:'ash',text:t})),{who:'sam',text:SCRIPT.sam_reply}]);
  faceTo(LEE,S.ash);await sayAll([{who:'lee',text:SCRIPT.lee_defends},{who:'ash',text:SCRIPT.ash_back}]);
  // Matt enters
  placeChar(S.matt,0,-19.5,0,-1,'forest');[LEE,S.ash,S.sam,S.man].forEach(c=>faceTo(c,S.matt));
  walkTo(S.matt,0.2,-25,5.5);await wait(1);cine.shake=0.12;
  await say('matt',SCRIPT.matt_scream);cine.shake=0;
  // Scene 7 — the mysterious man
  [LEE,S.ash,S.sam,S.matt].forEach(c=>faceTo(c,S.man));shot(V(0,2.8,-23.5),V(0,1.5,-33),1.2);await wait(1.2);
  await sayAll(SCRIPT.man_destiny.map(t=>({who:'man',text:t})));
  await say('matt',SCRIPT.matt_joke);
  await walkTo(S.man,0,-29.3,1.4);faceTo(S.man,LEE);
  await say('man',SCRIPT.man_saber);
  giveSaber();sfx('win');note('Received: Cyber Saber','gold');await wait(1);
  faceTo(S.ash,LEE);await say('ash',SCRIPT.ash_annoyed);
  await walkTo(S.man,0,-31.5,1);face(S.man,0,1);await fadeTo(S.man,0,2.2);S.man.hidden=true;refreshChar(S.man);S.man.spr.material.opacity=1;
  await wait(0.6);
  // Scene 8 — Voltix attacks
  await flash();placeChar(S.voltix,0,-40.5,0,1,'forest');[LEE,S.ash,S.sam,S.matt].forEach(c=>faceTo(c,S.voltix));
  shot(V(-5,3,-26.5),V(0,2,-36),1);cine.shake=0.05;await walkTo(S.voltix,0,-35.5,3.2);cine.shake=0;
  await say('voltix',SCRIPT.voltix_enter);
  await flash();
  G.members=['lee','sam','ash','matt'];healAll();G.story.stage='voltix';
  startBattle({group:['voltix'],c:S.voltix,boss:true},{tutorial:true,
    onStart:()=>startDialog(SCRIPT.tut_start.map(t=>({who:'man',text:t})),null,{noSkip:true})});
}
function giveSaber(){const m=G.party.lee;m.gear.weapon='cybersaber';G.story.saber=true;}
function tutAdvance(c){const T=B.tut;
  if(T.step===1&&c.type==='attack'){T.step=2;T.pending=SCRIPT.tut_attack.map(t=>({who:'man',text:t}));}
  else if(T.step===2&&c.type==='ability'&&ABIL[c.ab].kind==='special'){T.step=3;T.pending=SCRIPT.tut_special.map(t=>({who:'man',text:t}));}
  else if(T.step===3&&c.type==='defend'){T.step=4;T.pending=[{who:'voltix',text:SCRIPT.voltix_finish}];}}
async function tutFinish(){B.choosing=null;bCmd.innerHTML='';msg('Voltix unleashes a storm of lightning!');sfx('bad');
  B.party.forEach(p=>{p.m.hp=0;p.m.ko=true;});updateBattleUI();
  await wait(1.8);$('mist').classList.add('on');await wait(2);
  closeBattle();mode='cutscene';G.members=['lee'];healAll();await playWake();}

/* ---------- Scene 9: Lee wakes up ---------- */
async function playWake(){
  G.story.stage='bedroom';setZone('bedroom');
  ['ash','sam','matt','voltix'].forEach(k=>{S[k].hidden=true;refreshChar(S[k]);});
  LEE.pos.set(-2.2,-1.9);LEE.lie=1;LEE.lieY=0.72;LEE.lookT.set(0,1);LEE.look.set(0,1);LEE.noTag=true;refreshChar(LEE);
  shot(V(1.4,2.4,2.2),V(-2,0.9,-1.4));
  await wait(0.8);$('mist').classList.remove('on');await wait(2.4);
  shot(V(0.6,1.9,0.9),V(-1.5,0.9,-0.4),2.2);await wait(2.6);
  shot(V(1.4,2.4,2.2),V(-2,0.9,-1.4),1.2);await wait(1.2);
  cine.shake=0.05;await say('mum',SCRIPT.mum);cine.shake=0;
  await wait(0.6);LEE.noTag=false;G.story.chunk1=true;
  $('mist').classList.add('on');await wait(2);
  enterSandTown(false);touch();
  $('mist').classList.remove('on');await wait(1.2);note('Chunk 1 complete','gold');}

/* ---------- Continue from a story save ---------- */
function resumeStory(save){burst(()=>{
  G=Object.assign(freshStory(),save);MEMBERS.forEach(id=>{G.party[id].status={};});
  if(G.story.stage==='town'){LEE.pos.set(G.pos[0],G.pos[1]);LEE.lookT.set(G.look[0],G.look[1]);LEE.look.copy(LEE.lookT);yaw=G.yaw||0;
    $('title').classList.add('hidden');tagsEl.classList.remove('hidden');closeMenu();closeDialogSilently();enterSandTown(true);dirty=false;return;}
  setZone('forest');forestSetup();LEE.hidden=false;LEE.lie=0;LEE.noTag=false;refreshChar(LEE);
  LEE.pos.set(G.pos[0],G.pos[1]);LEE.lookT.set(G.look[0],G.look[1]);LEE.look.copy(LEE.lookT);yaw=G.yaw||0;
  $('title').classList.add('hidden');tagsEl.classList.remove('hidden');closeMenu();closeDialogSilently();
  beginForestPlay();dirty=false;});}
