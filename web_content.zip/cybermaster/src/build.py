"""Rebuild index.html from the source parts and sprite sheets.
Run from the project folder:  python3 src/build.py"""
import base64, os
here=os.path.dirname(os.path.abspath(__file__));root=os.path.dirname(here)
order=['p1','p2','p3','p4','p5','p7','p8','p9','p6']
js=''.join(open(os.path.join(here,p+'.js'),encoding='utf-8').read() for p in order)
for key,fn in [('LEE','lee'),('SAM','sam'),('ASH','ash'),('MATT','matt'),('VOLTIX','voltix'),('MAN','man')]:
    b=base64.b64encode(open(os.path.join(root,'assets','sprites',fn+'_sheet.png'),'rb').read()).decode()
    js=js.replace('__%s_SHEET__'%key,'data:image/png;base64,'+b)
html=open(os.path.join(here,'head.html'),encoding='utf-8').read()+'<script>\n'+js+'</script>\n</body>\n</html>\n'
open(os.path.join(root,'index.html'),'w',encoding='utf-8').write(html)
print('Built index.html',len(html)//1024,'KB')
