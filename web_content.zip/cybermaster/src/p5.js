
/* ================= Battle (ATB, pause-on-ready) ================= */
const B={on:false};
const bEl=$('battle'),bEn=$('bEnemies'),bParty=$('bParty'),bCmd=$('bCmd'),bMsg=$('bMsg');
function gainXp(m,x){const ups=[];m.xp+=x;while(m.xp>=xpNeed(m.lvl)){m.xp-=xpNeed(m.lvl);m.lvl++;
  const b=m.base;b.mhp+=8;b.mmp+=3;b.atk++;b.mag++;b.def++;if(m.lvl%2===0)b.spd++;m.hp+=8;m.mp+=3;m.dp+=3;ups.push(m.lvl);}touch();return ups;}
function startBattle(w,opts={}){
  const types=w.group;B.world=w;B.boss=!!w.boss;B.tut=opts.tutorial?{step:1,pending:null,finishing:false}:null;B.onEnd=opts.onEnd||null;
  const go=()=>burst(()=>{
    B.on=true;mode='battle';B.speed=1;$('bSpeed').textContent='1×';B.over=false;B.acting=0;B.choosing=null;B.ready=[];B.msgT=0;B.target=null;
    B.enemies=types.map((t,i)=>{const d=ENEMIES[t];return {isEnemy:true,type:t,d,name:d.name+(types.filter(x=>x===t).length>1?' '+(i+1):''),hp:d.hp,mhp:d.hp,atk:d.atk,mag:d.mag,def:d.def,spd:d.spd,gauge:rnd(0,50),status:{},alive:true,phase:1};});
    B.party=G.members.map(id=>{const m=G.party[id];m.status={};return {isEnemy:false,m,name:m.name,gauge:m.ko?0:rnd(20,70),defend:false};});
    if(devStatus){const lee=B.party.find(p=>p.m.id==='lee');if(lee&&!lee.m.ko)applyStatus(lee,devStatus);devStatus=null;}
    G.stats.battles++;renderBattle();bEl.classList.add('open');msg(B.boss?'Boss battle!':'Enemies approach!');
    $('bWin').classList.toggle('hidden',!devOn||!!B.tut);$('bLose').classList.toggle('hidden',!devOn||!!B.tut);
    if(opts.onStart)opts.onStart();
  });
  if(w.intro)startDialog(w.intro,go,{noSkip:true});
  else go();
}
function msg(t){bMsg.textContent=t;B.msgT=2.2;}
function renderBattle(){
  bEn.innerHTML='';
  B.enemies.forEach(e=>{const d=document.createElement('div');d.className='enemy'+(e.d.boss?' boss':'');const c=document.createElement('canvas');c.width=128;c.height=160;
    if(e.d.sheet&&e.d.sheet.ready){const S=e.d.sheet;c.width=S.fw;c.height=S.fh;c.getContext('2d').drawImage(S.img,0,0,S.fw,S.fh,0,0,S.fw,S.fh);}else blobArt(c.getContext('2d'),e.d.col,0,0.6,false,true);if(e.d.alpha)c.style.opacity=e.d.alpha;
    const nm=document.createElement('div');nm.className='nm';nm.textContent=e.name;d.append(c,nm);
    if(!e.d.boss){const bar=document.createElement('div');bar.className='bar';const i=document.createElement('i');bar.appendChild(i);d.appendChild(bar);e.bar=i;}
    d.onclick=()=>{if(B.targeting&&B.targeting.side==='enemy'&&e.alive)B.targeting.done(e);};e.el=d;bEn.appendChild(d);});
  $('bossBar').classList.toggle('hidden',!B.boss);if(B.boss){$('bossName').textContent=B.enemies[0].name;}
  bParty.innerHTML='';
  B.party.forEach(p=>{const r=document.createElement('div');r.className='prow';
    r.innerHTML='<div><b></b><small class="lv"></small></div><div><small>HP <span class="hpn"></span></small><div class="bar"><i class="hp"></i></div></div><div><small>MP <span class="mpn"></span></small><div class="bar"><i class="mp"></i></div></div><div><small>ATB</small><div class="bar"><i class="atb"></i></div></div><span class="st"></span>';
    r.querySelector('b').textContent=p.name;r.onclick=()=>{if(B.targeting&&B.targeting.side==='ally'&&B.targeting.ok(p))B.targeting.done(p);};p.el=r;bParty.appendChild(r);});
  updateBattleUI();
}
function updateBattleUI(){
  B.enemies.forEach(e=>{e.el.classList.toggle('dead',!e.alive);if(e.bar)e.bar.style.width=(e.hp/e.mhp*100)+'%';
    e.el.classList.toggle('targetable',!!(B.targeting&&B.targeting.side==='enemy'&&e.alive));});
  if(B.boss){const e=B.enemies[0];$('bossFill').style.width=(e.hp/e.mhp*100)+'%';}
  B.party.forEach(p=>{const m=p.m,r=p.el;r.querySelector('.lv').textContent='Lv '+m.lvl;
    r.querySelector('.hpn').textContent=m.hp+'/'+stat(m,'mhp');r.querySelector('.mpn').textContent=m.mp+'/'+stat(m,'mmp');
    r.querySelector('i.hp').style.width=(m.hp/stat(m,'mhp')*100)+'%';r.querySelector('i.mp').style.width=(m.mp/Math.max(1,stat(m,'mmp'))*100)+'%';
    r.querySelector('i.atb').style.width=p.gauge+'%';r.classList.toggle('ko',m.ko);r.classList.toggle('ready',B.choosing===p);
    r.classList.toggle('targetable',!!(B.targeting&&B.targeting.side==='ally'&&B.targeting.ok(p)));
    r.querySelector('.st').textContent=(m.ko?'KO ':'')+Object.keys(p.status||{}).map(s=>({poison:'Poison',sleep:'Sleep',para:'Paralysis'})[s]).join(' ')+(p.defend?' Defend':'');});
}
function pop(el,text,heal){if(!el)return;const s=document.createElement('span');s.className='pop'+(heal?' heal':'');s.textContent=text;el.appendChild(s);setTimeout(()=>s.remove(),1000);
  if(!heal){el.classList.remove('hit');void el.offsetWidth;el.classList.add('hit');}}
const alive=a=>a.isEnemy?a.alive:!a.m.ko;
function applyStatus(a,s){a.status=a.status||{};a.status[s]=s==='sleep'?6:s==='para'?4:0.001;if(s==='poison')a.status.poisonT=0;}
function hurt(t,dmg){dmg=Math.max(1,Math.round(dmg));
  if(t.isEnemy){t.hp=Math.max(t.d.unbeatable?1:0,t.hp-dmg);if(t.hp===0)t.alive=false;}
  else{if(t.defend)dmg=Math.max(1,Math.round(dmg/2));t.m.hp=Math.max(B.tut&&!B.over?1:0,t.m.hp-dmg);if(t.m.hp===0){t.m.ko=true;t.gauge=0;t.status={};B.ready=B.ready.filter(x=>x!==t);}}
  if(t.status&&t.status.sleep)delete t.status.sleep;
  sfx('hit');pop(t.el,dmg);return dmg;}
function heal(t,v){const m=t.m;v=Math.round(v);m.hp=Math.min(stat(m,'mhp'),m.hp+v);sfx('heal');pop(t.el,'+'+v,true);return v;}
function statOf(a,k){return a.isEnemy?a[k]:stat(a.m,k);}
function physDmg(a,t,power=1){return (statOf(a,'atk')*2.2*power-statOf(t,'def')*1.1+rnd(0,4));}
function magDmg(a,t,ab){let v=statOf(a,'mag')*ab.power+rnd(0,4)-statOf(t,'def')*0.5;
  if(t.isEnemy){if(ab.elem&&t.d.weak&&t.d.weak.includes(ab.elem))v*=1.5;if(ab.elem&&t.d.resist&&t.d.resist.includes(ab.elem))v*=0.5;if(t.d.weakMagic)v*=1.5;}return v;}
function mastery(m,ab){const v=m.mastery[ab]||0;return v>=100?1.2:1;}
function bumpMastery(m,ab){const v=m.mastery[ab]||0;if(v<100){m.mastery[ab]=Math.min(100,v+10);if(m.mastery[ab]===100)note(ABIL[ab].name+' mastered!','gold');}}
function randAlive(list){const l=list.filter(alive);return l[Math.floor(Math.random()*l.length)];}

function battleUpdate(dt){
  if(!B.on||B.over||dlg.open)return;
  if(B.msgT>0){B.msgT-=dt;if(B.msgT<=0&&!B.choosing)bMsg.textContent='';}
  dt*=B.speed;
  if(B.acting>0){B.acting-=dt;if(B.acting<=0)afterAct();updateBattleUI();return;}
  if(B.choosing){updateBattleUI();return;}                        // pause-on-ready: time stops while a command is chosen
  while(B.ready.length){const a=B.ready[0];
    if(!alive(a)){B.ready.shift();continue;}
    if(a.isEnemy)a.cmd=enemyAI(a);
    if(a.cmd){B.ready.shift();const c=a.cmd;a.cmd=null;a.gauge=0;execute(a,c);updateBattleUI();return;}
    openCommand(a);updateBattleUI();return;}
  [...B.enemies,...B.party].forEach(a=>{if(!alive(a))return;const st=a.status||{};
    if(st.poison){st.poisonT=(st.poisonT||0)+dt;if(st.poisonT>=3){st.poisonT=0;const mhp=a.isEnemy?a.mhp:stat(a.m,'mhp');
      const d=Math.max(1,Math.round(mhp*0.05));if(a.isEnemy)a.hp=Math.max(1,a.hp-d);else a.m.hp=Math.max(1,a.m.hp-d);pop(a.el,'☠'+d);}}
    if(st.sleep){st.sleep-=dt;if(st.sleep<=0)delete st.sleep;return;}
    if(st.para){st.para-=dt;if(st.para<=0)delete st.para;return;}
    if(a.gauge<100){a.gauge=Math.min(100,a.gauge+statOf(a,'spd')*dt*4.2);if(a.gauge>=100&&!B.ready.includes(a)){B.ready.push(a);if(!a.isEnemy)a.defend=false;}}});
  updateBattleUI();
}
function enemyAI(e){const t=randAlive(B.party);if(!t)return null;
  if(e.d.boss){if(e.phase===1&&e.hp<e.mhp*0.5){e.phase=2;return {type:'phase'};}
    return e.phase===1?{type:'slam',t}:(Math.random()<0.5?{type:'spray'}:{type:'crush',t});}
  return {type:'eattack',t};}
function execute(a,c){B.acting=0.95;
  const m=a.m;if(B.tut&&m&&m.id==='lee')tutAdvance(c);
  switch(c.type){
    case 'attack':{const t=c.t.alive?c.t:randAlive(B.enemies);if(!t)break;const d=hurt(t,physDmg(a,t));msg(a.name+' attacks '+t.name+' for '+d+'.');break;}
    case 'ability':{const ab=ABIL[c.ab];m.mp-=ab.mp;bumpMastery(m,c.ab);const mm=mastery(m,c.ab);
      if(ab.heal){const t=c.t;if(t.m.ko){msg(ab.name+' can’t reach a knocked-out ally.');break;}const v=heal(t,stat(m,'mag')*ab.heal*mm);msg(a.name+' uses '+ab.name+': '+t.name+' +'+v+' HP.');break;}
      if(ab.target==='all'){let tot=0;B.enemies.filter(alive).forEach(t=>tot+=hurt(t,physDmg(a,t,ab.power*mm)));msg(a.name+' uses '+ab.name+' on every enemy.');break;}
      let t=c.t.alive?c.t:randAlive(B.enemies);if(!t)break;
      if(ab.kind==='magic'){const d=hurt(t,magDmg(a,t,{...ab,power:ab.power*mm}));msg(a.name+' casts '+ab.name+' on '+t.name+' for '+d+'.');}
      else{let tot=0;for(let i=0;i<(ab.hits||1);i++){if(!t.alive)break;tot+=hurt(t,physDmg(a,t,ab.power*mm));}msg(a.name+' uses '+ab.name+' for '+tot+'.');}
      break;}
    case 'item':{const it=ITEMS[c.k];addItem(c.k,-1);const t=c.t;
      if(!itemValid(it,t.m)){msg('The '+it.name+' had no effect.');break;}
      if(it.revive){applyItem(it,t.m);t.gauge=0;sfx('heal');pop(t.el,'Revived',true);msg(t.name+' is revived at '+t.m.hp+' HP.');}
      else if(it.cure){t.status={};msg(t.name+' is cured.');sfx('heal');}
      else{applyItem(it,t.m);sfx('heal');pop(t.el,it.heal?'+'+it.heal:'+'+it.mp+' MP',true);msg(a.name+' uses '+it.name+' on '+t.name+'.');}
      break;}
    case 'defend':a.defend=true;msg(a.name+' defends.');break;
    case 'escape':
      if(B.boss){msg('You can’t escape from this fight!');sfx('bad');break;}
      if(Math.random()<0.55){msg('Got away safely!');B.over=true;G.stats.escapes++;setTimeout(()=>endBattle('escape'),800);}
      else{msg('Couldn’t escape!');sfx('bad');}
      break;
    case 'eattack':{const t=alive(c.t)?c.t:randAlive(B.party);if(!t)break;const d=hurt(t,physDmg(a,t));let s=a.name+' hits '+t.name+' for '+d+'.';
      const inf=a.d.inflict;if(inf&&!t.m.ko&&Math.random()<inf[1]){applyStatus(t,inf[0]);s+=' '+t.name+' is '+({poison:'poisoned',sleep:'asleep',para:'paralysed'})[inf[0]]+'!';}
      msg(s);break;}
    case 'phase':msg('Blob splits and reforms! Its attacks change. (Phase 2)');a.el.classList.add('hit');break;
    case 'slam':{const t=alive(c.t)?c.t:randAlive(B.party);if(!t)break;const d=hurt(t,physDmg(a,t,1.2));msg('Blob slams '+t.name+' for '+d+'.');break;}
    case 'crush':{const t=alive(c.t)?c.t:randAlive(B.party);if(!t)break;const d=hurt(t,physDmg(a,t,1.5));msg('Blob crushes '+t.name+' for '+d+'!');break;}
    case 'spray':{B.party.filter(alive).forEach(t=>{hurt(t,physDmg(a,t,0.7));if(!t.m.ko&&Math.random()<0.3)applyStatus(t,'poison');});msg('Split Spray hits the whole party!');break;}
  }
}
function afterAct(){
  if(B.over)return;
  if(B.tut){if(B.tut.pending){const p=B.tut.pending;B.tut.pending=null;startDialog(p,()=>{if(B.tut&&B.tut.step>=4&&!B.over){B.over=true;tutFinish();}},{noSkip:true});return;}
    if(B.tut.step>=4||B.party.every(p=>p.m.ko)){B.over=true;tutFinish();return;}}
  if(B.enemies.every(e=>!e.alive)){B.over=true;setTimeout(victory,500);return;}
  if(B.party.every(p=>p.m.ko)){B.over=true;setTimeout(gameOver,700);return;}
}
function openCommand(p){B.choosing=p;bMsg.textContent=p.name+' is ready.'+(B.tut&&p.m.id==='lee'?' '+(['','Choose Attack.','Choose Special, then Saber Beam.','Choose Defend.'][B.tut.step]||''):'');cmdRoot(p);}
function cmdBtn(label,sub,on,dis){const b=document.createElement('button');const s=document.createElement('span');s.textContent=label;b.appendChild(s);
  if(sub){const sm=document.createElement('small');sm.textContent=sub;b.appendChild(sm);}b.disabled=!!dis;b.onclick=e=>{e.stopPropagation();sfx('select');on();};return b;}
function cmdPanel(title,btns,grid){bCmd.innerHTML='';const h=document.createElement('h4');h.textContent=title;bCmd.appendChild(h);
  const wrap=document.createElement('div');if(grid)wrap.className='grid';btns.forEach(b=>wrap.appendChild(b));bCmd.appendChild(wrap);const f=bCmd.querySelector('button:not(:disabled)');f&&f.focus({preventScroll:true});}
function cmdRoot(p){B.targeting=null;const m=p.m,kit=KIT[m.id];
  // Voltix tutorial: Lee may only use the command being taught at each step
  const lock=B.tut&&m.id==='lee'&&B.tut.step<4?['','Attack','Special','Defend'][B.tut.step]:null;
  const lk=(b,label)=>{if(lock&&label!==lock){b.disabled=true;b.title='Follow the mysterious man’s guidance';}return b;};
  cmdPanel(p.name,[
    lk(cmdBtn('Attack','',()=>pickTarget(p,'enemy',t=>commit(p,{type:'attack',t}))),'Attack'),
    lk(cmdBtn('Magic','',()=>abilList(p,kit.magic,'Magic')),'Magic'),
    lk(cmdBtn('Special','',()=>abilList(p,kit.special,'Special')),'Special'),
    lk(cmdBtn('Item','',()=>itemList(p)),'Item'),
    lk(cmdBtn('Defend','',()=>commit(p,{type:'defend'})),'Defend'),
    lk(cmdBtn('Escape',B.boss?'Not possible':'',()=>commit(p,{type:'escape'})),'Escape')],true);}
function abilList(p,list,title){cmdPanel(p.name+' · '+title,list.map(k=>{const ab=ABIL[k];const v=p.m.mastery[k]||0;
  return cmdBtn(ab.name,ab.mp+' MP · '+(v>=100?'MAX':v+'%'),()=>pickTarget(p,ab.target==='ally'?'ally':ab.target==='all'?'none':'enemy',t=>commit(p,{type:'ability',ab:k,t}),ab.target==='ally'?(x=>!x.m.ko):null),p.m.mp<ab.mp);})
  .concat([cmdBtn('Back','',()=>cmdRoot(p))]));}
function itemList(p){const ks=Object.keys(G.inv).filter(k=>ITEMS[k].type==='use');
  cmdPanel(p.name+' · Items',ks.map(k=>cmdBtn(ITEMS[k].name,'×'+G.inv[k],()=>pickTarget(p,'ally',t=>commit(p,{type:'item',k,t}),x=>itemValid(ITEMS[k],x.m)))).concat([cmdBtn('Back','',()=>cmdRoot(p))]));}
function pickTarget(p,side,done,ok){
  if(side==='none'){done(null);return;}
  const opts=side==='enemy'?B.enemies.filter(e=>e.alive):B.party.filter(x=>(ok||(()=>true))(x));
  if(!opts.length){bMsg.textContent='No valid target.';return;}
  if(side==='enemy'&&opts.length===1){done(opts[0]);return;}
  B.targeting={side,ok:ok||(()=>true),done:t=>{B.targeting=null;done(t);}};bMsg.textContent='Choose a target.';
  cmdPanel(p.name+' · Target',[cmdBtn('Back','',()=>{B.targeting=null;cmdRoot(p);})]);updateBattleUI();}
function commit(p,c){p.cmd=c;B.choosing=null;B.targeting=null;bCmd.innerHTML='';updateBattleUI();}   // committed commands can’t be changed
function victory(){
  const xp=B.enemies.reduce((s,e)=>s+e.d.xp,0);let money=0;const got=[];
  B.enemies.forEach(e=>{money+=ri(e.d.money[0],e.d.money[1]);(e.d.drops||[]).forEach(([k,ch])=>{if(Math.random()<ch){if(addItem(k,1))got.push(ITEMS[k].name);}});
    if(e.d.guaranteed){addItem(e.d.guaranteed,1);got.push(ITEMS[e.d.guaranteed].name+' (guaranteed)');}});
  G.money+=money;updateMoney();G.stats.wins++;const lines=[];
  B.party.forEach(p=>{const m=p.m;if(m.ko){m.ko=false;m.hp=1;lines.push(m.name+' was knocked out: back at 1 HP, no XP.');}
    else{const ups=gainXp(m,xp);lines.push(m.name+' +'+xp+' XP'+(ups.length?' · Level '+ups[ups.length-1]+'! +'+ups.length*3+' DP':''));}m.status={};});
  if(B.boss)G.flags.bossDown=true;
  B.world.alive=false;setVisible(B.world.c,false);touch();sfx('win');
  bCmd.innerHTML='';bMsg.textContent='Victory!';
  cmdPanel('Rewards',[...[xp+' XP each · '+money+' G',got.length?'Items: '+got.join(', '):'No item drops',...lines].map(t=>{const d=document.createElement('p');d.style.margin='0';d.textContent=t;return d;}),
    cmdBtn('Continue','',()=>endBattle('win'))]);
}
function gameOver(){sfx('bad');bCmd.innerHTML='';bMsg.textContent='';
  const slot=lastSaveSlot();mode='menu';
  openMenu('GAME OVER',[{label:'Load last save',sub:slot?'Slot '+slot:'No saves yet',disabled:!slot,on:()=>{closeBattle();doLoad(slot);}},{label:'Main menu',on:()=>{closeMenu();burst(()=>{closeBattle();showTitle();});}}],'The whole party was defeated.');}
function closeBattle(){B.on=false;bEl.classList.remove('open');bCmd.innerHTML='';}
function endBattle(result){burst(()=>{closeBattle();G.members.forEach(id=>{G.party[id].status={};});mode='play';
  if(result==='escape'){invuln=2.5;const w=B.world;const dx=LEE.pos.x-w.c.pos.x,dz=LEE.pos.y-w.c.pos.y,d=Math.hypot(dx,dz)||1;LEE.pos.x+=dx/d*2;LEE.pos.y+=dz/d*2;resolve(LEE.pos,0.45);note('Escaped · no rewards');}});}
$('bSpeed').onclick=e=>{e.stopPropagation();B.speed=B.speed===1?2:1;$('bSpeed').textContent=B.speed+'×';};
B.hooks={};
$('bWin').onclick=e=>{e.stopPropagation();if(!B.on||B.over)return;B.enemies.forEach(en=>{en.hp=0;en.alive=false;});B.acting=0;B.choosing=null;bCmd.innerHTML='';B.over=true;updateBattleUI();setTimeout(victory,300);};
$('bLose').onclick=e=>{e.stopPropagation();if(!B.on||B.over)return;B.party.forEach(p=>{p.m.hp=0;p.m.ko=true;});B.choosing=null;bCmd.innerHTML='';B.over=true;updateBattleUI();setTimeout(gameOver,300);};
bEl.addEventListener('pointerdown',e=>e.stopPropagation());
