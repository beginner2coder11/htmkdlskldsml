
/* =====================================================================
   SCHOOL — built from Lee's layout (1 world unit = 14 map pixels)
   ===================================================================== */
const SX=(px,py)=>[(px-650)/14,(py-600)/14];
const SR=([x0,y0,x1,y1])=>{const a=SX(x0,y0),b=SX(x1,y1);return [[a[0],a[1]],[b[0],a[1]],[b[0],b[1]],[a[0],b[1]]];};
const ROOMS={
  hall:{r:[118,50,678,330],name:'Dinner Hall',floor:0xd9cdb0,wall:0xe6dcc6,h:3.2},
  corr:{r:[475,340,605,860],name:'Corridor',floor:0xcfc6b0,wall:0xe6dcc6,h:3.2},
  act:{r:[58,392,455,808],name:'Activity Room',floor:0xa0673a,wall:0xe0d2b8,h:3.2},
  play:{r:[628,392,930,790],name:'Playground',floor:0x5a5e66,wall:0x8e949e,h:1.3,out:true},
  class:{r:[975,442,1125,705],name:'Classroom',floor:0xd8c9a8,wall:0xe6dcc6,h:3.2},
  main:{r:[272,868,765,1100],name:'Main House',floor:0xa8703f,wall:0xe0d2b8,h:3.2},
  path:{r:[785,800,1135,945],name:'School Pathway',floor:0xc9c0a8,wall:0x9a8f7a,h:1.1,out:true}
};
// doorways between areas (rects in map pixels, or quads for the two diagonal links)
const LINKS=[
  {r:[505,318,575,352]},{r:[285,318,325,402]},{r:[445,590,485,640]},{r:[595,590,638,640]},
  {r:[335,800,380,878]},{r:[510,850,570,878]},{r:[920,555,985,600]},{r:[1020,695,1060,810]},
  {q:[[640,322],[676,322],[800,400],[760,400]],floor:0xc9c0a8},             // dinner hall ↔ playground (outside path)
  {q:[[725,878],[762,878],[805,822],[782,802]],floor:0xc9c0a8},             // main house ↔ school pathway
  {r:[1128,820,1190,930],floor:0x8e8a80}                                     // entrance gate → Sand Town
];
const linkBox=l=>l.r||[Math.min(...l.q.map(p=>p[0])),Math.min(...l.q.map(p=>p[1])),Math.max(...l.q.map(p=>p[0])),Math.max(...l.q.map(p=>p[1]))];

const SCHOOL=buildZone('school',{sky:0xcfe3f2,fog:[40,110],bounds:[-45,40,-42,37]},z=>{
  z.solids=[];BZ.solids=z.solids;
  groundPlane(0x7f9a62,240);
  z.walk=[];
  Object.values(ROOMS).forEach(R=>{const poly=SR(R.r);z.walk.push(poly);flatPoly(poly,R.floor,0.04);});
  LINKS.forEach(L=>{const poly=L.r?SR(L.r):L.q.map(p=>SX(...p));z.walk.push(poly);flatPoly(poly,L.floor||0xcfc6b0,0.035);});
  // walls along every room edge, with gaps wherever a doorway crosses
  Object.values(ROOMS).forEach(R=>{const [x0,y0,x1,y1]=R.r;
    [[x0,y0,x1,y0],[x1,y0,x1,y1],[x0,y1,x1,y1],[x0,y0,x0,y1]].forEach(([ax,ay,bx,by])=>{
      const horiz=ay===by,lo=horiz?ax:ay,hi=horiz?bx:by,line=horiz?ay:ax;
      const gaps=LINKS.map(linkBox).filter(b=>horiz?(b[1]-6<=line&&b[3]+6>=line):(b[0]-6<=line&&b[2]+6>=line))
        .map(b=>horiz?[b[0],b[2]]:[b[1],b[3]]).filter(([g0,g1])=>g1>lo&&g0<hi).sort((a,b)=>a[0]-b[0]);
      let cur=lo;const segs=[];gaps.forEach(([g0,g1])=>{if(g0>cur)segs.push([cur,g0]);cur=Math.max(cur,g1);});if(cur<hi)segs.push([cur,hi]);
      segs.forEach(([s0,s1])=>{if(s1-s0<4)return;const a=horiz?SX(s0,line):SX(line,s0),b=horiz?SX(s1,line):SX(line,s1);
        const w=horiz?b[0]-a[0]:0.4,d=horiz?0.4:b[1]-a[1];
        box(w,R.h,d,(a[0]+b[0])/2,R.h/2,(a[1]+b[1])/2,R.wall,false);
        box(w+(horiz?0:0.1),0.18,d+(horiz?0.1:0),(a[0]+b[0])/2,R.h+0.09,(a[1]+b[1])/2,R.out?0x6b6f78:0x9a8a70,false,false);});});});
  const at=(px,py)=>SX(px,py);
  const F=(w,h,d,px,py,y,c,solid=true)=>{const [x,zz]=at(px,py);return box(w,h,d,x,y+h/2,zz,c,solid);};
  const plant=(px,py,s=1)=>{const [x,zz]=at(px,py);add(new THREE.CylinderGeometry(0.35*s,0.3*s,0.5*s,8),0x8a5a3a,x,0.25*s,zz);add(new THREE.IcosahedronGeometry(0.6*s,0),0x4f8a3c,x,0.95*s,zz);circ(x,zz,0.4*s);};
  // --- Dinner hall (the gym is upstairs) ---
  F(18,1.1,1.2,360,80,0,0xbfc4cc);F(18,0.15,1.3,360,80,1.1,0x8a8f99,false);                   // serving counter
  [205,340,460,590].forEach(px=>{F(1.2,0.8,8.2,px,238,0,0xb07a45);
    for(let i=0;i<5;i++){const py=185+i*27;[px-24,px+24].forEach(sx=>{const [x,zz]=at(sx,py);add(new THREE.CylinderGeometry(0.28,0.28,0.5,8),0x3a5a9a,x,0.25,zz);});}});
  F(2.4,0.2,3.2,648,110,0,0x8a8f99);for(let i=0;i<6;i++)F(2.4,0.25,0.5,648,90+i*9,i*0.3,0x9aa0a8,false);   // stairs up to the gym
  [[135,305],[665,130],[665,290],[180,95]].forEach(p=>plant(...p));
  // --- Activity room ---
  F(3.8,0.9,2.2,237,488,0,0x3f7a36);F(4,0.12,2.4,237,488,0.9,0x6b4a30,false);                // pool table
  F(1.6,0.8,5.6,112,550,0,0x3b6fb0);F(4,0.8,1.5,348,512,0,0x3b6fb0);F(5.4,0.8,1.8,205,622,0,0x3b6fb0);   // sofas
  [[150,702],[218,702]].forEach(([px,py])=>{const [x,zz]=at(px,py);add(new THREE.CylinderGeometry(1,1,0.1,10),0xc9a27a,x,0.75,zz);add(new THREE.CylinderGeometry(0.12,0.12,0.75,6),0x6b4a30,x,0.37,zz);circ(x,zz,1);});
  F(3.2,0.9,1.8,302,690,0,0x2f6b3a);F(1.6,0.8,3.2,388,680,0,0x3b6fb0);                       // foosball, armchair
  F(4.4,2.2,0.6,143,412,0,0x6b4a30);F(4.4,2.2,0.6,385,412,0,0x6b4a30);F(6,0.9,1,160,778,0,0x8a5a3a);   // shelves / sideboard
  [[75,430],[75,700],[430,440],[430,760]].forEach(p=>plant(...p,0.9));
  // --- Playground ---
  const court=canvasTex(512,720,(g,w,h)=>{g.fillStyle='#5a5e66';g.fillRect(0,0,w,h);g.strokeStyle='#e8e8e8';g.lineWidth=6;
    g.strokeRect(24,24,w-48,h-48);g.beginPath();g.moveTo(24,h/2);g.lineTo(w-24,h/2);g.stroke();
    g.beginPath();g.arc(w/2,h/2,60,0,7);g.stroke();g.beginPath();g.arc(w/2,24,110,0,Math.PI);g.stroke();g.beginPath();g.arc(w/2,h-24,110,Math.PI,0);g.stroke();});
  {const a=at(660,420),b=at(858,760);const c=new THREE.Mesh(new THREE.PlaneGeometry(b[0]-a[0],b[1]-a[1]),new THREE.MeshLambertMaterial({map:court}));c.rotation.x=-Math.PI/2;c.position.set((a[0]+b[0])/2,0.06,(a[1]+b[1])/2);c.receiveShadow=true;BZ.group.add(c);}
  [[760,412,1],[760,772,-1]].forEach(([px,py,s])=>{const [x,zz]=at(px,py);add(new THREE.CylinderGeometry(0.1,0.1,3.4,8),0x2a2d33,x,1.7,zz);circ(x,zz,0.2);
    box(1.8,1.1,0.1,x,3.3,zz+s*0.35,0xf4f4f0,false);const hoop=new THREE.Mesh(new THREE.TorusGeometry(0.35,0.05,6,16),mat(0xe0602a));hoop.rotation.x=Math.PI/2;hoop.position.set(x,2.95,zz+s*0.8);BZ.group.add(hoop);});
  [[898,470],[898,540],[898,700]].forEach(([px,py])=>F(0.8,0.5,2.6,px,py,0,0x8a5a3a));
  [[895,610],[895,660],[655,420],[870,420]].forEach(([px,py],i)=>{const [x,zz]=at(px,py);if(i<2)tree(x,zz,0.9);else F(3,0.9,1,px,py,0,0x3f7a36);});
  // --- Player classroom ---
  F(6,1.4,0.2,1050,448,1,0x2f4a3a,false);                                                   // board
  F(2.8,0.8,1.2,1050,500,0,0x8a5a3a);                                                       // teacher's desk
  [[1015,540],[1085,540],[1015,590],[1085,590],[1015,640],[1085,640]].forEach(([px,py])=>{F(2.2,0.75,1,px,py,0,0xc9a27a);F(0.8,0.45,0.8,px,py+20,0,0x3a5a9a,false);});
  plant(1110,690,0.8);
  // --- Main house ---
  F(6.6,1,1.4,540,978,0,0x8a5a3a);                                                          // reception desk
  F(1.4,0.8,3.6,352,1035,0,0x3b6fb0);F(1.4,0.8,3.6,715,1035,0,0x3b6fb0);
  F(4.6,2.2,0.6,352,892,0,0x6b4a30);F(4.6,2.2,0.6,712,892,0,0x6b4a30);
  [[298,1050],[392,1090],[690,1090],[745,1060],[580,905]].forEach(p=>plant(...p));
  F(3.2,2.6,0.2,540,1098,0,0x4f3526,false);                                                 // front doors
  // --- School pathway ---
  [[925,815],[1040,905],[905,930],[1085,930]].forEach(([px,py])=>F(3.6,0.7,1.2,px,py,0,0x7a5a3a));
  [[810,825],[985,815],[1100,815],[805,905]].forEach(([px,py])=>{const [x,zz]=at(px,py);tree(x,zz,0.8);});
  // entrance gate
  [[1150,818],[1150,932]].forEach(([px,py])=>F(0.7,3,0.7,px,py,0,0x6b6f78));
  {const a=at(1150,818),b=at(1150,932);box(0.5,0.5,b[1]-a[1]+0.7,a[0],3.1,(a[1]+b[1])/2,0x6b6f78,false);}
  // room names
  Object.values(ROOMS).forEach(R=>{if(R.name==='Corridor')return;const [x0,y0,x1,y1]=R.r;const [x,zz]=SX((x0+x1)/2,(y0+y1)/2);label(R.name,x,zz,R.out?4.8:5.2,R.out?'#7cf5ff':'#f2c14e');});
  z.marks=[[...SX(1160,875),'#7cf5ff'],[...SX(648,110),'#f2c14e']];
  z.label=()=>{for(const R of Object.values(ROOMS)){const [x0,y0,x1,y1]=R.r,a=SX(x0,y0),b=SX(x1,y1);
    if(LEE.pos.x>=a[0]&&LEE.pos.x<=b[0]&&LEE.pos.y>=a[1]&&LEE.pos.y<=b[1])return 'School · '+R.name;}return 'School';};
});
BZ.solids=null;

/* ---------- map transfer: Sand Town school door ⇄ school entrance ---------- */
const SCHOOL_IN=SX(1110,875);
function placeLee(x,z,lx,lz){LEE.pos.set(x,z);LEE.lookT.set(lx,lz).normalize();LEE.look.copy(LEE.lookT);yaw=Math.atan2(-LEE.lookT.x,-LEE.lookT.y);
  camTgt.set(x,1.2,z);curDist=CAMD[settings.camera];LEE.walk=0;}
function setObjective(t){const el=$('tut');el.firstElementChild.textContent='Objective';$('tutText').textContent=t;el.classList.add('open');}
function goToSchool(){if(busy)return;stopJoy();burst(()=>{G.story.place='school';setZone('school');placeLee(SCHOOL_IN[0],SCHOOL_IN[1],-1,0);
  mode='play';touch();setObjective('Explore the school.');transferCool=1.5;});}
function goToTown(){if(busy)return;stopJoy();burst(()=>{G.story.place='sandtown';setZone('sandtown');const d=TOWN.schoolDoor;
  placeLee(d.x+d.nx*2.4,d.z+d.nz*2.4,d.nx,d.nz);mode='play';touch();setObjective('Explore Sand Town.');transferCool=1.5;});}
let transferCool=0;
SCHOOL.update=dt=>{if(transferCool>0){transferCool-=dt;return;}if(mode!=='play'||busy)return;
  if(LEE.pos.x>SX(1168,0)[0])goToTown();};
// the town's school door now leads inside
{const it=INTERACT.find(i=>i.zone==='sandtown'&&i.label==='School');it.label='Enter school';it.fn=goToSchool;}
INTERACT.push({zone:'school',x:SX(648,135)[0],z:SX(648,135)[1],r:2.2,label:'Stairs to the Gym',fn:()=>startDialog([{who:'Stairs',text:'The stairs up to the gym. (The top floor is a later build.)'}])});
INTERACT.push({zone:'school',x:SX(540,1080)[0],z:SX(540,1080)[1],r:2,label:'Front doors',fn:()=>startDialog([{who:'Front doors',text:'The main front doors. Use the school pathway entrance to get back to town.'}])});
