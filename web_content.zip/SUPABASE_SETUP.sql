-- JAS Laundry Supabase setup. Run once in Supabase Dashboard -> SQL Editor.
-- The app uses Supabase Auth; this table is private to the signed-in Owner account.
create table if not exists public.jas_laundry_cloud (
  owner_uid uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.jas_laundry_cloud enable row level security;
drop policy if exists "JAS owner can read own cloud data" on public.jas_laundry_cloud;
create policy "JAS owner can read own cloud data" on public.jas_laundry_cloud
  for select to authenticated using (auth.uid() = owner_uid);
drop policy if exists "JAS owner can insert own cloud data" on public.jas_laundry_cloud;
create policy "JAS owner can insert own cloud data" on public.jas_laundry_cloud
  for insert to authenticated with check (auth.uid() = owner_uid);
drop policy if exists "JAS owner can update own cloud data" on public.jas_laundry_cloud;
create policy "JAS owner can update own cloud data" on public.jas_laundry_cloud
  for update to authenticated using (auth.uid() = owner_uid) with check (auth.uid() = owner_uid);

-- Atomic merge prevents a stale device from replacing the entire cloud snapshot.
create or replace function public.jas_merge_cloud_data(p_data jsonb)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  current_data jsonb;
  merged jsonb;
  k text;
begin
  if uid is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.jas_laundry_cloud where owner_uid = uid) then
    insert into public.jas_laundry_cloud(owner_uid, data, updated_at)
    values (uid, coalesce(p_data, '{}'::jsonb), now())
    on conflict (owner_uid) do nothing;
  end if;
  select data into current_data from public.jas_laundry_cloud where owner_uid = uid for update;
  merged := coalesce(current_data, '{}'::jsonb) || coalesce(p_data, '{}'::jsonb);
  foreach k in array array['bills','customers','prices','activities','customerAdvances','refunds','attendance','expenses','purchases','branches','offers','__staffAccounts'] loop
    if jsonb_typeof(coalesce(current_data->k, '[]'::jsonb)) = 'array'
       or jsonb_typeof(coalesce(p_data->k, '[]'::jsonb)) = 'array' then
      merged := jsonb_set(merged, array[k], (
        select coalesce(jsonb_agg(item order by sort_time, rec_key), '[]'::jsonb)
        from (
          select distinct on (rec_key) item, sort_time, rec_key
          from (
            select v as item,
              coalesce(nullif(v->>'updatedAt','')::numeric, nullif(v->>'createdAt','')::numeric, 0) as sort_time,
              coalesce(nullif(v->>'id',''), nullif(v->>'key',''), v::text) as rec_key
            from jsonb_array_elements(case when jsonb_typeof(current_data->k)='array' then current_data->k else '[]'::jsonb end) v
            union all
            select v as item,
              coalesce(nullif(v->>'updatedAt','')::numeric, nullif(v->>'createdAt','')::numeric, 0) as sort_time,
              coalesce(nullif(v->>'id',''), nullif(v->>'key',''), v::text) as rec_key
            from jsonb_array_elements(case when jsonb_typeof(p_data->k)='array' then p_data->k else '[]'::jsonb end) v
          ) all_items
          order by rec_key, sort_time desc
        ) chosen
      ), true);
    end if;
  end loop;
  merged := jsonb_set(merged, '{next}', to_jsonb(greatest(
    coalesce((current_data->>'next')::bigint,1), coalesce((p_data->>'next')::bigint,1), 1
  )), true);
  update public.jas_laundry_cloud set data=merged, updated_at=now() where owner_uid=uid;
end;
$$;
grant execute on function public.jas_merge_cloud_data(jsonb) to authenticated;

-- Enable Realtime notifications for this table.
do $$ begin
  alter publication supabase_realtime add table public.jas_laundry_cloud;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
