-- PB Gestión: ejecutar en Supabase > SQL Editor > New query.
-- Cada usuario solo puede leer/escribir su propia fila.
create table if not exists public.pb_gestion_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.pb_gestion_data enable row level security;
revoke all on table public.pb_gestion_data from anon;
grant select, insert, update, delete on table public.pb_gestion_data to authenticated;

drop policy if exists "pb_gestion_select_own" on public.pb_gestion_data;
drop policy if exists "pb_gestion_insert_own" on public.pb_gestion_data;
drop policy if exists "pb_gestion_update_own" on public.pb_gestion_data;
drop policy if exists "pb_gestion_delete_own" on public.pb_gestion_data;
create policy "pb_gestion_select_own" on public.pb_gestion_data for select to authenticated using (auth.uid() = user_id);
create policy "pb_gestion_insert_own" on public.pb_gestion_data for insert to authenticated with check (auth.uid() = user_id);
create policy "pb_gestion_update_own" on public.pb_gestion_data for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "pb_gestion_delete_own" on public.pb_gestion_data for delete to authenticated using (auth.uid() = user_id);
