# Noch offene Punkte vor Veröffentlichung

1. Datenschutz-Verantwortlicher ergänzen; Datenschutz-E-Mail: 4000plus_x@gmx.net.
2. Aktive Datenschutz-URL veröffentlichen.
3. Finale Release-AAB bauen und signieren.
4. Finale AAB auf einem Android-Gerät testen.
5. Play-Store-Screenshots erstellen.
6. Play-Console-Formulare ausfüllen.
7. Prüfen, ob das verwendete Entwicklerkonto den Closed-Test mit 12 Testern über 14 Tage verlangt.
8. Erst danach Produktionseinreichung.

Die technischen API-36-Vorgaben sind im vorbereiteten Android-Projekt bereits gesetzt.
