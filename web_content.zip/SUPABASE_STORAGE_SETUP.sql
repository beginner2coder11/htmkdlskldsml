-- طلباتنا هنانا: إعداد تخزين صور المطاعم والوجبات والعروض
-- شغّل هذا الملف مرة واحدة في Supabase Dashboard > SQL Editor.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('talabatna-images', 'talabatna-images', true, 10485760, array['image/jpeg','image/png','image/webp','image/gif','image/avif'])
on conflict (id) do update set public = true, file_size_limit = 10485760, allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif','image/avif'];

drop policy if exists "talabatna images public read" on storage.objects;
create policy "talabatna images public read" on storage.objects for select to public using (bucket_id = 'talabatna-images');

drop policy if exists "talabatna images admin upload" on storage.objects;
create policy "talabatna images admin upload" on storage.objects for insert to authenticated with check (bucket_id = 'talabatna-images');

drop policy if exists "talabatna images admin update" on storage.objects;
create policy "talabatna images admin update" on storage.objects for update to authenticated using (bucket_id = 'talabatna-images') with check (bucket_id = 'talabatna-images');

drop policy if exists "talabatna images admin delete" on storage.objects;
create policy "talabatna images admin delete" on storage.objects for delete to authenticated using (bucket_id = 'talabatna-images');
