# Prototype Limits and Production Safety
- Demo data is local browser-only.
- No real bank transfers; demo donation amounts do not move money.
- Admin role is a visible label, not a protected account.
- The map is a directory placeholder; no provider/API is wired.
- Beneficiary contact/location privacy must be protected before launch.
- Production requires API, database, OTP/auth, RBAC, audit logs, moderation queue, payment-provider integration, secure deployment, backups, abuse controls and legal/privacy review.
