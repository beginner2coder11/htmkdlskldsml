# SAVOB Product Scope — 10X Demo Expansion

## Main experience
1. Dashboard: mission hero, impact cards, feed preview, campaign summary, volunteering preview.
2. Community: community posts, reactions, comments, share-copy and report demo.
3. Aid requests: create requests, category filtering, help action.
4. Volunteer: open opportunities, join/leave and participant counter.
5. Campaigns: dedicated fundraising cards, demo contribution tracking.
6. Market: listings by free items, services and jobs.
7. Suggestions: idea submissions and community votes.
8. Events: create, browse, register.
9. Messages: inbox and demo local chat.
10. Profile: editable name, bio, regional location.
11. Admin: post removal, aid request status, export JSON.

## Regional focus
Default focus: Qoraqalpog‘iston Respublikasi. Sample locations: Nukus, Beruniy, Mo‘ynoq. Location examples are demo seed content, not verified live organizations or services.

## Admin display
Admin identity in this prototype is Qadamboy. This is only display text; no login or permission system exists.
