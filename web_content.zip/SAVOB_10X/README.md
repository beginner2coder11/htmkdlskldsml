# SAVOB 10X — Community Platform Demo
## Demo start
Unzip, open `app/index.html` in a modern browser. No install or server needed.

## Enhanced features
- Full-width responsive layout, corrected CSS grid and mobile-first cards.
- Admin identity set to **Qadamboy**.
- Default profile and primary service region set to **Qoraqalpog‘iston Respublikasi**.
- Expanded community feed with regional content.
- Suggestions/ideas section: create suggestion and vote (local demo).
- Hero image asset included in project.
- Create post, help request, campaign, listing, event and suggestion.
- Community posts can now optionally attach videos (up to 25 MB); video blobs are stored in browser IndexedDB and rendered in-feed with native playback controls.
- Likes/comments, volunteer join/leave, demo donation, market contact actions, event registration, local chat.
- Profile editor, admin moderation and JSON export.
- Demo state is saved locally in browser `localStorage`; video files are stored locally in `IndexedDB`.

## Honest demo limitations
No backend/server, real accounts, payment processing, SMS, real map, push notification, or secure admin authentication. Donations only increment local demo figures. Do not use demo as a public service until backend, security, privacy and moderation work is implemented.
