package com.meusshows.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { public void onReceive(Context c,Intent i){AlarmScheduler.rescheduleAll(c);} }
