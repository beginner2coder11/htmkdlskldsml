package com.meusshows.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new AlarmBridge(this),"AndroidAlarm"); web.loadUrl("file:///android_asset/index.html"); if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},40); }
    public static void openExactAlarmSettings(Context c){ if(android.os.Build.VERSION.SDK_INT>=31){ try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+c.getPackageName())); c.startActivity(i);}catch(Exception ignored){} } }
}
class AlarmBridge {
    private final Context c; AlarmBridge(Context c){this.c=c;}
    @JavascriptInterface public void schedule(String id,String title,long triggerAt){ AlarmScheduler.schedule(c,id,title,triggerAt); }
    @JavascriptInterface public void cancel(String id){ AlarmScheduler.cancel(c,id); }
    @JavascriptInterface public boolean canScheduleExact(){ AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); return android.os.Build.VERSION.SDK_INT<31 || a.canScheduleExactAlarms(); }
    @JavascriptInterface public void requestExactAlarmPermission(){ MainActivity.openExactAlarmSettings(c); }
}
class AlarmScheduler {
 static final String PREF="alarms";
 static PendingIntent pi(Context c,String id){ Intent i=new Intent(c,AlarmReceiver.class).setAction("MEUS_SHOWS_ALARM_"+id).putExtra("id",id); return PendingIntent.getBroadcast(c,Math.abs(id.hashCode()),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
 static void schedule(Context c,String id,String title,long when){ AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent p=pi(c,id); if(android.os.Build.VERSION.SDK_INT>=31 && !a.canScheduleExactAlarms()){ MainActivity.openExactAlarmSettings(c); return; } if(android.os.Build.VERSION.SDK_INT>=23)a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);else a.setExact(AlarmManager.RTC_WAKEUP,when,p); c.getSharedPreferences(PREF,0).edit().putString(id,title+"|"+when).apply(); }
 static void cancel(Context c,String id){ AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); a.cancel(pi(c,id)); c.getSharedPreferences(PREF,0).edit().remove(id).apply(); }
 static void rescheduleAll(Context c){ for(String id:c.getSharedPreferences(PREF,0).getAll().keySet()){String v=c.getSharedPreferences(PREF,0).getString(id,""); try{String[] x=v.split("\\|",2); long when=Long.parseLong(x[1]); if(when>System.currentTimeMillis())schedule(c,id,x[0],when);}catch(Exception ignored){}} }
}
