MEUS SHOWS 2.0 — DESPERTADOR ANDROID

Esta versão adiciona um despertador nativo Android ao projeto original:
- AlarmManager exact + allow-while-idle
- funciona com o app fechado
- notificação de alta prioridade
- som de alarme e vibração
- tela do alarme com botão para desligar
- reprogramação após reiniciar o celular
- pedido de permissão de notificações no Android 13+
- pedido de permissão de alarmes exatos no Android 12+

O HTML original foi preservado em app/src/main/assets/index.html.

IMPORTANTE: este ambiente não possui Android SDK/Gradle instalado, então o APK não foi compilado aqui. O projeto está pronto para abrir no Android Studio e gerar o APK.
