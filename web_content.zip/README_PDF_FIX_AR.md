# إصلاح تحميل PDF

تم إصلاح مشكلة ظهور رسالة «تحميل PDF متاح داخل تطبيق Android».

## ما تم تغييره
- إضافة مسار احتياطي Native عبر `afriquia://savepdf` إذا لم يظهر جسر AndroidPrint في WebView.
- حفظ محتوى PDF مؤقتاً داخل WebView ثم تسليمه إلى Android لإنشاء الملف.
- حفظ PDF في مجلد Downloads باستخدام MediaStore على Android 10+.
- حفظه في Downloads مع MediaScanner على الإصدارات الأقدم.
- رفع رقم النسخة إلى 1.1 (versionCode 2).

## مهم
يجب إعادة بناء APK من هذا المشروع وتثبيته فوق النسخة القديمة. الملف ZIP هو مشروع Android Studio، وليس APK جاهزاً.
