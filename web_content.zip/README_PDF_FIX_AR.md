# إصلاح PDF v5
تم إصلاح تصدير PDF ليتم إنشاء الملف مباشرة باستعمال Android `PdfDocument` بعد اكتمال تخطيط WebView، بدلاً من `PrintDocumentAdapter` الذي قد يتوقف أو لا يستجيب في بعض إصدارات WebView/Android.
- حفظ مباشر داخل مجلد Downloads.
- دعم المستندات متعددة الصفحات.
- الإبقاء على مسار `afriquia://savepdf` الاحتياطي.
- إضافة استيراد `PrintManager` المطلوب للطباعة النظامية.
