# إصلاح PDF v3

تم إلغاء مسار `afriquia://savepdf` الذي كان يسبب فتح صفحة appassets بدلاً من إنشاء الملف. زر PDF يستدعي الآن `AndroidPrint.savePdf` مباشرة داخل التطبيق، ويتم إنشاء الملف Native وحفظه في Downloads عبر MediaStore.

يجب إعادة بناء APK وتثبيت النسخة الجديدة (versionCode 3 / versionName 1.2).
