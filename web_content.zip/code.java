package com.usdt.flash.tool; // Match your package name

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        
        // Enable JavaScript for your HTML tool
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        
        // Allow zooming if needed
        webSettings.setSupportZoom(false); 
        
        // Load the HTML file from assets
        webView.loadUrl("file:///android_asset/index.html");

        // Keep the app from opening external links in Chrome
        webView.setWebViewClient(new WebViewClient());
    }

    // Handle back button to go back in history instead of closing app
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}