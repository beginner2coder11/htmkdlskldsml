/* Uma gravação atómica; memória atualizada apenas após sucesso. */
globalThis.Store=(()=>{
 let handle;
 function open(){return new Promise((resolve,reject)=>{if(!globalThis.indexedDB)return reject(Error('Armazenamento indisponível. Abra num navegador compatível.'));const r=indexedDB.open('mv_controlo_compras_2',1);r.onupgradeneeded=()=>r.result.createObjectStore('state');r.onsuccess=()=>{handle=r.result;handle.onversionchange=()=>handle.close();resolve();};r.onerror=()=>reject(r.error);r.onblocked=()=>reject(Error('Feche outras janelas do aplicativo.'));});}
 async function load(){await open();return new Promise((resolve,reject)=>{const r=handle.transaction('state').objectStore('state').get('main');r.onsuccess=()=>resolve(r.result||CC.defaults());r.onerror=()=>reject(r.error);});}
 function save(data){return new Promise((resolve,reject)=>{
 const tx=handle.transaction('state','readwrite'),state=tx.objectStore('state');
 let verified=false;
 state.put(data,'main');
 const check=state.get('main');
 check.onsuccess=()=>{verified=JSON.stringify(check.result)===JSON.stringify(data);if(!verified)tx.abort();};
 tx.oncomplete=()=>verified?resolve():reject(Error('Não foi possível confirmar a gravação.'));
 tx.onerror=()=>reject(tx.error||Error('Falha ao guardar.'));
 tx.onabort=()=>reject(tx.error||Error('A alteração não foi gravada. Tente novamente.'));
 });}
 return {load,save};
})();
