package ba.kotlina.vrijeme

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pageReady = false
    private var askedOnce = false
    private var insetTop = 0
    private var insetBottom = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0D1830"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = 100
            setSupportZoom(false)
        }
        web.setOnApplyWindowInsetsListener { _, insets ->
            insetTop = insets.systemWindowInsetTop
            insetBottom = insets.systemWindowInsetBottom
            pushInsets()
            insets
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pushInsets()
                ensureLocation()
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun pushInsets() {
        if (!pageReady) return
        val d = resources.displayMetrics.density
        val js = "document.documentElement.style.setProperty('--sat','${insetTop / d}px');" +
                 "document.documentElement.style.setProperty('--sab','${insetBottom / d}px');"
        web.evaluateJavascript(js, null)
    }

    private fun ensureLocation() {
        val fine = Manifest.permission.ACCESS_FINE_LOCATION
        val coarse = Manifest.permission.ACCESS_COARSE_LOCATION
        val granted = checkSelfPermission(fine) == PackageManager.PERMISSION_GRANTED ||
                      checkSelfPermission(coarse) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            fetchLocation()
        } else if (!askedOnce) {
            askedOnce = true
            requestPermissions(arrayOf(fine, coarse), 7)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.any { it == PackageManager.PERMISSION_GRANTED }) fetchLocation()
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val best = lm.getProviders(true)
                .mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
            if (best != null) deliver(best)

            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider != null) {
                lm.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(l: Location) = deliver(l)
                    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                }, mainLooper)
            }
        } catch (_: SecurityException) {
        }
    }

    private fun deliver(l: Location) {
        val js = String.format(Locale.US, "window.setLocation && window.setLocation(%.5f,%.5f)", l.latitude, l.longitude)
        runOnUiThread { web.evaluateJavascript(js, null) }
    }
}
