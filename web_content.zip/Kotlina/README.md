# Kotlina – vremenska aplikacija za Android

Prognoza za tvoju lokaciju (GPS/mreža), sa podacima uživo (Open-Meteo, bez API ključa).
Ako lokacija nije dostupna, koristi se Hrasnica. Zadnji podaci se čuvaju za rad bez interneta.

## Kako dobiti APK

1. Instaliraj Android Studio (besplatan): https://developer.android.com/studio
2. File > Open > izaberi folder `Kotlina` i sačekaj da se Gradle sinhronizuje (treba internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK je u: `app/build/outputs/apk/debug/app-debug.apk`
5. Prebaci ga na telefon i instaliraj (dozvoli instalaciju iz nepoznatih izvora).

Preko terminala: `gradle assembleDebug` (ili `./gradlew assembleDebug` nakon što Android Studio generiše wrapper).

Za objavu na Google Play treba potpisan release: Build > Generate Signed Bundle / APK.

## Struktura

- `app/src/main/assets/index.html` – cijeli izgled i logika prognoze
- `app/src/main/java/ba/kotlina/vrijeme/MainActivity.kt` – WebView, dozvola za lokaciju
- `app/src/main/AndroidManifest.xml` – dozvole (internet, lokacija)

Minimalni Android: 8.0 (API 26).
