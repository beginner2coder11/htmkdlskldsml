(function () {
'use strict';
var C = Object.assign({ enabled: true, duration: 7, audio: true, failsafe: 3, audioSrc: 'assets/audio/pluck.mp3' }, window.INTRO_CONFIG || {});
var q = new URLSearchParams(location.search);
if (q.get('intro') === 'off') C.enabled = false;
if (+q.get('duration')) C.duration = Math.max(3, +q.get('duration'));
var $ = function (i) { return document.getElementById(i); };
var app = $('app'), cam = $('cam'), rub = $('rubab'), glow = $('glow'), halo = $('halo'), parts = $('parts'),
    pk = $('pk'), sh = $('sh'), pb = $('pb'), str = $('str'), title = $('title'), scrim = $('scrim'), snd = $('snd');
var TL = 6.8, done = false, raf = 0, el = 0, last = 0, lastT = 0, fs = 0, started = false, vw, vh, k, cams = [];
var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
var cl = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
var eio = function (x) { x = cl(x); return x * x * (3 - 2 * x); };
var eo = function (x) { x = cl(x); return 1 - Math.pow(1 - x, 3); };
var eis = function (x) { return .5 - .5 * Math.cos(Math.PI * cl(x)); };

/* Optional audio; sound button appears only if the audio file loads. */
var au = null, soundOn = false;
if (C.audio) { try {
  au = new Audio(C.audioSrc); au.preload = 'auto';
  au.addEventListener('canplaythrough', function () { snd.hidden = false; }, { once: true });
  au.addEventListener('error', function () { au = null; });
} catch (e) { au = null; } }
function pluck() { if (au && soundOn) { try { au.currentTime = 0; var p = au.play(); if (p) p.catch(function () {}); } catch (e) {} } }
snd.addEventListener('click', function (e) { e.stopPropagation(); soundOn = !soundOn; snd.setAttribute('aria-pressed', soundOn); pluck(); });

/* Geometry in image pixel space (1376 x 768). */
var P = [[295,472],[327,482],[370,495],[415,510],[430,512]];
var F = [[1132,20],[1130,20],[1144,20],[1169,20],[1204,20]];
var AX = 520, AY = 403, MX = -.309, MY = .951, ANG = -72;
var S = P.map(function (p, i) {
  var dx = F[i][0] - p[0], dy = F[i][1] - p[1], L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L;
  var el = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  el.setAttribute('fill', 'none'); el.setAttribute('stroke', '#d6d1c6'); el.setAttribute('stroke-width', '1.7'); el.setAttribute('opacity', '0');
  str.appendChild(el);
  return { el: el, ux: ux, uy: uy, nx: -uy, ny: ux, t0: -9, amp: 0, rel: false, held: false };
});
/* Pick motion timeline: [start,end,start-position,end-position,lift-start,lift-end,easing,arc]. */
var segs = [];
function seg(a, b, s0, s1, l0, l1, e, arc) { segs.push([a, b, s0, s1, l0, l1, e, arc || 0]); }
seg(1.35, 2.0, -340, -115, 1, 1, eo);
for (var i = 0; i < 3; i++) {
  var b = 2.0 + .83 * i;
  seg(b, b + .14, -115, -100, 1, 0, eio);
  seg(b + .14, b + .44, -100, 100, 0, 0, eis);
  seg(b + .44, b + .52, 100, 112, 0, 1, eio);
  if (i < 2) seg(b + .52, b + .83, 112, -115, 1, 1, eio, 26);
}
seg(4.18, 4.8, 112, -430, 1, 1, eio);
function pickAt(t) {
  for (var i = 0; i < segs.length; i++) { var g = segs[i];
    if (t >= g[0] && t <= g[1]) { var u = (t - g[0]) / (g[1] - g[0]), e = g[6](u);
      return { s: g[2] + (g[3] - g[2]) * e, l: g[4] + (g[5] - g[4]) * e, arc: g[7] * Math.sin(Math.PI * u) }; } }
  return null;
}
function layout() {
  vw = innerWidth; vh = innerHeight;
  var W = Math.min(vw, vh * .62 * 1376 / 768), H = W * 768 / 1376, cx = vw / 2;
  k = W / 1376; cam.style.width = W + 'px'; cam.style.height = H + 'px';
  cams = [[0, .94, 688, 384, cx, vh * .40], [4.2, 2.15, 500, 400, cx, vh * .42], [5.6, 1, 688, 384, cx, vh * .34], [TL, 1.03, 688, 384, cx, vh * .34]];
  title.style.top = (vh * .34 + H / 2 + vh * .05) + 'px';
  if (started) render(lastT);
}
function camAt(t) {
  var i = 0; while (i < cams.length - 2 && t > cams[i + 1][0]) i++;
  var a = cams[i], b = cams[i + 1], u = eio((t - a[0]) / (b[0] - a[0]));
  var L = function (j) { return a[j] + (b[j] - a[j]) * u; }, s = L(1);
  return 'translate3d(' + (L(4) - s * k * L(2)).toFixed(2) + 'px,' + (L(5) - s * k * L(3)).toFixed(2) + 'px,0) scale(' + s.toFixed(4) + ')';
}
function render(t) {
  lastT = t;
  cam.style.transform = camAt(t);
  cam.style.opacity = eo(t / 1.6);
  glow.style.opacity = (.3 * eio((t - .3) / 1.4) + .7 * eio((t - 4) / 1.5)) * .85;
  halo.style.opacity = .15 * eio(t / 1.5) + .6 * eio((t - 3.9) / 1.7);
  if (t > 1.7) parts.classList.add('on');
  if (t > 4.7) { title.classList.add('on'); scrim.style.opacity = 1; }
  var p = pickAt(t), now = t;
  if (!p) { pk.setAttribute('opacity', 0); }
  else {
    var tx = AX + p.s * MX - .951 * p.arc, ty = AY + p.s * MY - .309 * p.arc;
    pk.setAttribute('opacity', (cl((t - 1.35) / .35) * cl((4.8 - t) / .4)).toFixed(3));
    pk.setAttribute('transform', 'translate(' + tx.toFixed(1) + ' ' + ty.toFixed(1) + ')');
    sh.setAttribute('transform', 'translate(' + (p.l * 22).toFixed(1) + ' ' + (p.l * 30).toFixed(1) + ') rotate(' + ANG + ')');
    pb.setAttribute('transform', 'rotate(' + ANG + ') scale(' + (1 + .06 * p.l).toFixed(3) + ')');
    var contact = p.l < .2;
    if (p.l > .5) S.forEach(function (s) { s.rel = false; });
    S.forEach(function (s, i) {
      var rx = tx - P[i][0], ry = ty - P[i][1], d = rx * s.nx + ry * s.ny, tt = rx * s.ux + ry * s.uy;
      if (contact && tt > 20 && !s.rel) {
        if (d > 0 && d < 9) s.held = d; else if (d >= 9) { s.held = false; s.rel = true; s.t0 = now; s.amp = 9; pluck(); }
      }
      if (s.held !== false && !contact) s.held = false;
    });
  }
  S.forEach(function (s, i) {
    var a = P[i], f = F[i], e = now - s.t0, d;
    if (s.held !== false) {
      var tt = Math.max(0, (tx - a[0]) * s.ux + (ty - a[1]) * s.uy);
      d = 'M' + a + 'L' + (a[0] + s.ux * tt + s.nx * s.held).toFixed(1) + ' ' + (a[1] + s.uy * tt + s.ny * s.held).toFixed(1) + 'L' + f;
      s.el.setAttribute('d', d); s.el.setAttribute('opacity', .95);
    } else if (e >= 0 && e < 1.3) {
      var disp = s.amp * Math.exp(-3.4 * e) * Math.cos(2 * Math.PI * 16 * e);
      d = 'M' + a + 'Q' + ((a[0] + f[0]) / 2 + s.nx * disp * 2).toFixed(1) + ' ' + ((a[1] + f[1]) / 2 + s.ny * disp * 2).toFixed(1) + ' ' + f;
      s.el.setAttribute('d', d); s.el.setAttribute('opacity', (.95 * (1 - cl((e - .6) / .7))).toFixed(2));
    } else s.el.setAttribute('opacity', 0);
  });
}
var tx = 0, ty = 0;
function loop(n) {
  raf = 0; if (done || document.hidden) return;
  var dt = Math.min(n - last, 50); last = n; el += dt / 1000;
  var t = el * TL / C.duration; render(Math.min(t, TL));
  if (t >= TL) finish(false); else raf = requestAnimationFrame(loop);
}
function finish(immediate) {
  if (done) return; done = true; cancelAnimationFrame(raf); clearTimeout(fs);
  var go = function () {
    app.classList.add('gone');
    try { if (typeof window.onIntroComplete === 'function') window.onIntroComplete(); } catch (e) {}
    try { if (window.AndroidBridge && window.AndroidBridge.onIntroComplete) window.AndroidBridge.onIntroComplete(); } catch (e) {}
    window.dispatchEvent(new CustomEvent('introcomplete'));
  };
  if (immediate === true) go(); else { app.classList.add('end'); setTimeout(go, 300); }
}
function start() {
  if (started) return; started = true; layout();
  if (reduce) { render(6); title.classList.add('on'); setTimeout(function () { finish(false); }, 1800); return; }
  last = performance.now(); raf = requestAnimationFrame(loop);
}
document.addEventListener('visibilitychange', function () {
  if (done) return; app.classList.toggle('paused', document.hidden);
  if (!document.hidden && !raf && started && !reduce) { last = performance.now(); raf = requestAnimationFrame(loop); }
});
addEventListener('resize', layout); addEventListener('orientationchange', layout);
app.addEventListener('click', function () { finish(false); });
window.PashtoIntro = { skip: function () { finish(false); }, enableSound: function () { soundOn = true; } };
for (var j = 0; j < 14; j++) { var d = document.createElement('i'); d.className = 'p';
  d.style.cssText = 'left:' + (10 + Math.random() * 80) + '%;top:' + (30 + Math.random() * 45) + '%;animation-delay:' + (-Math.random() * 7).toFixed(2) + 's'; parts.appendChild(d); }
if (!C.enabled) { app.style.display = 'none'; addEventListener('load', function () { setTimeout(function () { finish(true); }, 0); }); }
else {
  fs = setTimeout(function () { finish(true); }, (C.duration + C.failsafe) * 1000);
  rub.addEventListener('error', function () { if (!app.classList.contains('fb')) { app.classList.add('fb'); rub.src = glow.src = 'assets/img/rubab-original.jpg'; } else start(); });
  if (rub.complete && rub.naturalWidth) start(); else rub.addEventListener('load', start);
}
})();
