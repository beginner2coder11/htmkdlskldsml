# پښتني ولسي ادب — Rubab Intro

This project preserves the supplied intro as separate HTML, CSS, and JavaScript files.

## Files
- `index.html` — intro markup and settings
- `css/intro.css` — styling and animations
- `js/intro.js` — camera, pick, string, timeline, and skip logic
- `assets/img/` — add the rubab image(s)
- `assets/fonts/` — optional Amiri fonts
- `assets/audio/` — optional pluck sound effect

## Required / optional assets
1. **Required for the intended visual:** `assets/img/rubab.webp`
2. **Fallback image referenced by the code:** `assets/img/rubab-original.jpg` (optional but recommended)
3. **Optional audio:** `assets/audio/pluck.mp3`
4. **Optional fonts:** `assets/fonts/Amiri-Regular.woff2` and `assets/fonts/Amiri-Bold.woff2`

The image should match the proportions and placement assumed by the code (SVG animation coordinate space is 1376 × 768). The image is not included because it was not attached as an asset with the code snippet.

## Run
Open `index.html` in a modern browser. Keep the `css`, `js`, and `assets` folders next to it. If the image is missing, the intended rubab animation cannot display correctly.

## Settings
Edit `window.INTRO_CONFIG` near the top of `index.html`.
- `enabled: false` disables the intro
- `duration: 7` controls duration in seconds
- `audio: true` enables optional audio support

URL options: `?duration=6` or `?intro=off`.

Tap/click anywhere to skip. The completion callback is `window.onIntroComplete`; the page also dispatches an `introcomplete` event.
