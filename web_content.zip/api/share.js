/* ClipVerse share preview: /s/<video id>?f=<file>&t=<caption>&u=<user>
   Crawlers (WhatsApp, Facebook, Telegram, X, ...) read the Open Graph tags below, so the shared link shows the video thumbnail,
   title and creator. People who open the link are sent straight to the app (/?v=<id>). */
const SITE = "https://clipverse-pwa-v7.vercel.app";
const SERVER = "https://clipverse.duckdns.org";
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clean = (s, n) => String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, n);
const one = v => Array.isArray(v) ? v[0] : v;

module.exports = async (req, res) => {
  const q = req.query || {};
  const id = clean(one(q.id), 120);
  const f = /^[A-Za-z0-9_-]{6,64}$/.test(String(one(q.f) || "")) ? String(one(q.f)) : "";   // file name only: the picture can only come from our own video server
  const title = clean(one(q.t), 80) || "ClipVerse video";
  const user = clean(one(q.u), 40);
  let image = SITE + "/icon-512.png";
  if (f) {
    const jpg = SERVER + "/uploads/videos/" + f + ".jpg";
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 2500);
      const r = await fetch(jpg, { method: "HEAD", signal: ctl.signal }); clearTimeout(to);
      if (r.ok) image = jpg;
    } catch (e) {}
  }
  const desc = (user ? "@" + user + " on ClipVerse - " : "") + "watch, create and share short videos on ClipVerse.";
  const go = "/?v=" + encodeURIComponent(id);
  const html = '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    "<title>" + esc(title) + " | ClipVerse</title>" +
    '<meta name="description" content="' + esc(desc) + '">' +
    '<meta property="og:site_name" content="ClipVerse">' +
    '<meta property="og:type" content="website">' +
    '<meta property="og:title" content="' + esc(title) + '">' +
    '<meta property="og:description" content="' + esc(desc) + '">' +
    '<meta property="og:image" content="' + esc(image) + '">' +
    '<meta property="og:image:alt" content="' + esc(title) + '">' +
    '<meta name="twitter:card" content="summary_large_image">' +
    '<meta name="twitter:title" content="' + esc(title) + '">' +
    '<meta name="twitter:description" content="' + esc(desc) + '">' +
    '<meta name="twitter:image" content="' + esc(image) + '">' +
    '<meta name="theme-color" content="#0a0014">' +
    '<style>body{margin:0;background:#0a0014;color:#f3eefc;font:16px system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh}a{color:#a259ff}</style>' +
    "</head><body><p>Opening ClipVerse... <a href=\"" + esc(go) + "\">Tap here if nothing happens</a></p>" +
    "<script>location.replace(" + JSON.stringify(go).replace(/</g, "\\u003c") + ");</script></body></html>";
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Cache-Control", "public, s-maxage=600, stale-while-revalidate=86400");
  res.end(html);
};
