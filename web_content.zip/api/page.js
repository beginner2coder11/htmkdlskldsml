/* ClipVerse public pages for Google, Facebook, WhatsApp ...
   /v/<id>/<slug>   one page per video (title, description, Open Graph, VideoObject data)
   /u/<uid>/<slug>  one page per creator
   /c/<category>    Funny Videos, Gaming Creators, Comedy Videos, Vlog Creators, Popular Videos
   /sitemap.xml     all of the above
   The data comes from the public Firestore REST API (the same videos everyone already sees in the app). Nothing is written. */
const SITE = "https://clipverse-pwa-v7.vercel.app";
const SERVER = "https://clipverse.duckdns.org";
const CLD = "https://res.cloudinary.com/up8sahxs/video/fetch/";
const PROJECT = "clipverse-df27c", KEY = "AIzaSyDTojXopKRBdTGrTPzCXzpjvKIgeSdEBMo";
const FS = "https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents";

const CATS = {
  "funny-videos": { name: "Funny Videos", h1: "Funny Videos on ClipVerse", desc: "Watch the funniest short videos, pranks and memes from creators on ClipVerse.", re: /\b(funny|fun|lol|lmao|meme|memes|prank|pranks|joke|jokes|hilarious|mazahiya)\b/i },
  "gaming-creators": { name: "Gaming Creators", h1: "Gaming Creators on ClipVerse", desc: "Discover gaming creators and gameplay clips - PUBG, Free Fire, Minecraft, GTA and more - on ClipVerse.", re: /\b(gaming|gamer|gamers|gameplay|game|pubg|freefire|free fire|minecraft|gta|fortnite|valorant|cod|roblox)\b/i },
  "comedy-videos": { name: "Comedy Videos", h1: "Comedy Videos on ClipVerse", desc: "Comedy skits, stand-up and sketches from creators on ClipVerse.", re: /\b(comedy|comedian|skit|skits|standup|stand-up|sketch|roast)\b/i },
  "vlog-creators": { name: "Vlog Creators", h1: "Vlog Creators on ClipVerse", desc: "Daily life, travel and lifestyle vlogs from creators on ClipVerse.", re: /\b(vlog|vlogs|vlogger|vloggers|travel|dayinmylife|daily vlog)\b/i },
  "popular-videos": { name: "Popular Videos", h1: "Popular Videos on ClipVerse", desc: "The most watched and most liked videos on ClipVerse right now.", popular: true }
};

const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clean = (s, n) => String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, n || 500);
const one = v => Array.isArray(v) ? v[0] : v;
const slugify = s => String(s || "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
const jsonLd = o => '<script type="application/ld+json">' + JSON.stringify(o).replace(/</g, "\\u003c") + "</script>";
const ID_RE = /^[A-Za-z0-9_-]{6,64}$/;

/* ---- Firestore REST helpers ---- */
function val(v) {
  if (!v) return null;
  if ("stringValue" in v) return v.stringValue;
  if ("integerValue" in v) return Number(v.integerValue);
  if ("doubleValue" in v) return Number(v.doubleValue);
  if ("booleanValue" in v) return v.booleanValue;
  if ("timestampValue" in v) return v.timestampValue;
  if ("arrayValue" in v) return (v.arrayValue.values || []).map(val);
  if ("mapValue" in v) { const o = {}, f = v.mapValue.fields || {}; for (const k in f) o[k] = val(f[k]); return o; }
  return null;
}
function doc(d) {
  if (!d || !d.name) return null;
  const o = { id: d.name.split("/").pop() }, f = d.fields || {};
  for (const k in f) o[k] = val(f[k]);
  return o;
}
async function fsGet(path) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 6000);
  try {
    const r = await fetch(FS + "/" + path + "?key=" + KEY, { signal: ctl.signal });
    if (!r.ok) return null;
    return doc(await r.json());
  } catch (e) { return null; } finally { clearTimeout(to); }
}
async function fsQuery(q) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
  try {
    const r = await fetch(FS + ":runQuery?key=" + KEY, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ structuredQuery: q }), signal: ctl.signal });
    if (!r.ok) return [];
    return (await r.json()).map(x => doc(x.document)).filter(Boolean);
  } catch (e) { return []; } finally { clearTimeout(to); }
}
const latestVideos = n => fsQuery({ from: [{ collectionId: "videos" }], orderBy: [{ field: { fieldPath: "createdAt" }, direction: "DESCENDING" }], limit: n });
const videosOf = uid => fsQuery({ from: [{ collectionId: "videos" }], where: { fieldFilter: { field: { fieldPath: "uid" }, op: "EQUAL", value: { stringValue: uid } } }, limit: 60 });

/* ---- video helpers ---- */
const fileOf = u => { const m = /\/uploads\/videos\/([A-Za-z0-9._-]+)/.exec(String(u || "")); return m ? m[1] : ""; };
const oracleUrl = u => { const f = fileOf(u); return f ? SERVER + "/uploads/videos/" + f : String(u || ""); };
const thumbOf = u => { const f = fileOf(u); return f ? SERVER + "/uploads/videos/" + f.replace(/\.[a-z0-9]+$/i, ".jpg") : SITE + "/og-image.jpg"; };
const titleOf = v => clean(v.title, 90) || clean(String(v.caption || "").split(/\n/)[0], 70) || "ClipVerse video";
const descOf = v => {
  const cap = clean(v.caption, 300), hasT = !!clean(v.title, 90);
  if (hasT && cap) return cap;
  if (!hasT && String(v.caption || "").length > 70) return cap;
  return "Watch " + titleOf(v) + (v.user ? " by " + clean(v.user, 40) : "") + " on ClipVerse - watch, create and share short videos.";
};
const ms = v => { const t = Date.parse(v.createdAt || ""); return isFinite(t) ? t : 0; };
const iso = v => { const t = ms(v); return t ? new Date(t).toISOString() : ""; };
const vUrl = v => SITE + "/v/" + v.id + "/" + (slugify(titleOf(v)) || "video");
const uUrl = (uid, name) => SITE + "/u/" + uid + "/" + (slugify(name) || "creator");
const dur8601 = s => { s = Math.round(Number(s) || 0); if (!s) return ""; const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return "PT" + (h ? h + "H" : "") + (m ? m + "M" : "") + (x || (!h && !m) ? x + "S" : ""); };
const views = v => Number(v.views) || 0;
const likes = v => Array.isArray(v.likedBy) ? v.likedBy.length : 0;
const ready = v => v && v.url && String(v.url).length > 5;
const catOf = (c, list) => c.popular ? list.slice().sort((a, b) => (views(b) + likes(b) * 3) - (views(a) + likes(a) * 3)).slice(0, 40) : list.filter(v => c.re.test((v.title || "") + " " + (v.caption || "")));

/* ---- page shell ---- */
const CSS = "*{box-sizing:border-box}body{margin:0;background:#0a0014;color:#f3eefc;font:16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}a{color:#b98cff;text-decoration:none}header{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid #2c2147}header b{font-size:20px;color:#fff}.btn{display:inline-block;background:linear-gradient(135deg,#d13fc8,#8b3df0);color:#fff;padding:10px 18px;border-radius:999px;font-weight:700}main{max-width:760px;margin:0 auto;padding:16px}h1{font-size:22px;margin:14px 0 6px}h2{font-size:17px;margin:22px 0 10px}video{width:100%;max-height:78vh;background:#000;border-radius:14px;display:block}.meta{color:#a99bc9;font-size:14px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;list-style:none;padding:0;margin:0}.grid a{display:block;background:#17102a;border:1px solid #2c2147;border-radius:12px;overflow:hidden;color:#f3eefc}.grid img{width:100%;aspect-ratio:3/4;object-fit:cover;display:block;background:#1b1426}.grid span{display:block;padding:8px 10px;font-size:14px;line-height:1.3}.tags a{display:inline-block;margin:4px 6px 0 0;padding:4px 12px;border:1px solid #3a2a63;border-radius:999px;font-size:13px}footer{padding:24px 16px;text-align:center;color:#8b7fae;font-size:13px}";
function shell(o) {
  const t = esc(o.title), d = esc(o.desc), img = esc(o.image || SITE + "/og-image.jpg"), can = esc(o.canonical);
  return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    "<title>" + t + "</title>" +
    '<meta name="description" content="' + d + '"><link rel="canonical" href="' + can + '">' +
    '<meta name="robots" content="' + (o.noindex ? "noindex,follow" : "index,follow,max-image-preview:large,max-video-preview:-1") + '">' +
    '<meta property="og:site_name" content="ClipVerse"><meta property="og:type" content="' + (o.ogType || "website") + '"><meta property="og:title" content="' + t + '"><meta property="og:description" content="' + d + '"><meta property="og:url" content="' + can + '"><meta property="og:image" content="' + img + '">' +
    (o.ogExtra || "") +
    '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="' + t + '"><meta name="twitter:description" content="' + d + '"><meta name="twitter:image" content="' + img + '">' +
    '<meta name="theme-color" content="#0a0014"><link rel="icon" href="/icons/favicon-32.png"><link rel="manifest" href="/manifest.json">' +
    '<link rel="preconnect" href="' + SERVER + '"><style>' + CSS + "</style>" + (o.ld || "") + "</head><body>" +
    '<header><a href="/"><b>ClipVerse</b></a><a class="btn" href="' + esc(o.open || "/") + '">Open ClipVerse</a></header><main>' + o.body +
    '</main><footer><a href="/">ClipVerse</a> &middot; <a href="/c/popular-videos">Popular</a> &middot; <a href="/c/funny-videos">Funny</a> &middot; <a href="/c/comedy-videos">Comedy</a> &middot; <a href="/c/gaming-creators">Gaming</a> &middot; <a href="/c/vlog-creators">Vlogs</a> &middot; <a href="/privacy-policy.html">Privacy</a></footer></body></html>';
}
const card = v => '<li><a href="' + esc(vUrl(v)) + '"><img loading="lazy" width="300" height="400" src="' + esc(thumbOf(v.url)) + '" alt="' + esc(titleOf(v)) + '"><span>' + esc(titleOf(v)) + "</span></a></li>";
const gridOf = l => l.length ? '<ul class="grid">' + l.map(card).join("") + "</ul>" : "";
const itemList = (name, l) => jsonLd({ "@context": "https://schema.org", "@type": "ItemList", name, itemListElement: l.slice(0, 30).map((v, i) => ({ "@type": "ListItem", position: i + 1, url: vUrl(v) })) });

function send(res, code, type, body, cache) {
  res.statusCode = code;
  res.setHeader("Content-Type", type);
  res.setHeader("Cache-Control", cache || "public, s-maxage=300, stale-while-revalidate=86400");
  res.end(body);
}
function notFound(res, what) {
  send(res, 404, "text/html; charset=utf-8", shell({ title: what + " not found | ClipVerse", desc: "This page is not available on ClipVerse.", canonical: SITE + "/", noindex: true, body: "<h1>" + esc(what) + " not found</h1><p>It may have been removed. <a href=\"/\">Go to ClipVerse</a></p>" }), "public, s-maxage=60");
}

/* ---- pages ---- */
async function videoPage(res, id) {
  if (!ID_RE.test(id)) return notFound(res, "Video");
  const v = await fsGet("videos/" + id);
  if (!ready(v)) return notFound(res, "Video");
  const title = titleOf(v), desc = descOf(v), url = vUrl(v), thumb = thumbOf(v.url), content = oracleUrl(v.url), play = fileOf(v.url) ? CLD + content : v.url;
  const more = (await latestVideos(30)).filter(x => ready(x) && x.id !== v.id), same = more.filter(x => x.uid === v.uid), rel = same.concat(more.filter(x => x.uid !== v.uid)).slice(0, 8);
  const tags = Object.keys(CATS).filter(k => !CATS[k].popular && CATS[k].re.test((v.title || "") + " " + (v.caption || "")));
  const ld = jsonLd({
    "@context": "https://schema.org", "@type": "VideoObject", name: title, description: desc, thumbnailUrl: [thumb], uploadDate: iso(v) || undefined,
    duration: dur8601(v.duration) || undefined, contentUrl: content, embedUrl: url, url,
    interactionStatistic: { "@type": "InteractionCounter", interactionType: { "@type": "WatchAction" }, userInteractionCount: views(v) },
    author: v.uid ? { "@type": "Person", name: clean(v.user, 40) || "ClipVerse creator", url: uUrl(v.uid, v.user) } : undefined,
    publisher: { "@type": "Organization", name: "ClipVerse", logo: { "@type": "ImageObject", url: SITE + "/icon-512.png" } }, isFamilyFriendly: true
  });
  const body = '<video controls playsinline preload="none" poster="' + esc(thumb) + '" src="' + esc(play) + '"></video>' +
    "<h1>" + esc(title) + "</h1>" +
    '<p class="meta">' + (v.uid ? 'By <a href="' + esc(uUrl(v.uid, v.user)) + '">' + esc(clean(v.user, 40) || "Creator") + "</a> &middot; " : "") + views(v) + " views &middot; " + likes(v) + " likes" + (iso(v) ? " &middot; " + esc(iso(v).slice(0, 10)) : "") + "</p>" +
    "<p>" + esc(clean(v.caption, 300) || desc) + "</p>" +
    (tags.length ? '<p class="tags">' + tags.map(k => '<a href="/c/' + k + '">' + esc(CATS[k].name) + "</a>").join("") + "</p>" : "") +
    '<p><a class="btn" href="/?v=' + encodeURIComponent(v.id) + '">Watch in the ClipVerse app</a></p>' +
    (rel.length ? "<h2>More videos</h2>" + gridOf(rel) : "");
  send(res, 200, "text/html; charset=utf-8", shell({ title: title + " | ClipVerse", desc, canonical: url, image: thumb, ogType: "video.other", open: "/?v=" + encodeURIComponent(v.id), ld, body,
    ogExtra: '<meta property="og:video" content="' + esc(content) + '"><meta property="og:video:type" content="video/mp4"><meta property="og:image:alt" content="' + esc(title) + '">' }));
}

async function creatorPage(res, uid) {
  if (!ID_RE.test(uid)) return notFound(res, "Creator");
  const [u, list0] = await Promise.all([fsGet("users/" + uid), videosOf(uid)]);
  const list = list0.filter(ready).sort((a, b) => ms(b) - ms(a));
  const name = clean((u && (u.name || u.displayName)) || (list[0] && list[0].user) || "", 40);
  if (!name) return notFound(res, "Creator");
  const priv = !!(u && u.private === true), bio = clean(u && u.bio, 200);
  const url = uUrl(uid, name), total = list.reduce((n, v) => n + views(v), 0);
  const desc = priv ? name + " on ClipVerse." : (bio ? bio + " - " : "") + name + " is a creator on ClipVerse with " + list.length + " video" + (list.length === 1 ? "" : "s") + " and " + total + " views.";
  const photo = u && u.photo && /^https:\/\//.test(u.photo) ? u.photo : (list[0] ? thumbOf(list[0].url) : SITE + "/og-image.jpg");
  const ld = jsonLd({ "@context": "https://schema.org", "@type": "ProfilePage", mainEntity: { "@type": "Person", name, description: bio || undefined, image: photo, url, interactionStatistic: { "@type": "InteractionCounter", interactionType: { "@type": "WatchAction" }, userInteractionCount: total } } }) + (list.length ? itemList(name + " videos", list) : "");
  const body = "<h1>" + esc(name) + "</h1>" + '<p class="meta">' + list.length + " videos &middot; " + total + " views</p>" + (bio ? "<p>" + esc(bio) + "</p>" : "") +
    '<p><a class="btn" href="/">Open ClipVerse</a></p>' + (priv ? "<p>This profile is private.</p>" : (list.length ? "<h2>Videos</h2>" + gridOf(list) : "<p>No videos yet.</p>"));
  send(res, 200, "text/html; charset=utf-8", shell({ title: name + " (creator) | ClipVerse", desc, canonical: url, image: photo, noindex: priv || !list.length, ld, body, ogType: "profile" }));
}

async function categoryPage(res, slug) {
  const c = CATS[slug]; if (!c) return notFound(res, "Page");
  const list = catOf(c, (await latestVideos(300)).filter(ready));
  const url = SITE + "/c/" + slug, creators = [], seen = new Set();
  for (const v of list) if (v.uid && !seen.has(v.uid)) { seen.add(v.uid); creators.push(v); }
  const body = "<h1>" + esc(c.h1) + "</h1><p>" + esc(c.desc) + "</p>" +
    (list.length ? gridOf(list) : "<p>No videos here yet. Be the first - <a href=\"/\">upload on ClipVerse</a>.</p>") +
    (creators.length ? "<h2>Creators</h2><p class=\"tags\">" + creators.slice(0, 20).map(v => '<a href="' + esc(uUrl(v.uid, v.user)) + '">' + esc(clean(v.user, 40) || "Creator") + "</a>").join("") + "</p>" : "");
  send(res, 200, "text/html; charset=utf-8", shell({ title: "ClipVerse " + c.name + " - " + c.h1.replace(" on ClipVerse", "") , desc: c.desc, canonical: url, image: list[0] ? thumbOf(list[0].url) : undefined, noindex: !list.length, ld: list.length ? itemList(c.name + " on ClipVerse", list) : "", body }));
}

async function sitemap(res) {
  const list = (await latestVideos(500)).filter(ready), xmlEsc = esc, out = [];
  const u = (loc, last, extra) => out.push("<url><loc>" + xmlEsc(loc) + "</loc>" + (last ? "<lastmod>" + last + "</lastmod>" : "") + (extra || "") + "</url>");
  u(SITE + "/", list[0] ? iso(list[0]).slice(0, 10) : "");
  for (const k of Object.keys(CATS)) if (catOf(CATS[k], list).length) u(SITE + "/c/" + k);
  const seen = new Set();
  for (const v of list) {
    const t = titleOf(v), d = descOf(v).slice(0, 2000);
    u(vUrl(v), iso(v).slice(0, 10), "<video:video><video:thumbnail_loc>" + xmlEsc(thumbOf(v.url)) + "</video:thumbnail_loc><video:title>" + xmlEsc(t.slice(0, 100)) + "</video:title><video:description>" + xmlEsc(d) + "</video:description><video:content_loc>" + xmlEsc(oracleUrl(v.url)) + "</video:content_loc>" + (Number(v.duration) ? "<video:duration>" + Math.round(Number(v.duration)) + "</video:duration>" : "") + (iso(v) ? "<video:publication_date>" + iso(v) + "</video:publication_date>" : "") + "</video:video>");
    if (v.uid && !seen.has(v.uid)) { seen.add(v.uid); u(uUrl(v.uid, v.user), iso(v).slice(0, 10)); }
  }
  send(res, 200, "application/xml; charset=utf-8", '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">' + out.join("") + "</urlset>", "public, s-maxage=3600, stale-while-revalidate=86400");
}

module.exports = async (req, res) => {
  const q = req.query || {}, t = clean(one(q.t), 10);
  try {
    if (t === "v") return await videoPage(res, clean(one(q.id), 80));
    if (t === "u") return await creatorPage(res, clean(one(q.id), 80));
    if (t === "c") return await categoryPage(res, clean(one(q.slug), 40));
    if (t === "sitemap") return await sitemap(res);
  } catch (e) { return send(res, 500, "text/plain; charset=utf-8", "Temporary error. Please try again.", "no-store"); }
  return notFound(res, "Page");
};
module.exports._test = { CATS, slugify, titleOf, descOf, dur8601 };
