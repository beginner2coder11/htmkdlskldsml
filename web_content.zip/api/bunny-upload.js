/* ClipVerse -> Bunny Stream.
   POST {idToken, title}  : checks the Firebase login, creates the video in the Bunny library and returns a one-time upload signature
                            (the secret API key never leaves this server).
   GET  ?status=<videoId> : tells the app when Bunny has finished converting the video.
   Needs the Vercel environment variable BUNNY_API_KEY (Library > API > "API Key"). */
const crypto = require("crypto");
const LIB = "823512";
const FB_KEY = "AIzaSyDTojXopKRBdTGrTPzCXzpjvKIgeSdEBMo";
const API = "https://video.bunnycdn.com";
const send = (res, code, obj) => { res.statusCode = code; res.setHeader("Content-Type", "application/json"); res.setHeader("Cache-Control", "no-store"); res.end(JSON.stringify(obj)); };

module.exports = async (req, res) => {
  const KEY = process.env.BUNNY_API_KEY;
  if (!KEY) return send(res, 500, { message: "Video storage is not set up yet (BUNNY_API_KEY missing)." });
  try {
    if (req.method === "GET") {
      const id = String((req.query && req.query.status) || "");
      if (!/^[0-9a-f-]{30,40}$/i.test(id)) return send(res, 400, { message: "bad id" });
      const r = await fetch(API + "/library/" + LIB + "/videos/" + id, { headers: { AccessKey: KEY, accept: "application/json" } });
      if (!r.ok) return send(res, r.status === 404 ? 404 : 502, { message: "status unavailable" });
      const j = await r.json();
      const hs = String(j.availableResolutions || "").split(",").map(s => parseInt(s.replace(/\D/g, ""), 10)).filter(Boolean).sort((a, b) => b - a);
      return send(res, 200, { status: j.status, done: j.status === 4, error: j.status === 5 || j.status === 6, heights: hs });
    }
    if (req.method !== "POST") return send(res, 405, { message: "POST only" });
    let b = req.body; if (typeof b === "string") { try { b = JSON.parse(b); } catch (e) { b = {}; } } b = b || {};
    const idToken = String(b.idToken || ""); if (!idToken) return send(res, 401, { message: "Please log in again." });
    const lk = await fetch("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + FB_KEY, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken }) });
    const lj = await lk.json().catch(() => ({}));
    if (!lk.ok || !lj.users || !lj.users[0]) return send(res, 401, { message: "Please log in again." });
    const title = String(b.title || "ClipVerse video").replace(/[\u0000-\u001f]/g, " ").slice(0, 90) || "ClipVerse video";
    const cr = await fetch(API + "/library/" + LIB + "/videos", { method: "POST", headers: { AccessKey: KEY, "Content-Type": "application/json", accept: "application/json" }, body: JSON.stringify({ title }) });
    const cj = await cr.json().catch(() => ({}));
    if (!cr.ok || !cj.guid) return send(res, 502, { message: "Could not start the upload (" + cr.status + ")." });
    const expire = Math.floor(Date.now() / 1000) + 6 * 3600;
    const signature = crypto.createHash("sha256").update(LIB + KEY + expire + cj.guid).digest("hex");
    return send(res, 200, { videoId: cj.guid, libraryId: LIB, expire, signature, endpoint: API + "/tusupload" });
  } catch (e) { return send(res, 500, { message: "Server error" }); }
};
