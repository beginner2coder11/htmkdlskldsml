(function () {
  'use strict';

  const STORAGE_KEY = 'afz_people_goods_ledger_v1';
  const SAVED_NAMES_KEY = 'afz_people_goods_names_v1';
  const PAGE_ID = 'afzPeopleLedger';
  const STYLE_ID = 'afz-people-ledger-sheet-styles';
  const palette = [
    { head:'#00e91b', soft:'#dff8e2', text:'#17451d', edge:'#79cc83' },
    { head:'#17c9df', soft:'#def8fb', text:'#104956', edge:'#6bcbd5' },
    { head:'#ffd45e', soft:'#fff6d7', text:'#674d08', edge:'#e2bf4c' },
    { head:'#bd9bf5', soft:'#f1eaff', text:'#42286f', edge:'#a17add' },
    { head:'#ffad83', soft:'#fff0e7', text:'#7c3d20', edge:'#e89568' },
    { head:'#9fc7ff', soft:'#eaf3ff', text:'#264b7c', edge:'#79a9e5' },
    { head:'#ff9fbd', soft:'#fff0f5', text:'#7d2f4a', edge:'#e77b9e' },
    { head:'#9bd9bd', soft:'#e7f8ef', text:'#20583b', edge:'#75bf99' }
  ];
  let editingId = null;
  let selectedPairKey = null;
  let selectedDate = null;
  let followToday = true;

  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    #afzPeopleLedger .ledger-sheet-shell{background:#fff;border:1px solid #d8e0e3;border-radius:12px;overflow:hidden;margin:12px 0}
    #afzPeopleLedger .ledger-title-row{padding:11px 13px;background:#f6f8f6;border-bottom:1px solid #d7ded9;display:flex;justify-content:space-between;gap:8px;align-items:center}
    #afzPeopleLedger .ledger-title-row h3{margin:0;color:#173b2a;font-size:18px}
    #afzPeopleLedger .ledger-title-row small{color:#697b70;font-size:11px}
    #afzPeopleLedger .ledger-intro{margin:8px 0 12px;color:#5f6d66;line-height:1.6;font-size:13px}
    #afzPeopleLedger .ledger-day-controls{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin:10px 0}
    #afzPeopleLedger .ledger-day-controls label{font-size:12px;font-weight:800;color:#405c49}
    #afzPeopleLedger .ledger-day-controls select{flex:1;min-width:150px;min-height:38px;border:1px solid #cbd9cf;border-radius:8px;padding:7px;background:#fff;font:inherit}
    #afzPeopleLedger .ledger-day-today{min-height:38px;border:1px solid #0b4f8a;border-radius:8px;padding:7px 11px;background:#fff;color:#0b4f8a;font-weight:800}
    #afzPeopleLedger .ledger-day-title{margin:10px 0 6px;color:#173b2a;font-size:15px}
    #afzPeopleLedger .ledger-opening-balance{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0 12px;padding:11px 12px;border:2px solid #809fd1;border-radius:10px;background:#eef4ff;color:#193b76}
    #afzPeopleLedger .ledger-opening-balance small{font-size:11px;color:#536a8f}
    #afzPeopleLedger .ledger-opening-balance strong{font-size:14px;text-align:left;direction:rtl}
    #afzPeopleLedger .ledger-tabs{display:flex;gap:6px;overflow-x:auto;margin:10px 0;padding:2px 0 7px}
    #afzPeopleLedger .ledger-tabs button{flex:none;border:1px solid #ccd9d1;background:#f7faf8;color:#344d3b;border-radius:9px;padding:8px 11px;font-weight:800;cursor:pointer}
    #afzPeopleLedger .ledger-tabs button.active{background:#0b4f8a;color:#fff;border-color:#0b4f8a}
    #afzPeopleLedger .ledger-empty{padding:18px;text-align:center;background:#f8faf9;border:1px dashed #bac9bf;border-radius:12px;color:#65756b;margin:12px 0}
    #afzPeopleLedger .ledger-sheet-tools{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin:10px 0}
    #afzPeopleLedger .ledger-add-button{border:0;border-radius:9px;background:#0b4f8a;color:#fff;font-weight:900;padding:10px 14px;cursor:pointer}
    #afzPeopleLedger .ledger-edit-note{font-size:11px;color:#66776c}
    #afzPeopleLedger .ledger-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;background:#f6faf7;border:1px solid #d4e4d8;border-radius:12px;padding:12px;margin:10px 0}
    #afzPeopleLedger .ledger-form[hidden]{display:none!important}
    #afzPeopleLedger .ledger-form label{display:block;font-size:12px;font-weight:800;color:#405c49;margin-bottom:4px}
    #afzPeopleLedger .ledger-form input{width:100%;box-sizing:border-box;min-height:38px;border:1px solid #cbd9cf;border-radius:8px;padding:8px 9px;background:#fff;font-size:14px}
    #afzPeopleLedger .ledger-name-picker{position:relative;z-index:20;width:100%}
    #afzPeopleLedger .ledger-name-field{position:relative;z-index:1}
    #afzPeopleLedger .ledger-name-field.is-open{z-index:100}
    #afzPeopleLedger .ledger-name-control{display:flex;gap:5px;align-items:stretch}
    #afzPeopleLedger .ledger-name-control input{flex:1;min-width:0}
    #afzPeopleLedger .ledger-name-arrow{flex:0 0 40px;min-height:38px;border:1px solid #cbd9cf;border-radius:8px;background:#fff;color:#0b4f8a;font-size:18px;font-weight:900;cursor:pointer;touch-action:manipulation}
    #afzPeopleLedger .ledger-name-menu[hidden]{display:none!important}
    #afzPeopleLedger .ledger-name-menu{position:absolute;top:calc(100% + 3px);left:0;right:0;z-index:100;max-height:190px;overflow-y:auto;padding:4px;border:1px solid #b9cbbd;border-radius:9px;background:#fff;box-shadow:0 8px 18px rgba(20,45,30,.18)}
    #afzPeopleLedger .ledger-name-option{display:block;width:100%;padding:9px 10px;border:0;border-radius:6px;background:#fff;color:#243f2d;text-align:right;font:inherit;cursor:pointer}
    #afzPeopleLedger .ledger-name-option:hover,#afzPeopleLedger .ledger-name-option:focus{background:#eef6f0}
    #afzPeopleLedger .ledger-name-empty{padding:9px;text-align:center;color:#78877c;font-size:12px}
    #afzPeopleLedger .ledger-form .full{grid-column:1/-1}
    #afzPeopleLedger .ledger-form-buttons{display:flex;gap:8px;flex-wrap:wrap}
    #afzPeopleLedger .ledger-form-buttons button{border:0;border-radius:8px;padding:10px 14px;font-weight:900;cursor:pointer}
    #afzPeopleLedger .ledger-save{background:#0b4f8a;color:#fff}
    #afzPeopleLedger .ledger-cancel{background:#e8edf0;color:#26332a}
    #afzPeopleLedger .ledger-preview-result{grid-column:1/-1;background:#eef4ff;border:1px solid #c7d6ef;border-radius:8px;padding:9px 10px;color:#244478;font-weight:800;font-size:12px}
    #afzPeopleLedger .ledger-pair-sheet{border:1px solid #d3d9d5;border-radius:10px;overflow:hidden;margin:12px 0;background:#fff}
    #afzPeopleLedger .ledger-person-title{background:var(--person-head);color:#101710;font-weight:900;text-align:center;padding:9px 6px;font-size:14px}
    #afzPeopleLedger .ledger-table-wrap{width:100%;max-height:360px;overflow:auto;overscroll-behavior:contain}
    #afzPeopleLedger table.ledger-grid thead th{position:sticky;top:0;z-index:2}
    #afzPeopleLedger table.ledger-grid{width:100%;min-width:0;border-collapse:collapse;table-layout:fixed;direction:ltr}
    #afzPeopleLedger table.ledger-grid th,#afzPeopleLedger table.ledger-grid td{border:1px solid #c8cfca;padding:4px 2px;text-align:right;direction:rtl;vertical-align:middle;font-size:9px;line-height:1.3;overflow-wrap:anywhere}
    #afzPeopleLedger table.ledger-grid th:nth-child(1),#afzPeopleLedger table.ledger-grid td:nth-child(1){width:20%}
    #afzPeopleLedger table.ledger-grid th:nth-child(2),#afzPeopleLedger table.ledger-grid td:nth-child(2){width:25%}
    #afzPeopleLedger table.ledger-grid th:nth-child(3),#afzPeopleLedger table.ledger-grid td:nth-child(3){width:20%}
    #afzPeopleLedger table.ledger-grid th:nth-child(4),#afzPeopleLedger table.ledger-grid td:nth-child(4){width:35%}
    #afzPeopleLedger table.ledger-grid thead th{background:var(--person-soft);color:var(--person-text);font-weight:900}
    #afzPeopleLedger table.ledger-grid .amount{direction:ltr!important;text-align:left!important;white-space:nowrap;font-weight:800;font-size:8px}
    #afzPeopleLedger table.ledger-grid .ledger-total td{background:var(--person-soft);font-weight:900;color:var(--person-text)}
    #afzPeopleLedger table.ledger-grid .ledger-total .amount{font-size:12px}
    /* Spreadsheet-like ledger layout requested by the user */
    #afzPeopleLedger table.ledger-grid th{background:#00e91b!important;color:#111!important;font-size:11px;padding:7px 4px;border-color:#b7b7b7}
    #afzPeopleLedger table.ledger-grid td{font-size:11px;padding:7px 4px;border-color:#c7c7c7;line-height:1.35}
    #afzPeopleLedger table.ledger-grid th:nth-child(1),#afzPeopleLedger table.ledger-grid td:nth-child(1){width:22%}
    #afzPeopleLedger table.ledger-grid th:nth-child(2),#afzPeopleLedger table.ledger-grid td:nth-child(2){width:20%}
    #afzPeopleLedger table.ledger-grid th:nth-child(3),#afzPeopleLedger table.ledger-grid td:nth-child(3){width:20%}
    #afzPeopleLedger table.ledger-grid th:nth-child(4),#afzPeopleLedger table.ledger-grid td:nth-child(4){width:38%}
    #afzPeopleLedger table.ledger-grid .ledger-total td{background:#fff000!important;color:#111!important;border-color:#c7c7c7}
    #afzPeopleLedger table.ledger-grid .ledger-total .amount{font-size:12px}
    #afzPeopleLedger .ledger-pair-sheet{border-radius:0;border-color:#c7c7c7}
    #afzPeopleLedger .ledger-person-title{border-bottom:1px solid #c7c7c7}
    #afzPeopleLedger .ledger-row-actions{display:flex;gap:4px;white-space:nowrap}
    #afzPeopleLedger .ledger-row-actions button{border:0;border-radius:6px;padding:5px 7px;font-size:10px;font-weight:800;cursor:pointer}
    #afzPeopleLedger .ledger-row-actions .edit{background:#edf4f9;color:#0b4f8a}
    #afzPeopleLedger .ledger-row-actions .delete{background:#fff0ed;color:#a33926}
    #afzPeopleLedger .ledger-separator{height:10px;background:#05dfe2;border-top:1px solid #50bdc1;border-bottom:1px solid #50bdc1;margin:12px 0}
    #afzPeopleLedger .ledger-common-result{display:grid;grid-template-columns:minmax(120px,1fr) auto;align-items:center;gap:8px;margin:14px 0;padding:12px 13px;border:2px solid #809fd1;border-radius:10px;background:#eef4ff;color:#193b76}
    #afzPeopleLedger .ledger-common-result small{display:block;font-size:11px;color:#536a8f;margin-bottom:3px}
    #afzPeopleLedger .ledger-common-result strong{font-size:18px;direction:ltr;white-space:nowrap}
    #afzPeopleLedger .ledger-common-result .ledger-result-label{font-weight:900;font-size:13px}
    #afzPeopleLedger .ledger-browse-note{padding:9px 11px;border-radius:9px;background:#fff8e8;color:#694b0b;border:1px solid #f0dda9;margin:9px 0;font-size:12px;line-height:1.5}
    #afzPeopleLedger [hidden],#afzPeopleLedger .no-print[hidden]{display:none!important}
    @media(max-width:480px){#afzPeopleLedger .ledger-form{grid-template-columns:1fr}#afzPeopleLedger .ledger-form .full{grid-column:auto}#afzPeopleLedger .ledger-common-result{grid-template-columns:1fr;text-align:center}}
    @media print{#afzPeopleLedger .no-print,#afzPeopleLedger .ledger-tabs{display:none!important}#afzPeopleLedger .ledger-table-wrap{overflow:visible!important;max-height:none!important}#afzPeopleLedger table.ledger-grid{min-width:0!important}}
  `;
  document.head.appendChild(style);

  function lang() { return document.documentElement.lang === 'fr' ? 'fr' : 'ar'; }
  function t(ar, fr) { return lang() === 'fr' ? fr : ar; }
  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
      return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[ch];
    });
  }
  function keyName(value) { return String(value || '').trim().toLocaleLowerCase(); }
  function localDate() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function money(value) { return (Number(value) || 0).toFixed(2) + ' DH'; }
  function sheetMoney(value) { return (Number(value) || 0).toFixed(2).replace(/\.00$/,'').replace(/(\.\d)0$/,'$1') + ' DH'; }
  function canEdit() { return typeof window.AFZ_CAN_EDIT === 'function' && window.AFZ_CAN_EDIT(); }
  function pairKey(a,b) { return [keyName(a),keyName(b)].sort().join('\u0000'); }

  function readRows() {
    try {
      const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(rows) ? rows.filter(function (row) {
        return row && typeof row === 'object' && String(row.from || '').trim() && String(row.to || '').trim();
      }) : [];
    } catch (e) {
      console.warn('People ledger storage could not be read', e);
      return [];
    }
  }
  function writeRows(rows) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
      return true;
    } catch (e) {
      console.error('People ledger storage could not be saved', e);
      alert(t('تعذر حفظ الحركة على هذا الجهاز.','Impossible d’enregistrer le mouvement sur cet appareil.'));
      return false;
    }
  }

  function readSavedPeople() {
    try {
      const values=JSON.parse(localStorage.getItem(SAVED_NAMES_KEY)||'[]');
      if(!Array.isArray(values)) return [];
      const names=new Map();
      values.forEach(function(value){const name=String(value||'').trim().replace(/\s+/g,' ');if(name.length>=2&&!names.has(keyName(name)))names.set(keyName(name),name);});
      return Array.from(names.values());
    } catch(e) { return []; }
  }
  function updatePeopleSuggestions(rows) {
    const names=new Map();
    readSavedPeople().forEach(function(name){names.set(keyName(name),name);});
    (rows||readRows()).forEach(function(row){[row.from,row.to].forEach(function(value){const name=String(value||'').trim().replace(/\s+/g,' ');if(name&&!names.has(keyName(name)))names.set(keyName(name),name);});});
    const sorted=Array.from(names.values()).sort(function(a,b){return a.localeCompare(b,lang()==='fr'?'fr':'ar');});
    const list=document.getElementById('ledgerPeople');
    if(list) list.innerHTML=sorted.map(function(name){return '<option value="'+esc(name)+'"></option>';}).join('');
    ['ledgerFrom','ledgerTo'].forEach(function(inputId){
      const menu=document.getElementById(inputId+'Menu'); if(!menu) return;
      menu.innerHTML=sorted.length?sorted.map(function(name){return '<button type="button" class="ledger-name-option" role="option" data-name-option="'+inputId+'" data-name-value="'+esc(name)+'">'+esc(name)+'</button>';}).join(''):'<div class="ledger-name-empty">'+esc(t('لا توجد أسماء محفوظة بعد.','Aucun nom enregistré pour le moment.'))+'</div>';
    });
  }
  function closePeopleMenus(page) {
    page.querySelectorAll('.ledger-name-menu').forEach(function(menu){menu.hidden=true;});
    page.querySelectorAll('[data-name-toggle]').forEach(function(button){button.setAttribute('aria-expanded','false');});
    page.querySelectorAll('.ledger-name-field').forEach(function(field){field.classList.remove('is-open');});
  }
  function rememberPersonName(value) {
    const name=String(value||'').trim().replace(/\s+/g,' ');
    if(name.length<2) return;
    const names=readSavedPeople();
    if(!names.some(function(saved){return keyName(saved)===keyName(name);})){
      names.push(name);
      try { localStorage.setItem(SAVED_NAMES_KEY,JSON.stringify(names)); }
      catch(e) { console.warn('People name could not be saved',e); }
    }
    updatePeopleSuggestions(readRows());
  }

  function pairData(rows, viewDate) {
    const targetDate = String(viewDate || selectedDate || localDate());
    const pairs = new Map();
    rows.forEach(function (row, index) {
      const from = String(row.from || '').trim();
      const to = String(row.to || '').trim();
      const fromKey = keyName(from), toKey = keyName(to);
      if (!fromKey || !toKey || fromKey === toKey) return;
      const key = pairKey(from,to);
      let pair = pairs.get(key);
      if (!pair) {
        pair = { key:key, aKey:fromKey, bKey:toKey, aName:from, bName:to, aRows:[], bRows:[], aTotal:0, bTotal:0, createdAt:Number(row.createdAt || index) };
        pairs.set(key,pair);
      }
      const value = Math.max(0,Number(row.amount) || 0);
      if (fromKey === pair.aKey) { pair.aRows.push(row); pair.aTotal += value; }
      else { pair.bRows.push(row); pair.bTotal += value; }
    });
    const built = [];
    pairs.forEach(function (pair) {
      const byDate = function (a,b) { return String(a.date || '').localeCompare(String(b.date || '')) || Number(a.createdAt || 0) - Number(b.createdAt || 0); };
      const allA = pair.aRows.slice().sort(byDate), allB = pair.bRows.slice().sort(byDate);
      const dateOf = function(row){return String(row.date || targetDate);};
      const priorA = allA.filter(function(row){return dateOf(row)<targetDate;});
      const priorB = allB.filter(function(row){return dateOf(row)<targetDate;});
      const dayA = allA.filter(function(row){return dateOf(row)===targetDate;});
      const dayB = allB.filter(function(row){return dateOf(row)===targetDate;});
      const existedByDate = allA.concat(allB).some(function(row){return dateOf(row)<=targetDate;});
      if(!existedByDate) return;
      const total = function(list){return list.reduce(function(sum,row){return sum+Math.max(0,Number(row.amount)||0);},0);};
      pair.openingRowsCount = priorA.length + priorB.length;
      pair.openingNet = total(priorA)-total(priorB);
      pair.dayATotal = total(dayA); pair.dayBTotal = total(dayB);
      pair.dayNet = pair.dayATotal-pair.dayBTotal;
      pair.aRows = dayA; pair.bRows = dayB;
      // Show the carried opening balance as a prior-day row, but keep dayNet
      // limited to real movements so the final balance is not double-counted.
      if (Math.abs(pair.openingNet) >= 0.005) {
        const priorDateParts = targetDate.split('-').map(Number);
        const priorDate = new Date(Date.UTC(priorDateParts[0], priorDateParts[1]-1, priorDateParts[2]-1));
        const openingDate = priorDate.getUTCFullYear() + '-' + String(priorDate.getUTCMonth()+1).padStart(2,'0') + '-' + String(priorDate.getUTCDate()).padStart(2,'0');
        const openingRow = { id:'__opening_balance__', amount:Math.abs(pair.openingNet), goods:t('حساب قديم','Ancien solde'), date:openingDate, createdAt:0, isOpeningBalance:true };
        if (pair.openingNet > 0) pair.aRows.unshift(openingRow);
        else pair.bRows.unshift(openingRow);
      }
      pair.net = pair.openingNet+pair.dayNet;
      pair.resultName = Math.abs(pair.net)<0.005 ? '' : (pair.net>0 ? pair.bName : pair.aName);
      pair.resultAmount = Math.abs(pair.net);
      built.push(pair);
    });
    return built.sort(function (a,b) { var aHasBalance = Math.abs(a.net) >= 0.005; var bHasBalance = Math.abs(b.net) >= 0.005; if (aHasBalance !== bHasBalance) return aHasBalance ? -1 : 1; if (aHasBalance && bHasBalance && Math.abs(a.net) !== Math.abs(b.net)) return Math.abs(b.net) - Math.abs(a.net); return a.aName.localeCompare(b.aName,lang()==='fr'?'fr':'ar') || a.bName.localeCompare(b.bName); });
  }

  function colorMap(pairs) {
    const names = Array.from(new Set(pairs.reduce(function (all,pair) { return all.concat([pair.aName,pair.bName]); },[]))).sort(function (a,b) { return a.localeCompare(b,lang() === 'fr' ? 'fr' : 'ar'); });
    const map = new Map();
    names.forEach(function (name,index) { map.set(keyName(name),palette[index % palette.length]); });
    return map;
  }
  function colorFor(name,map,avoid) {
    const found = map.get(keyName(name)) || palette[0];
    if (avoid && found === avoid) return palette[(palette.indexOf(found) + 1) % palette.length];
    return found;
  }
  function isEditMode() { return canEdit(); }

  function buildPage() {
    const main = document.querySelector('main');
    if (!main) return;
    const nav = document.querySelector('nav');
    if (nav && !document.getElementById('afzPeopleLedgerNav')) {
      const button = document.createElement('button');
      button.id = 'afzPeopleLedgerNav'; button.type = 'button';
      button.addEventListener('click',openPage); nav.appendChild(button);
    }
    let page = document.getElementById(PAGE_ID);
    if (!page) {
      page = document.createElement('section'); page.id = PAGE_ID; page.className = 'page';
      page.innerHTML = `
        <div class="ledger-title-row"><h3 data-ledger-title></h3><small data-ledger-tag></small></div>
        <p class="ledger-intro" data-ledger-intro></p>
        <div class="ledger-day-controls no-print"><label for="ledgerDaySelect" data-ledger-day-label></label><select id="ledgerDaySelect"></select><button id="ledgerTodayButton" class="ledger-day-today" type="button"></button></div>
        <h4 id="ledgerDayTitle" class="ledger-day-title"></h4>
        <div id="ledgerOpeningBalance" class="ledger-opening-balance"><small data-ledger-opening-title></small><strong id="ledgerOpeningValue"></strong></div>
        <div id="ledgerBrowseNote" class="ledger-browse-note" hidden></div>
        <div id="ledgerTabs" class="ledger-tabs no-print"></div>
        <div id="ledgerSheets"></div>
        <div id="ledgerEmpty" class="ledger-empty" hidden></div>
        <div id="ledgerSharedResult" class="ledger-common-result" hidden><div><small data-ledger-common-title></small><div id="ledgerResultLabel" class="ledger-result-label"></div></div><strong id="ledgerResultAmount"></strong></div>
        <div class="ledger-sheet-tools no-print ledger-edit-only" hidden><button id="ledgerAdd" type="button" class="ledger-add-button"></button><span id="ledgerEditHint" class="ledger-edit-note"></span></div>
        <form id="peopleLedgerForm" class="ledger-form no-print" autocomplete="off" hidden>
          <div><label for="ledgerDate" data-ledger-label="date"></label><input id="ledgerDate" type="date" required></div>
          <div><label for="ledgerGoods" data-ledger-label="goods"></label><input id="ledgerGoods" type="text" maxlength="120" required></div>
          <div class="ledger-name-field"><label for="ledgerFrom" data-ledger-label="from"></label><div class="ledger-name-picker"><div class="ledger-name-control"><input id="ledgerFrom" type="text" list="ledgerPeople" maxlength="100" required><button type="button" class="ledger-name-arrow" data-name-toggle="ledgerFrom" aria-controls="ledgerFromMenu" aria-expanded="false">▾</button></div><div id="ledgerFromMenu" class="ledger-name-menu" role="listbox" hidden></div></div></div>
          <div class="ledger-name-field"><label for="ledgerTo" data-ledger-label="to"></label><div class="ledger-name-picker"><div class="ledger-name-control"><input id="ledgerTo" type="text" list="ledgerPeople" maxlength="100" required><button type="button" class="ledger-name-arrow" data-name-toggle="ledgerTo" aria-controls="ledgerToMenu" aria-expanded="false">▾</button></div><div id="ledgerToMenu" class="ledger-name-menu" role="listbox" hidden></div></div></div>
          <datalist id="ledgerPeople"></datalist>
          <div><label for="ledgerAmount" data-ledger-label="amount"></label><input id="ledgerAmount" type="number" min="0.01" step="0.01" inputmode="decimal" required></div>
          <div class="ledger-preview-result" id="ledgerLivePreview"></div>
          <div class="ledger-form-buttons full"><button id="ledgerSave" class="ledger-save" type="submit"></button><button id="ledgerCancel" class="ledger-cancel" type="button"></button></div>
        </form>`;
      main.appendChild(page); bindPage(page);
    }
    applyLabels(); applyMode(); render();
  }

  function applyLabels() {
    const page = document.getElementById(PAGE_ID); if (!page) return;
    const nav = document.getElementById('afzPeopleLedgerNav');
    if (nav) nav.textContent = t('دفتر الحسابات','Livre des comptes');
    page.querySelector('[data-ledger-title]').textContent = t('دفتر الحسابات','Livre des comptes');
    page.querySelector('[data-ledger-tag]').textContent = t('جداول مستقلة · نتيجة مشتركة','Tableaux séparés · résultat commun');
    page.querySelector('[data-ledger-intro]').textContent = t('لكل شخص جدول بلون خاص، وخانة النتيجة المشتركة تحسب الفرق تلقائيًا بين مجموع الحركات.','Chaque personne a son tableau et sa couleur ; le résultat commun calcule automatiquement la différence des mouvements.');
    page.querySelector('[data-ledger-day-label]').textContent = t('عرض سجل يوم','Afficher le registre du jour');
    page.querySelector('#ledgerTodayButton').textContent = t('اليوم','Aujourd’hui');
    page.querySelector('[data-ledger-opening-title]').textContent = t('النتيجة السابقة المرحّلة','Solde précédent reporté');
    page.querySelector('[data-ledger-common-title]').textContent = t('النتيجة المشتركة بين الشخصين','Résultat commun entre les deux personnes');
    const labels = {
      date:['التاريخ','Date'], goods:['نوع السلعة','Type de marchandise'], from:['من (الشخص الذي دفع/سلّم)','De (personne qui a remis)'],
      to:['إلى (الشخص الآخر)','À (l’autre personne)'], amount:['الثمن بالدرهم','Montant (DH)']
    };
    page.querySelectorAll('[data-ledger-label]').forEach(function (node) { const pair=labels[node.getAttribute('data-ledger-label')]; if(pair) node.textContent=pair[lang()==='fr'?1:0]; });
    page.querySelectorAll('[data-name-toggle]').forEach(function(button){const label=t('عرض الأسماء المحفوظة','Afficher les noms enregistrés');button.setAttribute('aria-label',label);button.title=label;});
    page.querySelector('#ledgerAdd').textContent = t('＋ إضافة حركة','＋ Ajouter un mouvement');
    page.querySelector('#ledgerEditHint').textContent = t('المجموع والنتيجة يتحدّثان تلقائيًا بعد الحفظ.','Les totaux et le résultat se mettent à jour après l’enregistrement.');
    page.querySelector('#ledgerSave').textContent = editingId ? t('حفظ التعديل','Enregistrer les modifications') : t('حفظ الحركة','Enregistrer le mouvement');
    page.querySelector('#ledgerCancel').textContent = t('إلغاء','Annuler');
    page.querySelector('#ledgerBrowseNote').textContent = t('وضع التصفح: يمكنك مراجعة الجداول ومعاينة أو تنزيل PDF. أضف أو عدّل الحركات من وضع التعديل.','Mode consultation : consultez les tableaux et prévisualisez ou téléchargez le PDF. Modifiez les mouvements en mode édition.');
    page.querySelector('#ledgerEmpty').textContent = t('لا توجد حركات بعد. أضف أول حركة في وضع التعديل لإنشاء جدول الشخصين.','Aucun mouvement. Ajoutez-en un en mode édition pour créer les tableaux des deux personnes.');
  }

  function applyMode() {
    const page = document.getElementById(PAGE_ID); if (!page) return;
    const edit = isEditMode();
    const note = page.querySelector('#ledgerBrowseNote'); if (note) note.hidden = edit;
    const tools = page.querySelector('.ledger-sheet-tools'); if (tools) tools.hidden = !edit;
    page.querySelectorAll('.ledger-row-actions').forEach(function (node) { node.hidden = !edit; });
  }

  function formatDate(value) {
    if (!value) return '';
    const parts = String(value).split('-');
    if (parts.length !== 3) return value;
    return parts[2] + '/' + parts[1] + '/' + parts[0];
  }
  function formatDayDisplay(value) {
    const parts=String(value||'').split('-');
    if(parts.length!==3) return value||'';
    const date=new Date(Number(parts[0]),Number(parts[1])-1,Number(parts[2]),12,0,0);
    return date.toLocaleDateString(lang()==='fr'?'fr-MA':'ar-MA',{day:'numeric',month:'long',year:'numeric'});
  }
  function dayOptionLabel(value) {
    return (value===localDate()?t('اليوم — ','Aujourd’hui — '):'')+formatDayDisplay(value);
  }
  function resultLabel(pair) {
    if (!pair || Math.abs(pair.net) < 0.005) return t('الحساب متوازن','Compte équilibré');
    return t('الباقي عند ','Reste chez ') + pair.resultName;
  }
  function resultText(pair) {
    if (!pair) return t('أدخل الأسماء والمبالغ لحساب النتيجة.','Saisissez les noms et les montants pour calculer le résultat.');
    if (Math.abs(pair.net) < 0.005) return t('المجموعان متساويان.','Les deux totaux sont égaux.');
    return resultLabel(pair) + ' · ' + money(pair.resultAmount);
  }

  function renderPersonTable(person,other,rows,total,tone) {
    const title = esc(t('جدول ','Tableau de ') + person);
    const direction = esc(person + t(' دفع لـ ',' a remis à ') + other);
    const records = rows.length ? rows.map(function (row) {
      const actions = row.isOpeningBalance ? '' : '<div class="ledger-row-actions no-print"' + (isEditMode() ? '' : ' hidden') + '><button class="edit" type="button" data-ledger-edit="' + esc(row.id) + '">' + esc(t('تعديل','Modifier')) + '</button><button class="delete" type="button" data-ledger-delete="' + esc(row.id) + '">' + esc(t('حذف','Supprimer')) + '</button></div>';
      const goods = row.isOpeningBalance ? t('حساب قديم','Ancien solde') : (row.goods || '');
      const rowDirection = row.isOpeningBalance ? t('الباقي عند ','Reste chez ') + other + t(' من الحساب القديم',' du compte précédent') : direction;
      return '<tr><td class="amount">' + sheetMoney(row.amount) + '</td><td>' + esc(goods) + '</td><td>' + esc(formatDate(row.date)) + '</td><td><span>' + esc(rowDirection) + '</span>' + actions + '</td></tr>';
    }).join('') : '<tr><td colspan="4" class="ledger-no-rows">' + esc(t('لا توجد حركات لهذا الشخص في هذا اليوم.','Aucun mouvement pour cette personne ce jour.')) + '</td></tr>';
    return '<div class="ledger-pair-sheet" style="--person-head:' + tone.head + ';--person-soft:' + tone.soft + ';--person-text:' + tone.text + ';--person-edge:' + tone.edge + '">' +
      '<div class="ledger-person-title">' + title + '</div><div class="ledger-table-wrap"><table class="ledger-grid"><thead>' +
      '<tr><th>' + esc(t('الثمن بالدرهم','Montant (DH)')) + '</th><th>' + esc(t('نوع السلعة','Article')) + '</th><th>' + esc(t('التاريخ','Date')) + '</th><th>' + esc(t('الحركة','Mouvement')) + '</th></tr></thead><tbody>' + records +
      '<tr class="ledger-total"><td class="amount">' + sheetMoney(total) + '</td><td colspan="3">' + esc(t('مجموع حركات ','Total des mouvements de ') + person + t(' لهذا اليوم',' ce jour')) + '</td></tr></tbody></table></div></div>';
  }

  function render() {
    const page = document.getElementById(PAGE_ID); if (!page) return;
    if(!selectedDate || (followToday && selectedDate!==localDate())) selectedDate=localDate();
    applyMode();
    const rows = readRows();
    updatePeopleSuggestions(rows);
    const daySelect=page.querySelector('#ledgerDaySelect');
    const dates=Array.from(new Set([localDate()].concat(rows.map(function(row){return String(row.date||'');}).filter(Boolean)))).sort(function(a,b){return b.localeCompare(a);});
    daySelect.innerHTML=dates.map(function(date){return '<option value="'+esc(date)+'">'+esc(dayOptionLabel(date))+'</option>';}).join('');
    if(!dates.includes(selectedDate)){dates.push(selectedDate);dates.sort(function(a,b){return b.localeCompare(a);});daySelect.innerHTML=dates.map(function(date){return '<option value="'+esc(date)+'">'+esc(dayOptionLabel(date))+'</option>';}).join('');}
    daySelect.value=selectedDate;
    page.querySelector('#ledgerDayTitle').textContent=t('سجل يوم ','Registre du ')+formatDayDisplay(selectedDate);
    const pairs = pairData(rows,selectedDate);
    const colors = colorMap(pairs);
    const tabs = page.querySelector('#ledgerTabs');
    const empty = page.querySelector('#ledgerEmpty');
    const sheets = page.querySelector('#ledgerSheets');
    const shared = page.querySelector('#ledgerSharedResult');
    const openingValue=page.querySelector('#ledgerOpeningValue');
    if (!pairs.length) {
      tabs.innerHTML=''; sheets.innerHTML=''; empty.hidden=false; shared.hidden=true;
      empty.textContent=rows.length?t('لا توجد حركات مسجلة في هذا اليوم. اختر يومًا آخر لمراجعة السجلات السابقة.','Aucun mouvement ce jour. Choisissez une autre date pour consulter l’historique.'):
        t('لا توجد حركات بعد. أضف أول حركة في وضع التعديل لإنشاء جدول الشخصين.','Aucun mouvement. Ajoutez-en un en mode édition pour créer les tableaux des deux personnes.');
      openingValue.textContent=t('لا يوجد رصيد سابق · 0 DH','Aucun solde précédent · 0 DH');
      updateLivePreview(null);
      return;
    }
    empty.hidden=true;
    if (!selectedPairKey || !pairs.some(function(p){return p.key===selectedPairKey;})) selectedPairKey=pairs[0].key;
    tabs.innerHTML=pairs.map(function(pair){return '<button type="button" class="' + (pair.key===selectedPairKey?'active':'') + '" data-ledger-pair="' + encodeURIComponent(pair.key) + '">' + esc(pair.aName + ' ↔ ' + pair.bName) + '</button>';}).join('');
    const current=pairs.find(function(p){return p.key===selectedPairKey;})||pairs[0];
    const toneA=colorFor(current.aName,colors);
    const toneB=colorFor(current.bName,colors,toneA);
    const aFirst = Math.abs(current.openingNet)<0.005 || current.openingNet<0;
    const firstTable = aFirst
      ? renderPersonTable(current.aName,current.bName,current.aRows,current.dayATotal+Math.max(0,current.openingNet),toneA)
      : renderPersonTable(current.bName,current.aName,current.bRows,current.dayBTotal+Math.max(0,-current.openingNet),toneB);
    const secondTable = aFirst
      ? renderPersonTable(current.bName,current.aName,current.bRows,current.dayBTotal+Math.max(0,-current.openingNet),toneB)
      : renderPersonTable(current.aName,current.bName,current.aRows,current.dayATotal+Math.max(0,current.openingNet),toneA);
    sheets.innerHTML='<div class="ledger-sheet-shell"><div class="ledger-title-row"><h3>' + esc(current.aName + ' ↔ ' + current.bName) + '</h3><small>' + esc(t('حساب مستقل','Compte indépendant')) + '</small></div>' +
      firstTable + '<div class="ledger-separator no-print" aria-hidden="true"></div>' + secondTable + '</div>';
    if(Math.abs(current.openingNet)<0.005){
      openingValue.textContent=current.openingRowsCount?t('الحساب السابق متوازن · 0 DH','Solde antérieur équilibré · 0 DH'):t('لا يوجد رصيد سابق · 0 DH','Aucun solde précédent · 0 DH');
    }else{
      const owing=current.openingNet>0?current.bName:current.aName;
      openingValue.textContent=t('الباقي عند ','Reste chez ')+owing+' · '+money(Math.abs(current.openingNet));
    }
    shared.hidden=false;
    page.querySelector('#ledgerResultLabel').textContent=resultLabel(current);
    page.querySelector('#ledgerResultAmount').textContent=money(current.resultAmount);
    updateLivePreview(current);
  }

  function updateLivePreview(current) {
    const node=document.getElementById('ledgerLivePreview'); if(!node) return;
    const form=document.getElementById('peopleLedgerForm');
    if (!form || form.hidden) return;
    const from=form.querySelector('#ledgerFrom').value.trim();
    const to=form.querySelector('#ledgerTo').value.trim();
    const amount=Number(form.querySelector('#ledgerAmount').value);
    if(!from||!to||keyName(from)===keyName(to)||!Number.isFinite(amount)||amount<0){node.textContent=t('أدخل الطرفين والمبلغ لرؤية النتيجة بعد الحفظ.','Saisissez les deux personnes et le montant pour voir le résultat après l’enregistrement.');return;}
    const rows=readRows().filter(function(row){return !editingId||String(row.id)!==String(editingId);});
    rows.push({id:editingId||'__draft__',from:from,to:to,goods:'',amount:amount,date:form.querySelector('#ledgerDate').value||localDate(),createdAt:Date.now()});
    const previewDate=form.querySelector('#ledgerDate').value||selectedDate||localDate();
    const draftPair=pairData(rows,previewDate).find(function(pair){return pair.key===pairKey(from,to);});
    node.textContent=t('النتيجة بعد الحفظ: ','Résultat après enregistrement : ')+resultText(draftPair);
  }

  function openForm(row) {
    if(!isEditMode()) return;
    const page=document.getElementById(PAGE_ID), form=page.querySelector('#peopleLedgerForm');
    editingId=row?String(row.id):null;
    form.hidden=false;
    form.querySelector('#ledgerDate').value=row?.date||selectedDate||localDate();
    form.querySelector('#ledgerGoods').value=row?.goods||'';
    form.querySelector('#ledgerFrom').value=row?.from||(pairsSelected()?.aName||'');
    form.querySelector('#ledgerTo').value=row?.to||(pairsSelected()?.bName||'');
    form.querySelector('#ledgerAmount').value=row?.amount==null?'':row.amount;
    page.querySelector('#ledgerSave').textContent=editingId?t('حفظ التعديل','Enregistrer les modifications'):t('حفظ الحركة','Enregistrer le mouvement');
    updateLivePreview(); form.scrollIntoView({behavior:'smooth',block:'start'});
  }
  function pairsSelected(){return pairData(readRows(),selectedDate).find(function(pair){return pair.key===selectedPairKey;})||null;}
  function resetForm(){
    const page=document.getElementById(PAGE_ID);if(!page)return;
    closePeopleMenus(page);
    editingId=null;const form=page.querySelector('#peopleLedgerForm');form.reset();form.hidden=true;
    form.querySelector('#ledgerDate').value=selectedDate||localDate();
    page.querySelector('#ledgerSave').textContent=t('حفظ الحركة','Enregistrer le mouvement');
  }

  function bindPage(page){
    page.querySelector('#ledgerAdd').addEventListener('click',function(){openForm(null);});
    page.querySelector('#ledgerCancel').addEventListener('click',resetForm);
    page.querySelector('#ledgerDaySelect').addEventListener('change',function(){selectedDate=this.value||localDate();followToday=selectedDate===localDate();render();});
    page.querySelector('#ledgerTodayButton').addEventListener('click',function(){selectedDate=localDate();followToday=true;render();});
    ['#ledgerFrom','#ledgerTo'].forEach(function(selector){
      const input=page.querySelector(selector);
      input.addEventListener('change',function(){rememberPersonName(input.value);});
      input.addEventListener('blur',function(){rememberPersonName(input.value);});
    });
    page.querySelector('#peopleLedgerForm').addEventListener('input',function(){updateLivePreview();});
    page.querySelector('#peopleLedgerForm').addEventListener('change',function(){updateLivePreview();});
    page.querySelector('#peopleLedgerForm').addEventListener('submit',function(event){
      event.preventDefault();event.stopPropagation();
      if(!isEditMode()){alert(t('انتقل إلى وضع التعديل لإضافة حركة.','Passez en mode édition pour ajouter un mouvement.'));return;}
      const form=page.querySelector('#peopleLedgerForm');
      const date=form.querySelector('#ledgerDate').value||localDate();
      const goods=form.querySelector('#ledgerGoods').value.trim();
      const from=form.querySelector('#ledgerFrom').value.trim();
      const to=form.querySelector('#ledgerTo').value.trim();
      const amount=Number(form.querySelector('#ledgerAmount').value);
      if(!goods||!from||!to||keyName(from)===keyName(to)||!Number.isFinite(amount)||amount<=0){alert(t('أدخل التاريخ ونوع السلعة وشخصين مختلفين ومبلغًا أكبر من صفر.','Saisissez la date, l’article, deux personnes différentes et un montant supérieur à zéro.'));return;}
      rememberPersonName(from); rememberPersonName(to);
      const rows=readRows();
      const old=editingId?rows.find(function(row){return String(row.id)===String(editingId);}):null;
      const record={id:editingId||(Date.now().toString(36)+Math.random().toString(36).slice(2,8)),date:date,goods:goods,from:from,to:to,amount:Math.round(amount*100)/100,createdAt:old?Number(old.createdAt||Date.now()):Date.now()};
      const next=old?rows.map(function(row){return String(row.id)===String(editingId)?record:row;}):rows.concat(record);
      if(writeRows(next)){selectedPairKey=pairKey(from,to);selectedDate=date;followToday=date===localDate();resetForm();render();}
    });
    page.addEventListener('click',function(event){
      const nameToggle=event.target.closest('[data-name-toggle]');
      const nameOption=event.target.closest('[data-name-option]');
      if(nameToggle){
        event.preventDefault();event.stopPropagation();
        const inputId=nameToggle.getAttribute('data-name-toggle');
        const menu=page.querySelector('#'+inputId+'Menu');
        const shouldOpen=menu&&menu.hidden;
        closePeopleMenus(page);
        if(shouldOpen){updatePeopleSuggestions(readRows());menu.hidden=false;nameToggle.setAttribute('aria-expanded','true');const field=nameToggle.closest('.ledger-name-field');if(field)field.classList.add('is-open');}
        return;
      }
      if(nameOption){
        event.preventDefault();event.stopPropagation();
        const input=page.querySelector('#'+nameOption.getAttribute('data-name-option'));
        if(input){input.value=nameOption.getAttribute('data-name-value')||'';rememberPersonName(input.value);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));closePeopleMenus(page);}
        return;
      }
      if(!event.target.closest('.ledger-name-picker'))closePeopleMenus(page);
      const tab=event.target.closest('[data-ledger-pair]');
      const edit=event.target.closest('[data-ledger-edit]');
      const del=event.target.closest('[data-ledger-delete]');
      if(tab){selectedPairKey=decodeURIComponent(tab.getAttribute('data-ledger-pair')||'');render();return;}
      if(edit){event.preventDefault();event.stopPropagation();const row=readRows().find(function(item){return String(item.id)===String(edit.getAttribute('data-ledger-edit'));});if(row)openForm(row);return;}
      if(del){event.preventDefault();event.stopPropagation();if(!isEditMode())return;if(confirm(t('هل تريد حذف هذه الحركة؟ سيتم تحديث النتيجة.','Supprimer ce mouvement ? Le résultat sera recalculé.'))){const id=del.getAttribute('data-ledger-delete');if(writeRows(readRows().filter(function(row){return String(row.id)!==String(id);})))render();}}
    });
  }

  function openPage(){
    if(followToday) selectedDate=localDate();
    if(typeof window.show==='function')window.show(PAGE_ID);
    else{document.querySelectorAll('.page').forEach(function(node){node.classList.remove('active');});const page=document.getElementById(PAGE_ID);if(page)page.classList.add('active');}
    setTimeout(function(){const title=document.getElementById('sectionTitle');if(title)title.textContent=t('دفتر الحسابات','Livre des comptes');render();},0);
  }

  function init(){
    selectedDate=localDate();followToday=true;
    buildPage();
    const page=document.getElementById(PAGE_ID);
    if(page)page.querySelector('#ledgerDate').value=selectedDate;
    const modeObserver=new MutationObserver(function(){applyMode();});
    modeObserver.observe(document.body,{attributes:true,attributeFilter:['class']});
    const langObserver=new MutationObserver(function(){applyLabels();render();});
    langObserver.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    const refreshToday=function(){if(followToday&&selectedDate!==localDate()){selectedDate=localDate();render();}};
    window.setInterval(refreshToday,30000);
    document.addEventListener('visibilitychange',refreshToday);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
