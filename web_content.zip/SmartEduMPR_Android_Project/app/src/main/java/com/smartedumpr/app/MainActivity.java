package com.smartedumpr.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.print.PrintManager;
import android.webkit.WebView;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new ReminderBridge(this), "SmartEduReminder");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if ("appassets.androidplatform.net".equals(host) ||
                    ("www.gstatic.com".equals(host)) ||
                    ("firebaseapp.com".equals(host)) ||
                    (host != null && host.endsWith(".firebaseapp.com")) ||
                    ("googleapis.com".equals(host)) ||
                    (host != null && host.endsWith(".googleapis.com")) ||
                    ("gstatic.com".equals(host)) ||
                    (host != null && host.endsWith(".gstatic.com"))) {
                    return false;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });
        requestNotificationPermissionIfNeeded();
        ReminderScheduler.scheduleNext(this);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1300);
        }
    }

    public static class ReminderBridge {
        private final Context context;
        ReminderBridge(Context context) { this.context = context.getApplicationContext(); }
        @JavascriptInterface
        public void updateReminderData(String json) {
            if (json == null) return;
            context.getSharedPreferences("smart_mpr_reminders", Context.MODE_PRIVATE)
                    .edit().putString("app_payload", json).apply();
            ReminderScheduler.scheduleNext(context);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
