package com.smartedumpr.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    public static final String ACTION_DAILY_REMINDER = "com.smartedumpr.app.DAILY_ATTENDANCE_REMINDER";

    public static void scheduleNext(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_DAILY_REMINDER);
        PendingIntent pi = PendingIntent.getBroadcast(context, 1300, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, 13);
        when.set(Calendar.MINUTE, 0);
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        if (!when.after(Calendar.getInstance())) when.add(Calendar.DAY_OF_YEAR, 1);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android may defer this while in Doze; it does not require special exact-alarm access.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }
    }
}
