package com.smartedumpr.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "daily_attendance_reminders";
    private static final String PREFS = "smart_mpr_reminders";
    private static final String DATA_KEY = "app_payload";

    @Override public void onReceive(Context context, Intent intent) {
        createChannel(context);
        try {
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            Calendar now = Calendar.getInstance();
            boolean sunday = now.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
            String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DATA_KEY, "{}");
            JSONObject data = new JSONObject(raw);
            JSONObject holidays = data.optJSONObject("calendarHolidays");
            JSONObject lockedDays = data.optJSONObject("lockedDays");
            boolean customHoliday = holidays != null && holidays.has(today);
            String lockKey = now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH)) + "-" + now.get(Calendar.DAY_OF_MONTH);
            boolean attendanceSaved = lockedDays != null && lockedDays.optBoolean(lockKey, false);

            if (!sunday && !customHoliday && !attendanceSaved && canPostNotifications(context)) {
                Intent open = new Intent(context, MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                PendingIntent contentIntent = PendingIntent.getActivity(context, 1301, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                String schoolName = data.optString("schoolName", "your school");
                String message = "Please submit today's MDM attendance for " + (schoolName.trim().isEmpty() ? "your school" : schoolName.trim()) + ". If today is a scheduled holiday, mark it in Calendar & Holidays. Ignore if attendance is already submitted.";
                NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Attendance not submitted")
                        .setContentText("Please submit today's attendance.")
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true)
                        .setContentIntent(contentIntent);
                NotificationManagerCompat.from(context).notify(1300, builder.build());
            }
        } catch (Exception ignored) {
            // Keep reminder scheduling resilient if saved app data is absent or malformed.
        } finally {
            ReminderScheduler.scheduleNext(context);
        }
    }

    private boolean canPostNotifications(Context context) {
        return Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Daily attendance reminders", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Daily reminders to submit MDM attendance when attendance is not saved and the date is not a holiday.");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
