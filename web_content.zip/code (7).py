from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Simulated Wallet State
WALLET_BALANCE = 0.00500000  # Matches your screenshot

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_btc', methods=['POST'])
def send_btc():
    global WALLET_BALANCE
    
    data = request.get_json()
    recipient = data.get('recipient')
    amount = float(data.get('amount'))

    # Validation
    if not recipient or not amount:
        return jsonify({"success": False, "message": "Missing details"}), 400

    if amount <= 0:
        return jsonify({"success": False, "message": "Amount must be positive"}), 400

    if amount > WALLET_BALANCE:
        return jsonify({"success": False, "message": "Insufficient funds"}), 400

    # Process Transaction
    WALLET_BALANCE -= amount
    
    # In a real app, here you would call an API like Blockstream or Blockchain.com
    # to actually broadcast the transaction to the network.
    
    return jsonify({
        "success": True,
        "message": "Bitcoin sent successfully",
        "new_balance": WALLET_BALANCE
    })

if __name__ == '__main__':
    app.run(debug=True)