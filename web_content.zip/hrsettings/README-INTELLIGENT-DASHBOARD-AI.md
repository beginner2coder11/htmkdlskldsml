HOTEL HR MANAGER — INTELLIGENT DASHBOARD & AI MANAGER

This upgrade adds an HR dashboard generated from records stored on the device:
- Employee headcount, probation due in the next 14 days, training and appraisal totals.
- Probation dates already passed.
- Disciplinary follow-ups due within 7 days or overdue.
- Potential data completeness issues (missing department, role or probation date).
- Existing local analysis for low assessment/appraisal results, when a score can be read from a saved record.
- Quick links to ask the AI HR Manager about probation, recurring incidents, and performance.

AI MANAGER
The existing AI HR Manager is retained. Its built-in local assistant offers limited rule-based analysis without internet. Broader natural-language analysis requires deployment of the included ai-backend and configuration of a private HTTPS endpoint in the AI Manager screen. Keep AI provider secrets on the server, never in the APK. The app should be used as decision support: verify source records and make all employment decisions fairly with human review.

IMPORTANT
Dashboard alerts are derived only from the data currently saved in this device. They are not a substitute for checking original HR documents. This source ZIP is not a compiled APK; build and test in Android Studio before installing. Test the dashboard with representative sample records and confirm all existing records remain intact after upgrade.
