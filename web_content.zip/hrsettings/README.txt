HOTEL HR MANAGER — STABLE TABS + AI MANAGER UPGRADE

WHAT CHANGED
- Header navigation tabs have fixed widths/heights and stable font weights. The selected tab no longer changes dimensions; on phones, tabs scroll horizontally with consistent sizes.
- AI HR Manager supports a configurable secure HTTPS generative-AI backend. A backend starter is included in ai-backend/.
- If the AI backend is not configured, the existing local rule-based HR assistant still works.
- AI answers may propose a limited set of in-app changes: theme, accent colour, probation reminder setting, and saving a feature request. The app displays the proposed actions and asks for confirmation before applying them. It downloads a local HR data backup first.
- The AI cannot silently delete employee records, alter app code, or install a new APK. New app features still require a tested software update.

SECURE AI SETUP
1. Deploy the Node.js project in ai-backend/ to an HTTPS-capable host.
2. Configure private environment variables from ai-backend/.env.example. Keep OPENAI_API_KEY on the server; never paste it into the app.
3. Set CORS_ORIGINS to the exact origin of the app, and install dependencies (`npm install`) then run (`npm start`).
4. In the app, open AI HR Manager → Connect your AI service. Enter https://YOUR-HOST/api/hr-assistant and the AI_MANAGER_ACCESS_TOKEN. Save and test.
5. The backend starter uses an OpenAI Responses API model configured by OPENAI_MODEL. Usage may incur API charges.

DATA SAFETY
- Back up your current HR records before replacing the app files or installing an APK.
- Keep the same Android package ID and signing key for in-place APK updates.
- AI requests send the question and a limited employee/profile summary to your configured backend/provider. Only connect an approved service and avoid unnecessary sensitive details.
- Test updates on a copy of the data before production use.

DEMO LOGIN
Username: admin
Password: admin123
