HOTEL HR MANAGER — NOTIFICATIONS & EDITABLE SCORE STANDARDS UPGRADE

Included:
- Configurable app sounds: soft double tone, bright chime, bell, urgent alert, success tones, or silent.
- Reminder controls for probation, disciplinary follow-up, and low assessment/appraisal scores.
- Probation reminder lead-time setting with 14 days as the default, plus 7/21/30-day options.
- Configurable low-score threshold (60%, 70%, or 80%).
- Standard notification-bar mode and an in-app pop-up preference. Smartphone operating-system settings determine whether a system notification appears as a heads-up pop-up or only in the notification shade.
- Editable product knowledge assessment and quarterly appraisal score bands, ratings, and actions. Changes are stored separately in localStorage and used by the local AI score guidance.
- Existing employee and HR records retain the existing storage key.

INSTALLATION
1. Back up HR records using Reports & Backup before installing an update.
2. Extract the ZIP and use hrsettings/index.html as the app entry page in your HTML-to-APK builder.
3. For an APK update, keep the same Android package ID and signing key. Do not uninstall the previous app or clear its data before confirming a backup.

NOTIFICATION LIMITATIONS
This HTML-based app checks reminders when opened or resumed. Browser notifications require permission and support from the app container. Android decides whether system notifications appear as heads-up pop-ups or in the notification bar. Reliable scheduled reminders while the app is fully closed require native Android notification scheduling (for example, a native wrapper/plugin and notification channels). Sound settings apply to app feedback and in-app alerts; system notification sound may still be controlled by Android settings.

HR POLICY NOTE
The default standards are provided as a starting point. Edit the score bands to match the hotel's approved policy. Check that bands cover the intended score range without gaps or overlaps. Review assessment and disciplinary decisions fairly and in accordance with applicable HR policy and law.

Demo login in this prototype: admin / admin123

APPEARANCE PERSONALISATION
The Settings > Appearance panel now includes an expanded Excel-inspired colour palette for accent and background colours, plus font families (System, Aptos/Calibri, Arial, Verdana, Georgia, Trebuchet MS, Times New Roman), text size, normal/italic style, regular/medium/bold weight, compact layout, and rounded/square/tinted panel styles. Preferences are saved locally and are kept separate from employee records. Some fonts may fall back if they are not installed on the phone.


REPORTS AND LOCAL BACKUP UPDATE
- Reports & backup now includes working report tabs: Overview, Employees, Probation, Training & tests, Appraisals, Counselling and Disciplinary.
- Select a tab to preview live saved records, then download the selected report as CSV or Excel (.xlsx). Print / Save as PDF opens the device/browser print flow; choose Save as PDF if offered.
- Local backup is shown before Google Drive cloud backup. Download full local JSON backup saves a portable file to the phone's Downloads folder (or the browser's chosen download location). Keep this separate from cloud backup.
- Report preview displays up to 150 rows for responsiveness; exports include all rows. Personal data should be stored securely and shared only with authorised people.

EMAIL / SHARE DOCUMENTS
Saved documents, scanned images, and supported record attachments now include an Email / Share action. On compatible Android WebViews, choose Gmail, Outlook, or another app from the system share sheet and send the file after reviewing it. If sharing attachments is unavailable, the app downloads the file and opens an email draft; attach the downloaded file manually. Test in the final APK because support depends on the APK builder and Android WebView.
