SECURE AI BACKEND — HOTEL HR MANAGER

This optional Node.js backend enables generative AI responses. The provider API key stays on the server and is never placed in the Android app.

Deploy steps:
1. Deploy this folder to a Node.js host that supports HTTPS and environment variables.
2. Set OPENAI_API_KEY, AI_MANAGER_ACCESS_TOKEN, CORS_ORIGINS (comma-separated exact allowed origins), and optionally OPENAI_MODEL in the host's private environment settings. Never commit real keys.
3. Install dependencies with `npm install` and start with `npm start`.
4. Set CORS_ORIGINS to your app's exact web origin(s), comma-separated. For an APK/WebView, use the actual WebView origin if applicable. Do not use wildcard origins.
5. In the app's AI HR Manager section, enter `https://YOUR-HOST/api/hr-assistant`, enter the same AI_MANAGER_ACCESS_TOKEN, then save and test the connection.
6. Check `/health` to confirm the server is running.

SECURITY AND LIMITATIONS
- HTTPS is required by the app.
- Use a long random access token and rotate it if exposed. The token is an access credential, not a replacement for proper user accounts/roles.
- The backend uses rate limiting, security headers, request size limits and an action allowlist.
- Employee names and a limited HR data summary are sent to the AI provider when a question is submitted. Do not include unnecessary sensitive information. Obtain appropriate organisational approval and review your provider's privacy terms.
- AI-proposed app changes are limited to theme, accent colour, reminder preference and saving a feature request. The user must approve each batch; HR data cannot be deleted or modified by the AI action system.
- This service cannot rewrite or install APK code. Actual new app features still require a tested software update.
