import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();
const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin(origin, callback) { if (!origin || allowedOrigins.includes(origin)) return callback(null, true); return callback(new Error('Origin not allowed')); }, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type', 'Authorization'] }));
app.use(helmet());
app.use(express.json({ limit: '200kb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));
const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.OPENAI_API_KEY;
const ACCESS_TOKEN = process.env.AI_MANAGER_ACCESS_TOKEN;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
const allowedAccents = ['#173b35', '#2457a6', '#6b3fa0', '#9a4d18', '#a52d50'];

app.get('/health', (_req, res) => res.json({ ok: true, service: 'hotel-hr-ai-manager' }));
app.post('/api/hr-assistant', async (req, res) => {
  if (!API_KEY || !ACCESS_TOKEN) return res.status(503).json({ error: 'Server AI credentials are not configured.' });
  const auth = req.headers.authorization || '';
  if (auth !== `Bearer ${ACCESS_TOKEN}`) return res.status(401).json({ error: 'Unauthorised.' });
  const question = String(req.body?.question || '').trim().slice(0, 5000);
  if (!question) return res.status(400).json({ error: 'Question is required.' });
  const context = req.body?.context && typeof req.body.context === 'object' ? req.body.context : {};
  const instructions = `You are a careful, capable hotel HR management mentor and operations analyst. Reason clearly, give practical recommendations, and ground claims in the supplied app context. Treat HR information as confidential. Do not make final employment, disciplinary, medical, or legal decisions; flag uncertainty and advise human review. Never invent records or claim you changed the app. You may propose only these app actions when the user explicitly asks for them: {type:"set_theme", value:"light"|"dark"}; {type:"set_accent", value:one of ${allowedAccents.join(',')}}; {type:"set_reminders", value:boolean}; {type:"create_feature_request", text:string, priority:"Low"|"Normal"|"High"}. Never propose deleting records, changing employee records, modifying scores, or overriding HR policy. Return ONLY valid JSON shaped {"answer":"string","actions":[]} with no markdown fences. Actions are suggestions requiring user approval in the app.`;
  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: MODEL, instructions, input: JSON.stringify({ question, context }), max_output_tokens: 1400 })
    });
    const body = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'AI provider request failed.' });
    const text = (body.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('\n');
    let parsed;
    try { parsed = JSON.parse(text); } catch { return res.status(502).json({ error: 'AI returned an invalid structured response.' }); }
    const actions = Array.isArray(parsed.actions) ? parsed.actions.filter(a => {
      if (!a || typeof a !== 'object') return false;
      if (a.type === 'set_theme') return ['light', 'dark'].includes(a.value);
      if (a.type === 'set_accent') return allowedAccents.includes(a.value);
      if (a.type === 'set_reminders') return typeof a.value === 'boolean';
      if (a.type === 'create_feature_request') return typeof a.text === 'string' && a.text.trim().length > 0 && a.text.length <= 500 && ['Low', 'Normal', 'High'].includes(a.priority);
      return false;
    }).slice(0, 10) : [];
    res.set('Cache-Control', 'no-store');
    res.json({ answer: String(parsed.answer || 'No answer was generated.').slice(0, 10000), actions });
  } catch (err) {
    res.status(502).json({ error: 'Could not contact the AI provider.' });
  }
});
app.listen(PORT, () => console.log(`Hotel HR AI backend listening on ${PORT}`));
