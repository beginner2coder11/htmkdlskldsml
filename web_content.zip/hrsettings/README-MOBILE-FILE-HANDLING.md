Hotel HR Manager — mobile file handling update

Changes in this source edition:
- Android WebView file inputs use Android's system document picker (Storage Access Framework).
- Downloads, backups, CSV reports, generated workbooks and extracted text use an Android Create Document save dialog and write the selected URI through ContentResolver.
- The browser fallback still uses standard Blob downloads when opened outside the Android wrapper.
- CSV employee imports use an internal CSV parser, so CSV import does not depend on the remote spreadsheet library.
- XLSX import/export uses the SheetJS library when available; when export is requested offline, report/workbook actions fall back to CSV summaries instead of silently doing nothing.
- Restore keeps a bounded best-effort local safety snapshot before replacing records.
- Document analysis accepts images (OCR via online-loaded Tesseract), plain text/CSV/JSON, PDFs (text extraction via online-loaded PDF.js) and DOCX (text extraction via online-loaded Mammoth). This parser loading needs internet. Scanned/image-only PDFs and older .doc files may not yield text. Extracted profile values are suggestions and must be reviewed before a profile is created.
- App version incremented to 1.2.0 / versionCode 3.

Important limitations:
- This ZIP is source code, not a compiled APK.
- Android build and physical-device tests were not available in this environment. Build with the same application ID and signing key as the installed app before updating it.
- Files embedded in localStorage are limited to 1 MB each to reduce quota failures. Large originals should remain in Downloads/Drive; do not clear app data without a verified backup.
- Google Drive backup still requires a valid OAuth Web Client ID, internet, and correct Google Cloud OAuth/Drive API configuration.
- An APK/ZIP cannot be installed or self-updated by JavaScript. Android's package installer or the deployment process is required.
