EMAIL / SHARE SAVED HR DOCUMENTS

In Documents & Scanner, saved phone documents and scanned documents now have an “Email / Share” action. HR records with saved paper-image attachments also show this action.

On supported Android versions and WebViews, this opens the system share sheet with the actual file attached. Choose Gmail, Outlook, or another compatible email/sharing app, then review the message and send it yourself.

If direct file sharing is not supported, the app downloads the file and opens a prefilled email draft. For security and platform reasons, mailto links cannot attach files automatically, so attach the downloaded file manually in your email app.

Test this in the final APK on your target Android phone. Support depends on the APK builder/WebView and installed apps. Only email HR documents to authorised recipients; employee records can contain sensitive personal information.

Existing data key and app files are preserved. Back up HR records before installing an update, and keep the same Android package ID/signing key.
