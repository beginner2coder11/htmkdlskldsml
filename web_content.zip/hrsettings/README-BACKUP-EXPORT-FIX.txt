HOTEL HR MANAGER — BACKUP EXPORT FIX v3

This update adds a Web Share API file-sharing fallback for Android preview environments that block direct downloads. When supported, tapping Full Local Backup or Download all records as Excel/CSV should open the Android share sheet; choose Save to Files/Downloads.

If the preview environment blocks both downloads and file sharing, the app cannot force a file onto the device from JavaScript. Build and install the complete android-wrapper project so MainActivity.kt can provide the native HRAndroid.saveFile bridge.

After rebuilding, test both JSON backup and Excel export, verify the saved files in Files/Downloads, and test JSON restore before relying on backups. This source ZIP is not a compiled APK.
