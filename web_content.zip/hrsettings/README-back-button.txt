PHONE BACK BUTTON BEHAVIOUR

The app now listens for Android WebView/browser Back navigation. When you are in Employees, Reports, Settings, or another section, pressing the phone's Back button returns to the Dashboard. Pressing Back while already on the Dashboard keeps the app on the Dashboard rather than navigating to an earlier app section.

For best results, rebuild the APK using the same package ID and signing key as your existing installation. Back up your HR records before updating.
