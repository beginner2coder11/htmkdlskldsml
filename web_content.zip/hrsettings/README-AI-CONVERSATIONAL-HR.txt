HOTEL HR MANAGER — CONVERSATIONAL AI HR MANAGER

What's improved
- The AI screen now displays a chat-style conversation with your latest messages and answers.
- When a secure AI backend is configured, recent conversation turns are sent with each question so follow-up questions can use context.
- The AI receives summaries of employee profiles and the latest training, appraisal, counselling and disciplinary notes to discuss recurring topics, performance gaps, coaching strategies and follow-up plans.
- Without a configured backend, the built-in local assistant can perform a basic repeated-topic scan across saved counselling and disciplinary records, and list low scores it can reliably detect.
- A new “Recurring incidents” shortcut starts an analysis of repeated counselling/disciplinary topics.

How to use
1. Open AI HR Manager.
2. Configure your secure HTTPS backend if you want open-ended generative conversation. Keep the provider API key on the server; never paste it into the APK.
3. Ask a question such as: “Which staff have recurring incidents in counselling or statements?”
4. Ask follow-up questions naturally, for example: “What training plan would address the most common issue?”
5. Verify findings against the original forms before acting.

Privacy and HR fairness
- When connected, the app sends employee names and relevant HR record summaries (employee, title, date, details, scores and follow-up fields) to the configured backend for analysis. Use only a backend you control or trust, with authentication, HTTPS, access controls and an appropriate retention policy. Do not include unnecessary sensitive personal information in notes.
- The local assistant analyses records on the device, but its keyword matching is basic and may miss the same issue recorded with different wording or misclassify a note.
- AI suggestions are not findings of guilt or final disciplinary decisions. Confirm facts, give employees a fair chance to respond, follow hotel policy and applicable law, and use proportionate documented actions.
- Make a full HR backup before updating the app. This upgrade keeps the existing local data key and is designed as an additive update; still test with a backup first.

Build
Use hrsettings/index.html as the entry point in your existing HTML-to-APK builder. Keep the same Android package ID and signing key for an in-place update. The generative AI feature requires deploying/configuring the included ai-backend service; it is not live automatically just because the ZIP is installed.
