HOTEL HR MANAGER — SECTION LAUNCHER

This upgrade adds a distinctive compass/star-style button in the top-right header. It is deliberately not a three-dot menu or a downward arrow.

Tap the compass icon to open a drop-down list of every section currently present in the app. Tap any section to navigate there. The currently selected section is highlighted. Tap outside the menu or press Escape to close it. The launcher is shown after signing in and does not replace the existing tabs/navigation.

INSTALLATION
1. Back up your HR records using Reports & Backup before updating.
2. Extract this ZIP and use hrsettings/index.html as the HTML entry file in your APK builder.
3. Keep the same Android package ID and signing key to update an existing APK installation.
4. Test the launcher after sign-in on your target phone.

This is a web-app navigation feature. It does not change employee records or app data.
