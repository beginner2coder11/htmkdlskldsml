package com.tasklaunch.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int SHIZUKU_REQUEST_CODE = 7314;
    private static final Pattern PACKAGE_NAME = Pattern.compile("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 13, 25));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 25));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 13, 25));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new ADBBridge(), "TaskLaunchADB");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public final class ADBBridge {
        @JavascriptInterface public String status() {
            boolean binder = false, granted = false;
            try { binder = Shizuku.pingBinder(); } catch (Throwable ignored) { }
            if (binder) {
                try { granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
                catch (Throwable ignored) { }
            }
            return "{\"shizukuRunning\":" + binder + ",\"permission\":" + granted
                    + ",\"model\":\"" + json(Build.MODEL) + "\",\"android\":\"" + json(Build.VERSION.RELEASE) + "\"}";
        }

        @JavascriptInterface public String requestPermission() {
            try {
                if (!Shizuku.pingBinder()) return "Shizuku is not running. Start Shizuku using its Wireless debugging / ADB instructions, then retry.";
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return "Permission already granted.";
                runOnUiThread(() -> Shizuku.requestPermission(SHIZUKU_REQUEST_CODE));
                return "Permission request opened. Approve TaskLaunch in the Shizuku prompt, then tap Refresh status.";
            } catch (Throwable e) { return "Permission request failed: " + safeMessage(e); }
        }

        @JavascriptInterface public String runCommand(String command) {
            if (command == null) return "ERROR: Empty command.";
            String c = command.trim();
            if (c.length() > 180) return "ERROR: Command is too long.";
            String allowed = validateCommand(c);
            if (allowed == null) return "BLOCKED: This command is not on TaskLaunch's safe command list.";
            try {
                if (!Shizuku.pingBinder()) return "ERROR: Shizuku is not running. Start it through ADB/Wireless debugging first.";
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return "ERROR: TaskLaunch has no Shizuku permission. Tap Request permission.";
                Process process = Shizuku.newProcess(new String[]{"sh", "-c", allowed}, null, null);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                ByteArrayOutputStream err = new ByteArrayOutputStream();
                Thread stdoutReader = copyAsync(process.getInputStream(), out);
                Thread stderrReader = copyAsync(process.getErrorStream(), err);
                boolean ended = process.waitFor(8, TimeUnit.SECONDS);
                if (!ended) { process.destroy(); return "ERROR: Command timed out after 8 seconds."; }
                stdoutReader.join(500);
                stderrReader.join(500);
                String stdout = out.toString(StandardCharsets.UTF_8.name()).trim();
                String stderr = err.toString(StandardCharsets.UTF_8.name()).trim();
                String result = stdout;
                if (!stderr.isEmpty()) result += (result.isEmpty() ? "" : "\n") + stderr;
                if (result.isEmpty()) result = "Command completed (exit code " + process.exitValue() + ").";
                return result.length() > 18000 ? result.substring(0, 18000) + "\n…output truncated" : result;
            } catch (Throwable e) { return "ERROR: " + safeMessage(e); }
        }

        private String validateCommand(String c) {
            String[] safe = {"id", "whoami", "pwd", "df -h", "free -h", "ps -A", "pm list packages -3",
                    "dumpsys battery", "dumpsys meminfo", "getprop", "getprop ro.product.model",
                    "getprop ro.build.version.release", "getprop ro.build.version.sdk", "ls -la /sdcard",
                    "ls -la /sdcard/Download", "date", "uptime"};
            for (String s : safe) if (s.equals(c)) return s;
            if (c.matches("getprop [A-Za-z0-9._-]{1,100}")) return c;
            if (c.startsWith("am force-stop ")) {
                String pkg = c.substring("am force-stop ".length()).trim();
                if (PACKAGE_NAME.matcher(pkg).matches()) return "am force-stop " + pkg;
            }
            return null;
        }

        private Thread copyAsync(InputStream in, ByteArrayOutputStream out) {
            Thread t = new Thread(() -> {
                try (InputStream source = in) {
                    byte[] buffer = new byte[2048]; int n;
                    while ((n = source.read(buffer)) >= 0) {
                        if (out.size() < 20000) out.write(buffer, 0, Math.min(n, 20000 - out.size()));
                    }
                } catch (Exception ignored) { }
            });
            t.start();
            return t;
        }
        private String safeMessage(Throwable e) { String m = e.getMessage(); return m == null ? e.getClass().getSimpleName() : m; }
        private String json(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", ""); }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
