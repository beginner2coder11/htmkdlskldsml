# TaskLaunch ADB (serverless Android build)

TaskLaunch 2.0 removes the Node.js Windows companion server and all Windows-server URL/token settings. The Android app uses the Shizuku API to execute a limited set of real Android shell commands through Shizuku's ADB-backed service.

## Requirements
- Android Studio with Android SDK 35 and JDK 17.
- Internet access for the first Gradle sync (Android Gradle Plugin and Shizuku dependencies are downloaded from their configured repositories).
- The official Shizuku app on the target phone.

## Build the APK
1. Open this project folder in Android Studio.
2. Allow Gradle sync to finish.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the debug APK from `app/build/outputs/apk/debug/`.

## Enable the ADB-backed bridge
1. Install and open Shizuku on the same phone.
2. Enable Developer options, then Wireless debugging.
3. Start Shizuku with its built-in Wireless debugging pairing flow. Alternatively, connect the phone to a computer and use the ADB start instructions shown in the official Shizuku documentation.
4. Open TaskLaunch > Settings > **Start / Request permission**.
5. Approve TaskLaunch in the Shizuku permission prompt, then tap **Refresh status**.

Shizuku generally needs to be started again after a reboot unless the device's setup supports an automatic start method. TaskLaunch itself does not run an ADB daemon and does not need a Node.js server.

## Implemented live functions
- Shizuku running / permission status and device model / Android version.
- Allowlisted Android shell queries: `id`, `whoami`, `pwd`, `getprop`, `df -h`, `free -h`, `ps -A`, `pm list packages -3`, `dumpsys battery`, `dumpsys meminfo`, `ls -la /sdcard`, `ls -la /sdcard/Download`, `date`, and `uptime`.
- Local notes, calculator, theme settings, export, and external browser launch.
- `am force-stop <package>` is recognized by the native allowlist but is intentionally not exposed in the UI.

## Important limitations
- This is an Android device utility, not a Windows PC remote-control app or Windows emulator.
- The bridge requires Shizuku to be running and TaskLaunch to have permission. Without that setup, shell tools show a real connection/permission error rather than simulated results.
- The command runner deliberately blocks arbitrary shell commands. The shared-storage explorer is read-only in this version.
