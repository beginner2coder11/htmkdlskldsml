# SAVOB Full Interactive Demo — Responsive Fix Build

Open `app/index.html` in a modern browser.

## Layout fixes in this revision
- Full-width responsive layout on tablet and phone (900px breakpoint).
- Desktop sidebar becomes a bottom, scrollable app navigation on mobile/tablet.
- Feed cards expand to full width, with comfortable text line-height and action wrapping.
- Fixed invalid CSS Grid syntax.

## Module-specific data
- Community: social posts and reactions.
- Help: aid requests, categories, request form.
- Volunteer: tasks, join/leave actions.
- Campaigns: donation campaign cards, goals, progress and demo donation tracking.
- Market: listings and category filtering.
- Events: events and registration actions.
- Messages, Profile, Admin each have separate screens/actions.

## Running
Unzip, then open `app/index.html`. Local demo changes persist in this browser's localStorage.

## Important
Not production: no real authentication, backend, payments, live map, notification delivery or multi-user synchronization. Donation button only updates local demo data.
