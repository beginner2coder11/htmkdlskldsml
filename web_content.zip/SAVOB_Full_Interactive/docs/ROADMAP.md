# SAVOB Build Roadmap

**Pilot first:** one city and partner cohort.

Phase 1: UX validation and safeguarding design.
Phase 2: MVP backend and auth, feed, help requests, volunteer, campaigns, admin review.
Phase 3: pilot with partner organizations, audit logs, moderator workflows and impact metrics.
Phase 4: licensed payment integration, receipts, push notifications, mapping, events.
Phase 5: market, multilingual rollout, AI-assisted triage (human-reviewed), additional cities.

Before public launch: privacy/legal review, threat model, secure coding review, incident response, payment reconciliation, support/moderation capacity, backup restore drills and accessibility testing.
