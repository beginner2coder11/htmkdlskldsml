# API Starter Outline (not implemented in demo)

POST /auth/otp/request
POST /auth/otp/verify
GET/PATCH /users/me
GET/POST /posts
POST /posts/:id/reactions
GET/POST /posts/:id/comments
GET/POST /aid-requests
PATCH /aid-requests/:id/status
GET/POST /campaigns
POST /campaigns/:id/donation-intents
GET /campaigns/:id/ledger-summary
GET/POST /volunteer/tasks
POST /volunteer/tasks/:id/apply
GET/POST /market/listings
GET/POST /events
POST /events/:id/register
GET/POST /conversations
GET /admin/moderation
POST /admin/moderation/:id/decision

Each endpoint: auth, role permission, validation, rate limit, audit for sensitive operations, pagination, request IDs. Payment processing via approved payment provider, never store raw card details.
