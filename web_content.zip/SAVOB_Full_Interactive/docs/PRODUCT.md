# SAVOB Product Architecture

MVP modules: authentication/profile, social feed, aid requests, campaigns/donation tracking, volunteer task management, local listings, events, chat, discovery, admin console.

Recommended architecture: Next.js TypeScript frontend, NestJS/FastAPI API, PostgreSQL/PostGIS, Redis, object storage, OTP auth, RBAC, event queue, monitoring. Begin with modular monolith.

Must not expose sensitive beneficiary data or precise home location publicly. Donor funds must be processed by a licensed payment provider; demo donations are not real payments. Campaign review, evidence, audit trails, abuse reports, block controls, privacy consent and retention are required.

Suggested entities: User, Profile, Post, Comment, Reaction, AidRequest, Campaign, DonationIntent, CampaignLedgerEntry, VolunteerTask, TaskApplication, Listing, Event, Registration, Conversation, Message, Report, ModerationCase, AuditEvent.

Lifecycle: AidRequest submitted -> review -> verified -> matching -> in progress -> fulfilled/closed. Campaign draft -> review -> active -> paused/completed. Volunteer task open -> applied -> accepted -> check-in -> completed.

Metrics: request fulfilment/time-to-match, volunteer hours, campaign verified completion, repeat participation, 7/30-day retention, moderation SLA, fraud reports, user satisfaction.
