# SAVOB UI rebuild notes

Fixes based on mobile screenshot feedback:
- Mobile/tablet width now uses the full screen, no permanent desktop sidebar.
- Navigation moves to a fixed, horizontally scrollable bottom navigation.
- Content container expands to 100% width; feed cards and posts are full-width.
- Responsive breakpoints are revised at 900px and 520px.
- Fixed CSS Grid syntax error that invalidated the two-column grid declaration.
- Feed uses the Community feed dataset, while Help requests, campaigns, listings and events use their own module-specific records and forms.
- Campaign page explicitly states it shows campaign-only content, not Community feed posts.
- Demo remains localStorage-backed and offline; production services are not connected.
