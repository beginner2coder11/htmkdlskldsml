# Tasks
- [x] Match the supplied PixelPlayer screenshot while retaining music import, playback and exclusions.
- [x] Check folder navigation, search, favorites and playback layout.
- [ ] Package and inspect an editable source ZIP.