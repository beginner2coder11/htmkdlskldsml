RosterHQ — F&B Staff Roster Manager
Android HTML-to-APK project package

CONTENTS
- index.html: Main app entry file. Keep this file in the ZIP root for HTML-to-APK builders.
- RosterHQ_Staff_Roster_Manager.html: Same app with its descriptive filename.

HOW TO USE ON A PHONE
1. Extract the ZIP, or upload the ZIP directly to an HTML-to-APK builder that accepts a ZIP project.
2. If the builder asks for the start page or entry file, choose index.html.
3. Build/convert the project to an APK and install it on your Android phone.

IMPORTANT NOTES
- The app currently loads the SheetJS/XLSX library from jsDelivr (an internet connection is needed for Excel import/export features unless the builder bundles that library locally).
- Roster data is stored in the browser/app's local storage. Clearing app/browser data or uninstalling may erase it.
- Before upgrading, use the app's Export backup option and save the JSON backup somewhere safe (e.g. Google Drive or OneDrive). Use Restore backup after an upgrade if needed.
- The roster assistant drafts a roster from saved roster patterns/rules; it is not a live connected AI service. Always review shifts, leave, and coverage before publishing a draft.
- This package contains the HTML app, not a compiled APK. Use an APK builder to create the installable APK.
