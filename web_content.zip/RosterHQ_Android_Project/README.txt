RosterHQ Android Project - fixed build

IMPORTANT: index.html must remain at the ZIP root when imported into an HTML-to-APK builder.

Fixes in this revision:
- Removed a stray closing brace that prevented the main JavaScript from parsing. This disabled navigation, imports, and dashboard refresh.
- Added recognition of M/Morning, D/Day, and E/Evening shift codes as on-duty shifts.
- Kept the Service Staff Roster and Kitchen Tumbler import options.

How to test:
1. Extract the ZIP.
2. Open index.html in Chrome while connected to the internet (the XLSX reader is loaded from a CDN).
3. Tap Import weekly roster, choose Service or Kitchen, select the Excel file, and import.
4. Set the dashboard or daily roster date to a date contained in the imported workbook.
5. Check the import status message and Staff by department / On duty by shift.

Data safety:
- Export a JSON backup from the app before replacing any installed version.
- This is a browser-based app; imported records are saved in the browser's local storage on that device.
- Excel import currently requires the XLSX library to load from the internet.
