RosterHQ - F&B Staff Roster Manager
Updated project package

START PAGE
Open index.html. When converting this folder to an Android APK, set index.html as the app's start page.

NAVIGATION FIX
This build strengthens tab navigation for mobile browsers and Android WebViews, makes each section render independently, and avoids an optional backup button from stopping app initialization.

FEATURES
- Dashboard and daily roster
- Leave tracker and manual leave entry
- Staff directory
- Excel roster import (the XLSX library is loaded from a CDN and needs internet access)
- Local roster assistant and weekly roster draft tools
- JSON export and restore backup

IMPORTANT DATA SAFETY
Roster data is stored locally in the browser/WebView. It does not automatically sync to cloud. Export a JSON backup before replacing or reinstalling the app. Depending on how the APK builder packages the app, the new installation may use a different local storage area; restore your backup if needed.

AI NOTE
The in-app roster assistant is a local rule-based helper, not a connected external AI service. The upgrade assistant prepares a request to use with a separate AI coding assistant.

If tabs still do not switch in a particular APK builder, test index.html in Chrome first, then check the builder's WebView settings and ensure JavaScript is enabled.
