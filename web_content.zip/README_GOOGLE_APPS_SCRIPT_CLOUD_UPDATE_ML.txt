JAS LAUNDRY ROOM — GOOGLE APPS SCRIPT CLOUD CONFIG UPDATE

Included in this update:
- Login page now contains Google Apps Script Web App URL and Secret Token fields.
- Save & Connect stores both values in this device's localStorage, so logout and normal app restarts do not clear them.
- Saved values are loaded back into the login page.
- Appwrite SDK include and Appwrite Connection Test panel have been removed.
- Existing ERP screens and Google Sheet sync payload code are retained.

IMPORTANT LIMITATIONS / REQUIRED NEXT STEP:
- This update adds and persists the Google Apps Script connection settings. It does NOT replace the existing Firebase Authentication / Firestore login and sync implementation. The current Google Apps Script code is a Google Sheets data-sync route, not a complete owner/staff authentication backend. Replacing Firebase login requires corresponding Apps Script doPost/doGet actions for account login, account creation, session/token validation, and secure data read/write, plus a tested deployment.
- The existing sync path calls AndroidBridge.postToGoogleSheet(url, payload). A browser-only HTML preview cannot verify that native APK bridge. Build and test in the Android wrapper.
- The Secret Token is stored in localStorage on the device and is accessible to the app's JavaScript. Do not use a highly privileged Google credential as this token. Use a dedicated app-level shared secret and enforce validation server-side in Google Apps Script.
- Configuration remains on the device after logout/restart, but uninstalling the app or clearing app data/browser storage removes it.
- No live connection test was possible without your deployed URL, matching token, and Apps Script deployment permissions.

Original ZIP files and existing business data features are retained except the Appwrite test panel, which was removed as requested.
