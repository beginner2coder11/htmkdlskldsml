<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the standalone player in `public/noot.html` and embed it through the TanStack home route so the browser and Android WebView share one player implementation.
- Package Android wrapper source when available alongside the web source, without signing keys, dependencies or generated build output, so source downloads remain editable and safe.
