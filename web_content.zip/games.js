const GAMES = {
pt: { tab:"Jogos", play:"Jogar", again:"De novo", score:"Pontos", close:"Fechar",
  mem:"Memória Echo", memHint:"Encontre os pares. 8 cartas.",
  quiz:"Decisão-relâmpago", quizHint:"10 escolhas rápidas. Confie no instinto.",
  tap:"Orbe de foco", tapHint:"Toque só nas orbes roxas. 20 segundos.",
  simon:"Sequência", simonHint:"Repita a ordem das luzes.",
  word:"Palavra embaralhada", wordHint:"Desembaralhe o termo EchoForge."
},
en: { tab:"Games", play:"Play", again:"Again", score:"Score", close:"Close",
  mem:"Echo memory", memHint:"Find the pairs. 8 cards.",
  quiz:"Lightning decision", quizHint:"10 fast choices.",
  tap:"Focus orb", tapHint:"Tap purple orbs only. 20 seconds.",
  simon:"Sequence", simonHint:"Repeat the light order.",
  word:"Scramble", wordHint:"Unscramble the EchoForge word."
},
fr: { tab:"Jeux", play:"Jouer", again:"Encore", score:"Score", close:"Fermer",
  mem:"Mémoire Écho", memHint:"Trouvez les paires.",
  quiz:"Décision éclair", quizHint:"10 choix rapides.",
  tap:"Orbe de focus", tapHint:"Touchez seulement le violet. 20 s.",
  simon:"Séquence", simonHint:"Répétez l'ordre.",
  word:"Lettres mêlées", wordHint:"Remettez le mot."
}
};
const QUIZ = [
  {q:["Guardar o Echo","Vender agora"], ok:0},
  {q:["Dormir 7h","Mais uma tela"], ok:0},
  {q:["Nome na venda","Anonimizar"], ok:1},
  {q:["Esperar 2 noites","Decidir em 2 min"], ok:0},
  {q:["Expor alguém","Vender o padrão"], ok:1},
  {q:["Um hábito","Dez hábitos"], ok:0},
  {q:["Culpa", "Energia"], ok:1},
  {q:["Postar tudo","Filtrar"], ok:1},
  {q:["Comparar","Registrar o seu"], ok:1},
  {q:["Desistir no dia 1","Voltar amanhã"], ok:1}
];
const WORDS = ["ECHO","FORGE","ROTINA","FOCO","LIMITE","PADRAO","DECISAO","ENERGIA"];
