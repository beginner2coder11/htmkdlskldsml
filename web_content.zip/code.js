const Database = require('better-sqlite3');
const path = require('path');

// Create a local database file
const dbPath = path.join(__dirname, 'flasher.db');
const db = new Database(dbPath);

// Enable WAL mode for better performance in concurrent apps
db.pragma('journal_mode = WAL');

// Create tables if they don't exist
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    password TEXT, -- In real app, hash this!
    balance REAL DEFAULT 2000.00,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    sender_address TEXT,
    recipient_address TEXT,
    amount REAL,
    network TEXT,
    tx_hash TEXT,
    status TEXT DEFAULT 'Confirmed',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

module.exports = db;