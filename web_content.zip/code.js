const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// Helper to generate random hex string of specific length
function generateRandomHex(length) {
    return crypto.randomBytes(length / 2).toString('hex');
}

// Simulate different network formats
function getTxIdFormat(network) {
    switch(network) {
        case 'ERC20':
            // Ethereum TXIDs are 66 chars long (0x + 64 hex chars)
            return '0x' + generateRandomHex(64);
        case 'BEP20':
            // Binance Smart Chain is similar to ETH
            return '0x' + generateRandomHex(64);
        case 'TRC20':
            // Tron TXIDs are 64 hex chars (no 0x prefix usually, or with 0x)
            return '0x' + generateRandomHex(64);
        default:
            return generateRandomHex(32);
    }
}

app.post('/send', (req, res) => {
    const { network, amount, address, vpn } = req.body;

    // Simulation delay to make it feel real
    setTimeout(() => {
        const txid = getTxIdFormat(network);
        
        // Construct a fake explorer link based on network
        let explorerLink = '';
        if(network === 'ERC20') explorerLink = `https://etherscan.io/tx/${txid}`;
        if(network === 'BEP20') explorerLink = `https://bscscan.com/tx/${txid}`;
        if(network === 'TRC20') explorerLink = `https://tronscan.org/#/transaction/${txid}`;

        res.json({
            success: true,
            message: 'Transaction broadcasted successfully.',
            txid: txid,
            explorer_link: explorerLink,
            vpn_used: vpn
        });
    }, 2000); // 2 second delay for realism
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`USDT Flash Backend running on port ${PORT}`);
});