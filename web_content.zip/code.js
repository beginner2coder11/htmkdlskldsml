const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files (your index.html)
app.use(express.static(path.join(__dirname)));

// API Endpoint: Generate Flash Transaction
app.post('/api/generate-tx', (req, res) => {
    const { recipient, amount, validity } = req.body;

    // Simulate processing delay slightly if needed, but usually instant for UI wrappers
    const timestamp = new Date().toISOString();
    
    // Generate a realistic-looking TRC20 Hash
    const randomHex = () => Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
    const txHash = "0x" + randomHex();
    
    // Calculate Expiry
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(validity));
    const expiryStr = expiryDate.toLocaleDateString() + " " + expiryDate.toLocaleTimeString();

    // Mock Block Data
    const blockNum = Math.floor(Math.random() * (90000000 - 85000000) + 85000000);

    // Response Object
    const responseData = {
        success: true,
        data: {
            txHash: txHash,
            explorerUrl: `https://tronscan.org/#/transaction/${txHash}`,
            status: "CONFIRMED",
            blockNumber: blockNum,
            gasFee: "0.15 TRX",
            expiry: expiryStr,
            recipient: recipient,
            amount: amount,
            timestamp: timestamp
        }
    };

    // Log to console (you can see this when running the server)
    console.log(`[TX GENERATED] Hash: ${txHash} | Recipient: ${recipient.substring(0,6)}... | Amount: ${amount}`);

    res.json(responseData);
});

// Start the server
app.listen(PORT, () => {
    console.log(`USDT Flash Backend running at http://localhost:${PORT}`);
});