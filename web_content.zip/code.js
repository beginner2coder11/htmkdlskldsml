const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Database Setup
const db = new sqlite3.Database('./bank.db');

db.serialize(() => {
    // Create users table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Create accounts table
    db.run(`CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        aba_number TEXT NOT NULL,
        account_number TEXT NOT NULL,
        balance REAL DEFAULT 0.00,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    // Create transactions table
    db.run(`CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL, -- 'deposit', 'withdrawal'
        status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'failed'
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (account_id) REFERENCES accounts(id)
    )`);
});

// --- API Routes ---

// 1. Register User
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], function(err) {
            if (err) {
                return res.status(500).json({ error: 'User creation failed' });
            }
            res.json({ message: 'User registered successfully', userId: this.lastID });
        });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// 2. Login User
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid password' });
        }

        res.json({ message: 'Login successful', userId: user.id });
    });
});

// 3. Add Account (ABA + Account Number)
app.post('/api/accounts', (req, res) => {
    const { userId, abaNumber, accountNumber } = req.body;

    if (!userId || !abaNumber || !accountNumber) {
        return res.status(400).json({ error: 'Missing fields' });
    }

    // Simple validation
    if (abaNumber.length !== 9 || !/^\d+$/.test(abaNumber)) {
        return res.status(400).json({ error: 'Invalid ABA number' });
    }

    db.run('INSERT INTO accounts (user_id, aba_number, account_number) VALUES (?, ?, ?)', 
        [userId, abaNumber, accountNumber], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to add account' });
        }
        res.json({ message: 'Account added', accountId: this.lastID });
    });
});

// 4. Load Money (Deposit)
app.post('/api/deposit', (req, res) => {
    const { accountId, amount } = req.body;

    if (!accountId || !amount || amount <= 0) {
        return res.status(400).json({ error: 'Invalid deposit details' });
    }

    // Start transaction
    db.run('BEGIN TRANSACTION');

    // Insert transaction record
    db.run('INSERT INTO transactions (account_id, amount, type, status) VALUES (?, ?, ?, ?)', 
        [accountId, amount, 'deposit', 'completed'], function(err) {
        if (err) {
            db.run('ROLLBACK');
            return res.status(500).json({ error: 'Transaction failed' });
        }

        // Update account balance
        db.run('UPDATE accounts SET balance = balance + ? WHERE id = ?', 
            [amount, accountId], function(err) {
            if (err) {
                db.run('ROLLBACK');
                return res.status(500).json({ error: 'Balance update failed' });
            }

            db.run('COMMIT');
            res.json({ 
                message: 'Deposit successful', 
                newBalance: parseFloat(amount) 
            });
        });
    });
});

// 5. Get Account Balance
app.get('/api/balance/:accountId', (req, res) => {
    const { accountId } = req.params;

    db.get('SELECT balance FROM accounts WHERE id = ?', [accountId], (err, row) => {
        if (err || !row) {
            return res.status(404).json({ error: 'Account not found' });
        }
        res.json({ balance: row.balance });
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Banking API running on http://localhost:${PORT}`);
});