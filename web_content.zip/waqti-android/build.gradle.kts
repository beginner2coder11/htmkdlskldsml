// Top-level build file for the وقتي | منظم الوقت المتكامل wrapper project.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
