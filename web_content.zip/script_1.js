
(function(){
  const AFZ_TRANSLATIONS = {"💰 جميع أثمان المنتجات":"💰 Tous les prix des produits", "🪪 البطاقات التعريفية للمنتوجات":"🪪 Fiches produits", "1️⃣ اسم المنتوج أولاً":"1️⃣ Nom du produit d’abord", "2️⃣ رقم المنتوج ثانياً":"2️⃣ Référence du produit ensuite", "المنتوجات":"Produits", "🔍 ابحث باسم المنتوج":"🔍 Rechercher par nom du produit", "🔍 بحث في بطاقات المنتوجات بالاسم أو الرقم":"🔍 Rechercher dans les fiches produits par nom ou référence", "➕ إضافة منتوج":"➕ Ajouter un produit", "اسم المنتوج":"Nom du produit", "📷 صورة المنتوج":"📷 Image du produit", "حفظ المنتوج":"Enregistrer le produit", "تعديل":"Modifier", "حذف":"Supprimer", "تم حفظ المنتوج بنجاح":"Produit enregistré avec succès", "تم تعديل المنتوج بنجاح":"Produit modifié avec succès", "حذف هذا المنتوج؟":"Supprimer ce produit ?", "لا توجد منتوجات بعد":"Aucun produit pour le moment", "لا توجد نتائج للبحث":"Aucun résultat", "تسيير المخزون والمبيعات والحسابات": "Gestion du stock, des ventes et de la comptabilité", "الرئيسية": "Accueil", "المخزون": "Stock", "المبيعات": "Ventes", "الزبائن": "Clients", "وصل التسليم": "Bon de livraison", "مصاريف اليوم": "Dépenses du jour", "الكريدي": "Crédit", "دفتر الشيكات": "Carnet de chèques", "الإشعارات": "Notifications", "التقارير": "Rapports", "نسخة احتياطية": "Sauvegarde", "مجموع رأس مال المخزون": "Valeur totale du stock", "حسب ثمن الشراء": "Selon le prix d'achat", "مبيعات اليوم": "Ventes du jour", "إجمالي المبيعات": "Total des ventes", "أرباح اليوم": "Bénéfice du jour", "صافي ربح مبيعات اليوم": "Bénéfice net des ventes du jour", "مبيعات الشهر الماضي": "Ventes du mois précédent", "إجمالي مبيعات الشهر السابق": "Total des ventes du mois précédent", "المسجلة": "Enregistrées", "مجموع الكريدي": "Total du crédit", "إجمالي المبالغ غير المؤداة": "Total des montants impayés", "🔍 ابحث بالمرجع أو اسم المنتوج": "🔍 Rechercher par référence ou nom du produit", "🔍 بحث باسم الزبون": "🔍 Rechercher par nom du client", "📞 بحث بالهاتف": "📞 Rechercher par téléphone", "📝 بحث بالملاحظة": "📝 Rechercher par remarque", "🔢 بحث برقم الشيك": "🔢 Rechercher par numéro de chèque", "🔍 بحث باسم المستفيد": "🔍 Rechercher par bénéficiaire", "تحميل بيانات المخزون PDF": "📄 Télécharger le stock en PDF", "إضافة قطعة": "Ajouter un article", "اسم القطعة": "Nom de l'article", "المرجع / Référence": "Référence", "الكمية": "Quantité", "ثمن الشراء DH": "Prix d'achat DH", "صورة المنتوج": "📷 Image du produit", "حفظ القطعة": "Enregistrer l'article", "📊 تسجيل مبيعات اليوم": "📊 Enregistrer les ventes du jour", "تسجيل مبيعات اليوم": "Enregistrer les ventes du jour", "رقم المنتج": "Référence produit", "➕ إضافة بيع": "➕ Ajouter la vente", "التاريخ": "Date", "الأرباح": "Bénéfice", "المتبقي": "Restant", "لا توجد مبيعات اليوم": "Aucune vente aujourd'hui", "📅 الملخص اليومي": "📅 Résumé quotidien", "الملخص اليومي": "Résumé quotidien", "المدخول اليومي": "Chiffre d'affaires du jour", "المدخول الشهري": "Chiffre d'affaires du mois", "الصافي": "Net", "لا توجد بيانات": "Aucune donnée", "تحرير بون دوليفريزون مستقل": "Créer un bon de livraison indépendant", "هذا القسم مستقل تماماً عن قسم المبيعات. إنشاء وتعديل وصل التسليم هنا لا ينشئ بيعاً ولا يغيّر المخزون.": "Cette section est totalement indépendante des ventes. La création ou la modification d'un bon de livraison ici ne crée pas de vente et ne modifie pas le stock.", "اختر الزبون من قسم الزبائن": "Choisir le client depuis la section Clients", "اسم الزبون": "Nom du client", "هاتف الزبون": "Téléphone du client", "عنوان الزبون": "Adresse du client", "إضافة منتج إلى الوصل": "Ajouter un produit au bon", "اسم المنتج": "Nom du produit", "العدد": "Quantité", "الثمن": "Prix", "➕ إضافة المنتج": "➕ Ajouter le produit", "حفظ الوصل": "Enregistrer le bon", "معاينة الوصل": "Aperçu du bon", "⚡ طباعة PDF سريعة": "⚡ Impression PDF rapide", "إضافة زبون": "Ajouter un client", "الهاتف": "Téléphone", "📱 اختيار الزبون من جهة الاتصال": "📱 Choisir le client depuis les contacts", "اختر جهة اتصال من الهاتف وسيتم إدخال الاسم ورقم الهاتف تلقائياً، ثم اضغط حفظ الزبون.": "Choisissez un contact sur le téléphone : le nom et le numéro seront remplis automatiquement, puis appuyez sur Enregistrer le client.", "حفظ الزبون": "Enregistrer le client", "إدارة الكريدي": "Gestion du crédit", "اختر الزبون": "Choisir le client", "مبلغ الكريدي DH": "Montant du crédit DH", "ملاحظة (اختياري)": "Remarque (facultatif)", "تسجيل الكريدي": "Enregistrer le crédit", "رقم الشيك": "Numéro du chèque", "اسم المستفيد": "Bénéficiaire", "مبلغ الشيك DH": "Montant du chèque DH", "في الانتظار": "En attente", "تم صرفه": "Encaissé", "ملغى": "Annulé", "تسجيل الشيك": "Enregistrer le chèque", "جدول الشيكات المبرمجة": "Tableau des chèques programmés", "تنبيهات الشيكات التي اقترب تاريخ دخولها إلى البنك.": "Alertes pour les chèques dont la date de dépôt à la banque approche.", "إضافة مصروف": "Ajouter une dépense", "نوع المصروف": "Type de dépense", "المبلغ DH": "Montant DH", "حفظ المصروف": "Enregistrer la dépense", "حفظ واسترجاع البيانات": "Sauvegarde et restauration des données", "البيانات تحفظ داخل الهاتف. يمكنك أيضًا أخذ نسخة احتياطية.": "Les données sont enregistrées sur le téléphone. Vous pouvez également créer une sauvegarde.", "📥 تصدير نسخة احتياطية": "📥 Exporter une sauvegarde", "اختر ملف JSON لاسترجاع البيانات.": "Choisissez un fichier JSON pour restaurer les données.", "📊 التقارير الشهرية والسنوية": "📊 Rapports mensuels et annuels", "اختر الشهر": "Choisir le mois", "السنة": "Année", "المسجل": "Enregistré", "قبل المصاريف": "Avant dépenses", "خلال الشهر المختار": "Pendant le mois sélectionné", "غير المؤدى من كريدي الشهر": "Impayé du crédit du mois", "عدد عمليات البيع": "Nombre de ventes", "خلال الشهر": "Pendant le mois", "حساب صرف الشيكات السنوي": "Comptabilisation annuelle des chèques encaissés", "إجمالي قيمة الشيكات التي تم وضع حالتها \"تم صرفه\" خلال السنة": "Valeur totale des chèques marqués « Encaissé » pendant l'année", "عدد الشيكات المصروفة": "Nombre de chèques encaissés", "إجمالي الشيكات المسجلة في السنة": "Total des chèques enregistrés dans l'année", "يشمل جميع الحالات": "Toutes les situations incluses", "شيك": "chèque", "شيكات": "chèques", "لا توجد إشعارات حالياً.": "Aucune notification actuellement.", "إشعار الشيكات القريبة": "Alerte des chèques proches", "هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:": "Certains chèques seront à déposer à la banque dans les 3 prochains jours :", "المستفيد:": "Bénéficiaire :", "المبلغ:": "Montant :", "تاريخ الشيك:": "Date du chèque :", "اليوم": "Aujourd'hui", "غداً": "Demain", "بعد": "Dans", " أيام": " jours", "لا توجد شيكات مبرمجة": "Aucun chèque programmé", "جميع الشيكات — الأقرب تاريخاً أولاً": "Tous les chèques — date la plus proche en premier", "لا توجد شيكات مسجلة": "Aucun chèque enregistré", "المستحق حالياً": "Dû actuellement", "عدد الديون": "Nombre de dettes", "لا توجد ديون مسجلة": "Aucune dette enregistrée", "لا يوجد زبائن": "Aucun client", "لا توجد مصاريف": "Aucune dépense", "المصروف": "Dépense", "الزبون": "Client", "المرجع:": "Référence :", "قطعة": "article", "حسابات المخزون": "Comptabilité du stock", "إجمالي الشراء": "Total des achats", "المنتجات:": "Produits :", "الكمية:": "Quantité :", "مجموع المبيعات الشهرية": "Total des ventes mensuelles", "مجموع أرباح الشهر": "Total du bénéfice mensuel", "مجموع المصاريف الشهرية": "Total des dépenses mensuelles", "صافي الربح بعد المصاريف": "Bénéfice net après dépenses", "مجموع الكريدي المسجل": "Total du crédit enregistré", "الكريدي المتبقي": "Crédit restant", "عدد الشيكات المصروفة:": "Nombre de chèques encaissés :", "اختر منتجاً من المخزون أو اكتب الاسم": "Choisir un produit du stock ou saisir le nom", "منتجات الوصل": "Produits du bon", "لا تتم إضافة منتجات بعد": "Aucun produit ajouté", "لا توجد وصول محفوظة": "Aucun bon enregistré", "رقم الوصل": "N° du bon", "العنوان": "Adresse", "المجموع": "Total", "الوصول المستقلة المحفوظة": "Bons indépendants enregistrés", "➕ وصل جديد": "➕ Nouveau bon", "اسم": "Nom", "عدد": "Qté", "حذف": "Supprimer", "المجموع النهائي": "Total final", "زبون عابر": "Client de passage", "تم حفظ المنتج بنجاح": "Produit enregistré avec succès", "تعذر حفظ الصورة. جرّب صورة أصغر.": "Impossible d'enregistrer l'image. Essayez une image plus petite.", "اختر منتجًا": "Choisissez un produit", "الكمية غير صحيحة": "Quantité incorrecte", "الكمية المطلوبة أكبر من المخزون المتوفر": "La quantité demandée dépasse le stock disponible", "السعر غير صحيح": "Prix incorrect", "أضف منتجًا واحدًا على الأقل": "Ajoutez au moins un produit", "تم حفظ البيع بنجاح": "Vente enregistrée avec succès", "لا توجد مبيعات لتحميلها": "Aucune vente à télécharger", "أدخل اسم المنتج": "Saisissez le nom du produit", "أدخل العدد": "Saisissez la quantité", "الثمن غير صحيح": "Prix incorrect", "أضف منتجاً واحداً على الأقل": "Ajoutez au moins un produit", "تم حفظ وصل التسليم بشكل مستقل عن المبيعات": "Bon de livraison enregistré indépendamment des ventes", "أضف منتجات إلى الوصل أولاً": "Ajoutez d'abord des produits au bon", "تعذر إنشاء PDF:": "Impossible de créer le PDF :", "الطباعة الحرارية متاحة داخل تطبيق Android.": "L'impression thermique est disponible uniquement dans l'application Android.", "لا توجد مبيعات للطباعة": "Aucune vente à imprimer", "لا توجد مبيعات لإنشاء وصل التسليم": "Aucune vente pour créer un bon de livraison", "اختيار جهات الاتصال متاح داخل تطبيق Android فقط": "La sélection des contacts est disponible uniquement dans l'application Android", "تعذر فتح جهات الاتصال": "Impossible d'ouvrir les contacts", "تم حفظ الزبون": "Client enregistré", "تم حفظ المصروف": "Dépense enregistrée", "بيانات غير صحيحة": "Données incorrectes", "تم تعديل المنتج بنجاح": "Produit modifié avec succès", "حذف هذا المنتج؟": "Supprimer ce produit ?", "تم استرجاع البيانات": "Données restaurées", "ملف النسخة الاحتياطية غير صالح": "Fichier de sauvegarde invalide", "أدخل رقم المنتج": "Saisissez la référence du produit", "أدخل كمية صحيحة": "Saisissez une quantité valide", "رقم المنتج غير موجود في المخزون": "Produit introuvable dans le stock", "أدخل اسم الزبون": "Saisissez le nom du client", "أدخل مبلغاً صحيحاً": "Saisissez un montant valide", "تم تسجيل الكريدي بنجاح": "Crédit enregistré avec succès", "هل تريد حذف هذا الكريدي؟": "Voulez-vous supprimer ce crédit ?", "أدخل رقم الشيك": "Saisissez le numéro du chèque", "أدخل اسم المستفيد": "Saisissez le bénéficiaire", "تم تسجيل الشيك بنجاح": "Chèque enregistré avec succès", "هل تريد حذف هذا الشيك؟": "Voulez-vous supprimer ce chèque ?", "تم تسجيل البيع. المتبقي في المخزون:": "Vente enregistrée. Stock restant :", "اسم": "Nom", "رقم": "Référence", "الثمن": "Prix", "مع الخفض": "Prix remisé", "💰 الأسعار": "💰 Prix", "🔍 بحث باسم المنتوج": "🔍 Rechercher par nom du produit", "🔢 بحث برقم/مرجع المنتوج": "🔢 Rechercher par référence du produit", "⭐ أولوية البحث بالاسم: اكتب اسم المنتوج أولاً، وستظهر في خانة الرقم فقط الأرقام المرتبطة بهذا الاسم. يمكنك بعدها اختيار رقم لتضييق النتيجة.": "Vous pouvez rechercher par nom ou référence du produit.", "🔍 ابحث باسم المنتوج أو الرقم": "🔍 Rechercher par nom du produit ou référence", "لا توجد نتائج للبحث": "Aucun résultat"};
  let AFZ_LANG = localStorage.getItem('afz_lang') || 'ar';
  const originalText = new WeakMap();
  const originalAttr = new WeakMap();

  function tr(value){
    if (AFZ_LANG === 'ar') return value;
    if (AFZ_TRANSLATIONS[value] !== undefined) return AFZ_TRANSLATIONS[value];
    let out=value;
    const keys=Object.keys(AFZ_TRANSLATIONS).sort((a,b)=>b.length-a.length);
    for(const k of keys){
      if(out.includes(k)) out=out.split(k).join(AFZ_TRANSLATIONS[k]);
    }
    return out;
  }

  function translateTree(root){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n=>{
      if(!originalText.has(n)) originalText.set(n,n.nodeValue);
      const o=originalText.get(n);
      n.nodeValue=tr(o);
    });
    root.querySelectorAll('input,textarea,select,option,button').forEach(el=>{
      ['placeholder','title'].forEach(a=>{
        if(el.hasAttribute(a)){
          if(!originalAttr.has(el)) originalAttr.set(el,{});
          const rec=originalAttr.get(el);
          if(rec[a]===undefined) rec[a]=el.getAttribute(a);
          el.setAttribute(a,tr(rec[a]));
        }
      });
    });
  }

  function applyLanguage(){
    document.documentElement.lang=AFZ_LANG==='fr'?'fr':'ar';
    document.documentElement.dir=AFZ_LANG==='fr'?'ltr':'rtl';
    document.body.classList.toggle('lang-fr',AFZ_LANG==='fr');
    const b=document.getElementById('langToggle');
    if(b) b.textContent=AFZ_LANG==='fr'?'🇲🇦 العربية':'🇫🇷 Français';
    translateTree(document.body);
  }

  window.toggleLanguage=function(){
    AFZ_LANG=AFZ_LANG==='fr'?'ar':'fr';
    localStorage.setItem('afz_lang',AFZ_LANG);
    applyLanguage();
  };
  window.addEventListener('DOMContentLoaded',()=>setTimeout(applyLanguage,0));

  // Wrap render so dynamically generated sections are translated as well.
  const wrap=()=>{
    if(typeof window.render==='function' && !window.__afzRenderWrapped){
      const base=window.render;
      window.render=function(){ base.apply(this,arguments); setTimeout(applyLanguage,0); };
      window.__afzRenderWrapped=true;
    }
  };
  setTimeout(wrap,0);
  setInterval(wrap,250);
})();
