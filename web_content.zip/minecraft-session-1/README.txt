माइनक्राफ्ट सेशन 1 – Minecraft Session 1
निर्माता / Created by: Navneet Bhaskar

कैसे खोलें:
1. ZIP को खोलें (Extract करें)।
2. index.html फ़ाइल को Chrome ब्राउज़र में खोलें।
3. पहली बार खोलते समय इंटरनेट चालू रखें (3D लाइब्रेरी three.js और फ़ॉन्ट इंटरनेट से आते हैं)।

APK बनाने के लिए:
इस फ़ोल्डर को (index.html के साथ) किसी HTML-to-APK टूल में डाल सकते हैं।
मुख्य फ़ाइल: index.html

How to open:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Keep the internet on the first time (three.js and the font load from the internet).

फुल स्क्रीन / आड़ा (Landscape):
- खेलें दबाते ही गेम फुल स्क्रीन होकर आड़ा (landscape) लॉक हो जाता है। ऊपर ⛶ बटन से फुल स्क्रीन चालू/बंद करें।
- APK बनाते समय टूल की सेटिंग में Orientation = Landscape और Fullscreen = ON चुनें।
- manifest.json भी साथ में है (display: fullscreen, orientation: landscape)।

Full screen / Landscape:
- Pressing Play switches to full screen and locks landscape. Use the ⛶ button to toggle.
- In your APK builder choose Orientation = Landscape and Fullscreen = ON.
