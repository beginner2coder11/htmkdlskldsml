from flask import Flask, jsonify

app = Flask(__name__)

# Mock Database
ACCOUNT_DATA = {
    "balance": 12500.50,
    "account_number": "9876543210",
    "routing_number": "071000013",
    "transactions": [
        {"desc": "Payroll Direct Deposit", "amount": 4500.00},
        {"desc": "Streaming Service", "amount": -15.99},
        {"desc": "Local Grocery", "amount": -120.45}
    ]
}

@app.route('/api/account', methods=['GET'])
def get_account():
    return jsonify({
        "status": "success",
        "data": ACCOUNT_DATA
    })

if __name__ == '__main__':
    # Run on localhost so the Android WebView can access it
    app.run(host='0.0.0.0', port=5000, debug=True)