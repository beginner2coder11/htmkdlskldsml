KEA HSE STORE REGISTER - APP PACKAGE
====================================
1. Unzip the whole folder (keep the folder structure).
2. Open index.html (double-click, or open it in Chrome on phone/laptop).
3. Splash: 2 photos x 3 seconds each, then the app opens (tap to skip).

Folders
  index.html        main page (start here)
  css/style.css     design and print layout
  js/app.js         app logic
  js/data.js        default item master list
  js/logo.js        KEA logo used on screen/PDF/Word
  assets/img        the two splash photos (replace with same file names to change)
  assets/icons      app icons
  manifest.json     lets you "Add to Home Screen" as an app

Editable options
  Dropdown Lists tab: Category, Unit, Supplier, Status, Company, Site Location,
  Worker, Defect details - add, tap a name to edit it, or X to delete.
  Item Master tab: edit item name, category, unit, min level, standard; add/delete items.
  New company/location/worker/defect typed in the Daily Log are saved to the lists automatically.

Data is stored in the browser on that device. Use "Save backup" / "Restore" to move data.
