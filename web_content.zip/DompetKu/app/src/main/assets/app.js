'use strict';
const KEY='dompetku_final_v1',VER=2;
const MON=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const DC=['Makan & Minuman','Transportasi','BBM','Perbaikan Motor','Kebutuhan Bulanan','Sabun & Perawatan','Skincare','Pulsa & Internet','Hiburan','Keinginan','Belanja','Kesehatan','Sedekah','Lainnya'];
const GT=['Menikah','Rumah','Dana Darurat','Dana Cadangan','Restorasi Motor','Touring','Kendaraan','Pendidikan','Liburan','Gadget','Renovasi','Modal Usaha','Sedekah','Keinginan','Investasi','Kebutuhan Keluarga','Lainnya'];
const BANK=['BCA','BRI','BNI','Mandiri','BSI','CIMB Niaga','Bank lainnya'],EW=['GoPay','DANA','OVO','ShopeePay','E-Wallet lainnya'];
const COL=['#087f5b','#4385f5','#e99a2e','#8b5cf6','#d8ae2c','#d94343','#10a970','#74817c','#17352b','#f08fb0'];
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>'Rp '+new Intl.NumberFormat('id-ID',{maximumFractionDigits:0}).format(Math.round(n||0));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const pad=n=>String(n).padStart(2,'0');
const dstr=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const nowTs=()=>{const d=new Date();return dstr(d)+'T'+pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds())};
let db,ui={tab:'home',pt:'today',ht:'dana',f:{type:'all',per:'all',month:'',acc:'all'}};
function toast(m){const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(ui.tt);ui.tt=setTimeout(()=>t.style.display='none',2500)}
/* ===== DB, validasi, migrasi ===== */
const valid=o=>o&&typeof o==='object'&&typeof o.version==='number'&&o.version<=VER&&['accounts','categories','transactions','budgets','goals'].every(k=>Array.isArray(o[k]));
function migrate(o){const d=JSON.parse(JSON.stringify(o));d.settings=d.settings||{};
 const D=/^\d{4}-\d{2}-\d{2}$/,T=/^\d{4}-\d{2}-\d{2}T[\d:.]+Z?$/;
 d.accounts.forEach(a=>{a.opening=+a.opening||0;a.name=String(a.name??'');a.note=String(a.note||'')});
 d.transactions.forEach(t=>{t.amount=+t.amount||0;t.note=String(t.note||'');if(!t.id)t.id=uid();
  if(!D.test(t.date))t.date=T.test(t.createdAt)?t.createdAt.slice(0,10):'1970-01-01';
  if(!T.test(t.createdAt)){t.createdAt=t.date+'T00:00:00';t.noTime=true}
  if(!T.test(t.updatedAt))t.updatedAt=t.createdAt});
 d.goals.forEach(g=>{g.initialSaved=+g.initialSaved||0;g.target=+g.target||0;g.start=D.test(g.start)?g.start:'';g.end=D.test(g.end)?g.end:'';g.storageType=String(g.storageType||'Lainnya');g.storageName=String(g.storageName||'');g.note=String(g.note||'')});
 d.budgets.forEach(b=>{b.amount=+b.amount||0;b.start=D.test(b.start)?b.start:'';b.end=D.test(b.end)?b.end:'';if(!['weekly','monthly','yearly','custom'].includes(b.period))b.period='monthly'});
 DC.forEach((n,i)=>{if(!d.categories.some(c=>String(c.name).toLowerCase()===n.toLowerCase()))d.categories.push({id:d.categories.some(c=>c.id==='c'+i)?uid():'c'+i,name:n})});
 d.version=VER;return d}
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
function load(){const raw=localStorage.getItem(KEY);let o=null;
 try{o=raw?JSON.parse(raw):null}catch(e){}
 if(raw&&!valid(o)){localStorage.setItem(KEY+'_corrupt',raw);o=null}
 if(!o)o={version:VER,accounts:[],categories:[],transactions:[],budgets:[],goals:[]};
 if(raw&&o.version<VER)localStorage.setItem(KEY+'_v'+o.version+'_backup',raw);
 try{const n=migrate(o);if(!valid(n))throw 0;db=n;save()}catch(e){db=o;toast('Migrasi gagal. Data lama tidak diubah.')}}
const commit=()=>{save();renderAll()};
/* ===== Perhitungan ===== */
const catName=id=>(db.categories.find(c=>c.id===id)||{name:'(dihapus)'}).name;
const accName=id=>(db.accounts.find(a=>a.id===id)||{name:'(dihapus)'}).name;
const goalOf=id=>db.goals.find(g=>g.id===id);
function bal(id,skip){const a=db.accounts.find(x=>x.id===id);if(!a)return 0;let b=+a.opening||0;
 db.transactions.forEach(t=>{if(t.id===skip)return;const m=t.amount;
  if(t.type==='income'&&t.accountId===id)b+=m;
  else if((t.type==='expense'||t.type==='goal')&&t.accountId===id)b-=m;
  else if(t.type==='transfer'){if(t.from===id)b-=m;if(t.to===id)b+=m}});return b}
const total=()=>db.accounts.reduce((s,a)=>s+bal(a.id),0);
const saved=(g,skip)=>g.initialSaved+db.transactions.filter(t=>t.type==='goal'&&t.goalId===g.id&&t.id!==skip).reduce((s,t)=>s+t.amount,0);
function range(p,ref){const d=ref||new Date(),y=d.getFullYear(),m=d.getMonth();
 if(p==='today')return[dstr(d),dstr(d)];
 if(p==='week'||p==='weekly'){const w=(d.getDay()+6)%7;return[dstr(new Date(y,m,d.getDate()-w)),dstr(new Date(y,m,d.getDate()-w+6))]}
 if(p==='month'||p==='monthly')return[dstr(new Date(y,m,1)),dstr(new Date(y,m+1,0))];
 if(p==='yearly')return[y+'-01-01',y+'-12-31']}
const inR=(t,r)=>t.date>=r[0]&&t.date<=r[1];
const exps=r=>db.transactions.filter(t=>t.type==='expense'&&inR(t,r));
const sum=a=>a.reduce((s,t)=>s+t.amount,0);
const newest=(a,b)=>a.createdAt<b.createdAt?1:a.createdAt>b.createdAt?-1:0;
function byCat(list){const m={};list.forEach(t=>m[t.categoryId]=(m[t.categoryId]||0)+t.amount);return Object.entries(m).map(([k,v])=>({k,n:catName(k),v})).sort((a,b)=>b.v-a.v)}
function dayLabel(d){const t=new Date(),y=new Date(t.getFullYear(),t.getMonth(),t.getDate()-1);
 return d===dstr(t)?'Hari ini':d===dstr(y)?'Kemarin':(+d.slice(8))+' '+MON[+d.slice(5,7)-1]+' '+d.slice(0,4)}
const bRange=b=>b.period==='custom'?[b.start,b.end]:range(b.period);
/* ===== Render ===== */
const IC={home:'M3 11l9-8 9 8v10H3z',tx:'M4 6h16M4 12h16M4 18h16',exp:'M12 3v9h9a9 9 0 1 1-9-9z',goal:'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8',acc:'M3 7h16a2 2 0 0 1 2 2v10H5a2 2 0 0 1-2-2zM3 7l2-3h12'};
const NAV=[['home','Beranda'],['tx','Transaksi'],['exp','Pengeluaran'],['goal','Target'],['acc','Akun']];
function go(t){ui.tab=t;renderAll();scrollTo(0,0)}
function renderHeader(){const r=range('month'),inc=sum(db.transactions.filter(t=>t.type==='income'&&inR(t,r))),ex=sum(exps(r));
 $('#hdr').innerHTML=`<div class=brand><svg width=38 height=36 viewBox="0 0 512 490"><ellipse cx="256" cy="462" rx="205" ry="15" fill="#06402e" opacity=".22"/><g transform="translate(-6 -16) rotate(9 180 142)"><path d="M70.00,96.00Q70.00,70.00 96.00,70.00L264.00,70.00Q290.00,70.00 290.00,96.00L290.00,189.00Q290.00,215.00 264.00,215.00L96.00,215.00Q70.00,215.00 70.00,189.00Z" fill="#9fdcb8" stroke="#087f5b" stroke-width="8"/></g><g transform="rotate(-14 180 142)"><path d="M70.00,96.00Q70.00,70.00 96.00,70.00L264.00,70.00Q290.00,70.00 290.00,96.00L290.00,189.00Q290.00,215.00 264.00,215.00L96.00,215.00Q70.00,215.00 70.00,189.00Z" fill="#d7f5e6" stroke="#087f5b" stroke-width="8"/><circle cx="180" cy="142" r="32" fill="#10a970"/></g><circle cx="336" cy="148" r="90" fill="#f4cb4a" stroke="#b8891a" stroke-width="10"/><circle cx="336" cy="148" r="68" fill="none" stroke="#c9961f" stroke-width="6"/><path d="M50.00,324.00Q50.00,290.00 74.04,265.96L105.96,234.04Q130.00,210.00 164.00,210.00L428.00,210.00Q462.00,210.00 462.00,244.00L462.00,406.00Q462.00,440.00 428.00,440.00L84.00,440.00Q50.00,440.00 50.00,406.00Z" fill="#ec9d2c"/><path d="M318.00,332.00Q318.00,296.00 354.00,296.00L450.00,296.00Q486.00,296.00 486.00,332.00L486.00,336.00Q486.00,372.00 450.00,372.00L354.00,372.00Q318.00,372.00 318.00,336.00Z" fill="#c97d12"/><circle cx="372" cy="334" r="15" fill="#fff"/></svg>DompetKu</div><div style="font-size:12px;margin-top:12px;opacity:.85">Total saldo</div><div class=big>${fmt(total())}</div><div class=hs><div>Pemasukan bulan ini<b>${fmt(inc)}</b></div><div>Pengeluaran bulan ini<b>${fmt(ex)}</b></div><div>Sisa bulan ini<b>${fmt(inc-ex)}</b></div></div>`;
 $('#nav').innerHTML=NAV.map(([k,l])=>`<button class="${ui.tab===k?'on':''}" onclick="go('${k}')"><svg viewBox="0 0 24 24"><path d="${IC[k]}"/></svg>${l}</button>`).join('');
 document.querySelectorAll('section').forEach(s=>s.classList.toggle('on',s.id==='p-'+ui.tab))}
function donut(items,center){const T=items.reduce((s,i)=>s+i.v,0);if(!T)return'<p class=mu>Belum ada data bulan ini.</p>';
 let a=0;const g=items.map(i=>{const p=i.v/T*100,s=`${i.c} ${a}% ${a+p}%`;a+=p;return s}).join(',');
 return`<div class=donut style="background:conic-gradient(${g})"><i>${esc(center)}</i></div>`+items.map(i=>`<div class=lg><u style="background:${i.c}"></u><span>${esc(i.n)}</span><b>${(i.v/T*100).toFixed(1)}%</b><span style="text-align:right;flex:none">${fmt(i.v)}</span></div>`).join('')}
function renderChart(){const r=range('month'),e=exps(r),T=sum(e);let h=`<div class=tabs><button class="${ui.ht==='dana'?'on':''}" onclick="ui.ht='dana';renderChart()">Komposisi Dana</button><button class="${ui.ht==='exp'?'on':''}" onclick="ui.ht='exp';renderChart()">Pengeluaran</button></div>`;
 if(ui.ht==='dana'){const it=[];const av=Math.max(total(),0);if(av>0)it.push({n:'Dana tersedia',v:av,c:COL[0]});byCat(e).slice(0,8).forEach((c,i)=>it.push({n:c.n,v:c.v,c:COL[i+1]}));h+=donut(it,fmt(av))}
 else h+=donut(byCat(e).slice(0,10).map((c,i)=>({n:c.n,v:c.v,c:COL[i%COL.length]})),fmt(T));
 $('#chartCard').innerHTML=h}
function renderPeriodSummary(){const P={today:'Hari ini',week:'Minggu ini',month:'Bulan ini'},e=exps(range(ui.pt)),c=byCat(e);
 $('#periodCard').innerHTML=`<h3>Ringkasan Pengeluaran</h3><div class=tabs>${Object.keys(P).map(k=>`<button class="${ui.pt===k?'on':''}" onclick="ui.pt='${k}';renderPeriodSummary()">${P[k]}</button>`).join('')}</div>`+(e.length?`<div class=big style="color:var(--tx);font-size:22px;margin:0">${fmt(sum(e))}</div><p class=mu>${e.length} transaksi · Terbesar: ${esc(c[0].n)} (${fmt(c[0].v)})</p>${e.sort(newest).slice(0,5).map(txRow).join('')}`:'<p class=mu>Belum ada pengeluaran pada periode ini.</p>')}
function mini(){let h='<h3>Target</h3>';const bs=db.budgets.slice(0,3),gs=db.goals.slice(0,3);
 if(!bs.length&&!gs.length)return $('#miniT').innerHTML=h+'<p class=mu>Belum ada target pengeluaran.</p><p class=mu>Belum ada target dana.</p>';
 h+='<p class=mu>Target pengeluaran</p>'+(bs.map(b=>{const u=sum(exps(bRange(b)).filter(t=>t.categoryId===b.categoryId));return`<div class=row><span>${esc(catName(b.categoryId))}</span><span class=mu>${fmt(u)} / ${fmt(b.amount)}</span></div>`}).join('')||'<p class=mu>Belum ada target pengeluaran.</p>');
 h+='<p class=mu>Target dana</p>'+(gs.map(g=>`<div class=row><span>${esc(g.name)}</span><span class=mu>${fmt(saved(g))} / ${fmt(g.target)}</span></div>`).join('')||'<p class=mu>Belum ada target dana.</p>');$('#miniT').innerHTML=h}
function txTitle(t){return t.type==='expense'?catName(t.categoryId):t.type==='income'?'Pemasukan':t.type==='transfer'?accName(t.from)+' → '+accName(t.to):'Dana Target: '+((goalOf(t.goalId)||{}).name||'(dihapus)')}
function txRow(t){const s=t.type==='income'?'+':t.type==='transfer'?'':'-',c=t.type==='income'?'in':t.type==='expense'?'out':'';
 const acc=t.type==='transfer'?'':accName(t.accountId);return`<div class=tr data-id="${esc(t.id)}" onclick="txForm(db.transactions.find(x=>x.id===this.dataset.id))"><div><div>${esc(txTitle(t))}</div><div class=mu>${t.noTime?'':t.createdAt.slice(11,16)+' · '}${esc(acc)}${t.note?' · '+esc(t.note):''}</div></div><b class="${c}">${s}${fmt(t.amount)}</b></div>`}
function renderRecent(){const l=[...db.transactions].sort(newest).slice(0,5);$('#recent').innerHTML=l.length?l.map(txRow).join(''):'<p class=mu>Belum ada transaksi.</p>'}
const opts=(a,sel,f)=>a.map(x=>{const v=f?f(x)[0]:x,l=f?f(x)[1]:x;return`<option value="${esc(v)}" ${v===sel?'selected':''}>${esc(l)}</option>`}).join('');
function renderTransactions(){const f=ui.f;
 $('#filters').innerHTML=`<div class=card><label>Jenis</label><select onchange="ui.f.type=this.value;renderTransactions()">${opts(['all','income','expense','transfer','goal'],f.type,v=>[v,{all:'Semua',income:'Pemasukan',expense:'Pengeluaran',transfer:'Transfer',goal:'Dana Target'}[v]])}</select><label>Periode</label><select onchange="ui.f.per=this.value;renderTransactions()">${opts(['all','today','week','month','pick'],f.per,v=>[v,{all:'Semua',today:'Hari ini',week:'Minggu ini',month:'Bulan ini',pick:'Pilih bulan'}[v]])}</select>${f.per==='pick'?`<input type=month value="${esc(f.month)}" onchange="ui.f.month=this.value;renderTransactions()">`:''}<label>Akun</label><select onchange="ui.f.acc=this.value;renderTransactions()"><option value=all>Semua akun</option>${opts(db.accounts,f.acc,a=>[a.id,a.name])}</select></div>`;
 let r=null;if(['today','week','month'].includes(f.per))r=range(f.per);else if(f.per==='pick'&&f.month){const[y,m]=f.month.split('-');r=[f.month+'-01',dstr(new Date(+y,+m,0))]}
 const l=db.transactions.filter(t=>(f.type==='all'||t.type===f.type)&&(!r||inR(t,r))&&(f.acc==='all'||[t.accountId,t.from,t.to].includes(f.acc)));
 if(!l.length)return $('#txList').innerHTML='<p class=mu>Belum ada transaksi.</p>';
 const g={};l.forEach(t=>(g[t.date]=g[t.date]||[]).push(t));
 $('#txList').innerHTML=Object.keys(g).sort().reverse().map(d=>`<div class=day>${dayLabel(d)}</div><div class=card style="margin:0">${g[d].sort(newest).map(txRow).join('')}</div>`).join('')}
function bar(p,over){return`<div class=bar><b style="width:${Math.min(100,p)}%;${over?'background:var(--d)':''}"></b></div>`}
function renderBudgets(){const PL={weekly:'Mingguan',monthly:'Bulanan',yearly:'Tahunan',custom:'Custom'};
 $('#budgets').innerHTML=db.budgets.length?db.budgets.map(b=>{const r=bRange(b),u=sum(exps(r).filter(t=>t.categoryId===b.categoryId)),p=b.amount?u/b.amount*100:0;
  return`<div class=card><div class=row><b>${esc(catName(b.categoryId))}</b><span class=st>${PL[b.period]||''}</span></div><p class=mu>${r[0]} s/d ${r[1]}</p>${bar(p,u>b.amount)}<div class=row><span>Terpakai ${fmt(u)}</span><span class=mu>Batas ${fmt(b.amount)}</span></div><div class=row><span class=mu>Sisa ${fmt(b.amount-u)} · ${p.toFixed(0)}%</span><span><button class=btn data-id="${esc(b.id)}" onclick="budgetForm(this.dataset.id)">Edit</button> <button class="btn dng" data-id="${esc(b.id)}" onclick="delBudget(this.dataset.id)">Hapus</button></span></div></div>`}).join(''):'<p class=mu>Belum ada target pengeluaran.</p>'}
function renderGoals(){$('#goals').innerHTML=db.goals.length?db.goals.map(g=>{const s=saved(g),p=g.target?s/g.target*100:0,done=s>=g.target,today=dstr(new Date()),late=!done&&g.end&&g.end<today;
  const days=g.end?Math.ceil((new Date(g.end)-new Date(today))/864e5):null,left=days===null?'-':days<0?'Waktu lewat':days+' hari lagi',per=days>0&&!done?fmt((g.target-s)/Math.max(1,Math.ceil(days/30)))+'/bulan':'-';
  return`<div class=card><div class=row><b>${esc(g.name)}</b><span class=st>${done?'Tercapai ✓':late?'Waktu lewat':'Aktif'}</span></div><p class=mu>${esc(g.storageType)}${g.storageName&&g.storageName!==g.storageType?' · '+esc(g.storageName):''}</p>${bar(p)}<div class=row><span>${fmt(s)} / ${fmt(g.target)}</span><b>${p.toFixed(0)}%</b></div><p class=mu>Sisa ${fmt(Math.max(0,g.target-s))} · ${left} · Kebutuhan ${per}</p><div class=row><button class="btn pri" data-id="${esc(g.id)}" onclick="txForm(null,'goal',this.dataset.id)">+ Tambah Dana</button><span><button class=btn data-id="${esc(g.id)}" onclick="goalForm(this.dataset.id)">Edit</button> <button class="btn dng" data-id="${esc(g.id)}" onclick="delGoal(this.dataset.id)">Hapus</button></span></div></div>`}).join(''):'<p class=mu>Belum ada target dana.</p>'}
function renderAccounts(){$('#accounts').innerHTML=db.accounts.length?db.accounts.map(a=>`<div class=card><div class=row><b>${esc(a.name)}</b><b>${fmt(bal(a.id))}</b></div>${a.note?`<p class=mu>${esc(a.note)}</p>`:''}<div class=row><span class=mu>Saldo awal ${fmt(a.opening)}</span><span><button class=btn data-id="${esc(a.id)}" onclick="accForm(this.dataset.id)">Edit</button> <button class="btn dng" data-id="${esc(a.id)}" onclick="delAcc(this.dataset.id)">Hapus</button></span></div></div>`).join(''):'<p class=mu>Belum ada akun. Tambahkan BCA, Cash, E-Wallet, atau sumber dana lainnya.</p>'}
function renderAll(){renderHeader();renderChart();renderPeriodSummary();mini();renderRecent();renderTransactions();renderBudgets();renderGoals();renderAccounts()}
/* ===== Modal ===== */
function modal(title,body,onSave,onDel){ui.m={save:onSave,del:onDel};$('#modal').innerHTML=`<div class=sheet><div class=mh><b>${esc(title)}</b><button class=x onclick="closeM()">✕</button></div><div class=mb>${body}<div id=err class=err></div></div><div class=mf>${onDel?'<button class="btn dng" onclick="ui.m.del()">Hapus</button>':''}<button class=btn onclick="closeM()">Batal</button><button class="btn pri" onclick="ui.m.save()">Simpan</button></div></div>`;$('#modal').classList.add('show')}
const closeM=()=>$('#modal').classList.remove('show');
const err=m=>{$('#err').textContent=m;return false};
function confirmBox(msg,ok,cb){ui.cb=cb;$('#cf').innerHTML=`<div class=cfb><p>${esc(msg)}</p><div class=row><button class=btn style="flex:1" onclick="closeC()">Batal</button><button class="btn pri" style="flex:1" onclick="closeC();ui.cb()">${esc(ok)}</button></div></div>`;$('#cf').classList.add('show')}
const closeC=()=>$('#cf').classList.remove('show');
window.onBack=()=>{if($('#cf').classList.contains('show')){closeC();return true}if($('#modal').classList.contains('show')){closeM();return true}return false};
const S=()=>db.settings;
/* ===== Form transaksi ===== */
function txForm(t,type,gid){type=t?t.type:(type||'expense');
 const tabs=t?'':`<div class=tabs>${[['expense','Pengeluaran'],['income','Pemasukan'],['transfer','Transfer'],['goal','Dana Target']].map(([k,l])=>`<button class="${k===type?'on':''}" onclick="txForm(null,'${k}')">${l}</button>`).join('')}</div>`;
 const dflt=t?(t.accountId):(db.accounts.some(a=>a.id===S().lastAcc)?S().lastAcc:(db.accounts[0]||{}).id);
 const ao=(sel)=>opts(db.accounts,sel,a=>[a.id,a.name+' ('+fmt(bal(a.id))+')']);
 let f='';
 if(type==='expense')f=`<label>Kategori</label><select id=f-cat>${opts(db.categories,t?t.categoryId:S().lastCat,c=>[c.id,c.name])}</select><label>Akun / sumber dana</label><select id=f-acc>${ao(dflt)}</select>`;
 if(type==='income')f=`<label>Akun tujuan</label><select id=f-acc>${ao(dflt)}</select>`;
 if(type==='transfer')f=`<label>Dari</label><select id=f-from>${ao(t?t.from:dflt)}</select><label>Ke</label><select id=f-to>${ao(t?t.to:(db.accounts.find(a=>a.id!==dflt)||{}).id)}</select>`;
 if(type==='goal')f=`<label>Target Dana</label><select id=f-goal>${opts(db.goals,t?t.goalId:gid,g=>[g.id,g.name])}</select><label>Diambil dari akun</label><select id=f-acc>${ao(dflt)}</select>`;
 if(type!=='expense'&&type!=='income'&&type!=='transfer'&&type!=='goal')return;
 const body=tabs+((type!=='transfer'&&!db.accounts.length)||(type==='goal'&&!db.goals.length)?`<p class=mu>${!db.accounts.length?'Belum ada akun. Tambahkan BCA, Cash, E-Wallet, atau sumber dana lainnya.':'Belum ada target dana.'}</p>`:'')+`<label>Nominal</label><input id=f-amt type=number inputmode=numeric min=1 value="${t?t.amount:''}" placeholder="0">`+f+`<label>Tanggal</label><input id=f-date type=date value="${t?t.date:dstr(new Date())}"><label>Catatan</label><input id=f-note value="${t?esc(t.note):''}">`;
 modal(t?'Edit Transaksi':'Tambah Transaksi',body,()=>saveTx(t,type),t?()=>confirmBox('Hapus transaksi ini?','Hapus',()=>{db.transactions=db.transactions.filter(x=>x.id!==t.id);closeM();commit()}):null)}
function saveTx(t,type){const v=i=>($(i)||{}).value,amt=Math.round(+v('#f-amt')),date=v('#f-date'),skip=t&&t.id;
 if(!(amt>0))return err('Nominal wajib diisi dan lebih dari 0.');if(!date)return err('Tanggal wajib diisi.');
 const o=Object.assign({},t||{id:uid(),createdAt:nowTs()},{type,amount:amt,date,note:v('#f-note').trim(),updatedAt:nowTs()});
 let warn=false;
 if(type==='expense'||type==='income'||type==='goal'){o.accountId=v('#f-acc');if(!db.accounts.some(a=>a.id===o.accountId))return err('Akun wajib dipilih.')}
 if(type==='expense'){o.categoryId=v('#f-cat');if(!o.categoryId)return err('Kategori wajib dipilih.');if(bal(o.accountId,skip)<amt)warn=true}
 if(type==='transfer'){o.from=v('#f-from');o.to=v('#f-to');if(!o.from||!o.to)return err('Akun asal dan tujuan wajib dipilih.');if(o.from===o.to)return err('Akun asal dan tujuan harus berbeda.');if(bal(o.from,skip)<amt)return err('Saldo akun asal tidak cukup.')}
 if(type==='goal'){o.goalId=v('#f-goal');const g=goalOf(o.goalId);if(!g)return err('Target wajib dipilih.');if(bal(o.accountId,skip)<amt)return err('Saldo akun tidak cukup.');if(amt>g.target-saved(g,skip))return err('Nominal melebihi sisa target.')}
 const fin=()=>{if(!t)db.transactions.push(o);else db.transactions[db.transactions.findIndex(x=>x.id===t.id)]=o;
  if(o.accountId)S().lastAcc=o.accountId;if(o.categoryId)S().lastCat=o.categoryId;closeM();commit()};
 warn?confirmBox('Saldo akun tidak cukup. Tetap catat?','Tetap catat',fin):fin()}
/* ===== Akun ===== */
function accForm(id){const a=db.accounts.find(x=>x.id===id);
 modal(a?'Edit Akun':'Tambah Akun',`<label>Nama akun</label><input id=a-n value="${a?esc(a.name):''}"><label>Saldo awal</label><input id=a-o type=number inputmode=numeric value="${a?a.opening:0}"><label>Catatan</label><input id=a-t value="${a?esc(a.note||''):''}">`,()=>{
  const n=$('#a-n').value.trim(),op=+$('#a-o').value;if(!n)return err('Nama akun wajib diisi.');if(isNaN(op))return err('Saldo awal tidak valid.');
  if(db.accounts.some(x=>x.id!==id&&x.name.toLowerCase()===n.toLowerCase()))return err('Nama akun sudah ada.');
  if(a){a.name=n;a.opening=op;a.note=$('#a-t').value.trim()}else db.accounts.push({id:uid(),name:n,opening:op,note:$('#a-t').value.trim()});closeM();commit()})}
function delAcc(id){if(db.transactions.some(t=>[t.accountId,t.from,t.to].includes(id)))return toast('Akun masih dipakai transaksi.');confirmBox('Hapus akun ini?','Hapus',()=>{db.accounts=db.accounts.filter(a=>a.id!==id);commit()})}
/* ===== Kategori ===== */
function catMgr(eid){const e=db.categories.find(c=>c.id===eid);
 modal('Kategori Pengeluaran',db.categories.map(c=>`<div class=row><span>${esc(c.name)}</span><span><button class=btn data-id="${esc(c.id)}" onclick="catMgr(this.dataset.id)">Edit</button> <button class="btn dng" data-id="${esc(c.id)}" onclick="delCat(this.dataset.id)">Hapus</button></span></div>`).join('')+`<label>${e?'Ubah nama':'Kategori baru'}</label><input id=c-n value="${e?esc(e.name):''}">`,()=>{
  const n=$('#c-n').value.trim();if(!n)return err('Nama wajib diisi.');if(db.categories.some(c=>c.id!==eid&&c.name.toLowerCase()===n.toLowerCase()))return err('Kategori sudah ada.');
  if(e)e.name=n;else db.categories.push({id:uid(),name:n});save();renderAll();catMgr()})}
function delCat(id){if(db.transactions.some(t=>t.categoryId===id)||db.budgets.some(b=>b.categoryId===id))return err('Kategori sedang digunakan.');db.categories=db.categories.filter(c=>c.id!==id);save();renderAll();catMgr()}
/* ===== Budget ===== */
function budgetForm(id){const b=db.budgets.find(x=>x.id===id);
 modal(b?'Edit Target Pengeluaran':'Tambah Target Pengeluaran',`<label>Kategori</label><select id=b-c>${opts(db.categories,b&&b.categoryId,c=>[c.id,c.name])}</select><label>Batas nominal</label><input id=b-a type=number inputmode=numeric value="${b?b.amount:''}"><label>Periode</label><select id=b-p onchange="$('#b-d').style.display=this.value==='custom'?'block':'none'">${opts(['weekly','monthly','yearly','custom'],b?b.period:'monthly',v=>[v,{weekly:'Mingguan',monthly:'Bulanan',yearly:'Tahunan',custom:'Custom'}[v]])}</select><div id=b-d style="display:${b&&b.period==='custom'?'block':'none'}"><label>Mulai</label><input id=b-s type=date value="${b?b.start||'':''}"><label>Selesai</label><input id=b-e type=date value="${b?b.end||'':''}"></div>`,()=>{
  const o={id:b?b.id:uid(),categoryId:$('#b-c').value,amount:Math.round(+$('#b-a').value),period:$('#b-p').value};
  if(!(o.amount>0))return err('Batas harus lebih dari 0.');
  if(o.period==='custom'){o.start=$('#b-s').value;o.end=$('#b-e').value;if(!o.start||!o.end||o.end<o.start)return err('Tanggal custom tidak valid.')}else{[o.start,o.end]=range(o.period)}
  if(b)db.budgets[db.budgets.indexOf(b)]=o;else db.budgets.push(o);closeM();commit()})}
const delBudget=id=>confirmBox('Hapus target pengeluaran ini?','Hapus',()=>{db.budgets=db.budgets.filter(b=>b.id!==id);commit()});
/* ===== Target Dana ===== */
const stoOpts=t=>t==='Bank'?BANK:t==='E-Wallet'?EW:[];
function stoChg(){const o=stoOpts($('#g-st').value);$('#g-sn').innerHTML=opts(o,'');$('#g-sn').style.display=o.length?'block':'none'}
function goalForm(id){const g=goalOf(id),ST=['Cash / Tunai','Bank','E-Wallet','Lainnya'];
 modal(g?'Edit Target Dana':'Tambah Target Dana',`<label>Nama (pilih template atau ketik)</label><input id=g-n list=g-l value="${g?esc(g.name):''}"><datalist id=g-l>${GT.map(x=>`<option value="${esc(x)}">`).join('')}</datalist><label>Target dana</label><input id=g-t type=number inputmode=numeric value="${g?g.target:''}"><label>${g?'Dana awal':'Dana awal (opsional)'}</label><input id=g-i type=number inputmode=numeric value="${g?g.initialSaved:0}">${g?'':`<label>Ambil dana awal dari akun</label><select id=g-a><option value="">Tanpa akun (dana sudah terpisah)</option>${opts(db.accounts,'',a=>[a.id,a.name])}</select>`}<label>Tempat penyimpanan</label><select id=g-st onchange="stoChg()">${opts(ST,g&&g.storageType)}</select><select id=g-sn></select><label>Tanggal mulai</label><input id=g-s type=date value="${g?g.start||'':dstr(new Date())}"><label>Tanggal selesai</label><input id=g-e type=date value="${g?g.end||'':''}"><label>Catatan</label><input id=g-o value="${g?esc(g.note||''):''}">`,()=>{
  const n=$('#g-n').value.trim(),tg=Math.round(+$('#g-t').value),ini=Math.round(+$('#g-i').value||0),st=$('#g-st').value,sn=$('#g-sn').value||st,s=$('#g-s').value,e=$('#g-e').value,src=g?'':$('#g-a').value;
  if(!n)return err('Nama wajib diisi.');if(!(tg>0))return err('Target harus lebih dari 0.');if(ini<0)return err('Dana awal tidak boleh negatif.');if(ini>tg)return err('Dana awal tidak boleh melebihi target.');
  if(!s||!e)return err('Tanggal mulai dan selesai wajib diisi.');if(e<s)return err('Tanggal selesai harus setelah tanggal mulai.');
  if(db.goals.some(x=>x.id!==id&&x.name.toLowerCase()===n.toLowerCase()))return err('Nama target sudah ada.');
  if(g){const cur=saved(g)-g.initialSaved;if(ini+cur>tg)return err('Total dana melebihi target.');Object.assign(g,{name:n,target:tg,initialSaved:ini,storageType:st,storageName:sn,start:s,end:e,note:$('#g-o').value.trim()})}
  else{if(ini>0&&src&&bal(src)<ini)return err('Saldo akun tidak cukup.');const ng={id:uid(),name:n,target:tg,initialSaved:src?0:ini,storageType:st,storageName:sn,start:s,end:e,note:$('#g-o').value.trim()};db.goals.push(ng);
   if(ini>0&&src){const ts=nowTs();db.transactions.push({id:uid(),type:'goal',amount:ini,date:dstr(new Date()),createdAt:ts,updatedAt:ts,note:'Dana awal',goalId:ng.id,accountId:src})}}
  closeM();commit()});
 if(g)$('#g-sn').innerHTML=opts(stoOpts(g.storageType),g.storageName);else stoChg();$('#g-sn').style.display=stoOpts($('#g-st').value).length?'block':'none'}
function delGoal(id){if(db.transactions.some(t=>t.goalId===id))return toast('Hapus dulu transaksi dana target terkait.');confirmBox('Hapus target ini?','Hapus',()=>{db.goals=db.goals.filter(g=>g.id!==id);commit()})}
/* ===== Backup & Restore ===== */
function backup(){const j=JSON.stringify(db,null,1),n='DompetKu-backup-'+dstr(new Date())+'.json';
 if(window.Android){window.onBackupDone=ok=>toast(ok?'Backup berhasil disimpan.':'Backup gagal.');Android.saveBackup(j,n)}
 else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([j],{type:'application/json'}));a.download=n;a.click();toast('Backup berhasil disimpan.')}}
function restore(){if(window.Android)Android.openRestore();else{const i=document.createElement('input');i.type='file';i.accept='application/json';i.onchange=()=>i.files[0].text().then(onRestoreData);i.click()}}
window.onRestoreData=t=>{let o=null;try{o=JSON.parse(t)}catch(e){}
 if(!valid(o))return toast('File backup tidak valid atau berasal dari versi yang tidak didukung.');
 confirmBox('Restore akan menimpa data saat ini. Lanjutkan?','Restore',()=>{try{const n=migrate(o);if(!valid(n))throw 0;localStorage.setItem(KEY+'_prerestore',localStorage.getItem(KEY)||'');db=n;save();renderAll();toast('Restore berhasil.')}catch(e){toast('File backup tidak valid atau berasal dari versi yang tidak didukung.')}})};
load();renderAll();
