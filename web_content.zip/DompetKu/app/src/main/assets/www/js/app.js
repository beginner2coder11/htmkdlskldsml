'use strict';
const V=2,$=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rp=n=>'Rp '+new Intl.NumberFormat('id-ID').format(Math.round(n));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
// ---- tanggal (string YYYY-MM-DD, aritmatika UTC, bebas zona waktu) ----
const D=(y,m,d)=>new Date(Date.UTC(y,m,d)).toISOString().slice(0,10); // m 0-based
const P=s=>s.split('-').map(Number); // m 1-based
const add=(s,n)=>{const[y,m,d]=P(s);return D(y,m-1,d+n)};
const diff=(a,b)=>Math.round((Date.parse(b)-Date.parse(a))/864e5);
const today=()=>{const n=new Date();return D(n.getFullYear(),n.getMonth(),n.getDate())};
const nowTs=()=>{const n=new Date(),p=x=>String(x).padStart(2,'0');return today()+'T'+p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds())};
// Siklus = tanggal gajian NOMINAL -> sehari sebelum gajian nominal berikutnya.
function calculateSpendingCycle(ref,pd){const[y,m,d]=P(ref);const s=d>=pd?D(y,m-1,pd):D(y,m-2,pd);const[sy,sm]=P(s);return{start:s,end:D(sy,sm,pd-1)}}
// Hanya info kapan uang masuk. TIDAK dipakai untuk batas siklus.
function calculateActualPayDate(y,m,pd){const s=D(y,m,pd),w=new Date(s).getUTCDay();return w==6?add(s,-1):w==0?add(s,-2):s}
const calculateRemainingDays=(t,e)=>Math.max(0,diff(t,e)+1);
//END-CORE
const CATS=['Makan & Minuman','Transportasi','BBM','Perbaikan Motor','Kebutuhan Bulanan','Sabun & Perawatan','Skincare','Pulsa & Internet','Hiburan','Keinginan','Belanja','Kesehatan','Sedekah','Lainnya'];
const TY={expense:'Pengeluaran',income:'Pemasukan',transfer:'Transfer',goal:'Dana Target'};
const TPL=['Menikah','Rumah','Dana Darurat','Dana Cadangan','Restorasi Motor','Touring','Kendaraan','Pendidikan','Liburan','Gadget','Renovasi','Modal Usaha','Sedekah','Investasi','Kebutuhan Keluarga','Lainnya'];
const B=window.Android;
let db,broken=false,tab='home',editing=null,cb={};
let flt={type:'all',per:'all',acc:'all',from:'',to:''};
const fresh=()=>({databaseVersion:V,accounts:[],categories:CATS.map(n=>({id:uid(),name:n,active:true,createdAt:nowTs(),updatedAt:nowTs()})),transactions:[],budgets:[],goals:[],salarySettings:{paydayDay:10,cycleMode:'PAYDAY_TO_DAY_BEFORE_PAYDAY',active:true},salaryComponents:[],settings:{}});
// ---- migrasi bertahap ----
function migrate(o){if(!o||typeof o!='object'||Array.isArray(o))throw Error('format');const v=o.databaseVersion||1;if(!Number.isInteger(v)||v>V)throw Error('versi');
 const d=JSON.parse(JSON.stringify(o));
 if(v<2){['accounts','categories','transactions','budgets','goals','salaryComponents'].forEach(k=>d[k]=d[k]||[]);
  d.salarySettings=d.salarySettings||{paydayDay:10,cycleMode:'PAYDAY_TO_DAY_BEFORE_PAYDAY',active:true};d.settings=d.settings||{};
  ['accounts','categories','goals','salaryComponents','budgets'].forEach(k=>d[k].forEach(x=>{if(x.active===undefined)x.active=true}));
  d.transactions.forEach(t=>{if(!t.createdAt)t.createdAt=(t.date||'1970-01-01')+'T00:00:00';if(t.customName===undefined)t.customName='';if(t.salaryComponentId===undefined)t.salaryComponentId=null})}
 d.databaseVersion=V;return d}
function validate(d){['accounts','categories','transactions','budgets','goals','salaryComponents'].forEach(k=>{if(!Array.isArray(d[k]))throw Error('Struktur data tidak valid: '+k)});
 const ps=d.salarySettings;if(!ps||!(ps.paydayDay>=1&&ps.paydayDay<=28))throw Error('Tanggal gajian tidak valid.');
 const ids=k=>new Set(d[k].map(x=>x.id)),A=ids('accounts'),C=ids('categories'),G=ids('goals'),S=ids('salaryComponents');
 d.accounts.forEach(a=>{if(!Number.isInteger(a.openingBalance))throw Error('Saldo awal tidak valid.')});
 d.transactions.forEach(t=>{if(!TY[t.type]||!Number.isInteger(t.amount)||t.amount<=0||!/^\d{4}-\d\d-\d\d$/.test(t.date))throw Error('Transaksi tidak valid.');
  const need={income:[[A,'accountId']],expense:[[A,'accountId'],[C,'categoryId']],transfer:[[A,'fromAccountId'],[A,'toAccountId']],goal:[[A,'accountId'],[G,'goalId']]}[t.type];
  need.forEach(([s,k])=>{if(!s.has(t[k]))throw Error('Relasi transaksi tidak valid.')});
  if(t.salaryComponentId&&!S.has(t.salaryComponentId))throw Error('Relasi komponen gaji tidak valid.')});
 d.budgets.forEach(b=>{if(!C.has(b.categoryId))throw Error('Relasi budget tidak valid.')})}
// ---- penyimpanan (satu database ter-versioning) ----
function persist(d){const s=JSON.stringify(d);if(B){if(!B.saveDb(s))throw Error('Terjadi kesalahan saat menyimpan data. Data sebelumnya tetap dipertahankan.')}else localStorage.setItem('dompetku_database',s)}
function init(){let r='';try{r=B?B.loadDb():(localStorage.getItem('dompetku_database')||'')}catch(e){}
 if(!r){db=fresh();try{persist(db)}catch(e){}return}
 try{const o=JSON.parse(r);db=migrate(o);validate(db);if(o.databaseVersion!==V)persist(db)}catch(e){broken=true;db=fresh()}}
function mutate(fn){if(broken){toast('Database tidak terbaca. Perubahan dinonaktifkan agar data lama aman.');return false}
 try{const s=JSON.parse(JSON.stringify(db));fn(s);validate(s);persist(s);db=s;closeSheet();renderAll();return true}
 catch(e){toast(e.message||'Terjadi kesalahan saat menyimpan data. Data sebelumnya tetap dipertahankan.');return false}}
// ---- kalkulasi (selalu dihitung ulang dari transaksi) ----
const inR=(t,r)=>t.date>=r.start&&t.date<=r.end;
const num=v=>{const n=Number(v);return v!==''&&Number.isInteger(n)?n:NaN};
function calculateAllAccountBalances(d=db){const b={};d.accounts.forEach(a=>b[a.id]=a.openingBalance);
 d.transactions.forEach(t=>{const x=t.amount;if(t.type=='income')b[t.accountId]+=x;else if(t.type=='expense'||t.type=='goal')b[t.accountId]-=x;else{b[t.fromAccountId]-=x;b[t.toAccountId]+=x}});return b}
const calculateAccountBalance=(id,d=db)=>calculateAllAccountBalances(d)[id];
const calculateGoalSaved=(id,d=db)=>{const g=d.goals.find(x=>x.id==id);return g.initialSaved+d.transactions.filter(t=>t.type=='goal'&&t.goalId==id).reduce((s,t)=>s+t.amount,0)};
const sumT=f=>db.transactions.filter(f).reduce((s,t)=>s+t.amount,0);
const calculateSalaryCycle=(ref=today())=>calculateSpendingCycle(ref,db.salarySettings.paydayDay);
const calculateSalaryIncome=r=>sumT(t=>t.type=='income'&&inR(t,r));
const calculateSalaryExpenses=r=>sumT(t=>t.type=='expense'&&inR(t,r));
const calculateGoalAlloc=r=>sumT(t=>t.type=='goal'&&inR(t,r));
const calculateSalaryRemaining=r=>calculateSalaryIncome(r)-calculateSalaryExpenses(r)-calculateGoalAlloc(r);
const calculateSalaryComponentUsage=(id,r)=>{const rc=sumT(t=>t.type=='income'&&t.salaryComponentId==id&&inR(t,r)),us=sumT(t=>t.type=='expense'&&t.salaryComponentId==id&&inR(t,r));return{rc,us,left:rc-us}};
function nextPay(){const c=calculateSalaryCycle(),nom=add(c.end,1),[y,m]=P(nom);return{nom,act:calculateActualPayDate(y,m-1,db.salarySettings.paydayDay)}}
function periodOf(k,t=today()){const[y,m]=P(t);if(k=='cycle')return calculateSalaryCycle(t);if(k=='month')return{start:D(y,m-1,1),end:D(y,m,0)};if(k=='year')return{start:D(y,0,1),end:D(y,12,0)};
 if(k=='week'){const o=(new Date(t).getUTCDay()+6)%7;return{start:add(t,-o),end:add(t,6-o)}}return{start:t,end:t}}
const budPeriod=b=>periodOf({salaryCycle:'cycle',monthly:'month',weekly:'week',yearly:'year'}[b.periodType]||'month');
const calculateBudgetUsage=b=>{const r=budPeriod(b);return sumT(t=>t.type=='expense'&&t.categoryId==b.categoryId&&inR(t,r))};
// ---- util UI ----
const nm=(l,id)=>(l.find(x=>x.id==id)||{}).name||'(dihapus)';
const fd=s=>new Date(s+'T00:00:00Z').toLocaleDateString('id-ID',{timeZone:'UTC',day:'numeric',month:'long',year:'numeric'});
const dayLbl=s=>s==today()?'Hari ini':s==add(today(),-1)?'Kemarin':fd(s);
const txName=t=>t.customName||(t.type=='transfer'?'Transfer '+nm(db.accounts,t.fromAccountId)+' → '+nm(db.accounts,t.toAccountId):t.type=='goal'?'Dana: '+nm(db.goals,t.goalId):t.type=='expense'?nm(db.categories,t.categoryId):t.salaryComponentId?nm(db.salaryComponents,t.salaryComponentId):'Pemasukan');
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),3500)}
const closeSheet=()=>$('#sheet').classList.remove('on');
const ask=(m,ok='Ya')=>new Promise(r=>{const d=$('#dlg');d.innerHTML='<div class=box><p>'+esc(m)+'</p><div class=row><button class=btn2 id=dn>Batal</button><button class=btn id=dy>'+esc(ok)+'</button></div></div>';d.classList.add('on');const c=v=>{d.classList.remove('on');r(v)};$('#dn').onclick=()=>c(false);$('#dy').onclick=()=>c(true)});
const upsert=(s,k,o)=>{const x=s[k].find(y=>y.id==o.id),n=nowTs();if(x)Object.assign(x,o,{updatedAt:n});else s[k].push(Object.assign({createdAt:n,updatedAt:n,active:true},o))};
const dup=(l,n,id)=>l.some(x=>x.id!=id&&x.name.toLowerCase()==n.toLowerCase());
function fh(f){const id='f_'+f.k,v=f.v==null?'':f.v;let i;
 if(f.t=='select')i='<select id='+id+(f.c?' onchange="'+f.c+'"':'')+'>'+f.o.map(([a,b])=>'<option value="'+esc(a)+'"'+(a==v?' selected':'')+'>'+esc(b)+'</option>').join('')+'</select>';
 else if(f.t=='area')i='<textarea id='+id+'>'+esc(v)+'</textarea>';
 else i='<input id='+id+' type='+(f.t||'text')+' value="'+esc(v)+'"'+(f.t=='number'?' inputmode=numeric':'')+'>';
 return '<label>'+esc(f.l)+i+'</label>'}
function openForm(title,fields,save,del){cb={save:()=>{const o={};document.querySelectorAll('#sheet [id^=f_]').forEach(e=>o[e.id.slice(2)]=e.value.trim());save(o)},del};
 $('#sheet').innerHTML='<div class=box><h3>'+esc(title)+'</h3>'+fields.map(fh).join('')+'<div class=row><button class=btn2 onclick=closeSheet()>Batal</button>'+(del?'<button class="btn2 red" onclick=cb.del()>Hapus</button>':'')+'<button class=btn onclick=cb.save()>Simpan</button></div></div>';$('#sheet').classList.add('on')}
const cur=()=>{const o={};document.querySelectorAll('#sheet [id^=f_]').forEach(e=>o[e.id.slice(2)]=e.value);return o};
// ---- form transaksi ----
const openTx=t=>{editing=t&&t.id||null;txForm(t||{})};
function txForm(t){if(!db.accounts.length)return toast('Belum ada akun. Tambahkan dulu di menu Akun.');
 const ty=t.type||'expense',acc=db.accounts.filter(a=>a.active||a.id==t.accountId).map(a=>[a.id,a.name]),la=db.settings.lastAccountId;
 const cat=db.categories.filter(c=>c.active||c.id==t.categoryId).map(c=>[c.id,c.name]);
 const SC={k:'salaryComponentId',l:'Komponen gaji (opsional)',t:'select',v:t.salaryComponentId,o:[['','— Tidak ada —']].concat(db.salaryComponents.filter(c=>c.active||c.id==t.salaryComponentId).map(c=>[c.id,c.name]))};
 const A=(k,l)=>({k,l,t:'select',o:acc,v:t[k]||(db.accounts.some(a=>a.id==la)?la:'')});
 const F=[{k:'type',l:'Jenis',t:'select',o:Object.entries(TY),v:ty,c:'txForm(Object.assign(cur(),{type:this.value}))'}];
 if(ty=='expense')F.push({k:'categoryId',l:'Kategori',t:'select',o:cat,v:t.categoryId},A('accountId','Akun'),SC);
 else if(ty=='income')F.push(A('accountId','Akun tujuan'),SC);
 else if(ty=='transfer')F.push(A('fromAccountId','Dari akun'),{k:'toAccountId',l:'Ke akun',t:'select',o:acc,v:t.toAccountId});
 else F.push({k:'goalId',l:'Target',t:'select',o:db.goals.filter(g=>g.active).map(g=>[g.id,g.name]),v:t.goalId},A('accountId','Dari akun'));
 F.push({k:'amount',l:'Nominal (Rp)',t:'number',v:t.amount},{k:'date',l:'Tanggal',t:'date',v:t.date||today()},{k:'customName',l:'Nama transaksi (opsional)',v:t.customName},{k:'note',l:'Catatan (opsional)',v:t.note});
 openForm(editing?'Edit Transaksi':'Transaksi Baru',F,saveTx,editing?delTx:null)}
async function saveTx(o){const ty=o.type,amt=num(o.amount);
 if(!(amt>0))return toast('Nominal harus berupa bilangan bulat lebih dari 0.');
 if(!/^\d{4}-\d\d-\d\d$/.test(o.date)||isNaN(Date.parse(o.date)))return toast('Tanggal tidak valid.');
 const t={id:editing||uid(),type:ty,amount:amt,date:o.date,note:o.note,customName:o.customName};
 if(ty=='expense'){t.categoryId=o.categoryId;t.accountId=o.accountId;t.salaryComponentId=o.salaryComponentId||null}
 else if(ty=='income'){t.accountId=o.accountId;t.salaryComponentId=o.salaryComponentId||null}
 else if(ty=='transfer'){t.fromAccountId=o.fromAccountId;t.toAccountId=o.toAccountId;if(t.fromAccountId==t.toAccountId)return toast('Akun asal dan tujuan harus berbeda.')}
 else{t.goalId=o.goalId;t.accountId=o.accountId;if(!t.goalId)return toast('Pilih target terlebih dahulu.')}
 const rest=Object.assign({},db,{transactions:db.transactions.filter(x=>x.id!=editing)}),bal=calculateAllAccountBalances(rest),src=t.fromAccountId||t.accountId;
 if((ty=='transfer'||ty=='goal')&&bal[src]<amt)return toast('Saldo akun tidak cukup.');
 if(ty=='goal'){const g=db.goals.find(x=>x.id==t.goalId);if(amt>g.targetAmount-calculateGoalSaved(g.id,rest))return toast('Nominal melebihi sisa target.')}
 if(ty=='expense'&&bal[src]<amt&&!await ask('Saldo akun tidak cukup. Tetap catat?','Tetap catat'))return;
 mutate(s=>{if(editing){const x=s.transactions.find(y=>y.id==editing);if(!x)throw Error('Transaksi tidak ditemukan.');const ca=x.createdAt;Object.keys(x).forEach(k=>delete x[k]);Object.assign(x,t,{createdAt:ca,updatedAt:nowTs()})}
  else s.transactions.push(Object.assign(t,{createdAt:nowTs(),updatedAt:nowTs()}));s.settings.lastAccountId=src})}
async function delTx(){if(await ask('Hapus transaksi ini?','Hapus'))mutate(s=>{s.transactions=s.transactions.filter(x=>x.id!=editing)})}
// ---- form entitas ----
function accForm(id){const a=db.accounts.find(x=>x.id==id)||{},used=id&&db.transactions.some(t=>[t.accountId,t.fromAccountId,t.toAccountId].includes(id));
 openForm(id?'Edit Akun':'Tambah Akun',[{k:'name',l:'Nama akun',v:a.name},{k:'openingBalance',l:'Saldo awal',t:'number',v:a.openingBalance==null?0:a.openingBalance},{k:'note',l:'Catatan',v:a.note},{k:'active',l:'Status',t:'select',v:a.active===false?'0':'1',o:[['1','Aktif'],['0','Nonaktif']]}],
 o=>{const b=num(o.openingBalance);if(!o.name)return toast('Nama wajib diisi.');if(dup(db.accounts,o.name,id))return toast('Nama akun sudah ada.');if(!(b>=0))return toast('Saldo awal harus bilangan bulat ≥ 0.');
  mutate(s=>upsert(s,'accounts',{id:id||uid(),name:o.name,openingBalance:b,note:o.note,active:o.active=='1'}))},
 id&&!used?async()=>{if(await ask('Hapus akun ini?','Hapus'))mutate(s=>{s.accounts=s.accounts.filter(x=>x.id!=id)})}:null)}
function catForm(id){const c=db.categories.find(x=>x.id==id)||{};
 openForm(id?'Edit Kategori':'Tambah Kategori',[{k:'name',l:'Nama kategori',v:c.name},{k:'active',l:'Status (nonaktif = histori tetap aman)',t:'select',v:c.active===false?'0':'1',o:[['1','Aktif'],['0','Nonaktif']]}],
 o=>{if(!o.name)return toast('Nama wajib diisi.');if(dup(db.categories,o.name,id))return toast('Kategori sudah ada.');mutate(s=>upsert(s,'categories',{id:id||uid(),name:o.name,active:o.active=='1'}))})}
function budForm(id){const b=db.budgets.find(x=>x.id==id)||{};
 openForm(id?'Edit Budget':'Tambah Budget',[{k:'categoryId',l:'Kategori',t:'select',v:b.categoryId,o:db.categories.filter(c=>c.active||c.id==b.categoryId).map(c=>[c.id,c.name])},{k:'amount',l:'Batas (Rp)',t:'number',v:b.amount},
  {k:'periodType',l:'Periode',t:'select',v:b.periodType||'salaryCycle',o:[['salaryCycle','Siklus gaji (tgl gajian → sehari sebelumnya)'],['monthly','Bulanan (tgl 1 – akhir bulan)'],['weekly','Mingguan (Senin – Minggu)'],['yearly','Tahunan']]},{k:'active',l:'Status',t:'select',v:b.active===false?'0':'1',o:[['1','Aktif'],['0','Nonaktif']]}],
 o=>{const a=num(o.amount);if(!(a>0))return toast('Batas harus lebih dari 0.');mutate(s=>upsert(s,'budgets',{id:id||uid(),categoryId:o.categoryId,amount:a,periodType:o.periodType,startDate:null,endDate:null,salaryCycleBased:o.periodType=='salaryCycle',active:o.active=='1'}))},
 id?async()=>{if(await ask('Hapus budget ini? (transaksi tidak terpengaruh)','Hapus'))mutate(s=>{s.budgets=s.budgets.filter(x=>x.id!=id)})}:null)}
function goalForm(id){const g=db.goals.find(x=>x.id==id)||{},hasTx=id&&db.transactions.some(t=>t.goalId==id);
 openForm(id?'Edit Target':'Tambah Target',[{k:'tpl',l:'Template nama (opsional)',t:'select',v:'',c:"document.getElementById('f_name').value=this.value||document.getElementById('f_name').value",o:[['','— Pilih —']].concat(TPL.map(x=>[x,x]))},
  {k:'name',l:'Nama target',v:g.name},{k:'targetAmount',l:'Jumlah target (Rp)',t:'number',v:g.targetAmount},{k:'initialSaved',l:'Dana awal sudah terkumpul (di luar akun aplikasi)',t:'number',v:g.initialSaved==null?0:g.initialSaved},
  {k:'storageType',l:'Penyimpanan',t:'select',v:g.storageType||'Bank',o:['Cash','Bank','E-Wallet','Lainnya'].map(x=>[x,x])},{k:'storageName',l:'Nama penyimpanan',v:g.storageName},
  {k:'startDate',l:'Mulai',t:'date',v:g.startDate||today()},{k:'endDate',l:'Deadline (opsional)',t:'date',v:g.endDate},{k:'note',l:'Catatan',v:g.note}],
 o=>{const T=num(o.targetAmount),I=num(o.initialSaved);if(!o.name)return toast('Nama wajib diisi.');if(dup(db.goals,o.name,id))return toast('Nama target sudah ada.');if(!(T>0))return toast('Target harus lebih dari 0.');
  if(!(I>=0&&I<=T))return toast('Dana awal harus antara 0 dan target.');if(!o.startDate)return toast('Tanggal mulai wajib.');if(o.endDate&&o.endDate<o.startDate)return toast('Deadline tidak boleh sebelum tanggal mulai.');
  mutate(s=>upsert(s,'goals',{id:id||uid(),name:o.name,targetAmount:T,initialSaved:I,storageType:o.storageType,storageName:o.storageName,startDate:o.startDate,endDate:o.endDate||null,note:o.note,active:true}))},
 id?async()=>{if(await ask(hasTx?'Target ini punya riwayat dana. Nonaktifkan (riwayat tetap aman)?':'Hapus target ini?','Lanjut'))mutate(s=>{if(hasTx)s.goals.find(x=>x.id==id).active=false;else s.goals=s.goals.filter(x=>x.id!=id)})}:null)}
function compForm(id){const c=db.salaryComponents.find(x=>x.id==id)||{},used=id&&db.transactions.some(t=>t.salaryComponentId==id);
 openForm(id?'Edit Komponen Gaji':'Tambah Komponen Gaji',[{k:'name',l:'Nama komponen',v:c.name},{k:'defaultAmount',l:'Nominal default (Rp, hanya saran isian)',t:'number',v:c.defaultAmount==null?0:c.defaultAmount},
  {k:'type',l:'Jenis',t:'select',v:c.type||'fixed',o:[['fixed','Tetap'],['variable','Variabel']]},{k:'schedule',l:'Jadwal (mis. bulanan)',v:c.schedule},
  {k:'defaultAccountId',l:'Akun tujuan default',t:'select',v:c.defaultAccountId,o:[['','— Tidak ada —']].concat(db.accounts.map(a=>[a.id,a.name]))},{k:'note',l:'Catatan',v:c.note},{k:'active',l:'Status',t:'select',v:c.active===false?'0':'1',o:[['1','Aktif'],['0','Nonaktif']]}],
 o=>{const n=num(o.defaultAmount);if(!o.name)return toast('Nama wajib diisi.');if(dup(db.salaryComponents,o.name,id))return toast('Komponen sudah ada.');if(!(n>=0))return toast('Nominal tidak valid.');
  mutate(s=>upsert(s,'salaryComponents',{id:id||uid(),name:o.name,defaultAmount:n,type:o.type,schedule:o.schedule,defaultAccountId:o.defaultAccountId||null,note:o.note,active:o.active=='1'}))},
 id&&!used?async()=>{if(await ask('Hapus komponen ini?','Hapus'))mutate(s=>{s.salaryComponents=s.salaryComponents.filter(x=>x.id!=id)})}:null)}
function payForm(){openForm('Tanggal Gajian',[{k:'d',l:'Tanggal gajian nominal (1–28)',t:'number',v:db.salarySettings.paydayDay}],o=>{const d=num(o.d);if(!(d>=1&&d<=28))return toast('Isi tanggal 1 sampai 28.');mutate(s=>{s.salarySettings.paydayDay=d})})}
// ---- tampilan ----
function paycard(){const c=calculateSalaryCycle(),n=nextPay(),wk=n.nom!=n.act;
 return '<div class=li><span class=m>Gajian berikutnya (nominal)</span><b>'+fd(n.nom)+'</b></div>'+'<div class=li><span class=m>Perkiraan masuk</span><b>'+fd(n.act)+'</b></div>'+(wk?'<div class=m>Tanggal gajian jatuh di akhir pekan, uang diperkirakan masuk lebih awal. Siklus penggunaan tetap '+fd(c.start)+' – '+fd(c.end)+'.</div>':'')}
function pie(r){const m={};db.transactions.filter(t=>t.type=='expense'&&inR(t,r)).forEach(t=>m[t.categoryId]=(m[t.categoryId]||0)+t.amount);
 const a=Object.entries(m).sort((x,y)=>y[1]-x[1]).slice(0,8),tot=a.reduce((s,x)=>s+x[1],0);if(!tot)return'<p class=m>Belum ada data bulan ini.</p>';
 const C=['#087f5b','#4385f5','#e99a2e','#8b5cf6','#d8ae2c','#d94343','#10a970','#74817c'];let p=0;const g=a.map((x,i)=>{const s=p;p+=x[1]/tot*100;return C[i]+' '+s+'% '+p+'%'}).join(',');
 return '<div class=pie style="background:conic-gradient('+g+')"></div>'+a.map((x,i)=>'<div class=li><span><i style="background:'+C[i]+'"></i>'+esc(nm(db.categories,x[0]))+'</span><b>'+rp(x[1])+'</b></div>').join('')}
function budRow(b){const u=calculateBudgetUsage(b),pc=Math.round(u/b.amount*100),st=pc>100?['Melebihi budget','red']:pc>=90?['Hampir habis','or']:pc>=70?['Mendekati batas','or']:['Aman',''],n=esc(nm(db.categories,b.categoryId));
 return '<div class=card onclick="budForm(\''+b.id+'\')"><div class=li><b>'+n+'</b><span class="tag '+st[1]+'">'+st[0]+'</span></div><div class=bar><div style="width:'+Math.min(pc,100)+'%"></div></div><div class=li><span class=m>'+rp(u)+' / '+rp(b.amount)+' ('+pc+'%)</span><span class=m>'+(pc>100?'Melebihi '+n+' '+rp(u-b.amount):'Sisa '+rp(b.amount-u))+'</span></div></div>'}
function goalRow(g,full){const sv=calculateGoalSaved(g.id),pc=Math.min(100,Math.round(sv/g.targetAmount*100)),done=sv>=g.targetAmount,late=!done&&g.endDate&&g.endDate<today(),st=done?'Tercapai ✓':late?'Waktu lewat':'Aktif';
 let h='<div class=card><div class=li><b>'+esc(g.name)+'</b><span class="tag '+(late?'red':'')+'">'+st+'</span></div><div class=bar><div style="width:'+pc+'%"></div></div><div class=li><span class=m>'+rp(sv)+' / '+rp(g.targetAmount)+'</span><span class=m>Sisa '+rp(Math.max(0,g.targetAmount-sv))+'</span></div>';
 if(full){h+='<div class=m>'+esc(g.storageType)+(g.storageName?' – '+esc(g.storageName):'')+(g.endDate?' · Deadline '+fd(g.endDate):'')+'</div>';
  if(g.endDate&&!done&&!late)h+='<div class=m>Butuh '+rp((g.targetAmount-sv)/Math.max(1,Math.ceil(diff(today(),g.endDate)/30)))+' per bulan ('+diff(today(),g.endDate)+' hari lagi)</div>';
  h+='<div class=row><button class="btn sm" onclick="openTx({type:\'goal\',goalId:\''+g.id+'\'})">Tambah Dana</button><button class="btn2 sm" onclick="goalForm(\''+g.id+'\')">Edit</button></div>'}
 return h+'</div>'}
function txRow(t){const s=t.type=='income'?'+':t.type=='expense'||t.type=='goal'?'−':'',c=t.type=='income'?'in':t.type=='expense'?'ex':'';
 const acc=t.type=='transfer'?'':nm(db.accounts,t.accountId);
 return '<div class=li onclick="openTx(db.transactions.find(x=>x.id==\''+t.id+'\'))"><span><b>'+esc(txName(t))+'</b><br><span class=m>'+esc((t.createdAt||'').slice(11,16))+' · '+TY[t.type]+(acc?' · '+esc(acc):'')+(t.note?' · '+esc(t.note):'')+'</span></span><b class="'+c+'">'+s+rp(t.amount)+'</b></div>'}
const views={
home(){const c=calculateSalaryCycle(),inc=calculateSalaryIncome(c),ex=calculateSalaryExpenses(c),left=calculateSalaryRemaining(c),d=calculateRemainingDays(today(),c.end);
 const tb=Object.values(calculateAllAccountBalances()).reduce((a,b)=>a+b,0),rec=[...db.transactions].sort((a,b)=>b.createdAt<a.createdAt?-1:1).slice(0,5);
 const bs=db.budgets.filter(b=>b.active).map(b=>[b,calculateBudgetUsage(b)/b.amount]).sort((a,b)=>b[1]-a[1]).slice(0,3),gs=db.goals.filter(g=>g.active);
 return '<div class=hd><small>Total saldo</small><h1>'+rp(tb)+'</h1><small>Siklus '+fd(c.start)+' – '+fd(c.end)+'</small></div>'+
 '<div class=g2><div class=card><span class=m>Pemasukan siklus</span><h3 class=in>'+rp(inc)+'</h3></div><div class=card><span class=m>Pengeluaran siklus</span><h3 class=ex>'+rp(ex)+'</h3></div><div class=card><span class=m>Sisa dana siklus</span><h3>'+rp(left)+'</h3></div><div class=card><span class=m>Batas aman harian · '+d+' hari</span><h3>'+(d>0?rp(Math.max(0,left)/d):'—')+'</h3></div></div>'+
 '<div class=card><h3>Komposisi pengeluaran</h3>'+pie(c)+'</div><div class=card><h3>Gaji</h3>'+paycard()+'</div>'+
 '<h2>Transaksi terbaru</h2><div class=card>'+(rec.length?rec.map(txRow).join(''):'<p class=m>Belum ada transaksi.</p>')+'<button class="btn2 sm" onclick="go(\'tx\')">Lihat semua</button></div>'+
 '<h2>Budget</h2>'+(bs.length?bs.map(x=>budRow(x[0])).join(''):'<p class=m>Belum ada target pengeluaran.</p>')+
 '<h2>Target</h2>'+(gs.length?'<div class=card><div class=li><span>Target aktif</span><b>'+gs.length+'</b></div><div class=li><span>Total dana target</span><b>'+rp(gs.reduce((s,g)=>s+calculateGoalSaved(g.id),0))+'</b></div></div>':'<p class=m>Belum ada target dana.</p>')},
tx(){const rg={all:null,today:periodOf('d'),week:periodOf('week'),month:periodOf('month'),cycle:periodOf('cycle'),custom:{start:flt.from||'0000-01-01',end:flt.to||'9999-12-31'}}[flt.per];
 let l=db.transactions.filter(t=>(flt.type=='all'||t.type==flt.type)&&(!rg||inR(t,flt.per=='today'?{start:today(),end:today()}:rg))&&(flt.acc=='all'||[t.accountId,t.fromAccountId,t.toAccountId].includes(flt.acc)));
 l.sort((a,b)=>a.createdAt<b.createdAt?1:a.createdAt>b.createdAt?-1:0);
 const S=(k,o)=>'<select onchange="flt.'+k+'=this.value;renderAll()">'+o.map(([a,b])=>'<option value="'+esc(a)+'"'+(flt[k]==a?' selected':'')+'>'+esc(b)+'</option>').join('')+'</select>';
 let h='<div class=hd><small>Riwayat</small><h1>Transaksi</h1></div><div class=fl>'+S('type',[['all','Semua jenis']].concat(Object.entries(TY)))+S('per',[['all','Semua waktu'],['today','Hari ini'],['week','Minggu ini'],['month','Bulan ini'],['cycle','Siklus gaji'],['custom','Pilih tanggal']])+S('acc',[['all','Semua akun']].concat(db.accounts.map(a=>[a.id,a.name])))+'</div>';
 if(flt.per=='custom')h+='<div class=fl><input type=date value="'+flt.from+'" onchange="flt.from=this.value;renderAll()"><input type=date value="'+flt.to+'" onchange="flt.to=this.value;renderAll()"></div>';
 if(!l.length)return h+'<p class=m>'+(db.transactions.length?'Belum ada data pada periode ini.':'Belum ada transaksi.')+'</p>';
 let p='';return h+'<div class=card>'+l.map(t=>{let x='';if(t.date!=p){p=t.date;x='<div class=dh>'+dayLbl(p)+'</div>'}return x+txRow(t)}).join('')+'</div>'},
bud(){const l=db.budgets.filter(b=>b.active);return '<div class=hd><small>Rencana batas</small><h1>Budget</h1></div><button class="btn sm" onclick="budForm()">+ Tambah budget</button><br><br>'+(l.length?l.map(budRow).join(''):'<p class=m>Belum ada target pengeluaran.</p>')},
goal(){const l=db.goals.filter(g=>g.active);return '<div class=hd><small>Dana yang dikumpulkan</small><h1>Target</h1></div><button class="btn sm" onclick="goalForm()">+ Tambah target</button><br><br>'+(l.length?l.map(g=>goalRow(g,1)).join(''):'<p class=m>Belum ada target dana.</p>')},
sal(){const c=calculateSalaryCycle(),d=calculateRemainingDays(today(),c.end),left=calculateSalaryRemaining(c),hist=db.transactions.filter(t=>t.type=='income'&&t.salaryComponentId).sort((a,b)=>a.date<b.date?1:-1).slice(0,15);
 return '<div class=hd><small>Siklus gaji</small><h1>'+fd(c.start).replace(/ \d{4}$/,'')+' – '+fd(c.end)+'</h1></div><div class=card><div class=li><span class=m>Total penghasilan</span><b>'+rp(calculateSalaryIncome(c))+'</b></div><div class=li><span class=m>Pengeluaran siklus</span><b>'+rp(calculateSalaryExpenses(c))+'</b></div><div class=li><span class=m>Sisa dana</span><b>'+rp(left)+'</b></div><div class=li><span class=m>Hari tersisa</span><b>'+d+' hari</b></div><div class=li><span class=m>Batas aman harian</span><b>'+(d>0?rp(Math.max(0,left)/d):'—')+'</b></div>'+paycard()+'<div class=row><button class="btn2 sm" onclick=payForm()>Ubah tanggal gajian ('+db.salarySettings.paydayDay+')</button></div></div>'+
 '<h2>Komponen gaji</h2><button class="btn sm" onclick="compForm()">+ Tambah komponen</button><br><br>'+(db.salaryComponents.length?db.salaryComponents.map(k=>{const u=calculateSalaryComponentUsage(k.id,c);return '<div class=card onclick="compForm(\''+k.id+'\')"><div class=li><b>'+esc(k.name)+'</b><span class=m>'+(k.active?'':'Nonaktif · ')+(k.type=='fixed'?'Tetap':'Variabel')+'</span></div><div class=m>Default '+rp(k.defaultAmount)+(k.defaultAccountId?' → '+esc(nm(db.accounts,k.defaultAccountId)):'')+'</div><div class=m>Analisis penggunaan komponen (siklus ini, bukan saldo rekening): diterima '+rp(u.rc)+' · dipakai '+rp(u.us)+' · sisa analitis '+rp(u.left)+'</div></div>'}).join(''):'<p class=m>Belum ada komponen gaji.</p>')+
 '<h2>Riwayat penerimaan</h2>'+(hist.length?'<div class=card>'+hist.map(txRow).join('')+'</div>':'<p class=m>Belum ada data pada periode ini.</p>')},
acc(){const b=calculateAllAccountBalances();return '<div class=hd><small>Tempat uang berada</small><h1>Akun</h1></div><button class="btn sm" onclick="accForm()">+ Tambah akun</button><br><br>'+
 (db.accounts.length?db.accounts.map(a=>'<div class=card onclick="accForm(\''+a.id+'\')"><div class=li><b>'+esc(a.name)+(a.active?'':' (nonaktif)')+'</b><b class="'+(b[a.id]<0?'ex':'')+'">'+rp(b[a.id])+'</b></div>'+(a.note?'<div class=m>'+esc(a.note)+'</div>':'')+'</div>').join(''):'<p class=m>Belum ada akun.<br>Tambahkan BCA, Cash, E-Wallet, atau sumber dana lainnya.</p>')+
 '<h2>Kategori</h2><button class="btn sm" onclick="catForm()">+ Tambah kategori</button><br><br><div class=card>'+db.categories.map(c=>'<div class=li onclick="catForm(\''+c.id+'\')"><span>'+esc(c.name)+'</span><span class=m>'+(c.active?'':'nonaktif')+'</span></div>').join('')+'</div>'+
 '<h2>Data</h2><div class=card><p class=m>Backup disimpan ke lokasi pilihan Anda (mis. Documents/DompetKu) sehingga tetap ada setelah aplikasi dihapus.</p><div class=row><button class=btn onclick=doBackup()>Backup</button><button class=btn2 onclick=doRestore()>Restore</button></div><p class=m>Versi database '+db.databaseVersion+'</p></div>'}};
const NAV=[['home','🏠','Beranda'],['tx','🧾','Transaksi'],['bud','📊','Budget'],['goal','🎯','Target'],['sal','💼','Gaji'],['acc','🏦','Akun']];
function go(t){tab=t;renderAll();scrollTo(0,0)}
function renderAll(){$('#main').innerHTML=views[tab]();$('#nav').innerHTML=NAV.map(n=>'<button class="'+(n[0]==tab?'on':'')+'" onclick="go(\''+n[0]+'\')">'+n[1]+'<br>'+n[2]+'</button>').join('');$('#fab').style.display=tab=='home'||tab=='tx'?'block':'none'}
// ---- backup / restore ----
function doBackup(){if(!B)return toast('Backup hanya tersedia di aplikasi Android.');B.backup('DompetKu-backup-'+today()+'.json',JSON.stringify(db,null,1))}
function doRestore(){if(!B)return toast('Restore hanya tersedia di aplikasi Android.');B.restore()}
async function onRestore(text){let nd;try{nd=migrate(JSON.parse(text));validate(nd)}catch(e){return toast('File backup tidak valid atau berasal dari versi yang tidak didukung.')}
 if(!await ask('Data saat ini akan diganti dengan isi backup ('+nd.transactions.length+' transaksi, '+nd.accounts.length+' akun). Lanjutkan?','Restore'))return;
 try{persist(nd);db=nd;broken=false;renderAll();toast('Restore berhasil')}catch(e){toast('Terjadi kesalahan saat menyimpan data. Data sebelumnya tetap dipertahankan.')}}
init();renderAll();if(broken)toast('Database tidak terbaca. Data lama tidak diubah; perubahan dinonaktifkan. Restore dari backup untuk melanjutkan.');
