package id.dompetku

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private var pending = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                !r.url.toString().startsWith("file:///android_asset/")
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        setContentView(wv)
        wv.loadUrl("file:///android_asset/www/index.html")
    }

    private fun js(s: String) = runOnUiThread { wv.evaluateJavascript(s, null) }

    inner class Bridge {
        private val db get() = File(filesDir, "db.json")

        @JavascriptInterface
        fun loadDb(): String = if (db.exists()) db.readText(Charsets.UTF_8) else ""

        // Atomic write: tmp file -> keep .bak of previous -> rename
        @JavascriptInterface
        fun saveDb(json: String): Boolean = try {
            val tmp = File(filesDir, "db.tmp")
            tmp.writeText(json, Charsets.UTF_8)
            if (db.exists()) db.copyTo(File(filesDir, "db.bak"), true)
            tmp.renameTo(db)
        } catch (e: Exception) { false }

        @JavascriptInterface
        fun backup(name: String, json: String) {
            pending = json
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, name)
                startActivityForResult(i, 1)
            }
        }

        @JavascriptInterface
        fun restore() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json")
                startActivityForResult(i, 2)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (resultCode != RESULT_OK || u == null) return
        try {
            if (requestCode == 1) {
                contentResolver.openOutputStream(u, "wt")!!.use { it.write(pending.toByteArray(Charsets.UTF_8)) }
                pending = ""
                js("toast('Backup tersimpan')")
            } else if (requestCode == 2) {
                val t = contentResolver.openInputStream(u)!!.use { String(it.readBytes(), Charsets.UTF_8) }
                js("onRestore(" + JSONObject.quote(t) + ")")
            }
        } catch (e: Exception) {
            js("toast('Operasi file gagal. Data tetap aman.')")
        }
    }
}
