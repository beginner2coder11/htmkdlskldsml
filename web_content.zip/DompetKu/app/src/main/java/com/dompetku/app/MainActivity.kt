package com.dompetku.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = true; allowContentAccess = false
            setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveBackup(json: String, name: String) {
            pending = json
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, name)
                }, 1)
            }
        }
        @JavascriptInterface fun openRestore() {
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream"))
                }, 2)
            }
        }
    }

    private fun js(s: String) = web.post { web.evaluateJavascript(s, null) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) { if (req == 1) js("onBackupDone(false)"); return }
        try {
            if (req == 1) {
                contentResolver.openOutputStream(uri, "wt")!!.use { it.write((pending ?: "").toByteArray(Charsets.UTF_8)) }
                pending = null; js("onBackupDone(true)")
            } else {
                val t = contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
                js("onRestoreData(" + JSONObject.quote(t) + ")")
            }
        } catch (e: Exception) {
            if (req == 1) js("onBackupDone(false)") else js("onRestoreData(null)")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack&&onBack())===true") {
            if (it != "true") { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
        }
    }
}
