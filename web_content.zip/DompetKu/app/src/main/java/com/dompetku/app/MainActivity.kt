package com.dompetku.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: String? = null
    private var sat = 0f
    private var sab = 0f

    private fun pushInsets() {
        web.evaluateJavascript("document.documentElement.style.setProperty('--sat','" + sat + "px');document.documentElement.style.setProperty('--sab','" + sab + "px')", null)
    }

    @Suppress("DEPRECATION")
    private fun edgeToEdge() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28) { val lp = window.attributes; lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; window.attributes = lp }
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS, WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS)
        } else {
            var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = f
        }
        web.setOnApplyWindowInsetsListener { v, ins ->
            val d = resources.displayMetrics.density
            val top: Int; val bot: Int; var kb: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val s = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                top = s.top; bot = s.bottom
                kb = ins.getInsets(WindowInsets.Type.ime()).bottom
                if (kb <= bot) kb = 0
            } else {
                top = ins.systemWindowInsetTop; bot = ins.stableInsetBottom
                kb = maxOf(0, ins.systemWindowInsetBottom - bot)
            }
            v.setPadding(0, 0, 0, kb)
            sat = top / d; sab = if (kb > 0) 0f else bot / d
            pushInsets()
            ins
        }
        web.requestApplyInsets()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = true; allowContentAccess = false
            setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { pushInsets() }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        edgeToEdge()
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveBackup(json: String, name: String) {
            pending = json
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, name)
                }, 1)
            }
        }
        @JavascriptInterface fun openRestore() {
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream"))
                }, 2)
            }
        }
    }

    private fun js(s: String) = web.post { web.evaluateJavascript(s, null) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) { if (req == 1) js("onBackupDone(false)"); return }
        try {
            if (req == 1) {
                contentResolver.openOutputStream(uri, "wt")!!.use { it.write((pending ?: "").toByteArray(Charsets.UTF_8)) }
                pending = null; js("onBackupDone(true)")
            } else {
                val t = contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
                js("onRestoreData(" + JSONObject.quote(t) + ")")
            }
        } catch (e: Exception) {
            if (req == 1) js("onBackupDone(false)") else js("onRestoreData(null)")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack&&onBack())===true") {
            if (it != "true") { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
        }
    }
}
