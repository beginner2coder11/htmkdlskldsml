plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.dompetku.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.dompetku.app"; minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "2.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
