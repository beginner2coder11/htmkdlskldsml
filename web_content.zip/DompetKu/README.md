# DompetKu v2
Buka folder ini di Android Studio (Hedgehog+), tunggu Gradle sync, lalu Build > Build APK(s).
- Kotlin + satu WebView; UI di app/src/main/assets (index.html, style.css, app.js).
- Data: localStorage key `dompetku_final_v1`, schema version 2. Migrasi otomatis dari v1 (createdAt/updatedAt/settings ditambahkan; data lama tidak dihapus; salinan mentah disimpan di key `..._v1_backup`).
- Backup/Restore: file JSON via Storage Access Framework. Tanpa permission, tanpa internet.
- Catatan: data localStorage ikut terhapus saat aplikasi di-uninstall, jadi lakukan Backup dulu.
