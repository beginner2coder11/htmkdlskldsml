# DompetKu V2 — Offline-first Personal Finance (Android, WebView)

## Build
1. Buka folder ini di Android Studio (Hedgehog/Iguana atau lebih baru, JDK 17).
2. Tunggu Gradle sync (butuh internet SEKALI untuk mengunduh Gradle/plugin), lalu Run ▶ atau Build > Build APK(s).
Aplikasi sendiri tidak memakai permission apa pun (tanpa INTERNET).

## Struktur
- `app/src/main/java/id/dompetku/MainActivity.kt` — shell Android: WebView + bridge (`window.Android`).
- `app/src/main/assets/www/` — `index.html`, `css/app.css`, `js/app.js` (seluruh logika).
- `AndroidManifest.xml` — tanpa permission.

## Database
Satu objek JSON `databaseVersion=2` (accounts, categories, transactions, budgets, goals, salarySettings, salaryComponents, settings).
Disimpan oleh bridge ke `filesDir/db.json` secara atomic (tulis `db.tmp` → salin versi lama ke `db.bak` → rename).
Alur setiap perubahan: clone → ubah → validate (relasi ID, nominal integer) → persist → render. Jika gagal, data lama tetap.
Saldo akun, penggunaan budget, dana target, dan analisis gaji SELALU dihitung ulang dari transaksi (tidak ada saldo tersimpan).
`initialSaved` target = dana yang sudah ada di luar akun aplikasi (tidak mengurangi akun). Dana yang berasal dari akun dicatat lewat transaksi jenis Dana Target.

## Migrasi
`migrate()` di `app.js` bertahap (v1→v2 sudah ada). Versi baru: tambah blok `if(v<N)` dan naikkan `V`. Jangan pernah reset database.

## Backup / Restore
Storage Access Framework: `ACTION_CREATE_DOCUMENT` (DompetKu-backup-YYYY-MM-DD.json) dan `ACTION_OPEN_DOCUMENT`.
Restore: parse → migrate → validate → konfirmasi → commit. File rusak ditolak tanpa menyentuh data lama.

## Siklus gaji
- Gajian nominal = tanggal `paydayDay` (default 10, boleh 1–28).
- Spending cycle = gajian nominal → sehari sebelum gajian nominal berikutnya (10 → 9), fungsi `calculateSpendingCycle`.
- Actual pay date (Sabtu → Jumat, Minggu → Jumat sebelumnya) hanya informasi, `calculateActualPayDate`; tidak memengaruhi siklus.
- Hari tersisa = hari kalender dari hari ini s.d. akhir siklus, inklusif (`calculateRemainingDays`).

## Pengujian manual
Lihat bagian QC pada master prompt (saldo, transfer, target, budget, edit/hapus, backup→uninstall→restore, mode pesawat).
Logika tanggal sudah diuji dengan Node (contoh: 4 Okt → 10 Sep–9 Okt; 10 Okt → 10 Okt–9 Nov; 10 Okt 2026 Sabtu → gaji masuk 9 Okt).
