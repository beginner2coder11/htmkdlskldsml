'use strict';
let vuExpanded=false,vuPreviousFocus=null,vuLastTap=null;
function resizeVuCanvas(){
 const canvas=$('vuCanvas'),r=canvas.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2);
 const width=Math.max(1,Math.round(r.width*dpr)),height=Math.max(1,Math.round(r.height*dpr));
 if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height}
}
function updateVuValue(active,rms,db){$('vuValue').textContent=active?(rms>0?db.toFixed(1)+' dBFS · '+(eqState.vuMode==='analog'?'L / R ao vivo':'espectro ao vivo'):'Sem sinal · dBFS'):(media.paused&&current?'Pausado':'Sem sinal · dBFS')}
function drawAnalogVu(ctx,w,h,active,dt){
 const stacked=h>w*1.05,gap=Math.min(w,h)*.035;
 for(let ch=0;ch<2;ch++){
  let rms=0;
  if(active&&stereoAnalysers[ch]){const data=stereoSamples[ch];stereoAnalysers[ch].getFloatTimeDomainData(data);for(const v of data)rms+=v*v;rms=Math.sqrt(rms/data.length)}
  // A visual VU scale referenced to -18 dBFS; this is not calibrated hardware.
  const db=rms>0?20*Math.log10(rms):-60,target=Math.max(0,Math.min(1,(db+38)/23));
  analogLevels[ch]+=(target-analogLevels[ch])*(1-Math.exp(-dt/(target>analogLevels[ch]?.12:.32)));
  const x=gap+(stacked?0:ch*(w-gap)/2),y=gap+(stacked?ch*(h-gap)/2:0);
  const mw=stacked?w-gap*2:(w-gap*3)/2,mh=stacked?(h-gap*3)/2:h-gap*2;
  ctx.save();ctx.translate(x,y);ctx.scale(mw/360,mh/240);
  const bg=ctx.createLinearGradient(0,0,0,240);bg.addColorStop(0,'#fff4ca');bg.addColorStop(1,'#c6a979');
  ctx.fillStyle='#503c27';ctx.fillRect(0,0,360,240);ctx.fillStyle=bg;ctx.fillRect(6,6,348,228);
  const cx=180,cy=211,r=151,start=-Math.PI*.84,end=-Math.PI*.16,angle=t=>start+(end-start)*t;
  ctx.lineWidth=2;ctx.strokeStyle='#342b22';ctx.beginPath();ctx.arc(cx,cy,r,start,end);ctx.stroke();
  ctx.lineWidth=5;ctx.strokeStyle=vuColorAt(1);ctx.beginPath();ctx.arc(cx,cy,r,angle(20/23),end);ctx.stroke();
  for(let i=0;i<=46;i++) {const a=angle(i/46),major=i%2===0;ctx.strokeStyle=i>=40?'#af3027':'#342b22';ctx.lineWidth=major?1.7:.8;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*(r-2),cy+Math.sin(a)*(r-2));ctx.lineTo(cx+Math.cos(a)*(r-(major?13:7)),cy+Math.sin(a)*(r-(major?13:7)));ctx.stroke()}
  ctx.font='bold 13px Georgia';ctx.textAlign='center';
  for(const value of [-20,-10,-7,-5,-3,0,3]){const a=angle((value+20)/23);ctx.fillStyle=value>0?'#af3027':'#342b22';ctx.fillText(value>0?'+'+value:String(value),cx+Math.cos(a)*(r+17),cy+Math.sin(a)*(r+17)+4)}
  ctx.fillStyle='#423326';ctx.font='bold 29px Georgia';ctx.fillText('VU',180,150);ctx.font='12px Georgia';ctx.fillText(ch===0?'LEFT · ESQUERDO':'RIGHT · DIREITO',180,175);
  const a=angle(analogLevels[ch]);ctx.strokeStyle='#221b15';ctx.lineWidth=2.8;ctx.shadowColor='#0006';ctx.shadowBlur=3;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.cos(a)*(r-15),cy+Math.sin(a)*(r-15));ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle='#30251c';ctx.beginPath();ctx.arc(cx,cy,9,0,Math.PI*2);ctx.fill();ctx.restore();
 }
}
function setVuExpanded(expanded){
 vuExpanded=expanded;$('vuPanel').classList.toggle('vuExpanded',expanded);document.body.classList.toggle('vuFullOpen',expanded);
 $('vuFullscreen').textContent=expanded?'⤢ Voltar':'⛶ Tela cheia';$('vuFullscreen').setAttribute('aria-pressed',String(expanded));resizeVuCanvas();
}
function leaveVuFullscreen(){
 setVuExpanded(false);if(document.fullscreenElement===$('vuPanel')&&document.exitFullscreen)document.exitFullscreen().catch(()=>{});
 if(vuPreviousFocus){vuPreviousFocus.focus({preventScroll:true});vuPreviousFocus=null}
}
function toggleVuFullscreen(){
 if(vuExpanded){leaveVuFullscreen();return}
 vuPreviousFocus=document.activeElement;setVuExpanded(true);$('vuFullscreen').focus({preventScroll:true});
 // Keep the viewport-filling layout even when an APK WebView rejects this API.
 try{const request=$('vuPanel').requestFullscreen;if(request){const result=request.call($('vuPanel'));if(result&&result.catch)result.catch(()=>{})}}catch{}
}
$('vuFullscreen').onclick=toggleVuFullscreen;
$('vuCanvas').addEventListener('pointerup',e=>{
 if(e.pointerType==='mouse'||!e.isPrimary)return;
 const now=performance.now();if(vuLastTap&&now-vuLastTap.time<350&&Math.hypot(e.clientX-vuLastTap.x,e.clientY-vuLastTap.y)<32){vuLastTap=null;toggleVuFullscreen()}else vuLastTap={time:now,x:e.clientX,y:e.clientY};
});
$('vuCanvas').addEventListener('dblclick',e=>{if(e.sourceCapabilities&&e.sourceCapabilities.firesTouchEvents)return;if(e.pointerType&&e.pointerType!=='mouse')return;toggleVuFullscreen()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&vuExpanded)leaveVuFullscreen()});
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&vuExpanded)setVuExpanded(false)});
