# سياسة الخصوصية — سجل صيانة المركبة / Privacy Policy / Politique de confidentialité

## العربية
خصوصيتك أولوية قصوى في **سجل صيانة المركبة**.
- جميع بياناتك تُحفظ **محليًا فقط** على جهازك (التخزين المحلي للتطبيق). لا يُرسل أي بيانات إلى أي خادم خارجي إطلاقًا.
- يعمل التطبيق **بالكامل دون اتصال بالإنترنت**: لا طلبات شبكية، لا تتبع، لا إعلانات، لا خدمات تحليلات.
- **لا نجمع أي بيانات شخصية**: لا حسابات، لا أسماء، لا بريد إلكتروني.
- يمكنك حذف بياناتك في أي وقت من داخل التطبيق أو بمسح بيانات التطبيق من إعدادات جهازك.
- اسم الحزمة: `com.nexusapp.nsp2.brmvk2ekep45cuu0l9`.

## English
Your privacy is a top priority in **سجل صيانة المركبة**.
- All your data is stored **locally only** on your device (the app's local storage). No data is ever sent to any external server.
- The app works **fully offline**: no network requests, no tracking, no ads, no analytics.
- **We collect no personal data**: no accounts, no names, no email addresses.
- You can delete your data at any time from inside the app or by clearing the app's data in your device settings.
- Package name: `com.nexusapp.nsp2.brmvk2ekep45cuu0l9`.

## Français
Votre confidentialité est une priorité absolue dans **سجل صيانة المركبة**.
- Toutes vos données sont stockées **uniquement localement** sur votre appareil (stockage local de l'application). Aucune donnée n'est jamais envoyée à un serveur externe.
- L'application fonctionne **entièrement hors ligne** : aucune requête réseau, aucun suivi, aucune publicité, aucune analyse.
- **Nous ne collectons aucune donnée personnelle** : ni comptes, ni noms, ni adresses e-mail.
- Vous pouvez supprimer vos données à tout moment depuis l'application ou en effaçant les données de l'application dans les paramètres de votre appareil.
- Nom du package : `com.nexusapp.nsp2.brmvk2ekep45cuu0l9`.
