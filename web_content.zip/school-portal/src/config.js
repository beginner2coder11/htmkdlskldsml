// Edit these to match your school.
export const SCHOOL_NAME = 'School Portal'
export const CURRENCY = '$'

export const money = (n) => `${CURRENCY}${Number(n || 0).toLocaleString()}`

// Today (or any date) as YYYY-MM-DD in the phone's local time.
export const localISO = (d = new Date()) =>
  new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10)

export const monthStartISO = () => {
  const d = new Date()
  return localISO(new Date(d.getFullYear(), d.getMonth(), 1))
}
