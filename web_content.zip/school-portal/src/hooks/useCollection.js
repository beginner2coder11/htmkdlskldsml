import { useEffect, useState } from 'react'
import { collection, onSnapshot } from 'firebase/firestore'
import { db } from '../firebase'

// Live list of every document in a collection, sorted on the phone by `sortBy`.
export default function useCollection(name, sortBy) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, name),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        if (sortBy) list.sort((a, b) => String(a[sortBy] ?? '').localeCompare(String(b[sortBy] ?? '')))
        setItems(list)
        setLoading(false)
      },
      (err) => {
        setError(err.message)
        setLoading(false)
      }
    )
    return unsub
  }, [name, sortBy])

  return { items, loading, error }
}
