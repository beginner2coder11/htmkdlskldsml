import { useEffect, useState } from 'react'
import { collection, onSnapshot, query, where } from 'firebase/firestore'
import { db } from '../firebase'

function useAttendanceQuery(build, deps) {
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    const unsub = onSnapshot(
      build(collection(db, 'attendance')),
      (snap) => {
        setRecords(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
        setLoading(false)
      },
      () => setLoading(false)
    )
    return unsub
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return { records, loading }
}

// Attendance marks for a single day (YYYY-MM-DD).
export const useAttendanceByDate = (date) =>
  useAttendanceQuery((ref) => query(ref, where('date', '==', date)), [date])

// Attendance marks between two days, inclusive.
export const useAttendanceRange = (from, to) =>
  useAttendanceQuery((ref) => query(ref, where('date', '>=', from), where('date', '<=', to)), [from, to])
