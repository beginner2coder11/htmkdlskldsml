import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { signOut } from 'firebase/auth'
import { auth } from '../firebase'
import { SCHOOL_NAME } from '../config'

const LINKS = [
  { to: '/', label: 'Dashboard', end: true, icon: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z' },
  { to: '/attendance', label: 'Attendance', icon: 'M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h9' },
  { to: '/students', label: 'Students', icon: 'M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM21 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75' },
  { to: '/teachers', label: 'Teachers', icon: 'M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z' },
  { to: '/payments', label: 'Payments', icon: 'M2 6h20v12H2zM2 10h20M6 15h4' },
  { to: '/reports', label: 'Reports', icon: 'M4 20V10M10 20V4M16 20v-7M22 20H2' }
]

function Icon({ d }) {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  )
}

export default function Navbar(){
  const navigate = useNavigate()
  const handleLogout = async ()=>{
    await signOut(auth)
    navigate('/login')
  }
  return (
    <>
      <header className="sticky top-0 z-20 bg-navy-900 text-white" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div className="font-display text-lg font-semibold tracking-wide">{SCHOOL_NAME}</div>
          <nav className="hidden items-center gap-1 md:flex">
            {LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-2 text-sm ${isActive ? 'bg-white/15 text-white' : 'text-navy-100 hover:bg-white/10'}`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>
          <button onClick={handleLogout} className="rounded-lg px-3 py-2 text-sm text-navy-100 active:bg-white/10">
            Logout
          </button>
        </div>
      </header>

      <nav
        className="fixed inset-x-0 bottom-0 z-20 border-t border-slate-200 bg-white md:hidden"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        aria-label="Main"
      >
        <div className="grid grid-cols-6">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `relative flex flex-col items-center gap-0.5 px-0.5 pb-2 pt-2.5 text-[10.5px] font-medium ${isActive ? 'text-navy-700' : 'text-slate-500'}`
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && <span className="absolute inset-x-3 top-0 h-[3px] rounded-b bg-amber-500" />}
                  <Icon d={l.icon} />
                  <span className="max-w-full truncate">{l.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </>
  )
}
