import React from 'react'

export const inputCls =
  'w-full rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-base text-slate-900 placeholder:text-slate-400 focus:border-navy-600 focus:outline-none focus:ring-4 focus:ring-navy-600/15'
export const btnPrimary =
  'inline-flex items-center justify-center rounded-xl bg-navy-800 px-5 py-3 text-base font-semibold text-white active:bg-navy-900 disabled:opacity-50'
export const btnGhost =
  'inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 active:bg-slate-100'
export const btnDanger = 'rounded-lg px-3 py-2 text-sm font-medium text-absent active:bg-red-50'

export function PageTitle({ title, hint, children }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900">{title}</h1>
        {hint && <p className="mt-0.5 text-sm text-slate-500">{hint}</p>}
      </div>
      {children}
    </div>
  )
}

export function Card({ className = '', children }) {
  return <section className={`rounded-2xl border border-slate-200 bg-white p-4 ${className}`}>{children}</section>
}

export function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-600">{label}</span>
      {children}
    </label>
  )
}

export function Empty({ children }) {
  return <p className="rounded-2xl border border-dashed border-slate-300 px-4 py-8 text-center text-slate-500">{children}</p>
}

export function ErrorNote({ message }) {
  if (!message) return null
  return (
    <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm text-absent">
      {message}
    </p>
  )
}
