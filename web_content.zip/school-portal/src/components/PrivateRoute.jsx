import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuthState } from 'react-firebase-hooks/auth'
import { auth } from '../firebase'

export default function PrivateRoute({ children }){
  const [user, loading] = useAuthState(auth)
  if(loading) return <div className="grid h-full place-items-center text-slate-500">Loading...</div>
  if(!user) return <Navigate to="/login" />
  return children
}
