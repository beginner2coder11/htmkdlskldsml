import React from 'react'
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom'
import { configMissing } from './firebase'
import PrivateRoute from './components/PrivateRoute'
import Navbar from './components/Navbar'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Attendance from './pages/Attendance'
import Students from './pages/Students'
import Teachers from './pages/Teachers'
import Payments from './pages/Payments'
import Reports from './pages/Reports'

function Shell() {
  return (
    <div className="min-h-full">
      <Navbar />
      <main className="mx-auto w-full max-w-4xl px-4 pb-28 pt-5 md:pb-10">
        <Routes>
          <Route index element={<Dashboard />} />
          <Route path="attendance" element={<Attendance />} />
          <Route path="students" element={<Students />} />
          <Route path="teachers" element={<Teachers />} />
          <Route path="payments" element={<Payments />} />
          <Route path="reports" element={<Reports />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}

function SetupNotice() {
  return (
    <div className="grid min-h-full place-items-center p-6">
      <div className="max-w-md rounded-2xl border border-slate-200 bg-white p-6">
        <h1 className="font-display text-2xl font-semibold text-navy-900">Connect Firebase first</h1>
        <p className="mt-2 text-slate-600">
          The app can't sign anyone in yet because it has no Firebase settings. Copy <b>.env.example</b> to <b>.env</b>,
          paste in the values from your Firebase project, then restart the app.
        </p>
      </div>
    </div>
  )
}

export default function App() {
  if (configMissing) return <SetupNotice />
  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/*"
          element={
            <PrivateRoute>
              <Shell />
            </PrivateRoute>
          }
        />
      </Routes>
    </HashRouter>
  )
}
