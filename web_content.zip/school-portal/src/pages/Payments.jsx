import React, { useMemo, useState } from 'react'
import { addDoc, collection, deleteDoc, doc, serverTimestamp } from 'firebase/firestore'
import { db } from '../firebase'
import useCollection from '../hooks/useCollection'
import { localISO, money, CURRENCY } from '../config'
import { Card, PageTitle, Field, Empty, ErrorNote, inputCls, btnPrimary, btnDanger } from '../components/ui'

export default function Payments() {
  const { items: students } = useCollection('students', 'name')
  const { items: payments, loading, error } = useCollection('payments')
  const [form, setForm] = useState({ studentId: '', amount: '', note: '', date: localISO() })
  const [err, setErr] = useState('')
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const sorted = useMemo(
    () => [...payments].sort((a, b) => String(b.date).localeCompare(String(a.date))),
    [payments]
  )
  const total = payments.reduce((sum, p) => sum + Number(p.amount || 0), 0)

  const add = (e) => {
    e.preventDefault()
    const student = students.find((s) => s.id === form.studentId)
    const amount = Number(form.amount)
    if (!student || !(amount > 0)) return
    setErr('')
    addDoc(collection(db, 'payments'), {
      studentId: student.id,
      studentName: student.name,
      className: student.className || '',
      amount,
      note: form.note.trim(),
      date: form.date,
      createdAt: serverTimestamp()
    }).catch((ex) => setErr(ex.message))
    setForm((f) => ({ ...f, amount: '', note: '' }))
  }

  const remove = (p) => {
    if (window.confirm(`Delete the ${money(p.amount)} payment from ${p.studentName}?`)) {
      deleteDoc(doc(db, 'payments', p.id)).catch((ex) => setErr(ex.message))
    }
  }

  return (
    <>
      <PageTitle title="Payments" hint={`${money(total)} received in total`} />

      <Card className="mb-4">
        {students.length === 0 ? (
          <p className="text-slate-500">Add students first, then you can record their payments here.</p>
        ) : (
          <form onSubmit={add} className="space-y-3">
            <Field label="Student">
              <select className={inputCls} value={form.studentId} onChange={set('studentId')} required>
                <option value="">Choose a student</option>
                {students.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}{s.className ? ` (${s.className})` : ''}</option>
                ))}
              </select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={`Amount${CURRENCY ? ` (${CURRENCY})` : ''}`}>
                <input className={inputCls} type="number" inputMode="decimal" min="0" step="any" value={form.amount} onChange={set('amount')} required />
              </Field>
              <Field label="Date">
                <input className={inputCls} type="date" value={form.date} onChange={set('date')} required />
              </Field>
            </div>
            <Field label="Note (optional)">
              <input className={inputCls} value={form.note} onChange={set('note')} placeholder="e.g. Term 2 fees" />
            </Field>
            <button className={`${btnPrimary} w-full`}>Record payment</button>
          </form>
        )}
      </Card>

      <ErrorNote message={err || error} />

      {loading ? null : sorted.length === 0 ? (
        <Empty>No payments recorded yet.</Empty>
      ) : (
        <ul className="divide-y divide-slate-200 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {sorted.map((p) => (
            <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <div className="truncate font-medium">{p.studentName}</div>
                <div className="truncate text-sm text-slate-500">
                  {p.date}
                  {p.note ? ` \u2022 ${p.note}` : ''}
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <span className="font-semibold text-navy-900">{money(p.amount)}</span>
                <button className={btnDanger} onClick={() => remove(p)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
