import React, { useMemo, useState } from 'react'
import useCollection from '../hooks/useCollection'
import { useAttendanceRange } from '../hooks/useAttendance'
import { localISO, monthStartISO, money } from '../config'
import { Card, PageTitle, Field, Empty, inputCls, btnGhost } from '../components/ui'

const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`

export default function Reports() {
  const [from, setFrom] = useState(monthStartISO())
  const [to, setTo] = useState(localISO())
  const [note, setNote] = useState('')
  const { items: students } = useCollection('students', 'name')
  const { items: payments } = useCollection('payments')
  const { records } = useAttendanceRange(from, to)

  const rows = useMemo(() => {
    const byId = {}
    students.forEach((s) => { byId[s.id] = { id: s.id, name: s.name, className: s.className || '', present: 0, absent: 0, paid: 0 } })
    records.forEach((r) => {
      const row = byId[r.studentId]
      if (!row) return
      if (r.present) row.present += 1
      else row.absent += 1
    })
    payments.forEach((p) => {
      const row = byId[p.studentId]
      if (row && p.date >= from && p.date <= to) row.paid += Number(p.amount || 0)
    })
    return Object.values(byId)
      .map((r) => {
        const days = r.present + r.absent
        return { ...r, days, rate: days ? Math.round((r.present / days) * 100) : null }
      })
      .sort((a, b) => a.className.localeCompare(b.className) || a.name.localeCompare(b.name))
  }, [students, records, payments, from, to])

  const paidTotal = rows.reduce((sum, r) => sum + r.paid, 0)

  const toCSV = () => {
    const lines = [['Name', 'Class', 'Days present', 'Days absent', 'Attendance %', 'Paid'].map(csvCell).join(',')]
    rows.forEach((r) => lines.push([r.name, r.className, r.present, r.absent, r.rate ?? '', r.paid].map(csvCell).join(',')))
    return lines.join('\n')
  }

  const share = async () => {
    const text = toCSV()
    try {
      if (navigator.share) await navigator.share({ title: `Report ${from} to ${to}`, text })
      else {
        await navigator.clipboard.writeText(text)
        setNote('Copied. Paste it into a spreadsheet or message.')
      }
    } catch (e) {
      /* share sheet closed */
    }
  }

  return (
    <>
      <PageTitle title="Reports" hint="Attendance and payments per student." />

      <Card className="mb-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="From">
            <input className={inputCls} type="date" value={from} max={to} onChange={(e) => e.target.value && setFrom(e.target.value)} />
          </Field>
          <Field label="To">
            <input className={inputCls} type="date" value={to} min={from} onChange={(e) => e.target.value && setTo(e.target.value)} />
          </Field>
        </div>
      </Card>

      {rows.length === 0 ? (
        <Empty>No students yet, so there is nothing to report.</Empty>
      ) : (
        <>
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-sm text-slate-600">Paid in this period: <b className="text-navy-900">{money(paidTotal)}</b></p>
            <button className={btnGhost} onClick={share}>Share report</button>
          </div>
          {note && <p className="mb-2 text-sm text-present">{note}</p>}

          <ul className="divide-y divide-slate-200 overflow-hidden rounded-2xl border border-slate-200 bg-white">
            {rows.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <div className="truncate font-medium">{r.name}</div>
                  <div className="truncate text-sm text-slate-500">
                    {r.className || 'No class'} {'\u2022'} {r.present} present, {r.absent} absent
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <div className={`font-semibold ${r.rate === null ? 'text-slate-400' : r.rate >= 80 ? 'text-present' : 'text-absent'}`}>
                    {r.rate === null ? 'No data' : `${r.rate}%`}
                  </div>
                  <div className="text-sm text-slate-500">{money(r.paid)}</div>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </>
  )
}
