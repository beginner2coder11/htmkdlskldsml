import React, { useState } from 'react'
import { addDoc, collection, deleteDoc, doc, serverTimestamp } from 'firebase/firestore'
import { db } from '../firebase'
import useCollection from '../hooks/useCollection'
import { Card, PageTitle, Field, Empty, ErrorNote, inputCls, btnPrimary, btnDanger } from '../components/ui'

export default function Teachers() {
  const { items, loading, error } = useCollection('teachers', 'name')
  const [form, setForm] = useState({ name: '', subject: '', phone: '' })
  const [err, setErr] = useState('')
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const add = (e) => {
    e.preventDefault()
    if (!form.name.trim()) return
    setErr('')
    addDoc(collection(db, 'teachers'), {
      name: form.name.trim(),
      subject: form.subject.trim(),
      phone: form.phone.trim(),
      createdAt: serverTimestamp()
    }).catch((ex) => setErr(ex.message))
    setForm({ name: '', subject: '', phone: '' })
  }

  const remove = (t) => {
    if (window.confirm(`Delete ${t.name}?`)) {
      deleteDoc(doc(db, 'teachers', t.id)).catch((ex) => setErr(ex.message))
    }
  }

  return (
    <>
      <PageTitle title="Teachers" hint={`${items.length} on staff`} />

      <Card className="mb-4">
        <form onSubmit={add} className="space-y-3">
          <Field label="Full name">
            <input className={inputCls} value={form.name} onChange={set('name')} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Subject">
              <input className={inputCls} value={form.subject} onChange={set('subject')} placeholder="e.g. Mathematics" />
            </Field>
            <Field label="Phone">
              <input className={inputCls} inputMode="tel" value={form.phone} onChange={set('phone')} />
            </Field>
          </div>
          <button className={`${btnPrimary} w-full`}>Add teacher</button>
        </form>
      </Card>

      <ErrorNote message={err || error} />

      {loading ? null : items.length === 0 ? (
        <Empty>No teachers yet. Add the first one above.</Empty>
      ) : (
        <ul className="divide-y divide-slate-200 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {items.map((t) => (
            <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <div className="truncate font-medium">{t.name}</div>
                <div className="truncate text-sm text-slate-500">
                  {t.subject || 'No subject'}
                  {t.phone ? ` \u2022 ${t.phone}` : ''}
                </div>
              </div>
              <button className={btnDanger} onClick={() => remove(t)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
