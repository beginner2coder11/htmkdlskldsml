import React, { useState } from 'react'
import { addDoc, collection, deleteDoc, doc, serverTimestamp } from 'firebase/firestore'
import { db } from '../firebase'
import useCollection from '../hooks/useCollection'
import { Card, PageTitle, Field, Empty, ErrorNote, inputCls, btnPrimary, btnDanger } from '../components/ui'

export default function Students() {
  const { items, loading, error } = useCollection('students', 'name')
  const [form, setForm] = useState({ name: '', className: '', guardianPhone: '' })
  const [search, setSearch] = useState('')
  const [err, setErr] = useState('')
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const add = (e) => {
    e.preventDefault()
    if (!form.name.trim()) return
    setErr('')
    addDoc(collection(db, 'students'), {
      name: form.name.trim(),
      className: form.className.trim(),
      guardianPhone: form.guardianPhone.trim(),
      createdAt: serverTimestamp()
    }).catch((ex) => setErr(ex.message))
    setForm((f) => ({ name: '', className: f.className, guardianPhone: '' }))
  }

  const remove = (s) => {
    if (window.confirm(`Delete ${s.name}? Their past attendance and payments stay on record.`)) {
      deleteDoc(doc(db, 'students', s.id)).catch((ex) => setErr(ex.message))
    }
  }

  const q = search.trim().toLowerCase()
  const shown = q ? items.filter((s) => `${s.name} ${s.className}`.toLowerCase().includes(q)) : items

  return (
    <>
      <PageTitle title="Students" hint={`${items.length} enrolled`} />

      <Card className="mb-4">
        <form onSubmit={add} className="space-y-3">
          <Field label="Full name">
            <input className={inputCls} value={form.name} onChange={set('name')} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Class">
              <input className={inputCls} value={form.className} onChange={set('className')} placeholder="e.g. Grade 5A" />
            </Field>
            <Field label="Guardian phone">
              <input className={inputCls} inputMode="tel" value={form.guardianPhone} onChange={set('guardianPhone')} />
            </Field>
          </div>
          <button className={`${btnPrimary} w-full`}>Add student</button>
        </form>
      </Card>

      <ErrorNote message={err || error} />

      {items.length > 5 && (
        <input className={`${inputCls} mb-3`} placeholder="Search by name or class" value={search} onChange={(e) => setSearch(e.target.value)} />
      )}

      {loading ? null : shown.length === 0 ? (
        <Empty>{items.length ? 'No student matches that search.' : 'No students yet. Add the first one above.'}</Empty>
      ) : (
        <ul className="divide-y divide-slate-200 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {shown.map((s) => (
            <li key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <div className="truncate font-medium">{s.name}</div>
                <div className="truncate text-sm text-slate-500">
                  {s.className || 'No class'}
                  {s.guardianPhone ? ` \u2022 ${s.guardianPhone}` : ''}
                </div>
              </div>
              <button className={btnDanger} onClick={() => remove(s)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
