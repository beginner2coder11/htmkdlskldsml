import React, { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth'
import { useAuthState } from 'react-firebase-hooks/auth'
import { auth } from '../firebase'
import { SCHOOL_NAME } from '../config'
import { inputCls, btnPrimary, Field, ErrorNote } from '../components/ui'

function friendly(err) {
  switch (err && err.code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
    case 'auth/invalid-email':
      return 'Email or password is incorrect. Check both and try again.'
    case 'auth/network-request-failed':
      return 'No internet connection. Connect to Wi-Fi or mobile data and try again.'
    case 'auth/too-many-requests':
      return 'Too many attempts. Wait a few minutes, then try again.'
    default:
      return 'Could not sign in. Try again in a moment.'
  }
}

export default function Login() {
  const [user, loading] = useAuthState(auth)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  if (loading) return null
  if (user) return <Navigate to="/" replace />

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    setInfo('')
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password)
    } catch (err) {
      setError(friendly(err))
      setBusy(false)
    }
  }

  const reset = async () => {
    setError('')
    setInfo('')
    if (!email.trim()) return setError('Type your email above first, then tap "Forgot password?".')
    try {
      await sendPasswordResetEmail(auth, email.trim())
      setInfo(`Password reset link sent to ${email.trim()}.`)
    } catch (err) {
      setError(friendly(err))
    }
  }

  return (
    <div
      className="flex min-h-full flex-col justify-center bg-navy-900 px-5"
      style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-8 border-l-4 border-amber-500 pl-4">
          <h1 className="font-display text-3xl font-semibold text-white">{SCHOOL_NAME}</h1>
          <p className="mt-1 text-navy-200">Sign in with your staff account.</p>
        </div>

        <form onSubmit={submit} className="space-y-4 rounded-2xl bg-white p-5">
          <Field label="Email">
            <input
              className={inputCls}
              type="email"
              autoComplete="username"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </Field>
          <Field label="Password">
            <input
              className={inputCls}
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </Field>
          <ErrorNote message={error} />
          {info && <p className="rounded-xl bg-emerald-50 px-3.5 py-2.5 text-sm text-present">{info}</p>}
          <button className={`${btnPrimary} w-full`} disabled={busy}>
            {busy ? 'Signing in...' : 'Sign in'}
          </button>
          <button type="button" onClick={reset} className="block w-full py-1 text-center text-sm text-navy-700 underline">
            Forgot password?
          </button>
        </form>
      </div>
    </div>
  )
}
