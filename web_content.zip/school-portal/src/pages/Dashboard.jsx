import React, { useMemo } from 'react'
import { Link } from 'react-router-dom'
import useCollection from '../hooks/useCollection'
import { useAttendanceByDate } from '../hooks/useAttendance'
import { localISO, monthStartISO, money } from '../config'
import { Card, PageTitle } from '../components/ui'

export default function Dashboard() {
  const today = localISO()
  const { items: students } = useCollection('students')
  const { items: teachers } = useCollection('teachers')
  const { items: payments } = useCollection('payments')
  const { records } = useAttendanceByDate(today)

  const present = records.filter((r) => r.present).length
  const absent = records.length - present
  const unmarked = Math.max(students.length - records.length, 0)

  const monthTotal = useMemo(() => {
    const from = monthStartISO()
    return payments.filter((p) => p.date >= from).reduce((sum, p) => sum + Number(p.amount || 0), 0)
  }, [payments])

  const dateLabel = new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' })

  return (
    <>
      <PageTitle title="Today" hint={dateLabel} />

      <Card className="mb-3">
        <div className="flex items-baseline justify-between">
          <h2 className="font-medium text-slate-600">Attendance today</h2>
          <Link to="/attendance" className="text-sm font-medium text-navy-700 underline">Take attendance</Link>
        </div>
        <div className="mt-3 flex gap-6">
          <div><div className="font-display text-3xl font-semibold text-present">{present}</div><div className="text-sm text-slate-500">present</div></div>
          <div><div className="font-display text-3xl font-semibold text-absent">{absent}</div><div className="text-sm text-slate-500">absent</div></div>
          <div><div className="font-display text-3xl font-semibold text-slate-700">{unmarked}</div><div className="text-sm text-slate-500">not marked</div></div>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Link to="/students"><Card><div className="font-display text-3xl font-semibold text-navy-900">{students.length}</div><div className="text-sm text-slate-500">students</div></Card></Link>
        <Link to="/teachers"><Card><div className="font-display text-3xl font-semibold text-navy-900">{teachers.length}</div><div className="text-sm text-slate-500">teachers</div></Card></Link>
      </div>

      <Link to="/payments" className="mt-3 block">
        <Card>
          <div className="font-display text-3xl font-semibold text-navy-900">{money(monthTotal)}</div>
          <div className="text-sm text-slate-500">payments received this month</div>
        </Card>
      </Link>
    </>
  )
}
