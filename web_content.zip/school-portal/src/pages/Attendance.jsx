import React, { useEffect, useMemo, useState } from 'react'
import { doc, setDoc, writeBatch } from 'firebase/firestore'
import { db } from '../firebase'
import useCollection from '../hooks/useCollection'
import { useAttendanceByDate } from '../hooks/useAttendance'
import { localISO } from '../config'
import { Card, PageTitle, Field, Empty, inputCls, btnGhost } from '../components/ui'

export default function Attendance() {
  const [date, setDate] = useState(localISO())
  const [cls, setCls] = useState('')
  const { items: students } = useCollection('students', 'name')
  const { records } = useAttendanceByDate(date)

  const classes = useMemo(
    () => [...new Set(students.map((s) => s.className).filter(Boolean))].sort(),
    [students]
  )
  useEffect(() => {
    if (classes.length && !classes.includes(cls)) setCls(classes[0])
  }, [classes, cls])

  const roster = students.filter((s) => s.className === cls)
  const status = useMemo(() => {
    const m = {}
    records.forEach((r) => { m[r.studentId] = r.present })
    return m
  }, [records])

  const ref = (s) => doc(db, 'attendance', `${date}_${s.id}`)
  const payload = (s, present) => ({ date, studentId: s.id, className: s.className, present })

  const mark = (s, present) => {
    setDoc(ref(s), payload(s, present), { merge: true }).catch(() => {})
  }
  const markAll = (present) => {
    const batch = writeBatch(db)
    roster.forEach((s) => batch.set(ref(s), payload(s, present), { merge: true }))
    batch.commit().catch(() => {})
  }

  const presentCount = roster.filter((s) => status[s.id] === true).length
  const absentCount = roster.filter((s) => status[s.id] === false).length
  const unmarked = roster.length - presentCount - absentCount

  if (students.length && classes.length === 0) {
    return (
      <>
        <PageTitle title="Attendance" />
        <Empty>Your students don't have a class yet. Add a class to each student, then come back here.</Empty>
      </>
    )
  }

  return (
    <>
      <PageTitle title="Attendance" hint="Taps save automatically." />

      <Card className="mb-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date">
            <input className={inputCls} type="date" value={date} max={localISO()} onChange={(e) => e.target.value && setDate(e.target.value)} />
          </Field>
          <Field label="Class">
            <select className={inputCls} value={cls} onChange={(e) => setCls(e.target.value)}>
              {classes.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
        </div>
      </Card>

      {roster.length === 0 ? (
        <Empty>Add students to see the class register.</Empty>
      ) : (
        <>
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-sm text-slate-600">
              <b className="text-present">{presentCount}</b> present, <b className="text-absent">{absentCount}</b> absent
              {unmarked > 0 && <>, {unmarked} not marked</>}
            </p>
            <button className={btnGhost} onClick={() => markAll(true)}>Mark all present</button>
          </div>

          <ul className="space-y-2">
            {roster.map((s) => {
              const st = status[s.id]
              const stripe = st === true ? 'border-l-present' : st === false ? 'border-l-absent' : 'border-l-slate-300'
              return (
                <li key={s.id} className={`flex items-center justify-between gap-3 rounded-xl border border-l-[6px] border-slate-200 bg-white py-2.5 pl-3 pr-2.5 ${stripe}`}>
                  <span className="min-w-0 truncate font-medium">{s.name}</span>
                  <div className="flex shrink-0 overflow-hidden rounded-lg border border-slate-300 text-sm font-semibold">
                    <button
                      onClick={() => mark(s, true)}
                      aria-pressed={st === true}
                      className={`px-4 py-2.5 ${st === true ? 'bg-present text-white' : 'bg-white text-slate-600'}`}
                    >
                      Present
                    </button>
                    <button
                      onClick={() => mark(s, false)}
                      aria-pressed={st === false}
                      className={`border-l border-slate-300 px-4 py-2.5 ${st === false ? 'bg-absent text-white' : 'bg-white text-slate-600'}`}
                    >
                      Absent
                    </button>
                  </div>
                </li>
              )
            })}
          </ul>
        </>
      )}
    </>
  )
}
