# School Portal: Android app

React + Firebase school portal (Dashboard, Attendance, Students, Teachers,
Payments, Reports) wrapped with Capacitor so it installs as a real Android app
with its own icon and opens full-screen, with no link and no browser.

## 1. Set up Firebase (once, about 10 minutes)
1. Go to console.firebase.google.com and create a project.
2. Project settings > Your apps > add a **Web app**. Copy its config values.
3. In this folder, copy `.env.example` to `.env` and paste the values in.
4. Build > Authentication > Sign-in method > turn on **Email/Password**.
   Then add your staff under Users > Add user. (There is no public sign-up.)
5. Build > Firestore Database > Create database. Open the Rules tab and paste
   in the contents of `firestore.rules`, then Publish.

## 2. Try it on your computer
    npm install
    npm run dev
Open the address it prints. Sign in with a user you created.

## 3. Turn it into an Android app
Needs Node.js and Android Studio (installing Android Studio installs the SDK).

    npx cap add android
    npm run icons        (app icon and splash screen from /assets)
    npm run android      (builds the web app, copies it in, opens Android Studio)

In Android Studio, wait for Gradle sync, then:
- Test: plug in your phone (USB debugging on) and press the green Run button.
- APK file: Build > Build Bundle(s) / APK(s) > Build APK(s) > "locate".
  Copy `app-debug.apk` to a phone and open it to install.

After any code change: `npm run sync`, then Run again.

## Before you give it to others
- Change `appId` in `capacitor.config.json` (for example `com.yourschool.portal`)
  before you first run `npx cap add android`.
- The included Firestore rules let ANY signed-in user read and change ALL data.
  Only create accounts for staff you trust until you add roles.
- For Google Play, build a signed .aab (Build > Generate Signed Bundle) and keep
  the keystore file and passwords safe. You will need them for every update.

## Good to know
- Data lives in Firebase, so all phones see the same records live.
- Recent data is cached on the phone, so screens still open and taps still work
  when the connection drops. Changes sync when it returns.
- Edit school name and currency in `src/config.js`.
