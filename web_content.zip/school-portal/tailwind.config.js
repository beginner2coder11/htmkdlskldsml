/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#eef3fb', 100: '#dbe6f6', 200: '#b7cbe9', 600: '#24508f',
          700: '#1c3f73', 800: '#173359', 900: '#10243f'
        },
        amber: { 400: '#f0b93e', 500: '#e0a526' },
        present: '#1f7a54',
        absent: '#b3382c'
      },
      fontFamily: {
        display: ['"Iowan Old Style"', '"Palatino Linotype"', 'Palatino', 'Georgia', 'serif']
      }
    }
  },
  plugins: []
}
