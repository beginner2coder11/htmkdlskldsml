from flask import Flask, jsonify, request

app = Flask(__name__)

# Simple endpoint to verify a card number via Luhn
@app.route('/verify', methods=['POST'])
def verify_card():
    data = request.json
    card_number = data.get('cardNumber')
    
    def luhn_check(card_num):
        nums = [int(x) for x in card_num]
        reverse_nums = nums[::-1]
        total = 0
        for i, n in enumerate(reverse_nums):
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        return total % 10 == 0

    is_valid = luhn_check(card_number)
    return jsonify({"valid": is_valid, "card": card_number})

# Endpoint to get a random balance suggestion
@app.route('/balance', methods=['GET'])
def get_balance():
    balances = [
        "$12,450.00", "$25,000.00", "$50,000.00", 
        "$150,000.00", "$500,000.00", "$1,250,000.00"
    ]
    import random
    return jsonify({"balance": random.choice(balances)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)