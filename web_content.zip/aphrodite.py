import random
import string

class FlashBTCSender:
    def __init__(self):
        self.balance = 0.005  # Starting balance

    def send_bitcoin(self, address, amount):
        """Simulates sending flash BTC."""
        if amount > self.balance:
            return {"success": False, "error": "Insufficient balance"}
        
        if not address or len(address) < 26:
            return {"success": False, "error": "Invalid address format"}

        # Deduct balance
        self.balance -= amount

        # Generate fake TXID
        txid = ''.join(random.choices(string.hexdigits.lower(), k=64))

        return {
            "success": True,
            "txid": txid,
            "new_balance": round(self.balance, 8)
        }

# Example usage (if running standalone)
if __name__ == "__main__":
    sender = FlashBTCSender()
    print(sender.send_bitcoin("bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", 0.001))