from flask import Flask, render_template, request, jsonify, session
import time
import random
import string

app = Flask(__name__)
# Secret key for session management (required by Flask)
app.secret_key = 'btc-adder-secret-key-2026'

@app.route('/')
def index():
    """Serve the main HTML page."""
    return render_template('index.html')

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """
    Handle the AJAX request from the frontend.
    Validates input and simulates the transaction logic.
    """
    try:
        # Get data from the JSON payload sent by JavaScript
        data = request.get_json()
        
        wallet_address = data.get('walletAddress', '').strip()
        amount = data.get('amount', '0.10')
        server = data.get('server', 'BLOCKCHAIN')
        use_vpn = data.get('useVpn', False)
        hide_ip = data.get('hideIp', False)
        stealth = data.get('stealthMode', False)

        # Validation Logic
        if not wallet_address:
            return jsonify({
                'success': False,
                'message': 'Wallet address cannot be empty.'
            }), 400

        if len(wallet_address) < 26: # Basic check for Bitcoin address length
             return jsonify({
                'success': False,
                'message': 'Invalid wallet address format.'
            }), 400

        # Simulate Server-Side Processing Delay (Optional, for realism)
        # In a real app, you might query a blockchain API here
        
        # Generate a fake Transaction ID
        tx_id = ''.join(random.choices(string.ascii_letters + string.digits, k=64))
        
        # Log the transaction (in memory or database)
        transaction_log = {
            'timestamp': time.time(),
            'wallet': wallet_address,
            'amount': amount,
            'server': server,
            'tx_id': tx_id
        }
        
        # For demonstration, we print to console
        print(f"Transaction Processed: {transaction_log}")

        return jsonify({
            'success': True,
            'message': f'Successfully added {amount} BTC to {wallet_address}',
            'tx_id': tx_id
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'An error occurred: {str(e)}'
        }), 500

if __name__ == '__main__':
    # Run the development server
    # debug=True allows auto-reload when you change code
    app.run(debug=True, host='127.0.0.1', port=5000)