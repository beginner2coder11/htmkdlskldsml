# Hemi-Sync Binaural Integrator — Android App

This is a native Android wrapper around the Hemi-Sync Binaural Integrator web app.

## How to Build the APK

### Requirements
- Android Studio (latest recommended)
- Android SDK (API 34)

### Steps
1. Download and unzip this project.
2. Open Android Studio → **Open** → select the `HemiSyncApp` folder.
3. Let Gradle sync (it will download dependencies automatically).
4. Connect a device or start an emulator.
5. Click **Run** (green triangle) or go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Features in the App
- Full offline Web Audio processing
- Spectral analysis for best carrier frequency
- Purpose-based Hemi-Sync / Gateway frequencies
- Album art support
- Direct download of the enhanced WAV track to your Downloads folder
- Dark theme matching the original design

### Permissions
The app requests storage access so it can save the generated tracks to your device.

---

**Tip**: After installing, grant storage permissions if prompted so downloads work smoothly.
