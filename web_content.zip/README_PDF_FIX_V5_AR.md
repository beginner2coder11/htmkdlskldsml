إصلاح PDF v5
- اعتراض afriquia://savepdf عبر shouldOverrideUrlLoading(String) وWebResourceRequest.
- إنشاء PDF Native داخل Android وحفظه في Downloads.
- رفع versionCode إلى 5 / versionName 1.4.
- منع ظهور رسالة النظام "No app on this device can open that link" عند استخدام مسار PDF الاحتياطي.
