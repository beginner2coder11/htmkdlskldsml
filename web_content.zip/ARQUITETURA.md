# Controlo de Compras 2.3

- Início: menu de seis funções, sem dados, gráficos ou registos de compras.
- Compras: criação, edição, duplicação explícita, recuperação de rascunho e eliminação.
- Produtos: cadastro prévio, categoria, unidade, imagem opcional e arquivo.
- Histórico: registos por identidade do produto, ordenados por data e número.
- Relatórios: compra, histórico de produto e período. Sem comparação de compras completas.
- Definições: negócio, categorias, backup, restauração e limpeza.

Ao selecionar um produto numa nova compra, a embalagem usa a configuração do cadastro do produto; custo e venda começam vazios. Uma área de referência mostra data, custo por embalagem, quantidade por embalagem, custo por unidade e venda anteriores. Diferenças por unidade aparecem quando há valores atuais válidos e unidades compatíveis. Duplicação continua a copiar uma compra por escolha explícita.

Frete e despesas não alteram custos, margens ou lucros por produto. Afetam apenas o resumo. Lucros são estimativas de venda, não vendas realizadas.

core.js mantém cálculos e validação. storage.js mantém IndexedDB e gravação transacional. app.js gere interface e operações; reports.js gera relatórios e PDF. index.html incorpora os mesmos módulos e estilos, incluindo a biblioteca PDF offline. Banco mv_controlo_compras_2 e schema 2 preservados.

Rascunhos independentes: draft mantém o último e drafts preserva os restantes. Eliminações invalidam gravações automáticas pendentes. Eliminar definitivamente remove a compra e o seu rascunho; mover para eliminadas preserva recuperação. Reset restaura a estrutura vazia e limpa o estado da interface. Store.save confere o valor gravado na própria transação IndexedDB.

A versão 2.3 inclui o ícone original gerado em icone.png e incorpora-o no HTML autónomo. Restauração preserva rascunhos validados. Lixeira e rascunhos têm validação de identidade e de referências a produtos. Os testes completos do navegador estão em tests/test-browser.cjs.
