from flask import Flask, request, jsonify
import random
import string

app = Flask(__name__)

# Simulated Database
initial_balance = 1000.00
current_balance = initial_balance

def generate_tx_hash():
    """Generates a fake blockchain transaction hash."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(64))

@app.route('/balance', methods=['GET'])
def get_balance():
    return jsonify({
        "balance": current_balance,
        "currency": "USDT"
    })

@app.route('/send', methods=['POST'])
def send_usdt():
    global current_balance
    
    data = request.get_json()
    recipient = data.get('recipient')
    amount = float(data.get('amount'))
    network = data.get('network', 'TRC20')

    # Validation
    if not recipient or len(recipient) < 10:
        return jsonify({"success": False, "message": "Invalid recipient address"}), 400
    
    if amount <= 0:
        return jsonify({"success": False, "message": "Amount must be greater than 0"}), 400

    if amount > current_balance:
        return jsonify({"success": False, "message": "Insufficient balance"}), 400

    # Simulate processing delay (optional, for realism)
    # In a real app, you'd interact with a blockchain API here
    
    # Deduct balance
    current_balance -= amount
    
    # Generate fake TX Hash
    tx_hash = generate_tx_hash()

    return jsonify({
        "success": True,
        "txHash": tx_hash,
        "recipient": recipient,
        "amount": amount,
        "network": network,
        "newBalance": current_balance,
        "timestamp": "Just now"
    })

if __name__ == '__main__':
    # Run on all interfaces so the Android app can access it
    app.run(host='0.0.0.0', port=5000, debug=True)