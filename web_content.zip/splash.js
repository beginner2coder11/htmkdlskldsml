/* KEA HSE splash: shows the KEA HSE One Click logo + HSE Team chart
   - when any page/form is opened
   - when any Save button is pressed
   Included in every page with: <script src="../splash.js"></script> (root page: splash.js) */
(function(){
  if(window.__keaSplash)return;
  var cs=document.currentScript, base=cs&&cs.src?cs.src.replace(/[^\/]*$/,''):'';
  var IMG1=base+'splash/kea-hse-one-click.jpg', IMG2=base+'splash/hse-team-chart.jpg';
  var st=document.createElement('style');
  st.textContent=
   '#keaSplash{position:fixed;inset:0;z-index:2147483647;background:radial-gradient(ellipse at 50% 30%,#1b1b1f,#050506 75%);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2.2vh;padding:2vh 3vw;opacity:1;transition:opacity .45s ease;-webkit-tap-highlight-color:transparent;cursor:pointer}'+
   '#keaSplash.out{opacity:0;pointer-events:none}'+
   '#keaSplash img{display:block;max-width:92vw;object-fit:contain;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.55);animation:keaIn .7s ease both}'+
   '#keaSplash img.a{max-height:38vh;border-radius:0;box-shadow:none}'+
   '#keaSplash img.b{max-height:46vh;border:1px solid rgba(200,162,74,.55);animation-delay:.25s}'+
   '#keaSplash small{color:#c8a24a;font:600 12px Arial,sans-serif;letter-spacing:.14em;text-transform:uppercase;opacity:.8}'+
   '#keaSplash .m{color:#fff;font:700 13px Arial,sans-serif;letter-spacing:.06em}'+
   '@media (orientation:landscape) and (min-width:700px){#keaSplash{flex-direction:row;flex-wrap:wrap;gap:3vw}#keaSplash img.a{max-height:70vh;max-width:42vw}#keaSplash img.b{max-height:80vh;max-width:46vw}#keaSplash small,#keaSplash .m{flex-basis:100%;text-align:center}}'+
   '@keyframes keaIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}'+
   '@media print{#keaSplash{display:none!important}}';
  (document.head||document.documentElement).appendChild(st);
  var cur=null, timer=null;
  function hide(){
    if(!cur)return; var el=cur; cur=null; clearTimeout(timer);
    el.classList.add('out'); setTimeout(function(){if(el.parentNode)el.parentNode.removeChild(el)},500);
  }
  function show(ms,msg){
    if(cur){clearTimeout(timer);timer=setTimeout(hide,ms);return;}
    var d=document.createElement('div'); d.id='keaSplash'; d.className='no-print np';
    d.innerHTML='<img class="a" alt="KEA HSE One Click" src="'+IMG1+'"><img class="b" alt="KEA HSE Team Organizational Chart" src="'+IMG2+'">'+
      (msg?'<div class="m">'+msg+'</div>':'')+'<small style="visibility:hidden">Tap to continue</small>';
    var ok=false; d.onclick=function(){if(ok)hide()}; cur=d;
    setTimeout(function(){ok=true;var sm=d.querySelector('small');if(sm)sm.style.visibility='visible'},ms);
    (document.body||document.documentElement).appendChild(d);
    timer=setTimeout(hide,ms);
  }
  window.__keaSplash={show:show,hide:hide};
  /* 1) on opening any page / form */
  show(5000);
  /* 2) on any Save button */
  document.addEventListener('click',function(e){
    var b=e.target&&e.target.closest?e.target.closest('button,a,input[type=button],input[type=submit],[role=button]'):null;
    if(!b||b.closest('#keaSplash'))return;
    var t=((b.textContent||'')+' '+(b.value||'')+' '+(b.id||'')).toLowerCase();
    if(/save|\u{1F4BE}/u.test(t)&&!/setting|upload|unsaved/.test(t))show(5000,'Saving\u2026');
  },true);

  /* 3) heading bar "KEA HSE ONE CLICK" at the top of every form page (screen only, not printed/exported) */
  {
    var isHome=(base===location.href.replace(/[?#].*$/,'').replace(/[^\/]*$/,''));
    if(!isHome){
      var hs=document.createElement('style');
      hs.textContent='#keaHead{display:flex;align-items:center;justify-content:space-between;gap:8px;background:#1c1a1a;border-bottom:3px solid #c8a24a;color:#fff;font:700 14px Arial,sans-serif;letter-spacing:.08em;padding:calc(8px + env(safe-area-inset-top,0px)) 10px 8px}#keaHead .t{flex:1;text-align:center;white-space:nowrap}#keaHead .b{display:inline-flex;align-items:center;gap:6px;background:#c8a24a;color:#1c1a1a;border:0;border-radius:8px;padding:8px 11px;font:700 13px Arial,sans-serif;letter-spacing:0;text-decoration:none;cursor:pointer;min-height:36px}#keaHead .b svg{width:17px;height:17px;fill:currentColor;flex:none}#keaHead .b:active{background:#e0b865}@media (max-width:380px){#keaHead .t{font-size:12px;letter-spacing:.04em}#keaHead .b{padding:8px 9px}}@media print{#keaHead{display:none!important}}';
      (document.head||document.documentElement).appendChild(hs);
      var home=base+'index.html';
      var addHead=function(){
        if(document.getElementById('keaHead'))return;
        var h=document.createElement('div'); h.id='keaHead'; h.className='no-print np';
        h.innerHTML='<button type="button" class="b" id="keaBack" aria-label="Back"><svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"/></svg>Back</button>'+
          '<span class="t">KEA HSE ONE CLICK</span>'+
          '<a class="b" href="'+home+'" aria-label="Home"><svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>Home</a>';
        document.body.insertBefore(h,document.body.firstChild);
        document.getElementById('keaBack').onclick=function(){
          var ok=false; try{ok=document.referrer&&new URL(document.referrer).origin===location.origin}catch(e){}
          if(ok&&history.length>1)history.back(); else location.href=home;
        };
      };
      if(document.body)addHead(); else document.addEventListener('DOMContentLoaded',addHead);
    }
  }
})();
