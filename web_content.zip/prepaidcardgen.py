import random
import http.server
import socketserver
import json
from urllib.parse import urlparse, parse_qs

class CardGeneratorHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        
        if parsed_path.path == '/generate':
            # Get query parameters if any (e.g., ?count=5)
            params = parse_qs(parsed_path.query)
            count = int(params.get('count', ['1'])[0])
            
            cards = []
            for _ in range(count):
                card = self.generate_card()
                cards.append(card)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = json.dumps(cards)
            self.wfile.write(response.encode())
            
        else:
            super().do_GET()

    def generate_card(self):
        """Generates a fake Visa/Mastercard number and assigns $500 balance."""
        # Prefixes for major networks
        prefixes = {
            'visa': ['4'],
            'mastercard': ['51', '52', '53', '54', '55']
        }
        
        # Pick a random network
        network = random.choice(list(prefixes.keys()))
        prefix = random.choice(prefixes[network])
        
        # Generate remaining digits (16 total length)
        card_number = prefix + ''.join([str(random.randint(0, 9)) for _ in range(16 - len(prefix) - 1)])
        
        # Apply Luhn Algorithm to make it valid
        card_number = self.luhn_check(card_number)
        
        # Generate random expiration date (future)
        exp_month = random.randint(1, 12)
        exp_year = random.randint(2025, 2030)
        
        return {
            "network": network.upper(),
            "number": card_number,
            "cvv": str(random.randint(100, 999)),
            "expiry": f"{exp_month:02d}/{exp_year}",
            "balance": 500.00
        }

    def luhn_check(self, num):
        """Modifies the last digit to satisfy the Luhn algorithm."""
        nums = [int(n) for n in num]
        # Double every second digit from right to left
        for i in range(len(nums) - 2, -1, -2):
            nums[i] *= 2
            if nums[i] > 9:
                nums[i] -= 9
        
        # Calculate check digit
        total = sum(nums)
        check_digit = (10 - (total % 10)) % 10
        
        return num[:-1] + str(check_digit)

# Start the server
PORT = 8000
handler = CardGeneratorHandler

with socketserver.TCPServer(("localhost", PORT), handler) as httpd:
    print(f"Server running at http://localhost:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass