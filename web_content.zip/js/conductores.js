  const OPCIONES_TIPO_LICENCIA = ['Automovilista', 'Servicio de chofer particular', 'Motociclista'];

  function cargarVistaConductores() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Conductores</h2>' +
        '<button class="primario" onclick="mostrarFormularioConductor()">+ Nuevo conductor</button>' +
      '</div>' +
      '<div id="lista-conductores">Cargando...</div>';

    google.script.run
      .withSuccessHandler(renderizarListaConductores)
      .withFailureHandler(function (error) { document.getElementById('lista-conductores').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>'; })
      .listarConductores('');
  }

  function renderizarListaConductores(conductores) {
    const contenedor = document.getElementById('lista-conductores');
    if (!conductores.length) { contenedor.innerHTML = '<div class="tarjeta estado-vacio"><span class="icono-vacio">🧑‍✈️</span>No hay conductores registrados.</div>'; return; }
    contenedor.innerHTML = conductores.map(function (c) {
      const colorEstado = c.estado === 'Activo' ? 'verde' : 'rojo';
      return (
        '<div class="tarjeta" style="cursor:pointer;" onclick="mostrarFormularioConductor(\'' + c.id_conductor + '\')">' +
          '<div style="display:flex; justify-content:space-between;">' +
            '<strong>' + escaparHtml(c.nombre_completo) + '</strong>' +
            '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(c.estado || '') + '</span>' +
          '</div>' +
          '<div style="color:var(--gris); font-size:13px;">Licencia vence: ' + escaparHtml(formatearFecha(c.licencia_vigencia)) + '</div>' +
        '</div>'
      );
    }).join('');
  }

  function mostrarFormularioConductor(idConductor) {
    if (idConductor) {
      google.script.run.withSuccessHandler(renderizarFormularioConductor).withFailureHandler(function (e) { alert(e.message); }).obtenerConductor(idConductor);
    } else {
      renderizarFormularioConductor(null);
    }
  }

  function renderizarFormularioConductor(conductor) {
    const esEdicion = !!conductor;
    conductor = conductor || {};

    const html =
      '<div class="tarjeta">' +
        '<h3>' + (esEdicion ? 'Editar conductor' : 'Nuevo conductor') + '</h3>' +
        campoTexto('cf-nombre', 'Nombre completo', conductor.nombre_completo) +
        campoTexto('cf-telefono', 'Teléfono', conductor.telefono) +
        campoTexto('cf-numero-licencia', 'Número de licencia', conductor.numero_licencia) +
        campoSelect('cf-tipo-licencia', 'Tipo de licencia', OPCIONES_TIPO_LICENCIA, conductor.tipo_licencia, true) +
        campoFecha('cf-licencia-vigencia', 'Vigencia de la licencia', conductor.licencia_vigencia) +
        campoSelect('cf-estado', 'Estado', ['Activo', 'Inactivo'], conductor.estado) +
        campoTextarea('cf-observaciones', 'Observaciones', conductor.observaciones) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarConductor(' + (esEdicion ? "'" + conductor.id_conductor + "'" : 'null') + ')">Guardar</button> ' +
          '<button onclick="cargarVistaConductores()">Cancelar</button>' +
        '</div>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarConductor(idConductor) {
    const datos = {
      nombre_completo: document.getElementById('cf-nombre').value,
      telefono: document.getElementById('cf-telefono').value,
      numero_licencia: document.getElementById('cf-numero-licencia').value,
      tipo_licencia: document.getElementById('cf-tipo-licencia').value,
      licencia_vigencia: document.getElementById('cf-licencia-vigencia').value,
      estado: document.getElementById('cf-estado').value,
      observaciones: document.getElementById('cf-observaciones').value
    };

    if (!datos.nombre_completo) { alert('El nombre del conductor es obligatorio.'); return; }

    if (idConductor) {
      google.script.run.withSuccessHandler(function () { cargarVistaConductores(); }).withFailureHandler(function (e) { alert(e.message); }).actualizarConductor(idConductor, datos);
    } else {
      google.script.run.withSuccessHandler(function () { cargarVistaConductores(); }).withFailureHandler(function (e) { alert(e.message); }).crearConductor(datos);
    }
  }
