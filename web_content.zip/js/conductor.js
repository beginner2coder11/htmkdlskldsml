let SESION_CONDUCTOR = null;

const COLOR_POR_ESTADO_CONDUCTOR = {
  'Solicitud recibida': 'gris', 'Pendiente de autorización': 'gris',
  'Autorizado': 'azul', 'Programado': 'azul', 'Vehículo asignado': 'azul',
  'En traslado': 'ambar', 'Regresando': 'ambar',
  'En destino': 'verde', 'Finalizado': 'verde',
  'Cancelado': 'rojo', 'Paciente no se presentó': 'rojo',
  'Reprogramado': 'morado'
};

document.addEventListener('DOMContentLoaded', function () {
  if (!obtenerTokenGuardado()) {
    mostrarLoginConductor();
    return;
  }
  google.script.run
    .withSuccessHandler(iniciarPanelConductor)
    .withFailureHandler(function (error) {
      borrarTokenGuardado();
      mostrarLoginConductor(error.message);
    })
    .obtenerSesion();
});

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : texto;
  return div.innerHTML;
}

function mostrarLoginConductor(mensajeError) {
  document.getElementById('contenedor-conductor').innerHTML =
    '<div style="min-height:80vh; display:flex; align-items:center; justify-content:center;">' +
      '<div class="tarjeta" style="width:100%; max-width:320px;">' +
        '<div style="text-align:center; margin-bottom:16px;">' +
          '<div style="font-size:36px;">🚗</div>' +
          '<h2 style="margin:8px 0 0;">Panel del conductor</h2>' +
          '<div style="font-size:12.5px; color:var(--gris); margin-top:2px;">Traslados SVT</div>' +
        '</div>' +
        (mensajeError ? '<div style="background:var(--rojo-suave); color:var(--rojo); padding:10px 12px; border-radius:8px; font-size:13px; margin-bottom:12px;">' + escaparHtml(mensajeError) + '</div>' : '') +
        '<label style="display:block; font-size:13px; margin-bottom:4px;">Usuario</label>' +
        '<input type="text" id="login-usuario-c" style="width:100%; margin-bottom:10px;" autocomplete="username">' +
        '<label style="display:block; font-size:13px; margin-bottom:4px;">Contraseña</label>' +
        '<input type="password" id="login-password-c" style="width:100%; margin-bottom:12px;" autocomplete="current-password" onkeydown="if(event.key===\'Enter\') intentarLoginConductor()">' +
        '<div class="fila-recordarme">' +
          '<input type="checkbox" id="login-recordarme-c">' +
          '<label for="login-recordarme-c">Mantener mi sesión iniciada en este teléfono</label>' +
        '</div>' +
        '<button class="primario grande" onclick="intentarLoginConductor()">Entrar</button>' +
      '</div>' +
    '</div>';
  document.getElementById('login-usuario-c').focus();
}

function intentarLoginConductor() {
  const usuario = document.getElementById('login-usuario-c').value.trim();
  const password = document.getElementById('login-password-c').value;
  const recordarme = document.getElementById('login-recordarme-c').checked;
  if (!usuario || !password) { alert('Escribe tu usuario y contraseña.'); return; }

  const boton = document.querySelector('.tarjeta button.primario');
  boton.disabled = true;
  boton.textContent = 'Entrando...';

  google.script.run
    .withSuccessHandler(function (sesion) {
      guardarToken(sesion.token);
      iniciarPanelConductor(sesion);
    })
    .withFailureHandler(function (error) {
      mostrarLoginConductor(error.message);
    })
    .iniciarSesion(usuario, password, recordarme);
}

function cerrarSesionConductor() {
  detenerRastreoUbicacion();
  google.script.run.cerrarSesion(obtenerTokenGuardado());
  borrarTokenGuardado();
  mostrarLoginConductor();
}

function iniciales(nombre) {
  if (!nombre) return '?';
  const partes = nombre.trim().split(/\s+/);
  return (partes[0][0] + (partes[1] ? partes[1][0] : '')).toUpperCase();
}

function iniciarPanelConductor(sesion) {
  SESION_CONDUCTOR = sesion;
  cargarMisTraslados();
}

function encabezadoConductor() {
  const avisoRolAjeno = SESION_CONDUCTOR.rol !== 'Conductor'
    ? '<div id="aviso-rol">Estás entrando con un usuario de rol "' + escaparHtml(SESION_CONDUCTOR.rol) + '". Este panel está pensado para conductores; para la administración completa usa <strong>/admin</strong>.</div>'
    : '';

  return (
    '<div id="barra-conductor">' +
      '<div class="titulo-conductor">🚗 ' + escaparHtml(SESION_CONDUCTOR.nombre || SESION_CONDUCTOR.correo) + '</div>' +
      '<button class="salir" onclick="cerrarSesionConductor()">Cerrar sesión</button>' +
    '</div>' +
    avisoRolAjeno
  );
}

function cargarMisTraslados() {
  detenerRastreoUbicacion();
  document.getElementById('contenedor-conductor').innerHTML = encabezadoConductor() + '<p>Cargando tus traslados...</p>';

  google.script.run
    .withSuccessHandler(renderizarListaConductor)
    .withFailureHandler(function (error) {
      document.getElementById('contenedor-conductor').innerHTML = encabezadoConductor() + '<p>Error al cargar: ' + escaparHtml(error.message) + '</p>';
    })
    .listarTraslados({});
}

function renderizarListaConductor(traslados) {
  const contenedor = document.getElementById('contenedor-conductor');

  if (!traslados.length) {
    contenedor.innerHTML = encabezadoConductor() +
      '<div class="tarjeta estado-vacio"><span class="icono-vacio">🚑</span>No tienes traslados asignados por ahora.</div>';
    return;
  }

  // Los traslados que requieren captura de datos del vehículo van primero.
  const accionables = ['Vehículo asignado', 'En traslado', 'En destino'];
  const ordenados = traslados.slice().sort(function (a, b) {
    const pa = accionables.indexOf(a.estado_actual) === -1 ? 1 : 0;
    const pb = accionables.indexOf(b.estado_actual) === -1 ? 1 : 0;
    return pa - pb;
  });

  const tarjetas = ordenados.map(function (t) {
    const colorEstado = COLOR_POR_ESTADO_CONDUCTOR[t.estado_actual] || 'gris';
    const esAccionable = accionables.indexOf(t.estado_actual) !== -1;
    return (
      '<div class="tarjeta tarjeta-traslado" onclick="verTrasladoConductor(\'' + t.folio + '\')">' +
        '<div style="display:flex; justify-content:space-between; align-items:center;">' +
          '<strong>' + escaparHtml(t.folio) + '</strong>' +
          '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
        '</div>' +
        '<div style="color:var(--gris); font-size:14px; margin-top:4px;">' +
          'Cita: ' + escaparHtml(formatearFechaConductor(t.fecha_cita)) + ' ' + escaparHtml(t.hora_cita || '') +
        '</div>' +
        (esAccionable ? '<div style="color:var(--color-primario); font-size:13px; margin-top:6px; font-weight:600;">Toca para registrar datos →</div>' : '') +
      '</div>'
    );
  }).join('');

  contenedor.innerHTML = encabezadoConductor() + tarjetas;
}

function formatearFechaConductor(valor) {
  if (!valor) return '';
  const fecha = fechaLocalDesdeSoloFecha(valor);
  if (isNaN(fecha.getTime())) return valor;
  return fecha.toLocaleDateString('es-MX');
}

function verTrasladoConductor(folio) {
  document.getElementById('contenedor-conductor').innerHTML = encabezadoConductor() + '<p>Cargando traslado...</p>';

  google.script.run
    .withSuccessHandler(renderizarDetalleConductor)
    .withFailureHandler(function (error) {
      document.getElementById('contenedor-conductor').innerHTML = encabezadoConductor() + '<p>Error: ' + escaparHtml(error.message) + '</p>';
    })
    .obtenerTraslado(folio);
}

function renderizarDetalleConductor(t) {
  const colorEstado = COLOR_POR_ESTADO_CONDUCTOR[t.estado_actual] || 'gris';
  const enCurso = ESTADOS_RASTREABLES.indexOf(t.estado_actual) !== -1;

  const html =
    encabezadoConductor() +
    '<button onclick="cargarMisTraslados()" style="margin-bottom:12px;">← Volver a mis traslados</button>' +
    (enCurso ? '<div id="indicador-rastreo"><span class="punto-rastreo"></span>Compartiendo tu ubicación con la coordinación mientras dura el traslado</div>' : '') +
    '<div class="tarjeta">' +
      '<div style="display:flex; justify-content:space-between;">' +
        '<h2 style="margin:0;">' + escaparHtml(t.folio) + '</h2>' +
        '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
      '</div>' +
      '<p style="color:var(--gris);">Cita: ' + escaparHtml(formatearFechaConductor(t.fecha_cita)) + ' ' + escaparHtml(t.hora_cita || '') +
        ' · Motivo: ' + escaparHtml(t.motivo_traslado || '') + '</p>' +
      (t.id_vehiculo ? '<p>Vehículo: ' + escaparHtml(t.id_vehiculo) + '</p>' : '') +
    '</div>' +
    '<div class="tarjeta">' + construirAccionesConductor(t) + '</div>';

  document.getElementById('contenedor-conductor').innerHTML = html;

  if (enCurso) {
    iniciarRastreoUbicacion(t.folio);
  } else {
    detenerRastreoUbicacion();
  }
}

function construirAccionesConductor(t) {
  const estado = t.estado_actual;

  if (estado === 'Vehículo asignado') {
    return '<h3>Registrar salida</h3>' +
      '<button class="primario grande" onclick="accionRegistrarSalidaConductor(\'' + t.folio + '\')">Registrar salida</button>';
  }

  if (estado === 'En traslado') {
    return '<h3>Registrar llegada a destino</h3>' +
      '<button class="primario grande" onclick="accionRegistrarLlegadaConductor(\'' + t.folio + '\')">Registrar llegada</button>';
  }

  if (estado === 'En destino') {
    return '<h3>Registrar regreso</h3>' +
      '<button class="primario grande" onclick="accionRegistrarRegresoConductor(\'' + t.folio + '\')">Registrar salida de destino y llegada</button>';
  }

  return '<p style="color:var(--gris);">Este traslado no requiere que captures datos del vehículo en este momento.</p>';
}

function accionRegistrarSalidaConductor(folio) {
  google.script.run
    .withSuccessHandler(function () { verTrasladoConductor(folio); })
    .withFailureHandler(function (e) { alert(e.message); })
    .registrarSalida(folio, {});
}

function accionRegistrarLlegadaConductor(folio) {
  google.script.run
    .withSuccessHandler(function () { verTrasladoConductor(folio); })
    .withFailureHandler(function (e) { alert(e.message); })
    .registrarLlegadaDestino(folio, {});
}

function accionRegistrarRegresoConductor(folio) {
  google.script.run
    .withSuccessHandler(function () { verTrasladoConductor(folio); })
    .withFailureHandler(function (e) { alert(e.message); })
    .registrarRegreso(folio, {});
}

/* ------------------------------------------------------------------ *
 * Rastreo de ubicación (GPS)
 *
 * Solo se activa mientras el conductor tiene abierta la pantalla de un
 * traslado en alguno de los estados "en curso" (ver ESTADOS_RASTREABLES).
 * Envía la posición cada INTERVALO_RASTREO_MS al backend.
 *
 * Importante: por restricciones del navegador, esto SOLO funciona con la
 * pantalla encendida y la app en primer plano — se detiene si el
 * conductor bloquea el teléfono o cambia de app.
 * ------------------------------------------------------------------ */

const ESTADOS_RASTREABLES = ['En traslado', 'Regresando'];
const INTERVALO_RASTREO_MS = 240000; // 4 minutos
let TEMPORIZADOR_RASTREO = null;
let FOLIO_RASTREADO_ACTUAL = null;

function iniciarRastreoUbicacion(folio) {
  // Si ya se está rastreando este mismo folio, no reinicia nada.
  if (TEMPORIZADOR_RASTREO && FOLIO_RASTREADO_ACTUAL === folio) return;

  detenerRastreoUbicacion();

  if (!('geolocation' in navigator)) {
    mostrarAvisoRastreo('Este teléfono/navegador no permite compartir ubicación.', true);
    return;
  }

  FOLIO_RASTREADO_ACTUAL = folio;
  enviarUbicacionActual(folio); // primer reporte inmediato
  TEMPORIZADOR_RASTREO = setInterval(function () {
    enviarUbicacionActual(folio);
  }, INTERVALO_RASTREO_MS);
}

function detenerRastreoUbicacion() {
  if (TEMPORIZADOR_RASTREO) {
    clearInterval(TEMPORIZADOR_RASTREO);
    TEMPORIZADOR_RASTREO = null;
  }
  FOLIO_RASTREADO_ACTUAL = null;
}

function enviarUbicacionActual(folio) {
  navigator.geolocation.getCurrentPosition(
    function (posicion) {
      // Si mientras tanto el conductor navegó a otro traslado (o salió),
      // este reporte ya no aplica.
      if (FOLIO_RASTREADO_ACTUAL !== folio) return;

      google.script.run
        .withSuccessHandler(function () { mostrarAvisoRastreo(null); })
        .withFailureHandler(function (error) {
          mostrarAvisoRastreo('No se pudo enviar la ubicación: ' + error.message, true);
        })
        .registrarUbicacionConductor(folio, {
          lat: posicion.coords.latitude,
          lng: posicion.coords.longitude,
          precision_metros: Math.round(posicion.coords.accuracy || 0),
          marca_tiempo: new Date().toISOString()
        });
    },
    function (error) {
      const mensajes = {
        1: 'Activa el permiso de ubicación para que la coordinación te vea en el mapa.',
        2: 'No se pudo obtener tu ubicación (señal GPS débil).',
        3: 'Tardó demasiado en obtener tu ubicación, se reintentará.'
      };
      mostrarAvisoRastreo(mensajes[error.code] || 'No se pudo obtener tu ubicación.', true);
    },
    { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 }
  );
}

function mostrarAvisoRastreo(mensaje, esError) {
  const indicador = document.getElementById('indicador-rastreo');
  if (!indicador) return; // el conductor ya salió de esta pantalla
  if (!mensaje) {
    indicador.classList.remove('error');
    indicador.innerHTML = '<span class="punto-rastreo"></span>Compartiendo tu ubicación con la coordinación mientras dura el traslado';
    return;
  }
  indicador.classList.add('error');
  indicador.innerHTML = '⚠️ ' + escaparHtml(mensaje);
}
