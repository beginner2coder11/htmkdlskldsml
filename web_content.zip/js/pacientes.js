  function cargarVistaPacientes() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Pacientes</h2>' +
        '<button class="primario" onclick="mostrarFormularioPaciente()">+ Nuevo paciente</button>' +
      '</div>' +
      '<input type="text" id="buscador-pacientes" placeholder="Buscar por nombre, comunidad o teléfono..." ' +
        'style="width:100%; padding:10px; margin-bottom:12px; border:1px solid var(--color-borde); border-radius:8px;" ' +
        'oninput="buscarPacientes(this.value)">' +
      '<div id="lista-pacientes">Cargando...</div>';

    buscarPacientes('');
  }

  function buscarPacientes(texto) {
    google.script.run
      .withSuccessHandler(renderizarListaPacientes)
      .withFailureHandler(function (error) {
        document.getElementById('lista-pacientes').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>';
      })
      .listarPacientes(texto);
  }

  function renderizarListaPacientes(pacientes) {
    const contenedor = document.getElementById('lista-pacientes');
    if (!pacientes.length) {
      contenedor.innerHTML = '<div class="tarjeta estado-vacio"><span class="icono-vacio">👤</span>No se encontraron pacientes.</div>';
      return;
    }
    contenedor.innerHTML = pacientes.map(function (p) {
      return (
        '<div class="tarjeta" style="cursor:pointer;" onclick="mostrarDetallePaciente(\'' + p.id_paciente + '\')">' +
          '<strong>' + escaparHtml(p.nombre_completo) + '</strong>' +
          '<div style="color:var(--gris); font-size:13px;">' +
            escaparHtml(p.comunidad || '') +
            (p.telefono ? ' · ' + escaparHtml(p.telefono) : '') +
          '</div>' +
        '</div>'
      );
    }).join('');
  }

  function mostrarDetallePaciente(idPaciente) {
    google.script.run
      .withSuccessHandler(function (paciente) {
        google.script.run
          .withSuccessHandler(function (traslados) {
            const deEstePaciente = traslados
              .filter(function (t) { return t.id_paciente === idPaciente; })
              .sort(function (a, b) { return new Date(b.fecha_solicitud) - new Date(a.fecha_solicitud); });
            renderizarDetallePaciente(paciente, deEstePaciente[0]);
          })
          .withFailureHandler(function () { renderizarDetallePaciente(paciente, null); })
          .listarTraslados({});
      })
      .withFailureHandler(function (error) { alert(error.message); })
      .obtenerPaciente(idPaciente);
  }

  function renderizarDetallePaciente(paciente, solicitud) {
    const puedeEditar = SESION.rol === 'Administrador' || SESION.rol === 'Coordinador';
    const fila = function (etiqueta, valor) {
      return valor ? '<p><strong>' + etiqueta + ':</strong> ' + escaparHtml(valor) + '</p>' : '';
    };

    let htmlSolicitud = '';
    if (solicitud) {
      const institucion = solicitud.institucion_nombre ||
        (solicitud.institucion_otra_nombre ? solicitud.institucion_otra_nombre + ' (otra)' : '');
      htmlSolicitud =
        '<h4 style="margin-bottom:6px;">Datos de la solicitud (folio ' + escaparHtml(solicitud.folio) + ')</h4>' +
        fila('Acompañante', solicitud.acompanante_nombre) +
        fila('Parentesco', solicitud.acompanante_parentesco) +
        fila('Teléfono del acompañante', solicitud.acompanante_telefono) +
        fila('Institución', institucion) +
        fila('Especialidad', solicitud.especialidad) +
        fila('Fecha del traslado', formatearFechaDDMMYYYY(solicitud.fecha_cita)) +
        fila('Hora de la cita', solicitud.hora_cita) +
        fila('Motivo del traslado', solicitud.motivo_traslado);
    }

    const html =
      '<div class="tarjeta">' +
        '<h3 style="margin-top:0;">' + escaparHtml(paciente.nombre_completo) + '</h3>' +
        fila('Comunidad', paciente.comunidad) +
        fila('Teléfono', paciente.telefono) +
        (htmlSolicitud ? '<hr style="margin:14px 0; border:none; border-top:1px solid var(--color-borde);">' + htmlSolicitud
          : '<p style="color:var(--gris);">Este paciente no tiene solicitudes registradas.</p>') +
        '<div style="margin-top:12px; display:flex; gap:8px;">' +
          (puedeEditar ? '<button class="primario" onclick="mostrarFormularioPaciente(\'' + paciente.id_paciente + '\')">Editar</button>' : '') +
          (puedeEditar ? '<button onclick="confirmarEliminarPaciente(\'' + paciente.id_paciente + '\', ' + JSON.stringify(paciente.nombre_completo).replace(/"/g, '&quot;') + ')" style="color:#b42318;">Eliminar</button>' : '') +
          '<button onclick="cargarVistaPacientes()">Volver</button>' +
        '</div>' +
      '</div>';
    document.getElementById('contenido-principal').innerHTML = html;
  }

  function confirmarEliminarPaciente(idPaciente, nombre) {
    if (!confirm('¿Eliminar a ' + nombre + '? Esto no borra sus traslados ya registrados, pero no podrás deshacerlo.')) return;
    google.script.run
      .withSuccessHandler(function () { cargarVistaPacientes(); })
      .withFailureHandler(function (e) { alert(e.message); })
      .eliminarPaciente(idPaciente);
  }

  function mostrarFormularioPaciente(idPaciente) {
    if (idPaciente) {
      google.script.run
        .withSuccessHandler(function (paciente) { renderizarFormularioPaciente(paciente); })
        .withFailureHandler(function (error) { alert(error.message); })
        .obtenerPaciente(idPaciente);
    } else {
      renderizarFormularioPaciente(null);
    }
  }

  function renderizarFormularioPaciente(paciente) {
    const esEdicion = !!paciente;
    paciente = paciente || {};

    const html =
      '<div class="tarjeta">' +
        '<h3>' + (esEdicion ? 'Editar paciente' : 'Nuevo paciente') + '</h3>' +
        campoTexto('pf-nombre', 'Nombre completo', paciente.nombre_completo) +
        campoTexto('pf-comunidad', 'Comunidad', paciente.comunidad) +
        campoTexto('pf-telefono', 'Teléfono', paciente.telefono) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarPaciente(' + (esEdicion ? "'" + paciente.id_paciente + "'" : 'null') + ')">Guardar</button> ' +
          '<button onclick="cargarVistaPacientes()">Cancelar</button>' +
        '</div>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarPaciente(idPaciente) {
    const datos = {
      nombre_completo: document.getElementById('pf-nombre').value,
      comunidad: document.getElementById('pf-comunidad').value,
      telefono: document.getElementById('pf-telefono').value
    };

    if (!datos.nombre_completo) {
      alert('El nombre del paciente es obligatorio.');
      return;
    }

    const llamada = idPaciente
      ? google.script.run.withSuccessHandler(function () { cargarVistaPacientes(); }).withFailureHandler(function (e) { alert(e.message); }).actualizarPaciente(idPaciente, datos)
      : google.script.run.withSuccessHandler(function () { cargarVistaPacientes(); }).withFailureHandler(function (e) { alert(e.message); }).crearPaciente(datos);
  }

  // ---- Helpers de campos de formulario reutilizables en todo el sistema ----
  function campoTexto(id, etiqueta, valor) {
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<input type="text" id="' + id + '" value="' + escaparHtml(valor || '') + '" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;"></div>';
  }
  function campoTextarea(id, etiqueta, valor) {
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<textarea id="' + id + '" rows="2" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' + escaparHtml(valor || '') + '</textarea></div>';
  }
  function campoFecha(id, etiqueta, valor) {
    const valorFormateado = valor ? new Date(valor).toISOString().substring(0, 10) : '';
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<input type="date" id="' + id + '" value="' + valorFormateado + '" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;"></div>';
  }
  function campoSelect(id, etiqueta, opciones, valorSeleccionado, incluirVacio) {
    const opcionesHtml = (incluirVacio ? ['<option value="">Selecciona...</option>'] : [])
      .concat(opciones.map(function (op) {
        return '<option value="' + escaparHtml(op) + '"' + (op === valorSeleccionado ? ' selected' : '') + '>' + escaparHtml(op) + '</option>';
      })).join('');
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<select id="' + id + '" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' + opcionesHtml + '</select></div>';
  }
