  let DASHBOARD_DATOS = null;
  let DASHBOARD_CATEGORIA_ABIERTA = null;
  let DASHBOARD_INTERVALO_POLLING = null;

  const ETIQUETAS_CATEGORIA = {
    solicitudesPendientes: 'Solicitudes pendientes',
    trasladosHoy: 'Traslados de hoy',
    programados: 'Programados',
    enCurso: 'En curso',
    finalizados: 'Finalizados',
    cancelados: 'Cancelados'
  };

  function cargarVistaDashboard() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML = '<p>Cargando dashboard...</p>';
    DASHBOARD_CATEGORIA_ABIERTA = null;

    google.script.run
      .withSuccessHandler(function (datos) {
        DASHBOARD_DATOS = datos;
        renderizarDashboard(datos);
        iniciarPollingSolicitudes();
      })
      .withFailureHandler(function (error) { contenedor.innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>'; })
      .obtenerDatosDashboard();
  }

  /**
   * Revisa cada 15 segundos si cambió el número de solicitudes pendientes
   * mientras el usuario sigue viendo el Dashboard, para que la tarjeta
   * roja se actualice (y deje de parpadear) sin tener que recargar la
   * página. Se detiene automáticamente al salir del módulo (ver app.js).
   */
  function iniciarPollingSolicitudes() {
    detenerPollingDashboard();
    DASHBOARD_INTERVALO_POLLING = setInterval(function () {
      google.script.run
        .withSuccessHandler(function (conteo) {
          if (!DASHBOARD_DATOS) return;
          if (DASHBOARD_DATOS.kpis.solicitudesPendientes === conteo) return; // sin cambios, no vuelve a dibujar
          DASHBOARD_DATOS.kpis.solicitudesPendientes = conteo;
          actualizarTarjetaSolicitudes(conteo);
        })
        .withFailureHandler(function () { /* silencioso: un fallo de polling no debe interrumpir al usuario */ })
        .obtenerConteoSolicitudesPendientes();
    }, 15000);
  }

  function detenerPollingDashboard() {
    if (DASHBOARD_INTERVALO_POLLING) {
      clearInterval(DASHBOARD_INTERVALO_POLLING);
      DASHBOARD_INTERVALO_POLLING = null;
    }
  }

  function actualizarTarjetaSolicitudes(conteo) {
    const tarjeta = document.getElementById('tarjeta-solicitudes');
    if (!tarjeta) return;
    tarjeta.classList.toggle('parpadea', conteo > 0);
    const valor = tarjeta.querySelector('.valor-kpi');
    if (valor) valor.textContent = conteo;
    // Si el usuario tenía el desglose de solicitudes abierto, lo refresca
    // pidiendo el dashboard completo (para traer los folios actualizados).
    if (DASHBOARD_CATEGORIA_ABIERTA === 'solicitudesPendientes') {
      google.script.run.withSuccessHandler(function (datos) {
        DASHBOARD_DATOS = datos;
        renderizarDesglose('solicitudesPendientes');
      }).withFailureHandler(function () {}).obtenerDatosDashboard();
    }
  }

  function renderizarDashboard(datos) {
    const k = datos.kpis;

    const tarjetaSolicitudes =
      '<div class="tarjeta tarjeta-kpi tarjeta-solicitudes' + (k.solicitudesPendientes > 0 ? ' parpadea' : '') + '" id="tarjeta-solicitudes" onclick="toggleDesgloseCategoria(\'solicitudesPendientes\')">' +
        '<div class="icono-kpi" style="background:var(--rojo-suave); color:var(--rojo);">🔔</div>' +
        '<div><div class="valor-kpi">' + k.solicitudesPendientes + '</div><div class="etiqueta-kpi">Solicitudes pendientes</div></div>' +
      '</div>';

    const tarjetaKpi = function (clave, etiqueta, valor, icono, colorClave) {
      return '<div class="tarjeta tarjeta-kpi" style="cursor:pointer;" onclick="toggleDesgloseCategoria(\'' + clave + '\')">' +
        '<div class="icono-kpi" style="background:var(--' + colorClave + '-suave); color:var(--' + colorClave + ');">' + icono + '</div>' +
        '<div><div class="valor-kpi">' + valor + '</div><div class="etiqueta-kpi">' + etiqueta + '</div></div>' +
      '</div>';
    };

    const grillaKpis =
      '<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:10px; margin-bottom:8px;">' +
        tarjetaSolicitudes +
        tarjetaKpi('trasladosHoy', 'Traslados hoy', k.trasladosHoy, '📋', 'azul') +
        tarjetaKpi('programados', 'Programados', k.programados, '🗓️', 'azul') +
        tarjetaKpi('enCurso', 'En curso', k.enCurso, '🚑', 'ambar') +
        tarjetaKpi('finalizados', 'Finalizados', k.finalizados, '✅', 'verde') +
        tarjetaKpi('cancelados', 'Cancelados', k.cancelados, '✖️', 'rojo') +
      '</div>' +
      '<div id="desglose-dashboard"></div>';

    const alertas = (datos.alertasVehiculos || []).map(function (a) {
      return '<div class="tarjeta" style="border-left:4px solid var(--ambar); display:flex; align-items:center; gap:10px;"><span style="font-size:18px;">⚠️</span><span>' + escaparHtml(a.mensaje) + '</span></div>';
    }).join('');

    const proximos = (datos.proximosTraslados || []).map(function (t) {
      const colorEstado = COLOR_POR_ESTADO[t.estado_actual] || 'gris';
      return (
        '<div class="tarjeta" style="cursor:pointer; display:flex; justify-content:space-between; align-items:center;" onclick="navegarA(\'traslados\'); setTimeout(function(){verDetalleTraslado(\'' + t.folio + '\')}, 50)">' +
          '<div><strong>' + escaparHtml(t.folio) + '</strong><div style="font-size:13px; color:var(--gris); margin-top:2px;">' +
            escaparHtml(t.paciente) + ' · ' + escaparHtml(t.institucion) + ' · ' + escaparHtml(formatearFecha(t.fecha_cita)) + '</div></div>' +
          '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
        '</div>'
      );
    }).join('') || '<div class="tarjeta estado-vacio"><span class="icono-vacio">🚑</span>No hay traslados próximos.</div>';

    const filasPorMes = Object.keys(datos.trasladosPorMes || {}).sort();
    const filasPorInstitucion = Object.keys(datos.trasladosPorInstitucion || {});

    document.getElementById('contenido-principal').innerHTML =
      '<h2>Dashboard</h2>' +
      grillaKpis +
      alertas +
      '<h3>Próximos traslados</h3>' +
      proximos +
      '<h3>Traslados por mes</h3>' +
      '<div id="grafica-por-mes" style="height:220px;"></div>' +
      '<h3>Traslados por institución</h3>' +
      '<div id="grafica-por-institucion" style="height:220px;"></div>';

    dibujarBarras('grafica-por-mes', filasPorMes, filasPorMes.map(function (m) { return datos.trasladosPorMes[m]; }));
    dibujarBarras('grafica-por-institucion', filasPorInstitucion, filasPorInstitucion.map(function (i) { return datos.trasladosPorInstitucion[i]; }));

    if (DASHBOARD_CATEGORIA_ABIERTA) renderizarDesglose(DASHBOARD_CATEGORIA_ABIERTA);
  }

  /**
   * Al tocar una tarjeta, muestra/oculta debajo de la grilla la lista de
   * traslados que forman ese número. Tocar la misma tarjeta otra vez
   * la cierra.
   */
  function toggleDesgloseCategoria(categoria) {
    DASHBOARD_CATEGORIA_ABIERTA = (DASHBOARD_CATEGORIA_ABIERTA === categoria) ? null : categoria;
    renderizarDesglose(DASHBOARD_CATEGORIA_ABIERTA);
  }

  function renderizarDesglose(categoria) {
    const zona = document.getElementById('desglose-dashboard');
    if (!zona) return;

    if (!categoria || !DASHBOARD_DATOS) { zona.innerHTML = ''; return; }

    const items = (DASHBOARD_DATOS.desglose && DASHBOARD_DATOS.desglose[categoria]) || [];

    const filas = items.map(function (t) {
      const colorEstado = COLOR_POR_ESTADO[t.estado_actual] || 'gris';
      return (
        '<div class="tarjeta" style="padding:10px 14px; cursor:pointer;" onclick="navegarA(\'traslados\'); setTimeout(function(){verDetalleTraslado(\'' + t.folio + '\')}, 50)">' +
          '<div style="display:flex; justify-content:space-between;">' +
            '<strong>' + escaparHtml(t.folio) + '</strong>' +
            '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
          '</div>' +
          '<div style="font-size:12px; color:var(--gris); margin-top:2px;">' +
            escaparHtml(t.paciente) + (t.institucion ? ' · ' + escaparHtml(t.institucion) : '') +
            (t.fecha_cita ? ' · ' + escaparHtml(formatearFecha(t.fecha_cita)) : '') +
          '</div>' +
        '</div>'
      );
    }).join('') || '<div class="tarjeta estado-vacio">Sin registros en esta categoría.</div>';

    zona.innerHTML =
      '<div class="tarjeta" style="background:var(--color-fondo); border-style:dashed; margin-bottom:14px;">' +
        '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">' +
          '<strong>' + escaparHtml(ETIQUETAS_CATEGORIA[categoria] || categoria) + '</strong>' +
          '<button onclick="toggleDesgloseCategoria(\'' + categoria + '\')" style="padding:4px 10px; font-size:12px;">Cerrar ✕</button>' +
        '</div>' +
        filas +
      '</div>';

    zona.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /**
   * Gráfica de barras simple en SVG, sin dependencias externas.
   */
  function dibujarBarras(idContenedor, etiquetas, valores) {
    const contenedor = document.getElementById(idContenedor);
    if (!etiquetas.length) { contenedor.innerHTML = '<div class="estado-vacio">Sin datos suficientes todavía.</div>'; return; }

    const maxValor = Math.max.apply(null, valores) || 1;
    const anchoBarra = 100 / etiquetas.length;
    const altoGrafica = 95;

    const barras = etiquetas.map(function (etiqueta, i) {
      const alturaBarra = (valores[i] / maxValor) * altoGrafica;
      const x = i * anchoBarra;
      const y = altoGrafica - alturaBarra;
      return (
        '<rect x="' + (x + anchoBarra * 0.15).toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + (anchoBarra * 0.7).toFixed(1) + '" height="' + alturaBarra.toFixed(1) + '" fill="#1d6f5c" rx="1"></rect>' +
        '<text x="' + (x + anchoBarra * 0.5).toFixed(1) + '" y="' + (altoGrafica - 2) + '" font-size="4" text-anchor="middle" fill="#ffffff">' + escaparHtml(String(valores[i])) + '</text>'
      );
    }).join('');

    const etiquetasEje = etiquetas.map(function (etiqueta, i) {
      const x = i * anchoBarra + anchoBarra * 0.5;
      return '<text x="' + x.toFixed(1) + '" y="112" font-size="4" text-anchor="middle" fill="#6b7280">' + escaparHtml(String(etiqueta).substring(0, 10)) + '</text>';
    }).join('');

    contenedor.innerHTML =
      '<svg viewBox="0 0 100 120" style="width:100%; height:100%;" preserveAspectRatio="none">' + barras + etiquetasEje + '</svg>';
  }
