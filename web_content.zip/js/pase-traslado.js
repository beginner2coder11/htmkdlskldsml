// Genera el PDF "Tu Pase de Traslados" (el formato oficial impreso) ya
// llenado con los datos de un traslado/solicitud, para imprimirlo y
// recabar las firmas de quien solicita y quien autoriza.
//
// Cómo funciona: se parte de la plantilla en blanco
// (plantillas/pase-traslados.pdf, una página de 612x408pt) y se dibuja
// texto encima con pdf-lib, en las coordenadas donde caen los recuadros
// del diseño. Si el diseño de la plantilla cambia (se mueve o cambia de
// tamaño algún recuadro), hay que volver a medir y ajustar CAMPOS_PASE.

const RUTA_PLANTILLA_PASE = 'plantillas/pase-traslados.pdf';

// Recuadros que ya vienen vacíos en la plantilla (fondo verde claro):
// basta con escribir el texto encima, alineado a la izquierda.
// x, y = esquina inferior izquierda del texto (línea base), en puntos PDF.
// width = ancho disponible del recuadro, para achicar/truncar si no cabe.
const CAMPOS_TEXTO_PASE = {
  folio:               { x: 515.0, y: 367.8, width: 80,  size: 10,  bold: true },
  nombreCompleto:      { x: 151.5, y: 276.1, width: 167, size: 9.5 },
  telefonoContacto:    { x: 442.4, y: 276.1, width: 155, size: 9.5 },
  nombreAcompanante:   { x: 151.5, y: 256.4, width: 167, size: 9.5 },
  telefonoAcompanante: { x: 453.4, y: 256.4, width: 144, size: 9.5 },
  parentesco:          { x: 151.5, y: 236.7, width: 167, size: 9.5 },
  comunidad:           { x: 153.0, y: 216.6, width: 442, size: 9.5 },
  institucion:         { x: 193.3, y: 193.0, width: 402, size: 9.5 },
  especialidad:        { x: 148.2, y: 172.9, width: 447, size: 9.5 },
  motivoTraslado:      { x: 454.9, y: 136.4, width: 142, size: 9 },
  observaciones:       { x: 141.0, y: 111.4, width: 456, size: 9 }
};

// Recuadros que en la plantilla YA traen texto preimpreso (los guiones
// "___/___/2026" de las fechas). Para estos, primero se cubre el recuadro
// con un rectángulo blanco y luego se escribe la fecha/hora completa,
// centrada.
const CAMPOS_FECHA_PASE = {
  fechaSolicitud: { x: 456.4, yBottom: 313.0, width: 136.0, height: 22.0, size: 13, bold: true },
  fechaTraslado:  { x: 120.5, yBottom: 132.0, width: 97.4,  height: 21.6, size: 12, bold: true },
  horaCita:       { x: 299.0, yBottom: 132.0, width: 51.8,  height: 21.6, size: 11, bold: true }
};

// Línea sobre la que va cada firma (misma altura para ambas). "Quien
// solicita" se firma a mano encima de la X (solo marca dónde firmar).
// "Quien autoriza" se llena con el nombre de quien autorizó el traslado
// en el sistema (queda escrito, no necesita firma física).
// NOTA: LINEA_FIRMA_Y se recalibró (de 66.5 a 84.5) cuando se actualizó
// la plantilla — el diseño nuevo subió un poco el recuadro de firmas.
// xCentro/width de ambos recuadros se volvieron a medir sobre el PDF real
// (los valores anteriores, 198/378, quedaban ~15-20pt a la izquierda del
// centro real de cada caja — no se notaba con una sola "X" o un nombre
// corto, pero sí con el texto de 3 líneas de la aceptación electrónica).
const LINEA_FIRMA_Y = 84.5;
const CAMPOS_FIRMA_PASE = {
  quienSolicita: { xCentro: 218.5, width: 145 },
  quienAutoriza: { xCentro: 393.5, width: 145 }
};

let CONTEXTO_PASE_TRASLADO = null;

async function generarPaseTraslado(t, paciente, institucion) {
  const respuesta = await fetch(RUTA_PLANTILLA_PASE);
  if (!respuesta.ok) {
    throw new Error('No se encontró la plantilla del pase (' + RUTA_PLANTILLA_PASE + ').');
  }
  const bytesPlantilla = await respuesta.arrayBuffer();

  const { PDFDocument, StandardFonts, rgb } = PDFLib;
  const pdfDoc = await PDFDocument.load(bytesPlantilla);
  const pagina = pdfDoc.getPages()[0];
  const fuenteNormal = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fuenteNegrita = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fuenteCursiva = await pdfDoc.embedFont(StandardFonts.HelveticaOblique);
  const colorTexto = rgb(0.05, 0.08, 0.08);

  function ajustarYAcortar(texto, tamanoBase, anchoMaximo, fuente) {
    let tamano = tamanoBase;
    while (tamano > 6.5 && fuente.widthOfTextAtSize(texto, tamano) > anchoMaximo) {
      tamano -= 0.5;
    }
    while (texto.length > 1 && fuente.widthOfTextAtSize(texto, tamano) > anchoMaximo) {
      texto = texto.slice(0, -2).trimEnd() + '…';
    }
    return { texto: texto, tamano: tamano };
  }

  function escribirCampo(clave, valorCrudo) {
    const cfg = CAMPOS_TEXTO_PASE[clave];
    const valor = (valorCrudo == null ? '' : String(valorCrudo)).trim();
    if (!cfg || !valor) return;
    const fuente = cfg.bold ? fuenteNegrita : fuenteNormal;
    const ajustado = ajustarYAcortar(valor, cfg.size, cfg.width, fuente);
    pagina.drawText(ajustado.texto, { x: cfg.x, y: cfg.y, size: ajustado.tamano, font: fuente, color: colorTexto });
  }

  function escribirFecha(clave, valorCrudo) {
    const cfg = CAMPOS_FECHA_PASE[clave];
    const valor = (valorCrudo == null ? '' : String(valorCrudo)).trim();
    if (!cfg || !valor) return;
    const fuente = cfg.bold ? fuenteNegrita : fuenteNormal;

    // Cubre los guiones/año preimpresos con un rectángulo blanco.
    pagina.drawRectangle({
      x: cfg.x + 1, y: cfg.yBottom + 1,
      width: cfg.width - 2, height: cfg.height - 2,
      color: rgb(1, 1, 1)
    });

    const ajustado = ajustarYAcortar(valor, cfg.size, cfg.width - 6, fuente);
    const anchoTexto = fuente.widthOfTextAtSize(ajustado.texto, ajustado.tamano);
    const x = cfg.x + (cfg.width - anchoTexto) / 2;
    const y = cfg.yBottom + (cfg.height - ajustado.tamano) / 2 + 2;
    pagina.drawText(ajustado.texto, { x: x, y: y, size: ajustado.tamano, font: fuente, color: colorTexto });
  }

  escribirCampo('folio', t.folio);
  escribirFecha('fechaSolicitud', formatearFecha(t.fecha_solicitud));
  escribirCampo('nombreCompleto', paciente ? paciente.nombre_completo : '');
  escribirCampo('telefonoContacto', paciente ? paciente.telefono : '');
  escribirCampo('nombreAcompanante', t.acompanante_nombre);
  escribirCampo('telefonoAcompanante', t.acompanante_telefono);
  escribirCampo('parentesco', t.acompanante_parentesco);
  escribirCampo('comunidad', paciente ? paciente.comunidad : '');
  escribirCampo('institucion', institucion ? (institucion.nombre + (institucion.ciudad ? ' — ' + institucion.ciudad : '')) : (t.id_institucion || ''));
  escribirCampo('especialidad', t.especialidad);
  escribirFecha('fechaTraslado', formatearFecha(t.fecha_cita));
  escribirFecha('horaCita', t.hora_cita);
  escribirCampo('motivoTraslado', t.motivo_traslado);
  escribirCampo('observaciones', t.observaciones);

  // Firma de quien solicita: si la solicitud viene del formulario público
  // (ya aceptó los avisos electrónicamente al enviarla), se imprime esa
  // constancia en vez de dejar una X para firmar a mano. El folio NO se
  // incluye aquí (se conserva en su recuadro correspondiente arriba).
  // Si el traslado se dio de alta manualmente en el sistema (sin esa
  // aceptación electrónica), se conserva la X para firma física.
  //
  // NOTA DE ESPACIO: el recuadro de "MANIFESTACIÓN DE CONFORMIDAD" es muy
  // reducido. Debajo de la línea solo hay ~7pt libres antes de chocar con
  // el texto "MANIFESTACIÓN DE CONFORMIDAD" ya impreso en la plantilla, y
  // no hay espacio en blanco debajo del recuadro (la franja decorativa
  // empieza justo ahí). Por eso estas 3 líneas se colocan arriba de la
  // línea (único espacio libre real del recuadro), con fuente recta en
  // mayúsculas/minúsculas normales (no cursiva) para que no parezca una
  // firma a mano.
  const cfgX = CAMPOS_FIRMA_PASE.quienSolicita;

  function centrarEnFirma(texto, y, tamano, fuente) {
    const ajustado = ajustarYAcortar(texto, tamano, cfgX.width, fuente);
    const ancho = fuente.widthOfTextAtSize(ajustado.texto, ajustado.tamano);
    pagina.drawText(ajustado.texto, {
      x: cfgX.xCentro - ancho / 2, y: y, size: ajustado.tamano, font: fuente, color: colorTexto
    });
  }

  // Admite el esquema nuevo (fecha_aceptacion / hora_aceptacion, ya
  // formateados como texto) y, por compatibilidad, el esquema anterior de
  // solicitudes históricas (fecha_consentimiento, un timestamp completo).
  let fechaAceptacionTexto = '';
  let horaAceptacionTexto = '';
  if (t.fecha_aceptacion) {
    fechaAceptacionTexto = t.fecha_aceptacion;
    horaAceptacionTexto = t.hora_aceptacion || '';
  } else if (t.fecha_consentimiento) {
    const fc = new Date(t.fecha_consentimiento);
    if (!isNaN(fc.getTime())) {
      fechaAceptacionTexto = fc.toLocaleDateString('es-MX');
      horaAceptacionTexto = fc.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
    }
  }

  if (fechaAceptacionTexto) {
    centrarEnFirma('ACEPTACIÓN REGISTRADA ELECTRÓNICAMENTE', LINEA_FIRMA_Y + 10.5, 4.8, fuenteNegrita);
    centrarEnFirma('Fecha: ' + fechaAceptacionTexto, LINEA_FIRMA_Y + 6.0, 5.2, fuenteNormal);
    centrarEnFirma('Hora: ' + horaAceptacionTexto, LINEA_FIRMA_Y + 1.2, 5.2, fuenteNormal);
  } else {
    const anchoX = fuenteNegrita.widthOfTextAtSize('X', 16);
    pagina.drawText('X', {
      x: cfgX.xCentro - anchoX / 2, y: LINEA_FIRMA_Y + 3, size: 16, font: fuenteNegrita, color: colorTexto
    });
  }

  // Firma de quien autoriza: se imprime el nombre de quien autorizó el
  // traslado en el sistema (si ya fue autorizado).
  if (t.autorizado_por) {
    const cfgAut = CAMPOS_FIRMA_PASE.quienAutoriza;
    const ajustado = ajustarYAcortar(String(t.autorizado_por).trim(), 10, cfgAut.width, fuenteCursiva);
    const anchoTexto = fuenteCursiva.widthOfTextAtSize(ajustado.texto, ajustado.tamano);
    pagina.drawText(ajustado.texto, {
      x: cfgAut.xCentro - anchoTexto / 2, y: LINEA_FIRMA_Y + 3, size: ajustado.tamano, font: fuenteCursiva, color: colorTexto
    });
  }

  return pdfDoc.save();
}

function bytesABase64(bytes) {
  let binario = '';
  const trozo = 0x8000;
  for (let i = 0; i < bytes.length; i += trozo) {
    binario += String.fromCharCode.apply(null, bytes.subarray(i, i + trozo));
  }
  return btoa(binario);
}

function base64ABytes(base64) {
  const binario = atob(base64);
  const bytes = new Uint8Array(binario.length);
  for (let i = 0; i < binario.length; i++) bytes[i] = binario.charCodeAt(i);
  return bytes;
}

function generarYAbrirPaseTraslado() {
  if (!CONTEXTO_PASE_TRASLADO) return;
  const boton = event.target;
  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = 'Generando...';

  const t = CONTEXTO_PASE_TRASLADO.t;

  generarPaseTraslado(t, CONTEXTO_PASE_TRASLADO.paciente, CONTEXTO_PASE_TRASLADO.institucion)
    .then(function (bytes) {
      const blob = new Blob([bytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      boton.disabled = false;
      boton.textContent = textoOriginal;

      // Guarda una copia (los DATOS, no el PDF ya renderizado — ver nota
      // en guardarPasePrimeraVez) en "Pases de traslados" — solo si el
      // traslado ya está autorizado y solo la primera vez (el backend lo
      // verifica). No bloquea ni retrasa la apertura del PDF: se hace en
      // segundo plano. Si falla, sí avisa (para poder detectarlo) pero no
      // interrumpe: el PDF ya se abrió de todos modos.
      if (t.autorizado_por) {
        google.script.run
          .withSuccessHandler(function (resultado) {
            // Si se guardó (primera vez), el botón desaparece de una vez,
            // sin esperar a que se vuelva a abrir el detalle.
            if (resultado && resultado.guardado && boton.isConnected) {
              boton.outerHTML = '<span style="font-size:12.5px; color:var(--gris);">✅ Pase generado — está en "Pases de traslados"</span>';
            }
          })
          .withFailureHandler(function (error) {
            console.error('No se pudo guardar el pase en "Pases de traslados":', error);
            alert('El PDF se generó correctamente, pero no se pudo guardar una copia en "Pases de traslados": ' + error.message);
          })
          .guardarPasePrimeraVez(t.folio);
      }
    })
    .catch(function (error) {
      alert('No se pudo generar el pase: ' + error.message);
      boton.disabled = false;
      boton.textContent = textoOriginal;
    });
}
