// Calendario — cuadrícula de mes normal (domingo a sábado), con un punto
// de color por cada traslado con cita ese día (mismo color que su estado
// en el resto de la app). Al tocar un día se muestra abajo la lista de
// traslados con cita ese día.

let CALENDARIO_MES_ACTUAL = new Date();
let CALENDARIO_TRASLADOS = [];
let CALENDARIO_DIA_SELECCIONADO = null;

function cargarVistaCalendario() {
  const contenedor = document.getElementById('contenido-principal');
  contenedor.innerHTML = '<p>Cargando calendario...</p>';
  CALENDARIO_MES_ACTUAL = new Date();
  CALENDARIO_DIA_SELECCIONADO = new Date().getDate();
  cargarMesCalendario();
}

function cambiarMesCalendario(delta) {
  CALENDARIO_MES_ACTUAL.setMonth(CALENDARIO_MES_ACTUAL.getMonth() + delta);
  CALENDARIO_DIA_SELECCIONADO = null;
  cargarMesCalendario();
}

function cargarMesCalendario() {
  google.script.run
    .withSuccessHandler(function (traslados) {
      CALENDARIO_TRASLADOS = traslados;
      renderizarCalendario();
    })
    .withFailureHandler(function (error) {
      document.getElementById('contenido-principal').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>';
    })
    .listarTraslados({});
}

function seleccionarDiaCalendario(dia) {
  CALENDARIO_DIA_SELECCIONADO = (CALENDARIO_DIA_SELECCIONADO === dia) ? null : dia;
  renderizarCalendario();
}

function renderizarCalendario() {
  const anio = CALENDARIO_MES_ACTUAL.getFullYear();
  const mes = CALENDARIO_MES_ACTUAL.getMonth();
  const hoy = new Date();
  const esMesActual = hoy.getFullYear() === anio && hoy.getMonth() === mes;

  // Agrupa los traslados con cita este mes, por día del mes.
  const porDia = {};
  CALENDARIO_TRASLADOS.forEach(function (t) {
    if (!t.fecha_cita) return;
    const f = fechaLocalDesdeSoloFecha(t.fecha_cita);
    if (f.getFullYear() !== anio || f.getMonth() !== mes) return;
    const dia = f.getDate();
    (porDia[dia] = porDia[dia] || []).push(t);
  });

  const nombreMes = CALENDARIO_MES_ACTUAL.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });
  const encabezado =
    '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
      '<button onclick="cambiarMesCalendario(-1)">‹</button>' +
      '<h2 style="margin:0; text-transform:capitalize;">' + escaparHtml(nombreMes) + '</h2>' +
      '<button onclick="cambiarMesCalendario(1)">›</button>' +
    '</div>';

  const NOMBRES_DIA_SEMANA = ['D', 'L', 'M', 'M', 'J', 'V', 'S'];
  const encabezadoSemana =
    '<div class="cal-grid cal-encabezado-semana">' +
      NOMBRES_DIA_SEMANA.map(function (d) { return '<div class="cal-dia-semana">' + d + '</div>'; }).join('') +
    '</div>';

  // Arma las celdas: relleno del mes anterior, los días del mes, y
  // relleno del mes siguiente hasta completar semanas de 7.
  const primerDiaSemana = new Date(anio, mes, 1).getDay(); // 0 = domingo
  const diasEnMes = new Date(anio, mes + 1, 0).getDate();
  const diasEnMesAnterior = new Date(anio, mes, 0).getDate();
  const totalCeldas = Math.ceil((primerDiaSemana + diasEnMes) / 7) * 7;
  const diasFinales = totalCeldas - primerDiaSemana - diasEnMes;

  const celdas = [];
  for (let i = 0; i < primerDiaSemana; i++) {
    celdas.push({ numero: diasEnMesAnterior - primerDiaSemana + 1 + i, otroMes: true });
  }
  for (let dia = 1; dia <= diasEnMes; dia++) {
    celdas.push({ numero: dia, otroMes: false });
  }
  for (let i = 1; i <= diasFinales; i++) {
    celdas.push({ numero: i, otroMes: true });
  }

  const cuadricula =
    '<div class="cal-grid">' +
      celdas.map(function (c) {
        if (c.otroMes) {
          return '<div class="cal-dia cal-dia-otro-mes"><span class="cal-dia-numero">' + c.numero + '</span></div>';
        }
        const trasladosDia = porDia[c.numero] || [];
        const esHoy = esMesActual && hoy.getDate() === c.numero;
        const seleccionado = CALENDARIO_DIA_SELECCIONADO === c.numero;
        const puntosVisibles = trasladosDia.slice(0, 4);
        const puntos = puntosVisibles.map(function (t) {
          return '<span class="cal-punto badge-' + (COLOR_POR_ESTADO[t.estado_actual] || 'gris') + '"></span>';
        }).join('') + (trasladosDia.length > 4 ? '<span class="cal-punto-mas">+</span>' : '');

        return (
          '<div class="cal-dia' + (esHoy ? ' cal-dia-hoy' : '') + (seleccionado ? ' cal-dia-seleccionado' : '') + '" onclick="seleccionarDiaCalendario(' + c.numero + ')">' +
            '<span class="cal-dia-numero">' + c.numero + '</span>' +
            (trasladosDia.length ? '<div class="cal-puntos">' + puntos + '</div>' : '') +
          '</div>'
        );
      }).join('') +
    '</div>';

  let listaDia = '';
  if (CALENDARIO_DIA_SELECCIONADO) {
    const trasladosDia = porDia[CALENDARIO_DIA_SELECCIONADO] || [];
    const fechaSel = new Date(anio, mes, CALENDARIO_DIA_SELECCIONADO);
    listaDia =
      '<div style="margin-top:16px;">' +
        '<div style="font-weight:600; font-size:13.5px; color:var(--gris); margin-bottom:8px; text-transform:capitalize;">' +
          fechaSel.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' }) +
        '</div>' +
        (trasladosDia.length
          ? trasladosDia.map(function (t) {
              const colorEstado = COLOR_POR_ESTADO[t.estado_actual] || 'gris';
              return (
                '<div class="tarjeta" style="cursor:pointer;" onclick="navegarA(\'traslados\'); setTimeout(function(){verDetalleTraslado(\'' + t.folio + '\')}, 50)">' +
                  '<div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">' +
                    '<span>' + escaparHtml(t.hora_cita || '') + ' — ' + escaparHtml(t.folio) + '</span>' +
                    '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
                  '</div>' +
                '</div>'
              );
            }).join('')
          : '<div class="tarjeta estado-vacio" style="padding:18px;"><span class="icono-vacio">📅</span>Sin traslados con cita este día.</div>') +
      '</div>';
  }

  document.getElementById('contenido-principal').innerHTML =
    encabezado + encabezadoSemana +
    '<div class="tarjeta" style="padding:8px 6px;">' + cuadricula + '</div>' +
    listaDia;
}
