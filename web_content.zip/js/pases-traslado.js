// Pases de traslados — lista, para consulta rápida, el primer Pase de
// Traslados (PDF) que se generó de cada solicitud ya autorizada, guardado
// tal como se imprimió (ver guardarPasePrimeraVez en firebase-shim.js).
// No se guarda el de solicitudes sin autorizar, ni las generaciones
// posteriores del mismo folio (solo la primera).

function cargarVistaPases() {
  const contenedor = document.getElementById('contenido-principal');
  contenedor.innerHTML = '<p>Cargando pases de traslados...</p>';

  google.script.run
    .withSuccessHandler(renderizarListaPases)
    .withFailureHandler(function (error) {
      contenedor.innerHTML = '<p>Error al cargar los pases de traslados: ' + escaparHtml(error.message) + '</p>';
    })
    .listarPasesTraslado();
}

function renderizarListaPases(lista) {
  const contenedor = document.getElementById('contenido-principal');

  const encabezado =
    '<div style="margin-bottom:14px;">' +
      '<h2 style="margin:0 0 4px;">🖨️ Pases de traslados</h2>' +
      '<p style="margin:0; font-size:12.5px; color:var(--gris);">El primer Pase de Traslados (PDF) generado para cada solicitud ya autorizada, guardado tal como se imprimió.</p>' +
    '</div>';

  if (!lista.length) {
    contenedor.innerHTML = encabezado + '<div class="tarjeta estado-vacio"><span class="icono-vacio">🖨️</span>Todavía no se ha guardado ningún pase.<br><span style="font-size:12px;">Se guarda automáticamente la primera vez que generas el PDF de una solicitud ya autorizada.</span></div>';
    return;
  }

  const ordenados = lista.slice().sort(function (a, b) { return new Date(b.generado_en) - new Date(a.generado_en); });

  contenedor.innerHTML = encabezado + ordenados.map(function (p) {
    return (
      '<div class="tarjeta">' +
        '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">' +
          '<strong>' + escaparHtml(p.folio) + '</strong>' +
          '<span class="badge-estado badge-' + (COLOR_POR_ESTADO[p.estado_actual] || 'gris') + '">' + escaparHtml(p.estado_actual || '') + '</span>' +
        '</div>' +
        '<div style="font-size:14px; margin-top:6px; line-height:1.5;">' +
          (p.paciente_nombre ? '<div><strong>Paciente:</strong> ' + escaparHtml(p.paciente_nombre) + '</div>' : '') +
          (p.institucion_nombre ? '<div><strong>Institución:</strong> ' + escaparHtml(p.institucion_nombre) + '</div>' : '') +
          (p.fecha_cita ? '<div style="color:var(--gris);"><strong>Cita:</strong> ' + escaparHtml(formatearFecha(p.fecha_cita)) + '</div>' : '') +
          '<div style="color:var(--gris); font-size:12.5px; margin-top:4px;">Generado por ' + escaparHtml(p.generado_por || '—') + ' · ' + escaparHtml(formatearFecha(p.generado_en)) + '</div>' +
        '</div>' +
        '<div style="margin-top:10px;">' +
          '<button data-folio="' + escaparHtml(p.folio) + '" onclick="verPaseGuardado(this)">📄 Ver PDF guardado</button>' +
          ' <button data-folio="' + escaparHtml(p.folio) + '" onclick="verDetalleTraslado(this.dataset.folio)" style="margin-left:6px;">Ver traslado</button>' +
        '</div>' +
      '</div>'
    );
  }).join('');
}

function verPaseGuardado(boton) {
  const folio = boton.dataset.folio;
  const textoOriginal = boton.textContent;
  boton.disabled = true;
  boton.textContent = 'Generando...';

  google.script.run
    .withSuccessHandler(function (pase) {
      // El pase guardado es un snapshot de los datos (no el PDF ya
      // renderizado — pesaría más de lo que Firestore permite por campo,
      // ver nota en guardarPasePrimeraVez en firebase-shim.js). Se
      // regenera aquí mismo, con esos datos congelados, con la misma
      // función que lo generó la primera vez — el resultado es idéntico.
      generarPaseTraslado(pase.traslado, pase.paciente, pase.institucion)
        .then(function (bytes) {
          boton.disabled = false;
          boton.textContent = textoOriginal;
          const blob = new Blob([bytes], { type: 'application/pdf' });
          window.open(URL.createObjectURL(blob), '_blank');
        })
        .catch(function (error) {
          boton.disabled = false;
          boton.textContent = textoOriginal;
          alert('No se pudo generar el pase: ' + error.message);
        });
    })
    .withFailureHandler(function (error) {
      boton.disabled = false;
      boton.textContent = textoOriginal;
      alert('No se pudo abrir el pase: ' + error.message);
    })
    .obtenerPaseTraslado(folio);
}
