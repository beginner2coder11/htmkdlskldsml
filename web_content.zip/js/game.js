/**
 * Forgotten Lands — cliente pixel isometrico + multiplayer.
 * Sprites desenhados na hora (arte original). Nao usa grafico da CipSoft.
 */
(function () {
  const MAP = 36, HALF = 18;
  const TW = 64, TH = 32;
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;

  const TILE = { GRASS: 1, PATH: 2, WATER: 3, STONE: 4, WOOD: 5, SAND: 6 };
  let lang = localStorage.getItem("fl_lang") || "pt";
  const I18N = {
    pt: {
      lead: "Mundo pixel isometrico compartilhado. Crie conta e entre no mesmo servidor.",
      user: "conta (login)", pass: "senha", pname: "nome do personagem",
      voc: "Vocacao", look: "Aparencia", man: "Homem", woman: "Mulher",
      human: "Humano", elf: "Elfo", elfa: "Elfa", dwarf: "Anao",
      create: "Criar conta", enter: "Entrar", chosen: "Escolhido",
      chat: "fale no mundo...", map: "mapa", wings: "asas",
      pack: "Mochila", travel: "Viajar", arrived: "Voce chegou em ",
      equipped: "Voce equipou ", unequipped: "Voce desequipou ",
      levelup: "Voce avancou para o nivel ",
      hit: " te acerta (",
      dead: "Voce desmaiou e acordou no Porto.",
      killed: "derrotou ",
      online: "online",
      foot: "Pixel original · chat · trade · XP · mesmo mundo",
      daily: "Bonus diario: +50 ouro e +1 maca!",
      dailyDone: "Bonus diario ja coletado hoje.",
      q1: "Missao: mate 5 monstros fora da cidade.",
      q1ok: "Missao cumprida! +100 gp +200 xp",
      come: "Forgotten Lands: seus amigos estao online. Volta a jogar!",
      city: "CIDADE PRINCIPAL · ZONA SEGURA",
      hunt: "area de caca",
      wingsOn: "Asas abertas. Voo baixo.",
      wingsOff: "Voce pousou.",
      needLv: "Precisa de level ",
      set: "Configuracoes", setLang: "Idioma", setSfx: "Som / musica",
      setNames: "Nomes dos monstros", setNote: "A cidade principal nao tira vida.",
      halloween: "HALLOWEEN · CIDADE PRINCIPAL", camera: "Camera suave", zoom: "Zoom da camera",
    },
    fr: {
      lead: "Monde pixel isometrique partage. Creez un compte et rejoignez le serveur.",
      user: "compte (login)", pass: "mot de passe", pname: "nom du personnage",
      voc: "Vocation", look: "Apparence", man: "Homme", woman: "Femme",
      human: "Humain", elf: "Elfe", elfa: "Orc", dwarf: "Nain",
      create: "Creer un compte", enter: "Entrer", chosen: "Choisi",
      chat: "parler au monde...", map: "carte", wings: "ailes",
      pack: "Sac", travel: "Voyager", arrived: "Vous arrivez a ",
      equipped: "Vous equipez ", unequipped: "Vous retirez ",
      levelup: "Vous passez au niveau ",
      hit: " vous touche (",
      dead: "Vous tombez et reveillez au Port.",
      killed: "vaincu ",
      online: "en ligne",
      foot: "Pixel original · chat · echange · XP · meme monde",
      daily: "Bonus quotidien: +50 or et +1 pomme !",
      dailyDone: "Bonus du jour deja pris.",
      q1: "Quete: tuez 5 monstres hors de la ville.",
      q1ok: "Quete terminee ! +100 po +200 xp",
      come: "Forgotten Lands: tes amis sont en ligne. Reviens jouer !",
      city: "VILLE PRINCIPALE · ZONE SURE",
      hunt: "zone de chasse",
      wingsOn: "Ailes ouvertes. Vol bas.",
      wingsOff: "Vous atterrissez.",
      needLv: "Il faut le niveau ",
      set: "Reglages", setLang: "Langue", setSfx: "Son / musique",
      setNames: "Noms des monstres", setNote: "La ville principale ne retire pas de vie.",
      halloween: "HALLOWEEN · VILLE PRINCIPALE", camera: "Camera douce", zoom: "Zoom camera",
    },
    en: {
      lead: "Shared isometric pixel world. Create an account and join the same server.",
      user: "account (login)", pass: "password", pname: "character name",
      voc: "Vocation", look: "Look", man: "Male", woman: "Female",
      human: "Human", elf: "Elf", elfa: "Orc", dwarf: "Dwarf",
      create: "Create account", enter: "Enter", chosen: "Selected",
      chat: "talk to the world...", map: "map", wings: "wings",
      pack: "Backpack", travel: "Travel", arrived: "You arrived in ",
      equipped: "You equipped ", unequipped: "You unequipped ",
      levelup: "You reached level ",
      hit: " hits you (",
      dead: "You fainted and woke up at the Harbor.",
      killed: "defeated ",
      online: "online",
      foot: "Original pixel · chat · trade · XP · same world",
      daily: "Daily bonus: +50 gold and +1 apple!",
      dailyDone: "Daily bonus already claimed today.",
      q1: "Quest: defeat 5 monsters outside town.",
      q1ok: "Quest complete! +100 gp +200 xp",
      come: "Forgotten Lands: friends are online. Come back!",
      city: "MAIN CITY · SAFE ZONE",
      hunt: "hunting grounds",
      wingsOn: "Wings open. Low flight.",
      wingsOff: "You landed.",
      needLv: "Need level ",
      set: "Settings", setLang: "Language", setSfx: "Sound / music",
      setNames: "Monster names", setNote: "The main city does not take HP.",
      halloween: "HALLOWEEN · MAIN CITY", camera: "Smooth camera", zoom: "Camera zoom",
    },
  };
  function t(k) { return (I18N[lang] || I18N.pt)[k] || k; }
  function applyLang() {
    const L = I18N[lang] || I18N.pt;
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    const ph = (id, v) => { const e = document.getElementById(id); if (e) e.placeholder = v; };
    set("splash-lead", L.lead);
    ph("acc-user", L.user); ph("acc-pass", L.pass); ph("acc-name", L.pname);
    ph("chat-in", L.chat);
    set("btn-register", L.create); set("btn-start", L.enter);
    set("btn-map", L.map); set("btn-fly", L.wings);
    set("set-title", L.set);
    set("set-lang-lab", L.setLang);
    set("set-sfx-lab", L.setSfx);
    set("set-names-lab", L.setNames);
    set("set-note", L.setNote);
    document.querySelectorAll("#set-langs .lang").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
    const labs = document.querySelectorAll(".pick-lab");
    if (labs[0]) labs[0].textContent = L.voc;
    if (labs[1]) labs[1].textContent = L.look;
    const races = document.querySelectorAll("#races .voc");
    if (races[0]) races[0].textContent = L.human;
    if (races[1]) races[1].textContent = L.elf;
    if (races[2]) races[2].textContent = L.elfa;
    if (races[3]) races[3].textContent = L.dwarf;
    const sexes = document.querySelectorAll("#sexes .voc");
    if (sexes[0]) sexes[0].textContent = L.man;
    if (sexes[1]) sexes[1].textContent = L.woman;
    const small = document.querySelector("#splash small");
    if (small) small.textContent = L.foot;
    document.querySelectorAll("#lang-bar .lang").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
    localStorage.setItem("fl_lang", lang);
  }
  function todayKey() {
    const d = new Date();
    return d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
  }
  function giveDailyBonus() {
    if (!hero) return;
    const k = "fl_daily_" + (hero.name || "x");
    if (localStorage.getItem(k) === todayKey()) {
      chatLine(t("dailyDone"), "sys");
      return;
    }
    localStorage.setItem(k, todayKey());
    hero.gold = (hero.gold || 0) + 50;
    const ap = hero.inventory && hero.inventory.find((i) => i.id === "apple");
    if (ap) ap.qty += 1;
    else if (hero.inventory) hero.inventory.push({ id: "apple", icon: "🍎", name: "Maca", qty: 1, use: "food" });
    chatLine(t("daily"), "loot");
    chatLine(t("q1"), "sys");
    applyHero(hero);
    try {
      if (Notification && Notification.permission === "granted") {
        new Notification("Forgotten Lands", { body: t("daily") });
      } else if (Notification && Notification.permission !== "denied") {
        Notification.requestPermission();
      }
    } catch (e) {}
    setTimeout(() => {
      try { if (Notification && Notification.permission === "granted") new Notification("Forgotten Lands", { body: t("come") }); } catch (e) {}
      chatLine(t("come"), "sys");
    }, 8 * 60 * 1000);
  }
  const map = [];
  const solids = new Set();

  function seeded(x, y) {
    let n = x * 374761393 + y * 668265263;
    n = (n ^ (n >> 13)) * 1274126177;
    return ((n ^ (n >> 16)) >>> 0) / 4294967296;
  }
  function genMap(theme) {
    theme = theme || "grass";
    solids.clear();
    for (let y = 0; y < MAP; y++) {
      map[y] = [];
      for (let x = 0; x < MAP; x++) {
        const d = Math.hypot(x - HALF, y - HALF);
        let t = TILE.GRASS;
        if (theme === "sand") t = TILE.SAND;
        if (theme === "swamp") t = TILE.WOOD;
        if (theme === "forest") t = TILE.GRASS;
        if (theme === "city" || theme === "halloween") t = TILE.STONE;
        if (theme === "cave" || theme === "lair" || theme === "fort") t = TILE.STONE;
        if (theme === "lava") t = TILE.PATH;
        if (theme === "grass" && d > 15.4) t = TILE.WATER;
        else if (theme === "sand" && d > 14) t = TILE.WATER;
        else if (theme === "swamp" && seeded(x, y) > 0.55) t = TILE.WATER;
        else if (theme === "lava" && seeded(x, y) > 0.72) t = TILE.WATER;
        else if (theme === "city" && (Math.abs(x - HALF) < 2 || Math.abs(y - HALF) < 2)) t = TILE.PATH;
        else if (theme === "forest" && seeded(x, y) > 0.82) t = TILE.WOOD;
        else if ((theme === "grass" || theme === "city") && (Math.abs(x - HALF) < 1.2 || Math.abs(y - HALF) < 1.2)) t = TILE.PATH;
        else if (theme === "cave" && seeded(x, y) > 0.88) t = TILE.PATH;
        if ((theme === "city" || theme === "halloween") && x > 8 && x < 28 && y > 8 && y < 28) t = TILE.STONE;
        map[y][x] = t;
      }
    }
    if (theme === "city") {
      for (let y = 16; y <= 19; y++) for (let x = 16; x <= 19; x++) map[y][x] = TILE.STONE;
    }
    if (theme === "grass") {
      for (let x = 8; x <= 14; x++) map[20][x] = TILE.WOOD;
    }
    for (let y = 3; y < MAP - 3; y++) {
      for (let x = 3; x < MAP - 3; x++) {
        const r = seeded(x * 3, y * 7);
        if (theme === "forest" && r > 0.9) solids.add(x + "," + y);
        if (theme === "grass" && r > 0.96) solids.add(x + "," + y);
        if ((theme === "city" || theme === "halloween") && r > 0.97) solids.add(x + "," + y);
      }
    }
  }
  genMap("grass");

  function iso(x, y) {
    return { x: (x - y) * (TW / 2), y: (x + y) * (TH / 2) };
  }

  /* ---- pixel sprites (32x48 outfit tibia-like original) ---- */
  const pal = {
    knight: { body: "#8a1e12", legs: "#3d2b1a", boot: "#2a1a10", head: "#e0b090", hair: "#3a2410", extra: "#c9a227" },
    paladin: { body: "#2c5aa0", legs: "#2a3344", boot: "#1a1a22", head: "#e0b090", hair: "#6b3a12", extra: "#c9a227" },
    sorcerer: { body: "#5b2d8a", legs: "#2a1838", boot: "#1a1020", head: "#e8c4a0", hair: "#222", extra: "#88ccff" },
    druid: { body: "#2d6a28", legs: "#1a3a18", boot: "#243018", head: "#c48a58", hair: "#4a2a10", extra: "#88dd55" },
  };
  const racePal = {
    humano: { head: "#e0b090", hair: "#3a2410" },
    elfo: { head: "#f0d0b0", hair: "#d4c06a", extra: "#7dffb0" },
    orc: { head: "#6f9b52", hair: "#172015", extra: "#b8e86c", orc:true },
    anao: { head: "#c88858", hair: "#6a3a18", extra: "#c9a227", dwarf:true },
  };
  const spriteCache = {};

  function px(c, x, y, col, w) {
    c.fillStyle = col;
    c.fillRect(x, y, w || 1, 1);
  }
  function oval(c, x, y, rx, ry, col) {
    c.fillStyle = col;
    c.beginPath();
    c.ellipse(x, y, rx, ry, 0, 0, 7);
    c.fill();
  }
  function drawOutfit(c, o, frame) {
    c.fillStyle = "rgba(0,0,0,.28)";
    c.beginPath(); c.ellipse(16, 44, 9, 3, 0, 0, 7); c.fill();
    const step = frame ? 1 : 0;
    oval(c, 12 - step, 40, 3.2, 2.4, "#2a2a32");
    oval(c, 20 + step, 40, 3.2, 2.4, "#2a2a32");
    oval(c, 13, 34, 3.2, 7, "#8a9098");
    oval(c, 19, 34, 3.2, 7, "#8a9098");
    oval(c, 16, 24, 7.2, 9, o.body);
    oval(c, 16, 21, 6.4, 3, "#d8d8e0");
    oval(c, 16, 29, 6, 1.6, o.extra);
    oval(c, 16, 25, 2.2, 2.2, "#c9a227");
    oval(c, 8, 20, 3.4, 3.2, "#b8bec8");
    oval(c, 24, 20, 3.4, 3.2, "#b8bec8");
    oval(c, 8, 26, 2.4, 5, o.body);
    oval(c, 24, 26, 2.4, 5, o.body);
    oval(c, 16, 13, 5.4, 5.8, o.head);
    oval(c, 16, 9, 6.2, 3.6, "#c8ccd4");
    oval(c, 16, 12.2, 3.4, 1.6, "#1a1a22");
    oval(c, 14.2, 12.2, 1.1, 1.1, "#4a80ff");
    oval(c, 17.8, 12.2, 1.1, 1.1, "#4a80ff");
  }
  function makeCharSheet(voc, race, sex) {
    const key = voc + "-" + (race || "humano") + "-" + (sex || "m");
    if (spriteCache[key]) return spriteCache[key];
    voc = voc || "knight"; race = race || "humano"; sex = sex || "m";
    if (race === "elfa") { race = "elfo"; sex = "f"; }
    const s = document.createElement("canvas"); s.width = 64; s.height = 48;
    const c = s.getContext("2d"); c.imageSmoothingEnabled = false;
    const o = Object.assign({}, pal[voc] || pal.knight, racePal[race] || {});
    const female = sex === "f";
    const orc = race === "orc";
    const dwarf = race === "anao";
    drawOutfit(c, o, 0);

    // Race-specific silhouette details.
    c.save();
    if (orc) {
      // Broad orc ears, tusks and heavy brow.
      c.fillStyle = o.head; c.fillRect(7, 15, 4, 5); c.fillRect(21, 15, 4, 5);
      c.fillStyle = "#f4e6c0";
      c.fillRect(12, 16, 2, 3); c.fillRect(18, 16, 2, 3);
      c.fillStyle = o.hair;
      if (female) {
        c.fillRect(9, 6, 4, 15); c.fillRect(19, 6, 4, 15);
        c.fillRect(11, 5, 10, 3);
      } else {
        c.fillRect(10, 6, 12, 5); c.fillRect(12, 4, 8, 3);
      }
    } else if (race === "elfo") {
      // Pointed ears; female elf gets long flowing hair.
      c.fillStyle = o.head;
      c.beginPath(); c.moveTo(10,14); c.lineTo(2,10); c.lineTo(10,18); c.fill();
      c.beginPath(); c.moveTo(22,14); c.lineTo(30,10); c.lineTo(22,18); c.fill();
      c.fillStyle = o.hair;
      if (female) {
        c.fillRect(9, 6, 4, 17); c.fillRect(19, 6, 4, 17);
        c.fillRect(11, 5, 10, 4);
      } else {
        c.fillRect(10, 6, 12, 6); c.fillRect(12, 4, 8, 3);
      }
    } else if (dwarf) {
      // Stocky beard/long hair visual.
      c.fillStyle = o.hair;
      c.fillRect(10, 8, 12, 5);
      if (female) {
        c.fillRect(9, 10, 4, 14); c.fillRect(19, 10, 4, 14);
      } else {
        c.fillRect(12, 14, 8, 8);
      }
      c.fillStyle = o.head;
      c.fillRect(11, 14, 10, 5);
      if (!female) { c.fillStyle = o.hair; c.fillRect(12,18,8,5); }
    } else {
      // Human male/female: distinct hair and silhouette.
      c.fillStyle = o.hair || "#3a2410";
      if (female) {
        c.fillRect(9, 7, 4, 17); c.fillRect(19, 7, 4, 17);
        c.fillRect(11, 5, 10, 4);
      } else {
        c.fillRect(10, 6, 12, 6); c.fillRect(12, 4, 8, 3);
      }
    }
    c.restore();

    // Female body accent / hair, male shoulders remain broader.
    if (female) {
      c.fillStyle = o.extra || "#ff9ad4";
      c.fillRect(12, 27, 8, 2);
    } else {
      c.fillStyle = "rgba(255,255,255,.14)";
      c.fillRect(10, 23, 12, 2);
    }

    const low = document.createElement("canvas"); low.width = 32; low.height = 24;
    const lc = low.getContext("2d"); lc.imageSmoothingEnabled = false;
    lc.drawImage(s, 0, 0, 32, 24);
    c.clearRect(0, 0, 64, 48); c.imageSmoothingEnabled = false; c.drawImage(low, 0, 0, 64, 48);
    spriteCache[key] = s; return s;
  }
  function drawGearOn(pos, lift) {
    if (!hero || !hero.eq) return;
    const x = Math.round(pos.x), y = Math.round(pos.y - lift);
    ctx.save(); ctx.imageSmoothingEnabled = false;
    if (hero.eq.armor) {
      ctx.fillStyle = "#26313a"; ctx.fillRect(x - 10, y - 31, 20, 15);
      ctx.fillStyle = "#b7c5d2"; ctx.fillRect(x - 8, y - 29, 16, 3);
      ctx.fillStyle = "#d8a93d"; ctx.fillRect(x - 8, y - 18, 16, 2);
      ctx.fillStyle = "#6e7d8a"; ctx.fillRect(x - 5, y - 27, 3, 9); ctx.fillRect(x + 2, y - 27, 3, 9);
    }
    if (hero.eq.helm) {
      ctx.fillStyle = "#5f6b76"; ctx.fillRect(x - 9, y - 44, 18, 8);
      ctx.fillStyle = "#c9d2da"; ctx.fillRect(x - 7, y - 43, 14, 3);
      ctx.fillStyle = "#303840"; ctx.fillRect(x - 8, y - 36, 16, 3);
    }
    if (hero.eq.shield) {
      ctx.fillStyle = "#304a66"; ctx.fillRect(x - 19, y - 28, 9, 14);
      ctx.fillStyle = "#c9a227"; ctx.fillRect(x - 17, y - 25, 5, 8);
      ctx.fillStyle = "#eef4ff"; ctx.fillRect(x - 15, y - 23, 2, 4);
    }
    const swinging = performance.now() < atkUntil;
    const ang = swinging ? -0.9 + ((atkUntil - performance.now()) / 280) * 1.8 : 0;
    if (hero.eq.sword || swinging) {
      ctx.translate(x + 8, y - 22); ctx.rotate(ang);
      ctx.fillStyle = "#e9eef4"; ctx.fillRect(2, -18, 4, 22);
      ctx.fillStyle = "#8b9aaa"; ctx.fillRect(3, -18, 2, 16);
      ctx.fillStyle = "#d9ae43"; ctx.fillRect(0, 2, 8, 3);
      ctx.fillStyle = "#5a351c"; ctx.fillRect(2, 5, 4, 8);
    }
    ctx.restore();
    if (swinging) {
      ctx.strokeStyle = "rgba(255,232,150,.9)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x + 4, y - 24, 18, -0.25, 1.35); ctx.stroke();
    }
  }
  // Dragon wings: symmetric, upright, slightly larger than the old wings.
  // The body stays vertical; only the membranes gently flap around the shoulder.
  function drawMuWings(x, y) { // V8_DRAGON_WING_SCALE: 1.12, golden dragon wings behind character
    const flap = Math.sin(frame / 7.5);
    const breathe = Math.sin(frame / 11.0) * 1.2;
    const lift = flying ? Math.sin(frame / 8) * 3 : 0;
    const spread = 0.92 + flap * 0.025;
    const wingH = 1.18 + flap * 0.018;

    ctx.save();
    ctx.translate(x, y - 27 - lift + breathe);
    ctx.globalCompositeOperation = "source-over";

    // Soft golden aura.
    ctx.save();
    ctx.globalAlpha = 0.20 + Math.abs(flap) * 0.08;
    ctx.shadowColor = "#ffd76a";
    ctx.shadowBlur = 15;
    ctx.fillStyle = "#ffd45a";
    ctx.beginPath();
    ctx.ellipse(0, 1, 58, 38, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    function wing(side) {
      ctx.save();
      ctx.translate(side * 5, 2);
      ctx.scale(side * spread, wingH);

      // Keep the wing upright instead of rotating it diagonally.
      const rootX = 0;
      const outer = 43;
      const tipY = -34;
      const lowerY = 24;

      const grad = ctx.createLinearGradient(0, -30, 0, 32);
      grad.addColorStop(0, "#fff5b8");
      grad.addColorStop(0.22, "#e7b83f");
      grad.addColorStop(0.58, "#b88616");
      grad.addColorStop(1, "#6a4308");

      ctx.shadowColor = "rgba(255,216,86,.82)";
      ctx.shadowBlur = 7;
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(rootX, -2);
      ctx.lineTo(side * 14, -28);
      ctx.lineTo(side * 25, -55);
      ctx.lineTo(side * 24, -28);
      ctx.lineTo(side * 39, -43);
      ctx.lineTo(side * 36, -4);
      ctx.lineTo(side * 43, 2);
      ctx.lineTo(side * 34, 11);
      ctx.lineTo(side * outer, 21);
      ctx.lineTo(side * 22, 17);
      ctx.lineTo(side * 12, lowerY);
      ctx.lineTo(side * 6, 13);
      ctx.closePath();
      ctx.fill();

      // Bright membrane veins.
      ctx.shadowBlur = 0;
      ctx.strokeStyle = "rgba(255,242,165,.94)";
      ctx.lineWidth = 1.5;
      const veins = [
        [-2,-2, side*18,-15],
        [-1,-1, side*30,-34],
        [0,1, side*40,-24],
        [1,3, side*44,3],
        [2,4, side*36,14],
        [3,6, side*24,21]
      ];
      for (const v of veins) {
        ctx.beginPath();
        ctx.moveTo(v[0],v[1]);
        ctx.quadraticCurveTo(side*12, 0, v[2], v[3]);
        ctx.stroke();
      }

      // Golden edge highlights.
      ctx.strokeStyle = "rgba(255,221,105,.98)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(0,-2);
      ctx.lineTo(side*16,-16);
      ctx.lineTo(side*30,-36);
      ctx.lineTo(side*27,-12);
      ctx.lineTo(side*45,-25);
      ctx.lineTo(side*39,1);
      ctx.lineTo(side*50,5);
      ctx.lineTo(side*37,15);
      ctx.lineTo(side*48,25);
      ctx.stroke();

      ctx.restore();
    }

    // Draw left/right independently so they remain perfectly mirrored.
    wing(-1);
    wing(1);

    // Small animated golden particles near the wing roots.
    ctx.save();
    ctx.globalAlpha = 0.35 + Math.abs(flap) * 0.25;
    ctx.fillStyle = "#ffe58a";
    for (let i=0;i<4;i++) {
      const a = frame/35 + i*1.57;
      const px = Math.cos(a) * (19 + i*5);
      const py = Math.sin(a) * (10 + i*3) - 5;
      ctx.beginPath();
      ctx.arc(px,py,1.2 + (i%2)*.5,0,Math.PI*2);
      ctx.fill();
    }
    ctx.restore();

    ctx.restore();
  }
  const CITY_PVP_ARENA = { map: "porto", x: 18, y: 18, radius: 5.5 };
  function inCityPvpArena() {
    if (!hero) return false;
    if (currentMap !== CITY_PVP_ARENA.map) return false;
    const d = Math.hypot((hero.x || 0) - CITY_PVP_ARENA.x, (hero.y || 0) - CITY_PVP_ARENA.y);
    return d <= CITY_PVP_ARENA.radius;
  }
  function inSafeZone() {
    if (inCityPvpArena()) return false;
    const s = String(currentMap || "") + " " + String((hero && hero.map) || "") + " " + String(mapName || "");
    return /porto|templo|temple|cidade|harbor|port/i.test(s);
  }
  function canPvpHere() {
    return !!hero && !inSafeZone();
  }
  function makeMob(kind) {
    const key = "m_" + kind;
    if (spriteCache[key]) return spriteCache[key];
    const s = document.createElement("canvas");
    s.width = 32; s.height = 32;
    const c = s.getContext("2d");
    const colors = {
      rat: "#6a5340", snake: "#3d8a32", spider: "#222", orc: "#4a6b32",
      wolf: "#6a5a4a", slime: "#5aaa3a", scarab: "#6b5a22", bat: "#3a2a4a",
      berserk: "#5a2a12", fire: "#d45512", dragon: "#8a1e12",
      crab: "#c45a32", seagull: "#e8e8e0", boar: "#5a3a22", wasp: "#d4c017",
      toad: "#4a7a32", mummy: "#c8b888", troll: "#6a7a44",
    };
    const col = colors[kind] || "#555";
    c.fillStyle = "rgba(0,0,0,.3)"; c.fillRect(8, 26, 16, 4);
    if (kind === "rat") {
      c.fillStyle = "#3a2a18"; c.fillRect(6, 16, 20, 12);
      c.fillStyle = "#c48a4a"; c.fillRect(8, 17, 16, 9);
      c.fillRect(18, 10, 10, 10);
      c.fillStyle = "#fff"; c.fillRect(24, 13, 3, 3);
      c.fillStyle = "#111"; c.fillRect(25, 14, 2, 2);
      c.fillStyle = "#e8c090"; c.fillRect(26, 18, 5, 3);
    } else if (kind === "snake") {
      c.fillStyle = col; c.fillRect(8, 22, 16, 4); c.fillRect(20, 16, 6, 8); c.fillRect(22, 12, 4, 6);
    } else if (kind === "spider") {
      c.fillStyle = col; c.fillRect(12, 16, 8, 8);
      c.fillRect(6, 18, 20, 2); c.fillRect(8, 14, 2, 12); c.fillRect(22, 14, 2, 12);
    } else {
      c.fillStyle = col; c.fillRect(10, 10, 12, 16); c.fillStyle = "#6b8f3a"; c.fillRect(12, 4, 8, 8);
      c.fillStyle = "#222"; c.fillRect(14, 7, 2, 2); c.fillRect(18, 7, 2, 2);
    }
    spriteCache[key] = s;
    return s;
  }

  const tileCols = {
    1: ["#72e34b", "#2f9b36"],
    2: ["#ffd76a", "#d89a38"],
    3: ["#55d8ff", "#167ed1"],
    4: ["#d8d2c5", "#817a72"],
    5: ["#ff914d", "#a83f18"],
    6: ["#ffe68b", "#d69d38"],
  };
  function drawTile(x, y, t) {
    const p = iso(x, y);
    let cols = tileCols[t] || tileCols[1];
    if (currentTheme === "swamp" && t === TILE.WOOD) cols = ["#3a4a22", "#2a3318"];
    if (currentTheme === "forest" && t === TILE.GRASS) cols = ["#35b94b", "#176b31"];
    if (currentTheme === "lava" && t === TILE.PATH) cols = ["#6a2010", "#3a1008"];
    if (currentTheme === "lava" && t === TILE.WATER) cols = ["#e07020", "#a03010"];
    if (currentTheme === "lair" && t === TILE.STONE) cols = ["#4a2030", "#2a1018"];
    if (currentTheme === "fort" && t === TILE.STONE) cols = ["#6a6048", "#3a3828"];
    if (currentTheme === "city" && t === TILE.STONE) cols = ["#7a7a72", "#55554c"];
    if (currentTheme === "halloween" && t === TILE.STONE) cols = ["#5b5860", "#292a33"];
    if (currentTheme === "halloween" && t === TILE.PATH) cols = ["#8b673f", "#4c3326"];
    if (currentTheme === "halloween" && t === TILE.GRASS) cols = ["#3c8f3b", "#14291b"];
    if (currentTheme === "cave" && t === TILE.STONE) cols = ["#3a3a44", "#22222a"];
    const h = t === TILE.WATER ? 4 : 10;
    ctx.fillStyle = cols[1];
    ctx.beginPath();
    ctx.moveTo(p.x - TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x, p.y + TH + h);
    ctx.lineTo(p.x - TW / 2, p.y + TH / 2 + h);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#00000033";
    ctx.beginPath();
    ctx.moveTo(p.x + TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x, p.y + TH + h);
    ctx.lineTo(p.x + TW / 2, p.y + TH / 2 + h);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x - TW / 2, p.y + TH / 2);
    ctx.closePath();
    const tg = ctx.createLinearGradient(p.x, p.y, p.x, p.y + TH);
    tg.addColorStop(0, cols[0]);
    tg.addColorStop(1, cols[1]);
    ctx.fillStyle = tg;
    ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,.12)";
    ctx.lineWidth = 1;
    ctx.stroke();
    if (t === TILE.WATER) {
      const w = Math.sin((frame + x * 5 + y * 9) / 8);
      ctx.fillStyle = w > 0 ? "#3aa0c8" : "#2b88b4";
      ctx.beginPath();
      ctx.moveTo(p.x - 8, p.y + 10);
      ctx.quadraticCurveTo(p.x + w * 6, p.y + 14, p.x + 8, p.y + 12);
      ctx.strokeStyle = "rgba(180,230,255,.55)";
      ctx.stroke();
      if (((x * 13 + y * 7) % 11) === 0) {
        ctx.fillStyle = "#f0c060";
        ctx.fillRect(p.x - 2 + w, p.y + 8, 3, 2);
      }
    }
    if (t === TILE.GRASS) {
      const sway = Math.sin((frame + x * 7 + y * 3) / 14) * 2.2;
      ctx.strokeStyle = "rgba(70,140,50,.75)";
      ctx.lineWidth = 1.2;
      ctx.lineCap = "round";
      for (let i = 0; i < 5; i++) {
        const ox = ((x * 13 + y * 7 + i * 19) % 17) - 8;
        const oy = ((x * 5 + y * 11 + i * 9) % 11) - 2;
        ctx.beginPath();
        ctx.moveTo(p.x + ox, p.y + 10 + oy);
        ctx.quadraticCurveTo(p.x + ox + sway, p.y + 4 + oy, p.x + ox + sway * 0.4, p.y - 2 + oy);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(180,220,90,.18)";
      ctx.beginPath(); ctx.ellipse(p.x - 6, p.y + 6, 4, 2, 0, 0, 7); ctx.fill();
      if (((x * 17 + y * 11) % 9) === 0) {
        const fl = ["#ff4d6d", "#ffd24a", "#ff7ad9", "#7ae0ff"][(x + y) % 4];
        ctx.fillStyle = fl;
        ctx.beginPath(); ctx.ellipse(p.x + 4, p.y + 6, 3, 3, 0, 0, 7); ctx.fill();
      }
    }
    if (t === TILE.PATH || t === TILE.STONE) {
      ctx.strokeStyle = "rgba(0,0,0,.18)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(p.x - 10, p.y + 6); ctx.lineTo(p.x + 8, p.y + 14);
      ctx.moveTo(p.x + 4, p.y + 4); ctx.lineTo(p.x - 6, p.y + 12);
      ctx.stroke();
    }
  }
  function drawTree(x, y) {
    const p = iso(x, y);
    ctx.fillStyle = "#3a2010"; ctx.fillRect(p.x - 5, p.y - 6, 10, 20);
    ctx.fillStyle = "#5a3518"; ctx.fillRect(p.x - 3, p.y - 10, 6, 18);
    ctx.fillStyle = "#164a1c"; ctx.beginPath(); ctx.ellipse(p.x, p.y - 28, 16, 14, 0, 0, 7); ctx.fill();
    ctx.fillStyle = "#2d8a38"; ctx.beginPath(); ctx.ellipse(p.x - 2, p.y - 32, 12, 10, 0, 0, 7); ctx.fill();
  }
  function drawHouse(x, y) {
    const p = iso(x + 0.5, y + 0.5);
    const roofs = ["#e23b4a", "#2f6fe0", "#e07a14", "#7b2fd0", "#1aa36a"];
    const roof = roofs[(x + y) % roofs.length];
    ctx.fillStyle = "#c48a4a"; ctx.fillRect(p.x - 26, p.y - 8, 52, 24);
    ctx.fillStyle = "#e8b878"; ctx.fillRect(p.x - 24, p.y - 22, 48, 22);
    ctx.fillStyle = roof;
    ctx.beginPath(); ctx.moveTo(p.x - 30, p.y - 20); ctx.lineTo(p.x, p.y - 48); ctx.lineTo(p.x + 30, p.y - 20); ctx.fill();
    ctx.fillStyle = "#fff6a8";
    ctx.beginPath(); ctx.moveTo(p.x - 20, p.y - 22); ctx.lineTo(p.x, p.y - 40); ctx.lineTo(p.x + 8, p.y - 22); ctx.fill();
    ctx.fillStyle = "#7fe0ff"; ctx.fillRect(p.x - 16, p.y - 14, 8, 8); ctx.fillRect(p.x + 8, p.y - 14, 8, 8);
    ctx.fillStyle = "#5a3010"; ctx.fillRect(p.x - 5, p.y - 2, 10, 16);
  }
  function drawPumpkin(x, y, size=1) {
    const p = iso(x, y);
    ctx.save(); ctx.translate(p.x, p.y - 3); ctx.scale(size, size);
    ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.beginPath(); ctx.ellipse(0, 9, 13, 5, 0, 0, 7); ctx.fill();
    ctx.fillStyle = "#e97818"; ctx.beginPath(); ctx.ellipse(0, 0, 10, 8, 0, 0, 7); ctx.fill();
    ctx.fillStyle = "#b84e0d"; ctx.fillRect(-2, -9, 4, 4);
    ctx.fillStyle = "#2a1808"; ctx.beginPath(); ctx.moveTo(-6,-1); ctx.lineTo(-2,-3); ctx.lineTo(-1,1); ctx.lineTo(-5,3); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(2,-3); ctx.lineTo(6,-1); ctx.lineTo(5,3); ctx.lineTo(1,1); ctx.closePath(); ctx.fill();
    ctx.fillRect(-3,4,6,2); ctx.restore();
  }
  function drawHalloweenLantern(x, y) {
    const p = iso(x, y);
    ctx.fillStyle = "#3b2415"; ctx.fillRect(p.x-2,p.y-2,4,18);
    ctx.fillStyle = "rgba(255,145,25,.22)"; ctx.beginPath(); ctx.arc(p.x,p.y-7,15,0,7); ctx.fill();
    ctx.fillStyle = "#ff9d24"; ctx.fillRect(p.x-6,p.y-13,12,10);
    ctx.fillStyle = "#24120a"; ctx.fillRect(p.x-4,p.y-11,2,3); ctx.fillRect(p.x+2,p.y-11,2,3); ctx.fillRect(p.x-3,p.y-6,6,2);
  }

  function drawHauntedTree(x, y, scale=1) {
    const p = iso(x,y);
    ctx.save(); ctx.translate(p.x,p.y); ctx.scale(scale,scale);
    const sway=Math.sin(frame/35+x)*2;
    ctx.fillStyle="#24160f"; ctx.fillRect(-5,-4,10,24);
    ctx.strokeStyle="#332016"; ctx.lineWidth=5; ctx.lineCap="round";
    ctx.beginPath(); ctx.moveTo(-2,5); ctx.lineTo(-18,-12); ctx.moveTo(2,1); ctx.lineTo(18,-15);
    ctx.moveTo(-1,9); ctx.lineTo(-22,5); ctx.stroke();
    ctx.fillStyle="#16281c";
    [[-17,-19,13],[0,-27,16],[17,-20,12],[-8,-8,12],[9,-10,12]].forEach(a=>{
      ctx.beginPath(); ctx.ellipse(a[0]+sway,a[1],a[2],a[2]*.72,0,0,Math.PI*2); ctx.fill();
    });
    ctx.fillStyle="#7d3b1b";
    ctx.beginPath();ctx.arc(-7,-12,2,0,7);ctx.arc(10,-17,2,0,7);ctx.fill();
    ctx.restore();
  }
  function drawHauntedHouse(x,y,variant=0) {
    const p=iso(x+.5,y+.5); ctx.save();
    ctx.fillStyle="#3a2a25";ctx.fillRect(p.x-30,p.y-8,60,28);
    ctx.fillStyle="#51423b";ctx.fillRect(p.x-25,p.y-25,50,20);
    ctx.fillStyle=variant%2?"#35233e":"#2a2635";
    ctx.beginPath();ctx.moveTo(p.x-35,p.y-23);ctx.lineTo(p.x,p.y-55);ctx.lineTo(p.x+35,p.y-23);ctx.closePath();ctx.fill();
    ctx.strokeStyle="#7c6b61";ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle="#ff9b22";ctx.fillRect(p.x-17,p.y-15,9,10);ctx.fillRect(p.x+8,p.y-15,9,10);
    ctx.fillStyle="#140d0a";ctx.fillRect(p.x-3,p.y-1,10,21);
    ctx.fillStyle="#ffb52e";ctx.beginPath();ctx.arc(p.x+5,p.y+8,2,0,7);ctx.fill();
    // crooked chimney + moonlit window
    ctx.fillStyle="#29211f";ctx.fillRect(p.x+17,p.y-47,7,20);
    ctx.fillStyle="rgba(255,178,52,.16)";ctx.beginPath();ctx.arc(p.x,p.y-6,48,0,7);ctx.fill();
    ctx.restore();
  }
  function drawGravestone(x,y) {
    const p=iso(x,y);ctx.save();
    ctx.fillStyle="#77727b";ctx.fillRect(p.x-7,p.y-13,14,18);
    ctx.beginPath();ctx.arc(p.x,p.y-13,7,Math.PI,0);ctx.fill();
    ctx.fillStyle="#3d3a40";ctx.fillRect(p.x-1,p.y-9,2,7);ctx.fillRect(p.x-4,p.y-7,8,2);
    ctx.restore();
  }
  function drawSpiderWeb(x,y) {
    const p=iso(x,y);ctx.save();ctx.translate(p.x,p.y-26);
    ctx.strokeStyle="rgba(225,225,235,.45)";ctx.lineWidth=1;
    for(let i=0;i<8;i++){const a=i*Math.PI/4;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*22,Math.sin(a)*22);ctx.stroke();}
    for(let r=7;r<23;r+=7){ctx.beginPath();for(let i=0;i<=8;i++){const a=i*Math.PI/4;const x1=Math.cos(a)*r,y1=Math.sin(a)*r;i?ctx.lineTo(x1,y1):ctx.moveTo(x1,y1);}ctx.stroke();}
    ctx.restore();
  }
  function drawHalloweenArch(x,y) {
    const p=iso(x,y);ctx.save();
    ctx.strokeStyle="#21151b";ctx.lineWidth=8;ctx.lineCap="round";
    ctx.beginPath();ctx.moveTo(p.x-25,p.y+5);ctx.lineTo(p.x-25,p.y-28);ctx.quadraticCurveTo(p.x,p.y-58,p.x+25,p.y-28);ctx.lineTo(p.x+25,p.y+5);ctx.stroke();
    ctx.strokeStyle="#9d5a21";ctx.lineWidth=3;ctx.stroke();
    ctx.fillStyle="#ff8d1c";ctx.beginPath();ctx.arc(p.x,p.y-37,7,0,7);ctx.fill();
    ctx.fillStyle="#24120a";ctx.fillRect(p.x-4,p.y-39,2,3);ctx.fillRect(p.x+2,p.y-39,2,3);ctx.fillRect(p.x-3,p.y-34,6,2);
    ctx.restore();
  }


  function drawCityPvpArena() {
    if (currentMap !== "porto") return;
    const p=iso(CITY_PVP_ARENA.x,CITY_PVP_ARENA.y);
    const pulse=0.65+Math.sin(frame/12)*0.12;
    ctx.save();
    ctx.globalAlpha=.28;
    ctx.fillStyle="#b5162f";
    ctx.beginPath();ctx.ellipse(p.x,p.y+9,76,38,0,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=.9;
    ctx.strokeStyle=`rgba(255,90,90,${pulse})`;ctx.lineWidth=3;
    ctx.beginPath();ctx.ellipse(p.x,p.y+5,68,34,0,0,Math.PI*2);ctx.stroke();
    ctx.fillStyle="#3a1820";ctx.fillRect(p.x-42,p.y-4,84,10);
    ctx.fillStyle="#ffb52e";ctx.font="bold 11px sans-serif";ctx.textAlign="center";
    ctx.fillText("⚔ ARENA PVP ⚔",p.x,p.y+4);
    ctx.fillStyle="#d34b56";ctx.font="bold 8px sans-serif";ctx.fillText("COMBATE LIVRE",p.x,p.y+18);
    ctx.restore();
  }

  function drawBat(x, y) {
    const p = iso(x,y), flap = Math.sin(frame/5)*3;
    ctx.save(); ctx.translate(p.x,p.y-28); ctx.fillStyle="rgba(17,12,28,.9)";
    ctx.beginPath(); ctx.moveTo(0,4); ctx.quadraticCurveTo(-9,-7,-20,-2); ctx.lineTo(-11,6+flap); ctx.lineTo(-4,3); ctx.lineTo(0,8); ctx.lineTo(4,3); ctx.lineTo(11,6-flap); ctx.lineTo(20,-2); ctx.quadraticCurveTo(9,-7,0,4); ctx.fill(); ctx.restore();
  }

  function drawTemple(x, y) {
    const p = iso(x, y);
    ctx.fillStyle = "#cfc6b0"; ctx.fillRect(p.x - 26, p.y - 6, 52, 16);
    ctx.fillStyle = "#e8e0cc";
    ctx.fillRect(p.x - 20, p.y - 28, 6, 24);
    ctx.fillRect(p.x + 14, p.y - 28, 6, 24);
    ctx.fillStyle = "#d4a017"; ctx.fillRect(p.x - 24, p.y - 32, 48, 6);
    ctx.fillStyle = "#ff8a1a"; ctx.fillRect(p.x - 3, p.y - 40, 6, 8);
  }

  /* ---- state ---- */
  let hero = null;
  let others = [];
  let creatures = [];
  let drops = [];
  let portals = [];
  let cityChest = []; // persistent shared storage for the current account
  let currentMap = "porto";
  let currentTheme = "halloween";
  let mapName = "Porto Inicial";
  let ws = null;
  let connected = false;
  const keys = {};
  const joy = { dx: 0, dy: 0, on: false, id: null };
  let moveAcc = 0;
  let visX = 18, visY = 21;
  let camX = 0, camY = 0;
  let camZoom = 1.0, camUserX = 0, camUserY = 0, camShake = 0;
  let camDrag = null, camPointers = new Map(), camPinchStart = 0, camPinchZoom = 1;
  let frame = 0;
  let lookT = 0;
  let chosenVoc = "knight";
  let chosenRace = "humano";
  let chosenSex = "m";
  let flying = false;
  let atkUntil = 0, autoAtkNext = 0;
  let audioCtx = null, musicNodes = [], musicOn = true, musicTheme = "", showNames = true, pvpOn = true;
  let notifyEnabled = localStorage.getItem("fl_notify") === "1";
  let lastActivityAt = Date.now();
  let reminderTimer = null;
  const SONGS = {
    grass:[262,330,392,523,392,330,294,330,392,330,262,196],
    city:[330,392,440,523,440,392,349,392,494,440,392,330],
    sand:[294,349,440,523,440,392,349,294,262,349,392,440],
    forest:[220,262,330,392,330,294,262,220,247,294,330,370],
    swamp:[196,233,262,233,196,175,196,220,233,196],
    cave:[175,220,262,220,196,175,147,175,220,196],
    fort:[247,311,370,440,370,311,277,247,311,370],
    lava:[208,262,311,370,415,370,311,262,208,233],
    lair:[165,196,247,196,185,220,277,247,196,165],
    ice:[330,392,494,659,587,494,440,392,523,659],
    night:[196,247,294,370,330,294,247,220,196,247],
    halloween:[196,233,277,330,277,233,185,220,277,370,330,247,196,165],
    title:[262,330,392,523,494,392,330,392,440,392,330,262]
  };
  function mapSong(theme){
    const base=SONGS[theme]||SONGS.title;
    const id=String(currentMap||"");
    let seed=0; for(let i=0;i<id.length;i++) seed=(seed*31+id.charCodeAt(i))>>>0;
    const scale=[1,9/8,5/4,4/3,3/2,5/3,15/8];
    const mode=(seed%3);
    const out=[];
    for(let i=0;i<16;i++){
      const f=base[(i+(seed%base.length))%base.length];
      const bump=scale[(seed+i*7)%scale.length];
      out.push(Math.max(110,Math.min(880,Math.round(f*(mode===1?1:bump*0.9)))));
    }
    return out;
  }
  function ensureAudio() {
    if (audioCtx) return audioCtx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    audioCtx = new AC();
    return audioCtx;
  }
  function stopMusic() {
    musicNodes.forEach((n) => { try { n.stop(); } catch {} });
    musicNodes = [];
  }
  function playMapMusic(theme) {
    theme = theme || currentTheme || "title";
    if (!musicOn) return;
    const musicKey=String(currentMap||"title")+"|"+theme;
    if (musicTheme === musicKey && musicNodes.length) return;
    const ctx = ensureAudio();
    if (!ctx) return;
    if (ctx.state === "suspended") ctx.resume();
    stopMusic();
    musicTheme = musicKey;
    const notes = mapSong(theme);
    const master=ctx.createGain(); master.gain.value=0.055; master.connect(ctx.destination);
    const lead=ctx.createOscillator(), pad=ctx.createOscillator(), bass=ctx.createOscillator();
    const lg=ctx.createGain(), pg=ctx.createGain(), bg=ctx.createGain();
    lead.type="triangle"; pad.type="sine"; bass.type="sawtooth";
    lg.gain.value=.55; pg.gain.value=.22; bg.gain.value=.16;
    lead.connect(lg);pad.connect(pg);bass.connect(bg);lg.connect(master);pg.connect(master);bg.connect(master);
    const step=.30, start=ctx.currentTime+.03;
    notes.forEach((f,i)=>{
      const t=start+i*step;
      lead.frequency.setValueAtTime(f,t);
      pad.frequency.setValueAtTime(f/2,t);
      bass.frequency.setValueAtTime(f/4,t);
    });
    lead.start(start);pad.start(start);bass.start(start);
    const loop=notes.length*step;
    const iv=setInterval(()=>{
      if(!audioCtx||!musicOn)return;
      const t=audioCtx.currentTime+.01;
      notes.forEach((f,i)=>{const tt=t+i*step;lead.frequency.setValueAtTime(f,tt);pad.frequency.setValueAtTime(f/2,tt);bass.frequency.setValueAtTime(f/4,tt);});
    },loop*1000);
    const timer={stop(){try{lead.stop();pad.stop();bass.stop();}catch{}clearInterval(iv);}};
    musicNodes=[timer];
  }
  function sfx(freq, dur) {
    const ctx = ensureAudio();
    if (!ctx || !musicOn) return;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "square";
    o.frequency.value = freq;
    g.gain.value = 0.05;
    o.connect(g); g.connect(ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (dur || 0.12));
    o.stop(ctx.currentTime + (dur || 0.12));
  }
  let tradePeer = null;
  let tradeOffer = [];

  function resize() {
    canvas.width = innerWidth;
    canvas.height = innerHeight;
    ctx.imageSmoothingEnabled = false;
  }
  addEventListener("resize", resize);
  addEventListener("orientationchange", () => setTimeout(resize, 200));
  resize();

  function setChatExpanded(open) {
    document.body.classList.toggle("chat-expanded", !!open);
    const b = document.getElementById("chat-expand");
    if (b) {
      b.setAttribute("aria-label", open ? "Fechar chat" : "Abrir chat");
      b.title = open ? "Fechar chat" : "Abrir chat";
      b.textContent = open ? "✕" : "↗";
    }
    const el = document.getElementById("chat");
    if (el && open) setTimeout(() => { el.scrollTop = el.scrollHeight; }, 0);
  }
  document.getElementById("chat-expand")?.addEventListener("click", () => {
    setChatExpanded(!document.body.classList.contains("chat-expanded"));
  });

  function chatLine(text, cls) {
    const el = document.getElementById("chat");
    const nearBot = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
    const d = document.createElement("div");
    d.className = "line " + (cls || "say");
    d.textContent = text;
    el.appendChild(d);
    while (el.children.length > 80) el.removeChild(el.firstChild);
    if (nearBot) el.scrollTop = el.scrollHeight;
  }
  function floatText(x, y, text, color) {
    const el = document.createElement("div");
    el.className = "floater";
    el.textContent = text;
    el.style.color = color;
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.getElementById("dmg-layer").appendChild(el);
    setTimeout(() => el.remove(), 800);
  }
  function worldFloat(wx, wy, text, color) {
    const p = iso(wx, wy);
    floatText(innerWidth / 2 - camX + p.x, innerHeight / 2 - camY + p.y - 30, text, color);
  }
  function spawnDrop(x, y, from) {
    // 100% normal drop: every monster death creates loot on the ground.
    const common = [
      { id: "apple", icon: "🍎", name: "Maçã", qty: 1, use: "food" },
      { id: "potion", icon: "🧪", name: "Poção", qty: 1, use: "hp" },
      { id: "gem", icon: "💎", name: "Gema", qty: 1, use: "gold" },
      { id: "jewel", icon: "🔶", name: "Joia", qty: 1, use: "gold" },
      { id: "sword", icon: "⚔️", name: "Espada", qty: 1 },
      { id: "armor", icon: "🛡️", name: "Armadura", qty: 1 }
    ];
    const gold = 8 + ((Math.random() * 28) | 0);
    // Put the gold slightly away from the corpse so it is visible instead of
    // being picked up on the same frame as the kill.
    drops.push({
      x: x + 1.15, y: y + 0.35,
      gold, item: null, icon: "💰", name: gold + " gp",
      until: Date.now() + 30000
    });
    const item = Object.assign({}, common[(Math.random()*common.length)|0]);
    drops.push({
      x: x - 0.85, y: y + 0.75,
      gold: 0, item, icon: item.icon, name: item.name,
      until: Date.now() + 30000
    });
    chatLine("DROP 100%: " + item.name + " + " + gold + " gp!", "loot");
    const toast = document.getElementById("drop-toast");
    if (toast) {
      toast.textContent = "🎁 DROP: " + item.name + "  •  💰 +" + gold + " gp";
      toast.style.opacity = "1";
      clearTimeout(window.__flDropToastTimer);
      window.__flDropToastTimer = setTimeout(() => { toast.style.opacity = "0"; }, 1800);
    }
  }
  function pickupDrops() {
    if (!hero || !drops.length) return;
    const now = Date.now();
    drops = drops.filter((d) => {
      if (now > d.until) return false;
      if (Math.abs(d.x - hero.x) + Math.abs(d.y - hero.y) > 0.85) return true;
      if (d.gold) { hero.gold += d.gold; chatLine("+" + d.gold + " gp", "loot"); }
      if (d.item) {
        if (d.item.use === "gold") { hero.gold += 40; chatLine("+40 gp (gema)", "loot"); }
        else {
          const have = hero.inventory.find((i) => i.id === d.item.id);
          if (have) have.qty += d.item.qty || 1;
          else hero.inventory.push(Object.assign({}, d.item));
          chatLine("+ " + d.item.name, "loot");
        }
      }
      worldFloat(d.x, d.y, d.icon, "#ffe566");
      applyHero(hero);
      persistLocal();
      return false;
    });
  }
  function drawDrop(d) {
    const p = iso(d.x, d.y);
    const bob = Math.sin(frame / 8 + d.x) * 3;
    ctx.fillStyle = "rgba(255,220,80,.28)";
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, 10, 5, 0, 0, 7); ctx.fill();
    ctx.font = "22px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(d.icon, p.x, p.y - 8 + bob);
    ctx.font = "bold 9px sans-serif";
    ctx.fillStyle = "#ffe87a";
    ctx.strokeStyle = "rgba(0,0,0,.8)";
    ctx.lineWidth = 3;
    ctx.strokeText(d.name || "DROP", p.x, p.y + 14 + bob);
    ctx.fillText(d.name || "DROP", p.x, p.y + 14 + bob);
  }
  function applyHero(h) {
    hero = h;
    if (h.map && (h.map === "porto" || h.map === "templo" || h.map === "praia" || h.map === "bosque")) {
      currentMap = h.map;
    }
    document.getElementById("hp-fill").style.transform = "scaleX(" + (h.hp / h.hpMax) + ")";
    document.getElementById("mp-fill").style.transform = "scaleX(" + (h.mp / h.mpMax) + ")";
    document.getElementById("xp-fill").style.transform = "scaleX(" + (h.xp / h.xpNeed) + ")";
    const goldAmount = Math.max(0, Number(h.gold) || 0);
    const goldFill = Math.min(1, Math.log10(goldAmount + 1) / 4);
    document.getElementById("gold-fill").style.transform = "scaleX(" + Math.max(0.04, goldFill) + ")";
    document.getElementById("gold-txt").textContent = goldAmount.toLocaleString("pt-BR") + " gp";
    document.getElementById("hp-txt").textContent = Math.ceil(h.hp) + "/" + h.hpMax;
    document.getElementById("mp-txt").textContent = Math.ceil(h.mp) + "/" + h.mpMax;
    document.getElementById("meta").innerHTML =
      h.name + " · " + h.voc + " Lv." + h.level + " · " + (mapName || h.map || "") + "<br>" +
      h.gold + " gp · XP " + h.xp + "/" + h.xpNeed + " · ML " + Math.floor(h.skills.magic);
    drawPortrait();
    renderInv();
    try { refreshStatsBox(); } catch (e) {}
  }
  function drawPortrait() {
    const pc = document.getElementById("portrait");
    const c = pc.getContext("2d");
    c.imageSmoothingEnabled = true;
    c.fillStyle = "#1a1208"; c.fillRect(0, 0, 58, 58);
    const sheet = makeCharSheet(hero.voc, hero.race, hero.sex);
    c.drawImage(sheet, 0, 0, 32, 48, 7, 4, 44, 52);
  }
  const CLIENT_BONUSES = {
    sword: { name: "Espada de Ferro", atk: 8, crit: 3, element: "Físico" },
    armor: { name: "Armadura Reforçada", def: 6, hp: 15, element: "Físico" },
    shield: { name: "Escudo do Guardião", def: 4, block: 5, element: "Físico" },
    helm: { name: "Elmo de Aço", def: 3, hp: 8, element: "Físico" },
    wings: { name: "Asas Arcanas", speed: 2, magic: 5, element: "Arcano" }
  };
  function clientBonusText(id) {
    const b = CLIENT_BONUSES[id]; if (!b) return "";
    return Object.entries(b).filter(([k]) => k !== "name" && k !== "element").map(([k,v]) => {
      const labels={atk:"ATK",def:"DEF",crit:"CRIT",hp:"HP",block:"BLOQ",speed:"VEL",magic:"MAG"};
      return "+"+v+" "+(labels[k]||k);
    }).join(" · ");
  }
  function chestUserKey() {
    return (document.getElementById("acc-user")?.value || hero?.name || "").trim().toLowerCase();
  }
  function saveChest() {
    const user = chestUserKey();
    if (!user) return;
    const accs = loadAccs();
    if (!accs[user]) accs[user] = { pass: document.getElementById("acc-pass")?.value || "" };
    accs[user].cityChest = cityChest;
    if (hero) accs[user].hero = cloneHeroState(hero) || hero;
    saveAccs(accs);
    saveProgressBackup(user);
  }
  function stackItem(arr, item) {
    const same = arr.find(x => x.id === item.id);
    if (same) same.qty = (same.qty || 1) + (item.qty || 1);
    else arr.push(Object.assign({}, item, {qty:item.qty || 1}));
  }
  function renderChest() {
    const box = document.getElementById("chest-box");
    if (!box || !hero) return;
    const invBox = document.getElementById("chest-inv");
    const chestBox = document.getElementById("chest-slots");
    const count = cityChest.reduce((n,i)=>n+(i.qty||1),0);
    document.getElementById("chest-gold").textContent = "Itens guardados: " + count + "/30";
    invBox.innerHTML = ""; chestBox.innerHTML = "";

    (hero.inventory || []).forEach((it, index) => {
      const d=document.createElement("div"); d.className="slot";
      d.textContent=it.icon || "📦"; d.title=(it.name||"Item")+" · Toque para guardar";
      if((it.qty||1)>1){const q=document.createElement("span");q.className="qty";q.textContent=it.qty;d.appendChild(q);}
      d.onclick=()=>{
        if(cityChest.reduce((n,i)=>n+(i.qty||1),0)>=30){chatLine("Baú cheio (30 itens).","sys");return;}
        const moving=Object.assign({},it,{qty:1});
        it.qty=(it.qty||1)-1;
        if(it.qty<=0) hero.inventory.splice(index,1);
        stackItem(cityChest,moving); applyHero(hero); saveChest(); renderChest();
        chatLine("Guardado no baú: "+(moving.name||"item"),"loot");
      };
      invBox.appendChild(d);
    });
    for(let i=0;i<30;i++){
      const it=cityChest[i];
      const d=document.createElement("div"); d.className="slot";
      if(it){
        d.textContent=it.icon||"📦"; d.title=(it.name||"Item")+" · Toque para retirar";
        if((it.qty||1)>1){const q=document.createElement("span");q.className="qty";q.textContent=it.qty;d.appendChild(q);}
        d.onclick=()=>{
          const moving=Object.assign({},it,{qty:1});
          it.qty=(it.qty||1)-1;
          if(it.qty<=0) cityChest.splice(i,1);
          stackItem(hero.inventory,moving); applyHero(hero); saveChest(); renderChest();
          chatLine("Retirado do baú: "+(moving.name||"item"),"loot");
        };
      }
      chestBox.appendChild(d);
    }
  }
  function openChest() {
    if(!hero || currentMap!=="porto") return;
    const d=Math.hypot((hero.x||0)-22,(hero.y||0)-12);
    if(d>2.8){ chatLine("Aproxime-se do baú da cidade.","sys"); return; }
    const box=document.getElementById("chest-box");
    box.style.display="block"; renderChest();
  }
  function updateChestNear() {
    const b=document.getElementById("chest-near");
    if(!b) return;
    const near=hero && currentMap==="porto" && Math.hypot((hero.x||0)-22,(hero.y||0)-12)<=3.2;
    b.hidden=!near;
  }
  document.getElementById("chest-near")?.addEventListener("click",openChest);
  document.getElementById("chest-x")?.addEventListener("click",()=>{document.getElementById("chest-box").style.display="none";});

  function renderInv() {
    if (!hero) return;
    if (!hero.inventory) hero.inventory = [];
    if (!hero.eq) hero.eq = {};
    const box = document.getElementById("slots");
    box.innerHTML = "";
    for (let i = 0; i < 15; i++) {
      const it = hero.inventory[i];
      const d = document.createElement("div");
      d.className = "slot";
      if (it) {
        d.textContent = it.icon;
        d.title = it.name + (CLIENT_BONUSES[it.id] ? " — " + clientBonusText(it.id) : "");
        if (it.qty > 1) {
          const q = document.createElement("span"); q.className = "qty"; q.textContent = it.qty; d.appendChild(q);
        }
        const gear = ["sword", "shield", "armor", "helm", "wings"].includes(it.id);
        if (hero.eq && hero.eq[it.id]) { d.style.outline = "2px solid #f0d070"; d.title += " · EQUIPADO"; }
        const useIt = (e) => {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          if (d.dataset.busy) return;
          d.dataset.busy = "1";
          setTimeout(() => { delete d.dataset.busy; }, 300);
          if (tradePeer) {
            const offered=tradeOffer.filter(x=>x.id===it.id).reduce((n,x)=>n+(x.qty||1),0);
            if(offered >= (it.qty||1)){ chatLine("Você já colocou toda a quantidade desse item no trade.","sys"); return; }
            tradeOffer.push({ id: it.id, icon: it.icon, name: it.name, qty: 1, use: it.use });
            paintTradeMine();
            return;
          }
          handleLocal({ type: "use", id: it.id });
        };
        d.addEventListener("pointerup", useIt);
        if (gear) {
          const e = document.createElement("span");
          e.className = "qty";
          e.textContent = (hero.eq && hero.eq[it.id]) ? "ON" : "EQ";
          d.appendChild(e);
        }
      }
      box.appendChild(d);
    }
    const eqIds = ["sword","armor","shield","helm","wings"].filter(id => hero.eq && hero.eq[id]);
    const bonus = eqIds.map(clientBonusText).filter(Boolean).join(" · ");
    document.getElementById("gold-line").textContent =
      "Ouro: " + hero.gold + (bonus ? " · Bônus: " + bonus : "");
  }
  function paintTradeMine() {
    const box = document.getElementById("trade-my");
    box.innerHTML = "";
    tradeOffer.forEach((it) => {
      const d = document.createElement("div");
      d.className = "slot"; d.textContent = it.icon;
      box.appendChild(d);
    });
  }

  /* ---- net ---- */
  // V34: the online server is the source of truth for accounts and multiplayer.
  // LocalStorage is only a device cache; it is never the permanent account database.
  const SERVER = "forgotten-lands.onrender.com";
  function wsUrl() {
    let host = "";
    try { host = document.getElementById("acc-host").value.trim(); } catch (e) {}
    if (!host || /xxxx|aparelho/i.test(host)) host = SERVER;
    host = host.replace(/^https?:\/\//, "").replace(/^wss?:\/\//, "").replace(/\/.*$/, "");
    return "wss://" + host;
  }
  let offline = false;
  const LOCAL_KEY = "fl_accounts_v1";
  function loadAccs() {
    try { return JSON.parse(localStorage.getItem(LOCAL_KEY) || "{}"); } catch { return {}; }
  }
  function saveAccs(a) { localStorage.setItem(LOCAL_KEY, JSON.stringify(a)); }
  const PROGRESS_KEY = "fl_progress_backup_v2";
  function cloneHeroState(h) {
    try { return JSON.parse(JSON.stringify(h)); } catch { return null; }
  }
  function mergeInventorySafe(dst, src) {
    const out = Array.isArray(dst) ? dst : [];
    const incoming = Array.isArray(src) ? src : [];
    incoming.forEach(it => {
      if (!it || !it.id) return;
      const have = out.find(x => x.id === it.id);
      const qty = Math.max(1, Number(it.qty) || 1);
      if (have) have.qty = Math.max(Number(have.qty)||0, qty);
      else out.push(Object.assign({}, it, {qty}));
    });
    return out;
  }
  function mergeProgress(local, incoming) {
    if (!local) return incoming || null;
    if (!incoming) return cloneHeroState(local);
    const h = Object.assign({}, incoming);
    h.level = Math.max(Number(incoming.level)||1, Number(local.level)||1);
    h.gold = Math.max(Number(incoming.gold)||0, Number(local.gold)||0);
    h.xpNeed = Math.max(Number(incoming.xpNeed)||100, Number(local.xpNeed)||100);
    h.xp = (h.level > (Number(incoming.level)||1)) ? (Number(local.xp)||0) : Math.max(Number(incoming.xp)||0, Number(local.xp)||0);
    ["hpMax","mpMax","atk","def","ml"].forEach(k => h[k]=Math.max(Number(incoming[k])||0, Number(local[k])||0));
    h.inventory = mergeInventorySafe(incoming.inventory, local.inventory);
    h.eq = Object.assign({}, incoming.eq || {}, local.eq || {});
    h.quest = Object.assign({}, incoming.quest || {}, local.quest || {});
    h.name = incoming.name || local.name;
    h.voc = incoming.voc || local.voc;
    h.race = incoming.race || local.race;
    h.sex = incoming.sex || local.sex;
    h.map = incoming.map || local.map || "porto";
    return h;
  }
  function saveProgressBackup(user) {
    if (!hero || !user) return;
    try {
      const all = JSON.parse(localStorage.getItem(PROGRESS_KEY) || "{}");
      all[user] = cloneHeroState(hero);
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(all));
    } catch {}
  }
  function getProgressBackup(user) {
    try {
      const all = JSON.parse(localStorage.getItem(PROGRESS_KEY) || "{}");
      return all[user] || null;
    } catch { return null; }
  }

  let portalLock = 0;
  const LOCAL_WORLDS = [
    { id: "porto", name: "Porto Inicial · Halloween", theme: "halloween", min: 1,
      portals: [
        { x: 18, y: 15, to: "templo", tx: 18, ty: 20, need: 1 },
        { x: 10, y: 18, to: "praia", tx: 20, ty: 18, need: 1 },
        { x: 26, y: 18, to: "bosque", tx: 12, ty: 18, need: 1 },
      ],
      mobs: [] },
    { id: "praia", name: "Praia do Sul", theme: "sand", min: 1,
      portals: [{ x: 20, y: 18, to: "porto", tx: 12, ty: 18, need: 1 }],
      mobs: [["crab", 12, 12], ["crab", 24, 14], ["seagull", 16, 24], ["crab", 22, 22], ["seagull", 10, 20]] },
    { id: "bosque", name: "Bosque Claro", theme: "forest", min: 1,
      portals: [
        { x: 12, y: 18, to: "porto", tx: 24, ty: 18, need: 1 },
        { x: 26, y: 18, to: "planicie", tx: 12, ty: 18, need: 2 },
      ],
      mobs: [["boar", 14, 12], ["wasp", 22, 10], ["boar", 16, 24], ["wasp", 24, 22]] },
    { id: "templo", name: "Cidade do Templo", theme: "city", min: 1,
      portals: [
        { x: 18, y: 22, to: "porto", tx: 18, ty: 18, need: 1 },
        { x: 26, y: 18, to: "planicie", tx: 12, ty: 18, need: 2 },
      ],
      mobs: [] },
    { id: "planicie", name: "Planicie Verde", theme: "grass", min: 5,
      portals: [
        { x: 10, y: 18, to: "templo", tx: 24, ty: 18, need: 1 },
        { x: 26, y: 18, to: "floresta", tx: 12, ty: 18, need: 8 },
      ],
      mobs: [["snake", 16, 10], ["snake", 22, 12], ["spider", 20, 24], ["wolf", 14, 22], ["snake", 26, 10], ["spider", 8, 14]] },
    { id: "floresta", name: "Floresta Sombria", theme: "forest", min: 8,
      portals: [{ x: 10, y: 18, to: "planicie", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "pantano", tx: 10, ty: 18, need: 12 }],
      mobs: [["wolf", 14, 12], ["wolf", 22, 10], ["orc", 12, 26]] },
    { id: "pantano", name: "Pantano Podre", theme: "swamp", min: 12,
      portals: [{ x: 10, y: 18, to: "floresta", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "deserto", tx: 10, ty: 18, need: 16 }],
      mobs: [["slime", 14, 14], ["slime", 22, 12], ["snake", 20, 24]] },
    { id: "deserto", name: "Deserto de Areia", theme: "sand", min: 16,
      portals: [{ x: 10, y: 18, to: "pantano", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "caverna", tx: 18, ty: 22, need: 20 }],
      mobs: [["scarab", 14, 12], ["scarab", 22, 10], ["orc", 12, 26]] },
    { id: "caverna", name: "Caverna Umida", theme: "cave", min: 20,
      portals: [{ x: 18, y: 22, to: "deserto", tx: 26, ty: 18, need: 1 }, { x: 18, y: 10, to: "forte", tx: 18, ty: 22, need: 25 }],
      mobs: [["bat", 12, 12], ["bat", 24, 12], ["orc", 22, 24]] },
    { id: "forte", name: "Forte dos Orcs", theme: "fort", min: 25,
      portals: [{ x: 18, y: 22, to: "caverna", tx: 18, ty: 10, need: 1 }, { x: 18, y: 10, to: "vulcao", tx: 18, ty: 22, need: 30 }],
      mobs: [["orc", 12, 14], ["berserk", 22, 22], ["orc", 24, 14]] },
    { id: "vulcao", name: "Montanha de Fogo", theme: "lava", min: 30,
      portals: [{ x: 18, y: 22, to: "forte", tx: 18, ty: 10, need: 1 }, { x: 18, y: 10, to: "covil", tx: 18, ty: 22, need: 40 }],
      mobs: [["fire", 12, 14], ["fire", 24, 12], ["dragon", 22, 16]] },
    { id: "covil", name: "Covil do Dragao", theme: "lair", min: 40,
      portals: [{ x: 18, y: 22, to: "vulcao", tx: 18, ty: 10, need: 1 }],
      mobs: [["dragon", 14, 14], ["dragon", 22, 12], ["fire", 12, 24]] },
  ,
    {"id":"map001","name":"Vale 001","theme":"grass","min":10,"portals":[],"mobs":[["rat",9,11],["wasp",17,17],["troll",23,21]]},
    {"id":"map002","name":"Floresta 002","theme":"forest","min":20,"portals":[],"mobs":[["snake",10,14],["orc",18,22],["mummy",22,20]]},
    {"id":"map003","name":"Deserto 003","theme":"sand","min":30,"portals":[],"mobs":[["spider",11,17],["slime",19,14],["dragon",21,19]]},
    {"id":"map004","name":"Pântano 004","theme":"swamp","min":40,"portals":[],"mobs":[["wolf",12,20],["scarab",20,19],["fire",20,18]]},
    {"id":"map005","name":"Cidade 005","theme":"city","min":50,"portals":[],"mobs":[["boar",13,8],["bat",21,24],["berserk",19,17]]},
    {"id":"map006","name":"Geleira 006","theme":"ice","min":60,"portals":[],"mobs":[["wasp",14,11],["troll",22,16],["crab",18,16]]},
    {"id":"map007","name":"Vulcão 007","theme":"lava","min":70,"portals":[],"mobs":[["orc",15,14],["mummy",23,21],["rat",17,22]]},
    {"id":"map008","name":"Noite 008","theme":"night","min":80,"portals":[],"mobs":[["slime",16,17],["dragon",24,13],["snake",24,21]]},
    {"id":"map009","name":"Vale 009","theme":"grass","min":90,"portals":[],"mobs":[["scarab",17,20],["fire",16,18],["spider",23,20]]},
    {"id":"map010","name":"Floresta 010","theme":"forest","min":100,"portals":[],"mobs":[["bat",18,8],["berserk",17,23],["wolf",22,19]]},
    {"id":"map011","name":"Deserto 011","theme":"sand","min":110,"portals":[],"mobs":[["troll",19,11],["crab",18,15],["boar",21,18]]},
    {"id":"map012","name":"Pântano 012","theme":"swamp","min":120,"portals":[],"mobs":[["mummy",20,14],["rat",19,20],["wasp",20,17]]},
    {"id":"map013","name":"Cidade 013","theme":"city","min":130,"portals":[],"mobs":[["dragon",21,17],["snake",20,12],["orc",19,16]]},
    {"id":"map014","name":"Geleira 014","theme":"ice","min":140,"portals":[],"mobs":[["fire",22,20],["spider",21,17],["slime",18,22]]},
    {"id":"map015","name":"Vulcão 015","theme":"lava","min":150,"portals":[],"mobs":[["berserk",8,8],["wolf",22,22],["scarab",17,21]]},
    {"id":"map016","name":"Noite 016","theme":"night","min":160,"portals":[],"mobs":[["crab",9,11],["boar",23,14],["bat",24,20]]},
    {"id":"map017","name":"Vale 017","theme":"grass","min":170,"portals":[],"mobs":[["rat",10,14],["wasp",24,19],["troll",23,19]]},
    {"id":"map018","name":"Floresta 018","theme":"forest","min":180,"portals":[],"mobs":[["snake",11,17],["orc",16,24],["mummy",22,18]]},
    {"id":"map019","name":"Deserto 019","theme":"sand","min":190,"portals":[],"mobs":[["spider",12,20],["slime",17,16],["dragon",21,17]]},
    {"id":"map020","name":"Pântano 020","theme":"swamp","min":200,"portals":[],"mobs":[["wolf",13,8],["scarab",18,21],["fire",20,16]]},
    {"id":"map021","name":"Cidade 021","theme":"city","min":210,"portals":[],"mobs":[["boar",14,11],["bat",19,13],["berserk",19,22]]},
    {"id":"map022","name":"Geleira 022","theme":"ice","min":220,"portals":[],"mobs":[["wasp",15,14],["troll",20,18],["crab",18,21]]},
    {"id":"map023","name":"Vulcão 023","theme":"lava","min":230,"portals":[],"mobs":[["orc",16,17],["mummy",21,23],["rat",17,20]]},
    {"id":"map024","name":"Noite 024","theme":"night","min":240,"portals":[],"mobs":[["slime",17,20],["dragon",22,15],["snake",24,19]]},
    {"id":"map025","name":"Vale 025","theme":"grass","min":250,"portals":[],"mobs":[["scarab",18,8],["fire",23,20],["spider",23,18]]},
    {"id":"map026","name":"Floresta 026","theme":"forest","min":260,"portals":[],"mobs":[["bat",19,11],["berserk",24,12],["wolf",22,17]]},
    {"id":"map027","name":"Deserto 027","theme":"sand","min":270,"portals":[],"mobs":[["troll",20,14],["crab",16,17],["boar",21,16]]},
    {"id":"map028","name":"Pântano 028","theme":"swamp","min":280,"portals":[],"mobs":[["mummy",21,17],["rat",17,22],["wasp",20,22]]},
    {"id":"map029","name":"Cidade 029","theme":"city","min":290,"portals":[],"mobs":[["dragon",22,20],["snake",18,14],["orc",19,21]]},
    {"id":"map030","name":"Geleira 030","theme":"ice","min":300,"portals":[],"mobs":[["fire",8,8],["spider",19,19],["slime",18,20]]},
    {"id":"map031","name":"Vulcão 031","theme":"lava","min":310,"portals":[],"mobs":[["berserk",9,11],["wolf",20,24],["scarab",17,19]]},
    {"id":"map032","name":"Noite 032","theme":"night","min":320,"portals":[],"mobs":[["crab",10,14],["boar",21,16],["bat",24,18]]},
    {"id":"map033","name":"Vale 033","theme":"grass","min":330,"portals":[],"mobs":[["rat",11,17],["wasp",22,21],["troll",23,17]]},
    {"id":"map034","name":"Floresta 034","theme":"forest","min":340,"portals":[],"mobs":[["snake",12,20],["orc",23,13],["mummy",22,16]]},
    {"id":"map035","name":"Deserto 035","theme":"sand","min":350,"portals":[],"mobs":[["spider",13,8],["slime",24,18],["dragon",21,22]]},
    {"id":"map036","name":"Pântano 036","theme":"swamp","min":360,"portals":[],"mobs":[["wolf",14,11],["scarab",16,23],["fire",20,21]]},
    {"id":"map037","name":"Cidade 037","theme":"city","min":370,"portals":[],"mobs":[["boar",15,14],["bat",17,15],["berserk",19,20]]},
    {"id":"map038","name":"Geleira 038","theme":"ice","min":380,"portals":[],"mobs":[["wasp",16,17],["troll",18,20],["crab",18,19]]},
    {"id":"map039","name":"Vulcão 039","theme":"lava","min":390,"portals":[],"mobs":[["orc",17,20],["mummy",19,12],["rat",17,18]]},
    {"id":"map040","name":"Noite 040","theme":"night","min":400,"portals":[],"mobs":[["slime",18,8],["dragon",20,17],["snake",24,17]]},
    {"id":"map041","name":"Vale 041","theme":"grass","min":410,"portals":[],"mobs":[["scarab",19,11],["fire",21,22],["spider",23,16]]},
    {"id":"map042","name":"Floresta 042","theme":"forest","min":420,"portals":[],"mobs":[["bat",20,14],["berserk",22,14],["wolf",22,22]]},
    {"id":"map043","name":"Deserto 043","theme":"sand","min":430,"portals":[],"mobs":[["troll",21,17],["crab",23,19],["boar",21,21]]},
    {"id":"map044","name":"Pântano 044","theme":"swamp","min":440,"portals":[],"mobs":[["mummy",22,20],["rat",24,24],["wasp",20,20]]},
    {"id":"map045","name":"Cidade 045","theme":"city","min":450,"portals":[],"mobs":[["dragon",8,8],["snake",16,16],["orc",19,19]]},
    {"id":"map046","name":"Geleira 046","theme":"ice","min":460,"portals":[],"mobs":[["fire",9,11],["spider",17,21],["slime",18,18]]},
    {"id":"map047","name":"Vulcão 047","theme":"lava","min":470,"portals":[],"mobs":[["berserk",10,14],["wolf",18,13],["scarab",17,17]]},
    {"id":"map048","name":"Noite 048","theme":"night","min":480,"portals":[],"mobs":[["crab",11,17],["boar",19,18],["bat",24,16]]},
    {"id":"map049","name":"Vale 049","theme":"grass","min":490,"portals":[],"mobs":[["rat",12,20],["wasp",20,23],["troll",23,22]]},
    {"id":"map050","name":"Floresta 050","theme":"forest","min":500,"portals":[],"mobs":[["snake",13,8],["orc",21,15],["mummy",22,21]]},
    {"id":"map051","name":"Deserto 051","theme":"sand","min":510,"portals":[],"mobs":[["spider",14,11],["slime",22,20],["dragon",21,20]]},
    {"id":"map052","name":"Pântano 052","theme":"swamp","min":520,"portals":[],"mobs":[["wolf",15,14],["scarab",23,12],["fire",20,19]]},
    {"id":"map053","name":"Cidade 053","theme":"city","min":530,"portals":[],"mobs":[["boar",16,17],["bat",24,17],["berserk",19,18]]},
    {"id":"map054","name":"Geleira 054","theme":"ice","min":540,"portals":[],"mobs":[["wasp",17,20],["troll",16,22],["crab",18,17]]},
    {"id":"map055","name":"Vulcão 055","theme":"lava","min":550,"portals":[],"mobs":[["orc",18,8],["mummy",17,14],["rat",17,16]]},
    {"id":"map056","name":"Noite 056","theme":"night","min":560,"portals":[],"mobs":[["slime",19,11],["dragon",18,19],["snake",24,22]]},
    {"id":"map057","name":"Vale 057","theme":"grass","min":570,"portals":[],"mobs":[["scarab",20,14],["fire",19,24],["spider",23,21]]},
    {"id":"map058","name":"Floresta 058","theme":"forest","min":580,"portals":[],"mobs":[["bat",21,17],["berserk",20,16],["wolf",22,20]]},
    {"id":"map059","name":"Deserto 059","theme":"sand","min":590,"portals":[],"mobs":[["troll",22,20],["crab",21,21],["boar",21,19]]},
    {"id":"map060","name":"Pântano 060","theme":"swamp","min":600,"portals":[],"mobs":[["mummy",8,8],["rat",22,13],["wasp",20,18]]},
    {"id":"map061","name":"Cidade 061","theme":"city","min":610,"portals":[],"mobs":[["dragon",9,11],["snake",23,18],["orc",19,17]]},
    {"id":"map062","name":"Geleira 062","theme":"ice","min":620,"portals":[],"mobs":[["fire",10,14],["spider",24,23],["slime",18,16]]},
    {"id":"map063","name":"Vulcão 063","theme":"lava","min":630,"portals":[],"mobs":[["berserk",11,17],["wolf",16,15],["scarab",17,22]]},
    {"id":"map064","name":"Noite 064","theme":"night","min":640,"portals":[],"mobs":[["crab",12,20],["boar",17,20],["bat",24,21]]},
    {"id":"map065","name":"Vale 065","theme":"grass","min":650,"portals":[],"mobs":[["rat",13,8],["wasp",18,12],["troll",23,20]]},
    {"id":"map066","name":"Floresta 066","theme":"forest","min":660,"portals":[],"mobs":[["snake",14,11],["orc",19,17],["mummy",22,19]]},
    {"id":"map067","name":"Deserto 067","theme":"sand","min":670,"portals":[],"mobs":[["spider",15,14],["slime",20,22],["dragon",21,18]]},
    {"id":"map068","name":"Pântano 068","theme":"swamp","min":680,"portals":[],"mobs":[["wolf",16,17],["scarab",21,14],["fire",20,17]]},
    {"id":"map069","name":"Cidade 069","theme":"city","min":690,"portals":[],"mobs":[["boar",17,20],["bat",22,19],["berserk",19,16]]},
    {"id":"map070","name":"Geleira 070","theme":"ice","min":700,"portals":[],"mobs":[["wasp",18,8],["troll",23,24],["crab",18,22]]},
    {"id":"map071","name":"Vulcão 071","theme":"lava","min":710,"portals":[],"mobs":[["orc",19,11],["mummy",24,16],["rat",17,21]]},
    {"id":"map072","name":"Noite 072","theme":"night","min":720,"portals":[],"mobs":[["slime",20,14],["dragon",16,21],["snake",24,20]]},
    {"id":"map073","name":"Vale 073","theme":"grass","min":730,"portals":[],"mobs":[["scarab",21,17],["fire",17,13],["spider",23,19]]},
    {"id":"map074","name":"Floresta 074","theme":"forest","min":740,"portals":[],"mobs":[["bat",22,20],["berserk",18,18],["wolf",22,18]]},
    {"id":"map075","name":"Deserto 075","theme":"sand","min":750,"portals":[],"mobs":[["troll",8,8],["crab",19,23],["boar",21,17]]},
    {"id":"map076","name":"Pântano 076","theme":"swamp","min":760,"portals":[],"mobs":[["mummy",9,11],["rat",20,15],["wasp",20,16]]},
    {"id":"map077","name":"Cidade 077","theme":"city","min":770,"portals":[],"mobs":[["dragon",10,14],["snake",21,20],["orc",19,22]]},
    {"id":"map078","name":"Geleira 078","theme":"ice","min":780,"portals":[],"mobs":[["fire",11,17],["spider",22,12],["slime",18,21]]},
    {"id":"map079","name":"Vulcão 079","theme":"lava","min":790,"portals":[],"mobs":[["berserk",12,20],["wolf",23,17],["scarab",17,20]]},
    {"id":"map080","name":"Noite 080","theme":"night","min":800,"portals":[],"mobs":[["crab",13,8],["boar",24,22],["bat",24,19]]},
    {"id":"map081","name":"Vale 081","theme":"grass","min":810,"portals":[],"mobs":[["rat",14,11],["wasp",16,14],["troll",23,18]]},
    {"id":"map082","name":"Floresta 082","theme":"forest","min":820,"portals":[],"mobs":[["snake",15,14],["orc",17,19],["mummy",22,17]]},
    {"id":"map083","name":"Deserto 083","theme":"sand","min":830,"portals":[],"mobs":[["spider",16,17],["slime",18,24],["dragon",21,16]]},
    {"id":"map084","name":"Pântano 084","theme":"swamp","min":840,"portals":[],"mobs":[["wolf",17,20],["scarab",19,16],["fire",20,22]]},
    {"id":"map085","name":"Cidade 085","theme":"city","min":850,"portals":[],"mobs":[["boar",18,8],["bat",20,21],["berserk",19,21]]},
    {"id":"map086","name":"Geleira 086","theme":"ice","min":860,"portals":[],"mobs":[["wasp",19,11],["troll",21,13],["crab",18,20]]},
    {"id":"map087","name":"Vulcão 087","theme":"lava","min":870,"portals":[],"mobs":[["orc",20,14],["mummy",22,18],["rat",17,19]]},
    {"id":"map088","name":"Noite 088","theme":"night","min":880,"portals":[],"mobs":[["slime",21,17],["dragon",23,23],["snake",24,18]]},
    {"id":"map089","name":"Vale 089","theme":"grass","min":890,"portals":[],"mobs":[["scarab",22,20],["fire",24,15],["spider",23,17]]},
    {"id":"map090","name":"Floresta 090","theme":"forest","min":900,"portals":[],"mobs":[["bat",8,8],["berserk",16,20],["wolf",22,16]]},
    {"id":"map091","name":"Deserto 091","theme":"sand","min":910,"portals":[],"mobs":[["troll",9,11],["crab",17,12],["boar",21,22]]},
    {"id":"map092","name":"Pântano 092","theme":"swamp","min":920,"portals":[],"mobs":[["mummy",10,14],["rat",18,17],["wasp",20,21]]},
    {"id":"map093","name":"Cidade 093","theme":"city","min":930,"portals":[],"mobs":[["dragon",11,17],["snake",19,22],["orc",19,20]]},
    {"id":"map094","name":"Geleira 094","theme":"ice","min":940,"portals":[],"mobs":[["fire",12,20],["spider",20,14],["slime",18,19]]},
    {"id":"map095","name":"Vulcão 095","theme":"lava","min":950,"portals":[],"mobs":[["berserk",13,8],["wolf",21,19],["scarab",17,18]]},
    {"id":"map096","name":"Noite 096","theme":"night","min":960,"portals":[],"mobs":[["crab",14,11],["boar",22,24],["bat",24,17]]},
    {"id":"map097","name":"Vale 097","theme":"grass","min":970,"portals":[],"mobs":[["rat",15,14],["wasp",23,16],["troll",23,16]]},
    {"id":"map098","name":"Floresta 098","theme":"forest","min":980,"portals":[],"mobs":[["snake",16,17],["orc",24,21],["mummy",22,22]]},
    {"id":"map099","name":"Deserto 099","theme":"sand","min":990,"portals":[],"mobs":[["spider",17,20],["slime",16,13],["dragon",21,21]]},
    {"id":"map100","name":"Pântano 100","theme":"swamp","min":1000,"portals":[],"mobs":[["wolf",18,8],["scarab",17,18],["fire",20,20]]}];
  const LOCAL_MOBS = {
    rat: { hp: 22, atk: 5, xp: 22, gold: 3, name: "Rato" },
    crab: { hp: 28, atk: 6, xp: 26, gold: 4, name: "Caranguejo" },
    seagull: { hp: 18, atk: 4, xp: 16, gold: 2, name: "Gaivota" },
    boar: { hp: 55, atk: 9, xp: 48, gold: 7, name: "Javali" },
    wasp: { hp: 30, atk: 8, xp: 28, gold: 4, name: "Vespa" },
    spider: { hp: 36, atk: 7, xp: 32, gold: 4, name: "Aranha" },
    snake: { hp: 48, atk: 9, xp: 45, gold: 6, name: "Cobra" },
    wolf: { hp: 70, atk: 12, xp: 70, gold: 9, name: "Lobo" },
    slime: { hp: 90, atk: 14, xp: 95, gold: 12, name: "Lodo" },
    scarab: { hp: 120, atk: 16, xp: 130, gold: 16, name: "Escaravelho" },
    bat: { hp: 140, atk: 18, xp: 160, gold: 18, name: "Morcego Gigante" },
    orc: { hp: 160, atk: 20, xp: 190, gold: 22, name: "Orc" },
    berserk: { hp: 220, atk: 26, xp: 280, gold: 32, name: "Orc Berseker" },
    fire: { hp: 260, atk: 30, xp: 360, gold: 40, name: "Elemental de Fogo" },
    dragon: { hp: 420, atk: 38, xp: 650, gold: 80, name: "Dragao" },
  };
  const VOC_OFF = {
    knight: { hp: 220, mp: 40, atk: 24, def: 14, ml: 2 },
    paladin: { hp: 170, mp: 80, atk: 20, def: 10, ml: 6 },
    sorcerer: { hp: 125, mp: 160, atk: 12, def: 5, ml: 14 },
    druid: { hp: 135, mp: 150, atk: 12, def: 6, ml: 13 },
  };

  function makeLocalHero(name, voc) {
    const v = VOC_OFF[voc] || VOC_OFF.knight;
    return {
      name, voc, race: chosenRace, sex: chosenSex, map: "porto", x: 18, y: 21, gold: 50, level: 1, xp: 0, xpNeed: 66,
      hp: v.hp, hpMax: v.hp, mp: v.mp, mpMax: v.mp, atk: v.atk, def: v.def, ml: v.ml,
      cap: 350, soul: 100, food: 20,
      skills: { sword: 20, dist: 18, shielding: 18, magic: v.ml },
      inventory: [
        { id: "sword", icon: "🗡️", name: "Espada pequena", qty: 1 },
        { id: "shield", icon: "🛡️", name: "Escudo de madeira", qty: 1 },
        { id: "armor", icon: "🥋", name: "Armadura de couro", qty: 1 },
        { id: "helm", icon: "⛑️", name: "Elmo raso", qty: 1 },
        { id: "wings", icon: "🪽", name: "Asinhas", qty: 1 },
        { id: "apple", icon: "🍎", name: "Maca", qty: 10, use: "food" },
        { id: "hp", icon: "🧪", name: "Pocao de vida", qty: 5, use: "hp" },
        { id: "mp", icon: "📘", name: "Pocao de mana", qty: 3, use: "mp" },
      ],
      quest: { rats: 0, kills: 0, done: false, q2: false, q3: false, q4: false, fuse: 0 },
      eq: {},
    };
  }

  function spawnLocalMap(id) {
    const w = LOCAL_WORLDS.find((x) => x.id === id) || LOCAL_WORLDS[0];
    currentMap = w.id; currentTheme = (w.id === "porto" ? "halloween" : w.theme); mapName = w.name;
    portals = w.portals;
    drops = [];
    genMap(w.theme);
    creatures = w.mobs.map((m, i) => {
      const st = LOCAL_MOBS[m[0]] || LOCAL_MOBS.rat;
      return {
        id: "l" + i + m[0], kind: m[0], name: st.name, map: w.id,
        x: m[1], y: m[2], hp: st.hp, hpMax: st.hp, atk: st.atk, xp: st.xp, gold: st.gold, alive: true, aggro: 0, lastHit: 0,
      };
    });
    others = hero ? [{ name: hero.name, voc: hero.voc, x: hero.x, y: hero.y, hp: hero.hp, hpMax: hero.hpMax, level: hero.level, map: hero.map }] : [];
  }

  function goToMap(id, tx, ty) {
    const w = LOCAL_WORLDS.find((x) => x.id === id);
    if (!w) { chatLine("Mapa nao existe.", "sys"); return; }
    if (hero && hero.level < (w.min || 1) && w.min > 1) {
      chatLine("Precisa de level " + w.min + " para " + w.name + ".", "sys");
      return;
    }
    portalLock = Date.now() + 2500;
    hero.map = id;
    // Never keep remote players from the previous map visible after a portal.
    others = hero ? [{ name: hero.name, voc: hero.voc, race: hero.race, sex: hero.sex,
      x: hero.x, y: hero.y, hp: hero.hp, hpMax: hero.hpMax, level: hero.level, map: id }] : [];
    let lx = tx != null ? tx : 16;
    let ly = ty != null ? ty : 16;
    spawnLocalMap(id);
    if (cellBlocked(lx, ly)) { lx = 16; ly = 16; }
    if (cellBlocked(lx, ly)) { lx = 18; ly = 21; }
    hero.x = lx; hero.y = ly;
    visX = lx; visY = ly;
    if (id === "porto" || id === "templo") { hero.hp = hero.hpMax; creatures = []; }
    applyHero(hero);
    if (!offline && ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify({type:"move", x:Math.round(hero.x), y:Math.round(hero.y), map:id, mapChange:true})); } catch(e) {}
    }
    updateChestNear();
    chatLine(t("arrived") + mapName + ".", "sys");
    persistLocal();
    playMapMusic(w.theme);
  }

  function persistLocal() {
    if (!hero) return;
    hero.map = currentMap || hero.map || "porto";
    hero.theme = currentTheme;
    const accs = loadAccs();
    const user = (document.getElementById("acc-user").value || hero.name || "").trim().toLowerCase();
    if (!user) return;
    if (!accs[user]) accs[user] = { pass: document.getElementById("acc-pass").value };
    accs[user].hero = cloneHeroState(hero) || hero;
    accs[user].cityChest = cityChest;
    accs[user].pass = accs[user].pass || document.getElementById("acc-pass").value;
    saveAccs(accs);
    saveProgressBackup(user);
    try { localStorage.setItem("fl_last_user", user); } catch (e) {}
  }
  document.addEventListener("visibilitychange", () => { if (document.hidden) persistLocal(); });
  window.addEventListener("pagehide", persistLocal);
  window.addEventListener("beforeunload", persistLocal);
  setInterval(() => { if (hero) { persistLocal(); updateChestNear(); } }, 8000);
  setInterval(() => { if (hero) updateChestNear(); }, 500);

  function mobXpReward(baseXp) {
    const base = Math.max(1, Number(baseXp) || 1);
    // Fast progression through levels 1-10, then progressively slower.
    if (hero.level < 5) return Math.floor(base * 3.0);
    if (hero.level < 10) return Math.floor(base * 2.4);
    if (hero.level < 20) return Math.floor(base * 1.6);
    if (hero.level < 50) return Math.floor(base * 1.25);
    return base;
  }

  function localGainXp(n) {
    hero.xp += Math.max(0, Number(n) || 0);
    while (hero.xp >= hero.xpNeed && hero.level < 1000) {
      hero.xp -= hero.xpNeed;
      hero.level = Math.min(1000, hero.level + 1);
      if (hero.level < 10) hero.xpNeed = Math.floor(hero.xpNeed * 1.07) + 8;
      else if (hero.level < 20) hero.xpNeed = Math.floor(hero.xpNeed * 1.22) + 24;
      else hero.xpNeed = Math.floor(hero.xpNeed * 1.38) + 50;
      // Level-up growth: HP and MP/Energy increase progressively with the new level.
      const hpGain = 12 + Math.floor(hero.level * 1.5);
      const mpGain = 7 + Math.floor(hero.level * 0.9);
      hero.hpMax += hpGain;
      hero.mpMax += mpGain;
      hero.atk += 2 + Math.floor(hero.level / 100);
      hero.def += 1 + Math.floor(hero.level / 150);
      hero.ml += 1;
      // Refill the newly increased maximums immediately after every level-up.
      hero.hp = hero.hpMax;
      hero.mp = hero.mpMax;
      chatLine(t("levelup") + hero.level + "!", "sys");
    }
  }

  function startOffline(kind) {
    offline = true;
    connected = true;
    const user = document.getElementById("acc-user").value.trim().toLowerCase();
    const pass = document.getElementById("acc-pass").value;
    const name = (document.getElementById("acc-name").value.trim() || user || "Heroi").slice(0, 16);
    const accs = loadAccs();
    if (!user || user.length < 3) {
      document.getElementById("splash-err").textContent = "Conta: minimo 3 letras.";
      return;
    }
    if (kind === "register") {
      if (accs[user]) { document.getElementById("splash-err").textContent = "Essa conta ja existe neste celular."; return; }
      accs[user] = { pass, hero: makeLocalHero(name, chosenVoc) };
      saveAccs(accs);
    } else {
      if (!accs[user]) {
        accs[user] = { pass, hero: makeLocalHero(name, chosenVoc) };
        saveAccs(accs);
      } else if (accs[user].pass && pass && accs[user].pass !== pass) {
        document.getElementById("splash-err").textContent = "Senha errada.";
        return;
      }
    }
    hero = mergeProgress(getProgressBackup(user), accs[user].hero || makeLocalHero(name, chosenVoc)) || makeLocalHero(name, chosenVoc);
    if (hero.race === "elfa") { hero.race = "elfo"; hero.sex = "f"; }
    cityChest = Array.isArray(accs[user].cityChest) ? accs[user].cityChest : [];
    accs[user].hero = cloneHeroState(hero) || hero;
    accs[user].cityChest = cityChest;
    saveAccs(accs);
    saveProgressBackup(user);
    if (!hero.map) hero.map = "porto";
    spawnLocalMap(hero.map);
    applyHero(hero);
    document.getElementById("splash").style.display = "none";
    document.body.classList.add("ingame");
    document.getElementById("online").textContent = mapName + " · modo local (sem servidor)";
    playMapMusic(currentTheme);
    setTimeout(giveDailyBonus, 600);
  }

  function send(obj) {
    handleLocal(obj);
    if (!offline && ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify(obj)); } catch (e) {}
    }
  }

  function handleLocal(msg) {
    if (!hero) return;
    if (msg.type === "move") {
      if (portalLock > Date.now()) return;
      const gx = Math.round(hero.x), gy = Math.round(hero.y);
      const p = portals.find((o) => o.x === gx && o.y === gy);
      if (p) {
        if (hero.level < p.need) { chatLine("Precisa de level " + p.need + " para este portal.", "sys"); return; }
        goToMap(p.to, p.tx, p.ty);
      }
    }
    if (msg.type === "atk") {
      if (inSafeZone()) return;
      const target = creatures.find((c) => c.id === msg.target && c.alive);
      if (!target) return;
      const bonus = hero.eq && hero.eq.sword ? 8 : 0;
      const dmg = Math.max(1, hero.atk + bonus + ((Math.random() * 8) | 0) - 2);
      target.hp -= dmg;
      worldFloat(target.x, target.y, "-" + dmg, "#ffee66");
      if (target.hp <= 0) {
        target.alive = false;
        const xpReward = mobXpReward(target.xp);
        localGainXp(xpReward);
        hero.gold += target.gold || 0;
        if (target.kind === "rat") hero.quest.rats++;
        chatLine(t("killed") + target.name + " (+" + xpReward + " xp)", "loot");
        hero.quest = hero.quest || { rats: 0, kills: 0, done: false, q2: false, q3: false, q4: false, fuse: 0 };
        hero.quest.rats++;
        hero.quest.kills = (hero.quest.kills || 0) + 1;
        if (!hero.quest.done && hero.quest.kills >= 5) {
          hero.quest.done = true;
          hero.gold += 100;
          localGainXp(200);
          chatLine(t("q1ok"), "loot");
        }
        if (!hero.quest.q2 && hero.quest.kills >= 15) {
          hero.quest.q2 = true;
          hero.gold += 250;
          localGainXp(400);
          chatLine("Missao 2: 15 monstros. +250 gp", "loot");
        }
        if (!hero.quest.q4 && hero.level >= 5) {
          hero.quest.q4 = true;
          hero.gold += 200;
          chatLine("Missao level 5. +200 gp", "loot");
        }
        applyHero(hero);
        spawnDrop(target.x, target.y, target.name);
        persistLocal();
        setTimeout(() => {
          if (target) {
            target.alive = true;
            target.hp = target.hpMax;
            target.lastHit = 0;
            target.aggro = 0;
          }
        }, 2000);
      }
    }
    if (msg.type === "spell") {
      const book = {
        exura: () => { if (hero.mp < 20) return chatLine("Pouca mana.", "sys"); hero.mp -= 20; hero.hp = Math.min(hero.hpMax, hero.hp + 20 + hero.ml * 3); },
        exori: () => { if (hero.voc !== "knight" || hero.mp < 28) return; hero.mp -= 28; creatures.forEach((c) => { if (c.alive && Math.abs(c.x - hero.x) + Math.abs(c.y - hero.y) <= 1) { c.hp -= 22 + hero.atk; if (c.hp <= 0) { c.alive = false; const xpReward = mobXpReward(c.xp); localGainXp(xpReward); hero.gold += c.gold || 0; spawnDrop(c.x, c.y, c.name); persistLocal(); setTimeout(() => { c.alive = true; c.hp = c.hpMax; c.lastHit = 0; c.aggro = 0; }, 2000); } } }); },
        "exori vis": () => { if (hero.voc !== "sorcerer" || hero.mp < 36) return; hero.mp -= 36; const c = creatures.find((m) => m.alive && Math.abs(m.x - hero.x) + Math.abs(m.y - hero.y) <= 3); if (c) { c.hp -= 30 + hero.ml * 2; if (c.hp <= 0) { c.alive = false; localGainXp(c.xp); hero.gold += c.gold || 0; spawnDrop(c.x, c.y, c.name); persistLocal(); setTimeout(() => { c.alive = true; c.hp = c.hpMax; c.lastHit = 0; c.aggro = 0; }, 2000); } } },
        "exura gran": () => { if (hero.mp < 40) return; hero.mp -= 40; hero.hp = Math.min(hero.hpMax, hero.hp + 45 + hero.ml * 4); },
        "utevo lux": () => { if (hero.mp < 16) return; hero.mp -= 16; },
      };
      if (book[msg.name]) book[msg.name]();
      applyHero(hero);
    }
    if (msg.type === "use") {
      if (!hero.inventory) return;
      const it = hero.inventory.find((i) => i.id === msg.id);
      if (!it) return;
      if (!hero.eq) hero.eq = {};
      if (["sword", "shield", "armor", "helm", "wings"].includes(it.id)) {
        if (hero.eq[it.id]) {
          delete hero.eq[it.id];
          chatLine(t("unequipped") + it.name + ".", "sys");
        } else {
          hero.eq[it.id] = true;
          chatLine(t("equipped") + it.name + ".", "sys");
          if (it.id === "wings") { flying = true; const fb = document.getElementById("btn-fly"); if (fb) fb.classList.add("on"); }
        }
        applyHero(hero); persistLocal();
        return;
      }
      if (it.use === "food") { it.qty--; hero.food = Math.min(40, hero.food + 12); }
      if (it.use === "hp") { it.qty--; hero.hp = Math.min(hero.hpMax, hero.hp + 70); }
      if (it.use === "mp") { it.qty--; hero.mp = Math.min(hero.mpMax, hero.mp + 55); }
      if (it.use === "gold") { it.qty--; hero.gold += it.id === "bless" ? 120 : 40; }
      if (it.qty <= 0) hero.inventory = hero.inventory.filter((i) => i !== it);
      applyHero(hero); persistLocal();
    }
    if (msg.type === "npc") {
      if (msg.act === "apple" && hero.gold >= 8) { hero.gold -= 8; const f = hero.inventory.find((i) => i.id === "apple"); if (f) f.qty += 3; else hero.inventory.push({ id: "apple", icon: "🍎", name: "Maca", qty: 3, use: "food" }); }
      if (msg.act === "hp" && hero.gold >= 25) { hero.gold -= 25; const f = hero.inventory.find((i) => i.id === "hp"); if (f) f.qty++; else hero.inventory.push({ id: "hp", icon: "🧪", name: "Pocao de vida", qty: 1, use: "hp" }); }
      if (msg.act === "quest") {
        if (hero.quest.rats >= 5 && !hero.quest.done) { hero.quest.done = true; hero.gold += 80; localGainXp(200); chatLine("Missao cumprida!", "sys"); }
        else chatLine("Mate 5 ratos. " + hero.quest.rats + "/5", "sys");
      }
      applyHero(hero); persistLocal();
    }
    if (msg.type === "chat") chatLine(hero.name + ": " + msg.text, "say");
  }

  function notifyText(title, body) {
    try {
      if ("Notification" in window && Notification.permission === "granted") new Notification(title, { body });
    } catch (e) {}
  }
  async function enableNotifications() {
    if (!("Notification" in window)) { chatLine("Notificacoes nao suportadas neste dispositivo.", "sys"); return; }
    try {
      const p = await Notification.requestPermission();
      notifyEnabled = p === "granted";
      localStorage.setItem("fl_notify", notifyEnabled ? "1" : "0");
      chatLine(notifyEnabled ? "Notificacoes ativadas." : "Permissao de notificacao nao concedida.", "sys");
      if (notifyEnabled) notifyText("Forgotten Lands", "Lembretes do jogo estao ativados.");
    } catch (e) { chatLine("Nao foi possivel ativar notificacoes.", "sys"); }
  }
  function armReminderSystem() {
    if (reminderTimer) clearInterval(reminderTimer);
    reminderTimer = setInterval(() => {
      if (!notifyEnabled || !hero) return;
      const idle = Date.now() - lastActivityAt;
      if (idle >= 60 * 60 * 1000) {
        notifyText("Forgotten Lands", "Seu personagem e seus amigos estao esperando. Volte ao mundo!");
        lastActivityAt = Date.now();
      }
    }, 60 * 1000);
  }
  ["pointerdown","keydown","touchstart"].forEach(ev => addEventListener(ev, () => { lastActivityAt = Date.now(); }, {passive:true}));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) lastActivityAt = Date.now(); });

  function setServerStatus(text) {
    const el = document.getElementById("online");
    if (el) el.textContent = text;
    const st = document.getElementById("stat-status");
    if (st) st.textContent = "●";
  }

  function connect(kind) {
    const err = document.getElementById("splash-err");
    const hostField = document.getElementById("acc-host").value.trim();
    if (hostField) localStorage.setItem("fl_host", hostField);
    const onRender = location.hostname.indexOf("onrender.com") !== -1;
    if (!hostField && location.protocol === "file:" && !onRender) {
      err.textContent = "Cola o link do Render (xxxx.onrender.com) no campo IP.";
      return;
    }
    err.textContent = "conectando no multiplayer...";
    let settled = false;
    const failTimer = setTimeout(() => {
      if (!settled) {
        settled = true;
        err.textContent = "Servidor acordando... espera 1 min e toca Entrar de novo.";
      }
    }, 4000);
    try { if (ws) ws.close(); } catch {}
    try {
      ws = new WebSocket(wsUrl());
    } catch (e) {
      clearTimeout(failTimer);
      err.textContent = "URL do servidor invalida.";
      return;
    }
    ws.onopen = () => {
      settled = true;
      clearTimeout(failTimer);
      connected = true;
      offline = false;
      const payload = {
        type: kind,
        user: document.getElementById("acc-user").value.trim(),
        pass: document.getElementById("acc-pass").value,
        name: document.getElementById("acc-name").value.trim() || document.getElementById("acc-user").value.trim(),
        voc: chosenVoc,
        race: chosenRace,
        sex: chosenSex,
        map: "porto",
        clientVersion: "V34",
      };
      ws.send(JSON.stringify(payload));
    };
    ws.onerror = () => {
      if (!settled) { settled = true; clearTimeout(failTimer); err.textContent = "Erro no WebSocket. Usa o link https do Render."; }
    };
    ws.onclose = () => {
      connected = false;
      persistLocal();
      if (!offline && hero) {
        chatLine("Desconectado do servidor. Seus dados permanecem no servidor.", "sys");
        setServerStatus("servidor: reconectando...");
      }
    };
    ws.onmessage = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.type === "err") err.textContent = m.text;
      if (m.type === "you") {
        const incoming = m.hero || {};
        const user = (document.getElementById("acc-user").value || "").trim().toLowerCase();
        // The server is authoritative. A new APK/device retrieves the same
        // character from the server instead of depending on old localStorage.
        hero = incoming;
        if (!hero || !hero.name) {
          err.textContent = "O servidor não enviou o personagem desta conta.";
          return;
        }
        if (!hero.inventory) hero.inventory = [];
        if (!hero.eq) hero.eq = {};
        if (!hero.quest) hero.quest = {};
        if (!hero.map) hero.map = "porto";
        if (!hero.eq) hero.eq = {};
        applyHero(hero);
        persistLocal();
        spawnLocalMap(hero.map || "porto");
        document.getElementById("splash").style.display = "none";
        document.body.classList.add("ingame");
        lastActivityAt = Date.now();
        setTimeout(giveDailyBonus, 600);
        if (m.online) document.getElementById("online").textContent = "online: " + m.online.join(", ");
      }
      if (m.type === "world") {
        const incomingPlayers = Array.isArray(m.players) ? m.players : [];
        // Each world packet is authoritative for the currently connected world.
        // Normalize map so the renderer never leaks a player from another map.
        others = incomingPlayers
          .filter(p => p && p.name)
          .map(p => ({...p, map: p.map || p.currentMap || hero?.map || currentMap}))
          .filter(p => !hero || p.name === hero.name || p.map === currentMap);
        if (hero && !others.some(p => p.name === hero.name)) {
          others.unshift({name:hero.name,voc:hero.voc,race:hero.race,sex:hero.sex,
            x:hero.x,y:hero.y,hp:hero.hp,hpMax:hero.hpMax,level:hero.level,map:currentMap});
        }
        document.getElementById("online").textContent =
          (mapName ? mapName + " · " : "") + "online: " + others.filter(p => !hero || p.name !== hero.name).map(p => p.name).join(", ");
      }
      
      if (m.type === "partyInvite") {
        window.ForgottenLandsPartyApply({members:m.members||[], inviteFrom:m.from||m.fromName});
        if (confirm((m.from||"Jogador") + " convidou você para uma party. Aceitar?")) {
          send({type:"partyAccept", from:m.from});
        } else {
          send({type:"partyDecline", from:m.from});
        }
      }
      if (m.type === "party" || m.type === "partyUpdate") {
        window.ForgottenLandsPartyApply(m);
        if (m.text) chatLine(m.text,"sys");
      }
      if (m.type === "partyXp") {
        const gain=Number(m.xp||0);
        if (gain>0 && hero && hero.level<1000) {
          localGainXp(gain);
          chatLine("Party XP +"+gain,"loot");
          applyHero(hero);
        }
      }
if (m.type === "chat") chatLine((m.from ? m.from + ": " : "") + m.text, m.ch || "say");
      if (m.type === "pvpHit") {
        if (!canPvpHere()) return;
        hero.hp = Math.max(0, (m.hp != null ? m.hp : hero.hp - (m.dmg || 4)));
        worldFloat(hero.x, hero.y, "-" + (m.dmg || 0), "#ff66ee");
        chatLine((m.from || "?") + " PvP " + (m.dmg || ""), "dmg");
        applyHero(hero);
      }
      if (m.type === "float") {
        if (inSafeZone()) return;
        if (m.self) floatText(innerWidth / 2, innerHeight / 2 - 40, m.text, m.color);
        else floatText(innerWidth / 2, innerHeight / 2 - 80, m.text, m.color);
      }
      if (m.type === "tradeOpen") {
        tradePeer = m.peer; tradeOffer = [];
        document.getElementById("trade-box").style.display = "block";
        document.getElementById("trade-peer").textContent = m.peer;
      }
      if (m.type === "tradePeer") {
        const box = document.getElementById("trade-his");
        box.innerHTML = "";
        (m.items || []).forEach((it) => {
          const d = document.createElement("div"); d.className = "slot"; d.textContent = it.icon + (it.qty > 1 ? it.qty : "");
          box.appendChild(d);
        });
        chatLine("Oferta: " + (m.gold || 0) + " gp", "loot");
      }
      if (m.type === "tradeDone" || m.type === "tradeClose") {
        document.getElementById("trade-box").style.display = "none";
        tradePeer = null; tradeOffer = [];
      }
    };
  }

  function paintPick() {
    const raceNames = {humano:t("human"), elfo:t("elf"), orc:"Orc", anao:t("dwarf")};
    const sexName = chosenSex === "f" ? t("woman") : t("man");
    const el = document.getElementById("pick-now");
    if (el) el.textContent = t("chosen") + ": " + chosenVoc + " · " + (raceNames[chosenRace] || chosenRace) + " · " + sexName;
    const pv = document.getElementById("char-preview-canvas");
    if (pv && typeof makeCharSheet === "function") {
      const pc = pv.getContext("2d"); pc.clearRect(0,0,pv.width,pv.height); pc.imageSmoothingEnabled=false;
      const sheet = makeCharSheet(chosenVoc, chosenRace, chosenSex);
      pc.drawImage(sheet, 0, 0, pv.width, pv.height);
    }
    const pn=document.getElementById("char-preview-name");
    if(pn) pn.textContent = chosenRace==="orc" ? ("Orc · "+sexName) : ((raceNames[chosenRace]||chosenRace)+" · "+sexName);
  }
  function bindPick(sel, fn) {
    document.querySelectorAll(sel).forEach((b) => {
      const go = (e) => { e.preventDefault(); e.stopPropagation(); fn(b); paintPick(); };
      b.addEventListener("pointerdown", go);
      b.addEventListener("click", go);
    });
  }
  bindPick("#vocs .voc", (b) => {
    chosenVoc = b.dataset.voc;
    document.querySelectorAll("#vocs .voc").forEach((x) => x.classList.toggle("on", x === b));
  });
  bindPick("#races .voc", (b) => {
    chosenRace = b.dataset.race;
    document.querySelectorAll("#races .voc").forEach((x) => x.classList.toggle("on", x === b));
  });
  bindPick("#sexes .voc", (b) => {
    chosenSex = b.dataset.sex;
    document.querySelectorAll("#sexes .voc").forEach((x) => x.classList.toggle("on", x === b));
  });
  paintPick();
  function renderQuests() {
    if (!hero) return;
    const q = hero.quest || {};
    const list = document.getElementById("quest-list");
    const row = (ok, txt) => "<p>" + (ok ? "✔ " : "○ ") + txt + "</p>";
    list.innerHTML =
      row(q.done, "1) Mate 5 monstros  (" + Math.min(q.kills || 0, 5) + "/5)") +
      row(q.q2, "2) Mate 15 monstros  (" + Math.min(q.kills || 0, 15) + "/15)") +
      row(q.q3, "3) Fundir 3 joias  (" + (q.fuse || 0) + ")") +
      row(q.q4 || (hero.level >= 5), "4) Chegar no level 5  (lv " + hero.level + ")");
  }
  function doFuse() {
    if (!hero || !hero.inventory) return;
    const gems = hero.inventory.filter((i) => i.id === "gem" || i.id === "jewel");
    let n = gems.reduce((s, i) => s + (i.qty || 1), 0);
    if (n < 3) { chatLine("Precisa de 3 joias/gemas.", "sys"); return; }
    let left = 3;
    gems.forEach((i) => {
      if (left <= 0) return;
      const take = Math.min(i.qty || 1, left);
      i.qty -= take; left -= take;
    });
    hero.inventory = hero.inventory.filter((i) => !i.qty || i.qty > 0);
    hero.inventory.push({ id: "bless", icon: "✨", name: "Joia fundida", qty: 1, use: "gold" });
    hero.gold += 80;
    localGainXp(150);
    hero.quest = hero.quest || {};
    hero.quest.fuse = (hero.quest.fuse || 0) + 1;
    if (!hero.quest.q3) { hero.quest.q3 = true; hero.gold += 150; chatLine("Missao fusao completa.", "loot"); }
    chatLine("Fusao ok: joia brilhante +80 gp.", "loot");
    applyHero(hero); persistLocal(); renderQuests();
  }
  const qBtn = document.getElementById("btn-quest");
  if (qBtn) qBtn.onclick = () => {
    const box = document.getElementById("quest-box");
    renderQuests();
    box.style.display = box.style.display === "block" ? "none" : "block";
  };
  document.getElementById("quest-x").onclick = () => { document.getElementById("quest-box").style.display = "none"; };
  document.getElementById("btn-fuse").onclick = doFuse;
  document.getElementById("btn-map").onclick = () => {
    const box = document.getElementById("map-box");
    const opts = document.getElementById("map-opts");
    opts.innerHTML = "";
    LOCAL_WORLDS.forEach((w) => {
      const b = document.createElement("button");
      b.type = "button";
      const lock = hero && hero.level < w.min && w.min > 1;
      b.textContent = w.name + (lock ? "  (lv " + w.min + ")" : "  — aberto");
      b.onclick = () => {
        if (lock) { chatLine("Level " + w.min + " pra esse mapa.", "sys"); return; }
        box.style.display = "none";
        goToMap(w.id, 16, 16);
      };
      opts.appendChild(b);
    });
    box.style.display = "block";
    const currentBtn = Array.from(opts.children).find((b) => {
      const w = LOCAL_WORLDS.find((world) => (b.textContent || "").startsWith(world.name));
      return w && w.id === currentMap;
    });
    if (currentBtn) currentBtn.scrollIntoView({ block: "center", behavior: "instant" });
  };
  document.getElementById("map-x").onclick = () => { document.getElementById("map-box").style.display = "none"; };
  const flyBtn = document.getElementById("btn-fly");
  if (flyBtn) flyBtn.onclick = () => {
    flying = !flying;
    flyBtn.classList.toggle("on", flying);
    chatLine(flying ? t("wingsOn") : t("wingsOff"), "sys");
  };
  document.getElementById("btn-register").onclick = () => { ensureAudio(); connect("register"); };
  document.getElementById("btn-start").onclick = () => { ensureAudio(); connect("login"); };
  const muteBtn = document.getElementById("btn-mute");
  if (muteBtn) muteBtn.onclick = () => {
    musicOn = !musicOn;
    muteBtn.textContent = musicOn ? "som" : "mudo";
    if (!musicOn) stopMusic();
    else playMapMusic(currentTheme || "grass");
  };
  const setBox = document.getElementById("set-box");
  document.getElementById("btn-set").onclick = () => {
    const opening = setBox.style.display !== "block";
    setBox.style.display = opening ? "block" : "none";
    setChatModalHidden(opening);
    applyLang();
    document.getElementById("set-sfx").checked = musicOn;
    document.getElementById("set-names").checked = showNames;
    document.getElementById("set-pvp").checked = pvpOn;
  };
  document.getElementById("set-x").onclick = () => { setBox.style.display = "none"; setChatModalHidden(false); };
  document.querySelectorAll("#set-langs .lang").forEach((b) => {
    b.onclick = () => { lang = b.dataset.lang; applyLang(); };
  });
  document.getElementById("set-sfx").onchange = (e) => {
    musicOn = e.target.checked;
    if (!musicOn) stopMusic();
    else { ensureAudio(); playMapMusic(currentTheme || "title"); }
  };
  document.getElementById("set-names").onchange = (e) => { showNames = e.target.checked; };
  document.getElementById("set-pvp").onchange = (e) => { pvpOn = e.target.checked; };
  const notifyBtn = document.getElementById("set-notify");
  if (notifyBtn) notifyBtn.onclick = enableNotifications;
  const splashNotify = document.getElementById("btn-notify-splash");
  if (splashNotify) splashNotify.onclick = enableNotifications;
  armReminderSystem();

  /* ---- input ---- */
  const joyEl = document.getElementById("joystick");
  const stickEl = document.getElementById("stick");
  function joyFrom(e, rect) {
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const x = e.clientX - cx, y = e.clientY - cy;
    const max = rect.width * 0.32, len = Math.hypot(x, y) || 1, cl = Math.min(len, max);
    stickEl.style.left = 29 + (x / len) * cl + "px";
    stickEl.style.top = 29 + (y / len) * cl + "px";
    joy.dx = ((x / len) * cl) / max;
    joy.dy = ((y / len) * cl) / max;
  }
  joyEl.addEventListener("pointerdown", (e) => {
    joy.on = true; joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId);
    joyFrom(e, joyEl.getBoundingClientRect());
  });
  joyEl.addEventListener("pointermove", (e) => {
    if (joy.on && e.pointerId === joy.id) joyFrom(e, joyEl.getBoundingClientRect());
  });
  function endJoy() { joy.on = false; joy.dx = joy.dy = 0; stickEl.style.left = "29px"; stickEl.style.top = "29px"; }
  joyEl.addEventListener("pointerup", endJoy);
  joyEl.addEventListener("pointercancel", endJoy);

  // Camera: drag to pan, wheel/pinch to zoom, and a soft follow lead from movement.
  canvas.style.pointerEvents = "auto";
  function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }
  function pinchDistance(){ const a=[...camPointers.values()]; if(a.length<2) return 0; return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y); }
  canvas.addEventListener("pointerdown", (e)=>{
    camPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(camPointers.size===1){ camDrag={id:e.pointerId,x:e.clientX,y:e.clientY,sx:camUserX,sy:camUserY}; canvas.setPointerCapture(e.pointerId); }
    if(camPointers.size===2){ camPinchStart=pinchDistance(); camPinchZoom=camZoom; camDrag=null; }
  });
  canvas.addEventListener("pointermove", (e)=>{
    if(!camPointers.has(e.pointerId)) return;
    camPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(camPointers.size>=2){ const d=pinchDistance(); if(camPinchStart>0) camZoom=clamp(camPinchZoom*(d/camPinchStart),0.82,1.28); return; }
    if(camDrag && camDrag.id===e.pointerId){ camUserX=camDrag.sx-(e.clientX-camDrag.x)/camZoom; camUserY=camDrag.sy-(e.clientY-camDrag.y)/camZoom; }
  });
  function endCam(e){ camPointers.delete(e.pointerId); if(camDrag&&camDrag.id===e.pointerId) camDrag=null; if(camPointers.size<2) camPinchStart=0; }
  canvas.addEventListener("pointerup",endCam); canvas.addEventListener("pointercancel",endCam);
  canvas.addEventListener("wheel",(e)=>{ e.preventDefault(); camZoom=clamp(camZoom*(e.deltaY>0?.92:1.087),.82,1.28); },{passive:false});

  addEventListener("keydown", (e) => {
    keys[e.code] = true;
    if (e.code === "Space") { e.preventDefault(); doAtk(); }
    if (e.code === "KeyI") toggle("#inventory");
    if (e.code === "Digit1") send({ type: "spell", name: "exura" });
    if (e.code === "Digit2") send({ type: "spell", name: "exori" });
    if (e.code === "Digit3") send({ type: "spell", name: "exori vis" });
    if (e.code === "Digit4") send({ type: "spell", name: "exura gran" });
  });
  addEventListener("keyup", (e) => { keys[e.code] = false; });

  document.getElementById("btn-atk").onclick = doAtk;
  document.getElementById("btn-auto-atk").onclick = (e) => {
    e.preventDefault();
    setAutoAttack(!autoAttackEnabled);
  };
  document.getElementById("btn-inv").onclick = () => toggle("#inventory");
  document.getElementById("inv-close").onclick = () => document.getElementById("inventory").style.display = "none";

  // Character shop: free starter gear by vocation + gold purchases with class restrictions.
  // Large catalog: 1,200+ items generated from class, equipment type, material and rarity.
  const SHOP_RARITIES = [
    {key:"common", label:"Comum", min:80, max:900, mult:1},
    {key:"uncommon", label:"Incomum", min:1200, max:6000, mult:3},
    {key:"rare", label:"Raro", min:10000, max:45000, mult:8},
    {key:"super", label:"Super Raro", min:80000, max:350000, mult:18},
    {key:"legendary", label:"Lendário", min:1000000, max:5000000, mult:45}
  ];
  const SHOP_CLASSES = ["knight","paladin","sorcerer","druid"];
  const SHOP_ICONS = ["⚔️","🛡️","🗡️","🏹","🔮","🪄","🧥","🥋","⛑️","🪽","💍","📿","💎","🔥","❄️","⚡","🌪️","🌿","👑","✨"];
  const SHOP_TYPES = ["Espada","Escudo","Armadura","Elmo","Arco","Cajado","Manto","Anel","Amuleto","Asa","Lança","Machado","Botas","Luvas","Capa","Colar"];
  const SHOP_MATS = ["de Ferro","de Aço","de Prata","de Ouro","Obsidiano","Celestial","Dracônico","Arcano","Sombrio","Solar","Lunar","Élfico","Ancestral","Eterno","do Abismo"];
  const SHOP_NAMES = ["Guardião","Tempestade","Dragão","Fênix","Titã","Sombra","Aurora","Inferno","Gelo","Trovão","Floresta","Lua","Sol","Caos","Eclipse","Valente","Místico","Imperial","Real","Espectral"];
  const SHOP_RARE_THRESHOLD = {common:0, uncommon:1, rare:2, super:3, legendary:4};

  const SHOP_ITEMS = [
    {id:"starter-sword", icon:"🗡️", name:"Espada do Iniciante", price:0, voc:["knight"], rarity:"common", desc:"Grátis · exclusiva do Knight"},
    {id:"starter-staff", icon:"🪄", name:"Cajado do Iniciante", price:0, voc:["sorcerer"], rarity:"common", desc:"Grátis · exclusivo do Sorcerer"},
    {id:"starter-bow", icon:"🏹", name:"Arco do Iniciante", price:0, voc:["paladin"], rarity:"common", desc:"Grátis · exclusivo do Paladin"},
    {id:"starter-nature", icon:"🌿", name:"Cajado da Natureza", price:0, voc:["druid"], rarity:"common", desc:"Grátis · exclusivo do Druid"}
  ];

  // Build 1,200 purchasable entries. Every class gets hundreds of unique items,
  // plus universal accessories. Higher rarities require dramatically more gold.
  (function buildHugeShop(){
    let n=0;
    SHOP_RARE_THRESHOLD.common=0;
    for(let r=0;r<SHOP_RARITIES.length;r++){
      const rarity=SHOP_RARITIES[r];
      for(let c=0;c<SHOP_CLASSES.length;c++){
        const voc=SHOP_CLASSES[c];
        for(let i=0;i<60;i++){
          const type=SHOP_TYPES[(i+c*3+r)%SHOP_TYPES.length];
          const mat=SHOP_MATS[(i*2+c+r)%SHOP_MATS.length];
          const name=SHOP_NAMES[(i+c*5+r*2)%SHOP_NAMES.length];
          const icon=SHOP_ICONS[(i+c+r)%SHOP_ICONS.length];
          const price=rarity.min + ((i*7919+c*313+r*1777)%Math.max(1,rarity.max-rarity.min+1));
          n++;
          SHOP_ITEMS.push({
            id:"shop-"+r+"-"+c+"-"+i,
            icon,name: type+" "+name+" "+mat,
            price,
            voc:[voc],
            rarity:rarity.key,
            desc:voc.toUpperCase()+" · "+rarity.label+" · bônus de "+(4+r*9)+" "+(type==="Anel"||type==="Amuleto"?"MAG":"ATK/DEF")
          });
        }
      }
    }
    // 240 universal items.
    for(let i=0;i<240;i++){
      const r=i%5, rarity=SHOP_RARITIES[r];
      const price=rarity.min + ((i*9173+r*1231)%Math.max(1,rarity.max-rarity.min+1));
      SHOP_ITEMS.push({
        id:"shop-universal-"+i,
        icon:SHOP_ICONS[(i+7)%SHOP_ICONS.length],
        name:SHOP_TYPES[(i+4)%SHOP_TYPES.length]+" Universal "+SHOP_NAMES[(i*3)%SHOP_NAMES.length]+" "+SHOP_MATS[(i+r)%SHOP_MATS.length],
        price,voc:SHOP_CLASSES.slice(),rarity:rarity.key,
        desc:"TODAS AS CLASSES · "+rarity.label+" · item universal"
      });
    }
  })();

  let shopFilter="mine";
  function shopHas(id){ return !!(hero && hero.inventory && hero.inventory.find(i=>i.id===id)); }
  function addShopItem(item){
    if(!hero) return;
    if(!hero.inventory) hero.inventory=[];
    const have=hero.inventory.find(i=>i.id===item.id);
    if(have){ have.qty=(have.qty||1)+1; }
    else hero.inventory.push({id:item.id,icon:item.icon,name:item.name,qty:1,shop:true,voc:item.voc});
    if(item.id==="knight-blade"||item.id==="starter-sword") hero.eq=hero.eq||{};
    applyHero(hero); persistLocal();
  }
  function openShop(){
    const box=document.getElementById("shop-box"), list=document.getElementById("shop-items");
    if(!box||!list) return;
    box.style.display="block";
    const voc=hero?.voc||"knight";
    const vocName={knight:"Knight",paladin:"Paladin",sorcerer:"Sorcerer",druid:"Druid"}[voc]||voc;
    const gold=document.getElementById("shop-gold");
    if(gold) gold.textContent="💰 Ouro: "+(hero?.gold||0)+" · Classe: "+vocName+" · "+SHOP_ITEMS.length+" itens";
    document.querySelectorAll(".shop-filter").forEach(b=>b.classList.toggle("on",b.dataset.filter===shopFilter));

    let items=SHOP_ITEMS.filter(item=>{
      if(shopFilter==="mine") return item.voc.includes(voc);
      if(shopFilter==="all") return true;
      if(shopFilter==="rare") return SHOP_RARE_THRESHOLD[item.rarity]>=2;
      return item.voc.includes(shopFilter);
    });
    items.sort((a,b)=>SHOP_RARE_THRESHOLD[b.rarity]-SHOP_RARE_THRESHOLD[a.rarity] || a.price-b.price);
    const count=document.getElementById("shop-count");
    if(count) count.textContent="Mostrando "+items.length+" itens · role para baixo para ver mais";
    list.innerHTML="";
    const frag=document.createDocumentFragment();
    items.forEach(item=>{
      const allowed=item.voc.includes(voc), owned=shopHas(item.id), free=item.price===0;
      const row=document.createElement("div"); row.className="shop-item rarity-"+item.rarity;
      const rarityClass="r-"+item.rarity;
      row.innerHTML='<div class="shop-icon">'+item.icon+'</div><div><b>'+item.name+'</b><small><span class="shop-rarity '+rarityClass+'">'+item.rarity.toUpperCase()+'</span> '+item.desc+'</small></div>';
      const b=document.createElement("button");
      b.className=free?"free":"";
      b.disabled=!allowed || owned || (!free && (hero?.gold||0)<item.price);
      b.textContent=!allowed?"Outra classe":owned?"Já possui":free?"GRÁTIS":"💰 "+item.price.toLocaleString("pt-BR");
      b.onclick=()=>{
        if(!allowed||owned)return;
        if(!free){
          if((hero.gold||0)<item.price){chatLine("Ouro insuficiente.","sys");return;}
          hero.gold-=item.price;
        }
        addShopItem(item);
        chatLine((free?"Item grátis: ":"Comprado: ")+item.name,"loot");
        openShop();
      };
      row.appendChild(b); frag.appendChild(row);
    });
    list.appendChild(frag);
  }
  document.querySelectorAll(".shop-filter").forEach(b=>{
    b.addEventListener("click",()=>{shopFilter=b.dataset.filter||"mine";openShop();});
  });
  document.getElementById("btn-shop-settings")?.addEventListener("click",openShop);
  document.getElementById("shop-x")?.addEventListener("click",()=>{document.getElementById("shop-box").style.display="none";});

  document.querySelectorAll(".hk").forEach((b) => {
    b.onclick = () => {
      if (b.dataset.spell === "food") {
        const food = hero && hero.inventory.find((i) => i.use === "food");
        if (food) send({ type: "use", id: food.id });
      } else send({ type: "spell", name: b.dataset.spell });
    };
  });
  document.getElementById("chat-form").onsubmit = (e) => {
    e.preventDefault();
    const inp = document.getElementById("chat-in");
    if (inp.value.trim()) send({ type: "chat", text: inp.value.trim() });
    inp.value = "";
  };
  const npcBtn = document.getElementById("btn-npc");
  if (npcBtn) npcBtn.onclick = () => {};
  function closeNpc() { document.getElementById("npc-box").style.display = "none"; }
  document.getElementById("npc-x").onclick = closeNpc;
  document.getElementById("btn-trade").onclick = () => {
    const near = others.find((p) => hero && p.name !== hero.name && (!p.map || p.map===currentMap) && Math.abs(p.x - hero.x) + Math.abs(p.y - hero.y) <= 2);
    if (!near) return chatLine("Chegue perto de outro jogador para negociar.", "sys");
    send({ type: "tradeAsk", to: near.name });
  };
  const tradeNearBtn=document.getElementById("trade-near");
  let tradeTarget=null;
  function updateTradeNear(){
    if(!tradeNearBtn||!hero){if(tradeNearBtn)tradeNearBtn.hidden=true;return;}
    const p=(others||[]).filter(x=>x&&x.name&&x.name!==hero.name&&(!x.map||x.map===currentMap))
      .map(x=>({p:x,d:Math.hypot((x.x||0)-(hero.x||0),(x.y||0)-(hero.y||0))}))
      .sort((a,b)=>a.d-b.d)[0];
    tradeTarget=p&&p.d<=2.8?p.p:null;
    tradeNearBtn.hidden=!tradeTarget;
    if(tradeTarget) tradeNearBtn.textContent="🤝 TRADE · "+tradeTarget.name;
  }
  tradeNearBtn?.addEventListener("click",()=>{if(tradeTarget)send({type:"tradeAsk",to:tradeTarget.name});});
  setInterval(updateTradeNear,500);

  document.getElementById("trade-yes").onclick = () => {
    send({ type: "tradeOffer", gold: Number(document.getElementById("trade-gold").value) || 0, items: tradeOffer });
    send({ type: "tradeYes" });
  };
  document.getElementById("trade-x").onclick = () => send({ type: "tradeNo" });
  document.getElementById("trade-gold").onchange = () => {
    send({ type: "tradeOffer", gold: Number(document.getElementById("trade-gold").value) || 0, items: tradeOffer });
  };

  function toggle(sel) {
    const el = document.querySelector(sel);
    el.style.display = el.style.display === "block" ? "none" : "block";
    if (sel === "#inventory") renderInv();
  }
  let autoAttackEnabled = false;
  let autoAttackNext = 0;
  function nearestAutoMob() {
    if (!hero || inSafeZone()) return null;
    const candidates = creatures.filter(c =>
      c && c.alive &&
      Number.isFinite(c.x) && Number.isFinite(c.y) &&
      Math.abs(c.x - hero.x) + Math.abs(c.y - hero.y) <= 8
    );
    candidates.sort((a,b) => {
      const da = Math.hypot(a.x - hero.x, a.y - hero.y);
      const db = Math.hypot(b.x - hero.x, b.y - hero.y);
      return da - db;
    });
    return candidates[0] || null;
  }
  function setAutoAttack(enabled) {
    const requested = !!enabled;
    autoAttackEnabled = requested && !!hero && !inSafeZone();
    const b = document.getElementById("btn-auto-atk");
    if (b) {
      b.classList.toggle("on", autoAttackEnabled);
      b.classList.toggle("off", !autoAttackEnabled);
      b.textContent = autoAttackEnabled ? "⚔" : "A";
      b.title = autoAttackEnabled ? "Auto-ataque LIGADO — toque para desligar" : "Auto-ataque DESLIGADO — toque para ligar";
      b.setAttribute("aria-label", b.title);
      b.dataset.active = autoAttackEnabled ? "1" : "0";
    }
    if (requested !== autoAttackEnabled) {
      if (hero && inSafeZone()) chatLine("Auto-ataque desativado nesta área.", "sys");
      return;
    }
    if (autoAttackEnabled) {
      autoAttackNext = 0;
      chatLine("⚔ Auto-ataque LIGADO.", "sys");
    } else {
      chatLine("⏹ Auto-ataque DESLIGADO.", "sys");
    }
  }
  function autoAttackTick(now) {
    if (!autoAttackEnabled || !hero || inSafeZone()) return;
    if (now < autoAttackNext) return;
    const target = nearestAutoMob();
    if (!target) return;
    autoAttackNext = now + 420;
    atkUntil = performance.now() + 280;
    camShake = Math.min(2.5, camShake + 0.35);
    sfx(420, 0.05);
    send({ type: "atk", target: target.id });
  }

  function doAtk() {
    if (!hero) return;
    atkUntil = performance.now() + 280;
    camShake = Math.min(2.5, camShake + 0.8);
    sfx(420, 0.07);
    if (!canPvpHere()) {
      if (currentMap === "porto") chatLine("PvP desativado na cidade. Entre na ⚔ ARENA PVP ⚔.", "sys");
      return;
    }
    if (pvpOn) {
      const foe = others.filter((p) => p.name !== hero.name && Math.abs(p.x - hero.x) + Math.abs(p.y - hero.y) <= 1.8)
        .sort((a, b) => (Math.abs(a.x - hero.x) + Math.abs(a.y - hero.y)) - (Math.abs(b.x - hero.x) + Math.abs(b.y - hero.y)))[0];
      if (foe) {
        send({ type: "pvp", to: foe.name });
        worldFloat(foe.x, foe.y, "PvP", "#ff66ee");
        chatLine("PvP: " + foe.name, "dmg");
        return;
      }
    }
    const t = creatures.filter((c) => c.alive && Math.abs(c.x - hero.x) + Math.abs(c.y - hero.y) <= 1.6)
      .sort((a, b) => (Math.abs(a.x - hero.x) + Math.abs(a.y - hero.y)) - (Math.abs(b.x - hero.x) + Math.abs(b.y - hero.y)))[0];
    if (t) send({ type: "atk", target: t.id });
  }

  /* ---- loop ---- */
  const mini = document.getElementById("minimap");
  const mctx = mini.getContext("2d");
  mini.width = 110; mini.height = 110;

  function drawMini() {
    const s = 110 / MAP;
    for (let y = 0; y < MAP; y++) for (let x = 0; x < MAP; x++) {
      const t = map[y][x];
      mctx.fillStyle = t === 3 ? "#1a4a78" : t === 2 ? "#c2a86a" : t === 4 ? "#888" : t === 5 ? "#7a4a22" : t === 6 ? "#d2c08a" : "#2f6a28";
      mctx.fillRect(x * s, y * s, s + 0.4, s + 0.4);
    }
    if (hero) { mctx.fillStyle = "#ffee55"; mctx.fillRect(hero.x * s - 1, hero.y * s - 1, 4, 4); }
    mctx.fillStyle = "#e74c3c";
    creatures.forEach((c) => { if (c.alive) mctx.fillRect(c.x * s, c.y * s, 3, 3); });
    mctx.fillStyle = "#5dade2";
    others.forEach((p) => {
      if ((!hero || p.name !== hero.name) && (!p.map || p.map === currentMap))
        mctx.fillRect(p.x * s, p.y * s, 3, 3);
    });
  }

  function cellBlocked(x, y) {
    const gx = Math.round(x), gy = Math.round(y);
    if (gx < 2 || gy < 2 || gx >= MAP - 2 || gy >= MAP - 2) return true;
    if (!map[gy]) return true;
    if (!flying && map[gy][gx] === TILE.WATER) return true;
    if (solids.has(gx + "," + gy)) return true;
    return false;
  }
  let lastSentTile = "";
  function unstickFromMobs() {
    if (!hero || !creatures.length) return;
    creatures.forEach((c) => {
      if (!c.alive) return;
      const d = Math.hypot(c.x - hero.x, c.y - hero.y);
      if (d < 0.95) {
        const ang = Math.atan2(c.y - hero.y, c.x - hero.x) || 0.7;
        const tx = hero.x + Math.cos(ang) * 0.95;
        const ty = hero.y + Math.sin(ang) * 0.95;
        if (!cellBlocked(tx, c.y)) c.x = tx;
        if (!cellBlocked(c.x, ty)) c.y = ty;
        if (Math.hypot(c.x-hero.x,c.y-hero.y) < 0.7) {
          const sx = hero.x - Math.cos(ang) * 0.9, sy = hero.y - Math.sin(ang) * 0.9;
          if (!cellBlocked(sx, hero.y)) hero.x = sx;
          else if (!cellBlocked(hero.x, sy)) hero.y = sy;
        }
      }
    });
  }
  function tryStep(dx, dy) {
    if (!hero) return;
    unstickFromMobs();
    if (cellBlocked(hero.x, hero.y)) {
      for (const p of [[1,0],[-1,0],[0,1],[0,-1],[2,0],[-2,0],[0,2],[0,-2],[18,21]]) {
        if (!cellBlocked(hero.x + (p[0] < 5 ? p[0] : 0), hero.y + (p[1] < 5 ? p[1] : 0)) && p[0] < 5) {
          hero.x += p[0]; hero.y += p[1]; visX = hero.x; visY = hero.y; break;
        }
      }
    }
    const nx = hero.x + dx, ny = hero.y + dy;
    if (cellBlocked(nx, ny)) {
      if (!cellBlocked(nx, hero.y)) { hero.x = nx; }
      else if (!cellBlocked(hero.x, ny)) { hero.y = ny; }
      else return;
    } else {
      hero.x = nx;
      hero.y = ny;
    }
    const key = Math.round(hero.x) + "," + Math.round(hero.y);
    if (key !== lastSentTile) {
      lastSentTile = key;
      send({ type: "move", x: Math.round(hero.x), y: Math.round(hero.y), map: currentMap || hero.map || "porto" });
    }
  }

  let last = performance.now();
  function gameFrame(now) {
    window.__flTheme = currentTheme;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    frame++;
    if (hero) {
      autoAttackTick(now);
      moveAcc += dt;
      let ix = joy.dx, iy = joy.dy;
      if (keys.KeyA || keys.ArrowLeft) ix -= 1;
      if (keys.KeyD || keys.ArrowRight) ix += 1;
      if (keys.KeyW || keys.ArrowUp) iy -= 1;
      if (keys.KeyS || keys.ArrowDown) iy += 1;
      if (Math.abs(ix) > 0.12 || Math.abs(iy) > 0.12) {
        const spd = 2.8 * dt;
        const wx = (ix + iy) * spd;
        const wz = (iy - ix) * spd;
        tryStep(wx, wz);
        if (autoAttackEnabled) {
          autoAttackTick(now);
        }
      }
      visX = hero.x;
      visY = hero.y;
      unstickFromMobs();
      pickupDrops();
      if (inSafeZone()) {
        if (autoAttackEnabled) setAutoAttack(false);
        creatures = [];
        hero.hp = hero.hpMax;
        hero._lockHp = hero.hpMax;
        const layer = document.getElementById("dmg-layer");
        if (layer) layer.innerHTML = "";
      } else {
        hero._lockHp = hero.hp;
      }
      const onEl = document.getElementById("online");
      if (onEl) {
        onEl.textContent = inSafeZone()
          ? (mapName || "Porto Inicial") + " · " + t("city")
          : (mapName || "") + " · " + t("hunt");
      }
      if (inSafeZone()) {
        /* cidade principal: zero combate */
      } else if (hero.hp > 0) {
        creatures.forEach((c) => {
          if (!c.alive) return;
          const dx = hero.x - c.x, dy = hero.y - c.y;
          const dist = Math.abs(dx) + Math.abs(dy);
          const pos = iso(c.x, c.y);
          const sx = canvas.width / 2 - camX + pos.x;
          const sy = canvas.height / 2 - camY + pos.y;
          const onScreen = sx > 20 && sy > 40 && sx < canvas.width - 20 && sy < canvas.height - 70;
          if (dist > 7) { c.aggro = 0; return; }
          c.aggro = 1;
          if (dist > 1.35) {
            const step = 1.5 * dt;
            const nx = c.x + Math.sign(dx) * step;
            const ny = c.y + Math.sign(dy) * step;
            if (!cellBlocked(nx, c.y)) c.x = nx;
            if (!cellBlocked(c.x, ny)) c.y = ny;
          } else if (now - (c.lastHit || 0) > 1100) {
            c.lastHit = now;
            if (!onScreen || inSafeZone()) return;
            const defB = (hero.eq && hero.eq.armor ? 3 : 0) + (hero.eq && hero.eq.shield ? 2 : 0);
            const hit = Math.max(2, c.atk + ((Math.random() * 5) | 0) - Math.floor(hero.def / 8) - defB);
            hero.hp = Math.max(0, hero.hp - hit);
            applyHero(hero);
            chatLine(c.name + t("hit") + hit + ").", "dmg");
            worldFloat(hero.x, hero.y, "-" + hit, "#ff6b5a");
            sfx(180, 0.08);
            if (hero.hp <= 0) {
              hero.hp = hero.hpMax;
              goToMap("porto", 18, 21);
              chatLine(t("dead"), "sys");
            }
          }
        });
      }
    }

    const g = ctx.createLinearGradient(0, 0, 0, canvas.height);
    if (currentTheme === "grass" || currentTheme === "city") {
      g.addColorStop(0, "#6ad0ff");
      g.addColorStop(0.42, "#c8f06a");
      g.addColorStop(1, "#3a9a38");
    } else {
      g.addColorStop(0, "#1a2240");
      g.addColorStop(0.4, "#3a4a68");
      g.addColorStop(1, "#1a2818");
    }
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const leadWX = hero ? ((joy.dx + (keys.KeyD?1:0) - (keys.KeyA?1:0)) * 18) : 0;
    const leadWY = hero ? ((joy.dy + (keys.KeyS?1:0) - (keys.KeyW?1:0)) * 12) : 0;
    const targetCam = hero ? iso(visX, visY) : iso(18, 21);
    const desiredX = targetCam.x + camUserX + leadWX;
    const desiredY = targetCam.y + camUserY + leadWY;
    const spring = 1 - Math.exp(-dt * 7.5);
    camX += (desiredX - camX) * spring;
    camY += (desiredY - camY) * spring;
    camUserX *= Math.exp(-dt * 0.18);
    camUserY *= Math.exp(-dt * 0.18);
    camShake *= Math.exp(-dt * 9);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(camZoom, camZoom);
    ctx.translate(-camX + Math.sin(frame*1.7)*camShake, -camY + 20/camZoom + Math.cos(frame*1.3)*camShake);

    for (let y = 0; y < MAP; y++) {
      for (let x = 0; x < MAP; x++) drawTile(x, y, map[y][x]);
    }
    if (currentMap === "porto") {
      drawCityPvpArena();
    }
    const drawables = [];
    if (currentMap === "porto" && inCityPvpArena() && frame % 180 === 1) {
      chatLine("⚔ Você entrou na Arena PvP da cidade. Aqui o PvP é permitido!", "sys");
    }
    for (let y = 2; y < MAP - 2; y++) for (let x = 2; x < MAP - 2; x++) {
      if (map[y][x] !== TILE.GRASS) continue;
      const r = seeded(x * 2, y * 5);
      if (r > 0.965) drawables.push({ x, y, z: x + y, draw: () => drawTree(x, y) });
    }
    if (currentTheme === "city" || currentTheme === "grass") {
      drawables.push({ x: 11, y: 12, z: 24, draw: () => drawHouse(11, 12) });
      drawables.push({ x: 21, y: 11, z: 32, draw: () => drawHouse(21, 11) });
      if (currentTheme === "city") {
        drawables.push({ x: 8, y: 14, z: 22, draw: () => drawHouse(8, 14) });
        drawables.push({ x: 24, y: 13, z: 38, draw: () => drawHouse(24, 13) });
        drawables.push({ x: 17, y: 17, z: 34, draw: () => drawTemple(17, 17) });
        drawables.push({ x: 6, y: 10, z: 16, draw: () => drawHouse(6, 10) });
        drawables.push({ x: 28, y: 10, z: 38, draw: () => drawHouse(28, 10) });
        drawables.push({ x: 6, y: 22, z: 28, draw: () => drawHouse(6, 22) });
        drawables.push({ x: 28, y: 22, z: 50, draw: () => drawHouse(28, 22) });
      }
    }
    if (currentTheme === "forest") {
      for (let i = 0; i < 18; i++) {
        const tx = 6 + ((i * 5) % 22), ty = 6 + ((i * 7) % 20);
        drawables.push({ x: tx, y: ty, z: tx + ty, draw: () => drawTree(tx, ty) });
      }
    }
    if (currentTheme === "halloween") {
      // Full starter village Halloween treatment.
      [[6,8],[14,7],[25,8],[29,15],[5,22],[27,25],[10,27]].forEach((q,i)=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1],draw:()=>drawHauntedTree(q[0],q[1],.95+(i%3)*.08)}));
      [[9,12],[20,11],[27,20],[7,20],[23,27]].forEach((q,i)=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.2,draw:()=>drawHauntedHouse(q[0],q[1],i)}));
      [[7,10],[12,13],[25,10],[28,17],[9,25],[24,25],[17,9],[20,27],[15,22],[26,13]].forEach((q,i)=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.08,draw:()=>drawPumpkin(q[0],q[1],1+(i%3)*.14)}));
      [[10,18],[14,18],[22,18],[26,18],[18,13],[18,25],[8,15],[28,23]].forEach(q=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.1,draw:()=>drawHalloweenLantern(q[0],q[1])}));
      [[6,7],[15,6],[26,7],[30,14],[5,19],[28,27],[19,7],[11,24]].forEach(q=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.3,draw:()=>drawBat(q[0],q[1])}));
      [[13,20],[18,21],[25,23],[9,23],[21,15]].forEach(q=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.4,draw:()=>drawGravestone(q[0],q[1])}));
      [[6,12],[29,12],[8,26],[26,26]].forEach(q=>
        drawables.push({x:q[0],y:q[1],z:q[0]+q[1]+.5,draw:()=>drawSpiderWeb(q[0],q[1])}));
      drawables.push({x:18,y:11,z:29,draw:()=>drawHalloweenArch(18,11)});
    }

    if (currentMap === "porto") {
      drawables.push({
        x: 22, y: 12, z: 34,
        draw() {
          const p = iso(22,12);
          const glow = 0.55 + Math.sin(frame/12)*0.12;
          ctx.save();
          ctx.fillStyle = "rgba(255,194,45," + glow*0.18 + ")";
          ctx.beginPath(); ctx.arc(p.x,p.y-8,25,0,Math.PI*2); ctx.fill();
          ctx.fillStyle = "#5b3517"; ctx.fillRect(p.x-15,p.y-5,30,15);
          ctx.fillStyle = "#9b5b20"; ctx.fillRect(p.x-15,p.y-10,30,9);
          ctx.fillStyle = "#e0a83b"; ctx.fillRect(p.x-3,p.y-1,6,7);
          ctx.fillStyle = "#ffd95c"; ctx.fillRect(p.x-13,p.y-12,26,3);
          ctx.fillStyle = "#fff0a0"; ctx.font = "bold 10px sans-serif"; ctx.textAlign="center";
          ctx.fillText("BAÚ",p.x,p.y-20);
          ctx.restore();
        }
      });
    }

    portals.forEach((p) => {
      drawables.push({
        x: p.x, y: p.y, z: p.x + p.y + 0.05,
        draw() {
          const pos = iso(p.x, p.y);
          ctx.fillStyle = "#7d5cff";
          ctx.fillRect(pos.x - 8, pos.y - 4, 16, 10);
          ctx.fillStyle = "#e8deff";
          ctx.fillRect(pos.x - 4, pos.y - 18, 8, 16);
          ctx.fillStyle = "#fff";
          ctx.font = "9px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("Lv" + p.need, pos.x, pos.y - 22);
        },
      });
    });
    drops.forEach((d) => {
      drawables.push({ x: d.x, y: d.y, z: d.x + d.y + 0.15, draw: () => drawDrop(d) });
    });
    creatures.forEach((c) => {
      if (!c.alive) return;
      drawables.push({
        x: c.x, y: c.y, z: c.x + c.y + 0.2,
        draw() {
          const p = iso(c.x, c.y);
          const bob = Math.sin(frame / 8 + c.x) * 2;
          ctx.strokeStyle = "#ffe566";
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, 18, 10, 0, 0, 7); ctx.stroke();
          ctx.fillStyle = "rgba(0,0,0,.35)";
          ctx.beginPath(); ctx.ellipse(p.x, p.y + 4, 16, 7, 0, 0, 7); ctx.fill();
          const img = makeMob(c.kind);
          ctx.drawImage(img, p.x - 28, p.y - 48 + bob, 56, 56);
          ctx.fillStyle = "#000"; ctx.fillRect(p.x - 16, p.y - 46 + bob, 32, 5);
          ctx.fillStyle = "#e74c3c"; ctx.fillRect(p.x - 16, p.y - 46 + bob, 32 * Math.max(0, c.hp / c.hpMax), 5);
          if (showNames) {
            ctx.fillStyle = "#fff6c8";
            ctx.font = "bold 11px sans-serif";
            ctx.textAlign = "center";
            ctx.strokeStyle = "#000";
            ctx.lineWidth = 3;
            ctx.strokeText(c.name || c.kind, p.x, p.y - 50 + bob);
            ctx.fillText(c.name || c.kind, p.x, p.y - 50 + bob);
          }
        },
      });
    });
    const drawnMe = { v: false };
    others.filter(p => {
      if (!p) return false;
      if (hero && p.name === hero.name) return true;
      return !p.map || p.map === currentMap;
    }).forEach((p) => {
      const isMe = hero && p.name === hero.name;
      if (isMe) drawnMe.v = true;
      const px = isMe ? visX : p.x;
      const py = isMe ? visY : p.y;
      drawables.push({
        x: px, y: py, z: px + py + 0.4,
        draw() {
          const pos = iso(px, py);
          const lift = isMe && flying ? 10 + Math.sin(frame / 8) * 3 : 0;
          const sheet = makeCharSheet(p.voc, isMe ? hero.race : p.race, isMe ? hero.sex : p.sex);
          const fr = 0;
          drawMuWings(pos.x, pos.y - lift);
          ctx.drawImage(sheet, fr * 32, 0, 32, 48, pos.x - 26, pos.y - 68 - lift, 52, 74);
          if (isMe) drawGearOn(pos, lift);
          ctx.fillStyle = "#f5e6b8";
          ctx.font = "10px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(p.name, pos.x, pos.y - 44 - lift);
        },
      });
    });
    if (hero && !drawnMe.v) {
      drawables.push({
        x: visX, y: visY, z: visX + visY + 0.5,
        draw() {
          const pos = iso(visX, visY);
          const lift = flying ? 10 + Math.sin(frame / 8) * 3 : 0;
          const sheet = makeCharSheet(hero.voc, hero.race, hero.sex);
          const fr = (frame >> 3) & 1;
          drawMuWings(pos.x, pos.y - lift);
          ctx.drawImage(sheet, fr * 32, 0, 32, 48, pos.x - 26, pos.y - 68 - lift, 52, 74);
          drawGearOn(pos, lift);
          ctx.fillStyle = "#f5e6b8";
          ctx.font = "10px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(hero.name, pos.x, pos.y - 44 - lift);
        },
      });
    }
    drawables.sort((a, b) => a.z - b.z);
    drawables.forEach((d) => d.draw());
    ctx.restore();

    if (currentTheme === "halloween") {
      ctx.save(); ctx.setTransform(1,0,0,1,0,0);
      const fog=ctx.createLinearGradient(0,0,0,canvas.height); fog.addColorStop(0,"rgba(18,8,30,.22)"); fog.addColorStop(.5,"rgba(70,24,18,.03)"); fog.addColorStop(1,"rgba(0,0,0,.16)"); ctx.fillStyle=fog; ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle="rgba(255,170,60,.8)"; ctx.beginPath(); ctx.arc(canvas.width*.82,canvas.height*.19,26,0,7); ctx.fill();
      ctx.fillStyle="rgba(255,120,40,.13)"; ctx.beginPath(); ctx.arc(canvas.width*.82,canvas.height*.19,46,0,7); ctx.fill();
      ctx.restore();
    }
    drawMini();
    if (hero) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.font = "bold 14px sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(0,0,0,.45)";
      ctx.fillRect(canvas.width / 2 - 120, 128, 240, 20);
      ctx.fillStyle = inSafeZone() ? "#7dff9a" : "#ffe566";
      ctx.fillText((inSafeZone() ? "★ " : "") + mapName + (inSafeZone() ? "  ★" : ""), canvas.width / 2, 143);
      ctx.restore();
    }
    requestAnimationFrame(tick);
  }

  // Safety watchdog: a single malformed mob/map frame must never stop the game loop.
  let lastFrameError = 0;
  function tick(now) {
    try {
      gameFrame(now);
    } catch (err) {
      const tnow = performance.now();
      if (tnow - lastFrameError > 2000) {
        lastFrameError = tnow;
        try { chatLine("Recuperando o mapa…", "sys"); } catch {}
      }
      try {
        if (hero) { visX = Number.isFinite(hero.x) ? hero.x : 18; visY = Number.isFinite(hero.y) ? hero.y : 21; }
        endJoy();
      } catch {}
      requestAnimationFrame(tick);
    }
  }

  const statsBtn = document.getElementById("btn-stats");
  const statsBox = document.getElementById("stats-box");
  const statsX = document.getElementById("stats-x");
  function refreshStatsBox() {
    if (!statsBox || !hero) return;
    const eqIds = ["sword","armor","shield","helm","wings"].filter(id => hero.eq && hero.eq[id]);
    const rows = [
      ["ATK", (hero.atk || 0) + (hero.eq?.sword ? 8 : 0)],
      ["DEF", (hero.def || 0) + (hero.eq?.armor ? 6 : 0) + (hero.eq?.shield ? 4 : 0) + (hero.eq?.helm ? 3 : 0)],
      ["HP bônus", (hero.eq?.armor ? 15 : 0) + (hero.eq?.helm ? 8 : 0)],
      ["Crítico", (hero.eq?.sword ? 3 : 0) + "%"],
      ["Bloqueio", (hero.eq?.shield ? 5 : 0) + "%"],
      ["Magia", (hero.eq?.wings ? 5 : 0)],
      ["Velocidade", (hero.eq?.wings ? 2 : 0)]
    ];
    const target=document.getElementById("stats-content");
    if(target) target.innerHTML = rows.map(r => '<div class="stat-row"><span>'+r[0]+'</span><strong class="stat-good">'+r[1]+'</strong></div>').join('') +
      '<div style="margin-top:12px;color:#ffd979">Equipado: '+(eqIds.length ? eqIds.join(', ') : 'nenhum')+'</div>';
  }
  if (statsBtn) statsBtn.onclick = () => { refreshStatsBox(); statsBox.classList.add("open"); statsBox.setAttribute("aria-hidden","false"); };
  if (statsX) statsX.onclick = () => { statsBox.classList.remove("open"); statsBox.setAttribute("aria-hidden","true"); };

  requestAnimationFrame(tick);
  const savedHost = localStorage.getItem("fl_host");
  if (savedHost) document.getElementById("acc-host").value = savedHost;
  const lastU = localStorage.getItem("fl_last_user");
  if (lastU) document.getElementById("acc-user").value = lastU;
  document.querySelectorAll("#lang-bar .lang").forEach((b) => {
    b.onclick = () => { lang = b.dataset.lang; applyLang(); if (typeof paintPick === "function") {} };
  });
  applyLang();
  const kickMusic = () => { ensureAudio(); playMapMusic(currentTheme || "title"); };
  document.addEventListener("pointerdown", kickMusic, { once: false });
  document.getElementById("splash").addEventListener("pointerdown", kickMusic);
})();


/* === V9: 200 client systems inside existing Settings only === */
(function(){
 const FEATURES={"Jogo": ["Auto-save", "Reconexão automática", "Economia de bateria", "Qualidade gráfica", "Distância de visão", "Som ambiente", "Volume da música", "Volume de efeitos", "Vibração", "FPS alvo", "Idioma PT/FR/EN", "Números de dano", "Nomes de NPC", "Nomes de jogadores", "Nomes de monstros", "Tamanho da interface", "Opacidade da interface", "Modo canhoto", "Sensibilidade da câmera", "Velocidade da câmera", "Zoom máximo", "Zoom mínimo", "Suavidade da câmera", "Câmera invertida", "Bloqueio de alvo", "Auto-loot", "Confirmação de venda", "Confirmação de descarte", "Notificações de eventos", "Notificações de chat", "Filtro de palavras", "Chat global", "Chat local", "Chat de guilda", "Chat privado", "Registro de combate", "Registro de loot", "Tutorial", "Dicas de controles", "Acessibilidade", "Alto contraste", "Redução de efeitos", "Modo performance", "Modo qualidade", "Salvar preferências", "Restaurar configurações", "Central de ajuda", "Termos do jogo", "Créditos", "Versão do cliente"], "Mundo": ["Porto Inicial", "Floresta Sombria", "Deserto Rubro", "Pântano Espectral", "Montanhas de Gelo", "Costa dos Piratas", "Ruínas Antigas", "Minas Profundas", "Ilha Vulcânica", "Vale dos Dragões", "Cemitério", "Castelo Abandonado", "Templo Solar", "Cavernas Cristalinas", "Arena PvP", "Dungeon diária", "Dungeon semanal", "Boss mundial", "Boss de zona", "Eventos sazonais", "Halloween", "Festival de Inverno", "Festival de Primavera", "Festival de Verão", "Festival de Outono", "Ciclo dia/noite", "Chuva", "Tempestade", "Neve", "Névoa", "Clima regional", "Portais", "Pontos de teleporte", "Descoberta de mapa", "Mapa revelado", "Mapa oculto", "Áreas secretas", "Tesouros escondidos", "Baús", "Baús de elite", "Acampamentos inimigos", "Rotas de patrulha", "Zonas seguras", "Zonas de perigo", "NPCs ambulantes", "Mercadores viajantes", "Eventos aleatórios", "Invasões", "Caravanas", "Pesca"], "Personagem": ["Cinco poderes", "Dois poderes iniciais", "Desbloqueio por nível", "Cooldown de poderes", "Dano de habilidades", "Mana das habilidades", "Combos", "Ataque básico", "Crítico", "Defesa", "Esquiva", "Bloqueio", "Resistência ao fogo", "Resistência ao gelo", "Resistência elétrica", "Resistência física", "Velocidade", "Regeneração HP", "Regeneração MP", "Experiência", "Níveis", "Mastery", "Quests", "Quests diárias", "Quests semanais", "Conquistas", "Títulos", "Reputação", "Facções", "Profissões", "Crafting", "Forja", "Encantamento", "Upgrade de equipamento", "Durabilidade", "Equipamento visual", "Armaduras", "Armas", "Escudos", "Elmos", "Asas de dragão", "Brilho dourado das asas", "Animação das asas", "Montarias", "Pets", "Inventário", "Slots de equipamento", "Peso do inventário", "Banco", "Skills passivas"], "Economia": ["Ouro", "Drops normais", "Chance de drop 60%", "Poções", "Runas", "Cristais", "Materiais", "Itens de missão", "Loot de boss", "Itens de elite", "Comércio jogador-jogador", "Trade seguro", "Mercado", "Compra de NPC", "Venda de NPC", "Taxa de mercado", "Leilão", "Carteira de ouro", "Banco", "Recompensas diárias", "Bônus diário", "Recompensa de login", "Recompensas de quest", "Recompensas de evento", "Recompensa de conquista"], "Social": ["Guildas", "Convites de guilda", "Ranks de guilda", "Chat de guilda", "Guild quests", "Guild boss", "Guild storage", "Lista de amigos", "Pedidos de amizade", "Bloquear jogador", "Denunciar jogador", "Mensagem privada", "Party", "Convite para party", "Líder de party", "Experiência compartilhada", "Loot compartilhado", "Duelos", "PvP", "Arena", "Ranking", "Leaderboard", "Perfil do jogador", "Status online", "Lista de jogadores"]};
 const KEY="fl_v9_settings";
 const state=JSON.parse(localStorage.getItem(KEY)||"{}");
 const overlay=document.getElementById("feature-settings");
 const content=document.getElementById("settings-content");
 function save(){localStorage.setItem(KEY,JSON.stringify(state));}
 function toast(t){
   const e=document.getElementById("drop-toast");
   if(e){e.textContent=t;e.style.opacity="1";clearTimeout(e._v9);e._v9=setTimeout(()=>e.style.opacity="0",1400);}
 }
 function render(tab){
   const items=FEATURES[tab]||[];
   content.innerHTML='<div class="settings-grid">'+items.map((name,i)=>{
     const k=tab+"_"+i, on=state[k]!==false;
     return '<div class="setting-item"><b>'+name+'</b><small>'+ (on?"Ativo":"Desativado") +'</small><button type="button" data-k="'+k+'">'+(on?"DESATIVAR":"ATIVAR")+'</button></div>';
   }).join("")+'</div>';
   content.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{
     const k=b.dataset.k;state[k]=state[k]===false;save();render(tab);toast((state[k]?"Ativado: ":"Desativado: ")+items[+k.split("_").pop()]);
   });
 }
 function open(tab){overlay.hidden=false;render(tab||"Jogo");}
 function close(){overlay.hidden=true;}
 window.ForgottenLandsSettings={open,close,state,features:FEATURES};
 document.getElementById("settings-close")?.addEventListener("click",close);
 document.querySelectorAll(".settings-tabs [data-tab]").forEach(b=>b.addEventListener("click",()=>render(b.dataset.tab)));
 document.addEventListener("keydown",e=>{if(e.key==="Escape")close();});
 // Existing gear/settings controls open the system center; no new HUD button is created.
 document.querySelectorAll("button").forEach(b=>{
   const s=((b.textContent||"")+" "+(b.getAttribute("aria-label")||"")).toLowerCase();
   if((s.includes("⚙")||s.includes("config"))&&!b.dataset.v9settings){b.dataset.v9settings="1";b.addEventListener("click",()=>open("Jogo"));}
 });
 window.ForgottenLandsV9={
   featureCount:200, features:FEATURES, save, state,
   bossDrop(){
     const pool=["Ouro","Poção HP","Poção MP","Cristal Comum","Runa Simples","Fragmento de Ferro"];
     const item=pool[Math.floor(Math.random()*pool.length)];toast("Boss: drop normal — "+item);return item;
   },
   unlockPower(level){return {1:"Fogo",2:"Gelo",5:"Raio",10:"Vento",20:"Meteoro"}[level]||null;}
 };
})();


/* === V10: upright golden dragon wings + full login/server status === */
(function(){
  const extraI18N = {
    pt:{
      accounts:"Contas criadas", onlinePlayers:"Jogadores online", server:"Servidor",
      connecting:"Conectando...", onlineStatus:"Online", offlineStatus:"Indisponível",
      statsUnavailable:"Estatísticas do servidor indisponíveis", accountCount:"contas",
      playerCount:"jogadores online", dragon:"Asas de dragão douradas"
    },
    fr:{
      accounts:"Comptes créés", onlinePlayers:"Joueurs en ligne", server:"Serveur",
      connecting:"Connexion...", onlineStatus:"En ligne", offlineStatus:"Indisponible",
      statsUnavailable:"Statistiques du serveur indisponibles", accountCount:"comptes",
      playerCount:"joueurs en ligne", dragon:"Ailes de dragon dorées"
    },
    en:{
      accounts:"Accounts created", onlinePlayers:"Players online", server:"Server",
      connecting:"Connecting...", onlineStatus:"Online", offlineStatus:"Unavailable",
      statsUnavailable:"Server statistics unavailable", accountCount:"accounts",
      playerCount:"players online", dragon:"Golden dragon wings"
    }
  };
  function L(){ return extraI18N[window.lang || localStorage.getItem("fl_lang") || "pt"] || extraI18N.pt; }

  window.applyServerStatsLanguage=function(){
    const l=L();
    const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
    set("stat-accounts-label",l.accounts);
    set("stat-online-label",l.onlinePlayers);
    set("stat-status-label",l.server);
  };

  // Stats are read-only on the client. It tries common endpoints without changing the server.
  async function fetchStats(){
    const host=(document.getElementById("acc-host")?.value||"forgotten-lands.onrender.com").trim()
      .replace(/^https?:\/\//,"").replace(/\/+$/,"");
    const endpoints=[`https://${host}/api/stats`,`https://${host}/stats`,`https://${host}/status`];
    const accountEl=document.getElementById("stat-accounts");
    const onlineEl=document.getElementById("stat-online");
    const statusEl=document.getElementById("stat-status");
    const l=L();
    if(accountEl)accountEl.textContent="…";
    if(onlineEl)onlineEl.textContent="…";
    if(statusEl)statusEl.textContent="●";
    for(const url of endpoints){
      try{
        const r=await fetch(url,{cache:"no-store",headers:{"Accept":"application/json"}});
        if(!r.ok)continue;
        const d=await r.json();
        const accounts=d.accounts ?? d.accountCount ?? d.totalAccounts ?? d.users ?? d.total_users;
        const online=d.online ?? d.onlineCount ?? d.playersOnline ?? d.players ?? d.connected;
        if(accountEl && accounts!=null)accountEl.textContent=Number(accounts).toLocaleString();
        if(onlineEl && online!=null){
          const n=Array.isArray(online)?online.length:Number(online);
          onlineEl.textContent=Number.isFinite(n)?n.toLocaleString():String(n);
        }
        if(statusEl)statusEl.textContent="● "+l.onlineStatus;
        return;
      }catch(e){}
    }
    if(statusEl)statusEl.textContent="● "+l.offlineStatus;
    if(accountEl)accountEl.textContent="—";
    if(onlineEl)onlineEl.textContent="—";
  }
  window.refreshForgottenLandsStats=fetchStats;

  // Poll only while the login screen is visible.
  function poll(){
    const splash=document.getElementById("splash");
    if(splash && getComputedStyle(splash).display!=="none") fetchStats();
  }
  applyServerStatsLanguage();
  fetchStats();
  setInterval(poll,15000);

  // Hook the existing language buttons so the new stats labels follow PT/FR/EN.
  document.querySelectorAll("#lang-bar .lang").forEach(b=>{
    b.addEventListener("click",()=>setTimeout(applyServerStatsLanguage,0));
  });
  document.querySelectorAll("#set-langs .lang").forEach(b=>{
    b.addEventListener("click",()=>setTimeout(applyServerStatsLanguage,0));
  });

  // If the server already sends an online list, use it immediately.
  const oldOnMessage=window.__fl_original_onmessage;
})();


/* === V11 Party system / nearby contextual invite === */
(function(){
  const PARTY_RANGE=3.2;
  let partyTarget=null;
  let partyMembers=[];
  let partyXpShare=true;
  const btn=()=>document.getElementById("party-near");
  function nearest(){
    if(!window.hero || !Array.isArray(window.others)) return null;
    const list=window.others.filter(p=>p && p.name && p.name!==window.hero.name && (!p.map || p.map===window.hero.map));
    list.sort((a,b)=>
      Math.hypot(a.x-window.hero.x,a.y-window.hero.y)-
      Math.hypot(b.x-window.hero.x,b.y-window.hero.y));
    const p=list[0];
    if(!p) return null;
    const d=Math.hypot(p.x-window.hero.x,p.y-window.hero.y);
    return d<=PARTY_RANGE?p:null;
  }
  function show(){
    const b=btn(); if(!b)return;
    const p=nearest();
    partyTarget=p||null;
    if(p){b.hidden=false;b.textContent="👥 PARTY · "+p.name;b.classList.remove("party-pending");}
    else {b.hidden=true;b.classList.remove("party-pending");}
  }
  function sendParty(type,to){
    if(typeof window.ForgottenLandsSend==="function"){
      window.ForgottenLandsSend({type,to});
      return true;
    }
    return false;
  }
  function invite(){
    if(!partyTarget)return;
    btn().classList.add("party-pending");
    sendParty("partyAsk",partyTarget.name);
    if(typeof window.ForgottenLandsChat==="function")
      window.ForgottenLandsChat("Convite de party enviado para "+partyTarget.name+".","sys");
  }
  window.ForgottenLandsParty={
    update:show,
    invite,
    get members(){return partyMembers},
    setXpShare(v){partyXpShare=!!v},
    xpShare:()=>partyXpShare
  };
  btn()?.addEventListener("click",invite);

  // Render a compact party panel only while in a party, outside the joystick/action area.
  window.ForgottenLandsPartyApply=function(m){
    if(!m)return;
    partyMembers=m.members||m.players||partyMembers;
    const b=btn();
    if(b && partyMembers.length){
      b.hidden=false;
      b.textContent="👥 PARTY "+partyMembers.length;
      b.classList.remove("party-pending");
    }
  };
  setInterval(show,250);
})();

setTimeout(function(){
  try{
    window.ForgottenLandsSend = function(o){
      if(typeof send==="function") return send(o);
      return false;
    };
    window.ForgottenLandsChat = function(t,c){
      if(typeof chatLine==="function") chatLine(t,c||"sys");
    };
    window.ForgottenLandsPartyApply = window.ForgottenLandsPartyApply || function(){};
  }catch(e){}
},0);

/* V11: request shared XP when attacking while in a party. */
(function(){
  const oldSend=window.ForgottenLandsSend;
  window.ForgottenLandsRequestPartyXp=function(xp){
    try{
      if(typeof oldSend==="function") oldSend({type:"partyXp",xp:Number(xp)||0});
    }catch(e){}
  };
})();
