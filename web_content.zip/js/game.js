/**
 * Forgotten Lands — cliente pixel isometrico + multiplayer.
 * Sprites desenhados na hora (arte original). Nao usa grafico da CipSoft.
 */
(function () {
  const MAP = 36, HALF = 18;
  const TW = 64, TH = 32;
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = true;

  const TILE = { GRASS: 1, PATH: 2, WATER: 3, STONE: 4, WOOD: 5, SAND: 6 };
  let lang = localStorage.getItem("fl_lang") || "pt";
  const I18N = {
    pt: {
      lead: "Mundo pixel isometrico compartilhado. Crie conta e entre no mesmo servidor.",
      user: "conta (login)", pass: "senha", pname: "nome do personagem",
      voc: "Vocacao", look: "Aparencia", man: "Homem", woman: "Mulher",
      human: "Humano", elf: "Elfo", elfa: "Elfa", dwarf: "Anao",
      create: "Criar conta", enter: "Entrar", chosen: "Escolhido",
      chat: "fale no mundo...", map: "mapa", wings: "asas",
      pack: "Mochila", travel: "Viajar", arrived: "Voce chegou em ",
      equipped: "Voce equipou ", unequipped: "Voce desequipou ",
      levelup: "Voce avancou para o nivel ",
      hit: " te acerta (",
      dead: "Voce desmaiou e acordou no Porto.",
      killed: "derrotou ",
      online: "online",
      foot: "Pixel original · chat · trade · XP · mesmo mundo",
      daily: "Bonus diario: +50 ouro e +1 maca!",
      dailyDone: "Bonus diario ja coletado hoje.",
      q1: "Missao: mate 5 monstros fora da cidade.",
      q1ok: "Missao cumprida! +100 gp +200 xp",
      come: "Forgotten Lands: seus amigos estao online. Volta a jogar!",
      city: "CIDADE PRINCIPAL · ZONA SEGURA",
      hunt: "area de caca",
      wingsOn: "Asas abertas. Voo baixo.",
      wingsOff: "Voce pousou.",
      needLv: "Precisa de level ",
      set: "Configuracoes", setLang: "Idioma", setSfx: "Som / musica",
      setNames: "Nomes dos monstros", setNote: "A cidade principal nao tira vida.",
    },
    fr: {
      lead: "Monde pixel isometrique partage. Creez un compte et rejoignez le serveur.",
      user: "compte (login)", pass: "mot de passe", pname: "nom du personnage",
      voc: "Vocation", look: "Apparence", man: "Homme", woman: "Femme",
      human: "Humain", elf: "Elfe", elfa: "Elfe F", dwarf: "Nain",
      create: "Creer un compte", enter: "Entrer", chosen: "Choisi",
      chat: "parler au monde...", map: "carte", wings: "ailes",
      pack: "Sac", travel: "Voyager", arrived: "Vous arrivez a ",
      equipped: "Vous equipez ", unequipped: "Vous retirez ",
      levelup: "Vous passez au niveau ",
      hit: " vous touche (",
      dead: "Vous tombez et reveillez au Port.",
      killed: "vaincu ",
      online: "en ligne",
      foot: "Pixel original · chat · echange · XP · meme monde",
      daily: "Bonus quotidien: +50 or et +1 pomme !",
      dailyDone: "Bonus du jour deja pris.",
      q1: "Quete: tuez 5 monstres hors de la ville.",
      q1ok: "Quete terminee ! +100 po +200 xp",
      come: "Forgotten Lands: tes amis sont en ligne. Reviens jouer !",
      city: "VILLE PRINCIPALE · ZONE SURE",
      hunt: "zone de chasse",
      wingsOn: "Ailes ouvertes. Vol bas.",
      wingsOff: "Vous atterrissez.",
      needLv: "Il faut le niveau ",
      set: "Reglages", setLang: "Langue", setSfx: "Son / musique",
      setNames: "Noms des monstres", setNote: "La ville principale ne retire pas de vie.",
    },
    en: {
      lead: "Shared isometric pixel world. Create an account and join the same server.",
      user: "account (login)", pass: "password", pname: "character name",
      voc: "Vocation", look: "Look", man: "Male", woman: "Female",
      human: "Human", elf: "Elf", elfa: "Elf F", dwarf: "Dwarf",
      create: "Create account", enter: "Enter", chosen: "Selected",
      chat: "talk to the world...", map: "map", wings: "wings",
      pack: "Backpack", travel: "Travel", arrived: "You arrived in ",
      equipped: "You equipped ", unequipped: "You unequipped ",
      levelup: "You reached level ",
      hit: " hits you (",
      dead: "You fainted and woke up at the Harbor.",
      killed: "defeated ",
      online: "online",
      foot: "Original pixel · chat · trade · XP · same world",
      daily: "Daily bonus: +50 gold and +1 apple!",
      dailyDone: "Daily bonus already claimed today.",
      q1: "Quest: defeat 5 monsters outside town.",
      q1ok: "Quest complete! +100 gp +200 xp",
      come: "Forgotten Lands: friends are online. Come back!",
      city: "MAIN CITY · SAFE ZONE",
      hunt: "hunting grounds",
      wingsOn: "Wings open. Low flight.",
      wingsOff: "You landed.",
      needLv: "Need level ",
      set: "Settings", setLang: "Language", setSfx: "Sound / music",
      setNames: "Monster names", setNote: "The main city does not take HP.",
    },
  };
  function t(k) { return (I18N[lang] || I18N.pt)[k] || k; }
  function applyLang() {
    const L = I18N[lang] || I18N.pt;
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    const ph = (id, v) => { const e = document.getElementById(id); if (e) e.placeholder = v; };
    set("splash-lead", L.lead);
    ph("acc-user", L.user); ph("acc-pass", L.pass); ph("acc-name", L.pname);
    ph("chat-in", L.chat);
    set("btn-register", L.create); set("btn-start", L.enter);
    set("btn-map", L.map); set("btn-fly", L.wings);
    set("set-title", L.set);
    set("set-lang-lab", L.setLang);
    set("set-sfx-lab", L.setSfx);
    set("set-names-lab", L.setNames);
    set("set-note", L.setNote);
    document.querySelectorAll("#set-langs .lang").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
    const labs = document.querySelectorAll(".pick-lab");
    if (labs[0]) labs[0].textContent = L.voc;
    if (labs[1]) labs[1].textContent = L.look;
    const races = document.querySelectorAll("#races .voc");
    if (races[0]) races[0].textContent = L.human;
    if (races[1]) races[1].textContent = L.elf;
    if (races[2]) races[2].textContent = L.elfa;
    if (races[3]) races[3].textContent = L.dwarf;
    const sexes = document.querySelectorAll("#sexes .voc");
    if (sexes[0]) sexes[0].textContent = L.man;
    if (sexes[1]) sexes[1].textContent = L.woman;
    const small = document.querySelector("#splash small");
    if (small) small.textContent = L.foot;
    document.querySelectorAll("#lang-bar .lang").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
    localStorage.setItem("fl_lang", lang);
  }
  function todayKey() {
    const d = new Date();
    return d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
  }
  function giveDailyBonus() {
    if (!hero) return;
    const k = "fl_daily_" + (hero.name || "x");
    if (localStorage.getItem(k) === todayKey()) return;
    localStorage.setItem(k, todayKey());
    hero.gold = (hero.gold || 0) + 50;
    const ap = hero.inventory && hero.inventory.find((i) => i.id === "apple");
    if (ap) ap.qty += 1;
    else if (hero.inventory) hero.inventory.push({ id: "apple", icon: "🍎", name: "Maca", qty: 1, use: "food" });
    chatLine(t("daily"), "loot");
    chatLine(t("q1"), "sys");
    applyHero(hero);
    try {
      if (Notification && Notification.permission === "granted") {
        new Notification("Forgotten Lands", { body: t("daily") });
      } else if (Notification && Notification.permission !== "denied") {
        Notification.requestPermission();
      }
    } catch (e) {}
    setTimeout(() => {
      try { if (Notification && Notification.permission === "granted") new Notification("Forgotten Lands", { body: t("come") }); } catch (e) {}
      chatLine(t("come"), "sys");
    }, 8 * 60 * 1000);
  }
  const map = [];
  const solids = new Set();

  function seeded(x, y) {
    let n = x * 374761393 + y * 668265263;
    n = (n ^ (n >> 13)) * 1274126177;
    return ((n ^ (n >> 16)) >>> 0) / 4294967296;
  }
  function genMap(theme) {
    theme = theme || "grass";
    solids.clear();
    for (let y = 0; y < MAP; y++) {
      map[y] = [];
      for (let x = 0; x < MAP; x++) {
        const d = Math.hypot(x - HALF, y - HALF);
        let t = TILE.GRASS;
        if (theme === "sand") t = TILE.SAND;
        if (theme === "swamp") t = TILE.WOOD;
        if (theme === "forest") t = TILE.GRASS;
        if (theme === "city") t = TILE.STONE;
        if (theme === "cave" || theme === "lair" || theme === "fort") t = TILE.STONE;
        if (theme === "lava") t = TILE.PATH;
        if (theme === "grass" && d > 15.4) t = TILE.WATER;
        else if (theme === "sand" && d > 14) t = TILE.WATER;
        else if (theme === "swamp" && seeded(x, y) > 0.55) t = TILE.WATER;
        else if (theme === "lava" && seeded(x, y) > 0.72) t = TILE.WATER;
        else if (theme === "city" && (Math.abs(x - HALF) < 2 || Math.abs(y - HALF) < 2)) t = TILE.PATH;
        else if (theme === "forest" && seeded(x, y) > 0.82) t = TILE.WOOD;
        else if ((theme === "grass" || theme === "city") && (Math.abs(x - HALF) < 1.2 || Math.abs(y - HALF) < 1.2)) t = TILE.PATH;
        else if (theme === "cave" && seeded(x, y) > 0.88) t = TILE.PATH;
        if (theme === "city" && x > 8 && x < 28 && y > 8 && y < 28) t = TILE.STONE;
        map[y][x] = t;
      }
    }
    if (theme === "city") {
      for (let y = 16; y <= 19; y++) for (let x = 16; x <= 19; x++) map[y][x] = TILE.STONE;
    }
    if (theme === "grass") {
      for (let x = 8; x <= 14; x++) map[20][x] = TILE.WOOD;
    }
    for (let y = 3; y < MAP - 3; y++) {
      for (let x = 3; x < MAP - 3; x++) {
        const r = seeded(x * 3, y * 7);
        if (theme === "forest" && r > 0.9) solids.add(x + "," + y);
        if (theme === "grass" && r > 0.96) solids.add(x + "," + y);
        if (theme === "city" && r > 0.97) solids.add(x + "," + y);
      }
    }
  }
  genMap("grass");

  function iso(x, y) {
    return { x: (x - y) * (TW / 2), y: (x + y) * (TH / 2) };
  }

  /* ---- pixel sprites (32x48 outfit tibia-like original) ---- */
  const pal = {
    knight: { body: "#8a1e12", legs: "#3d2b1a", boot: "#2a1a10", head: "#e0b090", hair: "#3a2410", extra: "#c9a227" },
    paladin: { body: "#2c5aa0", legs: "#2a3344", boot: "#1a1a22", head: "#e0b090", hair: "#6b3a12", extra: "#c9a227" },
    sorcerer: { body: "#5b2d8a", legs: "#2a1838", boot: "#1a1020", head: "#e8c4a0", hair: "#222", extra: "#88ccff" },
    druid: { body: "#2d6a28", legs: "#1a3a18", boot: "#243018", head: "#c48a58", hair: "#4a2a10", extra: "#88dd55" },
  };
  const racePal = {
    humano: {},
    elfo: { head: "#f0d0b0", hair: "#d4c06a", extra: "#7dffb0" },
    elfa: { head: "#f3d4bc", hair: "#f2e08a", extra: "#ff9ad4" },
    anao: { head: "#c88858", hair: "#6a3a18", extra: "#c9a227" },
  };
  const spriteCache = {};

  function px(c, x, y, col, w) {
    c.fillStyle = col;
    c.fillRect(x, y, w || 1, 1);
  }
  function oval(c, x, y, rx, ry, col) {
    c.fillStyle = col;
    c.beginPath();
    c.ellipse(x, y, rx, ry, 0, 0, 7);
    c.fill();
  }
  function drawOutfit(c, o, frame) {
    c.fillStyle = "rgba(0,0,0,.28)";
    c.beginPath(); c.ellipse(16, 44, 9, 3, 0, 0, 7); c.fill();
    const step = frame ? 1 : 0;
    oval(c, 12 - step, 40, 3.2, 2.4, "#2a2a32");
    oval(c, 20 + step, 40, 3.2, 2.4, "#2a2a32");
    oval(c, 13, 34, 3.2, 7, "#8a9098");
    oval(c, 19, 34, 3.2, 7, "#8a9098");
    oval(c, 16, 24, 7.2, 9, o.body);
    oval(c, 16, 21, 6.4, 3, "#d8d8e0");
    oval(c, 16, 29, 6, 1.6, o.extra);
    oval(c, 16, 25, 2.2, 2.2, "#c9a227");
    oval(c, 8, 20, 3.4, 3.2, "#b8bec8");
    oval(c, 24, 20, 3.4, 3.2, "#b8bec8");
    oval(c, 8, 26, 2.4, 5, o.body);
    oval(c, 24, 26, 2.4, 5, o.body);
    oval(c, 16, 13, 5.4, 5.8, o.head);
    oval(c, 16, 9, 6.2, 3.6, "#c8ccd4");
    oval(c, 16, 12.2, 3.4, 1.6, "#1a1a22");
    oval(c, 14.2, 12.2, 1.1, 1.1, "#4a80ff");
    oval(c, 17.8, 12.2, 1.1, 1.1, "#4a80ff");
  }
  function makeCharSheet(voc, race, sex) {
    const key = voc + "-" + (race || "humano") + "-" + (sex || "m");
    if (spriteCache[key]) return spriteCache[key];
    voc = voc || "knight";
    const s = document.createElement("canvas");
    s.width = 64; s.height = 48;
    const c = s.getContext("2d");
    c.imageSmoothingEnabled = true;
    const o = Object.assign({}, pal[voc] || pal.knight, racePal[race] || {});
    if (sex === "f" || race === "elfa") o.hair = o.hair || "#e8c070";
    drawOutfit(c, o, 0);
    if (sex === "f" || race === "elfa") {
      c.fillStyle = o.hair;
      c.fillRect(10, 10, 3, 8);
      c.fillRect(19, 10, 3, 8);
    }
    if (race === "anao") {
      c.fillStyle = o.hair;
      c.fillRect(13, 18, 6, 3);
    }
    c.save(); c.translate(32, 0); drawOutfit(c, o, 1); c.restore();
    spriteCache[key] = s;
    return s;
  }
  function drawGearOn(pos, lift) {
    if (!hero || !hero.eq) return;
    const x = pos.x, y = pos.y - lift;
    if (hero.eq.armor) {
      ctx.fillStyle = "#7a5a28";
      ctx.fillRect(x - 8, y - 28, 16, 12);
      ctx.fillStyle = "#c9a227";
      ctx.fillRect(x - 8, y - 18, 16, 2);
    }
    if (hero.eq.helm) {
      ctx.fillStyle = "#8a8a8a";
      ctx.fillRect(x - 7, y - 42, 14, 6);
      ctx.fillRect(x - 8, y - 38, 16, 3);
    }
    if (hero.eq.shield) {
      ctx.fillStyle = "#8a6a32";
      ctx.fillRect(x - 16, y - 26, 7, 12);
      ctx.fillStyle = "#c9a227";
      ctx.fillRect(x - 15, y - 22, 5, 4);
    }
    const swinging = performance.now() < atkUntil;
    const ang = swinging ? -0.9 + ((atkUntil - performance.now()) / 280) * 1.8 : 0;
    if (hero.eq.sword || swinging) {
      ctx.save();
      ctx.translate(x + 8, y - 22);
      ctx.rotate(ang);
      ctx.fillStyle = hero.eq && hero.eq.sword ? "#cfd6de" : "#e8d0a8";
      ctx.fillRect(2, -16, 3, 20);
      ctx.fillStyle = "#c9a227";
      ctx.fillRect(0, 2, 7, 3);
      ctx.fillStyle = "#6b4423";
      ctx.fillRect(2, 4, 3, 6);
      ctx.restore();
    }
    if (swinging) {
      ctx.strokeStyle = "rgba(255,230,160,.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x + 4, y - 24, 16, -0.2, 1.3);
      ctx.stroke();
    }
  }
  function drawMuWings(x, y) {
    const glow = 0.4 + Math.sin(frame / 7) * 0.2;
    ctx.save();
    [[-1, -0.55], [1, 0.55]].forEach((s) => {
      ctx.fillStyle = "rgba(120,190,255," + glow + ")";
      ctx.beginPath();
      ctx.ellipse(x + s[0] * 28, y - 30, 22, 14, s[1], 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(230,245,255,.8)";
      ctx.beginPath();
      ctx.ellipse(x + s[0] * 24, y - 32, 12, 8, s[1], 0, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(180,220,255,.7)";
      ctx.lineWidth = 1.4;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(x + s[0] * 8, y - 24);
        ctx.quadraticCurveTo(x + s[0] * (18 + i * 4), y - 36 - i, x + s[0] * (30 + i * 3), y - 18 + i * 3);
        ctx.stroke();
      }
    });
    ctx.restore();
  }
  function inSafeZone() {
    const s = String(currentMap || "") + " " + String((hero && hero.map) || "") + " " + String(mapName || "");
    return /porto|templo|temple|cidade|harbor|port/i.test(s);
  }
  function makeMob(kind) {
    const key = "m_" + kind;
    if (spriteCache[key]) return spriteCache[key];
    const s = document.createElement("canvas");
    s.width = 32; s.height = 32;
    const c = s.getContext("2d");
    const colors = {
      rat: "#6a5340", snake: "#3d8a32", spider: "#222", orc: "#4a6b32",
      wolf: "#6a5a4a", slime: "#5aaa3a", scarab: "#6b5a22", bat: "#3a2a4a",
      berserk: "#5a2a12", fire: "#d45512", dragon: "#8a1e12",
      crab: "#c45a32", seagull: "#e8e8e0", boar: "#5a3a22", wasp: "#d4c017",
      toad: "#4a7a32", mummy: "#c8b888", troll: "#6a7a44",
    };
    const col = colors[kind] || "#555";
    c.fillStyle = "rgba(0,0,0,.3)"; c.fillRect(8, 26, 16, 4);
    if (kind === "rat") {
      c.fillStyle = "#3a2a18"; c.fillRect(6, 16, 20, 12);
      c.fillStyle = "#c48a4a"; c.fillRect(8, 17, 16, 9);
      c.fillRect(18, 10, 10, 10);
      c.fillStyle = "#fff"; c.fillRect(24, 13, 3, 3);
      c.fillStyle = "#111"; c.fillRect(25, 14, 2, 2);
      c.fillStyle = "#e8c090"; c.fillRect(26, 18, 5, 3);
    } else if (kind === "snake") {
      c.fillStyle = col; c.fillRect(8, 22, 16, 4); c.fillRect(20, 16, 6, 8); c.fillRect(22, 12, 4, 6);
    } else if (kind === "spider") {
      c.fillStyle = col; c.fillRect(12, 16, 8, 8);
      c.fillRect(6, 18, 20, 2); c.fillRect(8, 14, 2, 12); c.fillRect(22, 14, 2, 12);
    } else {
      c.fillStyle = col; c.fillRect(10, 10, 12, 16); c.fillStyle = "#6b8f3a"; c.fillRect(12, 4, 8, 8);
      c.fillStyle = "#222"; c.fillRect(14, 7, 2, 2); c.fillRect(18, 7, 2, 2);
    }
    spriteCache[key] = s;
    return s;
  }

  const tileCols = {
    1: ["#5cbc3a", "#3a8a28"],
    2: ["#f0d48a", "#d4b05a"],
    3: ["#3cb4e8", "#1e78c0"],
    4: ["#d0c8b0", "#a89880"],
    5: ["#c87838", "#8a4a18"],
    6: ["#f2d890", "#d4b060"],
  };
  function drawTile(x, y, t) {
    const p = iso(x, y);
    let cols = tileCols[t] || tileCols[1];
    if (currentTheme === "swamp" && t === TILE.WOOD) cols = ["#3a4a22", "#2a3318"];
    if (currentTheme === "forest" && t === TILE.GRASS) cols = ["#1e4a22", "#163818"];
    if (currentTheme === "lava" && t === TILE.PATH) cols = ["#6a2010", "#3a1008"];
    if (currentTheme === "lava" && t === TILE.WATER) cols = ["#e07020", "#a03010"];
    if (currentTheme === "lair" && t === TILE.STONE) cols = ["#4a2030", "#2a1018"];
    if (currentTheme === "fort" && t === TILE.STONE) cols = ["#6a6048", "#3a3828"];
    if (currentTheme === "city" && t === TILE.STONE) cols = ["#7a7a72", "#55554c"];
    if (currentTheme === "cave" && t === TILE.STONE) cols = ["#3a3a44", "#22222a"];
    const h = t === TILE.WATER ? 4 : 10;
    ctx.fillStyle = cols[1];
    ctx.beginPath();
    ctx.moveTo(p.x - TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x, p.y + TH + h);
    ctx.lineTo(p.x - TW / 2, p.y + TH / 2 + h);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#00000033";
    ctx.beginPath();
    ctx.moveTo(p.x + TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x, p.y + TH + h);
    ctx.lineTo(p.x + TW / 2, p.y + TH / 2 + h);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + TW / 2, p.y + TH / 2);
    ctx.lineTo(p.x, p.y + TH);
    ctx.lineTo(p.x - TW / 2, p.y + TH / 2);
    ctx.closePath();
    const tg = ctx.createLinearGradient(p.x, p.y, p.x, p.y + TH);
    tg.addColorStop(0, cols[0]);
    tg.addColorStop(1, cols[1]);
    ctx.fillStyle = tg;
    ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,.12)";
    ctx.lineWidth = 1;
    ctx.stroke();
    if (t === TILE.WATER) {
      const w = Math.sin((frame + x * 5 + y * 9) / 8);
      ctx.fillStyle = w > 0 ? "#3aa0c8" : "#2b88b4";
      ctx.beginPath();
      ctx.moveTo(p.x - 8, p.y + 10);
      ctx.quadraticCurveTo(p.x + w * 6, p.y + 14, p.x + 8, p.y + 12);
      ctx.strokeStyle = "rgba(180,230,255,.55)";
      ctx.stroke();
      if (((x * 13 + y * 7) % 11) === 0) {
        ctx.fillStyle = "#f0c060";
        ctx.fillRect(p.x - 2 + w, p.y + 8, 3, 2);
      }
    }
    if (t === TILE.GRASS) {
      const sway = Math.sin((frame + x * 7 + y * 3) / 14) * 2.2;
      ctx.strokeStyle = "rgba(70,140,50,.75)";
      ctx.lineWidth = 1.2;
      ctx.lineCap = "round";
      for (let i = 0; i < 5; i++) {
        const ox = ((x * 13 + y * 7 + i * 19) % 17) - 8;
        const oy = ((x * 5 + y * 11 + i * 9) % 11) - 2;
        ctx.beginPath();
        ctx.moveTo(p.x + ox, p.y + 10 + oy);
        ctx.quadraticCurveTo(p.x + ox + sway, p.y + 4 + oy, p.x + ox + sway * 0.4, p.y - 2 + oy);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(180,220,90,.18)";
      ctx.beginPath(); ctx.ellipse(p.x - 6, p.y + 6, 4, 2, 0, 0, 7); ctx.fill();
      if (((x * 17 + y * 11) % 9) === 0) {
        const fl = ["#ff4d6d", "#ffd24a", "#ff7ad9", "#7ae0ff"][(x + y) % 4];
        ctx.fillStyle = fl;
        ctx.beginPath(); ctx.ellipse(p.x + 4, p.y + 6, 3, 3, 0, 0, 7); ctx.fill();
      }
    }
    if (t === TILE.PATH || t === TILE.STONE) {
      ctx.strokeStyle = "rgba(0,0,0,.18)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(p.x - 10, p.y + 6); ctx.lineTo(p.x + 8, p.y + 14);
      ctx.moveTo(p.x + 4, p.y + 4); ctx.lineTo(p.x - 6, p.y + 12);
      ctx.stroke();
    }
  }
  function drawTree(x, y) {
    const p = iso(x, y);
    ctx.fillStyle = "#3a2010"; ctx.fillRect(p.x - 5, p.y - 6, 10, 20);
    ctx.fillStyle = "#5a3518"; ctx.fillRect(p.x - 3, p.y - 10, 6, 18);
    ctx.fillStyle = "#164a1c"; ctx.beginPath(); ctx.ellipse(p.x, p.y - 28, 16, 14, 0, 0, 7); ctx.fill();
    ctx.fillStyle = "#2d8a38"; ctx.beginPath(); ctx.ellipse(p.x - 2, p.y - 32, 12, 10, 0, 0, 7); ctx.fill();
  }
  function drawHouse(x, y) {
    const p = iso(x + 0.5, y + 0.5);
    const roofs = ["#e23b4a", "#2f6fe0", "#e07a14", "#7b2fd0", "#1aa36a"];
    const roof = roofs[(x + y) % roofs.length];
    ctx.fillStyle = "#c48a4a"; ctx.fillRect(p.x - 26, p.y - 8, 52, 24);
    ctx.fillStyle = "#e8b878"; ctx.fillRect(p.x - 24, p.y - 22, 48, 22);
    ctx.fillStyle = roof;
    ctx.beginPath(); ctx.moveTo(p.x - 30, p.y - 20); ctx.lineTo(p.x, p.y - 48); ctx.lineTo(p.x + 30, p.y - 20); ctx.fill();
    ctx.fillStyle = "#fff6a8";
    ctx.beginPath(); ctx.moveTo(p.x - 20, p.y - 22); ctx.lineTo(p.x, p.y - 40); ctx.lineTo(p.x + 8, p.y - 22); ctx.fill();
    ctx.fillStyle = "#7fe0ff"; ctx.fillRect(p.x - 16, p.y - 14, 8, 8); ctx.fillRect(p.x + 8, p.y - 14, 8, 8);
    ctx.fillStyle = "#5a3010"; ctx.fillRect(p.x - 5, p.y - 2, 10, 16);
  }
  function drawTemple(x, y) {
    const p = iso(x, y);
    ctx.fillStyle = "#cfc6b0"; ctx.fillRect(p.x - 26, p.y - 6, 52, 16);
    ctx.fillStyle = "#e8e0cc";
    ctx.fillRect(p.x - 20, p.y - 28, 6, 24);
    ctx.fillRect(p.x + 14, p.y - 28, 6, 24);
    ctx.fillStyle = "#d4a017"; ctx.fillRect(p.x - 24, p.y - 32, 48, 6);
    ctx.fillStyle = "#ff8a1a"; ctx.fillRect(p.x - 3, p.y - 40, 6, 8);
  }

  /* ---- state ---- */
  let hero = null;
  let others = [];
  let creatures = [];
  let drops = [];
  let portals = [];
  let currentMap = "porto";
  let currentTheme = "grass";
  let mapName = "Porto Inicial";
  let ws = null;
  let connected = false;
  const keys = {};
  const joy = { dx: 0, dy: 0, on: false, id: null };
  let moveAcc = 0;
  let visX = 18, visY = 21;
  let camX = 0, camY = 0;
  let frame = 0;
  let lookT = 0;
  let chosenVoc = "knight";
  let chosenRace = "humano";
  let chosenSex = "m";
  let flying = false;
  let atkUntil = 0;
  let audioCtx = null, musicNodes = [], musicOn = true, musicTheme = "", showNames = true, pvpOn = true;
  const SONGS = {
    grass: [262, 330, 392, 523, 392, 330, 294, 330, 392, 330, 262, 196],
    city: [330, 392, 440, 523, 440, 392, 349, 392],
    sand: [294, 349, 440, 349, 392, 294],
    forest: [220, 262, 330, 392, 330, 262],
    swamp: [196, 233, 262, 233, 196],
    cave: [175, 220, 262, 220],
    fort: [247, 311, 370, 311, 247],
    lava: [208, 262, 311, 370, 311],
    lair: [165, 196, 247, 196],
    title: [262, 330, 392, 523, 494, 392, 330, 392, 440, 392, 330, 262],
  };
  function ensureAudio() {
    if (audioCtx) return audioCtx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    audioCtx = new AC();
    return audioCtx;
  }
  function stopMusic() {
    musicNodes.forEach((n) => { try { n.stop(); } catch {} });
    musicNodes = [];
  }
  function playMapMusic(theme) {
    theme = theme || currentTheme || "title";
    if (!musicOn) return;
    if (musicTheme === theme && musicNodes.length) return;
    const ctx = ensureAudio();
    if (!ctx) return;
    if (ctx.state === "suspended") ctx.resume();
    stopMusic();
    musicTheme = theme;
    const notes = SONGS[theme] || SONGS.title;
    const master = ctx.createGain();
    master.gain.value = 0.09;
    master.connect(ctx.destination);
    const osc = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const bass = ctx.createOscillator();
    osc.type = "square";
    osc2.type = "triangle";
    bass.type = "sawtooth";
    osc.connect(master);
    osc2.connect(master);
    const bg = ctx.createGain(); bg.gain.value = 0.35; bass.connect(bg); bg.connect(master);
    const start = ctx.currentTime + 0.02;
    const step = 0.22;
    notes.forEach((f, i) => {
      osc.frequency.setValueAtTime(f, start + i * step);
      osc2.frequency.setValueAtTime(f * 1.5, start + i * step);
      bass.frequency.setValueAtTime(f / 2, start + i * step);
    });
    const loop = notes.length * step;
    osc.start(start); osc2.start(start); bass.start(start);
    const timer = { stop() { try { osc.stop(); osc2.stop(); bass.stop(); } catch {} clearInterval(iv); } };
    const iv = setInterval(() => {
      if (!audioCtx || !musicOn) return;
      const t = audioCtx.currentTime;
      notes.forEach((f, i) => {
        osc.frequency.setValueAtTime(f, t + i * step);
        osc2.frequency.setValueAtTime(f * 1.5, t + i * step);
        bass.frequency.setValueAtTime(f / 2, t + i * step);
      });
    }, loop * 1000);
    musicNodes = [timer];
  }
  function sfx(freq, dur) {
    const ctx = ensureAudio();
    if (!ctx || !musicOn) return;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "square";
    o.frequency.value = freq;
    g.gain.value = 0.05;
    o.connect(g); g.connect(ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (dur || 0.12));
    o.stop(ctx.currentTime + (dur || 0.12));
  }
  let tradePeer = null;
  let tradeOffer = [];

  function resize() {
    canvas.width = innerWidth;
    canvas.height = innerHeight;
    ctx.imageSmoothingEnabled = true;
  }
  addEventListener("resize", resize);
  addEventListener("orientationchange", () => setTimeout(resize, 200));
  resize();

  function chatLine(text, cls) {
    const el = document.getElementById("chat");
    const nearBot = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
    const d = document.createElement("div");
    d.className = "line " + (cls || "say");
    d.textContent = text;
    el.appendChild(d);
    while (el.children.length > 80) el.removeChild(el.firstChild);
    if (nearBot) el.scrollTop = el.scrollHeight;
  }
  function floatText(x, y, text, color) {
    const el = document.createElement("div");
    el.className = "floater";
    el.textContent = text;
    el.style.color = color;
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.getElementById("dmg-layer").appendChild(el);
    setTimeout(() => el.remove(), 800);
  }
  function worldFloat(wx, wy, text, color) {
    const p = iso(wx, wy);
    floatText(innerWidth / 2 - camX + p.x, innerHeight / 2 - camY + p.y - 30, text, color);
  }
  function spawnDrop(x, y, from) {
    const pool = [
      { chance: 0.85, gold: 8 + ((Math.random() * 28) | 0), icon: "💰", name: "Ouro" },
      { chance: 0.45, item: { id: "apple", icon: "🍎", name: "Maca", qty: 1, use: "food" } },
      { chance: 0.38, item: { id: "potion", icon: "🧪", name: "Pocao", qty: 1, use: "hp" } },
      { chance: 0.18, item: { id: "gem", icon: "💎", name: "Gema", qty: 1, use: "gold" } },
      { chance: 0.12, item: { id: "jewel", icon: "🔶", name: "Joia", qty: 1, use: "gold" } },
      { chance: 0.1, item: { id: "sword", icon: "⚔️", name: "Espada", qty: 1 } },
      { chance: 0.08, item: { id: "armor", icon: "🛡️", name: "Armadura", qty: 1 } },
      { chance: 0.08, item: { id: "shield", icon: "🔰", name: "Escudo", qty: 1 } },
      { chance: 0.06, item: { id: "helm", icon: "⛑️", name: "Elmo", qty: 1 } },
      { chance: 0.04, item: { id: "wings", icon: "🪽", name: "Asas", qty: 1 } },
    ];
    pool.forEach((d) => {
      if (Math.random() > d.chance) return;
      drops.push({
        x: x + (Math.random() - 0.5) * 0.7,
        y: y + (Math.random() - 0.5) * 0.7,
        gold: d.gold || 0,
        item: d.item || null,
        icon: d.item ? d.item.icon : d.icon,
        name: d.item ? d.item.name : (d.gold + " gp"),
        until: Date.now() + 28000,
      });
    });
    if (drops.length) chatLine("Drop no chao.", "loot");
  }
  function pickupDrops() {
    if (!hero || !drops.length) return;
    const now = Date.now();
    drops = drops.filter((d) => {
      if (now > d.until) return false;
      if (Math.abs(d.x - hero.x) + Math.abs(d.y - hero.y) > 1.05) return true;
      if (d.gold) { hero.gold += d.gold; chatLine("+" + d.gold + " gp", "loot"); }
      if (d.item) {
        if (d.item.use === "gold") { hero.gold += 40; chatLine("+40 gp (gema)", "loot"); }
        else {
          const have = hero.inventory.find((i) => i.id === d.item.id);
          if (have) have.qty += d.item.qty || 1;
          else hero.inventory.push(Object.assign({}, d.item));
          chatLine("+ " + d.item.name, "loot");
        }
      }
      worldFloat(d.x, d.y, d.icon, "#ffe566");
      applyHero(hero);
      persistLocal();
      return false;
    });
  }
  function drawDrop(d) {
    const p = iso(d.x, d.y);
    const bob = Math.sin(frame / 8 + d.x) * 3;
    ctx.fillStyle = "rgba(255,220,80,.28)";
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, 10, 5, 0, 0, 7); ctx.fill();
    ctx.font = "18px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(d.icon, p.x, p.y - 6 + bob);
  }
  function applyHero(h) {
    hero = h;
    if (h.map && (h.map === "porto" || h.map === "templo" || h.map === "praia" || h.map === "bosque")) {
      currentMap = h.map;
    }
    document.getElementById("hp-fill").style.transform = "scaleX(" + (h.hp / h.hpMax) + ")";
    document.getElementById("mp-fill").style.transform = "scaleX(" + (h.mp / h.mpMax) + ")";
    document.getElementById("xp-fill").style.transform = "scaleX(" + (h.xp / h.xpNeed) + ")";
    document.getElementById("hp-txt").textContent = Math.ceil(h.hp) + "/" + h.hpMax;
    document.getElementById("mp-txt").textContent = Math.ceil(h.mp) + "/" + h.mpMax;
    document.getElementById("meta").innerHTML =
      h.name + " · " + h.voc + " Lv." + h.level + " · " + (mapName || h.map || "") + "<br>" +
      h.gold + " gp · XP " + h.xp + "/" + h.xpNeed + " · ML " + Math.floor(h.skills.magic);
    drawPortrait();
    renderInv();
  }
  function drawPortrait() {
    const pc = document.getElementById("portrait");
    const c = pc.getContext("2d");
    c.imageSmoothingEnabled = true;
    c.fillStyle = "#1a1208"; c.fillRect(0, 0, 58, 58);
    const sheet = makeCharSheet(hero.voc, hero.race, hero.sex);
    c.drawImage(sheet, 0, 0, 32, 48, 7, 4, 44, 52);
  }
  function renderInv() {
    if (!hero) return;
    if (!hero.inventory) hero.inventory = [];
    if (!hero.eq) hero.eq = {};
    const box = document.getElementById("slots");
    box.innerHTML = "";
    for (let i = 0; i < 15; i++) {
      const it = hero.inventory[i];
      const d = document.createElement("div");
      d.className = "slot";
      if (it) {
        d.textContent = it.icon;
        d.title = it.name;
        if (it.qty > 1) {
          const q = document.createElement("span"); q.className = "qty"; q.textContent = it.qty; d.appendChild(q);
        }
        const gear = ["sword", "shield", "armor", "helm", "wings"].includes(it.id);
        if (hero.eq && hero.eq[it.id]) d.style.outline = "2px solid #f0d070";
        const useIt = (e) => {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          if (d.dataset.busy) return;
          d.dataset.busy = "1";
          setTimeout(() => { delete d.dataset.busy; }, 300);
          if (tradePeer) {
            tradeOffer.push({ id: it.id, icon: it.icon, name: it.name, qty: 1, use: it.use });
            paintTradeMine();
            return;
          }
          handleLocal({ type: "use", id: it.id });
        };
        d.addEventListener("pointerup", useIt);
        if (gear) {
          const e = document.createElement("span");
          e.className = "qty";
          e.textContent = (hero.eq && hero.eq[it.id]) ? "ON" : "EQ";
          d.appendChild(e);
        }
      }
      box.appendChild(d);
    }
    document.getElementById("gold-line").textContent =
      "Ouro: " + hero.gold + " · " +
      (hero.eq && hero.eq.sword ? "espada " : "") +
      (hero.eq && hero.eq.armor ? "armadura " : "") +
      (hero.eq && hero.eq.shield ? "escudo " : "") +
      (hero.eq && hero.eq.wings ? "asas " : "");
  }
  function paintTradeMine() {
    const box = document.getElementById("trade-my");
    box.innerHTML = "";
    tradeOffer.forEach((it) => {
      const d = document.createElement("div");
      d.className = "slot"; d.textContent = it.icon;
      box.appendChild(d);
    });
  }

  /* ---- net ---- */
  const SERVER = "forgotten-lands.onrender.com";
  function wsUrl() {
    let host = SERVER;
    try {
      const v = document.getElementById("acc-host").value.trim();
      if (v && /\./.test(v) && !/xxxx|aparelho/i.test(v)) host = v;
    } catch (e) {}
    host = host.replace(/^https?:\/\//, "").replace(/^wss?:\/\//, "").replace(/\/.*$/, "");
    return "wss://" + host;
  }
  let offline = false;
  const LOCAL_KEY = "fl_accounts_v1";
  function loadAccs() {
    try { return JSON.parse(localStorage.getItem(LOCAL_KEY) || "{}"); } catch { return {}; }
  }
  function saveAccs(a) { localStorage.setItem(LOCAL_KEY, JSON.stringify(a)); }

  let portalLock = 0;
  const LOCAL_WORLDS = [
    { id: "porto", name: "Porto Inicial", theme: "grass", min: 1,
      portals: [
        { x: 18, y: 15, to: "templo", tx: 18, ty: 20, need: 1 },
        { x: 10, y: 18, to: "praia", tx: 20, ty: 18, need: 1 },
        { x: 26, y: 18, to: "bosque", tx: 12, ty: 18, need: 1 },
      ],
      mobs: [] },
    { id: "praia", name: "Praia do Sul", theme: "sand", min: 1,
      portals: [{ x: 20, y: 18, to: "porto", tx: 12, ty: 18, need: 1 }],
      mobs: [["crab", 10, 10], ["crab", 26, 12], ["seagull", 14, 26], ["crab", 24, 24], ["seagull", 8, 22]] },
    { id: "bosque", name: "Bosque Claro", theme: "forest", min: 1,
      portals: [
        { x: 12, y: 18, to: "porto", tx: 24, ty: 18, need: 1 },
        { x: 26, y: 18, to: "planicie", tx: 12, ty: 18, need: 2 },
      ],
      mobs: [["boar", 14, 12], ["wasp", 22, 10], ["boar", 16, 24], ["wasp", 24, 22]] },
    { id: "templo", name: "Cidade do Templo", theme: "city", min: 1,
      portals: [
        { x: 18, y: 22, to: "porto", tx: 18, ty: 18, need: 1 },
        { x: 26, y: 18, to: "planicie", tx: 12, ty: 18, need: 2 },
      ],
      mobs: [] },
    { id: "planicie", name: "Planicie Verde", theme: "grass", min: 5,
      portals: [
        { x: 10, y: 18, to: "templo", tx: 24, ty: 18, need: 1 },
        { x: 26, y: 18, to: "floresta", tx: 12, ty: 18, need: 8 },
      ],
      mobs: [["snake", 16, 10], ["snake", 22, 12], ["spider", 20, 24], ["wolf", 14, 22], ["snake", 26, 10], ["spider", 8, 14]] },
    { id: "floresta", name: "Floresta Sombria", theme: "forest", min: 8,
      portals: [{ x: 10, y: 18, to: "planicie", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "pantano", tx: 10, ty: 18, need: 12 }],
      mobs: [["wolf", 14, 12], ["wolf", 22, 10], ["orc", 12, 26]] },
    { id: "pantano", name: "Pantano Podre", theme: "swamp", min: 12,
      portals: [{ x: 10, y: 18, to: "floresta", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "deserto", tx: 10, ty: 18, need: 16 }],
      mobs: [["slime", 14, 14], ["slime", 22, 12], ["snake", 20, 24]] },
    { id: "deserto", name: "Deserto de Areia", theme: "sand", min: 16,
      portals: [{ x: 10, y: 18, to: "pantano", tx: 26, ty: 18, need: 1 }, { x: 26, y: 18, to: "caverna", tx: 18, ty: 22, need: 20 }],
      mobs: [["scarab", 14, 12], ["scarab", 22, 10], ["orc", 12, 26]] },
    { id: "caverna", name: "Caverna Umida", theme: "cave", min: 20,
      portals: [{ x: 18, y: 22, to: "deserto", tx: 26, ty: 18, need: 1 }, { x: 18, y: 10, to: "forte", tx: 18, ty: 22, need: 25 }],
      mobs: [["bat", 12, 12], ["bat", 24, 12], ["orc", 22, 24]] },
    { id: "forte", name: "Forte dos Orcs", theme: "fort", min: 25,
      portals: [{ x: 18, y: 22, to: "caverna", tx: 18, ty: 10, need: 1 }, { x: 18, y: 10, to: "vulcao", tx: 18, ty: 22, need: 30 }],
      mobs: [["orc", 12, 14], ["berserk", 22, 22], ["orc", 24, 14]] },
    { id: "vulcao", name: "Montanha de Fogo", theme: "lava", min: 30,
      portals: [{ x: 18, y: 22, to: "forte", tx: 18, ty: 10, need: 1 }, { x: 18, y: 10, to: "covil", tx: 18, ty: 22, need: 40 }],
      mobs: [["fire", 12, 14], ["fire", 24, 12], ["dragon", 22, 16]] },
    { id: "covil", name: "Covil do Dragao", theme: "lair", min: 40,
      portals: [{ x: 18, y: 22, to: "vulcao", tx: 18, ty: 10, need: 1 }],
      mobs: [["dragon", 14, 14], ["dragon", 22, 12], ["fire", 12, 24]] },
  ];
  const LOCAL_MOBS = {
    rat: { hp: 22, atk: 5, xp: 22, gold: 3, name: "Rato" },
    crab: { hp: 28, atk: 6, xp: 26, gold: 4, name: "Caranguejo" },
    seagull: { hp: 18, atk: 4, xp: 16, gold: 2, name: "Gaivota" },
    boar: { hp: 55, atk: 9, xp: 48, gold: 7, name: "Javali" },
    wasp: { hp: 30, atk: 8, xp: 28, gold: 4, name: "Vespa" },
    spider: { hp: 36, atk: 7, xp: 32, gold: 4, name: "Aranha" },
    snake: { hp: 48, atk: 9, xp: 45, gold: 6, name: "Cobra" },
    wolf: { hp: 70, atk: 12, xp: 70, gold: 9, name: "Lobo" },
    slime: { hp: 90, atk: 14, xp: 95, gold: 12, name: "Lodo" },
    scarab: { hp: 120, atk: 16, xp: 130, gold: 16, name: "Escaravelho" },
    bat: { hp: 140, atk: 18, xp: 160, gold: 18, name: "Morcego Gigante" },
    orc: { hp: 160, atk: 20, xp: 190, gold: 22, name: "Orc" },
    berserk: { hp: 220, atk: 26, xp: 280, gold: 32, name: "Orc Berseker" },
    fire: { hp: 260, atk: 30, xp: 360, gold: 40, name: "Elemental de Fogo" },
    dragon: { hp: 420, atk: 38, xp: 650, gold: 80, name: "Dragao" },
  };
  const VOC_OFF = {
    knight: { hp: 220, mp: 40, atk: 24, def: 14, ml: 2 },
    paladin: { hp: 170, mp: 80, atk: 20, def: 10, ml: 6 },
    sorcerer: { hp: 125, mp: 160, atk: 12, def: 5, ml: 14 },
    druid: { hp: 135, mp: 150, atk: 12, def: 6, ml: 13 },
  };

  function makeLocalHero(name, voc) {
    const v = VOC_OFF[voc] || VOC_OFF.knight;
    return {
      name, voc, race: chosenRace, sex: chosenSex, map: "porto", x: 18, y: 21, gold: 50, level: 1, xp: 0, xpNeed: 66,
      hp: v.hp, hpMax: v.hp, mp: v.mp, mpMax: v.mp, atk: v.atk, def: v.def, ml: v.ml,
      cap: 350, soul: 100, food: 20,
      skills: { sword: 20, dist: 18, shielding: 18, magic: v.ml },
      inventory: [
        { id: "sword", icon: "🗡️", name: "Espada pequena", qty: 1 },
        { id: "shield", icon: "🛡️", name: "Escudo de madeira", qty: 1 },
        { id: "armor", icon: "🥋", name: "Armadura de couro", qty: 1 },
        { id: "helm", icon: "⛑️", name: "Elmo raso", qty: 1 },
        { id: "wings", icon: "🪽", name: "Asinhas", qty: 1 },
        { id: "apple", icon: "🍎", name: "Maca", qty: 10, use: "food" },
        { id: "hp", icon: "🧪", name: "Pocao de vida", qty: 5, use: "hp" },
        { id: "mp", icon: "📘", name: "Pocao de mana", qty: 3, use: "mp" },
      ],
      quest: { rats: 0, kills: 0, done: false, q2: false, q3: false, q4: false, fuse: 0 },
      eq: {},
    };
  }

  function spawnLocalMap(id) {
    const w = LOCAL_WORLDS.find((x) => x.id === id) || LOCAL_WORLDS[0];
    currentMap = w.id; currentTheme = w.theme; mapName = w.name;
    portals = w.portals;
    drops = [];
    genMap(w.theme);
    creatures = w.mobs.map((m, i) => {
      const st = LOCAL_MOBS[m[0]] || LOCAL_MOBS.rat;
      return {
        id: "l" + i + m[0], kind: m[0], name: st.name, map: w.id,
        x: m[1], y: m[2], hp: st.hp, hpMax: st.hp, atk: st.atk, xp: st.xp, gold: st.gold, alive: true, aggro: 0, lastHit: 0,
      };
    });
    others = (others || []).filter((p) => hero && p.name !== hero.name);
  }

  function goToMap(id, tx, ty) {
    const w = LOCAL_WORLDS.find((x) => x.id === id);
    if (!w) { chatLine("Mapa nao existe.", "sys"); return; }
    if (hero && hero.level < (w.min || 1) && w.min > 1) {
      chatLine("Precisa de level " + w.min + " para " + w.name + ".", "sys");
      return;
    }
    portalLock = Date.now() + 2500;
    hero.map = id;
    let lx = tx != null ? tx : 16;
    let ly = ty != null ? ty : 16;
    spawnLocalMap(id);
    if (cellBlocked(lx, ly)) { lx = 16; ly = 16; }
    if (cellBlocked(lx, ly)) { lx = 18; ly = 21; }
    hero.x = lx; hero.y = ly;
    visX = lx; visY = ly;
    if (id === "porto" || id === "templo") { hero.hp = hero.hpMax; creatures = []; }
    applyHero(hero);
    chatLine(t("arrived") + mapName + ".", "sys");
    persistLocal();
    playMapMusic(w.theme);
  }

  function persistLocal() {
    if (!hero) return;
    hero.map = currentMap || hero.map || "porto";
    hero.theme = currentTheme;
    const accs = loadAccs();
    const user = (document.getElementById("acc-user").value || hero.name || "").trim().toLowerCase();
    if (!user) return;
    if (!accs[user]) accs[user] = { pass: document.getElementById("acc-pass").value };
    accs[user].hero = hero;
    accs[user].pass = accs[user].pass || document.getElementById("acc-pass").value;
    saveAccs(accs);
    try { localStorage.setItem("fl_last_user", user); } catch (e) {}
  }
  document.addEventListener("visibilitychange", () => { if (document.hidden) persistLocal(); });
  window.addEventListener("pagehide", persistLocal);
  window.addEventListener("beforeunload", persistLocal);
  setInterval(() => { if (hero) persistLocal(); }, 8000);

  function localGainXp(n) {
    hero.xp += n;
    while (hero.xp >= hero.xpNeed) {
      hero.xp -= hero.xpNeed;
      hero.level++;
      if (hero.level < 10) hero.xpNeed = Math.floor(hero.xpNeed * 1.07) + 8;
      else if (hero.level < 20) hero.xpNeed = Math.floor(hero.xpNeed * 1.22) + 24;
      else hero.xpNeed = Math.floor(hero.xpNeed * 1.38) + 50;
      hero.hpMax += 14; hero.mpMax += 8; hero.atk += 2; hero.def += 1; hero.ml += 1;
      hero.hp = hero.hpMax; hero.mp = hero.mpMax;
      chatLine(t("levelup") + hero.level + "!", "sys");
    }
  }

  function startOffline(kind) {
    offline = true;
    connected = true;
    const user = document.getElementById("acc-user").value.trim().toLowerCase();
    const pass = document.getElementById("acc-pass").value;
    const name = (document.getElementById("acc-name").value.trim() || user || "Heroi").slice(0, 16);
    const accs = loadAccs();
    if (!user || user.length < 3) {
      document.getElementById("splash-err").textContent = "Conta: minimo 3 letras.";
      return;
    }
    if (kind === "register") {
      if (accs[user]) { document.getElementById("splash-err").textContent = "Essa conta ja existe neste celular."; return; }
      accs[user] = { pass, hero: makeLocalHero(name, chosenVoc) };
      saveAccs(accs);
    } else {
      if (!accs[user]) {
        accs[user] = { pass, hero: makeLocalHero(name, chosenVoc) };
        saveAccs(accs);
      } else if (accs[user].pass && pass && accs[user].pass !== pass) {
        document.getElementById("splash-err").textContent = "Senha errada.";
        return;
      }
    }
    hero = accs[user].hero;
    if (!hero.map) hero.map = "porto";
    spawnLocalMap(hero.map);
    applyHero(hero);
    document.getElementById("splash").style.display = "none";
    document.body.classList.add("ingame");
    document.getElementById("online").textContent = mapName + " · modo local (sem servidor)";
    playMapMusic(currentTheme);
    setTimeout(giveDailyBonus, 600);
  }

  function send(obj) {
    handleLocal(obj);
    if (!offline && ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify(obj)); } catch (e) {}
    }
  }

  function handleLocal(msg) {
    if (!hero) return;
    if (msg.type === "move") {
      if (portalLock > Date.now()) return;
      const gx = Math.round(hero.x), gy = Math.round(hero.y);
      const p = portals.find((o) => o.x === gx && o.y === gy);
      if (p) {
        if (hero.level < p.need) { chatLine("Precisa de level " + p.need + " para este portal.", "sys"); return; }
        if (offline) goToMap(p.to, p.tx, p.ty);
        else send({ type: "warp", to: p.to, tx: p.tx, ty: p.ty });
      }
    }
    if (msg.type === "atk") {
      if (inSafeZone()) return;
      const t = creatures.find((c) => c.id === msg.target && c.alive);
      if (!t) return;
      const bonus = hero.eq && hero.eq.sword ? 8 : 0;
      const dmg = Math.max(1, hero.atk + bonus + ((Math.random() * 8) | 0) - 2);
      t.hp -= dmg;
      worldFloat(t.x, t.y, "-" + dmg, "#ffee66");
      if (t.hp <= 0) {
        t.alive = false;
        localGainXp(t.xp);
        hero.gold += t.gold;
        if (t.kind === "rat") hero.quest.rats++;
        chatLine(t("killed") + t.name + " (+" + t.xp + " xp)", "loot");
        hero.quest = hero.quest || { rats: 0, kills: 0, done: false, q2: false, q3: false, q4: false, fuse: 0 };
        hero.quest.rats++;
        hero.quest.kills = (hero.quest.kills || 0) + 1;
        if (!hero.quest.done && hero.quest.kills >= 5) {
          hero.quest.done = true;
          hero.gold += 100;
          localGainXp(200);
          chatLine(t("q1ok"), "loot");
        }
        if (!hero.quest.q2 && hero.quest.kills >= 15) {
          hero.quest.q2 = true;
          hero.gold += 250;
          localGainXp(400);
          chatLine("Missao 2: 15 monstros. +250 gp", "loot");
        }
        if (!hero.quest.q4 && hero.level >= 5) {
          hero.quest.q4 = true;
          hero.gold += 200;
          chatLine("Missao level 5. +200 gp", "loot");
        }
        applyHero(hero);
        spawnDrop(t.x, t.y, t.name);
        persistLocal();
        setTimeout(() => { t.alive = true; t.hp = t.hpMax; }, 8000);
      }
    }
    if (msg.type === "spell") {
      const book = {
        exura: () => { if (hero.mp < 20) return chatLine("Pouca mana.", "sys"); hero.mp -= 20; hero.hp = Math.min(hero.hpMax, hero.hp + 20 + hero.ml * 3); },
        exori: () => { if (hero.voc !== "knight" || hero.mp < 28) return; hero.mp -= 28; creatures.forEach((c) => { if (c.alive && Math.abs(c.x - hero.x) + Math.abs(c.y - hero.y) <= 1) { c.hp -= 22 + hero.atk; if (c.hp <= 0) { c.alive = false; localGainXp(c.xp); } } }); },
        "exori vis": () => { if (hero.voc !== "sorcerer" || hero.mp < 36) return; hero.mp -= 36; const c = creatures.find((m) => m.alive && Math.abs(m.x - hero.x) + Math.abs(m.y - hero.y) <= 3); if (c) { c.hp -= 30 + hero.ml * 2; if (c.hp <= 0) { c.alive = false; localGainXp(c.xp); } } },
        "exura gran": () => { if (hero.mp < 40) return; hero.mp -= 40; hero.hp = Math.min(hero.hpMax, hero.hp + 45 + hero.ml * 4); },
        "utevo lux": () => { if (hero.mp < 16) return; hero.mp -= 16; },
      };
      if (book[msg.name]) book[msg.name]();
      applyHero(hero);
    }
    if (msg.type === "use") {
      if (!hero.inventory) return;
      const it = hero.inventory.find((i) => i.id === msg.id);
      if (!it) return;
      if (!hero.eq) hero.eq = {};
      if (["sword", "shield", "armor", "helm", "wings"].includes(it.id)) {
        if (hero.eq[it.id]) {
          delete hero.eq[it.id];
          chatLine(t("unequipped") + it.name + ".", "sys");
        } else {
          hero.eq[it.id] = true;
          chatLine(t("equipped") + it.name + ".", "sys");
          if (it.id === "wings") { flying = true; const fb = document.getElementById("btn-fly"); if (fb) fb.classList.add("on"); }
        }
        applyHero(hero); persistLocal();
        return;
      }
      if (it.use === "food") { it.qty--; hero.food = Math.min(40, hero.food + 12); }
      if (it.use === "hp") { it.qty--; hero.hp = Math.min(hero.hpMax, hero.hp + 70); }
      if (it.use === "mp") { it.qty--; hero.mp = Math.min(hero.mpMax, hero.mp + 55); }
      if (it.use === "gold") { it.qty--; hero.gold += it.id === "bless" ? 120 : 40; }
      if (it.qty <= 0) hero.inventory = hero.inventory.filter((i) => i !== it);
      applyHero(hero); persistLocal();
    }
    if (msg.type === "npc") {
      if (msg.act === "apple" && hero.gold >= 8) { hero.gold -= 8; const f = hero.inventory.find((i) => i.id === "apple"); if (f) f.qty += 3; else hero.inventory.push({ id: "apple", icon: "🍎", name: "Maca", qty: 3, use: "food" }); }
      if (msg.act === "hp" && hero.gold >= 25) { hero.gold -= 25; const f = hero.inventory.find((i) => i.id === "hp"); if (f) f.qty++; else hero.inventory.push({ id: "hp", icon: "🧪", name: "Pocao de vida", qty: 1, use: "hp" }); }
      if (msg.act === "quest") {
        if (hero.quest.rats >= 5 && !hero.quest.done) { hero.quest.done = true; hero.gold += 80; localGainXp(200); chatLine("Missao cumprida!", "sys"); }
        else chatLine("Mate 5 ratos. " + hero.quest.rats + "/5", "sys");
      }
      applyHero(hero); persistLocal();
    }
    if (msg.type === "chat") chatLine(hero.name + ": " + msg.text, "say");
  }

  function connect(kind) {
    const err = document.getElementById("splash-err");
    const hostField = document.getElementById("acc-host").value.trim() || SERVER;
    document.getElementById("acc-host").value = hostField;
    localStorage.setItem("fl_host", hostField);
    err.textContent = "conectando em " + hostField + " ...";
    let settled = false;
    const failTimer = setTimeout(() => {
      if (!settled) {
        settled = true;
        err.textContent = "Servidor acordando... espera 1 min e toca Entrar de novo.";
      }
    }, 4000);
    try { if (ws) ws.close(); } catch {}
    try {
      ws = new WebSocket(wsUrl());
    } catch (e) {
      clearTimeout(failTimer);
      err.textContent = "URL do servidor invalida.";
      return;
    }
    ws.onopen = () => {
      settled = true;
      clearTimeout(failTimer);
      connected = true;
      offline = false;
      const payload = {
        type: kind,
        user: document.getElementById("acc-user").value.trim(),
        pass: document.getElementById("acc-pass").value,
        name: document.getElementById("acc-name").value.trim() || document.getElementById("acc-user").value.trim(),
        voc: chosenVoc,
      };
      ws.send(JSON.stringify(payload));
    };
    ws.onerror = () => {
      if (!settled) { settled = true; clearTimeout(failTimer); err.textContent = "Erro no WebSocket. Usa o link https do Render."; }
    };
    ws.onclose = () => {
      connected = false;
      persistLocal();
      if (!offline && hero) {
        chatLine("Caiu do servidor. Reconectando...", "sys");
        setTimeout(() => { if (hero && (!ws || ws.readyState !== 1)) connect("login"); }, 4000);
      }
    };
    ws.onmessage = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.type === "err") err.textContent = m.text;
      if (m.type === "you") {
        const incoming = m.hero || {};
        const mapChanged = !hero || (incoming.map && incoming.map !== currentMap);
        if (!hero) hero = incoming;
        else {
          if (incoming.hp != null) hero.hp = incoming.hp;
          if (incoming.mp != null) hero.mp = incoming.mp;
          if (incoming.map) hero.map = incoming.map;
          if (incoming.gold != null) hero.gold = incoming.gold;
          if (mapChanged && incoming.x != null) { hero.x = incoming.x; hero.y = incoming.y; visX = incoming.x; visY = incoming.y; }
        }
        if (!hero.inventory || !hero.inventory.length) hero = Object.assign(makeLocalHero(hero.name || "Heroi", hero.voc || "knight"), hero);
        if (!hero.eq) hero.eq = {};
        applyHero(hero);
        if (mapChanged) spawnLocalMap(hero.map || "porto");
        document.getElementById("splash").style.display = "none";
        document.body.classList.add("ingame");
        if (m.online) document.getElementById("online").textContent = "online: " + m.online.join(", ");
      }
      if (m.type === "world") {
        const incoming = m.players || [];
        const keep = {};
        others.forEach((p) => { keep[p.name] = p; });
        others = incoming.map((p) => {
          const old = keep[p.name] || {};
          const n = Object.assign({}, old, p);
          if (n.vx == null) { n.vx = n.x; n.vy = n.y; }
          return n;
        });
        document.getElementById("online").textContent =
          (mapName ? mapName + " · " : "") + "online: " + others.map((p) => p.name).join(", ");
      }
      if (m.type === "chat") chatLine((m.from ? m.from + ": " : "") + m.text, m.ch || "say");
      if (m.type === "pvpHit") {
        if (inSafeZone()) return;
        hero.hp = Math.max(0, (m.hp != null ? m.hp : hero.hp - (m.dmg || 4)));
        worldFloat(hero.x, hero.y, "-" + (m.dmg || 0), "#ff66ee");
        chatLine((m.from || "?") + " PvP " + (m.dmg || ""), "dmg");
        applyHero(hero);
      }
      if (m.type === "float") {
        if (inSafeZone()) return;
        if (m.self) floatText(innerWidth / 2, innerHeight / 2 - 40, m.text, m.color);
        else floatText(innerWidth / 2, innerHeight / 2 - 80, m.text, m.color);
      }
      if (m.type === "tradeOpen") {
        tradePeer = m.peer; tradeOffer = [];
        document.getElementById("trade-box").style.display = "block";
        document.getElementById("trade-peer").textContent = m.peer;
      }
      if (m.type === "tradePeer") {
        const box = document.getElementById("trade-his");
        box.innerHTML = "";
        (m.items || []).forEach((it) => {
          const d = document.createElement("div"); d.className = "slot"; d.textContent = it.icon + (it.qty > 1 ? it.qty : "");
          box.appendChild(d);
        });
        chatLine("Oferta: " + (m.gold || 0) + " gp", "loot");
      }
      if (m.type === "tradeDone" || m.type === "tradeClose") {
        document.getElementById("trade-box").style.display = "none";
        tradePeer = null; tradeOffer = [];
      }
    };
  }

  function paintPick() {
    const el = document.getElementById("pick-now");
    if (el) el.textContent = t("chosen") + ": " + chosenVoc + " · " + chosenRace + " · " + (chosenSex === "f" ? t("woman") : t("man"));
  }
  function bindPick(sel, fn) {
    document.querySelectorAll(sel).forEach((b) => {
      const go = (e) => { e.preventDefault(); e.stopPropagation(); fn(b); paintPick(); };
      b.addEventListener("pointerdown", go);
      b.addEventListener("click", go);
    });
  }
  bindPick("#vocs .voc", (b) => {
    chosenVoc = b.dataset.voc;
    document.querySelectorAll("#vocs .voc").forEach((x) => x.classList.toggle("on", x === b));
  });
  bindPick("#races .voc", (b) => {
    chosenRace = b.dataset.race;
    document.querySelectorAll("#races .voc").forEach((x) => x.classList.toggle("on", x === b));
    if (chosenRace === "elfa") {
      chosenSex = "f";
      document.querySelectorAll("#sexes .voc").forEach((x) => x.classList.toggle("on", x.dataset.sex === "f"));
    }
  });
  bindPick("#sexes .voc", (b) => {
    chosenSex = b.dataset.sex;
    document.querySelectorAll("#sexes .voc").forEach((x) => x.classList.toggle("on", x === b));
  });
  paintPick();
  function renderQuests() {
    if (!hero) return;
    const q = hero.quest || {};
    const list = document.getElementById("quest-list");
    const row = (ok, txt) => "<p>" + (ok ? "✔ " : "○ ") + txt + "</p>";
    list.innerHTML =
      row(q.done, "1) Mate 5 monstros  (" + Math.min(q.kills || 0, 5) + "/5)") +
      row(q.q2, "2) Mate 15 monstros  (" + Math.min(q.kills || 0, 15) + "/15)") +
      row(q.q3, "3) Fundir 3 joias  (" + (q.fuse || 0) + ")") +
      row(q.q4 || (hero.level >= 5), "4) Chegar no level 5  (lv " + hero.level + ")");
  }
  function doFuse() {
    if (!hero || !hero.inventory) return;
    const gems = hero.inventory.filter((i) => i.id === "gem" || i.id === "jewel");
    let n = gems.reduce((s, i) => s + (i.qty || 1), 0);
    if (n < 3) { chatLine("Precisa de 3 joias/gemas.", "sys"); return; }
    let left = 3;
    gems.forEach((i) => {
      if (left <= 0) return;
      const take = Math.min(i.qty || 1, left);
      i.qty -= take; left -= take;
    });
    hero.inventory = hero.inventory.filter((i) => !i.qty || i.qty > 0);
    hero.inventory.push({ id: "bless", icon: "✨", name: "Joia fundida", qty: 1, use: "gold" });
    hero.gold += 80;
    localGainXp(150);
    hero.quest = hero.quest || {};
    hero.quest.fuse = (hero.quest.fuse || 0) + 1;
    if (!hero.quest.q3) { hero.quest.q3 = true; hero.gold += 150; chatLine("Missao fusao completa.", "loot"); }
    chatLine("Fusao ok: joia brilhante +80 gp.", "loot");
    applyHero(hero); persistLocal(); renderQuests();
  }
  const qBtn = document.getElementById("btn-quest");
  if (qBtn) qBtn.onclick = () => {
    const box = document.getElementById("quest-box");
    renderQuests();
    box.style.display = box.style.display === "block" ? "none" : "block";
  };
  document.getElementById("quest-x").onclick = () => { document.getElementById("quest-box").style.display = "none"; };
  document.getElementById("btn-fuse").onclick = doFuse;
  document.getElementById("btn-map").onclick = () => {
    const box = document.getElementById("map-box");
    const opts = document.getElementById("map-opts");
    opts.innerHTML = "";
    LOCAL_WORLDS.forEach((w) => {
      const b = document.createElement("button");
      const lock = hero && hero.level < w.min && w.min > 1;
      b.textContent = w.name + (lock ? "  (lv " + w.min + ")" : "  — aberto");
      b.onclick = () => {
        if (lock) { chatLine("Level " + w.min + " pra esse mapa.", "sys"); return; }
        box.style.display = "none";
        if (offline) goToMap(w.id, 16, 16);
        else send({ type: "warp", to: w.id, tx: 16, ty: 16 });
      };
      opts.appendChild(b);
    });
    box.style.display = "block";
  };
  document.getElementById("map-x").onclick = () => { document.getElementById("map-box").style.display = "none"; };
  const flyBtn = document.getElementById("btn-fly");
  if (flyBtn) flyBtn.onclick = () => {
    flying = !flying;
    flyBtn.classList.toggle("on", flying);
    chatLine(flying ? t("wingsOn") : t("wingsOff"), "sys");
  };
  document.getElementById("btn-register").onclick = () => { ensureAudio(); connect("register"); };
  document.getElementById("btn-start").onclick = () => { ensureAudio(); connect("login"); };
  const muteBtn = document.getElementById("btn-mute");
  if (muteBtn) muteBtn.onclick = () => {
    musicOn = !musicOn;
    muteBtn.textContent = musicOn ? "som" : "mudo";
    if (!musicOn) stopMusic();
    else playMapMusic(currentTheme || "grass");
  };
  const setBox = document.getElementById("set-box");
  document.getElementById("btn-set").onclick = () => {
    setBox.style.display = setBox.style.display === "block" ? "none" : "block";
    applyLang();
    document.getElementById("set-sfx").checked = musicOn;
    document.getElementById("set-names").checked = showNames;
    document.getElementById("set-pvp").checked = pvpOn;
  };
  document.getElementById("set-x").onclick = () => { setBox.style.display = "none"; };
  document.querySelectorAll("#set-langs .lang").forEach((b) => {
    b.onclick = () => { lang = b.dataset.lang; applyLang(); };
  });
  document.getElementById("set-sfx").onchange = (e) => {
    musicOn = e.target.checked;
    if (!musicOn) stopMusic();
    else { ensureAudio(); playMapMusic(currentTheme || "title"); }
  };
  document.getElementById("set-names").onchange = (e) => { showNames = e.target.checked; };
  document.getElementById("set-pvp").onchange = (e) => { pvpOn = e.target.checked; };

  /* ---- input ---- */
  const joyEl = document.getElementById("joystick");
  const stickEl = document.getElementById("stick");
  function joyFrom(e, rect) {
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const x = e.clientX - cx, y = e.clientY - cy;
    const max = rect.width * 0.32, len = Math.hypot(x, y) || 1, cl = Math.min(len, max);
    stickEl.style.left = 29 + (x / len) * cl + "px";
    stickEl.style.top = 29 + (y / len) * cl + "px";
    joy.dx = ((x / len) * cl) / max;
    joy.dy = ((y / len) * cl) / max;
  }
  joyEl.addEventListener("pointerdown", (e) => {
    joy.on = true; joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId);
    joyFrom(e, joyEl.getBoundingClientRect());
  });
  joyEl.addEventListener("pointermove", (e) => {
    if (joy.on && e.pointerId === joy.id) joyFrom(e, joyEl.getBoundingClientRect());
  });
  function endJoy() { joy.on = false; joy.dx = joy.dy = 0; stickEl.style.left = "29px"; stickEl.style.top = "29px"; }
  joyEl.addEventListener("pointerup", endJoy);
  joyEl.addEventListener("pointercancel", endJoy);

  addEventListener("keydown", (e) => {
    keys[e.code] = true;
    if (e.code === "Space") { e.preventDefault(); doAtk(); }
    if (e.code === "KeyI") toggle("#inventory");
    if (e.code === "Digit1") send({ type: "spell", name: "exura" });
    if (e.code === "Digit2") send({ type: "spell", name: "exori" });
    if (e.code === "Digit3") send({ type: "spell", name: "exori vis" });
    if (e.code === "Digit4") send({ type: "spell", name: "exura gran" });
  });
  addEventListener("keyup", (e) => { keys[e.code] = false; });

  document.getElementById("btn-atk").onclick = doAtk;
  document.getElementById("btn-inv").onclick = () => toggle("#inventory");
  document.getElementById("inv-close").onclick = () => document.getElementById("inventory").style.display = "none";
  document.querySelectorAll(".hk").forEach((b) => {
    b.onclick = () => {
      if (b.dataset.spell === "food") {
        const food = hero && hero.inventory.find((i) => i.use === "food");
        if (food) send({ type: "use", id: food.id });
      } else send({ type: "spell", name: b.dataset.spell });
    };
  });
  document.getElementById("chat-form").onsubmit = (e) => {
    e.preventDefault();
    const inp = document.getElementById("chat-in");
    if (inp.value.trim()) send({ type: "chat", text: inp.value.trim() });
    inp.value = "";
  };
  const npcBtn = document.getElementById("btn-npc");
  if (npcBtn) npcBtn.onclick = () => {};
  function closeNpc() { document.getElementById("npc-box").style.display = "none"; }
  document.getElementById("npc-x").onclick = closeNpc;
  document.getElementById("btn-trade").onclick = () => {
    const near = others.find((p) => hero && p.name !== hero.name && Math.abs(p.x - hero.x) + Math.abs(p.y - hero.y) <= 2);
    if (!near) return chatLine("Chegue perto de outro jogador para negociar.", "sys");
    send({ type: "tradeAsk", to: near.name });
  };
  document.getElementById("trade-yes").onclick = () => {
    send({ type: "tradeOffer", gold: Number(document.getElementById("trade-gold").value) || 0, items: tradeOffer });
    send({ type: "tradeYes" });
  };
  document.getElementById("trade-x").onclick = () => send({ type: "tradeNo" });
  document.getElementById("trade-gold").onchange = () => {
    send({ type: "tradeOffer", gold: Number(document.getElementById("trade-gold").value) || 0, items: tradeOffer });
  };

  function toggle(sel) {
    const el = document.querySelector(sel);
    el.style.display = el.style.display === "block" ? "none" : "block";
    if (sel === "#inventory") renderInv();
  }
  function doAtk() {
    if (!hero) return;
    atkUntil = performance.now() + 280;
    sfx(420, 0.07);
    if (inSafeZone()) return;
    if (pvpOn) {
      const foe = others.filter((p) => p.name !== hero.name && Math.abs(p.x - hero.x) + Math.abs(p.y - hero.y) <= 1.8)
        .sort((a, b) => (Math.abs(a.x - hero.x) + Math.abs(a.y - hero.y)) - (Math.abs(b.x - hero.x) + Math.abs(b.y - hero.y)))[0];
      if (foe) {
        send({ type: "pvp", to: foe.name });
        worldFloat(foe.x, foe.y, "PvP", "#ff66ee");
        chatLine("PvP: " + foe.name, "dmg");
        return;
      }
    }
    const t = creatures.filter((c) => c.alive && Math.abs(c.x - hero.x) + Math.abs(c.y - hero.y) <= 3.2)
      .sort((a, b) => (Math.abs(a.x - hero.x) + Math.abs(a.y - hero.y)) - (Math.abs(b.x - hero.x) + Math.abs(b.y - hero.y)))[0];
    if (t) send({ type: "atk", target: t.id });
  }

  /* ---- loop ---- */
  const mini = document.getElementById("minimap");
  const mctx = mini.getContext("2d");
  mini.width = 110; mini.height = 110;

  function drawMini() {
    const s = 110 / MAP;
    for (let y = 0; y < MAP; y++) for (let x = 0; x < MAP; x++) {
      const t = map[y][x];
      mctx.fillStyle = t === 3 ? "#1a4a78" : t === 2 ? "#c2a86a" : t === 4 ? "#888" : t === 5 ? "#7a4a22" : t === 6 ? "#d2c08a" : "#2f6a28";
      mctx.fillRect(x * s, y * s, s + 0.4, s + 0.4);
    }
    if (hero) { mctx.fillStyle = "#ffee55"; mctx.fillRect(hero.x * s - 1, hero.y * s - 1, 4, 4); }
    mctx.fillStyle = "#e74c3c";
    creatures.forEach((c) => { if (c.alive) mctx.fillRect(c.x * s, c.y * s, 3, 3); });
    mctx.fillStyle = "#5dade2";
    others.forEach((p) => { if (!hero || p.name !== hero.name) mctx.fillRect(p.x * s, p.y * s, 3, 3); });
  }

  function cellBlocked(x, y) {
    const gx = Math.round(x), gy = Math.round(y);
    if (gx < 2 || gy < 2 || gx >= MAP - 2 || gy >= MAP - 2) return true;
    if (!map[gy]) return true;
    if (!flying && map[gy][gx] === TILE.WATER) return true;
    if (solids.has(gx + "," + gy)) return true;
    return false;
  }
  let lastSentTile = "";
  function unstickFromMobs() {
    if (!hero || !creatures.length) return;
    creatures.forEach((c) => {
      if (!c.alive) return;
      const d = Math.hypot(c.x - hero.x, c.y - hero.y) || 0.01;
      if (d < 2.2) {
        const ang = Math.atan2(c.y - hero.y, c.x - hero.x) || 0.7;
        c.x = hero.x + Math.cos(ang) * 2.8;
        c.y = hero.y + Math.sin(ang) * 2.8;
        if (c.x < 4) c.x = 4; if (c.y < 4) c.y = 4;
        if (c.x > MAP - 5) c.x = MAP - 5; if (c.y > MAP - 5) c.y = MAP - 5;
      }
      if ((portals || []).some((o) => Math.round(c.x) === o.x && Math.round(c.y) === o.y)) {
        c.x += (c.x >= 18 ? 2 : -2);
        c.y += 2;
      }
    });
  }
  function tryStep(dx, dy) {
    if (!hero) return;
    unstickFromMobs();
    if (cellBlocked(hero.x, hero.y)) {
      hero.x += Math.sign(18 - hero.x) * 0.6;
      hero.y += Math.sign(21 - hero.y) * 0.6;
      visX = hero.x; visY = hero.y;
    }
    const nx = hero.x + dx, ny = hero.y + dy;
    if (cellBlocked(nx, ny)) {
      if (!cellBlocked(nx, hero.y)) { hero.x = nx; }
      else if (!cellBlocked(hero.x, ny)) { hero.y = ny; }
      else return;
    } else {
      hero.x = nx;
      hero.y = ny;
    }
    const key = Math.round(hero.x) + "," + Math.round(hero.y);
    if (key !== lastSentTile) {
      lastSentTile = key;
      send({ type: "move", x: Math.round(hero.x), y: Math.round(hero.y) });
    }
  }

  let last = performance.now();
  function tick(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    frame++;
    if (hero) {
      moveAcc += dt;
      let ix = joy.dx, iy = joy.dy;
      if (keys.KeyA || keys.ArrowLeft) ix -= 1;
      if (keys.KeyD || keys.ArrowRight) ix += 1;
      if (keys.KeyW || keys.ArrowUp) iy -= 1;
      if (keys.KeyS || keys.ArrowDown) iy += 1;
      if (Math.abs(ix) > 0.12 || Math.abs(iy) > 0.12) {
        const spd = 2.8 * dt;
        const wx = (ix + iy) * spd;
        const wz = (iy - ix) * spd;
        tryStep(wx, wz);
        if (now > atkUntil + 80) {
          /* nao ataca sozinho — evita ficar preso no combate */
        }
      }
      visX = hero.x;
      visY = hero.y;
      others.forEach((p) => {
        if (hero && p.name === hero.name) return;
        if (p.vx == null) { p.vx = p.x; p.vy = p.y; }
        p.vx += ((p.x - p.vx) * Math.min(1, dt * 9));
        p.vy += ((p.y - p.vy) * Math.min(1, dt * 9));
      });
      unstickFromMobs();
      pickupDrops();
      if (inSafeZone()) {
        creatures = [];
        hero.hp = hero.hpMax;
        hero._lockHp = hero.hpMax;
        const layer = document.getElementById("dmg-layer");
        if (layer) layer.innerHTML = "";
      } else {
        hero._lockHp = hero.hp;
      }
      const onEl = document.getElementById("online");
      if (onEl) {
        onEl.textContent = inSafeZone()
          ? (mapName || "Porto Inicial") + " · " + t("city")
          : (mapName || "") + " · " + t("hunt");
      }
      if (inSafeZone()) {
        /* cidade principal: zero combate */
      } else if (hero.hp > 0) {
        creatures.forEach((c) => {
          if (!c.alive) return;
          const dx = hero.x - c.x, dy = hero.y - c.y;
          const dist = Math.abs(dx) + Math.abs(dy);
          const pos = iso(c.x, c.y);
          const sx = canvas.width / 2 - camX + pos.x;
          const sy = canvas.height / 2 - camY + pos.y;
          const onScreen = sx > 20 && sy > 40 && sx < canvas.width - 20 && sy < canvas.height - 70;
          if (dist > 7) { c.aggro = 0; return; }
          c.aggro = 1;
          if (dist > 2.6) {
            const step = 1.1 * dt;
            const nx = c.x + Math.sign(dx) * step;
            const ny = c.y + Math.sign(dy) * step;
            if (!cellBlocked(nx, c.y) && Math.hypot(nx - hero.x, c.y - hero.y) >= 2.4) c.x = nx;
            if (!cellBlocked(c.x, ny) && Math.hypot(c.x - hero.x, ny - hero.y) >= 2.4) c.y = ny;
          } else if (now - (c.lastHit || 0) > 1000) {
            c.lastHit = now;
            if (!onScreen || inSafeZone()) return;
            const defB = (hero.eq && hero.eq.armor ? 3 : 0) + (hero.eq && hero.eq.shield ? 2 : 0);
            const hit = Math.max(2, c.atk + ((Math.random() * 5) | 0) - Math.floor(hero.def / 8) - defB);
            hero.hp = Math.max(0, hero.hp - hit);
            applyHero(hero);
            chatLine(c.name + t("hit") + hit + ").", "dmg");
            worldFloat(hero.x, hero.y, "-" + hit, "#ff6b5a");
            sfx(180, 0.08);
            if (hero.hp <= 0) {
              hero.hp = hero.hpMax;
              goToMap("porto", 18, 21);
              chatLine(t("dead"), "sys");
            }
          }
        });
      }
    }

    const g = ctx.createLinearGradient(0, 0, 0, canvas.height);
    if (currentTheme === "grass" || currentTheme === "city") {
      g.addColorStop(0, "#6ad0ff");
      g.addColorStop(0.42, "#c8f06a");
      g.addColorStop(1, "#3a9a38");
    } else {
      g.addColorStop(0, "#1a2240");
      g.addColorStop(0.4, "#3a4a68");
      g.addColorStop(1, "#1a2818");
    }
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const targetCam = hero ? iso(visX, visY) : iso(18, 21);
    camX += (targetCam.x - camX) * Math.min(1, dt * 8);
    camY += (targetCam.y - camY) * Math.min(1, dt * 8);
    ctx.save();
    ctx.translate(canvas.width / 2 - camX, canvas.height / 2 - camY + 20);

    for (let y = 0; y < MAP; y++) {
      for (let x = 0; x < MAP; x++) drawTile(x, y, map[y][x]);
    }
    const drawables = [];
    for (let y = 2; y < MAP - 2; y++) for (let x = 2; x < MAP - 2; x++) {
      if (map[y][x] !== TILE.GRASS) continue;
      const r = seeded(x * 2, y * 5);
      if (r > 0.965) drawables.push({ x, y, z: x + y, draw: () => drawTree(x, y) });
    }
    if (currentTheme === "city" || currentTheme === "grass") {
      drawables.push({ x: 11, y: 12, z: 24, draw: () => drawHouse(11, 12) });
      drawables.push({ x: 21, y: 11, z: 32, draw: () => drawHouse(21, 11) });
      if (currentTheme === "city") {
        drawables.push({ x: 8, y: 14, z: 22, draw: () => drawHouse(8, 14) });
        drawables.push({ x: 24, y: 13, z: 38, draw: () => drawHouse(24, 13) });
        drawables.push({ x: 17, y: 17, z: 34, draw: () => drawTemple(17, 17) });
        drawables.push({ x: 6, y: 10, z: 16, draw: () => drawHouse(6, 10) });
        drawables.push({ x: 28, y: 10, z: 38, draw: () => drawHouse(28, 10) });
        drawables.push({ x: 6, y: 22, z: 28, draw: () => drawHouse(6, 22) });
        drawables.push({ x: 28, y: 22, z: 50, draw: () => drawHouse(28, 22) });
      }
    }
    if (currentTheme === "forest") {
      for (let i = 0; i < 18; i++) {
        const tx = 6 + ((i * 5) % 22), ty = 6 + ((i * 7) % 20);
        drawables.push({ x: tx, y: ty, z: tx + ty, draw: () => drawTree(tx, ty) });
      }
    }
    portals.forEach((p) => {
      drawables.push({
        x: p.x, y: p.y, z: p.x + p.y + 0.05,
        draw() {
          const pos = iso(p.x, p.y);
          ctx.fillStyle = "#7d5cff";
          ctx.fillRect(pos.x - 8, pos.y - 4, 16, 10);
          ctx.fillStyle = "#e8deff";
          ctx.fillRect(pos.x - 4, pos.y - 18, 8, 16);
          ctx.fillStyle = "#fff";
          ctx.font = "9px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("Lv" + p.need, pos.x, pos.y - 22);
        },
      });
    });
    drops.forEach((d) => {
      drawables.push({ x: d.x, y: d.y, z: d.x + d.y + 0.15, draw: () => drawDrop(d) });
    });
    creatures.forEach((c) => {
      if (!c.alive) return;
      drawables.push({
        x: c.x, y: c.y, z: c.x + c.y + 0.2,
        draw() {
          const p = iso(c.x, c.y);
          const bob = Math.sin(frame / 8 + c.x) * 2;
          ctx.strokeStyle = "#ffe566";
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, 18, 10, 0, 0, 7); ctx.stroke();
          ctx.fillStyle = "rgba(0,0,0,.35)";
          ctx.beginPath(); ctx.ellipse(p.x, p.y + 4, 16, 7, 0, 0, 7); ctx.fill();
          const img = makeMob(c.kind);
          ctx.drawImage(img, p.x - 16, p.y - 28 + bob, 32, 32);
          ctx.fillStyle = "#000"; ctx.fillRect(p.x - 16, p.y - 46 + bob, 32, 5);
          ctx.fillStyle = "#e74c3c"; ctx.fillRect(p.x - 16, p.y - 46 + bob, 32 * Math.max(0, c.hp / c.hpMax), 5);
          if (showNames) {
            ctx.fillStyle = "#fff6c8";
            ctx.font = "bold 11px sans-serif";
            ctx.textAlign = "center";
            ctx.strokeStyle = "#000";
            ctx.lineWidth = 3;
            ctx.strokeText(c.name || c.kind, p.x, p.y - 50 + bob);
            ctx.fillText(c.name || c.kind, p.x, p.y - 50 + bob);
          }
        },
      });
    });
    const drawnMe = { v: false };
    others.forEach((p) => {
      const isMe = hero && p.name === hero.name;
      if (isMe) drawnMe.v = true;
      const px = isMe ? visX : (p.vx != null ? p.vx : p.x);
      const py = isMe ? visY : (p.vy != null ? p.vy : p.y);
      drawables.push({
        x: px, y: py, z: px + py + 0.4,
        draw() {
          const pos = iso(px, py);
          const lift = isMe && flying ? 10 + Math.sin(frame / 8) * 3 : 0;
          const sheet = makeCharSheet(p.voc, isMe ? hero.race : p.race, isMe ? hero.sex : p.sex);
          const fr = (frame >> 3) & 1;
          drawMuWings(pos.x, pos.y - lift);
          ctx.drawImage(sheet, fr * 32, 0, 32, 48, pos.x - 26, pos.y - 68 - lift, 52, 74);
          if (isMe) drawGearOn(pos, lift);
          ctx.fillStyle = "#f5e6b8";
          ctx.font = "10px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(p.name, pos.x, pos.y - 44 - lift);
        },
      });
    });
    if (hero && !drawnMe.v) {
      drawables.push({
        x: visX, y: visY, z: visX + visY + 0.5,
        draw() {
          const pos = iso(visX, visY);
          const lift = flying ? 10 + Math.sin(frame / 8) * 3 : 0;
          const sheet = makeCharSheet(hero.voc, hero.race, hero.sex);
          const fr = (frame >> 3) & 1;
          drawMuWings(pos.x, pos.y - lift);
          ctx.drawImage(sheet, fr * 32, 0, 32, 48, pos.x - 26, pos.y - 68 - lift, 52, 74);
          drawGearOn(pos, lift);
          ctx.fillStyle = "#f5e6b8";
          ctx.font = "10px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(hero.name, pos.x, pos.y - 44 - lift);
        },
      });
    }
    drawables.sort((a, b) => a.z - b.z);
    drawables.forEach((d) => d.draw());
    ctx.restore();

    drawMini();
    if (hero) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.font = "bold 14px sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(0,0,0,.45)";
      ctx.fillRect(canvas.width / 2 - 120, 128, 240, 20);
      ctx.fillStyle = inSafeZone() ? "#7dff9a" : "#ffe566";
      ctx.fillText((inSafeZone() ? "★ " : "") + mapName + (inSafeZone() ? "  ★" : ""), canvas.width / 2, 143);
      ctx.restore();
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  const savedHost = localStorage.getItem("fl_host");
  if (savedHost && /\./.test(savedHost) && !/xxxx|aparelho/i.test(savedHost)) {
    document.getElementById("acc-host").value = savedHost;
  } else {
    document.getElementById("acc-host").value = SERVER;
  }
  const lastU = localStorage.getItem("fl_last_user");
  if (lastU) document.getElementById("acc-user").value = lastU;
  document.querySelectorAll("#lang-bar .lang").forEach((b) => {
    b.onclick = () => { lang = b.dataset.lang; applyLang(); if (typeof paintPick === "function") {} };
  });
  applyLang();
  const kickMusic = () => { ensureAudio(); playMapMusic(currentTheme || "title"); };
  document.addEventListener("pointerdown", kickMusic, { once: false });
  document.getElementById("splash").addEventListener("pointerdown", kickMusic);
})();
