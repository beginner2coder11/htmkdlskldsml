/**
 * ubicaciones.js
 * Muestra en un mapa (Leaflet + OpenStreetMap, sin necesidad de API key)
 * la última posición reportada por cada conductor con un traslado "en
 * curso". El backend expone obtenerUbicacionesActivas(), que debe
 * devolver un arreglo como:
 * [{ conductor: 'Juan Pérez', folio: 'SVT-0001', lat: 22.15, lng: -99.0,
 *    marca_tiempo: '2026-09-07T14:32:00.000Z' }, ...]
 * Solo se listan conductores con reporte reciente (el backend decide
 * qué tan reciente; sugerido: últimos 20-30 minutos).
 */

const INTERVALO_POLLING_UBICACIONES_MS = 30000; // 30 segundos
let TEMPORIZADOR_POLLING_UBICACIONES = null;
let MAPA_UBICACIONES = null;
let MARCADORES_UBICACIONES = {};
let LIBRERIA_LEAFLET_CARGADA = false;

function detenerPollingUbicaciones() {
  if (TEMPORIZADOR_POLLING_UBICACIONES) {
    clearInterval(TEMPORIZADOR_POLLING_UBICACIONES);
    TEMPORIZADOR_POLLING_UBICACIONES = null;
  }
}

function cargarVistaUbicaciones() {
  const contenedor = document.getElementById('contenido-principal');
  contenedor.innerHTML =
    '<h2>📍 Ubicación de conductores en ruta</h2>' +
    '<div id="mapa-ubicaciones" class="tarjeta" style="padding:0;"></div>' +
    '<div class="tarjeta" id="lista-ubicaciones" style="margin-top:12px;"><p style="color:var(--gris);">Cargando...</p></div>';

  cargarLibreriaLeaflet(function () {
    inicializarMapaUbicaciones();
    actualizarUbicaciones();
    detenerPollingUbicaciones();
    TEMPORIZADOR_POLLING_UBICACIONES = setInterval(actualizarUbicaciones, INTERVALO_POLLING_UBICACIONES_MS);
  });
}

function cargarLibreriaLeaflet(callback) {
  if (LIBRERIA_LEAFLET_CARGADA || window.L) { LIBRERIA_LEAFLET_CARGADA = true; callback(); return; }

  const css = document.createElement('link');
  css.rel = 'stylesheet';
  css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
  document.head.appendChild(css);

  const script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
  script.onload = function () { LIBRERIA_LEAFLET_CARGADA = true; callback(); };
  document.head.appendChild(script);
}

function inicializarMapaUbicaciones() {
  // Centro por defecto: entre San Vicente Tancuayalab y Ciudad Valles.
  MAPA_UBICACIONES = L.map('mapa-ubicaciones').setView([22.02, -99.0], 10);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 18
  }).addTo(MAPA_UBICACIONES);
  MARCADORES_UBICACIONES = {};
}

function actualizarUbicaciones() {
  google.script.run
    .withSuccessHandler(renderizarUbicaciones)
    .withFailureHandler(function (error) {
      const lista = document.getElementById('lista-ubicaciones');
      if (lista) lista.innerHTML = '<p style="color:var(--rojo);">Error al cargar ubicaciones: ' + escaparHtml(error.message) + '</p>';
    })
    .obtenerUbicacionesActivas();
}

function renderizarUbicaciones(ubicaciones) {
  const lista = document.getElementById('lista-ubicaciones');
  if (!MAPA_UBICACIONES || !lista) return; // la vista pudo haberse cerrado mientras llegaba la respuesta

  if (!ubicaciones || !ubicaciones.length) {
    lista.innerHTML = '<div class="estado-vacio"><span class="icono-vacio">📍</span>Ningún conductor tiene un traslado en curso reportando ubicación en este momento.</div>';
  } else {
    lista.innerHTML = ubicaciones.map(function (u) {
      return (
        '<div class="tarjeta-conductor-ubicacion">' +
          '<div>' +
            '<div class="nombre-conductor-ub">🚑 ' + escaparHtml(u.conductor || 'Conductor') + '</div>' +
            '<div class="folio-ub">' + escaparHtml(u.folio || '') + '</div>' +
          '</div>' +
          '<div class="hace-ub">' + escaparHtml(haceCuanto(u.marca_tiempo)) + '</div>' +
        '</div>'
      );
    }).join('');
  }

  const idsVistos = {};
  (ubicaciones || []).forEach(function (u) {
    if (typeof u.lat !== 'number' || typeof u.lng !== 'number') return;
    const clave = u.folio || u.conductor;
    idsVistos[clave] = true;
    const textoPopup = '<strong>' + escaparHtml(u.conductor || '') + '</strong><br>' +
      escaparHtml(u.folio || '') + '<br>' + escaparHtml(haceCuanto(u.marca_tiempo));

    if (MARCADORES_UBICACIONES[clave]) {
      MARCADORES_UBICACIONES[clave].setLatLng([u.lat, u.lng]).setPopupContent(textoPopup);
    } else {
      MARCADORES_UBICACIONES[clave] = L.marker([u.lat, u.lng]).addTo(MAPA_UBICACIONES).bindPopup(textoPopup);
    }
  });

  // Quita del mapa a los conductores que ya no están reportando.
  Object.keys(MARCADORES_UBICACIONES).forEach(function (clave) {
    if (!idsVistos[clave]) {
      MAPA_UBICACIONES.removeLayer(MARCADORES_UBICACIONES[clave]);
      delete MARCADORES_UBICACIONES[clave];
    }
  });

  // Si hay al menos un conductor activo, encuadra el mapa para verlos a todos.
  const puntos = Object.keys(MARCADORES_UBICACIONES).map(function (k) { return MARCADORES_UBICACIONES[k].getLatLng(); });
  if (puntos.length === 1) {
    MAPA_UBICACIONES.setView(puntos[0], 13);
  } else if (puntos.length > 1) {
    MAPA_UBICACIONES.fitBounds(L.latLngBounds(puntos), { padding: [30, 30] });
  }
}

function haceCuanto(marcaTiempoIso) {
  if (!marcaTiempoIso) return '';
  const entonces = new Date(marcaTiempoIso).getTime();
  if (isNaN(entonces)) return '';
  const minutos = Math.round((Date.now() - entonces) / 60000);
  if (minutos <= 0) return 'justo ahora';
  if (minutos === 1) return 'hace 1 minuto';
  if (minutos < 60) return 'hace ' + minutos + ' minutos';
  const horas = Math.round(minutos / 60);
  return 'hace ' + horas + (horas === 1 ? ' hora' : ' horas');
}
