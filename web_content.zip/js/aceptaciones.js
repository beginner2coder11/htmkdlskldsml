// Registro de aceptaciones — sección de consulta rápida en el panel admin
// para ver, en un solo lugar, todas las solicitudes que tienen una
// aceptación registrada (quién aceptó/firmó, cuándo, y si firmó el
// paciente o el acompañante). Se presenta como línea de tiempo (agrupada
// por día) porque, por naturaleza, es una bitácora cronológica.
// No duplica el detalle completo del traslado: cada entrada lleva a
// "verDetalleTraslado", que ya muestra todos los datos con los que se
// registró la solicitud.

let ACEPTACIONES_CACHE = [];

function cargarVistaAceptaciones() {
  const contenedor = document.getElementById('contenido-principal');
  contenedor.innerHTML = '<p>Cargando registro de aceptaciones...</p>';

  google.script.run
    .withSuccessHandler(function (lista) {
      ACEPTACIONES_CACHE = lista;
      renderizarListaAceptaciones(lista);
    })
    .withFailureHandler(function (error) {
      contenedor.innerHTML = '<p>Error al cargar el registro de aceptaciones: ' + escaparHtml(error.message) + '</p>';
    })
    .listarAceptaciones();
}

function renderizarListaAceptaciones(lista) {
  const contenedor = document.getElementById('contenido-principal');

  const total = lista.length;
  const conAcompanante = lista.filter(function (a) { return a.es_paciente_menor_edad; }).length;

  contenedor.innerHTML =
    '<div style="margin-bottom:14px;">' +
      '<h2 style="margin:0 0 4px;">✅ Registro de aceptaciones</h2>' +
      '<p style="margin:0; font-size:12.5px; color:var(--gris);">Quién aceptó los avisos de cada solicitud, y cuándo. Toca una entrada para ver el detalle completo del traslado.</p>' +
    '</div>' +
    '<div style="display:flex; gap:10px; margin-bottom:14px;">' +
      '<div class="tarjeta tarjeta-kpi" style="flex:1; margin-bottom:0;">' +
        '<div class="icono-kpi" style="background:var(--color-primario-suave); color:var(--color-primario);">✅</div>' +
        '<div><div class="valor-kpi">' + total + '</div><div class="etiqueta-kpi">Aceptaciones registradas</div></div>' +
      '</div>' +
      '<div class="tarjeta tarjeta-kpi" style="flex:1; margin-bottom:0;">' +
        '<div class="icono-kpi" style="background:var(--ambar-suave); color:var(--ambar);">👥</div>' +
        '<div><div class="valor-kpi">' + conAcompanante + '</div><div class="etiqueta-kpi">Firmadas por acompañante</div></div>' +
      '</div>' +
    '</div>' +
    '<input type="text" id="buscador-aceptaciones" placeholder="Buscar por folio o nombre del paciente..." ' +
      'style="width:100%; padding:10px; margin-bottom:16px; border:1px solid var(--color-borde); border-radius:8px;" ' +
      'oninput="filtrarAceptaciones(this.value)">' +
    '<div id="lista-aceptaciones"></div>';

  pintarTarjetasAceptaciones(lista);
}

function filtrarAceptaciones(texto) {
  const q = String(texto || '').trim().toLowerCase();
  if (!q) { pintarTarjetasAceptaciones(ACEPTACIONES_CACHE); return; }
  const filtradas = ACEPTACIONES_CACHE.filter(function (a) {
    return String(a.folio).toLowerCase().indexOf(q) !== -1 ||
      String(a.paciente_nombre).toLowerCase().indexOf(q) !== -1;
  });
  pintarTarjetasAceptaciones(filtradas);
}

function pintarTarjetasAceptaciones(lista) {
  const destino = document.getElementById('lista-aceptaciones');
  if (!destino) return;

  if (!lista.length) {
    destino.innerHTML = '<div class="tarjeta estado-vacio"><span class="icono-vacio">✅</span>No hay solicitudes con aceptación registrada.</div>';
    return;
  }

  // Más recientes primero, agrupadas por día. El esquema nuevo guarda
  // fecha_aceptacion como texto "DD/MM/AAAA"; el histórico,
  // fecha_consentimiento como timestamp.
  const ordenadas = lista.slice().sort(function (a, b) { return marcaOrden(b) - marcaOrden(a); });

  const grupos = [];
  let grupoActual = null;
  ordenadas.forEach(function (a) {
    const marca = marcaOrden(a);
    const clave = marca ? new Date(marca).toDateString() : 'Sin fecha';
    if (!grupoActual || grupoActual.clave !== clave) {
      grupoActual = { clave: clave, marca: marca, items: [] };
      grupos.push(grupoActual);
    }
    grupoActual.items.push(a);
  });

  destino.innerHTML =
    '<div class="timeline-aceptaciones">' +
      grupos.map(function (g) {
        return (
          '<div class="grupo-fecha-aceptacion">' +
            '<div class="etiqueta-fecha-aceptacion">' + etiquetaFechaGrupo(g.marca) + '</div>' +
            g.items.map(itemAceptacionHtml).join('') +
          '</div>'
        );
      }).join('') +
    '</div>';

  destino.querySelectorAll('.item-aceptacion').forEach(function (item) {
    item.addEventListener('click', function () {
      verDetalleTraslado(item.dataset.folio);
    });
  });
}

function itemAceptacionHtml(a) {
  const esAnterior = !a.fecha_aceptacion && !!a.fecha_consentimiento;
  const hora = a.hora_aceptacion
    ? a.hora_aceptacion
    : (a.fecha_consentimiento ? new Date(a.fecha_consentimiento).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) : '');

  const iconoFirmante = a.es_paciente_menor_edad ? '👥' : '👤';
  const firmante = a.firmante_nombre
    ? iconoFirmante + ' ' + escaparHtml(a.firmante_nombre) + (a.es_paciente_menor_edad ? ' <span class="chip-aceptacion chip-ambar">acompañante · paciente menor</span>' : ' <span class="chip-aceptacion">paciente</span>')
    : '';

  const chipVersion = (a.version_consentimiento || a.version_aviso_privacidad)
    ? '<span class="chip-aceptacion">avisos v. ' + escaparHtml(a.version_consentimiento || a.version_aviso_privacidad) + '</span>'
    : (esAnterior ? '<span class="chip-aceptacion">registro anterior</span>' : '');

  return (
    '<div class="item-aceptacion' + (esAnterior ? ' registro-anterior' : '') + '" data-folio="' + escaparHtml(a.folio) + '">' +
      '<div class="fila-item-aceptacion">' +
        '<span class="hora-item-aceptacion">' + (hora ? escaparHtml(hora) : '—') + '</span>' +
        '<span class="badge-estado badge-' + (COLOR_POR_ESTADO[a.estado_actual] || 'gris') + '">' + escaparHtml(a.estado_actual || '') + '</span>' +
      '</div>' +
      '<div class="paciente-item-aceptacion">' + escaparHtml(a.paciente_nombre || 'Sin nombre') +
        (a.edad_paciente !== '' ? ' <span style="font-weight:400; color:var(--gris); font-size:12.5px;">· ' + escaparHtml(a.edad_paciente) + ' años</span>' : '') +
        ' <span class="folio-item-aceptacion">· ' + escaparHtml(a.folio) + '</span>' +
      '</div>' +
      (firmante || chipVersion ? '<div class="firmante-item-aceptacion">' + firmante + chipVersion + '</div>' : '') +
    '</div>'
  );
}

function etiquetaFechaGrupo(marca) {
  if (!marca) return 'Sin fecha registrada';
  const fecha = new Date(marca);
  const hoy = new Date();
  const ayer = new Date(hoy); ayer.setDate(ayer.getDate() - 1);
  if (fecha.toDateString() === hoy.toDateString()) return 'Hoy';
  if (fecha.toDateString() === ayer.toDateString()) return 'Ayer';
  const texto = fecha.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' });
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}

function marcaOrden(a) {
  if (a.fecha_aceptacion) {
    // "DD/MM/AAAA" -> "AAAA-MM-DD" para que Date lo interprete bien.
    const partes = a.fecha_aceptacion.split('/');
    if (partes.length === 3) {
      const iso = partes[2] + '-' + partes[1] + '-' + partes[0] + 'T' + (a.hora_aceptacion || '00:00');
      const t = new Date(iso).getTime();
      if (!isNaN(t)) return t;
    }
  }
  if (a.fecha_consentimiento) {
    const t = new Date(a.fecha_consentimiento).getTime();
    if (!isNaN(t)) return t;
  }
  return 0;
}
