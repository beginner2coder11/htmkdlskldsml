/* Spoken Sentences — Category Wise All in One
   App by Suryakant Bharti · Vision of Learners */
(function () {
  'use strict';
  var B = window.BOOK;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var app = $('#view');
  var AUTHOR_EN = 'Suryakant Bharti', AUTHOR_HI = 'सूर्यकांत भारती', MOBILE = '76776 36062';
  var COMP = [['S', 'Subject', 'कर्ता'], ['V', 'Verb', 'क्रिया'], ['O', 'Object', 'कर्म'], ['C', 'Complement', 'पूरक'], ['A', 'Adverbial', 'क्रियाविशेषण']];
  var LVN = { 1: 'सरल', 2: 'मध्यम', 3: 'कठिन' };

  /* ---------------- index ---------------- */
  var CH = {}, ALL = [], ORDER = [];
  B.parts.forEach(function (p) {
    p.ch.forEach(function (c) {
      c.part = p; CH[c.no] = c; ORDER.push(c.no);
      c.count = 0;
      c.s.forEach(function (s, si) {
        s.i.forEach(function (r, ri) {
          c.count++;
          ALL.push({ r: r, c: c.no, si: si, ri: ri, id: c.no + '.' + si + '.' + ri, lc: (r[0] + ' ' + r[1]).toLowerCase() });
        });
      });
    });
    p.count = p.ch.reduce(function (a, c) { return a + c.count; }, 0);
  });
  var BYID = {}; ALL.forEach(function (x, i) { x.n = i + 1; BYID[x.id] = x; });

  /* ---------------- storage ---------------- */
  function load(k, d) { try { var v = localStorage.getItem('ss_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem('ss_' + k, JSON.stringify(v)); } catch (e) { } }
  var S = {
    saved: load('saved', []), read: load('read', {}), last: load('last', 0),
    set: load('set', { fs: 16, rate: 0.85, accent: 'en-IN', theme: 'light', hideHi: false, autoHi: true })
  };
  function applySettings() {
    document.documentElement.style.setProperty('--fs', S.set.fs + 'px');
    document.documentElement.setAttribute('data-theme', S.set.theme);
  }
  applySettings();

  /* ---------------- helpers ---------------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function toast(t) { var el = $('#toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(function () { el.classList.remove('on'); }, 1800); }
  function setTheme(c1, c2, cbg) {
    var st = document.documentElement.style;
    st.setProperty('--c1', c1 || '#3B1490'); st.setProperty('--c2', c2 || '#6A1B9A'); st.setProperty('--cbg', cbg || '#EDE7F6');
  }
  function top(title, sub, back, extra) {
    return '<div class="top">' + (back ? '<button class="ib" data-act="back" aria-label="वापस">←</button>' : '<img class="tl" src="assets/logo_white.png" alt="Vision of Learners">') +
      '<div class="tt"><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div>' + (extra || '') +
      '<button class="ib" data-act="settings" aria-label="सेटिंग">⚙️</button></div><div class="rainbow"></div>';
  }
  function chips(r) {
    var h = '';
    COMP.forEach(function (c, i) {
      var v = r[2 + i];
      h += v ? '<span class="chip ' + c[0] + '"><b>' + c[0] + '</b><span>' + esc(v) + '</span></span>' : '<span class="chip ' + c[0] + ' empty"><b>' + c[0] + '</b><span>—</span></span>';
    });
    if (r[7]) h += '<span class="chip X"><b>+</b><span>' + esc(r[7]) + '</span></span>';
    return '<div class="chips">' + h + '</div>';
  }
  function hl(text, q) {
    var t = esc(text); if (!q) return t;
    var i = text.toLowerCase().indexOf(q); if (i < 0) return t;
    return esc(text.slice(0, i)) + '<mark>' + esc(text.slice(i, i + q.length)) + '</mark>' + esc(text.slice(i + q.length));
  }
  function card(x, opt) {
    opt = opt || {};
    var r = x.r, saved = S.saved.indexOf(x.id) >= 0;
    var tag = r[9] ? '<span class="tag ' + r[9] + '">' + r[9] + '</span>' : '';
    var c = CH[x.c];
    return '<div class="card fade" data-id="' + x.id + '" style="--c1:' + c.part.c1 + ';--c2:' + c.part.c2 + '">' +
      '<div class="r1"><span class="no">' + x.n + '</span><span class="en">' + tag + hl(r[0], opt.q) + '</span><span class="lv lv' + r[8] + '">' + LVN[r[8]] + '</span></div>' +
      '<div class="hi' + (S.set.hideHi && !opt.noHide ? ' blur' : '') + '" data-act="unblur">' + hl(r[1], opt.q) + '</div>' + chips(r) +
      '<div class="acts"><button data-act="say" title="अंग्रेज़ी सुनें">🔊 <span>English</span></button><button data-act="sayhi" title="हिंदी सुनें">🔈 <span>हिंदी</span></button>' +
      '<button data-act="star" class="' + (saved ? 'on' : '') + '" title="सहेजें">' + (saved ? '★' : '☆') + '</button><button data-act="copy" title="कॉपी">📋</button></div>' +
      (opt.from ? '<div class="from">अध्याय ' + c.no + ' · <button data-go="#/ch/' + c.no + '">' + esc(c.en) + '</button></div>' : '') + '</div>';
  }
  function foot() {
    return '<div class="foot"><div class="fl"><img src="assets/logo.png" alt="Vision of Learners"></div><br>Spoken Sentences — Category Wise All in One<br>' +
      '✍️ ' + AUTHOR_HI + ' | ' + AUTHOR_EN + ' · 📞 ' + MOBILE + '<br>© Vision of Learners</div>';
  }
  function dayIndex() { var d = new Date(); return (d.getFullYear() * 372 + d.getMonth() * 31 + d.getDate()) % ALL.length; }

  /* ---------------- speech ---------------- */
  var synth = window.speechSynthesis, voices = [];
  function loadVoices() { try { voices = synth ? synth.getVoices() : []; } catch (e) { voices = []; } }
  if (synth) { loadVoices(); try { synth.onvoiceschanged = loadVoices; } catch (e) { } }
  function pickVoice(lang) {
    var v = voices.filter(function (v) { return v.lang && v.lang.replace('_', '-').toLowerCase() === lang.toLowerCase(); });
    if (!v.length) v = voices.filter(function (v) { return v.lang && v.lang.toLowerCase().indexOf(lang.slice(0, 2).toLowerCase()) === 0; });
    return v[0] || null;
  }
  function speak(text, lang, done) {
    if (!synth || !window.SpeechSynthesisUtterance) { toast('इस फ़ोन में आवाज़ (Text-to-Speech) उपलब्ध नहीं है'); if (done) done(false); return; }
    var u = new SpeechSynthesisUtterance(text.replace(/[|]/g, ' '));
    u.lang = lang; var v = pickVoice(lang); if (v) u.voice = v;
    u.rate = lang.indexOf('hi') === 0 ? Math.min(1, S.set.rate + 0.05) : S.set.rate;
    u.onend = function () { if (done) done(true); };
    u.onerror = function () { if (done) done(false); };
    synth.speak(u);
  }
  function stopSpeak() { try { synth && synth.cancel(); } catch (e) { } playing = false; document.querySelectorAll('.card.speaking').forEach(function (e) { e.classList.remove('speaking'); }); var pb = $('#playAll'); if (pb) pb.textContent = '▶ सभी सुनें'; }
  var playing = false;
  function playAll() {
    if (playing) { stopSpeak(); return; }
    var cards = Array.prototype.slice.call(document.querySelectorAll('.card'));
    if (!cards.length) return;
    playing = true; $('#playAll').textContent = '⏸ रोकें';
    var i = 0;
    (function next() {
      if (!playing || i >= cards.length) { stopSpeak(); return; }
      var el = cards[i++], x = BYID[el.getAttribute('data-id')];
      document.querySelectorAll('.card.speaking').forEach(function (e) { e.classList.remove('speaking'); });
      el.classList.add('speaking'); el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      speak(x.r[0], S.set.accent, function () {
        if (!playing) return;
        if (S.set.autoHi) speak(x.r[1], 'hi-IN', function () { setTimeout(next, 450); });
        else setTimeout(next, 600);
      });
    })();
  }

  /* ---------------- views ---------------- */
  function vHome() {
    setTheme();
    var d = ALL[dayIndex()], last = CH[S.last];
    var readN = Object.keys(S.read).length;
    var h = '<div class="hero"><div class="lgrow"><img src="assets/logo_white.png" alt="Vision of Learners"><button class="set" data-act="settings" aria-label="सेटिंग">⚙️</button></div>' +
      '<div class="main"><div class="ph"><img src="assets/author_head.jpg" alt="' + AUTHOR_EN + '"></div><div><div class="k">ENGLISH</div><h1>SPOKEN</h1><div>SENTENCES</div>' +
      '<span class="pill">Category Wise · All in One</span></div></div>' +
      '<div class="hin">स्पोकन सेंटेंसेज़ — श्रेणीवार सम्पूर्ण संग्रह</div><div class="by">✍️ ' + AUTHOR_HI + ' | ' + AUTHOR_EN + '</div>' +
      '<div class="stats"><div><b>' + B.total.toLocaleString('en-IN') + '</b><span>वाक्य</span></div><div><b>' + ORDER.length + '</b><span>अध्याय</span></div><div><b>' + B.parts.length + '</b><span>भाग</span></div><div><b>' + readN + '</b><span>पढ़े अध्याय</span></div></div></div>';
    h += '<button class="continue" data-go="#/ch/' + (last ? last.no : 1) + '"><span class="ci">' + (last ? '📖' : '🚀') + '</span><span class="ct"><small>' + (last ? 'जहाँ छोड़ा था, वहीं से पढ़ें' : 'पढ़ना शुरू करें') + '</small><b>' +
      esc(last ? 'अध्याय ' + last.no + ' · ' + last.en : 'अध्याय 1 · The Seven Sentence Patterns') + '</b></span><span class="ar">›</span></button>';
    h += '<div class="wrap"><div class="tiles">' +
      tile('#/parts', '📚', 'सभी भाग', '14 श्रेणियाँ', '#5E35B1', '#8E24AA') +
      tile('#/practice', '🎯', 'अभ्यास', 'क्विज़ व फ़्लैशकार्ड', '#EF6C00', '#F9A825') +
      tile('#/search', '🔍', 'खोजें', 'English / हिंदी', '#00897B', '#00ACC1') +
      tile('#/saved', '⭐', 'सहेजे वाक्य', S.saved.length + ' वाक्य', '#C62828', '#EC407A') +
      tile('#/guide', '🧩', 'पाँच घटक', 'S · V · O · C · A', '#1565C0', '#7C4DFF') +
      tile('#/about', '👨‍🏫', 'लेखक', 'परिचय व संपर्क', '#2E7D32', '#9E9D24') + '</div>';
    h += '<div class="h2">🌟 आज का वाक्य <small>Sentence of the Day</small></div><div class="daily"><div class="dk">TODAY · आज</div><div class="de">' + esc(d.r[0]) + '</div><div class="dh">' + esc(d.r[1]) + '</div>' +
      '<div class="da"><button data-say="' + d.id + '">🔊 सुनें</button><button data-go="#/ch/' + d.c + '">📖 अध्याय देखें</button><button data-act="newday">🔀 दूसरा</button></div></div>';
    h += '<div class="h2">📚 श्रेणियाँ <small>Categories</small></div>' + partCards() + '</div>' + foot();
    return h;
  }
  function tile(go, e, t, s, a, b) { return '<button class="tile" data-go="' + go + '" style="background:linear-gradient(135deg,' + a + ',' + b + ')"><span class="te">' + e + '</span>' + t + '<small>' + s + '</small></button>'; }
  function partCards() {
    return '<div class="plist">' + B.parts.map(function (p) {
      var done = p.ch.filter(function (c) { return S.read[c.no]; }).length;
      return '<button class="pcard fade" data-go="#/part/' + p.no + '" style="--a:' + p.c1 + ';--b:' + p.c2 + '"><span class="pn">' + p.icon + '</span><span class="pt"><small>PART ' + p.no + ' · भाग ' + p.no + '</small><b>' + esc(p.en) + '</b><span>' + esc(p.hi) + '</span>' +
        '<div class="prog"><i style="width:' + Math.round(done * 100 / p.ch.length) + '%"></i></div><div class="pc">' + p.ch.length + ' अध्याय · ' + p.count + ' वाक्य · ' + done + ' पढ़े</div></span></button>';
    }).join('') + '</div>';
  }
  function vParts() { setTheme(); return top('सभी भाग · All Parts', B.parts.length + ' श्रेणियाँ · ' + B.total.toLocaleString('en-IN') + ' वाक्य', true) + '<div class="wrap">' + partCards() + '</div>' + foot(); }
  function vPart(n) {
    var p = B.parts.filter(function (x) { return x.no == n; })[0]; if (!p) return vParts();
    setTheme(p.c1, p.c2, p.bg);
    var h = top('भाग ' + p.no + ' · ' + p.hi, p.en, true) + '<div class="phead" data-n="' + p.no + '"><div class="pi">' + p.icon + '</div><h2>' + esc(p.en) + '</h2><div class="ph2">' + esc(p.hi) + '</div><p>' + esc(p.desc) + '<br><b>📊 ' + p.ch.length + ' अध्याय · ' + p.count + ' वाक्य</b></p></div>';
    h += '<div class="wrap"><div class="clist">' + p.ch.map(function (c) {
      return '<button class="citem fade" data-go="#/ch/' + c.no + '"><span class="cn">' + c.no + '</span><span class="ctx"><b>' + esc(c.en) + '</b><span>' + esc(c.hi) + '</span></span><span class="cc">' + (S.read[c.no] ? '<span class="done">✔</span><br>' : '') + c.count + ' वाक्य</span></button>';
    }).join('') + '</div></div>' + foot();
    return h;
  }
  var lvFilter = 0;
  function vChapter(n) {
    var c = CH[n]; if (!c) return vParts();
    var p = c.part; setTheme(p.c1, p.c2, p.bg);
    S.last = c.no; save('last', S.last); S.read[c.no] = 1; save('read', S.read);
    var h = top('अध्याय ' + c.no + ' · ' + c.hi, p.icon + ' भाग ' + p.no + ' · ' + p.en, true);
    h += '<div class="chead"><span class="ck">CHAPTER ' + c.no + ' · ' + c.count + ' SENTENCES</span><h2>' + esc(c.en) + '</h2><div class="ch2">' + esc(c.hi) + '</div></div>';
    if (c.intro) {
      var it = c.intro;
      h += '<div class="intro"><div class="d">📘 ' + esc(it.d) + '</div>' + (it.rows && it.rows.length ? '<div class="frm">' + it.rows.map(function (r) { return '<span class="fl">' + esc(r[0]) + '</span><span class="fv">' + esc(r[1]) + '</span>'; }).join('') + '</div>' : '') +
        (it.mk ? '<div class="mk">🔍 <b>हिंदी पहचान:</b> ' + esc(it.mk) + '</div>' : '') + (it.ex && it.ex.length ? '<div class="ex">✏️ <b>' + esc(it.ex[0]) + '</b> — ' + esc(it.ex[1]) + '</div>' : '') + '</div>';
    }
    h += '<div class="tools"><button class="chipbtn play" id="playAll" data-act="playall">▶ सभी सुनें</button>' +
      [0, 1, 2, 3].map(function (l) { return '<button class="chipbtn' + (lvFilter === l ? ' on' : '') + '" data-lv="' + l + '">' + (l ? LVN[l] : 'सभी स्तर') + '</button>'; }).join('') +
      '<button class="chipbtn' + (S.set.hideHi ? ' on' : '') + '" data-act="togglehi">' + (S.set.hideHi ? '🙈 हिंदी छुपी' : '👁 हिंदी दिखे') + '</button></div><div id="list">' + chapterList(c) + '</div>';
    var i = ORDER.indexOf(c.no), pv = CH[ORDER[i - 1]], nx = CH[ORDER[i + 1]];
    h += '<div class="pager">' + (pv ? '<button data-go="#/ch/' + pv.no + '"><small>‹ पिछला</small><b>' + esc(pv.en) + '</b></button>' : '<span style="flex:1"></span>') +
      (nx ? '<button class="nx" data-go="#/ch/' + nx.no + '"><small>अगला ›</small><b>' + esc(nx.en) + '</b></button>' : '<span style="flex:1"></span>') + '</div>' + foot();
    return h;
  }
  function chapterList(c) {
    var h = '', shown = 0;
    c.s.forEach(function (s, si) {
      var items = [];
      s.i.forEach(function (r, ri) { if (!lvFilter || r[8] === lvFilter) items.push(BYID[c.no + '.' + si + '.' + ri]); });
      if (!items.length) return;
      shown += items.length;
      h += '<div class="sec"><span class="si">' + (si + 1) + '</span><div><b>' + esc(s.t) + '</b><span>' + esc(s.h) + '</span></div></div>' + items.map(function (x) { return card(x); }).join('');
    });
    return shown ? h : '<div class="nores"><div class="ee">🔎</div><b>इस स्तर का कोई वाक्य नहीं है</b>दूसरा स्तर चुनें।</div>';
  }
  var lastQ = '';
  function vSearch() {
    setTheme('#00897B', '#00ACC1', '#E0F7FA');
    var sug = ['I am', 'have been', 'should', 'Who', 'There is', 'by', 'Let\'s', 'May you', 'What a', 'If', 'कल', 'पास', 'चाहिए', 'रहा है', 'क्या'];
    return top('खोजें · Search', 'अंग्रेज़ी या हिंदी शब्द लिखें', true) + '<div class="wrap"><div class="sbox"><span>🔍</span><input id="q" type="text" enterkeyhint="search" placeholder="जैसे: going to, बाज़ार, kitchen…" value="' + esc(lastQ) + '" autocomplete="off"><button data-act="clearq" aria-label="साफ़ करें">✕</button></div>' +
      '<div class="hint">सुझाव:</div><div class="sugg">' + sug.map(function (s) { return '<button class="chipbtn" data-q="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div><div id="res" style="margin:12px -14px 0"></div></div>';
  }
  function runSearch() {
    var q = ($('#q').value || '').trim().toLowerCase(); lastQ = q;
    var res = $('#res'); if (!res) return;
    if (q.length < 2) { res.innerHTML = '<div class="hint" style="margin:6px 18px">कम से कम 2 अक्षर लिखें।</div>'; return; }
    var out = [];
    for (var i = 0; i < ALL.length && out.length < 150; i++) if (ALL[i].lc.indexOf(q) >= 0) out.push(ALL[i]);
    var total = 0; ALL.forEach(function (x) { if (x.lc.indexOf(q) >= 0) total++; });
    res.innerHTML = '<div class="hint" style="margin:0 18px 10px">' + total + ' वाक्य मिले' + (total > 150 ? ' (पहले 150 दिखाए गए)' : '') + '</div>' +
      (out.length ? out.map(function (x) { return card(x, { q: q, from: true, noHide: true }); }).join('') : '<div class="nores"><div class="ee">🤔</div><b>कोई वाक्य नहीं मिला</b>दूसरा शब्द आज़माएँ।</div>');
  }
  function vSaved() {
    setTheme('#C62828', '#EC407A', '#FCE4EC');
    var items = S.saved.map(function (id) { return BYID[id]; }).filter(Boolean);
    return top('सहेजे वाक्य · Saved', items.length + ' वाक्य', true) + '<div style="padding-top:12px">' +
      (items.length ? items.map(function (x) { return card(x, { from: true }); }).join('') : '<div class="nores"><div class="ee">⭐</div><b>अभी कोई वाक्य सहेजा नहीं गया</b>किसी भी वाक्य पर ☆ दबाकर उसे यहाँ सहेजें — रोज़ दोहराने के लिए।</div>') + '</div>' + foot();
  }
  function vGuide() {
    setTheme('#1565C0', '#7C4DFF', '#EDE7F6');
    var D = [
      ['S', 'Subject', 'कर्ता', 'वाक्य में जो काम करता है या जिसके बारे में बात होती है।', 'पहचान: क्रिया से पहले "कौन?" या "क्या?" पूछें।', 'Ram plays. → Ram'],
      ['V', 'Verb', 'क्रिया', 'काम या स्थिति बताने वाला शब्द। is, has, will, can जैसी सहायक क्रियाएँ भी इसी में आती हैं।', 'पहचान: "क्या करता है / क्या है?"', 'She is reading a book. → is reading'],
      ['O', 'Object', 'कर्म', 'जिस पर क्रिया का असर पड़ता है। व्यक्ति वाला कर्म IO, वस्तु वाला DO।', 'पहचान: क्रिया के बाद "क्या?" या "किसे?"', 'He gave me (IO) a pen (DO).'],
      ['C', 'Complement', 'पूरक', 'कर्ता या कर्म के बारे में बात पूरी करने वाला संज्ञा या विशेषण। be, become, look, seem के बाद।', 'पहचान: "कौन है / कैसा है?"', 'Mohan is a doctor. → a doctor'],
      ['A', 'Adverbial', 'क्रियाविशेषण', 'कब, कहाँ, कैसे, क्यों, कितनी बार — बताने वाला शब्द-समूह।', 'पहचान: "कब? कहाँ? कैसे? क्यों?"', 'We play in the park every evening.']];
    var col = { S: '#1E88E5', V: '#E53935', O: '#43A047', C: '#8E24AA', A: '#FB8C00' };
    var h = top('वाक्य के पाँच घटक', 'The Five Components', true) + '<div class="wrap">';
    h += D.map(function (d) { return '<div class="comp fade"><div class="cl" style="background:' + col[d[0]] + '"><b>' + d[0] + '</b><small>' + d[1] + '</small><span>' + d[2] + '</span></div><div class="cr">' + esc(d[3]) + '<i>🔍 ' + esc(d[4]) + '</i><i>✏️ ' + esc(d[5]) + '</i></div></div>'; }).join('');
    var ex = ALL.filter(function (x) { return x.r[0].indexOf('made us tasty') >= 0; })[0] || ALL[100];
    h += '<div class="h2">🧩 सात मूल ढाँचे <small>7 Patterns</small></div><div class="box">SV · SVO · SVC · SVA · SVOO · SVOC · SVOA — अंग्रेज़ी के लगभग सभी वाक्य इन्हीं ढाँचों से बनते हैं। <button class="chipbtn" style="margin-top:8px" data-go="#/ch/1">अध्याय 1 में उदाहरण देखें ›</button></div>';
    h += '<div class="h2">🎨 रंगों का अर्थ</div><div class="box"><div class="chips" style="margin:0">' + COMP.map(function (c) { return '<span class="chip ' + c[0] + '"><b>' + c[0] + '</b><span>' + c[1] + ' · ' + c[2] + '</span></span>'; }).join('') +
      '<span class="chip X"><b>+</b><span>अन्य भाग</span></span></div><p style="margin-top:8px">फीका (—) बॉक्स = वह घटक वाक्य में नहीं है। (You) = छिपा हुआ कर्ता।<br>स्तर: <span class="lv lv1">सरल</span> <span class="lv lv2">मध्यम</span> <span class="lv lv3">कठिन</span></p></div></div>' + foot();
    return h;
  }
  function vAbout() {
    setTheme('#2E7D32', '#00897B', '#E8F5E9');
    return top('लेखक परिचय', 'About the Author', true) + '<div class="wrap about"><div class="ap" style="margin-top:8px"><img src="assets/author_portrait.jpg" alt="' + AUTHOR_EN + '" style="object-position:50% 12%"></div>' +
      '<h2>' + AUTHOR_EN + '</h2><div class="ah">' + AUTHOR_HI + ' — शिक्षक</div><a class="call" href="tel:+917677636062">📞 ' + MOBILE + '</a>' +
      '<div class="logo-card"><img src="assets/logo.png" alt="Vision of Learners"></div>' +
      '<div class="box"><h3>✍️ लेखक की ओर से</h3>प्रिय विद्यार्थियो, अंग्रेज़ी बोलना कठिन नहीं है — बस सही वाक्य-ढाँचे को समझना और रोज़ अभ्यास करना ज़रूरी है। इस ऐप में हर वाक्य के साथ उसका हिंदी अर्थ और उसके पाँच घटक रंगों में अलग करके दिखाए गए हैं। वाक्य को सुनें, ज़ोर से बोलें और उसी ढाँचे में अपने वाक्य बनाएँ।</div>' +
      '<div class="box"><h3>📚 लेखक की अन्य ई-बुक्स</h3><ul><li><b>WORD POWER</b> — English Vocabulary (कक्षा 1–12)</li><li><b>हिंदी शब्दकोश — शब्द-शक्ति</b></li><li><b>My Picture Word Book</b> — मेरी चित्र शब्द-पुस्तक</li></ul></div>' +
      '<div class="box" style="text-align:center"><img src="assets/badge.jpg" alt="Suryakant Bharti" style="width:200px;margin:0 auto"><b style="color:var(--brand)">Knowledge for a Better Tomorrow</b><br><span class="muted">Teach · Learn · Grow</span></div></div>' + foot();
  }

  /* ---------------- practice ---------------- */
  var Q = { mode: '', part: 0, ok: 0, no: 0, cur: null, answered: false };
  function vPractice() {
    setTheme('#EF6C00', '#F9A825', '#FFF8E1');
    var opts = '<option value="0">सभी भाग (मिश्रित)</option>' + B.parts.map(function (p) { return '<option value="' + p.no + '"' + (Q.part == p.no ? ' selected' : '') + '>भाग ' + p.no + ' · ' + esc(p.hi) + '</option>'; }).join('');
    return top('अभ्यास · Practice', 'सीखें, बोलें और ख़ुद को परखें', true) + '<div class="wrap"><div class="hint" style="margin-top:0">भाग चुनें:</div><select class="sel" id="qpart">' + opts + '</select>' +
      '<div class="h2">🎯 अभ्यास का तरीक़ा चुनें</div><div class="modes">' +
      '<button class="mode" data-mode="flash" style="background:linear-gradient(120deg,#5E35B1,#8E24AA)"><span class="me">🃏</span><span><b>हिंदी → English (फ़्लैशकार्ड)</b><span>हिंदी वाक्य देखकर अंग्रेज़ी में बोलें, फिर उत्तर देखें और सुनें।</span></span></button>' +
      '<button class="mode" data-mode="comp" style="background:linear-gradient(120deg,#00897B,#43A047)"><span class="me">🧩</span><span><b>घटक पहचानो (Quiz)</b><span>वाक्य में Subject, Verb, Object, Complement या Adverbial पहचानें।</span></span></button>' +
      '<button class="mode" data-mode="mcq" style="background:linear-gradient(120deg,#C62828,#EC407A)"><span class="me">✅</span><span><b>सही अनुवाद चुनो</b><span>हिंदी वाक्य का सही अंग्रेज़ी वाक्य चार विकल्पों में से चुनें।</span></span></button>' +
      '<button class="mode" data-mode="listen" style="background:linear-gradient(120deg,#1565C0,#7C4DFF)"><span class="me">🎧</span><span><b>सुनो और पहचानो</b><span>अंग्रेज़ी वाक्य सुनें और उसका सही हिंदी अर्थ चुनें।</span></span></button></div></div>' + foot();
  }
  function pool() { return Q.part ? ALL.filter(function (x) { return CH[x.c].part.no == Q.part; }) : ALL; }
  function rnd(a) { return a[Math.floor(Math.random() * a.length)]; }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function qHead(title) { return '<div class="qtop"><b style="color:var(--ink)">' + title + '</b><div class="score"><span class="ok">✔ ' + Q.ok + '</span><span class="no2">✘ ' + Q.no + '</span></div></div>'; }
  function vQuiz() {
    setTheme('#EF6C00', '#F9A825', '#FFF8E1');
    var P = pool(), x, h = '', names = { flash: 'फ़्लैशकार्ड', comp: 'घटक पहचानो', mcq: 'सही अनुवाद चुनो', listen: 'सुनो और पहचानो' };
    Q.answered = false;
    if (Q.mode === 'flash') {
      x = Q.cur = rnd(P);
      h = qHead('🃏 हिंदी → English') + '<div class="qq">इस वाक्य को अंग्रेज़ी में बोलिए:</div><div class="qhi">' + esc(x.r[1]) + '</div><div id="rv"></div>' +
        '<div class="btnrow" id="fbtn"><button class="btn o" data-q2="show">👁 उत्तर देखें</button></div>';
    } else if (Q.mode === 'comp') {
      var tries = 0, k;
      do { x = rnd(P); var have = COMP.filter(function (c, i) { return x.r[2 + i] && x.r[2 + i].length < 60; }); tries++; } while (have.length < 2 && tries < 50);
      k = rnd(have); Q.cur = x; Q.key = k;
      var idx = COMP.indexOf(k), right = x.r[2 + idx];
      var wrongs = COMP.map(function (c, i) { return x.r[2 + i]; }).filter(function (v, i) { return v && i !== idx; });
      var opts = [right].concat(wrongs.slice(0, 3));
      while (opts.length < 3) { var o = rnd(P).r[2 + idx]; if (o && opts.indexOf(o) < 0) opts.push(o); }
      opts = shuffle(opts.slice(0, 4)); Q.right = right;
      h = qHead('🧩 घटक पहचानो') + '<div class="qen">' + esc(x.r[0]) + '</div><div class="qq">' + esc(x.r[1]) + '</div>' +
        '<div class="qask">इस वाक्य में <span class="chip ' + k[0] + '"><b>' + k[0] + '</b><span>' + k[1] + ' · ' + k[2] + '</span></span> कौन-सा है?</div>' +
        '<div class="opts">' + opts.map(function (o) { return '<button class="opt" data-ans="' + esc(o) + '">' + esc(o) + '</button>'; }).join('') + '</div><div id="rv"></div>';
    } else {
      x = Q.cur = rnd(P);
      var field = Q.mode === 'mcq' ? 0 : 1, others = [];
      var same = P.filter(function (y) { return y.c === x.c && y !== x; });
      while (others.length < 3) { var y = (same.length > 6 && Math.random() < .7) ? rnd(same) : rnd(P); var v = y.r[field]; if (v !== x.r[field] && others.indexOf(v) < 0) others.push(v); }
      Q.right = x.r[field];
      var op = shuffle([x.r[field]].concat(others));
      if (Q.mode === 'mcq') h = qHead('✅ सही अनुवाद चुनो') + '<div class="qq">इस वाक्य का सही अंग्रेज़ी रूप कौन-सा है?</div><div class="qhi">' + esc(x.r[1]) + '</div>';
      else h = qHead('🎧 सुनो और पहचानो') + '<div class="qq">वाक्य सुनिए और उसका हिंदी अर्थ चुनिए:</div><div class="btnrow"><button class="btn o" data-q2="hear">🔊 फिर से सुनें</button></div>';
      h += '<div class="opts">' + op.map(function (o) { return '<button class="opt" data-ans="' + esc(o) + '">' + esc(o) + '</button>'; }).join('') + '</div><div id="rv"></div>';
    }
    var page = top(names[Q.mode], Q.part ? 'भाग ' + Q.part : 'सभी भाग', true) + '<div class="wrap"><div class="qbox fade">' + h + '</div>' +
      '<div class="btnrow"><button class="btn ghost" data-q2="reset">↺ स्कोर शून्य करें</button><button class="btn" data-q2="next">अगला ›</button></div></div>';
    return page;
  }
  function revealHTML(x) {
    return '<div class="reveal fade"><div class="qen">' + esc(x.r[0]) + '</div>' + (Q.mode !== 'flash' ? '<div class="qq" style="margin-top:4px">' + esc(x.r[1]) + '</div>' : '') + chips(x.r) +
      '<div class="btnrow"><button class="btn ghost" data-say="' + x.id + '">🔊 सुनें</button><button class="btn ghost" data-go="#/ch/' + x.c + '">📖 अध्याय ' + x.c + '</button></div></div>';
  }

  /* ---------------- router ---------------- */
  function route() {
    stopSpeak();
    var hsh = location.hash || '#/', m, h, tab = '';
    if ((m = hsh.match(/^#\/part\/(\d+)/))) { h = vPart(+m[1]); tab = 'parts'; }
    else if ((m = hsh.match(/^#\/ch\/(\d+)/))) { h = vChapter(+m[1]); tab = 'parts'; }
    else if (hsh.indexOf('#/parts') === 0) { h = vParts(); tab = 'parts'; }
    else if (hsh.indexOf('#/search') === 0) { h = vSearch(); tab = 'search'; }
    else if (hsh.indexOf('#/saved') === 0) { h = vSaved(); tab = 'saved'; }
    else if (hsh.indexOf('#/practice/') === 0) { Q.mode = hsh.split('/')[2]; h = vQuiz(); tab = 'practice'; }
    else if (hsh.indexOf('#/practice') === 0) { h = vPractice(); tab = 'practice'; }
    else if (hsh.indexOf('#/guide') === 0) { h = vGuide(); tab = 'home'; }
    else if (hsh.indexOf('#/about') === 0) { h = vAbout(); tab = 'home'; }
    else { h = vHome(); tab = 'home'; }
    app.innerHTML = h;
    document.querySelectorAll('.nav button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === tab); });
    window.scrollTo(0, 0);
    if (tab === 'search') { var q = $('#q'); if (lastQ) runSearch(); q.addEventListener('input', function () { clearTimeout(runSearch.t); runSearch.t = setTimeout(runSearch, 200); }); if (!lastQ) setTimeout(function () { q.focus(); }, 150); }
    if (Q.mode === 'listen' && hsh.indexOf('#/practice/listen') === 0) setTimeout(function () { speak(Q.cur.r[0], S.set.accent); }, 350);
  }
  function go(h) { if (location.hash === h) route(); else location.hash = h; }
  window.addEventListener('hashchange', route);

  /* ---------------- events ---------------- */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-go],[data-act],[data-lv],[data-say],[data-q],[data-mode],[data-q2],[data-ans],[data-tab],[data-set]');
    if (!t) return;
    var g = t.getAttribute('data-go'); if (g) { go(g); return; }
    if (t.hasAttribute('data-tab')) { go(t.getAttribute('data-tab-href')); return; }
    if (t.hasAttribute('data-say')) { var x0 = BYID[t.getAttribute('data-say')]; stopSpeak(); speak(x0.r[0], S.set.accent); return; }
    if (t.hasAttribute('data-q')) { $('#q').value = t.getAttribute('data-q'); runSearch(); return; }
    if (t.hasAttribute('data-lv')) { lvFilter = +t.getAttribute('data-lv'); var c = CH[S.last]; $('#list').innerHTML = chapterList(c); document.querySelectorAll('[data-lv]').forEach(function (b) { b.classList.toggle('on', +b.getAttribute('data-lv') === lvFilter); }); return; }
    if (t.hasAttribute('data-mode')) { Q.part = +$('#qpart').value; Q.ok = Q.no = 0; go('#/practice/' + t.getAttribute('data-mode')); return; }
    if (t.hasAttribute('data-set')) { setOpt(t.getAttribute('data-set'), t.getAttribute('data-v')); return; }
    if (t.hasAttribute('data-q2')) {
      var a = t.getAttribute('data-q2');
      if (a === 'next') { stopSpeak(); app.innerHTML = vQuiz(); window.scrollTo(0, 0); if (Q.mode === 'listen') setTimeout(function () { speak(Q.cur.r[0], S.set.accent); }, 250); }
      else if (a === 'reset') { Q.ok = Q.no = 0; app.innerHTML = vQuiz(); }
      else if (a === 'hear') { stopSpeak(); speak(Q.cur.r[0], S.set.accent); }
      else if (a === 'show') { $('#rv').innerHTML = revealHTML(Q.cur); $('#fbtn').innerHTML = '<button class="btn r" data-q2="miss">✘ नहीं आया</button><button class="btn g" data-q2="got">✔ सही बोला</button>'; speak(Q.cur.r[0], S.set.accent); }
      else if (a === 'got' || a === 'miss') { if (a === 'got') Q.ok++; else Q.no++; app.innerHTML = vQuiz(); window.scrollTo(0, 0); }
      return;
    }
    if (t.hasAttribute('data-ans')) {
      if (Q.answered) return; Q.answered = true;
      var ans = t.getAttribute('data-ans'), ok = ans === Q.right;
      if (ok) Q.ok++; else Q.no++;
      document.querySelectorAll('.opt').forEach(function (b) { var v = b.getAttribute('data-ans'); if (v === Q.right) b.classList.add('right'); else if (b === t) b.classList.add('wrong'); });
      $('.score').innerHTML = '<span class="ok">✔ ' + Q.ok + '</span><span class="no2">✘ ' + Q.no + '</span>';
      $('#rv').innerHTML = '<div class="fb" style="color:' + (ok ? '#2E7D32' : '#C62828') + '">' + (ok ? '🎉 शाबाश! सही उत्तर।' : '🙂 कोई बात नहीं — सही उत्तर हरे रंग में है।') + '</div>' + revealHTML(Q.cur);
      return;
    }
    var act = t.getAttribute('data-act'), cardEl = t.closest('.card'), x = cardEl ? BYID[cardEl.getAttribute('data-id')] : null;
    switch (act) {
      case 'back': if (history.length > 1) history.back(); else go('#/'); break;
      case 'settings': openSheet(); break;
      case 'closesheet': closeSheet(); break;
      case 'say': stopSpeak(); speak(x.r[0], S.set.accent); break;
      case 'sayhi': stopSpeak(); speak(x.r[1], 'hi-IN'); break;
      case 'unblur': t.classList.remove('blur'); break;
      case 'star':
        var i = S.saved.indexOf(x.id);
        if (i >= 0) { S.saved.splice(i, 1); t.classList.remove('on'); t.textContent = '☆'; toast('सहेजे वाक्यों से हटाया'); }
        else { S.saved.unshift(x.id); t.classList.add('on'); t.textContent = '★'; toast('⭐ वाक्य सहेजा गया'); }
        save('saved', S.saved); break;
      case 'copy':
        var txt = x.r[0] + '\n' + x.r[1];
        try { navigator.clipboard.writeText(txt).then(function () { toast('📋 कॉपी हो गया'); }, function () { fallbackCopy(txt); }); } catch (er) { fallbackCopy(txt); }
        break;
      case 'playall': playAll(); break;
      case 'togglehi': S.set.hideHi = !S.set.hideHi; save('set', S.set); route(); toast(S.set.hideHi ? 'हिंदी छुपी — अभ्यास के लिए हिंदी पर टैप करें' : 'हिंदी अर्थ दिख रहे हैं'); break;
      case 'clearq': $('#q').value = ''; lastQ = ''; $('#res').innerHTML = ''; $('#q').focus(); break;
      case 'newday': var dd = rnd(ALL); var box = t.closest('.daily'); box.querySelector('.de').textContent = dd.r[0]; box.querySelector('.dh').textContent = dd.r[1];
        box.querySelector('[data-say]').setAttribute('data-say', dd.id); box.querySelector('[data-go]').setAttribute('data-go', '#/ch/' + dd.c); break;
    }
  });
  function fallbackCopy(t) { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); toast('📋 कॉपी हो गया'); } catch (e) { toast('कॉपी नहीं हो सका'); } ta.remove(); }

  /* ---------------- settings sheet ---------------- */
  function seg(key, list) { return '<div class="seg">' + list.map(function (o) { return '<button data-set="' + key + '" data-v="' + o[0] + '" class="' + (String(S.set[key]) === String(o[0]) ? 'on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function sheetHTML() {
    return '<div class="grab"></div><h3>⚙️ सेटिंग · Settings</h3>' +
      '<div class="srow"><span>अक्षर का आकार</span>' + seg('fs', [[14, 'छोटा'], [16, 'सामान्य'], [18, 'बड़ा'], [20, 'बहुत बड़ा']]) + '</div>' +
      '<div class="srow"><span>बोलने की गति</span>' + seg('rate', [[0.65, 'धीमी'], [0.85, 'सामान्य'], [1, 'तेज़']]) + '</div>' +
      '<div class="srow"><span>अंग्रेज़ी उच्चारण</span>' + seg('accent', [['en-IN', 'Indian'], ['en-US', 'US'], ['en-GB', 'UK']]) + '</div>' +
      '<div class="srow"><span>"सभी सुनें" में हिंदी भी</span>' + seg('autoHi', [[true, 'हाँ'], [false, 'नहीं']]) + '</div>' +
      '<div class="srow"><span>थीम</span>' + seg('theme', [['light', '☀️ दिन'], ['dark', '🌙 रात']]) + '</div>' +
      '<div class="btnrow"><button class="btn" data-act="closesheet">ठीक है</button></div>';
  }
  function openSheet() { $('#sheet').innerHTML = sheetHTML(); $('#sheet').classList.add('on'); $('#shade').classList.add('on'); }
  function closeSheet() { $('#sheet').classList.remove('on'); $('#shade').classList.remove('on'); }
  function setOpt(k, v) {
    if (k === 'fs') v = +v; else if (k === 'rate') v = parseFloat(v); else if (k === 'autoHi') v = v === 'true';
    S.set[k] = v; save('set', S.set); applySettings(); $('#sheet').innerHTML = sheetHTML();
    if (k === 'rate' || k === 'accent') { stopSpeak(); speak('Hello! Welcome to Spoken Sentences.', S.set.accent); }
  }
  $('#shade').addEventListener('click', closeSheet);

  /* ---------------- start ---------------- */
  document.querySelectorAll('.nav button').forEach(function (b) { b.setAttribute('data-tab-href', b.getAttribute('data-href')); });
  route();
  setTimeout(function () { var s = $('#splash'); s.classList.add('hide'); setTimeout(function () { s.remove(); }, 500); }, 1100);
  if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) { try { navigator.serviceWorker.register('sw.js'); } catch (e) { } }
})();
