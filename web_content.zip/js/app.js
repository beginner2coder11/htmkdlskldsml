  let SESION = null;
  let IDS_MENU_MAS = [];

  const MODULOS_NAV = [
    { id: 'dashboard', icono: '🏠', etiqueta: 'Dashboard' },
    { id: 'traslados', icono: '🚑', etiqueta: 'Traslados' },
    { id: 'aceptaciones', icono: '✅', etiqueta: 'Aceptaciones' },
    { id: 'pases', icono: '🖨️', etiqueta: 'Pases de traslados' },
    { id: 'ubicaciones', icono: '📍', etiqueta: 'Ubicaciones' },
    { id: 'calendario', icono: '📅', etiqueta: 'Calendario' },
    { id: 'pacientes', icono: '👤', etiqueta: 'Pacientes' },
    { id: 'instituciones', icono: '🏥', etiqueta: 'Instituciones' },
    { id: 'vehiculos', icono: '🚗', etiqueta: 'Vehículos' },
    { id: 'conductores', icono: '🧑‍✈️', etiqueta: 'Conductores' },
    { id: 'reportes', icono: '📊', etiqueta: 'Reportes' },
    { id: 'usuarios', icono: '👥', etiqueta: 'Usuarios' }
  ];

  // En móvil solo caben cómodamente 3 accesos directos; el resto va en "Más".
  const MAX_ITEMS_NAV_MOVIL = 3;

  document.addEventListener('DOMContentLoaded', function () {
    if (!obtenerTokenGuardado()) {
      mostrarPantallaLogin();
      return;
    }
    google.script.run
      .withSuccessHandler(iniciarApp)
      .withFailureHandler(function (error) {
        borrarTokenGuardado();
        mostrarPantallaLogin(error.message);
      })
      .obtenerSesion();
  });

  function mostrarPantallaLogin(mensajeError) {
    document.getElementById('app').innerHTML =
      '<div id="pantalla-login">' +
        '<div id="tarjeta-login" class="tarjeta">' +
          '<div style="text-align:center; margin-bottom:16px;">' +
            '<div style="font-size:36px;">🚑</div>' +
            '<h2 style="margin:8px 0 0;">Traslados SVT</h2>' +
            '<div style="font-size:12.5px; color:var(--gris); margin-top:2px;">Panel interno</div>' +
          '</div>' +
          (mensajeError ? '<div style="background:var(--rojo-suave); color:var(--rojo); padding:10px 12px; border-radius:8px; font-size:13px; margin-bottom:12px;">' + escaparHtml(mensajeError) + '</div>' : '') +
          '<label style="display:block; font-size:13px; margin-bottom:4px;">Usuario</label>' +
          '<input type="text" id="login-usuario" style="width:100%; margin-bottom:10px;" autocomplete="username">' +
          '<label style="display:block; font-size:13px; margin-bottom:4px;">Contraseña</label>' +
          '<input type="password" id="login-password" style="width:100%; margin-bottom:12px;" autocomplete="current-password" onkeydown="if(event.key===\'Enter\') intentarLogin()">' +
          '<div class="fila-recordarme">' +
            '<input type="checkbox" id="login-recordarme">' +
            '<label for="login-recordarme">Mantener mi sesión iniciada en este dispositivo</label>' +
          '</div>' +
          '<button class="primario" style="width:100%; padding:12px;" onclick="intentarLogin()">Entrar</button>' +
        '</div>' +
      '</div>';
    document.getElementById('login-usuario').focus();
  }

  function intentarLogin() {
    const usuario = document.getElementById('login-usuario').value.trim();
    const password = document.getElementById('login-password').value;
    const recordarme = document.getElementById('login-recordarme').checked;
    if (!usuario || !password) { alert('Escribe tu usuario y contraseña.'); return; }

    const boton = document.querySelector('#tarjeta-login button.primario');
    boton.disabled = true;
    boton.textContent = 'Entrando...';

    google.script.run
      .withSuccessHandler(function (sesion) {
        guardarToken(sesion.token);
        iniciarApp(sesion);
      })
      .withFailureHandler(function (error) {
        mostrarPantallaLogin(error.message);
      })
      .iniciarSesion(usuario, password, recordarme);
  }

  function cerrarSesionApp() {
    if (typeof detenerPollingUbicaciones === 'function') detenerPollingUbicaciones();
    google.script.run.cerrarSesion(obtenerTokenGuardado());
    borrarTokenGuardado();
    mostrarPantallaLogin();
  }

  function mostrarErrorSesion(error) {
    document.getElementById('app').innerHTML =
      '<div id="pantalla-carga">🔒 ' + escaparHtml(error.message) + '</div>';
  }

  function iniciales(nombre) {
    if (!nombre) return '?';
    const partes = nombre.trim().split(/\s+/);
    return (partes[0][0] + (partes[1] ? partes[1][0] : '')).toUpperCase();
  }

  function iniciarApp(sesion) {
    SESION = sesion;
    const app = document.getElementById('app');

    const modulosVisibles = MODULOS_NAV.filter(function (m) {
      return SESION.permisos[m.id] !== false;
    });

    const modulosNavMovil = modulosVisibles.slice(0, MAX_ITEMS_NAV_MOVIL);
    const modulosMenuMas = modulosVisibles.slice(MAX_ITEMS_NAV_MOVIL);
    IDS_MENU_MAS = modulosMenuMas.map(function (m) { return m.id; });

    app.innerHTML =
      '<div id="app-layout">' +
        '<nav id="nav-lateral">' +
          modulosVisibles.map(function (m) {
            return '<a class="item-nav" data-modulo="' + m.id + '" onclick="navegarA(\'' + m.id + '\')">' +
              '<span>' + m.icono + '</span><span>' + m.etiqueta + '</span></a>';
          }).join('') +
        '</nav>' +
        '<div id="zona-central">' +
          '<div id="barra-superior">' +
            '<div class="titulo-app">🚑 Traslados SVT</div>' +
            '<div class="usuario-chip">' +
              '<span class="texto-usuario">' + escaparHtml(SESION.nombre || SESION.correo) + ' · ' + escaparHtml(SESION.rol) + '</span>' +
              '<div class="avatar" title="Cerrar sesión" style="cursor:pointer;" onclick="cerrarSesionApp()">' + iniciales(SESION.nombre || SESION.correo) + '</div>' +
            '</div>' +
          '</div>' +
          '<main id="contenido-principal"></main>' +
        '</div>' +
      '</div>' +
      '<nav id="nav-movil">' +
        modulosNavMovil.map(function (m) {
          return '<a data-modulo="' + m.id + '" onclick="navegarA(\'' + m.id + '\')">' +
            '<span class="icono-nav">' + m.icono + '</span><span>' + m.etiqueta + '</span></a>';
        }).join('') +
        (modulosMenuMas.length
          ? '<a data-modulo="__mas__" onclick="abrirMenuMas()"><span class="icono-nav">⋯</span><span>Más</span></a>'
          : '') +
      '</nav>' +
      '<div id="fondo-menu-mas" onclick="cerrarMenuMasSiEsFondo(event)">' +
        '<div id="panel-menu-mas">' +
          '<div class="manija"></div>' +
          modulosMenuMas.map(function (m) {
            return '<div class="item-menu-mas" onclick="navegarDesdeMenuMas(\'' + m.id + '\')">' +
              '<span class="icono-nav">' + m.icono + '</span><span>' + m.etiqueta + '</span></div>';
          }).join('') +
        '</div>' +
      '</div>';

    // Vista inicial: Conductor entra directo a "sus" traslados; el resto al dashboard.
    navegarA(SESION.rol === 'Conductor' ? 'traslados' : (modulosVisibles[0] ? modulosVisibles[0].id : 'traslados'));
  }

  function abrirMenuMas() {
    document.getElementById('fondo-menu-mas').classList.add('abierto');
  }
  function cerrarMenuMas() {
    document.getElementById('fondo-menu-mas').classList.remove('abierto');
  }
  function cerrarMenuMasSiEsFondo(evento) {
    if (evento.target.id === 'fondo-menu-mas') cerrarMenuMas();
  }
  function navegarDesdeMenuMas(modulo) {
    cerrarMenuMas();
    // El botón "Más" en sí no debe marcarse como activo para módulos internos,
    // pero sí resaltamos el ítem correspondiente si existiera en la barra.
    navegarA(modulo);
  }

  function navegarA(modulo) {
    // Si salimos de la vista de ubicaciones, detenemos su actualización automática.
    if (typeof detenerPollingUbicaciones === 'function' && modulo !== 'ubicaciones') {
      detenerPollingUbicaciones();
    }
    // Igual para el Dashboard: solo debe seguir consultando solicitudes
    // pendientes mientras el usuario lo tiene abierto.
    if (typeof detenerPollingDashboard === 'function' && modulo !== 'dashboard') {
      detenerPollingDashboard();
    }
    document.querySelectorAll('#nav-lateral .item-nav, #nav-movil a').forEach(function (el) {
      el.classList.toggle('activo', el.dataset.modulo === modulo);
    });
    const botonMas = document.querySelector('#nav-movil a[data-modulo="__mas__"]');
    if (botonMas && IDS_MENU_MAS.indexOf(modulo) !== -1) {
      botonMas.classList.add('activo');
    }
    // Sube el scroll al cambiar de módulo, para no dejar al usuario a media pantalla.
    window.scrollTo(0, 0);

    if (modulo === 'dashboard') {
      cargarVistaDashboard();
    } else if (modulo === 'traslados') {
      cargarVistaTraslados();
    } else if (modulo === 'aceptaciones') {
      cargarVistaAceptaciones();
    } else if (modulo === 'pases') {
      cargarVistaPases();
    } else if (modulo === 'ubicaciones') {
      cargarVistaUbicaciones();
    } else if (modulo === 'nuevo-traslado') {
      cargarVistaNuevoTraslado();
    } else if (modulo === 'pacientes') {
      cargarVistaPacientes();
    } else if (modulo === 'instituciones') {
      cargarVistaInstituciones();
    } else if (modulo === 'vehiculos') {
      cargarVistaVehiculos();
    } else if (modulo === 'conductores') {
      cargarVistaConductores();
    } else if (modulo === 'reportes') {
      cargarVistaReportes();
    } else if (modulo === 'usuarios') {
      cargarVistaUsuarios();
    } else if (modulo === 'calendario') {
      cargarVistaCalendario();
    } else {
      document.getElementById('contenido-principal').innerHTML =
        '<p>Módulo "' + modulo + '" pendiente de construir.</p>';
    }
  }

  function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto == null ? '' : texto;
    return div.innerHTML;
  }

  const COLOR_POR_ESTADO = {
    'Solicitud recibida': 'gris', 'Pendiente de autorización': 'gris',
    'Autorizado': 'azul', 'Programado': 'azul', 'Vehículo asignado': 'azul',
    'En traslado': 'ambar', 'Regresando': 'ambar',
    'En destino': 'verde', 'Finalizado': 'verde',
    'Cancelado': 'rojo', 'Paciente no se presentó': 'rojo',
    'Reprogramado': 'morado'
  };
