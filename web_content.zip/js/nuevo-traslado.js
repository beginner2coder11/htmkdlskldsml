  function cargarVistaNuevoTraslado() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML = '<p>Cargando catálogos...</p>';

    // Necesitamos pacientes e instituciones cargados antes de mostrar el formulario.
    Promise.all([
      new Promise(function (resolve, reject) {
        google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).listarPacientes('');
      }),
      new Promise(function (resolve, reject) {
        google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).listarInstituciones('');
      })
    ]).then(function (resultados) {
      renderizarFormularioNuevoTraslado(resultados[0], resultados[1]);
    }).catch(function (error) {
      contenedor.innerHTML = '<p>Error al cargar catálogos: ' + escaparHtml(error.message) + '</p>';
    });
  }

  function renderizarFormularioNuevoTraslado(pacientes, instituciones) {
    if (!pacientes.length) {
      document.getElementById('contenido-principal').innerHTML =
        '<div class="tarjeta"><p>Todavía no hay pacientes registrados. Registra al menos uno antes de crear un traslado.</p>' +
        '<button class="primario" onclick="navegarA(\'pacientes\')">Ir a Pacientes</button></div>';
      return;
    }
    if (!instituciones.length) {
      document.getElementById('contenido-principal').innerHTML =
        '<div class="tarjeta"><p>Todavía no hay instituciones registradas. Registra al menos una antes de crear un traslado.</p>' +
        '<button class="primario" onclick="navegarA(\'instituciones\')">Ir a Instituciones</button></div>';
      return;
    }

    const opcionesPacientes = pacientes.map(function (p) {
      return '<option value="' + p.id_paciente + '">' + escaparHtml(p.nombre_completo) + (p.comunidad ? ' — ' + escaparHtml(p.comunidad) : '') + '</option>';
    }).join('');

    const opcionesInstituciones = instituciones.map(function (i) {
      return '<option value="' + i.id_institucion + '">' + escaparHtml(i.nombre) + (i.ciudad ? ' — ' + escaparHtml(i.ciudad) : '') + '</option>';
    }).join('');

    const html =
      '<h2>Nuevo traslado</h2>' +

      '<div class="tarjeta">' +
        '<h3>1. Información del paciente</h3>' +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Paciente</label>' +
          '<select id="nt-paciente" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' +
            '<option value="">Selecciona un paciente...</option>' + opcionesPacientes +
          '</select></div>' +
        '<button onclick="navegarA(\'pacientes\')" style="font-size:13px;">+ Registrar paciente nuevo</button>' +
        campoTexto('nt-acompanante-nombre', 'Acompañante (nombre)', '') +
        campoTexto('nt-acompanante-telefono', 'Acompañante (teléfono)', '') +
        campoTexto('nt-acompanante-parentesco', 'Parentesco', '') +
        campoTexto('nt-num-acompanantes', 'Número de acompañantes', '') +
      '</div>' +

      '<div class="tarjeta">' +
        '<h3>2. Información de la cita</h3>' +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Institución médica</label>' +
          '<select id="nt-institucion" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' +
            '<option value="">Selecciona una institución...</option>' + opcionesInstituciones +
          '</select></div>' +
        campoTexto('nt-especialidad', 'Especialidad', '') +
        campoSelect('nt-tipo-cita', 'Tipo de cita', ['Primera vez', 'Seguimiento', 'Urgencia'], '', true) +
        campoFecha('nt-fecha-cita', 'Fecha de la cita', '') +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Hora de la cita</label>' +
          '<input type="time" id="nt-hora-cita" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;"></div>' +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Fecha y hora programada de salida</label>' +
          '<input type="datetime-local" id="nt-salida-programada" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;"></div>' +
      '</div>' +

      '<div class="tarjeta">' +
        '<h3>3. Información del traslado</h3>' +
        campoTextarea('nt-motivo', 'Motivo del traslado', '') +
        campoSelect('nt-tipo-traslado', 'Tipo de traslado', ['Programado', 'Urgente'], '', true) +
        campoSelect('nt-prioridad', 'Prioridad', ['Alta', 'Media', 'Baja'], '', true) +
        '<label style="display:flex; align-items:center; gap:6px; font-size:14px; margin-top:8px;">' +
          '<input type="checkbox" id="nt-consentimiento"> Se cuenta con consentimiento informado' +
        '</label>' +
      '</div>' +

      '<div class="tarjeta">' +
        '<h3>4. Observaciones</h3>' +
        campoTextarea('nt-observaciones', '', '') +
      '</div>' +

      '<div style="margin: 12px 0 40px;">' +
        '<button class="primario" onclick="guardarNuevoTraslado()">Crear traslado</button> ' +
        '<button onclick="navegarA(\'traslados\')">Cancelar</button>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarNuevoTraslado() {
    const idPaciente = document.getElementById('nt-paciente').value;
    const idInstitucion = document.getElementById('nt-institucion').value;
    const fechaCita = document.getElementById('nt-fecha-cita').value;

    if (!idPaciente) { alert('Selecciona un paciente.'); return; }
    if (!idInstitucion) { alert('Selecciona una institución.'); return; }
    if (!fechaCita) { alert('Indica la fecha de la cita.'); return; }

    const datos = {
      id_paciente: idPaciente,
      acompanante_nombre: document.getElementById('nt-acompanante-nombre').value,
      acompanante_telefono: document.getElementById('nt-acompanante-telefono').value,
      acompanante_parentesco: document.getElementById('nt-acompanante-parentesco').value,
      numero_acompanantes: document.getElementById('nt-num-acompanantes').value,
      id_institucion: idInstitucion,
      especialidad: document.getElementById('nt-especialidad').value,
      tipo_cita: document.getElementById('nt-tipo-cita').value,
      fecha_cita: fechaCita,
      hora_cita: document.getElementById('nt-hora-cita').value,
      fecha_hora_salida_programada: document.getElementById('nt-salida-programada').value,
      motivo_traslado: document.getElementById('nt-motivo').value,
      tipo_traslado: document.getElementById('nt-tipo-traslado').value,
      prioridad: document.getElementById('nt-prioridad').value,
      consentimiento_informado: document.getElementById('nt-consentimiento').checked,
      fecha_solicitud: new Date().toISOString().substring(0, 10),
      observaciones: document.getElementById('nt-observaciones').value
    };

    google.script.run
      .withSuccessHandler(function (folio) {
        alert('Traslado creado con folio ' + folio);
        navegarA('traslados');
      })
      .withFailureHandler(function (error) { alert(error.message); })
      .crearTraslado(datos);
  }
