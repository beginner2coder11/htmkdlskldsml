  function cargarVistaReportes() {
    const tiposReporte = {
      traslados_realizados: 'Traslados realizados',
      traslados_cancelados: 'Traslados cancelados',
      pacientes_transportados: 'Pacientes transportados',
      por_institucion: 'Traslados por institución',
      por_conductor: 'Traslados por conductor'
    };

    const opciones = Object.keys(tiposReporte).map(function (clave) {
      return '<option value="' + clave + '">' + tiposReporte[clave] + '</option>';
    }).join('');

    document.getElementById('contenido-principal').innerHTML =
      '<h2>Reportes</h2>' +
      '<div class="tarjeta">' +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Tipo de reporte</label>' +
          '<select id="rp-tipo" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' + opciones + '</select></div>' +
        campoFecha('rp-desde', 'Desde', '') +
        campoFecha('rp-hasta', 'Hasta', '') +
        '<button class="primario" onclick="generarVistaPreviaReporte()">Generar</button>' +
      '</div>' +
      '<div id="rp-resultado"></div>';
  }

  function filtrosReporteActuales() {
    return {
      fechaDesde: document.getElementById('rp-desde').value,
      fechaHasta: document.getElementById('rp-hasta').value
    };
  }

  function generarVistaPreviaReporte() {
    const tipo = document.getElementById('rp-tipo').value;
    const resultado = document.getElementById('rp-resultado');
    resultado.innerHTML = '<p>Generando...</p>';

    google.script.run
      .withSuccessHandler(function (datos) { renderizarVistaPreviaReporte(tipo, datos); })
      .withFailureHandler(function (error) { resultado.innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>'; })
      .generarReporte(tipo, filtrosReporteActuales());
  }

  function renderizarVistaPreviaReporte(tipo, datos) {
    if (!datos.filas.length) {
      document.getElementById('rp-resultado').innerHTML = '<p style="color:var(--gris);">No hay datos para los filtros seleccionados.</p>';
      return;
    }

    const encabezado = '<tr>' + datos.columnas.map(function (c) { return '<th style="text-align:left; padding:6px; border-bottom:1px solid var(--color-borde); font-size:12px;">' + escaparHtml(c) + '</th>'; }).join('') + '</tr>';
    const filas = datos.filas.map(function (fila) {
      return '<tr>' + fila.map(function (valor) { return '<td style="padding:6px; border-bottom:1px solid var(--color-borde); font-size:13px;">' + escaparHtml(String(valor)) + '</td>'; }).join('') + '</tr>';
    }).join('');

    document.getElementById('rp-resultado').innerHTML =
      '<div class="tarjeta" style="overflow-x:auto;">' +
        '<table style="width:100%; border-collapse:collapse;">' + encabezado + filas + '</table>' +
      '</div>' +
      '<div style="margin-bottom:24px;">' +
        '<button class="primario" onclick="exportarReporteActual(\'' + tipo + '\', \'pdf\')">Exportar PDF</button> ' +
        '<button class="primario" onclick="exportarReporteActual(\'' + tipo + '\', \'xlsx\')">Exportar Excel</button>' +
      '</div>';
  }

  function exportarReporteActual(tipo, formato) {
    google.script.run
      .withSuccessHandler(function (archivo) { descargarArchivoBase64(archivo); })
      .withFailureHandler(function (error) { alert('Error al exportar: ' + error.message); })
      .exportarReporte(tipo, filtrosReporteActuales(), formato);
  }

  function descargarArchivoBase64(archivo) {
    const enlace = document.createElement('a');
    enlace.href = 'data:' + archivo.mimeType + ';base64,' + archivo.base64;
    enlace.download = archivo.nombreArchivo;
    document.body.appendChild(enlace);
    enlace.click();
    document.body.removeChild(enlace);
  }
