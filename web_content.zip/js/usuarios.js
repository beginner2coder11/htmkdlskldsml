  function cargarVistaUsuarios() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Usuarios</h2>' +
        '<button class="primario" onclick="mostrarFormularioUsuario()">+ Nuevo usuario</button>' +
      '</div>' +
      '<div id="lista-usuarios">Cargando...</div>';

    google.script.run
      .withSuccessHandler(renderizarListaUsuarios)
      .withFailureHandler(function (error) { document.getElementById('lista-usuarios').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>'; })
      .listarUsuarios();
  }

  function renderizarListaUsuarios(usuarios) {
    const contenedor = document.getElementById('lista-usuarios');
    if (!usuarios.length) { contenedor.innerHTML = '<p>No hay usuarios registrados.</p>'; return; }
    contenedor.innerHTML = usuarios.map(function (u) {
      return (
        '<div class="tarjeta" style="cursor:pointer;" onclick="mostrarFormularioUsuario(\'' + u.id_usuario + '\')">' +
          '<div style="display:flex; justify-content:space-between;">' +
            '<strong>' + escaparHtml(u.nombre_completo || u.correo_google) + '</strong>' +
            '<span class="badge-estado badge-' + (u.activo ? 'verde' : 'rojo') + '">' + (u.activo ? 'Activo' : 'Inactivo') + '</span>' +
          '</div>' +
          '<div style="font-size:13px; color:var(--gris);">' + escaparHtml(u.correo_google) + ' · ' + escaparHtml(u.rol) + '</div>' +
        '</div>'
      );
    }).join('');
  }

  function mostrarFormularioUsuario(idUsuario) {
    if (idUsuario) {
      google.script.run.withSuccessHandler(function (usuario) { renderizarFormularioUsuario(idUsuario, usuario); }).withFailureHandler(function (e) { alert(e.message); }).obtenerUsuario(idUsuario);
    } else {
      renderizarFormularioUsuario(null, null);
    }
  }

  function renderizarFormularioUsuario(idUsuario, usuario) {
    const esEdicion = !!idUsuario;
    usuario = usuario || {};

    const roles = ['Administrador', 'Coordinador', 'Conductor', 'Consulta'];

    const html =
      '<div class="tarjeta">' +
        '<h3>' + (esEdicion ? 'Editar usuario' : 'Nuevo usuario') + '</h3>' +
        (esEdicion
          ? '<p style="font-size:13px; color:var(--gris);">Usuario: ' + escaparHtml(usuario.correo_google) + ' (no editable)</p>'
          : campoTexto('uf-correo', 'Usuario (para iniciar sesión)', '')) +
        campoTexto('uf-nombre', 'Nombre completo', usuario.nombre_completo) +
        campoSelect('uf-rol', 'Rol', roles, usuario.rol) +
        campoTexto('uf-password', esEdicion ? 'Nueva contraseña (déjalo vacío para no cambiarla)' : 'Contraseña inicial', '') +
        '<label style="display:flex; align-items:center; gap:6px; font-size:14px; margin-top:8px;">' +
          '<input type="checkbox" id="uf-activo" ' + (usuario.activo !== false ? 'checked' : '') + '> Activo' +
        '</label>' +
        campoTextarea('uf-observaciones', 'Observaciones', usuario.observaciones) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarUsuario(' + (esEdicion ? "'" + idUsuario + "'" : 'null') + ')">Guardar</button> ' +
          '<button onclick="cargarVistaUsuarios()">Cancelar</button>' +
        '</div>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarUsuario(idUsuario) {
    const datos = {
      nombre_completo: document.getElementById('uf-nombre').value,
      rol: document.getElementById('uf-rol').value,
      activo: document.getElementById('uf-activo').checked,
      observaciones: document.getElementById('uf-observaciones').value
    };
    const password = document.getElementById('uf-password').value;
    if (password) datos.password = password;

    if (idUsuario) {
      google.script.run.withSuccessHandler(function () { cargarVistaUsuarios(); }).withFailureHandler(function (e) { alert(e.message); }).actualizarUsuario(idUsuario, datos);
    } else {
      datos.correo_google = document.getElementById('uf-correo').value;
      if (!datos.correo_google) { alert('Falta el usuario para iniciar sesión.'); return; }
      if (!datos.password) { alert('Define una contraseña inicial.'); return; }
      google.script.run.withSuccessHandler(function () { cargarVistaUsuarios(); }).withFailureHandler(function (e) { alert(e.message); }).crearUsuario(datos);
    }
  }
