// Número de WhatsApp de la coordinadora del servicio (formato
// internacional, sin "+" ni espacios): al tocar "Compartir por WhatsApp"
// en la confirmación, se abre el chat directo con este número, con el
// folio ya escrito, en vez de dejar elegir un contacto cualquiera.
const NUMERO_WHATSAPP_COORDINADORA = '524891286539';

document.addEventListener('DOMContentLoaded', cargarFormularioPublico);

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : texto;
  return div.innerHTML;
}

// Contenido de los avisos: se muestran en una ventana emergente al tocar
// el hipervínculo correspondiente dentro del texto de la casilla (en vez
// de una sección aparte con acordeones).
const AVISOS_IMPORTANTES = [
  {
    slug: 'servicio',
    titulo: 'Aviso sobre el Servicio de Traslado',
    texto: 'Este servicio está destinado exclusivamente a traslados programados relacionados con citas, consultas, estudios o servicios médicos previamente solicitados.\n\n' +
      'El servicio de traslado no es un servicio de ambulancia y no proporciona atención médica, atención prehospitalaria ni atención de urgencias.\n\n' +
      'El personal encargado del traslado no sustituye al personal médico ni a los servicios de emergencia.\n\n' +
      'Si antes o durante el traslado el usuario presenta una situación que pueda poner en riesgo su vida o su integridad física, deberá solicitarse atención de emergencia a través del 911 o acudir al servicio de urgencias más cercano.'
  },
  {
    slug: 'disponibilidad',
    titulo: 'Aviso de Solicitud y Disponibilidad',
    texto: 'El envío de este formulario constituye únicamente una solicitud de traslado y no significa que el servicio haya sido confirmado.\n\n' +
      'Toda solicitud será revisada y estará sujeta a la disponibilidad de vehículo, personal, horarios y condiciones necesarias para realizar el traslado.\n\n' +
      'El traslado se considerará confirmado únicamente cuando la persona responsable del servicio lo haya autorizado y comunicado al solicitante.\n\n' +
      'Se recomienda realizar la solicitud con la mayor anticipación posible y proporcionar información correcta sobre la fecha y hora de la cita.'
  },
  {
    slug: 'consentimiento',
    titulo: 'Consentimiento y Autorización para Traslado',
    texto: 'Al solicitar el servicio, el usuario manifiesta que solicita voluntariamente el traslado y que la información proporcionada para su coordinación es correcta.\n\n' +
      'El usuario declara que ha tenido la oportunidad de conocer las condiciones del servicio y que comprende que se trata de un servicio de traslado y no de atención médica de urgencias.\n\n' +
      'La aceptación realizada mediante el formulario será registrada electrónicamente junto con los datos necesarios para identificar la solicitud, incluyendo, cuando corresponda, fecha y hora de la aceptación.\n\n' +
      'La persona responsable del servicio podrá revisar y autorizar la solicitud antes de que el traslado sea realizado.'
  },
  {
    slug: 'privacidad',
    titulo: 'Aviso de Privacidad',
    texto: 'La Lic. en Enf. y Obst. María Guadalupe Aradillas del Ángel, como responsable del tratamiento de los datos personales, utilizará la información proporcionada para recibir, registrar, programar, coordinar, autorizar, realizar y dar seguimiento al servicio de traslado solicitado.\n\n' +
      'Los datos que podrán solicitarse incluyen, entre otros: nombre completo, teléfono de contacto, comunidad/localidad/colonia, información del acompañante, institución médica, especialidad, fecha y hora de la cita y demás información necesaria para coordinar el servicio.\n\n' +
      'Cuando el usuario proporcione información relacionada con su estado de salud, ésta podrá constituir información personal sensible y será utilizada únicamente en la medida necesaria para las finalidades relacionadas con la coordinación, seguridad y prestación del servicio.\n\n' +
      'Los datos personales serán tratados con medidas razonables de seguridad y no deberán utilizarse para finalidades ajenas a las informadas en este aviso, salvo que exista una obligación o autorización legal que permita hacerlo.\n\n' +
      'El titular de los datos podrá solicitar información sobre el tratamiento de sus datos y, cuando corresponda, ejercer sus derechos de Acceso, Rectificación, Cancelación u Oposición (ARCO) mediante los medios de contacto establecidos por la responsable.\n\n' +
      'Responsable: Lic. en Enf. y Obst. María Guadalupe Aradillas del Ángel\n\n' +
      'Medio de contacto para asuntos de privacidad:\nTeléfono: 489 177 9160\nCorreo electrónico: acc26ting@gmail.com\n\n' +
      'Última actualización: 08/09/2026'
  },
  {
    slug: 'acompanante',
    titulo: 'Información del Acompañante',
    texto: 'Cuando el solicitante proporcione datos personales de un acompañante, declara que cuenta con autorización para proporcionar dichos datos para efectos de la coordinación y prestación del traslado.\n\n' +
      'La información del acompañante será utilizada únicamente para las finalidades relacionadas con el servicio solicitado.'
  }
];

function buscarAviso(slug) {
  return AVISOS_IMPORTANTES.find(function (a) { return a.slug === slug; });
}

function enlaceAviso(slug, textoVisible) {
  return '<button type="button" class="enlace-aviso" data-aviso="' + slug + '">' + escaparHtml(textoVisible) + '</button>';
}

// Texto EXACTO de la única casilla de aceptación — ni una palabra, coma
// o mayúscula cambiada respecto al texto acordado. Lo único que se hace
// es envolver los 4 avisos que ya se mencionan en el propio texto con un
// hipervínculo que abre su contenido completo en una ventana emergente,
// para no tener que repetir una sección aparte con acordeones.
const TEXTO_ACEPTACION_HTML =
  'He leído y comprendido el ' + enlaceAviso('servicio', 'Aviso sobre el Servicio de Traslado') +
  ', el ' + enlaceAviso('disponibilidad', 'Aviso de Disponibilidad') +
  ', el ' + enlaceAviso('consentimiento', 'Consentimiento y Autorización para Traslado') +
  ' y el ' + enlaceAviso('privacidad', 'Aviso de Privacidad') +
  '; asimismo, manifiesto mi conformidad con la solicitud del servicio y acepto el tratamiento de los datos personales proporcionados para las finalidades informadas.';

const OPCIONES_PARENTESCO = [
  'Hijo/a', 'Padre', 'Madre', 'Esposo/a', 'Hermano/a',
  'Abuelo/a', 'Nieto/a', 'Tío/a', 'Sobrino/a', 'Primo/a',
  'Vecino/a', 'Amigo/a', 'Cuidador/a', 'Otro'
];

function cargarFormularioPublico() {
  google.script.run
    .withSuccessHandler(renderizarFormularioPublico)
    .withFailureHandler(function (error) {
      document.getElementById('cuerpo-publico').innerHTML = '<div class="tarjeta">Error al cargar: ' + escaparHtml(error.message) + '</div>';
    })
    .listarInstitucionesPublico();
}

function renderizarFormularioPublico(instituciones) {
  const opcionesInstitucion = instituciones.map(function (i) {
    return '<option value="' + i.id_institucion + '">' + escaparHtml(i.nombre) + (i.ciudad ? ' — ' + escaparHtml(i.ciudad) : '') + '</option>';
  }).join('');

  const hoy = new Date();
  const fechaMinima = hoy.getFullYear() + '-' + String(hoy.getMonth() + 1).padStart(2, '0') + '-' + String(hoy.getDate()).padStart(2, '0');

  document.getElementById('cuerpo-publico').innerHTML =
    '<div id="leyenda-obligatorio">Los campos con <span style="color:var(--rojo);">*</span> son obligatorios</div>' +

    '<div class="tarjeta">' +
      '<div class="titulo-tarjeta">👤 Datos del paciente</div>' +
      campoGrupo('sp-nombre', 'text', 'Nombre completo del paciente', { requerido: true }) +
      campoGrupo('sp-telefono', 'tel', 'Teléfono de contacto', {
        requerido: true, inputmode: 'numeric', maxlength: 10,
        ayuda: 'Te contactaremos a este número para confirmar fecha y hora.'
      }) +
      campoGrupo('sp-edad', 'number', 'Edad del paciente (años)', {
        requerido: true, inputmode: 'numeric', maxlength: 3, min: '0', max: '120',
        ayuda: 'Si el paciente es menor de edad, el acompañante mayor de edad será quien firme el consentimiento.'
      }) +
      campoGrupo('sp-comunidad', 'text', 'Comunidad / Localidad / Colonia', {}) +
      campoGrupo('sp-acompanante', 'text', 'Nombre de quien acompañará al paciente', {}) +
      '<div style="margin:-8px 0 14px;"><button type="button" class="enlace-aviso" data-aviso="acompanante" style="font-size:12.5px;">Ver Información del Acompañante</button></div>' +
      campoSelect('sp-acompanante-parentesco', 'Parentesco con el paciente', OPCIONES_PARENTESCO, {
        onchange: 'alternarParentescoOtro()'
      }) +
      campoGrupo('sp-parentesco-otro', 'text', 'Especifica el parentesco', {
        oculto: true, placeholder: 'Ej. cuñado, tutor legal, cuidador...'
      }) +
      campoGrupo('sp-acompanante-telefono', 'tel', 'Teléfono del acompañante', {
        inputmode: 'numeric', maxlength: 10,
        ayuda: 'Opcional, por si no logramos contactar al paciente.'
      }) +
      campoGrupo('sp-edad-acompanante', 'number', 'Edad de quien acompaña (años)', {
        requerido: true, inputmode: 'numeric', maxlength: 3, min: '18', max: '120', oculto: true,
        ayuda: 'Debe ser mayor de edad: firmará el consentimiento en representación del paciente.'
      }) +
    '</div>' +

    '<div class="tarjeta">' +
      '<div class="titulo-tarjeta">🏥 Institución médica</div>' +
      '<div class="grupo-campo campo-req" id="grupo-sp-institucion">' +
        '<label for="sp-institucion">Institución a la que necesita ir</label>' +
        '<select id="sp-institucion" onchange="alternarCampoOtraInstitucion()">' +
          '<option value="">Selecciona...</option>' + opcionesInstitucion +
          '<option value="__otra__">Otra / Clínica particular (no está en la lista)</option>' +
        '</select>' +
        '<div class="error">Selecciona la institución médica.</div>' +
      '</div>' +
      '<div id="campos-otra-institucion" style="display:none;">' +
        campoGrupo('sp-otra-nombre', 'text', 'Nombre de la clínica', { requerido: true }) +
        campoGrupo('sp-otra-direccion', 'text', 'Dirección (si la sabe)', {}) +
        campoGrupo('sp-otra-ciudad', 'text', 'Ciudad', {}) +
      '</div>' +
      campoGrupo('sp-especialidad', 'text', 'Especialidad (si la sabe)', {}) +
    '</div>' +

    '<div class="tarjeta">' +
      '<div class="titulo-tarjeta">📅 Detalles del traslado</div>' +
      campoGrupo('sp-fecha', 'date', 'Fecha en que necesita el traslado', { requerido: true, min: fechaMinima }) +
      campoGrupo('sp-hora', 'time', 'Hora de la cita (si ya la tiene)', {}) +
      campoGrupoTextarea('sp-motivo', 'Motivo del traslado', 'Ej. cita de control, estudio, consulta médica...', { requerido: true }) +
    '</div>' +

    '<div class="tarjeta">' +
      '<div id="aviso-firmante" class="ayuda" style="display:none; margin-bottom:10px;"></div>' +
      campoCheckboxHtml('sp-aceptacion', TEXTO_ACEPTACION_HTML) +
    '</div>' +

    '<button class="primario" style="width:100%; padding:14px;" onclick="enviarSolicitudPublica()">Enviar solicitud</button>' +
    '<p style="font-size:12px; color:var(--gris); text-align:center; margin-top:10px;">Un coordinador revisará tu solicitud y te contactará para confirmar el traslado.</p>' +

    HTML_MODAL_AVISO;

  document.querySelectorAll('.enlace-aviso').forEach(function (boton) {
    boton.addEventListener('click', function (e) {
      e.preventDefault();
      abrirAviso(boton.dataset.aviso);
    });
  });
  document.getElementById('modal-aviso-cerrar').addEventListener('click', cerrarAviso);
  document.getElementById('modal-aviso-overlay').addEventListener('click', function (e) {
    if (e.target.id === 'modal-aviso-overlay') cerrarAviso();
  });

  document.getElementById('sp-telefono').addEventListener('input', function () {
    this.value = this.value.replace(/\D/g, '').slice(0, 10);
  });
  document.getElementById('sp-acompanante-telefono').addEventListener('input', function () {
    this.value = this.value.replace(/\D/g, '').slice(0, 10);
  });

  document.getElementById('sp-edad').addEventListener('input', actualizarFirmante);
  actualizarFirmante();
}

// Determina, según la edad del paciente, quién firma electrónicamente el
// consentimiento: el propio paciente (si es mayor de edad) o el
// acompañante mayor de edad (si el paciente es menor). Este dato solo se
// usa aquí, en la solicitud; no se usa en el Pase de Traslado.
function esPacienteMenorDeEdad() {
  const edad = parseInt(document.getElementById('sp-edad').value, 10);
  return !isNaN(edad) && edad >= 0 && edad < 18;
}

function alternarParentescoOtro() {
  const esOtro = document.getElementById('sp-acompanante-parentesco').value === 'Otro';
  const grupoOtro = document.getElementById('grupo-sp-parentesco-otro');
  grupoOtro.style.display = esOtro ? '' : 'none';
  grupoOtro.classList.toggle('campo-req', esOtro && esPacienteMenorDeEdad());
  if (!esOtro) marcarError('sp-parentesco-otro', false);
}

function actualizarFirmante() {
  const esMenor = esPacienteMenorDeEdad();
  const grupoEdadAcompanante = document.getElementById('grupo-sp-edad-acompanante');
  const grupoAcompanante = document.getElementById('grupo-sp-acompanante');
  const grupoParentesco = document.getElementById('grupo-sp-acompanante-parentesco');
  const avisoFirmante = document.getElementById('aviso-firmante');

  grupoEdadAcompanante.style.display = esMenor ? '' : 'none';
  [grupoAcompanante, grupoParentesco, grupoEdadAcompanante].forEach(function (grupo) {
    grupo.classList.toggle('campo-req', esMenor);
  });
  if (!esMenor) marcarError('sp-edad-acompanante', false);
  alternarParentescoOtro();

  avisoFirmante.style.display = esMenor ? '' : 'none';
  if (esMenor) {
    avisoFirmante.textContent = 'El paciente es menor de edad: el acompañante mayor de edad debe registrarse arriba; sus datos identifican a quien manifiesta la conformidad en representación del paciente.';
  }
}

function campoGrupo(id, tipo, etiqueta, opciones) {
  opciones = opciones || {};
  const claseReq = opciones.requerido ? ' campo-req' : '';
  const estiloOculto = opciones.oculto ? ' style="display:none;"' : '';
  const atributos =
    (opciones.inputmode ? ' inputmode="' + opciones.inputmode + '"' : '') +
    (opciones.maxlength ? ' maxlength="' + opciones.maxlength + '"' : '') +
    (opciones.min ? ' min="' + opciones.min + '"' : '') +
    (opciones.max ? ' max="' + opciones.max + '"' : '') +
    (opciones.placeholder ? ' placeholder="' + escaparHtml(opciones.placeholder) + '"' : '');

  return (
    '<div class="grupo-campo' + claseReq + '" id="grupo-' + id + '"' + estiloOculto + '>' +
      '<label for="' + id + '">' + escaparHtml(etiqueta) + '</label>' +
      '<input type="' + tipo + '" id="' + id + '"' + atributos + '>' +
      (opciones.ayuda ? '<div class="ayuda">' + escaparHtml(opciones.ayuda) + '</div>' : '') +
      '<div class="error">Este campo es obligatorio.</div>' +
    '</div>'
  );
}

function campoGrupoTextarea(id, etiqueta, placeholder, opciones) {
  opciones = opciones || {};
  const claseReq = opciones.requerido ? ' campo-req' : '';
  return (
    '<div class="grupo-campo' + claseReq + '" id="grupo-' + id + '">' +
      '<label for="' + id + '">' + escaparHtml(etiqueta) + '</label>' +
      '<textarea id="' + id + '" rows="3" placeholder="' + escaparHtml(placeholder) + '"></textarea>' +
      '<div class="error">Este campo es obligatorio.</div>' +
    '</div>'
  );
}

function campoSelect(id, etiqueta, opciones, config) {
  config = config || {};
  const claseReq = config.requerido ? ' campo-req' : '';
  const estiloOculto = config.oculto ? ' style="display:none;"' : '';
  const atrOnchange = config.onchange ? ' onchange="' + config.onchange + '"' : '';
  const listaOpciones = '<option value="">Selecciona...</option>' + opciones.map(function (o) {
    return '<option value="' + escaparHtml(o) + '">' + escaparHtml(o) + '</option>';
  }).join('');

  return (
    '<div class="grupo-campo' + claseReq + '" id="grupo-' + id + '"' + estiloOculto + '>' +
      '<label for="' + id + '">' + escaparHtml(etiqueta) + '</label>' +
      '<select id="' + id + '"' + atrOnchange + '>' + listaOpciones + '</select>' +
      (config.ayuda ? '<div class="ayuda">' + escaparHtml(config.ayuda) + '</div>' : '') +
      '<div class="error">Este campo es obligatorio.</div>' +
    '</div>'
  );
}

function campoCheckbox(id, texto) {
  return (
    '<div class="grupo-campo campo-checkbox" id="grupo-' + id + '">' +
      '<input type="checkbox" id="' + id + '">' +
      '<label for="' + id + '">' + escaparHtml(texto) +
        '<div class="error">Debes aceptar esto para poder enviar la solicitud.</div>' +
      '</label>' +
    '</div>'
  );
}

// Igual que campoCheckbox, pero el texto se inserta como HTML de confianza
// (generado por nosotros, no por el usuario) en vez de escaparse — lo usa
// la casilla de aceptación para incluir los hipervínculos de los avisos.
function campoCheckboxHtml(id, html) {
  return (
    '<div class="grupo-campo campo-checkbox" id="grupo-' + id + '">' +
      '<input type="checkbox" id="' + id + '">' +
      '<label for="' + id + '">' + html +
        '<div class="error">Debes aceptar esto para poder enviar la solicitud.</div>' +
      '</label>' +
    '</div>'
  );
}

const HTML_MODAL_AVISO =
  '<div id="modal-aviso-overlay">' +
    '<div id="modal-aviso-caja">' +
      '<div id="modal-aviso-header">' +
        '<span id="modal-aviso-titulo"></span>' +
        '<button type="button" id="modal-aviso-cerrar" aria-label="Cerrar">✕</button>' +
      '</div>' +
      '<div id="modal-aviso-cuerpo"></div>' +
    '</div>' +
  '</div>';

function abrirAviso(slug) {
  const aviso = buscarAviso(slug);
  if (!aviso) return;
  document.getElementById('modal-aviso-titulo').textContent = aviso.titulo;
  document.getElementById('modal-aviso-cuerpo').textContent = aviso.texto;
  document.getElementById('modal-aviso-overlay').classList.add('abierto');
}

function cerrarAviso() {
  document.getElementById('modal-aviso-overlay').classList.remove('abierto');
}

function alternarCampoOtraInstitucion() {
  const esOtra = document.getElementById('sp-institucion').value === '__otra__';
  document.getElementById('campos-otra-institucion').style.display = esOtra ? 'block' : 'none';
  if (!esOtra) marcarError('sp-otra-nombre', false);
}

function marcarError(idCampo, hayError) {
  const grupo = document.getElementById('grupo-' + idCampo);
  if (grupo) grupo.classList.toggle('con-error', hayError);
}

function enviarSolicitudPublica() {
  const idInstitucion = document.getElementById('sp-institucion').value;
  const esOtraInstitucion = idInstitucion === '__otra__';

  const esMenor = esPacienteMenorDeEdad();
  const edadPacienteTexto = document.getElementById('sp-edad').value.trim();
  const edadAcompananteTexto = document.getElementById('sp-edad-acompanante').value.trim();
  const nombrePaciente = document.getElementById('sp-nombre').value.trim();
  const nombreAcompanante = document.getElementById('sp-acompanante').value.trim();
  const parentescoSeleccionado = document.getElementById('sp-acompanante-parentesco').value;
  const parentescoEsOtro = parentescoSeleccionado === 'Otro';
  const parentescoOtroTexto = document.getElementById('sp-parentesco-otro').value.trim();
  const parentescoFinal = parentescoEsOtro ? parentescoOtroTexto : parentescoSeleccionado;

  const datos = {
    nombre_completo: nombrePaciente,
    telefono: document.getElementById('sp-telefono').value.trim(),
    edad_paciente: edadPacienteTexto === '' ? '' : parseInt(edadPacienteTexto, 10),
    comunidad: document.getElementById('sp-comunidad').value.trim(),
    acompanante_nombre: nombreAcompanante,
    acompanante_parentesco: parentescoFinal,
    acompanante_telefono: document.getElementById('sp-acompanante-telefono').value.trim(),
    edad_acompanante: edadAcompananteTexto === '' ? '' : parseInt(edadAcompananteTexto, 10),
    es_paciente_menor_edad: esMenor,
    firmante_nombre: esMenor ? nombreAcompanante : nombrePaciente,
    firmante_tipo: esMenor ? 'acompanante' : 'paciente',
    id_institucion: idInstitucion,
    institucion_otra_nombre: document.getElementById('sp-otra-nombre').value.trim(),
    institucion_otra_direccion: document.getElementById('sp-otra-direccion').value.trim(),
    institucion_otra_ciudad: document.getElementById('sp-otra-ciudad').value.trim(),
    especialidad: document.getElementById('sp-especialidad').value.trim(),
    fecha_cita: document.getElementById('sp-fecha').value,
    hora_cita: document.getElementById('sp-hora').value,
    motivo_traslado: document.getElementById('sp-motivo').value.trim(),
    aceptacion_avisos: document.getElementById('sp-aceptacion').checked
  };

  let primerError = null;
  function verificar(idCampo, valido) {
    marcarError(idCampo, !valido);
    if (!valido && !primerError) primerError = idCampo;
  }

  verificar('sp-nombre', !!datos.nombre_completo);
  verificar('sp-telefono', datos.telefono.length === 10);
  verificar('sp-edad', datos.edad_paciente !== '' && !isNaN(datos.edad_paciente) && datos.edad_paciente >= 0 && datos.edad_paciente <= 120);
  if (esMenor) {
    verificar('sp-acompanante', !!datos.acompanante_nombre);
    verificar('sp-acompanante-parentesco', !!parentescoSeleccionado);
    if (parentescoEsOtro) verificar('sp-parentesco-otro', !!parentescoOtroTexto);
    verificar('sp-edad-acompanante', datos.edad_acompanante !== '' && !isNaN(datos.edad_acompanante) && datos.edad_acompanante >= 18 && datos.edad_acompanante <= 120);
  }
  verificar('sp-institucion', !!idInstitucion);
  if (esOtraInstitucion) verificar('sp-otra-nombre', !!datos.institucion_otra_nombre);
  verificar('sp-fecha', !!datos.fecha_cita);
  verificar('sp-motivo', !!datos.motivo_traslado);
  verificar('sp-aceptacion', datos.aceptacion_avisos);

  if (primerError) {
    document.getElementById('grupo-' + primerError).scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  const boton = document.querySelector('#cuerpo-publico button.primario');
  boton.disabled = true;
  boton.textContent = 'Enviando...';

  google.script.run
    .withSuccessHandler(function (folio) { mostrarConfirmacionPublica(folio, datos); })
    .withFailureHandler(function (error) {
      alert('No se pudo enviar la solicitud: ' + error.message);
      boton.disabled = false;
      boton.textContent = 'Enviar solicitud';
    })
    .crearSolicitudPublica(datos);
}

function mostrarConfirmacionPublica(folio, datos) {
  document.getElementById('cuerpo-publico').innerHTML =
    '<div class="tarjeta" style="text-align:center; padding:28px 16px;">' +
      '<div style="font-size:40px;">✅</div>' +
      '<h3 style="margin-top:12px;">¡Solicitud recibida!</h3>' +
      '<p>Tu número de folio es:</p>' +
      '<p id="folio-confirmacion" style="font-size:20px; font-weight:700; color:var(--color-primario);">' + escaparHtml(folio) + '</p>' +
      '<p style="font-size:13px; color:var(--gris);">La solicitud fue recibida, pero el traslado quedará confirmado únicamente cuando sea autorizado. Guarda este folio: un coordinador la revisará y te contactará al teléfono que proporcionaste para confirmar fecha y hora.</p>' +
      '<div id="confirmacion-acciones">' +
        '<button onclick="copiarFolio(\'' + escaparHtml(folio) + '\')">📋 Copiar folio</button>' +
        '<button class="primario" onclick="compartirFolioWhatsApp(\'' + escaparHtml(folio) + '\', ' + JSON.stringify(datos.nombre_completo).replace(/"/g, '&quot;') + ')">📲 Avisar por WhatsApp</button>' +
      '</div>' +
    '</div>';
}

function copiarFolio(folio) {
  const boton = event.target;
  const textoOriginal = boton.textContent;
  navigator.clipboard.writeText(folio).then(function () {
    boton.textContent = '✅ Copiado';
    setTimeout(function () { boton.textContent = textoOriginal; }, 1800);
  }).catch(function () {
    alert('Tu folio es: ' + folio);
  });
}

function compartirFolioWhatsApp(folio, nombrePaciente) {
  const texto = 'Hola, acabo de solicitar un traslado médico para ' + nombrePaciente + '. Mi folio es: ' + folio;
  window.open('https://api.whatsapp.com/send?phone=' + NUMERO_WHATSAPP_COORDINADORA + '&text=' + encodeURIComponent(texto), '_blank');
}
