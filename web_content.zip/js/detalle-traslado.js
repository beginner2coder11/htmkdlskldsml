  // Transiciones "simples" que solo cambian el estado (sin capturar datos
  // adicionales). Debe coincidir con TRANSICIONES_PERMITIDAS del backend,
  // excluyendo las que tienen su propio formulario (ver más abajo).
  // "Pendiente de autorización" ya no es parte de la ruta normal (ver
  // nota en firebase-shim.js); se deja aquí solo para que un traslado
  // antiguo que se haya quedado en ese estado se pueda seguir moviendo.
  const TRANSICIONES_SIMPLES = {
    'Solicitud recibida': ['Autorizado', 'Cancelado'],
    'Pendiente de autorización': ['Autorizado', 'Cancelado'],
    'Autorizado': ['Programado', 'Cancelado'],
    'Programado': ['Reprogramado', 'Cancelado'], // "Vehículo asignado" tiene su propio formulario
    'Reprogramado': ['Programado', 'Cancelado']
  };

  // Texto de acción que se muestra en el botón (en lugar del nombre del
  // estado destino, cuando conviene un verbo más natural).
  const ETIQUETAS_BOTON_ESTADO = {
    'Autorizado': 'Autorizar'
  };

  // Botón "Notificar por WhatsApp" en el detalle del traslado: mismo
  // patrón de enlace directo (api.whatsapp.com/send?phone=...) que ya se
  // usa en el formulario público, pero aquí abre el chat con el TELÉFONO
  // DEL PACIENTE (o del acompañante si el paciente no tiene), con un
  // mensaje ya escrito según el resultado (autorizado o cancelado). Es
  // manual a propósito: coordinador/administrador revisa el mensaje y
  // toca "Enviar" en WhatsApp — no se manda nada solo, sin que alguien
  // lo confirme.
  function botonNotificarWhatsApp(t, paciente) {
    if (t.estado_actual !== 'Autorizado' && t.estado_actual !== 'Cancelado') return '';
    const telefono = (paciente && paciente.telefono) || t.acompanante_telefono || '';
    if (!telefono) return '';
    const datos = JSON.stringify({
      folio: t.folio, telefono: telefono, estado: t.estado_actual,
      fecha_cita: formatearFecha(t.fecha_cita), hora_cita: t.hora_cita || ''
    }).replace(/"/g, '&quot;');
    return '<button onclick=\'notificarPacienteWhatsApp(' + datos.replace(/'/g, '&#39;') + ')\'>📲 Notificar por WhatsApp</button>';
  }

  // Si el teléfono ya trae 10 dígitos (número local mexicano), se le
  // antepone el 52 (código de país) para el enlace de WhatsApp.
  function formatearNumeroWhatsApp(telefono) {
    const digitos = String(telefono || '').replace(/\D/g, '');
    if (!digitos) return '';
    return digitos.length === 10 ? '52' + digitos : digitos;
  }

  function notificarPacienteWhatsApp(datos) {
    const numero = formatearNumeroWhatsApp(datos.telefono);
    if (!numero) { alert('No hay un teléfono registrado para notificar por WhatsApp.'); return; }

    let texto;
    if (datos.estado === 'Autorizado') {
      texto = 'Hola, te escribimos de Traslados SVT. Tu traslado (folio ' + datos.folio + ') ya fue autorizado' +
        (datos.fecha_cita ? ' para el ' + datos.fecha_cita + (datos.hora_cita ? ' a las ' + datos.hora_cita : '') : '') +
        '. Cualquier duda, contáctanos por este medio.';
    } else {
      texto = 'Hola, te escribimos de Traslados SVT. Lamentamos informarte que tu traslado (folio ' + datos.folio + ') no pudo ser autorizado. Contáctanos por este medio si tienes dudas o quieres reagendar.';
    }
    window.open('https://api.whatsapp.com/send?phone=' + numero + '&text=' + encodeURIComponent(texto), '_blank');
  }

  function verDetalleTraslado(folio) {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML = '<p>Cargando traslado...</p>';

    new Promise(function (resolve, reject) {
      google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).obtenerTraslado(folio);
    }).then(function (t) {
      Promise.all([
        new Promise(function (resolve) {
          if (!t.id_paciente) { resolve(null); return; }
          google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve(null); }).obtenerPaciente(t.id_paciente);
        }),
        new Promise(function (resolve) {
          if (!t.id_institucion) { resolve(null); return; }
          google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve(null); }).obtenerInstitucion(t.id_institucion);
        }),
        new Promise(function (resolve) {
          if (!t.id_conductor) { resolve(null); return; }
          google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve(null); }).obtenerConductor(t.id_conductor);
        }),
        new Promise(function (resolve) {
          if (!t.id_vehiculo) { resolve(null); return; }
          google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve(null); }).obtenerVehiculo(t.id_vehiculo);
        }),
        new Promise(function (resolve) {
          // Solo importa consultarlo si ya está autorizado (antes de eso
          // nunca puede haber un pase guardado, ver guardarPasePrimeraVez).
          if (!t.autorizado_por) { resolve(false); return; }
          google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve(false); }).existePaseTraslado(folio);
        })
      ]).then(function (resultados) {
        renderizarDetalleTraslado(t, resultados[0], resultados[1], resultados[2], resultados[3], resultados[4]);
      });
    }).catch(function (error) {
      contenedor.innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>';
    });
  }

  function renderizarDatosRegistro(t, paciente, institucion, paseYaGenerado) {
    if (!paciente) return '';
    CONTEXTO_PASE_TRASLADO = { t: t, paciente: paciente, institucion: institucion };
    const edad = paciente.edad !== '' && paciente.edad !== undefined ? paciente.edad + ' años' : '';
    const accionPase = paseYaGenerado
      ? '<span style="font-size:12.5px; color:var(--gris);">✅ Pase generado — está en "Pases de traslados"</span>'
      : '<button onclick="generarYAbrirPaseTraslado()">🖨️ Generar Pase de Traslados (PDF)</button>';
    return (
      '<div class="tarjeta">' +
        '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:10px; flex-wrap:wrap;">' +
          '<h3 style="margin:0;">Datos con los que se registró la solicitud</h3>' +
          accionPase +
        '</div>' +
        '<p><strong>Paciente:</strong> ' + escaparHtml(paciente.nombre_completo || '') + (edad ? ' (' + edad + ')' : '') + '</p>' +
        (paciente.sexo ? '<p><strong>Sexo:</strong> ' + escaparHtml(paciente.sexo) + '</p>' : '') +
        (paciente.comunidad ? '<p><strong>Comunidad:</strong> ' + escaparHtml(paciente.comunidad) + '</p>' : '') +
        '<p><strong>Teléfono:</strong> ' + escaparHtml(paciente.telefono || '') + '</p>' +
        (paciente.contacto_emergencia_nombre ? '<p><strong>Contacto de emergencia:</strong> ' + escaparHtml(paciente.contacto_emergencia_nombre) + (paciente.contacto_emergencia_telefono ? ' · ' + escaparHtml(paciente.contacto_emergencia_telefono) : '') + '</p>' : '') +
        (t.acompanante_nombre ? '<p><strong>Acompañante:</strong> ' + escaparHtml(t.acompanante_nombre) + (t.acompanante_parentesco ? ' (' + escaparHtml(t.acompanante_parentesco) + ')' : '') + (t.acompanante_telefono ? ' · ' + escaparHtml(t.acompanante_telefono) : '') + '</p>' : '') +
        (t.firmante_nombre ? '<p style="font-size:12.5px; color:var(--gris);">✍️ Firmó el consentimiento: ' + escaparHtml(t.firmante_nombre) + (t.es_paciente_menor_edad ? ' (acompañante, ya que el paciente es menor de edad — ' + escaparHtml(t.edad_paciente) + ' años)' : ' (el propio paciente — ' + escaparHtml(t.edad_paciente) + ' años)') + '</p>' : '') +
        (t.aceptacion_avisos
          ? '<p style="font-size:12.5px; color:var(--gris);">✅ Avisos aceptados' + (t.fecha_aceptacion ? ' el ' + escaparHtml(t.fecha_aceptacion) + (t.hora_aceptacion ? ' a las ' + escaparHtml(t.hora_aceptacion) : '') : '') + '.</p>'
          : (t.consentimiento_traslado ? '<p style="font-size:12.5px; color:var(--gris);">✅ Consentimiento y Aviso de Privacidad aceptados' + (t.fecha_consentimiento ? ' el ' + escaparHtml(formatearFecha(t.fecha_consentimiento)) : '') + '.</p>' : '')) +
        '<p><strong>Institución:</strong> ' + escaparHtml(institucion ? institucion.nombre : (t.id_institucion || '')) + '</p>' +
        (t.especialidad ? '<p><strong>Especialidad:</strong> ' + escaparHtml(t.especialidad) + '</p>' : '') +
        '<p><strong>Fecha de la cita:</strong> ' + escaparHtml(formatearFecha(t.fecha_cita)) + (t.hora_cita ? ' ' + escaparHtml(t.hora_cita) : '') + '</p>' +
        '<p><strong>Motivo del traslado:</strong> ' + escaparHtml(t.motivo_traslado || '') + '</p>' +
        (t.observaciones ? '<p><strong>Observaciones:</strong> ' + escaparHtml(t.observaciones) + '</p>' : '') +
        '<p style="font-size:12px; color:var(--gris);">Registrado por: ' + escaparHtml(t.creado_por || '') + '</p>' +
      '</div>'
    );
  }

  function renderizarDetalleTraslado(t, paciente, institucion, conductor, vehiculo, paseYaGenerado) {
    const colorEstado = COLOR_POR_ESTADO[t.estado_actual] || 'gris';

    const timeline = (t.historial || []).map(function (h) {
      return (
        '<div style="border-left:2px solid var(--color-borde); padding-left:12px; margin-bottom:10px;">' +
          '<div style="font-size:13px; color:var(--gris);">' + escaparHtml(h.fecha) + ' ' + escaparHtml(h.hora) + ' · ' + escaparHtml(h.usuario) + '</div>' +
          '<div><strong>' + escaparHtml(h.estado_anterior || '(inicio)') + ' → ' + escaparHtml(h.estado_nuevo) + '</strong></div>' +
          (h.comentario ? '<div style="font-size:13px;">' + escaparHtml(h.comentario) + '</div>' : '') +
        '</div>'
      );
    }).join('');

    const puedeEditar = SESION.rol === 'Administrador' || SESION.rol === 'Coordinador';
    const puedeEliminar = SESION.rol === 'Administrador';

    const html =
      '<button onclick="navegarA(\'traslados\')" style="margin-bottom:12px;">← Volver a Traslados</button>' +
      '<div class="tarjeta">' +
        '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:10px;">' +
          '<h2 style="margin:0;">' + escaparHtml(t.folio) + '</h2>' +
          '<div style="display:flex; align-items:center; gap:8px;">' +
            '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
            (puedeEditar ? '<button onclick="mostrarFormularioEditarTraslado(\'' + t.folio + '\')">Editar</button>' : '') +
            botonNotificarWhatsApp(t, paciente) +
            (puedeEliminar ? '<button onclick="confirmarEliminarTraslado(\'' + t.folio + '\')" style="color:#b42318;">Eliminar</button>' : '') +
          '</div>' +
        '</div>' +
        '<p style="color:var(--gris);">Cita: ' + escaparHtml(formatearFecha(t.fecha_cita)) + ' ' + escaparHtml(t.hora_cita || '') +
          ' · Motivo: ' + escaparHtml(t.motivo_traslado || '') + '</p>' +
        (t.id_conductor ? '<p>Conductor asignado: ' + escaparHtml(conductor ? conductor.nombre_completo : t.id_conductor) + ' · Vehículo: ' + escaparHtml(vehiculo ? etiquetaVehiculo(vehiculo) : t.id_vehiculo) + '</p>' : '') +
        (t.duracion_total ? '<p>Duración total: ' + escaparHtml(String(t.duracion_total)) + ' min</p>' : '') +
      '</div>' +

      renderizarDatosRegistro(t, paciente, institucion, paseYaGenerado) +

      '<div class="tarjeta" id="zona-acciones">' + construirAccionesEstado(t) + '</div>' +

      '<div class="tarjeta"><h3>Bitácora</h3>' + (timeline || '<p>Sin movimientos aún.</p>') + '</div>';

    document.getElementById('contenido-principal').innerHTML = html;

    if (t.estado_actual === 'Programado') {
      cargarFormularioAsignacion(t.folio);
    }
  }

  function confirmarEliminarTraslado(folio) {
    if (!confirm('¿Eliminar el traslado ' + folio + '? Esta acción no se puede deshacer.')) return;
    google.script.run
      .withSuccessHandler(function () { navegarA('traslados'); })
      .withFailureHandler(function (e) { alert(e.message); })
      .eliminarTraslado(folio);
  }

  function mostrarFormularioEditarTraslado(folio) {
    google.script.run
      .withSuccessHandler(function (t) { renderizarFormularioEditarTraslado(t); })
      .withFailureHandler(function (e) { alert(e.message); })
      .obtenerTraslado(folio);
  }

  function renderizarFormularioEditarTraslado(t) {
    const html =
      '<button onclick="verDetalleTraslado(\'' + t.folio + '\')" style="margin-bottom:12px;">← Cancelar</button>' +
      '<div class="tarjeta">' +
        '<h3>Editar traslado ' + escaparHtml(t.folio) + '</h3>' +
        campoFecha('et-fecha-cita', 'Fecha de la cita', t.fecha_cita) +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Hora de la cita</label>' +
          '<input type="time" id="et-hora-cita" value="' + escaparHtml(t.hora_cita || '') + '" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;"></div>' +
        campoTexto('et-especialidad', 'Especialidad', t.especialidad) +
        campoTextarea('et-motivo', 'Motivo del traslado', t.motivo_traslado) +
        campoTexto('et-acompanante-nombre', 'Acompañante (nombre)', t.acompanante_nombre) +
        campoTexto('et-acompanante-telefono', 'Acompañante (teléfono)', t.acompanante_telefono) +
        campoTexto('et-acompanante-parentesco', 'Parentesco', t.acompanante_parentesco) +
        campoTextarea('et-observaciones', 'Observaciones', t.observaciones) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarEdicionTraslado(\'' + t.folio + '\')">Guardar cambios</button> ' +
          '<button onclick="verDetalleTraslado(\'' + t.folio + '\')">Cancelar</button>' +
        '</div>' +
      '</div>';
    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarEdicionTraslado(folio) {
    const cambios = {
      fecha_cita: document.getElementById('et-fecha-cita').value,
      hora_cita: document.getElementById('et-hora-cita').value,
      especialidad: document.getElementById('et-especialidad').value,
      motivo_traslado: document.getElementById('et-motivo').value,
      acompanante_nombre: document.getElementById('et-acompanante-nombre').value,
      acompanante_telefono: document.getElementById('et-acompanante-telefono').value,
      acompanante_parentesco: document.getElementById('et-acompanante-parentesco').value,
      observaciones: document.getElementById('et-observaciones').value
    };
    google.script.run
      .withSuccessHandler(function () { verDetalleTraslado(folio); })
      .withFailureHandler(function (e) { alert(e.message); })
      .actualizarTraslado(folio, cambios);
  }

  function construirAccionesEstado(t) {
    if (SESION.rol === 'Consulta') return '<p style="color:var(--gris);">Solo lectura.</p>';

    const estado = t.estado_actual;

    // Caso especial: Programado -> requiere elegir conductor y vehículo
    // antes de pasar a "Vehículo asignado".
    if (estado === 'Programado') {
      return '<h3>Asignar vehículo y conductor</h3><div id="zona-asignacion">Cargando catálogos...</div>';
    }

    if (estado === 'Vehículo asignado') {
      return '<h3>Registrar salida</h3>' +
        '<button class="primario" onclick="accionRegistrarSalida(\'' + t.folio + '\')">Registrar salida</button>';
    }

    if (estado === 'En traslado') {
      return '<h3>Registrar llegada a destino</h3>' +
        '<button class="primario" onclick="accionRegistrarLlegada(\'' + t.folio + '\')">Registrar llegada</button>';
    }

    if (estado === 'En destino') {
      return '<h3>Registrar regreso</h3>' +
        '<button class="primario" onclick="accionRegistrarRegreso(\'' + t.folio + '\')">Registrar salida de destino y llegada</button>' +
        '<p style="font-size:12px; color:var(--gris); margin-top:6px;">Esto registra en un solo paso la salida de Ciudad Valles y la llegada a San Vicente Tancuayalab, con la hora actual. Si necesitas horas distintas, pídeme que agregue esos campos.</p>';
    }

    const opciones = TRANSICIONES_SIMPLES[estado];
    if (!opciones || !opciones.length) return '<p style="color:var(--gris);">No hay acciones disponibles para este estado.</p>';

    return opciones.map(function (siguiente) {
      const etiqueta = ETIQUETAS_BOTON_ESTADO[siguiente] || siguiente;
      return '<button class="primario" style="margin-right:8px;" onclick="accionCambiarEstado(\'' + t.folio + '\', \'' + siguiente + '\')">' + etiqueta + '</button>';
    }).join('');
  }

  function cargarFormularioAsignacion(folio) {
    Promise.all([
      new Promise(function (resolve, reject) { google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).listarConductoresActivos(); }),
      new Promise(function (resolve, reject) { google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).listarVehiculosActivos(); })
    ]).then(function (resultados) {
      const conductores = resultados[0], vehiculos = resultados[1];
      const zona = document.getElementById('zona-asignacion');
      if (!zona) return; // el usuario ya navegó a otra vista

      if (!conductores.length || !vehiculos.length) {
        zona.innerHTML = '<p>Necesitas al menos un conductor activo y un vehículo activo registrados para asignar.</p>';
        return;
      }

      zona.innerHTML =
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Conductor</label>' +
          '<select id="asig-conductor" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' +
            conductores.map(function (c) { return '<option value="' + c.id_conductor + '">' + escaparHtml(c.nombre_completo) + '</option>'; }).join('') +
          '</select></div>' +
        '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">Vehículo</label>' +
          '<select id="asig-vehiculo" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;">' +
            vehiculos.map(function (v) { return '<option value="' + v.id_vehiculo + '">' + escaparHtml(etiquetaVehiculo(v)) + '</option>'; }).join('') +
          '</select></div>' +
        '<button class="primario" onclick="accionAsignarVehiculoConductor(\'' + folio + '\')">Confirmar asignación</button>';
    }).catch(function (error) {
      const zona = document.getElementById('zona-asignacion');
      if (zona) zona.innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>';
    });
  }

  function accionAsignarVehiculoConductor(folio) {
    const idConductor = document.getElementById('asig-conductor').value;
    const idVehiculo = document.getElementById('asig-vehiculo').value;

    google.script.run
      .withSuccessHandler(function () {
        google.script.run
          .withSuccessHandler(function () { verDetalleTraslado(folio); })
          .withFailureHandler(function (e) { alert(e.message); })
          .cambiarEstadoTraslado(folio, 'Vehículo asignado', 'Se asignó conductor y vehículo');
      })
      .withFailureHandler(function (e) { alert(e.message); })
      .actualizarTraslado(folio, { id_conductor: idConductor, id_vehiculo: idVehiculo });
  }

  function accionCambiarEstado(folio, nuevoEstado) {
    let comentario = '';
    if (nuevoEstado === 'Cancelado' || nuevoEstado === 'Reprogramado') {
      comentario = prompt('Motivo (opcional):') || '';
    }

    // Bloquea de inmediato todos los botones de acción de estado para
    // evitar doble clic mientras se confirma el cambio en el servidor.
    const zona = document.getElementById('zona-acciones');
    if (zona) {
      zona.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
    }

    google.script.run
      .withSuccessHandler(function () { verDetalleTraslado(folio); })
      .withFailureHandler(function (e) {
        if (zona) { zona.querySelectorAll('button').forEach(function (b) { b.disabled = false; }); }
        alert(e.message);
      })
      .cambiarEstadoTraslado(folio, nuevoEstado, comentario);
  }

  function accionRegistrarSalida(folio) {
    google.script.run
      .withSuccessHandler(function () { verDetalleTraslado(folio); })
      .withFailureHandler(function (e) { alert(e.message); })
      .registrarSalida(folio, {});
  }

  function accionRegistrarLlegada(folio) {
    google.script.run
      .withSuccessHandler(function () { verDetalleTraslado(folio); })
      .withFailureHandler(function (e) { alert(e.message); })
      .registrarLlegadaDestino(folio, {});
  }

  function accionRegistrarRegreso(folio) {
    google.script.run
      .withSuccessHandler(function () { verDetalleTraslado(folio); })
      .withFailureHandler(function (e) { alert(e.message); })
      .registrarRegreso(folio, {});
  }
