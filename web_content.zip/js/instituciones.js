  function cargarVistaInstituciones() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Instituciones médicas</h2>' +
        '<button class="primario" onclick="mostrarFormularioInstitucion()">+ Nueva institución</button>' +
      '</div>' +
      '<input type="text" id="buscador-instituciones" placeholder="Buscar por nombre o ciudad..." ' +
        'style="width:100%; padding:10px; margin-bottom:12px; border:1px solid var(--color-borde); border-radius:8px;" ' +
        'oninput="buscarInstituciones(this.value)">' +
      '<div id="lista-instituciones">Cargando...</div>';

    buscarInstituciones('');
  }

  function buscarInstituciones(texto) {
    google.script.run
      .withSuccessHandler(renderizarListaInstituciones)
      .withFailureHandler(function (error) {
        document.getElementById('lista-instituciones').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>';
      })
      .listarInstituciones(texto);
  }

  function renderizarListaInstituciones(instituciones) {
    const contenedor = document.getElementById('lista-instituciones');
    if (!instituciones.length) {
      contenedor.innerHTML = '<div class="tarjeta estado-vacio"><span class="icono-vacio">🏥</span>No se encontraron instituciones.</div>';
      return;
    }
    contenedor.innerHTML = instituciones.map(function (i) {
      return (
        '<div class="tarjeta" style="cursor:pointer;" onclick="mostrarFormularioInstitucion(\'' + i.id_institucion + '\')">' +
          '<strong>' + escaparHtml(i.nombre) + '</strong>' +
          '<div style="color:var(--gris); font-size:13px;">' + escaparHtml(i.tipo || '') +
            (i.ciudad ? ' · ' + escaparHtml(i.ciudad) : '') +
          '</div>' +
        '</div>'
      );
    }).join('');
  }

  function mostrarFormularioInstitucion(idInstitucion) {
    if (idInstitucion) {
      google.script.run
        .withSuccessHandler(renderizarFormularioInstitucion)
        .withFailureHandler(function (error) { alert(error.message); })
        .obtenerInstitucion(idInstitucion);
    } else {
      renderizarFormularioInstitucion(null);
    }
  }

  function renderizarFormularioInstitucion(institucion) {
    const esEdicion = !!institucion;
    institucion = institucion || {};

    const tiposInstitucion = ['Hospital', 'Clínica', 'IMSS', 'ISSSTE', 'Centro de salud', 'Laboratorio', 'Clínica particular', 'Otro'];

    const html =
      '<div class="tarjeta">' +
        '<h3>' + (esEdicion ? 'Editar institución' : 'Nueva institución') + '</h3>' +
        campoTexto('if-nombre', 'Nombre', institucion.nombre) +
        campoSelect('if-tipo', 'Tipo', tiposInstitucion, institucion.tipo, true) +
        campoTexto('if-direccion', 'Dirección', institucion.direccion) +
        campoTexto('if-ciudad', 'Ciudad', institucion.ciudad) +
        campoTexto('if-estado', 'Estado', institucion.estado) +
        campoTexto('if-telefono', 'Teléfono', institucion.telefono) +
        campoTexto('if-especialidades', 'Especialidades (separadas por coma)', institucion.especialidades) +
        campoTextarea('if-observaciones', 'Observaciones', institucion.observaciones) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarInstitucion(' + (esEdicion ? "'" + institucion.id_institucion + "'" : 'null') + ')">Guardar</button> ' +
          '<button onclick="cargarVistaInstituciones()">Cancelar</button>' +
        '</div>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarInstitucion(idInstitucion) {
    const datos = {
      nombre: document.getElementById('if-nombre').value,
      tipo: document.getElementById('if-tipo').value,
      direccion: document.getElementById('if-direccion').value,
      ciudad: document.getElementById('if-ciudad').value,
      estado: document.getElementById('if-estado').value,
      telefono: document.getElementById('if-telefono').value,
      especialidades: document.getElementById('if-especialidades').value,
      observaciones: document.getElementById('if-observaciones').value
    };

    if (!datos.nombre) {
      alert('El nombre de la institución es obligatorio.');
      return;
    }

    if (idInstitucion) {
      google.script.run.withSuccessHandler(function () { cargarVistaInstituciones(); }).withFailureHandler(function (e) { alert(e.message); }).actualizarInstitucion(idInstitucion, datos);
    } else {
      google.script.run.withSuccessHandler(function () { cargarVistaInstituciones(); }).withFailureHandler(function (e) { alert(e.message); }).crearInstitucion(datos);
    }
  }
