/**
 * api-shim.js
 * Todo el código de los módulos (traslados.js, pacientes.js, etc.) fue
 * escrito originalmente para ejecutarse DENTRO de Google Apps Script,
 * donde existe un objeto global `google.script.run` que llama funciones
 * del servidor. Ahora que el sitio vive en Netlify, ese objeto no existe
 * de forma nativa — así que lo recreamos aquí, pero en vez de llamar a
 * Apps Script directamente, hace un fetch() a la API que dejamos
 * corriendo en Apps Script (ver Code.gs del backend).
 *
 * Gracias a esto, NINGÚN otro archivo .js tuvo que reescribirse: siguen
 * usando exactamente `google.script.run.withSuccessHandler(...).withFailureHandler(...).nombreFuncion(args)`
 * como antes.
 */

// ⚠️ CONFIGURA ESTO: pega aquí la URL de tu implementación de Apps Script
// terminada en /exec (la que usan tú y tu equipo, la que pide login).
const URL_API_BACKEND = 'https://script.google.com/macros/s/AKfycbxhMbLscLqAKEe8tnXYVBP1nLSTMLHwCiIWEQFnOzN6gw3Nv2YTHhU3Y6CzYzFPZjBJ/exec';

const CLAVE_TOKEN_LOCALSTORAGE = 'svt_token';

function obtenerTokenGuardado() {
  return localStorage.getItem(CLAVE_TOKEN_LOCALSTORAGE) || '';
}
function guardarToken(token) {
  localStorage.setItem(CLAVE_TOKEN_LOCALSTORAGE, token);
}
function borrarTokenGuardado() {
  localStorage.removeItem(CLAVE_TOKEN_LOCALSTORAGE);
}

/**
 * Llama a una función del backend por su nombre. Devuelve una Promesa
 * (además de ser usada internamente por el shim de abajo).
 */
function llamarApi(nombreFuncion, argumentos) {
  return fetch(URL_API_BACKEND, {
    method: 'POST',
    // Content-Type: text/plain evita que el navegador dispare una
    // petición OPTIONS de preflight (que Apps Script no sabe responder).
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({
      fn: nombreFuncion,
      args: argumentos || [],
      token: obtenerTokenGuardado()
    })
  })
    .then(function (respuestaHttp) {
      if (!respuestaHttp.ok) {
        throw new Error('Error de red (HTTP ' + respuestaHttp.status + ')');
      }
      return respuestaHttp.json();
    })
    .then(function (resultado) {
      if (!resultado.ok) {
        throw new Error(resultado.error || 'Error desconocido del servidor.');
      }
      return resultado.data;
    });
}

/**
 * Recrea la interfaz de google.script.run usando un Proxy: cualquier
 * propiedad que se le pida (por ejemplo ".listarTraslados") se convierte
 * en una función que llama a llamarApi() con ese nombre.
 */
function crearGoogleScriptRunFalso() {
  let manejadorExito = function () {};
  let manejadorError = function (error) { console.error('Error sin manejar:', error); };

  const base = {
    withSuccessHandler: function (fn) { manejadorExito = fn; return proxy; },
    withFailureHandler: function (fn) { manejadorError = fn; return proxy; }
  };

  var proxy = new Proxy(base, {
    get: function (objetivo, propiedad) {
      if (propiedad in objetivo) return objetivo[propiedad];
      return function () {
        const argumentos = Array.prototype.slice.call(arguments);
        llamarApi(propiedad, argumentos)
          .then(function (datos) { manejadorExito(datos); })
          .catch(function (error) { manejadorError({ message: error.message }); });
        return proxy;
      };
    }
  });

  return proxy;
}

window.google = window.google || {};
window.google.script = window.google.script || {};
Object.defineProperty(window.google.script, 'run', {
  get: function () { return crearGoogleScriptRunFalso(); },
  configurable: true
});
