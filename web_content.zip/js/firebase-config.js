/**
 * firebase-config.js
 * Configuración del proyecto de Firebase (Traslados SVT).
 * Estos valores NO son secretos (están pensados para ir en el navegador),
 * la seguridad real la dan las Reglas de Firestore (firestore.rules) y
 * la autenticación, no este archivo.
 */
const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyBntkLpNW6jYDc60GIIoOWJrt_LWBa7P1U',
  authDomain: 'traslados-svt.firebaseapp.com',
  projectId: 'traslados-svt',
  storageBucket: 'traslados-svt.firebasestorage.app',
  messagingSenderId: '426154369323',
  appId: '1:426154369323:web:d7ab3d5843399905c8656e'
};
