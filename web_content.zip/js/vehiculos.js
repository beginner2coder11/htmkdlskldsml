  // Etiqueta para mostrar un vehículo en listas, tarjetas y menús
  // desplegables ahora que ya no existe el número económico.
  function etiquetaVehiculo(v) {
    if (!v) return '';
    const nombre = [v.marca, v.modelo].filter(Boolean).join(' ') || 'Vehículo';
    return v.placas ? nombre + ' (' + v.placas + ')' : nombre;
  }

  const OPCIONES_COMBUSTIBLE = ['Gasolina', 'Diésel', 'Eléctrico'];

  // Catálogo de marcas y modelos reales que existen en el mercado
  // mexicano (incluye pickups, vans y utilitarios comunes para este tipo
  // de traslados). Se combina con lo que ya exista en tus vehículos
  // registrados, y siempre puedes usar "Otro" para algo que no aparezca.
  const CATALOGO_MARCAS_MODELOS = {
    'Nissan': ['NP300', 'Frontier', 'Urvan', 'Versa', 'Sentra', 'March', 'Tsuru', 'Kicks', 'X-Trail'],
    'Chevrolet': ['Silverado', 'Cheyenne', 'S10', 'Aveo', 'Onix', 'Suburban', 'Express', 'Tornado'],
    'Toyota': ['Hilux', 'HiAce', 'Corolla', 'Yaris', 'RAV4', 'Land Cruiser'],
    'Ford': ['Ranger', 'F-150', 'Transit', 'Fiesta', 'Explorer', 'Lobo'],
    'Volkswagen': ['Saveiro', 'Crafter', 'Jetta', 'Vento', 'Gol', 'Amarok'],
    'Honda': ['CR-V', 'City', 'Civic', 'HR-V'],
    'Kia': ['Rio', 'Forte', 'Sportage', 'K2500', 'Pregio'],
    'Hyundai': ['H1', 'Accent', 'Elantra', 'Tucson', 'Grand i10'],
    'Mazda': ['Mazda 2', 'Mazda 3', 'CX-5', 'BT-50'],
    'Renault': ['Kangoo', 'Duster', 'Logan', 'Master'],
    'Dodge': ['RAM 2500', 'RAM 1500', 'Attitude', 'Journey'],
    'Jeep': ['Wrangler', 'Compass', 'Cherokee', 'Grand Cherokee'],
    'Mitsubishi': ['L200', 'Outlander', 'ASX'],
    'Suzuki': ['Vitara', 'Swift', 'Ertiga'],
    'Isuzu': ['D-Max', 'NPR', 'NHR'],
    'Fiat': ['Strada', 'Doblo', 'Ducato', 'Mobi'],
    'Mercedes-Benz': ['Sprinter', 'Vito'],
    'Volvo': ['XC60', 'FH']
  };

  function valoresUnicos(vehiculos, campo) {
    const vistos = {};
    const resultado = [];
    vehiculos.forEach(function (v) {
      const val = (v[campo] || '').toString().trim();
      if (val && !vistos[val]) { vistos[val] = true; resultado.push(val); }
    });
    return resultado;
  }

  // Guarda el catálogo de vehículos ya registrados mientras el formulario
  // de vehículo está abierto, para poder recalcular los modelos cuando
  // cambia la marca seleccionada.
  let VF_CATALOGO_VEHICULOS = [];

  function marcasDisponibles() {
    const marcas = Object.keys(CATALOGO_MARCAS_MODELOS).slice();
    valoresUnicos(VF_CATALOGO_VEHICULOS, 'marca').forEach(function (m) { if (marcas.indexOf(m) === -1) marcas.push(m); });
    marcas.sort();
    return marcas;
  }

  function modelosDisponibles(marca) {
    const modelos = (CATALOGO_MARCAS_MODELOS[marca] || []).slice();
    VF_CATALOGO_VEHICULOS.filter(function (v) { return v.marca === marca; }).forEach(function (v) {
      const mo = (v.modelo || '').trim();
      if (mo && modelos.indexOf(mo) === -1) modelos.push(mo);
    });
    return modelos;
  }

  // Select con opciones precargadas (marcas/modelos reales del mercado +
  // lo que ya exista en tus vehículos), más una opción "Otro" que revela
  // un campo de texto para un valor que no esté en la lista.
  function campoSelectConOtro(id, etiqueta, opciones, valorActual, onchangeExtra) {
    const lista = opciones.slice();
    if (valorActual && lista.indexOf(valorActual) === -1) lista.unshift(valorActual);
    const opcionesHtml = ['<option value="">Selecciona...</option>']
      .concat(lista.map(function (op) {
        return '<option value="' + escaparHtml(op) + '"' + (op === valorActual ? ' selected' : '') + '>' + escaparHtml(op) + '</option>';
      }))
      .concat(['<option value="__otro__">Otro (especificar)...</option>'])
      .join('');
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<select id="' + id + '" style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;" onchange="alternarCampoOtro(this);' + (onchangeExtra || '') + '">' + opcionesHtml + '</select>' +
      '<input type="text" id="' + id + '-otro" placeholder="Especifica ' + etiqueta.toLowerCase() + '" style="display:none; width:100%; padding:8px; margin-top:6px; border:1px solid var(--color-borde); border-radius:6px;">' +
    '</div>';
  }

  function campoSelectModelo(marca, valorActual) {
    return campoSelectConOtro('vf-modelo', 'Modelo', modelosDisponibles(marca), valorActual);
  }

  function alCambiarMarcaVehiculo(select) {
    const marca = select.value === '__otro__' ? '' : select.value;
    const contenedor = document.getElementById('contenedor-modelo-vehiculo');
    if (contenedor) contenedor.innerHTML = campoSelectModelo(marca, '');
  }

  function alternarCampoOtro(select) {
    const input = document.getElementById(select.id + '-otro');
    if (!input) return;
    input.style.display = select.value === '__otro__' ? 'block' : 'none';
  }

  function valorCampoConOtro(id) {
    const select = document.getElementById(id);
    if (select.value === '__otro__') {
      const otro = document.getElementById(id + '-otro');
      return otro ? otro.value.trim() : '';
    }
    return select.value;
  }

  // Campo de placas con formato mexicano XXX-000-X: mientras se escribe,
  // se limpia a mayúsculas/alfanumérico y se insertan los guiones solos.
  function campoPlacas(id, etiqueta, valor) {
    return '<div style="margin-bottom:10px;"><label style="display:block; font-size:13px; margin-bottom:4px;">' + etiqueta + '</label>' +
      '<input type="text" id="' + id + '" value="' + escaparHtml(formatearPlacas(valor || '')) + '" placeholder="ABC-123-D" maxlength="9" ' +
      'style="width:100%; padding:8px; border:1px solid var(--color-borde); border-radius:6px;" oninput="this.value = formatearPlacas(this.value)"></div>';
  }

  function formatearPlacas(valorCrudo) {
    const limpio = (valorCrudo || '').toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 7);
    let resultado = limpio.substring(0, 3);
    if (limpio.length > 3) resultado += '-' + limpio.substring(3, 6);
    if (limpio.length > 6) resultado += '-' + limpio.substring(6, 7);
    return resultado;
  }

  // Lista de años para el select: los años ya usados en el catálogo, más
  // un rango razonable (actual +1 hasta 20 años atrás), sin duplicados.
  function opcionesAnios(catalogoVehiculos) {
    const anioActual = new Date().getFullYear();
    const set = {};
    const anios = [];
    for (let y = anioActual + 1; y >= anioActual - 20; y--) { const s = String(y); set[s] = true; anios.push(s); }
    valoresUnicos(catalogoVehiculos, 'anio').forEach(function (a) { if (!set[a]) { set[a] = true; anios.push(a); } });
    anios.sort(function (a, b) { return Number(b) - Number(a); });
    return anios;
  }

  function cargarVistaVehiculos() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Vehículos</h2>' +
        '<button class="primario" onclick="mostrarFormularioVehiculo()">+ Nuevo vehículo</button>' +
      '</div>' +
      '<div id="lista-vehiculos">Cargando...</div>';

    google.script.run
      .withSuccessHandler(renderizarListaVehiculos)
      .withFailureHandler(function (error) { document.getElementById('lista-vehiculos').innerHTML = '<p>Error: ' + escaparHtml(error.message) + '</p>'; })
      .listarVehiculos('');
  }

  function renderizarListaVehiculos(vehiculos) {
    const contenedor = document.getElementById('lista-vehiculos');
    if (!vehiculos.length) { contenedor.innerHTML = '<div class="tarjeta estado-vacio"><span class="icono-vacio">🚗</span>No hay vehículos registrados.</div>'; return; }
    contenedor.innerHTML = vehiculos.map(function (v) {
      const colorEstado = v.estado === 'Activo' ? 'verde' : 'rojo';
      return (
        '<div class="tarjeta" style="cursor:pointer;" onclick="mostrarFormularioVehiculo(\'' + v.id_vehiculo + '\')">' +
          '<div style="display:flex; justify-content:space-between;">' +
            '<strong>' + escaparHtml(etiquetaVehiculo(v)) + '</strong>' +
            '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(v.estado || '') + '</span>' +
          '</div>' +
          '<div style="color:var(--gris); font-size:13px;">Placas: ' + escaparHtml(v.placas || '') + '</div>' +
        '</div>'
      );
    }).join('');
  }

  function mostrarFormularioVehiculo(idVehiculo) {
    Promise.all([
      new Promise(function (resolve, reject) {
        if (!idVehiculo) { resolve(null); return; }
        google.script.run.withSuccessHandler(resolve).withFailureHandler(reject).obtenerVehiculo(idVehiculo);
      }),
      new Promise(function (resolve) {
        // Catálogo de vehículos existentes, para precargar sugerencias de
        // marca y modelo con datos que ya están en uso.
        google.script.run.withSuccessHandler(resolve).withFailureHandler(function () { resolve([]); }).listarVehiculos('');
      })
    ]).then(function (resultados) {
      renderizarFormularioVehiculo(resultados[0], resultados[1]);
    }).catch(function (e) { alert(e.message); });
  }

  function renderizarFormularioVehiculo(vehiculo, catalogoVehiculos) {
    const esEdicion = !!vehiculo;
    vehiculo = vehiculo || {};
    catalogoVehiculos = catalogoVehiculos || [];
    VF_CATALOGO_VEHICULOS = catalogoVehiculos;

    const html =
      '<div class="tarjeta">' +
        '<h3>' + (esEdicion ? 'Editar vehículo' : 'Nuevo vehículo') + '</h3>' +
        campoSelectConOtro('vf-marca', 'Marca', marcasDisponibles(), vehiculo.marca, 'alCambiarMarcaVehiculo(this)') +
        '<div id="contenedor-modelo-vehiculo">' + campoSelectModelo(vehiculo.marca, vehiculo.modelo) + '</div>' +
        campoSelect('vf-anio', 'Año', opcionesAnios(catalogoVehiculos), vehiculo.anio, true) +
        campoPlacas('vf-placas', 'Placas', vehiculo.placas) +
        campoTexto('vf-vin', 'VIN', vehiculo.vin) +
        campoSelect('vf-combustible', 'Tipo de combustible', OPCIONES_COMBUSTIBLE, vehiculo.tipo_combustible, true) +
        campoSelect('vf-estado', 'Estado', ['Activo', 'Fuera de servicio'], vehiculo.estado) +
        campoTextarea('vf-observaciones', 'Observaciones', vehiculo.observaciones) +
        '<div style="margin-top:12px;">' +
          '<button class="primario" onclick="guardarVehiculo(' + (esEdicion ? "'" + vehiculo.id_vehiculo + "'" : 'null') + ')">Guardar</button> ' +
          '<button onclick="cargarVistaVehiculos()">Cancelar</button>' +
        '</div>' +
      '</div>';

    document.getElementById('contenido-principal').innerHTML = html;
  }

  function guardarVehiculo(idVehiculo) {
    const datos = {
      marca: valorCampoConOtro('vf-marca'),
      modelo: valorCampoConOtro('vf-modelo'),
      anio: document.getElementById('vf-anio').value,
      placas: document.getElementById('vf-placas').value,
      vin: document.getElementById('vf-vin').value,
      tipo_combustible: document.getElementById('vf-combustible').value,
      estado: document.getElementById('vf-estado').value,
      observaciones: document.getElementById('vf-observaciones').value
    };

    if (!datos.marca || !datos.modelo) { alert('Marca y modelo son obligatorios.'); return; }
    if (!datos.placas) { alert('Las placas son obligatorias.'); return; }

    if (idVehiculo) {
      google.script.run.withSuccessHandler(function () { cargarVistaVehiculos(); }).withFailureHandler(function (e) { alert(e.message); }).actualizarVehiculo(idVehiculo, datos);
    } else {
      google.script.run.withSuccessHandler(function () { cargarVistaVehiculos(); }).withFailureHandler(function (e) { alert(e.message); }).crearVehiculo(datos);
    }
  }
