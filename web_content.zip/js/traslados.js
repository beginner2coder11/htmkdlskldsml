  // "TRASLADOS_CACHE" guarda la lista completa que ya se trajo del
  // servidor, para poder filtrarla por folio sin volver a pedirla cada
  // vez que se teclea un dígito.
  let TRASLADOS_CACHE = [];

  function cargarVistaTraslados() {
    const contenedor = document.getElementById('contenido-principal');
    contenedor.innerHTML = '<p>Cargando traslados...</p>';

    google.script.run
      .withSuccessHandler(function (traslados) {
        TRASLADOS_CACHE = traslados;
        renderizarListaTraslados(traslados);
      })
      .withFailureHandler(function (error) {
        contenedor.innerHTML = '<p>Error al cargar traslados: ' + escaparHtml(error.message) + '</p>';
      })
      .listarTraslados({});
  }

  // La parte del folio "SVT-AAAA-" nunca la teclea nadie: siempre es igual
  // (solo cambia una vez al año). El buscador la muestra fija y solo deja
  // teclear los 5 dígitos consecutivos.
  function prefijoFolioActual() {
    return 'SVT-' + new Date().getFullYear() + '-';
  }

  function renderizarListaTraslados(traslados) {
    const contenedor = document.getElementById('contenido-principal');

    const encabezado =
      '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
        '<h2 style="margin:0;">Traslados</h2>' +
        (SESION.rol !== 'Conductor'
          ? '<button class="primario" onclick="navegarA(\'nuevo-traslado\')">+ Nuevo traslado</button>'
          : '') +
      '</div>' +
      '<div class="buscador-folio">' +
        '<span class="buscador-folio-prefijo">' + escaparHtml(prefijoFolioActual()) + '</span>' +
        '<input type="text" id="buscador-folio-digitos" inputmode="numeric" placeholder="00000" maxlength="5" oninput="filtrarTrasladosPorFolio(this.value)">' +
      '</div>' +
      '<div id="lista-traslados"></div>';

    contenedor.innerHTML = encabezado;
    pintarListaTraslados(traslados);
  }

  function filtrarTrasladosPorFolio(textoCrudo) {
    const campo = document.getElementById('buscador-folio-digitos');
    const digitos = textoCrudo.replace(/\D/g, '').slice(0, 5);
    if (campo.value !== digitos) campo.value = digitos; // descarta lo que no sea número

    if (!digitos) { pintarListaTraslados(TRASLADOS_CACHE); return; }

    const prefijo = prefijoFolioActual();
    const filtrados = TRASLADOS_CACHE.filter(function (t) {
      if (!t.folio || t.folio.indexOf(prefijo) !== 0) return false;
      return t.folio.slice(prefijo.length).indexOf(digitos) !== -1;
    });
    pintarListaTraslados(filtrados);
  }

  function pintarListaTraslados(traslados) {
    const destino = document.getElementById('lista-traslados');
    if (!destino) return;

    if (!traslados.length) {
      destino.innerHTML = TRASLADOS_CACHE.length
        ? '<div class="tarjeta estado-vacio"><span class="icono-vacio">🔎</span>Ningún folio coincide con esos dígitos.</div>'
        : '<div class="tarjeta estado-vacio"><span class="icono-vacio">🚑</span>No hay traslados registrados todavía.<br><span style="font-size:12px;">Toca "+ Nuevo traslado" para crear el primero.</span></div>';
      return;
    }

    // Los más recientes primero (por fecha de solicitud).
    traslados = traslados.slice().sort(function (a, b) {
      return new Date(b.fecha_creacion || b.fecha_solicitud || 0) - new Date(a.fecha_creacion || a.fecha_solicitud || 0);
    });

    const puedeEditar = SESION.rol === 'Administrador' || SESION.rol === 'Coordinador';
    const puedeEliminar = SESION.rol === 'Administrador';

    destino.innerHTML = traslados.map(function (t) {
      const colorEstado = COLOR_POR_ESTADO[t.estado_actual] || 'gris';

      const botones =
        (puedeEditar ? '<button data-accion="editar" data-folio="' + t.folio + '">✏️ Editar</button>' : '') +
        (puedeEliminar ? '<button data-accion="eliminar" data-folio="' + t.folio + '" style="color:#b42318;">🗑️ Eliminar</button>' : '');

      return (
        '<div class="tarjeta tarjeta-traslado" data-folio="' + t.folio + '">' +
          '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">' +
            '<strong>' + escaparHtml(t.folio) + '</strong>' +
            '<span class="badge-estado badge-' + colorEstado + '">' + escaparHtml(t.estado_actual) + '</span>' +
          '</div>' +
          '<div style="font-size:14px; margin-top:6px; line-height:1.5;">' +
            (t.paciente_nombre ? '<div><strong>Paciente:</strong> ' + escaparHtml(t.paciente_nombre) + (t.paciente_telefono ? ' · ' + escaparHtml(t.paciente_telefono) : '') + '</div>' : '') +
            (t.institucion_nombre ? '<div><strong>Institución:</strong> ' + escaparHtml(t.institucion_nombre) + '</div>' : '') +
            '<div style="color:var(--gris);"><strong>Cita:</strong> ' + escaparHtml(formatearFecha(t.fecha_cita)) + (t.hora_cita ? ' ' + escaparHtml(t.hora_cita) : '') + '</div>' +
            (t.motivo_traslado ? '<div style="color:var(--gris);"><strong>Motivo:</strong> ' + escaparHtml(t.motivo_traslado) + '</div>' : '') +
            (t.acompanante_nombre ? '<div style="color:var(--gris);"><strong>Acompañante:</strong> ' + escaparHtml(t.acompanante_nombre) + (t.acompanante_telefono ? ' · ' + escaparHtml(t.acompanante_telefono) : '') + '</div>' : '') +
          '</div>' +
          (botones ? '<div class="acciones-tarjeta-traslado">' + botones + '</div>' : '') +
        '</div>'
      );
    }).join('');

    // Un solo listener delegado: distingue si se tocó la tarjeta (abre
    // detalle) o alguno de los botones (edita/elimina), y en ese caso
    // NO deja que el clic siga hacia la tarjeta.
    destino.querySelectorAll('.tarjeta-traslado').forEach(function (tarjeta) {
      tarjeta.addEventListener('click', function (evento) {
        const boton = evento.target.closest('button[data-accion]');
        const folio = tarjeta.dataset.folio;

        if (boton) {
          evento.stopPropagation();
          if (boton.dataset.accion === 'editar') {
            mostrarFormularioEditarTraslado(folio);
          } else if (boton.dataset.accion === 'eliminar') {
            confirmarEliminarTraslado(folio);
          }
          return;
        }

        verDetalleTraslado(folio);
      });
    });
  }

  function formatearFecha(valor) {
    if (!valor) return '';
    const fecha = fechaLocalDesdeSoloFecha(valor);
    if (isNaN(fecha.getTime())) return valor;
    return fecha.toLocaleDateString('es-MX');
  }
