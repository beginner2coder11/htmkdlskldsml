/**
 * firebase-shim.js
 * Reemplaza a js/api-shim.js. Todos los módulos (traslados.js, pacientes.js,
 * etc.) siguen llamando exactamente igual a
 * `google.script.run.withSuccessHandler(...).withFailureHandler(...).nombreFuncion(args)`
 * — NINGÚN otro archivo .js tuvo que cambiar.
 *
 * La diferencia es que ahora, en vez de hacer fetch() a una implementación
 * de Apps Script, estas funciones hablan directamente con Firebase
 * (Firestore + Authentication) desde el navegador. Esto elimina el "viaje
 * redondo" a través de Apps Script (que tenía arranques en frío y límites
 * de cuota), por eso la app responde más rápido.
 *
 * Requiere que en el HTML, ANTES de este archivo, se hayan cargado:
 *   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-app-compat.js"></script>
 *   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-auth-compat.js"></script>
 *   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore-compat.js"></script>
 *   <script src="js/firebase-config.js"></script>
 */

firebase.initializeApp(FIREBASE_CONFIG);
const db = firebase.firestore();
const auth = firebase.auth();
// Guarda datos localmente para que la app cargue instantáneo en la
// siguiente visita y funcione un rato sin conexión.
db.enablePersistence({ synchronizeTabs: true }).catch(function () {
  /* si hay varias pestañas abiertas o el navegador no lo soporta, no pasa nada grave */
});

const CLAVE_TOKEN_LOCALSTORAGE = 'svt_token';
function obtenerTokenGuardado() { return localStorage.getItem(CLAVE_TOKEN_LOCALSTORAGE) || ''; }
function guardarToken(token) { localStorage.setItem(CLAVE_TOKEN_LOCALSTORAGE, token); }
function borrarTokenGuardado() { localStorage.removeItem(CLAVE_TOKEN_LOCALSTORAGE); }

let SESION_ACTUAL = null;

// Matriz de permisos por módulo y rol — idéntica a la que tenías en Auth.gs.
// true = acceso permitido, false = sin acceso, 'lectura' = solo ver,
// 'propios' = solo lo propio (usado por Conductor en traslados).
const PERMISOS = {
  Administrador: {
    dashboard: true, traslados: true, aceptaciones: true, pases: true, pacientes: true, instituciones: true,
    vehiculos: true, conductores: true,
    reportes: true, usuarios: true, configuracion: true
  },
  Coordinador: {
    dashboard: true, traslados: true, aceptaciones: true, pases: true, pacientes: true, instituciones: true,
    vehiculos: true, conductores: true,
    reportes: true, usuarios: false, configuracion: false
  },
  Conductor: {
    dashboard: false, traslados: 'propios', aceptaciones: false, pases: false, pacientes: false, instituciones: false,
    vehiculos: false, conductores: false,
    reportes: false, usuarios: false, configuracion: false
  },
  Consulta: {
    dashboard: true, traslados: 'lectura', aceptaciones: 'lectura', pases: 'lectura', pacientes: 'lectura', instituciones: 'lectura',
    vehiculos: 'lectura', conductores: 'lectura',
    reportes: true, usuarios: false, configuracion: false
  }
};

const TITULOS_REPORTE = {
  traslados_realizados: 'Traslados realizados',
  traslados_cancelados: 'Traslados cancelados',
  pacientes_transportados: 'Pacientes transportados',
  por_institucion: 'Traslados por institución',
  por_conductor: 'Traslados por conductor'
};

// ---------------------------------------------------------------------
// Utilidades generales (equivalentes a Utils.gs)
// ---------------------------------------------------------------------

function generarId(prefijo) {
  const marcaTiempo = Date.now().toString(36);
  const azar = Math.random().toString(36).substring(2, 7);
  return (prefijo ? prefijo + '_' : '') + marcaTiempo + azar;
}

// Genera un id de paciente predecible a partir de nombre + teléfono, para
// que el formulario público pueda detectar "es la misma persona de antes"
// sin necesitar leer toda la colección de pacientes (que por privacidad
// no puede ver). Misma persona (mismo nombre + mismo teléfono) siempre
// cae en el mismo id; no hace falta consultarlo antes de saber su id.
function idPacientePredecible(nombreCompleto, telefono) {
  const nombreNormalizado = String(nombreCompleto)
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quita acentos
    .toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  const telefonoDigitos = String(telefono).replace(/\D/g, '');
  return 'pac_' + telefonoDigitos + '_' + nombreNormalizado;
}

// Convierte un texto de fecha SIN HORA ("2026-09-10", el valor que dan
// los <input type="date">) en una fecha LOCAL, evitando el error clásico
// de JavaScript: `new Date("2026-09-10")` lo interpreta como medianoche
// UTC, y con funciones como .toLocaleDateString()/.getDate() eso se ve
// como el día anterior en cualquier huso horario negativo (como México).
// Para fechas con hora incluida (timestamps normales), se comporta igual
// que `new Date(valor)` de siempre.
function fechaLocalDesdeSoloFecha(valor) {
  if (typeof valor === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(valor)) {
    const partes = valor.split('-');
    return new Date(Number(partes[0]), Number(partes[1]) - 1, Number(partes[2]));
  }
  return new Date(valor);
}

function calcularEdad(fechaNacimiento) {
  if (!fechaNacimiento) return '';
  const hoy = new Date();
  const nacimiento = fechaLocalDesdeSoloFecha(fechaNacimiento);
  if (isNaN(nacimiento.getTime())) return '';
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mesDiferencia = hoy.getMonth() - nacimiento.getMonth();
  if (mesDiferencia < 0 || (mesDiferencia === 0 && hoy.getDate() < nacimiento.getDate())) edad--;
  return edad;
}

function minutosEntre(inicio, fin) {
  if (!inicio || !fin) return '';
  const msInicio = new Date(inicio).getTime();
  const msFin = new Date(fin).getTime();
  if (isNaN(msInicio) || isNaN(msFin)) return '';
  return Math.round((msFin - msInicio) / 60000);
}

function formatearFechaDDMMYYYY(valor) {
  if (!valor) return '';
  const fecha = new Date(valor);
  if (isNaN(fecha.getTime())) return String(valor);
  const d = String(fecha.getDate()).padStart(2, '0');
  const m = String(fecha.getMonth() + 1).padStart(2, '0');
  return d + '/' + m + '/' + fecha.getFullYear();
}

function formatearHoraHHMM(valor) {
  if (!valor) return '';
  const fecha = new Date(valor);
  if (isNaN(fecha.getTime())) return '';
  const h = String(fecha.getHours()).padStart(2, '0');
  const m = String(fecha.getMinutes()).padStart(2, '0');
  return h + ':' + m;
}

// Convierte un documento de Firestore a un objeto plano, transformando
// cualquier Timestamp en texto ISO (para que `new Date(campo)` del resto
// del código siga funcionando exactamente igual que con Sheets).
function docToObj(doc) {
  const data = doc.data() || {};
  const obj = Object.assign({}, data);
  Object.keys(obj).forEach(function (k) {
    if (obj[k] && typeof obj[k].toDate === 'function') obj[k] = obj[k].toDate().toISOString();
  });
  return obj;
}

async function coleccionComoArreglo(nombre) {
  const snap = await db.collection(nombre).get();
  return snap.docs.map(docToObj);
}

function exigirPermiso(modulo) {
  if (!SESION_ACTUAL) throw new Error('Sesión no iniciada. Inicia sesión para continuar.');
  const permisosRol = PERMISOS[SESION_ACTUAL.rol] || {};
  const permiso = permisosRol.hasOwnProperty(modulo) ? permisosRol[modulo] : false;
  if (permiso === false) throw new Error('No tienes permiso para acceder al módulo: ' + modulo);
  return permiso;
}

async function registrarAuditoria(usuario, accion, modulo, registroAfectado, detalle) {
  const ahora = new Date();
  try {
    await db.collection('auditoria').add({
      usuario: usuario, accion: accion, modulo: modulo,
      registro_afectado: registroAfectado,
      fecha: ahora.toISOString().slice(0, 10),
      hora: ahora.toTimeString().slice(0, 8),
      detalle: detalle
    });
  } catch (e) { console.warn('No se pudo registrar auditoría:', e.message); }
}

// Folio consecutivo SVT-YYYY-NNNNN, generado con una transacción atómica
// (equivalente al LockService + hoja "control" del backend anterior).
async function generarFolio() {
  const ref = db.collection('control').doc('folios');
  return db.runTransaction(async function (tx) {
    const snap = await tx.get(ref);
    const anioActual = new Date().getFullYear();
    const ultimo = snap.exists ? (snap.data().ultimo_consecutivo_folio || 0) : 0;
    const nuevo = ultimo + 1;
    tx.set(ref, { ultimo_consecutivo_folio: nuevo, anio_folio: anioActual }, { merge: true });
    return 'SVT-' + anioActual + '-' + String(nuevo).padStart(5, '0');
  });
}

function cargarScriptExterno(src) {
  return new Promise(function (resolve, reject) {
    if (document.querySelector('script[src="' + src + '"]')) { resolve(); return; }
    const s = document.createElement('script');
    s.src = src;
    s.onload = function () { resolve(); };
    s.onerror = function () { reject(new Error('No se pudo cargar ' + src)); };
    document.head.appendChild(s);
  });
}

async function asegurarLibreriasReporte() {
  if (!window.XLSX) await cargarScriptExterno('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js');
  if (!window.jspdf) await cargarScriptExterno('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
  if (!(window.jspdf && window.jspdf.jsPDF && window.jspdf.jsPDF.API && window.jspdf.jsPDF.API.autoTable)) {
    await cargarScriptExterno('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js');
  }
}

// Garantiza que exista una sesión de Firebase Auth (con nombre o anónima)
// antes de dejar pasar una llamada al formulario público.
async function asegurarSesionParaPublico() {
  if (auth.currentUser) return;
  await auth.signInAnonymously();
}

function esperarPrimerEstadoAuth() {
  return new Promise(function (resolve) {
    const cancelar = auth.onAuthStateChanged(function (user) { cancelar(); resolve(user); });
  });
}

// ---------------------------------------------------------------------
// Auth.gs
// ---------------------------------------------------------------------

async function iniciarSesion(correo, password, recordarme) {
  if (!correo || !password) throw new Error('Escribe tu usuario y contraseña.');
  await auth.setPersistence(recordarme ? firebase.auth.Auth.Persistence.LOCAL : firebase.auth.Auth.Persistence.SESSION);

  let credencial;
  try {
    credencial = await auth.signInWithEmailAndPassword(String(correo).trim().toLowerCase(), password);
  } catch (e) {
    throw new Error('Usuario o contraseña incorrectos.');
  }

  const uid = credencial.user.uid;
  let snap = await db.collection('usuarios').doc(uid).get();

  if (!snap.exists) {
    // Si todavía no hay NINGÚN usuario en el sistema, el primero en entrar
    // se vuelve Administrador automáticamente (para no depender de la
    // consola de Firebase la primera vez). Útil sobre todo en pruebas.
    const algunUsuario = await db.collection('usuarios').limit(1).get();
    if (algunUsuario.empty) {
      await db.collection('usuarios').doc(uid).set({
        nombre_completo: credencial.user.email,
        correo: credencial.user.email,
        rol: 'Administrador',
        conductor_id: '',
        activo: true,
        fecha_alta: new Date(),
        observaciones: 'Primer administrador (creado automáticamente al iniciar sesión por primera vez)'
      });
      snap = await db.collection('usuarios').doc(uid).get();
    } else {
      await auth.signOut();
      throw new Error('Tu cuenta no tiene un perfil asignado en el sistema. Pide a un Administrador que te dé de alta en el módulo Usuarios.');
    }
  }

  const u = snap.data();
  if (u.activo !== true) { await auth.signOut(); throw new Error('Tu cuenta está desactivada. Contacta al administrador.'); }

  SESION_ACTUAL = {
    nombre: u.nombre_completo, correo: u.correo, rol: u.rol,
    conductorId: u.conductor_id || null, permisos: PERMISOS[u.rol]
  };
  return Object.assign({ token: uid }, SESION_ACTUAL);
}

async function cerrarSesion() {
  try { await auth.signOut(); } catch (e) { /* noop */ }
  SESION_ACTUAL = null;
  return true;
}

async function obtenerSesion() {
  const user = await esperarPrimerEstadoAuth();
  if (!user) throw new Error('Tu sesión ya no es válida. Inicia sesión de nuevo.');
  const snap = await db.collection('usuarios').doc(user.uid).get();
  if (!snap.exists) throw new Error('Tu usuario ya no existe. Contacta al administrador.');
  const u = snap.data();
  if (u.activo !== true) throw new Error('Tu cuenta está desactivada. Contacta al administrador.');
  SESION_ACTUAL = {
    nombre: u.nombre_completo, correo: u.correo, rol: u.rol,
    conductorId: u.conductor_id || null, permisos: PERMISOS[u.rol]
  };
  return Object.assign({ token: user.uid }, SESION_ACTUAL);
}

async function cambiarMiPassword(passwordActual, passwordNueva) {
  if (!auth.currentUser) throw new Error('Sesión no iniciada. Inicia sesión para continuar.');
  if (!passwordNueva || passwordNueva.length < 6) throw new Error('La contraseña nueva debe tener al menos 6 caracteres.');
  const credencial = firebase.auth.EmailAuthProvider.credential(auth.currentUser.email, passwordActual);
  try {
    await auth.currentUser.reauthenticateWithCredential(credencial);
  } catch (e) {
    throw new Error('La contraseña actual no es correcta.');
  }
  await auth.currentUser.updatePassword(passwordNueva);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Usuarios', auth.currentUser.uid, 'Cambió su propia contraseña');
  return true;
}

// ---------------------------------------------------------------------
// Usuarios.gs (solo Administrador)
// ---------------------------------------------------------------------

async function listarUsuarios() {
  exigirPermiso('usuarios');
  const snap = await db.collection('usuarios').get();
  return snap.docs.map(function (d) { const u = docToObj(d); u.id_usuario = d.id; return u; });
}

async function obtenerUsuario(idUsuario) {
  exigirPermiso('usuarios');
  const snap = await db.collection('usuarios').doc(idUsuario).get();
  if (!snap.exists) throw new Error('No se encontró el usuario.');
  const u = docToObj(snap); u.id_usuario = snap.id; return u;
}

async function crearUsuario(datos) {
  exigirPermiso('usuarios');
  const correo = String(datos.correo_google || datos.correo || '').trim().toLowerCase();
  if (!correo) throw new Error('Falta el usuario (correo) para iniciar sesión.');
  if (!datos.password) throw new Error('Falta definir una contraseña inicial.');
  if (datos.password.length < 6) throw new Error('La contraseña debe tener al menos 6 caracteres.');
  if (!datos.rol || !PERMISOS.hasOwnProperty(datos.rol)) throw new Error('Rol inválido.');

  // Se crea el usuario de Auth en una app secundaria de Firebase para NO
  // cerrar la sesión del Administrador que está creando la cuenta (es una
  // limitación conocida de crear usuarios desde el navegador sin un backend
  // con privilegios de administrador).
  const appSecundaria = firebase.initializeApp(FIREBASE_CONFIG, 'secundaria_' + Date.now());
  try {
    const cred = await appSecundaria.auth().createUserWithEmailAndPassword(correo, datos.password);
    const uid = cred.user.uid;
    await db.collection('usuarios').doc(uid).set({
      nombre_completo: datos.nombre_completo || '',
      correo: correo,
      rol: datos.rol,
      conductor_id: datos.conductor_id || '',
      activo: datos.activo !== false,
      fecha_alta: new Date(),
      observaciones: datos.observaciones || ''
    });
    await appSecundaria.auth().signOut();
    await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Usuarios', uid, 'Creó al usuario ' + correo + ' con rol ' + datos.rol);
    return uid;
  } catch (e) {
    if (e.code === 'auth/email-already-in-use') throw new Error('Ya existe un usuario con ese correo.');
    if (e.code === 'auth/invalid-email') throw new Error('El correo no es válido.');
    throw e;
  } finally {
    await appSecundaria.delete();
  }
}

async function actualizarUsuario(idUsuario, cambios) {
  exigirPermiso('usuarios');
  const ref = db.collection('usuarios').doc(idUsuario);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el usuario.');
  if (cambios.rol && !PERMISOS.hasOwnProperty(cambios.rol)) throw new Error('Rol inválido.');

  const cambiosLimpios = Object.assign({}, cambios);
  if (cambiosLimpios.password) {
    // Desde el navegador no se puede fijar la contraseña de OTRO usuario
    // directamente (eso requeriría un backend con privilegios de admin).
    // En su lugar, se le manda un correo para que la restablezca él mismo.
    try { await auth.sendPasswordResetEmail(snap.data().correo); } catch (e) { /* noop */ }
  }
  delete cambiosLimpios.password;
  delete cambiosLimpios.id_usuario;
  delete cambiosLimpios.correo_google;
  delete cambiosLimpios.correo; // el correo no se edita, define la identidad del usuario

  await ref.update(cambiosLimpios);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Usuarios', idUsuario, 'Actualizó al usuario ' + idUsuario);
  return true;
}

// ---------------------------------------------------------------------
// Pacientes.gs / Instituciones.gs / Vehiculos.gs / Conductores.gs
// (los cuatro catálogos siguen el mismo patrón CRUD)
// ---------------------------------------------------------------------

function permisoEscrituraOLanza(modulo, mensaje) {
  const permiso = exigirPermiso(modulo);
  if (permiso === 'lectura' || permiso === 'propios') throw new Error(mensaje);
  return permiso;
}

async function listarPacientes(filtroTexto) {
  exigirPermiso('pacientes');
  let pacientes = await coleccionComoArreglo('pacientes');
  if (filtroTexto) {
    const texto = filtroTexto.toLowerCase();
    pacientes = pacientes.filter(function (p) {
      return String(p.nombre_completo).toLowerCase().indexOf(texto) !== -1 ||
             String(p.comunidad).toLowerCase().indexOf(texto) !== -1 ||
             String(p.telefono).indexOf(texto) !== -1;
    });
  }
  return pacientes.map(function (p) { p.edad = calcularEdad(p.fecha_nacimiento); return p; });
}

async function obtenerPaciente(idPaciente) {
  exigirPermiso('pacientes');
  const snap = await db.collection('pacientes').doc(idPaciente).get();
  if (!snap.exists) throw new Error('No se encontró el paciente.');
  const p = docToObj(snap); p.edad = calcularEdad(p.fecha_nacimiento); return p;
}

async function crearPaciente(datos) {
  permisoEscrituraOLanza('pacientes', 'No tienes permiso para crear pacientes.');
  if (!datos.nombre_completo) throw new Error('Falta el nombre del paciente.');
  const idPaciente = generarId('pac');
  await db.collection('pacientes').doc(idPaciente).set(Object.assign({}, datos, { id_paciente: idPaciente }));
  await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Pacientes', idPaciente, 'Creó al paciente ' + datos.nombre_completo);
  return idPaciente;
}

async function actualizarPaciente(idPaciente, cambios) {
  permisoEscrituraOLanza('pacientes', 'No tienes permiso para editar pacientes.');
  const ref = db.collection('pacientes').doc(idPaciente);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el paciente.');
  const c = Object.assign({}, cambios); delete c.id_paciente;
  await ref.update(c);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Pacientes', idPaciente, 'Actualizó al paciente ' + idPaciente);
}

async function eliminarPaciente(idPaciente) {
  permisoEscrituraOLanza('pacientes', 'No tienes permiso para eliminar pacientes.');
  const ref = db.collection('pacientes').doc(idPaciente);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el paciente.');
  const nombre = snap.data().nombre_completo;
  await ref.delete();
  await registrarAuditoria(SESION_ACTUAL.correo, 'Eliminar', 'Pacientes', idPaciente, 'Eliminó al paciente ' + nombre);
}

async function listarInstituciones(filtroTexto) {
  exigirPermiso('instituciones');
  let instituciones = await coleccionComoArreglo('instituciones');
  if (filtroTexto) {
    const texto = filtroTexto.toLowerCase();
    instituciones = instituciones.filter(function (i) {
      return String(i.nombre).toLowerCase().indexOf(texto) !== -1 || String(i.ciudad).toLowerCase().indexOf(texto) !== -1;
    });
  }
  return instituciones;
}

async function obtenerInstitucion(idInstitucion) {
  exigirPermiso('instituciones');
  const snap = await db.collection('instituciones').doc(idInstitucion).get();
  if (!snap.exists) throw new Error('No se encontró la institución.');
  return docToObj(snap);
}

async function crearInstitucion(datos) {
  permisoEscrituraOLanza('instituciones', 'No tienes permiso para crear instituciones.');
  if (!datos.nombre) throw new Error('Falta el nombre de la institución.');
  const idInstitucion = generarId('inst');
  await db.collection('instituciones').doc(idInstitucion).set(Object.assign({}, datos, { id_institucion: idInstitucion }));
  await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Instituciones', idInstitucion, 'Creó la institución ' + datos.nombre);
  return idInstitucion;
}

async function actualizarInstitucion(idInstitucion, cambios) {
  permisoEscrituraOLanza('instituciones', 'No tienes permiso para editar instituciones.');
  const ref = db.collection('instituciones').doc(idInstitucion);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró la institución.');
  const c = Object.assign({}, cambios); delete c.id_institucion;
  await ref.update(c);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Instituciones', idInstitucion, 'Actualizó la institución ' + idInstitucion);
}

async function listarVehiculos(filtroTexto) {
  exigirPermiso('vehiculos');
  let vehiculos = await coleccionComoArreglo('vehiculos');
  if (filtroTexto) {
    const texto = filtroTexto.toLowerCase();
    vehiculos = vehiculos.filter(function (v) {
      return String(v.marca).toLowerCase().indexOf(texto) !== -1 || String(v.modelo).toLowerCase().indexOf(texto) !== -1 || String(v.placas).toLowerCase().indexOf(texto) !== -1;
    });
  }
  return vehiculos;
}

async function obtenerVehiculo(idVehiculo) {
  exigirPermiso('vehiculos');
  const snap = await db.collection('vehiculos').doc(idVehiculo).get();
  if (!snap.exists) throw new Error('No se encontró el vehículo.');
  return docToObj(snap);
}

async function crearVehiculo(datos) {
  permisoEscrituraOLanza('vehiculos', 'No tienes permiso para crear vehículos.');
  if (!datos.placas) throw new Error('Faltan las placas del vehículo.');
  const idVehiculo = generarId('veh');
  await db.collection('vehiculos').doc(idVehiculo).set(Object.assign({}, datos, { id_vehiculo: idVehiculo, estado: datos.estado || 'Activo' }));
  await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Vehículos', idVehiculo, 'Creó el vehículo ' + (datos.marca || '') + ' ' + (datos.modelo || '') + ' (' + datos.placas + ')');
  return idVehiculo;
}

async function actualizarVehiculo(idVehiculo, cambios) {
  permisoEscrituraOLanza('vehiculos', 'No tienes permiso para editar vehículos.');
  const ref = db.collection('vehiculos').doc(idVehiculo);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el vehículo.');
  const c = Object.assign({}, cambios); delete c.id_vehiculo;
  await ref.update(c);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Vehículos', idVehiculo, 'Actualizó el vehículo ' + idVehiculo);
}

async function listarVehiculosActivos() {
  exigirPermiso('vehiculos');
  const vehiculos = await coleccionComoArreglo('vehiculos');
  return vehiculos.filter(function (v) { return v.estado === 'Activo'; });
}

async function obtenerAlertasVehiculos() {
  exigirPermiso('vehiculos');
  const vehiculos = await coleccionComoArreglo('vehiculos');
  const hoy = new Date();
  const en30Dias = new Date();
  en30Dias.setDate(hoy.getDate() + 30);
  const alertas = [];
  vehiculos.forEach(function (v) {
    const etiqueta = (v.marca || '') + ' ' + (v.modelo || '') + (v.placas ? ' (' + v.placas + ')' : '');
    if (v.seguro_vigencia) {
      const fechaSeguro = fechaLocalDesdeSoloFecha(v.seguro_vigencia);
      if (!isNaN(fechaSeguro.getTime()) && fechaSeguro <= en30Dias) {
        alertas.push({ tipo: 'seguro', vehiculo: etiqueta, mensaje: 'Seguro de ' + etiqueta + ' vence el ' + fechaSeguro.toLocaleDateString('es-MX') });
      }
    }
  });
  return alertas;
}

async function listarConductores(filtroTexto) {
  exigirPermiso('conductores');
  let conductores = await coleccionComoArreglo('conductores');
  if (filtroTexto) {
    const texto = filtroTexto.toLowerCase();
    conductores = conductores.filter(function (c) {
      return String(c.nombre_completo).toLowerCase().indexOf(texto) !== -1 || String(c.numero_licencia).toLowerCase().indexOf(texto) !== -1;
    });
  }
  return conductores;
}

async function obtenerConductor(idConductor) {
  exigirPermiso('conductores');
  const snap = await db.collection('conductores').doc(idConductor).get();
  if (!snap.exists) throw new Error('No se encontró el conductor.');
  return docToObj(snap);
}

async function crearConductor(datos) {
  permisoEscrituraOLanza('conductores', 'No tienes permiso para crear conductores.');
  if (!datos.nombre_completo) throw new Error('Falta el nombre del conductor.');
  const idConductor = generarId('cond');
  await db.collection('conductores').doc(idConductor).set(Object.assign({}, datos, { id_conductor: idConductor, estado: datos.estado || 'Activo' }));
  await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Conductores', idConductor, 'Creó al conductor ' + datos.nombre_completo);
  return idConductor;
}

async function actualizarConductor(idConductor, cambios) {
  permisoEscrituraOLanza('conductores', 'No tienes permiso para editar conductores.');
  const ref = db.collection('conductores').doc(idConductor);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el conductor.');
  const c = Object.assign({}, cambios); delete c.id_conductor;
  await ref.update(c);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Conductores', idConductor, 'Actualizó al conductor ' + idConductor);
}

async function listarConductoresActivos() {
  exigirPermiso('conductores');
  const conductores = await coleccionComoArreglo('conductores');
  return conductores.filter(function (c) { return c.estado === 'Activo'; });
}

// ---------------------------------------------------------------------
// Traslados.gs — CRUD + máquina de estados
// ---------------------------------------------------------------------

const TRANSICIONES_PERMITIDAS = {
  // "Pendiente de autorización" se quitó de la ruta normal: era un paso
  // intermedio que no capturaba ningún dato (idéntico en función a
  // "Solicitud recibida"), así que ahora se autoriza directo. Se deja la
  // transición de "Pendiente de autorización" en el mapa solo por
  // compatibilidad, por si algún traslado antiguo se quedó en ese estado.
  'Solicitud recibida': ['Autorizado', 'Cancelado'],
  'Pendiente de autorización': ['Autorizado', 'Cancelado'],
  'Autorizado': ['Programado', 'Cancelado'],
  'Programado': ['Vehículo asignado', 'Reprogramado', 'Cancelado'],
  'Vehículo asignado': ['En traslado', 'Reprogramado', 'Cancelado'],
  'En traslado': ['En destino', 'Paciente no se presentó'],
  'En destino': ['Regresando'],
  'Regresando': ['Finalizado'],
  'Reprogramado': ['Programado', 'Cancelado'],
  'Finalizado': [], 'Cancelado': [], 'Paciente no se presentó': []
};

async function listarTraslados(filtros) {
  const permiso = exigirPermiso('traslados');
  let traslados = await coleccionComoArreglo('traslados');

  if (permiso === 'propios') {
    traslados = traslados.filter(function (t) { return t.id_conductor === SESION_ACTUAL.conductorId; });
  }
  filtros = filtros || {};
  if (filtros.estado) traslados = traslados.filter(function (t) { return t.estado_actual === filtros.estado; });
  if (filtros.folio) {
    const f = filtros.folio.toLowerCase();
    traslados = traslados.filter(function (t) { return String(t.folio).toLowerCase().indexOf(f) !== -1; });
  }
  if (filtros.fechaDesde) traslados = traslados.filter(function (t) { return new Date(t.fecha_cita) >= new Date(filtros.fechaDesde); });
  if (filtros.fechaHasta) traslados = traslados.filter(function (t) { return new Date(t.fecha_cita) <= new Date(filtros.fechaHasta); });

  // Se resuelven aquí los nombres de paciente/institución (en vez de que
  // el frontend haga una llamada aparte por cada traslado) para que la
  // lista muestre de un jalón los datos con los que se registró la
  // solicitud. Esto es seguro incluso para el rol Conductor: ya se filtró
  // arriba a solo SUS traslados asignados, así que no se expone
  // información de pacientes ajenos.
  const [pacientes, instituciones] = await Promise.all([
    coleccionComoArreglo('pacientes'), coleccionComoArreglo('instituciones')
  ]);
  const buscar = function (arr, campo, valor) { return arr.find(function (x) { return x[campo] === valor; }); };

  return traslados.map(function (t) {
    const paciente = buscar(pacientes, 'id_paciente', t.id_paciente);
    const institucion = buscar(instituciones, 'id_institucion', t.id_institucion);
    return Object.assign({}, t, {
      paciente_nombre: paciente ? paciente.nombre_completo : '',
      paciente_telefono: paciente ? paciente.telefono : '',
      institucion_nombre: institucion ? institucion.nombre : ''
    });
  });
}

// Registro de aceptaciones: lista, para consulta rápida, todas las
// solicitudes que tienen una aceptación registrada (electrónica, del
// formulario público — esquema nuevo con aceptacion_avisos, o esquema
// anterior con consentimiento_traslado). No incluye traslados dados de
// alta manualmente en el sistema (esos no tienen aceptación electrónica).
async function listarAceptaciones() {
  exigirPermiso('aceptaciones');
  const traslados = await coleccionComoArreglo('traslados');
  const aceptados = traslados.filter(function (t) { return !!t.aceptacion_avisos || !!t.consentimiento_traslado; });

  const [pacientes, instituciones] = await Promise.all([
    coleccionComoArreglo('pacientes'), coleccionComoArreglo('instituciones')
  ]);
  const buscar = function (arr, campo, valor) { return arr.find(function (x) { return x[campo] === valor; }); };

  return aceptados.map(function (t) {
    const paciente = buscar(pacientes, 'id_paciente', t.id_paciente);
    const institucion = buscar(instituciones, 'id_institucion', t.id_institucion);
    return {
      folio: t.folio,
      estado_actual: t.estado_actual,
      paciente_nombre: paciente ? paciente.nombre_completo : '',
      institucion_nombre: institucion ? institucion.nombre : '',
      fecha_cita: t.fecha_cita || '',
      edad_paciente: t.edad_paciente || '',
      es_paciente_menor_edad: !!t.es_paciente_menor_edad,
      firmante_nombre: t.firmante_nombre || '',
      firmante_tipo: t.firmante_tipo || '',
      aceptacion_avisos: !!t.aceptacion_avisos,
      fecha_aceptacion: t.fecha_aceptacion || '',
      hora_aceptacion: t.hora_aceptacion || '',
      version_consentimiento: t.version_consentimiento || '',
      version_aviso_privacidad: t.version_aviso_privacidad || '',
      consentimiento_traslado: !!t.consentimiento_traslado,
      fecha_consentimiento: t.fecha_consentimiento || ''
    };
  });
}

async function obtenerTraslado(folio) {
  exigirPermiso('traslados');
  const snap = await db.collection('traslados').doc(folio).get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const traslado = docToObj(snap);
  const historialSnap = await db.collection('traslados').doc(folio).collection('historial').orderBy('creado').get();
  traslado.historial = historialSnap.docs.map(docToObj);
  return traslado;
}

async function registrarCambioEstado(folio, estadoAnterior, estadoNuevo, usuario, comentario) {
  const ahora = new Date();
  await db.collection('traslados').doc(folio).collection('historial').add({
    folio: folio,
    fecha: ahora.toISOString().slice(0, 10),
    hora: ahora.toTimeString().slice(0, 8),
    usuario: usuario, estado_anterior: estadoAnterior, estado_nuevo: estadoNuevo,
    comentario: comentario || '', creado: ahora
  });
}

async function crearTraslado(datos) {
  exigirPermiso('traslados');
  if (!datos.id_paciente) throw new Error('Falta seleccionar un paciente.');
  if (!datos.id_institucion) throw new Error('Falta seleccionar una institución médica.');
  if (!datos.fecha_cita) throw new Error('Falta la fecha de la cita.');

  const paciente = await db.collection('pacientes').doc(datos.id_paciente).get();
  if (!paciente.exists) throw new Error('El paciente indicado no existe.');
  const institucion = await db.collection('instituciones').doc(datos.id_institucion).get();
  if (!institucion.exists) throw new Error('La institución indicada no existe.');

  const folio = await generarFolio();
  const nuevoTraslado = Object.assign({}, datos, {
    folio: folio, estado_actual: 'Solicitud recibida',
    creado_por: SESION_ACTUAL.correo, fecha_creacion: new Date()
  });
  await db.collection('traslados').doc(folio).set(nuevoTraslado);
  await registrarCambioEstado(folio, '', 'Solicitud recibida', SESION_ACTUAL.correo, 'Traslado creado');
  await registrarAuditoria(SESION_ACTUAL.correo, 'Crear', 'Traslados', folio, 'Creó el traslado ' + folio);
  return folio;
}

async function actualizarTraslado(folio, cambios) {
  exigirPermiso('traslados');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const c = Object.assign({}, cambios); delete c.estado_actual; delete c.folio;
  await ref.update(c);
  await registrarAuditoria(SESION_ACTUAL.correo, 'Editar', 'Traslados', folio, 'Actualizó datos del traslado ' + folio);
}

async function eliminarTraslado(folio) {
  exigirPermiso('traslados');
  if (SESION_ACTUAL.rol !== 'Administrador') throw new Error('Solo un Administrador puede eliminar traslados.');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  await ref.delete();
  await registrarAuditoria(SESION_ACTUAL.correo, 'Eliminar', 'Traslados', folio, 'Eliminó el traslado ' + folio);
}

async function cambiarEstadoTraslado(folio, nuevoEstado, comentario) {
  exigirPermiso('traslados');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const traslado = docToObj(snap);
  const estadoActual = traslado.estado_actual;
  const permitidos = TRANSICIONES_PERMITIDAS[estadoActual] || [];
  if (permitidos.indexOf(nuevoEstado) === -1) throw new Error('No se puede cambiar de "' + estadoActual + '" a "' + nuevoEstado + '".');

  const cambios = { estado_actual: nuevoEstado };
  // Se guarda quién autorizó (el nombre de la sesión que hace el cambio a
  // "Autorizado" en ese momento), para poder imprimirlo en el Pase de
  // Traslados sin depender de que siga siendo el mismo usuario después.
  if (nuevoEstado === 'Autorizado') {
    cambios.autorizado_por = SESION_ACTUAL.nombre;
    cambios.autorizado_en = new Date();
  }
  await ref.update(cambios);
  await registrarCambioEstado(folio, estadoActual, nuevoEstado, SESION_ACTUAL.correo, comentario || '');
  await registrarAuditoria(SESION_ACTUAL.correo, 'Cambiar estado', 'Traslados', folio, 'Cambió el estado de "' + estadoActual + '" a "' + nuevoEstado + '"');
  return nuevoEstado;
}

// ---------------------------------------------------------------------
// Pases de Traslados guardados: se conserva una copia del PRIMER Pase de
// Traslados (PDF) generado para cada solicitud que ya esté autorizada
// (tal como se generó/imprimió en ese momento, sin depender de que los
// datos del traslado sigan siendo los mismos después). Generaciones
// posteriores del mismo folio no se vuelven a guardar.
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Pases de Traslados guardados: se conserva un SNAPSHOT (los datos con
// los que se generó, no el PDF ya renderizado) del PRIMER Pase de
// Traslados generado para cada solicitud que ya esté autorizada. El PDF
// pesa ~1.8MB por las imágenes de la plantilla — más que el límite de
// 1MB por campo de Firestore — así que en vez de guardar el archivo, se
// guardan los datos (folio, paciente e institución tal como estaban en
// ese momento) y el PDF se vuelve a generar al vuelo cuando se quiere
// ver, con la misma función que lo generó la primera vez: el resultado
// es idéntico, sin depender de que los datos del traslado sigan siendo
// los mismos después (por ejemplo, si se corrige el nombre del paciente
// más adelante, el pase guardado conserva el nombre original).
// Generaciones posteriores del mismo folio no se vuelven a guardar.
// ---------------------------------------------------------------------

async function guardarPasePrimeraVez(folio) {
  exigirPermiso('traslados');
  if (!folio) throw new Error('Falta el folio.');

  const refPase = db.collection('pases_traslado').doc(folio);
  const existente = await refPase.get();
  if (existente.exists) return { guardado: false, motivo: 'Ya había un pase guardado para este folio.' };

  const snap = await db.collection('traslados').doc(folio).get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const t = docToObj(snap);
  if (!t.autorizado_por) throw new Error('El traslado todavía no está autorizado.');

  const [paciente, institucion] = await Promise.all([
    t.id_paciente ? obtenerPaciente(t.id_paciente).catch(function () { return null; }) : null,
    t.id_institucion ? obtenerInstitucion(t.id_institucion).catch(function () { return null; }) : null
  ]);

  await refPase.set({
    folio: folio,
    traslado: t,
    paciente: paciente,
    institucion: institucion,
    generado_por: SESION_ACTUAL.nombre,
    generado_en: new Date(),
    estado_al_generar: t.estado_actual
  });
  await registrarAuditoria(SESION_ACTUAL.correo, 'Generar pase', 'Traslados', folio, 'Se guardó el primer Pase de Traslados generado para ' + folio);
  return { guardado: true };
}

async function listarPasesTraslado() {
  exigirPermiso('traslados');
  const pases = await coleccionComoArreglo('pases_traslado');
  const [pacientes, instituciones, traslados] = await Promise.all([
    coleccionComoArreglo('pacientes'), coleccionComoArreglo('instituciones'), coleccionComoArreglo('traslados')
  ]);
  const buscar = function (arr, campo, valor) { return arr.find(function (x) { return x[campo] === valor; }); };

  // La lista muestra los datos ACTUALES del traslado (para reconocerlo al
  // navegar); el snapshot congelado con el que se regenera el PDF exacto
  // se pide aparte, solo al abrir uno en particular, con obtenerPaseTraslado.
  return pases.map(function (p) {
    const t = buscar(traslados, 'folio', p.folio);
    const paciente = t ? buscar(pacientes, 'id_paciente', t.id_paciente) : null;
    const institucion = t ? buscar(instituciones, 'id_institucion', t.id_institucion) : null;
    return {
      folio: p.folio,
      generado_por: p.generado_por || '',
      generado_en: p.generado_en || '',
      estado_al_generar: p.estado_al_generar || '',
      estado_actual: t ? t.estado_actual : '',
      paciente_nombre: paciente ? paciente.nombre_completo : (p.paciente ? p.paciente.nombre_completo : ''),
      institucion_nombre: institucion ? institucion.nombre : (p.institucion ? p.institucion.nombre : ''),
      fecha_cita: t ? t.fecha_cita : (p.traslado ? p.traslado.fecha_cita : '')
    };
  });
}

async function obtenerPaseTraslado(folio) {
  exigirPermiso('traslados');
  const snap = await db.collection('pases_traslado').doc(folio).get();
  if (!snap.exists) throw new Error('No hay un pase guardado para el folio ' + folio + '.');
  return docToObj(snap);
}

// Verificación ligera (sin traer el snapshot completo) de si un folio ya
// tiene un pase guardado — la usa el detalle del traslado para decidir
// si sigue mostrando el botón de generar PDF.
async function existePaseTraslado(folio) {
  exigirPermiso('traslados');
  const snap = await db.collection('pases_traslado').doc(folio).get();
  return snap.exists;
}

async function registrarSalida(folio, datos) {
  exigirPermiso('traslados');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);

  await ref.update({
    hora_salida_real: (datos && datos.hora_salida_real) || new Date().toISOString()
  });
  return cambiarEstadoTraslado(folio, 'En traslado', 'Salida registrada');
}

async function registrarLlegadaDestino(folio, datos) {
  exigirPermiso('traslados');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const traslado = docToObj(snap);
  const horaLlegada = (datos && datos.hora_llegada_destino) || new Date().toISOString();

  await ref.update({ hora_llegada_destino: horaLlegada });
  const tiempoIda = minutosEntre(traslado.hora_salida_real, horaLlegada);
  if (tiempoIda !== '') await ref.update({ tiempo_ida: tiempoIda });
  return cambiarEstadoTraslado(folio, 'En destino', 'Llegada a destino registrada');
}

async function registrarRegreso(folio, datos) {
  exigirPermiso('traslados');
  const ref = db.collection('traslados').doc(folio);
  const snap = await ref.get();
  if (!snap.exists) throw new Error('No se encontró el traslado con folio ' + folio);
  const traslado = docToObj(snap);

  const horaSalidaDestino = (datos && datos.hora_salida_destino) || new Date().toISOString();
  const horaLlegadaOrigen = (datos && datos.hora_llegada_origen) || new Date().toISOString();
  const tiempoRegreso = minutosEntre(horaSalidaDestino, horaLlegadaOrigen);
  const tiempoEnDestino = minutosEntre(traslado.hora_llegada_destino, horaSalidaDestino);
  const tiempoIda = traslado.tiempo_ida || minutosEntre(traslado.hora_salida_real, traslado.hora_llegada_destino);
  const duracionTotal = minutosEntre(traslado.hora_salida_real, horaLlegadaOrigen);

  await ref.update({
    hora_salida_destino: horaSalidaDestino, hora_llegada_origen: horaLlegadaOrigen,
    tiempo_ida: tiempoIda, tiempo_en_destino: tiempoEnDestino, tiempo_regreso: tiempoRegreso,
    duracion_total: duracionTotal
  });

  await cambiarEstadoTraslado(folio, 'Regresando', 'Regreso registrado, procediendo a finalizar');
  return cambiarEstadoTraslado(folio, 'Finalizado', 'Traslado finalizado');
}

// ---------------------------------------------------------------------
// Dashboard.gs
// ---------------------------------------------------------------------

async function obtenerDatosDashboard() {
  exigirPermiso('dashboard');
  const traslados = await coleccionComoArreglo('traslados');
  // Se arma con las partes LOCALES de la fecha (no toISOString, que da la
  // fecha en UTC y en México, a partir de las 6pm, ya marca el día
  // siguiente). fecha_cita sí puede compararse con toISOString: al ser
  // una fecha sin hora, su instante UTC coincide siempre con el texto
  // original.
  const hoyLocal = new Date();
  const hoyStr = hoyLocal.getFullYear() + '-' + String(hoyLocal.getMonth() + 1).padStart(2, '0') + '-' + String(hoyLocal.getDate()).padStart(2, '0');
  const esHoy = function (t) { return t.fecha_cita && new Date(t.fecha_cita).toISOString().slice(0, 10) === hoyStr; };
  const enCurso = ['En traslado', 'En destino', 'Regresando'];

  const gruposEstado = {
    solicitudesPendientes: traslados.filter(function (t) { return t.estado_actual === 'Solicitud recibida'; }),
    trasladosHoy: traslados.filter(esHoy),
    programados: traslados.filter(function (t) { return t.estado_actual === 'Programado' || t.estado_actual === 'Vehículo asignado'; }),
    enCurso: traslados.filter(function (t) { return enCurso.indexOf(t.estado_actual) !== -1; }),
    finalizados: traslados.filter(function (t) { return t.estado_actual === 'Finalizado'; }),
    cancelados: traslados.filter(function (t) { return t.estado_actual === 'Cancelado'; })
  };

  const kpis = {
    solicitudesPendientes: gruposEstado.solicitudesPendientes.length,
    trasladosHoy: gruposEstado.trasladosHoy.length,
    programados: gruposEstado.programados.length,
    enCurso: gruposEstado.enCurso.length,
    finalizados: gruposEstado.finalizados.length,
    cancelados: gruposEstado.cancelados.length
  };

  const pacientes = await coleccionComoArreglo('pacientes');
  const instituciones = await coleccionComoArreglo('instituciones');
  const buscar = function (arr, campo, valor) { return arr.find(function (x) { return x[campo] === valor; }); };

  const resumenTraslado = function (t) {
    const paciente = buscar(pacientes, 'id_paciente', t.id_paciente);
    const institucion = buscar(instituciones, 'id_institucion', t.id_institucion);
    return {
      folio: t.folio,
      paciente: paciente ? paciente.nombre_completo : '',
      institucion: institucion ? institucion.nombre : '',
      fecha_cita: t.fecha_cita, hora_cita: t.hora_cita,
      estado_actual: t.estado_actual
    };
  };

  const desglose = {
    solicitudesPendientes: gruposEstado.solicitudesPendientes.map(resumenTraslado),
    trasladosHoy: gruposEstado.trasladosHoy.map(resumenTraslado),
    programados: gruposEstado.programados.map(resumenTraslado),
    enCurso: gruposEstado.enCurso.map(resumenTraslado),
    finalizados: gruposEstado.finalizados.map(resumenTraslado),
    cancelados: gruposEstado.cancelados.map(resumenTraslado)
  };

  const proximos = traslados
    .filter(function (t) { return ['Programado', 'Vehículo asignado', 'Autorizado'].indexOf(t.estado_actual) !== -1; })
    .sort(function (a, b) { return new Date(a.fecha_cita) - new Date(b.fecha_cita); })
    .slice(0, 8)
    .map(resumenTraslado);

  const porMes = {};
  traslados.forEach(function (t) {
    if (!t.fecha_solicitud) return;
    const fecha = new Date(t.fecha_solicitud);
    if (isNaN(fecha.getTime())) return;
    const clave = fecha.getFullYear() + '-' + String(fecha.getMonth() + 1).padStart(2, '0');
    porMes[clave] = (porMes[clave] || 0) + 1;
  });

  const porInstitucion = {};
  traslados.forEach(function (t) {
    if (!t.id_institucion) return;
    const institucion = buscar(instituciones, 'id_institucion', t.id_institucion);
    const nombre = institucion ? institucion.nombre : t.id_institucion;
    porInstitucion[nombre] = (porInstitucion[nombre] || 0) + 1;
  });

  return { kpis: kpis, desglose: desglose, proximosTraslados: proximos, trasladosPorMes: porMes, trasladosPorInstitucion: porInstitucion, alertasVehiculos: await obtenerAlertasVehiculos() };
}

/**
 * Versión ligera de obtenerDatosDashboard, usada para refrescar solo el
 * contador de solicitudes pendientes cada pocos segundos sin recalcular
 * todo el dashboard (gráficas, próximos traslados, etc.).
 */
async function obtenerConteoSolicitudesPendientes() {
  exigirPermiso('dashboard');
  const traslados = await coleccionComoArreglo('traslados');
  return traslados.filter(function (t) { return t.estado_actual === 'Solicitud recibida'; }).length;
}

// ---------------------------------------------------------------------
// Reportes.gs
// ---------------------------------------------------------------------

function aplicarFiltrosFecha(filas, filtros, campoFecha) {
  return filas.filter(function (f) {
    if (!f[campoFecha]) return true;
    const fecha = new Date(f[campoFecha]);
    if (filtros.fechaDesde && fecha < new Date(filtros.fechaDesde)) return false;
    if (filtros.fechaHasta && fecha > new Date(filtros.fechaHasta)) return false;
    return true;
  });
}

async function generarReporte(tipo, filtros) {
  exigirPermiso('reportes');
  filtros = filtros || {};
  const [trasladosRaw, pacientes, instituciones, conductores] = await Promise.all([
    coleccionComoArreglo('traslados'), coleccionComoArreglo('pacientes'),
    coleccionComoArreglo('instituciones'), coleccionComoArreglo('conductores')
  ]);
  const traslados = aplicarFiltrosFecha(trasladosRaw, filtros, 'fecha_cita');
  const buscar = function (arr, campo, valor) { return arr.find(function (x) { return x[campo] === valor; }); };
  const nombrePaciente = function (id) { const p = buscar(pacientes, 'id_paciente', id); return p ? p.nombre_completo : ''; };
  const nombreInstitucion = function (id) { const i = buscar(instituciones, 'id_institucion', id); return i ? i.nombre : ''; };
  const nombreConductor = function (id) { const c = buscar(conductores, 'id_conductor', id); return c ? c.nombre_completo : ''; };

  if (tipo === 'traslados_realizados') {
    const filas = traslados.filter(function (t) { return t.estado_actual === 'Finalizado'; })
      .map(function (t) { return [t.folio, nombrePaciente(t.id_paciente), nombreInstitucion(t.id_institucion), formatearFechaDDMMYYYY(t.fecha_cita), t.duracion_total || '']; });
    return { columnas: ['Folio', 'Paciente', 'Institución', 'Fecha', 'Duración (min)'], filas: filas };
  }
  if (tipo === 'traslados_cancelados') {
    const filas = traslados.filter(function (t) { return t.estado_actual === 'Cancelado'; })
      .map(function (t) { return [t.folio, nombrePaciente(t.id_paciente), formatearFechaDDMMYYYY(t.fecha_cita), t.observaciones || '']; });
    return { columnas: ['Folio', 'Paciente', 'Fecha', 'Observaciones'], filas: filas };
  }
  if (tipo === 'pacientes_transportados') {
    const conteo = {};
    traslados.filter(function (t) { return t.estado_actual === 'Finalizado'; }).forEach(function (t) {
      const nombre = nombrePaciente(t.id_paciente); conteo[nombre] = (conteo[nombre] || 0) + 1;
    });
    return { columnas: ['Paciente', 'Traslados realizados'], filas: Object.keys(conteo).map(function (n) { return [n, conteo[n]]; }) };
  }
  if (tipo === 'por_institucion') {
    const conteo = {};
    traslados.forEach(function (t) { const nombre = nombreInstitucion(t.id_institucion); if (!nombre) return; conteo[nombre] = (conteo[nombre] || 0) + 1; });
    return { columnas: ['Institución', 'Traslados'], filas: Object.keys(conteo).map(function (n) { return [n, conteo[n]]; }) };
  }
  if (tipo === 'por_conductor') {
    const conteo = {};
    traslados.forEach(function (t) {
      const nombre = nombreConductor(t.id_conductor); if (!nombre) return;
      conteo[nombre] = (conteo[nombre] || 0) + 1;
    });
    return { columnas: ['Conductor', 'Traslados'], filas: Object.keys(conteo).map(function (n) { return [n, conteo[n]]; }) };
  }
  throw new Error('Tipo de reporte no reconocido: ' + tipo);
}

async function exportarReporte(tipo, filtros, formato) {
  exigirPermiso('reportes');
  const datos = await generarReporte(tipo, filtros);
  await asegurarLibreriasReporte();

  if (formato === 'pdf') {
    const doc = new window.jspdf.jsPDF();
    doc.setFontSize(14);
    doc.text(TITULOS_REPORTE[tipo] || tipo, 14, 16);
    doc.autoTable({ head: [datos.columnas], body: datos.filas, startY: 22, styles: { fontSize: 9 } });
    return { base64: doc.output('datauristring').split(',')[1], mimeType: 'application/pdf', nombreArchivo: tipo + '.pdf' };
  }
  const hoja = window.XLSX.utils.aoa_to_sheet([datos.columnas].concat(datos.filas));
  const libro = window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(libro, hoja, 'Reporte');
  const base64 = window.XLSX.write(libro, { type: 'base64', bookType: 'xlsx' });
  return { base64: base64, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', nombreArchivo: tipo + '.xlsx' };
}

// ---------------------------------------------------------------------
// Ubicaciones.gs
// ---------------------------------------------------------------------

const MINUTOS_UBICACION_ACTIVA = 20;

async function registrarUbicacionConductor(folio, datos) {
  if (!SESION_ACTUAL) throw new Error('Sesión no iniciada. Inicia sesión para continuar.');
  if (!datos || typeof datos.lat !== 'number' || typeof datos.lng !== 'number') throw new Error('Ubicación inválida.');
  await db.collection('ubicaciones_conductores').doc(auth.currentUser.uid).set({
    conductor: SESION_ACTUAL.nombre, folio: folio || '', lat: datos.lat, lng: datos.lng,
    precision_metros: datos.precision_metros || '', marca_tiempo: datos.marca_tiempo || new Date().toISOString()
  });
  return true;
}

async function obtenerUbicacionesActivas() {
  if (SESION_ACTUAL && SESION_ACTUAL.rol === 'Conductor') throw new Error('No tienes permiso para ver este módulo.');
  const snap = await db.collection('ubicaciones_conductores').get();
  const limite = Date.now() - MINUTOS_UBICACION_ACTIVA * 60 * 1000;
  return snap.docs.map(docToObj).filter(function (u) {
    const t = new Date(u.marca_tiempo).getTime();
    return !isNaN(t) && t >= limite;
  }).map(function (u) { return { conductor: u.conductor, folio: u.folio, lat: u.lat, lng: u.lng, marca_tiempo: u.marca_tiempo }; });
}

// ---------------------------------------------------------------------
// Publico.gs — formulario público, sin sesión con nombre (usa Auth anónimo)
// ---------------------------------------------------------------------

async function listarInstitucionesPublico() {
  await asegurarSesionParaPublico();
  const instituciones = await coleccionComoArreglo('instituciones');
  return instituciones.map(function (i) { return { id_institucion: i.id_institucion, nombre: i.nombre, ciudad: i.ciudad }; });
}

async function crearSolicitudPublica(datos) {
  await asegurarSesionParaPublico();
  if (!datos.nombre_completo) throw new Error('Falta el nombre del paciente.');
  if (!datos.telefono) throw new Error('Falta un teléfono de contacto.');
  if (!datos.fecha_cita) throw new Error('Falta la fecha en que necesitas el traslado.');
  if (!datos.motivo_traslado) throw new Error('Falta indicar el motivo del traslado.');
  if (!datos.aceptacion_avisos) throw new Error('Debes aceptar los avisos antes de enviar la solicitud.');

  // Regla de firma electrónica según edad del paciente: si es menor de
  // edad, el acompañante (mayor de edad) es quien firma el consentimiento
  // en su representación; si es mayor de edad, firma él mismo. Este dato
  // solo se usa aquí, en la solicitud (no se usa en el Pase de Traslado).
  const edadPaciente = parseInt(datos.edad_paciente, 10);
  if (isNaN(edadPaciente) || edadPaciente < 0 || edadPaciente > 120) throw new Error('Falta o es inválida la edad del paciente.');
  const esMenor = edadPaciente < 18;
  let edadAcompanante = null;
  if (esMenor) {
    if (!datos.acompanante_nombre) throw new Error('El paciente es menor de edad: falta el nombre del acompañante que firmará el consentimiento.');
    if (!datos.acompanante_parentesco) throw new Error('Falta el parentesco del acompañante con el paciente.');
    edadAcompanante = parseInt(datos.edad_acompanante, 10);
    if (isNaN(edadAcompanante) || edadAcompanante < 18 || edadAcompanante > 120) throw new Error('El acompañante que firma debe ser mayor de edad.');
  } else if (datos.edad_acompanante !== '' && datos.edad_acompanante !== undefined && datos.edad_acompanante !== null) {
    const valorAcompanante = parseInt(datos.edad_acompanante, 10);
    edadAcompanante = isNaN(valorAcompanante) ? null : valorAcompanante;
  }
  const firmanteNombre = esMenor ? datos.acompanante_nombre : datos.nombre_completo;
  const firmanteTipo = esMenor ? 'acompanante' : 'paciente';

  let idInstitucion = datos.id_institucion;
  if (idInstitucion === '__otra__') {
    if (!datos.institucion_otra_nombre) throw new Error('Falta el nombre de la clínica o institución.');
    const instituciones = await coleccionComoArreglo('instituciones');
    const coincidencia = instituciones.find(function (i) { return String(i.nombre).trim().toLowerCase() === String(datos.institucion_otra_nombre).trim().toLowerCase(); });
    if (coincidencia) {
      idInstitucion = coincidencia.id_institucion;
    } else {
      idInstitucion = generarId('inst');
      await db.collection('instituciones').doc(idInstitucion).set({
        id_institucion: idInstitucion, nombre: datos.institucion_otra_nombre, tipo: 'Clínica particular',
        direccion: datos.institucion_otra_direccion || '', ciudad: datos.institucion_otra_ciudad || '',
        estado: '', telefono: '', especialidades: '',
        observaciones: 'Registrada automáticamente desde una solicitud pública de traslado; verificar y completar datos.'
      });
    }
  } else {
    if (!idInstitucion) throw new Error('Falta seleccionar la institución médica.');
    const inst = await db.collection('instituciones').doc(idInstitucion).get();
    if (!inst.exists) throw new Error('La institución seleccionada no es válida.');
  }

  // Nota: antes se revisaba toda la colección "pacientes" para evitar
  // duplicados, pero el formulario público (sesión anónima) no puede
  // leer esa lista completa (correcto por privacidad). En vez de eso,
  // usamos un id predecible (nombre + teléfono): si esta persona ya
  // había pedido un traslado antes, cae exactamente en el mismo
  // documento y lo reutilizamos; si no, se crea uno nuevo. Así se evitan
  // duplicados sin necesitar permiso para ver los datos de los demás.
  const idPaciente = idPacientePredecible(datos.nombre_completo, datos.telefono);
  const pacienteExistente = await db.collection('pacientes').doc(idPaciente).get();
  if (!pacienteExistente.exists) {
    await db.collection('pacientes').doc(idPaciente).set({
      id_paciente: idPaciente, nombre_completo: datos.nombre_completo, fecha_nacimiento: datos.fecha_nacimiento || '',
      sexo: datos.sexo || '', comunidad: datos.comunidad || '', telefono: datos.telefono,
      contacto_emergencia_nombre: datos.contacto_emergencia_nombre || '', contacto_emergencia_telefono: datos.contacto_emergencia_telefono || '',
      observaciones: 'Paciente registrado automáticamente vía formulario público'
    });
  }

  const folio = await generarFolio();
  const momentoAceptacion = new Date();
  await db.collection('traslados').doc(folio).set({
    folio: folio, id_paciente: idPaciente, acompanante_nombre: datos.acompanante_nombre || '',
    acompanante_telefono: datos.acompanante_telefono || '',
    acompanante_parentesco: datos.acompanante_parentesco || '', id_institucion: idInstitucion,
    especialidad: datos.especialidad || '', tipo_cita: datos.tipo_cita || '', fecha_cita: datos.fecha_cita,
    hora_cita: datos.hora_cita || '', motivo_traslado: datos.motivo_traslado, tipo_traslado: 'Programado',
    prioridad: 'Media', fecha_solicitud: new Date(), estado_actual: 'Solicitud recibida',
    edad_paciente: edadPaciente, edad_acompanante: edadAcompanante,
    es_paciente_menor_edad: esMenor, firmante_nombre: firmanteNombre, firmante_tipo: firmanteTipo,
    aceptacion_avisos: true,
    fecha_aceptacion: formatearFechaDDMMYYYY(momentoAceptacion),
    hora_aceptacion: formatearHoraHHMM(momentoAceptacion),
    version_consentimiento: '08/09/2026',
    version_aviso_privacidad: '08/09/2026',
    observaciones: datos.observaciones || '', creado_por: 'Solicitud pública (paciente)', fecha_creacion: new Date()
  });
  await registrarCambioEstado(folio, '', 'Solicitud recibida', 'Solicitud pública', 'Solicitud creada por el paciente desde el formulario público');
  await registrarAuditoria('Solicitud pública', 'Crear', 'Traslados', folio, 'Un paciente solicitó el traslado ' + folio + ' desde el formulario público');
  return folio;
}

// ---------------------------------------------------------------------
// Proxy que recrea la interfaz de google.script.run (idéntico al de
// api-shim.js), pero despachando a las funciones locales de arriba en
// vez de hacer fetch() a Apps Script.
// ---------------------------------------------------------------------

const FUNCIONES_DISPONIBLES = {
  iniciarSesion: iniciarSesion, cerrarSesion: cerrarSesion, obtenerSesion: obtenerSesion, cambiarMiPassword: cambiarMiPassword,
  listarUsuarios: listarUsuarios, obtenerUsuario: obtenerUsuario, crearUsuario: crearUsuario, actualizarUsuario: actualizarUsuario,
  listarPacientes: listarPacientes, obtenerPaciente: obtenerPaciente, crearPaciente: crearPaciente, actualizarPaciente: actualizarPaciente, eliminarPaciente: eliminarPaciente,
  listarInstituciones: listarInstituciones, obtenerInstitucion: obtenerInstitucion, crearInstitucion: crearInstitucion, actualizarInstitucion: actualizarInstitucion,
  listarVehiculos: listarVehiculos, obtenerVehiculo: obtenerVehiculo, crearVehiculo: crearVehiculo, actualizarVehiculo: actualizarVehiculo, listarVehiculosActivos: listarVehiculosActivos, obtenerAlertasVehiculos: obtenerAlertasVehiculos,
  listarConductores: listarConductores, obtenerConductor: obtenerConductor, crearConductor: crearConductor, actualizarConductor: actualizarConductor, listarConductoresActivos: listarConductoresActivos,
  listarTraslados: listarTraslados, obtenerTraslado: obtenerTraslado, crearTraslado: crearTraslado, actualizarTraslado: actualizarTraslado, eliminarTraslado: eliminarTraslado,
  cambiarEstadoTraslado: cambiarEstadoTraslado, registrarSalida: registrarSalida, registrarLlegadaDestino: registrarLlegadaDestino, registrarRegreso: registrarRegreso,
  obtenerDatosDashboard: obtenerDatosDashboard, obtenerConteoSolicitudesPendientes: obtenerConteoSolicitudesPendientes,
  generarReporte: generarReporte, exportarReporte: exportarReporte,
  obtenerUbicacionesActivas: obtenerUbicacionesActivas, registrarUbicacionConductor: registrarUbicacionConductor,
  listarInstitucionesPublico: listarInstitucionesPublico, crearSolicitudPublica: crearSolicitudPublica,
  listarAceptaciones: listarAceptaciones,
  guardarPasePrimeraVez: guardarPasePrimeraVez, listarPasesTraslado: listarPasesTraslado, obtenerPaseTraslado: obtenerPaseTraslado,
  existePaseTraslado: existePaseTraslado
};

function crearGoogleScriptRunFalso() {
  let manejadorExito = function () {};
  let manejadorError = function (error) { console.error('Error sin manejar:', error); };

  const base = {
    withSuccessHandler: function (fn) { manejadorExito = fn; return proxy; },
    withFailureHandler: function (fn) { manejadorError = fn; return proxy; }
  };

  var proxy = new Proxy(base, {
    get: function (objetivo, propiedad) {
      if (propiedad in objetivo) return objetivo[propiedad];
      const fn = FUNCIONES_DISPONIBLES[propiedad];
      return function () {
        const argumentos = Array.prototype.slice.call(arguments);
        if (!fn) {
          manejadorError({ message: 'Función no implementada en Firebase: ' + propiedad });
          return proxy;
        }
        Promise.resolve()
          .then(function () { return fn.apply(null, argumentos); })
          .then(function (datos) { manejadorExito(datos); })
          .catch(function (error) { manejadorError({ message: error.message || String(error) }); });
        return proxy;
      };
    }
  });
  return proxy;
}

window.google = window.google || {};
window.google.script = window.google.script || {};
Object.defineProperty(window.google.script, 'run', {
  get: function () { return crearGoogleScriptRunFalso(); },
  configurable: true
});
