SALES STORE GODOWN STOCK SOFTWARE — FINAL V1.1

Android phone par istemal:
1. Final ZIP download karein.
2. Phone ke Files / File Manager app mein Downloads kholen.
3. ZIP par tap karke Extract / Unzip karein.
4. Extract kiye folder mein index.html par tap karein aur Chrome/browser se kholen.
5. Pehli baar PIN:
   Owner: 1234
   Incharge: 2345
   Staff: 3456
6. Settings mein jaakar PIN badlein aur regular JSON backup banayein.

Features:
- Product name/SKU search
- Stock list, stock-in, stock-out
- Purchase cost and sale rate
- Supplier, bill number and notes
- Stock movement history
- CSV export and JSON backup/restore
- 3 local user roles with PIN

IMPORTANT:
- Yeh browser mein chalne wala offline web-app prototype hai, native Android APK nahi.
- Data isi browser/device mein save hota hai. Browser data clear karne ya phone badalne se data kho sakta hai. Backup rakhein.
- Alag-alag 3 phones par data automatic sync nahi hota.
- Pehle test ke liye kuch demo products add karke stock-in/out check karein.
