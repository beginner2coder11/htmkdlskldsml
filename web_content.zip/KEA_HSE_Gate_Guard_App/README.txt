KEA HSE GATE GUARD APP  (Scan + Dashboard)
==========================================
Open index.html in Chrome. For the camera, open it from an online link (https) - not straight from phone storage.

FIRST TIME / WHEN NEW PASSES ARE ISSUED
  Data tab > "Import passes file" and choose the "KEA_Guard_Passes_....json" file sent by the HSE office.

AT THE GATE
  Scan tab: start the camera scanner (QR / barcode), or use a handheld scanner / type the pass number.
  Shows photo, name, Emirates ID number, company, category, pass number and validity.
  Auto IN / OUT is recorded. Expired or unknown passes are refused and logged.

DASHBOARD TAB
  On site now, entries, exits, daily attendance (hours), full scan log, companies. Click a name for details.
  Excel (.csv) export and Print / Save PDF.

SEND SCANS TO HSE OFFICE
  Data tab > "Export scans file" and send "KEA_Guard_Scans_....json" to the HSE officer (WhatsApp / email).
  After HSE confirms, you may "Delete all scans" to start clean.

NOTES
  - All data stays on this device. Passes file and scans file are the only way data moves.
  - If the HSE office set a PIN, the Data tab asks for it.
  - Folders: index.html, css/, js/ (core.js, scan.js, guard.js, logo.js), assets/, manifest.json - keep them together.
