/* KEA HSE Gate Guard - import passes / export scans */
function renderData(){const T=today(),imp=ld(K.imp,0),exp=ld(K.exp,0);
 $("dInfo").innerHTML=REG.length?`<b>${REG.length}</b> passes loaded (<b>${REG.filter(r=>r.to>=T).length}</b> active). Last import: <b>${imp?dmy(fd(new Date(imp)))+" "+hhmm(imp):"-"}</b>`:'<b style="color:#C00000">No passes loaded yet. Import the passes file from the HSE office.</b>';
 $("sInfo").innerHTML=`<b>${ATT.length}</b> scan records on this device. Last export: <b>${exp?dmy(fd(new Date(exp)))+" "+hhmm(exp):"never"}</b>`;
 $("hdLogo").src=LOGO}
$("bImp").onclick=()=>$("fileImp").click();
$("fileImp").onchange=e=>{const f=e.target.files[0];e.target.value="";if(!f)return;const r=new FileReader();
 r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.REG))throw 0;
  if(!confirm("Replace the current "+REG.length+" passes with "+d.REG.length+" passes from this file? (Scan records are kept)"))return;
  REG=d.REG;if(d.CFG)CFG=Object.assign(CFG,d.CFG);LOGO=d.LOGO||LOGO;
  const ok=sv(K.reg,REG)&&sv(K.cfg,CFG)&&sv(K.logo,d.LOGO||"")&&sv(K.imp,Date.now());
  if(ok){UNL=true;renderData();renderDash();toast(REG.length+" passes imported")}}
  catch(x){alert("This is not a valid passes file from the HSE office")}};r.readAsText(f)};
$("bExp").onclick=()=>{if(!ATT.length)return toast("No scans to export yet");
 dl("KEA_Guard_Scans_"+today()+".json","application/json",JSON.stringify({type:"kea-scans",v:1,exported:Date.now(),site:CFG.site,ATT}));sv(K.exp,Date.now());renderData();toast("Scans file ready - send it to the HSE office")};
$("bClr").onclick=()=>{if(!ATT.length)return;if(!confirm("Delete ALL "+ATT.length+" scan records on this device? Have you exported and sent them to HSE?"))return;if(!confirm("Last warning - this cannot be undone. Delete all scans?"))return;ATT=[];sv(K.att,ATT);renderData();renderRecent();toast("Scan log cleared")};
renderData();net();
