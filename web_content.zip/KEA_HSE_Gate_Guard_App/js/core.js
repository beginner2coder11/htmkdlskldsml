/* KEA HSE Gate Guard - core helpers (guard data is kept separate from the admin app) */
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ld=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){toast("Storage full - export scans and delete old scans");return false}};
const K={cfg:"keaGuardCfg",reg:"keaGuardReg",att:"keaGuardAtt",logo:"keaGuardLogo",imp:"keaGuardImp",exp:"keaGuardExp"};
let CFG=Object.assign({site:"Veona by Gutti",hseName:"Asim Taj",hsePhone:"",guardPin:""},ld(K.cfg,{})),REG=ld(K.reg,[]),ATT=ld(K.att,[]).sort((a,b)=>a.ts-b.ts),LOGO=ld(K.logo,"")||DEFAULT_LOGO,UNL=false;
const AVATAR="data:image/svg+xml;utf8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 160"><rect width="120" height="160" fill="#e6e9ee"/><circle cx="60" cy="62" r="26" fill="#9aa5b4"/><path d="M12 160c0-34 22-52 48-52s48 18 48 52z" fill="#9aa5b4"/></svg>');
const fd=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const today=()=>fd(new Date());
const dmy=s=>s?s.split("-").reverse().join("-"):"";
let tmr;function toast(m){const t=$("toast");t.textContent=m;t.classList.add("on");clearTimeout(tmr);tmr=setTimeout(()=>t.classList.remove("on"),2600)}
function dl(n,m,d){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([d],{type:m}));a.download=n;a.click()}
const SECS=["scan","dash","data"];
function tab(t){if(t=="data"&&CFG.guardPin&&!UNL){const v=prompt("Enter PIN:");if(v!==CFG.guardPin){toast("Wrong PIN");return}UNL=true}
 document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.t==t));SECS.forEach(x=>$("t-"+x).hidden=x!=t);
 if(t!="scan")stopScan();if(t=="dash")renderDash();if(t=="data")renderData();if(t=="scan")$("manIn").focus()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>tab(b.dataset.t));
function net(){const o=navigator.onLine;$("net").textContent=o?"Online":"Offline - manual / handheld scan still works";$("net").className="net "+(o?"on":"off")}
addEventListener("online",net);addEventListener("offline",net);
