JAS LAUNDRY ROOM – SINGLE CREATE ACCOUNT BUTTON UPDATE

Login പേജിൽ ഇനി ഒരേയൊരു “Create Account” ബട്ടൺ മാത്രമാണ്. Login Type dropdown-ൽ Owner തിരഞ്ഞെടുത്താൽ Owner account form മാത്രം കാണുകയും അതേ ബട്ടൺ Owner account സൃഷ്ടിക്കുകയും ചെയ്യും. Staff തിരഞ്ഞെടുത്താൽ Owner authorization, Staff Name, Staff ID, Staff Password ഫീൽഡുകൾ കാണുകയും അതേ ബട്ടൺ Staff account സൃഷ്ടിക്കുകയും ചെയ്യും.

Staff account സൃഷ്ടിക്കുമ്പോൾ നിലവിലുള്ള Owner login/password സ്ഥിരീകരിക്കുന്ന പഴയ സുരക്ഷാ പരിശോധനയും Google Cloud sync ശ്രമവും നിലനിർത്തിയിട്ടുണ്ട്. Owner account സൃഷ്ടിക്കുമ്പോൾ നിലവിലുള്ള first-owner validation നിലനിർത്തിയിട്ടുണ്ട്.

മറ്റ് Billing, Customer, Payment, Inventory, Expense, Branch, Attendance, Cloud, Navigation പ്രവർത്തനങ്ങൾ മാറ്റിയിട്ടില്ല. നിലവിലുള്ള Local Storage / പഴയ ഡാറ്റ reset/delete ചെയ്യുന്ന കോഡ് ചേർത്തിട്ടില്ല.

പരിശോധന: ZIP integrity, HTML parse, inline JavaScript syntax പരിശോധിച്ചു. Android APK runtime, യഥാർത്ഥ Google Cloud account creation/sync എന്നിവ ഉപകരണത്തിൽ പരീക്ഷിച്ചിട്ടില്ല. ഇൻസ്റ്റാൾ/അപ്‌ഡേറ്റ് ചെയ്യുന്നതിന് മുമ്പ് Backup എടുക്കുക.
