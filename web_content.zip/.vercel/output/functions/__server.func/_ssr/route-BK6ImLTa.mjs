import { C as require_jsx_runtime, _ as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { A as upcomingMajors, E as istISO, j as useApp, s as Shell, v as daysBetween, w as getCity, y as formatLong } from "./chrome-Cw-sgEN-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-BK6ImLTa.js
var import_jsx_runtime = require_jsx_runtime();
function AppLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-frame",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandAside, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" })
		]
	});
}
function BrandAside() {
	const city = getCity(useApp((state) => state.cityId));
	const today = istISO();
	const next = upcomingMajors(today < "2027-01-01" ? "2027-01-01" : today, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "brand-pane",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "brand-hero",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/art/temple.jpg",
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "2027 Hindu calendar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-serif text-6xl leading-none text-cream",
							children: "SUMAN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-base leading-relaxed text-cream",
							children: "Panchang, festivals, muhurat and personal reminders — one year, kept in one place."
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-8 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Timings for ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-cream",
						children: city.name
					}),
					", shown in IST."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: next.map((festival) => {
					const away = daysBetween(today, festival.date);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-4 border-t border-line pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-2xl text-cream",
							children: festival.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-sm text-gold",
							children: away > 0 ? `${away}d` : away === 0 ? "Today" : formatLong(festival.date)
						})]
					}, festival.date + festival.name);
				})
			})]
		})]
	});
}
//#endregion
export { AppLayout as component };
