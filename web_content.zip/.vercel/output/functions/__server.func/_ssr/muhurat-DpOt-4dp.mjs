import { i as FESTIVALS } from "./chrome-Cw-sgEN-.mjs";
import { r as getDay, t as eachDate } from "./engine-BiRH4iq7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/muhurat-DpOt-4dp.js
var MARRIAGE_NAK = /* @__PURE__ */ new Set([
	3,
	4,
	9,
	11,
	12,
	14,
	16,
	18,
	20,
	25,
	26
]);
var MARRIAGE_GOOD_NAK = /* @__PURE__ */ new Set([
	7,
	13,
	21,
	22
]);
var GRIHA_NAK = /* @__PURE__ */ new Set([
	3,
	4,
	11,
	12,
	13,
	14,
	16,
	20,
	25,
	26
]);
var VEHICLE_NAK = /* @__PURE__ */ new Set([
	3,
	7,
	11,
	12,
	16,
	20,
	21,
	26
]);
var BEGIN_NAK = /* @__PURE__ */ new Set([
	3,
	7,
	11,
	12,
	20,
	21,
	25,
	26
]);
var SOFT_TITHI = /* @__PURE__ */ new Set([
	2,
	3,
	5,
	7,
	10,
	11,
	13
]);
var CORE_MONTHS = /* @__PURE__ */ new Set([
	10,
	11,
	1,
	2,
	8
]);
var BEST_DAYS = /* @__PURE__ */ new Set([
	1,
	3,
	4,
	5
]);
var SUNDAY = 0;
var devuthani = null;
function devuthaniDate(cityId) {
	if (devuthani) return devuthani;
	for (const iso of eachDate("2027-11-01", "2027-11-20")) {
		const day = getDay(iso, cityId);
		if (day.paksha === "Shukla" && day.tithiNumber === 11 && day.purnimantaIndex === 7) {
			devuthani = iso;
			return iso;
		}
	}
	devuthani = "2027-11-10";
	return devuthani;
}
function inChaturmas(iso, cityId) {
	return iso >= "2027-07-14" && iso < devuthaniDate(cityId);
}
function eclipse(iso) {
	return FESTIVALS.some((festival) => festival.date === iso && festival.kind === "eclipse");
}
function baseOk(day) {
	return !eclipse(day.iso);
}
function fitsOn(iso, cityId) {
	if (!iso.startsWith("2027")) return [];
	const day = getDay(iso, cityId);
	const hits = [
		"marriage",
		"griha",
		"vehicle",
		"property",
		"beginnings"
	].flatMap((id) => {
		const hit = score(id, day, cityId);
		return hit ? [{
			id,
			hit
		}] : [];
	});
	const classic = {
		"2027-05-09": "Akshaya Tritiya, a classic day for a purchase.",
		"2027-10-09": "Vijayadashami, traditionally used for a new vehicle.",
		"2027-10-27": "Dhanteras, the customary day to bring metal home."
	}[iso];
	if (classic) {
		const vehicle = hits.find((item) => item.id === "vehicle");
		const hit = {
			iso,
			grade: "Classic",
			reason: classic
		};
		if (vehicle) vehicle.hit = hit;
		else hits.push({
			id: "vehicle",
			hit
		});
	}
	return hits;
}
function muhuratFor(kind, cityId) {
	const hits = [];
	for (const iso of eachDate("2027-01-01", "2027-12-31")) {
		const hit = score(kind, getDay(iso, cityId), cityId);
		if (hit) hits.push(hit);
	}
	if (kind === "vehicle") {
		for (const classic of [
			["2027-05-09", "Akshaya Tritiya, a classic day for a purchase."],
			["2027-10-09", "Vijayadashami, traditionally used for a new vehicle."],
			["2027-10-27", "Dhanteras, the customary day to bring metal home."]
		]) if (!hits.some((hit) => hit.iso === classic[0])) hits.push({
			iso: classic[0],
			grade: "Classic",
			reason: classic[1]
		});
		else {
			const found = hits.find((hit) => hit.iso === classic[0]);
			if (found) {
				found.grade = "Classic";
				found.reason = classic[1];
			}
		}
		hits.sort((a, b) => a.iso.localeCompare(b.iso));
	}
	return hits;
}
function score(kind, day, cityId) {
	if (!baseOk(day)) return null;
	if (kind === "marriage") return scoreMarriage(day, cityId);
	if (kind === "griha") return scoreHouse(day, cityId, GRIHA_NAK, "A steady nakshatra for entering a home.");
	if (kind === "property") return scoreHouse(day, cityId, GRIHA_NAK, "Steady nakshatra for agreeing a home or a plot.");
	if (kind === "vehicle") return scoreVehicle(day);
	return scoreBeginnings(day, cityId);
}
function scoreMarriage(day, cityId) {
	if (inChaturmas(day.iso, cityId)) return null;
	if (day.paksha !== "Shukla") return null;
	if (!(CORE_MONTHS.has(day.amantaIndex) || day.amantaIndex === 0 || day.amantaIndex === 7)) return null;
	const strictNak = MARRIAGE_NAK.has(day.nakshatraIndex);
	const softNak = MARRIAGE_GOOD_NAK.has(day.nakshatraIndex);
	if (!strictNak && !softNak) return null;
	const strictTithi = SOFT_TITHI.has(day.tithiNumber);
	if (!strictTithi && day.tithiNumber !== 12) return null;
	if (!(BEST_DAYS.has(day.weekday) || day.weekday === SUNDAY)) return null;
	const excellent = strictNak && strictTithi && BEST_DAYS.has(day.weekday) && CORE_MONTHS.has(day.amantaIndex);
	return {
		iso: day.iso,
		grade: excellent ? "Excellent" : "Good",
		reason: excellent ? "Shukla paksha, supportive nakshatra, outside Chaturmas." : "Acceptable tithi and nakshatra. A priest may still prefer a stronger combination."
	};
}
function scoreHouse(day, cityId, nakshatras, reason) {
	if (inChaturmas(day.iso, cityId)) return null;
	if (day.paksha !== "Shukla") return null;
	if (!SOFT_TITHI.has(day.tithiNumber) && day.tithiNumber !== 12) return null;
	if (!nakshatras.has(day.nakshatraIndex)) return null;
	if (!CORE_MONTHS.has(day.amantaIndex)) return null;
	if (BEST_DAYS.has(day.weekday)) return {
		iso: day.iso,
		grade: "Excellent",
		reason
	};
	if (day.weekday === SUNDAY) return {
		iso: day.iso,
		grade: "Good",
		reason
	};
	return null;
}
function scoreVehicle(day) {
	if (day.tithiNumber === 4 || day.tithiNumber === 8 || day.tithiNumber === 9 || day.tithiNumber === 14) return null;
	if (day.paksha === "Krishna" && day.tithiNumber === 15) return null;
	if (!VEHICLE_NAK.has(day.nakshatraIndex)) return null;
	if (!BEST_DAYS.has(day.weekday)) return null;
	return {
		iso: day.iso,
		grade: "Excellent",
		reason: `${day.nakshatraName} with a favourable weekday. Avoid the Rahu Kalam window.`
	};
}
function scoreBeginnings(day, cityId) {
	if (inChaturmas(day.iso, cityId)) return null;
	if (day.paksha === "Krishna" && day.tithiNumber === 15) return null;
	if (!SOFT_TITHI.has(day.tithiNumber)) return null;
	if (!BEGIN_NAK.has(day.nakshatraIndex)) return null;
	if (day.weekday === 2 || day.weekday === 6) return null;
	const grade = day.paksha === "Shukla" && BEST_DAYS.has(day.weekday) ? "Excellent" : "Good";
	return {
		iso: day.iso,
		grade,
		reason: "Supportive for study, business or a first step."
	};
}
var MUHURAT_COPY = {
	marriage: {
		title: "Marriage",
		summary: "Shukla paksha in Magha, Phalguna, Vaishakha, Jyeshtha and Margashirsha, outside Chaturmas."
	},
	griha: {
		title: "Griha Pravesh",
		summary: "Housewarming dates with a steady nakshatra. Chaturmas is left out."
	},
	vehicle: {
		title: "Vehicle",
		summary: "Weekdays and nakshatras used for a purchase, plus Dhanteras, Dussehra and Akshaya Tritiya."
	},
	property: {
		title: "Property",
		summary: "Steady nakshatras for agreeing a home or a plot. Confirm the final hour locally."
	},
	beginnings: {
		title: "New beginnings",
		summary: "Study, a shop, a name, a journey. Tuesday and Saturday are set aside."
	}
};
//#endregion
export { fitsOn as n, muhuratFor as r, MUHURAT_COPY as t };
