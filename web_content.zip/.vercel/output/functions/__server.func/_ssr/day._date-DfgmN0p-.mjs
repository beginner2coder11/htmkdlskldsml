import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as formatTime, E as istISO, c as SunMoon, d as TimingList, j as useApp, l as TaskDialog, o as PanchangGrid, t as BackButton, w as getCity, y as formatLong } from "./chrome-Cw-sgEN-.mjs";
import { a as monthLabel, i as getLive, r as getDay } from "./engine-BiRH4iq7.mjs";
import { n as eventsOn } from "./observe-C-vyYYiC.mjs";
import { n as Route } from "./router-CHVLBz50.mjs";
import { n as fitsOn } from "./muhurat-DpOt-4dp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/day._date-DfgmN0p-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LABELS = {
	marriage: "Marriage",
	griha: "Griha Pravesh",
	vehicle: "Vehicle",
	property: "Property",
	beginnings: "New beginnings"
};
function DayPage() {
	const { date } = Route.useParams();
	const cityId = useApp((state) => state.cityId);
	const system = useApp((state) => state.monthSystem);
	if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-muted",
			children: "That date is not recognised."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayBody, {
		date,
		cityId,
		system
	});
}
function DayBody({ date, cityId, system }) {
	const city = getCity(cityId);
	const day = (0, import_react.useMemo)(() => getDay(date, cityId), [date, cityId]);
	const live = date === istISO() ? getLive() : readingFrom(day);
	const events = eventsOn(date, day);
	const suits = fitsOn(date, cityId);
	const [open, setOpen] = (0, import_react.useState)(false);
	const headline = events[0]?.name ?? `${day.weekdayName} panchang`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "eyebrow",
					children: [
						day.weekdayName,
						" · ",
						day.vara
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-serif text-4xl leading-tight",
					children: formatLong(date)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-gold",
					children: [
						monthLabel(day, system),
						" · ",
						day.paksha,
						" Paksha"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						city.name,
						" · IST · Amanta ",
						day.amantaName,
						day.amantaName !== day.purnimantaName ? ` · Purnimanta ${day.purnimantaName}` : ""
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-3xl border border-line bg-surface p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { day })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanchangGrid, {
				live,
				anchor: date === istISO() ? /* @__PURE__ */ new Date() : day.sunrise
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: [
					"Sunrise tithi is ",
					day.tithiName,
					" until ",
					formatTime(day.tithiEnd),
					", then ",
					day.nextTithi,
					". Moon in ",
					day.moonRashi,
					" (",
					day.moonRashiEn,
					"), Sun in ",
					day.sunRashi,
					" (",
					day.sunRashiEn,
					").",
					day.sankranti ? ` ${day.sankranti.name} at ${formatTime(day.sankranti.at)}.` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: "Timings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimingList, {
					day,
					now: date === istISO() ? /* @__PURE__ */ new Date() : void 0
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl",
						children: "On this day"
					}),
					events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No major observance is listed. The panchang above still holds."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3",
						children: events.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-line bg-inset px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: event.kind
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-serif text-2xl",
									children: event.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: event.note
								})
							]
						}, event.name))
					})
				]
			}),
			date.startsWith("2027") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl",
						children: "Muhurat fit"
					}),
					suits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Not flagged by the guides for marriage, griha pravesh, vehicle, property or new beginnings."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "overflow-hidden rounded-2xl border border-line",
						children: suits.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-line bg-surface px-4 py-3 last:border-b-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-cream",
									children: LABELS[item.id]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-gold",
									children: item.hit.grade
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: item.hit.reason
								})
							]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted",
						children: "A family priest may still set the final hour. Abhijit muhurat is the general midday window."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-12 rounded-2xl bg-gold text-bg",
				onClick: () => setOpen(true),
				children: "Remind me"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskDialog, {
				open,
				onClose: () => setOpen(false),
				initial: {
					title: headline,
					date,
					notes: events[0]?.note ?? ""
				}
			})
		]
	});
}
function readingFrom(day) {
	return {
		tithiName: day.tithiName,
		paksha: day.paksha,
		tithiNumber: day.tithiNumber,
		tithiEnd: day.tithiEnd,
		nakshatraName: day.nakshatraName,
		pada: day.pada,
		nakshatraEnd: day.nakshatraEnd,
		yogaName: day.yogaName,
		yogaEnd: day.yogaEnd,
		karanaName: day.karanaName,
		karanaEnd: day.karanaEnd
	};
}
//#endregion
export { DayPage as component };
