import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as istISO, _ as cn, j as useApp, k as samvatFor, n as CityButton } from "./chrome-Cw-sgEN-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-zZ7VH53t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MorePage() {
	const system = useApp((state) => state.monthSystem);
	const setMonthSystem = useApp((state) => state.setMonthSystem);
	const today = istISO();
	const samvat = samvatFor(today);
	const [permission, setPermission] = useStateLabel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "SUMAN"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "More"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/festivals",
				className: "overflow-hidden rounded-3xl border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-32",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/art/diyas.jpg",
							alt: "",
							className: "h-full w-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg via-bg/60 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 flex flex-col justify-end p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "2027"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-3xl",
								children: "Festivals & vrat"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 rounded-3xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Place"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CityButton, {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "Sunrise, Rahu Kalam and the other day divisions follow the city. Tithi itself is the same sky everywhere; which tithi is “today” can still shift if sunrise differs."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Lunar month"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [[
							"amanta",
							"Amanta",
							"Month ends on Amavasya. South and West."
						], [
							"purnimanta",
							"Purnimanta",
							"Month ends on Purnima. North."
						]].map(([id, title, note]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMonthSystem(id),
							className: cn("rounded-2xl border px-3 py-3 text-left", system === id ? "border-gold bg-inset" : "border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-cream",
								children: title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs leading-relaxed text-muted",
								children: note
							})]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Vikram Samvat ",
							samvat.vikram,
							" · Shaka ",
							samvat.shaka,
							". The year-count steps on Ugadi, 7 April 2027."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Reminders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: "Alerts appear inside SUMAN. Browser notifications only fire while this tab is open."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 self-start rounded-full border border-line px-4 text-sm text-gold",
						onClick: () => {
							if (typeof Notification === "undefined") return;
							Notification.requestPermission().then(() => setPermission(Notification.permission));
						},
						children: permission === "granted" ? "Alerts allowed" : "Allow alerts"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-cream",
						children: "How to read it"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tithi is the moon’s distance from the sun, in twelve-degree steps. Nakshatra is the moon’s place among the twenty-seven stars, sidereal, Lahiri ayanamsha." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Rahu Kalam, Yamaganda and Gulika are eight equal parts of the day from sunrise to sunset, picked by the weekday. Abhijit is the eighth of fifteen muhurtas. Brahma muhurta is the hour before dawn." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Festival dates follow published Amanta observances for India in 2027. A local temple may keep a tithi on the next morning if it begins late." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-xl italic leading-relaxed text-gold",
				children: "“A companion for the year — confirm the final muhurat with your priest.”"
			})
		]
	});
}
function useStateLabel() {
	const [permission, setPermission] = useStateSafe();
	return [permission, setPermission];
}
function useStateSafe() {
	const [permission, setPermission] = (0, import_react.useState)(() => {
		if (typeof Notification === "undefined") return "unknown";
		return Notification.permission;
	});
	return [permission, setPermission];
}
//#endregion
export { MorePage as component };
