import { M as weekdayIndex, f as VARA, h as addDays, p as WEEKDAYS, w as getCity } from "./chrome-Cw-sgEN-.mjs";
import { a as SearchMoonPhase, i as Observer, n as EclipticGeoMoon, o as SearchRiseSet, r as MakeTime, s as SunPosition, t as Body } from "../_libs/astronomy-engine.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-BiRH4iq7.js
var TITHI = [
	"Pratipada",
	"Dwitiya",
	"Tritiya",
	"Chaturthi",
	"Panchami",
	"Shashthi",
	"Saptami",
	"Ashtami",
	"Navami",
	"Dashami",
	"Ekadashi",
	"Dwadashi",
	"Trayodashi",
	"Chaturdashi",
	"Purnima"
];
var NAKSHATRAS = [
	"Ashwini",
	"Bharani",
	"Krittika",
	"Rohini",
	"Mrigashira",
	"Ardra",
	"Punarvasu",
	"Pushya",
	"Ashlesha",
	"Magha",
	"Purva Phalguni",
	"Uttara Phalguni",
	"Hasta",
	"Chitra",
	"Swati",
	"Vishakha",
	"Anuradha",
	"Jyeshtha",
	"Mula",
	"Purva Ashadha",
	"Uttara Ashadha",
	"Shravana",
	"Dhanishta",
	"Shatabhisha",
	"Purva Bhadrapada",
	"Uttara Bhadrapada",
	"Revati"
];
var YOGAS = [
	"Vishkambha",
	"Priti",
	"Ayushman",
	"Saubhagya",
	"Shobhana",
	"Atiganda",
	"Sukarma",
	"Dhriti",
	"Shula",
	"Ganda",
	"Vriddhi",
	"Dhruva",
	"Vyaghata",
	"Harshana",
	"Vajra",
	"Siddhi",
	"Vyatipata",
	"Variyan",
	"Parigha",
	"Shiva",
	"Siddha",
	"Sadhya",
	"Shubha",
	"Shukla",
	"Brahma",
	"Indra",
	"Vaidhriti"
];
var KARANA_REPEAT = [
	"Bava",
	"Balava",
	"Kaulava",
	"Taitila",
	"Gara",
	"Vanija",
	"Vishti"
];
var RASHIS = [
	["Mesha", "Aries"],
	["Vrishabha", "Taurus"],
	["Mithuna", "Gemini"],
	["Karka", "Cancer"],
	["Simha", "Leo"],
	["Kanya", "Virgo"],
	["Tula", "Libra"],
	["Vrishchika", "Scorpio"],
	["Dhanu", "Sagittarius"],
	["Makara", "Capricorn"],
	["Kumbha", "Aquarius"],
	["Meena", "Pisces"]
];
var LUNAR_MONTHS = [
	"Chaitra",
	"Vaishakha",
	"Jyeshtha",
	"Ashadha",
	"Shravana",
	"Bhadrapada",
	"Ashwin",
	"Kartika",
	"Margashirsha",
	"Pausha",
	"Magha",
	"Phalguna"
];
var EKADASHI = {
	Krishna: [
		"Papamochani Ekadashi",
		"Varuthini Ekadashi",
		"Apara Ekadashi",
		"Yogini Ekadashi",
		"Kamika Ekadashi",
		"Aja Ekadashi",
		"Indira Ekadashi",
		"Rama Ekadashi",
		"Utpanna Ekadashi",
		"Saphala Ekadashi",
		"Shattila Ekadashi",
		"Vijaya Ekadashi"
	],
	Shukla: [
		"Kamada Ekadashi",
		"Mohini Ekadashi",
		"Nirjala Ekadashi",
		"Devshayani Ekadashi",
		"Putrada Ekadashi",
		"Parsva Ekadashi",
		"Papankusha Ekadashi",
		"Devuthani Ekadashi",
		"Mokshada Ekadashi",
		"Pausha Putrada Ekadashi",
		"Jaya Ekadashi",
		"Amalaki Ekadashi"
	]
};
function ekadashiName(purnimantaIndex, paksha) {
	return EKADASHI[paksha][purnimantaIndex] ?? "Ekadashi";
}
function karanaName(index) {
	if (index <= 0) return "Kimstughna";
	if (index >= 57) return [
		"Shakuni",
		"Chatushpada",
		"Naga"
	][Math.min(2, index - 57)] ?? "Naga";
	return KARANA_REPEAT[(index - 1) % 7];
}
var RISE = 1;
var SET = -1;
var SPAN = 360 / 27;
var cache = /* @__PURE__ */ new Map();
function norm(deg) {
	return (deg % 360 + 360) % 360;
}
function lahiri(date) {
	return 23.852778 + MakeTime(date).ut / 365.2425 * (50.29 / 3600);
}
function sunTropical(date) {
	return SunPosition(date).elon;
}
function moonTropical(date) {
	return EclipticGeoMoon(date).lon;
}
function elongation(date) {
	return norm(moonTropical(date) - sunTropical(date));
}
function sunSidereal(date) {
	return norm(sunTropical(date) - lahiri(date));
}
function moonSidereal(date) {
	return norm(moonTropical(date) - lahiri(date));
}
function advanceTo(start, read, boundary) {
	const startVal = read(start);
	const need = norm(boundary - startVal);
	if (need < .02) return new Date(start.getTime() + 6e4);
	let lo = start.getTime();
	let hi = lo + 144e6;
	for (let i = 0; i < 22; i += 1) {
		const mid = (lo + hi) / 2;
		const progressed = norm(read(new Date(mid)) - startVal);
		if (progressed >= need && progressed < 300) hi = mid;
		else lo = mid;
	}
	return new Date(hi);
}
function nextTithiLabel(index) {
	const next = (index + 1) % 30;
	const paksha = next < 15 ? "Shukla" : "Krishna";
	const number = next % 15 + 1;
	return `${paksha} ${number === 15 ? paksha === "Shukla" ? "Purnima" : "Amavasya" : TITHI[number - 1]}`;
}
function tithiAt(date) {
	const elong = elongation(date);
	const index = Math.min(29, Math.floor(elong / 12));
	const paksha = index < 15 ? "Shukla" : "Krishna";
	const number = index % 15 + 1;
	return {
		index,
		paksha,
		number,
		name: number === 15 ? paksha === "Shukla" ? "Purnima" : "Amavasya" : TITHI[number - 1],
		end: advanceTo(date, elongation, (index + 1) * 12)
	};
}
function nakshatraAt(date) {
	const lon = moonSidereal(date);
	const index = Math.min(26, Math.floor(lon / SPAN));
	const within = lon - index * SPAN;
	const pada = Math.min(4, Math.floor(within / (SPAN / 4)) + 1);
	return {
		index,
		name: NAKSHATRAS[index],
		pada,
		end: advanceTo(date, moonSidereal, (index + 1) * SPAN)
	};
}
function yogaAt(date) {
	const read = (value) => norm(sunSidereal(value) + moonSidereal(value));
	const sum = read(date);
	const index = Math.min(26, Math.floor(sum / SPAN));
	return {
		index,
		name: YOGAS[index],
		end: advanceTo(date, read, (index + 1) * SPAN)
	};
}
function karanaAt(date) {
	const elong = elongation(date);
	const index = Math.min(59, Math.floor(elong / 6));
	return {
		name: karanaName(index),
		end: advanceTo(date, elongation, (index + 1) * 6)
	};
}
function rashiAt(lon) {
	const index = Math.min(11, Math.floor(norm(lon) / 30));
	return {
		index,
		name: RASHIS[index][0],
		en: RASHIS[index][1]
	};
}
var monthByNewMoon = /* @__PURE__ */ new Map();
function lunarMonth(sunrise) {
	const current = SearchMoonPhase(0, sunrise, -40);
	if (!current) return {
		index: 0,
		adhik: false
	};
	const key = Math.round(current.date.getTime() / 6e4);
	const cached = monthByNewMoon.get(key);
	if (cached) return cached;
	const rashi = Math.floor(sunSidereal(current.date) / 30) % 12;
	const index = (rashi + 1) % 12;
	const previous = SearchMoonPhase(0, /* @__PURE__ */ new Date(current.date.getTime() - 864e5), -40);
	const value = {
		index,
		adhik: (previous ? Math.floor(sunSidereal(previous.date) / 30) % 12 : -1) === rashi
	};
	monthByNewMoon.set(key, value);
	return value;
}
function segment(sunrise, sunset, part) {
	const span = sunset.getTime() - sunrise.getTime();
	return {
		start: new Date(sunrise.getTime() + (part - 1) / 8 * span),
		end: new Date(sunrise.getTime() + part / 8 * span)
	};
}
var RAHU = [
	8,
	2,
	7,
	5,
	6,
	4,
	3
];
var YAMA = [
	5,
	4,
	3,
	2,
	1,
	7,
	6
];
var GULIKA = [
	7,
	6,
	5,
	4,
	3,
	2,
	1
];
function timingsFor(sunrise, sunset, weekday) {
	const muhurta = (sunset.getTime() - sunrise.getTime()) / 15;
	return {
		rahu: segment(sunrise, sunset, RAHU[weekday] ?? 8),
		yamaganda: segment(sunrise, sunset, YAMA[weekday] ?? 5),
		gulika: segment(sunrise, sunset, GULIKA[weekday] ?? 7),
		abhijit: {
			start: new Date(sunrise.getTime() + 7 * muhurta),
			end: new Date(sunrise.getTime() + 8 * muhurta)
		},
		brahma: {
			start: /* @__PURE__ */ new Date(sunrise.getTime() - 576e4),
			end: /* @__PURE__ */ new Date(sunrise.getTime() - 288e4)
		}
	};
}
function sankrantiBetween(sunrise, next) {
	const before = Math.floor(sunSidereal(sunrise) / 30) % 12;
	if (before === Math.floor(sunSidereal(/* @__PURE__ */ new Date(next.getTime() - 6e4)) / 30) % 12) return null;
	let lo = sunrise.getTime();
	let hi = next.getTime();
	for (let i = 0; i < 24; i += 1) {
		const mid = (lo + hi) / 2;
		if (Math.floor(sunSidereal(new Date(mid)) / 30) % 12 === before) lo = mid;
		else hi = mid;
	}
	return {
		name: `${RASHIS[Math.floor(sunSidereal(new Date(hi)) / 30) % 12][0]} Sankranti`,
		at: new Date(hi)
	};
}
function riseSet(body, observer, direction, start) {
	return SearchRiseSet(body, observer, direction, start, 1)?.date ?? null;
}
function getDay(iso, cityId) {
	const key = `${cityId}:${iso}`;
	const cached = cache.get(key);
	if (cached) return cached;
	const city = getCity(cityId);
	const observer = new Observer(city.lat, city.lon, 0);
	const midnight = /* @__PURE__ */ new Date(`${iso}T00:00:00+05:30`);
	const sunrise = riseSet(Body.Sun, observer, RISE, midnight);
	const sunset = sunrise ? riseSet(Body.Sun, observer, SET, new Date(sunrise.getTime() + 6e4)) : null;
	if (!sunrise || !sunset) throw new Error(`Could not find sunrise for ${city.name} on ${iso}.`);
	const next = riseSet(Body.Sun, observer, RISE, new Date(sunrise.getTime() + 36e5)) ?? new Date(sunrise.getTime() + 864e5);
	const weekday = weekdayIndex(iso);
	const tithi = tithiAt(sunrise);
	const nakshatra = nakshatraAt(sunrise);
	const yoga = yogaAt(sunrise);
	const karana = karanaAt(sunrise);
	const sun = rashiAt(sunSidereal(sunrise));
	const moon = rashiAt(moonSidereal(sunrise));
	const month = lunarMonth(sunrise);
	const purnimantaIndex = tithi.paksha === "Shukla" ? month.index : (month.index + 1) % 12;
	const day = {
		iso,
		weekday,
		weekdayName: WEEKDAYS[weekday] ?? "Sunday",
		vara: VARA[weekday] ?? "Ravivara",
		sunrise,
		sunset,
		timings: timingsFor(sunrise, sunset, weekday),
		tithiIndex: tithi.index,
		tithiName: tithi.name,
		paksha: tithi.paksha,
		tithiNumber: tithi.number,
		tithiEnd: tithi.end,
		nextTithi: nextTithiLabel(tithi.index),
		nakshatraIndex: nakshatra.index,
		nakshatraName: nakshatra.name,
		pada: nakshatra.pada,
		nakshatraEnd: nakshatra.end,
		yogaIndex: yoga.index,
		yogaName: yoga.name,
		yogaEnd: yoga.end,
		karanaName: karana.name,
		karanaEnd: karana.end,
		sunRashi: sun.name,
		sunRashiEn: sun.en,
		moonRashi: moon.name,
		moonRashiEn: moon.en,
		amantaIndex: month.index,
		amantaName: month.adhik ? `Adhik ${LUNAR_MONTHS[month.index]}` : LUNAR_MONTHS[month.index],
		purnimantaIndex,
		purnimantaName: LUNAR_MONTHS[purnimantaIndex],
		adhik: month.adhik,
		sankranti: sankrantiBetween(sunrise, next),
		moonrise: riseSet(Body.Moon, observer, RISE, midnight),
		moonset: riseSet(Body.Moon, observer, SET, midnight)
	};
	cache.set(key, day);
	return day;
}
function getLive(date = /* @__PURE__ */ new Date()) {
	const tithi = tithiAt(date);
	const nakshatra = nakshatraAt(date);
	const yoga = yogaAt(date);
	const karana = karanaAt(date);
	return {
		tithiName: tithi.name,
		paksha: tithi.paksha,
		tithiNumber: tithi.number,
		tithiEnd: tithi.end,
		nakshatraName: nakshatra.name,
		pada: nakshatra.pada,
		nakshatraEnd: nakshatra.end,
		yogaName: yoga.name,
		yogaEnd: yoga.end,
		karanaName: karana.name,
		karanaEnd: karana.end
	};
}
function eachDate(from, to) {
	const dates = [];
	let cursor = from;
	while (cursor <= to) {
		dates.push(cursor);
		cursor = addDays(cursor, 1);
	}
	return dates;
}
function monthLabel(day, system) {
	return system === "amanta" ? day.amantaName : day.purnimantaName;
}
//#endregion
export { monthLabel as a, getLive as i, ekadashiName as n, getDay as r, eachDate as t };
