import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, n as VolumeX, o as Heart, r as Volume2, s as Coins, t as Zap } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DWfzTlEC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function audioCtor() {
	if (typeof window === "undefined") return null;
	if (window.AudioContext) return window.AudioContext;
	return window.webkitAudioContext ?? null;
}
var Sfx = class {
	ctx = null;
	master = null;
	muted = false;
	unlock() {
		const Ctor = audioCtor();
		if (!Ctor) return;
		if (!this.ctx) {
			this.ctx = new Ctor({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.master.gain.value = this.muted ? 0 : .18;
			this.master.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (!this.ctx || !this.master) return;
		this.master.gain.setTargetAtTime(muted ? 0 : .18, this.ctx.currentTime, .02);
	}
	tone(freq, dur, type, gain, slide = 0) {
		if (!this.ctx || !this.master || this.muted) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const amp = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		amp.gain.setValueAtTime(1e-4, t);
		amp.gain.exponentialRampToValueAtTime(gain, t + .012);
		amp.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(amp);
		amp.connect(this.master);
		osc.start(t);
		osc.stop(t + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			amp.disconnect();
		};
	}
	place() {
		this.tone(180, .09, "triangle", .16, -60);
	}
	shoot(kind) {
		if (kind === "scharf") this.tone(720, .07, "square", .05, -400);
		else if (kind === "saeure") this.tone(220, .12, "sawtooth", .04, -80);
		else if (kind === "kleber") this.tone(160, .1, "triangle", .06, -40);
		else this.tone(480 + Math.random() * 80, .04, "square", .035, -120);
	}
	hit() {
		this.tone(320 + Math.random() * 40, .04, "square", .03, -80);
	}
	kill() {
		this.tone(660, .08, "triangle", .07, 180);
	}
	leak() {
		this.tone(110, .22, "sawtooth", .08, -50);
	}
	wave() {
		this.tone(240, .12, "triangle", .07, 80);
		this.tone(360, .16, "triangle", .05, 40);
	}
	win() {
		this.tone(523, .12, "triangle", .08);
		this.tone(659, .14, "triangle", .07);
		this.tone(784, .2, "triangle", .08);
	}
	lose() {
		this.tone(200, .2, "sawtooth", .07, -80);
		this.tone(140, .28, "triangle", .06, -40);
	}
};
var WORLD_W = 1280;
var BEST_KEY = "donnys-arschwehr-v1";
var TOWERS = {
	schnell: {
		kind: "schnell",
		name: "Spritzpistole",
		short: "Spritzer",
		blurb: "Billig und schnell. Kurze Reichweite.",
		cost: 55,
		range: 148,
		damage: 7,
		rate: 4.4,
		shotSpeed: 540,
		splash: 0,
		slow: 0,
		slowDur: 0
	},
	scharf: {
		kind: "scharf",
		name: "Scharfschütze",
		short: "Scharf",
		blurb: "Lange Reichweite, harte Schüsse, langsames Tempo.",
		cost: 150,
		range: 290,
		damage: 48,
		rate: .72,
		shotSpeed: 980,
		splash: 0,
		slow: 0,
		slowDur: 0
	},
	saeure: {
		kind: "saeure",
		name: "Säurefass",
		short: "Säure",
		blurb: "Spritzer in der Fläche. Ignoriert Panzerung.",
		cost: 105,
		range: 168,
		damage: 15,
		rate: 1.15,
		shotSpeed: 300,
		splash: 72,
		slow: 0,
		slowDur: 0
	},
	kleber: {
		kind: "kleber",
		name: "Kleberkanone",
		short: "Kleber",
		blurb: "Bremst Würmer stark. Wenig Schaden.",
		cost: 80,
		range: 158,
		damage: 4,
		rate: 1.7,
		shotSpeed: 340,
		splash: 0,
		slow: .42,
		slowDur: 2.3
	}
};
var TOWER_ORDER = [
	"schnell",
	"kleber",
	"saeure",
	"scharf"
];
var ENEMIES = {
	wurm: {
		kind: "wurm",
		hp: 36,
		speed: 76,
		gold: 5,
		leak: 1,
		scale: 1,
		armor: 0
	},
	raser: {
		kind: "raser",
		hp: 26,
		speed: 132,
		gold: 7,
		leak: 1,
		scale: .82,
		armor: 0
	},
	panzer: {
		kind: "panzer",
		hp: 120,
		speed: 50,
		gold: 14,
		leak: 2,
		scale: 1.18,
		armor: .4
	},
	boss: {
		kind: "boss",
		hp: 980,
		speed: 40,
		gold: 90,
		leak: 5,
		scale: 1.72,
		armor: .15
	}
};
var DMG_TABLE = [
	60,
	105,
	170
];
var RATE_TABLE = [
	50,
	90,
	145
];
function upgradeCost(baseCost, rank, stat) {
	if (rank >= 3) return null;
	return Math.round((stat === "dmg" ? DMG_TABLE : RATE_TABLE)[rank] * (.72 + baseCost / 210));
}
function scaledDamage(def, rank) {
	return Math.round(def.damage * (1 + rank * .45));
}
function scaledRate(def, rank) {
	return Math.round(def.rate * (1 + rank * .28) * 100) / 100;
}
var WAVES = [
	{ groups: [{
		type: "wurm",
		count: 8,
		interval: .82
	}] },
	{ groups: [{
		type: "wurm",
		count: 12,
		interval: .55
	}] },
	{ groups: [{
		type: "wurm",
		count: 7,
		interval: .5
	}, {
		type: "raser",
		count: 6,
		interval: .4
	}] },
	{ groups: [{
		type: "raser",
		count: 10,
		interval: .36
	}, {
		type: "wurm",
		count: 8,
		interval: .4
	}] },
	{ groups: [{
		type: "panzer",
		count: 3,
		interval: 1.25
	}, {
		type: "wurm",
		count: 10,
		interval: .42
	}] },
	{ groups: [{
		type: "wurm",
		count: 10,
		interval: .34
	}, {
		type: "raser",
		count: 10,
		interval: .3
	}] },
	{ groups: [{
		type: "panzer",
		count: 5,
		interval: .95
	}, {
		type: "raser",
		count: 8,
		interval: .32
	}] },
	{ groups: [{
		type: "wurm",
		count: 14,
		interval: .28
	}, {
		type: "panzer",
		count: 4,
		interval: .85
	}] },
	{ groups: [{
		type: "raser",
		count: 14,
		interval: .24
	}, {
		type: "panzer",
		count: 5,
		interval: .8
	}] },
	{ groups: [{
		type: "panzer",
		count: 7,
		interval: .7
	}, {
		type: "raser",
		count: 10,
		interval: .26
	}] },
	{ groups: [
		{
			type: "wurm",
			count: 12,
			interval: .22
		},
		{
			type: "raser",
			count: 12,
			interval: .22
		},
		{
			type: "panzer",
			count: 6,
			interval: .65
		}
	] },
	{ groups: [
		{
			type: "boss",
			count: 1,
			interval: .4
		},
		{
			type: "panzer",
			count: 4,
			interval: .85
		},
		{
			type: "raser",
			count: 8,
			interval: .28
		}
	] }
];
function enemyName(kind, count) {
	if (kind === "wurm") return count === 1 ? "Wurm" : "Würmer";
	if (kind === "raser") return count === 1 ? "Raser" : "Raser";
	if (kind === "panzer") return count === 1 ? "Panzerwurm" : "Panzerwürmer";
	return count === 1 ? "Königswurm" : "Königswürmer";
}
function describeWave(index) {
	const wave = WAVES[index];
	if (!wave) return "";
	return wave.groups.map((g) => `${g.count} ${enemyName(g.type, g.count)}`).join(" · ");
}
function waveHpScale(waveIndex) {
	return 1 + waveIndex * .16;
}
var WAYPOINTS = [
	{
		x: 28,
		y: 100
	},
	{
		x: 400,
		y: 100
	},
	{
		x: 400,
		y: 292
	},
	{
		x: 848,
		y: 292
	},
	{
		x: 848,
		y: 100
	},
	{
		x: 1200,
		y: 100
	},
	{
		x: 1200,
		y: 420
	},
	{
		x: 512,
		y: 420
	},
	{
		x: 160,
		y: 420
	},
	{
		x: 160,
		y: 612
	},
	{
		x: 960,
		y: 612
	},
	{
		x: 1144,
		y: 588
	}
];
var BASE = WAYPOINTS[WAYPOINTS.length - 1];
function buildTrack(points) {
	const samples = [{
		x: points[0].x,
		y: points[0].y
	}];
	const cum = [0];
	for (let i = 0; i < points.length - 1; i++) {
		const a = points[i];
		const b = points[i + 1];
		const len = Math.hypot(b.x - a.x, b.y - a.y);
		const n = Math.max(1, Math.round(len / 6));
		for (let s = 1; s <= n; s++) {
			const t = s / n;
			const p = {
				x: a.x + (b.x - a.x) * t,
				y: a.y + (b.y - a.y) * t
			};
			const prev = samples[samples.length - 1];
			samples.push(p);
			cum.push(cum[cum.length - 1] + Math.hypot(p.x - prev.x, p.y - prev.y));
		}
	}
	return {
		samples,
		cum,
		length: cum[cum.length - 1]
	};
}
function pointAt(track, dist) {
	const d = Math.max(0, Math.min(track.length, dist));
	let lo = 0;
	let hi = track.cum.length - 1;
	while (lo < hi) {
		const mid = lo + hi >> 1;
		if (track.cum[mid] < d) lo = mid + 1;
		else hi = mid;
	}
	const i = Math.max(1, lo);
	const span = track.cum[i] - track.cum[i - 1] || 1;
	const t = (d - track.cum[i - 1]) / span;
	const a = track.samples[i - 1];
	const b = track.samples[i];
	return {
		x: a.x + (b.x - a.x) * t,
		y: a.y + (b.y - a.y) * t,
		ang: Math.atan2(b.y - a.y, b.x - a.x)
	};
}
function distToPath(x, y, pts) {
	let best = Infinity;
	for (let i = 0; i < pts.length - 1; i++) {
		const a = pts[i];
		const b = pts[i + 1];
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const l2 = dx * dx + dy * dy || 1;
		let t = ((x - a.x) * dx + (y - a.y) * dy) / l2;
		if (t < 0) t = 0;
		else if (t > 1) t = 1;
		const px = a.x + dx * t;
		const py = a.y + dy * t;
		const dd = (x - px) * (x - px) + (y - py) * (y - py);
		if (dd < best) best = dd;
	}
	return Math.sqrt(best);
}
function cellOf(x, y) {
	const c = Math.floor(x / 64);
	const r = Math.floor(y / 64);
	if (c < 0 || r < 0 || c >= 20 || r >= 11) return null;
	return {
		c,
		r
	};
}
function cellCenter(c, r) {
	return {
		x: c * 64 + 32,
		y: r * 64 + 32
	};
}
function makeBlocked() {
	const grid = [];
	for (let r = 0; r < 11; r++) {
		const row = [];
		for (let c = 0; c < 20; c++) {
			const p = cellCenter(c, r);
			const onPath = distToPath(p.x, p.y, WAYPOINTS) < 50;
			const onBase = Math.hypot(p.x - BASE.x, p.y - BASE.y) < 108;
			row.push(onPath || onBase);
		}
		grid.push(row);
	}
	return grid;
}
var TRACK = buildTrack(WAYPOINTS);
var BLOCKED = makeBlocked();
var STEP = 1 / 60;
var SHOT_COLORS = {
	schnell: "#f0c14a",
	scharf: "#fff4c8",
	saeure: "#9be05a",
	kleber: "#ff8fb8"
};
function loadImage(src) {
	return new Promise((resolve) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => resolve(img);
		img.src = src;
	});
}
function readBest$1() {
	if (typeof window === "undefined") return 0;
	const n = Number(window.localStorage.getItem("donnys-arschwehr-v1") || 0);
	return Number.isFinite(n) ? n : 0;
}
var Game = class {
	canvas;
	onHud;
	ctx;
	sfx = new Sfx();
	raf = 0;
	last = 0;
	acc = 0;
	time = 0;
	ro = null;
	reduced = false;
	phase = "menu";
	lives = 20;
	gold = 150;
	wave = 0;
	speed = 1;
	armed = null;
	selectedId = null;
	hint = "Bandwürmer wollen zu Donny. Stell dich ihnen in den Weg.";
	hintUntil = 0;
	bestWave = 0;
	spawning = false;
	spawnQueue = [];
	spawnClock = 0;
	nextId = 1;
	towers = [];
	enemies = [];
	shots = [];
	particles = [];
	floaters = [];
	shake = 0;
	hurt = 0;
	hover = null;
	floor = null;
	donny = null;
	worms = [];
	towerArt = {};
	path = new Path2D();
	onPointerDown;
	onPointerMove;
	onPointerLeave;
	onKey;
	onVis;
	constructor(canvas, onHud) {
		this.canvas = canvas;
		this.onHud = onHud;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas fehlt");
		this.ctx = ctx;
		this.bestWave = readBest$1();
		this.path.moveTo(WAYPOINTS[0].x, WAYPOINTS[0].y);
		for (let i = 1; i < WAYPOINTS.length; i++) this.path.lineTo(WAYPOINTS[i].x, WAYPOINTS[i].y);
		this.reduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.onPointerDown = (e) => this.pointerDown(e);
		this.onPointerMove = (e) => this.pointerMove(e);
		this.onPointerLeave = () => {
			this.hover = null;
		};
		this.onKey = (e) => this.key(e);
		this.onVis = () => {
			if (document.visibilityState === "visible") this.sfx.resume();
		};
		this.loadArt();
	}
	start() {
		this.resize();
		const parent = this.canvas.parentElement;
		if (parent && typeof ResizeObserver !== "undefined") {
			this.ro = new ResizeObserver(() => this.resize());
			this.ro.observe(parent);
		}
		this.canvas.addEventListener("pointerdown", this.onPointerDown);
		this.canvas.addEventListener("pointermove", this.onPointerMove);
		this.canvas.addEventListener("pointerleave", this.onPointerLeave);
		window.addEventListener("keydown", this.onKey);
		document.addEventListener("visibilitychange", this.onVis);
		this.publish();
		this.raf = requestAnimationFrame(this.frame);
	}
	stop() {
		cancelAnimationFrame(this.raf);
		this.ro?.disconnect();
		this.canvas.removeEventListener("pointerdown", this.onPointerDown);
		this.canvas.removeEventListener("pointermove", this.onPointerMove);
		this.canvas.removeEventListener("pointerleave", this.onPointerLeave);
		window.removeEventListener("keydown", this.onKey);
		document.removeEventListener("visibilitychange", this.onVis);
	}
	begin() {
		this.sfx.unlock();
		this.resetMatch();
		this.phase = "playing";
		this.say("Wähle einen Turm und tippe ein freies Feld neben dem Schleim.");
		this.publish();
	}
	restart() {
		this.sfx.unlock();
		this.resetMatch();
		this.phase = "playing";
		this.hint = "Neue Runde. Der Weg ist wieder frei.";
		this.publish();
	}
	arm(kind) {
		if (this.phase !== "playing") return;
		this.sfx.unlock();
		this.armed = this.armed === kind ? null : kind;
		this.selectedId = null;
		if (this.armed) this.say(`${TOWERS[this.armed].name}: ${TOWERS[this.armed].blurb}`);
		else this.hint = "Turm abgewählt.";
		this.publish();
	}
	startWave() {
		if (!this.canStart()) return;
		this.sfx.unlock();
		const index = this.wave;
		const spec = WAVES[index];
		let at = .15;
		const scale = waveHpScale(index);
		for (const group of spec.groups) {
			const base = ENEMIES[group.type];
			for (let i = 0; i < group.count; i++) {
				this.spawnQueue.push({
					at,
					kind: group.type,
					hp: Math.round(base.hp * scale)
				});
				at += group.interval;
			}
			at += .7;
		}
		this.spawnClock = 0;
		this.spawning = true;
		this.wave = index + 1;
		this.sfx.wave();
		this.say(`Welle ${this.wave}: ${describeWave(index)}`);
		this.publish();
	}
	toggleSpeed() {
		if (this.phase !== "playing") return;
		this.speed = this.speed === 1 ? 2 : 1;
		this.publish();
	}
	toggleMute() {
		this.sfx.unlock();
		this.sfx.setMuted(!this.sfx.muted);
		this.publish();
	}
	upgrade(stat) {
		const tower = this.selectedTower();
		if (!tower || this.phase !== "playing") return;
		const rank = stat === "dmg" ? tower.dmgRank : tower.rateRank;
		const cost = upgradeCost(TOWERS[tower.kind].cost, rank, stat);
		if (cost == null) return;
		if (this.gold < cost) {
			this.say("Zu wenig Gold für die Verbesserung.");
			return;
		}
		this.gold -= cost;
		tower.spent += cost;
		if (stat === "dmg") tower.dmgRank += 1;
		else tower.rateRank += 1;
		this.sfx.place();
		this.say(stat === "dmg" ? "Schaden verbessert." : "Feuerrate verbessert.");
		this.publish();
	}
	sell() {
		const tower = this.selectedTower();
		if (!tower || this.phase !== "playing") return;
		const refund = Math.round(tower.spent * .6);
		this.gold += refund;
		this.towers = this.towers.filter((t) => t.id !== tower.id);
		this.selectedId = null;
		this.float(`+${refund}`, tower.x, tower.y - 20, "#f0b429");
		this.sfx.kill();
		this.say(`Verkauft. +${refund} Gold.`);
		this.publish();
	}
	setAim(mode) {
		const tower = this.selectedTower();
		if (!tower) return;
		tower.aim = mode;
		this.publish();
	}
	resetMatch() {
		this.lives = 20;
		this.gold = 150;
		this.wave = 0;
		this.speed = 1;
		this.armed = null;
		this.selectedId = null;
		this.spawning = false;
		this.spawnQueue = [];
		this.spawnClock = 0;
		this.towers = [];
		this.enemies = [];
		this.shots = [];
		this.particles = [];
		this.floaters = [];
		this.shake = 0;
		this.hurt = 0;
		this.time = 0;
		this.acc = 0;
	}
	canStart() {
		return this.phase === "playing" && !this.spawning && this.enemies.length === 0 && this.wave < 12;
	}
	selectedTower() {
		return this.towers.find((t) => t.id === this.selectedId) ?? null;
	}
	say(text) {
		this.hint = text;
		this.hintUntil = this.time + 2.4;
	}
	publish() {
		const selected = this.selectedTower();
		let selectedHud = null;
		if (selected) {
			const def = TOWERS[selected.kind];
			const dmgCost = upgradeCost(def.cost, selected.dmgRank, "dmg");
			const rateCost = upgradeCost(def.cost, selected.rateRank, "rate");
			selectedHud = {
				id: selected.id,
				kind: selected.kind,
				name: def.name,
				dmgRank: selected.dmgRank,
				rateRank: selected.rateRank,
				damage: scaledDamage(def, selected.dmgRank),
				rate: scaledRate(def, selected.rateRank),
				nextDamage: selected.dmgRank < 3 ? scaledDamage(def, selected.dmgRank + 1) : null,
				nextRate: selected.rateRank < 3 ? scaledRate(def, selected.rateRank + 1) : null,
				dmgCost,
				rateCost,
				sell: Math.round(selected.spent * .6),
				aim: selected.aim
			};
		}
		const next = this.canStart() ? this.wave : -1;
		this.onHud({
			phase: this.phase,
			lives: this.lives,
			gold: this.gold,
			wave: this.wave,
			wavesTotal: 12,
			enemiesLeft: this.enemies.length + this.spawnQueue.length,
			canStart: this.canStart(),
			preview: next >= 0 ? describeWave(next) : "",
			speed: this.speed,
			muted: this.sfx.muted,
			armed: this.armed,
			selected: selectedHud,
			hint: this.hint,
			bestWave: this.bestWave
		});
	}
	rememberBest() {
		const reached = this.wave;
		if (reached > this.bestWave) {
			this.bestWave = reached;
			try {
				window.localStorage.setItem(BEST_KEY, String(reached));
			} catch {}
		}
	}
	frame = (stamp) => {
		const raw = this.last ? Math.min(.1, (stamp - this.last) / 1e3) : 0;
		this.last = stamp;
		if (this.phase === "playing") {
			this.acc += raw * this.speed;
			let guard = 0;
			while (this.acc >= STEP && guard++ < 10) {
				this.step(STEP);
				this.acc -= STEP;
			}
		}
		this.render(stamp / 1e3);
		this.raf = requestAnimationFrame(this.frame);
	};
	step(dt) {
		this.time += dt;
		if (this.hintUntil && this.time > this.hintUntil) {
			this.hintUntil = 0;
			this.hint = this.defaultHint();
			this.publish();
		}
		if (this.spawning) {
			this.spawnClock += dt;
			while (this.spawnQueue.length && this.spawnQueue[0].at <= this.spawnClock) {
				const job = this.spawnQueue.shift();
				this.spawnEnemy(job.kind, job.hp);
			}
			if (!this.spawnQueue.length) this.spawning = false;
		}
		for (const enemy of this.enemies) {
			const def = ENEMIES[enemy.kind];
			if (enemy.slowT > 0) enemy.slowT = Math.max(0, enemy.slowT - dt);
			const mult = enemy.slowT > 0 ? .42 : 1;
			enemy.dist += def.speed * mult * dt;
			enemy.flash = Math.max(0, enemy.flash - dt);
			const pose = pointAt(TRACK, enemy.dist);
			enemy.x = pose.x;
			enemy.y = pose.y;
			enemy.ang = pose.ang;
		}
		for (let i = this.enemies.length - 1; i >= 0; i--) {
			const enemy = this.enemies[i];
			if (enemy.dist >= TRACK.length - 4) {
				this.enemies.splice(i, 1);
				this.leak(enemy);
			}
		}
		for (const tower of this.towers) {
			tower.cool = Math.max(0, tower.cool - dt);
			tower.kick = Math.max(0, tower.kick - dt * 4);
			const target = this.pickTarget(tower);
			if (target) {
				tower.facing = Math.atan2(target.y - tower.y, target.x - tower.x);
				if (tower.cool <= 0) this.fire(tower, target);
			}
		}
		for (let i = this.shots.length - 1; i >= 0; i--) {
			const shot = this.shots[i];
			const target = this.enemies.find((e) => e.id === shot.target);
			if (target) {
				shot.tx = target.x;
				shot.ty = target.y;
			}
			const dx = shot.tx - shot.x;
			const dy = shot.ty - shot.y;
			const dist = Math.hypot(dx, dy) || 1;
			const step = shot.speed * dt;
			if (dist <= Math.max(16, step)) {
				this.impact(shot);
				this.shots.splice(i, 1);
				continue;
			}
			shot.x += dx / dist * step;
			shot.y += dy / dist * step;
			shot.life -= dt;
			if (shot.life <= 0) this.shots.splice(i, 1);
		}
		for (let i = this.particles.length - 1; i >= 0; i--) {
			const p = this.particles[i];
			p.life -= dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.vy += 30 * dt;
			if (p.life <= 0) this.particles.splice(i, 1);
		}
		for (let i = this.floaters.length - 1; i >= 0; i--) {
			const f = this.floaters[i];
			f.life -= dt;
			f.y -= 22 * dt;
			if (f.life <= 0) this.floaters.splice(i, 1);
		}
		if (this.phase === "playing" && !this.spawning && this.spawnQueue.length === 0 && this.enemies.length === 0 && this.wave > 0) {
			if (this.wave >= 12) this.finish(true);
		}
	}
	defaultHint() {
		if (this.phase !== "playing") return this.hint;
		if (this.armed) return `${TOWERS[this.armed].name}: Tippe ein freies Feld.`;
		if (this.canStart()) return this.wave === 0 ? "Baue zuerst, dann starte Welle 1." : "Weg ist frei. Nächste Welle, wenn du soweit bist.";
		return "Halte den Schleimweg.";
	}
	spawnEnemy(kind, hp) {
		const pose = pointAt(TRACK, 0);
		this.enemies.push({
			id: this.nextId++,
			kind,
			dist: 0,
			hp,
			maxHp: hp,
			slowT: 0,
			flash: 0,
			x: pose.x,
			y: pose.y,
			ang: pose.ang
		});
	}
	leak(enemy) {
		const loss = ENEMIES[enemy.kind].leak;
		this.lives = Math.max(0, this.lives - loss);
		this.shake = enemy.kind === "boss" ? 16 : 9;
		this.hurt = .35;
		this.sfx.leak();
		this.say(loss > 1 ? `Durchbruch! −${loss} Leben.` : "Ein Wurm ist durch.");
		this.publish();
		if (this.lives <= 0) this.finish(false);
	}
	finish(win) {
		if (this.phase !== "playing") return;
		this.phase = win ? "win" : "over";
		this.spawning = false;
		this.spawnQueue = [];
		this.rememberBest();
		if (win) this.sfx.win();
		else this.sfx.lose();
		this.hint = win ? "Donny bleibt unangetastet." : "Die Würmer sind angekommen.";
		this.publish();
	}
	pickTarget(tower) {
		const range = TOWERS[tower.kind].range;
		const r2 = range * range;
		let best = null;
		let bestScore = 0;
		for (const enemy of this.enemies) {
			const dx = enemy.x - tower.x;
			const dy = enemy.y - tower.y;
			const d2 = dx * dx + dy * dy;
			if (d2 > r2) continue;
			let score = 0;
			if (tower.aim === "first") score = enemy.dist;
			else if (tower.aim === "last") score = -enemy.dist;
			else if (tower.aim === "strong") score = enemy.hp;
			else score = -d2;
			if (!best || score > bestScore) {
				best = enemy;
				bestScore = score;
			}
		}
		return best;
	}
	fire(tower, target) {
		const def = TOWERS[tower.kind];
		tower.cool = 1 / scaledRate(def, tower.rateRank);
		tower.kick = 1;
		const dmg = scaledDamage(def, tower.dmgRank);
		this.shots.push({
			x: tower.x,
			y: tower.y,
			tx: target.x,
			ty: target.y,
			target: target.id,
			speed: def.shotSpeed,
			dmg,
			kind: tower.kind,
			splash: def.splash,
			slow: def.slow,
			slowDur: def.slowDur,
			life: 1.6
		});
		this.sfx.shoot(tower.kind);
	}
	impact(shot) {
		const hit = (enemy, dmg) => {
			const def = ENEMIES[enemy.kind];
			const armor = shot.kind === "saeure" ? 0 : def.armor;
			const dealt = Math.max(1, Math.round(dmg * (1 - armor)));
			enemy.hp -= dealt;
			enemy.flash = .08;
			if (shot.slow > 0) enemy.slowT = Math.max(enemy.slowT, shot.slowDur);
			return enemy.hp <= 0;
		};
		if (shot.splash > 0) {
			const r2 = shot.splash * shot.splash;
			for (let i = this.enemies.length - 1; i >= 0; i--) {
				const enemy = this.enemies[i];
				const dx = enemy.x - shot.x;
				const dy = enemy.y - shot.y;
				if (dx * dx + dy * dy > r2) continue;
				if (hit(enemy, shot.dmg)) this.killEnemy(i);
			}
		} else {
			let idx = this.enemies.findIndex((e) => e.id === shot.target);
			if (idx < 0) {
				let best = Infinity;
				for (let i = 0; i < this.enemies.length; i++) {
					const enemy = this.enemies[i];
					const d = (enemy.x - shot.x) ** 2 + (enemy.y - shot.y) ** 2;
					if (d < best && d < 784) {
						best = d;
						idx = i;
					}
				}
			}
			if (idx >= 0 && hit(this.enemies[idx], shot.dmg)) this.killEnemy(idx);
		}
		this.burst(shot.x, shot.y, SHOT_COLORS[shot.kind], shot.splash > 0 ? 10 : 5);
		this.sfx.hit();
	}
	killEnemy(index) {
		const enemy = this.enemies[index];
		if (!enemy) return;
		const gold = ENEMIES[enemy.kind].gold;
		this.gold += gold;
		this.float(`+${gold}`, enemy.x, enemy.y - 16, "#f0b429");
		this.burst(enemy.x, enemy.y, "#f4e2cf", 12);
		this.enemies.splice(index, 1);
		this.sfx.kill();
		this.publish();
	}
	burst(x, y, color, n) {
		for (let i = 0; i < n; i++) {
			const a = Math.random() * Math.PI * 2;
			const s = 30 + Math.random() * 90;
			this.particles.push({
				x,
				y,
				vx: Math.cos(a) * s,
				vy: Math.sin(a) * s,
				life: .28 + Math.random() * .2,
				max: .45,
				color,
				r: 2 + Math.random() * 2.5
			});
		}
	}
	float(text, x, y, color) {
		this.floaters.push({
			x,
			y,
			text,
			life: .8,
			color
		});
	}
	pointerDown(e) {
		if (this.phase !== "playing") return;
		this.sfx.unlock();
		const p = this.worldPoint(e);
		if (!p) return;
		const hit = this.towerAt(p.x, p.y);
		if (hit) {
			this.selectedId = hit.id;
			this.armed = null;
			this.say(`${TOWERS[hit.kind].name} gewählt.`);
			this.publish();
			return;
		}
		if (!this.armed) {
			this.selectedId = null;
			this.publish();
			return;
		}
		const cell = cellOf(p.x, p.y);
		if (!cell) {
			this.say("Daneben.");
			this.publish();
			return;
		}
		if (BLOCKED[cell.r][cell.c]) {
			this.say("Nicht auf dem Schleimweg und nicht auf Donny.");
			this.publish();
			return;
		}
		if (this.towers.some((t) => t.c === cell.c && t.r === cell.r)) {
			this.say("Hier steht schon ein Turm.");
			this.publish();
			return;
		}
		const def = TOWERS[this.armed];
		if (this.gold < def.cost) {
			this.say("Zu wenig Gold.");
			this.publish();
			return;
		}
		const center = cellCenter(cell.c, cell.r);
		this.gold -= def.cost;
		this.towers.push({
			id: this.nextId++,
			kind: this.armed,
			c: cell.c,
			r: cell.r,
			x: center.x,
			y: center.y,
			dmgRank: 0,
			rateRank: 0,
			spent: def.cost,
			cool: .15,
			aim: "first",
			facing: -Math.PI / 2,
			kick: 0
		});
		this.sfx.place();
		this.say(`${def.name} steht. Noch ${this.gold} Gold.`);
		this.publish();
	}
	pointerMove(e) {
		const p = this.worldPoint(e);
		this.hover = p ? cellOf(p.x, p.y) : null;
	}
	key(e) {
		if (e.repeat) return;
		const tag = e.target?.tagName;
		if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
		if (e.key === " " || e.key === "Enter") {
			if (this.phase === "menu") this.begin();
			else if (this.canStart()) this.startWave();
			e.preventDefault();
		} else if (e.key === "1") this.arm("schnell");
		else if (e.key === "2") this.arm("kleber");
		else if (e.key === "3") this.arm("saeure");
		else if (e.key === "4") this.arm("scharf");
		else if (e.key === "Escape") {
			this.armed = null;
			this.selectedId = null;
			this.publish();
		} else if (e.key === "f" || e.key === "F") this.toggleSpeed();
	}
	towerAt(x, y) {
		let best = null;
		let bestD = 784;
		for (const tower of this.towers) {
			const d = (tower.x - x) ** 2 + (tower.y - y) ** 2;
			if (d <= bestD) {
				best = tower;
				bestD = d;
			}
		}
		return best;
	}
	worldPoint(e) {
		const rect = this.canvas.getBoundingClientRect();
		if (rect.width <= 0 || rect.height <= 0) return null;
		return {
			x: (e.clientX - rect.left) / rect.width * WORLD_W,
			y: (e.clientY - rect.top) / rect.height * 720
		};
	}
	resize() {
		const parent = this.canvas.parentElement;
		if (!parent) return;
		const bounds = parent.getBoundingClientRect();
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const scale = Math.min(bounds.width / WORLD_W, bounds.height / 720);
		const cssW = Math.max(1, Math.floor(WORLD_W * scale));
		const cssH = Math.max(1, Math.floor(720 * scale));
		this.canvas.style.width = `${cssW}px`;
		this.canvas.style.height = `${cssH}px`;
		this.canvas.width = Math.floor(cssW * dpr);
		this.canvas.height = Math.floor(cssH * dpr);
		this.ctx.setTransform(dpr * (cssW / WORLD_W), 0, 0, dpr * (cssH / 720), 0, 0);
	}
	async loadArt() {
		const [floor, donny, w0, w1, w2, w3, schnell, scharf, saeure, kleber] = await Promise.all([
			loadImage("/game/floor.jpg"),
			loadImage("/game/donny.png"),
			loadImage("/game/worm-0.png"),
			loadImage("/game/worm-1.png"),
			loadImage("/game/worm-2.png"),
			loadImage("/game/worm-3.png"),
			loadImage("/game/tower-schnell.png"),
			loadImage("/game/tower-scharf.png"),
			loadImage("/game/tower-saeure.png"),
			loadImage("/game/tower-kleber.png")
		]);
		this.floor = floor.naturalWidth ? floor : null;
		this.donny = donny.naturalWidth ? donny : null;
		this.worms = [
			w0,
			w1,
			w2,
			w3
		].filter((img) => img.naturalWidth > 0);
		this.towerArt = {
			schnell: schnell.naturalWidth ? schnell : void 0,
			scharf: scharf.naturalWidth ? scharf : void 0,
			saeure: saeure.naturalWidth ? saeure : void 0,
			kleber: kleber.naturalWidth ? kleber : void 0
		};
	}
	render(now) {
		const ctx = this.ctx;
		ctx.clearRect(0, 0, WORLD_W, 720);
		ctx.save();
		if (!this.reduced && this.shake > .4) {
			ctx.translate((Math.random() - .5) * this.shake, (Math.random() - .5) * this.shake);
			this.shake *= .86;
		} else this.shake = 0;
		if (this.floor) ctx.drawImage(this.floor, 0, 0, WORLD_W, 720);
		else {
			ctx.fillStyle = "#e7b7bf";
			ctx.fillRect(0, 0, WORLD_W, 720);
		}
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = "rgba(86, 120, 58, 0.45)";
		ctx.lineWidth = 78;
		ctx.stroke(this.path);
		ctx.strokeStyle = "rgba(186, 214, 104, 0.94)";
		ctx.lineWidth = 58;
		ctx.stroke(this.path);
		ctx.strokeStyle = "rgba(255, 252, 220, 0.35)";
		ctx.lineWidth = 14;
		ctx.stroke(this.path);
		this.drawChevrons(ctx, now);
		if (this.phase === "playing" && this.armed) {
			ctx.strokeStyle = "rgba(247, 239, 230, 0.28)";
			ctx.lineWidth = 2;
			for (let r = 0; r < 11; r++) for (let c = 0; c < 20; c++) {
				if (BLOCKED[r][c]) continue;
				if (this.towers.some((t) => t.c === c && t.r === r)) continue;
				const x = c * 64 + 8;
				const y = r * 64 + 8;
				this.roundRect(ctx, x, y, 48, 48, 10);
				ctx.stroke();
			}
		}
		const ghost = this.hover && this.armed && this.phase === "playing" ? this.hover : null;
		if (ghost && !BLOCKED[ghost.r][ghost.c] && !this.towers.some((t) => t.c === ghost.c && t.r === ghost.r)) {
			const center = cellCenter(ghost.c, ghost.r);
			this.rangeRing(ctx, center.x, center.y, TOWERS[this.armed].range, "rgba(143, 211, 106, 0.28)");
			this.drawTowerSprite(ctx, this.armed, center.x, center.y, -Math.PI / 2, 0, .55);
		}
		const selected = this.selectedTower();
		if (selected && this.phase === "playing") this.rangeRing(ctx, selected.x, selected.y, TOWERS[selected.kind].range, "rgba(240, 180, 41, 0.28)");
		for (const tower of this.towers) this.drawTowerSprite(ctx, tower.kind, tower.x, tower.y, tower.facing, tower.kick, 1);
		for (const enemy of this.enemies) this.drawEnemy(ctx, enemy, now);
		for (const shot of this.shots) {
			ctx.fillStyle = SHOT_COLORS[shot.kind];
			ctx.beginPath();
			const rad = shot.kind === "scharf" ? 4 : shot.kind === "schnell" ? 3.5 : 7;
			ctx.arc(shot.x, shot.y, rad, 0, Math.PI * 2);
			ctx.fill();
			if (shot.kind === "scharf") {
				ctx.strokeStyle = "rgba(255, 244, 200, 0.7)";
				ctx.lineWidth = 2;
				ctx.beginPath();
				const ang = Math.atan2(shot.ty - shot.y, shot.tx - shot.x);
				ctx.moveTo(shot.x, shot.y);
				ctx.lineTo(shot.x - Math.cos(ang) * 18, shot.y - Math.sin(ang) * 18);
				ctx.stroke();
			}
		}
		for (const p of this.particles) {
			ctx.globalAlpha = Math.max(0, p.life / p.max);
			ctx.fillStyle = p.color;
			ctx.beginPath();
			ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
		}
		this.drawDonny(ctx, now);
		ctx.font = "700 18px Fredoka, Outfit, sans-serif";
		ctx.textAlign = "center";
		for (const f of this.floaters) {
			ctx.globalAlpha = Math.max(0, f.life / .8);
			ctx.fillStyle = f.color;
			ctx.fillText(f.text, f.x, f.y);
			ctx.globalAlpha = 1;
		}
		if (this.hurt > 0 && !this.reduced) {
			ctx.fillStyle = `rgba(228, 83, 78, ${this.hurt * .28})`;
			ctx.fillRect(0, 0, WORLD_W, 720);
			this.hurt = Math.max(0, this.hurt - .02);
		}
		ctx.restore();
	}
	drawChevrons(ctx, now) {
		ctx.fillStyle = "rgba(70, 100, 46, 0.55)";
		const shift = this.reduced ? 0 : now * 46 % 120;
		for (let d = 70 + shift; d < TRACK.length - 80; d += 120) {
			const a = pointAt(TRACK, d);
			const b = pointAt(TRACK, d + 10);
			const ang = Math.atan2(b.y - a.y, b.x - a.x);
			ctx.save();
			ctx.translate(a.x, a.y);
			ctx.rotate(ang);
			ctx.beginPath();
			ctx.moveTo(12, 0);
			ctx.lineTo(-8, -8);
			ctx.lineTo(-8, 8);
			ctx.closePath();
			ctx.fill();
			ctx.restore();
		}
	}
	rangeRing(ctx, x, y, range, color) {
		ctx.beginPath();
		ctx.arc(x, y, range, 0, Math.PI * 2);
		ctx.fillStyle = color;
		ctx.fill();
		ctx.strokeStyle = color.replace("0.28", "0.8");
		ctx.lineWidth = 2;
		ctx.stroke();
	}
	drawTowerSprite(ctx, kind, x, y, facing, kick, alpha) {
		const img = this.towerArt[kind];
		ctx.save();
		ctx.globalAlpha = alpha;
		ctx.translate(x, y);
		ctx.fillStyle = "rgba(40, 16, 24, 0.28)";
		ctx.beginPath();
		ctx.ellipse(0, 16, 20, 8, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.rotate(facing + Math.PI / 2);
		ctx.translate(0, kick * 7);
		const size = kind === "scharf" ? 78 : 70;
		if (img) ctx.drawImage(img, -size / 2, -size * .62, size, size);
		else {
			ctx.fillStyle = SHOT_COLORS[kind];
			ctx.beginPath();
			ctx.arc(0, 0, 16, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();
	}
	drawEnemy(ctx, enemy, now) {
		const def = ENEMIES[enemy.kind];
		const frame = this.worms.length ? this.worms[Math.floor(now * 8 + enemy.id) % this.worms.length] : null;
		const size = 188 * def.scale;
		ctx.save();
		ctx.translate(enemy.x, enemy.y);
		if (enemy.flash > 0) ctx.filter = "brightness(1.7)";
		ctx.rotate(enemy.ang);
		if (frame) ctx.drawImage(frame, -size / 2, -size / 2, size, size);
		else {
			ctx.fillStyle = "#f3e2c4";
			ctx.fillRect(-20, -8, 40, 16);
		}
		ctx.filter = "none";
		ctx.restore();
		if (enemy.kind === "boss") this.crown(ctx, enemy.x, enemy.y - 28 * def.scale);
		if (enemy.kind === "panzer") {
			ctx.strokeStyle = "rgba(70, 78, 96, 0.8)";
			ctx.lineWidth = 3;
			ctx.beginPath();
			ctx.arc(enemy.x, enemy.y, 16 * def.scale, 0, Math.PI * 2);
			ctx.stroke();
		}
		if (enemy.hp < enemy.maxHp) {
			const w = 36 * def.scale;
			const x = enemy.x - w / 2;
			const y = enemy.y - 18 * def.scale - 10;
			ctx.fillStyle = "rgba(20, 10, 14, 0.7)";
			ctx.fillRect(x, y, w, 5);
			ctx.fillStyle = enemy.slowT > 0 ? "#ff8fb8" : "#e4534e";
			ctx.fillRect(x, y, w * Math.max(0, enemy.hp / enemy.maxHp), 5);
		}
	}
	crown(ctx, x, y) {
		ctx.fillStyle = "#f0b429";
		ctx.beginPath();
		ctx.moveTo(x - 16, y + 8);
		ctx.lineTo(x - 16, y - 2);
		ctx.lineTo(x - 8, y + 4);
		ctx.lineTo(x, y - 10);
		ctx.lineTo(x + 8, y + 4);
		ctx.lineTo(x + 16, y - 2);
		ctx.lineTo(x + 16, y + 8);
		ctx.closePath();
		ctx.fill();
	}
	drawDonny(ctx, now) {
		const bob = this.reduced ? 0 : Math.sin(now * 2.2) * 3;
		const w = 176;
		const h = 176;
		const x = BASE.x - w / 2;
		const y = BASE.y - h * .78 + bob;
		if (this.donny) ctx.drawImage(this.donny, x, y, w, h);
		else {
			ctx.fillStyle = "#f0a05a";
			ctx.beginPath();
			ctx.arc(BASE.x, BASE.y - 40, 36, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	roundRect(ctx, x, y, w, h, r) {
		ctx.beginPath();
		ctx.moveTo(x + r, y);
		ctx.arcTo(x + w, y, x + w, y + h, r);
		ctx.arcTo(x + w, y + h, x, y + h, r);
		ctx.arcTo(x, y + h, x, y, r);
		ctx.arcTo(x, y, x + w, y, r);
		ctx.closePath();
	}
};
var AIM_LABEL = [
	{
		id: "first",
		label: "Erster"
	},
	{
		id: "last",
		label: "Letzter"
	},
	{
		id: "strong",
		label: "Stärkster"
	},
	{
		id: "near",
		label: "Nächster"
	}
];
function readBest() {
	if (typeof window === "undefined") return 0;
	const n = Number(window.localStorage.getItem("donnys-arschwehr-v1") || 0);
	return Number.isFinite(n) ? n : 0;
}
function initialHud() {
	return {
		phase: "menu",
		lives: 20,
		gold: 150,
		wave: 0,
		wavesTotal: 12,
		enemiesLeft: 0,
		canStart: false,
		preview: "",
		speed: 1,
		muted: false,
		armed: null,
		selected: null,
		hint: "Die Bandwürmer marschieren. Donny zählt auf die Türme.",
		bestWave: readBest()
	};
}
function pips(rank) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex gap-1",
		"aria-hidden": "true",
		children: [
			0,
			1,
			2
		].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: i < rank ? "h-1.5 w-4 rounded-full bg-gold" : "h-1.5 w-4 rounded-full bg-line" }, i))
	});
}
function GameScreen() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(initialHud);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const game = new Game(canvas, setHud);
		gameRef.current = game;
		game.start();
		return () => {
			game.stop();
			gameRef.current = null;
		};
	}, []);
	const game = () => gameRef.current;
	const playing = hud.phase === "playing";
	const status = hud.phase === "win" ? "Sieg. Donny bleibt unangetastet." : hud.phase === "over" ? "Niederlage. Die Würmer sind durch." : hud.phase === "menu" ? "Bereit." : `Welle ${hud.wave} von ${hud.wavesTotal}. ${hud.lives} Leben. ${hud.gold} Gold.`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-2 border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl leading-none text-fg",
						children: "Donnys Arschwehr"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: hud.hint
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex flex-wrap items-center justify-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-11 items-center gap-1.5 rounded-full bg-surface px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
									className: "size-4 text-danger",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-base",
									children: hud.lives
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Leben"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-11 items-center gap-1.5 rounded-full bg-surface px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, {
									className: "size-4 text-gold",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-base text-gold",
									children: hud.gold
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Gold"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-11 items-center rounded-full bg-surface px-3 font-display text-sm",
							children: [
								"Welle ",
								hud.wave > 0 ? hud.wave : "–",
								"/",
								hud.wavesTotal
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-11 items-center gap-1 rounded-full bg-surface px-3 text-sm text-fg disabled:opacity-40",
							onClick: () => game()?.toggleSpeed(),
							disabled: !playing,
							"aria-label": hud.speed === 1 ? "Doppelte Geschwindigkeit" : "Normale Geschwindigkeit",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {
									className: "size-4 text-slime",
									"aria-hidden": "true"
								}),
								hud.speed,
								"×"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full bg-surface text-fg",
							onClick: () => game()?.toggleMute(),
							"aria-label": hud.muted ? "Ton an" : "Ton aus",
							children: hud.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "stage",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "board-wrap h-full w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						className: "board",
						"aria-label": "Schlachtfeld"
					}), hud.phase !== "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overlay-card w-full max-w-md rounded-lg border border-line bg-surface px-5 py-5 text-fg shadow-lg",
							children: hud.phase === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl leading-none",
									children: "Halt den Ausgang dicht"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted",
									children: "Bandwürmer kriechen den Schleimweg entlang auf Donny zu. Setze Türme daneben, kassiere Gold für jeden Abschuss und verbessere Schaden sowie Feuerrate. Zwölf Wellen. Der Königswurm kommt zuletzt."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-3 space-y-1 text-sm text-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Spritzer hält die frühen Wellen. Scharfschütze reicht weit." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Säure frisst Panzerung. Kleber bremst Raser." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Leben oben links. Ein Durchbruch kostet welche." })
									]
								}),
								hud.bestWave > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-xs text-gold",
									children: ["Beste Runde: Welle ", hud.bestWave]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-4 h-12 w-full rounded-full bg-slime font-display text-lg text-ink",
									onClick: () => game()?.begin(),
									children: "Stellung beziehen"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl leading-none",
									children: hud.phase === "win" ? "Donny bleibt dicht" : "Durchbruch"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted",
									children: hud.phase === "win" ? "Welle 12 ist Geschichte. Kein Königswurm hat es bis zum Ende geschafft." : "Die Würmer sind angekommen. Donny ist wenig begeistert. Neue Türme, neue Runde."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-display text-lg",
									children: [
										"Welle ",
										hud.wave,
										"/",
										hud.wavesTotal,
										hud.bestWave > 0 ? ` · Bestleistung ${hud.bestWave}` : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-gold font-display text-lg text-ink",
									onClick: () => game()?.restart(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										className: "size-5",
										"aria-hidden": "true"
									}), "Nochmal"]
								})
							] })
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-line bg-bg px-3 pt-2 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sr-only",
						"aria-live": "polite",
						children: status
					}),
					hud.selected && playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap items-center gap-2 rounded-lg bg-surface px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-36",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-base leading-none",
									children: hud.selected.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										hud.selected.damage,
										" Schaden · ",
										hud.selected.rate,
										"/s"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm disabled:opacity-40",
								disabled: hud.selected.dmgCost == null || hud.gold < (hud.selected.dmgCost ?? 0),
								onClick: () => game()?.upgrade("dmg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Schaden" }),
									pips(hud.selected.dmgRank),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: hud.selected.dmgCost == null ? "Max" : hud.selected.dmgCost
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm disabled:opacity-40",
								disabled: hud.selected.rateCost == null || hud.gold < (hud.selected.rateCost ?? 0),
								onClick: () => game()?.upgrade("rate"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Feuerrate" }),
									pips(hud.selected.rateRank),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: hud.selected.rateCost == null ? "Max" : hud.selected.rateCost
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm",
								children: ["Ziel", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "bg-transparent text-fg outline-none",
									value: hud.selected.aim,
									onChange: (e) => game()?.setAim(e.target.value),
									children: AIM_LABEL.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: opt.id,
										className: "bg-surface text-fg",
										children: opt.label
									}, opt.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex h-11 items-center rounded-full bg-danger px-3 text-sm text-fg",
								onClick: () => game()?.sell(),
								children: ["Verkaufen +", hud.selected.sell]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-stretch gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid min-w-0 flex-1 grid-cols-4 gap-2",
							children: TOWER_ORDER.map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TowerButton, {
								kind,
								armed: hud.armed === kind,
								gold: hud.gold,
								disabled: !playing,
								onArm: () => game()?.arm(kind)
							}, kind))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "h-auto min-h-16 min-w-36 flex-1 rounded-lg bg-slime px-3 font-display text-base text-ink disabled:opacity-40 sm:flex-none sm:px-5",
							disabled: !hud.canStart,
							onClick: () => game()?.startWave(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block",
								children: hud.canStart ? `Welle ${hud.wave + 1} starten` : hud.phase === "playing" ? "Welle läuft" : "Bereit machen"
							}), hud.preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-sans font-semibold",
								children: hud.preview
							})]
						})]
					})
				]
			})
		]
	});
}
function TowerButton({ kind, armed, gold, disabled, onArm }) {
	const def = TOWERS[kind];
	const poor = gold < def.cost;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		"aria-pressed": armed,
		"aria-label": `${def.name}, ${def.cost} Gold. ${def.blurb}`,
		onClick: onArm,
		className: armed ? "flex min-h-16 flex-col items-center justify-center gap-0.5 rounded-lg border border-slime bg-surface-2 px-1 py-1.5 text-fg" : "flex min-h-16 flex-col items-center justify-center gap-0.5 rounded-lg border border-line bg-surface px-1 py-1.5 text-fg disabled:opacity-40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: `/game/tower-${kind}.png`,
				alt: "",
				className: "size-9 object-contain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-xs leading-none sm:text-sm",
				children: def.short
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: poor ? "text-xs text-danger" : "text-xs text-gold",
				children: def.cost
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameScreen, {});
}
//#endregion
export { Home as component };
