import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as weekdayIndex, S as formatShort, _ as cn, a as MUHURAT_ICONS, j as useApp, m as WEEK_SHORT, x as formatRange } from "./chrome-Cw-sgEN-.mjs";
import { r as getDay } from "./engine-BiRH4iq7.mjs";
import { r as muhuratFor, t as MUHURAT_COPY } from "./muhurat-DpOt-4dp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/muhurat-CoXsIaqr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ORDER = [
	"marriage",
	"griha",
	"vehicle",
	"property",
	"beginnings"
];
function MuhuratPage() {
	const cityId = useApp((state) => state.cityId);
	const [kind, setKind] = (0, import_react.useState)("marriage");
	const hits = (0, import_react.useMemo)(() => muhuratFor(kind, cityId), [kind, cityId]);
	const copy = MUHURAT_COPY[kind];
	const groups = /* @__PURE__ */ new Map();
	for (const hit of hits) {
		const key = hit.iso.slice(0, 7);
		const list = groups.get(key) ?? [];
		list.push(hit);
		groups.set(key, list);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "2027"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "Muhurat"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: copy.summary
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative -mx-4 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/art/mandap.jpg",
					alt: "",
					className: "h-36 w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: ORDER.map((id) => {
					const Icon = MUHURAT_ICONS[id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setKind(id),
						className: cn("inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm", id === kind ? "border-gold bg-gold text-bg" : "border-line text-cream"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 15,
							"aria-hidden": "true"
						}), MUHURAT_COPY[id].title]
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [hits.length, " dates · Abhijit is the midday window on each"]
			}),
			[...groups.entries()].map(([key, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl text-gold",
					children: monthTitle(key)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: list.map((hit) => {
					const day = getDay(hit.iso, cityId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/day/$date",
							params: { date: hit.iso },
							className: "flex flex-col gap-1 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-cream",
										children: [
											formatShort(hit.iso),
											" · ",
											WEEK_SHORT[weekdayIndex(hit.iso)]
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-gold",
										children: hit.grade
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										day.paksha,
										" ",
										day.tithiName,
										" · ",
										day.nakshatraName
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm tabular-nums text-auspicious",
									children: ["Abhijit ", formatRange(day.timings.abhijit.start, day.timings.abhijit.end)]
								})
							]
						})
					}, hit.iso + hit.grade);
				}) })]
			}, key)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: "These are traditional filters, not a personalised lagna. Rahu Kalam, Yamaganda and Gulika still apply on a chosen day. Ask your priest before fixing a wedding or a griha pravesh."
			})
		]
	});
}
function monthTitle(key) {
	const date = /* @__PURE__ */ new Date(`${key}-01T12:00:00+05:30`);
	return new Intl.DateTimeFormat("en-IN", {
		month: "long",
		timeZone: "Asia/Kolkata"
	}).format(date);
}
//#endregion
export { MuhuratPage as component };
