import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Sparkles, c as MapPin, f as ChevronLeft, g as Bell, h as CalendarDays, i as SunMedium, l as House, m as CarFront, o as Plus, p as Check, r as Trash2, s as Menu, t as X, u as Compass } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chrome-Cw-sgEN-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CITIES = [
	{
		id: "bengaluru",
		name: "Bengaluru",
		region: "Karnataka",
		lat: 12.9716,
		lon: 77.5946
	},
	{
		id: "mysuru",
		name: "Mysuru",
		region: "Karnataka",
		lat: 12.2958,
		lon: 76.6394
	},
	{
		id: "mumbai",
		name: "Mumbai",
		region: "Maharashtra",
		lat: 19.076,
		lon: 72.8777
	},
	{
		id: "pune",
		name: "Pune",
		region: "Maharashtra",
		lat: 18.5204,
		lon: 73.8567
	},
	{
		id: "delhi",
		name: "Delhi",
		region: "Delhi",
		lat: 28.6139,
		lon: 77.209
	},
	{
		id: "jaipur",
		name: "Jaipur",
		region: "Rajasthan",
		lat: 26.9124,
		lon: 75.7873
	},
	{
		id: "lucknow",
		name: "Lucknow",
		region: "Uttar Pradesh",
		lat: 26.8467,
		lon: 80.9462
	},
	{
		id: "varanasi",
		name: "Varanasi",
		region: "Uttar Pradesh",
		lat: 25.3176,
		lon: 82.9739
	},
	{
		id: "kolkata",
		name: "Kolkata",
		region: "West Bengal",
		lat: 22.5726,
		lon: 88.3639
	},
	{
		id: "hyderabad",
		name: "Hyderabad",
		region: "Telangana",
		lat: 17.385,
		lon: 78.4867
	},
	{
		id: "chennai",
		name: "Chennai",
		region: "Tamil Nadu",
		lat: 13.0827,
		lon: 80.2707
	},
	{
		id: "kochi",
		name: "Kochi",
		region: "Kerala",
		lat: 9.9312,
		lon: 76.2673
	},
	{
		id: "ahmedabad",
		name: "Ahmedabad",
		region: "Gujarat",
		lat: 23.0225,
		lon: 72.5714
	}
];
function getCity(id) {
	return CITIES.find((city) => city.id === id) ?? CITIES[0];
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function entry(date, name, kind, note) {
	return {
		date,
		name,
		kind,
		note
	};
}
var FESTIVALS = [
	entry("2027-01-03", "Saphala Ekadashi", "vrat", "Pausha Krishna Ekadashi. A fast kept for Vishnu."),
	entry("2027-01-13", "Lohri", "observance", "Bonfire eve observed in Punjab, the day before Bhogi."),
	entry("2027-01-14", "Bhogi", "observance", "First day of the Pongal cluster. The old is set aside."),
	entry("2027-01-15", "Makara Sankranti", "major", "Uttarayana. Sun’s entry into Makara is observed today across India, with Thai Pongal."),
	entry("2027-01-16", "Mattu Pongal", "observance", "Cattle are honoured on the third Pongal day."),
	entry("2027-01-17", "Kanum Pongal", "observance", "Closing day of Pongal, kept for outings and family."),
	entry("2027-01-18", "Pausha Putrada Ekadashi", "vrat", "Shukla Ekadashi of Pausha."),
	entry("2027-01-22", "Pausha Purnima", "vrat", "Full moon of Pausha."),
	entry("2027-01-25", "Sakat Chauth", "vrat", "Sankashti Chaturthi. Chandra darshan after moonrise ends the fast."),
	entry("2027-02-02", "Shattila Ekadashi", "vrat", "Magha Krishna Ekadashi. Til is offered."),
	entry("2027-02-06", "Mauni Amavasya", "major", "Magha Amavasya. Silence, a holy dip, and charity are traditional."),
	entry("2027-02-06", "Surya Grahan", "eclipse", "A solar eclipse falls on this Amavasya. Sutak and local visibility differ by city."),
	entry("2027-02-11", "Vasant Panchami", "major", "Magha Shukla Panchami. Saraswati is worshipped; spring is welcomed."),
	entry("2027-02-13", "Ratha Saptami", "vrat", "Surya’s ratha. A sunrise bath is traditional."),
	entry("2027-02-13", "Kumbha Sankranti", "sankranti", "Sun enters Kumbha."),
	entry("2027-02-14", "Bhishma Ashtami", "observance", "Magha Shukla Ashtami, in memory of Bhishma."),
	entry("2027-02-17", "Jaya Ekadashi", "vrat", "Magha Shukla Ekadashi."),
	entry("2027-02-20", "Magha Purnima", "vrat", "Full moon of Magha. Bathing at a sacred river is traditional."),
	entry("2027-02-21", "Chandra Grahan", "eclipse", "A lunar eclipse follows Magha Purnima. Follow your local panchang for sutak."),
	entry("2027-03-04", "Vijaya Ekadashi", "vrat", "Phalguna Krishna Ekadashi."),
	entry("2027-03-06", "Maha Shivaratri", "major", "Phalguna Krishna Chaturdashi. The night vigil is for Shiva."),
	entry("2027-03-08", "Somvati Amavasya", "vrat", "Amavasya on a Monday. Pitru tarpana is traditional."),
	entry("2027-03-15", "Meena Sankranti", "sankranti", "Sun enters Meena."),
	entry("2027-03-18", "Amalaki Ekadashi", "vrat", "Phalguna Shukla Ekadashi. The amla tree is honoured."),
	entry("2027-03-21", "Holika Dahan", "major", "Phalguna Purnima evening. The bonfire is lit at the proper prahda muhurat."),
	entry("2027-03-22", "Holi", "major", "Rangwali Holi, the day after Holika Dahan."),
	entry("2027-03-30", "Sheetala Ashtami", "observance", "Basoda. Stale food is offered and the hearth is left to rest."),
	entry("2027-04-02", "Papamochani Ekadashi", "vrat", "Chaitra Krishna Ekadashi."),
	entry("2027-04-07", "Ugadi", "major", "Chaitra Shukla Pratipada. New year in Karnataka, Andhra, Telangana and Maharashtra (Gudi Padwa)."),
	entry("2027-04-07", "Chaitra Navratri", "major", "Nine nights begin. Day 1 is dedicated to Shailputri."),
	entry("2027-04-08", "Navratri · Brahmacharini", "observance", "Chaitra Navratri, day 2."),
	entry("2027-04-09", "Gangaur", "observance", "Gauri puja, widely kept in Rajasthan. Chaitra Navratri, day 3."),
	entry("2027-04-12", "Yamuna Chhath", "observance", "Chaitra Shukla Shashthi."),
	entry("2027-04-14", "Mesha Sankranti", "sankranti", "Solar new year: Puthandu, Vishu and Vaisakhi are observed with this transit."),
	entry("2027-04-15", "Rama Navami", "major", "Chaitra Shukla Navami. Also Bohag Bihu and Pohela Boishakh in the east."),
	entry("2027-04-17", "Kamada Ekadashi", "vrat", "Chaitra Shukla Ekadashi."),
	entry("2027-04-20", "Hanuman Jayanti", "major", "Observed on Chaitra Purnima."),
	entry("2027-05-02", "Varuthini Ekadashi", "vrat", "Vaishakha Krishna Ekadashi."),
	entry("2027-05-08", "Parashurama Jayanti", "observance", "Akshaya Tritiya is observed the following day in 2027."),
	entry("2027-05-09", "Akshaya Tritiya", "major", "Vaishakha Shukla Tritiya. A classic day for beginnings, gold and purchases."),
	entry("2027-05-14", "Sita Navami", "observance", "Vaishakha Shukla Navami."),
	entry("2027-05-15", "Vrishabha Sankranti", "sankranti", "Sun enters Vrishabha."),
	entry("2027-05-16", "Mohini Ekadashi", "vrat", "Vaishakha Shukla Ekadashi."),
	entry("2027-05-18", "Narasimha Jayanti", "observance", "Vaishakha Shukla Chaturdashi."),
	entry("2027-05-20", "Buddha Purnima", "major", "Vaishakha Purnima."),
	entry("2027-06-01", "Apara Ekadashi", "vrat", "Jyeshtha Krishna Ekadashi."),
	entry("2027-06-04", "Vat Savitri", "vrat", "Observed on Jyeshtha Amavasya, with Shani Jayanti."),
	entry("2027-06-13", "Ganga Dussehra", "observance", "Jyeshtha Shukla Dashami."),
	entry("2027-06-14", "Nirjala Ekadashi", "major", "The waterless fast. It is said to stand for all ekadashis."),
	entry("2027-06-15", "Mithuna Sankranti", "sankranti", "Sun enters Mithuna."),
	entry("2027-06-18", "Vat Purnima", "vrat", "Jyeshtha Purnima. The banyan vrat is kept in Maharashtra."),
	entry("2027-06-30", "Yogini Ekadashi", "vrat", "Ashadha Krishna Ekadashi."),
	entry("2027-07-05", "Rath Yatra", "major", "Jagannath’s chariot festival at Puri, Ashadha Shukla Dwitiya."),
	entry("2027-07-14", "Devshayani Ekadashi", "major", "Ashadha Shukla Ekadashi. Chaturmas begins; Vishnu is said to rest."),
	entry("2027-07-17", "Karka Sankranti", "sankranti", "Dakshinayana. Sun enters Karka."),
	entry("2027-07-18", "Guru Purnima", "major", "Ashadha Purnima, kept for the guru."),
	entry("2027-08-06", "Nag Panchami", "observance", "Shravana Shukla Panchami."),
	entry("2027-08-13", "Varalakshmi Vrat", "vrat", "Friday vrat for Lakshmi, ahead of Shravana Purnima."),
	entry("2027-08-17", "Raksha Bandhan", "major", "Shravana Purnima. The thread is tied at the appointed muhurat."),
	entry("2027-08-25", "Krishna Janmashtami", "major", "Bhadrapada Krishna Ashtami in the Purnimanta reckoning. The midnight vigil is traditional."),
	entry("2027-09-03", "Hartalika Teej", "vrat", "Bhadrapada Shukla Tritiya, kept the day before Ganesh Chaturthi."),
	entry("2027-09-04", "Ganesh Chaturthi", "major", "Bhadrapada Shukla Chaturthi. Ganesha is welcomed home."),
	entry("2027-09-08", "Radha Ashtami", "observance", "Bhadrapada Shukla Ashtami."),
	entry("2027-09-11", "Parsva Ekadashi", "vrat", "Parivartini Ekadashi of Bhadrapada Shukla."),
	entry("2027-09-12", "Onam", "major", "Thiruvonam. Sun in Simha with Shravana nakshatra."),
	entry("2027-09-14", "Anant Chaturdashi", "major", "Ganesh visarjan and Anant vrat."),
	entry("2027-09-16", "Pitru Paksha begins", "observance", "The fortnight of shraddha opens after Bhadrapada Purnima."),
	entry("2027-09-26", "Indira Ekadashi", "vrat", "Krishna Ekadashi during Pitru Paksha."),
	entry("2027-09-29", "Mahalaya Amavasya", "major", "Sarva Pitru Amavasya. The last day of shraddha."),
	entry("2027-09-30", "Sharad Navratri", "major", "Ashwin Shukla Pratipada. Day 1, Shailputri. Nine nights begin."),
	entry("2027-10-01", "Navratri · Brahmacharini", "observance", "Sharad Navratri, day 2."),
	entry("2027-10-02", "Navratri · Chandraghanta", "observance", "Sharad Navratri, day 3."),
	entry("2027-10-03", "Navratri · Kushmanda", "observance", "Sharad Navratri, day 4."),
	entry("2027-10-04", "Navratri · Skandamata", "observance", "Sharad Navratri, day 5."),
	entry("2027-10-05", "Navratri · Katyayani", "observance", "Sharad Navratri, day 6."),
	entry("2027-10-06", "Navratri · Kalaratri", "observance", "Sharad Navratri, day 7."),
	entry("2027-10-07", "Durga Ashtami", "major", "Mahagauri. Sharad Navratri, day 8. Kanya puja is traditional."),
	entry("2027-10-08", "Maha Navami", "major", "Siddhidatri and Durga Puja. Sharad Navratri, day 9."),
	entry("2027-10-09", "Dussehra", "major", "Vijayadashami. Rama’s victory, and the close of Navratri."),
	entry("2027-10-14", "Sharad Purnima", "major", "Ashwin Purnima. Kojagari, when moonlight is offered to Lakshmi."),
	entry("2027-10-18", "Karwa Chauth", "major", "Kartika Krishna Chaturthi in the Purnimanta count. The fast breaks at moonrise."),
	entry("2027-10-27", "Dhanteras", "major", "Dhantrayodashi. A traditional day to buy metal, tools and vehicles."),
	entry("2027-10-28", "Naraka Chaturdashi", "major", "Chhoti Diwali. An early oil bath is traditional."),
	entry("2027-10-29", "Diwali", "major", "Lakshmi puja on Kartika Krishna Amavasya (Purnimanta). The new moon night."),
	entry("2027-10-30", "Govardhan Puja", "major", "Annakut, and Bestu Varas — the Gujarati new year."),
	entry("2027-10-31", "Bhai Dooj", "major", "Yama Dwitiya. Brothers are received at home."),
	entry("2027-11-04", "Chhath Puja", "major", "Surya Shashthi. The sandhya arghya is offered at dusk."),
	entry("2027-11-11", "Tulsi Vivah", "observance", "Kartika Shukla Dwadashi. The wedding of Tulsi and Shaligram."),
	entry("2027-11-14", "Kartika Purnima", "major", "Dev Diwali. Lamps are lit again, especially in Kashi."),
	entry("2027-12-09", "Gita Jayanti", "major", "Mokshada Ekadashi. The Bhagavad Gita’s day."),
	entry("2027-12-16", "Dhanu Sankranti", "sankranti", "Sun enters Dhanu.")
];
function artFor(name) {
	const text = name.toLowerCase();
	if (/diwali|dhanteras|navratri|durga|dussehra|lakshmi|karwa|chhath/.test(text)) return "/art/diyas.jpg";
	if (/vivah|wedding|griha|mandap|akshaya|hanuman|rama/.test(text)) return "/art/mandap.jpg";
	if (/ganesh|onam|pongal|sankranti|holi|janmashtami|shivaratri|ugadi|raksha/.test(text)) return "/art/lotus.jpg";
	return "/art/temple.jpg";
}
var KIND_RANK = {
	major: 0,
	eclipse: 1,
	sankranti: 2,
	vrat: 3,
	observance: 4
};
function byImportance(events) {
	return [...events].sort((a, b) => KIND_RANK[a.kind] - KIND_RANK[b.kind] || a.name.localeCompare(b.name));
}
function upcomingMajors(fromIso, count) {
	const seen = /* @__PURE__ */ new Set();
	const list = [];
	for (const festival of FESTIVALS) {
		if (festival.date < fromIso || festival.kind !== "major") continue;
		if (seen.has(festival.date + festival.name)) continue;
		seen.add(festival.date + festival.name);
		list.push(festival);
		if (list.length >= count) break;
	}
	return list;
}
var useApp = create()(persist((set) => ({
	cityId: "bengaluru",
	monthSystem: "amanta",
	tasks: [],
	setCity: (cityId) => set({ cityId }),
	setMonthSystem: (monthSystem) => set({ monthSystem }),
	addTask: (task) => set((state) => ({ tasks: [{
		...task,
		id: crypto.randomUUID(),
		done: false,
		notified: false
	}, ...state.tasks] })),
	toggleTask: (id) => set((state) => ({ tasks: state.tasks.map((task) => task.id === id ? {
		...task,
		done: !task.done
	} : task) })),
	removeTask: (id) => set((state) => ({ tasks: state.tasks.filter((task) => task.id !== id) })),
	markNotified: (id) => set((state) => ({ tasks: state.tasks.map((task) => task.id === id ? {
		...task,
		notified: true
	} : task) }))
}), { name: "suman-2027" }));
var IST = "Asia/Kolkata";
function istISO(date = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: IST,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(date);
}
function istMidnight(iso) {
	return /* @__PURE__ */ new Date(`${iso}T00:00:00+05:30`);
}
function addDays(iso, days) {
	return istISO(new Date(istMidnight(iso).getTime() + days * 864e5));
}
function weekdayIndex(iso) {
	return (/* @__PURE__ */ new Date(`${iso}T12:00:00+05:30`)).getUTCDay();
}
function istHour(date) {
	const hour = new Intl.DateTimeFormat("en-GB", {
		timeZone: IST,
		hour: "2-digit",
		hourCycle: "h23"
	}).format(date);
	return Number(hour);
}
function formatTime(date) {
	return new Intl.DateTimeFormat("en-US", {
		timeZone: IST,
		hour: "numeric",
		minute: "2-digit",
		hour12: true
	}).format(date).replace("AM", "AM").replace("am", "AM").replace("pm", "PM");
}
function formatRange(start, end) {
	return `${formatTime(start)} – ${formatTime(end)}`;
}
function formatUntil(end, anchor) {
	const time = formatTime(end);
	if (istISO(end) === istISO(anchor)) return `until ${time}`;
	return `until ${new Intl.DateTimeFormat("en-IN", {
		timeZone: IST,
		weekday: "short"
	}).format(end)}, ${time}`;
}
function formatLong(iso) {
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: IST,
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(istMidnight(iso));
}
function formatMonthYear(iso) {
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: IST,
		month: "long",
		year: "numeric"
	}).format(istMidnight(iso)).toUpperCase();
}
function formatShort(iso) {
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: IST,
		day: "numeric",
		month: "short"
	}).format(istMidnight(iso));
}
function daysBetween(fromIso, toIso) {
	return Math.round((istMidnight(toIso).getTime() - istMidnight(fromIso).getTime()) / 864e5);
}
function monthLength(year, month) {
	return new Date(Date.UTC(year, month, 0)).getUTCDate();
}
function pad2(value) {
	return String(value).padStart(2, "0");
}
var WEEKDAYS = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
var WEEK_SHORT = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
var VARA = [
	"Ravivara",
	"Somavara",
	"Mangalavara",
	"Budhavara",
	"Guruvara",
	"Shukravara",
	"Shanivara"
];
function greeting(date) {
	const hour = istHour(date);
	if (hour < 4) return "Good night";
	if (hour < 12) return "Good morning";
	if (hour < 17) return "Good afternoon";
	if (hour < 21) return "Good evening";
	return "Good night";
}
function samvatFor(iso) {
	const afterNewYear = iso >= "2027-04-07";
	return {
		vikram: afterNewYear ? 2084 : 2083,
		shaka: afterNewYear ? 1949 : 1948
	};
}
var NAV = [
	{
		to: "/",
		label: "Today",
		icon: SunMedium,
		test: (path) => path === "/"
	},
	{
		to: "/calendar",
		label: "Calendar",
		icon: CalendarDays,
		test: (path) => path.startsWith("/calendar") || path.startsWith("/day")
	},
	{
		to: "/muhurat",
		label: "Muhurat",
		icon: Sparkles,
		test: (path) => path.startsWith("/muhurat")
	},
	{
		to: "/tasks",
		label: "Tasks",
		icon: Check,
		test: (path) => path.startsWith("/tasks")
	},
	{
		to: "/more",
		label: "More",
		icon: Menu,
		test: (path) => path.startsWith("/more") || path.startsWith("/festivals")
	}
];
function Shell({ children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const tasks = useApp((state) => state.tasks);
	const markNotified = useApp((state) => state.markNotified);
	(0, import_react.useEffect)(() => {
		if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
		const now = Date.now();
		for (const task of tasks) {
			if (!task.remind || task.done || task.notified || !task.date) continue;
			const when = (/* @__PURE__ */ new Date(`${task.date}T${task.time || "09:00"}:00+05:30`)).getTime();
			if (Number.isNaN(when)) continue;
			if (when <= now && now - when < 648e5) {
				new Notification("SUMAN", { body: task.title });
				markNotified(task.id);
			}
		}
	}, [tasks, markNotified]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "phone-col bg-bg text-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "grid shrink-0 grid-cols-5 border-t border-line bg-bg/95 pb-2 backdrop-blur",
			"aria-label": "Primary",
			children: NAV.map((item) => {
				const on = item.test(path);
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: cn("flex min-h-14 flex-col items-center justify-center gap-1 micro", on ? "text-gold" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						size: 18,
						strokeWidth: 1.75,
						"aria-hidden": "true"
					}), item.label]
				}, item.to);
			})
		})]
	});
}
function CityButton() {
	const cityId = useApp((state) => state.cityId);
	const setCity = useApp((state) => state.setCity);
	const [open, setOpen] = (0, import_react.useState)(false);
	const city = getCity(cityId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(true),
		className: "inline-flex items-center gap-1 text-sm text-gold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
			size: 14,
			"aria-hidden": "true"
		}), city.name]
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/70",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Choose a city",
			className: "sheet w-full max-w-md overflow-y-auto rounded-t-3xl border border-line bg-surface p-4",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl",
					children: "City"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close",
					onClick: () => setOpen(false),
					className: "grid size-10 place-items-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col",
				children: CITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center justify-between border-t border-line py-3 text-left",
					onClick: () => {
						setCity(item.id);
						setOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-cream",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: item.region
					})] }), item.id === cityId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						size: 16,
						className: "text-gold"
					}) : null]
				}) }, item.id))
			})]
		})
	}) : null] });
}
function within(now, window) {
	return now >= window.start && now <= window.end;
}
function PanchangGrid({ live, anchor }) {
	const cells = [
		[
			"Tithi",
			live.tithiName,
			formatUntil(live.tithiEnd, anchor)
		],
		[
			"Nakshatra",
			live.nakshatraName,
			`Pada ${live.pada} · ${formatUntil(live.nakshatraEnd, anchor)}`
		],
		[
			"Yoga",
			live.yogaName,
			formatUntil(live.yogaEnd, anchor)
		],
		[
			"Karana",
			live.karanaName,
			formatUntil(live.karanaEnd, anchor)
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line",
		children: cells.map(([label, value, until]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-surface px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-serif text-2xl leading-none text-cream",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: until
				})
			]
		}, label))
	});
}
function TimingList({ day, now }) {
	const rows = [
		[
			"Rahu Kalam",
			day.timings.rahu,
			false
		],
		[
			"Yamaganda",
			day.timings.yamaganda,
			false
		],
		[
			"Gulika Kalam",
			day.timings.gulika,
			false
		],
		[
			"Abhijit Muhurat",
			day.timings.abhijit,
			true
		],
		[
			"Brahma Muhurta",
			day.timings.brahma,
			true
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "overflow-hidden rounded-2xl border border-line",
		children: rows.map(([label, window, good]) => {
			const active = now ? within(now, window) : false;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3 last:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("text-sm", good ? "text-auspicious" : "text-inauspicious"),
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tabular-nums text-cream",
					children: formatRange(window.start, window.end)
				})] }), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "eyebrow",
					children: "Now"
				}) : null]
			}, label);
		})
	});
}
function EventCard({ event, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/day/$date",
		params: { date: event.date },
		className: "block overflow-hidden rounded-2xl border border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative", compact ? "h-24" : "h-36"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: artFor(event.name),
					alt: "",
					className: "h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg via-bg/75 to-bg/10" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-0 flex flex-col justify-end p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: formatShort(event.date)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("font-serif leading-tight text-cream", compact ? "text-xl" : "text-3xl"),
						children: event.name
					})]
				})
			]
		}), event.note && !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-3 text-sm leading-relaxed text-muted",
			children: event.note
		}) : null]
	});
}
function SunMoon({ day }) {
	const items = [
		["Sunrise", day.sunrise],
		["Sunset", day.sunset],
		["Moonrise", day.moonrise],
		["Moonset", day.moonset]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-4 gap-2",
		children: items.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "micro text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm tabular-nums text-cream",
				children: value ? formatTime(value) : "—"
			})]
		}, label))
	});
}
function BackButton({ fallback = "/calendar" }) {
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "inline-flex items-center gap-1 text-sm text-gold",
		onClick: () => {
			if (window.history.length > 1) router.history.back();
			else router.navigate({ to: fallback });
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
			size: 16,
			"aria-hidden": "true"
		}), "Back"]
	});
}
function TaskDialog({ open, onClose, initial }) {
	const addTask = useApp((state) => state.addTask);
	const [title, setTitle] = (0, import_react.useState)(initial?.title ?? "");
	const [date, setDate] = (0, import_react.useState)(initial?.date ?? "2027-01-15");
	const [time, setTime] = (0, import_react.useState)("09:00");
	const [notes, setNotes] = (0, import_react.useState)(initial?.notes ?? "");
	const [remind, setRemind] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setTitle(initial?.title ?? "");
		setDate(initial?.date ?? "2027-01-15");
		setNotes(initial?.notes ?? "");
		setTime("09:00");
		setRemind(true);
	}, [
		open,
		initial?.title,
		initial?.date,
		initial?.notes
	]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "task-dialog-title",
			className: "w-full max-w-md rounded-t-3xl border border-line bg-surface p-5 sm:rounded-3xl",
			onClick: (event) => event.stopPropagation(),
			onSubmit: (event) => {
				event.preventDefault();
				const trimmed = title.trim();
				if (!trimmed) return;
				addTask({
					title: trimmed,
					notes: notes.trim(),
					date,
					time,
					remind
				});
				if (remind && typeof Notification !== "undefined" && Notification.permission === "default") Notification.requestPermission();
				toast("Reminder saved", { className: "suman-toast" });
				onClose();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "task-dialog-title",
					className: "font-serif text-3xl",
					children: "New reminder"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close",
					onClick: onClose,
					className: "grid size-10 place-items-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Title", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: title,
							onChange: (event) => setTitle(event.target.value),
							required: true,
							maxLength: 80
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-muted",
							children: ["Date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "date",
								value: date,
								min: "2026-01-01",
								max: "2027-12-31",
								onChange: (event) => setDate(event.target.value),
								required: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-muted",
							children: ["Time", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "time",
								value: time,
								onChange: (event) => setTime(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field mt-1",
							rows: 3,
							value: notes,
							maxLength: 280,
							onChange: (event) => setNotes(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm text-cream",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: remind,
							onChange: (event) => setRemind(event.target.checked)
						}), "Remind me"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "submit",
						className: "mt-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-gold text-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							size: 16,
							"aria-hidden": "true"
						}), "Save"]
					})
				]
			})]
		})
	});
}
function TaskRow({ task }) {
	const toggleTask = useApp((state) => state.toggleTask);
	const removeTask = useApp((state) => state.removeTask);
	const [armed, setArmed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start gap-3 border-b border-line py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": task.done ? "Mark not done" : "Mark done",
				onClick: () => toggleTask(task.id),
				className: cn("mt-0.5 grid size-6 shrink-0 place-items-center rounded-full border", task.done ? "border-gold bg-gold text-bg" : "border-gold-dim text-transparent"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 14 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-cream", task.done && "text-muted line-through"),
						children: task.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatShort(task.date),
							task.time ? ` · ${task.time}` : "",
							task.remind ? " · reminder" : ""
						]
					}),
					task.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: task.notes
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-sm text-muted",
				onClick: () => {
					if (!armed) {
						setArmed(true);
						return;
					}
					removeTask(task.id);
				},
				children: armed ? "Remove" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
					size: 16,
					"aria-label": "Delete reminder"
				})
			})
		]
	});
}
var MUHURAT_ICONS = {
	marriage: Sparkles,
	griha: House,
	vehicle: CarFront,
	property: Compass,
	beginnings: Bell
};
//#endregion
export { upcomingMajors as A, formatTime as C, monthLength as D, istISO as E, weekdayIndex as M, pad2 as O, formatShort as S, greeting as T, cn as _, MUHURAT_ICONS as a, formatMonthYear as b, SunMoon as c, TimingList as d, VARA as f, byImportance as g, addDays as h, FESTIVALS as i, useApp as j, samvatFor as k, TaskDialog as l, WEEK_SHORT as m, CityButton as n, PanchangGrid as o, WEEKDAYS as p, EventCard as r, Shell as s, BackButton as t, TaskRow as u, daysBetween as v, getCity as w, formatRange as x, formatLong as y };
