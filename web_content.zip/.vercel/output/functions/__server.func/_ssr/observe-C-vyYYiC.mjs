import { g as byImportance, i as FESTIVALS } from "./chrome-Cw-sgEN-.mjs";
import { n as ekadashiName } from "./engine-BiRH4iq7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/observe-C-vyYYiC.js
function shadowed(name, curated) {
	const lower = name.toLowerCase();
	const stem = [
		"ekadashi",
		"purnima",
		"amavasya",
		"pradosh",
		"sankashti",
		"shivaratri",
		"sankranti",
		"chaturthi",
		"chauth"
	].find((item) => lower.includes(item));
	if (!stem) return false;
	return curated.some((festival) => {
		const text = festival.name.toLowerCase();
		if (stem === "sankashti" || stem === "chaturthi" || stem === "chauth") return /sankashti|chaturthi|chauth|sakat/.test(text);
		return text.includes(stem);
	});
}
function eventsOn(iso, day) {
	const curated = FESTIVALS.filter((festival) => festival.date === iso);
	const extra = [];
	if (day) {
		if (day.tithiNumber === 11) extra.push({
			date: iso,
			name: ekadashiName(day.purnimantaIndex, day.paksha),
			kind: "vrat",
			note: `${day.purnimantaName} ${day.paksha} Ekadashi at sunrise.`
		});
		else if (day.paksha === "Shukla" && day.tithiNumber === 15) extra.push({
			date: iso,
			name: `${day.amantaName} Purnima`,
			kind: "vrat",
			note: "Full moon at sunrise."
		});
		else if (day.paksha === "Krishna" && day.tithiNumber === 15) extra.push({
			date: iso,
			name: `${day.amantaName} Amavasya`,
			kind: "vrat",
			note: "New moon at sunrise."
		});
		if (day.tithiNumber === 13) extra.push({
			date: iso,
			name: "Pradosh Vrat",
			kind: "vrat",
			note: `${day.paksha} Trayodashi. The pradosh kaal is just after sunset.`
		});
		if (day.paksha === "Krishna" && day.tithiNumber === 4) extra.push({
			date: iso,
			name: "Sankashti Chaturthi",
			kind: "vrat",
			note: "The fast is completed after moonrise."
		});
		if (day.paksha === "Krishna" && day.tithiNumber === 14) extra.push({
			date: iso,
			name: "Masik Shivaratri",
			kind: "vrat",
			note: "Monthly Shivaratri on Krishna Chaturdashi."
		});
		if (day.sankranti) extra.push({
			date: iso,
			name: day.sankranti.name,
			kind: "sankranti",
			note: "Astronomical transit of the Sun. The public observance is sometimes the next morning."
		});
	}
	const merged = [...curated, ...extra.filter((item) => !shadowed(item.name, curated))];
	return byImportance(merged);
}
function dotFor(events) {
	if (events.some((event) => event.kind === "major" || event.kind === "eclipse")) return "major";
	if (events.length > 0) return "mark";
	return null;
}
//#endregion
export { eventsOn as n, dotFor as t };
