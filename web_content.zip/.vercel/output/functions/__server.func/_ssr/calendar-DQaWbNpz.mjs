import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ChevronRight, f as ChevronLeft } from "../_libs/lucide-react.mjs";
import { D as monthLength, E as istISO, M as weekdayIndex, O as pad2, S as formatShort, _ as cn, h as addDays, j as useApp, m as WEEK_SHORT, n as CityButton } from "./chrome-Cw-sgEN-.mjs";
import { r as getDay } from "./engine-BiRH4iq7.mjs";
import { n as eventsOn, t as dotFor } from "./observe-C-vyYYiC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendar-DQaWbNpz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function CalendarPage() {
	const cityId = useApp((state) => state.cityId);
	const today = istISO();
	const startMonth = today.startsWith("2027") ? Number(today.slice(5, 7)) : 1;
	const [month, setMonth] = (0, import_react.useState)(startMonth);
	const isoMonth = `2027-${pad2(month)}`;
	const length = monthLength(2027, month);
	const first = `${isoMonth}-01`;
	const lead = weekdayIndex(first);
	const cells = (0, import_react.useMemo)(() => {
		const days = Array.from({ length: lead }, () => null);
		for (let day = 1; day <= length; day += 1) days.push(`${isoMonth}-${pad2(day)}`);
		while (days.length % 7 !== 0) days.push(null);
		return days;
	}, [
		isoMonth,
		lead,
		length
	]);
	const marked = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		let cursor = first;
		for (let i = 0; i < length; i += 1) {
			map.set(cursor, eventsOn(cursor, getDay(cursor, cityId)));
			cursor = addDays(cursor, 1);
		}
		return map;
	}, [
		cityId,
		first,
		length
	]);
	const list = [...marked.entries()].flatMap(([, events]) => events).filter((event) => event.kind === "major" || event.kind === "vrat" || event.kind === "eclipse");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "2027"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: MONTHS[month - 1]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CityButton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Previous month",
						disabled: month === 1,
						onClick: () => setMonth((value) => value - 1),
						className: "grid size-11 place-items-center rounded-full border border-line text-gold disabled:opacity-30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "January – December"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Next month",
						disabled: month === 12,
						onClick: () => setMonth((value) => value + 1),
						className: "grid size-11 place-items-center rounded-full border border-line text-gold disabled:opacity-30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 18 })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-7 gap-y-1 text-center",
				children: [WEEK_SHORT.map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "micro pb-2 text-muted",
					children: label
				}, label)), cells.map((iso, index) => {
					if (!iso) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, `empty-${index}`);
					const events = marked.get(iso) ?? [];
					const dot = dotFor(events);
					const isToday = iso === today;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/day/$date",
						params: { date: iso },
						className: cn("relative mx-auto grid size-11 place-items-center rounded-full text-sm", isToday ? "bg-gold text-bg" : "text-cream"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: Number(iso.slice(8))
						}), dot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute bottom-1 size-1 rounded-full", dot === "major" ? isToday ? "bg-bg" : "bg-gold" : isToday ? "bg-bg/70" : "bg-muted") }) : null]
					}, iso);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl",
						children: "This month"
					}),
					list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No listed observances."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col",
						children: list.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/day/$date",
								params: { date: event.date },
								className: "flex items-baseline justify-between gap-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-cream",
									children: event.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-sm text-gold",
									children: formatShort(event.date)
								})]
							})
						}, event.date + event.name))
					})
				]
			})
		]
	});
}
//#endregion
export { CalendarPage as component };
