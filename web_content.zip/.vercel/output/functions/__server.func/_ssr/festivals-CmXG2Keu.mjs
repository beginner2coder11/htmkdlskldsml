import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as cn, i as FESTIVALS, r as EventCard, t as BackButton } from "./chrome-Cw-sgEN-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/festivals-CmXG2Keu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "major",
		label: "Major"
	},
	{
		id: "vrat",
		label: "Vrat"
	},
	{
		id: "sankranti",
		label: "Sankranti"
	}
];
function FestivalsPage() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const list = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return FESTIVALS.filter((festival) => {
			if (filter !== "all" && festival.kind !== filter) return false;
			if (!needle) return true;
			return festival.name.toLowerCase().includes(needle) || festival.note.toLowerCase().includes(needle);
		});
	}, [filter, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { fallback: "/more" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "January – December"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Festivals & vrat"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "Search Diwali, Ekadashi…",
				value: query,
				onChange: (event) => setQuery(event.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(item.id),
					className: cn("min-h-10 shrink-0 rounded-full border px-4 text-sm", filter === item.id ? "border-gold bg-gold text-bg" : "border-line text-cream"),
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [list.length, " observances"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: list.map((festival) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, {
					event: festival,
					compact: festival.kind !== "major"
				}, festival.date + festival.name))
			})
		]
	});
}
//#endregion
export { FestivalsPage as component };
