import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as istISO, j as useApp, l as TaskDialog, u as TaskRow } from "./chrome-Cw-sgEN-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-Bb7rPsci.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TasksPage() {
	const tasks = useApp((state) => state.tasks);
	const [open, setOpen] = (0, import_react.useState)(false);
	const today = istISO();
	const openTasks = tasks.filter((task) => !task.done).sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
	const done = tasks.filter((task) => task.done);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "On this device"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "Tasks"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full bg-gold px-4 text-sm text-bg",
					onClick: () => setOpen(true),
					children: "Add"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Notes and reminders stay in this browser. If you allow alerts, SUMAN can also notify while the app is open."
			}),
			openTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-3xl border border-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/art/lotus.jpg",
					alt: "",
					className: "h-40 w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-2xl",
						children: "Nothing waiting"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Save Makar Sankranti, a griha pravesh, or a private note."
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: openTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, { task }, task.id)) }),
			done.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl text-muted",
				children: "Done"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: done.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, { task }, task.id)) })] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskDialog, {
				open,
				onClose: () => setOpen(false),
				initial: { date: today.startsWith("2027") ? today : "2027-01-15" }
			})
		]
	});
}
//#endregion
export { TasksPage as component };
