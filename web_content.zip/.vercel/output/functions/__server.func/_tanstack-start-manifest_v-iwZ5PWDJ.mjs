//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-iwZ5PWDJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_app"],
		preloads: ["/assets/index-CZHEbKbz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CZHEbKbz.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app/route.tsx",
		children: [
			"/_app/calendar",
			"/_app/festivals",
			"/_app/more",
			"/_app/muhurat",
			"/_app/tasks",
			"/_app/",
			"/_app/day/$date"
		],
		preloads: ["/assets/route-lImkgVby.js", "/assets/chrome-GUJdRKJO.js"]
	},
	"/_app/calendar": {
		filePath: "/workspace/src/routes/_app/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-ltsLNwOs.js",
			"/assets/engine-JDwjcMHX.js",
			"/assets/observe-B3113r6d.js"
		]
	},
	"/_app/festivals": {
		filePath: "/workspace/src/routes/_app/festivals.tsx",
		children: void 0,
		preloads: ["/assets/festivals-D0St7WMW.js"]
	},
	"/_app/more": {
		filePath: "/workspace/src/routes/_app/more.tsx",
		children: void 0,
		preloads: ["/assets/more-BKZ74KCO.js"]
	},
	"/_app/muhurat": {
		filePath: "/workspace/src/routes/_app/muhurat.tsx",
		children: void 0,
		preloads: [
			"/assets/muhurat-D5NCaJEW.js",
			"/assets/engine-JDwjcMHX.js",
			"/assets/muhurat-Dklc5gbq.js"
		]
	},
	"/_app/tasks": {
		filePath: "/workspace/src/routes/_app/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-Cv2ngg1u.js"]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-BqiYYYbJ.js",
			"/assets/engine-JDwjcMHX.js",
			"/assets/observe-B3113r6d.js"
		]
	},
	"/_app/day/$date": {
		filePath: "/workspace/src/routes/_app/day.$date.tsx",
		children: void 0,
		preloads: [
			"/assets/day._date-C3mUO5s2.js",
			"/assets/engine-JDwjcMHX.js",
			"/assets/observe-B3113r6d.js",
			"/assets/muhurat-Dklc5gbq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
