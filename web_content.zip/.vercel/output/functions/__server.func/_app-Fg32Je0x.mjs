import { i as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { A as upcomingMajors, C as formatTime, E as istISO, T as greeting, b as formatMonthYear, c as SunMoon, d as TimingList, j as useApp, k as samvatFor, l as TaskDialog, n as CityButton, o as PanchangGrid, r as EventCard, u as TaskRow, w as getCity } from "./_ssr/chrome-Cw-sgEN-.mjs";
import { a as monthLabel, i as getLive, r as getDay } from "./_ssr/engine-BiRH4iq7.mjs";
import { n as eventsOn } from "./_ssr/observe-C-vyYYiC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-Fg32Je0x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TodayPage() {
	const cityId = useApp((state) => state.cityId);
	const system = useApp((state) => state.monthSystem);
	const tasks = useApp((state) => state.tasks);
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 6e4);
		return () => window.clearInterval(id);
	}, []);
	const today = istISO(now);
	const city = getCity(cityId);
	const day = (0, import_react.useMemo)(() => getDay(today, cityId), [today, cityId]);
	const live = (0, import_react.useMemo)(() => getLive(now), [now]);
	const events = eventsOn(today, day);
	const headline = events[0];
	const upcoming = upcomingMajors(today < "2027-01-01" ? "2027-01-01" : today, 3).filter((item) => item.date !== today);
	const mine = tasks.filter((task) => !task.done && task.date >= today).slice(0, 3);
	const samvat = samvatFor(today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "wordmark text-cream",
					children: "SUMAN"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mt-1",
					children: "Hindu calendar"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CityButton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-3xl border border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/temple.jpg",
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/80 to-bg/25" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex flex-col gap-4 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-cream",
									children: greeting(now)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										"VS ",
										samvat.vikram,
										" · Shaka ",
										samvat.shaka
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: day.weekdayName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "date-num text-cream",
									children: Number(today.slice(8))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "kicker mt-2 text-cream",
									children: formatMonthYear(today)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-serif text-2xl text-gold",
									children: [
										monthLabel(day, system),
										" · ",
										day.paksha,
										" Paksha"
									]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { day })
						]
					})
				]
			}),
			!today.startsWith("2027") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-2xl border border-line bg-inset px-4 py-3 text-sm leading-relaxed text-muted",
				children: [
					"Festivals and muhurat in SUMAN cover January–December 2027. Today’s panchang is live for ",
					city.name,
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-3xl",
							children: "Panchang"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/day/$date",
							params: { date: today },
							className: "text-sm text-gold",
							children: "Full day"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanchangGrid, {
						live,
						anchor: now
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"At sunrise: ",
							day.tithiName,
							", ",
							day.nakshatraName,
							". Then ",
							day.nextTithi,
							" from ",
							formatTime(day.tithiEnd),
							". Moon in ",
							day.moonRashi,
							" · ",
							day.moonRashiEn,
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: "Important timings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimingList, {
					day,
					now
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-3xl",
							children: headline ? "Today" : "Coming up"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/festivals",
							className: "text-sm text-gold",
							children: "All festivals"
						})]
					}),
					headline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, { event: headline }) : null,
					events.slice(1, 3).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, {
						event,
						compact: true
					}, event.name)),
					!headline ? upcoming.slice(0, 2).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, { event }, event.date + event.name)) : upcoming.slice(0, 1).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, {
						event,
						compact: true
					}, event.date + event.name))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl",
						children: "Reminders"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-gold",
						onClick: () => setOpen(true),
						children: "Add"
					})]
				}), mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nothing saved yet. Pin a festival or a personal date."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: mine.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, { task }, task.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskDialog, {
				open,
				onClose: () => setOpen(false),
				initial: { date: today.startsWith("2027") ? today : "2027-01-15" }
			})
		]
	});
}
//#endregion
export { TodayPage as component };
