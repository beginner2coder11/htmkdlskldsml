WMMS v3 PT BBHA — pengembangan dari WMMS_v2_PT_BBHA.html

CARA PAKAI
1. Buka index.html di browser Android/PC. Untuk APK, gunakan HTML-to-APK Builder seperti alur sebelumnya.
2. Tab Peta/Catat/Analisis/Data asli tetap dipertahankan.
3. Tab Hidrologi berisi:
   - pencatatan jaringan kanal berbasis koordinat berurutan,
   - pencatatan inlet/outlet/pintu air/bendung/stasiun ukur,
   - log aliran masuk dari distrik lain,
   - impor CSV titik elevasi DEM dan ringkasan statistik,
   - pemeriksaan awal temuan/kelengkapan data untuk risiko,
   - backup dan restore data hidrologi JSON.

FORMAT DEM CSV
x,y,elevation
101.75000,1.50000,3.25
101.75100,1.50100,2.90

x = longitude, y = latitude, elevation = elevasi meter.
GeoTIFF belum didukung langsung. Ekspor titik/grid DEM ke CSV terlebih dahulu.

BATASAN PENTING
- Analisis elevasi pada versi ini hanya statistik titik dan identifikasi kelompok elevasi rendah, bukan flow direction/flow accumulation raster.
- Prediksi genangan belum berupa model prediktif terkalibrasi; indikator risiko hanya merangkum keberadaan catatan dan kondisi yang perlu diperiksa.
- Belum ada sinkronisasi multi-perangkat/server.
- Koordinat kanal/titik dan arah aliran harus diverifikasi di lapangan.
- Ambang Normal/Waspada/Kritis tetap mengikuti SOP dan standar hidrologi perusahaan.
- Jangan menggunakan aplikasi ini sebagai instruksi otomatis buka/tutup pintu air.
- Data tersimpan lokal di browser. Lakukan backup berkala.


TAMBAHAN: KORIDOR (kanal/jalan kandidat)
- 230 garis lurus menerus (sekitar 713 km) diekstrak dari celah antar petak di PDF peta konsesi; garis yang bersambung lurus di persimpangan digabung jadi satu.
- Peta > tombol Koridor: tampilkan garis. Oranye = belum dicek; biru tua = kanal primer; biru muda = kanal sekunder; coklat = jalan; abu-abu tipis = diabaikan.
- Ketuk garis: tandai Primer, Sekunder, Jalan, Abaikan, atau Reset.
- Analisis > Koridor: rekap panjang, penandaan massal per arah (horizontal/vertikal/miring) atau lebar celah, ekspor GeoJSON kanal.
- Ketuk petak: panjang kanal yang sudah ditandai di sekeliling petak (radius 35 m dari batas).
- BATASAN: hanya geometri celah, bukan peta kanal resmi. Arah aliran, kondisi, dan jenis harus diverifikasi lapangan. Penandaan disimpan di data utama (ikut Backup JSON), terpisah dari daftar kanal di tab Hidrologi.
