WMMS v3 PT BBHA — pengembangan dari WMMS_v2_PT_BBHA.html

CARA PAKAI
1. Buka index.html di browser Android/PC. Untuk APK, gunakan HTML-to-APK Builder seperti alur sebelumnya.
2. Tab Peta/Catat/Analisis/Data asli tetap dipertahankan.
3. Tab Hidrologi berisi:
   - pencatatan jaringan kanal berbasis koordinat berurutan,
   - pencatatan inlet/outlet/pintu air/bendung/stasiun ukur,
   - log aliran masuk dari distrik lain,
   - impor CSV titik elevasi DEM dan ringkasan statistik,
   - pemeriksaan awal temuan/kelengkapan data untuk risiko,
   - backup dan restore data hidrologi JSON.

FORMAT DEM CSV
x,y,elevation
101.75000,1.50000,3.25
101.75100,1.50100,2.90

x = longitude, y = latitude, elevation = elevasi meter.
GeoTIFF belum didukung langsung. Ekspor titik/grid DEM ke CSV terlebih dahulu.

BATASAN PENTING
- Analisis elevasi pada versi ini hanya statistik titik dan identifikasi kelompok elevasi rendah, bukan flow direction/flow accumulation raster.
- Prediksi genangan belum berupa model prediktif terkalibrasi; indikator risiko hanya merangkum keberadaan catatan dan kondisi yang perlu diperiksa.
- Belum ada sinkronisasi multi-perangkat/server.
- Koordinat kanal/titik dan arah aliran harus diverifikasi di lapangan.
- Ambang Normal/Waspada/Kritis tetap mengikuti SOP dan standar hidrologi perusahaan.
- Jangan menggunakan aplikasi ini sebagai instruksi otomatis buka/tutup pintu air.
- Data tersimpan lokal di browser. Lakukan backup berkala.


TAMBAHAN: KORIDOR (kanal/jalan kandidat)
- 640 segmen garis (sekitar 709 km) diekstrak dari celah antar petak di PDF peta konsesi.
- Peta > tombol Koridor: tampilkan garis. Oranye putus-putus = belum dicek; biru = kanal; coklat = jalan; abu-abu = diabaikan.
- Ketuk garis: tandai Kanal (primer/sekunder/tersier/drainase), Jalan, Abaikan, atau Reset.
- Analisis > Koridor: rekap panjang, penandaan cepat per kelas lebar, ekspor GeoJSON kanal.
- Ketuk petak: tampil panjang kanal terklasifikasi di sekeliling petak (radius 35 m dari batas).
- BATASAN: hanya geometri celah, bukan peta kanal resmi. Arah aliran, kondisi, dan jenis harus diverifikasi lapangan. Penandaan koridor tersimpan di data utama (ikut Backup JSON), terpisah dari daftar kanal di tab Hidrologi.
