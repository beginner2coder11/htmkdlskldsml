"""JR Player: read-only media folder, intended for localhost + Tailscale Serve."""
import argparse
import hmac
import json
import mimetypes
import secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlsplit

AUDIO={'.mp3','.m4a','.aac','.wav','.ogg','.flac','.opus'}
VIDEO={'.mp4','.webm','.mkv','.mov','.m4v'}

def make_handler(root, key):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Do not log access keys in URLs.

        def end_headers(self):
            self.send_header('Access-Control-Allow-Origin','*')
            self.send_header('Access-Control-Allow-Headers','Range')
            self.send_header('Access-Control-Allow-Methods','GET, HEAD, OPTIONS')
            self.send_header('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges')
            self.send_header('Cache-Control','no-store')
            self.send_header('Referrer-Policy','no-referrer')
            super().end_headers()

        def do_OPTIONS(self):
            self.send_response(204)
            self.end_headers()

        def do_HEAD(self):
            self.serve(head=True)

        def do_GET(self):
            self.serve()

        def serve(self, head=False):
            url=urlsplit(self.path)
            supplied=parse_qs(url.query).get('key',[''])[0]
            if not hmac.compare_digest(supplied.encode(),key.encode()):
                self.send_error(401,'Access key required')
                return
            if url.path=='/library':
                tracks=[]
                for file in sorted(root.rglob('*')):
                    if not file.is_file() or file.suffix.lower() not in AUDIO|VIDEO:
                        continue
                    resolved=file.resolve()
                    if not resolved.is_relative_to(root):
                        continue
                    tracks.append({'name':str(file.relative_to(root)), 'path':'media/'+quote(file.relative_to(root).as_posix(),safe='/'), 'kind':'video' if file.suffix.lower() in VIDEO else 'audio','size':file.stat().st_size})
                    if len(tracks)>=20000:
                        break
                body=json.dumps({'tracks':tracks},ensure_ascii=False).encode()
                self.send_response(200)
                self.send_header('Content-Type','application/json; charset=utf-8')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers()
                if not head:
                    self.wfile.write(body)
                return
            if not url.path.startswith('/media/'):
                self.send_error(404)
                return
            file=(root/unquote(url.path[len('/media/'):])).resolve()
            if not file.is_relative_to(root) or not file.is_file() or file.suffix.lower() not in AUDIO|VIDEO:
                self.send_error(404)
                return
            size=file.stat().st_size
            start,end=0,size-1
            partial=False
            if 'Range' in self.headers:
                try:
                    raw=self.headers['Range']
                    if not raw.startswith('bytes=') or ',' in raw:
                        raise ValueError()
                    a,b=raw[6:].split('-',1)
                    if a:
                        start=int(a)
                        end=min(int(b),size-1) if b else size-1
                    else:
                        count=int(b)
                        if count<=0:
                            raise ValueError()
                        start=max(0,size-count)
                    if start<0 or start>=size or end<start:
                        raise ValueError()
                    partial=True
                except ValueError:
                    self.send_response(416)
                    self.send_header('Content-Range',f'bytes */{size}')
                    self.send_header('Content-Length','0')
                    self.end_headers()
                    return
            self.send_response(206 if partial else 200)
            self.send_header('Content-Type',mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
            self.send_header('Accept-Ranges','bytes')
            self.send_header('Content-Length',str(max(0,end-start+1)))
            if partial:
                self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            if not head:
                try:
                    with file.open('rb') as stream:
                        stream.seek(start)
                        remaining=end-start+1
                        while remaining>0:
                            chunk=stream.read(min(256*1024,remaining))
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            remaining-=len(chunk)
                except (BrokenPipeError,ConnectionResetError):
                    pass
    return Handler

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('folder',nargs='?')
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    folder=args.folder
    if not folder:
        import tkinter as tk
        from tkinter.filedialog import askdirectory
        app=tk.Tk()
        app.withdraw()
        folder=askdirectory(title='Escolha a pasta das músicas e vídeos')
        app.destroy()
    if not folder:
        return
    root=Path(folder).resolve()
    if not root.is_dir():
        raise SystemExit('Pasta não encontrada.')
    config_path=Path(__file__).with_name('chave_acesso.json')
    if config_path.exists():
        key=json.loads(config_path.read_text())['key']
    else:
        key=secrets.token_urlsafe(32)
        config_path.write_text(json.dumps({'key':key}))
    print('\nJR PLAYER — PASTA REMOTA\nPasta:',root)
    print('Chave de acesso (copie no aplicativo):',key)
    print('Em outro terminal do Windows, execute: tailscale serve --bg 8765')
    print('Copie o endereço HTTPS retornado no campo Endereço do computador do app.')
    print('Mantenha esta janela aberta. Para encerrar, pressione Ctrl+C.\n')
    server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(root,key))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__=='__main__':
    main()
