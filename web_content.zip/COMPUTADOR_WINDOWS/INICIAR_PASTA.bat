@echo off
cd /d "%~dp0"
py -3 servidor_musicas.py
if errorlevel 1 echo Instale Python 3.10 ou mais recente em https://www.python.org/downloads/windows/
pause
