const KEY = "echoforge.v19";
const STRIPE_LINK = "https://buy.stripe.com/aFacN59Fk7VN0em6EBbsc02";
const FREE_ECHO_LIMIT = 25;
const ADMIN_EMAIL = "murilocastronv@gmail.com";
const $ = (id) => document.getElementById(id);
const types = ["Decisão","Rotina","Emocional","Habilidade","Local","Relação","Saúde"];
const prices = { Decisão:89, Rotina:49, Emocional:69, Habilidade:79, Local:39, Relação:59, Saúde:55 };

const COMMUNITY = [
  {id:"c1", type:"Rotina", owner:"maya@echoforge.app", ownerName:"Maya Costa", title:"Acordo 5h30 e não abro o celular", summary:"Água, 10 min de rua, um café. Só depois eu vejo mensagem. Minha manhã parou de começar com ansiedade.", createdAt: Date.now()-3600e3*5, listed:true},
  {id:"c2", type:"Relação", owner:"leo@echoforge.app", ownerName:"Léo Martins", title:"Aprendi a pedir desculpa sem me justificar", summary:"Falei: errei, te magoei, o que precisa agora? Calou o debate. A outra pessoa relaxou.", createdAt: Date.now()-3600e3*8, listed:true},
  {id:"c3", type:"Emocional", owner:"amina@echoforge.app", ownerName:"Amina Dias", title:"Quando o peito aperta eu nomeio", summary:"Digo em voz alta: isso é medo, não é fato. 10 respirações. Só então decido se respondo.", createdAt: Date.now()-3600e3*12, listed:true},
  {id:"c4", type:"Saúde", owner:"maya@echoforge.app", ownerName:"Maya Costa", title:"Troquei o 3º café por uma caminhada", summary:"13h eu saía pra mais cafeína. Agora são 12 minutos de quadra. A tarde rende mais.", createdAt: Date.now()-3600e3*20, listed:true},
  {id:"c5", type:"Habilidade", owner:"leo@echoforge.app", ownerName:"Léo Martins", title:"Estudei 25 min e anotei o erro", summary:"Não estudo até ‘terminar’. Estudo um bloco e escrevo o que quebrou. Isso virou método.", createdAt: Date.now()-3600e3*28, listed:true},
  {id:"c6", type:"Local", owner:"amina@echoforge.app", ownerName:"Amina Dias", title:"O banco da praça muda meu humor", summary:"Sempre o mesmo banco. 15 min sem fone. O bairro vira pausa, não corredor.", createdAt: Date.now()-3600e3*30, listed:true},
  {id:"c7", type:"Decisão", owner:"maya@echoforge.app", ownerName:"Maya Costa", title:"Não respondi o e-mail na hora", summary:"Era reversível. Esperei duas noites. O texto saiu 70% mais curto e sem veneno.", createdAt: Date.now()-3600e3*36, listed:true},
  {id:"c8", type:"Relação", owner:"amina@echoforge.app", ownerName:"Amina Dias", title:"Pus um limite sem sumir", summary:"Combinamos horário de conversa pesada. Fora disso eu não discuto no WhatsApp.", createdAt: Date.now()-3600e3*40, listed:true}
];
const seedFeed = [
  { user:"Maya", type:"Rotina", title:"Deep work 05:30", price:49 },
  { user:"Léo", type:"Decisão", title:"Left the job", price:89 },
  { user:"Amina", type:"Emocional", title:"Recovered from burnout", price:69 }
];

function defaultState() {
  return {
    lang: (navigator.language||"pt").slice(0,2) === "fr" ? "fr" : ((navigator.language||"pt").startsWith("en") ? "en" : "pt"),
    session: null,
    users: [],
    echoes: [],
    sold: 0,
    wallet: 0,
    streak: 1,
    pro: false,
    capture: true,
    anon: true,
    favs: [],
    notes: [],
    goal: 500,
    mode: "signup",
    stripeLink: STRIPE_LINK,
    journal: [],
    moodLog: [],
    habitsDone: {},
    lessonOpen: null,
    stripeOn: true,
    stripePk: "",
    backendUrl: "",
    lastBonusDay: "",
    missions: {},
    likes: {},
    reacts: {},
    comments: {},
    follows: {},
    friends: {},
    messages: [],
    chatWith: null,
    requests: []
  };
}

let S = (() => {
  try { return { ...defaultState(), ...JSON.parse(localStorage.getItem(KEY)||"{}") }; }
  catch { return defaultState(); }
})();
if (!S.stripeLink || !String(S.stripeLink).includes("buy.stripe.com")) S.stripeLink = STRIPE_LINK;
S.stripeOn = S.stripeOn !== false;
S.users = (S.users||[]).map(u => u.status==="pending" ? {...u, status:"approved"} : u);
S.likes = S.likes || {}; S.reacts = S.reacts || {}; S.comments = S.comments || {};
S.follows = S.follows || {}; S.friends = S.friends || {}; S.messages = S.messages || []; S.requests = S.requests || [];
if (!S._graph) {
  S._graph = 1;
  const m="maya@echoforge.app", l="leo@echoforge.app", am="amina@echoforge.app";
  S.follows[m]=[l,am]; S.follows[l]=[m]; S.follows[am]=[m,l];
  S.friends[m]=[l]; S.friends[l]=[m,am]; S.friends[am]=[l];
}
S.users = (S.users||[]).map(u => {
  if ((u.email||"").toLowerCase() === "murilocastroanive@gmail.com") {
    return { ...u, role: "user", status: u.status||"pending" };
  }
  return u;
});
if (!S.users.some(u => u.email === ADMIN_EMAIL)) {
  S.users.unshift({
    name: "Murilo Castro",
    email: ADMIN_EMAIL,
    password: "admin123",
    bio: "Fundador",
    createdAt: Date.now(),
    status: "approved",
    role: "admin",
    pro: true
  });
}
if (!S.users.some(u => u.email === "maya@echoforge.app")) {
  S.users.push(
    { name:"Maya Costa", email:"maya@echoforge.app", password:"demo123", bio:"Early adopter", createdAt: Date.now()-86400000*3, status:"approved", role:"user", pro:true },
    { name:"Léo Martins", email:"leo@echoforge.app", password:"demo123", bio:"", createdAt: Date.now()-86400000*2, status:"pending", role:"user", pro:false },
    { name:"Amina Dias", email:"amina@echoforge.app", password:"demo123", bio:"Coach", createdAt: Date.now()-86400000, status:"approved", role:"user", pro:false }
  );
}
S.users = S.users.map(u => ({
  status: (u.status==="blocked" && "blocked") || "approved",
  role: u.role || (u.email===ADMIN_EMAIL?"admin":"user"),
  pro: !!u.pro,
  ...u
}));
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
const t = () => I18N[S.lang] || I18N.pt;

function money(n) {
  const cur = t().currency;
  const loc = cur==="BRL"?"pt-BR":cur==="EUR"?"fr-FR":"en-US";
  const ccy = cur==="BRL"?"BRL":cur==="EUR"?"EUR":"USD";
  return n.toLocaleString(loc,{style:"currency",currency:ccy});
}

function level() {
  const n = S.echoes.length + S.sold;
  return t().levels[Math.min(4, Math.floor(n/3))];
}

function notify(text) {
  S.notes.unshift({ id: crypto.randomUUID(), text, at: Date.now(), read:false });
  save(); renderBadge();
}

function renderBadge() {
  const n = S.notes.filter(x=>!x.read).length;
  const b = $("badge");
  if (!b) return;
  b.textContent = n;
  b.classList.toggle("hidden", n===0);
}

function show(id) {
  ["splash","landing","auth","app","admin"].forEach(k => $(k) && $(k).classList.add("hidden"));
  $(id).classList.remove("hidden");
}

function isAdmin(email) {
  return (email||"").toLowerCase() === ADMIN_EMAIL;
}

function routeAfterLogin() {
  const email = S.session && S.session.email;
  const user = S.users.find(u => u.email === email);
  if (isAdmin(email)) { S.pro = true; bootApp(); return; }
  if (user && user.status === "pending") { user.status = "approved"; S.users = S.users.map(u => u.email===user.email?{...u,status:"approved"}:u); save(); }
  if (user && user.status === "blocked") { alert(t().waiting); S.session=null; save(); renderLanding(); return; }
  S.pro = !!(user && user.pro) || S.pro;
  bootApp();
}

function renderLanding() {
  const i = t();
  show("landing");
  $("landing").innerHTML = `
    <div class="lang-row">
      <button class="chip ${S.lang==="pt"?"on":""}" data-l="pt">PT</button>
      <button class="chip ${S.lang==="en"?"on":""}" data-l="en">EN</button>
      <button class="chip ${S.lang==="fr"?"on":""}" data-l="fr">FR</button>
    </div>
    <section class="hero-home">
      <img src="logo.svg" class="logo-img" alt="EchoForge" />
      <p class="eyebrow">${i.landingKicker}</p>
      <h1>EchoForge</h1>
      <p class="muted">${i.landingLead}</p>
      <div class="row">
        <button id="goSignup">${i.startNow}</button>
        <button class="ghost" id="goLogin">${i.enter}</button>
      </div>
    </section>
    <div class="kpis">
      <div class="stat"><b>${Math.max(1280, S.users.length*137)}</b><span>${i.kpiUsers}</span></div>
      <div class="stat"><b>${Math.max(5400, S.echoes.length*80)}</b><span>${i.kpiEchoes}</span></div>
      <div class="stat"><b>${Math.max(312, S.sold*21)}</b><span>${i.kpiPaid}</span></div>
    </div>
    <div class="card"><h3>${i.howTitle}</h3>
      <p class="feature"><span class="dot"></span>${i.how1}</p>
      <p class="feature"><span class="dot"></span>${i.how2}</p>
      <p class="feature"><span class="dot"></span>${i.how3}</p>
      <p class="feature"><span class="dot"></span>${i.how4}</p>
      <p class="feature"><span class="dot"></span>${i.how5}</p>
    </div>
    <div class="card"><h3>${i.featTitle}</h3>
      <p>• ${i.f1}</p><p>• ${i.f2}</p><p>• ${i.f3}</p><p>• ${i.f4}</p>
    </div>
    <div class="card"><h3>${i.whyTitle}</h3><p class="muted">${i.whyBody}</p></div>
    <div class="card"><h3>${i.faqTitle}</h3>
      <p><b>${i.faq1q}</b><br>${i.faq1a}</p>
      <p><b>${i.faq2q}</b><br>${i.faq2a}</p>
      <p><b>${i.faq3q}</b><br>${i.faq3a}</p>
    </div>
    <p class="muted">${i.legal}</p>`;
  $("landing").querySelectorAll("[data-l]").forEach(b => b.onclick = () => { S.lang=b.dataset.l; save(); renderLanding(); });
  $("goSignup").onclick = () => { S.mode="signup"; save(); show("auth"); renderAuth(); };
  $("goLogin").onclick = () => { S.mode="login"; save(); show("auth"); renderAuth(); };
}

function renderWaiting() {
  const i = t();
  show("landing");
  $("landing").innerHTML = `<div class="hero-home">
    <img src="logo.svg" class="logo-img" alt="EchoForge" />
    <h1>EchoForge</h1>
    <div class="card"><p>${i.waiting}</p></div>
    <button id="backL">${i.backHome}</button>
  </div>`;
  $("backL").onclick = () => { S.session=null; save(); renderLanding(); };
}

function renderAdmin() {
  const i = t();
  show("admin");
  const users = S.users;
  const pending = users.filter(u=>u.status==="pending").length;
  const paid = users.filter(u=>u.pro).length;
  $("admin").innerHTML = `
    <div class="brand"><img src="logo.svg" class="logo-img xs" /><h1>${i.adminTitle}</h1></div>
    <p class="muted">${ADMIN_EMAIL}</p>
    <div class="stats">
      <div class="stat"><b>${users.length}</b><span>${i.adminUsers}</span></div>
      <div class="stat"><b>${pending}</b><span>${i.adminPending}</span></div>
      <div class="stat"><b>${paid}</b><span>${i.adminPaid}</span></div>
      <div class="stat"><b>${S.echoes.length}</b><span>${i.statsEcho}</span></div>
    </div>
    <div class="card" style="overflow:auto">
      <table class="admin-table">
        <tr><th>Nome</th><th>E-mail</th><th>Status</th><th>Pro</th><th></th></tr>
        ${users.map(u=>`<tr>
          <td>${u.name}</td>
          <td>${u.email}</td>
          <td><span class="tag ${u.status==="approved"?"ok":u.status==="blocked"?"no":"wait"}">${u.status}</span></td>
          <td>${u.pro?"sim":"não"}</td>
          <td>
            ${isAdmin(u.email)? "admin": `
              <button data-ap="${u.email}">${i.adminApprove}</button>
              <button class="ghost" data-bl="${u.email}">${i.adminBlock}</button>
              <button class="ghost" data-pr="${u.email}">Pro</button>`}
          </td>
        </tr>`).join("")}
      </table>
    </div>
    <div class="card">
      <h3>Stripe (admin)</h3>
      <p class="muted">Ative pagamentos com Payment Link e chave pública pk_. Nunca cole sk_live / sk_test.</p>
      <p class="muted">Status: <b>${S.stripeOn?"ATIVO":"DESLIGADO"}</b></p>
      <label>Payment Link</label>
      <input id="admLink" value="${S.stripeLink||""}" placeholder="https://buy.stripe.com/..." />
      <label>Chave pública (pk_)</label>
      <input id="admPk" value="${S.stripePk||""}" placeholder="pk_live_... ou pk_test_..." />
      <label>Secret (sk_) — bloqueada</label>
      <input id="admSk" placeholder="não aceita — use um servidor" />
      <div class="row">
        <button id="admStripeSave">Salvar e ativar</button>
        <button class="ghost" id="admStripeOff">Desligar</button>
      </div>
    </div>
    <div class="row">
      <button id="adminApp">${i.tabs[0]}</button>
      <button class="ghost" id="adminOut">${i.logout}</button>
    </div>`;
  $("admin").querySelectorAll("[data-ap]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.ap?{...u,status:"approved"}:u); save(); renderAdmin();
  });
  $("admin").querySelectorAll("[data-bl]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.bl?{...u,status:"blocked"}:u); save(); renderAdmin();
  });
  $("admin").querySelectorAll("[data-pr]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.pr?{...u,pro:!u.pro}:u); save(); renderAdmin();
  });

  const saveStripeAdmin = (on) => {
    const link = ($("admLink").value||"").trim();
    const pk = ($("admPk").value||"").trim();
    const sk = ($("admSk").value||"").trim();
    if (sk.startsWith("sk_") || link.startsWith("sk_") || pk.startsWith("sk_")) {
      alert("Chave secreta sk_ recusada. Cole só buy.stripe.com e pk_.");
      $("admSk").value = "";
      return;
    }
    if (on && link && !link.includes("buy.stripe.com")) {
      alert("Use um Payment Link buy.stripe.com");
      return;
    }
    if (pk && !pk.startsWith("pk_")) {
      alert("Chave pública deve começar com pk_");
      return;
    }
    S.stripeLink = link || STRIPE_LINK;
    S.stripePk = pk;
    S.stripeOn = !!on;
    save();
    renderAdmin();
  };
  $("admStripeSave").onclick = () => saveStripeAdmin(true);
  $("admStripeOff").onclick = () => saveStripeAdmin(false);
  $("adminApp").onclick = () => bootApp();
  $("adminOut").onclick = () => { S.session=null; save(); renderLanding(); };
}

function renderRecover(){
  const i=t();
  show("auth");
  $("auth").innerHTML = `<h2>EchoForge</h2>
    <h1>${i.recover||"Recover"}</h1>
    <p class="muted">${i.email}</p>
    <input id="recEmail" type="email" placeholder="${i.email}" />
    <input id="recPass" type="password" placeholder="${i.newPass||""}" />
    <button id="doRec">${i.recover||"OK"}</button>
    <button class="link" id="backLogin">${i.hasAccount}</button>`;
  $("backLogin").onclick=()=>{ S.mode="login"; renderAuth(); };
  $("doRec").onclick=()=>{
    const email=($("recEmail").value||"").trim().toLowerCase();
    const pass=$("recPass").value||"";
    const u=S.users.find(x=>x.email===email);
    if(!u){ alert(i.recoverNo); return; }
    if(pass.length<6){ alert(i.weak); return; }
    S.users=S.users.map(x=>x.email===email?{...x,password:pass}:x);
    save(); alert(i.recoverOk); S.mode="login"; renderAuth();
  };
}
function renderAuth() {
  const i = t();
  const signup = S.mode !== "login";
  $("auth").innerHTML = `
    <div class="lang-row">
      <button class="chip ${S.lang==="pt"?"on":""}" data-l="pt">PT</button>
      <button class="chip ${S.lang==="en"?"on":""}" data-l="en">EN</button>
      <button class="chip ${S.lang==="fr"?"on":""}" data-l="fr">FR</button>
    </div>
    <img src="logo.svg" class="logo-img xs" alt="EchoForge" /><h2 style="text-align:center">EchoForge</h2>
    <h1>${signup?i.authTitleSignup:i.authTitleLogin}</h1>
    <p class="muted">${i.authSub}</p>
    <form id="authForm">
      ${signup?`<input id="name" placeholder="${i.name}" />`:""}
      <input id="email" type="email" placeholder="${i.email}" />
      <input id="password" type="password" placeholder="${i.password}" />
      <button>${signup?i.submitSignup:i.submitLogin}</button>
    </form>
    <button class="link" id="toggleAuth">${signup?i.hasAccount:i.noAccount}</button>
    ${signup?"":`<button class="link" id="forgotBtn">${i.forgot||"Forgot"}</button>`}
    <button class="link" id="toLanding">${i.backHome}</button>`;
  $("auth").querySelectorAll("[data-l]").forEach(b => b.onclick = () => { S.lang=b.dataset.l; save(); renderAuth(); });
  $("toggleAuth").onclick = () => { S.mode = signup?"login":"signup"; save(); renderAuth(); };
  const tl = $("toLanding"); if (tl) tl.onclick = () => renderLanding();
  const fb = $("forgotBtn"); if (fb) fb.onclick = () => renderRecover();
  $("authForm").onsubmit = (e) => {
    e.preventDefault();
    const email = $("email").value.trim().toLowerCase();
    const password = $("password").value;
    const name = ($("name")&&$("name").value.trim()) || email.split("@")[0];
    if (!email.includes("@") || password.length<6 || (signup && !name)) { alert(i.weak); return; }
    if (signup) {
      if (S.users.some(u=>u.email===email)) { S.mode="login"; renderAuth(); return; }
      S.users.push({
        name, email, password, bio:"", createdAt:Date.now(),
        status: "approved",
        role: isAdmin(email) ? "admin" : "user",
        pro: isAdmin(email)
      });
    } else {
      const u = S.users.find(u=>u.email===email && u.password===password);
      if (!u) { alert(i.needLogin); return; }
    }
    const user = S.users.find(u=>u.email===email);
    S.session = { email:user.email, name:user.name };
    notify(S.lang==="en"?"Welcome to EchoForge":S.lang==="fr"?"Bienvenue sur EchoForge":"Bem-vindo ao EchoForge");
    save(); routeAfterLogin();
  };
}

let tab = 0;
let filter = "all";
let q = "";
let feedTopic = "all";

function bootApp() {
  show("app");
  $("langSelect").value = S.lang;
  $("langSelect").onchange = () => { S.lang=$("langSelect").value; save(); paint(); };
  $("bell").onclick = () => openNotes();
  paint();
  grantDailyBonus();
}

function paint() {
  const i = t();
  $("hello").textContent = `${i.hello}, ${S.session.name.split(" ")[0]}`;
  $("walletLabel").textContent = i.bonus || i.wallet;
  $("walletValue").textContent = String(Math.round(S.wallet)) + " " + (i.points||"pts");
  const pill = $("streakPill"); if (pill) pill.textContent = "🔥 " + (S.streak||1) + "d";
  const icons = ["🏠","✦","🎁","🌐","💬","⚡","👤"];
  $("mainTabs").innerHTML = i.tabs.map((l,idx)=>`<button class="${tab===idx?"on":""}" data-t="${idx}">${icons[idx]||""} ${l}</button>`).join("");
  $("mainTabs").querySelectorAll("button").forEach(b => b.onclick = () => { tab=+b.dataset.t; paint(); });
  $("pageTitle").textContent = i.tabs[tab];
  renderBadge();
  const views = [homeView, echoesView, freeView, marketView, messagesView, earnView, profileView];
  $("content").innerHTML = views[tab]();
  wire();
}

function todayKey(){ return new Date().toISOString().slice(0,10); }
function grantDailyBonus(){
  const day = todayKey();
  if (S.lastBonusDay === day) return;
  S.lastBonusDay = day;
  S.wallet += 10;
  S.missions = S.missions || {};
  S.missions[day] = Object.assign({ open:true, echo:false, lesson:false, mood:false }, S.missions[day]||{});
  notify(t().bonusNotif);
  save();
}
function missionsBlock(){
  const i = t();
  const day = todayKey();
  const m = (S.missions && S.missions[day]) || { open:true, echo:false, lesson:false, mood:false };
  const row = (ok, label) => `<p>${ok?"✅":"⬜"} ${label}</p>`;
  return `<div class="card"><h3>${i.missions}</h3>${row(m.open,i.m1)}${row(m.echo,i.m2)}${row(m.lesson,i.m3)}${row(m.mood,i.m4)}<p class="muted">${i.noWithdraw}</p></div>`;
}
function completeMission(key){
  const day = todayKey();
  S.missions = S.missions || {};
  S.missions[day] = Object.assign({ open:true, echo:false, lesson:false, mood:false }, S.missions[day]||{});
  if (!S.missions[day][key]) { S.missions[day][key] = true; S.wallet += 5; notify(t().bonusGot); save(); }
}
function homeAdminPanel() {
  if (!S.session || !isAdmin(S.session.email)) return "";
  const i = t();
  const users = S.users;
  const pending = users.filter(u=>u.status==="pending").length;
  const paid = users.filter(u=>u.pro).length;
  return `
    <div class="card admin-card" id="adminBox">
      <div class="row"><div class="meta">PAINEL ADMIN • ${ADMIN_EMAIL}</div><button class="ghost" id="hideAdmin">✕</button></div>
      <h3>${i.adminTitle}</h3>
      <div class="stats">
        <div class="stat"><b>${users.length}</b><span>${i.adminUsers}</span></div>
        <div class="stat"><b>${pending}</b><span>${i.adminPending}</span></div>
        <div class="stat"><b>${paid}</b><span>${i.adminPaid}</span></div>
        <div class="stat"><b>${S.stripeOn?"ON":"OFF"}</b><span>Stripe</span></div>
      </div>
      ${(users.filter(u=>!isAdmin(u.email)).map(u=>`
        <div class="card" style="margin:8px 0">
          <b>${u.name}</b>
          <div class="meta">${u.email}</div>
          <div class="row">
            <span class="tag ${u.status==="approved"?"ok":u.status==="blocked"?"no":"wait"}">${u.status}</span>
            <span class="tag ${u.pro?"ok":"wait"}">${u.pro?"Pro":"free"}</span>
          </div>
          <div class="row">
            <button data-ap="${u.email}">${i.adminApprove}</button>
            <button class="ghost" data-bl="${u.email}">${i.adminBlock}</button>
            <button class="ghost" data-pr="${u.email}">Pro</button>
          </div>
        </div>`).join(""))}
      <label>Payment Link</label>
      <input id="admLink" value="${S.stripeLink||""}" />
      <label>pk_</label>
      <input id="admPk" value="${S.stripePk||""}" placeholder="pk_live_..." />
      <label>URL do servidor</label>
      <input id="admApi" value="${S.backendUrl||""}" placeholder="https://seu-servidor.com" />
      <div class="row">
        <button id="admStripeSave">Ativar Stripe</button>
        <button class="ghost" id="admStripeOff">Desligar</button>
      </div>
    </div>`;
}

function homeView() {
  const i = t();
  const listed = S.echoes.filter(e=>e.listed).length;
  const goalPct = Math.min(100, Math.round((S.wallet/S.goal)*100));
  return `
    ${homeAdminPanel()}
    ${missionsBlock()}
    <div class="quick">
      <button data-go="1">✦ Echo</button>
      <button data-go="2">🎁 ${i.tabs[2]}</button>
      <button data-go="3">🌐 ${i.tabs[3]}</button>
      <button data-go="4">💬 ${i.tabs[4]}</button>
    </div>
    <div class="stats">
      <div class="stat"><b>${S.echoes.length}</b><span>${i.statsEcho}</span></div>
      <div class="stat"><b>${listed}</b><span>${i.statsListed}</span></div>
      <div class="stat"><b>${S.sold}</b><span>${i.statsSold}</span></div>
      <div class="stat"><b>${S.streak}d</b><span>${i.statsStreak}</span></div>
    </div>
    <div class="card">
      <div class="meta">${i.rank}: <b>${level()}</b> • ${i.goalEarn}: ${money(S.goal)}</div>
      <div class="progress"><div class="bar" style="width:${goalPct}%"></div></div>
    </div>
    <button id="btnNew">${i.create}</button>
    ${freeHomeBlock()}
    ${gamesHub()}
    ${feedBlock()}
  `;
}


function F(){ return (typeof FREE!=="undefined" && FREE[S.lang]) ? FREE[S.lang] : FREE.pt; }

function freeHomeBlock(){
  const f = F();
  const day = new Date().getDay();
  return `<div class="card">
    <div class="meta">${f.daily}</div>
    <p>${f.prompts[day % f.prompts.length]}</p>
    <button class="ghost" id="usePrompt">${f.decide}</button>
  </div>
  <div class="card">
    <h3>${f.more}</h3>
    ${f.moreList.map(x=>`<p>• ${x}</p>`).join("")}
  </div>`;
}

function G(){ return (typeof GAMES!=="undefined" && GAMES[S.lang]) ? GAMES[S.lang] : GAMES.pt; }
function gamesHub(){
  const g = G();
  return `<div class="card"><h3>${g.tab}</h3>
    <button data-game="mem">${g.mem}</button>
    <p class="muted">${g.memHint}</p>
    <button data-game="quiz">${g.quiz}</button>
    <p class="muted">${g.quizHint}</p>
    <button data-game="tap">${g.tap}</button>
    <p class="muted">${g.tapHint}</p>
    <button data-game="simon">${g.simon}</button>
    <p class="muted">${g.simonHint}</p>
    <button data-game="word">${g.word}</button>
    <p class="muted">${g.wordHint}</p>
  </div>`;
}
function openGame(kind){
  const g = G();
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet"><h3>${g.tab}</h3><div id="gameBox"></div>
    <p id="gameScore" class="price"></p>
    <div class="row"><button class="ghost" id="gameClose">${g.close}</button><button id="gameAgain">${g.again}</button></div></div>`;
  $("gameClose").onclick = () => $("modal").classList.add("hidden");
  $("gameAgain").onclick = () => startGame(kind);
  startGame(kind);
}
function addPts(n){ S.wallet += n; notify("+" + n + " " + (t().points||"pts")); save(); }
function startGame(kind){
  const box = $("gameBox"); const sc = $("gameScore"); const g = G();
  if (kind==="mem") {
    const faces = ["⚡","🌿","💙","🎯","⚡","🌿","💙","🎯"];
    faces.sort(()=>Math.random()-0.5);
    let first=null, lock=false, pairs=0;
    box.innerHTML = `<div class="grid-cards">${faces.map((f,i)=>`<button class="mcard" data-i="${i}" data-f="${f}">?</button>`).join("")}</div>`;
    box.querySelectorAll(".mcard").forEach(btn => btn.onclick = () => {
      if (lock || btn.classList.contains("ok") || btn.classList.contains("on")) return;
      btn.textContent = btn.dataset.f; btn.classList.add("on");
      if (first==null) { first=btn; return; }
      lock=true;
      setTimeout(()=>{
        if (first.dataset.f===btn.dataset.f) { first.classList.add("ok"); btn.classList.add("ok"); pairs++; if(pairs===4){ sc.textContent=g.score+" 40"; addPts(40);} }
        else { first.textContent="?"; btn.textContent="?"; first.classList.remove("on"); btn.classList.remove("on"); }
        first=null; lock=false;
      }, 450);
    });
  }
  if (kind==="quiz") {
    let i=0, pts=0;
    const ask = () => {
      if (i>=QUIZ.length) { sc.textContent=g.score+" "+pts; addPts(pts); return; }
      const item = QUIZ[i];
      box.innerHTML = `<p>${i+1}/10</p><div class="row"><button data-c="0">${item.q[0]}</button><button data-c="1">${item.q[1]}</button></div>`;
      box.querySelectorAll("button").forEach(b => b.onclick = () => { if(+b.dataset.c===item.ok) pts+=8; i++; ask(); });
    };
    ask();
  }
  if (kind==="tap") {
    let pts=0, tleft=20, dead=false;
    box.innerHTML = `<div id="arena" style="height:220px;position:relative;background:#0c1118;border-radius:12px;overflow:hidden"></div>`;
    const arena = box.querySelector("#arena");
    const tick = setInterval(()=>{ tleft--; sc.textContent=tleft+"s • "+pts; if(tleft<=0){ dead=true; clearInterval(tick); addPts(pts); }},1000);
    const spawn = () => {
      if (dead) return;
      const good = Math.random()>0.3;
      const o = document.createElement("button");
      o.className="orb"; o.style.left=Math.random()*70+5+"%"; o.style.top=Math.random()*60+5+"%";
      o.style.background = good ? "#7c5cff" : "#ff5d73";
      o.onclick = () => { if(dead) return; if(good) pts+=4; else pts=Math.max(0,pts-6); o.remove(); sc.textContent=tleft+"s • "+pts; };
      arena.appendChild(o);
      setTimeout(()=>o.remove(), 900);
      setTimeout(spawn, 420);
    };
    spawn();
  }
  if (kind==="simon") {
    const colors=["#7c5cff","#3dd68c","#ffc857","#5d9bff"];
    let seq=[], user=[], step=0;
    box.innerHTML = `<div class="simon-row">${colors.map((c,i)=>`<button data-s="${i}" style="background:${c}"></button>`).join("")}</div>`;
    const flash = async () => {
      for (const i of seq) {
        const b = box.querySelector(`[data-s="${i}"]`);
        b.style.opacity=".35"; await new Promise(r=>setTimeout(r,280)); b.style.opacity="1"; await new Promise(r=>setTimeout(r,120));
      }
    };
    const next = async () => { seq.push(Math.floor(Math.random()*4)); user=[]; step=seq.length; sc.textContent="nv "+step; await flash(); };
    box.querySelectorAll("[data-s]").forEach(b => b.onclick = async () => {
      user.push(+b.dataset.s);
      if (user[user.length-1] !== seq[user.length-1]) { sc.textContent=g.score+" "+(seq.length-1)*10; addPts((seq.length-1)*10); seq=[]; return; }
      if (user.length===seq.length) { if (seq.length>=6) { addPts(60); sc.textContent=g.score+" 60"; return;} await new Promise(r=>setTimeout(r,300)); next(); }
    });
    next();
  }
  if (kind==="word") {
    const w = WORDS[Math.floor(Math.random()*WORDS.length)];
    const mix = w.split("").sort(()=>Math.random()-0.5).join("");
    box.innerHTML = `<p class="muted">${mix}</p><input id="guess" /><button id="okw">${g.play}</button>`;
    $("okw").onclick = () => {
      const v = ($("guess").value||"").toUpperCase();
      if (v===w) { addPts(15); sc.textContent=g.score+" 15"; } else sc.textContent="...";
    };
  }
}
function freeView(){
  const f = F();
  const dayKey = new Date().toISOString().slice(0,10);
  const done = S.habitsDone[dayKey] || [];
  return `
    <div class="card">
      <h3>${f.daily}</h3>
      <p>${f.prompts[new Date().getDay() % f.prompts.length]}</p>
    </div>
    <div class="card">
      <h3>${f.journal}</h3>
      <textarea id="journalTxt" rows="4" placeholder="${f.journalPh}"></textarea>
      <button id="saveJournal">${f.saveJournal}</button>
      ${(S.journal||[]).slice(0,5).map(j=>`<p class="muted">${new Date(j.at).toLocaleString()} — ${j.text.slice(0,80)}</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.mood}</h3>
      <div class="row">${f.moods.map(m=>`<button class="ghost" data-mood="${m}">${m}</button>`).join("")}</div>
      <p class="muted">${(S.moodLog||[]).slice(0,3).map(m=>m.mood).join(" · ")}</p>
    </div>
    <div class="card">
      <h3>${f.habits}</h3>
      ${f.habitList.map((h,i)=>`<label><input type="checkbox" data-hab="${i}" ${done.includes(i)?"checked":""}/> ${h}</label><br/>`).join("")}
    </div>
    <div class="card">
      <h3>${f.canvas}</h3>
      <input id="optA" placeholder="${f.optA}" />
      <input id="optB" placeholder="${f.optB}" />
      <button id="saveDecision">${f.decide}</button>
    </div>
    <div class="card">
      <h3>${f.lessons}</h3>
      ${f.lessonsList.map((l,i)=>`<details><summary>${l.t}</summary><p>${l.b}</p></details>`).join("")}
    </div>
    <div class="card">
      <h3>${f.packs}</h3>
      ${f.packsList.map(p=>`<button class="ghost" data-pack="${p}">${p}</button>`).join("")}
    </div>
    <div class="card">
      <h3>${f.check}</h3>
      ${f.checks.map(c=>`<p>• ${c}</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.quotes}</h3>
      ${f.quoteList.map(q=>`<p class="muted">“${q}”</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.more}</h3>
      ${f.moreList.map(x=>`<p>• ${x}</p>`).join("")}
    </div>
    ${gamesHub()}
    <div class="card">
      <h3>2 min</h3>
      <p class="muted">Respira 4-4-4. Fica no app.</p>
      <button id="breath">Iniciar</button>
      <p id="breathTxt" class="muted"></p>
    </div>
    <div class="card">
      <h3>Eco rápido</h3>
      <p>${["O que evitei hoje?","Quem eu protegi?","O que posso cortar amanhã?","Onde gastei energia à toa?"][new Date().getHours()%4]}</p>
      <button class="ghost" id="quickEcho">Registrar</button>
    </div>`;
}

function echoesView() {
  const i = t();
  const list = S.echoes.filter(e =>
    (filter==="all"||e.type===filter) &&
    (e.title+" "+e.summary).toLowerCase().includes(q.toLowerCase())
  );
  return `
    <input id="search" placeholder="${i.search}" value="${q}" />
    <div class="row">
      <button class="ghost ${filter==="all"?"on":""}" data-f="all">${i.filterAll}</button>
      ${types.map(tp=>`<button class="ghost" data-f="${tp}">${i.types[tp]}</button>`).join("")}
    </div>
    <button id="btnNew">${i.create}</button>
    ${list.length? list.map(echoCard).join("") : `<div class="card">${i.empty}</div>`}
  `;
}

function allFeed(){
  const mine = S.echoes.filter(e=>e.listed).map(e=>({...e, local:true}));
  return [...mine, ...COMMUNITY].sort((a,b)=>b.createdAt-a.createdAt);
}
function feedBlock(){
  const i = t();
  const topics = ["all", ...types];
  const items = allFeed().filter(e => feedTopic==="all" || e.type===feedTopic);
  return `<div class="card">
    <h3>${i.feedTitle}</h3>
    <p class="muted">${i.space||""}</p>
    <div class="row">
      ${topics.map(tp=>`<button class="ghost ${feedTopic===tp?"on":""}" data-topic="${tp}">${tp==="all"?i.filterAll:(i.types[tp]||tp)}</button>`).join("")}
    </div>
  </div>
  ${items.map(e=>echoCard(e,true)).join("") || `<div class="card">${i.spaceEmpty||i.empty}</div>`}`;
}
function areFriends(a,b){
  return (S.friends[a]||[]).includes(b) && (S.friends[b]||[]).includes(a);
}
function followingOf(email){ return S.follows[email]||[]; }
function followersOf(email){
  return Object.keys(S.follows||{}).filter(u => (S.follows[u]||[]).includes(email));
}
function friendsOf(email){ return S.friends[email]||[]; }
function mutualFriends(a,b){
  const A=new Set(friendsOf(a));
  return friendsOf(b).filter(x=>A.has(x) && x!==a && x!==b);
}
function nameOf(email){
  const u=S.users.find(x=>x.email===email);
  return u?u.name:email.split("@")[0];
}
function peopleLine(emails){
  if(!emails.length) return `<p class="muted">—</p>`;
  return emails.map(em=>`<button class="ghost" data-prof="${em}">${nameOf(em)}</button>`).join(" ");
}
function pendingReq(from,to){
  return (S.requests||[]).find(r=>r.from===from && r.to===to && r.status==="wait");
}
function openProfile(email){
  const i=t();
  const u=S.users.find(x=>x.email===email) || COMMUNITY.find(x=>x.owner===email && false);
  const user = S.users.find(x=>x.email===email);
  if(!user){
    // synthetic from community
    const name = (COMMUNITY.find(c=>c.owner===email)||{}).ownerName || email;
    S.users.push({name, email, password:"", bio:"Membro da comunidade EchoForge.", photo:"", status:"approved", role:"user", pro:false, createdAt:Date.now()});
    save();
  }
  const p = S.users.find(x=>x.email===email);
  const mine = me();
  const friends = areFriends(mine, email);
  const sent = pendingReq(mine, email);
  const incoming = pendingReq(email, mine);
  const posts = allFeed().filter(e => e.owner===email).length;
  const fol = followersOf(email).length;
  const fing = followingOf(email).length;
  const fr = friendsOf(email).length;
  const mut = mine!==email ? mutualFriends(mine,email) : friendsOf(email).slice(0,3);
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <div class="fb">
      <div class="cover"></div>
      ${p.photo?`<img class="fb-ava" src="${p.photo}" />`:`<div class="fb-ava letter">${(p.name||"?")[0]}</div>`}
    </div>
    <h2>${p.name}</h2>
    <p class="counts"><b>${fol}</b> ${i.people||"followers"} · <b>${fing}</b> ${i.following||"suivant"} · <b>${posts}</b> posts · <b>${fr}</b> ${i.friends}</p>
    <p class="muted" style="text-align:center">${p.bio||""}</p>
    <div class="mutual">${mut.map(em=>`<span class="mini">${nameOf(em)[0]}</span>`).join("")}${mut.length?`<span>${mut.length} ${i.friends}</span>`:""}</div>
    <div class="actions2">
      <button class="ghost" data-follow="${email}">${(S.follows[mine]||[]).includes(email)?i.following:i.follow}</button>
      ${friends?`<button>${i.friendOk}</button>`: incoming?`<button id="accReq">${i.accept}</button>`: sent?`<button class="ghost">${i.requestSent}</button>`:`<button id="sendReq">${i.addFriend}</button>`}
    </div>
    <div class="actions2">
      <button class="ghost" id="goChat">${i.chat}</button>
      <button class="ghost" id="closeProf">✕</button>
    </div>
  </div>`;
  $("closeProf").onclick=()=>$("modal").classList.add("hidden");
  const sr=$("sendReq"); if(sr) sr.onclick=()=>{ S.requests.push({from:mine,to:email,status:"wait",at:Date.now()}); notify(i.requestSent); save(); openProfile(email); };
  const ac=$("accReq"); if(ac) ac.onclick=()=>{
    S.requests=S.requests.map(r=>r.from===email&&r.to===mine?{...r,status:"ok"}:r);
    S.friends[mine]=S.friends[mine]||[]; S.friends[email]=S.friends[email]||[];
    if(!S.friends[mine].includes(email)) S.friends[mine].push(email);
    if(!S.friends[email].includes(mine)) S.friends[email].push(mine);
    save(); openProfile(email);
  };
  $("goChat").onclick=()=>{
    if(!areFriends(mine,email)){ alert(i.noChat); return; }
    S.chatWith=email; $("modal").classList.add("hidden"); tab=4; save(); paint();
  };
  document.querySelectorAll(".sheet [data-follow]").forEach(b => b.onclick = () => {
    S.follows[mine]=S.follows[mine]||[];
    if (S.follows[mine].includes(email)) S.follows[mine]=S.follows[mine].filter(x=>x!==email);
    else S.follows[mine].push(email);
    save(); openProfile(email);
  });
}
function me(){ return S.session && S.session.email; }
function avatarOf(email, name){
  const u = S.users.find(x=>x.email===email);
  if (u && u.photo) return `<img class="avatar" src="${u.photo}" alt="" />`;
  return `<div class="avatar">${(name||email||"?")[0]}</div>`;
}
function echoCard(e, social) {
  const i = t();
  const fav = S.favs.includes(e.id);
  const likes = (S.likes[e.id]||[]).length;
  const comm = S.comments[e.id]||[];
  const reacts = S.reacts[e.id]||{};
  const owner = e.ownerName || e.owner || "";
  const reactBar = ["❤️","🔥","🙌","💡","🤝"].map(em => {
    const n = (reacts[em]||[]).length;
    return `<button class="ghost" data-react="${e.id}|${em}">${em}${n?(" "+n):""}</button>`;
  }).join("");
  const commentsHtml = comm.map(c=>`<p class="muted"><b>${c.name}:</b> ${c.text}</p>`).join("");
  return `<article class="card echo">
    <div class="feed-item" data-prof="${e.owner||""}">${avatarOf(e.owner, owner)}<div>
      <b>${owner||i.space}</b>
      <div class="meta">${i.types[e.type]||e.type} • ${new Date(e.createdAt).toLocaleString()}</div>
    </div></div>
    <h3>${e.title}</h3>
    <p>${e.summary}</p>
    <div class="row">
      <button data-sell="${e.id}">${e.listed?i.unpublish||i.unsell:i.publish||i.sell}</button>
      <button class="ghost" data-like="${e.id}">♥ ${likes} ${i.like}</button>
      <button class="ghost" data-fav="${e.id}">${fav?"★":"☆"}</button>
      ${e.owner && e.owner!==me()?`<button class="ghost" data-follow="${e.owner}">${(S.follows[me()]||[]).includes(e.owner)?i.following:i.follow}</button>
      <button class="ghost" data-friend="${e.owner}">${(S.friends[me()]||[]).includes(e.owner)?i.friendOk:i.addFriend}</button>
      <button class="ghost" data-chat="${e.owner}">${i.chat}</button>`:""}
    </div>
    <div class="row">${reactBar}</div>
    ${social!==false?`<div>${commentsHtml}
      <input data-cmt="${e.id}" placeholder="${i.writeHelp||""}" />
      <button class="ghost" data-sendc="${e.id}">${i.comment}</button>
    </div>`:""}
  </article>`;
}

function marketView() {
  const i = t();
  const listed = allFeed();
  const people = S.users.filter(u=>u.email!==me());
  const chatUser = S.chatWith && S.users.find(u=>u.email===S.chatWith);
  const thread = (S.messages||[]).filter(m => chatUser && ((m.from===me()&&m.to===chatUser.email)||(m.to===me()&&m.from===chatUser.email)));
  return `
    <h3>${i.space||i.discover}</h3>
    <p class="muted">${i.spaceEmpty||""}</p>
    ${listed.length? listed.map(e=>echoCard(e,true)).join("") : `<div class="card">${i.spaceEmpty||i.marketEmpty}</div>`}
    <div class="card">
      <h3>${i.people}</h3>
      ${people.map(u=>`<div class="feed-item" style="margin:8px 0" data-prof="${u.email}">${avatarOf(u.email,u.name)}<div>
        <b>${u.name}</b>
        <div class="meta">${u.bio||u.email}</div>
        <div class="row">
          <button class="ghost" data-follow="${u.email}">${(S.follows[me()]||[]).includes(u.email)?i.following:i.follow}</button>
          <button class="ghost" data-friend="${u.email}">${(S.friends[me()]||[]).includes(u.email)?i.friendOk:i.addFriend}</button>
          <button class="ghost" data-chat="${u.email}">${i.chat}</button>
        </div>
      </div></div>`).join("") || `<p class="muted">${i.people}</p>`}
    </div>
    ${chatUser?`<div class="card">
      <h3>${i.chat} • ${chatUser.name}</h3>
      ${thread.map(m=>`<p class="muted"><b>${m.from===me()?"eu":chatUser.name}:</b> ${m.text}</p>`).join("")}
      <input id="chatTxt" placeholder="${i.writeHelp||""}" />
      <button id="chatSend">${i.send}</button>
    </div>`:""}
    <div class="card">
      <h3>${i.premium}</h3>
      <p class="muted">${i.premiumDesc}</p>
      <button id="btnPro">${S.pro?i.subscribed:i.subscribe}</button>
      ${S.pro?"":`<button class="ghost" id="btnPaid">${i.alreadyPaid}</button>`}
    </div>
  `;
}

function messagesView(){
  const i=t();
  const mine=me();
  const incoming=(S.requests||[]).filter(r=>r.to===mine && r.status==="wait");
  const pals=(S.friends[mine]||[]);
  const chatUser=S.chatWith && S.users.find(u=>u.email===S.chatWith);
  const thread=(S.messages||[]).filter(m=>chatUser && ((m.from===mine&&m.to===chatUser.email)||(m.to===mine&&m.from===chatUser.email)));
  return `
    <h3>${i.inbox||i.chat}</h3>
    ${incoming.length?`<div class="card"><h3>${i.requests}</h3>${incoming.map(r=>{
      const u=S.users.find(x=>x.email===r.from)||{name:r.from,email:r.from};
      return `<div class="row"><span>${u.name}</span><button data-acc="${r.from}">${i.accept}</button></div>`;
    }).join("")}</div>`:""}
    <div class="card">
      <h3>${i.friends}</h3>
      ${pals.map(em=>{
        const u=S.users.find(x=>x.email===em)||{name:em,email:em};
        return `<div class="feed-item" data-prof="${em}">${avatarOf(em,u.name)}<div>
          <b>${u.name}</b>
          <button class="ghost" data-chat="${em}">${i.chat}</button>
        </div></div>`;
      }).join("") || `<p class="muted">${i.noChat}</p>`}
    </div>
    ${chatUser?`<div class="card">
      <h3>${chatUser.name}</h3>
      <div style="max-height:240px;overflow:auto">${thread.map(m=>`<p class="muted"><b>${m.from===mine?"eu":chatUser.name}:</b> ${m.text}</p>`).join("")||"<p class='muted'>...</p>"}</div>
      <input id="chatTxt" placeholder="${i.writeHelp||""}" />
      <button id="chatSend">${i.send}</button>
    </div>`:""}
  `;
}
function earnView() {
  const i = t();
  const c1 = Math.min(3, S.echoes.length);
  return `
    <div class="card">
      <h3>${i.challenges}</h3>
      <p>${i.challenge1} — ${c1}/3</p>
      <div class="progress"><div class="bar" style="width:${(c1/3)*100}%"></div></div>
      <p>${i.challenge2} — ${Math.min(1,S.sold)}/1</p>
      <p>${i.challenge3} — 0/1</p>
    </div>
    <div class="card">
      <h3>${i.referral}</h3>
      <code>ECHO-${(S.session.name||"USER").slice(0,4).toUpperCase()}26</code>
      <button id="copyRef" class="ghost">${i.copyCode}</button>
    </div>
    <div class="card">
      <h3>${i.goals}</h3>
      <input id="goal" type="number" value="${S.goal}" />
      <button id="saveGoal">${i.goalEarn}</button>
    </div>
  `;
}

function profileView() {
  const i = t();
  const u = S.users.find(x=>x.email===S.session.email) || S.session;
  return `
    <div class="card" style="overflow:hidden;padding-top:0">
      <div class="fb" style="margin:0 -14px">
        <div class="cover"></div>
        ${u.photo?`<img class="fb-ava" src="${u.photo}" />`:`<div class="fb-ava letter">${u.name[0]}</div>`}
      </div>
      <h2 style="text-align:center">${u.name}</h2>
      <p class="counts"><b>${followersOf(u.email).length}</b> ${i.people} · <b>${followingOf(u.email).length}</b> ${i.following} · <b>${allFeed().filter(e=>e.owner===u.email).length}</b> posts · <b>${friendsOf(u.email).length}</b> ${i.friends}</p>
      <p class="muted" style="text-align:center">${i.verified} • ${level()}</p>
      ${u.photo?`<img src="${u.photo}" style="width:72px;height:72px;border-radius:50%;object-fit:cover" />`:""}
      <div class="card">
        <p class="muted">${i.following||"Seguindo"} (${followingOf(u.email).length})</p>
        ${peopleLine(followingOf(u.email))}
        <p class="muted">${i.people||"Seguidores"} (${followersOf(u.email).length})</p>
        ${peopleLine(followersOf(u.email))}
        <p class="muted">${i.friends} (${friendsOf(u.email).length})</p>
        ${peopleLine(friendsOf(u.email))}
      </div>
      <label class="muted">${i.photo||""}</label>
      <input id="photoFile" type="file" accept="image/*" />
      <label class="muted">${i.bio}</label>
      <textarea id="bio">${u.bio||""}</textarea>
      <button id="saveBio">${i.profile}</button>
    </div>
    <div class="card">
      <h3>${i.privacy}</h3>
      <label><input id="cap" type="checkbox" ${S.capture?"checked":""}/> ${i.capture}</label><br/>
      <label><input id="anon" type="checkbox" ${S.anon?"checked":""}/> ${i.anon}</label>
      <button id="wipe" class="danger">${i.wipe}</button>
    </div>
    <div class="card">
      <h3>${i.payTitle}</h3>
      <p class="muted">${i.payHint}</p>
      <input id="stripeLink" placeholder="https://buy.stripe.com/..." value="${S.stripeLink||""}" />
      <button id="saveStripe">${i.paySave}</button>
    </div>
    <div class="card">
      <h3>${i.support}</h3>
      <p class="muted">${i.faq}</p>
    </div>
    <button id="logout" class="ghost">${i.logout}</button>
  `;
}

function wire() {
  const n = $("btnNew"); if (n) n.onclick = openCreate;
  const br=$("breath"); if(br) br.onclick=()=>{
    let s=24; const el=$("breathTxt");
    const id=setInterval(()=>{ el.textContent = s+"s • inspira / segura / solta"; s--; if(s<0){ clearInterval(id); el.textContent="ok"; addPts(8);} },1000);
  };
  const qe=$("quickEcho"); if(qe) qe.onclick=()=>openCreate();
  document.querySelectorAll("[data-game]").forEach(b => b.onclick = () => openGame(b.dataset.game));

  document.querySelectorAll("[data-like]").forEach(b => b.onclick = () => {
    const id=b.dataset.like; S.likes[id]=S.likes[id]||[];
    if (S.likes[id].includes(me())) S.likes[id]=S.likes[id].filter(x=>x!==me());
    else S.likes[id].push(me());
    save(); paint();
  });
  document.querySelectorAll("[data-react]").forEach(b => b.onclick = () => {
    const [id,em]=b.dataset.react.split("|");
    S.reacts[id]=S.reacts[id]||{}; S.reacts[id][em]=S.reacts[id][em]||[];
    if (S.reacts[id][em].includes(me())) S.reacts[id][em]=S.reacts[id][em].filter(x=>x!==me());
    else S.reacts[id][em].push(me());
    save(); paint();
  });
  document.querySelectorAll("[data-sendc]").forEach(b => b.onclick = () => {
    const id=b.dataset.sendc;
    const inp=document.querySelector(`[data-cmt="${id}"]`);
    const text=(inp&&inp.value||"").trim(); if(!text) return;
    S.comments[id]=S.comments[id]||[];
    S.comments[id].push({name:S.session.name, email:me(), text, at:Date.now()});
    save(); paint();
  });
  document.querySelectorAll("[data-follow]").forEach(b => b.onclick = () => {
    const t=b.dataset.follow; S.follows[me()]=S.follows[me()]||[];
    if (S.follows[me()].includes(t)) S.follows[me()]=S.follows[me()].filter(x=>x!==t);
    else S.follows[me()].push(t);
    save(); paint();
  });
  document.querySelectorAll("[data-friend]").forEach(b => b.onclick = () => openProfile(b.dataset.friend));
  document.querySelectorAll("[data-prof]").forEach(b => b.onclick = () => { if(b.dataset.prof) openProfile(b.dataset.prof); });
  document.querySelectorAll("[data-chat]").forEach(b => b.onclick = () => {
    const em=b.dataset.chat;
    if(!areFriends(me(), em)) { openProfile(em); return; }
    S.chatWith=em; tab=4; save(); paint();
  });
  const cs=$("chatSend"); if(cs) cs.onclick=()=>{
    const text=($("chatTxt").value||"").trim(); if(!text||!S.chatWith) return;
    S.messages.push({from:me(), to:S.chatWith, text, at:Date.now()});
    save(); paint();
  };
  const pf=$("photoFile"); if(pf) pf.onchange=()=>{
    const f=pf.files&&pf.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=()=>{ S.users=S.users.map(u=>u.email===me()?{...u,photo:r.result}:u); save(); paint(); };
    r.readAsDataURL(f);
  };

  document.querySelectorAll("[data-ap]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.ap?{...u,status:"approved"}:u); save(); paint();
  });
  document.querySelectorAll("[data-bl]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.bl?{...u,status:"blocked"}:u); save(); paint();
  });
  document.querySelectorAll("[data-pr]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.pr?{...u,pro:!u.pro}:u); save(); paint();
  });
  if ($("admStripeSave")) {
    const saveStripeAdmin = (on) => {
      const link = ($("admLink").value||"").trim();
      const pk = ($("admPk").value||"").trim();
      if (link.startsWith("sk_") || pk.startsWith("sk_")) { alert("sk_ recusada"); return; }
      if (on && link && !link.includes("buy.stripe.com")) { alert("Use buy.stripe.com"); return; }
      if (pk && !pk.startsWith("pk_")) { alert("Use pk_"); return; }
      S.stripeLink = link || STRIPE_LINK;
      S.stripePk = pk;
      S.stripeOn = !!on;
      S.backendUrl = ($("admApi") && $("admApi").value || "").trim().replace(/\/$/,"");
      save(); paint();
    };
    $("admStripeSave").onclick = () => saveStripeAdmin(true);
    $("admStripeOff").onclick = () => saveStripeAdmin(false);
  }

  const up = $("usePrompt"); if (up) up.onclick = () => {
    const f=F(); const p = f.prompts[new Date().getDay() % f.prompts.length];
    addFreeEcho("Rotina", p, p);
  };
  const sj = $("saveJournal"); if (sj) sj.onclick = () => {
    const text = ($("journalTxt").value||"").trim();
    if (!text) return;
    S.journal = [{at:Date.now(), text}, ...(S.journal||[])];
    save(); paint();
  };
  document.querySelectorAll("[data-mood]").forEach(b => b.onclick = () => {
    completeMission('mood');
    S.moodLog = [{at:Date.now(), mood:b.dataset.mood}, ...(S.moodLog||[])];
    save(); paint();
  });
  document.querySelectorAll("[data-hab]").forEach(b => b.onchange = () => {
    const dayKey = new Date().toISOString().slice(0,10);
    const cur = new Set(S.habitsDone[dayKey]||[]);
    const i = +b.dataset.hab;
    b.checked ? cur.add(i) : cur.delete(i);
    S.habitsDone[dayKey] = [...cur];
    save();
  });
  const sd = $("saveDecision"); if (sd) sd.onclick = () => {
    const a1=$("optA").value||"A"; const b1=$("optB").value||"B";
    addFreeEcho("Decisão", a1+" vs "+b1, a1+" | "+b1);
  };
  document.querySelectorAll("[data-pack]").forEach(b => b.onclick = () => addFreeEcho("Rotina", b.dataset.pack, b.dataset.pack));

  const s = $("search"); if (s) s.oninput = () => { q=s.value; paint(); };
  document.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { filter=b.dataset.f; paint(); });
  document.querySelectorAll("[data-sell]").forEach(b => b.onclick = () => {
    S.echoes = S.echoes.map(e => e.id===b.dataset.sell ? {...e, listed:!e.listed}:e);
    save(); paint();
  });
  document.querySelectorAll("[data-lic]").forEach(b => b.onclick = () => {
    alert(t().payOnlyLink);
    window.open(S.stripeLink || STRIPE_LINK, "_blank");
  });
  document.querySelectorAll("[data-fav]").forEach(b => b.onclick = () => {
    S.favs = S.favs.includes(b.dataset.fav) ? S.favs.filter(id=>id!==b.dataset.fav) : [...S.favs,b.dataset.fav];
    save(); paint();
  });
  const p = $("btnPro"); if (p) p.onclick = () => startCheckout();
  const paid = $("btnPaid"); if (paid) paid.onclick = () => unlockPro();
  const c = $("copyRef"); if (c) c.onclick = () => { navigator.clipboard?.writeText("ECHO-REF26"); alert(t().copyCode); };
  const g = $("saveGoal"); if (g) g.onclick = () => { S.goal = Number($("goal").value||500); save(); paint(); };
  const sb = $("saveBio"); if (sb) sb.onclick = () => {
    S.users = S.users.map(u => u.email===S.session.email ? {...u, bio:$("bio").value}:u);
    save(); paint();
  };
  const cap = $("cap"); if (cap) cap.onchange = () => { S.capture = cap.checked; save(); };
  const anon = $("anon"); if (anon) anon.onchange = () => { S.anon = anon.checked; save(); };
  const w = $("wipe"); if (w) w.onclick = () => {
    if (!confirm(t().wipe+"?")) return;
    S.echoes=[]; S.sold=0; S.wallet=0; S.favs=[]; save(); paint();
  };
  const ss = $("saveStripe"); if (ss) ss.onclick = () => {
    const url = ($("stripeLink").value||"").trim();
    if (url.startsWith("sk_") || url.includes("sk_live") || url.includes("sk_test")) {
      alert(t().payHint); return;
    }
    S.stripeLink = url; save(); paint();
  };
  const lo = $("logout"); if (lo) lo.onclick = () => { S.session=null; save(); show("auth"); renderAuth(); };
}

function addFreeEcho(type, title, body){
  if (!S.pro && S.echoes.length >= FREE_ECHO_LIMIT) { tab = 3; paint(); return; }
  S.echoes.unshift({
    id: crypto.randomUUID(), type, title,
    summary: body.slice(0,180),
    price: prices[type]||49, listed:false, createdAt: Date.now()
  });
  save(); tab = 1; paint();
}

async function apiCheckout({title, amount, echoId}) {
  const base = (S.backendUrl||"").replace(/\/$/,"");
  if (!base) return null;
  const cur = t().currency || "BRL";
  const res = await fetch(base + "/checkout", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      echoId, title, amount,
      currency: cur,
      buyerEmail: S.session && S.session.email,
      sellerEmail: ADMIN_EMAIL,
      successUrl: location.href,
      cancelUrl: location.href
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "checkout");
  return data.url;
}

function startCheckout() {
  if (!S.stripeOn) { alert("Stripe desligado no painel admin."); return; }
  const goLink = () => window.open((S.stripeLink||STRIPE_LINK), "_blank");
  if (S.backendUrl) {
    apiCheckout({ title: "EchoForge Pro", amount: 29.9, echoId: "pro" })
      .then(url => { if (url) window.open(url, "_blank"); else goLink(); })
      .catch(() => goLink());
  } else goLink();
  const i = t();
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.payOpen}</h3>
    <p class="muted">${i.afterPay}</p>
    <div class="row">
      <button id="goStripe">${i.payOpen}</button>
      <button class="ghost" id="confirmPaid">${i.alreadyPaid}</button>
    </div>
  </div>`;
  $("goStripe").onclick = () => window.open(S.stripeLink||STRIPE_LINK, "_blank");
  $("confirmPaid").onclick = () => unlockPro();
}

function unlockPro() {
  S.pro = true;
  S.users = S.users.map(u => u.email===(S.session&&S.session.email)?{...u,pro:true}:u);
  notify(t().subscribed);
  save();
  $("modal").classList.add("hidden");
  paint();
}

function openCreate() {
  const i = t();
  if (!S.pro && S.echoes.length >= FREE_ECHO_LIMIT) {
    tab = 3; paint(); alert(i.payMissingUnlock || i.payMissing); return;
  }
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.create}</h3>
    <select id="echoType">${types.map(tp=>`<option value="${tp}">${i.types[tp]}</option>`).join("")}</select>
    <input id="echoTitle" placeholder="${i.title}" />
    <textarea id="echoBody" rows="4" placeholder="${i.body}"></textarea>
    <div class="row">
      <button class="ghost" id="btnCancel">${i.cancel}</button>
      <button id="btnSave">${i.generate}</button>
    </div>
  </div>`;
  $("btnCancel").onclick = () => $("modal").classList.add("hidden");
  $("btnSave").onclick = () => {
    const type = $("echoType").value;
    const title = $("echoTitle").value.trim() || i.types[type];
    const body = $("echoBody").value.trim() || title;
    S.echoes.unshift({
      id: crypto.randomUUID(), type, title,
      summary: `${i.types[type]} • ${body.slice(0,160)}`,
      price: 0, listed:false, createdAt: Date.now(), owner: S.session && S.session.email, ownerName: S.session && S.session.name
    });
    S.streak += 1;
    completeMission('echo');
    notify(i.create + ": " + title);
    save(); $("modal").classList.add("hidden"); paint();
  };
}

function openNotes() {
  const i = t();
  S.notes = S.notes.map(n => ({...n, read:true})); save(); renderBadge();
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.notify}</h3>
    ${S.notes.length? S.notes.map((n,idx)=>`<div class="card" data-note="${n.tab!=null?n.tab:0}"><div class="meta">${new Date(n.at).toLocaleString()}</div>${n.text}</div>`).join("") : `<p class="muted">${i.noNotify}</p>`}
    <button class="ghost" onclick="document.getElementById('modal').classList.add('hidden')">${i.cancel}</button>
  </div>`;
  $("modal").querySelectorAll("[data-note]").forEach(el => el.onclick = () => {
    $("modal").classList.add("hidden");
    tab = +el.dataset.note;
    if (S.session) paint();
  });
}

function startIdlePing(){
  const THREE = 3*60*60*1000;
  let hiddenAt = 0;
  let timer = null;
  const ping = () => {
    if (document.visibilityState === "visible") return;
    const msg = t().ping || "EchoForge";
    if ("Notification" in window && Notification.permission === "granted") {
      try { new Notification("EchoForge", { body: msg }); } catch(e) {}
    }
    S.notes.unshift({ text: msg, at: Date.now(), read:false, tab:0 });
    save();
  };
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      hiddenAt = Date.now();
      if (timer) clearTimeout(timer);
      timer = setTimeout(ping, THREE);
    } else {
      if (timer) { clearTimeout(timer); timer=null; }
    }
  });
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission().catch(()=>{});
  }
}
window.onload = () => {
  $("splashText").textContent = t().splash;
  startIdlePing();
  setTimeout(() => {
    if (S.session) routeAfterLogin();
    else renderLanding();
  }, 800);
};
