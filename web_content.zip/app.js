/* ===================== महिला समूह – बचत एवं ऋण प्रबंधन ===================== */
'use strict';
const KEY='mahilaSamooh.v2', MAX_MEMBERS=100;
const HM=['जनवरी','फ़रवरी','मार्च','अप्रैल','मई','जून','जुलाई','अगस्त','सितंबर','अक्टूबर','नवंबर','दिसंबर'];
const WD=['रवि','सोम','मंगल','बुध','गुरु','शुक्र','शनि'];
const ROLES=['सदस्य','अध्यक्ष','उपाध्यक्ष','सचिव','कोषाध्यक्ष'];
const PURPOSES=['सिलाई / बुनाई','किराना / दुकान','पशुपालन (गाय/भैंस/बकरी)','खेती-बाड़ी / बीज','बच्चों की पढ़ाई','इलाज / स्वास्थ्य','घर मरम्मत','शादी / पारिवारिक कार्य','अन्य'];

const $=s=>document.querySelector(s);
const pad=n=>String(n).padStart(2,'0');
const rs=n=>'₹'+Math.round(+n||0).toLocaleString('en-IN');
const num=v=>{const n=parseFloat(v);return isFinite(n)&&n>0?n:0};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const today=()=>iso(new Date());
const fmtD=s=>{if(!s)return'';const[y,m,d]=s.split('-').map(Number);return d+' '+HM[m-1]+' '+y};
const fmtS=s=>{if(!s)return'';const[y,m,d]=s.split('-').map(Number);return pad(d)+'/'+pad(m)+'/'+y};
const byDate=(a,b)=>a.date<b.date?-1:a.date>b.date?1:(a.created||0)-(b.created||0);
const initials=n=>(String(n||'?').trim()[0]||'?');

/* ---------------- डेटा ---------------- */
function defaults(){
  return {v:2, settings:{name:'',tagline:'',village:'',block:'',district:'',formed:today(),logo:'',photo:'',
      kistOptions:[1000,2000,4000,5000], defaultKist:1000, rate:2, fine:0, openCash:0,
      bankName:'',bankAcc:'',autofill:true, meetDay:10},
    members:[], meetings:[], nextRoll:1, setupDone:false};
}
let S;
function load(){ try{ S=JSON.parse(localStorage.getItem(KEY))||defaults(); }catch(e){ S=defaults(); }
  const d=defaults(); S.settings=Object.assign(d.settings,S.settings||{}); S.members=S.members||[]; S.meetings=S.meetings||[]; }
let saveT;
function save(now){ clearTimeout(saveT); const f=()=>{ try{ localStorage.setItem(KEY,JSON.stringify(S)); }catch(e){ toast('⚠️ स्टोरेज भर गया! बैकअप लें और पुरानी फोटो छोटी करें।'); } }; now?f():saveT=setTimeout(f,250); }
load();

/* ---------------- स्वचालित खाता-गणना (Ledger) ---------------- */
function ledger(){
  const set=S.settings; const mem={}; const msum={};
  S.members.forEach(m=>{
    const L={savings:+m.openSavings||0, all:[], intArrear:0, rows:[],
      t:{kist:0,interest:0,principal:0,fine:0,loan:0,openSavings:+m.openSavings||0}};
    if(+m.openLoan>0){ L.all.push({id:'open-'+m.id,amount:+m.openLoan,rate:+m.openLoanRate||set.rate,balance:+m.openLoan,date:m.joinDate||'',purpose:'पुराना बकाया ऋण (शुरुआती)',mid:null}); L.t.loan+=+m.openLoan; }
    mem[m.id]=L;
  });
  let cash=+set.openCash||0;
  const ms=S.meetings.filter(m=>m.status!=='scheduled').sort(byDate);
  for(const mt of ms){
    const sum={kist:0,interest:0,principal:0,fine:0,loan:0,exp:0,opening:cash,loanCount:0,present:0,count:0,intDue:0,rows:{}};
    for(const m of S.members){
      const L=mem[m.id], e=mt.entries&&mt.entries[m.id];
      if(!e && (m.joinDate||'')>mt.date) continue;
      if(!e && m.left && m.left<=mt.date) continue;
      const E=e||{};
      const act=L.all.filter(l=>l.balance>0.001);
      const prev=act.reduce((a,l)=>a+l.balance,0);
      const intCur=Math.round(act.reduce((a,l)=>a+l.balance*l.rate/100,0));
      const intDue=intCur+L.intArrear;
      const kist=+E.kist||0, interest=+E.interest||0, fine=+E.fine||0;
      const principal=Math.min(+E.principal||0,prev);
      L.intArrear=Math.max(0,intDue-interest);
      let p=principal; for(const l of act){ if(p<=0)break; const d=Math.min(p,l.balance); l.balance-=d; p-=d; }
      const nl=+E.newLoan||0, rate=E.loanRate!=null&&E.loanRate!==''?+E.loanRate:set.rate;
      if(nl>0){ L.all.push({id:mt.id+'-'+m.id,amount:nl,rate,balance:nl,date:mt.date,purpose:E.purpose||'',mid:mt.id}); }
      L.savings+=kist;
      Object.assign(L.t,{kist:L.t.kist+kist,interest:L.t.interest+interest,principal:L.t.principal+principal,fine:L.t.fine+fine,loan:L.t.loan+nl});
      const bal=L.all.reduce((a,l)=>a+l.balance,0);
      const row={mid:mt.id,date:mt.date,present:!!e&&E.present!==false,kist,savings:L.savings,prev,intCur,intDue,interest,principal,fine,newLoan:nl,rate,purpose:E.purpose||'',bal,intArrear:L.intArrear,
        paid:kist+interest+principal+fine};
      L.rows.push(row); sum.rows[m.id]=row; sum.count++;
      if(row.present) sum.present++;
      sum.kist+=kist; sum.interest+=interest; sum.principal+=principal; sum.fine+=fine; sum.loan+=nl; sum.intDue+=intDue; if(nl>0) sum.loanCount++;
    }
    sum.exp=(mt.expenses||[]).reduce((a,x)=>a+(+x.amt||0),0);
    sum.collected=sum.kist+sum.interest+sum.principal+sum.fine;
    sum.available=cash+sum.collected;
    cash=sum.available-sum.loan-sum.exp; sum.closing=cash;
    msum[mt.id]=sum;
  }
  // वर्तमान स्थिति + अगले माह का देय ब्याज
  const T={savings:0,outstanding:0,interest:0,fine:0,loanGiven:0,principal:0,exp:0,borrowers:0,kist:0,intArrear:0,nextInt:0};
  S.members.forEach(m=>{ const L=mem[m.id]; L.active=L.all.filter(l=>l.balance>0.001); L.bal=L.active.reduce((a,l)=>a+l.balance,0);
    L.nextInt=Math.round(L.active.reduce((a,l)=>a+l.balance*l.rate/100,0))+L.intArrear;
    T.savings+=L.savings; T.outstanding+=L.bal; T.interest+=L.t.interest; T.fine+=L.t.fine; T.loanGiven+=L.t.loan; T.principal+=L.t.principal; T.kist+=L.t.kist; T.intArrear+=L.intArrear; T.nextInt+=L.nextInt;
    if(L.bal>0) T.borrowers++; });
  T.exp=Object.values(msum).reduce((a,s)=>a+s.exp,0);
  T.cash=cash; T.corpus=cash+T.outstanding;
  return {mem,msum,T};
}

/* ---------------- UI सहायक ---------------- */
function toast(t){ const el=$('#toast'); el.textContent=t; el.classList.add('show'); clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),2600); }
function openModal(html){ $('#sheet').innerHTML=html; $('#modal').hidden=false; document.body.style.overflow='hidden'; }
function closeModal(){ $('#modal').hidden=true; $('#sheet').innerHTML=''; document.body.style.overflow=''; }
$('#modal').addEventListener('click',e=>{ if(e.target.id==='modal'||e.target.closest('[data-close]')) closeModal(); });
function busy(on,t){ $('#busy').hidden=!on; if(t) $('#busyText').textContent=t; }
function av(m,cls){ return m&&m.photo?`<img class="av ${cls||''}" src="${m.photo}" alt="">`:`<div class="av ${cls||''}">${esc(initials(m&&m.name))}</div>`; }
function confirmBox(msg,yesText,cb,danger){
  openModal(`<h3>पुष्टि करें<button class="x" data-close>✕</button></h3><p>${msg}</p>
   <div class="row"><button class="btn sec f1" data-close>रद्द करें</button><button class="btn ${danger?'bad':''} f1" id="cfYes">${yesText}</button></div>`);
  $('#cfYes').onclick=()=>{ closeModal(); cb(); };
}
function memberById(id){ return S.members.find(m=>m.id===id); }
function activeMembers(){ return S.members.filter(m=>!m.left).sort((a,b)=>a.roll-b.roll); }
function readPhoto(file,size){
  return new Promise(res=>{ if(!file) return res('');
    const r=new FileReader(); r.onload=()=>{ const img=new Image(); img.onload=()=>{
      const c=document.createElement('canvas'); const s=size||220; const k=Math.min(1,s/Math.min(img.width,img.height));
      const w=Math.round(img.width*k),h=Math.round(img.height*k); const side=Math.min(w,h);
      c.width=side;c.height=side; const x=c.getContext('2d'); x.fillStyle='#fff'; x.fillRect(0,0,side,side);
      x.drawImage(img,(side-w)/2,(side-h)/2,w,h); res(c.toDataURL('image/jpeg',0.8)); }; img.onerror=()=>res(''); img.src=r.result; };
    r.readAsDataURL(file); });
}
function download(blob,name){ const u=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=u; a.download=name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),60000); }
function waLink(text,mobile){ const n=mobile?String(mobile).replace(/\D/g,'').slice(-10):''; return 'https://wa.me/'+(n?'91'+n:'')+'?text='+encodeURIComponent(text); }
function openUrl(u){ const w=window.open(u,'_blank'); if(!w) location.href=u; }

/* ---------------- हेडर / नेविगेशन ---------------- */
function paintTop(){
  const s=S.settings; $('#topName').textContent=s.name||'महिला समूह';
  $('#topSub').textContent=s.village||'बचत एवं ऋण प्रबंधन';
  const lg=$('#topLogo'); if(s.logo){ lg.src=s.logo; lg.style.display=''; } else lg.style.display='none';
}
let route={v:'home'};
function parseHash(){ const h=(location.hash||'#home').slice(1).split('/'); return {v:h[0]||'home',id:h[1]}; }
function go(h){ if(location.hash==='#'+h) render(); else location.hash=h; }
window.addEventListener('hashchange',render);
$('#backBtn').onclick=()=>history.length>1?history.back():go('home');
$('#settingsBtn').onclick=()=>go('settings');

function render(){
  route=parseHash(); paintTop();
  const top=['home','members','meetings','loans','reports'];
  document.querySelectorAll('[data-nav]').forEach(a=>a.classList.toggle('on',a.dataset.nav===route.v));
  $('#backBtn').hidden=top.includes(route.v);
  const app=$('#app'); app.onclick=null; app.oninput=null; app.onchange=null;
  if(!S.setupDone && route.v!=='settings'){ return renderWelcome(app); }
  const fn={home:renderHome,members:renderMembers,member:renderPassbook,meetings:renderMeetings,meeting:renderRegister,loans:renderLoans,reports:renderReports,settings:renderSettings}[route.v]||renderHome;
  fn(app); window.scrollTo(0,0);
}

/* ---------------- स्वागत ---------------- */
function renderWelcome(app){
  app.innerHTML=`<div class="card hero"><div style="font-size:54px">👩‍👩‍👧‍👧</div><div><h1>नमस्ते! 🙏</h1><p>महिला स्वयं सहायता समूह का पूरा हिसाब – बचत, ऋण, ब्याज, पासबुक और PDF रिपोर्ट – अब एक ऐप में, बिना इंटरनेट के।</p></div></div>
  <div class="card"><b>शुरू करने के 3 आसान कदम</b><ol class="small" style="line-height:1.9;padding-left:18px">
   <li>समूह का नाम, लोगो, किस्त विकल्प और ब्याज दर सेट करें</li><li>सदस्य जोड़ें (फोटो, नाम, मोबाइल, पता) – 100 तक</li><li>कैलेंडर में बैठक तय करें, किस्त-ब्याज-ऋण भरें – बाकी सब स्वचालित</li></ol>
   <button class="btn wide" onclick="go('settings')">✨ समूह सेटअप शुरू करें</button>
   <button class="btn sec wide" style="margin-top:8px" onclick="loadDemo()">🧪 डेमो डेटा के साथ देखें</button>
   <button class="btn ghost wide" style="margin-top:8px" onclick="restorePick()">📂 पुराना बैकअप वापस लाएँ</button></div>`;
}

/* ---------------- डैशबोर्ड ---------------- */
function renderHome(app){
  const {T,msum}=ledger(); const s=S.settings; const am=activeMembers();
  const up=S.meetings.filter(m=>m.status!=='closed').sort(byDate)[0];
  const done=S.meetings.filter(m=>m.status!=='scheduled').sort(byDate);
  const last6=done.slice(-6);
  const mx=Math.max(1,...last6.map(m=>msum[m.id].collected));
  app.innerHTML=`
  <div class="card hero">${s.logo?`<img src="${s.logo}">`:'<div style="font-size:50px">🌸</div>'}
    <div><h1>${esc(s.name||'महिला समूह')}</h1><p>${esc(s.tagline||'')}</p><p class="small">👩 ${am.length} सदस्य • 💰 ${s.rate}% मासिक ब्याज</p></div></div>
  <div class="grid">
    <div class="stat" style="--c:#1e8e5a"><small>कुल बचत (किस्त)</small><b>${rs(T.savings)}</b></div>
    <div class="stat" style="--c:#c0392b"><small>सक्रिय ऋण (बकाया)</small><b>${rs(T.outstanding)}</b></div>
    <div class="stat" style="--c:#f39c12"><small>ब्याज आय</small><b>${rs(T.interest)}</b></div>
    <div class="stat" style="--c:#2463b0"><small>तिजोरी/बैंक में नकद</small><b>${rs(T.cash)}</b></div>
    <div class="stat"><small>समूह की कुल पूँजी</small><b>${rs(T.corpus)}</b></div>
    <div class="stat" style="--c:#7d3c98"><small>ऋणी महिलाएँ</small><b>${T.borrowers} / ${am.length}</b></div>
  </div>
  <h2>⚡ त्वरित कार्य</h2>
  <div class="qa">
    <button onclick="memberForm()"><span>➕</span>सदस्य जोड़ें</button>
    <button onclick="startMeetingQuick()"><span>📝</span>बैठक एंट्री</button>
    <button onclick="loanForm()"><span>💸</span>ऋण दें</button>
    <button onclick="go('reports')"><span>📄</span>PDF रिपोर्ट</button>
  </div>
  <h2>📅 ${up?(up.status==='open'?'चालू बैठक':'अगली बैठक'):'बैठक'}</h2>
  ${up?`<div class="card row"><div class="f1"><b>${fmtD(up.date)}</b> <span class="tag ${up.status==='open'?'acc':'info'}">${up.status==='open'?'एंट्री चालू':'तय'}</span>
     <div class="small muted">${WD[new Date(up.date).getDay()]}वार • ${daysLeft(up.date)}</div></div>
     <button class="btn sm" onclick="go('meeting/${up.id}')">${up.status==='open'?'एंट्री भरें':'खोलें'}</button></div>`
   :`<div class="card row"><div class="f1 muted">कोई बैठक तय नहीं है</div><button class="btn sm" onclick="go('meetings')">कैलेंडर खोलें</button></div>`}
  <h2>📊 पिछली बैठकों में कुल जमा</h2>
  <div class="card">${last6.length?`<div class="bars">${last6.map(m=>`<div class="b"><em>${shortRs(msum[m.id].collected)}</em><div style="height:${Math.max(3,msum[m.id].collected/mx*100)}%"></div>${HM[+m.date.slice(5,7)-1].slice(0,3)}</div>`).join('')}</div>`:'<div class="muted small">अभी कोई बैठक दर्ज नहीं हुई</div>'}</div>
  <h2>💡 अगली बैठक में अनुमानित वसूली</h2>
  <div class="card kv"><span>किस्त (${am.length} सदस्य)</span><b>${rs(am.reduce((a,m)=>a+(+m.kist||s.defaultKist),0))}</b>
    <span>देय ब्याज (बकाया सहित)</span><b>${rs(T.nextInt)}</b>
    <span>पिछला ब्याज बकाया</span><b style="color:var(--bad)">${rs(T.intArrear)}</b></div>`;
}
const shortRs=n=>n>=100000?(n/100000).toFixed(1)+'L':n>=1000?(n/1000).toFixed(1)+'k':Math.round(n);
function daysLeft(d){ const diff=Math.round((new Date(d)-new Date(today()))/86400000); return diff===0?'आज':diff>0?diff+' दिन बाकी':Math.abs(diff)+' दिन पहले'; }

/* ---------------- सदस्य ---------------- */
let mFilter='all', mQuery='';
function renderMembers(app){
  const {mem}=ledger(); const all=S.members.slice().sort((a,b)=>a.roll-b.roll);
  app.innerHTML=`<h2>👩‍👩‍👧 सदस्य <span class="tag">${activeMembers().length}/${MAX_MEMBERS}</span><span class="sp"></span><button class="btn sm" onclick="memberForm()">➕ जोड़ें</button></h2>
   <input class="search" id="mq" placeholder="🔍 नाम, क्रमांक या मोबाइल से खोजें…" value="${esc(mQuery)}">
   <div class="chips" style="margin-bottom:10px">${[['all','सभी'],['loan','ऋणी'],['noloan','बिना ऋण'],['left','निष्क्रिय']].map(([k,t])=>`<button class="chip ${mFilter===k?'on':''}" data-f="${k}">${t}</button>`).join('')}</div>
   <div class="card list" id="mlist"></div><button class="fab" onclick="memberForm()">+</button>`;
  const paint=()=>{
    const q=mQuery.trim().toLowerCase();
    const list=all.filter(m=>{ const L=mem[m.id];
      if(mFilter==='left'?!m.left:m.left) return false;
      if(mFilter==='loan'&&!(L.bal>0)) return false; if(mFilter==='noloan'&&L.bal>0) return false;
      return !q||(m.name||'').toLowerCase().includes(q)||String(m.roll)===q||(m.mobile||'').includes(q); });
    $('#mlist').innerHTML=list.length?list.map(m=>{ const L=mem[m.id]; return `<div class="item" data-id="${m.id}">${av(m)}
      <div class="mid"><b>${m.roll}. ${esc(m.name)} ${m.role&&m.role!=='सदस्य'?`<span class="tag acc">${esc(m.role)}</span>`:''}</b><span class="small muted">📞 ${esc(m.mobile)} • किस्त ${rs(m.kist||S.settings.defaultKist)}</span></div>
      <div class="end"><div style="color:var(--ok)">बचत ${rs(L.savings)}</div>${L.bal>0?`<div style="color:var(--bad)">ऋण ${rs(L.bal)}</div>`:'<div class="muted small">ऋण नहीं</div>'}</div></div>`; }).join('')
      :`<div class="empty"><div>👩</div>${S.members.length?'कोई सदस्य नहीं मिला':'अभी कोई सदस्य नहीं जोड़ा गया'}</div>`;
  };
  paint();
  $('#mq').oninput=e=>{ mQuery=e.target.value; paint(); };
  app.onclick=e=>{ const c=e.target.closest('[data-f]'); if(c){ mFilter=c.dataset.f; renderMembers(app); return; }
    const it=e.target.closest('.item[data-id]'); if(it) go('member/'+it.dataset.id); };
}

function memberForm(id){
  const m=id?memberById(id):null; const s=S.settings;
  if(!m && activeMembers().length>=MAX_MEMBERS) return toast('अधिकतम '+MAX_MEMBERS+' सदस्य जोड़े जा सकते हैं');
  let photo=m?m.photo:'';
  openModal(`<h3>${m?'✏️ सदस्य विवरण बदलें':'➕ नई महिला सदस्य'}<button class="x" data-close>✕</button></h3>
   <div class="photopick"><div id="pp">${av({photo,name:m&&m.name})}</div><div>
     <label class="btn sm sec">📷 फोटो चुनें<input type="file" accept="image/*" id="pf" hidden></label>
     <div class="small muted" style="margin-top:4px">कैमरा या गैलरी से</div></div></div>
   <label class="fl">महिला का पूरा नाम <span class="req">*</span><input id="f_name" value="${esc(m&&m.name)}" placeholder="जैसे: सरोज देवी"></label>
   <label class="fl">मोबाइल नंबर <span class="req">*</span><input id="f_mob" inputmode="numeric" maxlength="10" value="${esc(m&&m.mobile)}" placeholder="10 अंकों का नंबर"></label>
   <label class="fl">पता <span class="req">*</span><textarea id="f_addr" rows="2" placeholder="गाँव, वार्ड, पंचायत">${esc(m&&m.address)}</textarea></label>
   <div class="two"><label class="fl">पति / पिता का नाम<input id="f_rel" value="${esc(m&&m.relative)}"></label>
     <label class="fl">समूह में पद<select id="f_role">${ROLES.map(r=>`<option ${m&&m.role===r?'selected':''}>${r}</option>`).join('')}</select></label></div>
   <div class="two"><label class="fl">सदस्यता तिथि<input type="date" id="f_join" value="${m?m.joinDate:today()}"></label>
     <label class="fl">मासिक किस्त<select id="f_kist">${s.kistOptions.map(k=>`<option value="${k}" ${(m?+m.kist:s.defaultKist)===k?'selected':''}>${rs(k)}</option>`).join('')}</select></label></div>
   <label class="fl">नॉमिनी (वारिस) का नाम<input id="f_nom" value="${esc(m&&m.nominee)}"></label>
   <details ${m&&(m.openSavings||m.openLoan)?'open':''}><summary class="small" style="color:var(--p);font-weight:600;margin-bottom:10px">पुराने रजिस्टर से शुरुआती शेष (वैकल्पिक)</summary>
   <div class="two"><label class="fl">पुरानी बचत ₹<input type="number" id="f_os" value="${m?m.openSavings||'':''}"></label>
     <label class="fl">पुराना बकाया ऋण ₹<input type="number" id="f_ol" value="${m?m.openLoan||'':''}"></label></div>
   <label class="fl">पुराने ऋण पर ब्याज %<input type="number" step="0.1" id="f_olr" value="${m?m.openLoanRate||s.rate:s.rate}"></label></details>
   <div class="row" style="margin-top:6px">${m?`<button class="btn bad sm" id="mDel">🗑️</button><button class="btn sec sm" id="mLeft">${m.left?'↩️ सक्रिय करें':'🚪 निष्क्रिय'}</button>`:''}
    <button class="btn f1" id="mSave">💾 सेव करें</button></div>`);
  $('#pf').onchange=async e=>{ photo=await readPhoto(e.target.files[0]); $('#pp').innerHTML=av({photo}); };
  $('#mSave').onclick=()=>{
    const name=$('#f_name').value.trim(), mob=$('#f_mob').value.replace(/\D/g,''), addr=$('#f_addr').value.trim();
    if(!name) return toast('नाम आवश्यक है'); if(mob.length!==10) return toast('10 अंकों का सही मोबाइल नंबर डालें'); if(!addr) return toast('पता आवश्यक है');
    if(S.members.some(x=>x.mobile===mob&&(!m||x.id!==m.id))) return toast('यह मोबाइल नंबर पहले से किसी सदस्य का है');
    const d={name,mobile:mob,address:addr,relative:$('#f_rel').value.trim(),role:$('#f_role').value,joinDate:$('#f_join').value||today(),
      kist:+$('#f_kist').value,nominee:$('#f_nom').value.trim(),openSavings:num($('#f_os').value),openLoan:num($('#f_ol').value),openLoanRate:+$('#f_olr').value||s.rate,photo};
    if(m) Object.assign(m,d); else S.members.push(Object.assign({id:uid(),roll:S.nextRoll++,created:Date.now()},d));
    // खुली बैठक में नई सदस्य की एंट्री स्वतः
    if(!m) S.meetings.filter(x=>x.status==='open'&&x.date>=d.joinDate).forEach(x=>prefillMeeting(x,true));
    save(true); closeModal(); toast(m?'विवरण अपडेट हुआ ✅':name+' को समूह में जोड़ा गया ✅'); render();
  };
  if(m){
    $('#mDel').onclick=()=>confirmBox(`<b>${esc(m.name)}</b> को स्थायी रूप से हटाएँ? उसकी सारी बैठक प्रविष्टियाँ भी हट जाएँगी।<br><small class="muted">सुझाव: हटाने की बजाय "निष्क्रिय" करें ताकि पुराना हिसाब सुरक्षित रहे।</small>`,'हाँ, हटाएँ',()=>{
      S.members=S.members.filter(x=>x.id!==m.id); S.meetings.forEach(x=>{ if(x.entries) delete x.entries[m.id]; }); save(true); toast('सदस्य हटा दिया गया'); go('members'); },true);
    $('#mLeft').onclick=()=>{ m.left=m.left?'':today(); save(true); closeModal(); toast(m.left?'सदस्य निष्क्रिय किया गया':'सदस्य फिर से सक्रिय'); render(); };
  }
}

/* ---------------- पासबुक ---------------- */
function renderPassbook(app){
  const m=memberById(route.id); if(!m) return go('members');
  const {mem}=ledger(); const L=mem[m.id];
  app.innerHTML=`<div class="card" style="display:flex;gap:14px;align-items:center">${av(m,'lg')}
    <div style="flex:1;min-width:0"><div style="font-size:19px;font-weight:700">${esc(m.name)}</div>
    <div class="small muted">क्रमांक ${m.roll} • ${esc(m.role||'सदस्य')} ${m.left?'<span class="tag bad">निष्क्रिय</span>':''}</div>
    <div class="small">📞 ${esc(m.mobile)}</div><div class="small muted">📍 ${esc(m.address)}</div>
    ${m.relative?`<div class="small muted">पति/पिता: ${esc(m.relative)}</div>`:''}</div></div>
   <div class="row" style="margin-bottom:12px"><button class="btn sm sec" onclick="memberForm('${m.id}')">✏️ बदलें</button>
     <a class="btn sm sec" href="tel:${esc(m.mobile)}" style="text-decoration:none">📞 कॉल</a>
     <button class="btn sm ok" onclick="sharePassbookWA('${m.id}')">🟢 WhatsApp</button>
     <button class="btn sm" onclick="pdfPassbook('${m.id}')">📄 पासबुक PDF</button></div>
   <div class="grid">
    <div class="stat" style="--c:#1e8e5a"><small>कुल बचत</small><b>${rs(L.savings)}</b></div>
    <div class="stat" style="--c:#c0392b"><small>वर्तमान बकाया ऋण</small><b>${rs(L.bal)}</b></div>
    <div class="stat" style="--c:#7d3c98"><small>कुल ऋण लिया</small><b>${rs(L.t.loan)}</b></div>
    <div class="stat" style="--c:#2463b0"><small>मूलधन वापस किया</small><b>${rs(L.t.principal)}</b></div>
    <div class="stat" style="--c:#f39c12"><small>कुल ब्याज भरा</small><b>${rs(L.t.interest)}</b></div>
    <div class="stat"><small>अगले माह देय ब्याज</small><b>${rs(L.nextInt)}</b></div>
   </div>
   ${L.intArrear>0?`<div class="note bad">⚠️ ब्याज बकाया: ${rs(L.intArrear)} (अगली बैठक में देय ब्याज में जुड़ जाएगा)</div>`:''}
   ${L.t.fine?`<div class="note">जुर्माना भरा: ${rs(L.t.fine)}</div>`:''}
   <h2>💰 ऋण खाते</h2>
   ${L.all.length?`<div class="tw"><table class="t"><tr><th>तारीख</th><th>उद्देश्य</th><th>ऋण</th><th>दर</th><th>शेष</th><th>स्थिति</th></tr>
     ${L.all.map(l=>`<tr><td class="l">${fmtS(l.date)}</td><td class="l">${esc(l.purpose||'-')}</td><td>${rs(l.amount)}</td><td>${l.rate}%</td><td>${rs(l.balance)}</td><td>${l.balance>0.001?'<span class="tag bad">चालू</span>':'<span class="tag ok">चुकता</span>'}</td></tr>`).join('')}</table></div>`
     :'<div class="card muted small">कोई ऋण नहीं लिया</div>'}
   <h2>📒 पासबुक (बैठकवार हिसाब)</h2>
   ${L.rows.length?`<div class="tw"><table class="t"><tr><th>तारीख</th><th>किस्त</th><th>कुल बचत</th><th>पिछला ऋण</th><th>ब्याज</th><th>मूलधन वापस</th><th>नया ऋण</th><th>शेष ऋण</th><th>जुर्माना</th></tr>
     ${(+m.openSavings||+m.openLoan)?`<tr><td class="l">शुरुआती</td><td>-</td><td>${rs(m.openSavings)}</td><td>-</td><td>-</td><td>-</td><td>${rs(m.openLoan)}</td><td>${rs(m.openLoan)}</td><td>-</td></tr>`:''}
     ${L.rows.map(r=>`<tr><td class="l">${fmtS(r.date)}${r.present?'':' <small>(अनु.)</small>'}</td><td>${rs(r.kist)}</td><td>${rs(r.savings)}</td><td>${rs(r.prev)}</td><td>${rs(r.interest)}${r.interest<r.intDue?` <small style="color:var(--bad)">/${rs(r.intDue)}</small>`:''}</td><td>${rs(r.principal)}</td><td>${r.newLoan?rs(r.newLoan)+' @'+r.rate+'%':'-'}</td><td><b>${rs(r.bal)}</b></td><td>${r.fine?rs(r.fine):'-'}</td></tr>`).join('')}
     <tr class="tot"><td class="l">कुल</td><td>${rs(L.t.kist)}</td><td>${rs(L.savings)}</td><td></td><td>${rs(L.t.interest)}</td><td>${rs(L.t.principal)}</td><td>${rs(L.t.loan-(+m.openLoan||0))}</td><td>${rs(L.bal)}</td><td>${rs(L.t.fine)}</td></tr></table></div>`
     :'<div class="card muted small">अभी कोई बैठक प्रविष्टि नहीं</div>'}
   <p class="small muted">लाल छोटे अंक = उस बैठक का देय ब्याज (कम भरने पर बकाया आगे जुड़ता है)। नॉमिनी: ${esc(m.nominee||'-')}</p>`;
}
function sharePassbookWA(id){
  const m=memberById(id); const L=ledger().mem[id]; const s=S.settings;
  const last=L.rows[L.rows.length-1];
  const t=`*${s.name||'महिला समूह'}*\n📒 पासबुक – ${m.name} (क्र. ${m.roll})\n\n💚 कुल बचत: ${rs(L.savings)}\n💸 कुल ऋण लिया: ${rs(L.t.loan)}\n↩️ मूलधन वापस: ${rs(L.t.principal)}\n💰 कुल ब्याज भरा: ${rs(L.t.interest)}\n🔴 वर्तमान बकाया ऋण: ${rs(L.bal)}\n📅 अगले माह देय ब्याज: ${rs(L.nextInt)}`+
   (last?`\n\nपिछली बैठक (${fmtD(last.date)}): किस्त ${rs(last.kist)}, ब्याज ${rs(last.interest)}, वापसी ${rs(last.principal)}${last.newLoan?', नया ऋण '+rs(last.newLoan):''}`:'');
  openUrl(waLink(t,m.mobile));
}

/* ---------------- बैठक व कैलेंडर ---------------- */
let calY=new Date().getFullYear(), calM=new Date().getMonth();
function renderMeetings(app){
  const {msum}=ledger();
  const first=new Date(calY,calM,1), start=first.getDay(), dim=new Date(calY,calM+1,0).getDate();
  const byDay={}; S.meetings.forEach(m=>{ byDay[m.date]=m; });
  let cells=WD.map(w=>`<div class="wd">${w}</div>`).join('');
  for(let i=0;i<start;i++) cells+='<div class="d o"></div>';
  for(let d=1;d<=dim;d++){ const ds=calY+'-'+pad(calM+1)+'-'+pad(d); const m=byDay[ds];
    cells+=`<div class="d ${ds===today()?'today':''} ${m?'has '+(m.status==='scheduled'?'sch':m.status==='closed'?'cl':''):''}" data-d="${ds}">${d}${m?'<i>बैठक</i>':''}</div>`; }
  const list=S.meetings.slice().sort(byDate).reverse();
  app.innerHTML=`<h2>📅 बैठक कैलेंडर<span class="sp"></span><button class="btn sm sec" onclick="scheduleSeries()">🔁 मासिक तय करें</button></h2>
   <div class="card"><div class="cal-head"><button class="btn sm sec" id="cp">◀</button><b>${HM[calM]} ${calY}</b><button class="btn sm sec" id="cn">▶</button></div>
    <div class="cal">${cells}</div>
    <div class="legend"><span style="--c:var(--info)">तय</span><span style="--c:var(--p)">एंट्री चालू</span><span style="--c:var(--ok)">संपन्न</span><span style="--c:var(--acc)">आज (बॉर्डर)</span></div>
    <div class="small muted" style="margin-top:6px">किसी भी तारीख पर टैप करके बैठक तय करें</div></div>
   <div class="row" style="margin-bottom:6px"><button class="btn f1" onclick="meetingForm(today())">➕ नई बैठक</button><button class="btn sec" onclick="exportICS()">📲 फोन कैलेंडर</button></div>
   <h2>🗂️ सभी बैठकें (${S.meetings.length})</h2>
   <div class="card list">${list.length?list.map(m=>{ const s=msum[m.id]; return `<div class="item" data-mid="${m.id}"><div class="av" style="border-radius:14px;font-size:13px;line-height:1.1;text-align:center">${+m.date.slice(8)}<br>${HM[+m.date.slice(5,7)-1].slice(0,3)}</div>
     <div class="mid"><b>${fmtD(m.date)} ${m.title?'– '+esc(m.title):''}</b><span class="small">${m.status==='scheduled'?'<span class="tag info">तय</span> '+daysLeft(m.date):m.status==='open'?'<span class="tag acc">एंट्री चालू</span>':'<span class="tag ok">संपन्न</span>'} ${s?` उपस्थित ${s.present}/${s.count}`:''}</span></div>
     <div class="end">${s?`<div style="color:var(--ok)">जमा ${rs(s.collected)}</div><div style="color:var(--bad)">ऋण ${rs(s.loan)}</div>`:''}</div></div>`; }).join(''):'<div class="empty"><div>📅</div>अभी कोई बैठक नहीं</div>'}</div>`;
  $('#cp').onclick=()=>{ if(--calM<0){calM=11;calY--;} renderMeetings(app); };
  $('#cn').onclick=()=>{ if(++calM>11){calM=0;calY++;} renderMeetings(app); };
  app.onclick=e=>{ const d=e.target.closest('[data-d]'); if(d){ const m=byDay[d.dataset.d]; m?go('meeting/'+m.id):meetingForm(d.dataset.d); return; }
    const it=e.target.closest('[data-mid]'); if(it) go('meeting/'+it.dataset.mid); };
}
function meetingForm(date,id){
  const m=id?S.meetings.find(x=>x.id===id):null;
  openModal(`<h3>${m?'✏️ बैठक बदलें':'📅 बैठक तय करें'}<button class="x" data-close>✕</button></h3>
    <label class="fl">बैठक की तारीख<input type="date" id="b_d" value="${m?m.date:date}"></label>
    <label class="fl">समय<input type="time" id="b_t" value="${m?m.time||'11:00':'11:00'}"></label>
    <label class="fl">विषय / नोट (वैकल्पिक)<input id="b_n" value="${esc(m&&m.title)}" placeholder="जैसे: मासिक बैठक, ऋण वितरण"></label>
    <label class="fl">स्थान<input id="b_p" value="${esc(m?m.place:S.settings.village)}"></label>
    ${m?`<div class="row"><button class="btn bad sm" id="bDel">🗑️ हटाएँ</button><button class="btn f1" id="bSave">💾 सेव</button></div>`
      :`<div class="row"><button class="btn sec f1" id="bSch">📌 केवल तय करें</button><button class="btn f1" id="bStart">▶️ अभी एंट्री शुरू</button></div>`}`);
  const read=()=>({date:$('#b_d').value,time:$('#b_t').value,title:$('#b_n').value.trim(),place:$('#b_p').value.trim()});
  const dupe=d=>S.meetings.some(x=>x.date===d&&(!m||x.id!==m.id));
  if(m){
    $('#bSave').onclick=()=>{ const d=read(); if(!d.date) return; if(dupe(d.date)) return toast('इस तारीख पर पहले से बैठक है'); Object.assign(m,d); save(true); closeModal(); render(); };
    $('#bDel').onclick=()=>confirmBox('यह बैठक और इसकी सारी प्रविष्टियाँ (किस्त, ब्याज, ऋण) हटाएँ?','हटाएँ',()=>{ S.meetings=S.meetings.filter(x=>x.id!==m.id); save(true); toast('बैठक हटाई गई'); go('meetings'); },true);
  } else {
    const mk=st=>{ const d=read(); if(!d.date) return toast('तारीख चुनें'); if(dupe(d.date)) return toast('इस तारीख पर पहले से बैठक है');
      const mt=Object.assign({id:uid(),created:Date.now(),status:'scheduled',entries:{},expenses:[]},d);
      S.meetings.push(mt); if(st) startMeeting(mt); save(true); closeModal(); toast(st?'बैठक शुरू – एंट्री भरें':'बैठक तय की गई 📌'); st?go('meeting/'+mt.id):render(); };
    $('#bSch').onclick=()=>mk(false); $('#bStart').onclick=()=>mk(true);
  }
}
function scheduleSeries(){
  openModal(`<h3>🔁 हर महीने की बैठक तय करें<button class="x" data-close>✕</button></h3>
    <div class="two"><label class="fl">हर महीने की तारीख<input type="number" id="s_day" min="1" max="28" value="${S.settings.meetDay||10}"></label>
    <label class="fl">कितने महीने<input type="number" id="s_n" min="1" max="24" value="12"></label></div>
    <label class="fl">शुरुआत किस महीने से<input type="month" id="s_from" value="${today().slice(0,7)}"></label>
    <div class="note">पहले से तय तारीखें छोड़ दी जाएँगी।</div><button class="btn wide" id="s_go">✅ तय करें</button>`);
  $('#s_go').onclick=()=>{ const day=Math.min(28,Math.max(1,+$('#s_day').value||10)), n=Math.min(24,+$('#s_n').value||12); let [y,mo]=$('#s_from').value.split('-').map(Number); let c=0;
    S.settings.meetDay=day;
    for(let i=0;i<n;i++){ const ds=y+'-'+pad(mo)+'-'+pad(day); if(!S.meetings.some(x=>x.date.slice(0,7)===ds.slice(0,7))){ S.meetings.push({id:uid(),created:Date.now()+i,date:ds,time:'11:00',title:'मासिक बैठक',place:S.settings.village,status:'scheduled',entries:{},expenses:[]}); c++; } if(++mo>12){mo=1;y++;} }
    save(true); closeModal(); toast(c+' बैठकें कैलेंडर में तय की गईं'); render(); };
}
function prefillMeeting(mt,onlyMissing){
  if(!S.settings.autofill && !onlyMissing) { activeMembers().forEach(m=>{ if((m.joinDate||'')<=mt.date && !mt.entries[m.id]) mt.entries[m.id]={present:true,kist:0,interest:0,principal:0,fine:0,newLoan:0}; }); return; }
  const {msum}=ledger(); const s=msum[mt.id];
  activeMembers().forEach(m=>{ if((m.joinDate||'')>mt.date) return; if(onlyMissing&&mt.entries[m.id]) return;
    const r=s&&s.rows[m.id]; mt.entries[m.id]={present:true,kist:+m.kist||S.settings.defaultKist,interest:r?r.intDue:0,principal:0,fine:0,newLoan:0,loanRate:S.settings.rate,purpose:''}; });
}
function startMeeting(mt){ mt.status='open'; mt.entries=mt.entries||{}; prefillMeeting(mt,false); }
function startMeetingQuick(){
  const open=S.meetings.find(m=>m.status==='open'); if(open) return go('meeting/'+open.id);
  const sch=S.meetings.filter(m=>m.status==='scheduled').sort(byDate)[0];
  if(sch && sch.date<=today()){ startMeeting(sch); save(true); return go('meeting/'+sch.id); }
  meetingForm(today());
}

/* ---------- बैठक रजिस्टर (मुख्य एंट्री स्क्रीन) ---------- */
let showAll=true;
function renderRegister(app){
  const mt=S.meetings.find(m=>m.id===route.id); if(!mt) return go('meetings');
  if(mt.status==='scheduled'){
    app.innerHTML=`<div class="card"><h2 style="margin-top:0">📌 ${fmtD(mt.date)} ${mt.time?'• '+mt.time:''}</h2><p class="muted">${esc(mt.title||'मासिक बैठक')} • ${esc(mt.place||'')}</p><p>${daysLeft(mt.date)}</p>
     <div class="row"><button class="btn f1" id="st">▶️ बैठक शुरू करें (एंट्री)</button><button class="btn sec" onclick="meetingForm('','${mt.id}')">✏️</button></div>
     <p class="small muted">शुरू करते ही सभी सदस्यों की किस्त और देय ब्याज स्वतः भर जाएगा, आप बदल सकते हैं।</p></div>`;
    $('#st').onclick=()=>{ startMeeting(mt); save(true); render(); }; return;
  }
  const lock=mt.status==='closed'; const set=S.settings;
  const L=ledger(); let sum=L.msum[mt.id];
  const ms=Object.keys(mt.entries||{}).map(memberById).filter(Boolean).sort((a,b)=>a.roll-b.roll);
  const missing=activeMembers().filter(m=>!mt.entries[m.id]&&(m.joinDate||'')<=mt.date);
  const kOpts=[0,...set.kistOptions];
  app.innerHTML=`<div class="card"><div class="row"><div class="f1"><b style="font-size:17px">📝 ${fmtD(mt.date)}</b> ${lock?'<span class="tag ok">संपन्न 🔒</span>':'<span class="tag acc">एंट्री चालू</span>'}
     <div class="small muted">${esc(mt.title||'मासिक बैठक')} ${mt.place?'• '+esc(mt.place):''}</div></div>
     <button class="btn sm sec" onclick="meetingForm('','${mt.id}')">✏️</button></div>
     ${!lock?`<div class="row" style="margin-top:10px"><button class="btn sm sec" data-act="allkist">✅ सभी की किस्त</button><button class="btn sm sec" data-act="allint">💰 सभी का देय ब्याज</button><button class="btn sm ghost" data-act="clear">🧹 खाली करें</button></div>`:''}
     ${missing.length&&!lock?`<div class="note" style="margin:10px 0 0">${missing.length} सदस्य इस बैठक में नहीं जुड़े हैं। <button class="btn sm" data-act="addmissing">जोड़ें</button></div>`:''}</div>
   <input class="search" id="rq" placeholder="🔍 सदस्य खोजें…">
   <div id="reg">${ms.map(m=>card(m)).join('')||'<div class="empty"><div>👩</div>पहले सदस्य जोड़ें</div>'}</div>
   <div class="card"><b>🧾 बैठक का खर्च</b>
     <div id="exps">${(mt.expenses||[]).map((x,i)=>`<div class="row" style="margin-top:6px"><span class="f1">${esc(x.desc)}</span><b>${rs(x.amt)}</b>${lock?'':`<button class="btn sm ghost" data-delexp="${i}">✕</button>`}</div>`).join('')||'<div class="small muted">कोई खर्च नहीं</div>'}</div>
     ${lock?'':`<div class="row" style="margin-top:8px"><input class="f1 search" style="margin:0" id="ex_d" placeholder="जैसे: चाय-नाश्ता, रजिस्टर"><input class="search" style="margin:0;width:110px" type="number" id="ex_a" placeholder="₹"><button class="btn sm" data-act="addexp">➕</button></div>`}</div>
   <div class="card" id="msumBox"></div>
   <div class="row" style="margin-bottom:10px"><button class="btn ok f1" data-act="wa">🟢 बैठक पर्ची WhatsApp</button><button class="btn f1" data-act="pdf">📄 रजिस्टर PDF</button></div>
   ${lock?`<button class="btn ghost wide" data-act="unlock">🔓 सुधार के लिए फिर से खोलें</button>`:`<button class="btn acc wide" data-act="close">🔒 बैठक संपन्न करें</button>`}
   <div class="stick" id="stick"></div>`;

  function card(m){
    const e=mt.entries[m.id], r=sum.rows[m.id]||{}; const dis=lock?'disabled':'';
    const custom=!kOpts.includes(+e.kist);
    return `<div class="mcard ${e.present===false?'abs':''}" data-m="${m.id}" data-name="${esc((m.name+' '+m.roll).toLowerCase())}">
     <div class="mh">${av(m)}<div class="nm"><b>${m.roll}. ${esc(m.name)}</b><span class="small muted">📞 ${esc(m.mobile)}</span></div>
      <span class="small muted">उपस्थित</span><label class="switch"><input type="checkbox" data-f="present" ${e.present!==false?'checked':''} ${dis}><span></span></label></div>
     <div class="mb">
      <div class="info"><span>पिछला ऋण: <b data-o="prev">${rs(r.prev)}</b></span><span>देय ब्याज: <b data-o="due">${rs(r.intDue)}</b>${r.intDue>r.intCur?` <small style="color:var(--bad)">(बकाया सहित)</small>`:''}</span><span>कुल बचत: <b data-o="sav">${rs(r.savings)}</b></span></div>
      <div class="chips">${kOpts.map(k=>`<button class="chip ${+e.kist===k?'on':''}" data-k="${k}" ${dis}>${k?rs(k):'नहीं दी'}</button>`).join('')}
        <input type="number" data-f="kist" value="${custom?e.kist:''}" placeholder="अन्य ₹" style="width:84px;border-radius:20px;border:1.5px solid var(--ln);padding:4px 10px" ${dis}></div>
      <div class="fgrid">
        <label>ब्याज जमा ₹<input type="number" data-f="interest" value="${e.interest||''}" ${dis}></label>
        <label>मूलधन वापस ₹<input type="number" data-f="principal" value="${e.principal||''}" ${dis}></label>
        <label>जुर्माना ₹<input type="number" data-f="fine" value="${e.fine||''}" ${dis}></label></div>
      <div class="loanbox"><div class="fgrid">
        <label>💸 नया ऋण ₹<input type="number" data-f="newLoan" value="${e.newLoan||''}" ${dis}></label>
        <label>ब्याज दर %<input type="number" step="0.1" data-f="loanRate" value="${e.loanRate!=null&&e.loanRate!==''?e.loanRate:set.rate}" ${dis}></label>
        <label>उद्देश्य<select data-f="purpose" ${dis}><option value="">—</option>${PURPOSES.map(p=>`<option ${e.purpose===p?'selected':''}>${p}</option>`).join('')}</select></label></div></div>
      <div class="res"><span>कुल जमा: <b data-o="paid">${rs(r.paid)}</b></span><span>नया शेष ऋण: <b data-o="bal">${rs(r.bal)}</b></span></div>
     </div></div>`;
  }
  function paintSum(){
    sum=ledger().msum[mt.id];
    $('#stick').innerHTML=`<div class="row"><span>उपस्थित <b>${sum.present}/${sum.count}</b></span><span>कुल जमा <b style="color:var(--ok)">${rs(sum.collected)}</b></span><span>ऋण <b style="color:var(--bad)">${rs(sum.loan)}</b></span><span>शेष <b style="color:var(--info)">${rs(sum.closing)}</b></span></div>`;
    $('#msumBox').innerHTML=`<b>📊 बैठक सारांश व रोकड़</b><div class="kv" style="margin-top:8px">
      <span>पिछला नकद शेष (तिजोरी/बैंक)</span><b>${rs(sum.opening)}</b>
      <span>+ बचत किस्त</span><b>${rs(sum.kist)}</b><span>+ ब्याज (${set.rate}% आदि)</span><b>${rs(sum.interest)}</b>
      <span>+ मूलधन वापसी</span><b>${rs(sum.principal)}</b><span>+ जुर्माना</span><b>${rs(sum.fine)}</b>
      <span><b>= ऋण हेतु उपलब्ध राशि</b></span><b style="color:var(--ok)">${rs(sum.available)}</b>
      <span>− नया ऋण वितरण (${sum.loanCount} महिलाएँ)</span><b style="color:var(--bad)">${rs(sum.loan)}</b>
      <span>− बैठक खर्च</span><b>${rs(sum.exp)}</b>
      <span><b>= बैठक के बाद नकद शेष</b></span><b style="color:var(--info)">${rs(sum.closing)}</b></div>
      ${sum.closing<0?'<div class="note bad" style="margin-top:8px">⚠️ उपलब्ध राशि से अधिक ऋण दिया गया है! कृपया ऋण राशि जाँचें।</div>':''}`;
  }
  function paintCard(mid){
    const r=sum.rows[mid]; const c=app.querySelector(`.mcard[data-m="${mid}"]`); if(!c||!r) return;
    const set_=(k,v)=>{ const o=c.querySelector(`[data-o="${k}"]`); if(o) o.textContent=v; };
    set_('prev',rs(r.prev)); set_('due',rs(r.intDue)); set_('sav',rs(r.savings)); set_('paid',rs(r.paid)); set_('bal',rs(r.bal));
    c.classList.toggle('abs',mt.entries[mid].present===false);
  }
  paintSum();
  $('#rq').oninput=e=>{ const q=e.target.value.trim().toLowerCase(); app.querySelectorAll('.mcard').forEach(c=>c.style.display=!q||c.dataset.name.includes(q)?'':'none'); };
  const upd=(el)=>{
    const c=el.closest('.mcard'); if(!c||lock) return; const mid=c.dataset.m, e=mt.entries[mid], f=el.dataset.f;
    if(f==='present'){ e.present=el.checked; if(!el.checked&&set.autofill){ /* अनुपस्थित: कुछ नहीं बदलें */ } }
    else if(f==='purpose') e.purpose=el.value;
    else if(f==='loanRate') e.loanRate=el.value===''?'':+el.value;
    else { e[f]=num(el.value); if(f==='kist') c.querySelectorAll('[data-k]').forEach(b=>b.classList.toggle('on',+b.dataset.k===e.kist)); }
    save(); paintSum(); paintCard(mid);
  };
  app.oninput=e=>{ if(e.target.dataset.f && e.target.type!=='checkbox' && e.target.tagName!=='SELECT') upd(e.target); };
  app.onchange=e=>{ if(e.target.dataset.f && (e.target.type==='checkbox'||e.target.tagName==='SELECT')) upd(e.target); };
  app.onclick=e=>{
    const k=e.target.closest('[data-k]'); if(k&&!lock){ const c=k.closest('.mcard'); const en=mt.entries[c.dataset.m]; en.kist=+k.dataset.k;
      c.querySelectorAll('[data-k]').forEach(b=>b.classList.toggle('on',b===k)); c.querySelector('input[data-f="kist"]').value=''; save(); paintSum(); paintCard(c.dataset.m); return; }
    const d=e.target.closest('[data-delexp]'); if(d){ mt.expenses.splice(+d.dataset.delexp,1); save(true); render(); return; }
    const a=e.target.closest('[data-act]'); if(!a) return; const act=a.dataset.act;
    if(act==='allkist'){ Object.keys(mt.entries).forEach(id=>{ const m=memberById(id); if(m&&mt.entries[id].present!==false) mt.entries[id].kist=+m.kist||set.defaultKist; }); save(true); render(); toast('सभी उपस्थित सदस्यों की किस्त भरी गई'); }
    if(act==='allint'){ const s=ledger().msum[mt.id]; Object.keys(mt.entries).forEach(id=>{ if(s.rows[id]) mt.entries[id].interest=s.rows[id].intDue; }); save(true); render(); toast('सभी का देय ब्याज स्वतः भरा गया'); }
    if(act==='clear') confirmBox('इस बैठक की सभी किस्त/ब्याज/वापसी/ऋण राशि खाली करें?','खाली करें',()=>{ Object.values(mt.entries).forEach(x=>Object.assign(x,{kist:0,interest:0,principal:0,fine:0,newLoan:0})); save(true); render(); },true);
    if(act==='addmissing'){ prefillMeeting(mt,true); save(true); render(); }
    if(act==='addexp'){ const ds=$('#ex_d').value.trim(), am=num($('#ex_a').value); if(!ds||!am) return toast('खर्च का विवरण और राशि डालें'); mt.expenses=mt.expenses||[]; mt.expenses.push({desc:ds,amt:am}); save(true); render(); }
    if(act==='wa') openUrl(waLink(meetingSlip(mt)));
    if(act==='pdf') pdfRegister(mt.id);
    if(act==='close'){ const s=ledger().msum[mt.id]; if(s.closing<0) return toast('⚠️ नकद शेष ऋणात्मक है – पहले ऋण राशि ठीक करें');
      confirmBox(`बैठक संपन्न करें?<br>कुल जमा <b>${rs(s.collected)}</b>, नया ऋण <b>${rs(s.loan)}</b>, शेष नकद <b>${rs(s.closing)}</b>`,'🔒 संपन्न करें',()=>{ mt.status='closed'; mt.closedAt=Date.now(); save(true); toast('बैठक संपन्न ✅ सभी पासबुक अपडेट हो गईं'); render(); }); }
    if(act==='unlock'){ mt.status='open'; save(true); render(); }
  };
}
function meetingSlip(mt){
  const L=ledger(); const s=L.msum[mt.id]; const set=S.settings;
  const loans=Object.entries(s.rows).filter(([,r])=>r.newLoan>0).map(([id,r])=>`   • ${memberById(id).name} – ${rs(r.newLoan)} @${r.rate}%${r.purpose?' ('+r.purpose+')':''}`);
  return `*${set.name||'महिला समूह'}*\n📝 बैठक पर्ची – ${fmtD(mt.date)}\n\n👩 उपस्थित: ${s.present}/${s.count}\n💚 बचत किस्त: ${rs(s.kist)}\n💰 ब्याज जमा: ${rs(s.interest)}\n↩️ मूलधन वापसी: ${rs(s.principal)}\n⚖️ जुर्माना: ${rs(s.fine)}\n*कुल जमा: ${rs(s.collected)}*\n\n💸 नया ऋण: ${rs(s.loan)} (${s.loanCount} महिलाएँ)\n${loans.join('\n')}\n🧾 खर्च: ${rs(s.exp)}\n\n🏦 बैठक के बाद नकद शेष: *${rs(s.closing)}*\n📊 समूह का कुल बकाया ऋण: ${rs(L.T.outstanding)}\n💼 समूह की कुल पूँजी: ${rs(L.T.corpus)}`;
}
function exportICS(){
  const ms=S.meetings.filter(m=>m.status!=='closed'); if(!ms.length) return toast('कोई आगामी बैठक नहीं');
  const ev=ms.map(m=>{ const t=(m.time||'11:00').replace(':',''); const d=m.date.replace(/-/g,'');
    return `BEGIN:VEVENT\r\nUID:${m.id}@mahilasamooh\r\nDTSTAMP:${d}T000000\r\nDTSTART:${d}T${t}00\r\nDURATION:PT2H\r\nSUMMARY:${S.settings.name||'महिला समूह'} – ${m.title||'मासिक बैठक'}\r\nLOCATION:${m.place||''}\r\nBEGIN:VALARM\r\nTRIGGER:-P1D\r\nACTION:DISPLAY\r\nDESCRIPTION:कल समूह बैठक है\r\nEND:VALARM\r\nEND:VEVENT`; }).join('\r\n');
  download(new Blob([`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//MahilaSamooh//HI\r\n${ev}\r\nEND:VCALENDAR`],{type:'text/calendar'}),'samooh-baithak.ics');
  toast('फ़ाइल खोलकर फोन कैलेंडर में जोड़ें (1 दिन पहले रिमाइंडर)');
}

/* ---------------- ऋण ---------------- */
function renderLoans(app){
  const {mem,T,msum}=ledger(); const set=S.settings;
  const act=[]; S.members.forEach(m=>mem[m.id].active.forEach(l=>act.push({m,l})));
  act.sort((a,b)=>b.l.balance-a.l.balance);
  const hist=[]; S.meetings.filter(x=>x.status!=='scheduled').sort(byDate).reverse().forEach(mt=>{ const s=msum[mt.id]; Object.entries(s.rows).forEach(([id,r])=>{ if(r.newLoan>0) hist.push({mt,m:memberById(id),r}); }); });
  app.innerHTML=`<h2>💰 ऋण प्रबंधन<span class="sp"></span><button class="btn sm" onclick="loanForm()">💸 नया ऋण</button></h2>
   <div class="grid">
    <div class="stat" style="--c:#2463b0"><small>ऋण हेतु उपलब्ध नकद</small><b>${rs(T.cash)}</b></div>
    <div class="stat" style="--c:#c0392b"><small>कुल बकाया ऋण</small><b>${rs(T.outstanding)}</b></div>
    <div class="stat" style="--c:#7d3c98"><small>अब तक कुल ऋण दिया</small><b>${rs(T.loanGiven)}</b></div>
    <div class="stat" style="--c:#1e8e5a"><small>मूलधन वसूली</small><b>${rs(T.principal)}</b></div>
    <div class="stat" style="--c:#f39c12"><small>कुल ब्याज आय</small><b>${rs(T.interest)}</b></div>
    <div class="stat"><small>अगले माह अनुमानित ब्याज</small><b>${rs(T.nextInt)}</b></div></div>
   <div class="note">ℹ️ हर बैठक में बकाया ऋण पर ब्याज (ऋणवार % दर से) स्वतः जुड़ता है। मूलधन वापसी पहले सबसे पुराने ऋण में घटती है। ब्याज कम भरने पर बकाया अगली बैठक में जुड़ जाता है।</div>
   <h2>🔴 सक्रिय ऋण (${act.length})</h2>
   <div class="card list">${act.length?act.map(({m,l})=>`<div class="item" onclick="go('member/${m.id}')">${av(m)}<div class="mid"><b>${m.roll}. ${esc(m.name)}</b>
     <span class="small muted">${fmtS(l.date)} • ${rs(l.amount)} @ ${l.rate}% • ${esc(l.purpose||'')}</span></div>
     <div class="end"><b style="color:var(--bad)">${rs(l.balance)}</b><div class="small muted">मासिक ब्याज ${rs(l.balance*l.rate/100)}</div></div></div>`).join(''):'<div class="empty"><div>🎉</div>कोई सक्रिय ऋण नहीं</div>'}</div>
   <h2>🗂️ ऋण वितरण इतिहास</h2>
   ${hist.length?`<div class="tw"><table class="t"><tr><th>तारीख</th><th>सदस्य</th><th>ऋण</th><th>दर</th><th>उद्देश्य</th></tr>${hist.map(h=>`<tr><td class="l">${fmtS(h.mt.date)}</td><td class="l">${esc(h.m.name)}</td><td>${rs(h.r.newLoan)}</td><td>${h.r.rate}%</td><td class="l">${esc(h.r.purpose||'-')}</td></tr>`).join('')}</table></div>`:'<div class="card muted small">अभी कोई ऋण वितरण नहीं</div>'}`;
}
function loanForm(memberId){
  const set=S.settings; const am=activeMembers(); if(!am.length) return toast('पहले सदस्य जोड़ें');
  const {T,mem}=ledger();
  const opens=S.meetings.filter(m=>m.status==='open').sort(byDate);
  openModal(`<h3>💸 नया ऋण दें<button class="x" data-close>✕</button></h3>
   <div class="note">तिजोरी/बैंक में उपलब्ध नकद: <b>${rs(T.cash)}</b></div>
   <label class="fl">महिला सदस्य चुनें<select id="l_m">${am.map(m=>`<option value="${m.id}" ${m.id===memberId?'selected':''}>${m.roll}. ${esc(m.name)} ${mem[m.id].bal>0?'(बकाया '+rs(mem[m.id].bal)+')':''}</option>`).join('')}</select></label>
   <div class="two"><label class="fl">ऋण राशि ₹<input type="number" id="l_a" placeholder="जैसे: 10000"></label>
   <label class="fl">मासिक ब्याज दर %<input type="number" step="0.1" id="l_r" value="${set.rate}"></label></div>
   <label class="fl">उद्देश्य<select id="l_p">${PURPOSES.map(p=>`<option>${p}</option>`).join('')}</select></label>
   <label class="fl">किस बैठक में<select id="l_mt">${opens.map(m=>`<option value="${m.id}">${fmtD(m.date)} (चालू बैठक)</option>`).join('')}<option value="new">आज की नई बैठक (${fmtD(today())})</option></select></label>
   <div id="l_info" class="small muted" style="margin-bottom:10px"></div>
   <button class="btn wide" id="l_go">✅ ऋण स्वीकृत करें</button>`);
  const info=()=>{ const a=num($('#l_a').value), r=+$('#l_r').value||0; $('#l_info').innerHTML=a?`मासिक ब्याज: <b>${rs(a*r/100)}</b> • 12 माह में कुल ब्याज (बिना वापसी): ${rs(a*r/100*12)}${a>T.cash?'<br><span style="color:var(--bad)">⚠️ उपलब्ध नकद से अधिक!</span>':''}`:''; };
  $('#l_a').oninput=info; $('#l_r').oninput=info;
  $('#l_go').onclick=()=>{
    const a=num($('#l_a').value); if(!a) return toast('ऋण राशि डालें');
    let mt; const sel=$('#l_mt').value;
    if(sel==='new'){ mt=S.meetings.find(x=>x.date===today()); if(!mt){ mt={id:uid(),created:Date.now(),date:today(),time:'',title:'ऋण वितरण',place:set.village,status:'scheduled',entries:{},expenses:[]}; S.meetings.push(mt); }
      if(mt.status!=='open'){ if(mt.status==='closed') mt.status='open'; else startMeeting(mt); } }
    else mt=S.meetings.find(x=>x.id===sel);
    const mid=$('#l_m').value; const m=memberById(mid);
    const e=mt.entries[mid]||(mt.entries[mid]={present:true,kist:0,interest:0,principal:0,fine:0,newLoan:0});
    const prevNew=+e.newLoan||0; e.newLoan=prevNew+a; e.loanRate=+$('#l_r').value||0; e.purpose=$('#l_p').value;
    save(true); closeModal(); toast(`${m.name} को ${rs(a)} का ऋण दर्ज${prevNew?' (पहले के '+rs(prevNew)+' में जोड़ा)':''} ✅`); render();
  };
}

/* ---------------- रिपोर्ट ---------------- */
function renderReports(app){
  const {T,msum}=ledger(); const done=S.meetings.filter(m=>m.status!=='scheduled').sort(byDate);
  app.innerHTML=`<h2>📄 PDF रिपोर्ट</h2><div class="rep">
   <button onclick="pdfGroup()"><span>🏛️</span><div><b>समूह की पूरी रिपोर्ट</b><small>समूह विवरण, पदाधिकारी, कुल हिसाब, सदस्यवार व बैठकवार तालिका</small></div></button>
   <button onclick="pickMember()"><span>📒</span><div><b>सदस्य पासबुक PDF</b><small>किसी एक महिला का पूरा हिसाब</small></div></button>
   <button onclick="pdfAllPassbooks()"><span>📚</span><div><b>सभी सदस्यों की पासबुक (एक PDF)</b><small>हर सदस्य का अलग पेज</small></div></button>
   <button onclick="pickMeeting()"><span>📝</span><div><b>बैठक रजिस्टर PDF</b><small>चुनी गई बैठक का पूरा रजिस्टर, हस्ताक्षर सहित</small></div></button>
   <button onclick="pdfMembers()"><span>👩‍👩‍👧</span><div><b>सदस्य सूची PDF</b><small>नाम, मोबाइल, पता, पद</small></div></button>
   <button onclick="pdfLoans()"><span>💰</span><div><b>ऋण रिपोर्ट PDF</b><small>सक्रिय ऋण, दर, बकाया, मासिक ब्याज</small></div></button></div>
   <h2>📈 आय-व्यय (बैठकवार)</h2>
   ${done.length?`<div class="tw"><table class="t"><tr><th>तारीख</th><th>किस्त</th><th>ब्याज</th><th>वापसी</th><th>जुर्माना</th><th>कुल जमा</th><th>नया ऋण</th><th>खर्च</th><th>शेष नकद</th></tr>
    ${done.map(m=>{const s=msum[m.id];return `<tr><td class="l">${fmtS(m.date)}</td><td>${rs(s.kist)}</td><td>${rs(s.interest)}</td><td>${rs(s.principal)}</td><td>${rs(s.fine)}</td><td><b>${rs(s.collected)}</b></td><td>${rs(s.loan)}</td><td>${rs(s.exp)}</td><td>${rs(s.closing)}</td></tr>`}).join('')}
    <tr class="tot"><td class="l">कुल</td><td>${rs(T.kist)}</td><td>${rs(T.interest)}</td><td>${rs(T.principal)}</td><td>${rs(T.fine)}</td><td>${rs(T.kist+T.interest+T.principal+T.fine)}</td><td>${rs(T.loanGiven)}</td><td>${rs(T.exp)}</td><td>${rs(T.cash)}</td></tr></table></div>`:'<div class="card muted small">अभी कोई बैठक नहीं</div>'}
   <div class="card kv" style="margin-top:12px"><span>शुद्ध लाभ (ब्याज + जुर्माना − खर्च)</span><b style="color:var(--ok)">${rs(T.interest+T.fine-T.exp)}</b>
     <span>प्रति सदस्य औसत बचत</span><b>${rs(T.savings/Math.max(1,activeMembers().length))}</b></div>
   <h2>💾 डेटा सुरक्षा</h2>
   <div class="card"><p class="small muted" style="margin-top:0">सारा डेटा इसी फोन में सुरक्षित रहता है। फोन बदलने/ऐप हटाने से पहले बैकअप ज़रूर लें।</p>
    <div class="row"><button class="btn f1" onclick="backup()">⬇️ बैकअप फ़ाइल</button><button class="btn sec f1" onclick="restorePick()">⬆️ बैकअप वापस लाएँ</button></div>
    <button class="btn ghost wide" style="margin-top:8px" onclick="exportCSV()">📊 Excel (CSV) में निकालें</button></div>`;
}
function pickMember(){ const am=S.members.slice().sort((a,b)=>a.roll-b.roll); if(!am.length) return toast('कोई सदस्य नहीं');
  openModal(`<h3>📒 सदस्य चुनें<button class="x" data-close>✕</button></h3><div class="list">${am.map(m=>`<div class="item" onclick="closeModal();pdfPassbook('${m.id}')">${av(m)}<div class="mid"><b>${m.roll}. ${esc(m.name)}</b></div></div>`).join('')}</div>`); }
function pickMeeting(){ const ms=S.meetings.filter(m=>m.status!=='scheduled').sort(byDate).reverse(); if(!ms.length) return toast('कोई बैठक दर्ज नहीं');
  openModal(`<h3>📝 बैठक चुनें<button class="x" data-close>✕</button></h3><div class="list">${ms.map(m=>`<div class="item" onclick="closeModal();pdfRegister('${m.id}')"><div class="mid"><b>${fmtD(m.date)}</b><span class="small muted">${m.status==='closed'?'संपन्न':'चालू'}</span></div></div>`).join('')}</div>`); }

/* ---------- PDF बनाना ---------- */
async function newDoc(title,land,sub2){
  const s=S.settings; const logo=await loadImg(s.logo);
  return new PdfDoc({title,landscape:land,logo,group:{name:s.name||'महिला स्वयं सहायता समूह',tagline:s.tagline,village:[s.village,s.block,s.district].filter(Boolean).join(', '),printDate:fmtS(today()),sub2}});
}
function bearers(){ const r={}; S.members.filter(m=>!m.left&&m.role&&m.role!=='सदस्य').forEach(m=>{ r[m.role]=m.name; }); return r; }
function signRow(){ const b=bearers(); return [['अध्यक्ष',b['अध्यक्ष']],['सचिव',b['सचिव']],['कोषाध्यक्ष',b['कोषाध्यक्ष']]]; }
async function deliverPdf(doc,fname){
  const blob=doc.build(); busy(false);
  const file=new File([blob],fname,{type:'application/pdf'});
  const canShare=navigator.canShare&&navigator.canShare({files:[file]});
  openModal(`<h3>✅ PDF तैयार है<button class="x" data-close>✕</button></h3><p class="small muted">${esc(fname)} • ${(blob.size/1024).toFixed(0)} KB • ${doc.pageNo} पृष्ठ</p>
    <button class="btn wide" id="pd">⬇️ डाउनलोड करें</button>
    ${canShare?'<button class="btn ok wide" style="margin-top:8px" id="ps">📤 शेयर करें (WhatsApp आदि)</button>':''}
    <button class="btn sec wide" style="margin-top:8px" id="po">👁️ खोलकर देखें</button>`);
  $('#pd').onclick=()=>{ download(blob,fname); toast('डाउनलोड फ़ोल्डर में सेव'); };
  if(canShare) $('#ps').onclick=()=>navigator.share({files:[file],title:fname}).catch(()=>{});
  $('#po').onclick=()=>openUrl(URL.createObjectURL(blob));
}
async function run(fn,t){ busy(true,t||'PDF बन रहा है…'); await new Promise(r=>setTimeout(r,60)); try{ await fn(); }catch(e){ busy(false); console.error(e); toast('PDF बनाने में त्रुटि: '+e.message); } }
const fileSafe=s=>(String(s||'').replace(/[^A-Za-z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,30)||'Samooh');

async function passbookPages(doc,m,L){
  const img=await loadImg(m.photo);
  doc.profile(img,[m.name+'  (क्रमांक '+m.roll+')',(m.relative?'पति/पिता: '+m.relative+'   •   ':'')+'पद: '+(m.role||'सदस्य'),'मोबाइल: '+m.mobile+'   •   सदस्यता: '+fmtS(m.joinDate),'पता: '+(m.address||''),'नॉमिनी: '+(m.nominee||'-')]);
  doc.kvBoxes([['कुल बचत',rs(L.savings),'#1e8e5a'],['कुल ऋण लिया',rs(L.t.loan),'#7d3c98'],['मूलधन वापस',rs(L.t.principal),'#2463b0'],['कुल ब्याज भरा',rs(L.t.interest),'#f39c12'],
    ['वर्तमान बकाया ऋण',rs(L.bal),'#c0392b'],['ब्याज बकाया',rs(L.intArrear),'#c0392b'],['अगले माह देय ब्याज',rs(L.nextInt),'#8e1f63'],['जुर्माना भरा',rs(L.t.fine),'#555']],4);
  if(L.all.length){ doc.heading('ऋण खाते');
    doc.table([{h:'तारीख',w:1.2,a:'l'},{h:'उद्देश्य',w:2.2,a:'l'},{h:'ऋण राशि'},{h:'दर %',w:.7},{h:'शेष'},{h:'स्थिति',w:.9,a:'c'}],
      L.all.map(l=>[fmtS(l.date),l.purpose||'-',rs(l.amount),l.rate+'%',rs(l.balance),l.balance>0.001?'चालू':'चुकता'])); }
  doc.heading('पासबुक – बैठकवार लेन-देन');
  const rows=[]; if(+m.openSavings||+m.openLoan) rows.push(['-','शुरुआती','-',rs(m.openSavings),'-','-','-',rs(m.openLoan),rs(m.openLoan),'-']);
  L.rows.forEach((r,i)=>rows.push([i+1,fmtS(r.date)+(r.present?'':' (अनु.)'),rs(r.kist),rs(r.savings),rs(r.prev),rs(r.interest)+(r.interest<r.intDue?' /'+rs(r.intDue):''),rs(r.principal),r.newLoan?rs(r.newLoan)+' @'+r.rate+'%':'-',rs(r.bal),r.fine?rs(r.fine):'-']));
  doc.table([{h:'क्र.',w:.5,a:'c'},{h:'तारीख',w:1.3,a:'l'},{h:'किस्त'},{h:'कुल बचत',w:1.1},{h:'पिछला ऋण',w:1.1},{h:'ब्याज (भरा/देय)',w:1.4},{h:'मूलधन वापस',w:1.1},{h:'नया ऋण',w:1.3},{h:'शेष ऋण',w:1.1},{h:'जुर्माना',w:.9}],
    rows,{total:['','कुल',rs(L.t.kist),rs(L.savings),'',rs(L.t.interest),rs(L.t.principal),rs(L.t.loan-(+m.openLoan||0)),rs(L.bal),rs(L.t.fine)],size:16});
  doc.text('नोट: ब्याज कॉलम में "/" के बाद की राशि उस बैठक का देय ब्याज है; कम भरा ब्याज अगली बैठक में जुड़ता है।',{size:15,color:'#6b5a64'});
  doc.signatures([['सदस्य हस्ताक्षर',m.name],['सचिव',bearers()['सचिव']||''],['कोषाध्यक्ष',bearers()['कोषाध्यक्ष']||'']]);
}
function pdfPassbook(id){ run(async()=>{ const m=memberById(id); const L=ledger().mem[id]; const doc=await newDoc('सदस्य पासबुक',false,m.name); await passbookPages(doc,m,L); await deliverPdf(doc,'Passbook_'+m.roll+'_'+today()+'.pdf'); }); }
function pdfAllPassbooks(){ const ms=S.members.slice().sort((a,b)=>a.roll-b.roll); if(!ms.length) return toast('कोई सदस्य नहीं');
  run(async()=>{ const {mem}=ledger(); const doc=await newDoc('सभी सदस्य पासबुक'); for(let i=0;i<ms.length;i++){ if(i) doc.newPage(); $('#busyText').textContent='पासबुक '+(i+1)+'/'+ms.length; await passbookPages(doc,ms[i],mem[ms[i].id]); } await deliverPdf(doc,'All_Passbooks_'+fileSafe(S.settings.name)+'.pdf'); },'सभी पासबुक बन रही हैं…'); }
function pdfRegister(id){ run(async()=>{
  const mt=S.meetings.find(m=>m.id===id); const {msum}=ledger(); const s=msum[id];
  const doc=await newDoc('बैठक रजिस्टर',true,fmtD(mt.date));
  doc.text('बैठक तिथि: '+fmtD(mt.date)+(mt.time?'  •  समय: '+mt.time:'')+(mt.place?'  •  स्थान: '+mt.place:'')+'  •  उपस्थित: '+s.present+'/'+s.count+'  •  स्थिति: '+(mt.status==='closed'?'संपन्न':'चालू'),{size:19,bold:true});
  doc.space(6);
  const rows=Object.entries(s.rows).map(([mid,r])=>({m:memberById(mid),r})).sort((a,b)=>a.m.roll-b.m.roll)
    .map(({m,r})=>[m.roll,m.name,r.present?'✓':'✗',rs(r.kist),rs(r.prev),rs(r.intDue),rs(r.interest),rs(r.principal),r.fine?rs(r.fine):'-',rs(r.paid),r.newLoan?rs(r.newLoan):'-',r.newLoan?r.rate+'%':'-',rs(r.bal),rs(r.savings),'']);
  doc.table([{h:'क्र.',w:.5,a:'c'},{h:'सदस्य का नाम',w:2.2,a:'l'},{h:'उप.',w:.5,a:'c'},{h:'किस्त'},{h:'पिछला ऋण',w:1.1},{h:'देय ब्याज'},{h:'ब्याज जमा'},{h:'मूलधन वापस',w:1.1},{h:'जुर्माना',w:.8},{h:'कुल जमा',w:1.1},{h:'नया ऋण'},{h:'दर',w:.6},{h:'शेष ऋण',w:1.1},{h:'कुल बचत',w:1.1},{h:'हस्ताक्षर',w:1.3}],
    rows,{total:['','कुल योग',s.present,rs(s.kist),'',rs(s.intDue),rs(s.interest),rs(s.principal),rs(s.fine),rs(s.collected),rs(s.loan),'','','','']});
  doc.heading('रोकड़ सारांश');
  doc.kvBoxes([['पिछला नकद शेष',rs(s.opening),'#555'],['कुल जमा (+)',rs(s.collected),'#1e8e5a'],['ऋण हेतु उपलब्ध',rs(s.available),'#2463b0'],['नया ऋण (−)',rs(s.loan),'#c0392b'],['बैठक खर्च (−)',rs(s.exp),'#f39c12'],['बैठक के बाद नकद',rs(s.closing),'#8e1f63']],6);
  if((mt.expenses||[]).length) doc.text('खर्च: '+mt.expenses.map(x=>x.desc+' '+rs(x.amt)).join(', '),{size:18});
  const lo=Object.entries(s.rows).filter(([,r])=>r.newLoan>0); if(lo.length) doc.text('ऋण प्राप्त महिलाएँ: '+lo.map(([id,r])=>memberById(id).name+' '+rs(r.newLoan)+' @'+r.rate+'%'+(r.purpose?' ('+r.purpose+')':'')).join(';  '),{size:18});
  doc.signatures(signRow()); await deliverPdf(doc,'Register_'+mt.date+'.pdf'); }); }
function pdfGroup(){ run(async()=>{
  const {mem,msum,T}=ledger(); const st=S.settings; const doc=await newDoc('समूह रिपोर्ट',true,'दिनांक '+fmtS(today()));
  const img=await loadImg(st.photo);
  const b=bearers();
  doc.profile(img,[st.name||'महिला स्वयं सहायता समूह',(st.tagline||''),'पता: '+[st.village,st.block,st.district].filter(Boolean).join(', ')+'   •   गठन: '+fmtS(st.formed),
    'अध्यक्ष: '+(b['अध्यक्ष']||'-')+'   •   सचिव: '+(b['सचिव']||'-')+'   •   कोषाध्यक्ष: '+(b['कोषाध्यक्ष']||'-'),
    'सदस्य: '+activeMembers().length+'   •   मासिक ब्याज दर: '+st.rate+'%   •   किस्त विकल्प: '+st.kistOptions.map(rs).join(', ')+(st.bankName?'   •   बैंक: '+st.bankName+' '+(st.bankAcc||''):'')]);
  doc.kvBoxes([['कुल बचत',rs(T.savings),'#1e8e5a'],['कुल ब्याज आय',rs(T.interest),'#f39c12'],['जुर्माना आय',rs(T.fine),'#555'],['कुल खर्च',rs(T.exp),'#999'],['अब तक ऋण दिया',rs(T.loanGiven),'#7d3c98'],['मूलधन वसूली',rs(T.principal),'#2463b0'],
    ['सक्रिय बकाया ऋण',rs(T.outstanding),'#c0392b'],['नकद (तिजोरी/बैंक)',rs(T.cash),'#2463b0'],['समूह की कुल पूँजी',rs(T.corpus),'#8e1f63'],['ऋणी महिलाएँ',T.borrowers+'/'+activeMembers().length,'#7d3c98'],['ब्याज बकाया',rs(T.intArrear),'#c0392b'],['शुद्ध लाभ',rs(T.interest+T.fine-T.exp),'#1e8e5a']],6);
  doc.heading('सदस्यवार हिसाब');
  const ms=S.members.slice().sort((a,b)=>a.roll-b.roll);
  doc.table([{h:'क्र.',w:.5,a:'c'},{h:'नाम',w:2,a:'l'},{h:'मोबाइल',w:1.3,a:'l'},{h:'पद',w:1,a:'l'},{h:'कुल बचत'},{h:'ऋण लिया'},{h:'मूलधन वापस'},{h:'ब्याज भरा'},{h:'जुर्माना',w:.8},{h:'शेष ऋण'},{h:'ब्याज बकाया'}],
    ms.map(m=>{const L=mem[m.id];return [m.roll,m.name+(m.left?' (निष्क्रिय)':''),m.mobile,m.role||'सदस्य',rs(L.savings),rs(L.t.loan),rs(L.t.principal),rs(L.t.interest),rs(L.t.fine),rs(L.bal),rs(L.intArrear)]}),
    {total:['','कुल','','',rs(T.savings),rs(T.loanGiven),rs(T.principal),rs(T.interest),rs(T.fine),rs(T.outstanding),rs(T.intArrear)]});
  const done=S.meetings.filter(m=>m.status!=='scheduled').sort(byDate);
  if(done.length){ doc.heading('बैठकवार आय-व्यय');
    doc.table([{h:'तारीख',w:1.2,a:'l'},{h:'उपस्थित',w:.8},{h:'पिछला नकद'},{h:'किस्त'},{h:'ब्याज'},{h:'मूलधन वापसी'},{h:'जुर्माना',w:.8},{h:'कुल जमा'},{h:'नया ऋण'},{h:'खर्च',w:.8},{h:'शेष नकद'}],
      done.map(m=>{const s=msum[m.id];return [fmtS(m.date),s.present+'/'+s.count,rs(s.opening),rs(s.kist),rs(s.interest),rs(s.principal),rs(s.fine),rs(s.collected),rs(s.loan),rs(s.exp),rs(s.closing)]}),
      {total:['कुल','','',rs(T.kist),rs(T.interest),rs(T.principal),rs(T.fine),rs(T.kist+T.interest+T.principal+T.fine),rs(T.loanGiven),rs(T.exp),rs(T.cash)]}); }
  doc.signatures(signRow()); await deliverPdf(doc,'Samooh_Report_'+today()+'.pdf'); }); }
function pdfMembers(){ run(async()=>{ const doc=await newDoc('सदस्य सूची',true); const ms=S.members.slice().sort((a,b)=>a.roll-b.roll);
  doc.table([{h:'क्र.',w:.5,a:'c'},{h:'नाम',w:1.8,a:'l'},{h:'पति/पिता',w:1.6,a:'l'},{h:'मोबाइल',w:1.2,a:'l'},{h:'पता',w:3,a:'l'},{h:'पद',w:1,a:'l'},{h:'सदस्यता',w:1.1,a:'l'},{h:'किस्त',w:.9},{h:'नॉमिनी',w:1.4,a:'l'}],
    ms.map(m=>[m.roll,m.name+(m.left?' (निष्क्रिय)':''),m.relative||'',m.mobile,m.address||'',m.role||'सदस्य',fmtS(m.joinDate),rs(m.kist||S.settings.defaultKist),m.nominee||'']));
  doc.signatures(signRow()); await deliverPdf(doc,'Member_List.pdf'); }); }
function pdfLoans(){ run(async()=>{ const {mem,T}=ledger(); const doc=await newDoc('ऋण रिपोर्ट',true);
  doc.kvBoxes([['कुल बकाया ऋण',rs(T.outstanding),'#c0392b'],['अब तक ऋण दिया',rs(T.loanGiven),'#7d3c98'],['मूलधन वसूली',rs(T.principal),'#2463b0'],['ब्याज आय',rs(T.interest),'#f39c12'],['अगले माह ब्याज',rs(T.nextInt),'#8e1f63'],['उपलब्ध नकद',rs(T.cash),'#1e8e5a']],6);
  const rows=[]; S.members.slice().sort((a,b)=>a.roll-b.roll).forEach(m=>mem[m.id].active.forEach(l=>rows.push([m.roll,m.name,m.mobile,fmtS(l.date),l.purpose||'-',rs(l.amount),l.rate+'%',rs(l.amount-l.balance),rs(l.balance),rs(l.balance*l.rate/100)])));
  doc.heading('सक्रिय ऋण सूची');
  doc.table([{h:'क्र.',w:.5,a:'c'},{h:'नाम',w:1.8,a:'l'},{h:'मोबाइल',w:1.2,a:'l'},{h:'ऋण तिथि',w:1.1,a:'l'},{h:'उद्देश्य',w:2,a:'l'},{h:'ऋण राशि'},{h:'दर',w:.6},{h:'वापस'},{h:'शेष'},{h:'मासिक ब्याज'}],rows,{total:['','कुल','','','','','','',rs(T.outstanding),rs(S.members.reduce((a,m)=>a+mem[m.id].active.reduce((b,l)=>b+l.balance*l.rate/100,0),0))]});
  doc.signatures(signRow()); await deliverPdf(doc,'Loan_Report_'+today()+'.pdf'); }); }

/* ---------- बैकअप / CSV ---------- */
function backup(){ download(new Blob([JSON.stringify(S)],{type:'application/json'}),'MahilaSamooh_Backup_'+today()+'.json'); toast('बैकअप फ़ाइल सेव हुई – इसे WhatsApp/Drive पर सुरक्षित रखें'); }
function restorePick(){ const i=document.createElement('input'); i.type='file'; i.accept='.json,application/json';
  i.onchange=()=>{ const r=new FileReader(); r.onload=()=>{ try{ const d=JSON.parse(r.result); if(!d.members||!d.settings) throw 0;
    confirmBox('बैकअप से डेटा वापस लाएँ? अभी का डेटा बदल जाएगा।','हाँ, वापस लाएँ',()=>{ localStorage.setItem(KEY,JSON.stringify(d)); load(); toast('बैकअप सफलतापूर्वक लोड ✅'); go('home'); }); }catch(e){ toast('गलत बैकअप फ़ाइल'); } }; r.readAsText(i.files[0]); };
  i.click(); }
function exportCSV(){ const {mem}=ledger(); const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
  let csv='﻿क्रमांक,नाम,मोबाइल,पता,पद,कुल बचत,ऋण लिया,मूलधन वापस,ब्याज भरा,जुर्माना,शेष ऋण,ब्याज बकाया\n';
  S.members.slice().sort((a,b)=>a.roll-b.roll).forEach(m=>{ const L=mem[m.id]; csv+=[m.roll,m.name,m.mobile,m.address,m.role,L.savings,L.t.loan,L.t.principal,L.t.interest,L.t.fine,L.bal,L.intArrear].map(q).join(',')+'\n'; });
  csv+='\n\nबैठक,सदस्य,उपस्थित,किस्त,पिछला ऋण,देय ब्याज,ब्याज जमा,मूलधन वापस,जुर्माना,नया ऋण,दर,शेष ऋण,कुल बचत\n';
  const {msum}=ledger(); S.meetings.filter(m=>m.status!=='scheduled').sort(byDate).forEach(mt=>Object.entries(msum[mt.id].rows).forEach(([id,r])=>{ csv+=[mt.date,memberById(id).name,r.present?'हाँ':'नहीं',r.kist,r.prev,r.intDue,r.interest,r.principal,r.fine,r.newLoan,r.rate,r.bal,r.savings].map(q).join(',')+'\n'; }));
  download(new Blob([csv],{type:'text/csv;charset=utf-8'}),'MahilaSamooh_'+today()+'.csv'); }

/* ---------------- सेटिंग ---------------- */
function renderSettings(app){
  const s=S.settings; let logo=s.logo, photo=s.photo, opts=s.kistOptions.slice();
  app.innerHTML=`<h2>⚙️ समूह सेटिंग</h2>
   <div class="card"><b>समूह की पहचान</b>
    <div class="two" style="margin-top:10px"><div class="photopick" style="flex-direction:column"><div id="lgp">${logo?`<img class="av" style="border-radius:16px;width:76px;height:76px" src="${logo}">`:'<div class="av" style="border-radius:16px;width:76px;height:76px">🌸</div>'}</div>
      <label class="btn sm sec">🖼️ लोगो बदलें<input type="file" accept="image/*" id="lgf" hidden></label></div>
     <div class="photopick" style="flex-direction:column"><div id="php">${photo?`<img class="av" style="border-radius:16px;width:76px;height:76px" src="${photo}">`:'<div class="av" style="border-radius:16px;width:76px;height:76px">👩‍👩‍👧</div>'}</div>
      <label class="btn sm sec">📷 समूह फोटो<input type="file" accept="image/*" id="phf" hidden></label></div></div>
    <label class="fl">समूह का नाम <span class="req">*</span><input id="s_name" value="${esc(s.name)}" placeholder="जैसे: रानी लक्ष्मीबाई महिला स्वयं सहायता समूह"></label>
    <label class="fl">टैगलाइन / नारा<input id="s_tag" value="${esc(s.tagline)}" placeholder="जैसे: बचत से समृद्धि"></label>
    <div class="two"><label class="fl">गाँव / वार्ड<input id="s_vil" value="${esc(s.village)}"></label><label class="fl">प्रखंड / ब्लॉक<input id="s_blk" value="${esc(s.block)}"></label></div>
    <div class="two"><label class="fl">ज़िला<input id="s_dis" value="${esc(s.district)}"></label><label class="fl">गठन तिथि<input type="date" id="s_form" value="${s.formed||''}"></label></div>
    <div class="two"><label class="fl">बैंक का नाम<input id="s_bank" value="${esc(s.bankName)}"></label><label class="fl">समूह खाता संख्या<input id="s_acc" value="${esc(s.bankAcc)}"></label></div></div>
   <div class="card"><b>💰 किस्त व ब्याज नियम</b>
    <div class="small muted" style="margin:8px 0 4px">किस्त के विकल्प (टैप करके हटाएँ)</div>
    <div class="chips" id="kops"></div>
    <div class="row" style="margin-top:8px"><input class="search f1" style="margin:0" type="number" id="kadd" placeholder="नई किस्त राशि ₹"><button class="btn sm" id="kaddb">➕ जोड़ें</button></div>
    <div class="two" style="margin-top:12px"><label class="fl">डिफ़ॉल्ट किस्त<select id="s_dk"></select></label>
     <label class="fl">मासिक ब्याज दर %<input type="number" step="0.1" id="s_rate" value="${s.rate}"></label></div>
    <div class="two"><label class="fl">देरी जुर्माना ₹ (सुझाव)<input type="number" id="s_fine" value="${s.fine||''}"></label>
     <label class="fl">शुरुआती नकद/बैंक शेष ₹<input type="number" id="s_oc" value="${s.openCash||''}"></label></div>
    <label class="row" style="font-size:14px"><label class="switch"><input type="checkbox" id="s_auto" ${s.autofill?'checked':''}><span></span></label> बैठक शुरू होते ही किस्त व देय ब्याज स्वतः भरें</label></div>
   <button class="btn wide" id="sSave">💾 सेटिंग सेव करें</button>
   ${S.setupDone?`<div class="card" style="margin-top:14px"><b>🧹 अन्य</b><div class="row" style="margin-top:8px"><button class="btn sec f1" onclick="backup()">⬇️ बैकअप</button><button class="btn bad f1" id="reset">🗑️ सारा डेटा मिटाएँ</button></div></div>`:''}
   <p class="small muted" style="text-align:center">महिला समूह ऐप • संस्करण 2.0 • पूरी तरह ऑफ़लाइन</p>`;
  const paintK=()=>{ opts.sort((a,b)=>a-b); $('#kops').innerHTML=opts.map(k=>`<button class="chip on" data-rk="${k}">${rs(k)} ✕</button>`).join('');
    const cur=+$('#s_dk').value||s.defaultKist; $('#s_dk').innerHTML=opts.map(k=>`<option value="${k}" ${k===cur?'selected':''}>${rs(k)}</option>`).join(''); };
  paintK();
  $('#kops').onclick=e=>{ const b=e.target.closest('[data-rk]'); if(!b) return; if(opts.length<=1) return toast('कम से कम एक विकल्प ज़रूरी'); opts=opts.filter(k=>k!==+b.dataset.rk); paintK(); };
  $('#kaddb').onclick=()=>{ const v=num($('#kadd').value); if(!v) return; if(!opts.includes(v)) opts.push(v); $('#kadd').value=''; paintK(); };
  $('#lgf').onchange=async e=>{ logo=await readPhoto(e.target.files[0],256); $('#lgp').innerHTML=`<img class="av" style="border-radius:16px;width:76px;height:76px" src="${logo}">`; };
  $('#phf').onchange=async e=>{ photo=await readPhoto(e.target.files[0],480); $('#php').innerHTML=`<img class="av" style="border-radius:16px;width:76px;height:76px" src="${photo}">`; };
  $('#sSave').onclick=()=>{ const name=$('#s_name').value.trim(); if(!name) return toast('समूह का नाम डालें');
    Object.assign(s,{name,tagline:$('#s_tag').value.trim(),village:$('#s_vil').value.trim(),block:$('#s_blk').value.trim(),district:$('#s_dis').value.trim(),formed:$('#s_form').value,
      bankName:$('#s_bank').value.trim(),bankAcc:$('#s_acc').value.trim(),kistOptions:opts,defaultKist:+$('#s_dk').value,rate:+$('#s_rate').value||0,fine:num($('#s_fine').value),openCash:+$('#s_oc').value||0,autofill:$('#s_auto').checked,logo,photo});
    const first=!S.setupDone; S.setupDone=true; save(true); toast('सेटिंग सेव ✅'); go(first?'members':'home'); if(first) setTimeout(()=>memberForm(),300); };
  const r=$('#reset'); if(r) r.onclick=()=>confirmBox('सारा डेटा (सदस्य, बैठक, ऋण) हमेशा के लिए मिट जाएगा। पहले बैकअप ले लें!','हाँ, सब मिटाएँ',()=>{ localStorage.removeItem(KEY); load(); go('home'); },true);
}

/* ---------------- डेमो डेटा ---------------- */
function loadDemo(){
  const names=['सरोज देवी','सुनीता देवी','रेखा देवी','गीता देवी','अनीता देवी','पूनम देवी','मंजू देवी','कविता देवी','रीना देवी','ललिता देवी','शांति देवी','पुष्पा देवी'];
  S=defaults(); Object.assign(S.settings,{name:'रानी लक्ष्मीबाई महिला स्वयं सहायता समूह',tagline:'बचत से समृद्धि, एकता में शक्ति',village:'रामपुर',block:'सदर',district:'पटना',formed:'2026-01-05',openCash:0});
  names.forEach((n,i)=>S.members.push({id:uid()+i,roll:i+1,name:n,mobile:'98765432'+pad(i+10),address:'वार्ड '+(i%5+1)+', रामपुर',relative:'',role:i===0?'अध्यक्ष':i===1?'सचिव':i===2?'कोषाध्यक्ष':'सदस्य',joinDate:'2026-01-05',kist:i%4===0?2000:1000,nominee:'',openSavings:0,openLoan:0,openLoanRate:2,photo:'',created:i}));
  S.nextRoll=names.length+1; S.setupDone=true;
  const dates=['2026-07-10','2026-08-10','2026-09-10','2026-10-10'];
  dates.forEach((d,k)=>{ const mt={id:'demo'+k,created:k,date:d,time:'11:00',title:'मासिक बैठक',place:'पंचायत भवन',status:'scheduled',entries:{},expenses:[]}; S.meetings.push(mt); startMeeting(mt);
    if(k===0){ mt.entries[S.members[3].id].newLoan=5000; mt.entries[S.members[3].id].purpose=PURPOSES[0]; }
    if(k===1){ mt.entries[S.members[5].id].newLoan=10000; mt.entries[S.members[5].id].purpose=PURPOSES[2]; mt.entries[S.members[3].id].principal=1000; mt.expenses.push({desc:'रजिस्टर व स्टेशनरी',amt:150}); }
    if(k===2){ mt.entries[S.members[8].id].newLoan=8000; mt.entries[S.members[8].id].loanRate=1.5; mt.entries[S.members[8].id].purpose=PURPOSES[4]; mt.entries[S.members[5].id].principal=2000; mt.entries[S.members[7].id].present=false; mt.entries[S.members[7].id].kist=0; }
    if(k===3){ mt.entries[S.members[3].id].principal=4000; mt.entries[S.members[1].id].fine=50; }
    // ब्याज फिर से (पिछली प्रविष्टियों के बाद)
    const s=ledger().msum[mt.id]; Object.keys(mt.entries).forEach(id=>{ mt.entries[id].interest=s.rows[id].intDue; });
    if(k===3) mt.entries[S.members[5].id].interest=0;
    mt.status='closed'; });
  S.meetings.push({id:uid(),created:9,date:'2026-11-10',time:'11:00',title:'मासिक बैठक',place:'पंचायत भवन',status:'scheduled',entries:{},expenses:[]});
  S.meetings.push({id:uid(),created:10,date:'2026-12-10',time:'11:00',title:'मासिक बैठक',place:'पंचायत भवन',status:'scheduled',entries:{},expenses:[]});
  save(true); toast('डेमो डेटा लोड हुआ – सेटिंग में "सारा डेटा मिटाएँ" से हटा सकते हैं'); go('home');
}

/* ---------------- शुरू ---------------- */
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(()=>{});
render();
