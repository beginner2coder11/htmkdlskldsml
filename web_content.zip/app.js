(function () {
  'use strict';

  // ------------------------------------------------------------ postavke
  var KEY = 'calmhome';
  var WKEY = 'calmhome_weather';
  var DEF = {
    city: 'Sarajevo', lat: 43.8563, lon: 18.4131,
    h24: true, fahr: false,
    font: 'light', color: '#ffffff', size: 24,
    showWeather: true, wallpaper: '', dim: true
  };
  var COLORS = ['#ffffff', '#fff1dc', '#cde9ff', '#ffb74d', '#9e9e9e'];
  var FONTS = {
    thin:      { family: 'sans-serif',           weight: 100 },
    light:     { family: 'sans-serif',           weight: 300 },
    regular:   { family: 'sans-serif',           weight: 400 },
    condensed: { family: 'sans-serif-condensed', weight: 300 },
    serif:     { family: 'serif',                weight: 400 },
    mono:      { family: 'monospace',            weight: 400 }
  };
  var DAYS = ['nedjelja', 'ponedjeljak', 'utorak', 'srijeda', 'četvrtak', 'petak', 'subota'];
  var MONTHS = ['januar', 'februar', 'mart', 'april', 'maj', 'juni', 'juli', 'august',
    'septembar', 'oktobar', 'novembar', 'decembar'];

  var s = loadSettings();

  function loadSettings() {
    var out = {};
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { saved = {}; }
    for (var k in DEF) out[k] = (k in saved) ? saved[k] : DEF[k];
    return out;
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(s)); return true; }
    catch (e) { return false; }
  }

  function $(id) { return document.getElementById(id); }
  var clockEl = $('clock'), dateEl = $('date'), weatherEl = $('weather');

  // ------------------------------------------------------------ izgled
  function applyStyle() {
    var f = FONTS[s.font] || FONTS.light;
    document.documentElement.style.setProperty('--color', s.color);
    document.documentElement.style.setProperty('--size', s.size);
    clockEl.style.fontFamily = f.family;
    clockEl.style.fontWeight = f.weight;
    weatherEl.style.display = s.showWeather ? '' : 'none';

    var wp = $('wallpaper');
    if (s.wallpaper) {
      wp.style.backgroundImage = 'url("' + s.wallpaper.replace(/"/g, '%22') + '")';
      $('dim').style.display = s.dim ? 'block' : 'none';
    } else {
      wp.style.backgroundImage = 'none';
      $('dim').style.display = 'none';
    }
    syncPanel();
  }

  // ------------------------------------------------------------ sat i datum
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function tick() {
    var d = new Date();
    var h = d.getHours();
    var text;
    if (s.h24) {
      text = pad(h) + ':' + pad(d.getMinutes());
    } else {
      text = ((h % 12) || 12) + ':' + pad(d.getMinutes());
    }
    if (clockEl.textContent !== text) clockEl.textContent = text;

    var day = DAYS[d.getDay()];
    var dtext = day.charAt(0).toUpperCase() + day.slice(1) + ', ' +
      d.getDate() + '. ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    if (dateEl.textContent !== dtext) dateEl.textContent = dtext;
  }

  // ------------------------------------------------------------ vrijeme
  function weatherDesc(c) {
    if (c === 0) return 'Vedro';
    if (c === 1) return 'Pretežno vedro';
    if (c === 2) return 'Djelimično oblačno';
    if (c === 3) return 'Oblačno';
    if (c === 45 || c === 48) return 'Magla';
    if (c >= 51 && c <= 57) return 'Rosulja';
    if (c >= 61 && c <= 67) return 'Kiša';
    if (c >= 71 && c <= 77) return 'Snijeg';
    if (c >= 80 && c <= 82) return 'Pljuskovi';
    if (c === 85 || c === 86) return 'Snježni pljuskovi';
    if (c >= 95 && c <= 99) return 'Grmljavina';
    return '';
  }

  function showCachedWeather() {
    try {
      var c = JSON.parse(localStorage.getItem(WKEY) || 'null');
      if (c && c.text) weatherEl.textContent = c.text;
    } catch (e) { /* nema keša */ }
  }

  function loadWeather() {
    if (!s.showWeather) return;
    var url = 'https://api.open-meteo.com/v1/forecast?latitude=' + s.lat + '&longitude=' + s.lon +
      '&current=temperature_2m,weather_code' +
      '&daily=temperature_2m_max,temperature_2m_min' +
      '&forecast_days=1&timezone=auto&temperature_unit=' + (s.fahr ? 'fahrenheit' : 'celsius');
    var city = s.city;
    fetch(url)
      .then(function (r) { if (!r.ok) throw new Error('http'); return r.json(); })
      .then(function (j) {
        var t = Math.round(j.current.temperature_2m);
        var hi = Math.round(j.daily.temperature_2m_max[0]);
        var lo = Math.round(j.daily.temperature_2m_min[0]);
        var parts = [city, t + '°', weatherDesc(j.current.weather_code), '↑' + hi + '° ↓' + lo + '°'];
        var text = parts.filter(function (p) { return p; }).join('  ·  ');
        weatherEl.textContent = text;
        try { localStorage.setItem(WKEY, JSON.stringify({ text: text })); } catch (e) { /* ništa */ }
      })
      .catch(function () {
        if (!weatherEl.textContent) weatherEl.textContent = 'Vrijeme nije dostupno';
      });
  }

  function searchCity(q) {
    var box = $('cityResults');
    box.textContent = 'Tražim...';
    fetch('https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(q) +
      '&count=8&language=en&format=json')
      .then(function (r) { return r.json(); })
      .then(function (j) {
        box.textContent = '';
        if (!j.results || !j.results.length) { box.textContent = 'Nema rezultata.'; return; }
        j.results.forEach(function (r) {
          var b = document.createElement('button');
          b.type = 'button';
          b.textContent = [r.name, r.admin1, r.country].filter(Boolean).join(', ');
          b.onclick = function () {
            s.city = r.name; s.lat = r.latitude; s.lon = r.longitude;
            save();
            try { localStorage.removeItem(WKEY); } catch (e) { /* ništa */ }
            weatherEl.textContent = '';
            box.textContent = '';
            $('cityInput').value = '';
            loadWeather();
          };
          box.appendChild(b);
        });
      })
      .catch(function () { box.textContent = 'Pretraga nije uspjela. Provjeri internet.'; });
  }

  // ------------------------------------------------------------ pozadina
  function setWallpaper(src) {
    s.wallpaper = src;
    if (!save()) {
      s.wallpaper = '';
      alert('Slika je prevelika za spremanje. Probaj manju sliku.');
    }
    applyStyle();
  }

  function fileToWallpaper(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        var max = 1920;
        var scale = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement('canvas');
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        setWallpaper(c.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = function () { alert('Slika se ne može učitati.'); };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  // ------------------------------------------------------------ panel postavki
  function markSeg(id, value) {
    var btns = $(id).getElementsByTagName('button');
    for (var i = 0; i < btns.length; i++) {
      btns[i].className = (btns[i].getAttribute('data-v') === String(value)) ? 'on' : '';
    }
  }

  function syncPanel() {
    markSeg('segHour', s.h24 ? '24' : '12');
    markSeg('segUnit', s.fahr ? 'f' : 'c');
    markSeg('segWeather', s.showWeather ? '1' : '0');
    markSeg('segDim', s.dim ? '1' : '0');
    $('fontSel').value = s.font;
    $('sizeRange').value = s.size;
    var sw = $('swatches').getElementsByTagName('button');
    for (var i = 0; i < sw.length; i++) {
      sw[i].className = (sw[i].getAttribute('data-c') === s.color) ? 'on' : '';
    }
  }

  function segHandler(id, fn) {
    var btns = $(id).getElementsByTagName('button');
    for (var i = 0; i < btns.length; i++) {
      btns[i].onclick = function () { fn(this.getAttribute('data-v')); save(); applyStyle(); };
    }
  }

  function buildSwatches() {
    var box = $('swatches');
    COLORS.forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.style.background = c;
      b.setAttribute('data-c', c);
      b.setAttribute('aria-label', c);
      b.onclick = function () { s.color = c; save(); applyStyle(); };
      box.appendChild(b);
    });
  }

  function initPanel() {
    buildSwatches();

    $('gear').onclick = function () { $('panel').className = ''; syncPanel(); };
    $('closeBtn').onclick = function () { $('panel').className = 'hidden'; };
    $('panel').onclick = function (e) { if (e.target === $('panel')) $('panel').className = 'hidden'; };

    $('cityBtn').onclick = function () {
      var q = $('cityInput').value.trim();
      if (q) searchCity(q);
    };
    $('cityInput').onkeydown = function (e) { if (e.key === 'Enter') $('cityBtn').onclick(); };

    segHandler('segHour', function (v) { s.h24 = (v === '24'); tick(); });
    segHandler('segUnit', function (v) { s.fahr = (v === 'f'); localStorageRemoveWeather(); loadWeather(); });
    segHandler('segWeather', function (v) { s.showWeather = (v === '1'); if (s.showWeather) loadWeather(); });
    segHandler('segDim', function (v) { s.dim = (v === '1'); });

    $('fontSel').onchange = function () { s.font = this.value; save(); applyStyle(); };
    $('sizeRange').oninput = function () { s.size = parseInt(this.value, 10); save(); applyStyle(); };

    $('fileInput').onchange = function () {
      if (this.files && this.files[0]) fileToWallpaper(this.files[0]);
      this.value = '';
    };
    $('urlBtn').onclick = function () {
      var u = $('urlInput').value.trim();
      if (u) setWallpaper(u);
    };
    $('blackBtn').onclick = function () { setWallpaper(''); };
  }

  function localStorageRemoveWeather() {
    try { localStorage.removeItem(WKEY); } catch (e) { /* ništa */ }
  }

  // ------------------------------------------------------------ ekran ostaje upaljen
  var lock = null;
  function keepAwake() {
    try {
      if (navigator.wakeLock && navigator.wakeLock.request) {
        navigator.wakeLock.request('screen').then(function (l) { lock = l; }).catch(function () { });
      }
    } catch (e) { /* nije podržano */ }
  }

  // ------------------------------------------------------------ pokretanje
  initPanel();
  applyStyle();
  showCachedWeather();
  tick();
  setInterval(tick, 1000);
  loadWeather();
  setInterval(loadWeather, 15 * 60 * 1000);
  keepAwake();
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { keepAwake(); loadWeather(); tick(); }
  });
})();
