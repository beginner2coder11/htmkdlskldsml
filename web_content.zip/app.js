const KEY = "echoforge.v6";
const STRIPE_LINK = "https://buy.stripe.com/aFacN59Fk7VN0em6EBbsc02";
const FREE_ECHO_LIMIT = 25;
const ADMIN_EMAIL = "murilocastronv@gmail.com";
const $ = (id) => document.getElementById(id);
const types = ["Decisão","Rotina","Emocional","Habilidade","Local","Relação","Saúde"];
const prices = { Decisão:89, Rotina:49, Emocional:69, Habilidade:79, Local:39, Relação:59, Saúde:55 };

const seedFeed = [
  { user:"Maya", type:"Rotina", title:"Deep work 05:30", price:49 },
  { user:"Léo", type:"Decisão", title:"Left the job", price:89 },
  { user:"Amina", type:"Emocional", title:"Recovered from burnout", price:69 }
];

function defaultState() {
  return {
    lang: (navigator.language||"pt").slice(0,2) === "fr" ? "fr" : ((navigator.language||"pt").startsWith("en") ? "en" : "pt"),
    session: null,
    users: [],
    echoes: [],
    sold: 0,
    wallet: 0,
    streak: 1,
    pro: false,
    capture: true,
    anon: true,
    favs: [],
    notes: [],
    goal: 500,
    mode: "signup",
    stripeLink: STRIPE_LINK,
    journal: [],
    moodLog: [],
    habitsDone: {},
    lessonOpen: null
  };
}

let S = (() => {
  try { return { ...defaultState(), ...JSON.parse(localStorage.getItem(KEY)||"{}") }; }
  catch { return defaultState(); }
})();
S.stripeLink = STRIPE_LINK;
S.users = (S.users||[]).map(u => {
  if ((u.email||"").toLowerCase() === "murilocastroanive@gmail.com") {
    return { ...u, role: "user", status: u.status||"pending" };
  }
  return u;
});
if (!S.users.some(u => u.email === ADMIN_EMAIL)) {
  S.users.unshift({
    name: "Murilo Castro",
    email: ADMIN_EMAIL,
    password: "admin123",
    bio: "Fundador",
    createdAt: Date.now(),
    status: "approved",
    role: "admin",
    pro: true
  });
}
if (!S.users.some(u => u.email === "maya@echoforge.app")) {
  S.users.push(
    { name:"Maya Costa", email:"maya@echoforge.app", password:"demo123", bio:"Early adopter", createdAt: Date.now()-86400000*3, status:"approved", role:"user", pro:true },
    { name:"Léo Martins", email:"leo@echoforge.app", password:"demo123", bio:"", createdAt: Date.now()-86400000*2, status:"pending", role:"user", pro:false },
    { name:"Amina Dias", email:"amina@echoforge.app", password:"demo123", bio:"Coach", createdAt: Date.now()-86400000, status:"approved", role:"user", pro:false }
  );
}
S.users = S.users.map(u => ({
  status: u.status || (u.email===ADMIN_EMAIL?"approved":"pending"),
  role: u.role || (u.email===ADMIN_EMAIL?"admin":"user"),
  pro: !!u.pro,
  ...u
}));
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
const t = () => I18N[S.lang] || I18N.pt;

function money(n) {
  const cur = t().currency;
  const loc = cur==="BRL"?"pt-BR":cur==="EUR"?"fr-FR":"en-US";
  const ccy = cur==="BRL"?"BRL":cur==="EUR"?"EUR":"USD";
  return n.toLocaleString(loc,{style:"currency",currency:ccy});
}

function level() {
  const n = S.echoes.length + S.sold;
  return t().levels[Math.min(4, Math.floor(n/3))];
}

function notify(text) {
  S.notes.unshift({ id: crypto.randomUUID(), text, at: Date.now(), read:false });
  save(); renderBadge();
}

function renderBadge() {
  const n = S.notes.filter(x=>!x.read).length;
  const b = $("badge");
  if (!b) return;
  b.textContent = n;
  b.classList.toggle("hidden", n===0);
}

function show(id) {
  ["splash","landing","auth","app","admin"].forEach(k => $(k) && $(k).classList.add("hidden"));
  $(id).classList.remove("hidden");
}

function isAdmin(email) {
  return (email||"").toLowerCase() === ADMIN_EMAIL;
}

function routeAfterLogin() {
  const email = S.session && S.session.email;
  const user = S.users.find(u => u.email === email);
  if (isAdmin(email)) { renderAdmin(); return; }
  if (user && user.status === "pending") { renderWaiting(); return; }
  if (user && user.status === "blocked") { alert(t().waiting); S.session=null; save(); renderLanding(); return; }
  S.pro = !!(user && user.pro) || S.pro;
  bootApp();
}

function renderLanding() {
  const i = t();
  show("landing");
  $("landing").innerHTML = `
    <div class="lang-row">
      <button class="chip ${S.lang==="pt"?"on":""}" data-l="pt">PT</button>
      <button class="chip ${S.lang==="en"?"on":""}" data-l="en">EN</button>
      <button class="chip ${S.lang==="fr"?"on":""}" data-l="fr">FR</button>
    </div>
    <section class="hero-home">
      <img src="logo.svg" class="logo-img" alt="EchoForge" />
      <p class="eyebrow">${i.landingKicker}</p>
      <h1>EchoForge</h1>
      <p class="muted">${i.landingLead}</p>
      <div class="row">
        <button id="goSignup">${i.startNow}</button>
        <button class="ghost" id="goLogin">${i.enter}</button>
      </div>
    </section>
    <div class="kpis">
      <div class="stat"><b>${Math.max(1280, S.users.length*137)}</b><span>${i.kpiUsers}</span></div>
      <div class="stat"><b>${Math.max(5400, S.echoes.length*80)}</b><span>${i.kpiEchoes}</span></div>
      <div class="stat"><b>${Math.max(312, S.sold*21)}</b><span>${i.kpiPaid}</span></div>
    </div>
    <div class="card"><h3>${i.howTitle}</h3>
      <p class="feature"><span class="dot"></span>${i.how1}</p>
      <p class="feature"><span class="dot"></span>${i.how2}</p>
      <p class="feature"><span class="dot"></span>${i.how3}</p>
      <p class="feature"><span class="dot"></span>${i.how4}</p>
      <p class="feature"><span class="dot"></span>${i.how5}</p>
    </div>
    <div class="card"><h3>${i.featTitle}</h3>
      <p>• ${i.f1}</p><p>• ${i.f2}</p><p>• ${i.f3}</p><p>• ${i.f4}</p>
    </div>
    <div class="card"><h3>${i.whyTitle}</h3><p class="muted">${i.whyBody}</p></div>
    <div class="card"><h3>${i.faqTitle}</h3>
      <p><b>${i.faq1q}</b><br>${i.faq1a}</p>
      <p><b>${i.faq2q}</b><br>${i.faq2a}</p>
      <p><b>${i.faq3q}</b><br>${i.faq3a}</p>
    </div>
    <p class="muted">${i.legal}</p>`;
  $("landing").querySelectorAll("[data-l]").forEach(b => b.onclick = () => { S.lang=b.dataset.l; save(); renderLanding(); });
  $("goSignup").onclick = () => { S.mode="signup"; save(); show("auth"); renderAuth(); };
  $("goLogin").onclick = () => { S.mode="login"; save(); show("auth"); renderAuth(); };
}

function renderWaiting() {
  const i = t();
  show("landing");
  $("landing").innerHTML = `<div class="hero-home">
    <img src="logo.svg" class="logo-img" alt="EchoForge" />
    <h1>EchoForge</h1>
    <div class="card"><p>${i.waiting}</p></div>
    <button id="backL">${i.backHome}</button>
  </div>`;
  $("backL").onclick = () => { S.session=null; save(); renderLanding(); };
}

function renderAdmin() {
  const i = t();
  show("admin");
  const users = S.users;
  const pending = users.filter(u=>u.status==="pending").length;
  const paid = users.filter(u=>u.pro).length;
  $("admin").innerHTML = `
    <div class="brand"><img src="logo.svg" class="logo-img xs" /><h1>${i.adminTitle}</h1></div>
    <p class="muted">${ADMIN_EMAIL}</p>
    <div class="stats">
      <div class="stat"><b>${users.length}</b><span>${i.adminUsers}</span></div>
      <div class="stat"><b>${pending}</b><span>${i.adminPending}</span></div>
      <div class="stat"><b>${paid}</b><span>${i.adminPaid}</span></div>
      <div class="stat"><b>${S.echoes.length}</b><span>${i.statsEcho}</span></div>
    </div>
    <div class="card" style="overflow:auto">
      <table class="admin-table">
        <tr><th>Nome</th><th>E-mail</th><th>Status</th><th>Pro</th><th></th></tr>
        ${users.map(u=>`<tr>
          <td>${u.name}</td>
          <td>${u.email}</td>
          <td><span class="tag ${u.status==="approved"?"ok":u.status==="blocked"?"no":"wait"}">${u.status}</span></td>
          <td>${u.pro?"sim":"não"}</td>
          <td>
            ${isAdmin(u.email)? "admin": `
              <button data-ap="${u.email}">${i.adminApprove}</button>
              <button class="ghost" data-bl="${u.email}">${i.adminBlock}</button>
              <button class="ghost" data-pr="${u.email}">Pro</button>`}
          </td>
        </tr>`).join("")}
      </table>
    </div>
    <div class="row">
      <button id="adminApp">${i.tabs[0]}</button>
      <button class="ghost" id="adminOut">${i.logout}</button>
    </div>`;
  $("admin").querySelectorAll("[data-ap]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.ap?{...u,status:"approved"}:u); save(); renderAdmin();
  });
  $("admin").querySelectorAll("[data-bl]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.bl?{...u,status:"blocked"}:u); save(); renderAdmin();
  });
  $("admin").querySelectorAll("[data-pr]").forEach(b => b.onclick = () => {
    S.users = S.users.map(u => u.email===b.dataset.pr?{...u,pro:!u.pro}:u); save(); renderAdmin();
  });
  $("adminApp").onclick = () => bootApp();
  $("adminOut").onclick = () => { S.session=null; save(); renderLanding(); };
}

function renderAuth() {
  const i = t();
  const signup = S.mode !== "login";
  $("auth").innerHTML = `
    <div class="lang-row">
      <button class="chip ${S.lang==="pt"?"on":""}" data-l="pt">PT</button>
      <button class="chip ${S.lang==="en"?"on":""}" data-l="en">EN</button>
      <button class="chip ${S.lang==="fr"?"on":""}" data-l="fr">FR</button>
    </div>
    <img src="logo.svg" class="logo-img xs" alt="EchoForge" /><h2 style="text-align:center">EchoForge</h2>
    <h1>${signup?i.authTitleSignup:i.authTitleLogin}</h1>
    <p class="muted">${i.authSub}</p>
    <form id="authForm">
      ${signup?`<input id="name" placeholder="${i.name}" />`:""}
      <input id="email" type="email" placeholder="${i.email}" />
      <input id="password" type="password" placeholder="${i.password}" />
      <button>${signup?i.submitSignup:i.submitLogin}</button>
    </form>
    <button class="link" id="toggleAuth">${signup?i.hasAccount:i.noAccount}</button>
    <button class="link" id="toLanding">${i.backHome}</button>`;
  $("auth").querySelectorAll("[data-l]").forEach(b => b.onclick = () => { S.lang=b.dataset.l; save(); renderAuth(); });
  $("toggleAuth").onclick = () => { S.mode = signup?"login":"signup"; save(); renderAuth(); };
  const tl = $("toLanding"); if (tl) tl.onclick = () => renderLanding();
  $("authForm").onsubmit = (e) => {
    e.preventDefault();
    const email = $("email").value.trim().toLowerCase();
    const password = $("password").value;
    const name = ($("name")&&$("name").value.trim()) || email.split("@")[0];
    if (!email.includes("@") || password.length<6 || (signup && !name)) { alert(i.weak); return; }
    if (signup) {
      if (S.users.some(u=>u.email===email)) { S.mode="login"; renderAuth(); return; }
      S.users.push({
        name, email, password, bio:"", createdAt:Date.now(),
        status: isAdmin(email) ? "approved" : "pending",
        role: isAdmin(email) ? "admin" : "user",
        pro: isAdmin(email)
      });
    } else {
      const u = S.users.find(u=>u.email===email && u.password===password);
      if (!u) { alert(i.needLogin); return; }
    }
    const user = S.users.find(u=>u.email===email);
    S.session = { email:user.email, name:user.name };
    notify(S.lang==="en"?"Welcome to EchoForge":S.lang==="fr"?"Bienvenue sur EchoForge":"Bem-vindo ao EchoForge");
    save(); routeAfterLogin();
  };
}

let tab = 0;
let filter = "all";
let q = "";

function bootApp() {
  show("app");
  $("langSelect").value = S.lang;
  $("langSelect").onchange = () => { S.lang=$("langSelect").value; save(); paint(); };
  $("btnWithdraw").onclick = () => {
    if (!S.pro) { tab = 3; paint(); return; }
    alert(t().withdrawOk);
  };
  $("bell").onclick = () => openNotes();
  paint();
}

function paint() {
  const i = t();
  $("hello").textContent = `${i.hello}, ${S.session.name.split(" ")[0]}`;
  $("walletLabel").textContent = i.wallet;
  $("walletValue").textContent = money(S.wallet);
  $("btnWithdraw").textContent = i.withdraw;
  $("mainTabs").innerHTML = i.tabs.map((l,idx)=>`<button class="${tab===idx?"on":""}" data-t="${idx}">${l}</button>`).join("");
  $("mainTabs").querySelectorAll("button").forEach(b => b.onclick = () => { tab=+b.dataset.t; paint(); });
  $("pageTitle").textContent = i.tabs[tab];
  renderBadge();
  const views = [homeView, echoesView, freeView, marketView, earnView, profileView];
  $("content").innerHTML = views[tab]();
  wire();
}

function homeView() {
  const i = t();
  const listed = S.echoes.filter(e=>e.listed).length;
  const goalPct = Math.min(100, Math.round((S.wallet/S.goal)*100));
  return `
    <div class="stats">
      <div class="stat"><b>${S.echoes.length}</b><span>${i.statsEcho}</span></div>
      <div class="stat"><b>${listed}</b><span>${i.statsListed}</span></div>
      <div class="stat"><b>${S.sold}</b><span>${i.statsSold}</span></div>
      <div class="stat"><b>${S.streak}d</b><span>${i.statsStreak}</span></div>
    </div>
    <div class="card">
      <div class="meta">${i.rank}: <b>${level()}</b> • ${i.goalEarn}: ${money(S.goal)}</div>
      <div class="progress"><div class="bar" style="width:${goalPct}%"></div></div>
    </div>
    <button id="btnNew">${i.create}</button>
    ${freeHomeBlock()}
    <h3>${i.feedTitle}</h3>
    ${seedFeed.map(f=>`<article class="card feed-item"><div class="avatar">${f.user[0]}</div><div><b>${f.user}</b><div class="meta">${i.types[f.type]}</div><div>${f.title}</div><div class="price">${money(f.price)}</div></div></article>`).join("")}
  `;
}


function F(){ return (typeof FREE!=="undefined" && FREE[S.lang]) ? FREE[S.lang] : FREE.pt; }

function freeHomeBlock(){
  const f = F();
  const day = new Date().getDay();
  return `<div class="card">
    <div class="meta">${f.daily}</div>
    <p>${f.prompts[day % f.prompts.length]}</p>
    <button class="ghost" id="usePrompt">${f.decide}</button>
  </div>
  <div class="card">
    <h3>${f.more}</h3>
    ${f.moreList.map(x=>`<p>• ${x}</p>`).join("")}
  </div>`;
}

function freeView(){
  const f = F();
  const dayKey = new Date().toISOString().slice(0,10);
  const done = S.habitsDone[dayKey] || [];
  return `
    <div class="card">
      <h3>${f.daily}</h3>
      <p>${f.prompts[new Date().getDay() % f.prompts.length]}</p>
    </div>
    <div class="card">
      <h3>${f.journal}</h3>
      <textarea id="journalTxt" rows="4" placeholder="${f.journalPh}"></textarea>
      <button id="saveJournal">${f.saveJournal}</button>
      ${(S.journal||[]).slice(0,5).map(j=>`<p class="muted">${new Date(j.at).toLocaleString()} — ${j.text.slice(0,80)}</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.mood}</h3>
      <div class="row">${f.moods.map(m=>`<button class="ghost" data-mood="${m}">${m}</button>`).join("")}</div>
      <p class="muted">${(S.moodLog||[]).slice(0,3).map(m=>m.mood).join(" · ")}</p>
    </div>
    <div class="card">
      <h3>${f.habits}</h3>
      ${f.habitList.map((h,i)=>`<label><input type="checkbox" data-hab="${i}" ${done.includes(i)?"checked":""}/> ${h}</label><br/>`).join("")}
    </div>
    <div class="card">
      <h3>${f.canvas}</h3>
      <input id="optA" placeholder="${f.optA}" />
      <input id="optB" placeholder="${f.optB}" />
      <button id="saveDecision">${f.decide}</button>
    </div>
    <div class="card">
      <h3>${f.lessons}</h3>
      ${f.lessonsList.map((l,i)=>`<details><summary>${l.t}</summary><p>${l.b}</p></details>`).join("")}
    </div>
    <div class="card">
      <h3>${f.packs}</h3>
      ${f.packsList.map(p=>`<button class="ghost" data-pack="${p}">${p}</button>`).join("")}
    </div>
    <div class="card">
      <h3>${f.check}</h3>
      ${f.checks.map(c=>`<p>• ${c}</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.quotes}</h3>
      ${f.quoteList.map(q=>`<p class="muted">“${q}”</p>`).join("")}
    </div>
    <div class="card">
      <h3>${f.more}</h3>
      ${f.moreList.map(x=>`<p>• ${x}</p>`).join("")}
    </div>`;
}

function echoesView() {
  const i = t();
  const list = S.echoes.filter(e =>
    (filter==="all"||e.type===filter) &&
    (e.title+" "+e.summary).toLowerCase().includes(q.toLowerCase())
  );
  return `
    <input id="search" placeholder="${i.search}" value="${q}" />
    <div class="row">
      <button class="ghost ${filter==="all"?"on":""}" data-f="all">${i.filterAll}</button>
      ${types.map(tp=>`<button class="ghost" data-f="${tp}">${i.types[tp]}</button>`).join("")}
    </div>
    <button id="btnNew">${i.create}</button>
    ${list.length? list.map(echoCard).join("") : `<div class="card">${i.empty}</div>`}
  `;
}

function echoCard(e) {
  const i = t();
  const fav = S.favs.includes(e.id);
  return `<article class="card echo">
    <div class="meta">${i.types[e.type]} • ${new Date(e.createdAt).toLocaleString()}</div>
    <h3>${e.title}</h3>
    <p>${e.summary}</p>
    <div class="price">${money(e.price)}</div>
    <div class="row">
      <button data-sell="${e.id}">${e.listed?i.unsell:i.sell}</button>
      <button class="ghost" data-lic="${e.id}">${i.license}</button>
      <button class="ghost" data-fav="${e.id}">${fav?"★":"☆"} ${i.fav}</button>
    </div>
  </article>`;
}

function marketView() {
  const i = t();
  const listed = S.echoes.filter(e=>e.listed);
  return `
    <h3>${i.discover}</h3>
    ${listed.length? listed.map(echoCard).join("") : `<div class="card">${i.marketEmpty}</div>`}
    <div class="card">
      <h3>${i.premium}</h3>
      <p class="muted">${i.premiumDesc}</p>
      <button id="btnPro">${S.pro?i.subscribed:i.subscribe}</button>
      ${S.pro?"":`<button class="ghost" id="btnPaid">${i.alreadyPaid}</button>`}
    </div>
  `;
}

function earnView() {
  const i = t();
  const c1 = Math.min(3, S.echoes.length);
  return `
    <div class="card">
      <h3>${i.challenges}</h3>
      <p>${i.challenge1} — ${c1}/3</p>
      <div class="progress"><div class="bar" style="width:${(c1/3)*100}%"></div></div>
      <p>${i.challenge2} — ${Math.min(1,S.sold)}/1</p>
      <p>${i.challenge3} — 0/1</p>
    </div>
    <div class="card">
      <h3>${i.referral}</h3>
      <code>ECHO-${(S.session.name||"USER").slice(0,4).toUpperCase()}26</code>
      <button id="copyRef" class="ghost">${i.copyCode}</button>
    </div>
    <div class="card">
      <h3>${i.goals}</h3>
      <input id="goal" type="number" value="${S.goal}" />
      <button id="saveGoal">${i.goalEarn}</button>
    </div>
  `;
}

function profileView() {
  const i = t();
  const u = S.users.find(x=>x.email===S.session.email) || S.session;
  return `
    <div class="card">
      <div class="feed-item">
        <div class="avatar">${u.name[0]}</div>
        <div>
          <b>${u.name}</b>
          <div class="meta">${u.email}</div>
          <div class="ok">${i.verified} • ${i.rank}: ${level()}</div>
        </div>
      </div>
      <label class="muted">${i.bio}</label>
      <textarea id="bio">${u.bio||""}</textarea>
      <button id="saveBio">${i.profile}</button>
    </div>
    <div class="card">
      <h3>${i.privacy}</h3>
      <label><input id="cap" type="checkbox" ${S.capture?"checked":""}/> ${i.capture}</label><br/>
      <label><input id="anon" type="checkbox" ${S.anon?"checked":""}/> ${i.anon}</label>
      <button id="wipe" class="danger">${i.wipe}</button>
    </div>
    <div class="card">
      <h3>${i.payTitle}</h3>
      <p class="muted">${i.payHint}</p>
      <input id="stripeLink" placeholder="https://buy.stripe.com/..." value="${S.stripeLink||""}" />
      <button id="saveStripe">${i.paySave}</button>
    </div>
    <div class="card">
      <h3>${i.support}</h3>
      <p class="muted">${i.faq}</p>
    </div>
    <button id="logout" class="ghost">${i.logout}</button>
  `;
}

function wire() {
  const n = $("btnNew"); if (n) n.onclick = openCreate;
  const up = $("usePrompt"); if (up) up.onclick = () => {
    const f=F(); const p = f.prompts[new Date().getDay() % f.prompts.length];
    addFreeEcho("Rotina", p, p);
  };
  const sj = $("saveJournal"); if (sj) sj.onclick = () => {
    const text = ($("journalTxt").value||"").trim();
    if (!text) return;
    S.journal = [{at:Date.now(), text}, ...(S.journal||[])];
    save(); paint();
  };
  document.querySelectorAll("[data-mood]").forEach(b => b.onclick = () => {
    S.moodLog = [{at:Date.now(), mood:b.dataset.mood}, ...(S.moodLog||[])];
    save(); paint();
  });
  document.querySelectorAll("[data-hab]").forEach(b => b.onchange = () => {
    const dayKey = new Date().toISOString().slice(0,10);
    const cur = new Set(S.habitsDone[dayKey]||[]);
    const i = +b.dataset.hab;
    b.checked ? cur.add(i) : cur.delete(i);
    S.habitsDone[dayKey] = [...cur];
    save();
  });
  const sd = $("saveDecision"); if (sd) sd.onclick = () => {
    const a1=$("optA").value||"A"; const b1=$("optB").value||"B";
    addFreeEcho("Decisão", a1+" vs "+b1, a1+" | "+b1);
  };
  document.querySelectorAll("[data-pack]").forEach(b => b.onclick = () => addFreeEcho("Rotina", b.dataset.pack, b.dataset.pack));

  const s = $("search"); if (s) s.oninput = () => { q=s.value; paint(); };
  document.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { filter=b.dataset.f; paint(); });
  document.querySelectorAll("[data-sell]").forEach(b => b.onclick = () => {
    S.echoes = S.echoes.map(e => e.id===b.dataset.sell ? {...e, listed:!e.listed}:e);
    save(); paint();
  });
  document.querySelectorAll("[data-lic]").forEach(b => b.onclick = () => {
    const e = S.echoes.find(x=>x.id===b.dataset.lic);
    if (!e) return;
    S.sold += 1; S.wallet += e.price; S.streak += 1;
    notify(`${t().licensed}: ${e.title} • ${money(e.price)}`);
    save(); paint();
  });
  document.querySelectorAll("[data-fav]").forEach(b => b.onclick = () => {
    S.favs = S.favs.includes(b.dataset.fav) ? S.favs.filter(id=>id!==b.dataset.fav) : [...S.favs,b.dataset.fav];
    save(); paint();
  });
  const p = $("btnPro"); if (p) p.onclick = () => startCheckout();
  const paid = $("btnPaid"); if (paid) paid.onclick = () => unlockPro();
  const c = $("copyRef"); if (c) c.onclick = () => { navigator.clipboard?.writeText("ECHO-REF26"); alert(t().copyCode); };
  const g = $("saveGoal"); if (g) g.onclick = () => { S.goal = Number($("goal").value||500); save(); paint(); };
  const sb = $("saveBio"); if (sb) sb.onclick = () => {
    S.users = S.users.map(u => u.email===S.session.email ? {...u, bio:$("bio").value}:u);
    save(); paint();
  };
  const cap = $("cap"); if (cap) cap.onchange = () => { S.capture = cap.checked; save(); };
  const anon = $("anon"); if (anon) anon.onchange = () => { S.anon = anon.checked; save(); };
  const w = $("wipe"); if (w) w.onclick = () => {
    if (!confirm(t().wipe+"?")) return;
    S.echoes=[]; S.sold=0; S.wallet=0; S.favs=[]; save(); paint();
  };
  const ss = $("saveStripe"); if (ss) ss.onclick = () => {
    const url = ($("stripeLink").value||"").trim();
    if (url.startsWith("sk_") || url.includes("sk_live") || url.includes("sk_test")) {
      alert(t().payHint); return;
    }
    S.stripeLink = url; save(); paint();
  };
  const lo = $("logout"); if (lo) lo.onclick = () => { S.session=null; save(); show("auth"); renderAuth(); };
}

function addFreeEcho(type, title, body){
  if (!S.pro && S.echoes.length >= FREE_ECHO_LIMIT) { tab = 3; paint(); return; }
  S.echoes.unshift({
    id: crypto.randomUUID(), type, title,
    summary: body.slice(0,180),
    price: prices[type]||49, listed:false, createdAt: Date.now()
  });
  save(); tab = 1; paint();
}

function startCheckout() {
  window.open(STRIPE_LINK, "_blank");
  const i = t();
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.payOpen}</h3>
    <p class="muted">${i.afterPay}</p>
    <div class="row">
      <button id="goStripe">${i.payOpen}</button>
      <button class="ghost" id="confirmPaid">${i.alreadyPaid}</button>
    </div>
  </div>`;
  $("goStripe").onclick = () => window.open(STRIPE_LINK, "_blank");
  $("confirmPaid").onclick = () => unlockPro();
}

function unlockPro() {
  S.pro = true;
  S.users = S.users.map(u => u.email===(S.session&&S.session.email)?{...u,pro:true}:u);
  notify(t().subscribed);
  save();
  $("modal").classList.add("hidden");
  paint();
}

function openCreate() {
  const i = t();
  if (!S.pro && S.echoes.length >= FREE_ECHO_LIMIT) {
    tab = 3; paint(); alert(i.payMissingUnlock || i.payMissing); return;
  }
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.create}</h3>
    <select id="echoType">${types.map(tp=>`<option value="${tp}">${i.types[tp]}</option>`).join("")}</select>
    <input id="echoTitle" placeholder="${i.title}" />
    <textarea id="echoBody" rows="4" placeholder="${i.body}"></textarea>
    <div class="row">
      <button class="ghost" id="btnCancel">${i.cancel}</button>
      <button id="btnSave">${i.generate}</button>
    </div>
  </div>`;
  $("btnCancel").onclick = () => $("modal").classList.add("hidden");
  $("btnSave").onclick = () => {
    const type = $("echoType").value;
    const title = $("echoTitle").value.trim() || i.types[type];
    const body = $("echoBody").value.trim() || title;
    S.echoes.unshift({
      id: crypto.randomUUID(), type, title,
      summary: `${i.types[type]} • ${body.slice(0,160)}`,
      price: prices[type], listed:false, createdAt: Date.now()
    });
    S.streak += 1;
    notify(i.create + ": " + title);
    save(); $("modal").classList.add("hidden"); paint();
  };
}

function openNotes() {
  const i = t();
  S.notes = S.notes.map(n => ({...n, read:true})); save(); renderBadge();
  $("modal").classList.remove("hidden");
  $("modal").innerHTML = `<div class="sheet">
    <h3>${i.notify}</h3>
    ${S.notes.length? S.notes.map(n=>`<div class="card"><div class="meta">${new Date(n.at).toLocaleString()}</div>${n.text}</div>`).join("") : `<p class="muted">${i.noNotify}</p>`}
    <button class="ghost" onclick="document.getElementById('modal').classList.add('hidden')">${i.cancel}</button>
  </div>`;
}

window.onload = () => {
  $("splashText").textContent = t().splash;
  setTimeout(() => {
    if (S.session) routeAfterLogin();
    else renderLanding();
  }, 800);
};
