const seed = {
  products: [
    { id: 1, name: 'Plaquettes Brembo', ref: 'BR-4582', cat: 'فحمات الفرامل', qty: 24, price: 320, cost: 210 },
    { id: 2, name: 'Disque Renault', ref: 'DR-2210', cat: 'أقراص الفرامل', qty: 8, price: 580, cost: 390 },
    { id: 3, name: 'Liquide DOT 4', ref: 'DOT-004', cat: 'زيت الفرامل', qty: 35, price: 85, cost: 42 }
  ],
  sales: [
    { id: 1, total: 1280, payment: 'نقدًا', date: '2026-10-10', customer: 'محمد أمين', productId: 1, qty: 4 },
    { id: 2, total: 760, payment: 'شيك', date: '2026-10-09', customer: 'شركة الأطلس', productId: 3, qty: 2 }
  ],
  expenses: [{ id: 1, cat: 'النقل', total: 300, date: '2026-10-10', method: 'نقدًا', desc: 'توصيل بضاعة' }],
  checks: [{ id: 1, no: 'CH-00452', name: 'شركة الأطلس', amount: 2400, due: '2026-10-18', status: 'معلّق' }],
  customers: [
    { id: 1, name: 'محمد أمين', phone: '0667000000', type: 'عميل فردي' },
    { id: 2, name: 'شركة الأطلس', phone: '0667111111', type: 'شركة' }
  ],
  companies: [{ id: 2, name: 'شركة الأطلس', phone: '0667111111', type: 'شركة', contact: 'قسم المشتريات' }],
  deliveries: []
};

const stored = JSON.parse(localStorage.getItem('afriquia_db') || 'null');
const db = stored || seed;
db.companies = db.companies || db.customers.filter((item) => item.type === 'شركة');
db.deliveries = db.deliveries || [];
let route = 'home';
let lang = 'ar';
const today = new Date().toISOString().slice(0, 10);
const $ = (selector) => document.querySelector(selector);
const money = (value) => new Intl.NumberFormat('fr-MA', { maximumFractionDigits: 0 }).format(Number(value) || 0) + ' DH';

const labels = {
  home: ['الرئيسية', 'Accueil'], inventory: ['المخزون', 'Stock'], sales: ['المبيعات', 'Ventes'],
  expenses: ['المصاريف اليومية', 'Dépenses'], reports: ['التقارير المالية', 'Rapports'],
  customers: ['العملاء', 'Clients'], companies: ['الشركات', 'Sociétés'], checks: ['دفتر الشيكات', 'Chèques'],
  delivery: ['وصل التسليم', 'Bons de livraison'], notifications: ['الإشعارات', 'Notifications'], backup: ['نسخة احتياطية', 'Sauvegarde']
};
const t = (key) => labels[key]?.[lang === 'ar' ? 0 : 1] || key;
const save = () => localStorage.setItem('afriquia_db', JSON.stringify(db));
function toast(message) { const element = $('#toast'); element.textContent = message; element.classList.add('show'); setTimeout(() => element.classList.remove('show'), 2200); }
function sum(items, key = 'total') { return items.reduce((total, item) => total + (Number(item[key]) || 0), 0); }
function currentSales() { return db.sales.filter((item) => item.date === today); }
function currentExpenses() { return db.expenses.filter((item) => item.date === today); }

function render() {
  $('#pageTitle').textContent = t(route);
  $('#app').innerHTML = (views[route] || views.home)();
  document.querySelectorAll('[data-route]').forEach((button) => button.classList.toggle('active', button.dataset.route === route));
  bind();
}

const views = {
  home: () => {
    const sales = sum(currentSales());
    const expenses = sum(currentExpenses());
    const stock = db.products.reduce((total, item) => total + item.qty * item.cost, 0);
    return `<section class="hero"><img src="assets/logo.png" alt="AFRIQUIA FREINS ZEMAMRA"><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>تسيير المخزون والمبيعات والحسابات</p><div class="hero-actions"><button class="primary" data-route="inventory">وضع التصفح 👁</button><button class="secondary" onclick="openForm('sale')">+ بيع جديد</button></div></section><div class="section-head"><h2>ملخص اليوم</h2><button class="link" data-route="reports">عرض التقارير</button></div><div class="kpis"><div class="kpi green"><span class="label">مبيعات اليوم</span><strong>${money(sales)}</strong></div><div class="kpi red"><span class="label">مصاريف اليوم</span><strong>${money(expenses)}</strong></div><div class="kpi"><span class="label">قيمة المخزون</span><strong>${money(stock)}</strong></div></div><div class="section-head"><h2>الوحدات</h2><span class="muted">إدارة المحل</span></div><div class="grid">${[['inventory', '📦'], ['sales', '🛒'], ['customers', '👥'], ['companies', '🏢'], ['delivery', '🧾'], ['expenses', '▤'], ['checks', '▣'], ['reports', '◴'], ['notifications', '🔔'], ['backup', '↥']].map((item, index) => `<button class="tile ${index === 0 ? 'featured' : ''}" data-route="${item[0]}"><span>${item[1]}</span><small>${t(item[0])}</small></button>`).join('')}</div>`;
  },
  inventory: () => `<div class="page-header"><h1>${t('inventory')}</h1><button class="add-btn" onclick="openForm('product')">+ منتج</button></div><input class="search" id="productSearch" placeholder="ابحث بالاسم أو المرجع..."/><div class="tabs"><button class="tab active">الكل (${db.products.length})</button><button class="tab">منخفض المخزون</button><button class="tab">فحمات الفرامل</button></div><div class="card list" id="productList">${db.products.map((product) => `<div class="row"><div class="product-row"><div class="product-icon">⚙️</div><div><b>${product.name}</b><div class="muted">${product.ref} · ${product.cat}</div><div class="progress"><i style="width:${Math.min(product.qty * 3, 100)}%"></i></div></div></div><div style="text-align:left"><b>${product.qty}</b><div class="muted">${money(product.price)}</div>${product.qty < 10 ? '<span class="badge danger">منخفض</span>' : '<span class="badge">متوفر</span>'}</div></div>`).join('')}</div>`,
  sales: () => `<div class="page-header"><h1>${t('sales')}</h1><button class="add-btn" onclick="openForm('sale')">+ بيع جديد</button></div><div class="kpis"><div class="kpi green"><span class="label">مبيعات اليوم</span><strong>${money(sum(currentSales()))}</strong></div><div class="kpi"><span class="label">الفواتير</span><strong>${currentSales().length}</strong></div><div class="kpi"><span class="label">آجل</span><strong>${money(sum(currentSales().filter((item) => item.payment === 'آجل')))}</strong></div></div><div class="card list"><div class="section-head"><h2>آخر المبيعات</h2><span class="muted">اليوم</span></div>${db.sales.slice().reverse().map((sale) => `<div class="row"><div class="row-main"><div class="avatar">🧾</div><div><b>#${String(sale.id).slice(-4)} · ${sale.customer}</b><div class="muted">${sale.date} · ${sale.payment}</div></div></div><div class="amount">${money(sale.total)}</div></div>`).join('')}</div>`,
  expenses: () => `<div class="page-header"><h1>${t('expenses')}</h1><button class="add-btn" onclick="openForm('expense')">+ مصروف</button></div><div class="card"><div class="section-head"><h2>مصاريف اليوم</h2><span class="amount">${money(sum(currentExpenses()))}</span></div><div class="list">${db.expenses.slice().reverse().map((expense) => `<div class="row"><div class="row-main"><div class="avatar">▤</div><div><b>${expense.cat}</b><div class="muted">${expense.desc} · ${expense.method}</div></div></div><div class="amount">-${money(expense.total)}</div></div>`).join('')}</div></div>`,
  checks: () => `<div class="page-header"><h1>${t('checks')}</h1><button class="add-btn" onclick="openForm('check')">+ شيك</button></div><div class="tabs"><button class="tab active">الكل</button><button class="tab">صادرة</button><button class="tab">واردة</button></div><div class="card list">${db.checks.map((check) => `<div class="row"><div class="row-main"><div class="avatar">▣</div><div><b>${check.no} · ${check.name}</b><div class="muted">يستحق في ${check.due}</div></div></div><div style="text-align:left"><b>${money(check.amount)}</b><br><span class="badge warn">${check.status}</span></div></div>`).join('')}</div>`,
  customers: () => `<div class="page-header"><h1>${t('customers')}</h1><button class="add-btn" onclick="openForm('customer')">+ عميل</button></div><input class="search" placeholder="ابحث عن عميل..."/><div class="card list">${db.customers.map((customer) => `<div class="row"><div class="row-main"><div class="avatar">${customer.type === 'شركة' ? '🏢' : '👤'}</div><div><b>${customer.name}</b><div class="muted">${customer.type} · ${customer.phone || 'بدون هاتف'}</div></div></div><button class="link">كشف الحساب</button></div>`).join('')}</div>`,
  companies: () => `<div class="page-header"><h1>${t('companies')}</h1><button class="add-btn" onclick="openForm('company')">+ شركة</button></div><input class="search" placeholder="ابحث عن شركة..."/><div class="card list">${db.companies.map((company) => `<div class="row"><div class="row-main"><div class="avatar">🏢</div><div><b>${company.name}</b><div class="muted">${company.contact || 'حساب مهني'} · ${company.phone || 'بدون هاتف'}</div></div></div><button class="link">كشف الحساب</button></div>`).join('')}</div>`,
  delivery: () => `<div class="page-header"><h1>${t('delivery')}</h1><button class="add-btn" onclick="openForm('delivery')">+ وصل</button></div><div class="card list">${db.deliveries.length ? db.deliveries.map((delivery) => `<div class="row"><div class="row-main"><div class="avatar">🧾</div><div><b>${delivery.no} · ${delivery.customer}</b><div class="muted">${delivery.date} · ${delivery.status}</div></div></div><div class="amount">${money(delivery.total)}</div></div>`).join('') : '<div class="empty">لا توجد أوصال تسليم مسجلة اليوم.<br><button class="primary" style="margin-top:14px" onclick="openForm(\'delivery\')">إنشاء أول وصل</button></div>'}</div>`,
  reports: () => {
    const sales = sum(db.sales);
    const expenses = sum(db.expenses);
    const days = Array.from({ length: 7 }, (_, index) => { const date = new Date(); date.setDate(date.getDate() - (6 - index)); const key = date.toISOString().slice(0, 10); return { label: key.slice(8), value: sum(db.sales.filter((item) => item.date === key)) }; });
    const max = Math.max(...days.map((day) => day.value), 1);
    return `<div class="page-header"><h1>${t('reports')}</h1><button class="add-btn" onclick="window.print()">طباعة التقرير</button></div><div class="card"><div class="section-head"><h2>الأداء المالي</h2><span class="muted">آخر 7 أيام</span></div><div class="chart">${days.map((day) => `<div class="bar-wrap"><div class="bar" style="height:${Math.max((day.value / max) * 85, 8)}%"></div><small>${day.label}</small></div>`).join('')}</div></div><div class="kpis"><div class="kpi green"><span class="label">إجمالي المبيعات</span><strong>${money(sales)}</strong></div><div class="kpi red"><span class="label">المصاريف</span><strong>${money(expenses)}</strong></div><div class="kpi"><span class="label">الصافي</span><strong>${money(sales - expenses)}</strong></div></div><div class="card list"><div class="section-head"><h2>تقارير جاهزة</h2></div>${[['📊', 'تقرير المبيعات', 'حسب المنتج والعميل'], ['💳', 'تقرير الخزينة والبنك', 'المقبوضات والمدفوعات'], ['▣', 'تقرير الشيكات', 'المعلقة والمصروفة'], ['📦', 'تقرير المخزون والربحية', 'القيمة والهامش']].map((item) => `<button class="row" style="text-align:right;background:none;width:100%"><div class="row-main"><div class="avatar">${item[0]}</div><div><b>${item[1]}</b><div class="muted">${item[2]}</div></div></div><span>‹</span></button>`).join('')}</div>`;
  },
  notifications: () => `<div class="page-header"><h1>${t('notifications')}</h1></div><div class="card list"><div class="row"><div class="row-main"><div class="avatar">⚠️</div><div><b>مخزون Disque Renault منخفض</b><div class="muted">متبقي 8 قطع فقط</div></div></div><span class="badge danger">مهم</span></div><div class="row"><div class="row-main"><div class="avatar">▣</div><div><b>شيك يستحق قريبًا</b><div class="muted">CH-00452 · 18 أكتوبر</div></div></div><span class="badge warn">تنبيه</span></div></div>`,
  backup: () => `<div class="page-header"><h1>${t('backup')}</h1></div><div class="card"><h2>حماية بياناتك</h2><p class="muted">احفظ نسخة من المنتجات والمبيعات والمصاريف والشيكات على جهازك أو استرجع نسخة سابقة.</p><button class="submit" onclick="downloadBackup()">تحميل نسخة احتياطية JSON</button><button class="secondary" style="color:var(--blue);background:var(--pale);width:100%;margin-top:10px" onclick="restoreBackup()">استرجاع نسخة JSON</button></div>`
};

function bind() {
  document.querySelectorAll('[data-route]').forEach((button) => { button.onclick = () => { route = button.dataset.route; render(); }; });
  const search = $('#productSearch');
  if (search) search.oninput = () => document.querySelectorAll('#productList .row').forEach((row) => { row.style.display = row.textContent.toLowerCase().includes(search.value.toLowerCase()) ? 'flex' : 'none'; });
}

function openForm(type) {
  const titles = { product: 'إضافة منتج', sale: 'تسجيل بيع جديد', expense: 'إضافة مصروف يومي', check: 'تسجيل شيك', customer: 'إضافة عميل', company: 'إضافة شركة', delivery: 'إنشاء وصل تسليم' };
  const productOptions = db.products.map((product) => `<option value="${product.id}">${product.name} · ${money(product.price)}</option>`).join('');
  const fields = {
    product: `<div class="field"><label>اسم المنتج</label><input name="name" required placeholder="مثال: Plaquettes Brembo"></div><div class="field"><label>المرجع</label><input name="ref" placeholder="BR-0000"></div><div class="field"><label>الكمية</label><input name="qty" type="number" min="0" value="1"></div><div class="field"><label>سعر البيع</label><input name="price" type="number" min="0" value="0"></div><div class="field"><label>سعر الشراء</label><input name="cost" type="number" min="0" value="0"></div>`,
    sale: `<div class="field full"><label>القطعة</label><select name="productId"><option value="">بيع عام بدون ربط قطعة</option>${productOptions}</select></div><div class="field"><label>العميل</label><input name="customer" value="عميل نقدي"></div><div class="field"><label>الكمية</label><input name="qty" type="number" min="1" value="1"></div><div class="field"><label>المبلغ الإجمالي</label><input name="total" type="number" min="0" required></div><div class="field"><label>طريقة الدفع</label><select name="payment"><option>نقدًا</option><option>تحويل بنكي</option><option>شيك</option><option>آجل</option></select></div>`,
    expense: `<div class="field"><label>التصنيف</label><select name="cat"><option>النقل</option><option>الكراء</option><option>الكهرباء والماء</option><option>الأجور</option><option>مصاريف متنوعة</option></select></div><div class="field"><label>المبلغ</label><input name="total" type="number" min="0" required></div><div class="field full"><label>الوصف</label><input name="desc" placeholder="وصف المصروف"></div>`,
    check: `<div class="field"><label>رقم الشيك</label><input name="no" required></div><div class="field"><label>المستفيد</label><input name="name" required></div><div class="field"><label>المبلغ</label><input name="amount" type="number" min="0" required></div><div class="field"><label>تاريخ الاستحقاق</label><input name="due" type="date"></div>`,
    customer: `<div class="field full"><label>الاسم</label><input name="name" required></div><div class="field"><label>الهاتف</label><input name="phone"></div><div class="field"><label>النوع</label><select name="type"><option>عميل فردي</option><option>شركة</option></select></div>`,
    company: `<div class="field full"><label>اسم الشركة</label><input name="name" required></div><div class="field"><label>الهاتف</label><input name="phone"></div><div class="field"><label>جهة الاتصال</label><input name="contact" placeholder="المسؤول أو القسم"></div>`,
    delivery: `<div class="field"><label>رقم الوصل</label><input name="no" required value="BL-${Date.now().toString().slice(-5)}"></div><div class="field"><label>العميل</label><input name="customer" required></div><div class="field"><label>الإجمالي</label><input name="total" type="number" min="0" value="0"></div><div class="field"><label>الحالة</label><select name="status"><option>مسودة</option><option>جاهز للتسليم</option><option>تم التسليم</option></select></div>`
  }[type];
  $('#modal').innerHTML = `<button class="close" onclick="closeModal()">×</button><h2>${titles[type]}</h2><form id="dataForm" class="form-grid">${fields}<div class="field full"><button class="submit">حفظ العملية</button></div></form>`;
  $('#modalBackdrop').classList.add('open');
  $('#dataForm').onsubmit = (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target));
    const id = Date.now();
    if (type === 'product') db.products.push({ ...data, id, qty: Number(data.qty), price: Number(data.price), cost: Number(data.cost), cat: 'قطع فرامل' });
    if (type === 'sale') {
      const product = db.products.find((item) => String(item.id) === data.productId);
      const qty = Number(data.qty) || 1;
      const total = Number(data.total) || (product ? product.price * qty : 0);
      if (product && product.qty < qty) return toast('الكمية المطلوبة غير متوفرة');
      if (product) product.qty -= qty;
      db.sales.push({ ...data, id, qty, total, date: today });
    }
    if (type === 'expense') db.expenses.push({ ...data, id, total: Number(data.total), date: today, method: 'نقدًا' });
    if (type === 'check') db.checks.push({ ...data, id, amount: Number(data.amount), status: 'معلّق' });
    if (type === 'customer') db.customers.push({ ...data, id });
    if (type === 'company') db.companies.push({ ...data, id, type: 'شركة' });
    if (type === 'delivery') db.deliveries.push({ ...data, id, total: Number(data.total), date: today });
    save(); closeModal(); render(); toast('تم الحفظ بنجاح');
  };
}

function closeModal() { $('#modalBackdrop').classList.remove('open'); }
function downloadBackup() { const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' })); link.download = `afriquia-backup-${today}.json`; link.click(); toast('تم تحميل النسخة الاحتياطية'); }
function restoreBackup() { const input = document.createElement('input'); input.type = 'file'; input.accept = 'application/json,.json'; input.onchange = () => { const file = input.files[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { try { const imported = JSON.parse(reader.result); if (!imported.products || !imported.sales || !imported.expenses) throw new Error('invalid'); Object.keys(imported).forEach((key) => { db[key] = imported[key]; }); save(); render(); toast('تم استرجاع النسخة بنجاح'); } catch { toast('ملف النسخة غير صالح'); } }; reader.readAsText(file); }; input.click(); }

$('#modalBackdrop').onclick = (event) => { if (event.target.id === 'modalBackdrop') closeModal(); };
$('#langBtn').onclick = () => { lang = lang === 'ar' ? 'fr' : 'ar'; document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; $('#langBtn').textContent = lang === 'ar' ? 'Français' : 'العربية'; render(); };
$('#menuBtn').onclick = () => toast('استخدم بطاقات الوحدات للتنقل');
render();
