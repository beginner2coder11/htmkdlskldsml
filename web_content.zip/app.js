const products=[
["Hamburguesas","Hamburguesa de carne",10],
["Hamburguesas","Hamburguesa de pollo",12],
["Hamburguesas","Hamburguesa mixta",14],
["Hamburguesas","Hamburguesa de la casa",20],
["Alitas Gourmet","4 alitas gourmet",15],
["Alitas Gourmet","8 alitas gourmet",20],
["Alitas Gourmet","16 alitas gourmet",35],
["Salchipapas","Salchipapas a lo pobre",10],
["Salchipapas","Papicarne a lo pobre",12],
["Salchipapas","Papipollo a lo pobre",13],
["Salchipapas","Papi-mixto a lo pobre",15],
["Especiales","Club House (para 2 personas)",25],
["Arroz Chino","Arroz, pollo y jamón",12],
["Arroz Chino","Arroz, pollo, jamón y camarones",16],
["Lumpias","1 rollo de primavera",5],
["Lumpias","3 rollos de primavera",12]
];

let cart=[];
const categories=document.getElementById("categories");
[...new Set(products.map(p=>p[0]))].forEach(cat=>{
  const sec=document.createElement("section"); sec.className="category";
  sec.innerHTML=`<h2>${cat}</h2><div class="grid"></div>`;
  const grid=sec.querySelector(".grid");
  products.filter(p=>p[0]===cat).forEach((p,i)=>{
    const div=document.createElement("div"); div.className="product";
    div.innerHTML=`<h3>${p[1]}</h3><div class="price">S/ ${p[2].toFixed(2)}</div><button class="add">Agregar</button>`;
    div.querySelector("button").onclick=()=>add(p);
    grid.appendChild(div);
  });
  categories.appendChild(sec);
});
function add(p){const x=cart.find(i=>i[1]===p[1]);x?x[3]++:cart.push([p[0],p[1],p[2],1]);render()}
function render(){
 const box=document.getElementById("cartItems"); box.innerHTML="";
 if(!cart.length){box.innerHTML='<p class="empty">Tu carrito está vacío.</p>';document.getElementById("total").textContent="0.00";return}
 let total=0;
 cart.forEach((x,idx)=>{total+=x[2]*x[3];const row=document.createElement("div");row.className="cartrow";
 row.innerHTML=`<div><b>${x[1]}</b><br>S/ ${(x[2]*x[3]).toFixed(2)}</div><div class="qty"><button onclick="change(${idx},-1)">−</button> ${x[3]} <button onclick="change(${idx},1)">+</button></div>`;box.appendChild(row)});
 document.getElementById("total").textContent=total.toFixed(2);
}
function change(i,n){cart[i][3]+=n;if(cart[i][3]<=0)cart.splice(i,1);render()}
document.getElementById("clear").onclick=()=>{cart=[];render()};
document.getElementById("whatsapp").onclick=()=>{
 if(!cart.length){alert("Agrega productos al carrito primero.");return}
 let msg="Hola Gordo Burguer 👋%0AQuiero hacer este pedido:%0A";
 cart.forEach(x=>msg+=`%0A${x[3]} x ${x[1]} - S/ ${(x[2]*x[3]).toFixed(2)}`);
 const total=cart.reduce((s,x)=>s+x[2]*x[3],0);
 msg+=`%0A%0ATotal: S/ ${total.toFixed(2)}%0A%0ANombre:%0ADirección:%0AMétodo de pago:`;
 window.open("https://wa.me/51955201233?text="+msg,"_blank");
};
render();