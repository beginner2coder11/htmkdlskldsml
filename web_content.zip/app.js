/* アッシュのひなた Ver 2.5 — device clock, GPS weather, and natural blinks; local-first PWA */
'use strict';
const $=id=>document.getElementById(id);
const sprite=(costume,pose)=>`./images/poses/${costume}/${pose}.webp`;
const walkFrame=(costume,direction,index)=>`./images/walk/${costume}/${direction}/${index}.webp`;
const COSTUMES={normal:'いつもの姿',rider:'ライダージャケット',japan:'日本代表ユニフォーム',camo:'迷彩ダウンベスト'};
const START={version:2,outfit:'normal',mode:'idle',bond:10,walks:0,pets:0,sits:0,sleeps:0,treats:0,calls:0,opened:0,history:[],lastSaved:0};
const SAVE_KEY='ash-hinata-yoh-v2';
let data=loadData(),mode='idle',frameIndex=-1,frameDirection='right',frameCostume='',previousImage='',lastWalkFrame=0,walkEpoch=performance.now(),walkRAF=0;
let blinkTimer=null,blinkFrameTimer=null,tiltTimer=null,tiltEndTimer=null,blinkPhase=0,sitTilt="",bubbleTimer=null,returnTimer=null,toastTimer=null,mic=null,micActive=false,micWanted=false,photoDb=null,photos=[],audioContext=null,installPrompt=null,saveOk=true;
const builtin=[
{src:'./photos/01.webp',title:'稲佐山公園',description:'芝生を駆け寄ってくるアッシュ'},
{src:'./photos/02.webp',title:'ヘルメット',description:'黒いヘルメットをかぶったアッシュ'},
{src:'./photos/03.webp',title:'いつものまなざし',description:'おうちでくつろぐアッシュ'},
{src:'./photos/04.webp',title:'お出かけリュック',description:'ゴーグルをつけてお出かけ準備'},
{src:'./photos/05.webp',title:'アッシュライダー',description:'スクーターに乗るアッシュのイメージ'},
{src:'./photos/06.webp',title:'ドライブ',description:'ハンドルに前足をのせた思い出'},
{src:'./photos/07.webp',title:'うとうと',description:'抱っこで目を閉じるアッシュ'}];
function loadData(){try{const d=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return d&&d.version===2?{...START,...d,history:Array.isArray(d.history)?d.history:[]}:structuredClone(START)}catch{return {...START,history:[]}}}
function save(){try{data.lastSaved=Date.now();localStorage.setItem(SAVE_KEY,JSON.stringify(data));saveOk=true;$('saveStatus').textContent='● この端末に保存済み · オフラインでも遊べます';}catch(err){saveOk=false;$('saveStatus').textContent='保存容量を確認してください · おもいでからバックアップ可能';toast('保存できませんでした。容量やブラウザ設定を確認してください。')}}
function log(label){data.history.unshift({at:Date.now(),label});data.history=data.history.slice(0,1000);save()}
function updateSelected(){document.querySelectorAll('.action').forEach(b=>b.classList.toggle('active',b.dataset.action===mode))}
function setPose(pose){const url=sprite(data.outfit,pose);if(previousImage!==url){$('petImage').src=url;previousImage=url;} $('pet').classList.toggle('sleeping',pose==='sleep');$('pet').classList.toggle('animated',false);}
// Stand frames are sampled from the supplied six-frame animation sheet.
// The sitting poses retain their existing closed-eye versions during head tilts.
// Only timers drive eye animation; no CSS scaling/opacity that alters Ash's face.
function clearAmbient(){
  clearTimeout(blinkTimer);clearTimeout(blinkFrameTimer);
  clearTimeout(tiltTimer);clearTimeout(tiltEndTimer);
  blinkTimer=blinkFrameTimer=tiltTimer=tiltEndTimer=null;
  blinkPhase=0;sitTilt='';
}
function restingExpression(){
  if(mode==='sit'){
    const closed=blinkPhase===3;
    const pose=sitTilt?`sit_tilt_${sitTilt}${closed?'_blink':''}`:(closed?'sit_blink':'sit');
    setPose(pose);
  }else if(mode==='idle'){
    // The normal outfit uses the provided standing dog; dressed variants have their own sitting blink assets.
    if(data.outfit==='normal')setPose(`stand_${blinkPhase}`);
    else setPose(blinkPhase===3?'blink':'idle');
  }
}
function scheduleBlink(delay=2200+Math.random()*3200){
  if(mode!=='idle'&&mode!=='sit')return;
  clearTimeout(blinkTimer);
  blinkTimer=setTimeout(playBlink,delay);
}
function playBlink(){
  if((mode!=='idle'&&mode!=='sit')||document.hidden)return;
  // Full standing cycle: open → half closed → closed → half open → open.
  // Seated/costumed poses switch between their matching open/closed assets.
  const frames=(mode==='idle'&&data.outfit==='normal')
    ? [{phase:1,ms:52},{phase:2,ms:72},{phase:3,ms:112},{phase:4,ms:78},{phase:5,ms:60},{phase:0,ms:45}]
    : [{phase:3,ms:155},{phase:0,ms:55}];
  let index=0;
  const next=()=>{
    if((mode!=='idle'&&mode!=='sit')||document.hidden)return;
    const frame=frames[index++];
    blinkPhase=frame.phase;restingExpression();
    if(index<frames.length){blinkFrameTimer=setTimeout(next,frame.ms)}
    else{blinkFrameTimer=setTimeout(()=>{
      if((mode!=='idle'&&mode!=='sit')||document.hidden)return;
      blinkPhase=0;restingExpression();
      if(Math.random()<.14)scheduleBlink(230+Math.random()*140); // occasional natural double blink
      else scheduleBlink();
    },frame.ms)}
  };
  next();
}
function scheduleTilt(){
  if(mode!=='sit')return;
  tiltTimer=setTimeout(()=>{
    if(mode!=='sit'||document.hidden)return;
    sitTilt=Math.random()<.5?'left':'right';restingExpression();
    tiltEndTimer=setTimeout(()=>{
      if(mode!=='sit'||document.hidden)return;
      sitTilt='';restingExpression();scheduleTilt();
    },1450+Math.random()*550);
  },3100+Math.random()*3200);
}
function beginAmbient(){
  clearAmbient();
  if(mode!=='idle'&&mode!=='sit')return;
  restingExpression();
  scheduleBlink(1400+Math.random()*1300);
  if(mode==='sit')scheduleTilt();
}
function warmExpressions(outfit){
  const poses=['idle','blink','sit','sit_blink','sit_tilt_left','sit_tilt_right','sit_tilt_left_blink','sit_tilt_right_blink'];
  if(outfit==='normal')poses.push('stand_0','stand_1','stand_2','stand_3','stand_4','stand_5');
  for(const pose of poses){const img=new Image();img.src=sprite(outfit,pose)}
}
function setBubble(t,ms=2600){const el=$('speech');el.textContent=t;el.classList.add('show');clearTimeout(bubbleTimer);bubbleTimer=setTimeout(()=>el.classList.remove('show'),ms)}
function toast(t){const el=$('toast');el.textContent=t;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function hearts(){const target=$('hearts');for(let i=0;i<5;i++){const e=document.createElement('span');e.className='floating-heart';e.textContent='♥';e.style.left=`${i*17-25}px`;e.style.setProperty('--dx',`${(i-2)*13}px`);e.style.animationDelay=`${i*80}ms`;target.appendChild(e);setTimeout(()=>e.remove(),1900)}}
function resetPosition(){ $('pet').style.transform='translateX(0) scale(1)';$('pet').classList.remove('coming','petting','happy');}
function stopWalk(){if(walkRAF)cancelAnimationFrame(walkRAF);walkRAF=0;$('pet').classList.remove('animated');}
function setMode(next){clearTimeout(returnTimer);clearAmbient();stopWalk();mode=next;data.mode=next;resetPosition();updateSelected();if(next==='walk'){walkEpoch=performance.now();frameIndex=-1;frameCostume='';$('statusText').textContent='いっしょに、おさんぽ';walkRAF=requestAnimationFrame(animateWalk)}else if(next==='sleep'){$('statusText').textContent='すやすや、夢のなか';setPose('sleep');setBubble('すぅ… すぅ…',1800)}else if(next==='sit'){$('statusText').textContent='おりこうさん';setPose('sit');setBubble('じーっ。',1800)}else if(next==='happy'){$('statusText').textContent='しっぽをふりふり';setPose('happy')}else{$('statusText').textContent='いつもの、やさしい時間';restingExpression()}beginAmbient()}
function animateWalk(t){if(mode!=='walk')return;let passed=(t-walkEpoch)/21000;let part=((passed%2)+2)%2;let direction=part<1?'right':'left';let progress=part<1?part:2-part;let pos=progress*45;
  if(frameIndex===-1||t-lastWalkFrame>112||frameDirection!==direction||frameCostume!==data.outfit){
   frameIndex=(frameIndex+1)%8;frameDirection=direction;frameCostume=data.outfit;lastWalkFrame=t;
   const url=walkFrame(data.outfit,direction,frameIndex);if(previousImage!==url){$('petImage').src=url;previousImage=url;}
  }
  $('pet').classList.add('animated');$('pet').classList.remove('sleeping');$('pet').style.transform=`translateX(${pos}%)`;
  walkRAF=requestAnimationFrame(animateWalk);
}
function dogSound(kind){try{const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;if(!audioContext)audioContext=new Ctx();if(audioContext.state==='suspended')audioContext.resume();const t=audioContext.currentTime;
   if(kind==='huff'){const len=Math.ceil(audioContext.sampleRate*.22);const b=audioContext.createBuffer(1,len,audioContext.sampleRate);const ch=b.getChannelData(0);for(let i=0;i<len;i++){const env=Math.sin(Math.PI*i/len);ch[i]=(Math.random()*2-1)*env*.42;}const src=audioContext.createBufferSource();src.buffer=b;const low=audioContext.createBiquadFilter();low.type='lowpass';low.frequency.value=580;const g=audioContext.createGain();g.gain.value=.35;src.connect(low);low.connect(g);g.connect(audioContext.destination);src.start(t);src.stop(t+.22);}
   else{const o=audioContext.createOscillator(),g=audioContext.createGain();o.type='sine';o.frequency.setValueAtTime(670,t);o.frequency.exponentialRampToValueAtTime(840,t+.13);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.075,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.18);o.connect(g).connect(audioContext.destination);o.start(t);o.stop(t+.19);}
 }catch{}}
function petDog(){if(mode==='sleep')setMode('idle');data.pets++;data.bond=Math.min(100,data.bond+2);log('アッシュをなでた');setMode('happy');$('pet').classList.add('petting');hearts();dogSound('peep');setBubble('ピーピーピー♡');navigator.vibrate?.(24);returnTimer=setTimeout(()=>setMode('idle'),2200)}
function comeHere({fromVoice=false,autonomous=false}={}){if(mode==='sleep')setMode('idle');else if(mode==='walk')setMode('idle');else setMode('happy');
  $('pet').classList.add('coming');$('pet').style.transform='translateX(30%) scale(1.13)';$('pet').classList.add('happy');hearts();setBubble(autonomous?'アッシュが近寄ってきたよ。':fromVoice?'呼んだ？ ワン！':'ここにおるよ！');
  if(!autonomous){data.calls++;data.bond=Math.min(100,data.bond+1);log(fromVoice?'「アッシュ」の声に反応':'アッシュを呼んだ');dogSound('peep')}
  returnTimer=setTimeout(()=>setMode('idle'),3400);
}
function giveTreat(){stopWalk();setMode('happy');data.treats++;data.bond=Math.min(100,data.bond+3);log('唐揚げを食べた');setBubble('もぐもぐ…',1200);hearts();returnTimer=setTimeout(()=>{dogSound('huff');setBubble('フッ！ もういらんばい。',2400);returnTimer=setTimeout(()=>setMode('idle'),2550)},1300)}
function action(kind){switch(kind){case 'walk':setMode('walk');data.walks++;data.bond=Math.min(100,data.bond+1);log('おさんぽした');break;case 'pet':petDog();break;case 'sit':setMode('sit');data.sits++;log('おすわりした');break;case 'sleep':setMode('sleep');data.sleeps++;log('おひるねした');break;}}
// Modal helpers
function openSheet(title,render){$('sheetTitle').textContent=title;$('sheetContent').replaceChildren();$('overlay').hidden=false;document.body.style.overflow='hidden';render($('sheetContent'))}
function closeSheet(){$('overlay').hidden=true;document.body.style.overflow=''}
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e}
function outfitSheet(){openSheet('おきがえ',content=>{content.appendChild(el('p','section-note','お気に入りの服で、おさんぽも、おひるねも。歩いている間も服は変わらないよ。'));const grid=el('div','outfit-grid');
 for(const [id,title] of Object.entries(COSTUMES)){const b=el('button','outfit-option'+(data.outfit===id?' selected':''));const im=el('img');im.src=sprite(id,'idle');im.alt=title;const n=el('strong','',title);b.append(im,n);b.addEventListener('click',()=>{data.outfit=id;warmExpressions(id);log(`${title}におきがえ`);$('statusText').textContent=title;closeSheet();if(mode==='walk'){frameIndex=-1;frameCostume=''}else if(mode==='sit'||mode==='idle'){restingExpression()}else{setPose(mode==='sleep'?'sleep':mode==='happy'?'happy':'idle')}setBubble('似合っとる？');toast(`${title}におきがえしたよ`)});grid.appendChild(b)}content.appendChild(grid)})}
function photoDbOpen(){return new Promise((resolve,reject)=>{if(!('indexedDB'in window)){reject(Error('IndexedDB unavailable'));return}const r=indexedDB.open('ash-hinata-photos-v1',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('photos'))r.result.createObjectStore('photos',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function idbAll(){return new Promise((resolve,reject)=>{const tx=photoDb.transaction('photos','readonly');const r=tx.objectStore('photos').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function idbPut(item){return new Promise((resolve,reject)=>{const tx=photoDb.transaction('photos','readwrite');tx.objectStore('photos').put(item);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function idbDelete(id){return new Promise((resolve,reject)=>{const tx=photoDb.transaction('photos','readwrite');tx.objectStore('photos').delete(id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function albumSheet(){openSheet('アッシュの思い出アルバム',async content=>{const p=el('p','section-note','アッシュの写真をいつでも。追加した写真も、この端末に保存するよ。');content.append(p);const add=el('button','wide-button','＋ 写真を追加する');add.onclick=()=>$('photoInput').click();content.append(add);const grid=el('div','album-grid');content.append(grid);await refreshAlbum(grid)})}
async function refreshAlbum(grid){grid.replaceChildren();let custom=[];if(photoDb){try{custom=await idbAll()}catch{}}for(const item of [...builtin,...custom]){
 const own='id'in item,card=el('div','photo-card'),img=el('img');img.src=own?URL.createObjectURL(item.blob):item.src;img.alt=item.title||'アッシュの写真';img.loading='lazy';img.onclick=()=>showLightbox(img.src);const details=el('div');details.append(el('strong','',item.title),el('p','',item.description||''));if(own){const remove=el('button','','この写真を削除');remove.onclick=async()=>{if(confirm('この写真をアルバムから削除しますか？')){await idbDelete(item.id);log('アルバムから写真を削除');await refreshAlbum(grid)}};details.append(remove)}card.append(img,details);grid.append(card)}}
function showLightbox(src){const wrap=el('div','lightbox');wrap.setAttribute('role','dialog');const image=el('img');image.src=src;const close=el('button','','×');close.setAttribute('aria-label','写真を閉じる');close.onclick=()=>wrap.remove();wrap.onclick=e=>{if(e.target===wrap)wrap.remove()};wrap.append(image,close);document.body.append(wrap)}
async function compressImage(file){const src=URL.createObjectURL(file);try{const img=new Image();await new Promise((yes,no)=>{img.onload=yes;img.onerror=no;img.src=src});const max=1280,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const cv=document.createElement('canvas');cv.width=Math.max(1,Math.floor(img.naturalWidth*scale));cv.height=Math.max(1,Math.floor(img.naturalHeight*scale));cv.getContext('2d',{alpha:false}).drawImage(img,0,0,cv.width,cv.height);return await new Promise((yes,no)=>cv.toBlob(b=>b?yes(b):no(Error('encode error')),'image/jpeg',.83))}finally{URL.revokeObjectURL(src)}}
async function addPhotos(files){if(!photoDb){toast('写真の保存機能を利用できません');return}let ok=0;for(const file of [...files].slice(0,25)){if(!file.type.startsWith('image/'))continue;try{const blob=await compressImage(file);const id=`${Date.now()}-${Math.random().toString(36).slice(2)}`;await idbPut({id,blob,title:file.name.replace(/\.[^.]+$/,'').slice(0,80),description:'追加した思い出の写真',at:Date.now()});ok++}catch(err){console.warn('photo not saved',err)}}if(ok){log(`アルバムに写真を${ok}枚追加`);toast(`${ok}枚の写真を保存したよ`);if(!$('overlay').hidden&&$('sheetTitle').textContent.includes('アルバム'))albumSheet()}else toast('写真を保存できませんでした')}
function historySheet(){openSheet('アッシュとのおもいで',content=>{
 const note=el('p','section-note','歩いた日、なでた回数、唐揚げの思い出。アプリを閉じても同じ端末に残るよ。');content.append(note);
 const stats=el('div','stat-grid');for(const [label,k] of [['おさんぽ','walks'],['なでなで','pets'],['からあげ','treats'],['呼んだ回数','calls'],['おひるね','sleeps'],['なかよし度','bond']]){const div=el('div','stat');div.append(el('strong','',String(data[k])),el('span','',label));stats.append(div)}content.append(stats);
 const backup=el('div','info-card');backup.append(el('strong','','大切な記録をバックアップ'));backup.append(el('p','help-text','スマホを買い替えたりブラウザの保存データを消したりすると記録が消えることがあります。JSONバックアップを保存しておけば復元できます。'));const buttons=el('div','buttons-row');const exp=el('button','sub-button','記録と写真を保存（JSON）');exp.onclick=exportBackup;const imp=el('button','sub-button','バックアップを復元');imp.onclick=()=>$('restoreInput').click();buttons.append(exp,imp);backup.append(buttons);content.append(backup);
 const perms=el('button','sub-button','端末に保存を保持する設定を要求');perms.onclick=async()=>{if(!navigator.storage?.persist){toast('このブラウザでは設定できません');return}const ok=await navigator.storage.persist();toast(ok?'保存を保持する設定が有効になったよ':'ブラウザの設定で許可されませんでした')};content.append(perms);
 const ttl=el('h3','','最近の思い出');content.append(ttl);const ul=el('ul','history-list');for(const h of data.history.slice(0,50)){const li=el('li');li.append(el('span','',h.label),el('time','',new Date(h.at).toLocaleString('ja-JP',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})));ul.append(li)}if(!ul.children.length)ul.append(el('li','','これから思い出を作ろう。'));content.append(ul)
})}
function profileSheet(){openSheet('アッシュのプロフィール',content=>{const im=el('img','profile-photo');im.src='./photos/03.webp';im.alt='アッシュの写真';content.append(im);const h=el('div','story');h.textContent='アッシュ（アシュ丸）\n2004年2月8日 生まれ\n2017年3月10日 旅立ち';h.style.whiteSpace='pre-line';content.append(h);const bio=el('div','info-card');bio.append(el('p','','ロングコートチワワの男の子。'));bio.append(el('p','','血統書名：グリーンガーネット・ファルコ・カカオ'));bio.append(el('p','','唐揚げを食べ終わると「フッ！」、何か欲しいときは「ピーピーピー」。'));content.append(bio);content.append(el('p','section-note','このアプリは、アッシュと過ごした大切な時間をいつでも思い出せる小さな居場所です。'))})}
function micToggle(){if(micWanted){micWanted=false;micActive=false;try{mic?.stop()}catch{}micButtonUpdate();toast('声の聞き取りを停止したよ');return}
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){toast('このブラウザは音声認識に非対応。アッシュ↗のボタンで呼べるよ');return}
 try{mic=new SR();mic.lang='ja-JP';mic.continuous=true;mic.interimResults=false;
 mic.onresult=e=>{for(let i=e.resultIndex;i<e.results.length;i++){if(!e.results[i].isFinal)continue;const s=e.results[i][0].transcript; if(/アッシュ|あっしゅ|あしゅ|ash/i.test(s))comeHere({fromVoice:true})}};
 mic.onerror=e=>{if(['not-allowed','service-not-allowed','network','audio-capture'].includes(e.error)){micWanted=false;micActive=false;micButtonUpdate();toast(e.error==='network'?'音声認識に通信が必要です。ボタンで呼べます':'マイクが使えません。ボタンで呼べます')}};
 mic.onend=()=>{micActive=false;micButtonUpdate();if(micWanted)setTimeout(()=>{if(micWanted){try{mic.start();micActive=true;micButtonUpdate()}catch{micWanted=false;micButtonUpdate()}}},600)};
 micWanted=true;mic.start();micActive=true;micButtonUpdate();toast('アッシュと呼んでみて。マイクを使うよ');
 }catch{micWanted=false;micActive=false;micButtonUpdate();toast('マイクを開始できませんでした')}}
function micButtonUpdate(){$('micBtn').innerHTML=micWanted?'<span>●</span> 聞き取り中':'<span>♩</span> 声で呼ぶ';$('micBtn').setAttribute('aria-pressed',String(micWanted))}
function blobToDataURL(blob){return new Promise((yes,no)=>{const r=new FileReader();r.onload=()=>yes(r.result);r.onerror=()=>no(r.error);r.readAsDataURL(blob)})}
function dataURLToBlob(uri){const [head,value]=uri.split(',');if(!head?.startsWith('data:')||!value)throw Error('image data invalid');const mime=(head.match(/data:([^;]+)/)||[])[1]||'image/jpeg';const bytes=atob(value);const a=new Uint8Array(bytes.length);for(let i=0;i<bytes.length;i++)a[i]=bytes.charCodeAt(i);return new Blob([a],{type:mime})}
async function exportBackup(){try{let stored=[];if(photoDb)stored=await idbAll();const imgs=[];for(const ph of stored){imgs.push({id:ph.id,title:ph.title,description:ph.description,at:ph.at,dataURL:await blobToDataURL(ph.blob)})}const file=new Blob([JSON.stringify({app:'アッシュのひなた',version:2,createdAt:new Date().toISOString(),data,photos:imgs})],{type:'application/json'});const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download=`ash-hinata-backup-${new Date().toISOString().slice(0,10)}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('バックアップを保存したよ')}catch(err){console.warn(err);toast('バックアップを作れませんでした')}}
async function importBackup(file){if(!file)return;try{if(file.size>60_000_000)throw Error('too large');const obj=JSON.parse(await file.text());if(obj.app!=='アッシュのひなた'||obj.version!==2||!obj.data||!Array.isArray(obj.data.history))throw Error('invalid file');if(!confirm('現在の育成・履歴データを、バックアップ内容で上書きしますか？'))return;
  data={...START,...obj.data,version:2};data.outfit=COSTUMES[data.outfit]?data.outfit:'normal';data.history=data.history.slice(0,1000);save();let added=0;
  if(photoDb&&Array.isArray(obj.photos)){for(const p of obj.photos.slice(0,200)){if(typeof p.dataURL!=='string'||p.dataURL.length>12_000_000)continue;await idbPut({id:p.id||`${Date.now()}-${added}`,title:String(p.title||'アッシュの写真').slice(0,80),description:String(p.description||''),at:Number(p.at)||Date.now(),blob:dataURLToBlob(p.dataURL)});added++}}
  setMode('idle');closeSheet();toast(`育成データと写真${added}枚を復元したよ`)
 }catch(err){console.warn(err);toast('バックアップを読み込めませんでした。ファイルを確認してね')}}

/* Device clock follows Android/iPhone OS local timezone and manually set date/time.
   Geolocation and weather are independent; only requested GPS coordinates are shared
   with the weather/reverse-geocoding endpoints. No coordinates are saved to storage. */
const WEATHER_SAVE_KEY='ash-hinata-weather-v1';
const WEATHER_REFRESH_MS=30*60*1000;
let weatherRunning=false,lastWeatherRefresh=0,weatherCache=null;
function updateDeviceClock(){
  const now=new Date();
  const ds=`${now.getFullYear()}年${now.getMonth()+1}月${now.getDate()}日`;
  const ts=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  $('deviceDate').textContent=ds;
  $('deviceDate').dateTime=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
  $('deviceTime').textContent=ts;
  $('deviceTime').dateTime=ts;
}
function weatherDescription(code,isDay){
  if(code===0)return {label:'晴れ',icon:isDay?'☀️':'🌙'};
  if(code===1)return {label:'晴れ',icon:isDay?'🌤️':'🌙'};
  if(code===2)return {label:'くもり時々晴れ',icon:'⛅'};
  if(code===3)return {label:'くもり',icon:'☁️'};
  if(code===45||code===48)return {label:'霧',icon:'🌫️'};
  if([51,53,55,56,57].includes(code))return {label:'霧雨',icon:'🌦️'};
  if([61,63,65,66,67,80,81,82].includes(code))return {label:'雨',icon:'🌧️'};
  if([71,73,75,77,85,86].includes(code))return {label:'雪',icon:'❄️'};
  if([95,96,99].includes(code))return {label:'雷雨',icon:'⛈️'};
  return {label:'天気を確認',icon:'🌤️'};
}
function showWeather(record,{stale=false}={}){
  $('weatherCity').textContent=record.city||'現在地';
  $('weatherCondition').textContent=record.label||'天気を確認';
  $('weatherIcon').textContent=record.icon||'🌤️';
  const temp=typeof record.temperature==='number'&&Number.isFinite(record.temperature)?` · ${Math.round(record.temperature)}℃`:'';
  const when=stale?'前回取得の天気':`現在の天気${temp}`;
  $('weatherMeta').textContent=`${when} · タップで更新`;
  $('weatherBtn').title=stale?'天気は前回取得したものです。タップで更新':'GPSで現在地の天気を更新';
}
function weatherMessage(message){
  $('weatherCity').textContent='現在地';
  $('weatherCondition').textContent='天気を確認';
  $('weatherIcon').textContent='⌖';
  $('weatherMeta').textContent=message;
}
async function fetchWeatherJSON(url){
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),13000);
  try{const response=await fetch(url,{cache:'no-store',signal:controller.signal});if(!response.ok)throw Error(`weather request ${response.status}`);return await response.json()}finally{clearTimeout(timeout)}
}
function getGpsPosition(){
  return new Promise((resolve,reject)=>{
    if(!('geolocation' in navigator))return reject(new Error('GPS unsupported'));
    if(!window.isSecureContext)return reject(new Error('HTTPS required'));
    navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true,timeout:16000,maximumAge:300000});
  });
}
async function cityFromGPS(lat,lon){
  try{
    const url=`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&localityLanguage=ja`;
    const info=await fetchWeatherJSON(url);
    // Prefer city/locality to prefecture; works internationally rather than assuming Fukuoka.
    return [info.city,info.locality,info.principalSubdivision].find(x=>typeof x==='string'&&x.trim())?.trim()||'現在地';
  }catch{return '現在地'}
}
async function refreshWeather({manual=false}={}){
  if(weatherRunning)return;
  weatherRunning=true;
  if(!weatherCache)weatherMessage('位置情報を確認中…');
  else $('weatherMeta').textContent='GPSと天気を更新中…';
  try{
    if(!navigator.onLine)throw new Error('offline');
    const position=await getGpsPosition();
    const lat=position.coords.latitude,lon=position.coords.longitude;
    if(!Number.isFinite(lat)||!Number.isFinite(lon))throw Error('GPS invalid');
    const url=`https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=temperature_2m,weather_code,is_day&timezone=auto&forecast_days=1`;
    const [weather,city]=await Promise.all([fetchWeatherJSON(url),cityFromGPS(lat,lon)]);
    if(!weather||!weather.current||typeof weather.current.weather_code!=='number'||!Number.isFinite(weather.current.weather_code))throw Error('weather missing');
    const {label,icon}=weatherDescription(Number(weather.current.weather_code),weather.current.is_day!==0);
    weatherCache={city,label,icon,temperature:typeof weather.current.temperature_2m==='number'?weather.current.temperature_2m:null,updated:Date.now()};
        showWeather(weatherCache);
    lastWeatherRefresh=Date.now();
    try{localStorage.setItem(WEATHER_SAVE_KEY,JSON.stringify(weatherCache))}catch{}
    if(manual)toast('現在地の天気を更新したよ');
  }catch(err){
    const denied=err&&err.code===1;
    const offline=err?.message==='offline';
    const https=err?.message==='HTTPS required';
    if(weatherCache){showWeather(weatherCache,{stale:true})}
    else weatherMessage(denied?'位置情報を許可すると天気を表示':offline?'オフライン中 · タップで再試行':https?'HTTPSで開くとGPSを使えます':'GPS／通信を確認してタップで再試行');
    if(manual)toast(denied?'端末の位置情報の許可を確認してね':offline?'天気の更新にはネット接続が必要だよ':https?'HTTPSで公開したアプリから開いてね':'天気を取得できませんでした');
  }finally{weatherRunning=false}
}
function initClockWeather(){
  updateDeviceClock();setInterval(updateDeviceClock,1000);
  try{const cached=JSON.parse(localStorage.getItem(WEATHER_SAVE_KEY)||'null');
    if(cached&&typeof cached.label==='string'&&typeof cached.city==='string'&&Number.isFinite(cached.updated)){
      weatherCache=cached;showWeather(cached,{stale:true});
    }
  }catch{}
  $('weatherBtn').addEventListener('click',()=>refreshWeather({manual:true}));
  // Show automatic updates for already-granted permission, or ask on first use.
  refreshWeather();
  setInterval(()=>{if(!document.hidden&&navigator.onLine&&Date.now()-lastWeatherRefresh>=WEATHER_REFRESH_MS)refreshWeather()},WEATHER_REFRESH_MS);
  window.addEventListener('online',()=>{if(Date.now()-lastWeatherRefresh>=WEATHER_REFRESH_MS)refreshWeather()});
  document.addEventListener('visibilitychange',()=>{
    updateDeviceClock();
    if(!document.hidden&&navigator.onLine&&Date.now()-lastWeatherRefresh>=WEATHER_REFRESH_MS)refreshWeather();
  });
}
function setup(){initClockWeather();data.opened++;save();warmExpressions(data.outfit);setMode('idle');document.querySelectorAll('.action').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
 $('pet').onclick=petDog;$('callBtn').onclick=()=>comeHere();$('clothesBtn').onclick=outfitSheet;$('treatBtn').onclick=giveTreat;$('albumBtn').onclick=albumSheet;$('historyBtn').onclick=historySheet;$('profileBtn').onclick=profileSheet;$('micBtn').onclick=micToggle;$('closeSheet').onclick=closeSheet;$('closeScrim').onclick=closeSheet;
 $('photoInput').addEventListener('change',async e=>{await addPhotos(e.target.files);e.target.value=''});$('restoreInput').addEventListener('change',async e=>{await importBackup(e.target.files[0]);e.target.value=''});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){clearAmbient()}else{if(mode==='idle'||mode==='sit'){restingExpression();beginAmbient()}}});
 // Gentle spontaneous approach, but never while walking, napping, or viewing photographs.
 setInterval(()=>{if(document.hidden||!$('overlay').hidden||mode==='walk'||mode==='sleep'||mode==='happy')return;if(Math.random()<.56)comeHere({autonomous:true})},23000);
 const name=COSTUMES[data.outfit];if(name&&data.outfit!=='normal')$('statusText').textContent=name;
 initPwa();initPhotoDb();
}
async function initPhotoDb(){try{photoDb=await photoDbOpen()}catch{toast('写真の追加はこの環境では保存できません')}}
function initPwa(){window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('installBtn').hidden=false});$('installBtn').onclick=async()=>{if(installPrompt){installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('installBtn').hidden=true}else toast('Chromeの︙メニューから「ホーム画面に追加」を選んでね')};
 if('serviceWorker'in navigator&&location.protocol!=='file:'){navigator.serviceWorker.register('./sw.js').then(()=>{if(navigator.serviceWorker.controller)$('saveStatus').textContent='● この端末に保存済み · オフライン準備完了';navigator.serviceWorker.addEventListener('controllerchange',()=>{$('saveStatus').textContent='● この端末に保存済み · オフライン準備完了'})}).catch(()=>{})}
}
document.addEventListener('DOMContentLoaded',setup);
