/* Thuê SIM Số Tiến Thông - direct OTPVN API build.
 * The user requested remembering the token on this device.
 * Client-side token storage is less secure than a trusted backend. */
(() => {
  const $ = (id) => document.getElementById(id);
  const API = 'https://api.otpvn.com';
  const TOKEN_STORAGE_KEY = 'otp-viet-otpvn-token';
  let apiToken = '';
  let services = [];
  let activeRental = null;
  let historyItems = [];
  let pollTimer = null;
  let connected = false;

  function announce(message, kind = 'info') {
    const el = $('notice');
    el.textContent = message;
    el.dataset.kind = kind;
    $('connection-status').textContent = message;
    if ('vibrate' in navigator && kind !== 'info') {
      try { navigator.vibrate(kind === 'success' ? [40] : [90, 50, 90]); } catch (_) {}
    }
  }
  function splitCsv(s) { return s.split(',').map(x => x.trim()).filter(Boolean); }
  function money(n) { return Number(n || 0).toLocaleString('vi-VN') + ' VNĐ'; }
  function todayString(d = new Date()) {
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
  async function api(method, path, body) {
    if (!apiToken) throw new Error('Hãy nhập API token trước.');
    let res;
    try {
      res = await fetch(API + path, {
        method,
        headers: { 'Authorization': 'Bearer ' + apiToken, 'Content-Type': 'application/json', 'X-Lang': 'vi' },
        body: body === undefined ? undefined : JSON.stringify(body)
      });
    } catch (e) {
      throw new Error('Không kết nối được API. Có thể mạng bị lỗi hoặc WebView/trình đóng gói chặn CORS. Hãy thử mở trang trong Chrome; nếu vẫn lỗi, cần bản APK có cấu hình mạng phù hợp hoặc máy chủ trung gian.');
    }
    let data = {};
    try { data = await res.json(); } catch (_) {}
    if (!res.ok) {
      const code = data.code ? ` (${data.code})` : '';
      throw new Error((data.detail || `Lỗi HTTP ${res.status}`) + code);
    }
    return data;
  }
  function renderServices() {
    const q = $('service-search').value.trim().toLowerCase();
    const target = $('service-list'); target.replaceChildren();
    const shown = services.filter(s => `${s.id} ${s.name}`.toLowerCase().includes(q));
    if (!shown.length) {
      const p = document.createElement('p');
      p.textContent = services.length ? 'Không có dịch vụ khớp từ khóa.' : 'Chưa tải được danh sách dịch vụ.';
      target.appendChild(p); return;
    }
    shown.forEach(s => {
      const item = document.createElement('div'); item.className = 'list-item'; item.setAttribute('role', 'listitem');
      const text = document.createElement('p'); text.textContent = `${s.id} — ${s.name} — ${money(s.price)}`;
      const b = document.createElement('button'); b.textContent = 'Chọn dịch vụ này'; b.setAttribute('aria-label', `Chọn dịch vụ ${s.name}, ID ${s.id}`);
      b.addEventListener('click', () => { $('service-id').value = s.id; announce(`Đã chọn dịch vụ ${s.name}.`); $('service-id').focus(); });
      item.append(text, b); target.appendChild(item);
    });
  }
  async function refreshAccount(silent = false) {
    const [balance, list] = await Promise.all([api('GET', '/v1/balance'), api('GET', '/v1/services?country=vn')]);
    $('balance').textContent = `Số dư: ${money(balance.balance)}`;
    services = Array.isArray(list) ? list : [];
    renderServices();
    connected = true;
    if (!silent) announce(`Kết nối OTPVN thành công. Số dư ${money(balance.balance)}. Đã tải ${services.length} dịch vụ.`, 'success');
  }
  $('connect').addEventListener('click', async () => {
    apiToken = $('api-token').value.trim();
    if (!apiToken) { announce('Hãy nhập API token OTPVN của bạn.', 'error'); $('api-token').focus(); return; }
    // Save locally before connecting so the user does not have to retype it.
    // This is device-local browser storage, not encrypted secret storage.
    try {
      localStorage.setItem(TOKEN_STORAGE_KEY, apiToken);
    } catch (_) {
      announce('Không lưu được token trên thiết bị này. Hãy kiểm tra quyền lưu dữ liệu của ứng dụng.', 'error');
      return;
    }
    $('connect').disabled = true;
    announce('Đã lưu token trên thiết bị. Đang kiểm tra kết nối OTPVN…');
    try { await refreshAccount(); }
    catch (e) { connected = false; announce(`Kết nối thất bại: ${e.message}`, 'error'); }
    finally { $('connect').disabled = false; }
  });
  $('refresh').addEventListener('click', async () => {
    try { await refreshAccount(); }
    catch (e) { announce(`Không thể làm mới: ${e.message}`, 'error'); }
  });
  $('rent').addEventListener('click', async () => {
    const id = Number($('service-id').value.trim());
    if (!Number.isInteger(id) || id <= 0) { announce('Hãy chọn hoặc nhập ID dịch vụ hợp lệ.', 'error'); $('service-id').focus(); return; }
    const body = { serviceId: id };
    const carriers = splitCsv($('carrier').value).map(x => x.toUpperCase());
    const includePrefixes = splitCsv($('prefix-include').value);
    const excludePrefixes = splitCsv($('prefix-exclude').value);
    if (carriers.length) body.carriers = carriers;
    if (includePrefixes.length) body.includePrefixes = includePrefixes;
    if (excludePrefixes.length) body.excludePrefixes = excludePrefixes;
    $('rent').disabled = true; announce('Đang yêu cầu thuê số…');
    try {
      const data = await api('POST', '/v1/rentals', body);
      activeRental = { ...data, serviceId: id, serviceName: services.find(s => s.id === id)?.name || `Dịch vụ ${id}`, status: 0 };
      showRental(activeRental); startPolling();
      $('balance').textContent = `Số dư: ${money(data.balance)}`;
      announce(`Thuê số thành công. Số điện thoại ${data.phoneLocal}. Đang chờ mã OTP.`, 'success');
    } catch (e) { announce(`Thuê số thất bại: ${e.message}`, 'error'); }
    finally { $('rent').disabled = false; }
  });
  function showRental(r) {
    $('phone').textContent = `Số điện thoại: ${r.phoneLocal || 'chưa có'}`;
    $('otp').textContent = `Mã OTP: ${r.code || 'chưa có'}`;
    const statuses = { 0: 'Đang chờ tin nhắn', 1: 'Đã nhận mã OTP', 2: 'Hết hạn; tiền đã được hoàn lại' };
    $('countdown').textContent = `Lượt thuê #${r.id || '?'} — ${r.serviceName || 'Dịch vụ'} — ${statuses[r.status] || 'Trạng thái chưa rõ'}`;
  }
  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    if (!activeRental?.id) return;
    pollTimer = setInterval(async () => {
      if (!activeRental?.id || activeRental.status !== 0) { clearInterval(pollTimer); pollTimer = null; return; }
      try {
        const s = await api('GET', `/v1/rentals/${encodeURIComponent(activeRental.id)}`);
        activeRental = { ...activeRental, ...s };
        showRental(activeRental);
        if (s.status === 1) { clearInterval(pollTimer); pollTimer = null; announce(`Đã nhận mã OTP: ${s.code || 'hãy xem nội dung tin nhắn'}.`, 'success'); }
        else if (s.status === 2) { clearInterval(pollTimer); pollTimer = null; announce('Lượt thuê hết hạn; OTPVN báo tiền đã được hoàn lại.', 'error'); }
      } catch (e) { announce(`Chưa kiểm tra được OTP: ${e.message}`, 'error'); }
    }, 5000);
  }
  $('check-otp').addEventListener('click', async () => {
    if (!activeRental?.id) { announce('Chưa có lượt thuê để kiểm tra OTP.', 'error'); return; }
    try { const s = await api('GET', `/v1/rentals/${encodeURIComponent(activeRental.id)}`); activeRental = { ...activeRental, ...s }; showRental(activeRental); announce(s.code ? `Mã OTP: ${s.code}` : (s.status === 2 ? 'Lượt thuê đã hết hạn và được hoàn tiền.' : 'Chưa nhận được mã OTP.'), s.code ? 'success' : 'info'); }
    catch (e) { announce(`Không kiểm tra được OTP: ${e.message}`, 'error'); }
  });
  $('rerent').addEventListener('click', async () => {
    if (!activeRental?.phone || !activeRental?.serviceId) { announce('Chưa có số cũ đủ thông tin để thuê lại.', 'error'); return; }
    $('rerent').disabled = true;
    try {
      const data = await api('POST', '/v1/rentals/rerent', { serviceId: Number(activeRental.serviceId), phone: activeRental.phone });
      activeRental = { ...data, serviceId: activeRental.serviceId, serviceName: activeRental.serviceName, status: 0 };
      showRental(activeRental); startPolling(); $('balance').textContent = `Số dư: ${money(data.balance)}`;
      announce(`Đã thuê lại số ${data.phoneLocal}. Đang chờ OTP.`, 'success');
    } catch (e) { announce(`Thuê lại thất bại: ${e.message}`, 'error'); }
    finally { $('rerent').disabled = false; }
  });
  $('load-history').addEventListener('click', async () => {
    const serviceId = Number($('service-id').value.trim());
    if (!Number.isInteger(serviceId) || serviceId <= 0) { announce('Nhập/chọn ID dịch vụ trước khi tải lịch sử.', 'error'); $('service-id').focus(); return; }
    const to = todayString(); const d = new Date(); d.setDate(d.getDate() - 30); const from = todayString(d);
    announce('Đang tải lịch sử 30 ngày gần nhất…');
    try {
      const results = await Promise.all([0,1,2].map(status => api('GET', `/v1/rentals?serviceId=${serviceId}&status=${status}&limit=100&from=${from}&to=${to}`)));
      historyItems = results.flat().sort((a,b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).map(x => {
        const status = ['Đang chờ', 'Hoàn thành', 'Hết hạn/hoàn tiền'][x.status] || 'Không rõ';
        return `#${x.id} | ${x.serviceName || `Dịch vụ ${x.serviceId}`} | ${x.phoneLocal || x.phone || ''} | OTP: ${x.code || 'chưa có'} | ${status} | ${x.createdAt || ''}`;
      });
      renderHistory(); announce(`Đã tải ${historyItems.length} lượt thuê trong 30 ngày gần nhất.`, 'success');
    } catch (e) { announce(`Tải lịch sử thất bại: ${e.message}`, 'error'); }
  });
  function renderHistory() {
    const q = $('history-filter').value.toLowerCase();
    $('history').textContent = historyItems.filter(x => x.toLowerCase().includes(q)).join('\n\n') || 'Không có mục lịch sử khớp.';
  }
  $('service-search').addEventListener('input', renderServices);
  $('history-filter').addEventListener('input', renderHistory);
  function copy(value, label) {
    if (!value) { announce(`Chưa có ${label} để sao chép.`, 'error'); return; }
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(value).then(() => announce(`Đã sao chép ${label}.`, 'success'), () => manualCopy(value, label));
    else manualCopy(value, label);
  }
  function manualCopy(value, label) {
    const input = document.createElement('textarea'); input.value = value; input.setAttribute('aria-label', `Nội dung ${label} để sao chép`); document.body.appendChild(input); input.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (_) {} input.remove();
    announce(ok ? `Đã sao chép ${label}.` : `Không tự sao chép được ${label}; hãy sao chép thủ công.`, ok ? 'success' : 'error');
  }
  $('copy-phone').addEventListener('click', () => copy(activeRental?.phoneLocal || '', 'số điện thoại'));
  $('copy-otp').addEventListener('click', () => copy(activeRental?.code || '', 'mã OTP'));
  $('logout').addEventListener('click', () => {
    apiToken = ''; connected = false; $('api-token').value = ''; services = []; renderServices();
    try { localStorage.removeItem(TOKEN_STORAGE_KEY); } catch (_) {}
    if (pollTimer) clearInterval(pollTimer); pollTimer = null;
    announce('Đã xóa token đã lưu trên thiết bị và đăng xuất.');
  });
  // Restore saved token when the app is reopened.
  try {
    const savedToken = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (savedToken) {
      apiToken = savedToken;
      $('api-token').value = savedToken;
      announce('Đã khôi phục token đã lưu trên thiết bị. Bấm Kiểm tra kết nối để kết nối lại.');
    } else {
      announce('Nhập token OTPVN của bạn rồi bấm Kiểm tra kết nối.');
    }
  } catch (_) {
    announce('Nhập token OTPVN của bạn rồi bấm Kiểm tra kết nối.');
  }
  renderServices();
})();
