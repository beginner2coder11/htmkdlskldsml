(function(root){
const Characters=typeof module!=='undefined'?require('./characters.js'):root.MorfalouCharacters;
const Q=typeof module!=='undefined'?require('./questions.js'):root.QuizBank;
const old=typeof module!=='undefined'?require('./maze-base.js'):root.PartyEngine;
function shuffle(arr){let a=arr.slice();for(let i=a.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function norm(s){return s.replace(/œ/gi,'oe').replace(/æ/gi,'ae').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z]/g,'')}
const photos=[['eiffel','La tour Eiffel',['La tour Eiffel','La tour de Pise','Big Ben','La tour de Tokyo']],['colisee','Le Colisée',['Le Colisée','Le Parthénon','Le Panthéon de Rome','Le théâtre d’Orange']],['stylo','Un stylo',['Un stylo','Un crayon','Un pinceau','Un tournevis']],['casquette','Une casquette',['Une casquette','Un chapeau','Un bonnet','Un casque']],['cadenas','Un cadenas',['Un cadenas','Une serrure','Une clé','Une boucle de ceinture']],['cle','Une clé',['Une clé','Un décapsuleur','Une pince','Un tire-bouchon']],['brosse','Une brosse à dents',['Une brosse à dents','Un rasoir','Un peigne','Un pinceau']],['lunettes','Des lunettes',['Des lunettes','Des jumelles','Un masque de plongée','Une loupe']]];
const words=typeof module!=='undefined'?require('./words.js'):root.HangmanWords;
let historyWriter=null;let history={};try{history=JSON.parse(root.localStorage.getItem('party05.history')||'{}')}catch(e){}
function saveHistory(){if(historyWriter)historyWriter(history);try{root.localStorage.setItem('party05.history',JSON.stringify(history))}catch(e){}}
function draw(key,pool,id){let used=history[key]||[],left=pool.filter(x=>!used.includes(id(x)));if(!left.length){used=[];left=pool.filter(x=>id(x)!==history[key]?.at(-1));if(!left.length)left=pool;}let x=left[Math.floor(Math.random()*left.length)];history[key]=[...used,id(x)];saveHistory();return x}
function mental(level=1){level=Math.max(1,Math.min(3,Number(level)||1));let pool=[];
 for(let a=12;a<=59;a++)for(let b=3;b<=19;b++){
 if(level===1){pool.push([`${a} + ${b}`,a+b]);if(a>b)pool.push([`${a} − ${b}`,a-b]);}
 else if(level===2){pool.push([`${a} × ${b%8+2}`,a*(b%8+2)]);pool.push([`${a*b} ÷ ${b}`,a]);}
 else{pool.push([`(${a} + ${b}) × ${b%5+2}`,(a+b)*(b%5+2)]);pool.push([`${a} × ${b} − ${a}`,a*b-a]);}
 }
 let [expression,result]=draw('math'+level,pool,x=>x[0]),offsets=shuffle([1,2,3,5,10,-1,-2,-3,-5,-10]),options=[result];for(let d of offsets){if(result+d>=0&&!options.includes(result+d))options.push(result+d);if(options.length===4)break;}options=shuffle(options).map(String);
 return {kind:'math',question:expression+' = ?',category:'Calcul mental',difficulty:['Échauffement','Concentration','Défi'][level-1],level,options,answer:options.indexOf(String(result)),duration:[45000,60000,75000][level-1]};}
function makeRound(kind,level=null,expert=false){
 if(kind==='quiz'){let q=draw(expert?'expert':'quiz',Q.filter(q=>(q.difficulty==='Expert')===expert),q=>q.id),permutation=shuffle([0,1,2,3]);return {...q,kind,options:permutation.map(k=>q.options[k]),answer:permutation.indexOf(q.answer),duration:50000}}
 if(kind==='mystery'){let m=draw('photos',photos,x=>x[0]),options=shuffle(m[2]);return {kind,question:'Que dévoile cette image ?',photo:'assets/'+m[0]+'.webp',options,answer:options.indexOf(m[1]),duration:60000,tiles:shuffle(Array.from({length:240},(_,i)=>i))}}
 if(kind==='maze'){let m,signature,tries=0;do{m=old.maze();signature=JSON.stringify(m.cells)}while((history.mazes||[]).includes(signature)&&++tries<20);history.mazes=[...(history.mazes||[]).slice(-199),signature];saveHistory();return {kind,question:'Quelle sortie rejoint la flèche ?',options:['Sortie A','Sortie B','Sortie C','Sortie D'],answer:m.answer,maze:m,duration:60000}}
 if(kind==='math')return mental(level||1+Math.floor(Math.random()*3));
 let w=draw('words',words,x=>norm(x[0]));return {kind:'hangman',question:'Le pendu : trouvez le mot !',word:norm(w[0]),hint:w[1],duration:null};
}
function makeDeck(n=20){return Array.from({length:n},(_,i)=>makeRound(['quiz','mystery','maze','hangman','math'][i%5],null,i>0&&i%15===0))}
function player(name,i,character){if(name&&typeof name==='object'){character=name.character;name=name.name}let c=Characters.find(c=>c.id===character)||Characters[i%Characters.length];return {id:'p'+i,name:String(name||'Joueur '+(i+1)).slice(0,18),character:c.id,score:0}}
function create(names=[],n=20){n=Math.max(1,Math.min(50,Number(n)||20));return {players:names.map((name,i)=>player(name,i)),rounds:makeDeck(n),index:-1,phase:'lobby',picks:{},notice:'Bienvenue chez les morfalous !',revision:0}}
function specialty(q){if(q.kind==='math')return 'calcul';if(q.kind==='maze')return 'logique';if(q.kind==='hangman')return 'lettres';if(q.kind==='mystery')return /\/(eiffel|colisee)\.webp$/.test(q.photo)?'arts':null;
const expert={101:'lettres',102:'sciences',103:'histoire',104:'lettres',105:'arts',106:'calcul',107:'nature',108:'geographie',109:'calcul',110:'musique'};
return expert[q.id]||Characters.find(c=>c.categories.includes(q.category))?.id||null;}
function bonus(p,q){return p.character===specialty(q)?25:0}
function award(g,p,base){let extra=bonus(p,current(g));p.score+=base+extra;g.awards.push({id:p.id,base,bonus:extra,total:base+extra});return base+extra}
function current(g){return g.rounds[g.index]}
function finish(g,message){g.phase='reveal';g.notice=message;g.buzz=null;g.revision++}
function resolve(g){if(g.phase!=='play')return;let q=current(g);for(const p of g.players){let a=g.picks[p.id];if(a&&a.choice===q.answer){a.points=100+Math.max(0,Math.floor((g.deadline-a.at)/q.duration*50));a.bonus=bonus(p,q);a.points=award(g,p,a.points)}else if(a)a.points=0}finish(g,'Les réponses sont révélées !')}
function advance(g,now){if(!['lobby','reveal'].includes(g.phase))throw Error('La manche est encore en cours.');if(!g.players.length)throw Error('Ajoute au moins un joueur.');if(++g.index>=g.rounds.length){g.phase='done';g.revision++;return}g.phase='play';g.started=now;g.deadline=current(g).kind==='hangman'?null:now+current(g).duration;g.picks={};g.awards=[];g.letters=[];g.misses=0;g.turn=g.index%g.players.length;g.letterDeadline=now+15000;g.buzz=null;g.cooldowns={};g.notice=current(g).kind==='hangman'?'Une lettre chacun son tour. Tout le monde peut buzzer !':'Tout le monde joue en même temps !';g.revision++}
function tick(g,now){if(g.phase!=='play')return;let q=current(g);if(q.kind==='hangman'){
 if(g.buzz&&now>=g.buzz.until){let p=g.players.find(p=>p.id===g.buzz.id);p.score-=50;g.cooldowns[p.id]=now+5000;g.buzz=null;g.letterDeadline=now+15000;g.notice=p.name+' : proposition non envoyée, −50 points.';g.revision++}
 if(!g.buzz&&now>=g.letterDeadline){g.turn=(g.turn+1)%g.players.length;g.letterDeadline=now+15000;g.notice='Le tour passe au joueur suivant.';g.revision++}
 }else if(now>=g.deadline)resolve(g)}
function act(g,id,a,now=Date.now()){tick(g,now);if(g.phase!=='play')throw Error('Cette manche est terminée.');let p=g.players.find(p=>p.id===id);if(!p)throw Error('Joueur inconnu.');let q=current(g);
 if(q.kind!=='hangman'){if(a.type!=='answer'||!Number.isInteger(a.choice)||a.choice<0||a.choice>3)throw Error('Réponse invalide.');if(g.picks[id])throw Error('Ta réponse est déjà enregistrée.');g.picks[id]={choice:a.choice,at:now};g.revision++;if(q.kind==='math'&&a.choice===q.answer){let points=award(g,p,150);g.picks[id].points=points;g.picks[id].bonus=bonus(p,q);finish(g,p.name+' trouve le premier ! +'+points+' points.');return}if(g.players.every(p=>g.picks[p.id]))resolve(g);return}
 if(a.type==='buzz'){if(g.buzz)throw Error('Un joueur a déjà buzzé.');if((g.cooldowns[id]||0)>now)throw Error('Patiente quelques secondes avant de rebuzzer.');g.buzz={id,until:now+12000};g.notice=p.name+' a buzzé !';g.revision++;return}
 if(a.type==='word'){if(!g.buzz||g.buzz.id!==id)throw Error('Buzze avant de proposer un mot.');let word=norm(String(a.word||''));if(!word||word.length>40)throw Error('Entre un mot.');if(word===q.word){let points=award(g,p,200);finish(g,p.name+' a trouvé le mot ! +'+points+' points.')}else{p.score-=50;g.cooldowns[id]=now+5000;g.buzz=null;g.letterDeadline=now+15000;g.notice=p.name+' : mauvaise proposition, −50 points. On continue !';g.revision++}return}
 if(a.type==='letter'){if(g.buzz)throw Error('Une proposition de mot est en cours.');if(g.players[g.turn].id!==id)throw Error('Ce n’est pas ton tour de lettre.');let l=norm(String(a.letter||''));if(l.length!==1||g.letters.includes(l))throw Error('Choisis une nouvelle lettre.');g.letters.push(l);if(!q.word.includes(l))g.misses++;g.turn=(g.turn+1)%g.players.length;g.letterDeadline=now+15000;g.notice=p.name+' propose '+l+'.';g.revision++;if([...q.word].every(c=>g.letters.includes(c))){let points=award(g,p,200);finish(g,p.name+' complète le mot ! +'+points+' points.')}return}
 throw Error('Action inconnue.');}
function view(g,id=null){let q=current(g);let v={players:g.players,index:g.index,total:g.rounds.length,phase:g.phase,started:g.started,deadline:g.deadline,notice:g.notice,revision:g.revision,serverNow:Date.now(),answered:Object.keys(g.picks),me:id};if(!q)return v;v.round={specialty:specialty(q),kind:q.kind,question:q.question,options:q.options,category:q.category,difficulty:q.difficulty,questionId:q.id,photo:q.photo,level:q.level,tiles:q.tiles,maze:q.maze?{...q.maze,answer:undefined}:undefined,hint:q.hint};if(g.phase==='reveal'){v.round.answer=q.answer;v.round.word=q.word;v.results=g.picks;v.awards=g.awards}if(q.kind==='hangman'){v.mask=[...q.word].map(c=>g.letters.includes(c)||g.phase==='reveal'?c:'_');v.letters=g.letters;v.misses=g.misses;v.turn=g.players[g.turn].id;v.letterDeadline=g.letterDeadline;v.buzz=g.buzz;v.cooldowns=g.cooldowns}if(id&&g.picks[id])v.myChoice=g.picks[id].choice;return JSON.parse(JSON.stringify(v))}
function useHistory(data,write){history=data||{};historyWriter=write;}
const api={Characters,player,specialty,bonus,useHistory,create,advance,tick,act,view,makeDeck,makeRound,mental,norm};if(typeof module!=='undefined')module.exports=api;root.ShowGame=api;
})(typeof window!=='undefined'?window:globalThis);
