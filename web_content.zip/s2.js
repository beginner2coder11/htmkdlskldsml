
(function(){
  if(window.__priceCardsScrollGuardBound)return;
  window.__priceCardsScrollGuardBound=true;
  let active=null, moved=false, sx=0, sy=0;
  const isPriceCard=(el)=>el&&el.closest&&el.closest('.price-product-card, .price-bottom-product-card');
  document.addEventListener('pointerdown',function(e){
    const card=isPriceCard(e.target); if(!card)return;
    active=card; moved=false; sx=e.clientX; sy=e.clientY;
  },true);
  document.addEventListener('pointermove',function(e){
    if(!active)return;
    if(Math.abs(e.clientX-sx)>8 || Math.abs(e.clientY-sy)>8)moved=true;
  },true);
  document.addEventListener('pointerup',function(){
    if(active && moved)active.__priceScrollMoved=true;
    active=null;
  },true);
  document.addEventListener('click',function(e){
    const card=isPriceCard(e.target); if(!card)return;
    if(card.__priceScrollMoved){
      card.__priceScrollMoved=false;
      e.preventDefault(); e.stopImmediatePropagation();
    }
  },true);
  document.addEventListener('touchstart',function(e){
    const card=isPriceCard(e.target); if(!card)return;
    const t=e.touches&&e.touches[0]; if(!t)return;
    active=card; moved=false; sx=t.clientX; sy=t.clientY;
  },{capture:true,passive:true});
  document.addEventListener('touchmove',function(e){
    if(!active)return;
    const t=e.touches&&e.touches[0]; if(!t)return;
    if(Math.abs(t.clientX-sx)>8 || Math.abs(t.clientY-sy)>8)moved=true;
  },{capture:true,passive:true});
  document.addEventListener('touchend',function(){
    if(active && moved)active.__priceScrollMoved=true;
    active=null;
  },{capture:true,passive:true});
})();
