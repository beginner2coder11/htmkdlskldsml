export function volumeCft(lengthFt,widthIn,thicknessIn,qty){return lengthFt*(widthIn/12)*(thicknessIn/12)*qty}
export function effectiveRate(baseRate,thicknessIn){return Number(baseRate)+(Number(thicknessIn)===2?30:0)}
export function findSlab(rates,length){return rates.find(r=>length>=Number(r.min_ft)&&length<=Number(r.max_ft))}
export function lineTotal({length,width,thickness,qty,baseRate}){const cft=volumeCft(length,width,thickness,qty);const rate=effectiveRate(baseRate,thickness);return {cft,rate,amount:cft*rate}}
export function gstSplit(taxable,rate,interState=false){const gst=taxable*rate/100;return interState?{cgst:0,sgst:0,igst:gst,total:taxable+gst}:{cgst:gst/2,sgst:gst/2,igst:0,total:taxable+gst}}
