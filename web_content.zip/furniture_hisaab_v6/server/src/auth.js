import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
dotenv.config();
export async function hashPassword(p){return bcrypt.hash(p,12)}
export async function verifyPassword(p,h){return bcrypt.compare(p,h)}
export function signUser(u){return jwt.sign({sub:u.id,role:u.role,email:u.email},process.env.JWT_SECRET,{expiresIn:"12h"})}
export function auth(req,res,next){const h=req.headers.authorization||"";if(!h.startsWith("Bearer "))return res.status(401).json({error:"Authentication required"});try{req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:"Invalid or expired token"})}}
export function roles(...allowed){return (req,res,next)=>allowed.includes(req.user?.role)?next():res.status(403).json({error:"Insufficient permission"})}
