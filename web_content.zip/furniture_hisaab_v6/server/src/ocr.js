import fs from 'fs';

const schema={
  type:'object',additionalProperties:false,
  properties:{
    vendor:{type:['string','null']},invoiceNumber:{type:['string','null']},date:{type:['string','null']},currency:{type:'string'},
    gstRate:{type:'number'},subtotal:{type:'number'},total:{type:'number'},confidence:{type:'number'},
    warnings:{type:'array',items:{type:'string'}},
    lines:{type:'array',items:{type:'object',additionalProperties:false,properties:{
      description:{type:['string','null']},wood:{type:['string','null']},lengthFt:{type:['number','null']},widthIn:{type:['number','null']},thicknessIn:{type:['number','null']},qty:{type:['number','null']},cft:{type:['number','null']},rate:{type:['number','null']},amount:{type:['number','null']},hsn:{type:['string','null']},confidence:{type:'number'}
    },required:['description','wood','lengthFt','widthIn','thicknessIn','qty','cft','rate','amount','hsn','confidence']}}
  },required:['vendor','invoiceNumber','date','currency','gstRate','subtotal','total','confidence','warnings','lines']
};

const instructions=`You are the invoice ingestion engine for Furniture Hisaab, an Indian furniture/timber business.
Read the supplied invoice/document semantically. Do NOT assume fixed coordinates or a supplier-specific layout.
Extract vendor, invoice number, invoice date, GST rate, totals and every line item.
For timber lines, normalize dimensions into feet/inches and identify wood species when the document makes it reasonably clear.
Never invent missing dimensions, quantities, rates or amounts. Use null/0 and add a warning when uncertain.
Keep confidence 0..1. A low-confidence or ambiguous field must be flagged in warnings.
Return only the requested JSON schema.`;

export async function extractInvoiceWithAI(filePath,mimeType){
  if(!process.env.OPENAI_API_KEY) throw Object.assign(new Error('OPENAI_API_KEY is not configured'),{status:503,code:'OCR_NOT_CONFIGURED'});
  const buf=fs.readFileSync(filePath); const b64=buf.toString('base64');
  let content;
  if(mimeType.startsWith('image/')) content=[{type:'input_text',text:instructions},{type:'input_image',image_url:`data:${mimeType};base64,${b64}`,detail:'high'}];
  else if(mimeType==='application/pdf') content=[{type:'input_text',text:instructions},{type:'input_file',filename:'invoice.pdf',file_data:`data:application/pdf;base64,${b64}`}];
  else content=[{type:'input_text',text:instructions+`\nDocument text:\n${buf.toString('utf8').slice(0,120000)}`}];
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_OCR_MODEL||'gpt-6-luna',input:[{role:'user',content}],text:{format:{type:'json_schema',name:'invoice_extraction',strict:true,schema}},max_output_tokens:8000})});
  if(!r.ok){const t=await r.text();throw Object.assign(new Error(`OCR provider error: ${t.slice(0,500)}`),{status:502})}
  const j=await r.json(); const text=j.output_text||j.output?.flatMap(x=>x.content||[]).find(x=>x.type==='output_text')?.text;
  if(!text)throw Object.assign(new Error('OCR provider returned no structured output'),{status:502});
  return JSON.parse(text);
}
