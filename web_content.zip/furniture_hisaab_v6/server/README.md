# Furniture Hisaab API v5

## Run

1. Copy `.env.example` to `.env`.
2. Set PostgreSQL `DATABASE_URL` and a strong `JWT_SECRET`.
3. Optional AI invoice extraction: set `OPENAI_API_KEY` and `OPENAI_OCR_MODEL`.
4. Apply `sql/schema.sql`.
5. `npm install`
6. `npm start`

## AI invoice endpoints

- `POST /api/documents/upload` — authenticated upload + SHA-256 duplicate check.
- `POST /api/documents/:id/process` — optional AI semantic extraction into normalized structured JSON.
- `POST /api/documents/:id/extraction` — manually/provider-supplied normalized extraction for review.
- `POST /api/documents/:id/approve` — revalidates the reviewed extraction and atomically creates purchase voucher, stock batches, journal entry and marks the document POSTED.

The AI key is server-side only. The browser never receives it.
