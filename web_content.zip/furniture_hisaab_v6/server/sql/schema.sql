
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL,
 email text UNIQUE NOT NULL,
 password_hash text NOT NULL,
 role text NOT NULL DEFAULT 'STAFF' CHECK(role IN ('OWNER','ADMIN','STAFF','VIEWER')),
 active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS parties(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL,
 type text NOT NULL CHECK(type IN ('CUSTOMER','VENDOR','BOTH')),
 phone text, gstin text, address text,
 opening_balance numeric(14,2) NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wood_rates(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 wood text NOT NULL,
 min_ft numeric(8,2) NOT NULL,
 max_ft numeric(8,2) NOT NULL,
 base_rate numeric(12,2) NOT NULL,
 active boolean NOT NULL DEFAULT true,
 UNIQUE(wood,min_ft,max_ft)
);

CREATE TABLE IF NOT EXISTS vouchers(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 voucher_no text UNIQUE NOT NULL,
 voucher_type text NOT NULL CHECK(voucher_type IN ('PURCHASE','SALE','PAYMENT','RECEIPT','JOURNAL','EXPENSE')),
 party_id uuid REFERENCES parties(id),
 voucher_date date NOT NULL,
 taxable_amount numeric(14,2) NOT NULL DEFAULT 0,
 gst_rate numeric(6,2) NOT NULL DEFAULT 0,
 cgst numeric(14,2) NOT NULL DEFAULT 0,
 sgst numeric(14,2) NOT NULL DEFAULT 0,
 igst numeric(14,2) NOT NULL DEFAULT 0,
 total_amount numeric(14,2) NOT NULL DEFAULT 0,
 reference_no text,
 status text NOT NULL DEFAULT 'POSTED',
 created_by uuid REFERENCES users(id),
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS voucher_lines(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 voucher_id uuid NOT NULL REFERENCES vouchers(id) ON DELETE CASCADE,
 wood text, length_ft numeric(8,2), width_in numeric(8,2), thickness_in numeric(8,2),
 qty numeric(12,3) NOT NULL DEFAULT 0,
 cft numeric(14,4) NOT NULL DEFAULT 0,
 rate numeric(12,2) NOT NULL DEFAULT 0,
 amount numeric(14,2) NOT NULL DEFAULT 0,
 hsn text
);

CREATE TABLE IF NOT EXISTS stock_batches(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 wood text NOT NULL,
 length_ft numeric(8,2) NOT NULL,
 width_in numeric(8,2) NOT NULL,
 thickness_in numeric(8,2) NOT NULL,
 qty_in numeric(14,3) NOT NULL DEFAULT 0,
 qty_out numeric(14,3) NOT NULL DEFAULT 0,
 cft_in numeric(14,4) NOT NULL DEFAULT 0,
 cft_out numeric(14,4) NOT NULL DEFAULT 0,
 cost_rate numeric(12,2) NOT NULL DEFAULT 0,
 source_voucher uuid REFERENCES vouchers(id),
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS journal_entries(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 voucher_id uuid NOT NULL REFERENCES vouchers(id) ON DELETE CASCADE,
 account_debit text NOT NULL,
 account_credit text NOT NULL,
 amount numeric(14,2) NOT NULL,
 party_id uuid REFERENCES parties(id),
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workers(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL, phone text, daily_wage numeric(12,2) NOT NULL DEFAULT 0,
 hourly_ot numeric(12,2) NOT NULL DEFAULT 0, active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS attendance(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 worker_id uuid NOT NULL REFERENCES workers(id),
 work_date date NOT NULL,
 status text NOT NULL CHECK(status IN ('PRESENT','ABSENT','HALF_DAY')),
 overtime_hours numeric(8,2) NOT NULL DEFAULT 0,
 UNIQUE(worker_id,work_date)
);

CREATE TABLE IF NOT EXISTS advances(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 worker_id uuid NOT NULL REFERENCES workers(id),
 advance_date date NOT NULL,
 amount numeric(12,2) NOT NULL,
 note text
);

CREATE TABLE IF NOT EXISTS documents(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 original_name text NOT NULL,
 storage_path text NOT NULL,
 mime_type text NOT NULL,
 sha256 text NOT NULL,
 ocr_status text NOT NULL DEFAULT 'PENDING',
 extracted_json jsonb,
 uploaded_by uuid REFERENCES users(id),
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid REFERENCES users(id),
 action text NOT NULL,
 entity text NOT NULL,
 entity_id uuid,
 details jsonb,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vouchers_date ON vouchers(voucher_date);
CREATE INDEX IF NOT EXISTS idx_stock_wood ON stock_batches(wood);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(work_date);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
