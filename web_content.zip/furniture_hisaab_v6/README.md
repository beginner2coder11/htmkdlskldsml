# Furniture Hisaab v6.0

Production-oriented offline-first accounting, timber inventory, labour and invoice-ingestion application for a furniture/timber business.

## V6 highlights
- Zero-API invoice reading: no OpenAI/API key required.
- Local OCR in the browser for invoice photos; PDF text extraction plus local OCR fallback for scanned PDF pages.
- Supplier-independent heuristic parser for vendor, invoice number/date, GST, timber dimensions, quantity, rate, CFT and amount.
- Confidence/warnings + mandatory human review before posting.
- Works without cloud login; if a cloud API is configured, approved local entries can sync and failed syncs enter the offline queue.

## V5 highlights
- Cloud purchase/sale posting to PostgreSQL with transactional stock + double-entry journal updates.
- Offline queue when the API is unavailable.
- Supplier-independent AI invoice ingestion: upload image/PDF → semantic extraction → structured normalized JSON → confidence/warnings → editable review → explicit approval → stock + ledger posting.
- Optional OpenAI Responses API adapter. The API key stays on the server; it is never placed in browser code.
- SHA-256 duplicate document detection and invoice reference duplicate protection.
- Atomic document approval: voucher, voucher lines, stock batches, journal entry and document status update occur in one database transaction.
- Sale stock validation with locked FIFO-style batch allocation. Negative stock is rejected.
- Roles: OWNER / ADMIN / STAFF / VIEWER.
- Timber slab engine, GST, labour/hazri, ledgers, P&L, audit trail and JSON backup retained.

## Timber rules
- Mango and Acacia can use configured quarter-foot slabs.
- Sheesham/Rosewood, Teak, Ash and Oak can use configured half-foot slabs.
- 2-inch thickness adds ₹30/CFT to the matched base slab.
- CFT = length(ft) × width(in)/12 × thickness(in)/12 × quantity.

## Optional cloud setup
1. Copy `server/.env.example` to `server/.env`.
2. Set `DATABASE_URL` and a strong `JWT_SECRET`.
3. **No AI API key is required for V6 invoice reading.** OpenAI configuration from V5 is optional and not used by the local invoice reader.
4. Start PostgreSQL and apply `server/sql/schema.sql`.
5. In `server/`, run `npm install` then `npm start`.
6. Open the web app, set API Base URL, register/login, then use **AI Invoice OCR**.

### AI invoice flow
The original document is stored with a SHA-256 fingerprint. The AI adapter reads the document semantically rather than relying on fixed supplier coordinates. It returns a strict normalized schema with confidence and warnings. The user reviews/edit fields before pressing **Confirm → Stock + Ledger**. The server revalidates required timber fields and performs posting transactionally.

The local invoice reader does not send invoice files to an external AI service. A first-time internet connection may be needed to load the Tesseract.js/PDF.js browser libraries; after the app assets are cached, the workflow can continue offline depending on browser cache/service-worker availability. For difficult/handwritten invoices, review and correction are required.

## Deployment
Run the frontend as a static site and the API/PostgreSQL in a protected server/container. Use HTTPS, strong secrets, restricted CORS, regular PostgreSQL backups, upload retention controls and an admin-only registration/invite workflow before public deployment.

## V6 local invoice flow
Invoice photo/PDF → local OCR → semantic heuristic parsing → confidence/warnings → editable review → approve → local Stock + Ledger → optional cloud sync.

The parser intentionally never invents missing timber dimensions, quantity or rate. When it cannot confidently identify a line, the user must complete it manually before posting.
