const APP_VERSION='5.0.0';
const API_BASE=localStorage.getItem('furnitureHisaabApi')||'';
const API_TOKEN=localStorage.getItem('furnitureHisaabToken')||'';
const API_USER=JSON.parse(localStorage.getItem('furnitureHisaabUser')||'null');
const API={
 async request(path,opts={}){if(!API_BASE) throw new Error('API not configured'); const headers=new Headers(opts.headers||{}); if(API_TOKEN) headers.set('Authorization','Bearer '+API_TOKEN); if(opts.body && !(opts.body instanceof FormData)) headers.set('Content-Type','application/json'); const r=await fetch(API_BASE.replace(/\/$/,'')+path,{...opts,headers}); const text=await r.text(); let data={}; try{data=text?JSON.parse(text):{}}catch{data={raw:text}} if(!r.ok) throw new Error(data.error||`API ${r.status}`); return data;},
 get(path){return this.request(path)},
 post(path,body){return this.request(path,{method:'POST',body:JSON.stringify(body)})},
 upload(path,file){const f=new FormData();f.append('file',file);return this.request(path,{method:'POST',body:f})},
 configured(){return !!API_BASE&&!!API_TOKEN}
};
function apiState(){return API.configured()?'Cloud connected':API_BASE?'API set • Login required':'Offline/local mode'}
