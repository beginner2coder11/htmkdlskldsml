/* Furniture Hisaab V6 — zero-API local invoice reader. */
(function(){
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num=s=>{const m=String(s??'').replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):0};
  const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
  function dateFromText(t){
    const m=t.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](20\d{2})\b/); if(!m)return '';
    return `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
  }
  function gstFromText(t){
    const m=t.match(/(?:gst|igst|cgst\s*\+\s*sgst)[^\d]{0,20}(\d+(?:\.\d+)?)\s*%/i); return m?Number(m[1]):0;
  }
  function invoiceNoFromText(t){
    const m=t.match(/(?:invoice|inv|bill)\s*(?:no|number|#)?\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-_\.]{2,})/i); return m?m[1]:'';
  }
  function guessVendor(lines){
    const bad=/^(invoice|tax invoice|bill|date|gstin|gst|phone|mobile|email|address|ship|bill to|buyer|seller|hsn|description|item|qty|quantity|rate|amount|total|subtotal|cgst|sgst|igst|grand total|terms|page)/i;
    for(let i=0;i<Math.min(lines.length,14);i++){const x=clean(lines[i]); if(x.length>=3&&x.length<80&&!bad.test(x)&&/[A-Za-z]{3}/.test(x))return x;}
    return '';
  }
  function speciesFromLine(line){
    const l=line.toLowerCase();
    if(/sheesham|rosewood/.test(l))return 'Sheesham';
    if(/acacia|babul/.test(l))return 'Acacia';
    if(/mango/.test(l))return 'Mango';
    if(/teak/.test(l))return 'Teak';
    if(/ash/.test(l))return 'Ash';
    if(/oak/.test(l))return 'Oak';
    return '';
  }
  function lineParse(raw){
    const line=clean(raw); if(!line)return null;
    // Supports: 2.5 x 4 x 1 | 10 | 620 | 1550, and 2.5x4x1 10 620 1550.
    const dim=line.match(/(\d+(?:\.\d+)?)\s*(?:ft|')?\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(?:in|\")?\s*[x×*]\s*(\d+(?:\.\d+)?)/i);
    if(!dim)return null;
    const before=line.slice(0,dim.index), after=line.slice((dim.index||0)+dim[0].length);
    const nums=(after.match(/-?\d+(?:[,.]\d+)*/g)||[]).map(x=>Number(x.replace(/,/g,'')));
    if(nums.length<2)return null;
    // Most timber bills end with qty, rate, amount. If 4+ numbers, use the last 3.
    const tail=nums.slice(-3); let qty,rate,amount;
    if(tail.length===3){[qty,rate,amount]=tail}else{qty=tail[0];rate=tail[1];amount=0}
    if(!(qty>0&&rate>0))return null;
    const L=Number(dim[1]),W=Number(dim[2]),T=Number(dim[3]);
    const cft=L*(W/12)*(T/12)*qty;
    if(!(cft>0))return null;
    if(!(amount>0))amount=cft*rate;
    return {description:line,wood:speciesFromLine(line)||speciesFromLine(before)||null,lengthFt:L,widthIn:W,thicknessIn:T,qty,cft,rate,amount,confidence:0.72};
  }
  function parseInvoiceText(text){
    const lines=String(text||'').split(/\r?\n/).map(clean).filter(Boolean);
    const joined=lines.join('\n');
    const out={vendor:guessVendor(lines),invoiceNumber:invoiceNoFromText(joined),date:dateFromText(joined),currency:'INR',gstRate:gstFromText(joined),subtotal:0,total:0,confidence:0,warnings:[],lines:[],rawText:text};
    for(const l of lines){const p=lineParse(l); if(p)out.lines.push(p)}
    const amounts=(joined.match(/(?:grand\s*total|total\s*amount|net\s*amount)[^\d]{0,15}([\d,]+(?:\.\d+)?)/ig)||[]).map(x=>num(x));
    if(amounts.length)out.total=amounts.at(-1);
    out.subtotal=out.lines.reduce((s,x)=>s+x.amount,0);
    if(!out.total)out.total=out.subtotal*(1+out.gstRate/100);
    if(!out.vendor)out.warnings.push('Vendor could not be confidently identified.');
    if(!out.invoiceNumber)out.warnings.push('Invoice number not detected.');
    if(!out.date)out.warnings.push('Invoice date not detected.');
    if(!out.lines.length)out.warnings.push('No timber line with recognizable dimensions was detected. Add lines manually.');
    if(out.lines.some(x=>!x.wood))out.warnings.push('Some wood species were not detected; review each line.');
    const fieldScore=[out.vendor,out.invoiceNumber,out.date,out.lines.length>0].filter(Boolean).length/4;
    out.confidence=Math.max(0,Math.min(1,fieldScore*0.55+(out.lines.length?0.45:0)));
    return out;
  }
  async function pdfTextAndImages(file,onProgress){
    let pdfjs=window.pdfjsLib;
    if(!pdfjs){ try { pdfjs=await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.min.mjs'); } catch(e) { throw new Error('PDF engine not loaded. Refresh once with internet, then retry.'); } }
    if(!pdfjs) throw new Error('PDF engine not loaded. Refresh once with internet, then retry.');
    const buf=await file.arrayBuffer(); const pdf=await pdfjs.getDocument({data:buf}).promise; let text='';
    for(let i=1;i<=pdf.numPages;i++){
      const page=await pdf.getPage(i); const tc=await page.getTextContent();
      const pageText=tc.items.map(x=>x.str).join(' '); text+='\n'+pageText;
      onProgress?.(`Reading PDF page ${i}/${pdf.numPages}…`);
      if(pageText.trim().length<80 && window.Tesseract){
        const vp=page.getViewport({scale:1.7}); const c=document.createElement('canvas');c.width=Math.ceil(vp.width);c.height=Math.ceil(vp.height);const ctx=c.getContext('2d');
        await page.render({canvasContext:ctx,viewport:vp}).promise;
        const r=await Tesseract.recognize(c,'eng',{logger:m=>{if(m.status==='recognizing text'&&m.progress)onProgress?.(`OCR PDF page ${i}/${pdf.numPages} ${Math.round(m.progress*100)}%…`)}});
        text+='\n'+r.data.text;
      }
    }
    return text;
  }
  async function imageText(file,onProgress){
    if(!window.Tesseract)throw new Error('Local OCR engine not loaded. Refresh once with internet, then retry.');
    const r=await Tesseract.recognize(file,'eng',{logger:m=>{if(m.status&&m.progress)onProgress?.(`Local OCR: ${m.status} ${Math.round(m.progress*100)}%…`)}});
    return r.data.text||'';
  }
  window.LocalInvoiceOCR={
    async extract(file,onProgress){
      onProgress?.('Starting local, zero-API invoice reading…');
      let text='';
      if(file.type.startsWith('image/')) text=await imageText(file,onProgress);
      else if(file.type==='application/pdf') text=await pdfTextAndImages(file,onProgress);
      else text=await file.text();
      const result=parseInvoiceText(text); result.source='LOCAL_OCR'; result.fileName=file.name;
      return result;
    },parseInvoiceText
  };
})();
