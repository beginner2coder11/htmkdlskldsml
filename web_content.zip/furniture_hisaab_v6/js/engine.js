
const E={
 uid(prefix="ID"){return prefix+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,7)},
 num(v){return Number(v)||0},
 round(v,n=2){const p=10**n;return Math.round((v+Number.EPSILON)*p)/p},
 slab(wood,length){
   const rates=DB.woodRates[wood]||[];
   return rates.find(x=>length>=x.min-1e-9 && length<=x.max+1e-9)||null
 },
 rate(wood,length,thickness){
   const s=this.slab(wood,length);
   if(!s)return {base:0,surcharge:0,effective:0,slab:null};
   const surcharge=Number(thickness)===2?30:0;
   return {base:s.rate,surcharge,effective:s.rate+surcharge,slab:s};
 },
 volume(length,widthIn,thicknessIn,qty=1){return (length*(widthIn/12)*(thicknessIn/12))*qty},
 amount(wood,length,width,thickness,qty){const r=this.rate(wood,length,thickness),cft=this.volume(length,width,thickness,qty);return {cft,rate:r.effective,base:r.base,surcharge:r.surcharge,total:cft*r.effective}},
 postPurchase(x){
   const item={id:this.uid("STK"),date:x.date,wood:x.wood,length:x.length,width:x.width,thickness:x.thickness,qty:x.qty,cft:x.cft,rate:x.rate,amount:x.amount,type:"IN",ref:x.ref||""};
   DB.inventory.push(item);
   this.journal({date:x.date,ref:x.ref||item.id,description:"Timber purchase",debit:"Inventory",credit:x.party||"Supplier",amount:x.amount,party:x.party||""});
 },
 postSale(x){
   DB.inventory.push({id:this.uid("STK"),date:x.date,wood:x.wood,length:x.length,width:x.width,thickness:x.thickness,qty:x.qty,cft:x.cft,rate:x.rate,amount:x.amount,type:"OUT",ref:x.ref||""});
   this.journal({date:x.date,ref:x.ref||"",description:"Timber/furniture sale",debit:x.party||"Customer",credit:"Sales",amount:x.amount,party:x.party||""});
 },
 journal(x){
   DB.ledger.push({id:this.uid("J"),...x});
 },
 inventoryBalance(){
   const m={};
   for(const x of DB.inventory){
     const key=[x.wood,x.length,x.width,x.thickness].join("|");
     if(!m[key])m[key]={...x,cft:0,qty:0,amount:0};
     const sign=x.type==="OUT"?-1:1;m[key].cft+=sign*this.num(x.cft);m[key].qty+=sign*this.num(x.qty);m[key].amount+=sign*this.num(x.amount);
   }
   return Object.values(m).filter(x=>Math.abs(x.cft)>1e-9);
 },
 partyBalance(name){
   let b=0;
   for(const x of DB.ledger) if(x.party===name){b+=(x.debit===name?x.amount:0);b-=(x.credit===name?x.amount:0)}
   return b;
 },
 workerWages(workerId,from,to){
   const w=DB.workers.find(x=>x.id===workerId);if(!w)return 0;
   let total=0;
   DB.attendance.filter(a=>a.workerId===workerId&&a.date>=from&&a.date<=to).forEach(a=>{
     total += a.status==="P"?w.daily: a.status==="HD"?w.daily/2:0;
     total += this.num(a.overtime)*this.num(w.hourly);
   });
   const adv=DB.advances.filter(a=>a.workerId===workerId&&a.date>=from&&a.date<=to).reduce((s,a)=>s+this.num(a.amount),0);
   return {gross:total,advances:adv,net:total-adv};
 },
 pAndL(month){
   const rows=DB.ledger.filter(x=>!month||x.date.startsWith(month));
   const revenue=rows.filter(x=>x.credit==="Sales").reduce((s,x)=>s+x.amount,0);
   const purchases=rows.filter(x=>x.description==="Timber purchase").reduce((s,x)=>s+x.amount,0);
   const labour=rows.filter(x=>x.description==="Labour wage").reduce((s,x)=>s+x.amount,0);
   const expenses=rows.filter(x=>["Expense","Freight","Labour wage"].includes(x.description)).reduce((s,x)=>s+x.amount,0);
   return {revenue,purchases,labour,expenses,totalExpenses:purchases+expenses,profit:revenue-purchases-expenses};
 }
};

E.audit=function(action,entity,id,details={}){
  DB.audit.push({id:this.uid("AUD"),ts:new Date().toISOString(),user:"local-user",action,entity,entityId:id,details});
};
E.safeNumber=function(v){const n=Number(v);return Number.isFinite(n)?n:0};
E.invoiceFingerprint=function(x){
  return [String(x.party||"").trim().toLowerCase(),x.date,x.invoiceNo||"",x.amount||0].join("|");
};
E.isDuplicateInvoice=function(x){
  const fp=this.invoiceFingerprint(x);
  return DB.invoices.some(i=>this.invoiceFingerprint(i)===fp);
};
E.postPurchase=function(x){
  const id=this.uid("STK");
  const item={id,date:x.date,wood:x.wood,length:+x.length,width:+x.width,thickness:+x.thickness,
    qty:+x.qty,cft:+x.cft,rate:+x.rate,amount:+x.amount,type:"IN",ref:x.ref||"",
    invoiceNo:x.invoiceNo||"",batchId:this.uid("BATCH"),gstRate:+(x.gstRate||0),gstAmount:+(x.gstAmount||0)};
  DB.inventory.push(item); DB.stockBatches.push({...item,status:"OPEN"});
  this.journal({date:x.date,ref:x.ref||id,description:"Timber purchase",debit:"Inventory",credit:x.party||"Supplier",amount:+x.amount,party:x.party||""});
  this.audit("CREATE","PURCHASE",id,item); return id;
};
E.postSale=function(x){
  const id=this.uid("STK");
  DB.inventory.push({id,date:x.date,wood:x.wood,length:+x.length,width:+x.width,thickness:+x.thickness,
    qty:+x.qty,cft:+x.cft,rate:+x.rate,amount:+x.amount,type:"OUT",ref:x.ref||"",invoiceNo:x.invoiceNo||""});
  this.journal({date:x.date,ref:x.ref||id,description:"Timber/furniture sale",debit:x.party||"Customer",credit:"Sales",amount:+x.amount,party:x.party||""});
  this.audit("CREATE","SALE",id,x); return id;
};
E.validateInvoice=function(x){
  const errors=[];
  if(!x.party)errors.push("Vendor is required");
  if(!x.date)errors.push("Invoice date is required");
  if(!x.wood)errors.push("Wood type is required");
  if(!(+x.qty>0))errors.push("Quantity must be greater than zero");
  if(!(+(x.length)>0))errors.push("Length is required");
  if(this.isDuplicateInvoice(x))errors.push("Possible duplicate invoice");
  return errors;
};
E.gst=function(taxable,rate){const r=+rate||0;return {taxable:+taxable,gst:+taxable*r/100,total:+taxable*(1+r/100)}};
