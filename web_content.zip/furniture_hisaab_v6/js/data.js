
const seed = {
 settings:{business:"House of Vedha",currency:"₹",wastage:15,gstRate:18,invoicePrefix:"HV",financialYear:"2026-27"},
 woodRates:{
   Mango:[
     {min:1.5,max:2.25,rate:570},{min:2.5,max:3.5,rate:620},{min:3.75,max:4.75,rate:670},
     {min:5,max:5.25,rate:720},{min:5.5,max:6,rate:770}
   ],
   Acacia:[
     {min:1.5,max:2.25,rate:570},{min:2.5,max:3.25,rate:620},{min:3.5,max:4.25,rate:660},
     {min:4.5,max:4.75,rate:710},{min:5,max:5.25,rate:750},{min:5.5,max:6,rate:800}
   ],
   Sheesham:[
     {min:1.5,max:2,rate:750},{min:2.5,max:3,rate:800},{min:3.5,max:4,rate:900},
     {min:4.5,max:5,rate:950},{min:5.5,max:6,rate:1050}
   ],
   Teak:[{min:1.5,max:2,rate:1200},{min:2.5,max:3,rate:1300},{min:3.5,max:4,rate:1400}],
   Ash:[{min:1.5,max:2,rate:850},{min:2.5,max:3,rate:900},{min:3.5,max:4,rate:980}],
   Oak:[{min:1.5,max:2,rate:850},{min:2.5,max:3,rate:900},{min:3.5,max:4,rate:980}]
 },
 inventory:[],
 parties:[],
 workers:[],
 attendance:[],
 advances:[],
 vouchers:[],
 ledger:[],
 invoices:[],audit:[],stockBatches:[],documents:[]
};
function loadDB(){
 const raw=localStorage.getItem("furnitureHisaabDB");
 if(!raw){localStorage.setItem("furnitureHisaabDB",JSON.stringify(seed));return structuredClone(seed)}
 try{return {...structuredClone(seed),...JSON.parse(raw)} }catch(e){return structuredClone(seed)}
}
let DB=loadDB();
function saveDB(){localStorage.setItem("furnitureHisaabDB",JSON.stringify(DB))}
