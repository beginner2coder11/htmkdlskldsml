@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed on PATH.
  echo Open this folder in Android Studio, then use Build ^> Generate App Bundles or APKs ^> Generate APKs.
  echo The project is already configured with Android Gradle Plugin 8.7.3 and compileSdk 35.
  pause
  exit /b 1
)
gradle clean assembleRelease
if errorlevel 1 exit /b 1
echo APK: app\build\outputs\apk\release\app-release.apk
pause
