# SAVOB Android Studio project (prototype v0.1)

This project packages the existing SAVOB HTML prototype into a simple Android WebView app. It is a wrapper APK project, not a native Flutter rewrite. Demo content and localStorage data stay on the device.


## Build APK
1. Install Android Studio (latest stable) and Android SDK platform 35.
2. Open this folder (`SAVOB_Android`) in Android Studio.
3. Allow Gradle sync/downloads to finish.
4. From menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When build finishes, use the Build notification's `locate` link. APK output is usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it (allow installation from this source if Android asks).

If sync asks for SDK platform 35, install it via Tools > SDK Manager.

## Prototype limitations
- No cloud backend or real multi-user accounts yet.
- Demo missions and approval/points are local prototype behavior.
- Admin demo PIN remains 1234; do not use as a production credential.
