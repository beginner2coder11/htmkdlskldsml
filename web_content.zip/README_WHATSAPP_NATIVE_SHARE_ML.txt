JAS LAUNDRY — WhatsApp Business Thermal PDF + Open/Print Update

Files
-----
- JAS_LAUNDRY_OWNER_ACCESS_THERMAL_WHATSAPP_PDF.html
  Updated: adds an "Open / Print Thermal PDF" action. It creates the same 72 mm thermal receipt PDF from the same receipt image used by the thermal-print workflow.
- android/ThermalPdfBridge.java
  Example Android WebView bridge methods for sharing the PDF to WhatsApp Business and opening it in a PDF / thermal-printer app.
- android/file_paths.xml and android/AndroidManifest-provider-snippet.xml
  FileProvider configuration snippets.

Important: an HTML file cannot control the signed-in WhatsApp Business account or silently choose a chat. The APK must implement the native bridge and be rebuilt. With the bridge, WhatsApp Business is targeted when installed and the PDF is attached. WhatsApp Business still requires the operator to select/confirm the customer chat and tap Send; its public share intent does not guarantee selecting a phone-number chat automatically.

APK integration
---------------
1. Copy ThermalPdfBridge.java into your Android app package and replace `YOUR.APP.PACKAGE` with the real package declaration.
2. Add AndroidX Core dependency if not already present:
   implementation "androidx.core:core:1.13.1"
3. Put file_paths.xml in app/src/main/res/xml/file_paths.xml (create xml folder if needed).
4. Merge the provider snippet into the app's AndroidManifest.xml inside <application>.
5. In the Activity that owns the WebView, register the bridge before loading the HTML:
   webView.getSettings().setJavaScriptEnabled(true);
   webView.addJavascriptInterface(new ThermalPdfBridge(this), "AndroidBridge");
   If your app already has an AndroidBridge class, merge the three methods into that existing class rather than registering a second object with the same name.
6. Rebuild and install the APK on the phone with WhatsApp Business signed in.

Usage
-----
- "WhatsApp Business · Thermal Bill PDF": generates the thermal receipt PDF, uses the saved bill customer name/mobile, targets com.whatsapp.w4b, and attaches the PDF. User confirms the intended customer chat and sends.
- "Open / Print Thermal PDF": opens the generated PDF through Android's PDF viewer / printer-app chooser. Select the installed thermal printer app and print.
- "Thermal Print": remains the existing Bluetooth thermal-image print workflow.

Printer note
------------
A thermal printer itself usually does not open a PDF file. The Android phone needs a compatible PDF viewer / thermal-printer app or the APK's Bluetooth print integration. The PDF page is 72 mm wide, matching the thermal receipt image width. Printer apps may still require selecting paper width, margins, density, and printer.

What this ZIP does not include
------------------------------
This is not a rebuilt APK. The uploaded ZIP contains the HTML app, not the Android Studio project, signing configuration, or printer SDK. Native bridge code must be integrated into the actual APK project and rebuilt to make direct WhatsApp Business targeting and Android PDF opening work.
