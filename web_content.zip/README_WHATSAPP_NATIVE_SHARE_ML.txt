JAS LAUNDRY — PDF-first WhatsApp Business integration

What changed in the HTML
------------------------
- Reads the customer mobile number from the saved bill (no manual number prompt).
- Creates the high-resolution 72mm thermal receipt PDF.
- Removes the non-working “Thermal Print” button and its browser print fallback.
- WhatsApp Business action now requests PDF-first sharing with NO bill text message.
- The preferred Android bridge is:

  @JavascriptInterface
  public boolean downloadAndShareThermalPdfToNumber(String base64, String filename, String phone)

Required Android APK implementation
-----------------------------------
The ZIP contains the updated HTML and this integration specification. It is NOT a rebuilt APK and cannot add Java code to an existing installed APK by itself.

Implement downloadAndShareThermalPdfToNumber in the Android WebView host:
1. Validate the customer phone number and decode the PDF Base64.
2. Save the PDF to the public Downloads collection using Android DownloadManager (or MediaStore).
3. Configure DownloadManager.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED), set the PDF MIME type, and use a clear filename. This gives the user an Android download-complete notification. Do not return success until the download has been queued; ideally wait for completion before starting WhatsApp sharing.
4. After the download completes, obtain a content:// URI through FileProvider or MediaStore and grant read permission.
5. Launch WhatsApp Business (package com.whatsapp.w4b) with ACTION_SEND, type application/pdf, and EXTRA_STREAM set to the PDF URI. Include FLAG_GRANT_READ_URI_PERMISSION.
6. Do NOT set EXTRA_TEXT, Intent.EXTRA_SUBJECT, or any text/message field. The PDF must be the shared payload, not a text message followed by a download link.
7. Target com.whatsapp.w4b explicitly when installed. If it is not installed, show a clear error. Do not silently open a generic chooser if the user specifically requested WhatsApp Business.
8. Run UI launch operations on the Android main thread.
9. WhatsApp Business may still show its own recipient selection. Confirm the bill's customer number before sending; WhatsApp does not provide a supported public API guaranteeing a direct media attachment to an arbitrary chat.

Download notification / open / share
------------------------------------
The DownloadManager notification should remain available in Android notifications and Downloads. The user can open or share the downloaded PDF from there. The app's PDF-first WhatsApp flow should share the same saved PDF file.

Fallback behavior
-----------------
In a browser without the native bridge, the page downloads the PDF and then attempts Web Share with the PDF file only (no text). Browser share targets and recipient selection are controlled by Android/browser. Reliable WhatsApp Business targeting and download notification require the rebuilt APK bridge above.

Testing checklist
-----------------
- Install WhatsApp Business and sign in.
- Install a rebuilt APK with downloadAndShareThermalPdfToNumber implemented.
- Create a bill with a valid customer mobile number.
- Tap “WhatsApp Business · Thermal Bill PDF”.
- Confirm PDF downloads first and Android shows a download-complete notification.
- Confirm WhatsApp Business opens with the PDF attachment and no prefilled text message.
- Confirm the intended customer chat and tap Send.
- Tap the download notification and confirm the same PDF opens; test open/share from Downloads.
- Confirm the removed “Thermal Print” option no longer appears.

Thermal PNG preview addition
----------------------------
- Order List-ൽ Thermal Print button opens an in-app modal with the full 576px PNG receipt.
- The same modal has Download PNG and Print buttons.
- Download uses AndroidBridge.saveImage when available; otherwise it uses the browser download mechanism.
- The browser fallback may depend on the WebView host's download listener. Reliable Android Downloads/Gallery behavior requires the APK native bridge.
