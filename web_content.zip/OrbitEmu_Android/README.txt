ORBIT Emulator Launcher — Android Studio project

This is an installable-app source project wrapping the ORBIT launcher interface in a native Android Activity/WebView. It supports phone/tablet sizing and orientation changes.

Build an APK:
1. Install Android Studio (current stable version).
2. Open this folder as a project.
3. Let Gradle sync and install any requested Android SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Use the APK link shown by Android Studio to install on your Android device.

What works:
- Offline launcher interface loaded from app assets.
- Horizontal carousel, category filters, search, favorites, recent selection.
- Immersive full-screen layout; follows device orientation.

Limitations:
- This is an Android Studio source project, not a precompiled APK.
- Sample game tiles are placeholders. The Play button reports that actual launching is not connected.
- Launching installed games/emulators requires adding Android package discovery and explicit launch-intent handling. Some apps restrict external launching.
- No PC server, ADB, or companion app is included.
