const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors()); // Allow requests from your APK
app.use(express.json());

// In-memory "Database" for fake transactions
const transactions = {};

// Helper: Generate a fake ETH hash
function generateFakeHash() {
    const chars = '0123456789abcdef';
    let hash = '0x';
    for (let i = 0; i < 64; i++) {
        hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
}

// Endpoint: Send Transaction
app.post('/api/send', (req, res) => {
    const { recipient, amount, network } = req.body;

    if (!recipient || !amount) {
        return res.status(400).json({ error: 'Missing recipient or amount' });
    }

    const hash = generateFakeHash();
    
    // Simulate processing time (1-3 seconds)
    setTimeout(() => {
        // Store the transaction
        transactions[hash] = {
            hash: hash,
            recipient: recipient,
            amount: amount,
            network: network,
            status: 'Confirmed',
            timestamp: new Date().toISOString(),
            explorerUrl: getExplorerUrl(hash, network)
        };

        res.json({
            success: true,
            message: 'Transaction broadcasted successfully',
            data: transactions[hash]
        });
    }, 1500);
});

// Endpoint: Check Transaction Status
app.get('/api/tx/:hash', (req, res) => {
    const hash = req.params.hash;
    const tx = transactions[hash];

    if (!tx) {
        return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json(tx);
});

// Helper: Get Explorer URL
function getExplorerUrl(hash, network) {
    switch(network) {
        case 'eth': return `https://etherscan.io/tx/${hash}`;
        case 'bsc': return `https://bscscan.com/tx/${hash}`;
        case 'polygon': return `https://polygonscan.com/tx/${hash}`;
        default: return `https://etherscan.io/tx/${hash}`;
    }
}

app.listen(PORT, () => {
    console.log(`USDT Flash Server running on port ${PORT}`);
});