JAS LAUNDRY ROOM — GOOGLE APPS SCRIPT CLOUD EDITION

ഈ build-ൽ Firebase SDK, Firebase Authentication, Firestore, Appwrite references എന്നിവ HTML-ൽ നിന്ന് നീക്കി. Login / Owner bootstrap / Staff accounts / Session validation / ERP data sync എന്നിവ Google Apps Script Web App API ഉപയോഗിച്ചാണ് പ്രവർത്തിക്കുക.

ZIP-ൽ ഉള്ളത്
1. JAS_LAUNDRY_ROOM_GOOGLE_CLOUD.html — പുതിയ ERP HTML
2. GoogleAppsScript.gs — Google Apps Script backend
3. ഈ setup guide
4. INTEGRATION_STATUS_ML.txt — പരിശോധനാ നിലയും പരിധികളും

ആദ്യമായി Google Apps Script backend deploy ചെയ്യുക
1. https://script.google.com തുറന്ന് New project സൃഷ്ടിക്കുക.
2. Code.gs-ൽ ഉള്ള default code മുഴുവൻ മാറ്റി ഈ ZIP-യിലെ GoogleAppsScript.gs paste ചെയ്യുക.
3. Project Settings → Script Properties-ൽ JAS_APP_SECRET എന്ന property സൃഷ്ടിക്കുക.
4. Value ആയി കുറഞ്ഞത് 32 അക്ഷരമുള്ള ശക്തമായ random secret നൽകുക. Google account password ഇവിടെ ഉപയോഗിക്കരുത്.
5. Save ചെയ്യുക. Function dropdown-ൽ setupJasCloud തിരഞ്ഞെടുത്ത് Run ചെയ്യുക; ആവശ്യപ്പെട്ട Google permissions authorize ചെയ്യുക.
6. Deploy → New deployment → Web app.
   Execute as: Me
   Who has access: Anyone
7. Deploy ചെയ്ത ശേഷം ലഭിക്കുന്ന Web App URL (/exec) പകർത്തുക. Script Properties-ൽ സൂക്ഷിച്ച അതേ JAS_APP_SECRET ആണ് app-ൽ Secret Token ആയി നൽകേണ്ടത്.

App-ൽ ആദ്യ Setup
1. JAS_LAUNDRY_ROOM_GOOGLE_CLOUD.html തുറക്കുക (അല്ലെങ്കിൽ HTML-to-APK tool-ൽ ഈ ഫയൽ ഉപയോഗിക്കുക).
2. Login page-ലെ Google Apps Script URL, Secret Token നൽകുക.
3. Save Connection Details അമർത്തുക.
4. Create First Owner Account തുറന്ന് Owner name, email/Login ID, പുതിയ ERP password (കുറഞ്ഞത് 10 അക്ഷരം) നൽകി Create ചെയ്യുക.
5. Owner Login ചെയ്യുക. വിജയിച്ചാൽ Session validate ചെയ്ത് Google Cloud data download/upload ആരംഭിക്കും.
6. Owner-ന് Settings → Owner / Staff Accounts വഴി Staff account സൃഷ്ടിക്കാം.
7. മറ്റ് ഫോണുകളിലും അതേ URL, Token Save ചെയ്ത് അതത് Owner/Staff login ഉപയോഗിക്കുക.

പ്രവർത്തനരീതി
- Login വിജയിച്ചാൽ Google Apps Script session token server-ൽ validate ചെയ്യും.
- ഓരോ save-നും local-first save നടക്കും; തുടർന്ന് authenticated saveData API വഴി cloud sync ശ്രമിക്കും.
- Internet തിരികെ വന്നാൽ sync വീണ്ടും ശ്രമിക്കും.
- App തുറന്നിരിക്കുന്ന സമയത്ത് 45 സെക്കൻഡിന് ഒരിക്കൽ cloud pull/poll നടക്കും.
- Logout ചെയ്യുമ്പോൾ server session revoke ചെയ്യാൻ ശ്രമിക്കും.
- Staff data access server-side allowlist വഴി പരിമിതപ്പെടുത്തിയിരിക്കുന്നു.

വളരെ പ്രധാനപ്പെട്ട സുരക്ഷാ/പരിധി കുറിപ്പുകൾ
- Secret Token HTML/APK-യിൽ നിന്നും പൂർണ്ണമായി മറയ്ക്കാൻ കഴിയില്ല; localStorage-ൽ സൂക്ഷിക്കുന്നു. APK പരിശോധിക്കാൻ കഴിയുന്ന ഒരാൾക്ക് token കണ്ടെത്താൻ സാധ്യതയുണ്ട്. അതിനാൽ ഇത് high-security production secret ആയി കാണരുത്. കൂടുതൽ ശക്തമായ സുരക്ഷയ്ക്കായി token-നെ app client-ൽ നിന്ന് മാറ്റി server-to-server proxy / managed identity ഉപയോഗിക്കണം.
- Google Apps Script Web App endpoint Anyone access ആയി deploy ചെയ്യേണ്ടതിനാൽ ഓരോ API call-ലും shared secret + user session പരിശോധിക്കുന്നു. Script Properties-ൽ മാത്രം server secret സൂക്ഷിക്കുക.
- Session lifetime 12 മണിക്കൂറാണ്; കാലാവധി കഴിഞ്ഞാൽ വീണ്ടും login വേണം.
- AndroidBridge.postToGoogleSheet(url, payload) method arbitrary JSON POST request അയച്ച് response തിരികെ നൽകണം. HTML-ൽ bridge method ഉപയോഗിച്ചിരിക്കുന്നു; APK native Java/Kotlin implementation/source ലഭ്യമല്ലാത്തതിനാൽ native bridge-ന്റെ end-to-end പ്രവർത്തനം ഇവിടെ സ്ഥിരീകരിക്കാൻ കഴിഞ്ഞിട്ടില്ല. Browser fallback fetch ഉണ്ട്, പക്ഷേ Apps Script redirect/CORS നിയന്ത്രണങ്ങൾ കാരണം APK bridge ആണ് ഉചിതം.
- ഈ HTML build-ൽ പഴയ Firebase backend data-യിൽ നിന്ന് സ്വയം migration ഇല്ല. Google Apps Script sheet-ൽ data ഇല്ലെങ്കിൽ നിലവിലെ ഫോണിലെ local ERP data ആദ്യ login-ൽ upload ചെയ്യും. Data Firebase-ൽ മാത്രം ആണെങ്കിൽ അത് വേറിട്ട് export/merge ചെയ്യണം.
- നിലവിലുള്ള HTML features നിലനിർത്തിയിട്ടുണ്ട്; APK build, device login, two-phone sync, Google Apps Script deployment എന്നിവ live test ചെയ്തിട്ടില്ല.
- പഴയ Firebase data / പഴയ APK / backup delete ചെയ്യരുത്. ആദ്യം backup എടുത്ത് രണ്ടാമത്തെ ഫോണിൽ പരീക്ഷിക്കുക.
