(function(){
  const c=document.getElementById('visual-fx'); if(!c) return;
  const x=c.getContext('2d'); let w=0,h=0,dpr=1,t=0;
  const dust=Array.from({length:55},(_,i)=>({x:Math.random(),y:Math.random(),r:.5+Math.random()*1.7,s:.08+Math.random()*.24,a:.06+Math.random()*.13}));
  function size(){dpr=Math.min(2,window.devicePixelRatio||1);w=innerWidth;h=innerHeight;c.width=w*dpr;c.height=h*dpr;c.style.width=w+'px';c.style.height=h+'px';x.setTransform(dpr,0,0,dpr,0,0)}
  function draw(){
    t+=.008; x.clearRect(0,0,w,h);
    const theme=window.__flTheme||'grass';
    let tint='rgba(255,214,145,.035)';
    if(theme==='cave'||theme==='lair') tint='rgba(100,130,210,.055)';
    if(theme==='lava') tint='rgba(255,90,35,.055)';
    if(theme==='swamp') tint='rgba(120,190,90,.04)';
    x.fillStyle=tint;x.fillRect(0,0,w,h);
    for(const p of dust){
      p.y-=p.s/1000*16; if(p.y<0)p.y=1;
      const px=p.x*w+Math.sin(t+p.x*8)*9, py=p.y*h;
      x.fillStyle='rgba(255,238,194,'+p.a+')';x.beginPath();x.arc(px,py,p.r,0,Math.PI*2);x.fill();
    }
    const g=x.createRadialGradient(w*.5,h*.46,Math.min(w,h)*.12,w*.5,h*.46,Math.max(w,h)*.72);
    g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.66,'rgba(0,0,0,.035)');g.addColorStop(1,'rgba(0,0,0,.42)');
    x.fillStyle=g;x.fillRect(0,0,w,h);
    requestAnimationFrame(draw);
  }
  addEventListener('resize',size,{passive:true}); size(); draw();
})();

/* === Forgotten Lands: powers + normal monster drops === */
(function(){
  const powers = [
    {name:"Fogo", icon:"🔥", unlock:1, dmg:18, cd:1800},
    {name:"Gelo", icon:"❄️", unlock:1, dmg:14, cd:2200},
    {name:"Raio", icon:"⚡", unlock:5, dmg:25, cd:2500},
    {name:"Vento", icon:"🌪️", unlock:10, dmg:30, cd:3000},
    {name:"Meteoro", icon:"☄️", unlock:20, dmg:48, cd:4500}
  ];
  let powerLevel = Number(localStorage.getItem("fl_power_level") || "1");
  const ready = new Map();

  function toast(t){
    const el=document.getElementById("drop-toast");
    if(!el)return;
    el.textContent=t; el.style.opacity="1";
    clearTimeout(el._timer); el._timer=setTimeout(()=>el.style.opacity="0",1700);
  }
  function refreshPowers(){
    powers.forEach((p,i)=>{
      const b=document.getElementById("power-"+(i+1)); if(!b)return;
      const unlocked=powerLevel>=p.unlock;
      b.classList.toggle("locked",!unlocked);
      b.classList.toggle("ready",unlocked);
      b.title=unlocked ? p.name+" — pronto" : p.name+" — desbloqueia no nível "+p.unlock;
      b.querySelector("span").textContent=unlocked?p.icon:"🔒";
    });
  }
  function cast(i){
    const p=powers[i]; if(powerLevel<p.unlock){toast(p.name+" desbloqueia no nível "+p.unlock);return;}
    if(ready.get(i)){toast(p.name+" ainda recarregando");return;}
    ready.set(i,true);
    toast(p.icon+" "+p.name+" lançado! Dano base "+p.dmg);
    const b=document.getElementById("power-"+(i+1));
    if(b){b.style.transform="scale(.92)";setTimeout(()=>b.style.transform="",120)}
    setTimeout(()=>ready.delete(i),p.cd);
  }
  powers.forEach((_,i)=>{
    const b=document.getElementById("power-"+(i+1));
    if(b)b.addEventListener("click",()=>cast(i));
  });

  // First two powers are available immediately.
  refreshPowers();

  // Normal drop table: 60% total chance of a drop event.
  window.ForgottenLandsDrop = function(){
    if(Math.random()>0.60){ toast("O monstro não deixou nenhum item."); return null; }
    const pool=[
      ["Ouro",Math.floor(5+Math.random()*26)],
      ["Poção de HP",1],["Poção de MP",1],
      ["Fragmento de Ferro",1],["Pele de Monstro",1],
      ["Cristal Comum",1],["Runa Simples",1]
    ];
    const item=pool[Math.floor(Math.random()*pool.length)];
    toast("🎁 Drop normal: "+item[0]+(item[1]>1?" x"+item[1]:""));
    return {name:item[0],qty:item[1],rarity:"normal"};
  };

  // Hooks commonly used by the existing client, if present.
  window.FL_Powers = {powers, getLevel:()=>powerLevel, setLevel:(v)=>{powerLevel=Number(v)||1;localStorage.setItem("fl_power_level",powerLevel);refreshPowers();}};
})();
