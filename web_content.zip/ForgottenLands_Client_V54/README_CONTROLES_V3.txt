FORGOTTEN LANDS — CONTROLES V3

Esta versão corrige o problema de botões cortados/sobrepostos no celular.

Zonas fixas:
- joystick: canto inferior esquerdo;
- ações: grade independente no canto inferior direito;
- chat: corredor central separado das ações;
- configurações: canto superior direito.

Os botões nunca são posicionados um em cima do outro pelo CSS. O tamanho
se adapta ao espaço disponível e respeita a área segura do Android.

Servidor/multiplayer: não alterado.
