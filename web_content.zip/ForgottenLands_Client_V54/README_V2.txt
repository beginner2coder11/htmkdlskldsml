Forgotten Lands — Client V2 Pixel MMORPG

- Controles móveis reorganizados e elevados da área de navegação Android.
- Mundo e sprites com renderização crisp/pixel.
- Personagem/equipamentos com detalhes mais nítidos.
- Asas com flap contínuo e movimento leve.
- Painel Equipamento & Bônus.
- Bônus visuais/client-side para espada, armadura, escudo, elmo e asas.
- Câmera suave e zoom preservados.
- Halloween preservado no Porto Inicial.
- Servidor/protocolo não alterado.

Os bônus do painel são informativos/client-side e não mudam a autoridade do servidor.
