FORGOTTEN LANDS — CLIENTE HD MMORPG

Base: cliente multiplayer existente. O servidor/protocolo nao foi alterado.

Melhorias visuais no cliente:
- HUD MMORPG premium com barras, molduras, sombras e vidro.
- Joystick e botoes de combate redesenhados para celular.
- Minimap com moldura premium.
- Menus, inventario, quests, trade e configuracoes com novo visual.
- Iluminacao/atmosfera 2.5D, vinheta, particulas e contraste cinematografico.
- Sombras e destaque visual ao redor dos monstros sem trocar os monstros existentes.
- Tela inicial de login/personagem mais moderna.
- Layout responsivo para retrato e paisagem.

Notificacoes:
- O cliente pede permissao e pode enviar lembretes enquanto o app estiver em execucao.
- Notificacoes push quando o app estiver totalmente fechado exigem um servico push/native (FCM/OneSignal etc.) e integracao de backend; isso nao foi adicionado para manter o servidor existente intocado.


VERSION 2 — CAMERA + HALLOWEEN
- Servidor/protocolo nao alterados.
- Porto Inicial usa tema Halloween somente no cliente.
- Aboboras, lanternas, morcegos, lua e nevoa sao desenhados pelo cliente.
- Controles laterais reorganizados para nao cortar no modo retrato.
- Camera com suavizacao, movimento de acompanhamento, arrasto e zoom por gesto/roda.
- Estilo visual: MMORPG isometrico classico original, sem copiar assets oficiais de terceiros.
- PT/FR/EN continuam disponiveis; novas mensagens de camera/Halloween foram traduzidas.
