package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBackup {
        private String safeFileName(String fileName) {
            String safe = fileName == null || fileName.trim().isEmpty()
                    ? "AFRIQUIA-BACKUP.json" : fileName.trim();
            // Keep the filename simple and compatible with Android file managers.
            safe = safe.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
            return safe;
        }

        private void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }

        @JavascriptInterface
        public boolean saveBackup(String json, String fileName) {
            final String safe = safeFileName(fileName);
            final byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Android 10+ : save directly into the public "Download" folder
                    // using MediaStore. No storage permission is needed.
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                    Uri uri = null;
                    Exception firstError = null;
                    try {
                        uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    } catch (Exception e) {
                        firstError = e;
                    }

                    // Fallback for devices whose Downloads provider rejects one of the optional fields.
                    if (uri == null) {
                        ContentValues fallback = new ContentValues();
                        fallback.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                        fallback.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                        fallback.put(MediaStore.MediaColumns.IS_PENDING, 1);
                        uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, fallback);
                    }

                    if (uri == null) {
                        throw new Exception(firstError != null && firstError.getMessage() != null
                                ? firstError.getMessage() : "تعذر إنشاء الملف داخل التنزيلات");
                    }

                    boolean published = false;
                    try {
                        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                            if (out == null) throw new Exception("تعذر فتح ملف النسخة الاحتياطية");
                            out.write(data);
                            out.flush();
                        }

                        ContentValues done = new ContentValues();
                        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        getContentResolver().update(uri, done, null, null);

                        // Verify only that the file can be opened and contains the expected number of bytes.
                        long length = -1;
                        try (android.content.res.AssetFileDescriptor afd =
                                     getContentResolver().openAssetFileDescriptor(uri, "r")) {
                            if (afd != null && afd.getLength() >= 0) length = afd.getLength();
                        } catch (Exception ignored) {
                            // Some providers do not expose a length. The successful write is enough.
                        }
                        if (length >= 0 && length != data.length) {
                            throw new Exception("تم إنشاء الملف لكن حجمه غير مكتمل");
                        }

                        published = true;
                        toast("✅ تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                        return true;
                    } finally {
                        if (!published) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                        }
                    }
                }

                // Android 9 and older: write to the public Download folder.
                // The old path may require WRITE_EXTERNAL_STORAGE on older Android versions.
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("تعذر إنشاء مجلد التنزيلات");
                }
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                    out.getFD().sync();
                }
                if (!file.exists() || file.length() != data.length) {
                    throw new Exception("لم يكتمل حفظ الملف");
                }
                toast("✅ تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                return true;
            } catch (Exception e) {
                String msg = e.getMessage();
                toast("❌ فشل تنزيل النسخة الاحتياطية" + (msg == null || msg.isEmpty() ? "" : ": " + msg));
                return false;
            }
        }
    }
}
