package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBackup {
        @JavascriptInterface public boolean saveBackup(String json, String fileName) {
            try {
                String safe = fileName == null ? "backup.json" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("تعذر إنشاء ملف في مجلد التنزيلات");
                    boolean published = false;
                    try {
                        byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);
                        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                            if (out == null) throw new Exception("تعذر فتح ملف النسخة الاحتياطية");
                            out.write(data);
                            out.flush();
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Downloads.IS_PENDING, 0);
                        int updated = getContentResolver().update(uri, done, null, null);
                        if (updated <= 0) throw new Exception("تعذر إنهاء حفظ ملف النسخة الاحتياطية");
                        published = true;
                    } finally {
                        if (!published) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                        }
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم حفظ النسخة الاحتياطية فعليًا في مجلد التنزيلات", Toast.LENGTH_LONG).show());
                    return true;
                }
                // الأجهزة القديمة: لا نعلن نجاحًا كاذبًا. هذه النسخة تستهدف Android 14+.
                return false;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذر تنزيل النسخة: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }
}
