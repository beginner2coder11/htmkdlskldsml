package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import android.content.Intent;
import android.webkit.WebChromeClient.FileChooserParams;
import android.content.ActivityNotFoundException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح اختيار الصور", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBackup {
        @JavascriptInterface
        public boolean saveBackup(String json, String fileName) {
            String safe = fileName == null ? "backup.json" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
            byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("تعذر إنشاء الملف في التنزيلات");
                    boolean ok = false;
                    try {
                        OutputStream out = getContentResolver().openOutputStream(uri, "w");
                        if (out == null) throw new Exception("تعذر فتح ملف التنزيل");
                        try {
                            out.write(data);
                            out.flush();
                        } finally {
                            try { out.close(); } catch (Exception ignored) {}
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Downloads.IS_PENDING, 0);
                        int updated = getContentResolver().update(uri, done, null, null);
                        if (updated <= 0) throw new Exception("تعذر إنهاء حفظ الملف");
                        // تحقق أخير من أن الملف أصبح ظاهرًا كملف منشور.
                        android.database.Cursor c = getContentResolver().query(
                                uri, new String[]{MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING},
                                null, null, null);
                        try {
                            if (c == null || !c.moveToFirst()) throw new Exception("لم يتم العثور على الملف بعد الحفظ");
                            int pending = c.getInt(c.getColumnIndexOrThrow(MediaStore.Downloads.IS_PENDING));
                            if (pending != 0) throw new Exception("الملف ما زال قيد الحفظ");
                        } finally { if (c != null) c.close(); }
                        ok = true;
                        Toast.makeText(MainActivity.this, "تم حفظ النسخة في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                        return true;
                    } finally {
                        if (!ok) { try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {} }
                    }
                }

                // دعم الأجهزة القديمة أيضًا.
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                }
                if (!file.exists() || file.length() != data.length) throw new Exception("لم يكتمل حفظ الملف");
                Toast.makeText(MainActivity.this, "تم حفظ النسخة في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "فشل حفظ النسخة: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    Uri uri = data.getData();
                    if (uri != null) results = new Uri[]{uri};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

}
