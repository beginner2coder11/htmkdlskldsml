# Release-Test – 4.000 WOCHEN Plus X

## Funktion
- [ ] Startseite öffnet ohne Fehler
- [ ] Aktuelles Datum stimmt
- [ ] Wochenplanung synchronisiert mit Heute
- [ ] Foto-Vorschau synchronisiert mit Startseite
- [ ] Beschriftung synchronisiert mit Startseite
- [ ] X/Y-Position der Beschriftung bleibt erhalten
- [ ] Tagebuch-Suche funktioniert
- [ ] Fotos in vorgesehenen Bereichen funktionieren
- [ ] Lebenskalender funktioniert
- [ ] Erinnerungen lassen sich anlegen
- [ ] Benachrichtigungsberechtigung funktioniert
- [ ] App-Neustart erhält gespeicherte Daten
- [ ] Geräte-Neustart erhält Erinnerungen
- [ ] Keine sichtbaren Fehlermeldungen

## Datenschutz / Berechtigungen
- [ ] Nur benötigte Android-Berechtigungen vorhanden
- [ ] Datenschutz-URL aktiv und erreichbar
- [ ] Datenschutzerklärung entspricht exakt der Release-Version
- [ ] Play-Console-Datensicherheitsformular entspricht exakt der Release-Version

## Google Play
- [ ] Target API 36
- [ ] versionCode erhöht
- [ ] Release AAB signiert
- [ ] Play App Signing eingerichtet
- [ ] Store-Name
- [ ] Kurzbeschreibung
- [ ] Vollständige Beschreibung
- [ ] App-Symbol
- [ ] Screenshots
- [ ] Inhaltsbewertung
- [ ] Zielgruppe
- [ ] Werbeangabe
- [ ] App-Zugriff / Prüferhinweise, falls erforderlich
- [ ] Closed Test, falls vom Entwicklerkonto verlangt
