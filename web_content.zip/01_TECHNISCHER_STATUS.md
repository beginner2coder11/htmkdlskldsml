# 4.000 WOCHEN Plus X – Play-Store Vorbereitung

Stand: 21.09.2026

## Bereits vorhanden / geprüft
- Android-Projekt aus der aktuellen Konverter-APK übernommen.
- compileSdk = 36
- targetSdk = 36
- minSdk = 26
- applicationId = de.wochen.plusx
- versionCode für die nächste Fassung auf 4 erhöht
- versionName für die nächste Fassung auf 1.3 gesetzt
- Benachrichtigungsberechtigung POST_NOTIFICATIONS vorhanden.
- RECEIVE_BOOT_COMPLETED vorhanden, weil Erinnerungen nach Neustart wiederhergestellt werden.
- Kein INTERNET-Permission-Eintrag im vorhandenen Manifest.
- Web-App verwendet localStorage für App-Daten.
- Im geprüften HTML wurden keine fetch()-Aufrufe und keine HTTP/HTTPS-Netzwerkaufrufe gefunden.

## Noch vor Veröffentlichung
1. Signierten Release-Build als Android App Bundle (.aab) erzeugen.
2. Keystore/Play App Signing sauber einrichten.
3. Release auf mindestens einem aktuellen Android-Gerät testen.
4. Datenschutzkontakt: 4000plus_x@gmx.net; aktive Datenschutz-URL noch einsetzen.
5. Play-Console-Formulare zu Datensicherheit, Zielgruppe und Inhaltsbewertung ausfüllen.
6. Store-Grafiken/Screenshots final erstellen.
7. Falls für das Entwicklerkonto erforderlich: Closed Test und anschließend Produktionszugriff.
