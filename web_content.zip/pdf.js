/* ऑफ़लाइन PDF इंजन: कैनवास पर हिंदी टेक्स्ट बनाकर JPEG पेजों से PDF फ़ाइल तैयार करता है */
(function(){
const FONT='"Noto Sans Devanagari","Mangal","Nirmala UI",system-ui,sans-serif';

function loadImg(src){
  return new Promise(res=>{ if(!src) return res(null);
    const i=new Image(); i.onload=()=>res(i); i.onerror=()=>res(null); i.src=src; });
}
function b64ToBytes(dataUrl){
  const b=atob(dataUrl.split(',')[1]); const u=new Uint8Array(b.length);
  for(let i=0;i<b.length;i++) u[i]=b.charCodeAt(i); return u;
}

class PdfDoc{
  constructor(opt){
    opt=opt||{};
    this.land=!!opt.landscape;
    this.W=this.land?1754:1240; this.H=this.land?1240:1754; this.M=56;
    this.group=opt.group||{}; this.logo=opt.logo||null; this.title=opt.title||'';
    this.pagesJpg=[]; this.pageNo=0;
    this.c=document.createElement('canvas'); this.c.width=this.W; this.c.height=this.H;
    this.x=this.c.getContext('2d');
    this.newPage(true);
  }
  font(size,bold){ this.x.font=(bold?'700 ':'400 ')+size+'px '+FONT; }
  finishPage(){
    const x=this.x;
    this.font(16); x.fillStyle='#8a7a84'; x.textAlign='left';
    x.fillText((this.group.name||'')+' • '+this.title, this.M, this.H-28);
    x.textAlign='right';
    x.fillText('पृष्ठ '+this.pageNo+'   •   तैयार: '+(this.group.printDate||''), this.W-this.M, this.H-28);
    x.strokeStyle='#e5d5df'; x.beginPath(); x.moveTo(this.M,this.H-52); x.lineTo(this.W-this.M,this.H-52); x.stroke();
    this.pagesJpg.push(b64ToBytes(this.c.toDataURL('image/jpeg',0.86)));
  }
  newPage(first){
    if(!first) this.finishPage();
    this.pageNo++;
    const x=this.x; x.setTransform(1,0,0,1,0,0);
    x.fillStyle='#fff'; x.fillRect(0,0,this.W,this.H);
    // header band
    x.fillStyle='#8e1f63'; x.fillRect(0,0,this.W,10);
    let tx=this.M; const top=34;
    if(this.logo){ try{ x.save(); this.roundRect(this.M,top,84,84,16); x.clip(); x.drawImage(this.logo,this.M,top,84,84); x.restore(); tx=this.M+100; }catch(e){} }
    x.textAlign='left'; x.fillStyle='#8e1f63'; this.font(34,true);
    x.fillText(this.fit(this.group.name||'महिला स्वयं सहायता समूह', this.W-tx-this.M-360), tx, top+38);
    x.fillStyle='#6b5a64'; this.font(19);
    const sub=[this.group.village,this.group.tagline].filter(Boolean).join(' • ');
    if(sub) x.fillText(this.fit(sub,this.W-tx-this.M-360), tx, top+72);
    x.textAlign='right'; x.fillStyle='#2a1d26'; this.font(26,true);
    x.fillText(this.title, this.W-this.M, top+38);
    if(this.group.sub2){ this.font(17); x.fillStyle='#6b5a64'; x.fillText(this.group.sub2, this.W-this.M, top+70); }
    x.strokeStyle='#8e1f63'; x.lineWidth=2; x.beginPath(); x.moveTo(this.M,top+100); x.lineTo(this.W-this.M,top+100); x.stroke(); x.lineWidth=1;
    this.y=top+124;
  }
  roundRect(x0,y0,w,h,r){ const x=this.x; x.beginPath(); x.moveTo(x0+r,y0); x.arcTo(x0+w,y0,x0+w,y0+h,r); x.arcTo(x0+w,y0+h,x0,y0+h,r); x.arcTo(x0,y0+h,x0,y0,r); x.arcTo(x0,y0,x0+w,y0,r); x.closePath(); }
  fit(s,w){ s=String(s); if(this.x.measureText(s).width<=w) return s; while(s.length>1&&this.x.measureText(s+'…').width>w) s=s.slice(0,-1); return s+'…'; }
  limit(){ return this.H-70; }
  ensure(h){ if(this.y+h>this.limit()) this.newPage(); }
  space(h){ this.y+=h; }
  heading(t,opt){
    opt=opt||{}; this.ensure(70);
    const x=this.x; x.fillStyle=opt.bg||'#fbe9f3'; this.roundRect(this.M,this.y,this.W-2*this.M,44,10); x.fill();
    x.fillStyle='#8e1f63'; this.font(22,true); x.textAlign='left'; x.fillText(t,this.M+14,this.y+30);
    this.y+=56;
  }
  text(t,opt){
    opt=opt||{}; const size=opt.size||19; this.font(size,opt.bold);
    const lines=this.wrap(String(t), this.W-2*this.M); const lh=size*1.45;
    for(const ln of lines){ this.ensure(lh); this.x.fillStyle=opt.color||'#2a1d26'; this.x.textAlign=opt.align||'left';
      const xx=opt.align==='right'?this.W-this.M:opt.align==='center'?this.W/2:this.M;
      this.x.fillText(ln,xx,this.y+size); this.y+=lh; }
  }
  wrap(s,w){
    const out=[]; for(const para of s.split('\n')){
      const words=para.split(' '); let cur='';
      for(const wd of words){ const t=cur?cur+' '+wd:wd;
        if(this.x.measureText(t).width<=w||!cur) cur=t; else { out.push(cur); cur=wd; } }
      // break very long single words
      while(this.x.measureText(cur).width>w && cur.length>2){ let i=cur.length; while(i>1&&this.x.measureText(cur.slice(0,i)).width>w) i--; out.push(cur.slice(0,i)); cur=cur.slice(i); }
      out.push(cur);
    } return out;
  }
  /* items: [[label,value],...] */
  kvBoxes(items,cols){
    cols=cols||4; const gap=12, w=(this.W-2*this.M-gap*(cols-1))/cols, h=78;
    for(let i=0;i<items.length;i+=cols){
      this.ensure(h+gap);
      items.slice(i,i+cols).forEach((it,j)=>{
        const x0=this.M+j*(w+gap), x=this.x;
        x.fillStyle='#fcf6fa'; this.roundRect(x0,this.y,w,h,12); x.fill();
        x.strokeStyle='#ecd9e5'; x.stroke();
        x.fillStyle=it[2]||'#8e1f63'; x.fillRect(x0,this.y+10,5,h-20);
        x.textAlign='left'; x.fillStyle='#6b5a64'; this.font(17); x.fillText(this.fit(it[0],w-24),x0+16,this.y+30);
        x.fillStyle='#2a1d26'; this.font(25,true); x.fillText(this.fit(String(it[1]),w-24),x0+16,this.y+62);
      });
      this.y+=h+gap;
    }
  }
  /* profile block with photo */
  profile(img,lines){
    const h=Math.max(150,lines.length*30+20); this.ensure(h+10);
    const x=this.x; let tx=this.M+14;
    x.fillStyle='#fffaf3'; this.roundRect(this.M,this.y,this.W-2*this.M,h,14); x.fill(); x.strokeStyle='#f2dcae'; x.stroke();
    if(img){ x.save(); this.roundRect(this.M+14,this.y+14,122,122,61); x.clip(); x.drawImage(img,this.M+14,this.y+14,122,122); x.restore(); tx=this.M+156; }
    lines.forEach((l,i)=>{ x.textAlign='left'; x.fillStyle=i===0?'#8e1f63':'#2a1d26'; this.font(i===0?28:19,i===0); x.fillText(this.fit(l,this.W-tx-this.M-10),tx,this.y+(i===0?46:42+i*30)); });
    this.y+=h+14;
  }
  /* cols: [{h:'शीर्षक',w:1,a:'r'|'l'|'c'}], rows: arrays, opt.total: array */
  table(cols,rows,opt){
    opt=opt||{}; const fs=opt.size||(this.land?18:17); const pad=7, lh=fs*1.3;
    const tw=this.W-2*this.M, sw=cols.reduce((a,c)=>a+(c.w||1),0);
    const ws=cols.map(c=>(c.w||1)*tw/sw); const x=this.x;
    const headH=()=>{ this.font(fs,true); return Math.max(...cols.map((c,j)=>this.wrap(c.h,ws[j]-2*pad).length))*lh+2*pad; };
    const drawRow=(cells,style)=>{
      this.font(fs,style==='head'||style==='tot');
      const lines=cells.map((v,j)=>this.wrap(v==null?'':String(v),ws[j]-2*pad));
      const h=Math.max(...lines.map(l=>l.length))*lh+2*pad;
      if(style!=='head' && this.y+h>this.limit()){ this.newPage(); drawHead(); this.font(fs,style==='tot'); }
      let xx=this.M;
      x.fillStyle=style==='head'?'#8e1f63':style==='tot'?'#fbe9f3':(style==='alt'?'#fcf7fa':'#ffffff');
      x.fillRect(this.M,this.y,tw,h);
      lines.forEach((ls,j)=>{
        const a=style==='head'?'c':(cols[j].a||'r');
        x.fillStyle=style==='head'?'#ffffff':'#2a1d26';
        if(style!=='head'&&cols[j].color) x.fillStyle=cols[j].color;
        ls.forEach((ln,k)=>{
          x.textAlign=a==='l'?'left':a==='c'?'center':'right';
          const px=a==='l'?xx+pad:a==='c'?xx+ws[j]/2:xx+ws[j]-pad;
          x.fillText(ln,px,this.y+pad+fs*0.98+k*lh);
        });
        xx+=ws[j];
      });
      x.strokeStyle='#e3cfdb'; x.strokeRect(this.M,this.y,tw,h);
      let vx=this.M; ws.slice(0,-1).forEach(w=>{ vx+=w; x.beginPath(); x.moveTo(vx,this.y); x.lineTo(vx,this.y+h); x.stroke(); });
      this.y+=h;
    };
    const drawHead=()=>drawRow(cols.map(c=>c.h),'head');
    this.ensure(headH()+lh*2+2*pad); drawHead();
    rows.forEach((r,i)=>drawRow(r,i%2?'alt':''));
    if(opt.total) drawRow(opt.total,'tot');
    this.y+=16;
  }
  signatures(names){
    this.ensure(140); this.y+=60; const n=names.length, w=(this.W-2*this.M)/n, x=this.x;
    names.forEach((nm,i)=>{ const cx=this.M+w*i+w/2; x.strokeStyle='#555'; x.beginPath(); x.moveTo(cx-w*0.35,this.y); x.lineTo(cx+w*0.35,this.y); x.stroke();
      x.fillStyle='#2a1d26'; x.textAlign='center'; this.font(18,true); x.fillText(nm[0],cx,this.y+28); this.font(16); x.fillStyle='#6b5a64'; x.fillText(nm[1]||'',cx,this.y+52); });
    this.y+=70;
  }
  build(){
    this.finishPage();
    const pw=this.land?841.89:595.28, ph=this.land?595.28:841.89;
    const enc=new TextEncoder(); const parts=[]; const off=[]; let pos=0;
    const push=d=>{ if(typeof d==='string') d=enc.encode(d); parts.push(d); pos+=d.length; };
    const n=this.pagesJpg.length; const total=3+n*3;
    push(new Uint8Array([37,80,68,70,45,49,46,52,10,37,226,227,207,211,10]));
    off[1]=pos; push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
    const kids=[]; for(let i=0;i<n;i++) kids.push((3+i*3)+' 0 R');
    off[2]=pos; push('2 0 obj\n<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+n+' >>\nendobj\n');
    this.pagesJpg.forEach((jpg,i)=>{
      const p=3+i*3, c=p+1, im=p+2;
      off[p]=pos; push(p+' 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+pw+' '+ph+'] /Resources << /XObject << /Im0 '+im+' 0 R >> >> /Contents '+c+' 0 R >>\nendobj\n');
      const cs='q '+pw+' 0 0 '+ph+' 0 0 cm /Im0 Do Q';
      off[c]=pos; push(c+' 0 obj\n<< /Length '+cs.length+' >>\nstream\n'+cs+'\nendstream\nendobj\n');
      off[im]=pos; push(im+' 0 obj\n<< /Type /XObject /Subtype /Image /Width '+this.W+' /Height '+this.H+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+jpg.length+' >>\nstream\n');
      push(jpg); push('\nendstream\nendobj\n');
    });
    const xref=pos;
    let xs='xref\n0 '+total+'\n0000000000 65535 f \n';
    for(let i=1;i<total;i++) xs+=String(off[i]).padStart(10,'0')+' 00000 n \n';
    push(xs+'trailer\n<< /Size '+total+' /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF');
    return new Blob(parts,{type:'application/pdf'});
  }
}
window.PdfDoc=PdfDoc; window.loadImg=loadImg;
})();
