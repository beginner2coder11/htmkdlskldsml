JAS LAUNDRY ROOM - GOOGLE CLOUD / MANUAL BILLING / CASH CONTROL UPDATE

Included in this ZIP:
- JAS_LAUNDRY_ROOM_FAST_SAVE_CLOUD_SYNC.html: updated application source.
- GOOGLE_CLOUD_APPS_SCRIPT_BACKEND.gs: Google Apps Script Web App backend source.

Implemented in the HTML app:
1. Added Google Cloud URL + Secret Token fields under Owner Settings and new-phone login setup.
2. Added Google Apps Script Web App REST calls: ping, get, save.
3. Local-first save with background upload and 15-second remote polling while the app is open.
4. Added Owner-only Manual Billing with manual bill number, historical billing date, item rows from Price List, payment amount and separate payment received date.
5. Manual bills are stored in the existing bills ledger; billing activity uses the entered billing date and payment activity uses the entered received date.
6. Added Cash Management page for staff cash opening, cash collection, cash expenses, denomination-based closing, Owner opening cash add, partial Owner deposit, and date-filtered closing/deposit slips.
7. Added Owner staff assignment editor for Office/Delivery destination and branch.
8. Existing business data structure and existing bills are retained; no database clear/reset was added.

REQUIRED GOOGLE CLOUD SETUP BEFORE MULTI-PHONE SYNC CAN WORK:
1. Open script.google.com and create a Google Apps Script project.
2. Paste the contents of GOOGLE_CLOUD_APPS_SCRIPT_BACKEND.gs into Code.gs and save.
3. In Project Settings / Script Properties, add JAS_SECRET_TOKEN with a long random secret value (32+ characters). Do not share it publicly.
4. Deploy > New deployment > Web app. Execute as the script owner. Choose the narrowest access setting that works for your managed devices. Authorize Drive access.
5. Copy the deployed Web App URL ending in /exec.
6. In the app, Owner Settings > Google Cloud Connection, enter that URL and the same secret token, then Connect Google Cloud.
7. On each additional phone, open Google Cloud Login Setup on the login screen, enter the same URL and token, save, then log in with an account that has been synced to Cloud.

IMPORTANT LIMITATIONS / TESTING NOTES:
- The Google Apps Script backend is a Drive JSON snapshot service. It is not Firestore, Cloud SQL, or a native Google Cloud Identity login service.
- The app stores the URL and token in that device's localStorage. This is convenient for the requested one-time setup but is not a hardware-backed secret vault. Anyone with access to the unlocked app/browser storage may be able to recover the token.
- Sync uses a single shared snapshot and 15-second polling, not true real-time database subscriptions. Simultaneous edits from two phones can overwrite each other. Avoid editing the same records simultaneously; export a backup before first cloud migration.
- The first Connect asks whether to download existing Cloud data or upload this phone's local data. Choose carefully. A cloud upload replaces the shared snapshot; it does not perform a record-by-record merge.
- The backend requires Apps Script deployment, Drive authorization, URL and token. Those cannot be completed from this ZIP alone.
- Live network access, APK WebView CORS behavior, Apps Script deployment permissions, two-phone login and production data migration have NOT been verified in this environment.
- The source was statically checked for JavaScript syntax and the ZIP was checked for archive integrity. This is not a claim of end-to-end APK/cloud testing.

CASH RULES IN THIS BUILD:
- Expected closing = previous un-deposited closing balance + today's cash payments received by the staff + Owner opening additions - cash expenses attributed to that staff.
- Closing is disabled if counted denomination total is below expected closing. Excess cash is retained as the staff's carry-forward balance.
- Owner deposit is limited to the remaining closing balance. Partial deposits are allowed; undeposited balance carries forward.
- Cash receipt attribution depends on the payment history's receivedById matching the staff ID or login. Older payments without staff attribution may not be allocated to an individual staff member automatically.
