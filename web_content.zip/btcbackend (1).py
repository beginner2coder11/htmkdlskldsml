from flask import Flask, request, jsonify
import time
import uuid

app = Flask(__name__)

# --- State Management (In-memory database) ---
# In a real app, you'd use SQLite or Redis, but for a flash sender demo, 
# simple variables work well until the app restarts.

class BitcoinWallet:
    def __init__(self):
        self.initial_balance = 0.50000000
        self.balance = self.initial_balance
        self.transactions = [] # List of dicts

    def get_balance(self):
        return self.balance

    def refresh_balance(self):
        """Feature 1: Regenerates balance by adding a fixed amount."""
        refresh_amount = 0.05000000
        self.balance += refresh_amount
        
        # Log the internal refresh
        self._add_transaction(
            address="System", 
            amount=refresh_amount, 
            type="in"
        )
        
        return {
            "new_balance": self.balance,
            "amount_added": refresh_amount
        }

    def send_bitcoin(self, address, amount):
        """Feature 2 & 3: Send function with validation."""
        try:
            amount = float(amount)
        except ValueError:
            return {"error": "Invalid amount format"}, 400

        if amount <= 0:
            return {"error": "Amount must be positive"}, 400

        if amount > self.balance:
            return {"error": "Insufficient funds"}, 402

        # Deduct balance
        self.balance -= amount

        # Create transaction record
        tx_id = str(uuid.uuid4())[:8]
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        tx_record = {
            "id": tx_id,
            "address": address,
            "amount": amount,
            "type": "out",
            "timestamp": timestamp,
            "status": "confirmed" # Simulated confirmation
        }
        
        self.transactions.append(tx_record)
        
        # Add the reverse entry to history (optional, but good for UI consistency)
        self._add_transaction(address, -amount, "out")

        return {
            "success": True,
            "tx_id": tx_id,
            "new_balance": self.balance,
            "transaction": tx_record
        }, 200

    def get_history(self):
        """Feature 4: Returns transaction history."""
        # Return last 50 transactions reversed (newest first)
        return self.transactions[::-1][:50]

    def _add_transaction(self, address, amount, type_):
        """Internal helper to log system actions."""
        self.transactions.append({
            "id": str(uuid.uuid4())[:8],
            "address": address,
            "amount": abs(amount),
            "type": type_,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "status": "internal"
        })

# Initialize Wallet
wallet = BitcoinWallet()

# --- API Endpoints ---

@app.route('/api/balance', methods=['GET'])
def get_balance():
    return jsonify({
        "balance": wallet.get_balance(),
        "currency": "BTC"
    })

@app.route('/api/refresh', methods=['POST'])
def refresh_balance_endpoint():
    result = wallet.refresh_balance()
    return jsonify(result)

@app.route('/api/send', methods=['POST'])
def send_bitcoin_endpoint():
    data = request.json
    
    if not data or 'address' not in data or 'amount' not in data:
        return jsonify({"error": "Missing address or amount"}), 400

    address = data['address']
    amount = data['amount']

    response_data, status_code = wallet.send_bitcoin(address, amount)
    
    if status_code == 200:
        return jsonify(response_data)
    else:
        return jsonify(response_data), status_code

@app.route('/api/history', methods=['GET'])
def get_history_endpoint():
    history = wallet.get_history()
    return jsonify(history)

if __name__ == '__main__':
    # Run on local network so the Android device/app can access it
    # Use host='0.0.0.0' if running inside a container or wrapper that needs external access
    app.run(host='0.0.