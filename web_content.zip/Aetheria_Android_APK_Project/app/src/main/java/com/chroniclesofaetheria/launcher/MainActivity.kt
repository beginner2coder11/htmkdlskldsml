package com.chroniclesofaetheria.launcher

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceResponse
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val gameDir by lazy { File(filesDir, "installed-game") }
    private val stagingDir by lazy { File(filesDir, "game-staging") }
    private var webView: WebView? = null

    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importGame(uri)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/", WebViewAssetLoader.InternalStoragePathHandler(this, gameDir))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(0xFF07111F.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(LauncherBridge(), "AndroidLauncher")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                    assetLoader.shouldInterceptRequest(request.url)
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (url == LAUNCHER_URL) {
                        val manifest = installedManifest()
                        val message = if (manifest != null) "INSTALLED · Aetheria v${manifest.optString("version", "unknown")}\nYour game is ready to play." else "No game loaded yet.\nChoose an Aetheria game ZIP to import it into this launcher."
                        notifyPage(true, message, manifest != null)
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val host = request.url.host
                    return host != "appassets.androidplatform.net"
                }
            }
            loadUrl(LAUNCHER_URL)
        }
        setContentView(webView)
    }

    inner class LauncherBridge {
        @JavascriptInterface fun pickGameZip() { runOnUiThread { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) } }
        @JavascriptInterface fun launchGame() { runOnUiThread { if (installedManifest() != null) webView?.loadUrl(GAME_URL) else notifyPage(false, "Load a valid Aetheria ZIP first.", false) } }
        @JavascriptInterface fun removeGame() { runOnUiThread { android.app.AlertDialog.Builder(this@MainActivity).setTitle("Remove installed game?").setMessage("This removes game files. Player saves are stored separately.").setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ -> gameDir.deleteRecursively(); webView?.loadUrl(LAUNCHER_URL); notifyPage(true, "Game removed.\nChoose an Aetheria game ZIP to import.", false) }.show() } }
    }

    private fun importGame(uri: Uri) {
        notifyPage(false, "IMPORTING GAME…\nChecking package and extracting files.", installedManifest() != null)
        scope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { installZip(uri) } }
            result.onSuccess { version ->
                notifyPage(true, "INSTALLED · Aetheria v$version\nYour game is ready to play.", true)
                Toast.makeText(this@MainActivity, "Aetheria installed", Toast.LENGTH_SHORT).show()
            }.onFailure { error ->
                notifyPage(false, "IMPORT FAILED\n${error.message ?: "The ZIP could not be installed."}", installedManifest() != null)
            }
        }
    }

    private fun installZip(uri: Uri): String {
        stagingDir.deleteRecursively(); stagingDir.mkdirs()
        var expanded = 0L; var entries = 0
        contentResolver.openInputStream(uri)?.use { input -> ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries++; require(entries <= MAX_ENTRIES) { "ZIP contains too many files." }
                val name = entry.name.replace('\\', '/')
                require(name.isNotBlank() && !name.startsWith("/") && !name.split('/').contains("..")) { "Unsafe ZIP path: $name" }
                val out = File(stagingDir, name).canonicalFile
                require(out.path.startsWith(stagingDir.canonicalPath + File.separator)) { "Invalid ZIP destination." }
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { sink ->
                        val buffer = ByteArray(65536)
                        while (true) { val count = zip.read(buffer); if (count < 0) break; expanded += count; require(expanded <= MAX_EXPANDED_BYTES) { "Expanded ZIP exceeds 600 MB." }; sink.write(buffer, 0, count) }
                    }
                }
                zip.closeEntry()
            }
        } } ?: error("Unable to open the selected ZIP.")

        // Accept GitHub's artifact ZIP containing exactly one inner game ZIP.
        if (!File(stagingDir, "manifest.json").isFile) {
            val nested = stagingDir.walkTopDown().filter { it.isFile && it.extension.equals("zip", true) }.toList()
            require(nested.size == 1) { "manifest.json is missing. If this is a GitHub artifact, it must contain exactly one game ZIP." }
            val nestedZip = nested.single()
            val nestedStage = File(filesDir, "nested-staging").apply { deleteRecursively(); mkdirs() }
            ZipInputStream(FileInputStream(nestedZip)).use { zip ->
                var count = 0; var size = 0L
                while (true) { val e = zip.nextEntry ?: break; count++; require(count <= MAX_ENTRIES) { "Nested ZIP has too many files." }; val n=e.name.replace('\\','/'); require(n.isNotBlank()&&!n.startsWith("/")&&!n.split('/').contains("..")) { "Unsafe nested ZIP path." }; val out=File(nestedStage,n).canonicalFile; require(out.path.startsWith(nestedStage.canonicalPath+File.separator)); if(e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); FileOutputStream(out).use { sink -> val b=ByteArray(65536); while(true){val c=zip.read(b);if(c<0)break;size+=c;require(size<=MAX_EXPANDED_BYTES){"Nested game exceeds 600 MB."};sink.write(b,0,c)} } }; zip.closeEntry() }
            }
            stagingDir.deleteRecursively(); require(nestedStage.renameTo(stagingDir)) { "Could not unpack inner game ZIP." }
        }

        val manifestFile = File(stagingDir, "manifest.json")
        val manifest = JSONObject(manifestFile.readText())
        require(manifest.optInt("packageFormat") == PACKAGE_FORMAT) { "Unsupported Aetheria package format." }
        require(manifest.optString("gameId") == GAME_ID) { "This ZIP is not an Aetheria game package." }
        val entry = manifest.optString("entryPoint", "index.html")
        require(entry == "index.html" && File(stagingDir, entry).isFile) { "Game index.html is missing." }
        val checksums = manifest.optJSONObject("checksums") ?: error("Package checksums are missing.")
        val keys = checksums.keys(); var checked = 0
        while (keys.hasNext()) {
            val relative = keys.next(); if (relative == "manifest.json") continue
            val file = File(stagingDir, relative).canonicalFile
            require(file.path.startsWith(stagingDir.canonicalPath + File.separator) && file.isFile) { "Required game file missing: $relative" }
            require(sha256(file) == checksums.getString(relative)) { "Integrity check failed: $relative" }; checked++
        }
        require(checked > 0) { "No package files were verified." }
        val backup = File(filesDir, "previous-game").apply { deleteRecursively() }
        if (gameDir.exists()) check(gameDir.renameTo(backup)) { "Could not stage existing installation." }
        if (!stagingDir.renameTo(gameDir)) { if (backup.exists()) backup.renameTo(gameDir); error("Could not activate new installation.") }
        backup.deleteRecursively()
        return manifest.optString("version", "unknown")
    }

    private fun installedManifest(): JSONObject? = runCatching { JSONObject(File(gameDir, "manifest.json").readText()) }.getOrNull()?.takeIf {
        it.optString("gameId") == GAME_ID && it.optInt("packageFormat") == PACKAGE_FORMAT && File(gameDir, it.optString("entryPoint", "index.html")).isFile
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input -> val buffer=ByteArray(65536); while(true){val n=input.read(buffer);if(n<0)break;digest.update(buffer,0,n)} }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun notifyPage(ok: Boolean, message: String, installed: Boolean) {
        val safe = JSONObject.quote(message)
        runOnUiThread { webView?.evaluateJavascript("window.nativeImportFinished(${if(ok) "true" else "false"},$safe,${if(installed) "true" else "false"})", null) }
    }

    override fun onBackPressed() {
        if (webView?.url == GAME_URL) webView?.loadUrl(LAUNCHER_URL) else super.onBackPressed()
    }
    override fun onDestroy() { scope.cancel(); webView?.destroy(); super.onDestroy() }

    companion object {
        private const val GAME_ID = "com.chroniclesofaetheria.game"
        private const val PACKAGE_FORMAT = 1
        private const val MAX_ENTRIES = 12000
        private const val MAX_EXPANDED_BYTES = 600L * 1024L * 1024L
        private const val LAUNCHER_URL = "https://appassets.androidplatform.net/assets/launcher/index.html"
        private const val GAME_URL = "https://appassets.androidplatform.net/index.html"
    }
}
