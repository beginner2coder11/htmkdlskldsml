# Aetheria Launcher — Android APK Project

This is an Android Studio project that wraps the Aetheria launcher UI in a native Android WebView and adds Android-native ZIP import/install support.

## Included capabilities
- Launcher interface based on the latest Aetheria Launcher HTML (v0.4 design and controls).
- Native Android document picker using the Storage Access Framework (`ACTION_OPEN_DOCUMENT` via `ActivityResultContracts.OpenDocument`). No broad storage permission is requested.
- Accepts either the inner `chronicles-of-aetheria-launcher.zip` package or a GitHub artifact ZIP containing exactly one inner game ZIP.
- Extracts into app-private storage, rejects unsafe paths and oversized archives, validates `manifest.json`, game ID, entry point and SHA-256 checksums.
- Keeps game files in app-private storage and launches them from a stable HTTPS-like local origin using AndroidX `WebViewAssetLoader`, so module imports and root-relative `/assets/...` paths can resolve normally.
- Internet permission is declared for online services and remote resources. The game itself must bundle dependencies/assets if offline play is required.
- Player save data is not intentionally deleted when replacing/removing game files; however, save compatibility is still determined by Aetheria's own save implementation.

## Build an APK
1. On a computer, install Android Studio (current stable), Android SDK Platform 35, and JDK 17.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the extracted `Aetheria_Android_APK_Project` folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show a link to the generated debug APK. The usual output is `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This ZIP is the Android Studio project source, **not a prebuilt APK**. It has not been compiled or tested on a physical Android device in this environment.
- Android Studio is a desktop IDE; it is not a normal Android-phone app. If you only have your phone, this project can be built using a cloud Android build service/CI, but that requires a separate setup.
- Imported game ZIPs must follow the launcher package contract: root `manifest.json`, root `index.html`, `packageFormat: 1`, `gameId: com.chroniclesofaetheria.game`, and SHA-256 checksums for packaged files.
- Checksums detect corruption; they do not prove a package is trustworthy.
- Internet permission is enabled, but network access is not guaranteed if a device is offline or a remote service is unavailable.
