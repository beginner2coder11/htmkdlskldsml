from flask import Flask, request, jsonify
import stripe

# Initialize Stripe
# You can get a Test Key here: https://dashboard.stripe.com/test/apikeys
stripe.api_key = "sk_test_54NvJ4u...YOUR_TEST_KEY..." 

app = Flask(__name__)

@app.route('/check', methods=['POST'])
def check_card():
    data = request.get_json()
    cc_number = data.get('number')
    exp_month = data.get('exp').split('/')[0]
    exp_year = data.get('exp').split('/')[1]
    cvv = data.get('cvv')

    try:
        # We create a PaymentMethod to see if the card is valid.
        # To get a real balance, you usually need a specific Gateway 
        # that supports "Balance Inquiry".
        
        payment_method = stripe.PaymentMethod.create(
            type='card',
            card={
                'number': cc_number,
                'exp_month': int(exp_month),
                'exp_year': int(exp_year),
                'cvc': cvv,
            },
        )

        # If we got here, the card format is valid.
        # In a real scenario, you charge $0.00 to check balance, 
        # or use a gateway specifically for "Bin Checks".
        
        return jsonify({
            "status": "approved",
            "message": "Card is Valid",
            "balance": "0.00", # Placeholder - Real balance requires specific billing integration
            "type": payment_method.card.brand.upper()
        })

    except stripe.error.CardError as e:
        # This is where declined cards go
        body = e.json_body
        err  = body.get('error', {})
        return jsonify({
            "status": "declined",
            "message": err.get('message', "Declined")
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    # Run on 0.0.0.0 so your phone can access it via Wi-Fi
    app.run(host='0.0.0.0', port=5000)