# Job titles and Department View fix (2026-10-14)

This cumulative source updates both `hrsettings/app.js` and the Android WebView copy at `android-wrapper/app/src/main/assets/public/app.js` to the same current version.

- Food & Beverage dropdown: Assistant F&B Manager, Restaurant Manager, Supervisor, Cashier, Barman, Barista, Waiter/ Waitress, Events Manager, Bqt Coordinator, Driver, Store.
- Kitchen dropdown: Executive Chef, Acting Executive Chef, Sous Chef, Acting Sous Chef, Chef de Partie, Cook, Pastry Cook, Cold Kitchen, Cook Staff, Chief Steward, Steward.
- For other departments, the list also includes the requested titles so the generic Manager/Assistant Manager options are not the only visible choices.
- Department View is in the navigation and Dashboard Quick actions.
- Persistent local sign-in remains enabled until manual Sign out.
- Cache-busting was added to the app.js script reference to help avoid stale preview assets.

After replacing the project files, rebuild/reload the preview or APK. An already installed/built app does not update just because a ZIP was downloaded.
