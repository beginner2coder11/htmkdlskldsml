// Never-Ending Story Engine
// Maintains continuity via localStorage, generates consistent narrative + SVG + ambient audio

const STORAGE_KEY = 'neverending_story_v1';

let state = {
  history: [],
  entities: { characters: [], locations: [], items: [], facts: [] },
  currentScene: { location: 'the threshold', mood: 'mysterious', time: 'dusk' },
  paragraphCount: 0,
  lastImageKeywords: []
};

let audioCtx = null;
let oscillators = [];
let gainNodes = [];
let musicPlaying = false;

// Load or initialize
function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      state = JSON.parse(saved);
    }
  } catch (e) {}
  if (state.history.length === 0) {
    // Seed the very first opening
    const opening = "You stand at the edge of something that has no edge. The air tastes of rain that has not yet fallen, and a single light flickers in the distance, not quite inviting and not quite warning. Somewhere behind you, the path you came from has already forgotten your name.";
    state.history.push(opening);
    state.entities.locations.push({ name: 'the threshold', description: 'a place between places' });
    state.currentScene.location = 'the threshold';
    state.paragraphCount = 1;
    saveState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function addEntity(type, name, description = '') {
  const list = state.entities[type];
  if (!list.find(e => e.name.toLowerCase() === name.toLowerCase())) {
    list.push({ name, description });
    // Keep lists from growing forever
    if (list.length > 12) list.shift();
  }
}

function extractAndRemember(text) {
  // Simple pattern matching to pull out potential new entities without contradiction
  const charMatch = text.match(/(?:named|called|the)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/);
  if (charMatch && Math.random() > 0.6) {
    addEntity('characters', charMatch[1], 'appeared in the story');
  }
  const locMatch = text.match(/(?:in|at|through|into)\s+(?:the\s+)?([A-Za-z\s]+?)(?:\.|,|$)/i);
  if (locMatch && locMatch[1].length < 40) {
    addEntity('locations', locMatch[1].trim(), 'visited');
  }
}

function generateNextChunk() {
  const loc = state.currentScene.location;
  const mood = state.currentScene.mood;
  const chars = state.entities.characters.slice(-3).map(c => c.name);
  const locs = state.entities.locations.slice(-3).map(l => l.name);
  const facts = state.entities.facts.slice(-2);

  // Templates that always reference existing state
  const templates = [
    () => `In ${loc}, the ${mood} silence stretches. ${chars.length ? chars[0] + ' watches, unmoving.' : 'Nothing moves.'} A sound rises—not quite a voice, not quite wind—and then falls again, leaving the air thinner than before.`,
    () => `The path through ${locs.length > 1 ? locs[1] : loc} curves without warning. You notice ${chars.length > 1 ? chars[1] + ' has left something behind: ' : ''}a small object that catches what little light remains. It was not there a moment ago. Or perhaps it was, and you only now have the eyes to see it.`,
    () => `Time in ${loc} does not behave. What felt like minutes may have been hours. ${facts.length ? facts[0] + ' ' : ''}You remember this, or something like it, from a dream that belonged to someone else.`,
    () => `${chars.length ? chars[Math.floor(Math.random()*chars.length)] + ' speaks without moving their mouth. The words arrive directly.' : 'A thought arrives that is not yours:'} "${generateWhisper()}". The ${mood} feeling deepens, settling into your bones like cold.`,
    () => `You leave ${loc} behind, though the place does not leave you. Ahead, ${generateNewLocation()} waits. The air changes. Something in the story has shifted, but nothing that came before has been undone.`
  ];

  let text = templates[Math.floor(Math.random() * templates.length)]();

  // Occasionally introduce a new consistent fact
  if (Math.random() > 0.7) {
    const newFact = generateFact();
    state.entities.facts.push(newFact);
    if (state.entities.facts.length > 8) state.entities.facts.shift();
    text += ' ' + newFact;
  }

  // Update scene occasionally
  if (Math.random() > 0.65) {
    state.currentScene.location = generateNewLocation();
    state.currentScene.mood = pickMood();
  }

  extractAndRemember(text);
  state.history.push(text);
  state.paragraphCount++;
  if (state.history.length > 40) state.history = state.history.slice(-30); // keep recent
  saveState();
  return text;
}

function generateWhisper() {
  const whispers = [
    "Do not look back",
    "It remembers you",
    "The door was never locked",
    "You have been here longer than you think",
    "Someone is waiting who does not know your face",
    "The light is not what it seems"
  ];
  return whispers[Math.floor(Math.random() * whispers.length)];
}

function generateNewLocation() {
  const bases = ['the hollow', 'the glass tower', 'the drowned library', 'the red orchard', 'the quiet station', 'the bone market', 'the unfinished bridge', 'the mirror garden', 'the last lighthouse', 'the paper city'];
  const adj = ['forgotten', 'shifting', 'silent', 'burning', 'submerged', 'half-built', 'echoing'];
  return adj[Math.floor(Math.random()*adj.length)] + ' ' + bases[Math.floor(Math.random()*bases.length)];
}

function pickMood() {
  const moods = ['tense', 'melancholy', 'uneasy', 'wondrous', 'ominous', 'still', 'charged', 'fragile'];
  return moods[Math.floor(Math.random() * moods.length)];
}

function generateFact() {
  const facts = [
    "The characters who appear more than once never change their essential nature.",
    "Locations, once named, retain the properties first given to them.",
    "Nothing introduced earlier is later denied.",
    "The story prefers to deepen rather than reverse."
  ];
  return facts[Math.floor(Math.random() * facts.length)];
}

// SVG image generation — simple, atmospheric, free
function generateSVG(text) {
  const mood = state.currentScene.mood;
  const colors = {
    tense: ['#1a1a2e', '#16213e', '#0f3460', '#e94560'],
    melancholy: ['#2c3e50', '#34495e', '#7f8c8d', '#bdc3c7'],
    uneasy: ['#1e1e1e', '#2d2d2d', '#8b4513', '#cd853f'],
    wondrous: ['#0c1445', '#1b3a4b', '#4a6fa5', '#f0e6d2'],
    ominous: ['#0d0d0d', '#1a1a1a', '#4a0000', '#8b0000'],
    still: ['#1a2332', '#2c3e50', '#95a5a6', '#ecf0f1'],
    charged: ['#1a0a2e', '#3d1a5c', '#7b2cbf', '#ff6b9d'],
    fragile: ['#2d3436', '#636e72', '#dfe6e9', '#fab1a0']
  };
  const pal = colors[mood] || colors.uneasy;
  const shapes = [];
  const n = 3 + Math.floor(Math.random() * 4);
  for (let i = 0; i < n; i++) {
    const x = 40 + Math.random() * 320;
    const y = 40 + Math.random() * 180;
    const r = 20 + Math.random() * 60;
    const op = 0.15 + Math.random() * 0.4;
    shapes.push(`<circle cx="${x}" cy="${y}" r="${r}" fill="${pal[i % pal.length]}" opacity="${op}"/>`);
  }
  // Add a simple horizon or structure
  shapes.push(`<rect x="0" y="160" width="400" height="40" fill="${pal[0]}" opacity="0.6"/>`);
  if (Math.random() > 0.5) {
    shapes.push(`<polygon points="200,60 160,140 240,140" fill="${pal[2]}" opacity="0.3"/>`);
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200" width="100%" height="auto">
    <rect width="400" height="200" fill="${pal[0]}"/>
    ${shapes.join('\n    ')}
    <text x="20" y="190" fill="${pal[3]}" font-family="serif" font-size="11" opacity="0.7">${state.currentScene.location.slice(0, 28)}</text>
  </svg>`;
}

// Ambient music via Web Audio API
function initAudio() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
}

function startMusic() {
  if (!audioCtx) initAudio();
  if (musicPlaying) return;
  musicPlaying = true;
  stopMusic(false);

  const mood = state.currentScene.mood;
  const baseFreqs = {
    tense: [55, 82.4, 110],
    melancholy: [49, 73.4, 98],
    uneasy: [58.3, 87.3, 116.5],
    wondrous: [65.4, 98, 130.8],
    ominous: [41.2, 61.7, 82.4],
    still: [52, 78, 104],
    charged: [61.7, 92.5, 123.5],
    fragile: [55, 82.4, 110]
  };
  const freqs = baseFreqs[mood] || baseFreqs.uneasy;

  freqs.forEach((f, i) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = i === 0 ? 'sine' : 'triangle';
    osc.frequency.value = f;
    gain.gain.value = 0.04 - i * 0.008;
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    oscillators.push(osc);
    gainNodes.push(gain);
  });

  // Slow filter sweep for drama
  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 400;
  // Reconnect with filter if desired (simplified for reliability)
}

function stopMusic(full = true) {
  oscillators.forEach(o => { try { o.stop(); } catch(e){} });
  oscillators = [];
  gainNodes = [];
  if (full) musicPlaying = false;
}

function updateMusic() {
  if (musicPlaying) {
    stopMusic(false);
    startMusic();
  }
}

// UI
function render() {
  const container = document.getElementById('story-container');
  container.innerHTML = '';

  // Show last image + recent history
  const recent = state.history.slice(-6);
  const svg = generateSVG(recent[recent.length-1] || '');
  const imgDiv = document.createElement('div');
  imgDiv.innerHTML = svg;
  imgDiv.className = 'scene-image';
  container.appendChild(imgDiv);

  recent.forEach((chunk, i) => {
    const p = document.createElement('p');
    p.className = 'story-chunk';
    p.textContent = chunk;
    container.appendChild(p);
  });

  document.getElementById('status').innerHTML = 
    `<span class="mood-indicator" style="background:${moodColor()}"></span> ${state.currentScene.mood} · ${state.currentScene.location} · ${state.paragraphCount} beats`;

  // Auto-scroll
  window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
}

function moodColor() {
  const map = { tense: '#e94560', melancholy: '#7f8c8d', uneasy: '#cd853f', wondrous: '#4a6fa5', ominous: '#8b0000', still: '#95a5a6', charged: '#7b2cbf', fragile: '#fab1a0' };
  return map[state.currentScene.mood] || '#c9a87c';
}

document.getElementById('continue-btn').addEventListener('click', () => {
  const btn = document.getElementById('continue-btn');
  btn.disabled = true;
  btn.textContent = '…';
  setTimeout(() => {
    generateNextChunk();
    render();
    updateMusic();
    btn.disabled = false;
    btn.textContent = 'Continue';
  }, 400);
});

document.getElementById('pause-btn').addEventListener('click', () => {
  if (musicPlaying) {
    stopMusic();
    document.getElementById('pause-btn').textContent = 'Resume Music';
  } else {
    startMusic();
    document.getElementById('pause-btn').textContent = 'Pause Music';
  }
});

// Init
loadState();
render();
// Start music on first interaction (browser policy)
document.body.addEventListener('click', () => {
  if (!musicPlaying) startMusic();
}, { once: true });
