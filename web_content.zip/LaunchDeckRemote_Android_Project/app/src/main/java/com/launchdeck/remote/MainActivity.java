package com.launchdeck.remote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new NativeBridge(), "LaunchDeckNative");
        web.setBackgroundColor(0xFF0B1020);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private final class NativeBridge {
        @JavascriptInterface public String openBluetoothSettings() {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
                return "OK";
            } catch (Exception e) { return "Unable to open Bluetooth settings"; }
        }

        @JavascriptInterface public String connectSSH(String host, String username, String password) {
            try {
                String output = runSSH(host, username, password, "echo LAUNCHDECK_OK");
                return output.contains("LAUNCHDECK_OK") ? "OK" : "SSH connected, but Windows did not confirm the test command";
            } catch (Exception e) { return friendlyError(e); }
        }

        @JavascriptInterface public String launchApp(String host, String username, String password, String app) {
            String command;
            switch (app) {
                case "browser": command = "Start-Process 'msedge'"; break;
                case "media": command = "Start-Process 'wmplayer'"; break;
                case "games": command = "Start-Process 'steam://open/main'"; break;
                case "files": command = "Start-Process 'explorer.exe'"; break;
                case "tools": command = "Start-Process 'ms-settings:'"; break;
                case "custom": return "Custom app launch is not configured yet. Add a trusted app path in a future version.";
                default: return "Unknown app shortcut";
            }
            try {
                runSSH(host, username, password, "powershell.exe -NoProfile -NonInteractive -Command \"" + command + "\"");
                return "OK";
            } catch (Exception e) { return friendlyError(e); }
        }
    }

    private String runSSH(String host, String username, String password, String command) throws Exception {
        if (host == null || host.trim().isEmpty() || host.contains(" ") || host.contains("/") || host.contains(":"))
            throw new Exception("Enter the PC's local IP address only, such as 192.168.1.100");
        if (username == null || username.trim().isEmpty()) throw new Exception("Windows username is required");
        JSch jsch = new JSch();
        Session session = jsch.getSession(username.trim(), host.trim(), 22);
        session.setPassword(password);
        Properties config = new Properties();
        // Password is sent only inside the encrypted SSH session. Host-key checking is disabled in this prototype;
        // use only a trusted home network until host-key verification is added.
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "password,keyboard-interactive");
        session.setConfig(config);
        session.connect(9000);
        try {
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            ByteArrayOutputStream stdout = new ByteArrayOutputStream();
            ByteArrayOutputStream stderr = new ByteArrayOutputStream();
            channel.setCommand(command);
            channel.setOutputStream(stdout);
            channel.setErrStream(stderr);
            channel.connect(7000);
            long deadline = System.currentTimeMillis() + 10000;
            while (!channel.isClosed() && System.currentTimeMillis() < deadline) Thread.sleep(100);
            if (!channel.isClosed()) { channel.disconnect(); throw new Exception("Windows command timed out"); }
            int exit = channel.getExitStatus();
            String out = stdout.toString(StandardCharsets.UTF_8.name());
            String err = stderr.toString(StandardCharsets.UTF_8.name());
            channel.disconnect();
            if (exit != 0 && !out.contains("LAUNCHDECK_OK")) throw new Exception(err.isEmpty() ? "Windows SSH command failed (exit " + exit + ")" : err.trim());
            return out + "\n" + err;
        } finally { session.disconnect(); }
    }

    private String friendlyError(Exception e) {
        String message = e.getMessage();
        if (message == null || message.trim().isEmpty()) return "Connection failed. Check Windows OpenSSH Server and network settings.";
        String m = message.toLowerCase();
        if (m.contains("auth fail") || m.contains("authentication")) return "Windows rejected the login. Check username/password and SSH password authentication.";
        if (m.contains("timeout") || m.contains("connect timed out")) return "Connection timed out. Check the PC IP, same Wi-Fi network, firewall, and OpenSSH Server.";
        if (m.contains("refused")) return "Windows refused the connection. Start the OpenSSH SSH Server service and allow TCP port 22.";
        return message.length() > 180 ? message.substring(0, 180) : message;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
