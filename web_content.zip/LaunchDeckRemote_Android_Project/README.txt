LaunchDeck Remote — Android Studio source project

WHAT THIS VERSION DOES\n- Shows only the PC IP address field; username and password fields are removed from the interface.
- Runs as an installed Android app (the interface is bundled locally; it is not a web-hosted page).
- Connects to Windows over your local Wi-Fi using Windows' built-in OpenSSH Server.
- Provides quick launch commands for Microsoft Edge, Windows Media Player, Steam, File Explorer, and Windows Settings.
- Opens Android Bluetooth settings so you can pair devices.
- Does not require a separate LaunchDeck PC companion program.

IMPORTANT LIMITATIONS
- Wi-Fi/SSH is the command path for launching Windows programs. Bluetooth pairing by itself cannot make Windows execute app-launch commands. Bluetooth app launching would require a PC-side receiver/service, which this no-companion version intentionally does not install.
- This is Android source code, NOT a compiled APK. Build it with Android Studio.
- The SSH prototype currently disables host-key verification. Use only on a trusted private network; do not use on public Wi-Fi. A production release should add host-key fingerprint verification and a safer credential-storage flow.
- Windows GUI applications may not appear in the logged-in desktop session on every Windows/OpenSSH configuration. Test with the specific Windows account and session before relying on it.
- The Custom app tile is a placeholder; arbitrary custom paths are not enabled.

WINDOWS SETUP (ONE TIME; BUILT-IN WINDOWS FEATURE, NOT A LAUNCHDECK COMPANION)
1. On Windows, open Settings > System > Optional features > View features.
2. Install “OpenSSH Server” if it is not installed.
3. Open PowerShell as Administrator and run:
     Start-Service sshd
     Set-Service -Name sshd -StartupType Automatic
4. Ensure Windows Firewall allows the built-in OpenSSH Server (TCP port 22) on your private network only.
5. Find the PC's local IPv4 address with `ipconfig`.
6. Keep the phone and PC on the same trusted Wi-Fi network.
7. In LaunchDeck, enter the PC IPv4 address. IMPORTANT: the IP-only interface is a UI update; password-free SSH key authentication is not yet implemented, so connecting/launching will show a setup notice rather than connect.

SECURITY NOTES
- Do not expose port 22 to the public internet or configure router port forwarding for this app.
- Use a strong Windows account password and a private network.
- This prototype sends credentials through an encrypted SSH connection but does not yet pin the PC's SSH host key.

BUILD APK
1. Install Android Studio: https://developer.android.com/studio
2. Open this extracted project folder in Android Studio.
3. Allow Gradle sync; an internet connection is needed to fetch the JSch dependency.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually created at app/build/outputs/apk/debug/app-debug.apk.
