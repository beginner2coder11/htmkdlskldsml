package br.com.nossomercadao.terminalalternativo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;

public class MainActivity extends ComponentActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private SharedPreferences prefs;
    private boolean pageReady, scannerBusy;
    private String queuedStatus;
    private TextToSpeech tts;
    private boolean ttsReady;
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(new ScanContract(), result -> {
        scannerBusy = false;
        if (result.getContents() != null && result.getContents().matches("[0-9]{1,64}")) {
            prefs.edit().putString("pendingBarcode", result.getContents()).commit(); deliverBarcode();
        } else status(result.getContents() == null ? "Leitura cancelada." : "Código de barras não numérico.");
    });
    private final ActivityResultLauncher<String> permission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
        if (granted) launchScanner();
        else { scannerBusy = false; status("Câmera não autorizada. Libere a permissão nas configurações do aplicativo ou digite o código."); }
    });
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("terminal_alternativo", MODE_PRIVATE);
        if (state != null) scannerBusy = state.getBoolean("scannerBusy");
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom()); return insets;
        });
        setContentView(root); root.requestApplyInsets();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new Bridge(), "InventoryAndroid");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse resource = loader.shouldInterceptRequest(request.getUrl());
                if (resource != null) return resource;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return !HOME.equals(request.getUrl().toString()); }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) { pageReady = false; }
            @Override public void onPageFinished(WebView view, String url) {
                if (!HOME.equals(url)) return;
                pageReady = true; deliverBarcode();
                if (queuedStatus != null) { String text = queuedStatus; queuedStatus = null; status(text); }
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){var e=document.getElementById('settings');if(e.style.display==='block'){e.style.display='none';return true;}return false;})()", result -> {
                    if (!"true".equals(result)) new AlertDialog.Builder(MainActivity.this).setMessage("Fechar o terminal de consulta?")
                        .setPositiveButton("Fechar", (d,w) -> finish()).setNegativeButton("Continuar", null).show();
                });
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Confirmar", (d,w) -> result.confirm())
                    .setNegativeButton("Cancelar", (d,w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show(); return true;
            }
        });
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS && tts != null) {
                int available = tts.setLanguage(new Locale("pt", "BR"));
                ttsReady = available != TextToSpeech.LANG_MISSING_DATA && available != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        web.loadUrl(HOME);
    }
    private void status(String text) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (!pageReady) { queuedStatus = text; return; }
            web.evaluateJavascript("window.onNativeStatus&&window.onNativeStatus(" + JSONObject.quote(text) + ");", null);
        });
    }
    private void deliverBarcode() {
        if (!pageReady) return;
        String code = prefs.getString("pendingBarcode", null);
        if (code != null) web.evaluateJavascript("(function(){if(typeof window.onBarcodeScanned!=='function')return false;window.onBarcodeScanned("+JSONObject.quote(code)+");return true;})()", result -> {
            if ("true".equals(result)) prefs.edit().remove("pendingBarcode").apply();
        });
    }
    private void launchScanner() {
        try {
            ScanOptions options = new ScanOptions(); options.setCaptureActivity(ScannerActivity.class);
            options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
            options.setPrompt("Aponte para o código de barras"); options.setBeepEnabled(true);
            options.setOrientationLocked(false); options.setBarcodeImageEnabled(false); scanner.launch(options);
        } catch (Exception e) { scannerBusy = false; status("Falha ao abrir scanner: "+e.getMessage()); }
    }
    private boolean localHost(String host) {
        if (host == null) return false;
        String[] parts = host.split("\\.", -1); if (parts.length != 4) return false;
        int[] n = new int[4];
        for (int i=0; i<4; i++) {
            if (!parts[i].matches("[0-9]{1,3}") || (parts[i].length()>1 && parts[i].charAt(0)=='0')) return false;
            n[i]=Integer.parseInt(parts[i]); if (n[i]>255) return false;
        }
        return n[0]==10 || (n[0]==192 && n[1]==168) || (n[0]==172 && n[1]>=16 && n[1]<=31);
    }
    private void terminalResponse(String id, boolean success, String text) {
        runOnUiThread(() -> {
            if (!pageReady || isFinishing() || isDestroyed()) return;
            web.evaluateJavascript("window.onTerminalResponse&&window.onTerminalResponse("+JSONObject.quote(id)+","+success+","+JSONObject.quote(text)+");", null);
        });
    }
    private String message(String template, String code, String name) {
        String text = template.replace("{codigo}", code).replace("{terminal}", name);
        return text.replace("\\r", "\r").replace("\\n", "\n").replace("\\t", "\t");
    }
    private String readReply(Socket socket, Charset charset) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        long deadline = System.nanoTime() + 7000000000L;
        while (System.nanoTime() < deadline) {
            try {
                int count = socket.getInputStream().read(buffer);
                if (count < 0) break;
                output.write(buffer, 0, count);
                if (output.size() > 1048576) throw new IllegalStateException("Resposta muito grande");
                boolean line = false;
                for (int i=0;i<count;i++) if (buffer[i]=='\n') line=true;
                if (line) break;
                socket.setSoTimeout(700);
            } catch (SocketTimeoutException e) {
                if (output.size() > 0) break;
            }
        }
        if (output.size()==0) throw new IllegalStateException("Serviço não respondeu à mensagem. Confira o protocolo.");
        return new String(output.toByteArray(), charset);
    }
    private String http(JSONObject c, String code) throws Exception {
        String path = c.optString("url");
        if (!path.startsWith("/") || path.startsWith("//") || !path.contains("{codigo}") || path.indexOf('\r')>=0 || path.indexOf('\n')>=0)
            throw new IllegalArgumentException("Configure uma URL local iniciada por / com {codigo}.");
        path=path.replace("{codigo}", code);
        HttpURLConnection connection=(HttpURLConnection)new URL("http", c.getString("serverIp"), Integer.parseInt(c.getString("port")), path).openConnection(Proxy.NO_PROXY);
        try {
            connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(4000); connection.setReadTimeout(7000);
            connection.setUseCaches(false); connection.setRequestProperty("Accept","application/json");
            int status=connection.getResponseCode();
            if (status<200 || status>=300) throw new IllegalStateException("Serviço retornou HTTP "+status);
            try (InputStream input=connection.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] b=new byte[4096]; int count;
                while((count=input.read(b))!=-1){out.write(b,0,count);if(out.size()>1048576)throw new IllegalStateException("Resposta muito grande");}
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { connection.disconnect(); }
    }
    public class Bridge {
        @JavascriptInterface public String loadConfig() { return prefs.getString("server", ""); }
        @JavascriptInterface public boolean saveConfig(String json) {
            try {
                JSONObject c = new JSONObject(json); int port = Integer.parseInt(c.getString("port"));
                if ((!c.optString("serverIp").isEmpty() && !localHost(c.getString("serverIp"))) || port<1 || port>65535) return false;
                return prefs.edit().putString("server", c.toString()).commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void openWifi() { runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS))); }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> { if(ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preco"); else status("Voz em português indisponível no aparelho."); });
        }
        @JavascriptInterface public void queryTerminal(String config, String code, String id, boolean test) {
            io.execute(() -> {
                try {
                    JSONObject c=new JSONObject(config);
                    String host=c.getString("serverIp"), mode=c.optString("mode"), name=c.optString("terminalName");
                    int port=Integer.parseInt(c.getString("port"));
                    if(!localHost(host)||port<1||port>65535||!id.matches("[0-9]{1,12}"))throw new IllegalArgumentException("IP local ou porta inválidos.");
                    if(!test&&!code.matches("[0-9]{1,64}"))throw new IllegalArgumentException("Código inválido.");
                    if(!test&&"http".equals(mode)){terminalResponse(id,true,http(c,code));return;}
                    if(!"tcp".equals(mode)&&!test)throw new IllegalArgumentException("Modo de comunicação inválido.");
                    try(Socket socket=new Socket()){
                        socket.connect(new InetSocketAddress(host,port),4000); socket.setSoTimeout(1000);
                        if(test){terminalResponse(id,true,"");return;}
                        Charset charset=Charset.forName("windows-1252");
                        if(c.optBoolean("waitGreeting")){
                            byte[] initial=new byte[4096];
                            int received=socket.getInputStream().read(initial);
                            if(received<0)throw new IllegalStateException("Serviço encerrou a conexão inicial.");
                            String reply=c.optString("greetingReply");
                            if(!reply.isEmpty()){socket.getOutputStream().write(message(reply,code,name).getBytes(charset));socket.getOutputStream().flush();}
                        }
                        String template=c.optString("requestTemplate");
                        if(!template.contains("{codigo}"))throw new IllegalArgumentException("Mensagem TCP deve conter {codigo}.");
                        socket.getOutputStream().write(message(template,code,name).getBytes(charset));socket.getOutputStream().flush();
                        terminalResponse(id,true,readReply(socket,charset));
                    }
                } catch(Exception e){terminalResponse(id,false,"Falha na consulta local: "+e.getMessage());}
            });
        }
        @JavascriptInterface public void startScan() {
            runOnUiThread(() -> {
                if (scannerBusy) return; scannerBusy=true;
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) launchScanner();
                else permission.launch(Manifest.permission.CAMERA);
            });
        }
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putBoolean("scannerBusy", scannerBusy); super.onSaveInstanceState(state); }
    @Override protected void onDestroy() { pageReady=false; if(web!=null){web.removeJavascriptInterface("InventoryAndroid");web.destroy();}if(tts!=null){tts.stop();tts.shutdown();}io.shutdownNow();super.onDestroy(); }
}
