package br.com.nossomercadao.terminalalternativo;
import com.journeyapps.barcodescanner.CaptureActivity;
public class ScannerActivity extends CaptureActivity {}
