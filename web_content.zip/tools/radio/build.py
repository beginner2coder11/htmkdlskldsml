import sys, csv, copy
sys.path.insert(0, '/tmp/radioscripts')
import uv32img, routes
SRC, OUT, CSVIN, CSVOUT, CHIRPCSV, NEWLIST = sys.argv[1:7]
im = uv32img.Img(SRC)
tmpl = im.rec(116)
rows = list(csv.DictReader(open(CSVIN)))
# move Georgia 401-430 -> 239-268 ; Florida 801-851 -> 644-694
moves = {}
for a,b,dst in ((401,430,239),(801,851,644)):
    for i,n in enumerate(range(a,b+1)): moves[n]=dst+i
saved = {n: bytes(im.rec(n)) for n in moves}
assert all(im.empty(d) for d in moves.values())
for n in moves: im.clear(n)
for n,d in moves.items(): im.put(d, saved[n])
names = ["WEATHER+WALKIE","CANTON HOME","ATL+GEORGIA","NORTH GA","VIRGINIA+DC","TN+KY","ALABAMA+FLA","CAROLINAS","CANADA ROUTE","EMERGENCY"]
for i,nm in enumerate(names): im.set_bank(i,nm)
for r in rows:
    n=int(r['Channel #'])
    if n in moves: r['Channel #']=str(moves[n])
    z=(int(r['Channel #'])-1)//100
    r['Zone #']=str(z+1); r['Zone Name']=names[z]
new=[]
def add(start, items):
    for i,x in enumerate(items):
        n=start+i; assert n<start+100 and im.empty(n)
        nm=f"{x['area']} {x['call']}"[:12]
        im.write(n, tmpl, round(x['f']*1e6), round(x['off']*1e6), x['tone'], nm)
        zone=(n-1)//100
        band = "220" if 220<x['f']<226 else ("70cm" if x['f']>400 else "2m")
        new.append({'Zone #':str(zone+1),'Zone Name':names[zone],'Channel #':str(n),'Name':nm,
            'Technical / Official Name':f"{x['call']} {band} repeater, {x['place']} (RepeaterBook)",
            'Freq (MHz)':f"{x['f']:.4f}",'Duplex':'+ offset' if x['off']>0 else '- offset',
            'Offset (MHz)':f"{abs(x['off']):.4f}",'Tone':f"Tone {x['tone']}" if x['tone'] else '',
            'Mode':'FM','Power':'High'})
add(401, routes.parse(routes.VA)); add(801, routes.parse(routes.CA))
allrows=sorted(rows+new, key=lambda r:int(r['Channel #']))
with open(CSVOUT,'w',newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(allrows)
with open(NEWLIST,'w',newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(new)
# CHIRP generic CSV of everything (import fallback)
with open(CHIRPCSV,'w',newline='') as f:
    w=csv.writer(f); w.writerow(["Location","Name","Frequency","Duplex","Offset","Tone","rToneFreq","cToneFreq","DtcsCode","DtcsPolarity","RxDtcsCode","CrossMode","Mode","TStep","Skip","Power","Comment","URCALL","RPT1CALL","RPT2CALL","DVCODE"])
    for r in allrows:
        d=r['Duplex']; t=r['Tone']; tm=''; tv='88.5'
        dup={'RX Only':'off','Simplex':'','+ offset':'+','- offset':'-'}.get(d,'')
        if t.startswith('Tone'): tm='Tone'; tv=t.split()[1]
        elif t.startswith('TSQL'): tm='TSQL'; tv=t.split()[1]
        w.writerow([r['Channel #'],r['Name'],r['Freq (MHz)'],dup,r['Offset (MHz)'] or '0.000000',tm,tv,tv,'023','NN','023','Tone->Tone',r['Mode'],'5.00','',r['Power'],r['Technical / Official Name'],'','','',''])
im.save(OUT)
print('new', len(new), 'total', len(allrows), 'img', len(im.b))
