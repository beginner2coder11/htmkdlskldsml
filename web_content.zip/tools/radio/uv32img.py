"""Minimal UV-32 (Baofeng UV-17Pro family) CHIRP image reader/writer, written from CHIRP's driver memory map."""
import struct
REC = 32
NAMES = 0x8280

def bcd_le(b):  # lbcd[4] -> int (units of 10 Hz)
    s = "".join(f"{x:02x}" for x in reversed(b))
    return int(s)

def to_bcd_le(v):
    s = f"{v:08d}"
    return bytes(int(s[i:i+2], 16) for i in (6, 4, 2, 0))

def tone_dec(v):
    if v in (0, 0xFFFF): return None
    if v >= 0x258: return ("Tone", v / 10.0)
    return ("DTCS", v)

class Img:
    def __init__(self, path):
        self.b = bytearray(open(path, "rb").read())
    def rec(self, n): return self.b[(n-1)*REC:n*REC]
    def put(self, n, r): self.b[(n-1)*REC:n*REC] = r
    def empty(self, n): return self.rec(n)[0] == 0xFF
    def clear(self, n): self.put(n, b"\xff" * REC)
    def decode(self, n):
        r = self.rec(n)
        if r[0] == 0xFF: return None
        rx = bcd_le(r[0:4]) * 10
        txraw = r[4:8]
        tx = None if txraw == b"\xff\xff\xff\xff" else bcd_le(txraw) * 10
        rxt, txt = struct.unpack("<HH", r[8:12])
        name = r[20:32].split(b"\xff")[0].decode("ascii", "replace").rstrip()
        flags14, flags15 = r[14], r[15]
        return dict(n=n, rx=rx, tx=tx, rxtone=tone_dec(rxt), txtone=tone_dec(txt), name=name,
                    lowpower=flags14 & 3, wide=(flags15 >> 6) & 1, scan=(flags15 >> 2) & 1, raw=bytes(r))
    def write(self, n, template, rx_hz, offset_hz, tone, name):
        """offset_hz: signed (+/-) or None for simplex. tone: CTCSS float (Tone mode) or None."""
        r = bytearray(template)
        r[0:4] = to_bcd_le(rx_hz // 10)
        tx = rx_hz + (offset_hz or 0)
        r[4:8] = to_bcd_le(tx // 10)
        r[8:10] = struct.pack("<H", 0)
        r[10:12] = struct.pack("<H", int(round(tone * 10)) if tone else 0)
        nm = name.upper()[:12].encode("ascii")
        r[20:32] = nm + b"\xff" * (12 - len(nm))
        self.put(n, bytes(r))
    def bank_names(self):
        return [self.b[NAMES + i*16: NAMES + (i+1)*16] for i in range(10)]
    def set_bank(self, i, name):
        old = self.b[NAMES + i*16: NAMES + (i+1)*16]
        pad = b"\xff" if b"\xff" in old else (b"\x00" if b"\x00" in old else b" ")
        nm = name.upper()[:16].encode("ascii")
        self.b[NAMES + i*16: NAMES + (i+1)*16] = nm + pad * (16 - len(nm))
    def save(self, path): open(path, "wb").write(bytes(self.b))
