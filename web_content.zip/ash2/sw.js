'use strict';
const CACHE='ash-meadow-v8-natural-walk';
const FILES=['./','index.html','style.css','app.js','sound.js','manifest.webmanifest','assets/meadow.webp','assets/ash-atlas.png','assets/ash-rest.webp','assets/ash-idle.png','assets/ash-photo.webp','assets/icon-192.png','assets/icon-512.png','assets/outfit-rider.webp','assets/outfit-japan.webp','assets/outfit-camo.webp','assets/outfit-hoodie.webp'];
const urls=FILES.map(p=>new URL(p,self.registration.scope).href);
self.addEventListener('install',e=>e.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 for(const url of urls){const response=await fetch(new Request(url,{cache:'reload',credentials:'same-origin'}));
 if(!response.ok||response.redirected||(!url.endsWith('/')&&!url.endsWith('.html')&&(response.headers.get('content-type')||'').includes('text/html')))throw Error('Asset unavailable');
 await cache.put(url,response);}
 await self.skipWaiting();
})()));
self.addEventListener('activate',e=>e.waitUntil((async()=>{for(const name of await caches.keys())if(name.startsWith('ash-meadow-')&&name!==CACHE)await caches.delete(name);await self.clients.claim();})()));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET')return;
 const url=new URL(e.request.url),scope=new URL(self.registration.scope);
 if(url.origin!==scope.origin)return;
 url.search='';
 // Installed shortcuts and bookmarked routes must all open the cached app.
 if(e.request.mode==='navigate' && url.pathname.startsWith(scope.pathname)){
  e.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(new URL('index.html',scope).href)||fetch(e.request);})());return;
 }
 if(!urls.includes(url.href))return;
 e.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(url.href)||fetch(e.request);})());
});
self.addEventListener('message',e=>{if(!['CHECK_READY','REPAIR_CACHE'].includes(e.data))return;e.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 if(e.data==='REPAIR_CACHE'){
  for(const url of urls){
   if(await cache.match(url))continue;
   try{const response=await fetch(new Request(url,{cache:'reload',credentials:'same-origin'}));
    if(!response.ok||response.redirected||(!url.endsWith('/')&&!url.endsWith('.html')&&(response.headers.get('content-type')||'').includes('text/html')))throw Error('Asset unavailable');
    await cache.put(url,response);
   }catch{}
  }
 }
 const ready=(await Promise.all(urls.map(url=>cache.match(url)))).every(Boolean);
 e.ports[0]?.postMessage({ready,version:CACHE});
})());});
