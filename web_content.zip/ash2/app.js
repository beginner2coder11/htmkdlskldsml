'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const canvas = $('pet-canvas'), ctx = canvas.getContext('2d');
  const atlas = new Image(), rest = new Image();
  atlas.src = 'assets/ash-atlas.png'; rest.src = 'assets/ash-rest.webp';
  const outfits={};let outfit='none';
  try{const saved=localStorage.getItem('ash-outfit');if(['rider','japan','camo','hoodie'].includes(saved))outfit=saved;}catch{}
  for(const name of ['rider','japan','camo','hoodie']){const img=new Image();outfits[name]={img,ready:false};img.onload=()=>outfits[name].ready=true;img.onerror=()=>{if(outfit===name){outfit='none';$('outfit-status').textContent='衣装を読み込めませんでした。通信を確認して選び直してください。';}};img.src='assets/outfit-'+name+'.webp';}
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w=0,h=0,x=.5,goal=.5,dir=1,state='idle',stateAt=performance.now(),last=0,lastDraw=0,nextIdle=performance.now()+12000;
  let walkDistance=0,walkSpeed=0;
  let loaded=false,restLoaded=false,ready=false,deferredInstall=null,offlineReady=false;
  const labels={idle:'ひなたぼっこ、気持ちいいね。',walk:'いっしょに、おさんぽしよう。',happy:'うれしいな。もっと、なでて。',sit:'おすわり。ちゃんと待ってるよ。',sleep:'すぅ、すぅ……おやすみ、アッシュ。',call:'なあに？ 呼んでくれた？'};
  const buttons=[...document.querySelectorAll('[data-action]')];
  function resize(){const b=canvas.getBoundingClientRect();w=b.width;h=b.height;const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);}
  new ResizeObserver(resize).observe(canvas);
  function setState(next,now=performance.now()){
    if((next==='sit'||next==='sleep'||next==='happy')&&!restLoaded){$('status').textContent='アッシュの準備をしているよ…';return;}
    if(state==='walk'&&next!=='walk')walkSpeed=0;
    state=next;window.AshSound.state(next);stateAt=now;nextIdle=now+12000+Math.random()*6000;
    $('status').textContent=labels[next];$('app').classList.toggle('sleeping',next==='sleep');
    buttons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.action===next)));
    if(next==='walk'){walkSpeed=0;const pad=Math.min(.37,Math.max(.23,100/w));goal=x>.5?pad:1-pad;dir=goal>x?1:-1;}
    canvas.setAttribute('aria-label',next==='sleep'?'眠っているアッシュ。タッチで起こせます':'アッシュ。タッチすると喜びます');
  }
  function hearts(){if(reduced)return;for(let i=0;i<3;i++){const el=document.createElement('span');el.className='heart';el.textContent='♡';el.style.left=`${x*w-25+Math.random()*50}px`;el.style.bottom=`${Math.max(45,h*.22)+i*10}px`;el.style.animationDelay=`${i*.12}s`;$('hearts').append(el);setTimeout(()=>el.remove(),1900);}}
  function action(next){if(!loaded)return;window.AshSound.unlock();setState(next);if(state!==next)return;window.AshSound.trigger(next);if(next==='happy')hearts();}
  buttons.forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
  $('call').addEventListener('click',()=>action('call'));
  canvas.addEventListener('pointerup',()=>action('happy'));
  canvas.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();action('happy');}});
  function cell(now){const elapsed=now-stateAt;
    if(outfit!=='none'&&outfits[outfit]?.ready){
      let index=0;
      if(state==='walk')index=2+Math.floor(elapsed/220)%2;
      else if(state==='sit')index=4;
      else if(state==='sleep')index=5;
      else if(state==='happy')index=6+Math.floor(elapsed/280)%2;
      else if(state==='call')index=elapsed<350?2:0;
      else index=elapsed%5400>5150?1:0;
      return {img:outfits[outfit].img,row:Math.floor(index/4),col:index%4,cw:384,ch:416,flip:(state==='walk'||state==='call'&&elapsed<350)&&dir<0};
    }
    if(state==='walk')return {img:atlas,row:dir===1?1:2,col:Math.floor(elapsed/145)%8,cw:192,ch:208};
    if(state==='call'){
      if(elapsed<500){const seq=dir===1?[4,3,2,1]:[4,5,6,7];return {img:atlas,row:dir===1?9:10,col:seq[Math.min(3,Math.floor(elapsed/125))],cw:192,ch:208};}
      return {img:atlas,row:0,col:0,cw:192,ch:208};
    }
    if(state==='happy'){const seq=[0,1,2,3,2,1];return {img:rest,row:2,col:seq[Math.floor(elapsed/145)%seq.length],cw:384,ch:416};}
    if(state==='sit'){const blink=(elapsed%5500);return {img:rest,row:0,col:blink>4200&&blink<4500?2:blink>3000&&blink<4200?1:0,cw:384,ch:416};}
    if(state==='sleep')return {img:rest,row:1,col:Math.floor(elapsed/950)%4,cw:384,ch:416};
    const blink=elapsed%5400;return {img:atlas,row:0,col:blink<4300?0:Math.min(5,Math.floor((blink-4300)/170)),cw:192,ch:208};
  }
  function draw(now){
    requestAnimationFrame(draw);if(document.hidden){last=now;return;}const dt=Math.min((now-(last||now))/1000,.04);last=now;
    if(!loaded||!w||!h)return;
    if(state==='walk'){
      const scale=Math.min(245,w*.58,h*.92)/384;
      const remaining=Math.abs(goal-x)*w;
      const desired=Math.min(40,Math.sqrt(2*65*remaining));
      walkSpeed=Math.min(desired,walkSpeed+90*dt);
      const step=Math.min(remaining,walkSpeed*dt);
      x+=dir*step/w;walkDistance+=step/scale;
      if(remaining<.15){x=goal;setState('idle',now);}
    }else if((state==='happy'&&now-stateAt>5000)||(state==='call'&&now-stateAt>1400)){setState('idle',now);}
    else if(state==='idle'&&now>nextIdle&&!reduced){setState(Math.random()>.45?'walk':'happy',now);}
    if(now-lastDraw<(reduced?120:32))return;lastDraw=now;
    const f=cell(now),size=Math.min(245,w*.58,h*.92),height=size*208/192;
    const ground=h-10,breathe=reduced?0:Math.sin(now/(state==='sleep'?1100:1400))*(state==='sleep'?1.4:.65);
    ctx.clearRect(0,0,w,h);ctx.save();ctx.globalAlpha=state==='sleep'?.14:.12;ctx.fillStyle='#254725';ctx.filter='blur(5px)';ctx.beginPath();ctx.ellipse(x*w,ground-5,size*.33,10,0,0,Math.PI*2);ctx.fill();ctx.restore();
    ctx.save();if(f.flip){ctx.translate(x*w*2,0);ctx.scale(-1,1);}ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(f.img,f.col*f.cw,f.row*f.ch,f.cw,f.ch,x*w-size/2,ground-height-breathe,size,height+breathe);ctx.restore();ctx.globalAlpha=1;
  }
  atlas.onload=()=>{loaded=true;$('fallback-pet').hidden=true;resize();};
  rest.onload=()=>restLoaded=true;
  atlas.onerror=()=>{$('status').textContent='画像を読み込めませんでした。通信を確認して、開き直してください。';};
  rest.onerror=()=>{$('status').textContent='一部のしぐさを読み込めませんでした。通信を確認して開き直してください。';};
  // Cached images may already be complete before listeners are attached.
  if(atlas.complete&&atlas.naturalWidth){loaded=true;$('fallback-pet').hidden=true;}if(rest.complete&&rest.naturalWidth)restLoaded=true;
  requestAnimationFrame(draw);
  function openDialog(id){$(id).showModal();}
  $('wardrobe').addEventListener('click',()=>openDialog('wardrobe-dialog'));
  const outfitButtons=[...document.querySelectorAll('[data-outfit]')];
  function markOutfit(){outfitButtons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.outfit===outfit)));}
  markOutfit();
  outfitButtons.forEach(b=>b.addEventListener('click',()=>{
    const name=b.dataset.outfit;
    if(name!=='none'&&!outfits[name].ready){$('outfit-status').textContent='衣装を準備中です。少し待って、もう一度選んでね。';return;}
    outfit=name;try{localStorage.setItem('ash-outfit',name);}catch{}markOutfit();$('wardrobe-dialog').close();
    if(state!=='sleep')setState('idle');
  }));
  $('about').addEventListener('click',()=>openDialog('info-dialog'));
  document.querySelectorAll('.dialog-close').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const b=d.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)d.close();}}));
  $('install').addEventListener('click',async()=>{if(deferredInstall){await deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;}else openDialog('install-dialog');});
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;});
  window.addEventListener('appinstalled',()=>{$('install').textContent='ホーム画面に追加済み';deferredInstall=null;});
  function networkLabel(){ $('offline-status').textContent=offlineReady?(navigator.onLine?'● オフライン準備完了':'● オフラインで遊んでいます'):(navigator.onLine?'オフラインの準備中…':'初回の準備には通信が必要です'); }
  addEventListener('online',networkLabel);addEventListener('offline',networkLabel);
  networkLabel();
  let preparing=false;
  function workerMessage(worker,message){
    return new Promise((resolve,reject)=>{
      const channel=new MessageChannel();
      const timer=setTimeout(()=>{channel.port1.close();reject(Error('timeout'));},60000);
      channel.port1.onmessage=e=>{clearTimeout(timer);channel.port1.close();resolve(e.data);};
      worker.postMessage(message,[channel.port2]);
    });
  }
  async function checkCache(worker,repair=false){
    if(!worker)return;
    const result=await workerMessage(worker,repair?'REPAIR_CACHE':'CHECK_READY');
    offlineReady=!!result.ready;networkLabel();
    $('cache-help').textContent=offlineReady?'保存できました。この端末で、通信なしでもアッシュと遊べます。機内モードで一度開いて確かめてね。':'保存がまだ完了していません。通信できる状態で「オフライン保存をやり直す」を押してください。';
  }
  async function prepareOffline(){
    if(preparing)return;preparing=true;
    $('offline-retry').disabled=true;
    $('cache-help').textContent='写真・衣装・アッシュの動きを端末に保存しています…';
    try{
      if(!('serviceWorker' in navigator)||!window.isSecureContext)throw Error('unsupported');
      const reg=await navigator.serviceWorker.register('sw.js',{updateViaCache:'none'});
      if(navigator.onLine)await reg.update();
      const active=await Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(Error('timeout')),60000))]);
      await checkCache(active.active,navigator.onLine);
    }catch{
      $('offline-status').textContent=offlineReady?'● 保存済み（更新はあとで再試行）':'オフライン保存が完了していません';
      $('cache-help').textContent='AndroidのChromeで開き、通信を確認して保存をやり直してください。';
    }finally{preparing=false;$('offline-retry').disabled=false;}
  }
  $('offline-retry').addEventListener('click',()=>{
    navigator.storage?.persist?.().catch(()=>{});
    prepareOffline();
  });
  if('serviceWorker' in navigator && window.isSecureContext){
    prepareOffline();
    navigator.serviceWorker.addEventListener('controllerchange',()=>checkCache(navigator.serviceWorker.controller).catch(()=>{}));
    addEventListener('online',prepareOffline);
  }else{$('offline-status').textContent='オフライン保存はChromeなどのブラウザで開いてください';}
  // Animation runs locally, with no API keys or AI calls.

  window.AshApp={getState:()=>({state,x,loaded,restLoaded,offlineReady,outfit,walkDistance,walkSpeed}),setOfflineReady(value){offlineReady=value;networkLabel();}};
})();
