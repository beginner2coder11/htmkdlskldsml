/* Distance-driven four-beat walk. Feet in stance are fixed in world space. */
(function(root){
 const CYCLE=48,STANCE=.65;
 function foot(distance,offset,hip){
  const phase=((distance/CYCLE+offset)%1+1)%1;
  if(phase<STANCE)return {x:hip+CYCLE*STANCE/2-CYCLE*phase,y:0,stance:true};
  const t=(phase-STANCE)/(1-STANCE),ease=t*t*(3-2*t);
  return {x:hip-CYCLE*STANCE/2+CYCLE*STANCE*ease,y:-8*Math.sin(Math.PI*t),stance:false};
 }
 function knee(a,b,l1,l2,bend){
  const dx=b.x-a.x,dy=b.y-a.y,d=Math.max(.01,Math.hypot(dx,dy));
  const reach=Math.min(d,l1+l2-.01),along=(l1*l1-l2*l2+reach*reach)/(2*reach),side=Math.sqrt(Math.max(0,l1*l1-along*along));
  return {x:a.x+dx/d*along+dy/d*side*bend,y:a.y+dy/d*along-dx/d*side*bend};
 }
 root.AshGait={CYCLE,STANCE,foot,knee};
 if(typeof module!=='undefined')module.exports=root.AshGait;
})(typeof window==='undefined'?globalThis:window);
