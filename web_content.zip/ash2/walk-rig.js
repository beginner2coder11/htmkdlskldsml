(function(){
 const textures={};let ready=false;
 const names=['none','rider','japan','hoodie','camo','tail','front','rear'];
 Promise.all(names.map(name=>new Promise((resolve,reject)=>{const im=new Image();textures[name]=im;im.onload=resolve;im.onerror=reject;im.src='assets/rig-'+name+'.webp';}))).then(()=>ready=true).catch(()=>{});
 const legs=[{hip:100,phase:.5,front:false,far:true},{hip:244,phase:.75,front:true,far:true},{hip:94,phase:0,front:false},{hip:238,phase:.25,front:true}];
 function segment(ctx,im,sy,sh,a,b,width){
  const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy);
  ctx.save();ctx.translate(a.x,a.y);ctx.rotate(-Math.atan2(dx,dy));
  ctx.drawImage(im,0,sy,im.width,sh,-width/2,-1,width,len+1);ctx.restore();
 }
 function pose(distance){return legs.map(l=>({...l,...AshGait.foot(distance,l.phase,l.hip)}));}
 function render(ctx,{x,ground,size,dir,outfit,distance,now,settle=0}){
  if(!ready)return false;
  const scale=size/384,cycle=distance/AshGait.CYCLE*Math.PI*2;
  const bounce=(Math.cos(cycle*2)*1.7)*(1-settle);
  ctx.save();ctx.translate(x,ground);ctx.scale(scale*dir,scale);ctx.translate(-192,0);
  const feet=pose(distance);
  function leg(l){
   const target={x:l.x+(l.hip-l.x)*settle,y:l.y*(1-settle)-8*Math.sin(Math.PI*settle)};
   // Preserve the complete canine leg silhouette: no cut-and-rotated knee pieces.
   // Warp the upper fur gently; keep the paw level at its planted contact.
   const im=textures[l.front?'front':'rear'];
   const top=-100+bounce, bottom=target.y;
   const width=l.front?42:48;
   ctx.save();if(l.far){ctx.filter='brightness(.86)';}
   const slices=24;
   for(let i=0;i<slices;i++){
    const t=i/slices, next=(i+1)/slices;
    const follow=t*t*(3-2*t);
    const center=l.hip+(target.x-l.hip)*follow;
    ctx.drawImage(im,0,t*im.height,im.width,im.height/slices,
     center-width/2,top+(bottom-top)*t,width,(bottom-top)/slices+.6);
   }
   ctx.restore();
  }
  feet.filter(l=>l.far).forEach(leg);
  ctx.save();ctx.translate(61,-140+bounce);ctx.rotate(Math.sin(cycle+now/1800)*.10);ctx.drawImage(textures.tail,-36,-142,104,149);ctx.restore();
  feet.filter(l=>!l.far).forEach(leg);
  const im=textures[outfit]||textures.none;
  ctx.drawImage(im,39,-312+bounce,300,246);
  ctx.restore();return true;
 }
 window.AshWalkRig={render,pose,get ready(){return ready;}};
})();
