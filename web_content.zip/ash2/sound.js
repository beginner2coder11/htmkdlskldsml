'use strict';
// Original synthesized canine effects; no recordings or remote requests.
window.AshSound = (() => {
  let context, active, mode='idle', unlocked=false, serial=0;
  let enabled=true;
  try { enabled=localStorage.getItem('ash-sound')!=='off'; } catch {}
  const buffers={};
  function make(kind) {
    if(buffers[kind])return buffers[kind];
    const rate=context.sampleRate, duration=kind==='sleep'?3.8:kind==='happy'?3.6:.42;
    const buffer=context.createBuffer(1,Math.ceil(rate*duration),rate), data=buffer.getChannelData(0);
    let low=0, smooth=0, phase=0;
    for(let i=0;i<data.length;i++){
      const t=i/rate, noise=Math.random()*2-1;
      low+=.055*(noise-low);smooth+=.32*(noise-smooth);
      let v=0;
      if(kind==='sit'){
        const u=t/duration, env=Math.pow(Math.sin(Math.PI*u),.7)*Math.exp(-3*u);
        const f=690-360*u+24*Math.sin(2*Math.PI*35*t);
        phase+=2*Math.PI*f/rate;
        const voice=Math.sin(phase)+.5*Math.sin(phase*2)+.3*Math.sin(phase*3)+.16*Math.sin(phase*5);
        v=.52*env*(.7*Math.tanh(voice*1.6)+.55*(smooth-low));
      } else if(kind==='happy'){
        const cycle=t%.45, inhale=cycle<.19;
        const u=inhale?cycle/.19:(cycle-.19)/.26;
        const env=Math.pow(Math.sin(Math.PI*u),1.7);
        v=env*(inhale?.42:.7)*(smooth-low*.65)*(1+.15*Math.sin(t*90));
      } else {
        const cycle=t%3.8;
        const u=cycle<1.45?cycle/1.45:cycle<1.8?0:cycle<3.45?(cycle-1.8)/1.65:0;
        const env=Math.pow(Math.sin(Math.PI*u),1.6);
        v=env*.48*(low*.8+smooth*.3);
      }
      const fade=Math.min(1,t/.015,(duration-t)/.035);
      data[i]=v*fade;
    }
    return buffers[kind]=buffer;
  }
  function stop(){serial++;if(active){try{active.stop();}catch{}active.disconnect();active=null;}}
  function play(){
    stop();
    if(!enabled||!unlocked||document.hidden||!['happy','sleep','sit'].includes(mode))return;
    const token=serial, selected=mode;
    const begin=()=>{
      if(token!==serial||document.hidden||!enabled)return;
      const node=context.createBufferSource();node.buffer=make(selected);node.loop=selected==='sleep';
      node.connect(context.destination);active=node;node.start();
      node.onended=()=>{node.disconnect();if(active===node)active=null;};
    };
    if(context.state==='running')begin();else context.resume().then(begin).catch(()=>{});
  }
  function unlock(){
    if(unlocked)return;
    const Audio=window.AudioContext||window.webkitAudioContext;
    if(!Audio)return;
    try{context=new Audio();unlocked=true;}catch{}
  }
  const button=document.getElementById('sound-toggle');
  function label(){button.textContent=enabled?'音：オン':'音：オフ';button.setAttribute('aria-pressed',String(enabled));}
  button.addEventListener('click',()=>{enabled=!enabled;try{localStorage.setItem('ash-sound',enabled?'on':'off');}catch{}unlock();label();if(enabled&&mode==='sleep')play();else stop();});
  label();
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();else if(mode==='sleep')play();});
  window.addEventListener('pagehide',stop);
  return { unlock, state(next){mode=next;stop();}, trigger(next){mode=next;unlock();play();}, getState:()=>({enabled,mode,playing:!!active}) };
})();
