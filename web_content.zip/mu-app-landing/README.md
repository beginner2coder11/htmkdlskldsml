# MuOnlineClaude 3D — Landing App

Uma página inicial estilo trailer para celular e computador, com cenário 3D animado, modelos GLB fornecidos, contadores reais do servidor e formulário de cadastro/login ligado à API existente do MuOnlineClaude.

## Conexão com o servidor existente

A página usa estas rotas que já aparecem no `server.js` fornecido no histórico do projeto:
- `GET /api/stats` — números reais de jogadores online e contas.
- `POST /api/register` — cria conta com `{ username, email, password }`.
- `POST /api/login` — login com `{ id, password }`.

**Importante:** para cadastro funcionar sem bloqueio CORS, publique a página no mesmo domínio do jogo, idealmente em `https://muonlineclaude.com/app/`. O HTML usa a origem atual quando está hospedado no domínio. Se abrir o arquivo diretamente ou hospedar em outro domínio, a política CORS do servidor pode bloquear chamadas; nesse caso, hospede no mesmo domínio ou configure CORS no backend com uma origem permitida específica.

## Instalação no site

1. Faça backup dos arquivos atuais.
2. Copie o conteúdo desta pasta para uma pasta pública servida pelo mesmo backend, por exemplo `public/app/` ou o diretório equivalente que seu `server.js` usa para arquivos estáticos.
3. Confirme que `https://muonlineclaude.com/app/` abre `index.html` e que os caminhos `/app/assets/...` carregam os modelos.
4. Teste os contadores, crie uma conta de teste e faça login. Não teste repetidamente com e-mails de usuários reais.
5. A página envia o visitante ao jogo existente em `https://muonlineclaude.com/jogar` depois de criar a conta/login.

A estrutura de arquivos estática pode variar conforme o `server.js` publicado. Este pacote não altera o backend e não faz deploy automático.

## Instalação como app no Android

O pacote inclui um manifesto PWA. Depois de hospedado em HTTPS, abra `/app/` no Chrome Android e use o menu ⋮ → **Adicionar à tela inicial** ou **Instalar app**. Isso cria um app instalável tipo PWA. Não é um APK nativo compilado.

## Modelos incluídos

- `assets/cls_mudk.glb` — Dark Knight
- `assets/cls_mudw.glb` — Dark Wizard
- `assets/cls_muelf.glb` — Fairy Elf
- `assets/cls_mumg.glb` — Magic Gladiator
- `assets/cls_mudl.glb` — Dark Lord

A prévia 3D usa Three.js e GLTFLoader via CDN. É necessário acesso à internet para carregar a biblioteca. A disponibilidade de animações depende de cada arquivo GLB; a página usa movimento de câmera e apresentação visual mesmo quando o modelo não contém animações.

## Segurança

A senha é enviada diretamente por HTTPS para a API existente; este front-end não salva senhas localmente. As regras e a validação final continuam sendo responsabilidade do servidor. O login nesta página confirma as credenciais e apresenta o botão para abrir o jogo; ele não transfere automaticamente a sessão para o jogo se o jogo usar um mecanismo de token separado.
