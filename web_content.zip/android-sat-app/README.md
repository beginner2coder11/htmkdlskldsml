# Android aplikacija - Sat i vrijeme (HTML u WebView)

Ovo je jednostavna Android aplikacija koja učitava tvoj HTML sat i **zaključava ekran u landscape mod** preko `android:screenOrientation="landscape"` u AndroidManifest.xml.

## Kako napraviti APK

1. Instaliraj **Android Studio** (besplatno sa https://developer.android.com/studio)
2. Otvori Android Studio → **Open** → izaberi folder `android-sat-app`
3. Sačekaj da se projekat sinhronizuje (može tražiti da skine SDK komponente)
4. Kopiraj fajl `sat_vrijeme_landskape.html` u:
   `app/src/main/assets/index.html`
   (preimenuj ga u `index.html`)
5. Klikni **Build → Build Bundle(s) / APK(s) → Build APK(s)**
6. APK će biti u `app/build/outputs/apk/debug/`

## Važne stvari

- Aplikacija je **uvijek u landscape** modu (to je pravo rješenje za Android, ne ovisi o `screen.orientation.lock`).
- HTML fajl je u `assets` folderu i učitava se lokalno.
- Potrebne su dozvole za internet i lokaciju (za vrijeme).

## Ako želiš ikonu

U Android Studiju desni klik na `res` → New → Image Asset i napravi ikonu.

Gotovo! Aplikacija će se otvarati horizontalno i prikazivati tvoj sat.