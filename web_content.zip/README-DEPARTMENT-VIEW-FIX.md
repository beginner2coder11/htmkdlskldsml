# Department View update

Changes:
- Added a department selector: All Departments, Food & Beverage, and Kitchen.
- Fixed F&B employee classification/headcount for common department labels including F&B, Food & Beverage, Food and Beverage, Service, and Banqueting.
- Added Events Manager and Banqueting Coordinator (including Bqt Coordinator) to the F&B Management group.
- Kept Kitchen classification and existing Kitchen job-title sections.
- Counts update when the selected department changes.
- Updated both the Android app's bundled interface and the matching hrsettings source copy.

Validation:
- `node --check` passed for both updated JavaScript files.
- This is a source ZIP; an Android APK build and on-device test have not yet been performed.
