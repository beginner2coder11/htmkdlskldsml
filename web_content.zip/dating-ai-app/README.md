# MatchMind AI — Dating Coach

Multilingual dating coach in Portuguese, French and English.

## Included
- Email/password sign-up and sign-in with Supabase Auth.
- Password recovery by email.
- Profile builder with bio ideas and prompts.
- Conversation coach focused on confidence, respect, consent and authentic communication.
- Dating strategy plans and first-message ideas.
- Photo upload + AI feedback endpoint (OpenAI vision) for composition, lighting, clarity, authenticity and profile fit. It does **not** infer sensitive traits or attractiveness scores.
- Responsive mobile-first UI.
- Language switcher: PT / FR / EN.

## Setup
1. Create a Supabase project and enable Email provider in Authentication.
2. Add the URL and anon key to `.env` as `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
3. For photo analysis, add `OPENAI_API_KEY` to `.env` and run the Express API with `npm run server`.
4. Install and run:
   - `npm install`
   - `npm run dev`
5. In Supabase Auth > URL Configuration, set the Site URL to your app URL. Add your local/deployed callback URL if needed.

The frontend works without the AI server; the photo analysis button will show a configuration message until the API is available.
