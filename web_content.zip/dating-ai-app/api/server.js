import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({limit:'2mb'}));
const upload = multer({storage: multer.memoryStorage(), limits:{fileSize:8*1024*1024}});

app.get('/api/health', (_,res)=>res.json({ok:true}));

app.post('/api/analyze-photo', upload.single('photo'), async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'AI server is not configured. Add OPENAI_API_KEY to .env.'});
  if(!req.file) return res.status(400).json({error:'No photo uploaded.'});
  try{
    const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const b64=req.file.buffer.toString('base64');
    const mime=req.file.mimetype || 'image/jpeg';
    const lang=req.body.language || 'en';
    const prompt=`You are a respectful dating-profile coach. Review this profile photo for practical presentation quality only. Do not infer or comment on sensitive traits (race, ethnicity, religion, health, sexuality, disability, age beyond obvious image-quality concerns), and do not give an attractiveness score. Focus on: lighting, framing, facial visibility, background, image quality, authenticity, clothing/context appropriateness, and whether it works as a dating-app primary photo. Give 3 strengths, 5 concrete improvements, and a short suggested use (main photo / secondary photo / replace). Be honest but encouraging. Respond in ${lang==='pt'?'Brazilian Portuguese':lang==='fr'?'French':'English'} with clear headings.`;
    const r=await client.responses.create({model:'gpt-5.6-mini',input:[{role:'user',content:[{type:'input_text',text:prompt},{type:'input_image',image_url:`data:${mime};base64,${b64}`}]}]});
    res.json({analysis:r.output_text});
  }catch(e){console.error(e);res.status(500).json({error:'Photo analysis failed.'});}
});

const dist=path.resolve('dist');
if(fs.existsSync(dist)){app.use(express.static(dist));app.get('*',(_,res)=>res.sendFile(path.join(dist,'index.html')))}
const port=process.env.PORT||8787; app.listen(port,()=>console.log(`API running on ${port}`));
