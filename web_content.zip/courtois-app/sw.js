const CACHE = "courtois-app-v2";
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(["./", "./index.html", "./manifest.json", "./icon.svg"])));
  self.skipWaiting();
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then((cached) => cached || fetch(e.request).then((res) => res).catch(() => cached))
  );
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(clients.openWindow("./index.html#/annonces"));
});
self.addEventListener("push", (e) => {
  const data = e.data ? e.data.json() : { title: "Courtois", body: "Nouvelle demande" };
  e.waitUntil(self.registration.showNotification(data.title || "Courtois", {
    body: data.body || "",
    icon: "./icon.svg",
    badge: "./icon.svg"
  }));
});
