# Afriquia Stock: no custom shrinking rules required.
