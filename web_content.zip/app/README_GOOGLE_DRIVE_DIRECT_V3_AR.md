# ربط Google Drive مباشرة — الإصدار 3.0

تم تعديل التطبيق ليصبح النسخ الاحتياطي مرتبطًا بحساب Google داخل التطبيق بدل فتح مدير الملفات.

## ما الذي تغير؟
- زر **تسجيل الدخول إلى Google** داخل صفحة النسخ الاحتياطي.
- اختيار حساب Google من شاشة Google الرسمية.
- طلب صلاحية `drive.file`، وهي مخصصة لملفات التطبيق التي ينشئها على Drive.
- زر حفظ يرفع `AFRIQUIA-FREINS-backup.json` مباشرة إلى Google Drive عبر Drive REST API.
- زر الاسترجاع يبحث عن آخر نسخة بالاسم نفسه ويحمّلها مباشرة.
- يبقى تسجيل الدخول محفوظًا على الجهاز ويمكن استعماله بعد إعادة فتح التطبيق.

## مهم قبل إنشاء APK نهائي
يلزم إعداد Google Cloud مرة واحدة:

1. افتح مشروعًا في Google Cloud Console.
2. فعّل **Google Drive API**.
3. فعّل إعداد OAuth consent screen / Google Auth Platform.
4. أنشئ **OAuth Client ID من نوع Android**.
5. استخدم package name:
   `com.afriquia.freinszemamra`
6. أضف SHA-1 لشهادة APK التي ستوقع بها التطبيق (debug أو release).
7. إذا كان التطبيق في وضع الاختبار، أضف حساب Google الذي سيستخدم التطبيق ضمن Test users عند الحاجة.

لا نضع كلمة مرور حساب Google داخل التطبيق، ولا يحتاج التطبيق إلى معرفة البريد مسبقًا؛ شاشة Google هي التي تسمح للمستخدم باختيار الحساب.

## ملاحظة
الكود المرفق يستخدم `play-services-auth` لتسجيل الدخول وGoogle Drive REST API للرفع والاسترجاع. لذلك لا يكفي تغيير زر داخل HTML فقط؛ يجب أن يكون OAuth وDrive API مهيئين في مشروع Google Cloud.
