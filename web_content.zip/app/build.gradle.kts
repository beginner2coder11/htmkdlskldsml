plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.prepapeinture.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.prepapeinture.app"; minSdk = 24; targetSdk = 34; versionCode = 3; versionName = "3.0" }
}
