plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.rocketbrowser.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.rocketbrowser.app"; minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "2.0" }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
