plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.rb.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.rb.app"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
}
