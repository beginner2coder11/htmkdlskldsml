plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.sportsanalyzer.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.sportsanalyzer.app"; minSdk = 24; targetSdk = 34; versionCode = 4; versionName = "4.0" }
}
