plugins {
    id("com.android.application")
}

android {
    namespace = "com.aboyomna.mynetwork"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aboyomna.mynetwork"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies { implementation("androidx.webkit:webkit:1.12.1") }
