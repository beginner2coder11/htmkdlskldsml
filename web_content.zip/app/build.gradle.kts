plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tjoefbuddies.p2p"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tjoefbuddies.p2p"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-p2p"
    }
}
