plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.rbv4.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.rbpoker.app"; minSdk = 24; targetSdk = 34; versionCode = 6; versionName = "6.0" }
}
