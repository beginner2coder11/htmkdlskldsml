# جسر النسخ الاحتياطي Google Drive - الإصدار 1.7

تمت إضافة ملف Java مستقل باسم `BackupBridge.java` ويتم تسجيله داخل WebView باسم `AndroidBackup`.

الدوال:
- `isReady()`
- `getBridgeVersion()`
- `saveToGoogleDrive(json)`
- `restoreFromGoogleDrive()`

يوجد أيضاً مسار احتياطي native عبر `afriquia://backup-save` و`afriquia://backup-restore` إذا لم يتم حقن الجسر في WebView لأي سبب.

بعد بناء APK يجب تثبيت الإصدار 1.7 على الهاتف.
