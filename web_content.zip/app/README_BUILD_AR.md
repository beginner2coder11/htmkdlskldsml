# تجهيز البناء - Afriquia Stock

المشروع مضبوط للبناء في Android Studio باستخدام Android Gradle Plugin 8.7.3 وcompileSdk 35.

## إخراج APK
افتح مجلد `AfriquiaStockAndroid` في Android Studio، ثم:
**Build → Generate App Bundles or APKs → Generate APKs**

الملف الناتج:
`app/build/outputs/apk/release/app-release.apk`

## ملف BUILD_APK.bat
يوجد ملف `BUILD_APK.bat` للبناء من Windows إذا كان Gradle متاحًا في PATH.

> ملاحظة: لم أضمّن Gradle Wrapper binary لأن بيئة إعداد الملف الحالية لا تستطيع تنزيله من الإنترنت. لذلك يلزم أول مرة فتح المشروع في Android Studio ومزامنة Gradle، أو تثبيت Gradle محليًا.
