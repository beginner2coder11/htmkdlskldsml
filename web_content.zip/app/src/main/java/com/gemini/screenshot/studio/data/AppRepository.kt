package com.gemini.screenshot.studio.data

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate

class AppRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("com.gemini.screenshot.studio_storage", Context.MODE_PRIVATE)

    fun isNightModeEnabled(): Boolean {
        return prefs.getBoolean("night_mode", true)
    }

    fun setNightModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("night_mode", enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    fun saveFullStateJson(json: String) {
        prefs.edit().putString("full_app_json_state", json).apply()
    }
}