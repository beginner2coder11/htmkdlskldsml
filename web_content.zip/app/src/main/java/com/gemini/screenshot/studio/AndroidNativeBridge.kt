package com.gemini.screenshot.studio

import android.Manifest
import android.app.Activity
import android.os.Build
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.gemini.screenshot.studio.data.AppRepository

class AndroidNativeBridge(
    private val activity: Activity,
    private val repository: AppRepository
) {
    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun requestAndroidPermission(permissionName: String) {
        val perm = when (permissionName.uppercase()) {
            "CAMERA" -> Manifest.permission.CAMERA
            "AUDIO", "RECORD_AUDIO" -> Manifest.permission.RECORD_AUDIO
            "NOTIFICATIONS", "POST_NOTIFICATIONS" -> if (Build.VERSION.SDK_INT >= 33) "android.permission.POST_NOTIFICATIONS" else Manifest.permission.INTERNET
            else -> permissionName
        }
        ActivityCompat.requestPermissions(activity, arrayOf(perm), 1001)
    }

    @JavascriptInterface
    fun saveJsonState(json: String) {
        repository.saveFullStateJson(json)
    }
}