package com.muzakkir.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** إعادة جدولة التذكيرات بعد إعادة تشغيل الهاتف */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && ReminderScheduler.isEnabled(ctx)) {
            ReminderScheduler.scheduleNext(ctx, ReminderScheduler.intervalMinutes(ctx))
        }
    }
}
