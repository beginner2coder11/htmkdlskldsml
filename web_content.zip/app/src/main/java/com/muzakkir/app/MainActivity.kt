package com.muzakkir.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    inner class RbBridge {
        /** يستقبل إعدادات التنبيهات والنصائح من التطبيق ويجدول المنبهات */
        @JavascriptInterface
        fun scheduleReminders(json: String) {
            try {
                ReminderScheduler.saveConfig(this@MainActivity, json)
                ReminderScheduler.scheduleFromConfig(this@MainActivity)
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun cancelReminders() {
            try { ReminderScheduler.cancel(this@MainActivity) } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 43)
            }
        }

        @JavascriptInterface
        fun hasNotificationPermission(): String {
            if (Build.VERSION.SDK_INT < 33) return "true"
            return (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED).toString()
        }

        @JavascriptInterface
        fun canScheduleExactAlarms(): String {
            if (Build.VERSION.SDK_INT < 31) return "true"
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            return am.canScheduleExactAlarms().toString()
        }

        @JavascriptInterface
        fun canUseFullScreenIntent(): String {
            if (Build.VERSION.SDK_INT < 34) return "true"
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            return nm.canUseFullScreenIntent().toString()
        }

        @JavascriptInterface
        fun openExactAlarmSettings() {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            try {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                startActivity(i)
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun openAppDetailsSettings() {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }

        /** تنبيه فوري للاختبار */
        @JavascriptInterface
        fun testNotification(json: String) {
            try {
                val o = JSONObject(json)
                ReminderReceiver.showFullScreen(
                    this@MainActivity,
                    o.optString("title"),
                    o.optString("body"),
                    o.optString("category")
                )
            } catch (_: Exception) { }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(RbBridge(), "RBAndroid")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request?.isForMainFrame != true) return false
                val url = request.url?.toString() ?: return false
                if (url.startsWith("file:///android_asset/")) return false
                // الروابط الخارجية تُفتح في المتصفح
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
                return true
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 43)
        }
        webView.loadUrl("file:///android_asset/app.html")
    }
}
