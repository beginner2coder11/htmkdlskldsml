package com.muzakkir.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** شاشة التنبيه بملء الشاشة — تظهر فوق شاشة القفل */
class ReminderActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // الظهور فوق شاشة القفل مع إيقاظ الشاشة
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val title = intent.getStringExtra("title").orEmpty()
        val body = intent.getStringExtra("body").orEmpty()
        val category = intent.getStringExtra("category").orEmpty()

        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#1a2340"), Color.parseColor("#0d5c63"), Color.parseColor("#0a1f33"))
        )
        bg.cornerRadius = 0f

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(48), dp(28), dp(48))
            background = bg
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }

        val emoji = TextView(this).apply {
            text = "💡"
            textSize = 56f
            gravity = Gravity.CENTER
        }
        root.addView(emoji)

        if (category.isNotEmpty()) {
            val chipBg = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFFFFF"))
                cornerRadius = dp(20).toFloat()
            }
            val chip = TextView(this).apply {
                text = category
                textSize = 14f
                setTextColor(Color.parseColor("#FFE9A8"))
                gravity = Gravity.CENTER
                background = chipBg
                setPadding(dp(18), dp(8), dp(18), dp(8))
            }
            val chipWrap = LinearLayout(this).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, 0)
                addView(chip)
            }
            root.addView(chipWrap)
        }

        val titleView = TextView(this).apply {
            text = if (title.isNotEmpty()) title else "مذكّر"
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(titleView)

        val scroll = ScrollView(this).apply {
            setPadding(0, dp(12), 0, 0)
        }
        val bodyView = TextView(this).apply {
            text = body
            textSize = 21f
            setTextColor(Color.parseColor("#F2F5FA"))
            gravity = Gravity.CENTER
            setLineSpacing(dp(6).toFloat(), 1f)
        }
        scroll.addView(bodyView)
        val scrollParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        )
        root.addView(scroll, scrollParams)

        val btnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#FFC93C"))
            cornerRadius = dp(16).toFloat()
        }
        val openBtn = Button(this).apply {
            text = "فتح التطبيق"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#1a2340"))
            background = btnBg
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                startActivity(Intent(this@ReminderActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                })
                finish()
            }
        }
        val openParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(20)
        }
        root.addView(openBtn, openParams)

        val closeBtn = Button(this).apply {
            text = "إغلاق"
            textSize = 16f
            setTextColor(Color.parseColor("#BFD0E8"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }
        root.addView(closeBtn)

        setContentView(root)
    }
}
