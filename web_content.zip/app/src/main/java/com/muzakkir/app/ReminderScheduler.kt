package com.muzakkir.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.util.Calendar

/** حفظ الإعدادات وجدولة المنبهات الدورية لتطبيق مذكّر */
object ReminderScheduler {
    const val PREFS = "muzakkir"
    const val ACTION_REMIND = "com.muzakkir.app.REMIND"

    fun saveConfig(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("config", json)
            .putInt("index", 0)
            .apply()
    }

    fun setEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean("enabled", enabled).apply()
    }

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(ctx))
        setEnabled(ctx, false)
    }

    private fun pendingIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_REMIND)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(ctx, 1001, intent, flags)
    }

    fun scheduleNext(ctx: Context, delayMinutes: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = System.currentTimeMillis() + delayMinutes.coerceAtLeast(1) * 60_000L
        val pi = pendingIntent(ctx)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun scheduleFromConfig(ctx: Context) {
        val cfg = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null) ?: return
        try {
            val o = JSONObject(cfg)
            val enabled = o.optBoolean("enabled", true)
            setEnabled(ctx, enabled)
            if (!enabled) {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.cancel(pendingIntent(ctx))
                return
            }
            scheduleNext(ctx, o.optInt("intervalMinutes", 30).coerceAtLeast(1))
        } catch (_: Exception) { }
    }

    fun isQuietNow(ctx: Context): Boolean {
        return try {
            val cfgStr = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null) ?: return false
            val cfg = JSONObject(cfgStr)
            fun parse(t: String): Int {
                val p = t.split(":")
                return p[0].toInt() * 60 + p[1].toInt()
            }
            val s = parse(cfg.optString("quietStart", "23:00"))
            val e = parse(cfg.optString("quietEnd", "07:00"))
            val now = Calendar.getInstance()
            val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            if (s <= e) nowMin in s until e else (nowMin >= s || nowMin < e)
        } catch (_: Exception) { false }
    }

    /** النصيحة التالية بالتناوب الدائري مع احترام الفئات المختارة */
    fun nextTip(ctx: Context): JSONObject? {
        return try {
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val cfg = JSONObject(prefs.getString("config", null) ?: return null)
            val tips = cfg.optJSONArray("tips") ?: return null
            val cats = mutableSetOf<String>()
            cfg.optJSONArray("categories")?.let { arr ->
                for (i in 0 until arr.length()) cats.add(arr.optString(i))
            }
            val pool = mutableListOf<JSONObject>()
            for (i in 0 until tips.length()) {
                val t = tips.optJSONObject(i) ?: continue
                if (cats.isEmpty() || cats.contains(t.optString("category"))) pool.add(t)
            }
            if (pool.isEmpty()) return null
            val idx = prefs.getInt("index", 0)
            val tip = pool[idx % pool.size]
            prefs.edit().putInt("index", idx + 1).apply()
            tip
        } catch (_: Exception) { null }
    }

    fun intervalMinutes(ctx: Context): Int {
        return try {
            val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null) ?: return 30
            JSONObject(s).optInt("intervalMinutes", 30).coerceAtLeast(1)
        } catch (_: Exception) { 30 }
    }
}
