package com.muzakkir.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** يُطلق عند حلول موعد التذكير: يعرض إشعارًا بملء الشاشة ويجدول الموعد التالي */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent?) {
        if (!ReminderScheduler.isEnabled(ctx)) return
        // ربط الموعد التالي أولًا حتى لا تنقطع الدورة مهما حدث
        ReminderScheduler.scheduleNext(ctx, ReminderScheduler.intervalMinutes(ctx))
        if (ReminderScheduler.isQuietNow(ctx)) return
        val tip = ReminderScheduler.nextTip(ctx) ?: return
        showFullScreen(
            ctx,
            tip.optString("title"),
            tip.optString("body"),
            tip.optString("category")
        )
    }

    companion object {
        const val CHANNEL_ID = "muzakkir_reminders"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        CHANNEL_ID,
                        "تذكيرات مذكّر",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    ch.description = "إشعارات النصائح الدورية بملء الشاشة"
                    ch.enableVibration(true)
                    ch.setShowBadge(true)
                    nm.createNotificationChannel(ch)
                }
            }
        }

        /** إشعار بملء الشاشة يظهر فوق شاشة القفل */
        fun showFullScreen(ctx: Context, title: String, body: String, category: String) {
            val fullIntent = Intent(ctx, ReminderActivity::class.java).apply {
                putExtra("title", title)
                putExtra("body", body)
                putExtra("category", category)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val fullPi = PendingIntent.getActivity(ctx, 2001, fullIntent, flags)

            val openIntent = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openPi = PendingIntent.getActivity(ctx, 2002, openIntent, flags)

            val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ensureChannel(ctx)
                Notification.Builder(ctx, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(ctx)
            }
            builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(if (title.isNotEmpty()) title else "مذكّر 💡")
                .setContentText(if (body.isNotEmpty()) body else "")
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(openPi)
                .setAutoCancel(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                builder.setVisibility(Notification.VISIBILITY_PUBLIC)
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                @Suppress("DEPRECATION")
                builder.setPriority(Notification.PRIORITY_MAX)
                    .setDefaults(Notification.DEFAULT_ALL)
            }
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(3001, builder.build())
        }
    }
}
