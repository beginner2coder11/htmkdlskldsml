package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Base64;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.api.Scope;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import org.json.JSONArray;
import org.json.JSONObject;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.print.PrintDocumentInfo;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;


public class MainActivity extends Activity {
    private WebView webView;
    private WebView pdfWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int WRITE_STORAGE_REQUEST = 1002;
    private static final int GOOGLE_SIGN_IN_REQUEST = 1101;
    private static final String DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String DRIVE_FOLDER_NAME = "AFRIQUIA Backup";
    private static final String DRIVE_BACKUP_NAME = "AFRIQUIA-BACKUP-LATEST.json";
    private GoogleSignInClient googleSignInClient;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception ignored) {
                Toast.makeText(MainActivity.this, "تعذر فتح الملف للتنزيل", Toast.LENGTH_LONG).show();
            }
        });
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.addJavascriptInterface(new GoogleAccountBridge(), "GoogleAccount");
        webView.addJavascriptInterface(new GoogleDriveBridge(), "GoogleDrive");
        webView.addJavascriptInterface(new AndroidPrint(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح اختيار الصور", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }


    private void startGoogleSignIn() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(new Scope(DRIVE_FILE_SCOPE))
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        startActivityForResult(googleSignInClient.getSignInIntent(), GOOGLE_SIGN_IN_REQUEST);
    }

    private void signOutGoogle() {
        if (googleSignInClient == null) {
            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestScopes(new Scope(DRIVE_FILE_SCOPE)).build();
            googleSignInClient = GoogleSignIn.getClient(this, gso);
        }
        googleSignInClient.signOut().addOnCompleteListener(task -> {
            if (webView != null) webView.evaluateJavascript("window.onGoogleAccountChanged && window.onGoogleAccountChanged(null);", null);
            Toast.makeText(MainActivity.this, "تم تسجيل الخروج من حساب Google", Toast.LENGTH_SHORT).show();
        });
    }

    private void notifyGoogleAccount(GoogleSignInAccount account) {
        final String email = account == null || account.getEmail() == null ? "" : account.getEmail();
        final String safe = email.replace("\\","\\\\").replace("\"","\\\"");
        if (webView != null) webView.evaluateJavascript("window.onGoogleAccountChanged && window.onGoogleAccountChanged(" + (email.isEmpty()?"null":"\""+safe+"\"") + " );", null);
    }

    public class GoogleAccountBridge {
        @JavascriptInterface public void signIn() { runOnUiThread(() -> startGoogleSignIn()); }
        @JavascriptInterface public void signOut() { runOnUiThread(() -> signOutGoogle()); }
        @JavascriptInterface public String getEmail() {
            GoogleSignInAccount a = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            return a == null || a.getEmail() == null ? "" : a.getEmail();
        }
    }


    /**
     * Google Drive bridge. Uses the same Google account selected by Google Sign-In
     * and the narrow drive.file scope. Backups are stored in a dedicated folder
     * created by this application.
     */
    public class GoogleDriveBridge {
        @JavascriptInterface
        public void uploadBackup(final String json) {
            final GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (account == null) {
                driveCallback(false, "يرجى ربط حساب Google أولاً", "");
                return;
            }
            new Thread(() -> {
                try {
                    String token = getDriveToken(account);
                    String folderId = findOrCreateBackupFolder(token);
                    String fileId = findBackupFile(token, folderId);
                    if (fileId == null) {
                        createBackupFile(token, folderId, json == null ? "" : json);
                    } else {
                        // إنشاء النسخة الجديدة أولاً ثم حذف القديمة، لتجنب PATCH غير المدعوم
                        // في بعض إصدارات HttpURLConnection على Android.
                        createBackupFile(token, folderId, json == null ? "" : json);
                        deleteFile(token, fileId);
                    }
                    driveCallback(true, "تم حفظ النسخة الاحتياطية في Google Drive", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(new java.util.Date()));
                } catch (Exception e) {
                    driveCallback(false, "تعذر الحفظ في Google Drive: " + safeMessage(e), "");
                }
            }).start();
        }

        @JavascriptInterface
        public void restoreLatest() {
            final GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (account == null) {
                driveRestoreCallback(false, "يرجى ربط حساب Google أولاً", "");
                return;
            }
            new Thread(() -> {
                try {
                    String token = getDriveToken(account);
                    String folderId = findBackupFolder(token);
                    if (folderId == null) {
                        driveRestoreCallback(false, "لم توجد مجلدات نسخ احتياطية في Google Drive", "");
                        return;
                    }
                    String fileId = findBackupFile(token, folderId);
                    if (fileId == null) {
                        driveRestoreCallback(false, "لا توجد نسخة احتياطية في Google Drive", "");
                        return;
                    }
                    String json = downloadFile(token, fileId);
                    driveRestoreCallback(true, "تم تنزيل آخر نسخة من Google Drive", json);
                } catch (Exception e) {
                    driveRestoreCallback(false, "تعذر الاسترجاع من Google Drive: " + safeMessage(e), "");
                }
            }).start();
        }

        private String getDriveToken(GoogleSignInAccount account) throws Exception {
            if (account.getAccount() == null) throw new Exception("حساب Google غير متاح");
            String scope = "oauth2:" + DRIVE_FILE_SCOPE;
            return GoogleAuthUtil.getToken(MainActivity.this, account.getAccount(), scope);
        }

        private String findBackupFolder(String token) throws Exception {
            String q = "name='" + escapeQuery(DRIVE_FOLDER_NAME) + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
            JSONObject result = getJson("https://www.googleapis.com/drive/v3/files?q=" + java.net.URLEncoder.encode(q, "UTF-8") + "&pageSize=10&fields=files(id,name)", token);
            JSONArray files = result.optJSONArray("files");
            return files != null && files.length() > 0 ? files.getJSONObject(0).optString("id", null) : null;
        }

        private String findOrCreateBackupFolder(String token) throws Exception {
            String id = findBackupFolder(token);
            if (id != null) return id;
            JSONObject meta = new JSONObject();
            meta.put("name", DRIVE_FOLDER_NAME);
            meta.put("mimeType", "application/vnd.google-apps.folder");
            JSONObject created = postJson("https://www.googleapis.com/drive/v3/files?fields=id,name", token, meta.toString());
            String folderId = created.optString("id", "");
            if (TextUtils.isEmpty(folderId)) throw new Exception("تعذر إنشاء مجلد النسخ الاحتياطية");
            return folderId;
        }

        private String findBackupFile(String token, String folderId) throws Exception {
            if (TextUtils.isEmpty(folderId)) return null;
            String q = "'" + escapeQuery(folderId) + "' in parents and name='" + escapeQuery(DRIVE_BACKUP_NAME) + "' and trashed=false";
            JSONObject result = getJson("https://www.googleapis.com/drive/v3/files?q=" + java.net.URLEncoder.encode(q, "UTF-8") + "&pageSize=10&orderBy=modifiedTime desc&fields=files(id,name,modifiedTime)", token);
            JSONArray files = result.optJSONArray("files");
            return files != null && files.length() > 0 ? files.getJSONObject(0).optString("id", null) : null;
        }

        private void createBackupFile(String token, String folderId, String json) throws Exception {
            String boundary = "----AFZBoundary" + System.currentTimeMillis();
            URL url = new URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,modifiedTime");
            HttpURLConnection c = open(url, token, "POST");
            c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);
            c.setDoOutput(true);
            JSONObject meta = new JSONObject();
            meta.put("name", DRIVE_BACKUP_NAME);
            meta.put("parents", new JSONArray().put(folderId));
            byte[] body = multipartBody(boundary, meta.toString(), json);
            c.getOutputStream().write(body);
            checkResponse(c);
            c.disconnect();
        }

        private void deleteFile(String token, String fileId) throws Exception {
            URL url = new URL("https://www.googleapis.com/drive/v3/files/" + java.net.URLEncoder.encode(fileId, "UTF-8"));
            HttpURLConnection c = open(url, token, "DELETE");
            checkResponse(c);
            c.disconnect();
        }

        private String downloadFile(String token, String fileId) throws Exception {
            URL url = new URL("https://www.googleapis.com/drive/v3/files/" + java.net.URLEncoder.encode(fileId, "UTF-8") + "?alt=media");
            HttpURLConnection c = open(url, token, "GET");
            return readResponse(c);
        }

        private HttpURLConnection open(URL url, String token, String method) throws Exception {
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/json");
            return c;
        }

        private JSONObject getJson(String url, String token) throws Exception {
            HttpURLConnection c = open(new URL(url), token, "GET");
            return new JSONObject(readResponse(c));
        }

        private JSONObject postJson(String url, String token, String body) throws Exception {
            HttpURLConnection c = open(new URL(url), token, "POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
            return new JSONObject(readResponse(c));
        }

        private byte[] multipartBody(String boundary, String meta, String json) throws Exception {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            String p1 = "--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n";
            out.write(p1.getBytes(StandardCharsets.UTF_8));
            out.write(meta.getBytes(StandardCharsets.UTF_8));
            out.write(("\r\n--" + boundary + "\r\nContent-Type: application/json\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
            return out.toByteArray();
        }

        private String readResponse(HttpURLConnection c) throws Exception {
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String text = readStream(in);
            if (code < 200 || code >= 300) throw new Exception("Google Drive HTTP " + code + ": " + text);
            c.disconnect();
            return text;
        }

        private void checkResponse(HttpURLConnection c) throws Exception { readResponse(c); }

        private String readStream(InputStream in) throws Exception {
            if (in == null) return "";
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            r.close(); return b.toString();
        }

        private String escapeQuery(String s) {
            return String.valueOf(s).replace("\\", "\\\\").replace("'", "\\'");
        }

        private String safeMessage(Exception e) {
            String m = e.getMessage();
            return m == null ? "خطأ غير معروف" : m;
        }

        private void driveCallback(boolean ok, String message, String info) {
            String q1 = org.json.JSONObject.quote(message == null ? "" : message);
            String q2 = org.json.JSONObject.quote(info == null ? "" : info);
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(
                    "window.onDriveBackupResult && window.onDriveBackupResult(" + ok + "," + q1 + "," + q2 + ");", null);
            });
        }

        private void driveRestoreCallback(boolean ok, String message, String json) {
            String q1 = org.json.JSONObject.quote(message == null ? "" : message);
            String q2 = org.json.JSONObject.quote(json == null ? "" : json);
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(
                    "window.onDriveRestoreResult && window.onDriveRestoreResult(" + ok + "," + q1 + "," + q2 + ");", null);
            });
        }
    }

    public class AndroidBackup {
        @JavascriptInterface
        public boolean saveBackup(String json, String fileName) {
            String safe = fileName == null ? "AFRIQUIA-BACKUP.json" : fileName
                    .replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
            byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);

            try {
                // Android 10+ : MediaStore is the correct public-storage API and does
                // not require storage permission.  First use the normal pending-file
                // flow; if an OEM file manager has trouble with IS_PENDING, retry with
                // a directly visible Downloads entry.
                if (Build.VERSION.SDK_INT >= 29) {
                    Exception firstError = null;
                    try {
                        if (saveToDownloadsMediaStore(safe, data, true)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        firstError = e;
                    }
                    try {
                        if (saveToDownloadsMediaStore(safe, data, false)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        if (firstError == null) firstError = e;
                    }
                    throw new Exception(firstError == null
                            ? "تعذر إنشاء الملف في مجلد التنزيلات"
                            : "تعذر حفظ الملف في التنزيلات: " + firstError.getMessage());
                }

                // Android 9 and earlier: write to the public Downloads folder.
                if (Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(
                            new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},
                            WRITE_STORAGE_REQUEST));
                    throw new Exception("اسمح للتطبيق بالوصول إلى التخزين ثم اضغط حفظ النسخة الاحتياطية مرة أخرى");
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                }
                if (!file.exists() || file.length() != data.length) {
                    throw new Exception("لم يكتمل حفظ الملف");
                }
                showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                return true;
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "خطأ غير معروف" : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "فشل حفظ النسخة الاحتياطية: " + msg, Toast.LENGTH_LONG).show());
                return false;
            }
        }

        private boolean saveToDownloadsMediaStore(String requestedName, byte[] data, boolean pending) throws Exception {
            String safe = requestedName;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            if (pending) values.put(MediaStore.Downloads.IS_PENDING, 1);

            // احذف نسخة سابقة بنفس الاسم حتى لا ينشئ Android ملفات متكررة مثل (1), (2)...
            try {
                getContentResolver().delete(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{safe, Environment.DIRECTORY_DOWNLOADS + "/"}
                );
            } catch (Exception ignored) {}

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("تعذر إنشاء ملف في التنزيلات");
            boolean success = false;
            try {
                OutputStream out = getContentResolver().openOutputStream(uri, "w");
                if (out == null) throw new IOException("تعذر فتح ملف التنزيل");
                try {
                    out.write(data);
                    out.flush();
                } finally {
                    try { out.close(); } catch (Exception ignored) {}
                }

                if (pending) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    int updated = getContentResolver().update(uri, done, null, null);
                    if (updated <= 0) throw new IOException("تعذر إظهار الملف في التنزيلات");
                }
                success = true;
                return true;
            } finally {
                if (!success && pending) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }
        }

        private void showBackupToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
    }

    /**
     * Creates a real PDF from the HTML generated by the app and saves it directly
     * into the Android Downloads folder. This replaces the old afriquia:// link,
     * which caused Android's "No app on this device can open that link" message.
     */
    public class AndroidPrint {
        @JavascriptInterface
        public void savePdf(final String html, final String requestedName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "لا توجد بيانات لإنشاء PDF", Toast.LENGTH_LONG).show());
                return;
            }
            final String safeName = makePdfName(requestedName);
            runOnUiThread(() -> createPdf(html, safeName));
        }

        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            // Keep the existing thermal/HTML print entry point working.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String title) {
            // On phones without a thermal printer integration, save a PDF instead of
            // showing an error. The document remains available in Downloads.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        private String makePdfName(String name) {
            String safe = name == null ? "document.pdf" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            return safe;
        }
    }

    private void createPdf(final String html, final String fileName) {
        try {
            if (pdfWebView != null) {
                try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            }
            pdfWebView = new WebView(MainActivity.this);
            configurePdfWebView(pdfWebView);
            // Keep the PDF WebView laid out at the real screen size. A 1x1 WebView
            // can produce a blank/narrow PDF on some Android WebView versions.
            pdfWebView.setVisibility(WebView.VISIBLE);
            pdfWebView.setAlpha(0f);
            addContentView(pdfWebView, new android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            pdfWebView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    // Give WebView a moment to finish layout/images before creating the PDF.
                    view.postDelayed(() -> {
                        view.measure(
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().widthPixels, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().heightPixels, android.view.View.MeasureSpec.AT_MOST));
                        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
                        writePdf(view, fileName);
                    }, 700);
                }
            });
            pdfWebView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void configurePdfWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
    }

    private void writePdf(final WebView view, final String fileName) {
        if (Build.VERSION.SDK_INT < 21) {
            Toast.makeText(this, "إنشاء PDF يحتاج Android 5.0 أو أحدث", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            final PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(fileName.replace(".pdf", ""));
            final PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("afriquia_pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            final PdfTarget target = createPdfTarget(fileName);
            if (target == null || target.pfd == null) throw new IOException("تعذر إنشاء ملف PDF في التنزيلات");

            adapter.onLayout(null, attrs, null, new PrintDocumentAdapter.LayoutResultCallback() {
                @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, target.pfd, null, new PrintDocumentAdapter.WriteResultCallback() {
                        @Override public void onWriteFinished(PageRange[] pages) {
                            finishPdfTarget(target, true);
                            cleanupPdfWebView();
                        }
                        @Override public void onWriteFailed(CharSequence error) {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                            Toast.makeText(MainActivity.this, "فشل إنشاء PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                        }
                        @Override public void onWriteCancelled() {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                        }
                    });
                }
                @Override public void onLayoutFailed(CharSequence error) {
                    finishPdfTarget(target, false);
                    cleanupPdfWebView();
                    Toast.makeText(MainActivity.this, "تعذر تجهيز PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                }
            }, null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            cleanupPdfWebView();
        }
    }

    private static class PdfTarget {
        Uri uri;
        File file;
        ParcelFileDescriptor pfd;
    }

    private PdfTarget createPdfTarget(String fileName) throws Exception {
        PdfTarget t = new PdfTarget();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            t.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (t.uri == null) throw new IOException("تعذر إنشاء الملف في التنزيلات");
            t.pfd = getContentResolver().openFileDescriptor(t.uri, "w");
        } else {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, WRITE_STORAGE_REQUEST);
                throw new IOException("اسمح للتطبيق بالوصول إلى التخزين ثم أعد المحاولة");
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد التنزيلات");
            t.file = new File(dir, fileName);
            t.pfd = ParcelFileDescriptor.open(t.file, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY);
        }
        if (t.pfd == null) throw new IOException("تعذر فتح ملف PDF");
        return t;
    }

    private void finishPdfTarget(PdfTarget target, boolean success) {
        try { if (target.pfd != null) target.pfd.close(); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 29 && target.uri != null) {
            try {
                if (success) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(target.uri, done, null, null);
                    Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                } else {
                    getContentResolver().delete(target.uri, null, null);
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر إتمام حفظ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (success && target.file != null) {
            Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
        }
    }

    private void cleanupPdfWebView() {
        if (pdfWebView != null) {
            try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            pdfWebView = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_SIGN_IN_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(com.google.android.gms.common.api.ApiException.class);
                    notifyGoogleAccount(account);
                    Toast.makeText(this, "تم ربط التطبيق بحساب Google: " + account.getEmail(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    notifyGoogleAccount(null);
                    Toast.makeText(this, "تعذر ربط حساب Google", Toast.LENGTH_LONG).show();
                }
            } else {
                notifyGoogleAccount(null);
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override protected void onDestroy() {
        cleanupPdfWebView();
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
