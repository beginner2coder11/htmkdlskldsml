package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.print.PrintDocumentInfo;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView pdfWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int WRITE_STORAGE_REQUEST = 1002;
    private static final int BACKUP_CREATE_DOCUMENT_REQUEST = 1003;
    private byte[] pendingBackupData;
    private String pendingBackupFileName;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception ignored) {
                Toast.makeText(MainActivity.this, "تعذر فتح الملف للتنزيل", Toast.LENGTH_LONG).show();
            }
        });
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.addJavascriptInterface(new AndroidPrint(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح اختيار الصور", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }

    public class AndroidBackup {
        @JavascriptInterface
        public boolean saveBackup(String json, String fileName) {
            String safe = fileName == null ? "AFRIQUIA-BACKUP.json" : fileName
                    .replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
            byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);

            try {
                // Android 10+ : MediaStore is the correct public-storage API and does
                // not require storage permission.  First use the normal pending-file
                // flow; if an OEM file manager has trouble with IS_PENDING, retry with
                // a directly visible Downloads entry.
                if (Build.VERSION.SDK_INT >= 29) {
                    Exception firstError = null;
                    try {
                        if (saveToDownloadsMediaStore(safe, data, true)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        firstError = e;
                    }
                    try {
                        if (saveToDownloadsMediaStore(safe, data, false)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        if (firstError == null) firstError = e;
                    }
                    // بعض واجهات Android المخصصة قد تمنع الكتابة المباشرة إلى Downloads.
                    // في هذه الحالة افتح نافذة حفظ النظام كحل احتياطي، بدل إظهار فشل للمستخدم.
                    pendingBackupData = data;
                    pendingBackupFileName = safe;
                    runOnUiThread(() -> {
                        try {
                            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            intent.setType("application/json");
                            intent.putExtra(Intent.EXTRA_TITLE, safe);
                            startActivityForResult(intent, BACKUP_CREATE_DOCUMENT_REQUEST);
                            Toast.makeText(MainActivity.this,
                                    "اختر مجلد التنزيلات ثم اضغط حفظ", Toast.LENGTH_LONG).show();
                        } catch (Exception chooserError) {
                            Toast.makeText(MainActivity.this,
                                    "تعذر فتح نافذة حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                        }
                    });
                    return true;
                }

                // Android 9 and earlier: write to the public Downloads folder.
                if (Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(
                            new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},
                            WRITE_STORAGE_REQUEST));
                    throw new Exception("اسمح للتطبيق بالوصول إلى التخزين ثم اضغط حفظ النسخة الاحتياطية مرة أخرى");
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                }
                if (!file.exists() || file.length() != data.length) {
                    throw new Exception("لم يكتمل حفظ الملف");
                }
                showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                return true;
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "خطأ غير معروف" : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "فشل حفظ النسخة الاحتياطية: " + msg, Toast.LENGTH_LONG).show());
                return false;
            }
        }

        private boolean saveToDownloadsMediaStore(String requestedName, byte[] data, boolean pending) throws Exception {
            String safe = requestedName;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            if (pending) values.put(MediaStore.Downloads.IS_PENDING, 1);

            // احذف نسخة سابقة بنفس الاسم حتى لا ينشئ Android ملفات متكررة مثل (1), (2)...
            try {
                getContentResolver().delete(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{safe, Environment.DIRECTORY_DOWNLOADS + "/"}
                );
            } catch (Exception ignored) {}

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("تعذر إنشاء ملف في التنزيلات");
            boolean success = false;
            try {
                OutputStream out = getContentResolver().openOutputStream(uri, "w");
                if (out == null) throw new IOException("تعذر فتح ملف التنزيل");
                try {
                    out.write(data);
                    out.flush();
                } finally {
                    try { out.close(); } catch (Exception ignored) {}
                }

                if (pending) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    int updated = getContentResolver().update(uri, done, null, null);
                    if (updated <= 0) throw new IOException("تعذر إظهار الملف في التنزيلات");
                }
                success = true;
                return true;
            } finally {
                if (!success && pending) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }
        }

        private void showBackupToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
    }

    /**
     * Creates a real PDF from the HTML generated by the app and saves it directly
     * into the Android Downloads folder. This replaces the old afriquia:// link,
     * which caused Android's "No app on this device can open that link" message.
     */
    public class AndroidPrint {
        @JavascriptInterface
        public void savePdf(final String html, final String requestedName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "لا توجد بيانات لإنشاء PDF", Toast.LENGTH_LONG).show());
                return;
            }
            final String safeName = makePdfName(requestedName);
            runOnUiThread(() -> createPdf(html, safeName));
        }

        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            // Keep the existing thermal/HTML print entry point working.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String title) {
            // On phones without a thermal printer integration, save a PDF instead of
            // showing an error. The document remains available in Downloads.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        private String makePdfName(String name) {
            String safe = name == null ? "document.pdf" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            return safe;
        }
    }

    private void createPdf(final String html, final String fileName) {
        try {
            if (pdfWebView != null) {
                try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            }
            pdfWebView = new WebView(MainActivity.this);
            configurePdfWebView(pdfWebView);
            // Keep the PDF WebView laid out at the real screen size. A 1x1 WebView
            // can produce a blank/narrow PDF on some Android WebView versions.
            pdfWebView.setVisibility(WebView.VISIBLE);
            pdfWebView.setAlpha(0f);
            addContentView(pdfWebView, new android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            pdfWebView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    // Give WebView a moment to finish layout/images before creating the PDF.
                    view.postDelayed(() -> {
                        view.measure(
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().widthPixels, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().heightPixels, android.view.View.MeasureSpec.AT_MOST));
                        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
                        writePdf(view, fileName);
                    }, 700);
                }
            });
            pdfWebView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void configurePdfWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
    }

    private void writePdf(final WebView view, final String fileName) {
        if (Build.VERSION.SDK_INT < 21) {
            Toast.makeText(this, "إنشاء PDF يحتاج Android 5.0 أو أحدث", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            final PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(fileName.replace(".pdf", ""));
            final PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("afriquia_pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            final PdfTarget target = createPdfTarget(fileName);
            if (target == null || target.pfd == null) throw new IOException("تعذر إنشاء ملف PDF في التنزيلات");

            adapter.onLayout(null, attrs, null, new PrintDocumentAdapter.LayoutResultCallback() {
                @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, target.pfd, null, new PrintDocumentAdapter.WriteResultCallback() {
                        @Override public void onWriteFinished(PageRange[] pages) {
                            finishPdfTarget(target, true);
                            cleanupPdfWebView();
                        }
                        @Override public void onWriteFailed(CharSequence error) {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                            Toast.makeText(MainActivity.this, "فشل إنشاء PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                        }
                        @Override public void onWriteCancelled() {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                        }
                    });
                }
                @Override public void onLayoutFailed(CharSequence error) {
                    finishPdfTarget(target, false);
                    cleanupPdfWebView();
                    Toast.makeText(MainActivity.this, "تعذر تجهيز PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                }
            }, null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            cleanupPdfWebView();
        }
    }

    private static class PdfTarget {
        Uri uri;
        File file;
        ParcelFileDescriptor pfd;
    }

    private PdfTarget createPdfTarget(String fileName) throws Exception {
        PdfTarget t = new PdfTarget();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            t.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (t.uri == null) throw new IOException("تعذر إنشاء الملف في التنزيلات");
            t.pfd = getContentResolver().openFileDescriptor(t.uri, "w");
        } else {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, WRITE_STORAGE_REQUEST);
                throw new IOException("اسمح للتطبيق بالوصول إلى التخزين ثم أعد المحاولة");
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد التنزيلات");
            t.file = new File(dir, fileName);
            t.pfd = ParcelFileDescriptor.open(t.file, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY);
        }
        if (t.pfd == null) throw new IOException("تعذر فتح ملف PDF");
        return t;
    }

    private void finishPdfTarget(PdfTarget target, boolean success) {
        try { if (target.pfd != null) target.pfd.close(); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 29 && target.uri != null) {
            try {
                if (success) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(target.uri, done, null, null);
                    Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                } else {
                    getContentResolver().delete(target.uri, null, null);
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر إتمام حفظ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (success && target.file != null) {
            Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
        }
    }

    private void cleanupPdfWebView() {
        if (pdfWebView != null) {
            try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            pdfWebView = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        if (requestCode == BACKUP_CREATE_DOCUMENT_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupData != null) {
                Uri uri = data.getData();
                try {
                    OutputStream out = getContentResolver().openOutputStream(uri, "w");
                    if (out == null) throw new IOException("تعذر فتح ملف الحفظ");
                    try { out.write(pendingBackupData); out.flush(); } finally { try { out.close(); } catch (Exception ignored) {} }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "فشل حفظ النسخة الاحتياطية: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else if (resultCode != RESULT_OK) {
                Toast.makeText(this, "لم يتم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            }
            pendingBackupData = null;
            pendingBackupFileName = null;
        }
    }

    @Override protected void onDestroy() {
        cleanupPdfWebView();
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
