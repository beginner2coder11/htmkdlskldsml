package com.afriquia.cheques;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.print.PrintDocumentInfo;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Scope;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView pdfWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int WRITE_STORAGE_REQUEST = 1002;
    private static final int GOOGLE_DRIVE_SIGN_IN_REQUEST = 2001;
    private static final int GOOGLE_DRIVE_RECOVERABLE_REQUEST = 2002;
    private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String DRIVE_FOLDER_NAME = "AFRIQUIA BACKUPS";
    private final ExecutorService driveExecutor = Executors.newSingleThreadExecutor();
    private GoogleSignInAccount driveAccount;
    private String pendingDriveJson;
    private String pendingDriveFileName;
    private String pendingDriveOperation;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception ignored) {
                Toast.makeText(MainActivity.this, "تعذر فتح الملف للتنزيل", Toast.LENGTH_LONG).show();
            }
        });
        webView.addJavascriptInterface(new AndroidBackup(), "AndroidBackup");
        webView.addJavascriptInterface(new AndroidDrive(), "AndroidDrive");
        webView.addJavascriptInterface(new AndroidPrint(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_DRIVE_SIGN_IN_REQUEST) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                driveAccount = account;
                final String email = account != null && account.getEmail() != null ? account.getEmail() : "Google Drive";
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.onDriveAuthResult && window.onDriveAuthResult(true," + jsQuote(email) + ");", null);
                });
                if (pendingDriveOperation != null) {
                    String op = pendingDriveOperation;
                    pendingDriveOperation = null;
                    if ("upload".equals(op)) performDriveUpload(pendingDriveJson, pendingDriveFileName);
                    else if ("download".equals(op)) performDriveDownload();
                    pendingDriveJson = null;
                    pendingDriveFileName = null;
                }
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "تعذر تسجيل الدخول إلى Google" : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript("window.onDriveAuthResult && window.onDriveAuthResult(false," + jsQuote(msg) + ");", null));
            }
        } else if (requestCode == GOOGLE_DRIVE_RECOVERABLE_REQUEST) {
            if (pendingDriveOperation != null) {
                String op = pendingDriveOperation;
                pendingDriveOperation = null;
                if ("upload".equals(op)) performDriveUpload(pendingDriveJson, pendingDriveFileName);
                else if ("download".equals(op)) performDriveDownload();
            }
        } else if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private String jsQuote(String value) {
        if (value == null) value = "";
        return JSONObject.quote(value);
    }

    private void configureWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح اختيار الصور", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }

    public class AndroidBackup {
        @JavascriptInterface
        public boolean saveBackup(String json, String fileName) {
            String safe = fileName == null ? "AFRIQUIA-BACKUP.json" : fileName
                    .replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".json")) safe += ".json";
            byte[] data = json == null ? new byte[0] : json.getBytes(StandardCharsets.UTF_8);

            try {
                // Android 10+ : MediaStore is the correct public-storage API and does
                // not require storage permission.  First use the normal pending-file
                // flow; if an OEM file manager has trouble with IS_PENDING, retry with
                // a directly visible Downloads entry.
                if (Build.VERSION.SDK_INT >= 29) {
                    Exception firstError = null;
                    try {
                        if (saveToDownloadsMediaStore(safe, data, true)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        firstError = e;
                    }
                    try {
                        if (saveToDownloadsMediaStore(safe, data, false)) {
                            showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                            return true;
                        }
                    } catch (Exception e) {
                        if (firstError == null) firstError = e;
                    }
                    throw new Exception(firstError == null
                            ? "تعذر إنشاء الملف في مجلد التنزيلات"
                            : "تعذر حفظ الملف في التنزيلات: " + firstError.getMessage());
                }

                // Android 9 and earlier: write to the public Downloads folder.
                if (Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(
                            new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},
                            WRITE_STORAGE_REQUEST));
                    throw new Exception("اسمح للتطبيق بالوصول إلى التخزين ثم اضغط حفظ النسخة الاحتياطية مرة أخرى");
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                }
                if (!file.exists() || file.length() != data.length) {
                    throw new Exception("لم يكتمل حفظ الملف");
                }
                showBackupToast("تم تنزيل النسخة الاحتياطية في مجلد التنزيلات");
                return true;
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "خطأ غير معروف" : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "فشل حفظ النسخة الاحتياطية: " + msg, Toast.LENGTH_LONG).show());
                return false;
            }
        }

        private boolean saveToDownloadsMediaStore(String requestedName, byte[] data, boolean pending) throws Exception {
            String safe = requestedName;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            if (pending) values.put(MediaStore.Downloads.IS_PENDING, 1);

            // احذف نسخة سابقة بنفس الاسم حتى لا ينشئ Android ملفات متكررة مثل (1), (2)...
            try {
                getContentResolver().delete(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{safe, Environment.DIRECTORY_DOWNLOADS + "/"}
                );
            } catch (Exception ignored) {}

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("تعذر إنشاء ملف في التنزيلات");
            boolean success = false;
            try {
                OutputStream out = getContentResolver().openOutputStream(uri, "w");
                if (out == null) throw new IOException("تعذر فتح ملف التنزيل");
                try {
                    out.write(data);
                    out.flush();
                } finally {
                    try { out.close(); } catch (Exception ignored) {}
                }

                if (pending) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    int updated = getContentResolver().update(uri, done, null, null);
                    if (updated <= 0) throw new IOException("تعذر إظهار الملف في التنزيلات");
                }
                success = true;
                return true;
            } finally {
                if (!success && pending) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }
        }

        private void showBackupToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
    }

    /** Google Drive integration: OAuth sign-in + Drive REST API for app backups. */
    public class AndroidDrive {
        @JavascriptInterface
        public void connect() {
            runOnUiThread(() -> startDriveSignIn(null, null, null));
        }

        @JavascriptInterface
        public void uploadBackup(String json, String fileName) {
            if (json == null || json.trim().isEmpty()) {
                notifyDrive(false, "لا توجد بيانات لرفعها إلى Google Drive");
                return;
            }
            if (driveAccount == null) {
                pendingDriveJson = json;
                pendingDriveFileName = fileName == null ? "AFRIQUIA-BACKUP.json" : fileName;
                pendingDriveOperation = "upload";
                runOnUiThread(() -> startDriveSignIn(pendingDriveJson, pendingDriveFileName, "upload"));
                return;
            }
            performDriveUpload(json, fileName);
        }

        @JavascriptInterface
        public void downloadLatestBackup() {
            if (driveAccount == null) {
                pendingDriveOperation = "download";
                runOnUiThread(() -> startDriveSignIn(null, null, "download"));
                return;
            }
            performDriveDownload();
        }

        @JavascriptInterface
        public boolean isConnected() { return driveAccount != null; }

        private void startDriveSignIn(String json, String fileName, String operation) {
            if (operation != null) pendingDriveOperation = operation;
            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail()
                    .requestScopes(new Scope(DRIVE_SCOPE))
                    .build();
            GoogleSignInClient client = GoogleSignIn.getClient(MainActivity.this, gso);
            client.silentSignIn().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    driveAccount = task.getResult();
                    String email = driveAccount.getEmail() == null ? "Google Drive" : driveAccount.getEmail();
                    webView.evaluateJavascript("window.onDriveAuthResult && window.onDriveAuthResult(true," + jsQuote(email) + ");", null);
                    if (pendingDriveOperation != null) {
                        String op = pendingDriveOperation; pendingDriveOperation = null;
                        if ("upload".equals(op)) performDriveUpload(pendingDriveJson, pendingDriveFileName);
                        else if ("download".equals(op)) performDriveDownload();
                    }
                } else {
                    try {
                        startActivityForResult(client.getSignInIntent(), GOOGLE_DRIVE_SIGN_IN_REQUEST);
                    } catch (Exception e) {
                        notifyDrive(false, "تعذر فتح تسجيل الدخول إلى Google: " + e.getMessage());
                    }
                }
            });
        }
    }

    private void performDriveUpload(final String json, final String fileName) {
        driveExecutor.execute(() -> {
            try {
                String token = getDriveAccessToken();
                String folderId = findOrCreateDriveFolder(token);
                String safeName = (fileName == null || fileName.trim().isEmpty()) ? "AFRIQUIA-BACKUP.json" : fileName;
                JSONObject metadata = new JSONObject();
                metadata.put("name", safeName);
                metadata.put("mimeType", "application/json");
                JSONArray parents = new JSONArray(); parents.put(folderId); metadata.put("parents", parents);
                String boundary = "afz_boundary_" + System.currentTimeMillis();
                URL url = new URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true);
                c.setRequestProperty("Authorization", "Bearer " + token);
                c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);
                String bodyStart = "--" + boundary + "\\r\\n" +
                        "Content-Type: application/json; charset=UTF-8\\r\\n\\r\\n" + metadata.toString() + "\\r\\n" +
                        "--" + boundary + "\\r\\n" +
                        "Content-Type: application/json\\r\\n\\r\\n";
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                out.write(bodyStart.getBytes(StandardCharsets.UTF_8));
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.write(("\\r\\n--" + boundary + "--\\r\\n").getBytes(StandardCharsets.UTF_8));
                c.getOutputStream().write(out.toByteArray());
                int code = c.getResponseCode();
                String response = readResponse(c, code);
                c.disconnect();
                if (code < 200 || code >= 300) throw new IOException("Google Drive HTTP " + code + ": " + response);
                JSONObject created = new JSONObject(response);
                notifyDrive(true, "تم حفظ النسخة الاحتياطية في Google Drive: " + created.optString("name", safeName));
            } catch (UserRecoverableAuthException e) {
                pendingDriveOperation = "upload"; pendingDriveJson = json; pendingDriveFileName = fileName;
                runOnUiThread(() -> startActivityForResult(e.getIntent(), GOOGLE_DRIVE_RECOVERABLE_REQUEST));
            } catch (Exception e) {
                notifyDrive(false, "فشل الحفظ في Google Drive: " + errorMessage(e));
            }
        });
    }

    private void performDriveDownload() {
        driveExecutor.execute(() -> {
            try {
                String token = getDriveAccessToken();
                String folderId = findOrCreateDriveFolder(token);
                String q = "'" + folderId + "' in parents and mimeType='application/json' and trashed=false";
                String listUrl = "https://www.googleapis.com/drive/v3/files?q=" + URLEncoder.encode(q, "UTF-8") +
                        "&orderBy=modifiedTime%20desc&pageSize=1&fields=files(id,name,mimeType,modifiedTime)";
                HttpURLConnection c = authorizedConnection(listUrl, token, "GET");
                int code = c.getResponseCode(); String response = readResponse(c, code); c.disconnect();
                if (code < 200 || code >= 300) throw new IOException("Google Drive HTTP " + code + ": " + response);
                JSONArray files = new JSONObject(response).optJSONArray("files");
                if (files == null || files.length() == 0) throw new IOException("لا توجد نسخة احتياطية في Google Drive");
                JSONObject f = files.getJSONObject(0);
                String fileId = f.getString("id");
                String name = f.optString("name", "AFRIQUIA-BACKUP.json");
                URL url = new URL("https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media");
                c = authorizedConnection(url.toString(), token, "GET");
                code = c.getResponseCode(); response = readResponse(c, code); c.disconnect();
                if (code < 200 || code >= 300) throw new IOException("Google Drive HTTP " + code + ": " + response);
                final String json = response;
                runOnUiThread(() -> webView.evaluateJavascript("window.onDriveBackupDownloaded && window.onDriveBackupDownloaded(" + jsQuote(json) + "," + jsQuote(name) + ");", null));
            } catch (UserRecoverableAuthException e) {
                pendingDriveOperation = "download";
                runOnUiThread(() -> startActivityForResult(e.getIntent(), GOOGLE_DRIVE_RECOVERABLE_REQUEST));
            } catch (Exception e) {
                notifyDrive(false, "فشل استرجاع النسخة من Google Drive: " + errorMessage(e));
            }
        });
    }

    private String getDriveAccessToken() throws Exception {
        if (driveAccount == null) throw new IOException("يجب تسجيل الدخول إلى Google أولاً");
        return GoogleAuthUtil.getToken(this, driveAccount.getAccount(), "oauth2:" + DRIVE_SCOPE);
    }

    private String findOrCreateDriveFolder(String token) throws Exception {
        String q = "name='" + DRIVE_FOLDER_NAME.replace("'", "\\'") + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
        String listUrl = "https://www.googleapis.com/drive/v3/files?q=" + URLEncoder.encode(q, "UTF-8") + "&pageSize=1&fields=files(id,name)";
        HttpURLConnection c = authorizedConnection(listUrl, token, "GET");
        int code = c.getResponseCode(); String response = readResponse(c, code); c.disconnect();
        if (code < 200 || code >= 300) throw new IOException("Google Drive HTTP " + code + ": " + response);
        JSONArray files = new JSONObject(response).optJSONArray("files");
        if (files != null && files.length() > 0) return files.getJSONObject(0).getString("id");
        JSONObject metadata = new JSONObject(); metadata.put("name", DRIVE_FOLDER_NAME); metadata.put("mimeType", "application/vnd.google-apps.folder");
        c = authorizedConnection("https://www.googleapis.com/drive/v3/files", token, "POST");
        c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.getOutputStream().write(metadata.toString().getBytes(StandardCharsets.UTF_8));
        code = c.getResponseCode(); response = readResponse(c, code); c.disconnect();
        if (code < 200 || code >= 300) throw new IOException("تعذر إنشاء مجلد النسخ الاحتياطية: " + response);
        return new JSONObject(response).getString("id");
    }

    private HttpURLConnection authorizedConnection(String url, String token, String method) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method); c.setRequestProperty("Authorization", "Bearer " + token); c.setConnectTimeout(20000); c.setReadTimeout(30000); return c;
    }

    private String readResponse(HttpURLConnection c, int code) throws Exception {
        java.io.InputStream in = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close(); return out.toString("UTF-8");
    }

    private String errorMessage(Exception e) {
        String m = e.getMessage(); return m == null || m.trim().isEmpty() ? e.getClass().getSimpleName() : m;
    }

    private void notifyDrive(boolean ok, String message) {
        runOnUiThread(() -> webView.evaluateJavascript("window.onDriveResult && window.onDriveResult(" + (ok ? "true" : "false") + "," + jsQuote(message) + ");", null));
    }

    /**
     * Creates a real PDF from the HTML generated by the app and saves it directly
     * into the Android Downloads folder. This replaces the old afriquia:// link,
     * which caused Android's "No app on this device can open that link" message.
     */
    public class AndroidPrint {
        @JavascriptInterface
        public void savePdf(final String html, final String requestedName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "لا توجد بيانات لإنشاء PDF", Toast.LENGTH_LONG).show());
                return;
            }
            final String safeName = makePdfName(requestedName);
            runOnUiThread(() -> createPdf(html, safeName));
        }

        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            // Keep the existing thermal/HTML print entry point working.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String title) {
            // On phones without a thermal printer integration, save a PDF instead of
            // showing an error. The document remains available in Downloads.
            savePdf(html, title == null ? "document.pdf" : title + ".pdf");
        }

        private String makePdfName(String name) {
            String safe = name == null ? "document.pdf" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            return safe;
        }
    }

    private void createPdf(final String html, final String fileName) {
        try {
            if (pdfWebView != null) {
                try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            }
            pdfWebView = new WebView(MainActivity.this);
            configurePdfWebView(pdfWebView);
            // Keep the PDF WebView laid out at the real screen size. A 1x1 WebView
            // can produce a blank/narrow PDF on some Android WebView versions.
            pdfWebView.setVisibility(WebView.VISIBLE);
            pdfWebView.setAlpha(0f);
            addContentView(pdfWebView, new android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            pdfWebView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    // Give WebView a moment to finish layout/images before creating the PDF.
                    view.postDelayed(() -> {
                        view.measure(
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().widthPixels, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(view.getResources().getDisplayMetrics().heightPixels, android.view.View.MeasureSpec.AT_MOST));
                        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
                        writePdf(view, fileName);
                    }, 700);
                }
            });
            pdfWebView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void configurePdfWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowFileAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 16) s.setAllowUniversalAccessFromFileURLs(true);
    }

    private void writePdf(final WebView view, final String fileName) {
        if (Build.VERSION.SDK_INT < 21) {
            Toast.makeText(this, "إنشاء PDF يحتاج Android 5.0 أو أحدث", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            final PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(fileName.replace(".pdf", ""));
            final PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("afriquia_pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            final PdfTarget target = createPdfTarget(fileName);
            if (target == null || target.pfd == null) throw new IOException("تعذر إنشاء ملف PDF في التنزيلات");

            adapter.onLayout(null, attrs, null, new PrintDocumentAdapter.LayoutResultCallback() {
                @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, target.pfd, null, new PrintDocumentAdapter.WriteResultCallback() {
                        @Override public void onWriteFinished(PageRange[] pages) {
                            finishPdfTarget(target, true);
                            cleanupPdfWebView();
                        }
                        @Override public void onWriteFailed(CharSequence error) {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                            Toast.makeText(MainActivity.this, "فشل إنشاء PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                        }
                        @Override public void onWriteCancelled() {
                            finishPdfTarget(target, false);
                            cleanupPdfWebView();
                        }
                    });
                }
                @Override public void onLayoutFailed(CharSequence error) {
                    finishPdfTarget(target, false);
                    cleanupPdfWebView();
                    Toast.makeText(MainActivity.this, "تعذر تجهيز PDF" + (error == null ? "" : ": " + error), Toast.LENGTH_LONG).show();
                }
            }, null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            cleanupPdfWebView();
        }
    }

    private static class PdfTarget {
        Uri uri;
        File file;
        ParcelFileDescriptor pfd;
    }

    private PdfTarget createPdfTarget(String fileName) throws Exception {
        PdfTarget t = new PdfTarget();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            t.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (t.uri == null) throw new IOException("تعذر إنشاء الملف في التنزيلات");
            t.pfd = getContentResolver().openFileDescriptor(t.uri, "w");
        } else {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, WRITE_STORAGE_REQUEST);
                throw new IOException("اسمح للتطبيق بالوصول إلى التخزين ثم أعد المحاولة");
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد التنزيلات");
            t.file = new File(dir, fileName);
            t.pfd = ParcelFileDescriptor.open(t.file, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY);
        }
        if (t.pfd == null) throw new IOException("تعذر فتح ملف PDF");
        return t;
    }

    private void finishPdfTarget(PdfTarget target, boolean success) {
        try { if (target.pfd != null) target.pfd.close(); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 29 && target.uri != null) {
            try {
                if (success) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(target.uri, done, null, null);
                    Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                } else {
                    getContentResolver().delete(target.uri, null, null);
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر إتمام حفظ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (success && target.file != null) {
            Toast.makeText(this, "تم تنزيل PDF في مجلد التنزيلات", Toast.LENGTH_LONG).show();
        }
    }

    private void cleanupPdfWebView() {
        if (pdfWebView != null) {
            try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            pdfWebView = null;
        }
    }

    @Override protected void onDestroy() {
        cleanupPdfWebView();
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
