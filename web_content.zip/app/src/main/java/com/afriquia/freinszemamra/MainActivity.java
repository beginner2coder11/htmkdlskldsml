package com.afriquia.freinszemamra;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.os.Environment;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String USB_PERMISSION = "com.afriquia.freinszemamra.USB_PERMISSION";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private UsbDevice pendingUsbDevice;
    private String pendingHtml;
    private String pendingJobName;
    private int pendingWidthPx = 576;
    private static final int REQ_READ_CONTACTS = 7001;
    private static final int REQ_PICK_CONTACT = 7002;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && device != null && pendingUsbDevice != null && device.getDeviceId() == pendingUsbDevice.getDeviceId()) {
                UsbDevice d = pendingUsbDevice;
                pendingUsbDevice = null;
                renderAndPrintThermal(pendingHtml, pendingJobName, pendingWidthPx, d);
            } else {
                Toast.makeText(MainActivity.this, "لم يتم منح إذن USB للطابعة", Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("afriquia://savepdf")) {
                    view.evaluateJavascript("(function(){return JSON.stringify({html:localStorage.getItem('__afriquia_pdf_html')||'',name:localStorage.getItem('__afriquia_pdf_name')||'Afriquia-Document.pdf'});})()", value -> {
                        try {
                            String json = value == null ? "" : value;
                            if (json.startsWith("\"") && json.endsWith("\"")) json = new org.json.JSONTokener(json).nextValue().toString();
                            JSONObject obj = new JSONObject(json);
                            String html = obj.optString("html", "");
                            String name = obj.optString("name", "Afriquia-Document.pdf");
                            if (html.isEmpty()) { Toast.makeText(MainActivity.this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show(); return; }
                            createAndSavePdf(html, name);
                            view.evaluateJavascript("localStorage.removeItem('__afriquia_pdf_html');localStorage.removeItem('__afriquia_pdf_name');", null);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    return true;
                }
                return false;
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** فتح جهة الاتصال لاختيار اسم ورقم الزبون من دفتر الهاتف. */
    private void pickCustomerContact() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_READ_CONTACTS);
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(intent, REQ_PICK_CONTACT);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح جهات الاتصال", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pickCustomerContact();
            } else {
                Toast.makeText(this, "يجب السماح للتطبيق بالوصول إلى جهات الاتصال لاختيار الزبون", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_CONTACT || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = "";
        String phone = "";
        try (android.database.Cursor cursor = getContentResolver().query(uri,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int phoneIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                if (nameIdx >= 0) name = cursor.getString(nameIdx);
                if (phoneIdx >= 0) phone = cursor.getString(phoneIdx);
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة جهة الاتصال", Toast.LENGTH_LONG).show();
            return;
        }
        final String jsName = JSONObject.quote(name == null ? "" : name);
        final String jsPhone = JSONObject.quote(phone == null ? "" : phone);
        webView.post(() -> webView.evaluateJavascript("setCustomerFromContact(" + jsName + "," + jsPhone + ");", null));
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(context);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { Toast.makeText(context, "خدمة الطباعة غير متاحة", Toast.LENGTH_LONG).show(); return; }
                        String name = (jobName == null || jobName.trim().isEmpty()) ? "Afriquia Stock - Invoice" : jobName;
                        pm.print(name, view.createPrintDocumentAdapter(name), new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build());
                    }
                });
                WebSettings ps = printWeb.getSettings();
                ps.setJavaScriptEnabled(false);
                ps.setDomStorageEnabled(false);
                printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String jobName) {
            runOnUiThread(() -> chooseThermalPrinter(html, jobName));
        }

        @JavascriptInterface
        public boolean isReady() {
            return true;
        }

        @JavascriptInterface
        public void savePdf(final String html, final String fileName) {
            runOnUiThread(() -> {
                if (html == null || html.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show();
                    return;
                }
                createAndSavePdf(html, fileName);
            });
        }

        @JavascriptInterface
        public void pickCustomerContact() {
            runOnUiThread(MainActivity.this::pickCustomerContact);
        }
    }

    /**
     * Creates a PDF using Android's WebView print engine instead of drawing the
     * WebView manually on PdfDocument. The old approach could hang/produce an
     * empty document on some Android/WebView versions because the off-screen
     * WebView had not finished layout when draw() was called.
     */
    private void createAndSavePdf(String html, String fileName) {
        if (html == null || html.trim().isEmpty()) {
            Toast.makeText(this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show();
            return;
        }

        final String safeName = safePdfName(fileName);
        final WebView pdfWeb = new WebView(this);
        pdfWeb.setBackgroundColor(Color.WHITE);
        WebSettings settings = pdfWeb.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        pdfWeb.setWebViewClient(new WebViewClient() {
            private boolean started = false;

            @Override public void onPageFinished(WebView view, String url) {
                if (started) return;
                started = true;
                // Let WebView finish image/font/layout work before creating the
                // print adapter. This is intentionally short; no UI is blocked.
                view.postDelayed(() -> exportWebViewToPdf(view, safeName), 500);
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(MainActivity.this, "تعذر تحميل محتوى PDF: " + description, Toast.LENGTH_LONG).show();
                view.destroy();
            }
        });

        // Base URL is important because the invoice HTML references logo.svg.
        pdfWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void exportWebViewToPdf(final WebView webView, final String fileName) {
        if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && webView.isDestroyed())) return;

        final Uri uri;
        try {
            uri = createPendingPdfUri(fileName);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء ملف PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            webView.destroy();
            return;
        }

        final PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(fileName);
        final PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("afriquia_pdf", "Afriquia PDF", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();

        adapter.onLayout(null, attributes, null, new PrintDocumentAdapter.LayoutResultCallback() {
            @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                if (info == null) {
                    failPendingPdf(uri, webView, "لم يتم تجهيز صفحات PDF");
                    return;
                }
                try {
                    ParcelFileDescriptor pfd = openPdfOutput(uri);
                    if (pfd == null) throw new Exception("تعذر فتح ملف PDF للكتابة");
                    adapter.onWrite(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES}, pfd,
                            new CancellationSignal(), new PrintDocumentAdapter.WriteResultCallback() {
                                @Override public void onWriteFinished(android.print.PageRange[] pages) {
                                    try { pfd.close(); } catch (Exception ignored) {}
                                    finishPendingPdf(uri, webView, fileName);
                                }

                                @Override public void onWriteFailed(CharSequence error) {
                                    try { pfd.close(); } catch (Exception ignored) {}
                                    failPendingPdf(uri, webView, error == null ? "تعذر كتابة PDF" : error.toString());
                                }

                                @Override public void onWriteCancelled() {
                                    try { pfd.close(); } catch (Exception ignored) {}
                                    failPendingPdf(uri, webView, "تم إلغاء إنشاء PDF");
                                }
                            });
                } catch (Exception e) {
                    failPendingPdf(uri, webView, e.getMessage() == null ? "تعذر كتابة PDF" : e.getMessage());
                }
            }

            @Override public void onLayoutFailed(CharSequence error) {
                failPendingPdf(uri, webView, error == null ? "تعذر تجهيز PDF" : error.toString());
            }

            @Override public void onLayoutCancelled() {
                failPendingPdf(uri, webView, "تم إلغاء إنشاء PDF");
            }
        }, null);
    }

    private ParcelFileDescriptor openPdfOutput(Uri uri) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            return getContentResolver().openFileDescriptor(uri, "w");
        }
        File file = new File(uri.getPath());
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY);
    }

    private Uri createPendingPdfUri(String fileName) throws Exception {
        if (Build.VERSION.SDK_INT < 29) {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
            File file = new File(dir, fileName);
            return Uri.fromFile(file);
        }
        android.content.ContentValues values = new android.content.ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("تعذر إنشاء ملف في مجلد التنزيلات");
        return uri;
    }

    private void finishPendingPdf(Uri uri, WebView webView, String fileName) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues done = new android.content.ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            Toast.makeText(this, "تم تحميل PDF في مجلد التنزيلات: " + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            Toast.makeText(this, "تعذر إنهاء حفظ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
    }

    private void failPendingPdf(Uri uri, WebView webView, String message) {
        try {
            if (Build.VERSION.SDK_INT >= 29) getContentResolver().delete(uri, null, null);
            else {
                try {
                    File f = new File(uri.getPath());
                    if (f.exists()) f.delete();
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        try { webView.destroy(); } catch (Exception ignored) {}
        Toast.makeText(this, "تعذر إنشاء PDF: " + message, Toast.LENGTH_LONG).show();
    }

    private String safePdfName(String fileName) {
        String name = (fileName == null || fileName.trim().isEmpty()) ? "Afriquia-Document.pdf" : fileName.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")) name += ".pdf";
        return name;
    }

    private void savePdfDocument(PdfDocument document, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء ملف في مجلد التنزيلات");
            try {
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new Exception("تعذر فتح ملف PDF");
                try (OutputStream out = os) {
                    document.writeTo(out);
                    out.flush();
                }
                android.content.ContentValues done = new android.content.ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } catch (Exception e) {
                try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                throw e;
            }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
            File file = new File(dir, fileName);
            try (OutputStream os = new FileOutputStream(file)) {
                document.writeTo(os);
                os.flush();
            }
            android.media.MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, new String[]{"application/pdf"}, null);
        }
        runOnUiThread(() -> Toast.makeText(this, "تم تحميل PDF في مجلد التنزيلات: " + fileName, Toast.LENGTH_LONG).show());
    }

    private void chooseThermalPrinter(String html, String jobName) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Object> devices = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 7001);
        }
        try {
            android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isEnabled()) {
                for (android.bluetooth.BluetoothDevice d : adapter.getBondedDevices()) {
                    labels.add("Bluetooth • " + (d.getName() == null ? "طابعة" : d.getName()) + "\n" + d.getAddress());
                    devices.add(d);
                }
            }
        } catch (SecurityException ignored) {}

        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        if (usb != null) {
            for (UsbDevice d : usb.getDeviceList().values()) {
                labels.add("USB • " + (d.getProductName() == null ? "طابعة USB" : d.getProductName()));
                devices.add(d);
            }
        }

        if (devices.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("الطابعة الحرارية")
                    .setMessage("لم يتم العثور على طابعة.\n\nBluetooth: قم بإقران الطابعة من إعدادات الهاتف أولاً.\nUSB: وصل الطابعة بواسطة OTG.")
                    .setPositiveButton("حسناً", null).show();
            return;
        }

        final String[] items = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("اختر الطابعة الحرارية")
                .setItems(items, (dialog, which) -> choosePaperWidth(html, jobName, devices.get(which)))
                .setNegativeButton("إلغاء", null).show();
    }

    private void choosePaperWidth(String html, String jobName, Object device) {
        final String[] widths = {"80 mm (576px)", "58 mm (384px)"};
        new AlertDialog.Builder(this).setTitle("عرض الورق")
                .setSingleChoiceItems(widths, 0, (dialog, which) -> {
                    pendingWidthPx = which == 0 ? 576 : 384;
                    dialog.dismiss();
                    if (device instanceof UsbDevice) {
                        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
                        if (usb != null && usb.hasPermission((UsbDevice) device)) {
                            renderAndPrintThermal(html, jobName, pendingWidthPx, (UsbDevice) device);
                        } else if (usb != null) {
                            pendingUsbDevice = (UsbDevice) device;
                            pendingHtml = html;
                            pendingJobName = jobName;
                            usb.requestPermission((UsbDevice) device, android.app.PendingIntent.getBroadcast(this, 9001,
                                    new Intent(USB_PERMISSION).setPackage(getPackageName()),
                                    Build.VERSION.SDK_INT >= 31 ? android.app.PendingIntent.FLAG_MUTABLE : 0));
                        }
                    } else if (device instanceof android.bluetooth.BluetoothDevice) {
                        renderAndPrintThermal(html, jobName, pendingWidthPx, (android.bluetooth.BluetoothDevice) device);
                    }
                }).setNegativeButton("إلغاء", null).show();
    }

    private void renderAndPrintThermal(String html, String jobName, int widthPx, Object device) {
        final WebView receipt = new WebView(this);
        receipt.setBackgroundColor(Color.WHITE);
        WebSettings s = receipt.getSettings();
        s.setJavaScriptEnabled(false);
        s.setDomStorageEnabled(false);
        receipt.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    try {
                        int height = Math.max(300, (int) Math.ceil(view.getContentHeight() * view.getScale()));
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(widthPx, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(height, android.view.View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, widthPx, height);
                        Bitmap bitmap = Bitmap.createBitmap(widthPx, height, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(Color.WHITE);
                        view.draw(canvas);
                        byte[] data = buildEscPos(bitmap, widthPx);
                        if (device instanceof android.bluetooth.BluetoothDevice) {
                            printBluetooth((android.bluetooth.BluetoothDevice) device, data);
                        } else if (device instanceof UsbDevice) {
                            printUsb((UsbDevice) device, data);
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر تجهيز الفاتورة للطابعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    } finally {
                        receipt.destroy();
                    }
                }, 350);
            }
        });
        receipt.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private byte[] buildEscPos(Bitmap source, int targetWidth) {
        Bitmap scaled = source;
        if (source.getWidth() != targetWidth) {
            int h = Math.max(1, source.getHeight() * targetWidth / source.getWidth());
            scaled = Bitmap.createScaledBitmap(source, targetWidth, h, true);
        }
        int width = scaled.getWidth();
        int height = scaled.getHeight();
        int bytesPerRow = (width + 7) / 8;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0x1B); out.write('@');
        out.write(0x1B); out.write('a'); out.write(1); // center
        out.write(0x1D); out.write('v'); out.write('0'); out.write(0);
        out.write(bytesPerRow & 0xFF); out.write((bytesPerRow >> 8) & 0xFF);
        out.write(height & 0xFF); out.write((height >> 8) & 0xFF);
        for (int y = 0; y < height; y++) {
            for (int bx = 0; bx < bytesPerRow; bx++) {
                int b = 0;
                for (int bit = 0; bit < 8; bit++) {
                    int x = bx * 8 + bit;
                    if (x >= width) continue;
                    int c = scaled.getPixel(x, y);
                    int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
                    if (gray < 170) b |= (1 << (7 - bit));
                }
                out.write(b);
            }
        }
        out.write('\n'); out.write('\n'); out.write('\n');
        out.write(0x1D); out.write('V'); out.write(66); out.write(0); // partial cut
        if (scaled != source) scaled.recycle();
        source.recycle();
        return out.toByteArray();
    }

    private void printBluetooth(android.bluetooth.BluetoothDevice device, byte[] data) {
        new Thread(() -> {
            android.bluetooth.BluetoothSocket socket = null;
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> Toast.makeText(this, "اسمح للتطبيق بالوصول إلى Bluetooth ثم أعد المحاولة", Toast.LENGTH_LONG).show());
                    return;
                }
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream os = socket.getOutputStream();
                os.write(data); os.flush();
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة Bluetooth", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل Bluetooth: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally { if (socket != null) try { socket.close(); } catch (Exception ignored) {} }
        }).start();
    }

    private void printUsb(UsbDevice device, byte[] data) {
        new Thread(() -> {
            UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbDeviceConnection conn = null;
            UsbInterface intf = null;
            try {
                if (manager == null || !manager.hasPermission(device)) throw new Exception("لا يوجد إذن USB");
                conn = manager.openDevice(device);
                if (conn == null) throw new Exception("تعذر فتح الطابعة");
                UsbEndpoint outEndpoint = null;
                for (int i = 0; i < device.getInterfaceCount(); i++) {
                    UsbInterface candidate = device.getInterface(i);
                    for (int j = 0; j < candidate.getEndpointCount(); j++) {
                        UsbEndpoint ep = candidate.getEndpoint(j);
                        if (ep.getDirection() == UsbConstants.USB_DIR_OUT && ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            intf = candidate; outEndpoint = ep; break;
                        }
                    }
                    if (outEndpoint != null) break;
                }
                if (outEndpoint == null) throw new Exception("لم يتم العثور على منفذ طباعة USB");
                if (!conn.claimInterface(intf, true)) throw new Exception("تعذر حجز منفذ USB");
                int offset = 0;
                while (offset < data.length) {
                    int len = Math.min(4096, data.length - offset);
                    int sent = conn.bulkTransfer(outEndpoint, data, offset, len, 10000);
                    if (sent <= 0) throw new Exception("فشل إرسال بيانات USB");
                    offset += sent;
                }
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة USB", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل USB: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) { if (intf != null) try { conn.releaseInterface(intf); } catch (Exception ignored) {} conn.close(); }
            }
        }).start();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
