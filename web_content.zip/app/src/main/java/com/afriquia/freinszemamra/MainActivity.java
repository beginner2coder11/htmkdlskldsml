package com.afriquia.freinszemamra;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String USB_PERMISSION = "com.afriquia.freinszemamra.USB_PERMISSION";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private UsbDevice pendingUsbDevice;
    private String pendingHtml;
    private String pendingJobName;
    private int pendingWidthPx = 576;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && device != null && pendingUsbDevice != null && device.getDeviceId() == pendingUsbDevice.getDeviceId()) {
                UsbDevice d = pendingUsbDevice;
                pendingUsbDevice = null;
                renderAndPrintThermal(pendingHtml, pendingJobName, pendingWidthPx, d);
            } else {
                Toast.makeText(MainActivity.this, "لم يتم منح إذن USB للطابعة", Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("afriquia-pdf://save")) {
                    final String requestedName = extractQueryParameter(url, "name");
                    view.evaluateJavascript("window.__pendingPdfHtml || ''", value -> {
                        String html = decodeJsString(value);
                        if (html == null || html.trim().isEmpty()) {
                            Toast.makeText(MainActivity.this, "تعذر تجهيز محتوى PDF", Toast.LENGTH_LONG).show();
                            return;
                        }
                        createAndSavePdf(html, requestedName);
                    });
                    return true;
                }
                return false;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Keep a diagnostic flag, but PDF download also has a URL-scheme fallback
                // so it works even when a WebView build does not expose the JS bridge.
                view.evaluateJavascript("window.__ANDROID_PDF_READY__ = !!(window.AndroidPrint && typeof window.AndroidPrint.savePdf === 'function');", null);
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(context);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { Toast.makeText(context, "خدمة الطباعة غير متاحة", Toast.LENGTH_LONG).show(); return; }
                        String name = (jobName == null || jobName.trim().isEmpty()) ? "Afriquia Stock - Invoice" : jobName;
                        pm.print(name, view.createPrintDocumentAdapter(name), new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build());
                    }
                });
                WebSettings ps = printWeb.getSettings();
                ps.setJavaScriptEnabled(false);
                ps.setDomStorageEnabled(false);
                printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String jobName) {
            runOnUiThread(() -> chooseThermalPrinter(html, jobName));
        }

        @JavascriptInterface
        public void savePdf(final String html, final String fileName) {
            runOnUiThread(() -> {
                try { createAndSavePdf(html, fileName); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "خطأ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }

        @JavascriptInterface
        public String getPdfStatus() {
            return "ready";
        }
    }

    private String extractQueryParameter(String url, String key) {
        try {
            android.net.Uri u = android.net.Uri.parse(url);
            String v = u.getQueryParameter(key);
            return v == null ? "Afriquia-Document.pdf" : v;
        } catch (Exception e) {
            return "Afriquia-Document.pdf";
        }
    }

    private String decodeJsString(String value) {
        if (value == null || value.equals("null")) return "";
        try {
            return new org.json.JSONTokener(value).nextValue().toString();
        } catch (Exception e) {
            return value;
        }
    }

    private void createAndSavePdf(String html, String fileName) {
        if (html == null || html.trim().isEmpty()) {
            Toast.makeText(this, "لا توجد بيانات لإنشاء PDF", Toast.LENGTH_LONG).show();
            return;
        }
        final WebView pdfWeb = new WebView(this);
        pdfWeb.setBackgroundColor(Color.WHITE);
        WebSettings settings = pdfWeb.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(true);
        pdfWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    PdfDocument document = new PdfDocument();
                    try {
                        final int pageWidth = 595;
                        final int pageHeight = 842;
                        final float scale = pageWidth / 794f;
                        int contentWidth = 794;
                        int contentHeight = Math.max(1123, (int)Math.ceil(view.getContentHeight() * view.getScale()));
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(contentWidth, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(contentHeight, android.view.View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, contentWidth, contentHeight);

                        int pageCount = Math.max(1, (int)Math.ceil(contentHeight / (pageHeight / scale)));
                        for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create();
                            PdfDocument.Page page = document.startPage(info);
                            Canvas canvas = page.getCanvas();
                            canvas.drawColor(Color.WHITE);
                            canvas.save();
                            canvas.scale(scale, scale);
                            canvas.translate(0, -pageIndex * (pageHeight / scale));
                            view.draw(canvas);
                            canvas.restore();
                            document.finishPage(page);
                        }

                        String safeName = (fileName == null || fileName.trim().isEmpty()) ? "Afriquia-Document" : fileName.trim();
                        if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";
                        savePdfDocument(document, safeName);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    } finally {
                        document.close();
                        pdfWeb.destroy();
                    }
                }, 400);
            }
        });
        pdfWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void savePdfDocument(PdfDocument document, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء ملف في مجلد التنزيلات");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new Exception("تعذر فتح ملف PDF");
                document.writeTo(os);
            }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
            File file = new File(dir, fileName);
            try (OutputStream os = new FileOutputStream(file)) {
                document.writeTo(os);
            }
        }
        runOnUiThread(() -> Toast.makeText(this, "تم حفظ PDF في التنزيلات: " + fileName, Toast.LENGTH_LONG).show());
    }

    private void chooseThermalPrinter(String html, String jobName) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Object> devices = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 7001);
        }
        try {
            android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isEnabled()) {
                for (android.bluetooth.BluetoothDevice d : adapter.getBondedDevices()) {
                    labels.add("Bluetooth • " + (d.getName() == null ? "طابعة" : d.getName()) + "\n" + d.getAddress());
                    devices.add(d);
                }
            }
        } catch (SecurityException ignored) {}

        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        if (usb != null) {
            for (UsbDevice d : usb.getDeviceList().values()) {
                labels.add("USB • " + (d.getProductName() == null ? "طابعة USB" : d.getProductName()));
                devices.add(d);
            }
        }

        if (devices.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("الطابعة الحرارية")
                    .setMessage("لم يتم العثور على طابعة.\n\nBluetooth: قم بإقران الطابعة من إعدادات الهاتف أولاً.\nUSB: وصل الطابعة بواسطة OTG.")
                    .setPositiveButton("حسناً", null).show();
            return;
        }

        final String[] items = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("اختر الطابعة الحرارية")
                .setItems(items, (dialog, which) -> choosePaperWidth(html, jobName, devices.get(which)))
                .setNegativeButton("إلغاء", null).show();
    }

    private void choosePaperWidth(String html, String jobName, Object device) {
        final String[] widths = {"80 mm (576px)", "58 mm (384px)"};
        new AlertDialog.Builder(this).setTitle("عرض الورق")
                .setSingleChoiceItems(widths, 0, (dialog, which) -> {
                    pendingWidthPx = which == 0 ? 576 : 384;
                    dialog.dismiss();
                    if (device instanceof UsbDevice) {
                        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
                        if (usb != null && usb.hasPermission((UsbDevice) device)) {
                            renderAndPrintThermal(html, jobName, pendingWidthPx, (UsbDevice) device);
                        } else if (usb != null) {
                            pendingUsbDevice = (UsbDevice) device;
                            pendingHtml = html;
                            pendingJobName = jobName;
                            usb.requestPermission((UsbDevice) device, android.app.PendingIntent.getBroadcast(this, 9001,
                                    new Intent(USB_PERMISSION).setPackage(getPackageName()),
                                    Build.VERSION.SDK_INT >= 31 ? android.app.PendingIntent.FLAG_MUTABLE : 0));
                        }
                    } else if (device instanceof android.bluetooth.BluetoothDevice) {
                        renderAndPrintThermal(html, jobName, pendingWidthPx, (android.bluetooth.BluetoothDevice) device);
                    }
                }).setNegativeButton("إلغاء", null).show();
    }

    private void renderAndPrintThermal(String html, String jobName, int widthPx, Object device) {
        final WebView receipt = new WebView(this);
        receipt.setBackgroundColor(Color.WHITE);
        WebSettings s = receipt.getSettings();
        s.setJavaScriptEnabled(false);
        s.setDomStorageEnabled(false);
        receipt.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    try {
                        int height = Math.max(300, (int) Math.ceil(view.getContentHeight() * view.getScale()));
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(widthPx, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(height, android.view.View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, widthPx, height);
                        Bitmap bitmap = Bitmap.createBitmap(widthPx, height, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(Color.WHITE);
                        view.draw(canvas);
                        byte[] data = buildEscPos(bitmap, widthPx);
                        if (device instanceof android.bluetooth.BluetoothDevice) {
                            printBluetooth((android.bluetooth.BluetoothDevice) device, data);
                        } else if (device instanceof UsbDevice) {
                            printUsb((UsbDevice) device, data);
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر تجهيز الفاتورة للطابعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    } finally {
                        receipt.destroy();
                    }
                }, 350);
            }
        });
        receipt.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private byte[] buildEscPos(Bitmap source, int targetWidth) {
        Bitmap scaled = source;
        if (source.getWidth() != targetWidth) {
            int h = Math.max(1, source.getHeight() * targetWidth / source.getWidth());
            scaled = Bitmap.createScaledBitmap(source, targetWidth, h, true);
        }
        int width = scaled.getWidth();
        int height = scaled.getHeight();
        int bytesPerRow = (width + 7) / 8;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0x1B); out.write('@');
        out.write(0x1B); out.write('a'); out.write(1); // center
        out.write(0x1D); out.write('v'); out.write('0'); out.write(0);
        out.write(bytesPerRow & 0xFF); out.write((bytesPerRow >> 8) & 0xFF);
        out.write(height & 0xFF); out.write((height >> 8) & 0xFF);
        for (int y = 0; y < height; y++) {
            for (int bx = 0; bx < bytesPerRow; bx++) {
                int b = 0;
                for (int bit = 0; bit < 8; bit++) {
                    int x = bx * 8 + bit;
                    if (x >= width) continue;
                    int c = scaled.getPixel(x, y);
                    int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
                    if (gray < 170) b |= (1 << (7 - bit));
                }
                out.write(b);
            }
        }
        out.write('\n'); out.write('\n'); out.write('\n');
        out.write(0x1D); out.write('V'); out.write(66); out.write(0); // partial cut
        if (scaled != source) scaled.recycle();
        source.recycle();
        return out.toByteArray();
    }

    private void printBluetooth(android.bluetooth.BluetoothDevice device, byte[] data) {
        new Thread(() -> {
            android.bluetooth.BluetoothSocket socket = null;
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> Toast.makeText(this, "اسمح للتطبيق بالوصول إلى Bluetooth ثم أعد المحاولة", Toast.LENGTH_LONG).show());
                    return;
                }
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream os = socket.getOutputStream();
                os.write(data); os.flush();
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة Bluetooth", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل Bluetooth: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally { if (socket != null) try { socket.close(); } catch (Exception ignored) {} }
        }).start();
    }

    private void printUsb(UsbDevice device, byte[] data) {
        new Thread(() -> {
            UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbDeviceConnection conn = null;
            UsbInterface intf = null;
            try {
                if (manager == null || !manager.hasPermission(device)) throw new Exception("لا يوجد إذن USB");
                conn = manager.openDevice(device);
                if (conn == null) throw new Exception("تعذر فتح الطابعة");
                UsbEndpoint outEndpoint = null;
                for (int i = 0; i < device.getInterfaceCount(); i++) {
                    UsbInterface candidate = device.getInterface(i);
                    for (int j = 0; j < candidate.getEndpointCount(); j++) {
                        UsbEndpoint ep = candidate.getEndpoint(j);
                        if (ep.getDirection() == UsbConstants.USB_DIR_OUT && ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            intf = candidate; outEndpoint = ep; break;
                        }
                    }
                    if (outEndpoint != null) break;
                }
                if (outEndpoint == null) throw new Exception("لم يتم العثور على منفذ طباعة USB");
                if (!conn.claimInterface(intf, true)) throw new Exception("تعذر حجز منفذ USB");
                int offset = 0;
                while (offset < data.length) {
                    int len = Math.min(4096, data.length - offset);
                    int sent = conn.bulkTransfer(outEndpoint, data, offset, len, 10000);
                    if (sent <= 0) throw new Exception("فشل إرسال بيانات USB");
                    offset += sent;
                }
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة USB", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل USB: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) { if (intf != null) try { conn.releaseInterface(intf); } catch (Exception ignored) {} conn.close(); }
            }
        }).start();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
