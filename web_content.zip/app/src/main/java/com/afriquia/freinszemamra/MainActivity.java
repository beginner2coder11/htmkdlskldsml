package com.afriquia.freinszemamra;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.os.Environment;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.SystemClock;
import android.os.Bundle;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String USB_PERMISSION = "com.afriquia.freinszemamra.USB_PERMISSION";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private UsbDevice pendingUsbDevice;
    private String pendingHtml;
    private String pendingJobName;
    private int pendingWidthPx = 576;
    private static final int REQ_READ_CONTACTS = 7001;
    private static final int REQ_FILE_CHOOSER = 8001;
    private static final int REQ_CAMERA_PERMISSION = 8002;
    private ValueCallback<Uri[]> pendingFileCallback;
    private Uri pendingCameraUri;
    private static final int REQ_PICK_CONTACT = 7002;
    private boolean pickContactForCredit = false;
    private static final String NOTIF_CHANNEL_ID = "afriquia_checks";
    private static final int NOTIF_REQ = 8123;
    private static final int REQ_CREATE_BACKUP = 9001;
    private String pendingBackupJson;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && device != null && pendingUsbDevice != null && device.getDeviceId() == pendingUsbDevice.getDeviceId()) {
                UsbDevice d = pendingUsbDevice;
                pendingUsbDevice = null;
                renderAndPrintThermal(pendingHtml, pendingJobName, pendingWidthPx, d);
            } else {
                Toast.makeText(MainActivity.this, "لم يتم منح إذن USB للطابعة", Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION));
        webView = new WebView(this);
        setContentView(webView);
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
        }
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERMISSION);
                } else {
                    openImageChooser();
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("afriquia://savepdf")) {
                    view.evaluateJavascript("(function(){return JSON.stringify({html:localStorage.getItem('__afriquia_pdf_html')||'',name:localStorage.getItem('__afriquia_pdf_name')||'Afriquia-Document.pdf'});})()", value -> {
                        try {
                            String json = value == null ? "" : value;
                            if (json.startsWith("\"") && json.endsWith("\"")) json = new org.json.JSONTokener(json).nextValue().toString();
                            JSONObject obj = new JSONObject(json);
                            String html = obj.optString("html", "");
                            String name = obj.optString("name", "Afriquia-Document.pdf");
                            if (html.isEmpty()) { Toast.makeText(MainActivity.this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show(); return; }
                            createAndSavePdf(html, name);
                            view.evaluateJavascript("localStorage.removeItem('__afriquia_pdf_html');localStorage.removeItem('__afriquia_pdf_name');", null);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    return true;
                }
                return false;
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.addJavascriptInterface(new NotificationBridge(this), "AndroidNotifications");
        webView.addJavascriptInterface(new BackupBridge(this), "AndroidBackup");
        webView.addJavascriptInterface(new ExpenseBridge(this), "AndroidExpenses");
        webView.loadUrl("file:///android_asset/index.html");
        webView.postDelayed(() -> webView.evaluateJavascript("(function(){try{if(window.AndroidNotifications&&typeof AndroidNotifications.syncChecks==='function'){AndroidNotifications.syncChecks(JSON.stringify((window.db&&db.checks)||[]));}}catch(e){}})();", null), 1200);
    }


    public static class ExpenseBridge {
        private final Context context;
        private static final String PREF = "afriquia_expenses_native";
        private static final String KEY = "expenses_json";
        ExpenseBridge(Context context) { this.context = context.getApplicationContext(); }
        @JavascriptInterface public void saveExpenses(String json) {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, json == null ? "[]" : json).apply();
        }
        @JavascriptInterface public String loadExpenses() {
            return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(NOTIF_CHANNEL_ID, "تنبيهات الشيكات", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيهات مواعيد الشيكات القادمة");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    public class BackupBridge {
        private final Context context;
        BackupBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void exportBackup(String json) {
            pendingBackupJson = json == null ? "{}" : json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "AFRIQUIA-BACKUP-" +
                    new java.text.SimpleDateFormat("yyyy-MM-dd-HHmm", java.util.Locale.US).format(new java.util.Date()) + ".json");
            startActivityForResult(intent, REQ_CREATE_BACKUP);
        }
    }

    public class NotificationBridge {
        private final Context context;
        NotificationBridge(Context context) { this.context = context; }
        @JavascriptInterface public void syncChecks(String json) {
            getSharedPreferences("afriquia_notifications", MODE_PRIVATE).edit().putString("checks", json == null ? "[]" : json).apply();
            scheduleCheckAlarm(context);
            notifyUpcomingChecks(context, false);
        }
        @JavascriptInterface public void requestPermission() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
            }
        }
    }

    private static void scheduleCheckAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(context, CheckNotificationReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, NOTIF_REQ, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 9); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    static void notifyUpcomingChecks(Context context, boolean fromAlarm) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        String json = context.getSharedPreferences("afriquia_notifications", Context.MODE_PRIVATE).getString("checks", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            java.util.Calendar today = java.util.Calendar.getInstance();
            today.set(java.util.Calendar.HOUR_OF_DAY,0); today.set(java.util.Calendar.MINUTE,0); today.set(java.util.Calendar.SECOND,0); today.set(java.util.Calendar.MILLISECOND,0);
            long todayMs = today.getTimeInMillis();
            long untilMs = todayMs + 3L*24*60*60*1000;
            String todayKey = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(today.getTime());
            String lastKey = context.getSharedPreferences("afriquia_notifications", Context.MODE_PRIVATE).getString("last_day", "");
            if (todayKey.equals(lastKey) && fromAlarm) return;
            int count=0; String first="";
            for(int i=0;i<arr.length();i++){
                JSONObject c=arr.optJSONObject(i); if(c==null || !"pending".equals(c.optString("status"))) continue;
                String ds=c.optString("date",""); if(ds.length()<10) continue;
                java.util.Date d=new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(ds.substring(0,10));
                if(d.getTime()>=todayMs && d.getTime()<=untilMs){ count++; if(first.isEmpty()) first="شيك رقم "+c.optString("number","")+" — "+c.optString("beneficiary",""); }
            }
            if(count==0)return;
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
            Intent open=new Intent(context, MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent content=PendingIntent.getActivity(context, NOTIF_REQ, open, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            String title="🔔 تنبيه الشيكات"; String text=count==1?first:"لديك "+count+" شيكات قريبة من موعد الدخول إلى البنك";
            NotificationCompat.Builder b=new NotificationCompat.Builder(context, NOTIF_CHANNEL_ID).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text+"\nافتح التطبيق للاطلاع على التفاصيل.")).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(content);
            nm.notify(1001,b.build());
            context.getSharedPreferences("afriquia_notifications", Context.MODE_PRIVATE).edit().putString("last_day",todayKey).apply();
        } catch(Exception ignored) {}
    }

    /** فتح جهة الاتصال لاختيار اسم ورقم الزبون من دفتر الهاتف. */
    private void openImageChooser() {
        try {
            Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
            gallery.addCategory(Intent.CATEGORY_OPENABLE);
            gallery.setType("image/*");

            Intent camera = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            if (camera.resolveActivity(getPackageManager()) != null) {
                String fileName = "AFRIQUIA-" + System.currentTimeMillis() + ".jpg";
                android.content.ContentValues values = new android.content.ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AFRIQUIA");
                }
                pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (pendingCameraUri != null) {
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                    camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            }

            Intent chooser = Intent.createChooser(gallery, "اختر صورة من الهاتف أو الكاميرا");
            if (camera.resolveActivity(getPackageManager()) != null && pendingCameraUri != null) {
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
            }
            startActivityForResult(chooser, REQ_FILE_CHOOSER);
        } catch (Exception e) {
            if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
            pendingCameraUri = null;
            Toast.makeText(this, "تعذر فتح الكاميرا أو معرض الصور", Toast.LENGTH_LONG).show();
        }
    }

    private void pickCustomerContact() {
        pickContactForCredit = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_READ_CONTACTS);
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(intent, REQ_PICK_CONTACT);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح جهات الاتصال", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openImageChooser();
            } else {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = null;
                Toast.makeText(this, "يمكنك السماح بالكاميرا لاختيار أو التقاط صورة", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode == REQ_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pickCustomerContact();
            } else {
                Toast.makeText(this, "يجب السماح للتطبيق بالوصول إلى جهات الاتصال لاختيار الزبون", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void pickCreditContact() {
        pickContactForCredit = true;
        pickCustomerContact();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (pendingCameraUri != null) {
                    results = new Uri[]{pendingCameraUri};
                }
            }
            if (resultCode != RESULT_OK && pendingCameraUri != null) {
                try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
            }
            if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(results);
            pendingFileCallback = null;
            pendingCameraUri = null;
            return;
        }

        if (requestCode == REQ_PICK_CONTACT) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
            Uri uri = data.getData();
            String name = "";
            String phone = "";
            try (android.database.Cursor cursor = getContentResolver().query(uri,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                    int phoneIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    if (nameIdx >= 0) name = cursor.getString(nameIdx);
                    if (phoneIdx >= 0) phone = cursor.getString(phoneIdx);
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر قراءة جهة الاتصال", Toast.LENGTH_LONG).show();
                return;
            }
            final String jsName = JSONObject.quote(name == null ? "" : name);
            final String jsPhone = JSONObject.quote(phone == null ? "" : phone);
            final boolean forCredit = pickContactForCredit;
            pickContactForCredit = false;
            webView.post(() -> webView.evaluateJavascript((forCredit ? "setCreditCustomerFromContact(" : "setCustomerFromContact(") + jsName + "," + jsPhone + ");", null));
            return;
        }

        if (requestCode == REQ_CREATE_BACKUP) {
            try {
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("تعذر فتح ملف الحفظ");
                        out.write((pendingBackupJson == null ? "{}" : pendingBackupJson).getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show();
                } else if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(this, "تم إلغاء حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                pendingBackupJson = null;
            }
        }
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(context);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { Toast.makeText(context, "خدمة الطباعة غير متاحة", Toast.LENGTH_LONG).show(); return; }
                        String name = (jobName == null || jobName.trim().isEmpty()) ? "Afriquia Stock - Invoice" : jobName;
                        pm.print(name, view.createPrintDocumentAdapter(name), new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build());
                    }
                });
                WebSettings ps = printWeb.getSettings();
                ps.setJavaScriptEnabled(false);
                ps.setDomStorageEnabled(false);
                printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void showThermalPrinterDialog(final String html, final String jobName) {
            runOnUiThread(() -> chooseThermalPrinter(html, jobName));
        }

        @JavascriptInterface
        public boolean isReady() {
            return true;
        }

        @JavascriptInterface
        public void savePdf(final String html, final String fileName) {
            runOnUiThread(() -> {
                if (html == null || html.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show();
                    return;
                }
                createAndSavePdf(html, fileName);
            });
        }

        @JavascriptInterface
        public void pickCustomerContact() {
            runOnUiThread(MainActivity.this::pickCustomerContact);
        }

        @JavascriptInterface
        public void pickCreditContact() {
            runOnUiThread(MainActivity.this::pickCreditContact);
        }
    }

    /**
     * Creates a PDF using Android's WebView print engine instead of drawing the
     * WebView manually on PdfDocument. The old approach could hang/produce an
     * empty document on some Android/WebView versions because the off-screen
     * WebView had not finished layout when draw() was called.
     */
    /**
     * Export HTML to PDF without Android's PrintDocumentAdapter.
     * The print adapter can hang on some WebView/Android combinations.
     * We render the fully laid-out WebView into Android PdfDocument pages,
     * then save the resulting file directly to Downloads.
     */
    private void createAndSavePdf(String html, String fileName) {
        if (html == null || html.trim().isEmpty()) {
            Toast.makeText(this, "محتوى PDF فارغ", Toast.LENGTH_LONG).show();
            return;
        }

        final String safeName = safePdfName(fileName);
        final WebView pdfWeb = new WebView(this);
        pdfWeb.setBackgroundColor(Color.WHITE);

        WebSettings settings = pdfWeb.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setTextZoom(100);

        pdfWeb.setWebViewClient(new WebViewClient() {
            private boolean exported = false;

            @Override public void onPageFinished(WebView view, String url) {
                if (exported) return;
                exported = true;

                // Give WebView one frame to complete layout, images and fonts.
                view.postDelayed(() -> {
                    try {
                        exportRenderedWebViewToPdf(view, safeName);
                    } catch (Exception e) {
                        try { view.destroy(); } catch (Exception ignored) {}
                        Toast.makeText(MainActivity.this,
                                "تعذر إنشاء PDF: " + (e.getMessage() == null ? "خطأ غير معروف" : e.getMessage()),
                                Toast.LENGTH_LONG).show();
                    }
                }, 350);
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                try { view.destroy(); } catch (Exception ignored) {}
                Toast.makeText(MainActivity.this,
                        "تعذر تحميل محتوى PDF: " + description, Toast.LENGTH_LONG).show();
            }
        });

        pdfWeb.loadDataWithBaseURL(
                "file:///android_asset/",
                html,
                "text/html",
                "UTF-8",
                null
        );
    }

    private void exportRenderedWebViewToPdf(WebView view, String fileName) throws Exception {
        final int pageWidth = 595;   // A4 width in PDF points
        final int pageHeight = 842;  // A4 height in PDF points

        // Measure the complete HTML document, not just the visible WebView area.
        view.measure(
                View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );
        int contentWidth = view.getMeasuredWidth();
        int contentHeight = Math.max(view.getMeasuredHeight(), 1);

        view.layout(0, 0, contentWidth, contentHeight);

        PdfDocument document = new PdfDocument();
        int pageCount = (int) Math.ceil(contentHeight / (double) pageHeight);

        try {
            for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                int top = pageIndex * pageHeight;
                PdfDocument.PageInfo pageInfo =
                        new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create();
                PdfDocument.Page page = document.startPage(pageInfo);

                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                canvas.save();
                canvas.clipRect(0, 0, pageWidth, pageHeight);
                canvas.translate(0, -top);
                view.draw(canvas);
                canvas.restore();

                document.finishPage(page);
            }

            savePdfDocument(document, fileName);
        } finally {
            document.close();
            try { view.destroy(); } catch (Exception ignored) {}
        }
    }

    private String safePdfName(String fileName) {
        String name = (fileName == null || fileName.trim().isEmpty()) ? "Afriquia-Document.pdf" : fileName.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")) name += ".pdf";
        return name;
    }

    private void savePdfDocument(PdfDocument document, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء ملف في مجلد التنزيلات");
            try {
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new Exception("تعذر فتح ملف PDF");
                try (OutputStream out = os) {
                    document.writeTo(out);
                    out.flush();
                }
                android.content.ContentValues done = new android.content.ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } catch (Exception e) {
                try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                throw e;
            }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
            File file = new File(dir, fileName);
            try (OutputStream os = new FileOutputStream(file)) {
                document.writeTo(os);
                os.flush();
            }
            android.media.MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, new String[]{"application/pdf"}, null);
        }
        runOnUiThread(() -> Toast.makeText(this, "تم تحميل PDF في مجلد التنزيلات: " + fileName, Toast.LENGTH_LONG).show());
    }

    private void chooseThermalPrinter(String html, String jobName) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Object> devices = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 7001);
        }
        try {
            android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isEnabled()) {
                for (android.bluetooth.BluetoothDevice d : adapter.getBondedDevices()) {
                    labels.add("Bluetooth • " + (d.getName() == null ? "طابعة" : d.getName()) + "\n" + d.getAddress());
                    devices.add(d);
                }
            }
        } catch (SecurityException ignored) {}

        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        if (usb != null) {
            for (UsbDevice d : usb.getDeviceList().values()) {
                labels.add("USB • " + (d.getProductName() == null ? "طابعة USB" : d.getProductName()));
                devices.add(d);
            }
        }

        if (devices.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("الطابعة الحرارية")
                    .setMessage("لم يتم العثور على طابعة.\n\nBluetooth: قم بإقران الطابعة من إعدادات الهاتف أولاً.\nUSB: وصل الطابعة بواسطة OTG.")
                    .setPositiveButton("حسناً", null).show();
            return;
        }

        final String[] items = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("اختر الطابعة الحرارية")
                .setItems(items, (dialog, which) -> choosePaperWidth(html, jobName, devices.get(which)))
                .setNegativeButton("إلغاء", null).show();
    }

    private void choosePaperWidth(String html, String jobName, Object device) {
        final String[] widths = {"80 mm (576px)", "58 mm (384px)"};
        new AlertDialog.Builder(this).setTitle("عرض الورق")
                .setSingleChoiceItems(widths, 0, (dialog, which) -> {
                    pendingWidthPx = which == 0 ? 576 : 384;
                    dialog.dismiss();
                    if (device instanceof UsbDevice) {
                        UsbManager usb = (UsbManager) getSystemService(Context.USB_SERVICE);
                        if (usb != null && usb.hasPermission((UsbDevice) device)) {
                            renderAndPrintThermal(html, jobName, pendingWidthPx, (UsbDevice) device);
                        } else if (usb != null) {
                            pendingUsbDevice = (UsbDevice) device;
                            pendingHtml = html;
                            pendingJobName = jobName;
                            usb.requestPermission((UsbDevice) device, android.app.PendingIntent.getBroadcast(this, 9001,
                                    new Intent(USB_PERMISSION).setPackage(getPackageName()),
                                    Build.VERSION.SDK_INT >= 31 ? android.app.PendingIntent.FLAG_MUTABLE : 0));
                        }
                    } else if (device instanceof android.bluetooth.BluetoothDevice) {
                        renderAndPrintThermal(html, jobName, pendingWidthPx, (android.bluetooth.BluetoothDevice) device);
                    }
                }).setNegativeButton("إلغاء", null).show();
    }

    private void renderAndPrintThermal(String html, String jobName, int widthPx, Object device) {
        final WebView receipt = new WebView(this);
        receipt.setBackgroundColor(Color.WHITE);
        WebSettings s = receipt.getSettings();
        s.setJavaScriptEnabled(false);
        s.setDomStorageEnabled(false);
        receipt.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    try {
                        int height = Math.max(300, (int) Math.ceil(view.getContentHeight() * view.getScale()));
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(widthPx, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(height, android.view.View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, widthPx, height);
                        Bitmap bitmap = Bitmap.createBitmap(widthPx, height, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(Color.WHITE);
                        view.draw(canvas);
                        byte[] data = buildEscPos(bitmap, widthPx);
                        if (device instanceof android.bluetooth.BluetoothDevice) {
                            printBluetooth((android.bluetooth.BluetoothDevice) device, data);
                        } else if (device instanceof UsbDevice) {
                            printUsb((UsbDevice) device, data);
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر تجهيز الفاتورة للطابعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    } finally {
                        receipt.destroy();
                    }
                }, 350);
            }
        });
        receipt.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private byte[] buildEscPos(Bitmap source, int targetWidth) {
        Bitmap scaled = source;
        if (source.getWidth() != targetWidth) {
            int h = Math.max(1, source.getHeight() * targetWidth / source.getWidth());
            scaled = Bitmap.createScaledBitmap(source, targetWidth, h, true);
        }
        int width = scaled.getWidth();
        int height = scaled.getHeight();
        int bytesPerRow = (width + 7) / 8;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0x1B); out.write('@');
        out.write(0x1B); out.write('a'); out.write(1); // center
        out.write(0x1D); out.write('v'); out.write('0'); out.write(0);
        out.write(bytesPerRow & 0xFF); out.write((bytesPerRow >> 8) & 0xFF);
        out.write(height & 0xFF); out.write((height >> 8) & 0xFF);
        for (int y = 0; y < height; y++) {
            for (int bx = 0; bx < bytesPerRow; bx++) {
                int b = 0;
                for (int bit = 0; bit < 8; bit++) {
                    int x = bx * 8 + bit;
                    if (x >= width) continue;
                    int c = scaled.getPixel(x, y);
                    int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
                    if (gray < 170) b |= (1 << (7 - bit));
                }
                out.write(b);
            }
        }
        out.write('\n'); out.write('\n'); out.write('\n');
        out.write(0x1D); out.write('V'); out.write(66); out.write(0); // partial cut
        if (scaled != source) scaled.recycle();
        source.recycle();
        return out.toByteArray();
    }

    private void printBluetooth(android.bluetooth.BluetoothDevice device, byte[] data) {
        new Thread(() -> {
            android.bluetooth.BluetoothSocket socket = null;
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> Toast.makeText(this, "اسمح للتطبيق بالوصول إلى Bluetooth ثم أعد المحاولة", Toast.LENGTH_LONG).show());
                    return;
                }
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream os = socket.getOutputStream();
                os.write(data); os.flush();
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة Bluetooth", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل Bluetooth: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally { if (socket != null) try { socket.close(); } catch (Exception ignored) {} }
        }).start();
    }

    private void printUsb(UsbDevice device, byte[] data) {
        new Thread(() -> {
            UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbDeviceConnection conn = null;
            UsbInterface intf = null;
            try {
                if (manager == null || !manager.hasPermission(device)) throw new Exception("لا يوجد إذن USB");
                conn = manager.openDevice(device);
                if (conn == null) throw new Exception("تعذر فتح الطابعة");
                UsbEndpoint outEndpoint = null;
                for (int i = 0; i < device.getInterfaceCount(); i++) {
                    UsbInterface candidate = device.getInterface(i);
                    for (int j = 0; j < candidate.getEndpointCount(); j++) {
                        UsbEndpoint ep = candidate.getEndpoint(j);
                        if (ep.getDirection() == UsbConstants.USB_DIR_OUT && ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            intf = candidate; outEndpoint = ep; break;
                        }
                    }
                    if (outEndpoint != null) break;
                }
                if (outEndpoint == null) throw new Exception("لم يتم العثور على منفذ طباعة USB");
                if (!conn.claimInterface(intf, true)) throw new Exception("تعذر حجز منفذ USB");
                int offset = 0;
                while (offset < data.length) {
                    int len = Math.min(4096, data.length - offset);
                    int sent = conn.bulkTransfer(outEndpoint, data, offset, len, 10000);
                    if (sent <= 0) throw new Exception("فشل إرسال بيانات USB");
                    offset += sent;
                }
                runOnUiThread(() -> Toast.makeText(this, "تم إرسال الفاتورة إلى طابعة USB", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "فشل USB: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) { if (intf != null) try { conn.releaseInterface(intf); } catch (Exception ignored) {} conn.close(); }
            }
        }).start();
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(function(){try{if(typeof clearQuickSaleSearchFields===\'function\')clearQuickSaleSearchFields();var a=document.querySelector(\'.page.active\');if(a&&a.id!==\'home\'){if(typeof show===\'function\')show(\'home\');return \'handled\';}}catch(e){}return \'exit\';})()", value -> {
            if (value == null || value.contains("exit")) super.onBackPressed();
        });
    }

}
