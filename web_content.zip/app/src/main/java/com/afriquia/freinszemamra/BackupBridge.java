package com.afriquia.freinszemamra;

import android.webkit.JavascriptInterface;

/** جسر بسيط للنسخ الاحتياطي عبر مدير ملفات Android، مع إمكانية اختيار Google Drive. */
public final class BackupBridge {
    private final MainActivity activity;
    public BackupBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public boolean isReady() { return true; }
    @JavascriptInterface public String getBridgeVersion() { return "AFZ-BACKUP-2.0"; }
    @JavascriptInterface public void saveToGoogleDrive(String json) { activity.saveBackupToDrive(json); }
    @JavascriptInterface public void restoreFromGoogleDrive() { activity.restoreBackupFromDrive(); }
    @JavascriptInterface public void signInToGoogleDrive() { activity.saveBackupToDrive("{}"); }
}
