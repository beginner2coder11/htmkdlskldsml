package com.afriquia.freinszemamra;

import android.content.Context;
import android.webkit.JavascriptInterface;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Native JavaScript bridge for application backup and restore.
 * Exposed to WebView as window.AndroidBackup.
 */
public final class BackupBridge {
    private final MainActivity activity;

    public BackupBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean isReady() {
        return true;
    }

    @JavascriptInterface
    public String getBridgeVersion() {
        return "AFZ-BACKUP-BRIDGE-1.7";
    }

    @JavascriptInterface
    public void saveToGoogleDrive(final String json) {
        activity.startBackupSave(json);
    }

    @JavascriptInterface
    public void restoreFromGoogleDrive() {
        activity.runOnUiThread(activity::openBackupRestorePicker);
    }

    /** Persist the latest app database inside Android app storage. This survives
     * normal app updates and WebView/localStorage resets. */
    @JavascriptInterface
    public void savePersistentData(final String json) {
        try {
            File f = new File(activity.getFilesDir(), "afz_auto_backup.json");
            try (FileOutputStream out = new FileOutputStream(f, false)) {
                out.write((json == null ? "{}" : json).getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
        } catch (Exception ignored) { }
    }

    /** Return the last automatically persisted database, or an empty string. */
    @JavascriptInterface
    public String getPersistentData() {
        try {
            File f = new File(activity.getFilesDir(), "afz_auto_backup.json");
            if (!f.exists()) return "";
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] b = new byte[(int)Math.min(f.length(), 20L * 1024L * 1024L)];
                int n = in.read(b);
                return n > 0 ? new String(b, 0, n, StandardCharsets.UTF_8) : "";
            }
        } catch (Exception ignored) { return ""; }
    }
}
