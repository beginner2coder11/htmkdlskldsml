package com.downloader.app

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val chooserCode = 777
    private var desktopMode = false
    private var mobileUserAgent: String? = null
    private val desktopUserAgent =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    // downloadManagerId -> original url
    private val pendingDownloads = mutableMapOf<Long, String>()

    private val downloadDoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: return
            val url = pendingDownloads.remove(id) ?: return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val q = dm.query(DownloadManager.Query().setFilterById(id))
            var ok = false
            var path = ""
            if (q.moveToFirst()) {
                val status = q.getInt(q.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                ok = status == DownloadManager.STATUS_SUCCESSFUL
                path = q.getString(q.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: ""
            }
            q.close()
            val js = "window.RBDownloadDone&&window.RBDownloadDone(" +
                JsQuote.quote(url) + "," + JsQuote.quote(path) + "," + ok + ")"
            webView.evaluateJavascript(js, null)
            Toast.makeText(
                this@MainActivity,
                if (ok) "اكتمل التنزيل" else "فشل التنزيل",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /** جسر RBAndroid الذي يستدعيه ملف app.html */
    inner class RbBridge {
        @JavascriptInterface
        fun openUrl(rawUrl: String) {
            runOnUiThread { openUrlNative(rawUrl) }
        }

        @JavascriptInterface
        fun downloadFile(rawUrl: String) {
            runOnUiThread { enqueueDownload(rawUrl) }
        }

        @JavascriptInterface
        fun openFile(path: String) {
            runOnUiThread { openFileNative(path) }
        }

        @JavascriptInterface
        fun setDesktopMode(on: Boolean) {
            runOnUiThread { applyDesktopMode(on) }
        }
    }

    private fun normalizeUrl(raw: String): String? {
        val value = raw.trim()
        if (value.isEmpty()) return null
        return if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) value else "https://$value"
    }

    private fun openUrlNative(raw: String) {
        val url = normalizeUrl(raw) ?: return
        val uri = Uri.parse(url)
        if (uri.scheme == "http" || uri.scheme == "https") {
            webView.loadUrl(url)
        } else {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun enqueueDownload(rawUrl: String) {
        val url = normalizeUrl(rawUrl) ?: return
        try {
            val uri = Uri.parse(url)
            if (uri.scheme != "http" && uri.scheme != "https") return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(uri)
                .setTitle(URLUtil.guessFileName(url, null, null))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, null, null))
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
            req.addRequestHeader("User-Agent", webView.settings.userAgentString ?: "")
            val id = dm.enqueue(req)
            pendingDownloads[id] = url
            Toast.makeText(this, "بدأ التنزيل 🚀", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر بدء التنزيل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFileNative(path: String) {
        try {
            var p = path.trim()
            if (p.startsWith("file://")) p = Uri.parse(p).path ?: p
            val file = File(p)
            if (!file.exists()) {
                Toast.makeText(this, "الملف غير موجود", Toast.LENGTH_SHORT).show()
                return
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = when (file.extension.lowercase()) {
                "pdf" -> "application/pdf"
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "mp4" -> "video/mp4"
                "mp3" -> "audio/mpeg"
                "txt" -> "text/plain"
                "html", "htm" -> "text/html"
                "zip" -> "application/zip"
                "apk" -> "application/vnd.android.package-archive"
                else -> "*/*"
            }
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "فتح الملف"))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح الملف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyDesktopMode(on: Boolean) {
        if (mobileUserAgent == null) mobileUserAgent = webView.settings.userAgentString
        desktopMode = on
        webView.settings.userAgentString = if (on) desktopUserAgent else mobileUserAgent
        webView.reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadsImagesAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.allowFileAccess = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mediaPlaybackRequiresUserGesture = false

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(RbBridge(), "RBAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    false // التنقل داخل التطبيق
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                    } catch (_: Exception) { true }
                }
            }

        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                // نوافذ target=_blank تُفتح في نفس الـWebView
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popup = WebView(this@MainActivity)
                popup.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                        r?.url?.toString()?.let { openUrlNative(it) }
                        return true
                    }
                }
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    startActivityForResult(
                        params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" },
                        chooserCode
                    ); true
                } catch (_: Exception) { filePathCallback = null; false }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            enqueueDownload(url)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadDoneReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(downloadDoneReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
        }

        webView.loadUrl("file:///android_asset/app.html")
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooserCode) {
            val result = if (resultCode == RESULT_OK)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(downloadDoneReceiver) } catch (_: Exception) {}
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    // ترميز JSON بسيط لتفادي اعتماد إضافي
    private object JsQuote {
        fun quote(s: String): String {
            val sb = StringBuilder("\"")
            for (c in s) {
                when (c) {
                    '"' -> sb.append("\\\"")
                    '\\' -> sb.append("\\\\")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
                }
            }
            return sb.append("\"").toString()
        }
    }
}
