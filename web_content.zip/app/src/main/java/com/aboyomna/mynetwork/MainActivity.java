package com.aboyomna.mynetwork;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;
    private PingController ping;
    private int colorIndex;
    private boolean hidden;
    private final int[] colors = {Color.BLACK, 0xffb91c1c, 0xff166534, 0xff172554, 0xffc99732, 0xff333333, 0xff07090e, Color.TRANSPARENT};
    private void applyStatus() {
        getWindow().setStatusBarColor(colors[colorIndex]);
        if(hidden) getWindow().addFlags(1024); else getWindow().clearFlags(1024);
        getPreferences(0).edit().putInt("color",colorIndex).putBoolean("hidden",hidden).apply();
    }
    private static final String START_URL = "https://appassets.androidplatform.net/assets/web/index.html";

    public class AndroidBridge {
        @JavascriptInterface public void startAccessPing(String ip, boolean reset){runOnUiThread(()->ping.start(ip,reset));}
        @JavascriptInterface public void stopAccessPing(){runOnUiThread(()->ping.stop());}
        @JavascriptInterface public void nextStatusColor(){runOnUiThread(()->{colorIndex=(colorIndex+1)%colors.length;applyStatus();});}
        @JavascriptInterface public void toggleStatusBar(){runOnUiThread(()->{hidden=!hidden;applyStatus();});}
        @JavascriptInterface
        public void shareRoundedCapture(double left, double top, double width, double height, double radius, double cssViewportWidth) {
            runOnUiThread(() -> {
                try {
                    if (webView == null || cssViewportWidth <= 0 || width <= 0 || height <= 0) return;
                    float scale = (float)(webView.getWidth() / cssViewportWidth);
                    int w = Math.round((float)width * scale);
                    int h = Math.round((float)height * scale);
                    if (w < 1 || h < 1 || w > 4096 || h > 4096) return;
                    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    Path clip = new Path();
                    float rad = (float)radius * scale;
                    clip.addRoundRect(new RectF(0,0,w,h),rad,rad,Path.Direction.CW);
                    canvas.clipPath(clip);
                    canvas.translate(-(float)left * scale, -(float)top * scale);
                    webView.draw(canvas);
                    File dir = new File(getCacheDir(), "shared_images");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cache unavailable");
                    File output = new File(dir, "subscriber-details.png");
                    try (FileOutputStream stream = new FileOutputStream(output)) {
                        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw new Exception("PNG error");
                    }
                    bitmap.recycle();
                    Uri uri = Uri.parse("content://" + getPackageName() + ".sharedimages/subscriber-details.png");
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "إرسال صورة بيانات المشترك"));
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "تعذر مشاركة الصورة", Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface
        public void closeCurrentPage() {
            runOnUiThread(() -> {
                if (webView != null && webView.canGoBack()) webView.goBack();
                else if (webView != null) webView.loadUrl(START_URL);
            });
        }
        @JavascriptInterface
        public void closeApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finishAndRemoveTask();
                }
            });
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        colorIndex=Math.floorMod(getPreferences(0).getInt("color",0),colors.length); hidden=getPreferences(0).getBoolean("hidden",false); applyStatus();
        getWindow().setNavigationBarColor(Color.parseColor("#07090e"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#07090e"));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        ping = new PingController(this,webView);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient());

        final androidx.webkit.WebViewAssetLoader loader = new androidx.webkit.WebViewAssetLoader.Builder().addPathHandler("/assets/",new androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return false;
                String url = request.getUrl().toString();
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });

        webView.loadUrl(START_URL);
        setContentView(webView, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(function(){var m=document.getElementById('accessPingModal');if(m&&m.classList.contains('open')){closeAccessPing();return true;}return false;})()", handled -> { if (!"true".equals(handled)) normalBack(); });
    }
    private void normalBack() {
        // The renewal confirmation must only close via its two explicit buttons.
        webView.evaluateJavascript("(function(){var m=document.getElementById('tgToastModal');return !!(m && m.classList.contains('show'));})()", result -> {
            if ("true".equals(result)) return;
            if (webView.canGoBack()) webView.goBack();
            else MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if(ping!=null)ping.stop();
        if(webView!=null)webView.evaluateJavascript("if(window.accessPingPaused)accessPingPaused()",null);
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if(ping!=null)ping.stop();
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
