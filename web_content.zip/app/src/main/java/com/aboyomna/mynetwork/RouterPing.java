package com.aboyomna.mynetwork;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
final class RouterPing implements Closeable {
 final Socket socket=new Socket(); InputStream in; OutputStream out;
 void connect(String user,String pass)throws IOException{socket.connect(new InetSocketAddress("10.17.83.29",8728),5000);socket.setSoTimeout(7000);in=socket.getInputStream();out=socket.getOutputStream();send("/login","=name="+user,"=password="+pass);readResults();}
 void word(String s)throws IOException{byte[] b=s.getBytes(StandardCharsets.UTF_8);int n=b.length;if(n<128)out.write(n);else if(n<16384){out.write((n>>8)|128);out.write(n&255);}else throw new IOException("Word too long");out.write(b);}
 void send(String... words)throws IOException{for(String w:words)word(w);out.write(0);out.flush();}
 int octet()throws IOException{int x=in.read();if(x<0)throw new EOFException();return x;}
 String readWord()throws IOException{int a=octet(),n;if(a<128)n=a;else if(a<192)n=((a&63)<<8)|octet();else if(a<224)n=((a&31)<<16)|(octet()<<8)|octet();else if(a<240)n=((a&15)<<24)|(octet()<<16)|(octet()<<8)|octet();else throw new IOException("Invalid API length");if(n>1048576)throw new IOException("API response too large");byte[] b=new byte[n];new DataInputStream(in).readFully(b);return new String(b,StandardCharsets.UTF_8);}
 List<Map<String,String>> readResults()throws IOException{List<Map<String,String>> rows=new ArrayList<>();String error=null;while(true){String type=readWord();Map<String,String> m=new HashMap<>();for(String w;(w=readWord()).length()>0;){int i=w.indexOf('=',1);if(w.startsWith("=")&&i>0)m.put(w.substring(1,i),w.substring(i+1));}if(type.equals("!re"))rows.add(m);if(type.equals("!trap"))error=m.getOrDefault("message","API rejected request");if(type.equals("!fatal"))throw new IOException("API disconnected");if(type.equals("!done")){if(error!=null)throw new IOException(error);return rows;}}}
 List<Map<String,String>> ping(String ip)throws IOException{send("/ping","=address="+ip,"=interface=out","=arp-ping=yes","=count=1");return readResults();}
 public void close(){try{socket.close();}catch(IOException ignored){}}
}
