package com.tjoefbuddies.p2p

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.NetworkInterface
import java.util.Collections
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val tcpPort = 39873
    private val udpPort = 39872
    private val peers = CopyOnWriteArrayList<JSONObject>()
    private val sockets = CopyOnWriteArrayList<Socket>()
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var p2pManager: WifiP2pManager? = null
    private var p2pChannel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var myName = "Tjoef Rebel"
    private var myUsername = "rebel"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(P2PBridge(), "AndroidP2P")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifi.createMulticastLock("TjoefBuddiesP2P").apply { setReferenceCounted(true); acquire() }
        p2pManager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        p2pChannel = p2pManager?.initialize(this, mainLooper, null)
        requestNeededPermissions()
        startTcpServer()
    }

    private fun requestNeededPermissions() {
        val wanted = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) wanted.add("android.permission.NEARBY_WIFI_DEVICES")
        val missing = wanted.distinct().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 77)
    }

    private fun js(method: String, value: String) {
        runOnUiThread { web.evaluateJavascript("if(window.$method)window.$method(${JSONObject.quote(value)});", null) }
    }
    private fun status(s: String) = js("onP2PStatus", s)

    inner class P2PBridge {
        @JavascriptInterface fun start() {
            running = true
            startUdpDiscovery()
            startWifiDirect()
            status("Scanning same Wi-Fi and requesting Wi-Fi Direct discovery…")
        }
        @JavascriptInterface fun startWifiDirect() {
            try {
                val manager = p2pManager ?: return status("Wi-Fi Direct is not supported on this phone.")
                val channel = p2pChannel ?: return status("Wi-Fi Direct could not initialize.")
                requestNeededPermissions()
                registerP2pReceiver()
                manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { status("Wi-Fi Direct scan started. Open the app on the other phone too.") }
                    override fun onFailure(reason: Int) { status("Wi-Fi Direct scan failed ($reason). Same-Wi-Fi mode may still work.") }
                })
            } catch (_: Exception) { status("Wi-Fi Direct unavailable on this device.") }
        }
        @JavascriptInterface fun connectPeer(ip: String) { thread { connectTcp(ip, tcpPort) } }
        @JavascriptInterface fun connectDirect(address: String) {
            try {
                val config = WifiP2pConfig().apply { deviceAddress = address }
                p2pManager?.connect(p2pChannel, config, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { status("Wi-Fi Direct connection requested. Accept any Android prompt.") }
                    override fun onFailure(reason: Int) { status("Wi-Fi Direct connect failed ($reason). Try same-Wi-Fi mode.") }
                })
            } catch (_: Exception) { status("Could not request Wi-Fi Direct connection.") }
        }
        @JavascriptInterface fun sendMessage(raw: String) {
            try {
                val packet = JSONObject(raw)
                myName = packet.optString("name", myName)
                myUsername = packet.optString("username", myUsername)
                if (sockets.isEmpty()) { status("No connected peers. Scan and connect both phones first."); return }
                val line = packet.toString()
                var sent = false
                sockets.toList().forEach { s -> try { PrintWriter(s.getOutputStream(), true).println(line); sent = true } catch (_: Exception) {} }
                status(if (sent) "P2P message sent to connected devices." else "Message not sent. Reconnect to the peer.")
            } catch (_: Exception) { status("Could not send message.") }
        }
    }

    private fun startTcpServer() {
        thread(name = "tjoef-tcp-server") {
            try {
                server = ServerSocket(tcpPort)
                while (!isFinishing) {
                    val s = server!!.accept()
                    sockets.add(s)
                    readSocket(s)
                }
            } catch (_: Exception) { }
        }
    }
    private fun readSocket(socket: Socket) {
        thread(name = "tjoef-peer-reader") {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                while (!socket.isClosed) {
                    val line = reader.readLine() ?: break
                    js("onP2PMessage", JSONObject(line).toString())
                }
            } catch (_: Exception) { } finally {
                sockets.remove(socket); try { socket.close() } catch (_: Exception) {}; status("A peer disconnected.")
            }
        }
    }
    private fun connectTcp(host: String, port: Int) {
        try {
            if (sockets.any { it.inetAddress.hostAddress == host && !it.isClosed }) return
            val s = Socket(); s.connect(java.net.InetSocketAddress(host, port), 5000); sockets.add(s)
            status("Connected to nearby device at $host."); readSocket(s)
        } catch (_: Exception) { status("Could not connect to $host. Check both phones are on the same Wi-Fi.") }
    }
    private fun startUdpDiscovery() {
        thread(name = "tjoef-udp-discovery") {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket(udpPort).apply { broadcast = true; soTimeout = 900 }
                val buf = ByteArray(2048)
                while (running && !isFinishing) {
                    try {
                        val packet = DatagramPacket(buf, buf.size); sock.receive(packet)
                        val obj = JSONObject(String(packet.data, packet.offset, packet.length))
                        val ip = packet.address.hostAddress ?: ""
                        if (obj.optString("app") == "tjoef-buddies" && ip.isNotBlank() && ip != localIp()) {
                            obj.put("ip", ip).put("kind", "Same Wi-Fi"); addPeer(obj); connectTcp(ip, tcpPort)
                        }
                    } catch (_: java.net.SocketTimeoutException) { } catch (_: Exception) { }
                    try {
                        val bytes = JSONObject().put("app", "tjoef-buddies").put("name", myName).put("username", myUsername).put("port", tcpPort).toString().toByteArray()
                        sock.send(DatagramPacket(bytes, bytes.size, InetAddress.getByName("255.255.255.255"), udpPort))
                    } catch (_: Exception) { }
                }
            } catch (_: Exception) { status("Same-Wi-Fi discovery failed. Check Wi-Fi permissions.") } finally { sock?.close() }
        }
    }
    private fun addPeer(p: JSONObject) {
        synchronized(peers) { if (peers.none { it.optString("ip") == p.optString("ip") && it.optString("address") == p.optString("address") }) peers.add(p) }
        val arr = JSONArray(); peers.forEach { arr.put(it) }; js("onP2PPeers", arr.toString()); status("Found nearby device: " + p.optString("name", "Tjoef Rebel"))
    }
    @SuppressLint("MissingPermission") private fun registerP2pReceiver() {
        if (receiver != null) return
        val filter = IntentFilter().apply { addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION); addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION); addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION) }
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: android.content.Intent) {
                when (intent.action) {
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> try {
                        p2pManager?.requestPeers(p2pChannel) { list ->
                            list.deviceList.forEach { d -> addPeer(JSONObject().put("name", d.deviceName ?: "Nearby Android").put("username", d.deviceName ?: "android_peer").put("address", d.deviceAddress).put("kind", "Wi-Fi Direct")) }
                        }
                    } catch (_: Exception) { }
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> try {
                        p2pManager?.requestConnectionInfo(p2pChannel) { info ->
                            if (info.groupFormed && info.groupOwnerAddress != null) {
                                val host = info.groupOwnerAddress.hostAddress
                                if (!info.isGroupOwner && host != null) connectTcp(host, tcpPort)
                                status("Wi-Fi Direct group formed; opening the message channel…")
                            }
                        }
                    } catch (_: Exception) { }
                }
            }
        }
        try { if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(receiver, filter) } catch (_: Exception) { }
    }
    private fun localIp(): String {
        try { Collections.list(NetworkInterface.getNetworkInterfaces()).forEach { ni -> Collections.list(ni.inetAddresses).forEach { a -> if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: "" } } } catch (_: Exception) { }
        return ""
    }
    override fun onDestroy() {
        running = false; try { server?.close() } catch (_: Exception) { }; sockets.forEach { try { it.close() } catch (_: Exception) { } }
        try { receiver?.let { unregisterReceiver(it) } } catch (_: Exception) { }; try { multicastLock?.release() } catch (_: Exception) { }; web.destroy(); super.onDestroy()
    }
}
