package com.htmltoapk.khhcmsc1

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.webkit.CookieManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.sqrt

/** Small, offline-capable PDF viewer. Only the current page is retained in memory. */
class PdfActivity : ComponentActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var renderer: PdfRenderer? = null // accessed only on worker
    private var descriptor: ParcelFileDescriptor? = null
    private var temporary: File? = null
    private var bitmap: Bitmap? = null
    private lateinit var image: ImageView
    private lateinit var status: TextView
    private lateinit var previous: Button
    private lateinit var next: Button
    private lateinit var zoom: Button
    private var page = 0
    private var pages = 0
    private var enlarged = false
    @Volatile private var closed = false
    @Volatile private var connection: HttpURLConnection? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        page = savedInstanceState?.getInt("page") ?: 0
        enlarged = savedInstanceState?.getBoolean("enlarged") ?: false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        controls.addView(Button(this).apply { text = "‹"; contentDescription = getString(R.string.pdf_close); setOnClickListener { finish() } })
        status = TextView(this).apply { text = getString(R.string.pdf_loading); gravity = Gravity.CENTER }
        controls.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        previous = Button(this).apply { text = "←"; contentDescription = getString(R.string.pdf_previous); setOnClickListener { showPage(page - 1) } }
        next = Button(this).apply { text = "→"; contentDescription = getString(R.string.pdf_next); setOnClickListener { showPage(page + 1) } }
        zoom = Button(this).apply { text = "+"; contentDescription = getString(R.string.pdf_zoom); setOnClickListener { enlarged = !enlarged; showPage(page) } }
        // Two rows keep all controls usable on narrow screens.
        root.addView(controls)
        val navigation = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(previous); addView(zoom); addView(next) }
        root.addView(navigation)
        val scroll = android.widget.ScrollView(this)
        val horizontal = android.widget.HorizontalScrollView(this)
        image = ImageView(this).apply { adjustViewBounds = true; setBackgroundColor(Color.WHITE) }
        horizontal.addView(image)
        scroll.addView(horizontal)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        setBusy(true)
        val uri = intent.data
        val cookie = uri?.let { CookieManager.getInstance().getCookie(it.toString()) }
        worker.execute {
            try {
                require(uri != null)
                temporary = File.createTempFile("pdf_", ".pdf", cacheDir)
                input(uri, cookie).use { source ->
                    temporary!!.outputStream().use { output ->
                        val buffer = ByteArray(8192)
                        var total = 0L
                        while (true) {
                            check(!closed) { "cancelled" }
                            val count = source.read(buffer)
                            if (count < 0) break
                            total += count
                            require(total <= 100L * 1024 * 1024) { "PDF exceeds 100 MB" }
                            output.write(buffer, 0, count)
                        }
                    }
                }
                descriptor = ParcelFileDescriptor.open(temporary!!, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(descriptor!!)
                val count = renderer!!.pageCount
                require(count > 0)
                runOnUiThread {
                    if (!closed) { pages = count; page = page.coerceIn(0, pages - 1); showPage(page) }
                }
            } catch (failure: Exception) { reportError(failure) }
            finally { connection?.disconnect(); connection = null }
        }
    }

    private fun input(uri: Uri, cookie: String?): InputStream = when {
        uri.scheme == "content" -> contentResolver.openInputStream(uri) ?: error("Cannot open PDF")
        uri.scheme == "https" && uri.host == "appassets.androidplatform.net" && uri.path?.startsWith("/assets/www/") == true -> {
            val path = uri.path!!.removePrefix("/assets/")
            require(path.split('/').none { it == ".." })
            assets.open(path)
        }
        uri.scheme in listOf("https", "http") -> {
            val remote = URL(uri.toString()).openConnection() as HttpURLConnection
            connection = remote
            remote.connectTimeout = 15_000
            remote.readTimeout = 20_000
            if (!cookie.isNullOrBlank()) remote.setRequestProperty("Cookie", cookie)
            remote.inputStream
        }
        else -> error("Unsupported PDF address")
    }

    private fun showPage(index: Int) {
        if (closed || index !in 0 until pages) return
        page = index
        setBusy(true)
        val width = (resources.displayMetrics.widthPixels * if (enlarged) 2 else 1).coerceAtMost(2400)
        worker.execute {
            var rendered: Bitmap? = null
            try {
                renderer!!.openPage(index).use { pdf ->
                    val ratio = pdf.height.toDouble() / pdf.width.coerceAtLeast(1)
                    val boundedWidth = width.coerceAtMost(sqrt(2_000_000.0 / ratio).toInt().coerceAtLeast(1))
                    rendered = Bitmap.createBitmap(boundedWidth, (boundedWidth * ratio).toInt().coerceIn(1, 4096), Bitmap.Config.ARGB_8888)
                    rendered!!.eraseColor(Color.WHITE)
                    pdf.render(rendered!!, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
                val ready = rendered!!
                runOnUiThread {
                    if (closed) ready.recycle() else {
                        val old = bitmap
                        bitmap = ready
                        image.setImageBitmap(ready)
                        image.layoutParams = image.layoutParams.apply {
                            this.width = width
                            height = (width.toDouble() * ready.height / ready.width).toInt().coerceAtMost(20_000)
                        }
                        old?.recycle()
                        status.text = getString(R.string.pdf_page, index + 1, pages)
                        zoom.text = if (enlarged) "−" else "+"
                        setBusy(false)
                    }
                }
            } catch (failure: Exception) { rendered?.recycle(); reportError(failure) }
        }
    }

    private fun setBusy(busy: Boolean) {
        previous.isEnabled = !busy && page > 0
        next.isEnabled = !busy && page + 1 < pages
        zoom.isEnabled = !busy && pages > 0
    }

    private fun reportError(failure: Exception) {
        android.util.Log.w("PdfViewer", "PDF could not be displayed", failure)
        runOnUiThread { if (!closed) { status.text = getString(R.string.pdf_error); setBusy(false) } }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("page", page)
        outState.putBoolean("enlarged", enlarged)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        closed = true
        connection?.disconnect()
        image.setImageDrawable(null)
        bitmap?.recycle()
        bitmap = null
        worker.execute {
            renderer?.close()
            descriptor?.close()
            temporary?.delete()
        }
        worker.shutdown()
        super.onDestroy()
    }

    companion object {
        fun isPdf(uri: Uri?): Boolean = uri?.path?.endsWith(".pdf", ignoreCase = true) == true
        fun open(context: Context, uri: Uri): Boolean {
            if (uri.scheme !in listOf("content", "https", "http")) return false
            context.startActivity(Intent(context, PdfActivity::class.java).apply {
                data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            return true
        }
    }
}
