package com.htmltoapk.khhcmsc1

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.SparseArray
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.InputStream
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/** Continuous vertical PDF pages; only attached pages retain raster images. */
class PdfDocumentView(context: Context) : LinearLayout(context) {
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val worker = ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, LinkedBlockingQueue())
    private val status = TextView(context)
    private val zoomButton = Button(context)
    private val horizontal = HorizontalScrollView(context)
    val pageList = RecyclerView(context)
    private val manager = LinearLayoutManager(context)
    private val pageAdapter = Pages()
    private val ratios = SparseArray<Double>()
    private val holders = mutableSetOf<PageHolder>()
    private var renderer: PdfRenderer? = null // worker only
    private var descriptor: ParcelFileDescriptor? = null
    private var temporary: File? = null
    @Volatile private var released = false
    private var pageCount = 0
    private var zoomed = false
    private var viewportWidth = 0
    private var restoredPage = 0
    private var restoredOffset = 0
    private var opened = false
    var onReady: (() -> Unit)? = null
    var onError: (() -> Unit)? = null
    val currentPage: Int get() = manager.findFirstVisibleItemPosition().coerceAtLeast(0)
    val renderedPageCount: Int get() = holders.count { it.bitmap != null }

    init {
        orientation = VERTICAL
        val dark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        setBackgroundColor(if (dark) Color.rgb(31, 32, 36) else Color.rgb(235, 237, 241))
        val controls = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        status.text = context.getString(R.string.pdf_document_loading)
        status.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        status.gravity = Gravity.CENTER
        controls.addView(status, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        zoomButton.text = "+"
        zoomButton.contentDescription = context.getString(R.string.pdf_document_zoom)
        zoomButton.isEnabled = false
        zoomButton.setOnClickListener {
            val page = currentPage
            zoomed = !zoomed
            updateWidth(page, 0)
        }
        controls.addView(zoomButton)
        addView(controls, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        pageList.layoutManager = manager
        pageList.adapter = pageAdapter
        pageList.itemAnimator = null
        pageList.setItemViewCacheSize(0)
        pageList.recycledViewPool.setMaxRecycledViews(0, 2)
        pageList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) { updateStatus() }
        })
        horizontal.isFillViewport = true
        horizontal.addView(pageList, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(horizontal, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && w != viewportWidth) {
            val position = manager.findFirstVisibleItemPosition()
            val page = if (position != RecyclerView.NO_POSITION) position else restoredPage
            val offset = if (position != RecyclerView.NO_POSITION) pageOffset(position) else restoredOffset
            viewportWidth = w
            main.post { if (!released) updateWidth(page, offset) }
        }
    }

    private fun updateWidth(page: Int, offset: Int) {
        if (viewportWidth <= 0 || released) return
        holders.forEach { it.clear() }
        pageList.layoutParams = pageList.layoutParams.apply { width = viewportWidth * if (zoomed) 2 else 1 }
        zoomButton.text = if (zoomed) "−" else "+"
        pageAdapter.notifyDataSetChanged()
        manager.scrollToPositionWithOffset(page, offset)
        if (!zoomed) horizontal.scrollTo(0, 0)
    }

    /** Copies with a bound to a seekable private file; PDF bytes never become one large array. */
    fun openDocument(input: () -> InputStream) {
        check(!opened) { "Document is already open" }
        opened = true
        worker.execute {
            try {
                val file = File.createTempFile("pdf_document_", ".pdf", context.cacheDir)
                temporary = file
                input().use { source -> file.outputStream().use { target ->
                    val buffer = ByteArray(32 * 1024)
                    var total = 0L
                    while (true) {
                        check(!released) { "cancelled" }
                        val count = source.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_PDF_BYTES) { "PDF exceeds 100 MB" }
                        target.write(buffer, 0, count)
                    }
                } }
                descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(descriptor!!)
                val pages = renderer!!.pageCount
                require(pages > 0) { "Empty PDF" }
                main.post {
                    if (!released) {
                        pageCount = pages
                        restoredPage = restoredPage.coerceIn(0, pages - 1)
                        updateWidth(restoredPage, restoredOffset)
                        zoomButton.isEnabled = true
                        updateStatus()
                        onReady?.invoke()
                    }
                }
            } catch (failure: Exception) {
                android.util.Log.w("PdfDocumentView", "Cannot open PDF", failure)
                main.post { if (!released) { status.setText(R.string.pdf_document_error); onError?.invoke() } }
            }
        }
    }

    fun scrollToPage(page: Int) {
        if (pageCount > 0) manager.scrollToPositionWithOffset(page.coerceIn(0, pageCount - 1), 0)
    }

    private fun updateStatus() {
        if (pageCount > 0) status.text = context.getString(R.string.pdf_document_page, currentPage + 1, pageCount)
    }

    private fun pageOffset(page: Int): Int = manager.findViewByPosition(page)?.let {
        manager.getDecoratedTop(it) - (it.layoutParams as RecyclerView.LayoutParams).topMargin
    } ?: 0

    fun saveState(state: Bundle) {
        state.putInt("pdf_document_page", currentPage)
        // LinearLayoutManager offsets include item margins; View.top does not.
        state.putInt("pdf_document_offset", pageOffset(currentPage))
        state.putBoolean("pdf_document_zoom", zoomed)
    }

    fun restoreState(state: Bundle?) {
        restoredPage = state?.getInt("pdf_document_page") ?: 0
        restoredOffset = state?.getInt("pdf_document_offset") ?: 0
        zoomed = state?.getBoolean("pdf_document_zoom") ?: false
    }

    fun release() {
        if (released) return
        released = true
        holders.forEach { it.clear() }
        pageList.adapter = null
        worker.queue.clear()
        worker.execute {
            runCatching { renderer?.close() }
            runCatching { descriptor?.close() }
            temporary?.delete()
        }
        worker.shutdown()
    }

    private fun gap() = (8 * resources.displayMetrics.density).toInt()
    private fun pageWidth() = (viewportWidth * if (zoomed) 2 else 1) - gap() * 2

    private inner class PageHolder(val frame: FrameLayout, val image: ImageView) : RecyclerView.ViewHolder(frame) {
        var bitmap: Bitmap? = null
        var future: Future<*>? = null
        @Volatile var token = 0
        var page = -1
        fun clear() {
            token++
            future?.cancel(false)
            future = null
            worker.purge()
            image.setImageDrawable(null)
            bitmap?.recycle()
            bitmap = null
        }
    }

    private inner class Pages : RecyclerView.Adapter<PageHolder>() {
        override fun getItemCount() = pageCount
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
            val frame = FrameLayout(context).apply {
                setBackgroundColor(Color.WHITE)
                elevation = 2 * resources.displayMetrics.density
            }
            val image = ImageView(context).apply { scaleType = ImageView.ScaleType.FIT_XY }
            frame.addView(image, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            return PageHolder(frame, image).also { holders += it }
        }
        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            holders += holder
            holder.clear()
            holder.page = position
            val width = pageWidth().coerceAtLeast(1)
            holder.frame.layoutParams = RecyclerView.LayoutParams(LayoutParams.MATCH_PARENT,
                (width * (ratios[position] ?: sqrt(2.0))).toInt().coerceIn(1, 100_000)).apply {
                setMargins(gap(), gap(), gap(), gap())
            }
            holder.image.contentDescription = context.getString(R.string.pdf_document_page, position + 1, pageCount)
            render(holder)
        }
        override fun onViewAttachedToWindow(holder: PageHolder) {
            if (holder.bitmap == null && holder.future == null) render(holder)
        }
        override fun onViewDetachedFromWindow(holder: PageHolder) { holder.clear() }
        override fun onViewRecycled(holder: PageHolder) { holder.clear(); holder.page = -1; holders -= holder }
    }

    private fun render(holder: PageHolder) {
        if (released || viewportWidth <= 0 || holder.page < 0) return
        val token = holder.token
        val index = holder.page
        val width = pageWidth().coerceAtLeast(1)
        holder.future = worker.submit {
            var rendered: Bitmap? = null
            try {
                if (released || holder.token != token) return@submit
                var ratio = sqrt(2.0)
                renderer!!.openPage(index).use { page ->
                    ratio = page.height.toDouble() / page.width.coerceAtLeast(1)
                    val rasterWidth = minOf(width, 1600, sqrt(2_000_000.0 / ratio).toInt().coerceAtLeast(1))
                    val rasterHeight = (rasterWidth * ratio).toInt().coerceIn(1, 4096)
                    rendered = Bitmap.createBitmap(rasterWidth, rasterHeight, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
                    page.render(rendered!!, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
                val ready = rendered!!
                main.post {
                    if (released || holder.token != token || holder.page != index) ready.recycle() else {
                        holder.future = null
                        ratios.put(index, ratio)
                        holder.frame.layoutParams = holder.frame.layoutParams.apply {
                            height = (width * ratio).toInt().coerceIn(1, 100_000)
                        }
                        holder.bitmap = ready
                        holder.image.setImageBitmap(ready)
                    }
                }
            } catch (failure: Exception) {
                android.util.Log.w("PdfDocumentView", "Cannot render PDF page $index", failure)
                rendered?.recycle()
                main.post {
                    if (!released && holder.token == token) {
                        holder.future = null
                        status.setText(R.string.pdf_document_error)
                        onError?.invoke()
                    }
                }
            }
        }
    }

    companion object { const val MAX_PDF_BYTES = 100L * 1024 * 1024 }
}
