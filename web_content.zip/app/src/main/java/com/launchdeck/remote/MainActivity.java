package com.launchdeck.remote;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.view.Window;
import java.net.*;
import java.io.*;
import java.util.Enumeration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16,19,38));
        getWindow().setNavigationBarColor(Color.rgb(16,19,38));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,19,38));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new NativeBridge(), "LaunchDeckNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    public class NativeBridge {
        @JavascriptInterface public void discoverPC(String callbackName) {
            pool.execute(() -> {
                String found = "";
                try {
                    Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
                    outer: while (nets.hasMoreElements()) {
                        NetworkInterface ni = nets.nextElement();
                        if (!ni.isUp() || ni.isLoopback()) continue;
                        Enumeration<InetAddress> addrs = ni.getInetAddresses();
                        while (addrs.hasMoreElements()) {
                            InetAddress addr = addrs.nextElement();
                            if (!(addr instanceof Inet4Address) || addr.isLoopbackAddress()) continue;
                            byte[] b = addr.getAddress();
                            String prefix = (b[0]&255)+"."+(b[1]&255)+"."+(b[2]&255)+".";
                            for (int i=1;i<=254;i++) {
                                String ip = prefix+i;
                                try (Socket socket = new Socket()) {
                                    socket.connect(new InetSocketAddress(ip,8765),100);
                                    socket.setSoTimeout(250);
                                    HttpURLConnection c = (HttpURLConnection)new URL("http://"+ip+":8765/health").openConnection();
                                    c.setConnectTimeout(250); c.setReadTimeout(250);
                                    if(c.getResponseCode()==200) { found=ip; c.disconnect(); break outer; }
                                    c.disconnect();
                                } catch(Exception ignored) {}
                            }
                        }
                    }
                } catch(Exception ignored) {}
                final String result = found;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript(callbackName+"("+JSONObjectQuote(result)+")", null);
                });
            });
        }
        private String JSONObjectQuote(String s) {
            return "\"" + s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","") + "\"";
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
