package com.kendaraanku.app;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "service_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = nm.getNotificationChannel(CHANNEL);
            if (ch == null) {
                ch = new NotificationChannel(CHANNEL, "Pengingat servis", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Pengingat jadwal perawatan kendaraan");
                ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
                nm.createNotificationChannel(ch);
            }
        }
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title == null ? "KendaraanKu" : title)
            .setContentText(body == null ? "Waktunya mengecek jadwal servis kendaraan." : body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        nm.notify((int)(System.currentTimeMillis()/1000), b.build());
    }
}
