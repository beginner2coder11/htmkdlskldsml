package com.kendaraanku.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int NOTIF = 20;
    static final String PREFS = "vehicle";
    static final String IDS = "scheduled_ids";
    WebView web;
    SharedPreferences sp;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF);
        }
    }

    @Override protected void onDestroy() {
        if (web != null) web.removeJavascriptInterface("Android");
        super.onDestroy();
    }

    public class Bridge {
        @JavascriptInterface public void saveData(String d) { sp.edit().putString("data", d).apply(); scheduleFromJson(MainActivity.this, d); }
        @JavascriptInterface public void cancelAll() { cancelAllReminders(MainActivity.this); }
        @JavascriptInterface public String getData() { return sp.getString("data", "{}"); }
        @JavascriptInterface public void openNotificationSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(i);
            } catch (Exception ignored) {}
        }
    }

    static long dateAtNine(String yyyyMmDd) throws ParseException {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setLenient(false); f.setTimeZone(TimeZone.getDefault());
        return f.parse(yyyyMmDd + " 09:00").getTime();
    }

    static void scheduleFromJson(Context context, String json) {
        cancelAllReminders(context);
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            JSONArray schedules = root.optJSONArray("schedules");
            if (schedules == null) return;
            int[] days = {7,3,1,0};
            String[] bodies = {
                "Jadwal servis 7 hari lagi. Saatnya mengatur jadwal servis.",
                "Jadwal servis 3 hari lagi. Jangan lupa servis kendaraan.",
                "Besok jadwal servis kendaraan.",
                "Hari ini jadwal servis kendaraan."
            };
            for (int sIndex=0; sIndex<schedules.length(); sIndex++) {
                JSONObject s = schedules.optJSONObject(sIndex);
                if (s == null || !s.optBoolean("reminder", true)) continue;
                String date = s.optString("nextDate", "").trim();
                if (date.isEmpty()) continue;
                String name = s.optString("name", "Kendaraan").trim();
                if (name.isEmpty()) name = "Kendaraan";
                long serviceDay = dateAtNine(date);
                String sid = s.optString("id", "schedule_"+sIndex);
                for (int i=0;i<days.length;i++) {
                    long when = serviceDay - days[i]*24L*60L*60L*1000L;
                    if (when > System.currentTimeMillis()) {
                        int requestCode = requestCode(sid, days[i]);
                        scheduleOne(context, when, "Pengingat servis " + name, bodies[i], requestCode);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    static int requestCode(String id, int day) { return Math.abs((id + "#" + day).hashCode()); }

    static void cancelAllReminders(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String csv = p.getString(IDS, "");
        if (!csv.isEmpty()) for (String x : csv.split(",")) {
            try {
                int code = Integer.parseInt(x);
                PendingIntent pi = PendingIntent.getBroadcast(context, code, new Intent(context, ReminderReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(pi); pi.cancel();
            } catch (Exception ignored) {}
        }
        p.edit().remove(IDS).apply();
    }

    static void scheduleOne(Context context, long when, String title, String body, int requestCode) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(context, ReminderReceiver.class).putExtra("title", title).putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String old = p.getString(IDS, "");
        p.edit().putString(IDS, old.isEmpty()?String.valueOf(requestCode):old+","+requestCode).apply();
    }
}
