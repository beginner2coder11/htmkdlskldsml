package com.tradingviewvoice.fno;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import android.view.View;
import android.webkit.*;
import android.os.Build;

public class MainActivity extends Activity {
    private WebView web;
    private static final int MIC_REQ=44;
    private static final int OVERLAY_REQ=45;
    private boolean pendingVoice=false;
    @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(final PermissionRequest request){
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 21) {
                        String[] resources = request.getResources();
                        for (String r : resources) {
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                                } else {
                                    request.deny();
                                }
                                return;
                            }
                        }
                    }
                    request.deny();
                });
            }
        });web.addJavascriptInterface(new VoiceBridge(),"AndroidVoice");web.addJavascriptInterface(new VoiceBridge(),"AndroidVoiceBridge");web.loadUrl("file:///android_asset/index.html");}
    private void requestMicThenOverlay(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQ);return;} startOverlayFlow();
    }
    private void startOverlayFlow(){
        if(android.os.Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),OVERLAY_REQ);}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));} return;}
        Intent i=new Intent(this,FloatingVoiceService.class); if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); Toast.makeText(this,"Floating 🎤 voice bubble enabled",Toast.LENGTH_SHORT).show();
    }
    public void stopOverlay(){stopService(new Intent(this,FloatingVoiceService.class));}
    private void startNativeVoice(){
        Intent i=new Intent(this,VoiceActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }
    private void requestMicThenVoice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){pendingVoice=true;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQ);return;}
        if(android.os.Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){
            pendingVoice=true;
            try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),OVERLAY_REQ);}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));}
            return;
        }
        startNativeVoice();
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==OVERLAY_REQ){ if(pendingVoice){pendingVoice=false; startNativeVoice();} else startOverlayFlow(); }}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==MIC_REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){ if(pendingVoice) requestMicThenVoice(); else startOverlayFlow(); }else Toast.makeText(this,"Microphone permission is required",Toast.LENGTH_LONG).show();}
    public class VoiceBridge{
        @JavascriptInterface public void startVoice(){requestMicThenVoice();}
        @JavascriptInterface public void enableFloating(){requestMicThenOverlay();}
        @JavascriptInterface public void stopFloating(){stopOverlay();}
    }
}
