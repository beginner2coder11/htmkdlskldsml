package com.tradingviewvoice.fno;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.view.*;
import android.widget.*;
import java.net.URLEncoder;
import java.util.*;

public class FloatingVoiceService extends Service {
    public static final String ACTION_START_VOICE="com.tradingviewvoice.fno.START_VOICE";
 private WindowManager wm; private TextView bubble; private SpeechRecognizer recognizer; private boolean listening; private int retryCount=0;
 private float downX,downY; private int startX,startY;
 private final ArrayList<String> stocks=new ArrayList<>(); private final HashMap<String,String> aliases=new HashMap<>();
 @Override public void onCreate(){super.onCreate();loadUniverse();createChannel();if(Build.VERSION.SDK_INT>=29)startForeground(7001,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(7001,notification());showBubble();}
 private void loadUniverse(){
  stocks.add("NIFTY");
  stocks.add("BANKNIFTY");
  stocks.add("FINNIFTY");
  stocks.add("MIDCPNIFTY");
  stocks.add("NIFTYNXT50");
  stocks.add("360ONE");
  stocks.add("ABB");
  stocks.add("ADANIENSOL");
  stocks.add("ADANIENT");
  stocks.add("ADANIGREEN");
  stocks.add("ADANIPORTS");
  stocks.add("ADANIPOWER");
  stocks.add("ABCAPITAL");
  stocks.add("ALKEM");
  stocks.add("AMBER");
  stocks.add("AMBUJACEM");
  stocks.add("ANGELONE");
  stocks.add("APLAPOLLO");
  stocks.add("APOLLOHOSP");
  stocks.add("ASHOKLEY");
  stocks.add("ASIANPAINT");
  stocks.add("ASTRAL");
  stocks.add("AUBANK");
  stocks.add("AUROPHARMA");
  stocks.add("DMART");
  stocks.add("AXISBANK");
  stocks.add("BAJAJ-AUTO");
  stocks.add("BAJFINANCE");
  stocks.add("BAJAJFINSV");
  stocks.add("BAJAJHLDNG");
  stocks.add("BANDHANBNK");
  stocks.add("BANKBARODA");
  stocks.add("BANKINDIA");
  stocks.add("BDL");
  stocks.add("BEL");
  stocks.add("BHARATFORG");
  stocks.add("BPCL");
  stocks.add("BHARTIARTL");
  stocks.add("BHEL");
  stocks.add("BIOCON");
  stocks.add("BLUESTARCO");
  stocks.add("BOSCHLTD");
  stocks.add("BRITANNIA");
  stocks.add("BSE");
  stocks.add("CANBK");
  stocks.add("CDSL");
  stocks.add("CGPOWER");
  stocks.add("CHOLAFIN");
  stocks.add("CIPLA");
  stocks.add("COALINDIA");
  stocks.add("COCHINSHIP");
  stocks.add("COFORGE");
  stocks.add("COLPAL");
  stocks.add("CAMS");
  stocks.add("CONCOR");
  stocks.add("CROMPTON");
  stocks.add("CUMMINSIND");
  stocks.add("DABUR");
  stocks.add("DALBHARAT");
  stocks.add("DELHIVERY");
  stocks.add("DIVISLAB");
  stocks.add("DIXON");
  stocks.add("DLF");
  stocks.add("DRREDDY");
  stocks.add("EICHERMOT");
  stocks.add("ETERNAL");
  stocks.add("FEDERALBNK");
  stocks.add("FORCEMOT");
  stocks.add("FORTIS");
  stocks.add("NYKAA");
  stocks.add("GAIL");
  stocks.add("GVT&D");
  stocks.add("GLENMARK");
  stocks.add("GMRAIRPORT");
  stocks.add("GODFRYPHLP");
  stocks.add("GODREJCP");
  stocks.add("GODREJPROP");
  stocks.add("GRASIM");
  stocks.add("HAVELLS");
  stocks.add("HCLTECH");
  stocks.add("HDFCAMC");
  stocks.add("HDFCBANK");
  stocks.add("HDFCLIFE");
  stocks.add("HEROMOTOCO");
  stocks.add("HINDALCO");
  stocks.add("HAL");
  stocks.add("HINDPETRO");
  stocks.add("HINDUNILVR");
  stocks.add("HINDZINC");
  stocks.add("POWERINDIA");
  stocks.add("HYUNDAI");
  stocks.add("ICICIBANK");
  stocks.add("ICICIGI");
  stocks.add("ICICIPRULI");
  stocks.add("IDFCFIRSTB");
  stocks.add("INDIANB");
  stocks.add("IEX");
  stocks.add("IOC");
  stocks.add("IRFC");
  stocks.add("IREDA");
  stocks.add("INDUSTOWER");
  stocks.add("INDUSINDBK");
  stocks.add("NAUKRI");
  stocks.add("INFY");
  stocks.add("INOXWIND");
  stocks.add("INDIGO");
  stocks.add("ITC");
  stocks.add("JINDALSTEL");
  stocks.add("JIOFIN");
  stocks.add("JSWENERGY");
  stocks.add("JSWSTEEL");
  stocks.add("JUBLFOOD");
  stocks.add("KALYANKJIL");
  stocks.add("KAYNES");
  stocks.add("KEI");
  stocks.add("KFINTECH");
  stocks.add("KOTAKBANK");
  stocks.add("KPITTECH");
  stocks.add("LTF");
  stocks.add("LT");
  stocks.add("LAURUSLABS");
  stocks.add("LICHSGFIN");
  stocks.add("LICI");
  stocks.add("LODHA");
  stocks.add("LTM");
  stocks.add("LUPIN");
  stocks.add("M&M");
  stocks.add("MANAPPURAM");
  stocks.add("MANKIND");
  stocks.add("MARICO");
  stocks.add("MARUTI");
  stocks.add("MFSL");
  stocks.add("MAXHEALTH");
  stocks.add("MAZDOCK");
  stocks.add("MOTILALOFS");
  stocks.add("MPHASIS");
  stocks.add("MCX");
  stocks.add("MUTHOOTFIN");
  stocks.add("NATIONALUM");
  stocks.add("NBCC");
  stocks.add("NESTLEIND");
  stocks.add("NHPC");
  stocks.add("NAM-INDIA");
  stocks.add("NMDC");
  stocks.add("NTPC");
  stocks.add("OBEROIRLTY");
  stocks.add("ONGC");
  stocks.add("OIL");
  stocks.add("PAYTM");
  stocks.add("OFSS");
  stocks.add("PAGEIND");
  stocks.add("PATANJALI");
  stocks.add("POLICYBZR");
  stocks.add("PERSISTENT");
  stocks.add("PETRONET");
  stocks.add("PGEL");
  stocks.add("PIIND");
  stocks.add("PIDILITIND");
  stocks.add("PNBHOUSING");
  stocks.add("POLYCAB");
  stocks.add("PFC");
  stocks.add("POWERGRID");
  stocks.add("PREMIERENE");
  stocks.add("PRESTIGE");
  stocks.add("PNB");
  stocks.add("RADICO");
  stocks.add("RVNL");
  stocks.add("RBLBANK");
  stocks.add("RECLTD");
  stocks.add("RELIANCE");
  stocks.add("MOTHERSON");
  stocks.add("SBICARD");
  stocks.add("SBILIFE");
  stocks.add("SHREECEM");
  stocks.add("SHRIRAMFIN");
  stocks.add("SIEMENS");
  stocks.add("SOLARINDS");
  stocks.add("SONACOMS");
  stocks.add("SRF");
  stocks.add("SBIN");
  stocks.add("SAIL");
  stocks.add("SUNPHARMA");
  stocks.add("SUPREMEIND");
  stocks.add("SUZLON");
  stocks.add("SWIGGY");
  stocks.add("TCS");
  stocks.add("TATACONSUM");
  stocks.add("TATAELXSI");
  stocks.add("TMPV");
  stocks.add("TATAPOWER");
  stocks.add("TATASTEEL");
  stocks.add("TECHM");
  stocks.add("INDHOTEL");
  stocks.add("PHOENIXLTD");
  stocks.add("TITAN");
  stocks.add("TORNTPHARM");
  stocks.add("TRENT");
  stocks.add("TIINDIA");
  stocks.add("TVSMOTOR");
  stocks.add("ULTRACEMCO");
  stocks.add("UNIONBANK");
  stocks.add("UNITDSPR");
  stocks.add("UNOMINDA");
  stocks.add("UPL");
  stocks.add("VBL");
  stocks.add("VEDL");
  stocks.add("VMM");
  stocks.add("IDEA");
  stocks.add("VOLTAS");
  stocks.add("WAAREEENER");
  stocks.add("WIPRO");
  stocks.add("YESBANK");
  stocks.add("ZYDUSLIFE");
  String[][] a=new String[][]{
   {"reliance","RELIANCE"},
   {"रिलायंस","RELIANCE"},
   {"reliance industries","RELIANCE"},
   {"tata motors","TMPV"},
   {"टाटा मोटर्स","TMPV"},
   {"tata power","TATAPOWER"},
   {"टाटा पावर","TATAPOWER"},
   {"tata steel","TATASTEEL"},
   {"hdfc bank","HDFCBANK"},
   {"एचडीएफसी बैंक","HDFCBANK"},
   {"icici bank","ICICIBANK"},
   {"आईसीआईसीआई बैंक","ICICIBANK"},
   {"sbi","SBIN"},
   {"state bank","SBIN"},
   {"स्टेट बैंक","SBIN"},
   {"bharti airtel","BHARTIARTL"},
   {"airtel","BHARTIARTL"},
   {"infosys","INFY"},
   {"इन्फोसिस","INFY"},
   {"tcs","TCS"},
   {"tata consultancy","TCS"},
   {"hcl tech","HCLTECH"},
   {"wipro","WIPRO"},
   {"bajaj finance","BAJFINANCE"},
   {"bajaj finserv","BAJAJFINSV"},
   {"bajaj auto","BAJAJ-AUTO"},
   {"axis bank","AXISBANK"},
   {"kotak bank","KOTAKBANK"},
   {"kotak mahindra","KOTAKBANK"},
   {"adani enterprise","ADANIENT"},
   {"adani ports","ADANIPORTS"},
   {"adani power","ADANIPOWER"},
   {"adani green","ADANIGREEN"},
   {"jio financial","JIOFIN"},
   {"jiofin","JIOFIN"},
   {"eternal","ETERNAL"},
   {"zomato","ETERNAL"},
   {"paytm","PAYTM"},
   {"policy bazaar","POLICYBZR"},
   {"policybazaar","POLICYBZR"},
   {"max health","MAXHEALTH"},
   {"max healthcare","MAXHEALTH"},
   {"fortis","FORTIS"},
   {"फोर्टिस","FORTIS"},
   {"ireda","IREDA"},
   {"इरेडा","IREDA"},
   {"mcx","MCX"},
   {"एमसीएक्स","MCX"},
   {"nifty","NIFTY"},
   {"निफ्टी","NIFTY"},
   {"bank nifty","BANKNIFTY"},
   {"बैंक निफ्टी","BANKNIFTY"},
   {"fin nifty","FINNIFTY"},
   {"midcap nifty","MIDCPNIFTY"},
   {"titan","TITAN"},
   {"टाइटन","TITAN"},
   {"trent","TRENT"},
   {"trident","TRENT"},
   {"sun pharma","SUNPHARMA"},
   {"hindalco","HINDALCO"},
   {"coal india","COALINDIA"},
   {"coal","COALINDIA"},
   {"ongc","ONGC"},
   {"ntpc","NTPC"},
   {"power grid","POWERGRID"},
   {"pfc","PFC"},
   {"bel","BEL"},
   {"bharat electronics","BEL"},
   {"bhel","BHEL"},
   {"hal","HAL"},
   {"hindustan aeronautics","HAL"},
   {"indigo","INDIGO"},
   {"interglobe","INDIGO"},
   {"maruti","MARUTI"},
   {"mahindra","M&M"},
   {"m&m","M&M"},
   {"m m","M&M"},
   {"larsen","LT"},
   {"l&t","LT"},
   {"lt","LT"},
   {"lic","LICI"},
   {"lic india","LICI"},
   {"sbi cards","SBICARD"},
   {"bank of baroda","BANKBARODA"},
   {"bob","BANKBARODA"},
   {"canara bank","CANBK"},
   {"canbank","CANBK"},
   {"indian bank","INDIANB"},
   {"union bank","UNIONBANK"},
   {"yes bank","YESBANK"},
   {"idfc first","IDFCFIRSTB"},
   {"indusind bank","INDUSINDBK"},
   {"federal bank","FEDERALBNK"},
   {"rbl bank","RBLBANK"},
   {"bandhan bank","BANDHANBNK"},
   {"swiggy","SWIGGY"},
   {"nykaa","NYKAA"},
   {"angel one","ANGELONE"},
   {"dixon","DIXON"},
   {"kaynes","KAYNES"},
   {"cochin shipyard","COCHINSHIP"},
   {"mazagon dock","MAZDOCK"},
   {"inox wind","INOXWIND"},
   {"manappuram","MANAPPURAM"},
   {"lic housing","LICHSGFIN"},
   {"vedanta","VEDL"},
   {"idea","IDEA"},
   {"vodafone idea","IDEA"},
  }; for(String[] p:a)aliases.put(p[0],p[1]);
 }
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("voice","TradingView Voice",NotificationManager.IMPORTANCE_LOW);c.setDescription("Floating TradingView voice control");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
 private Notification notification(){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"voice"):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("TradingView Voice").setContentText("Floating voice control is active").setContentIntent(pi).setOngoing(true).build();}
 private void showBubble(){if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))return;wm=(WindowManager)getSystemService(WINDOW_SERVICE);bubble=new TextView(this);bubble.setText("🎤");bubble.setTextSize(24);bubble.setGravity(Gravity.CENTER);bubble.setTextColor(Color.WHITE);bubble.setPadding(8,8,8,8);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(0,137,123));bg.setShape(GradientDrawable.OVAL);bg.setStroke(dp(2),Color.WHITE);bubble.setBackground(bg);bubble.setElevation(12f);WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(58),dp(58),Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=18;lp.y=220;bubble.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();startX=lp.x;startY=lp.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=startX+(int)(e.getRawX()-downX);lp.y=startY+(int)(e.getRawY()-downY);wm.updateViewLayout(bubble,lp);return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-downX)<20&&Math.abs(e.getRawY()-downY)<20)openVoiceActivity();return true;}return false;});wm.addView(bubble,lp);}
 private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 private void startVoice(){if(listening)return;if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){toast("Open app once and allow microphone");return;}if(!SpeechRecognizer.isRecognitionAvailable(this)){toast("Speech recognition unavailable");return;}if(recognizer!=null)recognizer.destroy();recognizer=SpeechRecognizer.createSpeechRecognizer(this);listening=true;bubble.setText("⏺");recognizer.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle p){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}public void onError(int e){
                listening=false; bubble.setText("🎤");
                if((e==SpeechRecognizer.ERROR_NO_MATCH||e==SpeechRecognizer.ERROR_SPEECH_TIMEOUT) && retryCount<1){
                    retryCount++; new Handler(Looper.getMainLooper()).postDelayed(()->startVoice(),250); return;
                }
                retryCount=0;
                String msg;
                switch(e){
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: msg="Microphone permission denied"; break;
                    case SpeechRecognizer.ERROR_NETWORK: msg="Voice network error"; break;
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: msg="Voice network timeout"; break;
                    case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: msg="Hindi voice language unavailable"; break;
                    case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: msg="Hindi voice language not downloaded"; break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: msg="Voice recognizer busy"; break;
                    case SpeechRecognizer.ERROR_AUDIO: msg="Microphone audio error"; break;
                    default: msg="Voice error: "+e;
                }
                toast(msg);
            }public void onResults(Bundle r){listening=false;bubble.setText("🎤");ArrayList<String>a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);openStock(resolve(a!=null&&!a.isEmpty()?a.get(0):""));}public void onPartialResults(Bundle r){}public void onEvent(int e,Bundle b){}});Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN");i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);recognizer.startListening(i);}
 private String norm(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\u0900-\u097f&]+"," ").trim();}
 private String resolve(String spoken){String lower=norm(spoken);String[] keys={" kholo"," khol"," open"," chart"," trading view"," tradingview"," खोलो"," खोल"," ओपन"," चार्ट"};for(String k:keys)lower=lower.replace(k," ").trim();if(aliases.containsKey(lower))return aliases.get(lower);for(Map.Entry<String,String>e:aliases.entrySet())if(lower.contains(e.getKey()))return e.getValue();for(String s:stocks)if(lower.replace(" ","").equalsIgnoreCase(s.replace(" ","")))return s;for(String s:stocks)if(lower.contains(s.toLowerCase(Locale.ROOT)))return s;return "";}
 private void openStock(String symbol){if(symbol==null||symbol.isEmpty()){toast("Stock not found");return;}try{String url="https://www.tradingview.com/chart/?symbol=NSE%3A"+URLEncoder.encode(symbol,"UTF-8");Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){toast("Could not open TradingView");}}
 private void toast(String s){new Handler(Looper.getMainLooper()).post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
 @Override public int onStartCommand(Intent i,int flags,int id){ return START_STICKY; }
 private void openVoiceActivity(){ try { Intent i=new Intent(this,VoiceActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); } catch(Exception e){ toast("Tap Enable Floating Voice once from the app, then try again"); } }
 @Override public void onDestroy(){if(recognizer!=null)recognizer.destroy();if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
