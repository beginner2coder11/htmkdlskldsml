package com.tradingviewvoice.fno;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Window;
import android.widget.Toast;
import java.net.URLEncoder;
import java.util.*;

public class VoiceActivity extends Activity {
    private static final int MIC_REQ = 901;
    private SpeechRecognizer recognizer;
    private boolean finished;
    private final ArrayList<String> stocks = new ArrayList<>();
    private final HashMap<String,String> aliases = new HashMap<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(new android.view.View(this));
        loadUniverse();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
        } else startListening();
    }

    private void loadUniverse() {
        String raw="NIFTY,BANKNIFTY,FINNIFTY,MIDCPNIFTY,NIFTYNXT50,360ONE,ABB,ADANIENSOL,ADANIENT,ADANIGREEN,ADANIPORTS,ADANIPOWER,ABCAPITAL,ALKEM,AMBER,AMBUJACEM,ANGELONE,APLAPOLLO,APOLLOHOSP,ASHOKLEY,ASIANPAINT,ASTRAL,AUBANK,AUROPHARMA,DMART,AXISBANK,BAJAJ-AUTO,BAJFINANCE,BAJAJFINSV,BANDHANBNK,BANKBARODA,BANKINDIA,BDL,BEL,BHARATFORG,BPCL,BHARTIARTL,BHEL,BIOCON,BLUESTARCO,BOSCHLTD,BRITANNIA,BSE,CANBK,CDSL,CGPOWER,CHOLAFIN,CIPLA,COALINDIA,COCHINSHIP,COFORGE,COLPAL,CAMS,CONCOR,CROMPTON,CUMMINSIND,DABUR,DALBHARAT,DELHIVERY,DIVISLAB,DIXON,DLF,DRREDDY,EICHERMOT,ETERNAL,FEDERALBNK,FORCEMOT,FORTIS,NYKAA,GAIL,GVT&D,GLENMARK,GMRAIRPORT,GODFRYPHLP,GODREJCP,GODREJPROP,GRASIM,HAVELLS,HCLTECH,HDFCAMC,HDFCBANK,HDFCLIFE,HEROMOTOCO,HINDALCO,HAL,HINDPETRO,HINDUNILVR,HINDZINC,POWERINDIA,HYUNDAI,ICICIBANK,ICICIGI,ICICIPRULI,IDFCFIRSTB,INDIANB,IEX,IOC,IRFC,IREDA,INDUSTOWER,INDUSINDBK,NAUKRI,INFY,INOXWIND,INDIGO,ITC,JINDALSTEL,JIOFIN,JSWENERGY,JSWSTEEL,JUBLFOOD,KALYANKJIL,KAYNES,KEI,KFINTECH,KOTAKBANK,KPITTECH,LTF,LT,LAURUSLABS,LICHSGFIN,LICI,LODHA,LTM,LUPIN,M&M,MANAPPURAM,MANKIND,MARICO,MARUTI,MFSL,MAXHEALTH,MAZDOCK,MOTILALOFS,MPHASIS,MCX,MUTHOOTFIN,NATIONALUM,NBCC,NESTLEIND,NHPC,NAM-INDIA,NMDC,NTPC,OBEROIRLTY,ONGC,OIL,PAYTM,OFSS,PAGEIND,PATANJALI,POLICYBZR,PERSISTENT,PETRONET,PGEL,PIIND,PIDILITIND,PNBHOUSING,POLYCAB,PFC,POWERGRID,PREMIERENE,PRESTIGE,PNB,RADICO,RVNL,RBLBANK,RECLTD,RELIANCE,MOTHERSON,SBICARD,SBILIFE,SHREECEM,SHRIRAMFIN,SIEMENS,SOLARINDS,SONACOMS,SRF,SBIN,SAIL,SUNPHARMA,SUPREMEIND,SUZLON,SWIGGY,TCS,TATACONSUM,TATAELXSI,TMPV,TATAPOWER,TATASTEEL,TECHM,INDHOTEL,PHOENIXLTD,TITAN,TORNTPHARM,TRENT,TIINDIA,TVSMOTOR,ULTRACEMCO,UNIONBANK,UNITDSPR,UNOMINDA,UPL,VBL,VEDL,VMM,IDEA,VOLTAS,WAAREEENER,WIPRO,YESBANK,ZYDUSLIFE";
        stocks.addAll(Arrays.asList(raw.split(",")));
        String[][] a={{"reliance","RELIANCE"},{"रिलायंस","RELIANCE"},{"reliance industries","RELIANCE"},{"tata motors","TMPV"},{"टाटा मोटर्स","TMPV"},{"tata power","TATAPOWER"},{"टाटा पावर","TATAPOWER"},{"tata steel","TATASTEEL"},{"hdfc bank","HDFCBANK"},{"एचडीएफसी बैंक","HDFCBANK"},{"icici bank","ICICIBANK"},{"आईसीआईसीआई बैंक","ICICIBANK"},{"sbi","SBIN"},{"state bank","SBIN"},{"स्टेट बैंक","SBIN"},{"airtel","BHARTIARTL"},{"bharti airtel","BHARTIARTL"},{"infosys","INFY"},{"इन्फोसिस","INFY"},{"tcs","TCS"},{"hcl tech","HCLTECH"},{"wipro","WIPRO"},{"bajaj finance","BAJFINANCE"},{"bajaj finserv","BAJAJFINSV"},{"bajaj auto","BAJAJ-AUTO"},{"axis bank","AXISBANK"},{"kotak bank","KOTAKBANK"},{"adani enterprise","ADANIENT"},{"adani ports","ADANIPORTS"},{"adani power","ADANIPOWER"},{"adani green","ADANIGREEN"},{"jio financial","JIOFIN"},{"jiofin","JIOFIN"},{"zomato","ETERNAL"},{"eternal","ETERNAL"},{"paytm","PAYTM"},{"policy bazaar","POLICYBZR"},{"max health","MAXHEALTH"},{"fortis","FORTIS"},{"फोर्टिस","FORTIS"},{"ireda","IREDA"},{"इरेडा","IREDA"},{"mcx","MCX"},{"एमसीएक्स","MCX"},{"nifty","NIFTY"},{"निफ्टी","NIFTY"},{"bank nifty","BANKNIFTY"},{"बैंक निफ्टी","BANKNIFTY"},{"fin nifty","FINNIFTY"},{"midcap nifty","MIDCPNIFTY"},{"titan","TITAN"},{"trent","TRENT"},{"sun pharma","SUNPHARMA"},{"hindalco","HINDALCO"},{"coal india","COALINDIA"},{"ongc","ONGC"},{"ntpc","NTPC"},{"power grid","POWERGRID"},{"pfc","PFC"},{"bel","BEL"},{"bharat electronics","BEL"},{"bhel","BHEL"},{"hal","HAL"},{"hindustan aeronautics","HAL"},{"indigo","INDIGO"},{"maruti","MARUTI"},{"mahindra","M&M"},{"m m","M&M"},{"larsen","LT"},{"l&t","LT"},{"lic","LICI"},{"lic india","LICI"},{"bank of baroda","BANKBARODA"},{"bob","BANKBARODA"},{"canara bank","CANBK"},{"indian bank","INDIANB"},{"union bank","UNIONBANK"},{"yes bank","YESBANK"},{"idfc first","IDFCFIRSTB"},{"indusind bank","INDUSINDBK"},{"federal bank","FEDERALBNK"},{"rbl bank","RBLBANK"},{"bandhan bank","BANDHANBNK"},{"swiggy","SWIGGY"},{"nykaa","NYKAA"},{"angel one","ANGELONE"},{"dixon","DIXON"},{"kaynes","KAYNES"},{"cochin shipyard","COCHINSHIP"},{"mazagon dock","MAZDOCK"},{"inox wind","INOXWIND"},{"manappuram","MANAPPURAM"},{"lic housing","LICHSGFIN"},{"vedanta","VEDL"},{"idea","IDEA"},{"vodafone idea","IDEA"}};
        for(String[] p:a) aliases.put(p[0],p[1]);
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Speech recognition unavailable"); finish(); return; }
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){}
            public void onBeginningOfSpeech(){}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){}
            public void onPartialResults(Bundle r){}
            public void onEvent(int e,Bundle b){}
            public void onError(int e){ toast(errorText(e)); finish(); }
            public void onResults(Bundle r){
                ArrayList<String> a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String heard=a!=null&&!a.isEmpty()?a.get(0):"";
                String symbol=resolve(heard);
                if(symbol.isEmpty()) toast("Stock not found: "+heard); else openTradingView(symbol);
            }
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak stock name — e.g. Reliance kholo");
        recognizer.startListening(i);
    }

    private String norm(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\u0900-\\u097f&]+"," ").trim();}
    private String resolve(String spoken){
        String lower=norm(spoken);
        String[] keys={" kholo"," khol"," open"," chart"," trading view"," tradingview"," खोलो"," खोल"," ओपन"," चार्ट"};
        for(String k:keys) lower=lower.replace(k," ").trim();
        if(aliases.containsKey(lower)) return aliases.get(lower);
        for(Map.Entry<String,String> e:aliases.entrySet()) if(lower.contains(e.getKey())) return e.getValue();
        for(String s:stocks) if(lower.replace(" ","").equalsIgnoreCase(s.replace(" ",""))) return s;
        for(String s:stocks) if(lower.contains(s.toLowerCase(Locale.ROOT))) return s;
        return "";
    }

    private void openTradingView(String symbol){
        try {
            String url="https://www.tradingview.com/chart/?symbol=NSE%3A"+URLEncoder.encode(symbol,"UTF-8");
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage("com.tradingview.tradingviewapp");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); }
            catch(Exception noApp) {
                Intent fallback=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(fallback);
            }
        } catch(Exception e){ toast("Could not open TradingView"); }
        new Handler().postDelayed(this::finish,350);
    }
    private String errorText(int e){
        switch(e){case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:return "Microphone permission denied";case SpeechRecognizer.ERROR_NO_MATCH:return "Could not understand — speak again";case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:return "No speech detected";case SpeechRecognizer.ERROR_NETWORK:return "Voice network error";case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:return "Hindi voice language unavailable";default:return "Voice error: "+e;}
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==MIC_REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startListening();else {toast("Microphone permission is required");finish();}}
    @Override protected void onDestroy(){if(recognizer!=null){recognizer.cancel();recognizer.destroy();}super.onDestroy();}
}
