package uz.bahriddin.whisperingpines;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.libraries.ads.mobile.sdk.MobileAds;
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig;
import com.google.android.libraries.ads.mobile.sdk.banner.AdView;
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;

public class MainActivity extends Activity {
    private static final String TAG = "WhisperingPines";
    private static final String ADMOB_APP_ID = "ca-app-pub-1275271216332471~7533429441";

    // Use Google's TEST banner while building/testing. Replace with your own ad unit
    // only after the test APK works and before publishing:
    // ca-app-pub-1275271216332471/7775091694
    private static final String BANNER_AD_UNIT_ID =
            "ca-app-pub-3940256099942544/9214589741";

    private WebView webView;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(27, 56, 32));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(27, 56, 32));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());

        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(webView, webParams);

        FrameLayout bannerContainer = new FrameLayout(this);
        bannerContainer.setBackgroundColor(Color.WHITE);
        root.addView(bannerContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        // GMA Next-Gen SDK initialization must run on a background thread.
        new Thread(() -> {
            try {
                MobileAds.initialize(
                        getApplicationContext(),
                        new InitializationConfig.Builder(ADMOB_APP_ID).build(),
                        status -> runOnUiThread(() -> loadBanner(bannerContainer)));
            } catch (Exception e) {
                Log.e(TAG, "Ad SDK initialization failed", e);
            }
        }).start();
    }

    private void loadBanner(FrameLayout container) {
        if (isFinishing() || isDestroyed()) return;

        adView = new AdView(this);
        int widthDp = (int) (getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        AdSize adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp);
        adView.setAdUnitId(BANNER_AD_UNIT_ID);
        adView.setAdSize(adSize);
        container.addView(adView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        BannerAdRequest request = new BannerAdRequest.Builder(BANNER_AD_UNIT_ID, adSize).build();
        adView.loadAd(request, new AdLoadCallback<BannerAd>() {
            @Override
            public void onAdLoaded(@NonNull BannerAd bannerAd) {
                Log.d(TAG, "Test banner loaded successfully.");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError error) {
                Log.e(TAG, "Banner failed to load: " + error);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
