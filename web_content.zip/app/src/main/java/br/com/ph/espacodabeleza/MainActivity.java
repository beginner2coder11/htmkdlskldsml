package br.com.ph.espacodabeleza;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import org.json.JSONObject;

public class MainActivity extends Activity {
 private WebView web;
 private String pendingJson;
 private static final int SAVE=101, RESTORE=102;
 @Override public void onCreate(Bundle state){super.onCreate(state);
  web=new WebView(this);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());
  // Bridge exposed only to the trusted local HTML asset. Do not load untrusted remote pages.
  web.addJavascriptInterface(new Bridge(),"PHAndroid");
  web.loadUrl("file:///android_asset/index.html");
 }
 private void status(String msg){runOnUiThread(()->web.evaluateJavascript("phAndroidBackupStatus("+JSONObject.quote(msg)+")",null));}
 public class Bridge {
  @JavascriptInterface public void saveBackup(String filename,String json){
   runOnUiThread(()->{pendingJson=json;
    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
    i.putExtra(Intent.EXTRA_TITLE,filename);
    try{startActivityForResult(i,SAVE);}catch(Exception e){status("Não foi possível abrir o seletor de arquivos do Android.");}
   });
  }
  @JavascriptInterface public void restoreBackup(){runOnUiThread(()->{
   Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
   try{startActivityForResult(i,RESTORE);}catch(Exception e){status("Não foi possível escolher o backup.");}
  });}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(result!=RESULT_OK || data==null || data.getData()==null){status("Operação cancelada. Nenhum arquivo foi alterado.");return;}
  Uri uri=data.getData();
  if(request==SAVE){
   try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
    if(out==null)throw new Exception("Destino indisponível");
    out.write(pendingJson.getBytes(StandardCharsets.UTF_8));out.flush();
    status("Backup salvo no local escolhido. Confira o arquivo no gerenciador de arquivos.");
   }catch(Exception e){status("Falha ao salvar backup: "+e.getMessage());}
   finally{pendingJson=null;}
  }else if(request==RESTORE){
   try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
    if(in==null)throw new Exception("Arquivo indisponível");
    byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>15*1024*1024)throw new Exception("Backup maior que 15 MB");}
    String b64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
    web.evaluateJavascript("phAndroidRestoreBase64("+JSONObject.quote(b64)+")",null);
   }catch(Exception e){status("Falha ao abrir backup: "+e.getMessage());}
  }
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
