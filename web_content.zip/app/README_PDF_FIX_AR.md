# إصلاح PDF v4
تمت إضافة مسار احتياطي Native عبر `afriquia://savepdf` إذا لم يتوفر جسر `AndroidPrint`، مع اعتراض الرابط داخل Android وإنشاء PDF وحفظه في مجلد Downloads. تم رفع الإصدار إلى 1.3 (versionCode 4).
