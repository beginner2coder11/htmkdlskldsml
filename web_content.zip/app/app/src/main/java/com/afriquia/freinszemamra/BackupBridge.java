package com.afriquia.freinszemamra;

import android.webkit.JavascriptInterface;

/** جسر النسخ الاحتياطي المباشر إلى Google Drive. */
public final class BackupBridge {
    private final MainActivity activity;
    public BackupBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public boolean isReady() { return true; }
    @JavascriptInterface public boolean isGoogleSignedIn() { return activity.isGoogleDriveSignedInForUi(); }
    @JavascriptInterface public String getGoogleAccountEmail() { return activity.getGoogleAccountEmailForUi(); }
    @JavascriptInterface public String getBridgeVersion() { return "AFZ-GOOGLE-DRIVE-3.2"; }
    @JavascriptInterface public void saveToGoogleDrive(String json) { activity.saveBackupToDrive(json); }
    @JavascriptInterface public void restoreFromGoogleDrive() { activity.restoreBackupFromDrive(); }
    @JavascriptInterface public void signInToGoogleDrive() { activity.signInToGoogleDrive(); }
}
