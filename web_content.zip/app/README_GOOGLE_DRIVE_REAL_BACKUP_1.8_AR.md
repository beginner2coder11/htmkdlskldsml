# النسخ الاحتياطي الحقيقي إلى Google Drive — الإصدار 1.8

تم تغيير النظام من اختيار ملفات Android إلى اتصال مباشر مع Google Drive.

## طريقة العمل
1. اضغط «تسجيل الدخول إلى Google Drive».
2. اختر حساب Google واسمح للتطبيق بالوصول إلى الملفات التي ينشئها التطبيق.
3. اضغط «حفظ نسخة مباشرة في Google Drive».
4. الاسترجاع يبحث عن ملف `AFRIQUIA-FREINS-backup.json` في Drive ويسترجعه مباشرة.

## إعداد Google Cloud المطلوب قبل أول APK
- فعّل **Google Drive API** في مشروع Google Cloud.
- أنشئ OAuth Client من نوع **Android** للحزمة `com.afriquia.freinszemamra`.
- أضف SHA-1 لشهادة توقيع التطبيق (debug أو release حسب APK الذي ستثبته).
- اضبط شاشة OAuth consent وأضف نطاق Drive المطلوب.

هذا المشروع يستخدم `play-services-auth` وتوكن OAuth من Google ثم REST API لـ Drive. لا يستخدم ACTION_CREATE_DOCUMENT أو ACTION_OPEN_DOCUMENT للنسخ الاحتياطي.
