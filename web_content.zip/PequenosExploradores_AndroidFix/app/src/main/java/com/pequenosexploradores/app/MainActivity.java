package com.pequenosexploradores.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.view.HapticFeedbackConstants;
import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.os.Build;
import java.util.Set;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.view.View;
import android.content.SharedPreferences;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ImageView splashView;
    private FrameLayout rootLayout;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingText = null;
    private String speechLanguage = "es";
    private volatile boolean showingGallery = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.rgb(191, 234, 255));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (splashView != null) {
                    splashView.animate().alpha(0f).setDuration(180).withEndAction(new Runnable() {
                        @Override public void run() {
                            if (splashView != null) {
                                rootLayout.removeView(splashView);
                                splashView = null;
                            }
                        }
                    }).start();
                }
            }
        });
        webView.addJavascriptInterface(new Speaker(), "AndroidSpeaker");
        rootLayout.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        splashView = new ImageView(this);
        splashView.setImageResource(com.pequenosexploradores.app.R.drawable.splash_exploradores);
        splashView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splashView.setBackgroundColor(Color.rgb(191, 234, 255));
        rootLayout.addView(splashView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(rootLayout);
        SharedPreferences prefs = getSharedPreferences("exploradores", MODE_PRIVATE);
        speechLanguage = prefs.getString("language", "es");
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    setTtsLanguage(speechLanguage);
                    if (ttsReady && pendingText != null) speak(pendingText);
                }
            }
        });
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    private boolean setTtsLanguage(String language) {
        speechLanguage = "en".equals(language) ? "en" : "es";
        if (tts == null) return false;
        // Preferir español latinoamericano (México) antes que castellano de España.
        Locale[] choices = "en".equals(speechLanguage)
                ? new Locale[]{Locale.US, Locale.UK, Locale.ENGLISH}
                : new Locale[]{new Locale("es", "MX"), new Locale("es", "US"), new Locale("es", "419"), new Locale("es", "ES"), new Locale("es")};
        ttsReady = false;
        for (Locale locale : choices) {
            int result = tts.setLanguage(locale);
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = true;
                break;
            }
        }
        if (ttsReady) configurePreferredVoice();
        getSharedPreferences("exploradores", MODE_PRIVATE).edit().putString("language", speechLanguage).apply();
        if (!ttsReady) {
            final String message = "Instala la voz " + ("en".equals(speechLanguage) ? "inglesa" : "española") + " en Ajustes > Texto a voz";
            runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show(); } });
        }
        return ttsReady;
    }

    private void configurePreferredVoice() {
        if (tts == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice voice : voices) {
                Locale locale = voice.getLocale();
                if (locale == null) continue;
                String lang = locale.getLanguage();
                if ("en".equals(speechLanguage) && !"en".equals(lang)) continue;
                if ("es".equals(speechLanguage) && !"es".equals(lang)) continue;
                String country = locale.getCountry() == null ? "" : locale.getCountry().toUpperCase(Locale.ROOT);
                String name = voice.getName() == null ? "" : voice.getName().toLowerCase(Locale.ROOT);
                int score = 0;
                if ("es".equals(speechLanguage)) {
                    if ("MX".equals(country) || "US".equals(country) || "419".equals(country)) score += 100;
                    if ("ES".equals(country)) score -= 20;
                    if (name.contains("female") || name.contains("woman") || name.contains("mujer") || name.contains("femenina")) score += 30;
                    if (name.contains("male") || name.contains("man") || name.contains("hombre")) score -= 30;
                } else if ("US".equals(country)) score += 20;
                if (!voice.isNetworkConnectionRequired()) score += 5;
                if (voice.getQuality() >= Voice.QUALITY_HIGH) score += 3;
                if (score > bestScore) { bestScore = score; best = voice; }
            }
            if (best != null) tts.setVoice(best);
            tts.setSpeechRate("es".equals(speechLanguage) ? 0.84f : 0.88f);
            tts.setPitch("es".equals(speechLanguage) ? 1.12f : 1.0f);
        } catch (Exception ignored) { }
    }

    private void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (!ttsReady) {
            pendingText = text;
            runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, "Activa o instala una voz en español en Ajustes > Texto a voz", Toast.LENGTH_LONG).show(); } });
            return;
        }
        if (tts.isSpeaking()) return; // No interrumpir ni repetir mientras el audio anterior sigue activo.
        pendingText = null;
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "pequenos-exploradores-" + System.currentTimeMillis());
    }

    private class Speaker {
        @JavascriptInterface public void say(final String text) {
            runOnUiThread(new Runnable() { @Override public void run() { speak(text); } });
        }
        @JavascriptInterface public void setLanguage(final String language) {
            runOnUiThread(new Runnable() { @Override public void run() { setTtsLanguage(language); } });
        }
        @JavascriptInterface public String getLanguage() { return speechLanguage; }
        @JavascriptInterface public boolean isSpeaking() { return tts != null && tts.isSpeaking(); }
        @JavascriptInterface public void vibrate() { runOnUiThread(new Runnable() { @Override public void run() { boolean didVibrate = false; try { Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (v != null && v.hasVibrator()) { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(VibrationEffect.createOneShot(35, 120)); else v.vibrate(35); didVibrate = true; } } catch (Exception ignored) {} try { if (!didVibrate && webView != null) webView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); } catch (Exception ignored) {} } }); }
        @JavascriptInterface public void setPage(final String page) { showingGallery = "gallery".equals(page); }
    }

    @Override public void onBackPressed() {
        if (webView != null && showingGallery) {
            webView.evaluateJavascript("if (typeof goHome === 'function') { goHome(); true; } else { false; }", null);
            showingGallery = false;
        } else {
            super.onBackPressed();
        }
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
