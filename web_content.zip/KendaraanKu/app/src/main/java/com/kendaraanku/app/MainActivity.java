package com.kendaraanku.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final int NOTIF = 20;
    static final int BASE_REQUEST = 100;
    WebView web;
    SharedPreferences sp;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("vehicle", MODE_PRIVATE);
        web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF);
        }
        scheduleFromJson(this, sp.getString("data", "{}"));
    }

    public class Bridge {
        @JavascriptInterface public String getData() { return sp.getString("data", "{}"); }
        @JavascriptInterface public void saveData(String d) {
            sp.edit().putString("data", d).apply();
            scheduleFromJson(MainActivity.this, d);
        }
        @JavascriptInterface public void cancelAll() { cancelAllReminders(MainActivity.this); }
        @JavascriptInterface public void schedule(long millis, String title, String body, int index) {
            scheduleOne(MainActivity.this, millis, title, body, index);
        }
        @JavascriptInterface public void exactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception ignored) { }
            }
        }
    }

    static long dateAtNine(String yyyyMmDd) throws ParseException {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setLenient(false);
        f.setTimeZone(TimeZone.getDefault());
        return f.parse(yyyyMmDd + " 09:00").getTime();
    }

    static void scheduleFromJson(Context context, String json) {
        cancelAllReminders(context);
        try {
            JSONObject o = new JSONObject(json == null ? "{}" : json);
            String nextDate = o.optString("nextDate", "").trim();
            if (nextDate.isEmpty()) return;
            String name = o.optString("name", "kendaraan").trim();
            if (name.isEmpty()) name = "kendaraan";

            int[] days = {7, 3, 1, 0};
            String[] bodies = {
                    "Jadwal servis 7 hari lagi. Saatnya mengatur jadwal servis.",
                    "Jadwal servis 3 hari lagi. Jangan lupa servis kendaraan.",
                    "Besok jadwal servis kendaraan.",
                    "Hari ini jadwal servis kendaraan."
            };
            long serviceDay = dateAtNine(nextDate);
            for (int i = 0; i < days.length; i++) {
                long when = serviceDay - days[i] * 24L * 60L * 60L * 1000L;
                if (when > System.currentTimeMillis()) {
                    scheduleOne(context, when, "Pengingat servis " + name, bodies[i], i);
                }
            }
        } catch (Exception ignored) {
            // Data UI tetap aman; notifikasi hanya dilewati jika tanggal tidak valid.
        }
    }

    static void cancelAllReminders(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < 4; i++) {
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, BASE_REQUEST + i,
                    new Intent(context, ReminderReceiver.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        }
    }

    static void scheduleOne(Context context, long when, String title, String body, int idx) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(context, ReminderReceiver.class)
                .putExtra("title", title)
                .putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, BASE_REQUEST + idx, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }
}
