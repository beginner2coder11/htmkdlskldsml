# KendaraanKu — Android native + notifikasi servis

Aplikasi offline untuk satu kendaraan.

## Pengingat servis
Aplikasi membuat **notifikasi Android biasa**, bukan alarm khusus dan bukan suara buatan aplikasi.

Jadwal yang dibuat tepat 4 kali:
- H-7 — "Jadwal servis 7 hari lagi"
- H-3 — "Jadwal servis 3 hari lagi"
- H-1 — "Besok jadwal servis"
- Hari H — "Hari ini jadwal servis"

Notifikasi memakai suara notifikasi dari sistem/HP. Aplikasi tidak menyediakan suara sendiri.

Pengingat dijadwalkan sekitar pukul 09:00 pada hari yang ditentukan. Jika Android tidak memberikan izin exact alarm, sistem tetap memakai alarm yang diizinkan agar notifikasi tetap dapat muncul.

Setelah jadwal diubah atau servis dicatat, pengingat lama dibatalkan dan jadwal baru dibuat. Jadwal juga dibuat kembali setelah perangkat reboot.

Tidak ada login, backend, cloud, Firebase, iklan, atau backup/restore.
