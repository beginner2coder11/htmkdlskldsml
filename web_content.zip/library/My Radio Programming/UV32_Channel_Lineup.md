# UV-32 Go-Bag Radio — Full Channel Lineup

Complete programming for the Baofeng UV-32 go-bag radios: **704 channels** across **10 zones**. Generated directly from `UV32_Useful_Channels_Reference.csv`.

## Zone Index

| Zone # | Zone Name | Channel Range | Channel Count |
|---|---|---|---|
| 1 | WEATHER+WALKIE | 1-44 | 34 |
| 2 | CANTON HOME | 101-200 | 82 |
| 3 | ATL+GEORGIA | 201-268 | 68 |
| 4 | NORTH GA | 301-353 | 53 |
| 5 | VIRGINIA+DC | 401-483 | 83 |
| 6 | TN+KY | 501-575 | 75 |
| 7 | ALABAMA+FLA | 601-694 | 94 |
| 8 | CAROLINAS | 701-776 | 76 |
| 9 | CANADA ROUTE | 801-879 | 79 |
| 10 | EMERGENCY | 901-960 | 60 |

**v79 changes:** Atlanta + Georgia merged into zone 3 (Georgia moved to ch 239-268); Alabama + Florida merged into zone 7 (Florida moved to ch 644-694). New zone 5 VIRGINIA+DC (ch 401-483: Richmond, South Hill, NoVA/Manassas/Leesburg/Fairfax/Reston, DC/Arlington/Alexandria, I-81 Winchester to Wytheville, Roanoke, Hagerstown MD) and new zone 9 CANADA ROUTE (ch 801-879: Dayton-Toledo-Detroit-Windsor-London-Kitchener-Toronto, Montreal, Quebec City, Plattsburgh/Burlington, I-81/I-87 Albany-Syracuse-Binghamton-Scranton-Harrisburg). Repeater names are AREA + callsign. Source: RepeaterBook (Nov 2026) - verify before relying on them. In Canada, US hams sign e.g. `/VE3` (Ontario) or `/VE2` (Quebec); GMRS is not legal in Canada (FRS channels only, low power).

## Zone 1 — WEATHER+WALKIE

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 1 | WX1 | 162.5500 | RX Only | — | — | FM | High | — |
| 2 | WX2 | 162.4000 | RX Only | — | — | FM | High | — |
| 3 | WX3 | 162.4750 | RX Only | — | — | FM | High | — |
| 4 | WX4 | 162.4250 | RX Only | — | — | FM | High | — |
| 5 | WX5 | 162.4500 | RX Only | — | — | FM | High | — |
| 6 | WX6 | 162.5000 | RX Only | — | — | FM | High | — |
| 7 | WX7 | 162.5250 | RX Only | — | — | FM | High | — |
| 10 | Fralick | 462.5625 | Simplex | — | TSQL 141.3 | NFM | High | — |
| 11 | FRS/GMRS2 | 462.5875 | Simplex | — | — | NFM | High | — |
| 12 | FRS/GMRS3 | 462.6125 | Simplex | — | — | NFM | High | — |
| 13 | FRS/GMRS4 | 462.6375 | Simplex | — | — | NFM | High | — |
| 14 | FRS/GMRS5 | 462.6625 | Simplex | — | — | NFM | High | — |
| 15 | FRS/GMRS6 | 462.6875 | Simplex | — | — | NFM | High | — |
| 16 | FRS/GMRS7 | 462.7125 | Simplex | — | — | NFM | High | — |
| 17 | FRS 8 | 467.5625 | Simplex | — | — | NFM | High | — |
| 18 | FRS 9 | 467.5875 | Simplex | — | — | NFM | High | — |
| 19 | FRS 10 | 467.6125 | Simplex | — | — | NFM | High | — |
| 20 | FRS 11 | 467.6375 | Simplex | — | — | NFM | High | — |
| 21 | FRS 12 | 467.6625 | Simplex | — | — | NFM | High | — |
| 22 | FRS 13 | 467.6875 | Simplex | — | — | NFM | High | — |
| 23 | FRS 14 | 467.7125 | Simplex | — | — | NFM | High | — |
| 24 | FRS/GMRS15 | 462.5500 | Simplex | — | — | NFM | High | — |
| 25 | FRS/GMRS16 | 462.5750 | Simplex | — | — | NFM | High | — |
| 26 | FRS/GMRS17 | 462.6000 | Simplex | — | — | NFM | High | — |
| 27 | FRS/GMRS18 | 462.6250 | Simplex | — | — | NFM | High | — |
| 28 | FRS/GMRS19 | 462.6500 | Simplex | — | — | NFM | High | — |
| 29 | FRS/GMRS20 | 462.6750 | Simplex | — | — | NFM | High | — |
| 30 | FRS/GMRS21 | 462.7000 | Simplex | — | — | NFM | High | — |
| 31 | FRS/GMRS22 | 462.7250 | Simplex | — | — | NFM | High | — |
| 40 | FRALICK TST | 151.8200 | Simplex | — | TSQL 141.3 | FM | Low | MURS channel 1 (151.820) repurposed as a dedicated, legal-power (2W) test channel - same TSQL tone as the real Fralick, for routine range/comms testing without touching the emergency channel |
| 41 | MURS 2 | 151.8800 | Simplex | — | — | FM | High | — |
| 42 | MURS 3 | 151.9400 | Simplex | — | — | FM | High | — |
| 43 | MURS 4 | 154.5700 | Simplex | — | — | FM | High | — |
| 44 | MURS 5 | 154.6000 | Simplex | — | — | FM | High | — |

## Zone 2 — CANTON HOME

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 101 | 2M CALLING | 146.5200 | Simplex | — | — | FM | High | — |
| 102 | 2M SPLX1 | 146.5500 | Simplex | — | — | FM | High | — |
| 103 | 2M SPLX2 | 146.5800 | Simplex | — | — | FM | High | — |
| 104 | 2M SPLX3 | 147.4200 | Simplex | — | — | FM | High | — |
| 105 | 2M SPLX4 | 147.4800 | Simplex | — | — | FM | High | — |
| 106 | 2M SPLX5 | 145.5100 | Simplex | — | — | FM | High | — |
| 107 | 1.25M RPT1 | 224.2000 | - offset | 1.600 | Tone 100.0 | FM | High | KR4FN, Waleska/Pine Log Mtn - 1.25m repeater, -1.6MHz offset (standard 220MHz split) |
| 108 | 1.25M RPT2 | 224.9400 | - offset | 1.600 | Tone 100.0 | FM | High | KJ4JJX, Waleska/Pine Log Mtn - 1.25m repeater, -1.6MHz offset (standard 220MHz split) |
| 109 | CHEROKEE APT | 123.0000 | RX Only | — | — | AM | High | Cherokee County Airport/Grice Field (KCNI) CTAF/Unicom - AM mode, RX only |
| 110 | CHEROKEE WX | 119.8250 | RX Only | — | — | AM | High | Cherokee County Airport/Grice Field (KCNI) AWOS-3 automated weather - AM mode, RX only |
| 111 | 70CM CALLNG | 446.0000 | Simplex | — | — | FM | High | — |
| 112 | 70CM SPLX1 | 446.0250 | Simplex | — | — | FM | High | — |
| 113 | 70CM SPLX2 | 446.0500 | Simplex | — | — | FM | High | — |
| 114 | 70CM SPLX3 | 446.0750 | Simplex | — | — | FM | High | — |
| 115 | 70CM SPLX4 | 446.1000 | Simplex | — | — | FM | High | — |
| 116 | CHER ARES 2 | 145.4300 | - offset | 0.600 | Tone 107.2 | FM | High | WB4NWS, Cherokee County ARES (confirmed via direct RadioReference county page, Aug 2026 - an earlier pass had mistakenly flagged this as unverified/Pickens Co) |
| 117 | CHEROKEE EOC | 443.0750 | + offset | 5.000 | Tone 107.2 | FM | High | WA4EOC, Cherokee County ARES (confirmed still live/analog via direct RadioReference county page, Aug 2026 - an earlier pass had incorrectly excluded this as digital-occupied) |
| 118 | CHEROKEE UHF | 442.0250 | + offset | 5.000 | Tone 127.3 | FM | High | W8QO, analog side of a dual-mode repeater (also runs NXDN digital on the same frequency, not receivable - only analog tone-access side programmed) |
| 121 | CANTON 1 | 145.1900 | Simplex | — | Tone 173.8 | FM | High | — |
| 122 | CANTON 2 | 145.2700 | - offset | 0.600 | Tone 100.0 | FM | High | — |
| 123 | CANTON 3 | 147.0150 | + offset | 0.600 | — | FM | High | KK4YLX, Waleska/Pine Log Mtn - CSQ, no tone (corrected via direct RadioReference county page, Aug 2026; originally sourced as WD4AUX with tone 100.0) |
| 124 | WOODSTOCK | 442.2750 | + offset | 5.000 | Tone 67.0 | FM | High | — |
| 125 | CANTON UHF | 443.8500 | + offset | 5.000 | Tone 192.8 | FM | High | — |
| 131 | 2M SPLX6 | 146.4000 | Simplex | — | — | FM | High | — |
| 132 | 2M SPLX7 | 146.4100 | Simplex | — | — | FM | High | — |
| 133 | 2M SPLX8 | 146.4300 | Simplex | — | — | FM | High | — |
| 134 | 2M SPLX9 | 146.4600 | Simplex | — | — | FM | High | — |
| 135 | 2M SPLX10 | 146.4900 | Simplex | — | — | FM | High | — |
| 136 | 2M SPLX11 | 146.5000 | Simplex | — | — | FM | High | — |
| 137 | 2M SPLX12 | 146.5400 | Simplex | — | — | FM | High | — |
| 138 | 2M SPLX13 | 146.5600 | Simplex | — | — | FM | High | — |
| 139 | 2M SPLX14 | 146.6000 | Simplex | — | — | FM | High | — |
| 140 | 2M SPLX15 | 147.5000 | Simplex | — | — | FM | High | — |
| 141 | 2M SPLX16 | 147.5200 | Simplex | — | — | FM | High | — |
| 142 | 2M SPLX17 | 147.5600 | Simplex | — | — | FM | High | — |
| 143 | 2M SPLX18 | 147.6000 | Simplex | — | — | FM | High | — |
| 144 | 2M SPLX19 | 145.5300 | Simplex | — | — | FM | High | — |
| 145 | 2M SPLX20 | 145.5500 | Simplex | — | — | FM | High | — |
| 146 | DISASTER NET | 145.5700 | Simplex | — | — | FM | High | SATERN net freq |
| 147 | 2M SPLX21 | 145.5900 | Simplex | — | — | FM | High | — |
| 151 | 70CM SPLX5 | 446.1500 | Simplex | — | — | FM | High | — |
| 152 | 70CM SPLX6 | 446.1750 | Simplex | — | — | FM | High | — |
| 153 | 70CM SPLX7 | 446.2000 | Simplex | — | — | FM | High | — |
| 154 | 70CM SPLX8 | 446.2250 | Simplex | — | — | FM | High | — |
| 155 | 70CM SPLX9 | 446.2500 | Simplex | — | — | FM | High | — |
| 156 | SHARED CH | 445.9250 | Simplex | — | — | FM | High | Itinerant/shared coordination freq |
| 157 | 70CM SPLX10 | 446.5000 | Simplex | — | — | FM | High | — |
| 158 | 70CM SPLX11 | 446.5250 | Simplex | — | — | FM | High | — |
| 159 | 70CM SPLX12 | 447.5000 | Simplex | — | — | FM | High | — |
| 160 | 70CM SPLX13 | 447.5250 | Simplex | — | — | FM | High | — |
| 161 | 70CM SPLX14 | 448.0000 | Simplex | — | — | FM | High | — |
| 162 | 70CM SPLX15 | 448.0250 | Simplex | — | — | FM | High | — |
| 171 | BALLGRD PD | 151.4900 | RX Only | — | — | NFM | High | — |
| 172 | CANTON PD | 155.0850 | RX Only | — | — | NFM | High | — |
| 173 | CANTON FD | 156.2175 | RX Only | — | — | NFM | High | — |
| 174 | HOLLYSPR PD | 151.2500 | RX Only | — | — | NFM | High | — |
| 175 | NELSON PD | 154.7625 | RX Only | — | — | NFM | High | — |
| 176 | WOODSTOCK PD | 156.2400 | RX Only | — | — | NFM | High | — |
| 177 | CHER FIRE 1 | 154.2950 | RX Only | — | — | NFM | High | — |
| 178 | CHER FIRE 2 | 154.2650 | RX Only | — | — | NFM | High | — |
| 179 | CHER FIRE 3 | 154.3400 | RX Only | — | — | NFM | High | — |
| 180 | CHER FIRE 6 | 159.4200 | RX Only | — | — | NFM | High | — |
| 181 | NORTHSIDE 1 | 451.4625 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 182 | NORTHSIDE 2 | 451.6375 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 183 | NORTHSIDE 3 | 452.1375 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 184 | NORTHSIDE 4 | 452.8125 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 185 | NORTHSIDE 5 | 456.4625 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 186 | NORTHSIDE 6 | 456.6375 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 187 | NORTHSIDE 7 | 457.1375 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 188 | NORTHSIDE 8 | 457.8125 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 189 | NORTHSIDE 9 | 461.4875 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 190 | NORTHSIDE10 | 462.1125 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 191 | NORTHSIDE11 | 464.8750 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 192 | NORTHSIDE12 | 466.4875 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 193 | NORTHSIDE13 | 467.1125 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 194 | NORTHSIDE14 | 469.8750 | RX Only | — | — | NFM | High | Northside Hospital-Cherokee, Canton GA (FCC Part 90 license) |
| 195 | 1.25M CALL | 223.5000 | Simplex | — | — | FM | High | — |
| 196 | 1.25M SPLX1 | 223.4200 | Simplex | — | — | FM | High | — |
| 197 | 1.25M SPLX2 | 223.4400 | Simplex | — | — | FM | High | — |
| 198 | 1.25M SPLX3 | 223.4600 | Simplex | — | — | FM | High | — |
| 199 | 1.25M SPLX4 | 223.4800 | Simplex | — | — | FM | High | — |
| 200 | 1.25M SPLX5 | 223.5200 | Simplex | — | — | FM | High | — |

## Zone 3 — ATL+GEORGIA

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 201 | ATLANTA 1 | 145.1500 | - offset | 0.600 | Tone 167.9 | FM | High | — |
| 202 | ATLANTA 2 | 146.8200 | - offset | 0.600 | Tone 146.2 | FM | High | — |
| 203 | ROSWELL | 147.0600 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 204 | VILLA RICA | 147.1800 | + offset | 0.600 | Tone 127.3 | FM | High | — |
| 205 | ATLANTA 3 | 147.0750 | + offset | 0.600 | Tone 82.5 | FM | High | — |
| 206 | DEKALB | 146.7600 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 207 | COBB UHF | 443.4500 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 208 | ATLANTA U1 | 442.1000 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 209 | ATLANTA U2 | 442.3250 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 210 | ATLANTA U3 | 440.6000 | + offset | 5.000 | — | FM | High | — |
| 211 | ATLANTA U4 | 444.8250 | + offset | 5.000 | — | FM | High | — |
| 212 | MCDONOUGH | 146.7150 | - offset | 0.600 | Tone 146.2 | FM | High | KI4FVI, Henry Co |
| 213 | MCDONOUGH U | 442.1250 | + offset | 5.000 | Tone 103.5 | FM | High | W9KLS, Henry Co |
| 214 | DOUGLASVL1 | 145.1100 | - offset | 0.600 | Tone 88.5 | FM | High | W4SCR, Douglas Co |
| 215 | DOUGLASVL2 | 147.3600 | + offset | 0.600 | Tone 88.5 | FM | High | W4SCR, Douglas Co |
| 216 | DOUGLASVLU | 444.5750 | + offset | 5.000 | Tone 88.5 | FM | High | W4SCR, Douglas Co |
| 217 | DALLAS GA | 146.9550 | - offset | 0.600 | Tone 77.0 | FM | High | WB4QOJ, Paulding Co |
| 218 | ROCKMART U | 443.4750 | + offset | 5.000 | Tone 77.0 | FM | High | WX4PCA, Paulding Co |
| 219 | DALLAS GA U | 443.7750 | + offset | 5.000 | Tone 114.8 | FM | High | WB2UEV Echolink/AllStar/Skywarn, Paulding Co |
| 220 | FAYETTEVL1 | 145.2100 | - offset | 0.600 | Tone 131.8 | FM | High | KK4GQ, Fayette Co |
| 221 | FAYETTE UHF | 442.5000 | + offset | 5.000 | Tone 77.0 | FM | High | W4PSZ, Fayette Co |
| 222 | FAYETTEVLU | 444.6000 | + offset | 5.000 | Tone 77.0 | FM | High | W4PSZ, Fayette Co |
| 223 | NEWNAN | 145.1300 | - offset | 0.600 | Tone 131.8 | FM | High | K4NRC, Coweta Co |
| 224 | NEWNAN 2 | 147.1650 | + offset | 0.600 | Tone 131.8 | FM | High | K4NRC, Coweta Co |
| 225 | FORSYTH CO | 147.1500 | + offset | 0.600 | — | FM | High | WB4GQX, Forsyth Co |
| 226 | N FULTON ALT | 145.4700 | - offset | 0.600 | Tone 100.0 | FM | High | North Fulton ARES backup repeater |
| 227 | GA SKYWARN | 444.6750 | + offset | 5.000 | Tone 77.0 | FM | High | Statewide Skywarn net-control, Tyrone |
| 228 | EMORY DECAT | 464.1500 | RX Only | — | — | NFM | High | Emory Decatur Hospital Security, DeKalb Co |
| 229 | VA HOSPITAL | 409.4375 | RX Only | — | — | NFM | High | VA Medical Center Atlanta Maintenance, Decatur |
| 230 | WELLSTR DOUG | 463.8125 | RX Only | — | — | NFM | High | WellStar Douglas Hospital Maintenance, Douglasville |
| 231 | PIEDMONT FA1 | 451.8250 | RX Only | — | — | NFM | High | Piedmont Fayette Hospital, Fayetteville |
| 232 | PIEDMONT FA2 | 452.7250 | RX Only | — | — | NFM | High | Piedmont Fayette Hospital, Fayetteville |
| 233 | PIEDMONT FA3 | 464.9625 | RX Only | — | — | NFM | High | Piedmont Fayette Hospital, Fayetteville |
| 234 | PIEDMONT FA4 | 464.5500 | RX Only | — | — | NFM | High | Piedmont Fayette Hospital, Fayetteville |
| 235 | DALLAS GA SO | 155.4300 | RX Only | — | — | NFM | High | Dallas/Paulding Co Sheriff dispatch |
| 236 | DALLAS TAC | 155.5200 | RX Only | — | — | NFM | High | Dallas/Paulding Co Sheriff tactical |
| 237 | FAYETTEVL SO | 155.5950 | RX Only | — | — | NFM | High | Fayetteville/Fayette Co Sheriff dispatch |
| 238 | NEWNAN SO | 155.5650 | RX Only | — | — | NFM | High | Newnan/Coweta Co Sheriff dispatch |
| 239 | SAVANNAH | 146.9700 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 240 | SAVANNAH 2 | 147.2100 | + offset | 0.600 | Tone 210.7 | FM | High | — |
| 241 | SAVANNAH U | 442.7000 | + offset | 5.000 | Tone 123.0 | FM | High | — |
| 242 | AUGUSTA | 145.1100 | - offset | 0.600 | Tone 71.9 | FM | High | — |
| 243 | AUGUSTA2 | 147.1800 | + offset | 0.600 | Tone 71.9 | FM | High | — |
| 244 | AUGUSTA U | 444.9500 | + offset | 5.000 | Tone 71.9 | FM | High | — |
| 245 | MACON | 145.4300 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 246 | MACON 2 | 147.0150 | + offset | 0.600 | Tone 88.5 | FM | High | — |
| 247 | COLUMBUS | 146.7450 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 248 | COLUMBUS U | 442.1000 | + offset | 5.000 | Tone 123.0 | FM | High | — |
| 249 | VALDOSTA1 | 145.1300 | - offset | 0.600 | Tone 141.3 | FM | High | — |
| 250 | VALDOSTA2 | 146.7600 | - offset | 0.600 | Tone 141.3 | FM | High | — |
| 251 | ATHENS GA | 145.3300 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 252 | STATESBORO | 147.1050 | + offset | 0.600 | — | FM | High | KF4DG, Bulloch Co |
| 253 | BRUNSWICK | 145.3300 | - offset | 0.600 | Tone 131.8 | FM | High | AB4KK, Glynn Co |
| 254 | WARNER RB1 | 146.6700 | - offset | 0.600 | Tone 82.5 | FM | High | WM4B Houston Medical, Houston Co |
| 255 | WARNER RB2 | 146.9550 | - offset | 0.600 | Tone 107.2 | FM | High | WR4MG Middle GA RA/Perry, Houston Co |
| 256 | WAYCROSS | 146.6400 | - offset | 0.600 | Tone 141.3 | FM | High | KF4SUY, Ware Co |
| 257 | THOMASVIL1 | 147.0600 | + offset | 0.600 | — | FM | High | W4UCJ, Thomas Co |
| 258 | THOMASVILU | 442.6000 | + offset | 5.000 | — | FM | High | W4UCJ, Thomas Co |
| 259 | AUGUSTA SKY | 145.4900 | - offset | 0.600 | Tone 71.9 | FM | High | Augusta/CSRA weather-spotter net |
| 260 | AUGUSTA ALT | 145.2900 | - offset | 0.600 | Tone 71.9 | FM | High | Augusta, in-town backup site |
| 261 | MACON SKY2 | 146.8050 | - offset | 0.600 | — | FM | High | Central GA regional Skywarn (tone unconfirmed - CSQ) |
| 262 | AUGUSTA MED1 | 456.3125 | RX Only | — | — | NFM | High | Medical College of Georgia/Augusta University Medical Center |
| 263 | AUGUSTA MED2 | 467.4875 | RX Only | — | — | NFM | High | Medical College of Georgia/Augusta University Medical Center |
| 264 | WAYCROSS PD | 154.7250 | RX Only | — | — | NFM | High | Waycross PD, Ware Co (single-source, weaker confidence) |
| 265 | GA SHERIFF1 | 154.9050 | RX Only | — | — | NFM | High | Georgia Statewide Sheriff's Network - base/dispatch output |
| 266 | GA SHERIFF2 | 154.9350 | RX Only | — | — | NFM | High | Georgia Statewide Sheriff's Network - mobile input |
| 267 | GA EMS PTRPT | 155.2050 | RX Only | — | — | NFM | High | Georgia Statewide EMS Patient Reports channel |
| 268 | GA HOSP NET | 155.3400 | RX Only | — | — | NFM | High | Georgia State Hospital Emergency Net (same nationally-reused MED freq as other states' hospital channels) |

## Zone 4 — NORTH GA

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 301 | GAINESVIL1 | 145.3100 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 302 | GAINESVIL2 | 146.6700 | - offset | 0.600 | — | FM | High | — |
| 303 | CORNELIA | 147.1200 | + offset | 0.600 | — | FM | High | — |
| 304 | LAKEMONT U | 443.1500 | + offset | 5.000 | Tone 127.3 | FM | High | — |
| 305 | TOCCOA1 | 145.2500 | - offset | 0.600 | Tone 71.9 | FM | High | — |
| 306 | TOCCOA2 | 147.3300 | + offset | 0.600 | Tone 127.3 | FM | High | — |
| 307 | BLAIRSVIL1 | 147.2100 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 308 | BLAIRSVIL2 | 146.9500 | - offset | 0.600 | Tone 100.0 | FM | High | — |
| 309 | HELEN/CLEV | 146.9100 | - offset | 0.600 | Tone 100.0 | FM | High | — |
| 310 | DALTON | 147.1350 | + offset | 0.600 | Tone 141.3 | FM | High | N4BZJ Skywarn, Whitfield Co |
| 311 | ROME1 | 146.9400 | - offset | 0.600 | Tone 88.5 | FM | High | W4VO, Floyd Co |
| 312 | ROME2 | 147.3000 | + offset | 0.600 | Tone 100.0 | FM | High | N4EBY, Floyd Co |
| 313 | CALHOUN | 146.7450 | - offset | 0.600 | Tone 100.0 | FM | High | K4WOC, Gordon Co |
| 314 | FT MOUNTAIN | 145.2300 | - offset | 0.600 | — | FM | High | W4DRC Dalton ARC, Ft Mountain/Murray Co |
| 315 | RINGGOLD | 146.7150 | - offset | 0.600 | Tone 67.0 | FM | High | W4ABZ, Catoosa Co |
| 316 | CARTERSVILLE | 146.9100 | - offset | 0.600 | Tone 77.0 | FM | High | W4CLM, Bartow Co |
| 317 | SUMMERVILLE | 147.2250 | + offset | 0.600 | Tone 88.5 | FM | High | Chattooga Co |
| 318 | BLUE RIDGE | 443.2250 | + offset | 5.000 | — | FM | High | Fannin Co |
| 319 | ELLIJAY1 | 145.1700 | - offset | 0.600 | Tone 100.0 | FM | High | W4HHH, Gilmer Co |
| 320 | ELLIJAY2 | 146.9850 | - offset | 0.600 | Tone 77.0 | FM | High | KC4ZGN, Gilmer Co |
| 321 | ELLIJAY U | 443.3000 | + offset | 5.000 | Tone 100.0 | FM | High | KK4AFG, Gilmer Co |
| 322 | JASPER1 | 146.8050 | + offset | 0.600 | Tone 100.0 | FM | High | KC4AQS, Pickens Co |
| 323 | JASPER U1 | 443.3750 | + offset | 5.000 | Tone 100.0 | FM | High | KC4AQS Biskey Mtn, Pickens Co |
| 324 | JASPER U2 | 443.5000 | + offset | 5.000 | Tone 100.0 | FM | High | KC4JNN Biskey Mtn, Pickens Co |
| 325 | NE GA MED1 | 458.0250 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 326 | NE GA MED2 | 458.0750 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 327 | NE GA MED3 | 458.1250 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 328 | NE GA MED4 | 463.0000 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 329 | NE GA MED5 | 463.0250 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 330 | NE GA MED6 | 463.0500 | RX Only | — | — | NFM | High | Northeast Georgia Medical Center, Gainesville |
| 331 | HAMILTON 1 | 457.5250 | RX Only | — | — | NFM | High | Hamilton Medical Center, Dalton |
| 332 | HAMILTON 2 | 457.5500 | RX Only | — | — | NFM | High | Hamilton Medical Center, Dalton |
| 333 | HAMILTON 3 | 457.5750 | RX Only | — | — | NFM | High | Hamilton Medical Center, Dalton |
| 334 | HAMILTON 4 | 457.6000 | RX Only | — | — | NFM | High | Hamilton Medical Center, Dalton |
| 335 | FLOYD MED1 | 468.0000 | RX Only | — | — | NFM | High | Floyd Medical Center, Rome |
| 336 | FLOYD MED2 | 468.0500 | RX Only | — | — | NFM | High | Floyd Medical Center, Rome |
| 337 | FLOYD MED3 | 468.1000 | RX Only | — | — | NFM | High | Floyd Medical Center, Rome |
| 338 | FLOYD MED4 | 468.1500 | RX Only | — | — | NFM | High | Floyd Medical Center, Rome |
| 339 | REDMOND REG | 151.0925 | RX Only | — | — | NFM | High | Redmond Regional Medical Center, Rome |
| 340 | ELLIJAY MED1 | 152.0075 | RX Only | — | — | NFM | High | Ellijay/North Georgia Medical Center |
| 341 | ELLIJAY MED2 | 155.3400 | RX Only | — | — | NFM | High | Ellijay/North Georgia Medical Center |
| 342 | HUTCHESON 1 | 153.0200 | RX Only | — | — | NFM | High | Hutcheson Medical Center, Ft Oglethorpe (operational status uncertain - 2015-16 bankruptcy) |
| 343 | HUTCHESON 2 | 153.1550 | RX Only | — | — | NFM | High | Hutcheson Medical Center, Ft Oglethorpe (operational status uncertain - 2015-16 bankruptcy) |
| 344 | FT OGLTHRP1 | 154.2200 | RX Only | — | — | NFM | High | Fort Oglethorpe PD/FD, Catoosa Co |
| 345 | RINGGOLD PS | 154.2800 | RX Only | — | — | NFM | High | Ringgold Public Safety, Catoosa Co |
| 346 | CATOOSA CO1 | 154.8450 | RX Only | — | — | NFM | High | Catoosa Co dispatch 1 |
| 347 | CATOOSA CO2 | 155.3700 | RX Only | — | — | NFM | High | Catoosa Co dispatch 2 |
| 348 | GILMER CO1 | 155.3700 | RX Only | — | — | NFM | High | Gilmer Co dispatch 1 |
| 349 | GILMER CO2 | 158.8125 | RX Only | — | — | NFM | High | Gilmer Co dispatch 2 |
| 350 | PICKENS CO | 150.8050 | RX Only | — | — | NFM | High | Pickens Co Sheriff/dispatch |
| 351 | GORDON CO1 | 159.1725 | RX Only | — | — | NFM | High | Gordon Co dispatch 1 |
| 352 | CALHOUN PD | 160.0800 | RX Only | — | — | NFM | High | Calhoun PD, Gordon Co |
| 353 | HABERSHM SO | 151.3400 | RX Only | — | — | NFM | High | Habersham Co Sheriff dispatch |

## Zone 5 — VIRGINIA+DC

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 401 | RIC KC4VDZ | 147.1350 | + offset | 0.600 | Tone 107.2 | FM | High | KC4VDZ 2m repeater, Richmond (RepeaterBook) |
| 402 | RIC KG4MRA | 145.4300 | - offset | 0.600 | Tone 74.4 | FM | High | KG4MRA 2m repeater, Richmond (RepeaterBook) |
| 403 | RIC N8ELS | 145.1100 | - offset | 0.600 | Tone 74.4 | FM | High | N8ELS 2m repeater, Hanover (RepeaterBook) |
| 404 | RIC KA4CBB | 147.3600 | + offset | 0.600 | — | FM | High | KA4CBB 2m repeater, Chester (RepeaterBook) |
| 405 | RIC WA4FC | 147.3900 | + offset | 0.600 | Tone 74.4 | FM | High | WA4FC 2m repeater, Petersburg (RepeaterBook) |
| 406 | RIC WA4FC | 444.9750 | + offset | 5.000 | Tone 74.4 | FM | High | WA4FC 70cm repeater, Petersburg (RepeaterBook) |
| 407 | RIC KB4MIC | 444.8000 | + offset | 5.000 | Tone 203.5 | FM | High | KB4MIC 70cm repeater, Oilville (RepeaterBook) |
| 408 | RIC WA4FC | 224.5200 | - offset | 1.600 | Tone 74.4 | FM | High | WA4FC 220 repeater, Richmond (RepeaterBook) |
| 409 | RIC KG4MRA | 224.4200 | - offset | 1.600 | Tone 74.4 | FM | High | KG4MRA 220 repeater, Richmond (RepeaterBook) |
| 410 | RIC KD4JLY | 224.3600 | - offset | 1.600 | Tone 74.4 | FM | High | KD4JLY 220 repeater, Powhatan (RepeaterBook) |
| 411 | SHL WA4FC | 147.2400 | + offset | 0.600 | Tone 74.4 | FM | High | WA4FC 2m repeater, South Hill (RepeaterBook) |
| 412 | SHL KB2AHZ | 147.0000 | + offset | 0.600 | Tone 77.0 | FM | High | KB2AHZ 2m repeater, South Hill (RepeaterBook) |
| 413 | SHL W4CMH | 145.4700 | - offset | 0.600 | Tone 82.5 | FM | High | W4CMH 2m repeater, South Hill (RepeaterBook) |
| 414 | SHL KB2AHZ | 443.5250 | + offset | 5.000 | Tone 100.0 | FM | High | KB2AHZ 70cm repeater, South Hill (RepeaterBook) |
| 415 | MAN W4OVH | 146.9700 | - offset | 0.600 | Tone 100.0 | FM | High | W4OVH 2m repeater, Manassas (RepeaterBook) |
| 416 | MAN W4OVH | 146.8650 | - offset | 0.600 | — | FM | High | W4OVH 2m repeater, Manassas (RepeaterBook) |
| 417 | MAN W4OVH | 442.2000 | + offset | 5.000 | Tone 100.0 | FM | High | W4OVH 70cm repeater, Manassas (RepeaterBook) |
| 418 | MAN K4GVT | 443.5000 | + offset | 5.000 | Tone 110.9 | FM | High | K4GVT 70cm repeater, Manassas (RepeaterBook) |
| 419 | MAN W4OVH | 224.6600 | - offset | 1.600 | Tone 100.0 | FM | High | W4OVH 220 repeater, Manassas (RepeaterBook) |
| 420 | MAN KA4DCS | 145.1300 | - offset | 0.600 | Tone 107.2 | FM | High | KA4DCS 2m repeater, Haymarket (RepeaterBook) |
| 421 | MAN W4BRM | 145.4500 | - offset | 0.600 | — | FM | High | W4BRM 2m repeater, Haymarket (RepeaterBook) |
| 422 | MAN W4IY | 147.2400 | + offset | 0.600 | Tone 107.2 | FM | High | W4IY 2m repeater, Woodbridge (RepeaterBook) |
| 423 | MAN W4IY | 444.9000 | + offset | 5.000 | Tone 127.3 | FM | High | W4IY 70cm repeater, Woodbridge (RepeaterBook) |
| 424 | LEE WA4TXE | 146.7000 | - offset | 0.600 | Tone 77.0 | FM | High | WA4TXE 2m repeater, Leesburg (RepeaterBook) |
| 425 | LEE WA4TXE | 442.1000 | + offset | 5.000 | Tone 77.0 | FM | High | WA4TXE 70cm repeater, Leesburg (RepeaterBook) |
| 426 | LEE WB6EFW | 145.1850 | - offset | 0.600 | Tone 103.5 | FM | High | WB6EFW 2m repeater, Leesburg (RepeaterBook) |
| 427 | LEE WB6EFW | 224.0000 | - offset | 1.600 | Tone 123.0 | FM | High | WB6EFW 220 repeater, Leesburg (RepeaterBook) |
| 428 | FFX NV4FM | 146.7900 | - offset | 0.600 | Tone 77.0 | FM | High | NV4FM 2m repeater, Fairfax (RepeaterBook) |
| 429 | FFX NV4FM | 146.9100 | - offset | 0.600 | Tone 77.0 | FM | High | NV4FM 2m repeater, Fairfax (RepeaterBook) |
| 430 | FFX NV4FM | 224.1000 | - offset | 1.600 | Tone 77.0 | FM | High | NV4FM 220 repeater, Fairfax (RepeaterBook) |
| 431 | FFX W4CIA | 147.2100 | + offset | 0.600 | Tone 110.9 | FM | High | W4CIA 2m repeater, Fairfax (RepeaterBook) |
| 432 | FFX K4HTA | 146.6850 | - offset | 0.600 | Tone 110.9 | FM | High | K4HTA 2m repeater, Fairfax (RepeaterBook) |
| 433 | FFX W4AVA | 146.6250 | - offset | 0.600 | Tone 107.2 | FM | High | W4AVA 2m repeater, Fairfax (RepeaterBook) |
| 434 | RES W8RBJ | 147.3750 | + offset | 0.600 | Tone 131.8 | FM | High | W8RBJ 2m repeater, Reston (RepeaterBook) |
| 435 | RES N1RM | 443.0000 | + offset | 5.000 | Tone 88.5 | FM | High | N1RM 70cm repeater, Reston (RepeaterBook) |
| 436 | DC W3DCA | 147.2700 | + offset | 0.600 | Tone 100.0 | FM | High | W3DCA 2m repeater, Washington DC (RepeaterBook) |
| 437 | DC W3DOS | 145.1900 | - offset | 0.600 | Tone 151.4 | FM | High | W3DOS 2m repeater, Washington DC (RepeaterBook) |
| 438 | DC K3VOA | 147.0450 | + offset | 0.600 | Tone 77.0 | FM | High | K3VOA 2m repeater, Washington DC (RepeaterBook) |
| 439 | DC W3NAB | 442.7000 | + offset | 5.000 | Tone 103.5 | FM | High | W3NAB 70cm repeater, Washington DC (RepeaterBook) |
| 440 | ARL WB4MJF | 145.1500 | - offset | 0.600 | Tone 107.2 | FM | High | WB4MJF 2m repeater, Arlington (RepeaterBook) |
| 441 | ARL W4WVP | 145.4700 | - offset | 0.600 | Tone 107.2 | FM | High | W4WVP 2m repeater, Arlington (RepeaterBook) |
| 442 | ARL K4AF | 444.5500 | + offset | 5.000 | Tone 88.5 | FM | High | K4AF 70cm repeater, Arlington (RepeaterBook) |
| 443 | ALX W4HFH | 147.3150 | + offset | 0.600 | Tone 107.2 | FM | High | W4HFH 2m repeater, Alexandria (RepeaterBook) |
| 444 | ALX W4HFH | 444.6000 | + offset | 5.000 | Tone 107.2 | FM | High | W4HFH 70cm repeater, Alexandria (RepeaterBook) |
| 445 | FRY K4QJZ | 145.2100 | - offset | 0.600 | Tone 141.3 | FM | High | K4QJZ 2m repeater, Front Royal (RepeaterBook) |
| 446 | FRY N3UHD | 444.1500 | + offset | 5.000 | Tone 77.0 | FM | High | N3UHD 70cm repeater, Front Royal (RepeaterBook) |
| 447 | WIN W4RKC | 146.8200 | - offset | 0.600 | Tone 146.2 | FM | High | W4RKC 2m repeater, Winchester (RepeaterBook) |
| 448 | WIN KG4Y | 145.3900 | - offset | 0.600 | Tone 146.2 | FM | High | KG4Y 2m repeater, Winchester (RepeaterBook) |
| 449 | WIN W3IF | 442.0000 | + offset | 5.000 | Tone 146.2 | FM | High | W3IF 70cm repeater, Winchester (RepeaterBook) |
| 450 | WIN N3UR | 442.3500 | + offset | 5.000 | Tone 123.0 | FM | High | N3UR 70cm repeater, Winchester (RepeaterBook) |
| 451 | BLU N3JLT | 147.3000 | + offset | 0.600 | Tone 146.2 | FM | High | N3JLT 2m repeater, Bluemont (RepeaterBook) |
| 452 | HBG K4MRA | 145.1300 | - offset | 0.600 | Tone 131.8 | FM | High | K4MRA 2m repeater, Harrisonburg (RepeaterBook) |
| 453 | HBG K4MRA | 444.6000 | + offset | 5.000 | Tone 131.8 | FM | High | K4MRA 70cm repeater, Harrisonburg (RepeaterBook) |
| 454 | HBG K4KLH | 147.2250 | + offset | 0.600 | Tone 131.8 | FM | High | K4KLH 2m repeater, Harrisonburg (RepeaterBook) |
| 455 | HBG N4YSA | 146.6250 | - offset | 0.600 | Tone 131.8 | FM | High | N4YSA 2m repeater, Harrisonburg (RepeaterBook) |
| 456 | HBG KO4CTF | 146.8500 | - offset | 0.600 | Tone 131.8 | FM | High | KO4CTF 2m repeater, Harrisonburg (RepeaterBook) |
| 457 | STN W4GSB | 146.6700 | - offset | 0.600 | Tone 114.8 | FM | High | W4GSB 2m repeater, Staunton (RepeaterBook) |
| 458 | STN N4KYM | 146.7000 | - offset | 0.600 | Tone 131.8 | FM | High | N4KYM 2m repeater, Staunton (RepeaterBook) |
| 459 | STN KG4TIH | 145.1700 | - offset | 0.600 | Tone 123.0 | FM | High | KG4TIH 2m repeater, Staunton (RepeaterBook) |
| 460 | STN WA4TFZ | 146.8950 | - offset | 0.600 | Tone 151.4 | FM | High | WA4TFZ 2m repeater, Staunton (RepeaterBook) |
| 461 | ROA W4KDN | 146.9400 | - offset | 0.600 | Tone 107.2 | FM | High | W4KDN 2m repeater, Roanoke (RepeaterBook) |
| 462 | ROA KF4RGH | 146.8800 | - offset | 0.600 | Tone 107.2 | FM | High | KF4RGH 2m repeater, Roanoke (RepeaterBook) |
| 463 | ROA N4MGQ | 145.3900 | - offset | 0.600 | Tone 107.2 | FM | High | N4MGQ 2m repeater, Roanoke (RepeaterBook) |
| 464 | ROA N4VL | 145.4100 | - offset | 0.600 | Tone 103.5 | FM | High | N4VL 2m repeater, Roanoke (RepeaterBook) |
| 465 | ROA W4CA | 146.9850 | - offset | 0.600 | Tone 107.2 | FM | High | W4CA 2m repeater, Roanoke (RepeaterBook) |
| 466 | ROA K1GG | 146.7450 | - offset | 0.600 | Tone 107.2 | FM | High | K1GG 2m repeater, Roanoke (RepeaterBook) |
| 467 | ROA KN4PDL | 147.2700 | + offset | 0.600 | Tone 100.0 | FM | High | KN4PDL 2m repeater, Roanoke (RepeaterBook) |
| 468 | ROA W4KZK | 442.7500 | + offset | 5.000 | Tone 107.2 | FM | High | W4KZK 70cm repeater, Roanoke (RepeaterBook) |
| 469 | ROA W4WAU | 224.6200 | - offset | 1.600 | Tone 114.8 | FM | High | W4WAU 220 repeater, Roanoke (RepeaterBook) |
| 470 | BED WD4KQI | 147.1050 | + offset | 0.600 | Tone 136.5 | FM | High | WD4KQI 2m repeater, Bedford (RepeaterBook) |
| 471 | BBG N4NRV | 444.6500 | + offset | 5.000 | Tone 107.2 | FM | High | N4NRV 70cm repeater, Blacksburg (RepeaterBook) |
| 472 | BBG W9KIC | 146.7150 | - offset | 0.600 | — | FM | High | W9KIC 2m repeater, Blacksburg (RepeaterBook) |
| 473 | BBG KD4ADL | 145.2100 | - offset | 0.600 | Tone 110.9 | FM | High | KD4ADL 2m repeater, Blacksburg (RepeaterBook) |
| 474 | PUL N4VL | 444.6000 | + offset | 5.000 | Tone 103.5 | FM | High | N4VL 70cm repeater, Pulaski (RepeaterBook) |
| 475 | WYT K4EZ | 147.0150 | + offset | 0.600 | Tone 103.5 | FM | High | K4EZ 2m repeater, Wytheville (RepeaterBook) |
| 476 | WYT K4EZ | 444.3250 | + offset | 5.000 | Tone 103.5 | FM | High | K4EZ 70cm repeater, Wytheville (RepeaterBook) |
| 477 | WYT K4IJ | 146.8650 | - offset | 0.600 | Tone 103.5 | FM | High | K4IJ 2m repeater, Wytheville (RepeaterBook) |
| 478 | WYT K4XE | 442.5250 | + offset | 5.000 | Tone 103.5 | FM | High | K4XE 70cm repeater, Wytheville (RepeaterBook) |
| 479 | GLX W4BRC | 147.0900 | + offset | 0.600 | Tone 103.5 | FM | High | W4BRC 2m repeater, Galax (RepeaterBook) |
| 480 | HIL N4DN | 145.2700 | - offset | 0.600 | Tone 103.5 | FM | High | N4DN 2m repeater, Hillsville (RepeaterBook) |
| 481 | HAG W3CWC | 147.3750 | + offset | 0.600 | Tone 100.0 | FM | High | W3CWC 2m repeater, Hagerstown MD (RepeaterBook) |
| 482 | HAG W3CWC | 146.9400 | - offset | 0.600 | Tone 100.0 | FM | High | W3CWC 2m repeater, Hagerstown MD (RepeaterBook) |
| 483 | HAG W3CWC | 147.0900 | + offset | 0.600 | Tone 100.0 | FM | High | W3CWC 2m repeater, Hagerstown MD (RepeaterBook) |

## Zone 6 — TN+KY

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 501 | NASHVILLE1 | 146.9550 | - offset | 0.600 | Tone 114.8 | FM | High | — |
| 502 | NASHVILLE2 | 147.0150 | + offset | 0.600 | Tone 114.8 | FM | High | — |
| 503 | NASHVILLE3 | 442.7500 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 504 | NASHVILLE U | 442.8000 | + offset | 5.000 | Tone 107.2 | FM | High | — |
| 505 | CHATT 1 | 146.6100 | - offset | 0.600 | Tone 107.2 | FM | High | — |
| 506 | CHATT 2 | 442.4250 | + offset | 5.000 | Tone 94.8 | FM | High | — |
| 507 | CHATT U1 | 444.1000 | + offset | 5.000 | — | FM | High | — |
| 508 | CHATT U2 | 444.9000 | + offset | 5.000 | Tone 94.8 | FM | High | — |
| 509 | KNOXVILLE | 145.3700 | - offset | 0.600 | Tone 100.0 | FM | High | — |
| 510 | GATLINBURG | 147.1950 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 511 | KNOXVILLE U1 | 442.5000 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 512 | KNOXVILLE U2 | 444.5000 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 513 | MEMPHIS | 145.4500 | - offset | 0.600 | Tone 107.2 | FM | High | — |
| 514 | GERMANTOWN | 146.6250 | - offset | 0.600 | Tone 107.2 | FM | High | — |
| 515 | MEMPHIS2 | 146.8200 | - offset | 0.600 | Tone 107.2 | FM | High | — |
| 516 | MEMPHIS U | 444.4000 | + offset | 5.000 | Tone 107.2 | FM | High | — |
| 517 | JACKSON1 | 145.1700 | - offset | 0.600 | Tone 107.2 | FM | High | Madison Co |
| 518 | JACKSON2 | 145.3100 | - offset | 0.600 | Tone 107.2 | FM | High | Madison Co |
| 519 | JOHNSON CITY | 146.7900 | - offset | 0.600 | Tone 131.8 | FM | High | W4ABR, Washington Co |
| 520 | SULPHUR SPG | 147.1200 | Simplex | — | Tone 118.8 | FM | High | W4DWQ, Washington Co (simplex per source) |
| 521 | CLARKSVILLE | 147.3900 | + offset | 0.600 | — | FM | High | KF4L CATS, Montgomery Co |
| 522 | COOKEVILLE | 147.2100 | + offset | 0.600 | Tone 107.2 | FM | High | W4HPL, Putnam Co |
| 523 | MURFREESBORO | 145.2300 | - offset | 0.600 | Tone 114.8 | FM | High | W4CAT Skywarn, Rutherford Co |
| 524 | BRISTOL1 | 146.7000 | - offset | 0.600 | — | FM | High | KE4CCB, Sullivan Co |
| 525 | BRISTOL2 | 146.8800 | - offset | 0.600 | — | FM | High | WD4CYZ, Sullivan Co |
| 526 | NASH SKY2 | 146.6700 | - offset | 0.600 | — | FM | High | Nashville ARC backup/info net |
| 527 | CHATT EOC | 154.1600 | RX Only | — | — | NFM | High | — |
| 528 | CHATT SKY2 | 146.7900 | - offset | 0.600 | — | FM | High | W4AM Signal Mtn, Chattanooga backup Skywarn |
| 529 | E RIDGE FD | 154.3100 | RX Only | — | — | NFM | High | — |
| 530 | RED BANK FD | 154.3250 | RX Only | — | — | NFM | High | — |
| 531 | SODDY DAISY | 154.4150 | RX Only | — | — | NFM | High | — |
| 532 | KNOX CO FIRE | 154.4300 | RX Only | — | — | NFM | High | — |
| 533 | ETN SKYWARN | 147.3000 | + offset | 0.600 | Tone 107.2 | FM | High | East TN regional Skywarn (Knox/Loudon/Blount/Sevier) |
| 534 | ETN SKY2 | 146.9400 | - offset | 0.600 | — | FM | High | East TN Skywarn backup repeater |
| 535 | ETN SKY SPLX | 147.4200 | Simplex | — | — | FM | High | — |
| 536 | MEM FIRE PG | 154.2350 | RX Only | — | — | NFM | High | — |
| 537 | SHELBY EMA | 155.8950 | RX Only | — | — | NFM | High | — |
| 538 | LOUISVIL1 | 147.0300 | + offset | 0.600 | Tone 151.4 | FM | High | — |
| 539 | LOUISVIL2 | 147.1800 | + offset | 0.600 | Tone 79.7 | FM | High | — |
| 540 | LOUISVIL3 | 442.0000 | + offset | 5.000 | Tone 146.2 | FM | High | — |
| 541 | LEXINGTN1 | 146.7600 | - offset | 0.600 | Tone 67.0 | FM | High | — |
| 542 | LEXINGTN2 | 444.8750 | + offset | 5.000 | Tone 67.0 | FM | High | — |
| 543 | LEXINGTN3 | 146.9400 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 544 | BOWLGRN1 | 147.1650 | + offset | 0.600 | — | FM | High | — |
| 545 | BOWLGRN2 | 147.3300 | + offset | 0.600 | Tone 107.2 | FM | High | — |
| 546 | LONDON1 | 147.1800 | + offset | 0.600 | Tone 74.4 | FM | High | — |
| 547 | LONDON2 | 442.9000 | + offset | 5.000 | Tone 77.0 | FM | High | — |
| 548 | SOMERST1 | 146.8800 | - offset | 0.600 | Tone 77.0 | FM | High | — |
| 549 | SOMERST2 | 443.6000 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 550 | RICHMOND1 | 145.3700 | - offset | 0.600 | Tone 192.8 | FM | High | — |
| 551 | RICHMOND2 | 444.6250 | + offset | 5.000 | Tone 192.8 | FM | High | — |
| 552 | FRANKFRT1 | 147.2400 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 553 | OWENSBOR1 | 145.3300 | - offset | 0.600 | Tone 103.5 | FM | High | — |
| 554 | OWENSBOR2 | 147.2100 | + offset | 0.600 | Tone 146.2 | FM | High | — |
| 555 | PADUCAH1 | 146.7600 | - offset | 0.600 | Tone 179.9 | FM | High | — |
| 556 | PADUCAH2 | 147.0600 | + offset | 0.600 | Tone 179.9 | FM | High | — |
| 557 | COVNGTN1 | 147.3900 | + offset | 0.600 | — | FM | High | — |
| 558 | COVNGTN2 | 442.5250 | + offset | 5.000 | — | FM | High | — |
| 559 | JTOWN PW | 155.9550 | RX Only | — | — | NFM | High | — |
| 560 | LOUISVIL FD | 152.0075 | RX Only | — | — | NFM | High | Jefferson Co Suburban Fire District (Louisville) |
| 561 | LOUISVIL MA | 154.2950 | RX Only | — | — | NFM | High | Louisville-area fire mutual aid |
| 562 | HARRODS FD | 155.3400 | RX Only | — | — | NFM | High | — |
| 563 | JEFF SKYWARN | 147.1350 | + offset | 0.600 | — | FM | High | Louisville/Jefferson Co ham Skywarn net |
| 564 | JEFF SKY ALT | 146.5500 | Simplex | — | — | FM | High | — |
| 565 | LEXINGTN TC1 | 154.2650 | RX Only | — | — | NFM | High | Central KY Firefighters Assn TAC 1 |
| 566 | LEXINGTN TC2 | 154.2800 | RX Only | — | — | NFM | High | Central KY Firefighters Assn TAC 2 |
| 567 | LEXINGTN TC3 | 154.2950 | RX Only | — | — | NFM | High | Central KY Firefighters Assn TAC 3 |
| 568 | NASH MED NET | 463.0250 | RX Only | — | — | NFM | High | Vanderbilt University Medical Center ER - shared regional med-net freq, not dedicated |
| 569 | MEMPHIS MED1 | 453.0250 | RX Only | — | — | NFM | High | Baptist Memorial Hospital-Memphis (927 beds, region's largest) |
| 570 | MEMPHIS MED2 | 462.1500 | RX Only | — | — | NFM | High | Baptist Memorial Hospital-Memphis (927 beds, region's largest) |
| 571 | MEMPHIS MED3 | 462.7750 | RX Only | — | — | NFM | High | Baptist Memorial Hospital-Memphis (927 beds, region's largest) |
| 572 | MEMPHIS MED4 | 462.8500 | RX Only | — | — | NFM | High | Baptist Memorial Hospital-Memphis (927 beds, region's largest) |
| 573 | LOUISVIL MED | 464.0250 | RX Only | — | — | NFM | High | Norton Hospital downtown, Louisville (605 beds) - analog variant, distinct from a DMR variant on same freq |
| 574 | LEXINGTN MD1 | 463.8750 | RX Only | — | — | NFM | High | UK Chandler Hospital, Lexington |
| 575 | LEXINGTN MD2 | 461.8625 | RX Only | — | — | NFM | High | UK Chandler Hospital, Lexington - LTR trunked system, but analog under the hood |

## Zone 7 — ALABAMA+FLA

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 601 | BIRMINGHAM1 | 146.8800 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 602 | BIRMINGHAM2 | 146.7600 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 603 | BIRMINGHAM3 | 147.2800 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 604 | BHAM UHF1 | 444.1000 | + offset | 5.000 | Tone 162.2 | FM | High | — |
| 605 | BHAM UHF2 | 442.5250 | + offset | 5.000 | Tone 156.7 | FM | High | — |
| 606 | MONTGOMERY | 146.8400 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 607 | MONTGOMERY2 | 147.1800 | + offset | 0.600 | Tone 123.0 | FM | High | — |
| 608 | MONTGOMERY3 | 147.2000 | + offset | 0.600 | Tone 107.2 | FM | High | — |
| 609 | MONTGOMERYU | 444.5000 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 610 | HUNTSVILLE | 147.2200 | + offset | 0.600 | Tone 136.5 | FM | High | — |
| 611 | HUNTSVILLE3 | 147.1400 | + offset | 0.600 | Tone 100.0 | FM | High | — |
| 612 | HUNTSVILLE4 | 444.5750 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 613 | HUNTSVILLE5 | 442.7750 | + offset | 5.000 | Tone 107.2 | FM | High | — |
| 614 | HUNTSVILLE6 | 147.3000 | + offset | 0.600 | Tone 103.5 | FM | High | — |
| 615 | MOBILE1 | 146.8200 | - offset | 0.600 | Tone 203.5 | FM | High | W4IAX, Mobile Co |
| 616 | MOBILE2 | 147.1200 | + offset | 0.600 | Tone 151.4 | FM | High | K4AN, Mobile Co |
| 617 | TUSCALOOSA1 | 146.8200 | - offset | 0.600 | Tone 118.8 | FM | High | W4XI, Tuscaloosa Co |
| 618 | TUSCALOOSA2 | 147.2400 | + offset | 0.600 | Tone 186.2 | FM | High | KR4ET, Tuscaloosa Co |
| 619 | DOTHAN | 147.1400 | + offset | 0.600 | Tone 186.2 | FM | High | KC4JBF, Houston Co |
| 620 | AUBURN | 147.1200 | + offset | 0.600 | — | FM | High | W4LEE, Lee Co |
| 621 | AUBURN 2 | 147.1500 | + offset | 0.600 | Tone 123.0 | FM | High | WX4LEE, Lee Co |
| 622 | DECATUR AL | 147.0000 | + offset | 0.600 | Tone 123.0 | FM | High | W4ATD Skywarn, Morgan Co |
| 623 | GADSDEN | 147.1600 | + offset | 0.600 | Tone 100.0 | FM | High | K4JMC, Etowah Co |
| 624 | MONTGOM U2 | 444.4500 | + offset | 5.000 | Tone 100.0 | FM | High | Montgomery, WD4JRB EchoLink |
| 625 | HUNTSVL SKY | 146.9400 | - offset | 0.600 | Tone 100.0 | FM | High | Huntsville/NARA primary Skywarn net |
| 626 | N ALA SKY | 147.3600 | + offset | 0.600 | — | FM | High | 11-county regional Skywarn (tone unconfirmed) |
| 627 | MOBILE UHF | 444.5000 | + offset | 5.000 | Tone 123.0 | FM | High | WB4QEV, confirmed Mobile 70cm |
| 628 | AL FIRE MUT | 155.0400 | RX Only | — | — | NFM | High | Alabama statewide fire mutual aid |
| 629 | AL LAW MUT | 155.0100 | RX Only | — | — | NFM | High | Alabama statewide law-enforcement mutual aid |
| 630 | DCH SECURITY | 461.1500 | RX Only | — | — | NFM | High | DCH Regional Medical Center Security, Tuscaloosa |
| 631 | DCH MAINT | 464.7000 | RX Only | — | — | NFM | High | DCH Regional Medical Center Maintenance, Tuscaloosa |
| 632 | BAPTIST MGM | 464.8250 | RX Only | — | — | NFM | High | Baptist Medical Center South, Montgomery (license possibly expired) |
| 633 | JACKSON HOS1 | 452.2250 | RX Only | — | — | NFM | High | Jackson Hospital, Montgomery |
| 634 | JACKSON HOS2 | 451.3250 | RX Only | — | — | NFM | High | Jackson Hospital, Montgomery |
| 635 | UAB MED WEST | 464.9250 | RX Only | — | — | NFM | High | UAB Medical West, Bessemer (satellite facility - not the main downtown UAB campus) |
| 636 | HUNTSVL HOSP | 155.3400 | RX Only | — | — | NFM | High | Huntsville Hospital |
| 637 | USA MED CTR | 155.3400 | RX Only | — | — | NFM | High | USA Medical Center, Mobile |
| 638 | PROVIDENCE | 155.3400 | RX Only | — | — | NFM | High | Providence Hospital, Mobile |
| 639 | SPRINGHILL | 155.3400 | RX Only | — | — | NFM | High | Springhill Medical Center, Mobile |
| 640 | SE HEALTH DT | 155.3400 | RX Only | — | — | NFM | High | Southeast Health Medical Center, Dothan |
| 641 | DECATUR HOSP | 155.3400 | RX Only | — | — | NFM | High | Decatur Morgan Hospital, Decatur |
| 642 | GADSDEN HOSP | 155.3400 | RX Only | — | — | NFM | High | Gadsden Regional Medical Center, Gadsden |
| 643 | RIVERVIEW HP | 155.3400 | RX Only | — | — | NFM | High | Riverview Regional Medical Center, Gadsden |
| 644 | JACKSONVL1 | 146.7600 | - offset | 0.600 | Tone 127.3 | FM | High | — |
| 645 | JACKSONVL2 | 147.3150 | + offset | 0.600 | Tone 127.3 | FM | High | — |
| 646 | JACKSONVL3 | 146.9550 | - offset | 0.600 | Tone 127.3 | FM | High | — |
| 647 | JACKSONVLU1 | 444.6750 | + offset | 5.000 | Tone 127.3 | FM | High | — |
| 648 | JACKSONVLU2 | 444.9250 | + offset | 5.000 | Tone 127.3 | FM | High | — |
| 649 | ORLANDO | 146.7300 | - offset | 0.600 | Tone 103.5 | FM | High | — |
| 650 | DISNEY | 147.3000 | + offset | 0.600 | Tone 103.5 | FM | High | — |
| 651 | DISNEY U | 442.0000 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 652 | ORLANDO 2 | 443.0500 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 653 | BITHLO | 442.6200 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 654 | TAMPA 1 | 146.7900 | - offset | 0.600 | Tone 146.2 | FM | High | — |
| 655 | TAMPA 2 | 147.1000 | + offset | 0.600 | Tone 146.2 | FM | High | — |
| 656 | BRANDON FL | 147.1650 | + offset | 0.600 | Tone 136.5 | FM | High | — |
| 657 | TAMPA U1 | 444.2200 | + offset | 5.000 | Tone 146.2 | FM | High | — |
| 658 | TAMPA U2 | 442.7200 | + offset | 5.000 | Tone 146.2 | FM | High | — |
| 659 | MIAMI 1 | 146.7000 | - offset | 0.600 | Tone 100.0 | FM | High | KI4IJQ linked, Miami-Dade Co |
| 660 | MIAMI 2 | 147.0000 | - offset | 0.600 | Tone 94.8 | FM | High | W4NVU Dade Radio Twr, Miami-Dade Co |
| 661 | POMPANO | 146.6100 | - offset | 0.600 | Tone 110.9 | FM | High | W4BUG, Broward Co |
| 662 | FTLAUDERDALE | 146.9100 | - offset | 0.600 | Tone 110.9 | FM | High | W4AB, Broward Co |
| 663 | TALLAHASSEE1 | 146.9100 | - offset | 0.600 | Tone 94.8 | FM | High | K4TLH, Leon Co |
| 664 | TALLAHASSEE2 | 147.0300 | + offset | 0.600 | Tone 94.8 | FM | High | K4TLH, Leon Co |
| 665 | PENSACOLA | 146.7600 | - offset | 0.600 | Tone 100.0 | FM | High | W4UC, Escambia Co |
| 666 | FT WALTON | 147.0000 | + offset | 0.600 | Tone 100.0 | FM | High | W4RH, Escambia Co |
| 667 | GAINESVL FL | 146.8200 | - offset | 0.600 | Tone 123.0 | FM | High | GARS, Alachua Co |
| 668 | GAINESVLFL2 | 146.9100 | - offset | 0.600 | Tone 123.0 | FM | High | W4DFU, Alachua Co |
| 669 | NAPLES | 146.6700 | - offset | 0.600 | Tone 136.5 | FM | High | WB2QLP, Collier Co |
| 670 | NAPLES 2 | 147.0300 | + offset | 0.600 | Tone 136.5 | FM | High | K4YHB, Collier Co |
| 671 | JACKSONVL4 | 146.7000 | - offset | 0.600 | Tone 127.3 | FM | High | Jacksonville RACES/ARES-linked |
| 672 | ORLANDO SW | 444.1250 | + offset | 5.000 | Tone 103.5 | FM | High | Orange Co ARES, SW Orange |
| 673 | ORLANDO AP | 443.5250 | + offset | 5.000 | Tone 103.5 | FM | High | Orange Co ARES, linked to airport |
| 674 | TAMPA AREA | 442.5500 | + offset | 5.000 | Tone 100.0 | FM | High | West Central FL ARES Net |
| 675 | TAMPA SKYWRN | 145.4300 | - offset | 0.600 | Tone 100.0 | FM | High | Tampa Bay-area linked Skywarn |
| 676 | MIAMI 3 | 146.7600 | - offset | 0.600 | Tone 94.8 | FM | High | South FL FM Assn, U. Miami |
| 677 | MIAMI 4 | 444.2000 | + offset | 5.000 | Tone 94.8 | FM | High | South FL FM Assn, Coral Gables |
| 678 | GNVL MED1 | 464.2000 | RX Only | — | — | NFM | High | UF Health Shands Hospital, Gainesville |
| 679 | GNVL MED2 | 464.5250 | RX Only | — | — | NFM | High | UF Health Shands Hospital, Gainesville |
| 680 | TAMPA MED1 | 464.9750 | RX Only | — | — | NFM | High | Tampa General Hospital |
| 681 | TAMPA MED2 | 464.6750 | RX Only | — | — | NFM | High | Tampa General Hospital |
| 682 | TAMPA MED3 | 464.4750 | RX Only | — | — | NFM | High | Tampa General Hospital |
| 683 | ORLANDO MD1 | 461.2500 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 684 | ORLANDO MD2 | 464.2750 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 685 | ORLANDO MD3 | 464.6250 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 686 | ORLANDO MD4 | 452.6250 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 687 | ORLANDO MD5 | 463.4500 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 688 | ORLANDO MD6 | 464.2500 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 689 | ORLANDO MD7 | 155.2650 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 690 | ORLANDO MD8 | 163.2500 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 691 | ORLANDO MD9 | 155.3400 | RX Only | — | — | NFM | High | Orlando Health/Orlando Regional Medical Center |
| 692 | JAX BAPTIST | 464.8750 | RX Only | — | — | NFM | High | Baptist Medical Center Downtown, Jacksonville |
| 693 | UF HLTH JAX1 | 463.7875 | RX Only | — | — | NFM | High | UF Health Jacksonville |
| 694 | UF HLTH JAX2 | 461.7625 | RX Only | — | — | NFM | High | UF Health Jacksonville |

## Zone 8 — CAROLINAS

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 701 | CHARLOTTE1 | 442.1250 | + offset | 5.000 | Tone 156.7 | FM | High | — |
| 702 | CHARLOTTE2 | 444.1750 | + offset | 5.000 | Tone 110.9 | FM | High | — |
| 703 | CHARLOTTE3 | 147.2250 | + offset | 0.600 | Tone 110.9 | FM | High | — |
| 704 | BANNER ELK | 444.4000 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 705 | LANSING NC | 444.3000 | + offset | 5.000 | Tone 103.5 | FM | High | — |
| 706 | RALEIGH | 146.6400 | - offset | 0.600 | — | FM | High | — |
| 707 | RALEIGH 2 | 146.8800 | - offset | 0.600 | Tone 82.5 | FM | High | — |
| 708 | CARY | 444.7750 | + offset | 5.000 | Tone 100.0 | FM | High | — |
| 709 | RALEIGH U | 444.3000 | + offset | 5.000 | Tone 82.5 | FM | High | — |
| 710 | GREENSBORO | 146.7600 | - offset | 0.600 | Tone 156.7 | FM | High | K4GWH, Guilford Co |
| 711 | WINSTON1 | 145.2500 | - offset | 0.600 | Tone 97.4 | FM | High | W4GG, Forsyth Co |
| 712 | WINSTON2 | 146.6400 | - offset | 0.600 | Tone 100.0 | FM | High | W4NC, Forsyth Co |
| 713 | FAYETTEV NC | 146.9100 | - offset | 0.600 | Tone 131.8 | FM | High | Cumberland Co |
| 714 | WILMINGTON1 | 146.8200 | - offset | 0.600 | Tone 88.5 | FM | High | N4ILM PCRN, New Hanover Co |
| 715 | WILMINGTON2 | 147.1800 | + offset | 0.600 | Tone 88.5 | FM | High | AC4RC, New Hanover Co |
| 716 | BOONE NC | 147.3600 | + offset | 0.600 | Tone 103.5 | FM | High | WA4J, Watauga Co |
| 717 | HICKORY | 145.4900 | - offset | 0.600 | Tone 146.2 | FM | High | KF4LUC, Catawba Co |
| 718 | ASHEVIL2 | 146.9100 | - offset | 0.600 | Tone 91.5 | FM | High | W4MOE, genuine Asheville-area repeater |
| 719 | CHARLOTTE EM | 146.9400 | - offset | 0.600 | Tone 118.8 | FM | High | Mecklenburg ARES/Metrolina Emergency Net |
| 720 | S WAKE ARC | 145.2100 | - offset | 0.600 | Tone 82.5 | FM | High | South Wake ARC, Garner NC |
| 721 | JOHNSTN ARES | 147.2700 | + offset | 0.600 | Tone 100.0 | FM | High | Johnston Co ARES |
| 722 | GREENVIL1 | 146.8200 | - offset | 0.600 | — | FM | High | — |
| 723 | GREENVIL2 | 146.9400 | - offset | 0.600 | Tone 107.2 | FM | High | — |
| 724 | SPARTANB1 | 147.0900 | + offset | 0.600 | Tone 162.2 | FM | High | — |
| 725 | SPARTANB2 | 442.0750 | + offset | 5.000 | Tone 123.0 | FM | High | — |
| 726 | COLUMBIA1 | 147.3300 | + offset | 0.600 | Tone 156.7 | FM | High | — |
| 727 | COLUMBIA2 | 146.7150 | - offset | 0.600 | Tone 91.5 | FM | High | — |
| 728 | CHARLEST1 | 146.7300 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 729 | CHARLEST2 | 146.6100 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 730 | MYRTLEB1 | 147.2400 | + offset | 0.600 | Tone 85.4 | FM | High | — |
| 731 | MYRTLEB2 | 147.1200 | + offset | 0.600 | Tone 85.4 | FM | High | — |
| 732 | ANDERSON1 | 146.7900 | - offset | 0.600 | Tone 127.3 | FM | High | — |
| 733 | ANDERSON2 | 146.9700 | - offset | 0.600 | Tone 127.3 | FM | High | — |
| 734 | AIKEN1 | 145.1600 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 735 | AIKEN2 | 441.5250 | + offset | 5.000 | Tone 91.5 | FM | High | — |
| 736 | FLORENCE1 | 147.1950 | + offset | 0.600 | Tone 123.0 | FM | High | — |
| 737 | FLORENCE2 | 146.8500 | - offset | 0.600 | Tone 123.0 | FM | High | — |
| 738 | ROCKHILL1 | 147.0300 | - offset | 0.600 | Tone 88.5 | FM | High | — |
| 739 | ROCKHILL2 | 444.9250 | + offset | 5.000 | Tone 91.5 | FM | High | — |
| 740 | CLEMSON1 | 147.1950 | + offset | 0.600 | Tone 141.3 | FM | High | — |
| 741 | CLEMSON2 | 442.1250 | + offset | 5.000 | Tone 127.3 | FM | High | — |
| 742 | GREENVIL FD1 | 154.2800 | RX Only | — | — | NFM | High | South Greenville Fire fireground/tac 1 |
| 743 | GREENVIL FD2 | 154.4150 | RX Only | — | — | NFM | High | South Greenville Fire fireground/tac 2 |
| 744 | MAULDIN FD | 460.3750 | RX Only | — | — | NFM | High | — |
| 745 | TRAVLRS RST | 453.4000 | RX Only | — | — | NFM | High | — |
| 746 | NE COLA FIRE | 453.4000 | RX Only | — | — | NFM | High | — |
| 747 | NW COLA FIRE | 453.4500 | RX Only | — | — | NFM | High | — |
| 748 | SE RICHLND | 453.9250 | RX Only | — | — | NFM | High | — |
| 749 | N RICHLND FD | 453.9750 | RX Only | — | — | NFM | High | — |
| 750 | CLT MEDCTR1 | 463.2625 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 751 | CLT MEDCTR2 | 452.4000 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 752 | CLT MEDCTR3 | 464.6000 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 753 | CLT MEDCTR4 | 464.7500 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 754 | CLT MEDCTR5 | 463.7750 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 755 | CLT MEDCTR6 | 464.3000 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 756 | CLT MEDCTR7 | 463.9500 | RX Only | — | — | NFM | High | Atrium Health Carolinas Medical Center, Charlotte |
| 757 | MUSC CHARL1 | 461.0250 | RX Only | — | — | NFM | High | MUSC Health, Charleston |
| 758 | MUSC CHARL2 | 155.3250 | RX Only | — | — | NFM | High | MUSC Health, Charleston |
| 759 | COLA MED1 | 153.8450 | RX Only | — | — | NFM | High | Prisma Health Richland Hospital, Columbia |
| 760 | COLA MED2 | 155.1600 | RX Only | — | — | NFM | High | Prisma Health Richland Hospital, Columbia |
| 761 | COLA PROVID | 469.5000 | RX Only | — | — | NFM | High | Providence Health Columbia |
| 762 | RALEIGH MED | 463.8750 | RX Only | — | — | NFM | High | Rex Hospital, Raleigh |
| 763 | GRNVL MED1 | 155.2800 | RX Only | — | — | NFM | High | Greenville Memorial Hospital (legacy license - may have migrated to newer DMR network) |
| 764 | GRNVL MED2 | 463.9000 | RX Only | — | — | NFM | High | Greenville Memorial Hospital (legacy license - may have migrated to newer DMR network) |
| 765 | SPARTANB MED | 463.2375 | RX Only | — | — | NFM | High | Spartanburg Regional/Mary Black Medical Center |
| 766 | MYRTLEB MED | 463.5875 | RX Only | — | — | NFM | High | Grand Strand Medical Center, Myrtle Beach (source frequency digit-order ambiguous; nearest valid tuning-grid value used) |
| 767 | FLORENCE MED | 466.3750 | RX Only | — | — | NFM | High | McLeod Health, Florence |
| 768 | RCKHILL MED1 | 451.3250 | RX Only | — | — | NFM | High | Piedmont Medical Center, Rock Hill campus |
| 769 | RCKHILL MED2 | 452.1250 | RX Only | — | — | NFM | High | Piedmont Medical Center, Rock Hill campus |
| 770 | FT MILL MED1 | 463.3250 | RX Only | — | — | NFM | High | Piedmont Medical Center, Fort Mill campus |
| 771 | FT MILL MED2 | 451.9750 | RX Only | — | — | NFM | High | Piedmont Medical Center, Fort Mill campus |
| 772 | BOONE NC PD | 155.1300 | RX Only | — | — | NFM | High | Boone PD, Watauga Co NC |
| 773 | HICKORY PD | 155.7000 | RX Only | — | — | NFM | High | Hickory PD, Catawba Co NC (backup channel only) |
| 774 | AIKEN DPS | 453.6500 | RX Only | — | — | NFM | High | Aiken Dept of Public Safety, SC (marginal signal, patched-interop caveat) |
| 775 | FLORENCE TC1 | 460.1500 | RX Only | — | — | NFM | High | Florence Co Law Enforcement Tactical 1, SC |
| 776 | FLORENCE TC2 | 460.5500 | RX Only | — | — | NFM | High | Florence Co Law Enforcement Tactical 2, SC |

## Zone 9 — CANADA ROUTE

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 801 | DAY W8BI | 146.9400 | - offset | 0.600 | Tone 123.0 | FM | High | W8BI 2m repeater, Dayton OH (RepeaterBook) |
| 802 | DAY WF8M | 146.9850 | - offset | 0.600 | Tone 123.0 | FM | High | WF8M 2m repeater, Dayton OH (RepeaterBook) |
| 803 | DAY WA8PLZ | 146.8200 | - offset | 0.600 | Tone 77.0 | FM | High | WA8PLZ 2m repeater, Dayton OH (RepeaterBook) |
| 804 | DAY K8MCA | 146.6400 | - offset | 0.600 | Tone 123.0 | FM | High | K8MCA 2m repeater, Dayton OH (RepeaterBook) |
| 805 | DAY W8BI | 442.1000 | + offset | 5.000 | Tone 123.0 | FM | High | W8BI 70cm repeater, Dayton OH (RepeaterBook) |
| 806 | FIN KC8EPF | 146.6850 | - offset | 0.600 | — | FM | High | KC8EPF 2m repeater, New Riegel OH (RepeaterBook) |
| 807 | TOL K8ALB | 146.6100 | - offset | 0.600 | Tone 103.5 | FM | High | K8ALB 2m repeater, Toledo OH (RepeaterBook) |
| 808 | TOL W8HHF | 146.8350 | - offset | 0.600 | Tone 103.5 | FM | High | W8HHF 2m repeater, Toledo OH (RepeaterBook) |
| 809 | TOL N8LPQ | 146.9400 | - offset | 0.600 | Tone 103.5 | FM | High | N8LPQ 2m repeater, Toledo OH (RepeaterBook) |
| 810 | TOL W8HHF | 147.2700 | + offset | 0.600 | Tone 103.5 | FM | High | W8HHF 2m repeater, Toledo OH (RepeaterBook) |
| 811 | TOL W8RZM | 147.3750 | + offset | 0.600 | Tone 103.5 | FM | High | W8RZM 2m repeater, Toledo OH (RepeaterBook) |
| 812 | TOL N8LPQ | 444.9500 | + offset | 5.000 | Tone 103.5 | FM | High | N8LPQ 70cm repeater, Toledo OH (RepeaterBook) |
| 813 | DET WR8DAR | 145.3300 | - offset | 0.600 | Tone 100.0 | FM | High | WR8DAR 2m repeater, Detroit MI (RepeaterBook) |
| 814 | DET WR8DAR | 147.1600 | + offset | 0.600 | Tone 100.0 | FM | High | WR8DAR 2m repeater, Detroit MI (RepeaterBook) |
| 815 | DET W8DET | 145.1100 | - offset | 0.600 | Tone 100.0 | FM | High | W8DET 2m repeater, Detroit MI (RepeaterBook) |
| 816 | DET WY8DOT | 147.2400 | + offset | 0.600 | Tone 100.0 | FM | High | WY8DOT 2m repeater, Detroit MI (RepeaterBook) |
| 817 | DET WW8GM | 443.0750 | + offset | 5.000 | Tone 123.0 | FM | High | WW8GM 70cm repeater, Detroit MI (RepeaterBook) |
| 818 | WSR VE3SXC | 145.3900 | - offset | 0.600 | — | FM | High | VE3SXC 2m repeater, Windsor ON (RepeaterBook) |
| 819 | WSR VE3WHT | 146.8800 | - offset | 0.600 | Tone 118.8 | FM | High | VE3WHT 2m repeater, Windsor ON (RepeaterBook) |
| 820 | WSR VE3EXT | 145.2900 | - offset | 0.600 | Tone 118.8 | FM | High | VE3EXT 2m repeater, Windsor ON (RepeaterBook) |
| 821 | WSR VE3OOO | 224.6600 | - offset | 1.600 | Tone 118.8 | FM | High | VE3OOO 220 repeater, Windsor ON (RepeaterBook) |
| 822 | CHT VA3ODC | 145.1000 | - offset | 0.600 | — | FM | High | VA3ODC 2m repeater, Chatham ON (RepeaterBook) |
| 823 | CHT VE3COZ | 145.1900 | - offset | 0.600 | Tone 123.0 | FM | High | VE3COZ 2m repeater, Chatham ON (RepeaterBook) |
| 824 | LON VE3GYQ | 145.3500 | - offset | 0.600 | Tone 114.8 | FM | High | VE3GYQ 2m repeater, London ON (RepeaterBook) |
| 825 | LON VE3OME | 145.4500 | - offset | 0.600 | Tone 114.8 | FM | High | VE3OME 2m repeater, London ON (RepeaterBook) |
| 826 | LON VA3LON | 147.0600 | + offset | 0.600 | Tone 114.8 | FM | High | VA3LON 2m repeater, London ON (RepeaterBook) |
| 827 | LON VE3STR | 146.8050 | - offset | 0.600 | Tone 114.8 | FM | High | VE3STR 2m repeater, London ON (RepeaterBook) |
| 828 | KIT VE3WFM | 147.0900 | + offset | 0.600 | Tone 131.8 | FM | High | VE3WFM 2m repeater, Kitchener ON (RepeaterBook) |
| 829 | KIT VE3RCK | 146.8650 | - offset | 0.600 | Tone 131.8 | FM | High | VE3RCK 2m repeater, Kitchener ON (RepeaterBook) |
| 830 | KIT VE3SWR | 145.1500 | - offset | 0.600 | Tone 131.8 | FM | High | VE3SWR 2m repeater, Kitchener ON (RepeaterBook) |
| 831 | GPH VE3GEG | 147.0000 | + offset | 0.600 | Tone 131.8 | FM | High | VE3GEG 2m repeater, Guelph ON (RepeaterBook) |
| 832 | TOR VE3TOR | 146.9400 | - offset | 0.600 | Tone 103.5 | FM | High | VE3TOR 2m repeater, Toronto ON (RepeaterBook) |
| 833 | TOR VE3OBN | 145.2300 | - offset | 0.600 | Tone 103.5 | FM | High | VE3OBN 2m repeater, Toronto ON (RepeaterBook) |
| 834 | TOR VE3SKY | 146.9850 | - offset | 0.600 | Tone 103.5 | FM | High | VE3SKY 2m repeater, Toronto ON (RepeaterBook) |
| 835 | TOR VA3GTU | 145.1300 | - offset | 0.600 | Tone 103.5 | FM | High | VA3GTU 2m repeater, Toronto ON (RepeaterBook) |
| 836 | TOR VE3WOO | 145.1100 | - offset | 0.600 | Tone 82.5 | FM | High | VE3WOO 2m repeater, Toronto ON (RepeaterBook) |
| 837 | TOR VE3TNC | 147.2700 | + offset | 0.600 | Tone 103.5 | FM | High | VE3TNC 2m repeater, Toronto ON (RepeaterBook) |
| 838 | TOR VE3MIS | 145.4300 | - offset | 0.600 | Tone 103.5 | FM | High | VE3MIS 2m repeater, Mississauga ON (RepeaterBook) |
| 839 | TOR VE3YPL | 145.4500 | - offset | 0.600 | Tone 85.4 | FM | High | VE3YPL 2m repeater, Toronto ON (RepeaterBook) |
| 840 | TOR VE3RTC | 146.7450 | - offset | 0.600 | Tone 136.5 | FM | High | VE3RTC 2m repeater, Toronto ON (RepeaterBook) |
| 841 | TOR VE3SPA | 147.3750 | + offset | 0.600 | Tone 103.5 | FM | High | VE3SPA 2m repeater, Toronto ON (RepeaterBook) |
| 842 | TOR VE3NIB | 443.5000 | + offset | 5.000 | Tone 103.5 | FM | High | VE3NIB 70cm repeater, Toronto ON (RepeaterBook) |
| 843 | TOR VA3RCI | 444.8000 | + offset | 5.000 | Tone 100.0 | FM | High | VA3RCI 70cm repeater, Toronto CN Tower (RepeaterBook) |
| 844 | MTL VE2RVL | 147.0750 | + offset | 0.600 | Tone 141.3 | FM | High | VE2RVL 2m repeater, Montreal QC (RepeaterBook) |
| 845 | MTL VE2RWI | 146.9100 | - offset | 0.600 | Tone 88.5 | FM | High | VE2RWI 2m repeater, Montreal QC (RepeaterBook) |
| 846 | MTL VE2REM | 147.0150 | + offset | 0.600 | Tone 103.5 | FM | High | VE2REM 2m repeater, Montreal QC (RepeaterBook) |
| 847 | MTL VE2RED | 147.2700 | + offset | 0.600 | Tone 103.5 | FM | High | VE2RED 2m repeater, Montreal QC (RepeaterBook) |
| 848 | MTL VE2RVC | 146.7300 | - offset | 0.600 | Tone 100.0 | FM | High | VE2RVC 2m repeater, Montreal QC (RepeaterBook) |
| 849 | MTL VE2RSM | 145.3900 | - offset | 0.600 | Tone 103.5 | FM | High | VE2RSM 2m repeater, Montreal QC (RepeaterBook) |
| 850 | MTL VE2RCU | 147.0450 | + offset | 0.600 | — | FM | High | VE2RCU 2m repeater, Montreal QC (RepeaterBook) |
| 851 | QC VE2RRS | 147.2250 | + offset | 0.600 | Tone 141.3 | FM | High | VE2RRS 2m repeater, Quebec City QC (RepeaterBook) |
| 852 | QC VE2RCQ | 147.3000 | + offset | 0.600 | Tone 100.0 | FM | High | VE2RCQ 2m repeater, Quebec City QC (RepeaterBook) |
| 853 | QC VE2RAX | 146.7900 | - offset | 0.600 | Tone 100.0 | FM | High | VE2RAX 2m repeater, Quebec City QC (RepeaterBook) |
| 854 | QC VE2RQE | 147.2550 | + offset | 0.600 | Tone 100.0 | FM | High | VE2RQE 2m repeater, Quebec City QC (RepeaterBook) |
| 855 | QC VE2RQR | 146.6100 | - offset | 0.600 | Tone 100.0 | FM | High | VE2RQR 2m repeater, Quebec City QC (RepeaterBook) |
| 856 | QC VE2RVJ | 145.4100 | - offset | 0.600 | Tone 141.3 | FM | High | VE2RVJ 2m repeater, Quebec City QC (RepeaterBook) |
| 857 | QC VE2RIG | 146.8800 | - offset | 0.600 | Tone 100.0 | FM | High | VE2RIG 2m repeater, Quebec City QC (RepeaterBook) |
| 858 | LEV VA2RSB | 147.1500 | + offset | 0.600 | Tone 100.0 | FM | High | VA2RSB 2m repeater, Levis QC (RepeaterBook) |
| 859 | PLB W2UXC | 147.2550 | + offset | 0.600 | Tone 123.0 | FM | High | W2UXC 2m repeater, Plattsburgh NY (RepeaterBook) |
| 860 | PLB W2UXC | 147.1500 | + offset | 0.600 | Tone 123.0 | FM | High | W2UXC 2m repeater, Plattsburgh NY (RepeaterBook) |
| 861 | PLB WA2LRE | 145.4900 | - offset | 0.600 | Tone 123.0 | FM | High | WA2LRE 2m repeater, Plattsburgh NY (RepeaterBook) |
| 862 | BTV W1KOO | 146.6100 | - offset | 0.600 | Tone 100.0 | FM | High | W1KOO 2m repeater, Burlington VT (RepeaterBook) |
| 863 | ALB K2CT | 145.1900 | - offset | 0.600 | Tone 103.5 | FM | High | K2CT 2m repeater, Albany NY (RepeaterBook) |
| 864 | ALB KA2QYE | 147.3750 | + offset | 0.600 | Tone 100.0 | FM | High | KA2QYE 2m repeater, Albany NY (RepeaterBook) |
| 865 | ALB K2ALB | 146.6400 | - offset | 0.600 | Tone 100.0 | FM | High | K2ALB 2m repeater, Albany NY (RepeaterBook) |
| 866 | TRY K2REN | 146.7600 | - offset | 0.600 | Tone 103.5 | FM | High | K2REN 2m repeater, Troy NY (RepeaterBook) |
| 867 | SYR W2CNY | 146.7750 | - offset | 0.600 | Tone 151.4 | FM | High | W2CNY 2m repeater, Syracuse NY (RepeaterBook) |
| 868 | SYR K2OCR | 147.3000 | + offset | 0.600 | Tone 67.0 | FM | High | K2OCR 2m repeater, Syracuse NY (RepeaterBook) |
| 869 | SYR KD2SL | 146.6700 | - offset | 0.600 | Tone 103.5 | FM | High | KD2SL 2m repeater, Syracuse NY (RepeaterBook) |
| 870 | SYR W2CM | 146.9100 | - offset | 0.600 | Tone 103.5 | FM | High | W2CM 2m repeater, Syracuse NY (RepeaterBook) |
| 871 | BNG N2VFD | 146.6400 | - offset | 0.600 | Tone 141.3 | FM | High | N2VFD 2m repeater, Binghamton NY (RepeaterBook) |
| 872 | BNG WA2QEL | 146.8650 | - offset | 0.600 | Tone 146.2 | FM | High | WA2QEL 2m repeater, Binghamton NY (RepeaterBook) |
| 873 | BNG WA2VCS | 147.2550 | + offset | 0.600 | Tone 100.0 | FM | High | WA2VCS 2m repeater, Binghamton NY (RepeaterBook) |
| 874 | SCR WB3FEQ | 147.2850 | + offset | 0.600 | Tone 127.3 | FM | High | WB3FEQ 2m repeater, Scranton PA (RepeaterBook) |
| 875 | SCR K3CSG | 146.9400 | - offset | 0.600 | Tone 127.3 | FM | High | K3CSG 2m repeater, Scranton PA (RepeaterBook) |
| 876 | SCR WB3KGD | 146.7750 | - offset | 0.600 | Tone 136.5 | FM | High | WB3KGD 2m repeater, Scranton PA (RepeaterBook) |
| 877 | HBP W3UU | 146.7600 | - offset | 0.600 | Tone 100.0 | FM | High | W3UU 2m repeater, Harrisburg PA (RepeaterBook) |
| 878 | HBP KA3TKW | 145.2100 | - offset | 0.600 | Tone 123.0 | FM | High | KA3TKW 2m repeater, Harrisburg PA (RepeaterBook) |
| 879 | HBP W3ND | 145.2900 | - offset | 0.600 | Tone 123.0 | FM | High | W3ND 2m repeater, Harrisburg PA (RepeaterBook) |

## Zone 10 — EMERGENCY

| Ch # | Name | Freq (MHz) | Duplex | Offset | Tone | Mode | Power | Notes |
|---|---|---|---|---|---|---|---|---|
| 901 | WX1 | 162.5500 | RX Only | — | — | FM | High | — |
| 902 | WX2 | 162.4000 | RX Only | — | — | FM | High | — |
| 903 | WX3 | 162.4750 | RX Only | — | — | FM | High | — |
| 904 | WX4 | 162.4250 | RX Only | — | — | FM | High | — |
| 905 | WX5 | 162.4500 | RX Only | — | — | FM | High | — |
| 906 | WX6 | 162.5000 | RX Only | — | — | FM | High | — |
| 907 | WX7 | 162.5250 | RX Only | — | — | FM | High | — |
| 908 | 2M CALLING | 146.5200 | RX Only | — | — | FM | High | — |
| 909 | 70CM CALLNG | 446.0000 | RX Only | — | — | FM | High | — |
| 910 | FRS/GMRS1 | 462.5625 | Simplex | — | — | NFM | High | — |
| 911 | FRS/GMRS2 | 462.5875 | Simplex | — | — | NFM | High | — |
| 912 | FRS/GMRS3 | 462.6125 | Simplex | — | — | NFM | High | — |
| 913 | FRS/GMRS4 | 462.6375 | Simplex | — | — | NFM | High | — |
| 914 | FRS/GMRS5 | 462.6625 | Simplex | — | — | NFM | High | — |
| 915 | FRS/GMRS6 | 462.6875 | Simplex | — | — | NFM | High | — |
| 916 | FRS/GMRS7 | 462.7125 | Simplex | — | — | NFM | High | — |
| 917 | FRS 8 | 467.5625 | Simplex | — | — | NFM | High | — |
| 918 | FRS 9 | 467.5875 | Simplex | — | — | NFM | High | — |
| 919 | FRS 10 | 467.6125 | Simplex | — | — | NFM | High | — |
| 920 | FRS 11 | 467.6375 | Simplex | — | — | NFM | High | — |
| 921 | FRS 12 | 467.6625 | Simplex | — | — | NFM | High | — |
| 922 | FRS 13 | 467.6875 | Simplex | — | — | NFM | High | — |
| 923 | FRS 14 | 467.7125 | Simplex | — | — | NFM | High | — |
| 924 | FRS/GMRS15 | 462.5500 | Simplex | — | — | NFM | High | — |
| 925 | FRS/GMRS16 | 462.5750 | Simplex | — | — | NFM | High | — |
| 926 | FRS/GMRS17 | 462.6000 | Simplex | — | — | NFM | High | — |
| 927 | FRS/GMRS18 | 462.6250 | Simplex | — | — | NFM | High | — |
| 928 | FRS/GMRS19 | 462.6500 | Simplex | — | — | NFM | High | — |
| 929 | FRS/GMRS20 | 462.6750 | Simplex | — | — | NFM | High | — |
| 930 | FRS/GMRS21 | 462.7000 | Simplex | — | — | NFM | High | — |
| 931 | FRS/GMRS22 | 462.7250 | Simplex | — | — | NFM | High | — |
| 932 | MURS 1 | 151.8200 | Simplex | — | — | FM | High | — |
| 933 | MURS 2 | 151.8800 | Simplex | — | — | FM | High | — |
| 934 | MURS 3 | 151.9400 | Simplex | — | — | FM | High | — |
| 935 | MURS 4 | 154.5700 | Simplex | — | — | FM | High | — |
| 936 | MURS 5 | 154.6000 | Simplex | — | — | FM | High | — |
| 937 | CALL CHANNEL | 155.7525 | RX Only | — | — | FM | High | VCALL10 (Natl VHF interop calling) |
| 938 | TAC CHANNEL1 | 151.1375 | RX Only | — | — | FM | High | VTAC11 (Natl VHF tactical) |
| 939 | TAC CHANNEL2 | 154.4525 | RX Only | — | — | FM | High | VTAC12 (Natl VHF tactical) |
| 940 | TAC CHANNEL3 | 158.7375 | RX Only | — | — | FM | High | VTAC13 (Natl VHF tactical) |
| 941 | TAC CHANNEL4 | 159.4725 | RX Only | — | — | FM | High | VTAC14 (Natl VHF tactical) |
| 942 | TAC CHANNEL5 | 161.8500 | RX Only | — | — | FM | High | VTAC17D (Natl VHF tactical, digital-capable) |
| 943 | RESCUE CHAN | 155.1600 | RX Only | — | — | FM | High | VSAR16 (Natl search & rescue) |
| 944 | FIRE CHAN 1 | 154.2800 | RX Only | — | — | FM | High | VFIRE21 (Natl fire mutual aid) |
| 945 | FIRE CHAN 2 | 154.2650 | RX Only | — | — | FM | High | VFIRE22 (Natl fire mutual aid) |
| 946 | FIRE CHAN 3 | 154.2950 | RX Only | — | — | FM | High | VFIRE23 (Natl fire mutual aid) |
| 947 | POLICE CHAN | 155.4750 | RX Only | — | — | FM | High | VLAW31 (Natl law enforcement tactical) |
| 948 | U CALL CHAN | 453.2125 | RX Only | — | — | FM | High | UCALL40D (Natl UHF interop calling) |
| 949 | U TAC CHAN1 | 453.4625 | RX Only | — | — | FM | High | UTAC41D (Natl UHF tactical) |
| 950 | U TAC CHAN2 | 453.7125 | RX Only | — | — | FM | High | UTAC42D (Natl UHF tactical) |
| 951 | U TAC CHAN3 | 453.8625 | RX Only | — | — | FM | High | UTAC43D (Natl UHF tactical) |
| 952 | AVIATION EM | 121.5000 | RX Only | — | — | AM | High | — |
| 953 | MARINE CH16 | 156.8000 | RX Only | — | — | FM | High | — |
| 954 | ISS VOICE | 145.8000 | RX Only | — | — | FM | High | — |
| 955 | CAP CALL 1 | 141.5750 | RX Only | — | — | NFM | High | CAP national command/control 1 |
| 956 | CAP CALL 2 | 141.0000 | RX Only | — | — | NFM | High | CAP national command/control 2 |
| 957 | CAP GUARD | 150.2250 | RX Only | — | — | NFM | High | CAP internal emergency/guard channel |
| 958 | CAP TAC 1 | 139.8750 | RX Only | — | — | NFM | High | CAP tactical/ground team ops |
| 959 | CAP RPTR 1 | 148.1250 | RX Only | — | — | NFM | High | CAP CONUS repeater R-01 (output freq) |
| 960 | CAP RPTR 2 | 148.1500 | RX Only | — | — | NFM | High | CAP CONUS repeater R-02 (output freq) |

