from flask import Flask, request, jsonify
import re
import os

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'temp_uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def extract_keys_from_binary(file_path):
    """
    Reads the binary file and searches for common license key patterns.
    """
    keys_found = []
    
    try:
        # Read the entire file content
        with open(file_path, 'rb') as f:
            content = f.read()
            
        # Decode to string (errors='ignore' skips weird binary chars)
        text_content = content.decode('utf-8', errors='ignore')
        
        # Common License Key Patterns
        patterns = [
            # UUID format (common in modern software)
            r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}',
            
            # Generic Alphanumeric with Dashes (e.g., XXXX-XXXX-XXXX-XXXX)
            r'\b[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}\b',
            
            # Serial numbers with dots (e.g., 1234.5678.9012)
            r'\b\d{4}[.\-]\d{4}[.\-]\d{4}\b',
            
            # Long alphanumeric strings (potential raw keys)
            r'\b[A-Za-z0-9]{20,}\b'
        ]
        
        found_keys = set() # Use set to avoid duplicates
        
        for pattern in patterns:
            matches = re.findall(pattern, text_content)
            for match in matches:
                # Filter out very short matches or obvious false positives
                if len(match) > 10: 
                    found_keys.add(match)
                    
        keys_found = list(found_keys)
        
    except Exception as e:
        print(f"Error processing file: {e}")
        
    return keys_found

@app.route('/extract-keys', methods=['POST'])
def extract_keys():
    if 'file' not in request.files:
        return jsonify({'status': 'error', 'message': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'status': 'error', 'message': 'No selected file'}), 400
    
    # Save file temporarily
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)
    
    try:
        keys = extract_keys_from_binary(file_path)
        return jsonify({
            'status': 'success', 
            'keys': keys
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        # Clean up temp file
        if os.path.exists(file_path):
            os.remove(file_path)

if __name__ == '__main__':
    # Run on all interfaces so Android can reach it via your PC's IP
    app.run(host='0.0.0.0', port=5000, debug=True)