from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.webview import WebView
from kivy.core.window import Window

class BitFlashApp(App):
    def build(self):
        # Set screen size for mobile optimization
        Window.size = (400, 700) 
        
        layout = BoxLayout(orientation='vertical')
        
        # Load the HTML file locally
        self.webview = WebView(source='index.html')
        
        layout.add_widget(self.webview)
        return layout

if __name__ == '__main__':
    BitFlashApp().run()