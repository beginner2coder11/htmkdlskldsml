# Getting subscribers when nobody knows you yet

A website does not make itself popular. What works for a school book launch is
people who already trust you sharing it with people who trust them. Nobody can
promise numbers, but this plan gives you the best chance. Start 4 weeks out.

## The offer (already built into the site)
People do not join a list to "get updates". They join for the free first
chapter. Every post, poster and message should point to that ONE offer.

## Week 1: launch the list (goal: your first 50)
- Put the link in the school WhatsApp groups, parent groups and staff groups.
  Say it in one line: "Read the first chapter of [Title] free: [link]".
- Announce it at assembly. Show a poster with a QR code of the link
  (make one free at any QR generator).
- Ask 5 to 10 teachers to be launch helpers: each shares once and asks 3 parents.
- Add the link to every school email signature, newsletter and social profile.
- Start a WhatsApp channel or group for book news and put its link in CONFIG.

## Week 2: give people a reason to share
- Run a simple giveaway: everyone who joins the list and shares the link gets
  entered to win a signed copy. Pick a winner on a set day and announce it.
- Class competition: the class with the most families on the list gets
  the author visiting for 30 minutes.
- Ask students to draw a character or scene from the book. Post the best
  (with permission from parents). Families share their child's work.
- Post 3 times this week: a book teaser line, a behind-the-scenes photo of
  you writing or proofing, and a short video reading one page.

## Week 3: widen the circle
- Contact other schools, libraries, church or mosque youth groups, and local
  bookshops. Offer a free author talk and a bulk price for their families.
- Send a short press note to local radio, community pages and newspapers:
  "Local school publishes its own book; launch on [date]". Lead with the
  human story, not the sales pitch.
- Ask 3 respected people (a head teacher, a librarian, a local leader) for one
  honest sentence about the book. Put real quotes in CONFIG under `reviews`.

## Week 4: countdown
- Every 2 to 3 days post the countdown: "12 days to go", "One week left".
- Email the list twice: the sample chapter follow-up, then "launch price ends
  soon" (see the emails below).
- Tell people how many seats are left if seating is limited. Only say it if true.

## Launch day and after
- Take photos and a short video. Post them the same evening with the site link.
- Thank everyone by name where you can. Ask buyers to leave a review or send
  a photo of the child reading. Add real ones to the site.
- Keep emailing once or twice a month: the next reading, a school event,
  a discount for the next book. A list you keep warm is worth more than launch day.

## Three emails to send
1. Right after sign-up (automatic reply in your email tool):
   Subject: Your free first chapter of [Title]
   "Thank you for joining! Here is your chapter: [link]. If you enjoy it,
   the launch is on [date] at [place]. Bring a friend."
2. One week before the launch:
   Subject: [Title] launch is 7 days away
   "Seats are filling up. Save yours, and reserve your copy at the launch price
   (it ends on [date]): [link]"
3. Day after launch:
   Subject: Thank you, and a small favour
   "It was wonderful to see you. If you bought the book, could you reply with
   one sentence about what your child thought? It helps other families decide."

## Keep it honest and safe
- Only publish real reviews and real numbers.
- Get parents' written permission before showing any child's name, photo or work.
- Only email people who ticked the consent box, and include an unsubscribe link
  (your email tool adds one).
- Check your country's rules on selling to children and on collecting
  personal data.

## What to measure (all free)
- Number of sign-ups per week.
- Which post or group brought people in (add `?from=whatsapp` to the link you
  share in each place and check with a free tool such as Cloudflare Web Analytics).
- Do more of what worked; drop what did not.
