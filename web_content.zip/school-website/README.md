# Book launch and book shop website (free to run)

One file (`index.html`). No accounts, no code tools, no monthly cost.
It has: a countdown to your launch, a launch-event page with free seat
sign-up and Add-to-Calendar, a shop for your books, a free-sample-chapter
sign-up to grow your subscriber list, share buttons and search-engine tags.

## Step 1. Make it yours (15 minutes)
1. Open `index.html` in Notepad, TextEdit or VS Code.
2. Change the 4 lines under "EDIT ME" at the very top (title, description).
3. Scroll to `const CONFIG = {` and replace the sample details: school name,
   book title, author, launch date and venue, prices, contact details.
   Only change the text between the quotes. Keep the commas.
4. Double-click `index.html` to preview it in your browser. When you change
   the school name, the yellow "Setup mode" bar disappears by itself.

## Step 2. Put your pictures in
- Make a folder called `images` next to `index.html` and add your photos
  (resize big photos first; under 400 KB each keeps the site fast).
- Your book cover: set `image: 'images/cover.jpg'` on each book in CONFIG.
  Until you do, a colourful cover is drawn automatically.
- School photos: fill in `gallery`. The photo section appears when you add some.
- Reviews: add REAL quotes only, in `reviews`. Empty means the section is hidden.
- Want professionally coloured pictures? Use `CHATGPT-PROMPT.md`.

## Step 3. Take payments (free to set up; the provider takes a fee per sale)
Create a payment link with any provider that works in your country, then paste
the link into `paymentLink` for that book:
- Paystack or Flutterwave payment pages (Nigeria, Ghana, Kenya, South Africa and more)
- Stripe Payment Links, PayPal.me or PayPal buttons
- Selar, Payhip or Gumroad: best for eBooks, because they email the file
  to the buyer automatically
If you leave `paymentLink` empty, the button opens WhatsApp (or email) with the
order already typed, and you send bank details. Set `whatsapp` as digits with
the country code, e.g. `'2348012345678'`.

## Step 4. Collect subscribers (free)
The sample-chapter form needs somewhere to send emails:
1. Make a free account at formspree.io (or use MailerLite / Buttondown, which
   also send the newsletters).
2. Create a form and copy its address, e.g. `https://formspree.io/f/abcdwxyz`.
3. Paste it into `formEndpoint` in CONFIG.
4. Upload your sample chapter as a PDF next to `index.html` and set
   `sampleUrl: 'sample-chapter.pdf'`. Visitors get the link right after signing up.
Until you set `formEndpoint`, sign-ups open a WhatsApp/email message instead.
The form has a consent tick box and a spam trap built in.

## Step 5. Publish it for free
Pick ONE:
- Netlify Drop: go to app.netlify.com/drop and drag the whole folder in.
  You get a free address in seconds.
- Cloudflare Pages or GitHub Pages: both free, both take this folder as-is.
Then:
1. In `index.html` change `og:image` to the full address of your picture,
   e.g. `https://yourschool.netlify.app/og-image.png`. WhatsApp and Facebook
   need the full address to show the preview picture.
2. Replace `og-image.png` with your own (1200 x 630) if you like.
3. Open the live site on your phone, tap every button, and send a test sign-up.

A custom address such as yourschool.com costs about 10 to 15 dollars a year,
but you do not need one to start.

Read `GROWTH-PLAYBOOK.md` next. It is the plan for getting people to arrive.

## Important: launch price vs normal price
A payment link charges one fixed amount. Make TWO links per book: one at the
launch price (`paymentLink`) and one at the normal price (`regularPaymentLink`).
The site switches to the second link by itself after `launchPriceUntil`.
