# Prompts for ChatGPT (real colourful pictures and a fancier design)

I built a complete colourful site (`index.html`) but I cannot make real photos.
ChatGPT can make images. Fill in the [BRACKETS], then paste each prompt.

## Prompt 1: Book cover
Create a front cover for a children's book titled "[TITLE]" by "[AUTHOR]".
Age group: [AGE RANGE]. Story in one sentence: [WHAT THE BOOK IS ABOUT].
Style: bright, warm, hand-painted picture-book illustration with bold shapes.
Colours: deep indigo, sunshine yellow, coral, mint green. Include the title in
large, readable letters and the author's name at the bottom. Portrait 2:3.

## Prompt 2: Hero and section pictures (run once per picture)
Create a wide 16:9 illustration for a school book-launch website:
[DESCRIBE THE SCENE, e.g. "children reading on colourful cushions in a bright
library, one holding our book"]. Flat, friendly illustration style, colours
indigo, yellow, coral and mint, lots of space on the left for text, no words
in the image.

## Prompt 3: Sharing picture for WhatsApp and Facebook
Create a 1200 x 630 pixel banner: the text "[TITLE] Book Launch" in big bold
letters, the line "[DATE] at [SCHOOL NAME]", and a smiling illustration of
children with books. Colours: indigo, yellow, coral, mint.

Save the pictures into the `images` folder, then list them in CONFIG
(`gallery`, and `image:` on each book). Keep each file under 400 KB.
If ChatGPT makes people who look like real children, that is fine for
illustrations, but never upload photos of pupils without parents' permission.

## Prompt 4: Ask ChatGPT to upgrade the website itself
I am attaching `index.html`, a single-file website for a school book launch
and book shop. Keep everything in the CONFIG object working. Improve the
design with [WHAT YOU WANT, e.g. a photo hero section, a testimonial slider,
a Spanish/French version]. Keep it one file, mobile first, fast, and free to
host on Netlify. Do not add any paid services. Return the full updated file.
