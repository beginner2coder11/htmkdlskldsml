// Syntax-only validation for the inline JavaScript shipped in app/src/main/assets/index.html.
const fs = require('fs');
const path = require('path');
const htmlPath = path.join(__dirname, 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const blocks = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
const appScript = blocks[blocks.length - 1];
if (!appScript) throw new Error('Main application script was not found.');
new Function(appScript);
console.log('JAS Laundry inline JavaScript syntax: OK');
