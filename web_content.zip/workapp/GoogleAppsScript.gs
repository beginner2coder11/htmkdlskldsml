/** JAS Laundry Google Sheets connector.
 * 1) Change ACCESS_TOKEN to a long private token, then paste this whole file into script.google.com.
 * 2) Optional: set SPREADSHEET_ID to an existing Google Sheet ID. Leave blank to auto-create one on first sync.
 * 3) Deploy as Web app, Execute as: Me, Who has access: Anyone. Keep the URL and token private.
 */
const ACCESS_TOKEN = 'CHANGE_THIS_TO_A_LONG_PRIVATE_TOKEN_9f3d8c7a';
const SPREADSHEET_ID = ''; // Optional: the part between /d/ and /edit in your Google Sheet URL.

function doGet() {
  const ss = getOrCreateSpreadsheet_();
  return json_({ ok: true, message: 'JAS Laundry Google Sheets connector is ready.', spreadsheetUrl: ss.getUrl() });
}

function doPost(e) {
  try {
    const payload = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!ACCESS_TOKEN || ACCESS_TOKEN.indexOf('CHANGE_THIS') === 0 || payload.token !== ACCESS_TOKEN) {
      return json_({ ok: false, message: 'Invalid sync token. Set the same private token in GoogleAppsScript.gs and the app.' });
    }
    const ss = getOrCreateSpreadsheet_();
    writeTable_(ss, 'Customers',
      ['Customer Name','Mobile Number','Bill Number(s)','Bill Date(s)','Delivery Date(s)','Order Status(es)','Number of Bills','Total Billing','Paid Amount','Balance Due','Payment Status'],
      (payload.customers || []).map(c => [c.name,c.mobile,c.billNumbers,c.billDates,c.deliveryDates,c.orderStatuses,c.billCount,c.totalBilling,c.paidAmount,c.balanceDue,c.paymentStatus]));
    writeTable_(ss, 'Bills',
      ['Bill Number','Bill Date','Customer Name','Mobile','Customer Type','Subtotal','Discount','Total','Paid','Balance','Payment Type','Payment Method','Payment Status','Order Status','Delivery Date','Delivery Time','Urgent Date','Remark','Created At','Payment History JSON'],
      (payload.bills || []).map(b => [b.no,b.date,b.customer,b.mobile,b.customerType,b.subtotal,b.discount,b.total,b.paid,b.balance,b.paymentType,b.method,(Number(b.balance||0)<=0.0001?'Paid':Number(b.paid||0)>0?'Partially Paid':'Unpaid'),b.orderStatus||'Received',b.deliveryDate,b.deliveryTime,b.urgentDate,b.remark,b.createdAt,JSON.stringify(b.paymentHistory||[])]));
    writeTable_(ss, 'Bill Items',
      ['Bill Number','Bill Date','Customer Name','Mobile','Category','Item','Quantity','Rate','Amount','Work Type','Item Details JSON'],
      (payload.billItems || []).map(i => [i.billNo,i.billDate,i.customer,i.mobile,i.category,i.item,i.qty,i.rate,i.amount,i.workType,JSON.stringify(i)]));
    writeTable_(ss, 'Price List',
      ['ID','Category','Item','Regular Price','Student Price','Unit','Other Details JSON'],
      (payload.prices || []).map(p => [p.id,p.category,p.name||p.item,p.price,p.studentPrice,p.unit,JSON.stringify(p)]));
    writeTable_(ss, 'Sync Info', ['Item','Value'], [
      ['Shop Name',(payload.shop||{}).shop||'JAS LAUNDRY ROOM'],
      ['Shop Phone',(payload.shop||{}).phone||''],
      ['Shop Address',(payload.shop||{}).address||''],
      ['Last Sync',payload.syncedAt||new Date().toISOString()],
      ['Customers',(payload.customers||[]).length],
      ['Bills',(payload.bills||[]).length]
    ]);
    return json_({ ok: true, message: 'Google Sheet synced', spreadsheetUrl: ss.getUrl(), customerCount: (payload.customers||[]).length, billCount: (payload.bills||[]).length });
  } catch (err) {
    return json_({ ok: false, message: String(err && err.message ? err.message : err) });
  }
}

function getOrCreateSpreadsheet_() {
  if (SPREADSHEET_ID && SPREADSHEET_ID.trim()) return SpreadsheetApp.openById(SPREADSHEET_ID.trim());
  const props = PropertiesService.getScriptProperties();
  const existingId = props.getProperty('JAS_LAUNDRY_SHEET_ID');
  if (existingId) return SpreadsheetApp.openById(existingId);
  const ss = SpreadsheetApp.create('JAS Laundry Customer & Billing Data');
  props.setProperty('JAS_LAUNDRY_SHEET_ID', ss.getId());
  return ss;
}

function writeTable_(ss, name, headers, rows) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  sh.clearContents();
  const values = [headers].concat(rows.map(row => headers.map((_, i) => value_(row[i]))));
  sh.getRange(1, 1, values.length, headers.length).setValues(values);
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, headers.length).setFontWeight('bold');
  sh.autoResizeColumns(1, headers.length);
}
function value_(v) { return v === undefined || v === null ? '' : (typeof v === 'object' ? JSON.stringify(v) : v); }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
