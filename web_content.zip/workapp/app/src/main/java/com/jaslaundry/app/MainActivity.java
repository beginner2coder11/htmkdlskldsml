package com.jaslaundry.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.ConsoleMessage;
import android.app.AlertDialog;
import android.widget.Toast;

import android.app.Activity;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        // Handle JavaScript alert/confirm dialogs in the Android WebView.
        // Without this, the Price List delete confirmation can appear to do nothing.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("JAS Laundry")
                    .setMessage(message)
                    .setPositiveButton("OK", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Confirm")
                    .setMessage(message)
                    .setPositiveButton("Delete / Yes", (dialog, which) -> result.confirm())
                    .setNegativeButton("Cancel", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public static class AndroidBridge {
        private final MainActivity activity;
        private final Context context;
        AndroidBridge(MainActivity a) { activity = a; context = a.getApplicationContext(); }

        private byte[] decode(String base64) {
            if (Build.VERSION.SDK_INT >= 26) return Base64.getDecoder().decode(base64);
            return android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        }

        @JavascriptInterface
        public boolean saveImage(String base64, String filename) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JAS Laundry");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                }
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    cr.update(uri, done, null, null);
                }
                Toast.makeText(context, "Bill JPG saved to Gallery → JAS Laundry", Toast.LENGTH_SHORT).show();
                return true;
            } catch (Exception e) {
                Toast.makeText(context, "Could not save JPG: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }

        // Save bill images as real files in Downloads/JAS Laundry using scoped storage.
        // Android 10+ does not require broad storage permission for MediaStore Downloads.
        @JavascriptInterface
        public boolean saveBillFile(String base64, String filename, String mimeType) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE,
                    (mimeType == null || mimeType.trim().isEmpty()) ? "image/jpeg" : mimeType);
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/JAS Laundry");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                }
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Downloads folder access failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("File output stream unavailable");
                    out.write(bytes);
                    out.flush();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    cr.update(uri, done, null, null);
                }
                activity.runOnUiThread(() -> Toast.makeText(activity,
                    "Bill saved to Downloads/JAS Laundry", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity,
                    "Bill download failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean saveThermalImage(String base64, String filename) {
            return writeThermalImage(base64, filename, false);
        }

        @JavascriptInterface
        public boolean downloadThermalImage(String base64, String filename) {
            return writeThermalImage(base64, filename, true);
        }

        private boolean writeThermalImage(String base64, String filename, boolean downloads) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, downloads ? "Download/JAS Laundry" : "Pictures/JAS Laundry");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                }
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    cr.update(uri, done, null, null);
                }
                String folder = downloads ? "Downloads/JAS Laundry" : "Gallery → JAS Laundry";
                activity.runOnUiThread(() -> Toast.makeText(activity, "Thermal receipt saved: " + folder, Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Thermal receipt save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public void printThermal(String html) {
            activity.runOnUiThread(() -> {
                try {
                    WebView printView = new WebView(activity);
                    printView.getSettings().setJavaScriptEnabled(false);
                    printView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            try {
                                PrintManager printManager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                                if (printManager == null) throw new Exception("Android Print service unavailable");
                                String jobName = "JAS Laundry Thermal Receipt";
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(jobName);
                                PrintAttributes attributes = new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT)
                                    .setResolution(new PrintAttributes.Resolution("jas_thermal", "Thermal printer", 203, 203))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();
                                printManager.print(jobName, adapter, attributes);
                                Toast.makeText(activity, "Print dialog opened. Select your thermal printer.", Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(activity, "Thermal print failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(activity, "Thermal print failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        // Create a compact thermal-receipt PDF, save it under Downloads/JAS Laundry,
        // then share the actual PDF attachment (not a text-only WhatsApp message).
        private Uri createAndSaveThermalPdf(String base64, String filename) throws Exception {
            byte[] imageBytes = decode(base64);
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            if (bitmap == null) throw new Exception("Thermal receipt image could not be decoded");
            int pageWidth = 227; // approximately 80 mm at 72 dpi
            int pageHeight = Math.max(100, (int)Math.ceil((double)bitmap.getHeight() * pageWidth / bitmap.getWidth()) + 16);
            PdfDocument pdf = new PdfDocument();
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create());
            page.getCanvas().drawColor(android.graphics.Color.WHITE);
            page.getCanvas().drawBitmap(bitmap, null, new Rect(0, 8, pageWidth, pageHeight - 8), null);
            pdf.finishPage(page);
            java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
            pdf.writeTo(buffer);
            pdf.close();
            bitmap.recycle();

            ContentResolver cr = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/JAS Laundry");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
            }
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Downloads folder access failed");
            try (OutputStream out = cr.openOutputStream(uri)) {
                if (out == null) throw new Exception("PDF output stream unavailable");
                out.write(buffer.toByteArray()); out.flush();
            }
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                cr.update(uri, done, null, null);
            }
            return uri;
        }

        @JavascriptInterface
        public boolean downloadThermalPdf(String base64, String filename) {
            try {
                createAndSaveThermalPdf(base64, filename);
                activity.runOnUiThread(() -> Toast.makeText(activity, "Thermal bill PDF saved to Downloads/JAS Laundry", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "PDF download failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareThermalPdf(String base64, String filename, String message) {
            try {
                Uri uri = createAndSaveThermalPdf(base64, filename);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    send.setPackage("com.whatsapp.w4b");
                    if (send.resolveActivity(context.getPackageManager()) != null) {
                        activity.startActivity(send);
                        return true;
                    }
                } catch (Exception ignored) {}
                Intent chooser = Intent.createChooser(send, "Send Thermal Bill PDF");
                activity.startActivity(chooser);
                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Could not share thermal PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareThermalImage(String base64, String filename, String message) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JAS Laundry");
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    send.setPackage("com.whatsapp.w4b");
                    if (send.resolveActivity(context.getPackageManager()) != null) {
                        activity.startActivity(send);
                        return true;
                    }
                } catch (Exception ignored) {}
                Intent chooser = Intent.createChooser(send, "Send Thermal Bill with WhatsApp Business");
                activity.startActivity(chooser);
                return true;
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Could not share thermal bill: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean openWhatsAppReport(String phone, String message) {
            try {
                String cleanPhone = phone == null ? "" : phone.replaceAll("[^0-9]", "");
                if (cleanPhone.length() < 10 || cleanPhone.length() > 15) throw new Exception("Invalid phone number");
                String encoded = java.net.URLEncoder.encode(message == null ? "" : message, "UTF-8");
                Uri target = Uri.parse("https://wa.me/" + cleanPhone + "?text=" + encoded);
                Intent business = new Intent(Intent.ACTION_VIEW, target);
                business.setPackage("com.whatsapp.w4b");
                try {
                    activity.startActivity(business);
                    return true;
                } catch (Exception businessNotAvailable) {
                    // If WhatsApp Business is absent, try standard WhatsApp or the Android app chooser.
                    Intent standard = new Intent(Intent.ACTION_VIEW, target);
                    try {
                        standard.setPackage("com.whatsapp");
                        activity.startActivity(standard);
                        Toast.makeText(activity, "WhatsApp Business ലഭ്യമല്ല; സാധാരണ WhatsApp തുറക്കുന്നു.", Toast.LENGTH_LONG).show();
                        return true;
                    } catch (Exception standardNotAvailable) {
                        Intent chooser = Intent.createChooser(new Intent(Intent.ACTION_VIEW, target), "Open report with WhatsApp");
                        activity.startActivity(chooser);
                        return true;
                    }
                }
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "WhatsApp റിപ്പോർട്ട് തുറക്കാൻ കഴിഞ്ഞില്ല: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareImage(String base64, String filename, String message) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JAS Laundry");
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }

                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/jpeg");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                Intent chooser = Intent.createChooser(send, "Send Bill");
                // Prefer WhatsApp Business when it is installed.
                try {
                    send.setPackage("com.whatsapp.w4b");
                    if (send.resolveActivity(context.getPackageManager()) != null) {
                        context.startActivity(send);
                        return true;
                    }
                } catch (Exception ignored) {}
                context.startActivity(chooser);
                return true;
            } catch (Exception e) {
                Toast.makeText(context, "Could not share bill: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }
}
