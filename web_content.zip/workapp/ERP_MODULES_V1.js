/* JAS Laundry ERP starter modules - records use the existing db/save/Firebase sync pipeline. */
(function () {
  const ensure = (key, value) => { if (!Array.isArray(db[key])) db[key] = value; };
  ensure('branches', [{ id: 'main', name: 'Main Branch', code: 'MAIN', active: true, createdAt: Date.now() }]);
  ensure('inventory', []); ensure('suppliers', []); ensure('purchases', []); ensure('expenses', []);
  ensure('attendance', []); ensure('payroll', []); ensure('offers', []);
  window.jasActiveBranch = localStorage.getItem('jasERPActiveBranch') || 'main';
  const safe = value => esc(value);
  const branchName = id => (db.branches.find(b => b.id === id) || {}).name || 'Main Branch';
  const ownerOnly = ['inventory', 'suppliers', 'purchases', 'expenses', 'attendance', 'payroll', 'branches', 'offers', 'erpReports'];
  const items = [
    ['production', '🧺 Production'], ['inventory', '📦 Inventory'], ['purchases', '🛒 Purchase'],
    ['suppliers', '🚚 Suppliers'], ['expenses', '💸 Expenses'], ['attendance', '🕒 Attendance'],
    ['payroll', '💰 Payroll'], ['branches', '🏬 Branches'], ['offers', '🎟 Offers'], ['erpReports', '📊 ERP Reports']
  ];
  navItems.push(...items);
  const topActions = document.querySelector('.top .row');
  if (topActions && !document.getElementById('jasGlobalBranch')) {
    const wrap = document.createElement('label');
    wrap.className = 'small'; wrap.style.cssText = 'display:flex;align-items:center;gap:6px;color:#64748b'; wrap.textContent = 'Branch';
    const select = document.createElement('select'); select.id = 'jasGlobalBranch'; select.style.maxWidth = '170px';
    select.onchange = () => { window.jasActiveBranch = select.value; localStorage.setItem('jasERPActiveBranch', select.value); };
    wrap.appendChild(select); topActions.prepend(wrap);
  }
  window.jasRefreshBranchSelector = function () {
    const select = document.getElementById('jasGlobalBranch'); if (!select) return;
    select.innerHTML = db.branches.filter(b => b.active !== false).map(b => `<option value="${safe(b.id)}">${safe(b.name)}</option>`).join('');
    const valid = db.branches.some(b => b.id === window.jasActiveBranch && b.active !== false);
    if (!valid) window.jasActiveBranch = (db.branches.find(b => b.active !== false) || { id: 'main' }).id;
    select.value = window.jasActiveBranch;
  };
  jasRefreshBranchSelector();
  const previousAllowed = allowed;
  allowed = function (p) { if (ownerOnly.includes(p)) return role === 'owner'; if (p === 'production') return role === 'owner' || role === 'staff'; return previousAllowed(p); };
  const previousShow = show;
  show = function (p) {
    if (!items.some(item => item[0] === p)) return previousShow(p);
    if (!allowed(p)) return;
    page = p; renderNav(); $('pageTitle').textContent = (items.find(item => item[0] === p) || [p, p])[1];
    renderERP(p);
  };
  const panel = html => `<div class="panel">${html}</div>`;
  const heading = (name, description, button) => `<div class="row between"><div><h2>${name}</h2><div class="muted">${description}</div></div>${button || ''}</div>`;
  const table = (headers, body) => `<div class="scroll"><table><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${body || `<tr><td colspan="${headers.length}" class="muted">No records yet</td></tr>`}</tbody></table></div>`;
  const branchPicker = () => `<div class="field" style="max-width:260px"><label>Active Branch</label><select onchange="jasSetBranch(this.value)">${db.branches.filter(b => b.active !== false).map(b => `<option value="${safe(b.id)}" ${b.id === window.jasActiveBranch ? 'selected' : ''}>${safe(b.name)}</option>`).join('')}</select></div>`;
  const branchPill = id => `<span class="pill">${safe(branchName(id))}</span>`;
  function renderERP(p) {
    if (p === 'production') return renderProduction();
    if (p === 'inventory') return renderInventory();
    if (p === 'suppliers') return renderSuppliers();
    if (p === 'purchases') return renderPurchases();
    if (p === 'expenses') return renderExpenses();
    if (p === 'attendance') return renderAttendance();
    if (p === 'payroll') return renderPayroll();
    if (p === 'branches') return renderBranches();
    if (p === 'offers') return renderOffers();
    if (p === 'erpReports') return renderReports();
  }
  window.jasSetBranch = id => { window.jasActiveBranch = id; localStorage.setItem('jasERPActiveBranch', id); jasRefreshBranchSelector(); renderERP(page); };
  function renderProduction() {
    const body = db.bills.slice().sort((a,b) => (b.createdAt || 0) - (a.createdAt || 0)).map(b => {
      const garmentList = (b.items || []).map(x => `${safe(x.item)} × ${x.qty}`).join(', ');
      const options = ['Received','Processing','Ready','Delivered'].map(s => `<option ${s === (b.orderStatus || 'Received') ? 'selected' : ''}>${s}</option>`).join('');
      return `<tr><td>${safe(b.no)}</td><td>${safe(b.customer)}</td><td>${garmentList}</td><td><select onchange="jasProductionStatus('${safe(b.id)}',this.value)">${options}</select></td><td>${safe(b.deliveryDate || '—')}</td></tr>`;
    }).join('');
    $('view').innerHTML = heading('Laundry Production', 'Order workflow: Received → Processing → Ready → Delivered') + panel('<div class="notice">ഇവിടെ status മാറ്റുമ്പോൾ നിലവിലുള്ള Bill / Order List-ലും update ആകും.</div>' + table(['Bill','Customer','Items','Status','Delivery'], body));
  }
  window.jasProductionStatus = (id, status) => { if (typeof updateBillStatusFromCustomers === 'function') updateBillStatusFromCustomers(id, status); else { const bill = db.bills.find(x => x.id === id); if (bill) { bill.orderStatus = status; save(); } } renderProduction(); };
  function renderInventory() {
    const rows = db.inventory.filter(x => !x.branchId || x.branchId === window.jasActiveBranch).map(x => {
      const status = Number(x.qty || 0) <= Number(x.reorder || 0) ? '<span class="warn">Low Stock</span>' : '<span class="good">In Stock</span>';
      return `<tr><td>${safe(x.name)}</td><td>${safe(x.category || 'General')}</td><td>${Number(x.qty) || 0}</td><td>${safe(x.unit || 'pcs')}</td><td>${Number(x.reorder) || 0}</td><td>${status}</td><td><button class="secondary" onclick="jasAdjustStock('${safe(x.id)}')">Adjust</button> <button class="danger" onclick="jasDeleteERPRecord('inventory','${safe(x.id)}')">Delete</button></td></tr>`;
    }).join('');
    $('view').innerHTML = heading('Inventory Management', 'Track chemicals, packaging and laundry supplies', '<button onclick="jasAddInventory()">＋ Add Stock Item</button>') + panel(branchPicker() + table(['Item','Category','Stock Qty','Unit','Reorder Level','Status','Action'], rows));
  }
  window.jasAddInventory = () => { const name = prompt('Stock item name'); if (!name) return; const qty = Number(prompt('Opening quantity','0')); if (!Number.isFinite(qty) || qty < 0) return alert('Enter a valid quantity'); db.inventory.push({ id:'stk_'+Date.now(), name:name.trim(), category:prompt('Category','Chemical') || 'General', qty, unit:prompt('Unit','litre') || 'pcs', reorder:Number(prompt('Low stock alert level','5')) || 0, branchId:window.jasActiveBranch, createdAt:Date.now() }); save(); renderInventory(); };
  window.jasAdjustStock = id => { const item = db.inventory.find(x => x.id === id); if (!item) return; const delta = Number(prompt('Stock adjustment (+ / -)','0')); if (!Number.isFinite(delta) || !delta) return; if ((Number(item.qty) || 0) + delta < 0) return alert('Stock cannot be negative'); item.qty = (Number(item.qty) || 0) + delta; item.updatedAt = Date.now(); save(); renderInventory(); };
  function renderSuppliers() {
    const rows = db.suppliers.map(x => `<tr><td>${safe(x.name)}</td><td>${safe(x.contact || '—')}</td><td>${safe(x.phone || '—')}</td><td>${safe(x.email || '—')}</td><td>${safe(x.notes || '')}</td><td><button class="danger" onclick="jasDeleteERPRecord('suppliers','${safe(x.id)}')">Delete</button></td></tr>`).join('');
    $('view').innerHTML = heading('Supplier Management','Maintain vendor contacts and payment references','<button onclick="jasAddSupplier()">＋ Add Supplier</button>') + panel(table(['Supplier','Contact','Phone','Email','Notes','Action'], rows));
  }
  window.jasAddSupplier = () => { const name = prompt('Supplier name'); if (!name) return; db.suppliers.push({ id:'sup_'+Date.now(), name:name.trim(), contact:prompt('Contact person','') || '', phone:prompt('Phone','') || '', email:prompt('Email','') || '', notes:prompt('Notes','') || '', createdAt:Date.now() }); save(); renderSuppliers(); };
  function renderPurchases() {
    const rows = db.purchases.filter(x => !x.branchId || x.branchId === window.jasActiveBranch).map(x => `<tr><td>${safe(x.date)}</td><td>${safe(x.supplier)}</td><td>${safe(x.item)}</td><td>${x.qty} ${safe(x.unit || '')}</td><td>${money(x.unitCost)}</td><td>${money(x.total)}</td><td>${branchPill(x.branchId)}</td></tr>`).join('');
    $('view').innerHTML = heading('Purchase Management','Purchases increase the matching inventory stock','<button onclick="jasAddPurchase()">＋ Record Purchase</button>') + panel(branchPicker() + table(['Date','Supplier','Item','Qty','Unit Cost','Total','Branch'], rows));
  }
  window.jasAddPurchase = () => { const supplier = prompt('Supplier name'); if (!supplier) return; const item = prompt('Purchased item'); if (!item) return; const qty = Number(prompt('Quantity','1')); const unitCost = Number(prompt('Unit cost ₹','0')); if (!(qty > 0) || !(unitCost >= 0)) return alert('Enter valid quantity and cost'); const unit = prompt('Unit','pcs') || 'pcs'; db.purchases.push({ id:'pur_'+Date.now(), supplier, item, qty, unit, unitCost, total:qty*unitCost, date:today(), branchId:window.jasActiveBranch, createdBy:userProfile?.login || 'unknown', createdAt:Date.now() }); const stock = db.inventory.find(x => x.name.toLowerCase() === item.toLowerCase() && x.branchId === window.jasActiveBranch); if (stock) stock.qty = (Number(stock.qty) || 0) + qty; else db.inventory.push({ id:'stk_'+Date.now(), name:item, category:'Purchased', qty, unit, reorder:0, branchId:window.jasActiveBranch }); save(); renderPurchases(); };
  function renderExpenses() {
    const list = db.expenses.filter(x => !x.branchId || x.branchId === window.jasActiveBranch); const sum = list.reduce((a,x) => a + (Number(x.amount) || 0), 0);
    const rows = list.slice().sort((a,b) => String(b.date).localeCompare(String(a.date))).map(x => `<tr><td>${safe(x.date)}</td><td>${safe(x.category)}</td><td>${safe(x.note)}</td><td>${money(x.amount)}</td><td>${safe(x.method)}</td><td>${branchPill(x.branchId)}</td></tr>`).join('');
    $('view').innerHTML = heading('Expense Management','Record branch operating costs','<button onclick="jasAddExpense()">＋ Add Expense</button>') + `<div class="cards"><div class="card"><div class="muted">Listed Expenses</div><div class="value">${money(sum)}</div></div><div class="card"><div class="muted">Entries</div><div class="value">${list.length}</div></div></div>` + panel(branchPicker() + table(['Date','Category','Description','Amount','Payment','Branch'], rows));
  }
  window.jasAddExpense = () => { const category = prompt('Expense category','Other'); if (!category) return; const amount = Number(prompt('Amount ₹','0')); if (!(amount > 0)) return alert('Enter a valid amount'); db.expenses.push({ id:'exp_'+Date.now(), date:today(), category, note:prompt('Description','') || '', amount, method:prompt('Payment method','Cash') || 'Cash', branchId:window.jasActiveBranch, createdBy:userProfile?.login || 'unknown', createdAt:Date.now() }); save(); renderExpenses(); };
  function renderAttendance() {
    const rows = db.attendance.slice().sort((a,b) => String(b.date).localeCompare(String(a.date))).map(x => `<tr><td>${safe(x.date)}</td><td>${safe(x.staff)}</td><td>${safe(x.status)}</td><td>${safe(x.in || '—')}</td><td>${safe(x.out || '—')}</td><td>${branchPill(x.branchId)}</td></tr>`).join('');
    $('view').innerHTML = heading('Staff Attendance','Daily attendance register','<button onclick="jasMarkAttendance()">＋ Mark Attendance</button>') + panel(table(['Date','Staff','Status','Check-in','Check-out','Branch'], rows));
  }
  window.jasMarkAttendance = () => { const staff = prompt('Staff name / ID'); if (!staff) return; const status = prompt('Status: Present / Absent / Leave','Present') || 'Present'; db.attendance.push({ id:'att_'+Date.now(), date:today(), staff, status, in:status === 'Present' ? new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}) : '', out:'', branchId:window.jasActiveBranch, markedBy:userProfile?.login || 'unknown' }); save(); renderAttendance(); };
  function renderPayroll() {
    const total = db.payroll.reduce((a,x) => a + (Number(x.net) || 0), 0); const rows = db.payroll.map(x => `<tr><td>${safe(x.month)}</td><td>${safe(x.staff)}</td><td>${money(x.basic)}</td><td>${money(x.deduction)}</td><td>${money(x.net)}</td><td>${safe(x.status)}</td></tr>`).join('');
    $('view').innerHTML = heading('Payroll','Record salary payments and deductions','<button onclick="jasAddPayroll()">＋ Add Salary Record</button>') + `<div class="cards"><div class="card"><div class="muted">Recorded Net Payroll</div><div class="value">${money(total)}</div></div><div class="card"><div class="muted">Records</div><div class="value">${db.payroll.length}</div></div></div>` + panel(table(['Month','Staff','Basic','Advance / Deduction','Net Pay','Status'], rows));
  }
  window.jasAddPayroll = () => { const staff = prompt('Staff name / ID'); if (!staff) return; const basic = Number(prompt('Basic salary ₹','0')); const deduction = Number(prompt('Advance / deductions ₹','0')); if (!(basic >= 0) || !(deduction >= 0) || deduction > basic) return alert('Enter valid salary values'); db.payroll.push({ id:'pay_'+Date.now(), month:today().slice(0,7), staff, basic, deduction, net:basic-deduction, status:prompt('Payment status','Pending') || 'Pending', branchId:window.jasActiveBranch, createdAt:Date.now() }); save(); renderPayroll(); };
  function renderBranches() {
    const rows = db.branches.map(x => `<tr><td>${safe(x.name)}</td><td>${safe(x.code)}</td><td>${x.active === false ? 'Inactive' : 'Active'}</td><td>${new Date(x.createdAt || Date.now()).toLocaleDateString('en-IN')}</td><td>${x.id === 'main' ? 'Default branch' : `<button class="secondary" onclick="jasToggleBranch('${safe(x.id)}')">${x.active === false ? 'Activate' : 'Disable'}</button>`}</td></tr>`).join('');
    $('view').innerHTML = heading('Multi-Branch Management','Create branches and assign new ERP records to the selected branch','<button onclick="jasAddBranch()">＋ Add Branch</button>') + panel(table(['Branch','Code','Status','Created','Action'], rows)) + panel('<b>Important:</b> Branch tagging is active for new ERP records. Server-side branch isolation must be added to Firebase Security Rules before assigning real staff to separate branches.');
  }
  window.jasAddBranch = () => { const name = prompt('Branch name'); if (!name) return; const code = (prompt('Unique branch code','BR'+(db.branches.length+1)) || '').trim().toUpperCase(); if (!code) return; if (db.branches.some(x => x.code === code)) return alert('Branch code already exists'); db.branches.push({ id:'br_'+Date.now(), name:name.trim(), code, active:true, createdAt:Date.now() }); save(); jasRefreshBranchSelector(); renderBranches(); };
  window.jasToggleBranch = id => { const b = db.branches.find(x => x.id === id); if (!b) return; b.active = b.active === false; save(); jasRefreshBranchSelector(); renderBranches(); };
  function renderOffers() {
    const rows = db.offers.map(x => `<tr><td>${safe(x.name)}</td><td>${safe(x.discount)}</td><td>${safe(x.until || '—')}</td><td>${safe(x.status || 'Active')}</td></tr>`).join('');
    $('view').innerHTML = heading('CRM & Customer Offers','Create and track promotional offers','<button onclick="jasAddOffer()">＋ Add Offer</button>') + panel(table(['Offer','Discount','Valid Until','Status'], rows));
  }
  window.jasAddOffer = () => { const name = prompt('Offer name'); if (!name) return; db.offers.push({ id:'off_'+Date.now(), name, discount:prompt('Discount details','10%') || '', until:prompt('Valid until YYYY-MM-DD','') || '', status:'Active' }); save(); renderOffers(); };
  function renderReports() {
    const sales = db.bills.reduce((a,b) => a + (Number(b.total) || 0), 0); const paid = db.bills.reduce((a,b) => a + (Number(b.paid) || 0), 0);
    const expenses = db.expenses.reduce((a,x) => a + (Number(x.amount) || 0), 0); const purchases = db.purchases.reduce((a,x) => a + (Number(x.total) || 0), 0);
    $('view').innerHTML = heading('ERP Reports','Preliminary operational summary from saved app records') + `<div class="cards"><div class="card"><div class="muted">Total Billed</div><div class="value">${money(sales)}</div></div><div class="card"><div class="muted">Payments Recorded</div><div class="value">${money(paid)}</div></div><div class="card"><div class="muted">Expenses</div><div class="value">${money(expenses)}</div></div><div class="card"><div class="muted">Purchases</div><div class="value">${money(purchases)}</div></div><div class="card"><div class="muted">Balance Due</div><div class="value">${money(sales-paid)}</div></div><div class="card"><div class="muted">Active Branches</div><div class="value">${db.branches.filter(b => b.active !== false).length}</div></div></div>` + panel('<div class="notice">ഈ റിപ്പോർട്ട് preliminary summary മാത്രമാണ്; audited profit/loss അല്ല. GST ledger, depreciation, purchase returns, stock valuation എന്നിവ ഇനിയും വികസിപ്പിക്കേണ്ടതാണ്.</div><button class="secondary" onclick="jasExportERP()">Export ERP CSV</button> <button class="secondary" onclick="backup()">Download Full Backup JSON</button>');
  }
  window.jasExportERP = () => { const rows = [['Type','Date','Name','Amount','Branch'], ...db.expenses.map(x => ['Expense',x.date,x.category,x.amount,branchName(x.branchId)]), ...db.purchases.map(x => ['Purchase',x.date,x.item,x.total,branchName(x.branchId)]), ...db.bills.map(x => ['Bill',x.date,x.no,x.total,branchName(x.branchId)])]; const csv = '\uFEFF' + rows.map(r => r.map(v => '"'+String(v ?? '').replace(/"/g,'""')+'"').join(',')).join('\r\n'); download(csv,'JAS_Laundry_ERP_Export_'+today()+'.csv','text/csv;charset=utf-8'); };
  window.jasDeleteERPRecord = (type,id) => { if (!confirm('Delete this record?')) return; db[type] = db[type].filter(x => x.id !== id); save(); renderERP(page); };
})();
