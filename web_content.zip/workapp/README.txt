JAS LAUNDRY ROOM - FREE ANDROID STUDIO BUILD

1. Install Android Studio.
2. Open this folder as an existing Android Studio project.
3. Wait for Gradle Sync to finish.
4. Connect an Android phone with USB debugging enabled.
5. Press Run, or use Build > Generate App Bundles or APKs > Generate APKs.
6. The generated debug APK can be installed on the phone.

This build contains the supplied HTML app plus a native Android bridge:
- Save JPG directly to Pictures/JAS Laundry in the Gallery.
- Share the JPG to WhatsApp Business when installed.
- Falls back to Android's share chooser when WhatsApp Business is unavailable.

Note: Firebase/Appwrite/cloud settings inside the HTML are unchanged. Configure them in the app as you already do.
