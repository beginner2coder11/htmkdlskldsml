JAS LAUNDRY ROOM - FREE ANDROID STUDIO BUILD

1. Install Android Studio.
2. Open this folder as an existing Android Studio project.
3. Wait for Gradle Sync to finish.
4. Connect an Android phone with USB debugging enabled.
5. Press Run, or use Build > Generate App Bundles or APKs > Generate APKs.
6. The generated debug APK can be installed on the phone.

This build contains the supplied HTML app plus a native Android bridge:
- Save JPG directly to Pictures/JAS Laundry in the Gallery.
- Share the JPG to WhatsApp Business when installed.
- Falls back to Android's share chooser when WhatsApp Business is unavailable.

Note: Firebase/Appwrite/cloud settings inside the HTML are unchanged. Configure them in the app as you already do.

PDF update:
- WhatsApp Business · Thermal PDF shares the thermal receipt as an actual PDF attachment.
- Download Thermal PDF saves a PDF to Download/JAS Laundry on Android 10+.
- The PDF preserves the thermal receipt layout as a compact single-page PDF.
- The Android PDF bridge must be included in the rebuilt APK; WhatsApp still requires the user to choose/confirm the customer chat and press Send.

OFFLINE + AUTOMATIC CLOUD SYNC
See CHANGELOG_OFFLINE_AUTOMATIC_CLOUD_SYNC.txt. The app saves business data locally first and marks it pending. When internet returns, it automatically retries using the saved Firebase config and an existing Firebase Authentication session. First-time Firebase setup/sign-in is still required on each phone. This is a best-effort offline merge on the current shared Firestore document; simultaneous edits to the same record and deletions need a future per-record sync migration.
