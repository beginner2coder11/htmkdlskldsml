JAS LAUNDRY ROOM - FREE ANDROID STUDIO BUILD

1. Install Android Studio.
2. Open this folder as an existing Android Studio project.
3. Wait for Gradle Sync to finish.
4. Connect an Android phone with USB debugging enabled.
5. Press Run, or use Build > Generate App Bundles or APKs > Generate APKs.
6. The generated debug APK can be installed on the phone.

This build contains the supplied HTML app plus a native Android bridge:
- Save JPG directly to Pictures/JAS Laundry in the Gallery.
- Share the JPG to WhatsApp Business when installed.
- Falls back to Android's share chooser when WhatsApp Business is unavailable.

Note: Firebase/Appwrite/cloud settings inside the HTML are unchanged. Configure them in the app as you already do.

PDF update:
- WhatsApp Business · Thermal PDF shares the thermal receipt as an actual PDF attachment.
- Download Thermal PDF saves a PDF to Download/JAS Laundry on Android 10+.
- The PDF preserves the thermal receipt layout as a compact single-page PDF.
- The Android PDF bridge must be included in the rebuilt APK; WhatsApp still requires the user to choose/confirm the customer chat and press Send.

ERP STARTER V1:
- Added ERP modules: Production, Inventory, Purchase, Suppliers, Expenses,
  Attendance, Payroll, Branches, CRM Offers and ERP Reports.
- The original Billing app modules are retained.
- Read ERP_V1_MALAYALAM_SETUP.txt for scope, limitations and test steps.
- ERP_MODULES_V1.js is loaded by app/src/main/assets/index.html.
- This starter has not been connected to or tested against the user's live
  Firebase project. Branch-level server-side security is not yet implemented.
