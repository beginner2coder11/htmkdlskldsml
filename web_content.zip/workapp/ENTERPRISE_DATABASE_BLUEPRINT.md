# JAS Laundry Enterprise — Target Data Model (Draft)

This is a migration blueprint, not an active Firebase deployment. Existing `JAS_LAUNDRY_ROOM_V2` and legacy documents must remain untouched until a verified migration is approved.

## Core principles
- One document per business record; never keep the entire business in one growing Firestore document.
- Every business record carries `tenantId` and `branchId`.
- Stable IDs, `createdAt`, `updatedAt`, `createdByUid`, `updatedByUid`, `schemaVersion`, and `recordVersion` on mutable records.
- Financial events are append-only ledger entries; corrections use reversal/adjustment records rather than silently rewriting history.
- Enforce tenant/branch/role permissions in Firestore Security Rules, not only in the UI.

## Proposed collections

```text
organizations/{tenantId}
organizations/{tenantId}/branches/{branchId}
organizations/{tenantId}/members/{uid}
organizations/{tenantId}/roles/{roleId}
organizations/{tenantId}/customers/{customerId}
organizations/{tenantId}/bills/{billId}
organizations/{tenantId}/payments/{paymentId}
organizations/{tenantId}/paymentAllocations/{allocationId}
organizations/{tenantId}/priceBooks/{priceBookId}
organizations/{tenantId}/inventoryItems/{itemId}
organizations/{tenantId}/garmentBatches/{batchId}
organizations/{tenantId}/garmentEvents/{eventId}
organizations/{tenantId}/expenses/{expenseId}
organizations/{tenantId}/cashSessions/{sessionId}
organizations/{tenantId}/auditEvents/{eventId}
organizations/{tenantId}/syncOutbox/{operationId}
```

## Record examples

### Branch
```json
{
  "branchId": "MAIN",
  "name": "Main Branch",
  "shortCode": "MAIN",
  "active": true,
  "timezone": "Asia/Kolkata",
  "createdAt": "server timestamp"
}
```

### Bill
```json
{
  "billNo": "JAS-00018",
  "tenantId": "existing-tenant-mapped-during-migration",
  "branchId": "MAIN",
  "customerId": "stable-customer-id",
  "customerSnapshot": {"name": "Customer", "mobile": "..."},
  "billDate": "YYYY-MM-DD",
  "deliveryDate": "YYYY-MM-DD",
  "items": [],
  "subtotal": 0,
  "discount": 0,
  "total": 0,
  "paidTotal": 0,
  "balance": 0,
  "orderStatus": "Received",
  "createdByUid": "firebase-auth-uid",
  "updatedByUid": "firebase-auth-uid",
  "recordVersion": 1,
  "schemaVersion": 1
}
```

### Payment (append-only)
```json
{
  "billId": "bill-document-id",
  "customerId": "customer-document-id",
  "branchId": "MAIN",
  "amount": 0,
  "method": "Cash",
  "receivedAt": "server timestamp",
  "receivedByUid": "firebase-auth-uid",
  "status": "posted",
  "schemaVersion": 1
}
```

## Legacy mapping
- `db.customers[]` -> customers documents; preserve mobile/name and assign stable IDs without changing printed bill history.
- `db.bills[]` -> bills documents; preserve `id`, `no`, `date`, `createdAt`, items, paymentHistory, statusHistory, creator metadata.
- Bill `paid` and `paymentHistory[]` -> payments; reconcile sum against old paid amount before cutover.
- `db.customerAdvances[]` -> customer advance ledger entries / balance projection.
- `db.refunds[]` -> refund ledger entries.
- `db.activities[]` -> auditEvents; retain original timestamps and actor fields.
- `db.prices[]` -> branch-aware priceBooks; retain regular/student prices and service categories.
- `db.settings` -> branch settings and organization settings.

## Migration protocol
1. Freeze writes briefly or enable a controlled dual-write window.
2. Export legacy local data and legacy Firestore docs; record counts and SHA-256 hashes.
3. Run a dry-run converter that writes only to a staging tenant/branch.
4. Reconcile customer count, bill count, total bill value, paid total, balance total, advances, refunds, and activity count.
5. Verify bill numbers remain unique per organization (or use a branch prefix if explicitly adopted).
6. Test Owner/Manager/Staff access with positive and negative permission cases.
7. Owner approves cutover; switch reads to new collections.
8. Keep legacy data read-only for rollback; never delete it as part of the migration.

## Required Firestore indexes and rules
Indexes must be derived from actual queries (branchId + date, branchId + orderStatus + deliveryDate, customerId + billDate, staff UID + createdAt). Rules must validate `request.auth.uid`, tenant membership, branch membership, and permission claims/document roles. Staff must not be able to grant themselves roles, read another tenant, or change immutable creator fields.
