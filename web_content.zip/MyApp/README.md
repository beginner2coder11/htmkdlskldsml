# متصفح برق

تصفّح سريع وآمن مع مانع إعلانات ووضع تخفٍّ وفحص للتنزيلات

## Run it
1. Unzip, then open this folder in Android Studio (Koala 2024.1 or newer). Let Gradle sync; accept upgrade prompts if shown.
2. Press Run to try it on an emulator or a phone with USB debugging.
3. APK for testing: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. For Google Play: Build > Generate Signed Bundle / APK with your own keystore, then use the files in google-play/.

## What is inside
- app/src/main/assets/www/ : the whole app (HTML, CSS, JavaScript), works offline.
- MainActivity.kt : WebView host with camera, microphone, location, file picker, share, notifications, file saving and back button support.
- web/index.html : the same app as one file, openable in any browser.
