# رعاية الحامل

1. Open this folder in Android Studio and let Gradle sync.
2. Run on an emulator or phone.
3. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Play Store images are in google-play/.
