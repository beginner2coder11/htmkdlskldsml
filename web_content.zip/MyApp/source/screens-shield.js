(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};

  var shieldState = { checkDraft: "" };
  var rulesState = { view: "custom", query: "" };
  var WEEKDAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) {} }
  function setting(k, d) { try { return App.setting(k, d); } catch (e) { try { return Kit.setting(k, d); } catch (e2) { return d; } } }
  function num(n) { try { return Kit.util.fmtNum(Number(n) || 0); } catch (e) { return String(Number(n) || 0); } }
  function riskColor(r) { try { return App.riskColor(r) || "var(--muted)"; } catch (e) { return "var(--muted)"; } }
  function riskLabel(r) {
    try { var l = App.riskLabel(r); if (l) return l; } catch (e) {}
    return r === "danger" ? "خطر" : r === "warn" ? "تحذير" : "آمن";
  }
  function inputVal(v) { return typeof v === "string" ? v : (v && v.target ? v.target.value : ""); }

  // ---------- Stats helpers ----------
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function keyOf(d) {
    try {
      if (typeof App.dayKey === "function") {
        var k = App.dayKey(d.getTime());
        if (typeof k === "string" && /^\d{4}-\d{2}-\d{2}$/.test(k)) return k;
      }
    } catch (e) {}
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function statDay(key) {
    var s = null;
    try { s = App.statsStore.get(); } catch (e) {}
    var days = s && s.days && typeof s.days === "object" ? s.days : {};
    var d = days[key] || {};
    return { ads: Number(d.ads) || 0, trackers: Number(d.trackers) || 0, params: Number(d.params) || 0, files: Number(d.files) || 0 };
  }

  function last7() {
    var out = [];
    for (var i = 6; i >= 0; i--) {
      var d = new Date();
      d.setHours(12, 0, 0, 0);
      d.setDate(d.getDate() - i);
      var k = keyOf(d);
      out.push({ key: k, label: i === 0 ? "اليوم" : WEEKDAYS[d.getDay()], s: statDay(k) });
    }
    return out;
  }

  function rulesData() {
    var r = null;
    try { r = App.rulesStore.get(); } catch (e) {}
    if (!r || typeof r !== "object") r = {};
    return {
      custom: Array.isArray(r.custom) ? r.custom.filter(function (c) { return c && c.id; }) : [],
      allow: Array.isArray(r.allow) ? r.allow.filter(function (a) { return a && a.id; }) : [],
      builtinEnabled: r.builtinEnabled !== false
    };
  }

  function updateRules(fn) {
    App.rulesStore.update(function (r) {
      if (!r || typeof r !== "object") r = {};
      if (!Array.isArray(r.custom)) r.custom = [];
      if (!Array.isArray(r.allow)) r.allow = [];
      if (r.builtinEnabled === undefined) r.builtinEnabled = true;
      fn(r);
      return r;
    });
  }

  // ---------- Wipe ----------
  App.wipeAll = function (opts) {
    opts = opts || {};
    var res = { history: 0, tabs: 0 };
    try { var hl = App.historyStore.get(); res.history = Array.isArray(hl) ? hl.length : 0; } catch (e) {}
    try { res.tabs = (App.allTabs(false) || []).length + (App.allTabs(true) || []).length; } catch (e) {}
    try { App.closeAllNow(true); } catch (e) {}
    try { App.closeAllNow(false); } catch (e) {}
    try { if (Array.isArray(App.privateTabs)) App.privateTabs.length = 0; } catch (e) {}
    try { App.tabsStore.set([]); } catch (e) {}
    try { App.sessionStore.set({ currentTabId: null, currentPrivate: false }); } catch (e) {}
    try { App.historyStore.set([]); } catch (e) {}
    try { App.clearAllowOnce(); } catch (e) {}
    try { if (window.sessionStorage) window.sessionStorage.clear(); } catch (e) {}
    try { if (App.hasPin && App.hasPin()) App.lockPrivate(); } catch (e) { App.privateUnlocked = false; }
    if (!opts.silent) haptic(60);
    return res;
  };

  async function wipeNow() {
    var ok = await Kit.confirm("مسح السجل وكل التبويبات (العادية والخاصة) وذاكرة الجلسة الآن؟ لا يمكن التراجع.", { danger: true, ok: "تنظيف الآن" });
    if (!ok) return;
    var r = App.wipeAll();
    toast("تم التنظيف: " + num(r.history) + " زيارة و" + num(r.tabs) + " تبويب");
  }

  // ---------- Link checker ----------
  function prepLink(raw) {
    var t = String(raw || "").trim();
    if (!t) return { error: "الصق رابطاً لفحصه" };
    if (/\s/.test(t)) return { error: "الرابط لا يجب أن يحتوي على مسافات" };
    if (!/^[a-z][a-z0-9+.-]*:/i.test(t)) t = "https://" + t;
    var u;
    try { u = new URL(t); } catch (e) { return { error: "الرابط غير صالح، مثال: https://example.com" }; }
    if (!/^https?:$/.test(u.protocol)) return { error: "يدعم الفاحص روابط http وhttps فقط" };
    if (!u.hostname) return { error: "اسم النطاق في الرابط غير صحيح" };
    return { url: u.href };
  }

  function renderCheck(box, url) {
    box.textContent = "";
    var r = null;
    try { r = App.checkUrl(url); } catch (e) {}
    r = r || {};
    var risk = r.risk === "danger" || r.risk === "warn" ? r.risk : "safe";
    var score = Kit.util.clamp(Number(r.score) || (risk === "danger" ? 90 : risk === "warn" ? 50 : 8), 0, 100);
    var items = (Array.isArray(r.items) ? r.items : []).map(function (it) {
      return it && typeof it === "object" ? { ok: it.ok === true, text: String(it.text || "") } : { ok: false, text: String(it || "") };
    }).filter(function (it) { return it.text; });
    var blk = null;
    try { blk = App.isBlocked(url); } catch (e) {}
    var st = { url: url, removed: 0 };
    try { st = App.stripTracking(url) || st; } catch (e) {}
    var removed = Number(st.removed) || 0;
    var clean = st.url || url;

    box.appendChild(h("div", { class: "k-row", style: { alignItems: "center", gap: "12px" } },
      Kit.ui.ring(score, { label: "خطورة" }),
      h("div", { class: "k-col k-grow", style: { minWidth: "0", gap: "4px" } },
        h("div", { class: "k-h2", style: { color: riskColor(risk) } }, riskLabel(risk)),
        h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, url))));

    if (blk && blk.blocked) {
      box.appendChild(h("div", { class: "k-row", style: { gap: "8px", alignItems: "center", color: "var(--danger)" } },
        Kit.icon("shield", 18), h("span", { class: "k-small" }, blk.reason || "النطاق محظور")));
    }
    var warns = items.filter(function (i) { return !i.ok; });
    var shown = (warns.length ? warns : items).slice(0, 5);
    shown.forEach(function (it) {
      box.appendChild(h("div", { class: "k-row", style: { gap: "8px", alignItems: "flex-start" } },
        h("span", { style: { color: it.ok ? "var(--ok)" : "var(--danger)", display: "inline-flex", flexShrink: "0" } }, Kit.icon(it.ok ? "check" : "info", 16)),
        h("span", { class: "k-small k-grow" }, it.text)));
    });
    if (removed) {
      box.appendChild(h("div", { class: "k-small", style: { color: "var(--accent)" } },
        "يحتوي الرابط على " + num(removed) + " من معاملات التتبّع. النسخة النظيفة:"));
      box.appendChild(h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, clean));
    }
    var acts = h("div", { class: "k-row k-wrap", style: { gap: "8px" } });
    acts.appendChild(Kit.ui.btn("التقرير الكامل", { kind: "tonal", icon: "file", small: true, onClick: function () { Kit.go("scanreport", { url: url, kind: "link" }); } }));
    acts.appendChild(Kit.ui.btn(removed ? "نسخ النظيف" : "نسخ", { kind: "ghost", icon: "copy", small: true, onClick: function () {
      try { Kit.native.copy(clean); } catch (e) {}
      if (removed) { try { App.bumpStat("params", removed); } catch (e) {} }
      haptic(15); toast(removed ? "نُسخ الرابط بعد تنظيفه" : "نُسخ الرابط");
    } }));
    acts.appendChild(Kit.ui.btn("فتح", { kind: "ghost", icon: "globe", small: true, onClick: async function () {
      if (risk !== "safe" && !(await Kit.confirm("الرابط يحمل تحذيرات أمنية. فتحه رغم ذلك؟", { danger: true, ok: "فتح" }))) return;
      try { App.openUrl(clean, { newTab: true }); } catch (e) { toast("تعذّر فتح الرابط"); }
    } }));
    box.appendChild(acts);
    box.style.display = "flex";
    if (risk !== "safe") haptic(40);
  }

  function checkerCard() {
    var err = h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } });
    var box = h("div", { class: "k-col barq-check-result", style: { gap: "8px", display: "none", borderBlockStart: "1px solid var(--line)", paddingBlockStart: "10px" } });
    var f = Kit.ui.field({ label: "الرابط", type: "url", value: shieldState.checkDraft, placeholder: "https://example.com/page",
      onInput: function (v) { shieldState.checkDraft = inputVal(v); } });
    if (f.input) {
      f.input.setAttribute("dir", "ltr");
      f.input.addEventListener("input", function () { shieldState.checkDraft = f.input.value; err.textContent = ""; });
    }
    function run(ev) {
      if (ev && ev.preventDefault) ev.preventDefault();
      var p = prepLink(f.input ? f.input.value : shieldState.checkDraft);
      if (p.error) { err.textContent = p.error; box.style.display = "none"; return; }
      err.textContent = "";
      renderCheck(box, p.url);
    }
    return h("form", { class: "k-card k-col", style: { gap: "8px" }, onsubmit: run },
      h("div", { class: "k-row", style: { alignItems: "center", gap: "8px" } }, Kit.icon("search", 20), h("div", { class: "k-h2" }, "فاحص أمان الروابط")),
      h("div", { class: "k-small k-muted" }, "يكشف الاتصال غير المشفّر والأحرف المخادعة وعناوين IP والروابط المختصرة والنطاقات المشبوهة."),
      f, err,
      Kit.ui.btn("افحص الرابط", { kind: "primary", icon: "shield", block: true, onClick: run }),
      box);
  }

  function protectionRow(icon, label, on) {
    return Kit.ui.item({ title: label, icon: icon, trailing: h("span", { class: "k-badge", style: { color: on ? "var(--ok)" : "var(--muted)" } }, on ? "مفعّل" : "معطّل") });
  }

  // ---------- Shield screen ----------
  App.screens.shield = function (el) {
    var days = last7();
    var today = days[days.length - 1].s;
    var week = days.reduce(function (a, d) {
      a.ads += d.s.ads; a.trackers += d.s.trackers; a.params += d.s.params; a.files += d.s.files; return a;
    }, { ads: 0, trackers: 0, params: 0, files: 0 });
    var rd = rulesData();
    var root = h("div", { class: "k-col barq-shield", style: { gap: "14px", paddingBlockEnd: "16px" } });

    var active = setting("adBlock", true);
    root.appendChild(h("div", { class: "k-card k-row", style: { alignItems: "center", gap: "12px" } },
      h("span", { style: { color: active ? "var(--ok)" : "var(--danger)", display: "inline-flex" } }, Kit.icon("shield", 40)),
      h("div", { class: "k-col k-grow", style: { gap: "2px" } },
        h("div", { class: "k-h2" }, active ? "الحماية تعمل" : "حظر الإعلانات معطّل"),
        h("div", { class: "k-small k-muted" }, "حُظر اليوم " + num(today.ads + today.trackers) + " طلباً، و" + num(week.ads + week.trackers) + " خلال سبعة أيام."))));

    root.appendChild(Kit.ui.section("اليوم"));
    root.appendChild(Kit.ui.grid([
      Kit.ui.stat({ icon: "shield", value: num(today.ads), label: "إعلانات" }),
      Kit.ui.stat({ icon: "eye", value: num(today.trackers), label: "متتبّعات" }),
      Kit.ui.stat({ icon: "file", value: num(today.files), label: "ملفات مرفوضة" }),
      Kit.ui.stat({ icon: "filter", value: num(today.params), label: "معاملات مُزالة" })
    ], 2));

    root.appendChild(Kit.ui.section("آخر سبعة أيام"));
    var chart = h("div", { class: "k-card k-col", style: { gap: "8px" } });
    if (week.ads + week.trackers + week.files + week.params === 0) {
      chart.appendChild(h("div", { class: "k-muted k-small", style: { textAlign: "center", paddingBlock: "12px" } }, "لا توجد عمليات حظر مسجّلة بعد."));
    } else {
      chart.appendChild(Kit.ui.bars(days.map(function (d) { return { label: d.label, value: d.s.ads + d.s.trackers }; })));
      chart.appendChild(h("div", { class: "k-small k-muted" },
        "المجموع: " + num(week.ads) + " إعلان · " + num(week.trackers) + " متتبّع · " + num(week.files) + " ملف · " + num(week.params) + " معامل"));
    }
    root.appendChild(chart);

    root.appendChild(checkerCard());

    root.appendChild(Kit.ui.section("قواعد الحظر", { label: "إدارة", onClick: function () { Kit.go("rules"); } }));
    root.appendChild(Kit.ui.list([
      Kit.ui.item({ title: "القائمة المدمجة", sub: num(App.BLOCKLIST_COUNT || 0) + " نطاقاً · " + (rd.builtinEnabled ? "مفعّلة" : "معطّلة"), icon: "shield", chevron: true, onClick: function () { rulesState.view = "builtin"; Kit.go("rules"); } }),
      Kit.ui.item({ title: "قواعد مخصّصة", sub: num(rd.custom.length) + " قاعدة · " + num(rd.custom.filter(function (c) { return c.enabled !== false; }).length) + " مفعّلة", icon: "filter", chevron: true, onClick: function () { rulesState.view = "custom"; Kit.go("rules"); } }),
      Kit.ui.item({ title: "قائمة السماح", sub: num(rd.allow.length) + " موقعاً موثوقاً", icon: "check", chevron: true, onClick: function () { rulesState.view = "allow"; Kit.go("rules"); } })
    ]));

    root.appendChild(Kit.ui.section("حالة الحماية"));
    root.appendChild(Kit.ui.list([
      protectionRow("shield", "حظر الإعلانات والمتتبّعات", setting("adBlock", true)),
      protectionRow("filter", "إزالة معاملات التتبّع", setting("stripParams", true)),
      protectionRow("lock", "فرض HTTPS", setting("forceHttps", true)),
      protectionRow("file", "فحص الملفات قبل التنزيل", setting("scanDownloads", true))
    ]));
    root.appendChild(h("div", { class: "k-small k-muted" }, "غيّر هذه الخيارات من الإعدادات."));

    root.appendChild(h("div", { class: "k-card k-col", style: { gap: "8px" } },
      h("div", { class: "k-h2" }, "تنظيف فوري"),
      h("div", { class: "k-small k-muted" }, "يمسح السجل وكل التبويبات وذاكرة الجلسة بضغطة واحدة. لا يمسّ الإشارات المرجعية ولا الاتصال السريع."),
      Kit.ui.btn("تنظيف الآن", { kind: "danger", icon: "trash", block: true, onClick: wipeNow }),
      Kit.ui.btn("تصفير الإحصاءات", { kind: "ghost", icon: "refresh", block: true, onClick: async function () {
        if (!(await Kit.confirm("تصفير كل إحصاءات الحماية؟", { danger: true, ok: "تصفير" }))) return;
        App.statsStore.set({ days: {} }); haptic(30); toast("صُفّرت الإحصاءات");
      } })));

    el.appendChild(root);
  };

  // ---------- Domain sheet ----------
  function domainSheet(title, label, initial, onSave) {
    Kit.sheet(function (close) {
      var err = h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } });
      var f = Kit.ui.field({ label: label, type: "text", value: initial || "", placeholder: "example.com" });
      if (f.input) {
        f.input.setAttribute("dir", "ltr");
        f.input.setAttribute("autocapitalize", "off");
        f.input.addEventListener("input", function () { err.textContent = ""; });
        setTimeout(function () { try { f.input.focus(); } catch (e) {} }, 150);
      }
      function save(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        var msg = onSave(f.input ? f.input.value : "");
        if (msg) { err.textContent = msg; haptic(30); return; }
        haptic(20); close();
      }
      return h("form", { class: "k-col", style: { gap: "10px" }, onsubmit: save },
        f, err,
        h("div", { class: "k-small k-muted" }, "يشمل النطاق كل نطاقاته الفرعية تلقائياً."),
        Kit.ui.btn("حفظ", { kind: "primary", icon: "check", block: true, onClick: save }));
    }, { title: title });
  }

  function editDomain(listKey, item) {
    domainSheet("تعديل النطاق", "النطاق", item.domain, function (text) {
      var d = App.normalizeDomain(text);
      if (!d) return "اكتب اسم النطاق أولاً";
      if (!App.validDomain(d)) return "النطاق غير صالح، مثال صحيح: ads.example.com";
      var dup = rulesData()[listKey].some(function (x) { return x.id !== item.id && App.normalizeDomain(x.domain) === d; });
      if (dup) return "هذا النطاق موجود بالفعل";
      updateRules(function (r) { r[listKey].forEach(function (x) { if (x && x.id === item.id) x.domain = d; }); });
      toast("حُفظ التعديل");
      return null;
    });
  }

  async function removeDomain(listKey, item) {
    var ok = await Kit.confirm("حذف «" + item.domain + "»" + (listKey === "allow" ? " من قائمة السماح؟" : " من قواعد الحظر؟"), { danger: true, ok: "حذف" });
    if (!ok) return;
    updateRules(function (r) { r[listKey] = r[listKey].filter(function (x) { return x && x.id !== item.id; }); });
    haptic(25); toast("حُذف النطاق");
  }

  function tagSearch(node, text) {
    try { node.setAttribute("data-search", String(text || "").toLowerCase()); node.classList.add("barq-rule-row"); } catch (e) {}
    return node;
  }

  function applyRuleFilter(root, q) {
    var query = String(q || "").trim().toLowerCase(), shown = 0;
    var rows = root.querySelectorAll(".barq-rule-row");
    for (var i = 0; i < rows.length; i++) {
      var m = !query || (rows[i].getAttribute("data-search") || "").indexOf(query) >= 0;
      rows[i].style.display = m ? "" : "none";
      if (m) shown++;
    }
    var note = root.querySelector(".barq-rule-nomatch");
    if (note) note.style.display = query && rows.length && !shown ? "block" : "none";
  }

  function customView(rd) {
    var wrap = h("div", { class: "k-col", style: { gap: "10px" } });
    wrap.appendChild(Kit.ui.btn("إضافة قاعدة حظر", { kind: "primary", icon: "plus", block: true, onClick: function () {
      domainSheet("قاعدة حظر جديدة", "النطاق المراد حظره", "", function (t) { var e = App.addCustomRule(t); if (!e) toast("أُضيفت القاعدة"); return e; });
    } }));
    if (!rd.custom.length) {
      wrap.appendChild(Kit.ui.empty({ icon: "filter", title: "لا توجد قواعد مخصّصة", text: "أضف نطاقاً لحظره في كل التبويبات." }));
      return wrap;
    }
    wrap.appendChild(Kit.ui.list(rd.custom.map(function (c) {
      var on = c.enabled !== false;
      return tagSearch(Kit.ui.item({
        title: c.domain, sub: on ? "مفعّلة" : "معطّلة", icon: "filter",
        trailing: h("div", { class: "k-row", style: { alignItems: "center", gap: "2px" } },
          Kit.ui.switch(on, function () {
            updateRules(function (r) { r.custom.forEach(function (x) { if (x && x.id === c.id) x.enabled = !(x.enabled !== false); }); });
            haptic(10);
          }),
          Kit.ui.iconBtn("edit", "تعديل", function () { editDomain("custom", c); }),
          Kit.ui.iconBtn("trash", "حذف", function () { removeDomain("custom", c); }))
      }), c.domain);
    })));
    return wrap;
  }

  function allowView(rd) {
    var wrap = h("div", { class: "k-col", style: { gap: "10px" } });
    wrap.appendChild(h("div", { class: "k-small k-muted" }, "المواقع هنا لا تُحظر أبداً، حتى لو ظهرت في القائمة المدمجة أو قواعدك."));
    var row = h("div", { class: "k-row", style: { gap: "8px" } },
      Kit.ui.btn("إضافة موقع", { kind: "primary", icon: "plus", block: true, onClick: function () {
        domainSheet("موقع موثوق", "النطاق", "", function (t) { var e = App.addAllowDomain(t); if (!e) toast("أُضيف إلى قائمة السماح"); return e; });
      } }));
    var cur = null;
    try { cur = App.currentTab(); } catch (e) {}
    var curHost = cur && cur.url ? (App.hostOf(cur.url) || "") : "";
    if (curHost && App.validDomain(curHost) && !App.isAllowed(curHost)) {
      row.appendChild(Kit.ui.btn("الموقع الحالي", { kind: "tonal", icon: "globe", block: true, onClick: function () {
        var e = App.addAllowDomain(curHost); toast(e || "سُمح بـ " + App.normalizeDomain(curHost)); haptic(15);
      } }));
    }
    wrap.appendChild(row);
    if (!rd.allow.length) {
      wrap.appendChild(Kit.ui.empty({ icon: "check", title: "قائمة السماح فارغة", text: "أضف المواقع التي تثق بها لتجاوز الحظر." }));
      return wrap;
    }
    wrap.appendChild(Kit.ui.list(rd.allow.map(function (a) {
      return tagSearch(Kit.ui.item({
        title: a.domain, icon: "check",
        trailing: h("div", { class: "k-row", style: { alignItems: "center", gap: "2px" } },
          Kit.ui.iconBtn("edit", "تعديل", function () { editDomain("allow", a); }),
          Kit.ui.iconBtn("trash", "حذف", function () { removeDomain("allow", a); }))
      }), a.domain);
    })));
    return wrap;
  }

  function builtinView(rd) {
    var wrap = h("div", { class: "k-col", style: { gap: "10px" } });
    wrap.appendChild(Kit.ui.card([
      h("div", { class: "k-row", style: { alignItems: "center", gap: "10px" } },
        h("div", { class: "k-col k-grow", style: { gap: "2px" } },
          h("div", { style: { fontWeight: "600" } }, "تفعيل القائمة المدمجة"),
          h("div", { class: "k-small k-muted" }, num(App.BLOCKLIST_COUNT || 0) + " نطاقاً معروفاً للإعلانات والتتبّع")),
        Kit.ui.switch(rd.builtinEnabled, function () {
          updateRules(function (r) { r.builtinEnabled = !(r.builtinEnabled !== false); });
          haptic(15);
        }))
    ]));
    if (!setting("adBlock", true)) {
      wrap.appendChild(h("div", { class: "k-small", style: { color: "var(--danger)" } }, "حظر الإعلانات معطّل من الإعدادات، لذا لا تُطبّق هذه القائمة حالياً."));
    }
    var list = Array.isArray(App.BLOCKLIST) ? App.BLOCKLIST : [];
    if (!list.length) {
      wrap.appendChild(Kit.ui.empty({ icon: "shield", title: "القائمة غير متاحة", text: "تعذّر تحميل القائمة المدمجة." }));
      return wrap;
    }
    wrap.appendChild(Kit.ui.list(list.map(function (b) {
      var allowed = App.isAllowed(b.domain);
      return tagSearch(Kit.ui.item({
        title: b.domain, sub: App.kindLabel(b.kind) + (allowed ? " · مسموح" : ""),
        icon: b.kind === "tracker" ? "eye" : "shield"
      }), b.domain + " " + App.kindLabel(b.kind));
    })));
    return wrap;
  }

  // ---------- Rules screen ----------
  App.screens.rules = function (el) {
    var rd = rulesData();
    var view = ["custom", "allow", "builtin"].indexOf(rulesState.view) >= 0 ? rulesState.view : "custom";
    var root = h("div", { class: "k-col barq-rules", style: { gap: "12px", paddingBlockEnd: "16px" } });

    root.appendChild(Kit.ui.segmented([
      { value: "custom", label: "مخصّصة (" + rd.custom.length + ")" },
      { value: "allow", label: "السماح (" + rd.allow.length + ")" },
      { value: "builtin", label: "المدمجة" }
    ], view, function (v) { rulesState.view = v; Kit.refresh(); }));

    var s = Kit.ui.search(function (v) {
      rulesState.query = inputVal(v);
      applyRuleFilter(root, rulesState.query);
    }, "ابحث عن نطاق");
    if (s.input) {
      if (rulesState.query) s.input.value = rulesState.query;
      s.input.addEventListener("input", function () { rulesState.query = s.input.value; applyRuleFilter(root, rulesState.query); });
    }
    root.appendChild(s);

    if (view === "custom") root.appendChild(customView(rd));
    else if (view === "allow") root.appendChild(allowView(rd));
    else root.appendChild(builtinView(rd));

    root.appendChild(h("div", { class: "k-small k-muted barq-rule-nomatch", style: { display: "none", textAlign: "center" } }, "لا توجد نطاقات تطابق بحثك."));
    el.appendChild(root);
    if (rulesState.query) applyRuleFilter(root, rulesState.query);
  };
})();