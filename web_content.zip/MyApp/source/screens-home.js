(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};

  var DIAL_COLORS = [
    "#1E6FFF", "#00C2A8", "#E53935", "#FB8C00", "#8E24AA", "#43A047",
    "#3949AB", "#6D4C41", "#00897B", "#D81B60", "#546E7A", "#F4B400"
  ];
  var MAX_DIALS = 24;

  var homeState = { privateMode: false, editDials: false };

  function toast(m) { try { Kit.toast(m); } catch (e) {} }

  function validUrl(text) {
    if (typeof App.validUrl === "function") {
      try { return !!App.validUrl(text); } catch (e) {}
    }
    var t = String(text || "").trim();
    if (!t || /\s/.test(t)) return false;
    if (!/^https?:\/\//i.test(t)) t = "https://" + t;
    try {
      var u = new URL(t);
      var host = u.hostname || "";
      return host === "localhost" || /^[^.]+\.[^.]{2,}/.test(host) || /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host);
    } catch (e) { return false; }
  }

  function todayKey() {
    try { if (typeof App.todayKey === "function") return App.todayKey(); } catch (e) {}
    return Kit.util.today();
  }

  function todayStats() {
    var s = null;
    try { s = App.statsStore.get(); } catch (e) {}
    var d = s && s.days && s.days[todayKey()];
    d = d && typeof d === "object" ? d : {};
    return {
      ads: Number(d.ads) || 0,
      trackers: Number(d.trackers) || 0,
      params: Number(d.params) || 0,
      files: Number(d.files) || 0
    };
  }

  function engineName() {
    try {
      var key = App.engineKey();
      var eng = (App.SEARCH_ENGINES || {})[key] || {};
      return eng.name || eng.label || key || "DuckDuckGo";
    } catch (e) { return "DuckDuckGo"; }
  }

  function firstLetter(title) {
    var t = String(title || "").trim();
    if (!t) return "؟";
    var ch = Array.from(t)[0] || "؟";
    return ch.toUpperCase();
  }

  function dials() {
    var l = [];
    try { l = App.speeddialStore.get(); } catch (e) {}
    return Array.isArray(l) ? l.filter(function (d) { return d && d.id; }) : [];
  }

  function safeColor(c) {
    return /^#[0-9a-f]{3,8}$/i.test(String(c || "")) ? c : DIAL_COLORS[0];
  }

  // ---------- Search / address bar ----------
  function searchBar() {
    var hint = h("div", { class: "k-small k-muted", style: { minHeight: "1.3em", paddingInline: "4px" } }, "");
    var input = h("input", {
      class: "barq-address-input",
      type: "text",
      dir: "auto",
      autocomplete: "off",
      autocapitalize: "off",
      spellcheck: "false",
      enterkeyhint: "go",
      "aria-label": "ابحث أو اكتب رابطاً",
      placeholder: "ابحث أو اكتب رابطاً",
      style: {
        flex: "1", minWidth: "0", minHeight: "44px", border: "none", outline: "none",
        background: "transparent", color: "var(--text)", fontSize: "16px", paddingInline: "8px"
      },
      oninput: function () { updateHint(); }
    });

    function updateHint() {
      var v = String(input.value || "").trim();
      if (!v) { hint.textContent = ""; return; }
      var isUrl = false;
      try { isUrl = App.looksLikeUrl(v); } catch (e) {}
      hint.textContent = isUrl ? "سيُفتح الرابط مباشرة" : "سيُبحث عن «" + v + "» عبر " + engineName();
    }

    var privBtn = h("button", {
      type: "button",
      class: "barq-priv-toggle",
      "aria-label": "تبويب خفي",
      "aria-pressed": homeState.privateMode ? "true" : "false",
      title: "تبويب خفي",
      style: privStyle(),
      onclick: function () {
        homeState.privateMode = !homeState.privateMode;
        privBtn.setAttribute("aria-pressed", homeState.privateMode ? "true" : "false");
        var st = privStyle();
        for (var k in st) privBtn.style[k] = st[k];
        App.haptic(10);
        toast(homeState.privateMode ? "سيُفتح البحث في تبويب خفي" : "سيُفتح البحث في تبويب عادي");
      }
    }, Kit.icon("eye", 20));

    function privStyle() {
      return {
        minWidth: "44px", minHeight: "44px", borderRadius: "var(--radius-s)", border: "none",
        display: "inline-flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
        background: homeState.privateMode ? "var(--primary)" : "transparent",
        color: homeState.privateMode ? "var(--on-primary)" : "var(--muted)"
      };
    }

    function submit(ev) {
      if (ev && ev.preventDefault) ev.preventDefault();
      var v = String(input.value || "").trim();
      if (!v) { toast("اكتب رابطاً أو كلمة للبحث"); input.focus(); return; }
      try { input.blur(); } catch (e) {}
      App.haptic(10);
      App.openUrl(v, { private: homeState.privateMode, newTab: true });
    }

    var form = h("form", { class: "barq-address k-col", onsubmit: submit, style: { gap: "4px" } },
      h("div", {
        class: "k-row barq-address-bar",
        style: {
          alignItems: "center", gap: "4px", background: "var(--surface)", border: "1px solid var(--line)",
          borderRadius: "var(--radius)", paddingInline: "8px", boxShadow: "var(--shadow)"
        }
      },
        h("span", { style: { color: "var(--muted)", display: "inline-flex" } }, Kit.icon("search", 20)),
        input,
        privBtn,
        h("button", {
          type: "submit", "aria-label": "انتقال",
          style: {
            minWidth: "44px", minHeight: "44px", border: "none", borderRadius: "var(--radius-s)",
            background: "var(--primary)", color: "var(--on-primary)", display: "inline-flex",
            alignItems: "center", justifyContent: "center", cursor: "pointer"
          }
        }, Kit.icon("next", 20))
      ),
      hint
    );
    return form;
  }

  // ---------- Quick actions ----------
  function quickBtn(icon, label, onClick) {
    return h("button", {
      type: "button", class: "barq-quick k-col", "aria-label": label, onclick: onClick,
      style: {
        alignItems: "center", justifyContent: "center", gap: "6px", minHeight: "72px", padding: "8px 4px",
        background: "var(--surface)", color: "var(--text)", border: "1px solid var(--line)",
        borderRadius: "var(--radius)", cursor: "pointer", fontSize: "12px"
      }
    }, h("span", { style: { color: "var(--primary)", display: "inline-flex" } }, Kit.icon(icon, 22)), h("span", null, label));
  }

  async function quickWipe() {
    if (typeof App.wipeAll === "function") { await App.wipeAll(); return; }
    var ok = await Kit.confirm("مسح السجل وكل التبويبات وذاكرة الجلسة؟", { danger: true, ok: "مسح" });
    if (!ok) return;
    App.historyStore.set([]);
    App.closeAllNow(true);
    App.closeAllNow(false);
    App.haptic(40);
    toast("مُسحت بيانات التصفّح");
  }

  function quickActions() {
    return Kit.ui.grid([
      quickBtn("plus", "تبويب جديد", function () { App.newTab(false); }),
      quickBtn("eye", "تبويب خفي", function () { App.newTab(true); }),
      quickBtn("download", "التنزيلات", function () { Kit.go("downloads"); }),
      quickBtn("star", "الإشارات", function () { Kit.go("bookmarks"); }),
      quickBtn("globe", "المترجم", function () { Kit.go("translator"); }),
      quickBtn("zap", "اختبار السرعة", function () { Kit.go("speedtest"); }),
      quickBtn("trash", "مسح البيانات", quickWipe),
      quickBtn("shield", "الدرع", function () { Kit.go("shield"); })
    ], 4);
  }

  // ---------- Speed dial ----------
  function dialTile(d) {
    var color = safeColor(d.color);
    var tile = h("button", {
      type: "button", class: "barq-dial k-col",
      "aria-label": homeState.editDials ? "تعديل " + (d.title || "") : "فتح " + (d.title || ""),
      style: {
        alignItems: "center", gap: "6px", minHeight: "84px", padding: "6px 2px", border: "none",
        background: "transparent", color: "var(--text)", cursor: "pointer", position: "relative"
      },
      onclick: function () {
        if (homeState.editDials) { App.editDialSheet(d); return; }
        App.haptic(10);
        App.openUrl(d.url, { private: homeState.privateMode, newTab: true });
      },
      oncontextmenu: function (ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        App.haptic(25);
        App.editDialSheet(d);
      }
    },
      h("span", {
        style: {
          width: "52px", height: "52px", borderRadius: "var(--radius)", background: color,
          color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "22px", fontWeight: "700", boxShadow: "var(--shadow)", position: "relative"
        }
      }, firstLetter(d.title),
        homeState.editDials ? h("span", {
          style: {
            position: "absolute", insetBlockStart: "-6px", insetInlineEnd: "-6px", width: "22px", height: "22px",
            borderRadius: "50%", background: "var(--surface)", color: "var(--text)", display: "flex",
            alignItems: "center", justifyContent: "center", border: "1px solid var(--line)"
          }
        }, Kit.icon("edit", 13)) : null
      ),
      h("span", {
        class: "k-small",
        style: { maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }
      }, d.title || App.shortHost(d.url) || "")
    );
    return tile;
  }

  function addTile() {
    return h("button", {
      type: "button", class: "barq-dial k-col", "aria-label": "إضافة اتصال سريع",
      style: {
        alignItems: "center", gap: "6px", minHeight: "84px", padding: "6px 2px", border: "none",
        background: "transparent", color: "var(--muted)", cursor: "pointer"
      },
      onclick: function () { App.editDialSheet(null); }
    },
      h("span", {
        style: {
          width: "52px", height: "52px", borderRadius: "var(--radius)", border: "2px dashed var(--line)",
          display: "flex", alignItems: "center", justifyContent: "center"
        }
      }, Kit.icon("plus", 22)),
      h("span", { class: "k-small" }, "إضافة")
    );
  }

  function speedDialSection() {
    var list = dials();
    var wrap = h("div", { class: "k-col", style: { gap: "8px" } });
    wrap.appendChild(Kit.ui.section("الاتصال السريع", {
      label: homeState.editDials ? "تم" : "تعديل",
      onClick: function () { homeState.editDials = !homeState.editDials; Kit.refresh(); }
    }));
    if (!list.length) {
      wrap.appendChild(Kit.ui.empty({
        icon: "star", title: "لا توجد مربّعات بعد",
        text: "أضف مواقعك المفضّلة للوصول إليها بلمسة واحدة.",
        action: { label: "إضافة مربّع", onClick: function () { App.editDialSheet(null); } }
      }));
      return wrap;
    }
    var tiles = list.map(dialTile);
    if (list.length < MAX_DIALS) tiles.push(addTile());
    wrap.appendChild(Kit.ui.grid(tiles, 4));
    if (homeState.editDials) {
      wrap.appendChild(h("div", { class: "k-small k-muted" }, "اضغط على أي مربّع لتعديله أو حذفه."));
    } else {
      wrap.appendChild(h("div", { class: "k-small k-muted" }, "اضغط مطوّلاً على مربّع لتعديله."));
    }
    return wrap;
  }

  // ---------- Protection summary ----------
  function protectionSection() {
    var s = todayStats();
    var total = s.ads + s.trackers + s.params + s.files;
    var adOn = App.setting("adBlock", true);
    var wrap = h("div", { class: "k-col", style: { gap: "8px" } });
    wrap.appendChild(Kit.ui.section("حماية اليوم", { label: "الدرع", onClick: function () { Kit.go("shield"); } }));
    var card = Kit.ui.card([
      h("div", { class: "k-row", style: { alignItems: "center", gap: "8px", marginBlockEnd: "8px" } },
        h("span", { style: { color: adOn ? "var(--ok)" : "var(--danger)", display: "inline-flex" } }, Kit.icon("shield", 22)),
        h("span", { class: "k-grow" }, adOn
          ? (total ? "أوقفنا اليوم " + Kit.util.fmtNum(total) + " محاولة تتبّع وإزعاج" : "الحماية مفعّلة، لم يُحظر شيء اليوم بعد")
          : "حظر الإعلانات معطّل من الإعدادات")
      ),
      Kit.ui.grid([
        Kit.ui.stat({ icon: "x", value: Kit.util.fmtNum(s.ads), label: "إعلانات" }),
        Kit.ui.stat({ icon: "eye", value: Kit.util.fmtNum(s.trackers), label: "متتبّعات" }),
        Kit.ui.stat({ icon: "filter", value: Kit.util.fmtNum(s.params), label: "معاملات" }),
        Kit.ui.stat({ icon: "file", value: Kit.util.fmtNum(s.files), label: "ملفات خطرة" })
      ], 4)
    ], { onClick: function () { Kit.go("shield"); } });
    wrap.appendChild(card);
    return wrap;
  }

  // ---------- Continue browsing ----------
  function continueSection() {
    var cur = null;
    try { cur = App.currentTab(); } catch (e) {}
    var normal = 0, priv = 0;
    try { normal = App.allTabs(false).length; priv = App.allTabs(true).length; } catch (e) {}
    if (!cur && !normal && !priv) return null;
    var sub = normal + " عادية" + (priv ? " · " + priv + " خاصة" : "");
    var items = [];
    if (cur) {
      items.push(Kit.ui.item({
        title: cur.title || App.titleFor(cur.url),
        sub: cur.private ? "تبويب خفي" : (App.shortHost(cur.url) || ""),
        icon: cur.private ? "eye" : "globe",
        chevron: true,
        onClick: function () { App.switchTab(cur.id, !!cur.private); }
      }));
    }
    items.push(Kit.ui.item({
      title: "كل التبويبات", sub: sub, icon: "copy",
      trailing: Kit.ui.badge(String(normal + priv)), chevron: true,
      onClick: function () { Kit.go("tabs"); }
    }));
    return h("div", { class: "k-col", style: { gap: "8px" } },
      Kit.ui.section("تابع التصفّح"),
      Kit.ui.list(items));
  }

  // ---------- Recent history ----------
  function recentSection() {
    var hist = [];
    try { hist = App.historyStore.get(); } catch (e) {}
    hist = Array.isArray(hist) ? hist.filter(function (x) { return x && x.url; }) : [];
    hist = hist.slice().sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); }).slice(0, 5);
    var wrap = h("div", { class: "k-col", style: { gap: "8px" } });
    wrap.appendChild(Kit.ui.section("أحدث الزيارات", { label: "عرض الكل", onClick: function () { Kit.go("history"); } }));
    if (!hist.length) {
      wrap.appendChild(Kit.ui.empty({
        icon: "clock", title: "لا يوجد سجل",
        text: App.setting("saveHistory", true) ? "ستظهر هنا الصفحات التي تزورها." : "حفظ السجل معطّل من الإعدادات.",
        action: { label: "تبويب جديد", onClick: function () { App.newTab(false); } }
      }));
      return wrap;
    }
    wrap.appendChild(Kit.ui.list(hist.map(function (it) {
      return Kit.ui.item({
        title: it.title || App.shortHost(it.url) || it.url,
        sub: (App.shortHost(it.url) || "") + " · " + Kit.util.fmtTime(it.ts || Date.now()),
        leading: Kit.ui.avatar(firstLetter(it.title || App.shortHost(it.url))),
        onClick: function () { App.openUrl(it.url, { private: false, newTab: true }); }
      });
    })));
    return wrap;
  }

  // ---------- Screen ----------
  App.screens.home = function (el) {
    var root = h("div", { class: "k-col barq-home", style: { gap: "18px", paddingBlockEnd: "16px" } });
    root.appendChild(h("div", { class: "k-col", style: { gap: "4px" } },
      h("div", { class: "k-h1" }, "متصفح برق"),
      h("div", { class: "k-small k-muted" }, "البحث عبر " + engineName())
    ));
    root.appendChild(searchBar());
    root.appendChild(quickActions());
    var cont = continueSection();
    if (cont) root.appendChild(cont);
    root.appendChild(speedDialSection());
    root.appendChild(protectionSection());
    root.appendChild(recentSection());
    el.appendChild(root);
  };

  // ---------- Speed dial editor ----------
  App.editDialSheet = function (item) {
    var existing = item && item.id ? item : null;
    if (!existing && dials().length >= MAX_DIALS) {
      toast("وصلت إلى الحد الأقصى (" + MAX_DIALS + " مربّعاً)");
      return;
    }
    Kit.sheet(function (close) {
      var color = safeColor(existing ? existing.color : DIAL_COLORS[dials().length % DIAL_COLORS.length]);
      var tf = Kit.ui.field({ label: "الاسم", value: existing ? existing.title : "", placeholder: "مثال: ويكيبيديا" });
      var uf = Kit.ui.field({ label: "الرابط", type: "url", value: existing ? existing.url : "", placeholder: "https://example.com" });
      if (uf.input) uf.input.setAttribute("dir", "ltr");
      var err = h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } });

      var preview = h("span", {
        style: {
          width: "56px", height: "56px", borderRadius: "var(--radius)", background: color, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px", fontWeight: "700",
          boxShadow: "var(--shadow)", flexShrink: "0"
        }
      }, firstLetter(existing ? existing.title : ""));

      function updatePreview() {
        preview.textContent = firstLetter(tf.input ? tf.input.value : "");
        preview.style.background = color;
      }
      if (tf.input) tf.input.addEventListener("input", function () { updatePreview(); err.textContent = ""; });
      if (uf.input) uf.input.addEventListener("input", function () { err.textContent = ""; });

      var swatches = h("div", { class: "k-row k-wrap", style: { gap: "8px" } });
      function drawSwatches() {
        swatches.textContent = "";
        DIAL_COLORS.forEach(function (c) {
          var sel = c.toLowerCase() === color.toLowerCase();
          swatches.appendChild(h("button", {
            type: "button", "aria-label": "اللون " + c, "aria-pressed": sel ? "true" : "false",
            style: {
              width: "44px", height: "44px", borderRadius: "50%", background: c, cursor: "pointer",
              border: sel ? "3px solid var(--text)" : "2px solid var(--line)", color: "#fff",
              display: "inline-flex", alignItems: "center", justifyContent: "center"
            },
            onclick: function () { color = c; drawSwatches(); updatePreview(); App.haptic(8); }
          }, sel ? Kit.icon("check", 18) : null));
        });
      }
      drawSwatches();

      function save(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        var title = String(tf.input ? tf.input.value : "").trim();
        var url = String(uf.input ? uf.input.value : "").trim();
        if (!title) { err.textContent = "اكتب اسماً للمربّع"; if (tf.input) tf.input.focus(); return; }
        if (title.length > 30) { err.textContent = "الاسم طويل، استخدم 30 حرفاً على الأكثر"; return; }
        if (!url) { err.textContent = "اكتب رابط الموقع"; if (uf.input) uf.input.focus(); return; }
        if (!validUrl(url)) { err.textContent = "الرابط غير صالح، مثال صحيح: https://example.com"; return; }
        if (!/^https?:\/\//i.test(url)) url = "https://" + url;
        App.speeddialStore.update(function (arr) {
          arr = Array.isArray(arr) ? arr : [];
          if (existing) {
            return arr.map(function (d) {
              return d && d.id === existing.id ? { id: d.id, title: title, url: url, color: color } : d;
            });
          }
          arr.push({ id: App.uid(), title: title, url: url, color: color });
          return arr;
        });
        App.haptic(25);
        toast(existing ? "حُفظت التعديلات" : "أُضيف «" + title + "» إلى الاتصال السريع");
        close();
      }

      async function remove() {
        if (!existing) return;
        var ok = await Kit.confirm("حذف «" + (existing.title || "") + "» من الاتصال السريع؟", { danger: true, ok: "حذف" });
        if (!ok) return;
        App.speeddialStore.update(function (arr) {
          return (Array.isArray(arr) ? arr : []).filter(function (d) { return d && d.id !== existing.id; });
        });
        App.haptic(30);
        toast("حُذف المربّع");
        close();
      }

      return h("form", { class: "k-col k-gap", onsubmit: save },
        h("div", { class: "k-row", style: { alignItems: "center", gap: "12px" } },
          preview,
          h("div", { class: "k-small k-muted k-grow" }, "يظهر الحرف الأول من الاسم داخل المربّع باللون الذي تختاره.")
        ),
        tf, uf,
        h("div", { class: "k-small k-muted" }, "اللون"),
        swatches,
        err,
        Kit.ui.btn(existing ? "حفظ التعديلات" : "إضافة المربّع", { kind: "primary", icon: "check", block: true, onClick: save }),
        existing ? Kit.ui.btn("حذف المربّع", { kind: "danger", icon: "trash", block: true, onClick: remove }) : null
      );
    }, { title: existing ? "تعديل الاتصال السريع" : "إضافة اتصال سريع" });
  };
})();