(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};

  // Sites that commonly refuse to be shown inside a frame (X-Frame-Options / CSP frame-ancestors).
  var FRAME_REFUSERS = [
    "google.com", "youtube.com", "github.com", "x.com", "twitter.com", "facebook.com",
    "instagram.com", "linkedin.com", "stackoverflow.com", "reddit.com", "amazon.com",
    "microsoft.com", "live.com", "apple.com", "whatsapp.com", "tiktok.com", "netflix.com",
    "paypal.com", "yahoo.com", "bing.com", "aljazeera.net", "bbc.com", "bbc.co.uk",
    "duckduckgo.com", "search.brave.com", "brave.com", "startpage.com", "translate.goog",
    "googleusercontent.com", "gmail.com", "accuweather.com", "skynewsarabia.com",
    "khanacademy.org", "developer.mozilla.org", "mozilla.org", "openai.com", "chatgpt.com",
    "spotify.com", "discord.com", "telegram.org", "messenger.com", "pinterest.com",
    "snapchat.com", "ebay.com", "aliexpress.com", "booking.com", "dropbox.com",
    "office.com", "outlook.com", "icloud.com", "cnn.com", "nytimes.com", "medium.com",
    "quora.com", "twitch.tv", "vimeo.com", "zoom.us", "binance.com", "noon.com"
  ];
  var LOAD_TIMEOUT = 12000;
  var dismissedNotice = {};
  var forceFrame = {};
  // Pages already sent to the external browser in this navigation (prevents re-opening on re-render).
  var autoOpened = {};

  if (typeof App.openUrl === "function" && !App.openUrl.__barqWrapped) {
    var origOpenUrl = App.openUrl;
    App.openUrl = function () {
      autoOpened = {};
      return origOpenUrl.apply(this, arguments);
    };
    App.openUrl.__barqWrapped = true;
  }

  // Google search with igu=1 accepts being shown inside a frame.
  function embeddable(url) {
    return /^https:\/\/(www\.)?google\.[a-z.]+\/(search|webhp)\?(.*&)?igu=1(&|$)/i.test(String(url || ""));
  }

  // Sites the user marked as "refuses to show inside the app" (persisted).
  App.frameRefuseStore = App.frameRefuseStore || Kit.store("frameRefusers", []);

  function userRefusers() {
    var l = [];
    try { l = App.frameRefuseStore.get(); } catch (e) {}
    return Array.isArray(l) ? l.filter(function (x) { return typeof x === "string" && x; }) : [];
  }

  function siteKey(url) {
    var k = "";
    try { k = App.shortHost(url) || ""; } catch (e) {}
    return k || hostOf(url);
  }

  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) {} }

  function hostOf(url) {
    try { return App.hostOf(url) || ""; } catch (e) { return ""; }
  }

  function likelyRefuses(url) {
    if (embeddable(url)) return false;
    var host = hostOf(url);
    if (!host) return false;
    var all = FRAME_REFUSERS.concat(userRefusers());
    for (var i = 0; i < all.length; i++) {
      try {
        if (App.domainMatches(host, all[i])) return true;
      } catch (e) {
        if (host === all[i] || host.slice(-(all[i].length + 1)) === "." + all[i]) return true;
      }
    }
    return false;
  }

  function markRefuser(url, auto) {
    var key = siteKey(url);
    if (!key) { if (!auto) toast("لا يوجد موقع لتعليمه"); return; }
    if (userRefusers().indexOf(key) >= 0) { if (!auto) toast("هذا الموقع معلَّم مسبقاً"); return; }
    haptic(20);
    toast("سيُفتح " + key + " في المتصفح الخارجي مباشرة في المرات التالية");
    App.frameRefuseStore.update(function (l) {
      var arr = Array.isArray(l) ? l.filter(function (x) { return typeof x === "string"; }) : [];
      arr.push(key);
      if (arr.length > 300) arr = arr.slice(-300);
      return arr;
    });
  }

  function unmarkRefuser(url) {
    var key = siteKey(url);
    App.frameRefuseStore.update(function (l) {
      return (Array.isArray(l) ? l : []).filter(function (x) { return x !== key; });
    });
    toast("أُزيل " + key + " من المواقع الرافضة");
  }

  // Opens the page externally and remembers the site so next time it opens there directly.
  function openExternalRemember(tab) {
    autoOpened[tab.id + "|" + tab.url] = true;
    haptic(15);
    App.openExternal(tab.url);
    if (App.setting("autoExternal", true)) markRefuser(tab.url, true);
  }

  // ---------- Remembered refusers: open externally right away ----------
  function autoExternalPage(tab) {
    var key = tab.id + "|" + tab.url;
    var site = siteKey(tab.url);
    if (!autoOpened[key]) {
      autoOpened[key] = true;
      haptic(15);
      setTimeout(function () { App.openExternal(tab.url); }, 0);
    }
    return h("div", { class: "k-card k-col barq-refused", style: { alignItems: "center", textAlign: "center", gap: "12px", paddingBlock: "24px" } },
      h("span", { style: { color: "var(--primary)", display: "inline-flex" } }, Kit.icon("globe", 48)),
      h("div", { class: "k-h2" }, "فُتح الموقع في المتصفح الخارجي"),
      h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, tab.url || ""),
      h("div", { class: "k-small", style: { lineHeight: "1.7" } },
        "يتذكّر التطبيق أن " + site + " يرفض العرض داخل التطبيق، لذلك يفتحه في المتصفح الخارجي مباشرة."),
      h("div", { class: "k-col", style: { gap: "8px", width: "100%" } },
        Kit.ui.btn("فتح مرة أخرى", { kind: "primary", icon: "globe", block: true, onClick: function () { haptic(15); App.openExternal(tab.url); } }),
        Kit.ui.btn("نسخ الرابط", { kind: "tonal", icon: "copy", block: true, onClick: function () { App.copyUrl(tab.url); } }),
        Kit.ui.btn("محاولة العرض هنا على أي حال", { kind: "ghost", icon: "refresh", block: true, onClick: function () { forceFrame[key] = true; try { Kit.refresh(); } catch (e) {} } }),
        Kit.ui.btn("إلغاء تذكّر هذا الموقع", { kind: "ghost", icon: "x", block: true, onClick: function () { unmarkRefuser(tab.url); } })
      )
    );
  }

  // ---------- Honest page for sites that refuse framing ----------
  function refusedPage(tab) {
    var key = tab.id + "|" + tab.url;
    var site = siteKey(tab.url);
    var userMarked = userRefusers().indexOf(site) >= 0;
    return h("div", { class: "k-card k-col barq-refused", style: { alignItems: "center", textAlign: "center", gap: "12px", paddingBlock: "24px" } },
      h("span", { style: { color: "var(--accent)", display: "inline-flex" } }, Kit.icon("globe", 48)),
      h("div", { class: "k-h2" }, "هذا الموقع يمنع عرضه داخل التطبيق"),
      h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, tab.url || ""),
      h("div", { class: "k-small", style: { lineHeight: "1.7" } },
        "بعض المواقع تمنع لأسباب أمنية عرض صفحاتها داخل التطبيقات الأخرى. إذا ظهرت لك رسالة مثل «Ce contenu est bloqué» أو «This content is blocked» فمصدرها الموقع نفسه، وليست عطلاً في التطبيق. افتح الموقع في المتصفح الخارجي لتصفّحه بشكل كامل، وسيتذكّر التطبيق ذلك في المرات التالية."),
      App.isSearchUrl(tab.url)
        ? h("div", { class: "k-small k-muted" }, "للبحث داخل التطبيق اختر «Google (داخل التطبيق)» من محرّك البحث في الإعدادات.")
        : null,
      h("div", { class: "k-col", style: { gap: "8px", width: "100%" } },
        Kit.ui.btn("فتح في المتصفح الخارجي", { kind: "primary", icon: "globe", block: true, onClick: function () { openExternalRemember(tab); } }),
        Kit.ui.btn("نسخ الرابط", { kind: "tonal", icon: "copy", block: true, onClick: function () { App.copyUrl(tab.url); } }),
        Kit.ui.btn("محاولة العرض هنا على أي حال", { kind: "ghost", icon: "refresh", block: true, onClick: function () { forceFrame[key] = true; try { Kit.refresh(); } catch (e) {} } }),
        userMarked ? Kit.ui.btn("إلغاء تعليم هذا الموقع", { kind: "ghost", icon: "x", block: true, onClick: function () { unmarkRefuser(tab.url); } }) : null
      )
    );
  }

  function isSecure(url) { return /^https:\/\//i.test(String(url || "")); }

  // ---------- Link safety sheet ----------
  App.showLinkCheck = function (url) {
    if (!url) { toast("لا يوجد رابط لفحصه"); return; }
    var r = { risk: "safe", score: 0, items: [] };
    try { r = App.checkUrl(url) || r; } catch (e) {}
    var items = Array.isArray(r.items) ? r.items : [];
    var color = "var(--primary)";
    var label = "";
    try { color = App.riskColor(r.risk) || color; } catch (e) {}
    try { label = App.riskLabel(r.risk) || ""; } catch (e) {}
    var score = Kit.util.clamp(Number(r.score) || 0, 0, 100);
    haptic(r.risk === "danger" ? 60 : 15);

    Kit.sheet(function (close) {
      var rows = items.map(function (it) {
        var ok = it && it.ok === true;
        var text = it && typeof it === "object" ? (it.text || "") : String(it || "");
        return h("div", { class: "k-row", style: { alignItems: "flex-start", gap: "8px", paddingBlock: "6px" } },
          h("span", { style: { color: ok ? "var(--ok)" : "var(--danger)", display: "inline-flex", flexShrink: "0" } },
            Kit.icon(ok ? "check" : "info", 18)),
          h("span", { class: "k-grow" }, text));
      });
      return h("div", { class: "k-col k-gap" },
        h("div", { class: "k-row", style: { alignItems: "center", gap: "12px" } },
          Kit.ui.ring(score, { label: "خطورة" }),
          h("div", { class: "k-col k-grow", style: { gap: "4px", minWidth: "0" } },
            h("div", { class: "k-h2", style: { color: color } }, label || "نتيجة الفحص"),
            h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, url))),
        rows.length ? h("div", { class: "k-card" }, rows) : h("div", { class: "k-muted" }, "لم تُرصد أي ملاحظات على هذا الرابط."),
        h("div", { class: "k-small k-muted" }, "الفحص يعتمد على قواعد محلية وقائية، ولا يضمن سلامة الموقع بالكامل."),
        Kit.ui.btn("نسخ الرابط المنظّف", { kind: "tonal", icon: "copy", block: true, onClick: function () { App.copyUrl(url); } }),
        Kit.ui.btn("إغلاق", { kind: "ghost", block: true, onClick: function () { close(); } })
      );
    }, { title: "فحص أمان الرابط" });
  };

  // ---------- More menu ----------
  function moreMenu(tab) {
    Kit.sheet(function (close) {
      function act(fn) { return function () { close(); try { fn(); } catch (e) { toast("تعذّر تنفيذ الإجراء"); } }; }
      var items = [
        Kit.ui.item({ title: "مشاركة الرابط", sub: "بعد إزالة معاملات التتبّع", icon: "share", onClick: act(function () { App.shareUrl(tab.url, tab.title); }) }),
        Kit.ui.item({ title: "نسخ الرابط", icon: "copy", onClick: act(function () { App.copyUrl(tab.url); }) }),
        Kit.ui.item({ title: "حفظ كإشارة مرجعية", icon: "star", onClick: act(function () { App.addBookmarkSheet(tab); }) }),
        Kit.ui.item({ title: "ترجمة الصفحة", icon: "globe", onClick: act(function () { App.translatePage(tab); }) }),
        Kit.ui.item({ title: "فحص أمان الرابط", icon: "shield", onClick: act(function () { App.showLinkCheck(tab.url); }) }),
        Kit.ui.item({ title: "فتح في المتصفح الخارجي", icon: "globe", onClick: act(function () { App.openExternal(tab.url); }) })
      ];
      if (typeof App.startDownload === "function") {
        items.push(Kit.ui.item({ title: "تنزيل هذا الرابط", sub: "مع فحص مسبق", icon: "download", onClick: act(function () { App.startDownload(tab.url); }) }));
      }
      items.push(
        Kit.ui.item({ title: "تبويب جديد", icon: "plus", onClick: act(function () { App.newTab(false); }) }),
        Kit.ui.item({ title: "تبويب خفي جديد", icon: "eye", onClick: act(function () { App.newTab(true); }) }),
        Kit.ui.item({ title: "كل التبويبات", icon: "copy", onClick: act(function () { Kit.go("tabs"); }) }),
        Kit.ui.item({ title: "إغلاق هذا التبويب", icon: "x", onClick: act(function () { App.closeTab(tab.id); }) })
      );
      return Kit.ui.list(items);
    }, { title: tab.title || "المزيد" });
  }

  // ---------- Address bar ----------
  function addressBar(tab) {
    var secure = isSecure(tab.url);
    var input = h("input", {
      type: "text", dir: "ltr", value: tab.url || "", autocomplete: "off", autocapitalize: "off",
      spellcheck: "false", enterkeyhint: "go", "aria-label": "العنوان", placeholder: "ابحث أو اكتب رابطاً",
      style: {
        flex: "1", minWidth: "0", minHeight: "44px", border: "none", outline: "none",
        background: "transparent", color: "var(--text)", fontSize: "15px", paddingInline: "6px"
      },
      onfocus: function () { try { input.select(); } catch (e) {} }
    });
    function submit(ev) {
      if (ev && ev.preventDefault) ev.preventDefault();
      var v = String(input.value || "").trim();
      if (!v) { toast("اكتب رابطاً أو كلمة للبحث"); return; }
      try { input.blur(); } catch (e) {}
      haptic(10);
      App.openUrl(v, { tabId: tab.id, private: !!tab.private, go: false });
    }
    var lock = h("button", {
      type: "button", "aria-label": secure ? "اتصال آمن، اضغط للفحص" : "اتصال غير مشفّر، اضغط للفحص",
      style: {
        minWidth: "40px", minHeight: "44px", border: "none", background: "transparent", cursor: "pointer",
        color: secure ? "var(--ok)" : "var(--danger)", display: "inline-flex", alignItems: "center", justifyContent: "center"
      },
      onclick: function () { App.showLinkCheck(tab.url); }
    }, Kit.icon(secure ? "lock" : "info", 18));
    var tabsCount = 0;
    try { tabsCount = App.allTabs(false).length + App.allTabs(true).length; } catch (e) {}
    var tabsBtn = h("button", {
      type: "button", "aria-label": "التبويبات (" + tabsCount + ")",
      style: {
        minWidth: "44px", minHeight: "44px", border: "none", background: "transparent", cursor: "pointer",
        color: "var(--text)", display: "inline-flex", alignItems: "center", justifyContent: "center"
      },
      onclick: function () { Kit.go("tabs"); }
    }, h("span", {
      style: {
        minWidth: "24px", height: "24px", border: "2px solid currentColor", borderRadius: "6px",
        display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "12px", fontWeight: "700", paddingInline: "2px"
      }
    }, String(tabsCount)));

    return h("form", {
      class: "k-row barq-urlbar", onsubmit: submit,
      style: {
        alignItems: "center", gap: "2px", background: "var(--surface)", border: "1px solid " + (tab.private ? "var(--accent)" : "var(--line)"),
        borderRadius: "var(--radius)", paddingInline: "4px", boxShadow: "var(--shadow)"
      }
    }, lock, input, tabsBtn);
  }

  // ---------- Toolbar ----------
  function toolbar(tab) {
    function tb(icon, label, onClick, disabled) {
      return h("button", {
        type: "button", "aria-label": label, title: label, disabled: !!disabled,
        style: {
          flex: "1", minWidth: "44px", minHeight: "44px", border: "none", background: "transparent",
          color: disabled ? "var(--muted)" : "var(--text)", opacity: disabled ? "0.45" : "1",
          cursor: disabled ? "default" : "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center",
          borderRadius: "var(--radius-s)"
        },
        onclick: function () { if (!disabled) onClick(); }
      }, Kit.icon(icon, 20));
    }
    return h("div", {
      class: "k-row barq-toolbar",
      style: { alignItems: "center", background: "var(--surface)", border: "1px solid var(--line)", borderRadius: "var(--radius)" }
    },
      tb("back", "رجوع", function () { haptic(10); App.goBack(); }, !App.canGoBack()),
      tb("next", "تقدّم", function () { haptic(10); App.goForward(); }, !App.canGoForward()),
      tb("refresh", "تحديث", function () { haptic(10); App.reloadCurrent(); }, !tab.url),
      tb("share", "مشاركة", function () { App.shareUrl(tab.url, tab.title); }, !tab.url),
      tb("star", "حفظ إشارة", function () { App.addBookmarkSheet(tab); }, !tab.url),
      tb("globe", "ترجمة", function () { App.translatePage(tab); }, !tab.url || !!tab.blocked),
      tb("more", "المزيد", function () { moreMenu(tab); })
    );
  }

  // ---------- Blocked page ----------
  function blockedPage(tab) {
    var b = tab.blocked || {};
    var host = hostOf(b.url || tab.url) || b.domain || "";
    var kind = "";
    try { kind = App.kindLabel(b.kind) || ""; } catch (e) {}
    return h("div", { class: "k-card barq-blocked k-col", style: { alignItems: "center", textAlign: "center", gap: "12px", paddingBlock: "28px" } },
      h("span", { style: { color: "var(--danger)", display: "inline-flex" } }, Kit.icon("shield", 56)),
      h("div", { class: "k-h1" }, "تم الحظر"),
      kind ? Kit.ui.badge(kind) : null,
      h("div", null, b.reason || "هذا النطاق موجود في قائمة الحظر."),
      h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, b.url || tab.url || ""),
      h("div", { class: "k-col", style: { gap: "8px", width: "100%" } },
        Kit.ui.btn("السماح مرة واحدة", { kind: "primary", icon: "check", block: true, onClick: function () { App.allowBlockedOnce(tab); } }),
        host ? Kit.ui.btn("إضافة " + host + " إلى قائمة السماح", {
          kind: "tonal", icon: "plus", block: true,
          onClick: async function () {
            var ok = await Kit.confirm("السماح دائماً بالنطاق " + host + "؟ لن يُحظر بعد الآن.", { ok: "سماح" });
            if (!ok) return;
            var err = App.addAllowDomain(host);
            if (err) { toast(err); return; }
            haptic(25);
            toast("أُضيف إلى قائمة السماح");
            App.reloadCurrent();
          }
        }) : null,
        App.canGoBack()
          ? Kit.ui.btn("الرجوع للصفحة السابقة", { kind: "ghost", icon: "back", block: true, onClick: function () { App.goBack(); } })
          : Kit.ui.btn("إغلاق التبويب", { kind: "ghost", icon: "x", block: true, onClick: function () { App.closeTab(tab.id); } })
      )
    );
  }

  // ---------- Frame-refusal notice ----------
  function frameNotice(tab, reason) {
    var key = tab.id + "|" + tab.url;
    if (dismissedNotice[key]) return null;
    var box = h("div", {
      class: "k-card barq-frame-notice", role: "status",
      style: { borderInlineStart: "4px solid var(--accent)", display: "flex", flexDirection: "column", gap: "8px" }
    },
      h("div", { class: "k-row", style: { alignItems: "flex-start", gap: "8px" } },
        h("span", { style: { color: "var(--accent)", display: "inline-flex", flexShrink: "0" } }, Kit.icon("info", 20)),
        h("div", { class: "k-grow k-small" }, reason)),
      h("div", { class: "k-row k-wrap", style: { gap: "8px" } },
        Kit.ui.btn("فتح في المتصفح الخارجي", { kind: "primary", icon: "globe", small: true, onClick: function () { openExternalRemember(tab); } }),
        Kit.ui.btn("إخفاء", { kind: "ghost", small: true, onClick: function () { dismissedNotice[key] = true; if (box.parentNode) box.parentNode.removeChild(box); } }))
    );
    return box;
  }

  // ---------- Page frame ----------
  function pageFrame(tab, noticeSlot) {
    var bar = h("div", { style: { height: "100%", width: "0%", background: "var(--primary)", transition: "width .2s" } });
    var loadbar = h("div", { class: "barq-loadbar", "aria-hidden": "true", style: { height: "3px", background: "var(--surface2)", borderRadius: "2px", overflow: "hidden" } }, bar);
    var loaded = false;
    var pct = 8;
    var frame = h("iframe", {
      class: "barq-frame",
      src: tab.url,
      title: tab.title || "الصفحة",
      sandbox: "allow-scripts allow-same-origin allow-forms allow-popups allow-modals",
      referrerpolicy: tab.private ? "no-referrer" : "strict-origin-when-cross-origin",
      allow: "fullscreen",
      style: {
        width: "100%", height: "calc(100vh - 250px)", minHeight: "360px", border: "1px solid var(--line)",
        borderRadius: "var(--radius)", background: "#fff", display: "block"
      }
    });
    bar.style.width = pct + "%";

    var timer = setInterval(function () {
      if (!frame.isConnected || loaded) { clearInterval(timer); return; }
      pct = Math.min(90, pct + (90 - pct) * 0.08);
      bar.style.width = pct + "%";
    }, 250);

    frame.addEventListener("load", function () {
      loaded = true;
      clearInterval(timer);
      bar.style.width = "100%";
      setTimeout(function () { loadbar.style.visibility = "hidden"; }, 350);
    });

    setTimeout(function () {
      if (loaded || !frame.isConnected || noticeSlot.childNodes.length) return;
      var n = frameNotice(tab, "تأخّر تحميل الصفحة. قد يكون الاتصال بطيئاً أو أن الموقع يرفض العرض داخل التطبيق.");
      if (n) noticeSlot.appendChild(n);
    }, LOAD_TIMEOUT);

    return h("div", { class: "k-col", style: { gap: "6px" } }, loadbar, frame);
  }

  // ---------- Locked / empty states ----------
  function lockedPrivate() {
    return Kit.ui.empty({
      icon: "lock", title: "التبويبات الخاصة مقفلة",
      text: "أدخل رمز PIN لعرض هذا التبويب الخفي.",
      action: { label: "فتح القفل", onClick: function () { App.unlockPrivate(); } }
    });
  }

  function noTab() {
    return h("div", { class: "k-col", style: { gap: "12px" } },
      Kit.ui.empty({
        icon: "globe", title: "لا يوجد تبويب مفتوح",
        text: "افتح تبويباً جديداً لتبدأ التصفّح.",
        action: { label: "تبويب جديد", onClick: function () { App.newTab(false); } }
      }),
      Kit.ui.btn("تبويب خفي جديد", { kind: "tonal", icon: "eye", block: true, onClick: function () { App.newTab(true); } }));
  }

  // ---------- Screen ----------
  App.screens.browser = function (el) {
    var tab = null;
    try { tab = App.currentTab(); } catch (e) {}
    if (!tab) { el.appendChild(noTab()); return; }

    var root = h("div", {
      class: "k-col barq-browser" + (tab.private ? " barq-private" : ""),
      style: { gap: "8px", paddingBlockEnd: "8px" }
    });

    if (tab.private) {
      root.appendChild(h("div", {
        class: "k-row barq-incognito", style: { alignItems: "center", gap: "8px", color: "var(--accent)" }
      },
        h("span", { class: "k-badge", style: { display: "inline-flex", alignItems: "center", gap: "4px" } }, Kit.icon("eye", 14), "خفي"),
        h("span", { class: "k-small k-muted k-grow" }, "لا يُحفظ هذا التبويب في السجل ويُمحى عند إغلاقه.")));
      if (App.hasPin() && !App.privateUnlocked) {
        root.appendChild(lockedPrivate());
        el.appendChild(root);
        return;
      }
    }

    var urlbar = addressBar(tab);
    root.appendChild(urlbar);
    root.appendChild(toolbar(tab));

    if (!tab.url) {
      root.appendChild(Kit.ui.empty({
        icon: "search", title: "تبويب فارغ",
        text: "اكتب رابطاً أو كلمة بحث في الشريط أعلاه.",
        action: { label: "ابدأ الكتابة", onClick: function () {
          var inp = urlbar.querySelector ? urlbar.querySelector("input") : null;
          if (inp) { try { inp.focus(); } catch (e) {} }
        } }
      }));
      el.appendChild(root);
      return;
    }

    if (tab.blocked) {
      root.appendChild(blockedPage(tab));
      el.appendChild(root);
      return;
    }

    var noticeSlot = h("div", { class: "k-col", style: { gap: "6px" } });
    if (!isSecure(tab.url)) {
      noticeSlot.appendChild(h("div", { class: "k-small", role: "status", style: { color: "var(--danger)", display: "flex", gap: "6px", alignItems: "center" } },
        Kit.icon("info", 16), "الاتصال غير مشفّر، تجنّب إدخال كلمات المرور أو البيانات الحساسة."));
    }
    var refuses = likelyRefuses(tab.url);
    if (refuses && !forceFrame[tab.id + "|" + tab.url]) {
      var remembered = userRefusers().indexOf(siteKey(tab.url)) >= 0;
      root.appendChild(noticeSlot);
      root.appendChild(remembered && App.setting("autoExternal", true) ? autoExternalPage(tab) : refusedPage(tab));
      el.appendChild(root);
      return;
    }
    if (refuses) {
      var n = frameNotice(tab, "هذا الموقع يرفض غالباً عرض صفحاته داخل تطبيقات أخرى لأسباب أمنية، فقد تظهر الصفحة فارغة أو برسالة «المحتوى محظور». هذا قرار من الموقع نفسه وليس عطلاً في التطبيق.");
      if (n) noticeSlot.appendChild(n);
    }
    root.appendChild(noticeSlot);
    root.appendChild(pageFrame(tab, noticeSlot));
    var linkStyle = { minHeight: "44px", border: "none", background: "transparent", color: "var(--primary)", cursor: "pointer", paddingInline: "6px" };
    root.appendChild(h("div", { class: "k-row", style: { justifyContent: "center", alignItems: "center", gap: "4px", flexWrap: "wrap" } },
      h("span", { class: "k-small k-muted" }, "لا تظهر الصفحة أو ظهرت رسالة حظر؟"),
      h("button", {
        type: "button", class: "k-small", style: linkStyle,
        onclick: function () { openExternalRemember(tab); }
      }, "افتحها في المتصفح الخارجي"),
      refuses ? null : h("button", {
        type: "button", class: "k-small", style: linkStyle,
        onclick: function () { markRefuser(tab.url); }
      }, "تذكّر أن هذا الموقع يرفض العرض")));
    el.appendChild(root);
  };
})();