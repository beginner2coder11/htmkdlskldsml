(function () {
  "use strict";

  App.screens = App.screens || {};

  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) { try { Kit.native.vibrate(ms); } catch (e2) {} } }
  function setting(k, d) {
    try { if (typeof App.setting === "function") return App.setting(k, d); } catch (e) {}
    try { return Kit.setting(k, d); } catch (e2) { return d; }
  }
  function has(name) { return typeof App[name] === "function"; }

  // ---------- Safe screen wrapper ----------
  function fallback(el, title) {
    el.appendChild(Kit.ui.empty({
      icon: "info",
      title: title || "تعذّر عرض الشاشة",
      text: "حدث خطأ أثناء تحميل هذه الشاشة. ارجع إلى الرئيسية وحاول مجدداً.",
      action: { label: "الرئيسية", onClick: function () { Kit.go("home"); } }
    }));
  }
  function screen(id, title) {
    return function (el, params, ctx) {
      var fn = App.screens && App.screens[id];
      if (typeof fn !== "function") { fallback(el, title); return; }
      return fn(el, params || {}, ctx);
    };
  }

  // ---------- Inline scan report fallback (only if missing) ----------
  if (typeof App.screens.scanreport !== "function") {
    App.screens.scanreport = function (el, params) {
      var p = params || {}, rep = null;
      try {
        if (p.id) {
          var list = App.downloadsStore.get();
          rep = (Array.isArray(list) ? list : []).filter(function (d) { return d && d.id === p.id; })[0] || null;
        } else if (p.url && has("checkUrl")) {
          var r = App.checkUrl(p.url);
          rep = { name: p.url, risk: r.risk, report: (r.items || []).map(function (i) { return { ok: !!i.ok, text: String(i.text || "") }; }) };
        }
      } catch (e) { rep = null; }
      if (!rep) { fallback(el, "لا يوجد تقرير"); return; }
      var label = rep.risk;
      try { label = App.riskLabel(rep.risk); } catch (e) {}
      el.appendChild(Kit.h("div", { class: "k-col barq-report", style: { gap: "12px" } },
        Kit.h("div", { class: "k-card k-col", style: { gap: "8px" } },
          Kit.h("div", { class: "barq-dl-name" }, String(rep.name || rep.url || "")),
          Kit.h("span", { class: "barq-risk barq-risk-" + (rep.risk || "safe") }, String(label || ""))),
        Kit.h("div", { class: "k-card" }, (Array.isArray(rep.report) ? rep.report : []).map(function (i) {
          return Kit.h("div", { class: "barq-check-item " + (i && i.ok ? "barq-check-ok" : "barq-check-bad") },
            Kit.icon(i && i.ok ? "check" : "info", 18), Kit.h("span", {}, String(i && i.text || "")));
        })),
        Kit.h("div", { class: "k-small k-muted" }, App.SCAN_NOTE || "هذا الفحص وقائي ولا يغني عن برنامج مكافحة فيروسات.")));
    };
  }

  // ---------- Actions ----------
  function newTab(priv) {
    try {
      if (has("newTab")) { App.newTab(!!priv); haptic(12); return; }
      if (has("openUrl")) { App.openUrl("", { private: !!priv, newTab: true }); haptic(12); return; }
    } catch (e) {}
    toast("تعذّر فتح تبويب جديد");
  }

  async function promptDownload() {
    if (!has("startDownload")) { toast("مدير التنزيلات غير متاح"); return; }
    var url = await Kit.prompt("رابط الملف", { placeholder: "https://example.com/file.pdf", type: "url" });
    if (url == null) return;
    url = String(url).trim();
    if (!url) { toast("اكتب رابط الملف"); return; }
    if (/\s/.test(url)) { toast("الرابط لا يجب أن يحتوي على مسافات"); return; }
    if (!/^[a-z][a-z0-9+.-]*:/i.test(url)) url = "https://" + url;
    try { new URL(url); } catch (e) { toast("الرابط غير صالح"); return; }
    try { App.startDownload(url); } catch (e) { toast("تعذّر بدء التنزيل"); }
  }

  async function setPinFlow() {
    if (!has("setPin")) { toast("قفل التبويبات غير متاح"); return; }
    try {
      if (App.setPin.length === 0) { await App.setPin(); return; }
      var hasPin = false;
      try { hasPin = has("hasPin") ? !!App.hasPin() : !!(App.securityStore.get() || {}).pin; } catch (e) {}
      if (hasPin) {
        var remove = await Kit.confirm("الرمز مفعّل حالياً. هل تريد إزالته؟ اختر «إلغاء» لتغييره.", { ok: "إزالة الرمز", danger: true });
        if (remove) { await App.setPin(null); haptic(20); toast("أُزيل الرمز"); return; }
      }
      var pin = await Kit.prompt("رمز PIN جديد (4 إلى 8 أرقام)", { type: "password", placeholder: "••••" });
      if (pin == null) return;
      pin = String(pin).trim();
      if (!/^\d{4,8}$/.test(pin)) { toast("يجب أن يتكوّن الرمز من 4 إلى 8 أرقام"); haptic(40); return; }
      var again = await Kit.prompt("أعد كتابة الرمز للتأكيد", { type: "password", placeholder: "••••" });
      if (again == null) return;
      if (String(again).trim() !== pin) { toast("الرمزان غير متطابقين"); haptic(40); return; }
      await App.setPin(pin);
      haptic(25); toast("فُعّل قفل التبويبات الخاصة");
    } catch (e) { toast("تعذّر حفظ الرمز"); }
  }

  // ---------- Clear on exit ----------
  var cleared = false;
  function clearSession(force) {
    if (cleared && !force) return;
    if (!setting("clearOnExit", false)) return;
    cleared = true;
    try { App.privateTabs = []; } catch (e) {}
    try { App.historyStore.set([]); } catch (e) {}
    try { App.tabsStore.set([]); } catch (e) {}
    try { App.sessionStore.set({ currentTabId: null, currentPrivate: false }); } catch (e) {}
  }
  function wipePrivate() {
    try { if (Array.isArray(App.privateTabs)) App.privateTabs.length = 0; } catch (e) {}
    try { if (has("lockPrivate")) App.lockPrivate(); } catch (e) {}
  }

  // Apply at launch too: Android may kill the WebView without firing unload events.
  try { clearSession(true); cleared = false; } catch (e) {}

  window.addEventListener("pagehide", function () { wipePrivate(); clearSession(); });
  window.addEventListener("beforeunload", function () { wipePrivate(); clearSession(); });
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "hidden") { try { if (has("lockPrivate")) App.lockPrivate(); } catch (e) {} }
  });

  // ---------- Tabs FAB ----------
  var tabsFab = { icon: "plus", label: "تبويب جديد", onClick: function () { newTab(false); } };
  try {
    if (App.tabsFab && typeof App.tabsFab === "object" && typeof App.tabsFab.onClick === "function") tabsFab = App.tabsFab;
  } catch (e) {}

  // ---------- Boot ----------
  Kit.app({
    name: "متصفح برق",
    tagline: "تصفّح سريع وآمن مع مانع إعلانات ووضع تخفٍّ وفحص للتنزيلات",
    needsInternet: true,
    tabs: [
      { id: "home", label: "الرئيسية", icon: "home", render: screen("home", "الرئيسية"),
        actions: [
          { icon: "eye", label: "تبويب خفي جديد", onClick: function () { newTab(true); } },
          { icon: "plus", label: "تبويب جديد", onClick: function () { newTab(false); } }
        ] },
      { id: "tabs", label: "التبويبات", icon: "copy", render: screen("tabs", "التبويبات"), fab: tabsFab },
      { id: "downloads", label: "التنزيلات", icon: "download", render: screen("downloads", "التنزيلات"),
        fab: { icon: "plus", label: "تنزيل جديد", onClick: promptDownload } },
      { id: "shield", label: "الدرع", icon: "shield", render: screen("shield", "الدرع"),
        actions: [{ icon: "filter", label: "قواعد الحظر", onClick: function () { Kit.go("rules"); } }] },
      { id: "tools", label: "أدوات", icon: "zap", render: screen("tools", "الأدوات") }
    ],
    screens: {
      browser: { title: "المتصفح", render: screen("browser", "المتصفح") },
      bookmarks: { title: "الإشارات المرجعية", render: screen("bookmarks", "الإشارات المرجعية") },
      history: { title: "السجل", render: screen("history", "السجل") },
      translator: { title: "المترجم", render: screen("translator", "المترجم") },
      speedtest: { title: "اختبار السرعة", render: screen("speedtest", "اختبار السرعة") },
      rules: { title: "قواعد الحظر", render: screen("rules", "قواعد الحظر") },
      scanreport: { title: "تقرير الفحص", render: screen("scanreport", "تقرير الفحص") }
    },
    onboarding: [
      { icon: "zap", title: "سرعة بلا عوائق", text: "ابحث أو اكتب رابطاً وانطلق، وافتح عدة تبويبات وتنقّل بينها بلمسة." },
      { icon: "shield", title: "حماية تلقائية", text: "نحظر نطاقات الإعلانات والمتتبّعات، ونزيل معاملات التتبّع، ونفحص الملفات قبل تنزيلها." },
      { icon: "eye", title: "تخفٍّ كامل", text: "التبويبات الخاصة لا تترك أثراً، ويمكنك قفلها برمز سرّي." }
    ],
    about: {
      version: "1.0",
      description: "متصفح برق متصفح خفيف وسريع يركّز على الخصوصية والأمان. يحظر نطاقات الإعلانات والمتتبّعات المعروفة، ويزيل معاملات التتبّع من الروابط، ويوفّر وضع تخفٍّ حقيقياً لا يحفظ شيئاً. يفحص الملفات بقواعد وقائية قبل التنزيل، ويضمّ مترجماً واختبار سرعة حقيقياً.",
      privacy: "يحفظ التطبيق على جهازك فقط: الإشارات المرجعية، والسجل، والتبويبات العادية، والاتصال السريع، وقائمة التنزيلات، وقواعد الحظر، والإحصاءات، ونتائج اختبار السرعة، والترجمات. لا نرسل أي بيانات إلى خوادمنا، ولا نملك خوادم أصلاً، ولا نستخدم أي أدوات تحليل أو إعلانات. التبويبات الخاصة لا تُكتب في الذاكرة الدائمة وتُمحى عند إغلاقها. تتواصل المواقع التي تزورها ومحرّك البحث الذي تختاره مباشرة مع جهازك وفق سياساتها الخاصة. أما اختبار السرعة فيحمّل ملفات اختبار من خوادم عامة ليقيس سرعتك، ولا يرسل أي معلومات شخصية. الأذونات المستخدمة: الاهتزاز لتأكيد الإجراءات المهمة، والإشعارات لإبلاغك باكتمال التنزيل أو رفضه. يمكنك حذف جميع البيانات في أي وقت من الإعدادات أو بزر «تنظيف فوري»."
    },
    settings: [
      { type: "select", key: "searchEngine", label: "محرّك البحث", icon: "search", default: "google_inapp", options: [
        { value: "google_inapp", label: "Google (يعمل داخل التطبيق)" },
        { value: "duckduckgo", label: "DuckDuckGo" },
        { value: "google", label: "Google" },
        { value: "bing", label: "Bing" },
        { value: "brave", label: "Brave Search" },
        { value: "startpage", label: "Startpage" }
      ] },
      { type: "select", key: "translateLang", label: "لغة ترجمة الصفحات", icon: "globe", default: "ar", options: [
        { value: "ar", label: "العربية" },
        { value: "en", label: "English" },
        { value: "fr", label: "Français" },
        { value: "es", label: "Español" },
        { value: "de", label: "Deutsch" },
        { value: "tr", label: "Türkçe" }
      ] },
      { type: "switch", key: "autoExternal", label: "تذكّر المواقع الرافضة وفتحها خارجياً مباشرة", icon: "globe", default: true },
      { type: "switch", key: "adBlock", label: "حظر الإعلانات والمتتبّعات", icon: "shield", default: true },
      { type: "switch", key: "stripParams", label: "إزالة معاملات التتبّع من الروابط", icon: "filter", default: true },
      { type: "switch", key: "forceHttps", label: "فرض الاتصال الآمن HTTPS", icon: "lock", default: true },
      { type: "switch", key: "scanDownloads", label: "فحص الملفات قبل التنزيل", icon: "file", default: true },
      { type: "switch", key: "blockExecutables", label: "طلب التأكيد قبل الملفات التنفيذية", icon: "info", default: true },
      { type: "switch", key: "saveHistory", label: "حفظ سجل التصفّح", icon: "clock", default: true },
      { type: "switch", key: "clearOnExit", label: "مسح السجل والتبويبات عند الخروج", icon: "trash", default: false },
      { type: "button", key: "setPin", label: "رمز قفل التبويبات الخاصة", icon: "lock", onClick: setPinFlow },
      { type: "button", key: "exportData", label: "تصدير الإشارات والاتصال السريع", icon: "download", onClick: function () {
        if (has("exportData")) App.exportData(); else toast("التصدير غير متاح");
      } },
      { type: "button", key: "importData", label: "استيراد الإشارات والاتصال السريع", icon: "upload", onClick: function () {
        if (has("importData")) App.importData(); else toast("الاستيراد غير متاح");
      } }
    ]
  });
})();