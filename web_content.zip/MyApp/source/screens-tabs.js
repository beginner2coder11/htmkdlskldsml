(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};

  var tabsState = { view: "all", query: "" };

  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) {} }

  function listTabs(priv) {
    var l = [];
    try { l = App.allTabs(!!priv); } catch (e) { l = []; }
    return Array.isArray(l) ? l.filter(function (t) { return t && t.id; }) : [];
  }

  function hasPin() {
    try { return !!App.hasPin(); } catch (e) { return false; }
  }

  function privateLocked() {
    return hasPin() && !App.privateUnlocked;
  }

  function currentId() {
    try {
      var c = App.currentTab();
      return c ? c.id : null;
    } catch (e) { return null; }
  }

  function tabTitle(t) {
    if (t.title) return t.title;
    if (!t.url) return "تبويب جديد";
    try { return App.titleFor(t.url) || t.url; } catch (e) { return t.url; }
  }

  function tabHost(t) {
    if (!t.url) return "صفحة فارغة";
    try { return App.shortHost(t.url) || t.url; } catch (e) { return t.url; }
  }

  function firstLetter(text) {
    var s = String(text || "").trim();
    if (!s) return "؟";
    return (Array.from(s)[0] || "؟").toUpperCase();
  }

  function safeRefresh() { try { Kit.refresh(); } catch (e) {} }

  function openNew(priv) {
    haptic(15);
    try { App.newTab(!!priv); } catch (e) { toast("تعذّر فتح تبويب جديد"); }
  }

  App.tabsFab = { icon: "plus", label: "تبويب جديد", onClick: function () { openNew(false); } };

  function closeOne(t) {
    haptic(20);
    try { App.closeTab(t.id); } catch (e) { toast("تعذّر إغلاق التبويب"); return; }
    toast(t.private ? "أُغلق التبويب الخفي ومُحيت بياناته" : "أُغلق التبويب");
    safeRefresh();
  }

  async function closeAllOf(priv) {
    var count = listTabs(priv).length;
    if (!count) { toast("لا توجد تبويبات لإغلاقها"); return; }
    var msg = priv
      ? "إغلاق كل التبويبات الخاصة (" + count + ")؟ ستُمحى بياناتها نهائياً."
      : "إغلاق كل التبويبات العادية (" + count + ")؟";
    var ok = await Kit.confirm(msg, { danger: true, ok: "إغلاق الكل" });
    if (!ok) return;
    try {
      if (typeof App.closeAllNow === "function") App.closeAllNow(!!priv);
      else {
        listTabs(priv).forEach(function (t) { try { App.closeTab(t.id); } catch (e) {} });
      }
    } catch (e) { toast("تعذّر إغلاق التبويبات"); return; }
    haptic(40);
    toast(priv ? "أُغلقت كل التبويبات الخاصة" : "أُغلقت كل التبويبات العادية");
    safeRefresh();
  }

  function unlock() {
    var r;
    try { r = App.unlockPrivate(); } catch (e) { toast("تعذّر فتح القفل"); return; }
    Promise.resolve(r).then(function () { safeRefresh(); }, function () {});
  }

  function lockNow() {
    try { App.lockPrivate(); } catch (e) { App.privateUnlocked = false; }
    haptic(25);
    toast("قُفلت التبويبات الخاصة");
    safeRefresh();
  }

  function setPin() {
    if (typeof App.setPin !== "function") { toast("هذه الميزة غير متاحة"); return; }
    var r;
    try { r = App.setPin(); } catch (e) { toast("تعذّر تعيين الرمز"); return; }
    Promise.resolve(r).then(function () { safeRefresh(); }, function () {});
  }

  // ---------- Tab card ----------
  function tabCard(t, isCurrent) {
    var priv = !!t.private;
    var title = tabTitle(t);
    var host = tabHost(t);
    var blocked = !!t.blocked;

    var closeBtn = h("button", {
      type: "button",
      "aria-label": "إغلاق " + title,
      title: "إغلاق",
      style: {
        minWidth: "44px", minHeight: "44px", border: "none", background: "transparent",
        color: "var(--muted)", cursor: "pointer", display: "inline-flex",
        alignItems: "center", justifyContent: "center", borderRadius: "var(--radius-s)", flexShrink: "0"
      },
      onclick: function (ev) {
        if (ev) { ev.stopPropagation(); if (ev.preventDefault) ev.preventDefault(); }
        closeOne(t);
      }
    }, Kit.icon("x", 20));

    var thumb = h("div", {
      class: "barq-tab-thumb",
      "aria-hidden": "true",
      style: {
        height: "72px", borderRadius: "var(--radius-s)",
        background: priv ? "var(--accent)" : "var(--surface2)",
        color: priv ? "var(--on-primary)" : "var(--primary)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "30px", fontWeight: "700", position: "relative"
      }
    },
      blocked ? Kit.icon("shield", 30) : (t.url ? firstLetter(host) : Kit.icon("plus", 28)),
      priv ? h("span", {
        style: {
          position: "absolute", insetBlockStart: "6px", insetInlineStart: "6px",
          display: "inline-flex", alignItems: "center", gap: "2px", fontSize: "11px",
          background: "var(--surface)", color: "var(--text)", borderRadius: "999px", paddingInline: "6px"
        }
      }, Kit.icon("eye", 12), "خفي") : null
    );

    var card = h("div", {
      class: "k-card barq-tab-card" + (priv ? " barq-tab-private" : "") + (isCurrent ? " barq-tab-current" : ""),
      role: "button",
      tabindex: "0",
      "aria-label": "التبديل إلى " + title,
      "data-search": (title + " " + (t.url || "")).toLowerCase(),
      style: {
        display: "flex", flexDirection: "column", gap: "6px", padding: "8px", cursor: "pointer", minWidth: "0",
        border: isCurrent ? "2px solid var(--primary)" : "1px solid " + (priv ? "var(--accent)" : "var(--line)")
      },
      onclick: function () {
        haptic(10);
        try { App.switchTab(t.id, priv); } catch (e) { toast("تعذّر فتح التبويب"); }
      },
      onkeydown: function (ev) {
        if (ev && (ev.key === "Enter" || ev.key === " ")) {
          ev.preventDefault();
          try { App.switchTab(t.id, priv); } catch (e) {}
        }
      }
    },
      thumb,
      h("div", { class: "k-row", style: { alignItems: "center", gap: "2px", minWidth: "0" } },
        h("div", { class: "k-col k-grow", style: { minWidth: "0", gap: "2px" } },
          h("div", {
            style: { fontWeight: "600", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }
          }, title),
          h("div", {
            class: "k-small k-muted", dir: "auto",
            style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }
          }, blocked ? "محظور" : host)
        ),
        closeBtn
      ),
      isCurrent ? h("div", { class: "k-small", style: { color: "var(--primary)" } }, "التبويب الحالي") : null
    );
    return card;
  }

  function cardsGrid(list, cur) {
    var sorted = list.slice().sort(function (a, b) { return (b.created || 0) - (a.created || 0); });
    return h("div", {
      class: "barq-tab-grid",
      style: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }
    }, sorted.map(function (t) { return tabCard(t, t.id === cur); }));
  }

  // ---------- Sections ----------
  function normalSection(cur) {
    var list = listTabs(false);
    var wrap = h("div", { class: "k-col barq-tab-section", style: { gap: "8px" } });
    wrap.appendChild(Kit.ui.section("التبويبات العادية (" + list.length + ")",
      list.length ? { label: "إغلاق الكل", onClick: function () { closeAllOf(false); } } : undefined));
    if (!list.length) {
      wrap.appendChild(Kit.ui.empty({
        icon: "copy", title: "لا توجد تبويبات",
        text: "افتح تبويباً جديداً لتبدأ التصفّح.",
        action: { label: "تبويب جديد", onClick: function () { openNew(false); } }
      }));
      return wrap;
    }
    wrap.appendChild(cardsGrid(list, cur));
    return wrap;
  }

  function privateSection(cur) {
    var list = listTabs(true);
    var locked = privateLocked();
    var wrap = h("div", { class: "k-col barq-tab-section barq-private-section", style: { gap: "8px" } });
    wrap.appendChild(Kit.ui.section("التبويبات الخاصة (" + list.length + ")",
      list.length && !locked ? { label: "إغلاق الكل", onClick: function () { closeAllOf(true); } } : undefined));

    var info = h("div", {
      class: "k-row", style: { alignItems: "center", gap: "8px", color: "var(--accent)" }
    },
      Kit.icon("eye", 18),
      h("span", { class: "k-small k-muted k-grow" }, "لا تُحفظ في السجل ولا في الذاكرة الدائمة، وتُمحى عند إغلاقها أو عند الخروج من التطبيق.")
    );
    wrap.appendChild(info);

    if (locked) {
      wrap.appendChild(Kit.ui.empty({
        icon: "lock", title: "القسم الخاص مقفل",
        text: list.length ? "لديك " + list.length + " تبويب خفي. أدخل رمز PIN لعرضها." : "أدخل رمز PIN لعرض التبويبات الخاصة.",
        action: { label: "فتح القفل", onClick: unlock }
      }));
      return wrap;
    }

    var lockRow = h("div", { class: "k-row k-wrap", style: { gap: "8px" } });
    if (hasPin()) {
      lockRow.appendChild(Kit.ui.btn("قفل الآن", { kind: "tonal", icon: "lock", small: true, onClick: lockNow }));
    } else {
      lockRow.appendChild(Kit.ui.btn("تعيين رمز PIN", { kind: "tonal", icon: "lock", small: true, onClick: setPin }));
    }
    lockRow.appendChild(Kit.ui.btn("تبويب خفي جديد", { kind: "ghost", icon: "plus", small: true, onClick: function () { openNew(true); } }));
    wrap.appendChild(lockRow);

    if (!list.length) {
      wrap.appendChild(Kit.ui.empty({
        icon: "eye", title: "لا توجد تبويبات خاصة",
        text: "تصفّح دون أن تترك أثراً على هذا الجهاز.",
        action: { label: "تبويب خفي جديد", onClick: function () { openNew(true); } }
      }));
      return wrap;
    }
    wrap.appendChild(cardsGrid(list, cur));
    return wrap;
  }

  // ---------- Search (filters cards in place, no re-render while typing) ----------
  function applyFilter(root, q) {
    var query = String(q || "").trim().toLowerCase();
    var cards = root.querySelectorAll(".barq-tab-card");
    var shown = 0;
    for (var i = 0; i < cards.length; i++) {
      var hay = cards[i].getAttribute("data-search") || "";
      var match = !query || hay.indexOf(query) >= 0;
      cards[i].style.display = match ? "flex" : "none";
      if (match) shown++;
    }
    var note = root.querySelector(".barq-tab-nomatch");
    if (note) note.style.display = query && cards.length && !shown ? "block" : "none";
  }

  // ---------- Screen ----------
  App.screens.tabs = function (el) {
    var normal = listTabs(false);
    var priv = listTabs(true);
    var cur = currentId();
    var total = normal.length + priv.length;

    var root = h("div", { class: "k-col barq-tabs", style: { gap: "16px", paddingBlockEnd: "88px" } });

    root.appendChild(h("div", { class: "k-row", style: { alignItems: "center", gap: "8px" } },
      h("div", { class: "k-col k-grow", style: { gap: "2px" } },
        h("div", { class: "k-h1" }, "التبويبات"),
        h("div", { class: "k-small k-muted" },
          total ? total + " مفتوحة · " + normal.length + " عادية · " + priv.length + " خاصة" : "لا توجد تبويبات مفتوحة")
      ),
      Kit.ui.badge(String(total))
    ));

    root.appendChild(h("div", { class: "k-row", style: { gap: "8px" } },
      Kit.ui.btn("تبويب جديد", { kind: "primary", icon: "plus", block: true, onClick: function () { openNew(false); } }),
      Kit.ui.btn("تبويب خفي", { kind: "tonal", icon: "eye", block: true, onClick: function () { openNew(true); } })
    ));

    var view = tabsState.view;
    if (["all", "normal", "private"].indexOf(view) < 0) view = "all";
    root.appendChild(Kit.ui.segmented([
      { value: "all", label: "الكل" },
      { value: "normal", label: "عادية" },
      { value: "private", label: "خاصة" }
    ], view, function (v) { tabsState.view = v; safeRefresh(); }));

    if (total > 3) {
      var s = Kit.ui.search(function (val) {
        tabsState.query = typeof val === "string" ? val : (val && val.target ? val.target.value : "");
        applyFilter(root, tabsState.query);
      }, "ابحث في التبويبات");
      if (s.input && tabsState.query) s.input.value = tabsState.query;
      root.appendChild(s);
      root.appendChild(h("div", { class: "k-muted k-small barq-tab-nomatch", style: { display: "none", textAlign: "center" } },
        "لا توجد تبويبات تطابق بحثك."));
    } else {
      tabsState.query = "";
    }

    if (view !== "private") root.appendChild(normalSection(cur));
    if (view !== "normal") root.appendChild(privateSection(cur));

    if (total > 1 && view === "all") {
      root.appendChild(Kit.ui.btn("إغلاق كل التبويبات", {
        kind: "danger", icon: "trash", block: true,
        onClick: async function () {
          var locked = privateLocked();
          var ok = await Kit.confirm(
            locked
              ? "إغلاق كل التبويبات العادية؟ التبويبات الخاصة المقفلة لن تُغلق."
              : "إغلاق كل التبويبات العادية والخاصة (" + total + ")؟",
            { danger: true, ok: "إغلاق الكل" });
          if (!ok) return;
          try {
            App.closeAllNow(false);
            if (!locked) App.closeAllNow(true);
          } catch (e) { toast("تعذّر إغلاق التبويبات"); return; }
          haptic(40);
          toast("أُغلقت التبويبات");
          safeRefresh();
        }
      }));
    }

    root.appendChild(h("button", {
      type: "button", class: "barq-tabs-fab", "aria-label": "تبويب جديد",
      style: {
        position: "fixed", insetInlineEnd: "16px", insetBlockEnd: "88px", width: "56px", height: "56px",
        borderRadius: "50%", border: "none", background: "var(--primary)", color: "var(--on-primary)",
        boxShadow: "var(--shadow)", display: "flex", alignItems: "center", justifyContent: "center",
        cursor: "pointer", zIndex: "5"
      },
      onclick: function () { openNew(false); }
    }, Kit.icon("plus", 26)));

    el.appendChild(root);
    if (tabsState.query) applyFilter(root, tabsState.query);
  };
})();