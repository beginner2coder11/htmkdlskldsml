(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};
  App.dlLive = App.dlLive || {};
  App.dlBlobs = App.dlBlobs || {};

  var MAX_ITEMS = 200;
  var MAX_INMEM = 150 * 1024 * 1024;
  var MAX_KEEP_BLOB = 50 * 1024 * 1024;
  var dlState = { filter: "all", sort: "new", query: "", draft: "" };
  var staleChecked = false;
  var RISK_ORDER = { safe: 0, warn: 1, danger: 2 };
  var RISK_SCORE = { safe: 8, warn: 55, danger: 92 };

  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) {} }
  function setting(k, d) { try { return App.setting(k, d); } catch (e) { return d; } }
  function notify(t, b) { try { Promise.resolve(Kit.native.notify(t, b)).catch(function () {}); } catch (e) {} }
  function uid() { try { return App.uid(); } catch (e) { return Kit.util.uid(); } }

  function list() {
    var l = [];
    try { l = App.downloadsStore.get(); } catch (e) {}
    return Array.isArray(l) ? l.filter(function (d) { return d && d.id; }) : [];
  }
  function findDl(id) { return list().filter(function (d) { return d.id === id; })[0] || null; }

  function upsert(entry) {
    App.downloadsStore.update(function (arr) {
      arr = Array.isArray(arr) ? arr.filter(Boolean) : [];
      var i = -1;
      for (var k = 0; k < arr.length; k++) if (arr[k].id === entry.id) { i = k; break; }
      if (i >= 0) arr[i] = Object.assign({}, arr[i], entry);
      else arr.unshift(entry);
      if (arr.length > MAX_ITEMS) arr.length = MAX_ITEMS;
      return arr;
    });
  }

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n <= 0) return "—";
    var u = ["بايت", "ك.ب", "م.ب", "ج.ب"], i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (i ? n.toFixed(n < 10 ? 1 : 0) : Math.round(n)) + " " + u[i];
  }

  function hostOf(url) { try { return App.shortHost(url) || App.hostOf(url) || ""; } catch (e) { return ""; } }
  function riskColor(r) { try { return App.riskColor(r) || "var(--muted)"; } catch (e) { return "var(--muted)"; } }
  function riskLabel(r) {
    try { var l = App.riskLabel(r); if (l) return l; } catch (e) {}
    return r === "danger" ? "خطر" : r === "warn" ? "تحذير" : "آمن";
  }

  function normItems(arr) {
    if (!Array.isArray(arr)) return [];
    return arr.map(function (it) {
      if (it && typeof it === "object") return { ok: it.ok === true, text: String(it.text || it.label || "") };
      return { ok: false, text: String(it || "") };
    }).filter(function (it) { return it.text; });
  }

  function runScan(url, name, mime) {
    var r = null;
    try { r = App.scanFile(url, name, mime || ""); } catch (e) {}
    r = r || {};
    var risk = RISK_ORDER.hasOwnProperty(r.risk) ? r.risk : "safe";
    return { risk: risk, score: Number(r.score) || RISK_SCORE[risk], items: normItems(r.items || r.report) };
  }

  function nameFromUrl(url) {
    var n = "";
    try { n = App.fileNameFromUrl(url) || ""; } catch (e) {}
    if (!n) n = "download";
    try { n = App.sanitizeFileName(n) || n; } catch (e) {}
    return n;
  }

  function prepUrl(raw) {
    var t = String(raw || "").trim();
    if (!t) return { error: "اكتب رابط الملف" };
    if (/\s/.test(t)) return { error: "الرابط لا يجب أن يحتوي على مسافات" };
    if (!/^[a-z][a-z0-9+.-]*:/i.test(t)) t = "https://" + t;
    var u;
    try { u = new URL(t); } catch (e) { return { error: "الرابط غير صالح، مثال: https://example.com/file.pdf" }; }
    if (!/^https?:$/.test(u.protocol)) return { error: "يدعم التنزيل روابط http وhttps فقط" };
    if (!u.hostname || (u.hostname.indexOf(".") < 0 && u.hostname !== "localhost")) return { error: "اسم النطاق في الرابط غير صحيح" };
    return { url: u.href };
  }

  function needConfirm(risk) {
    return setting("blockExecutables", true) ? risk !== "safe" : risk === "danger";
  }

  function confirmRisk(name, scan) {
    haptic(60);
    var warns = scan.items.filter(function (i) { return !i.ok; }).slice(0, 4).map(function (i) { return "• " + i.text; }).join("\n");
    var msg = "تحذير (" + riskLabel(scan.risk) + "): الملف «" + name + "» قد يكون ضاراً.\n" + (warns ? warns + "\n" : "") +
      "هذا الفحص وقائي ولا يغني عن برنامج مكافحة فيروسات. هل تريد التنزيل رغم ذلك؟";
    return Kit.confirm(msg, { danger: true, ok: "تنزيل رغم ذلك" });
  }

  function rejectEntry(id, url, name, scan, report, why) {
    upsert({ id: id, url: url, name: name, size: 0, received: 0, status: "blocked", speed: 0, risk: scan.risk === "safe" ? "danger" : scan.risk,
      score: Math.max(scan.score, 70), report: report.concat([{ ok: false, text: why }]), ts: Date.now() });
    try { App.bumpStat("files", 1); } catch (e) {}
    haptic(50);
    notify("رُفض تنزيل ملف", name + " — " + why);
    toast("رُفض التنزيل: " + why);
  }

  function sendExternal(id, url, why) {
    delete App.dlLive[id];
    var d = findDl(id);
    upsert({ id: id, status: "external", speed: 0,
      report: ((d && d.report) || []).concat([{ ok: false, text: why }]) });
    try { App.openExternal(url); } catch (e) { try { Kit.native.openUrl(url); } catch (e2) {} }
    notify("تنزيل خارجي", "حُوّل الملف إلى مدير التنزيل في النظام");
    toast("حُوّل التنزيل إلى مدير التنزيل في النظام");
  }

  function failEntry(id, why) {
    delete App.dlLive[id];
    var d = findDl(id);
    upsert({ id: id, status: "failed", speed: 0, report: ((d && d.report) || []).concat([{ ok: false, text: why }]) });
  }

  function updateLive(id) {
    var live = App.dlLive[id];
    if (!live) return;
    var sel = '[data-dl-live="' + (window.CSS && CSS.escape ? CSS.escape(id) : id) + '"]';
    var nodes = document.querySelectorAll(sel);
    for (var i = 0; i < nodes.length; i++) {
      var fill = nodes[i].querySelector(".barq-dl-fill");
      var meta = nodes[i].querySelector(".barq-dl-meta");
      var pct = live.size ? Math.min(100, Math.round(live.received / live.size * 100)) : 0;
      if (fill) fill.style.width = (live.size ? pct : 35) + "%";
      if (meta) meta.textContent = fmtBytes(live.received) + (live.size ? " من " + fmtBytes(live.size) + " · " + pct + "%" : "") +
        (live.speed ? " · " + fmtBytes(live.speed) + "/ث" : "");
    }
  }

  function isTextual(mime) { return /^text\/|json|xml|csv/i.test(String(mime || "")); }

  function saveBlob(name, blob, mime) {
    if (isTextual(mime) && blob.text) {
      return blob.text().then(function (t) { return Kit.native.saveFile(name, t, mime || "text/plain"); });
    }
    return new Promise(function (resolve) {
      var u = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = u; a.download = name; a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { try { a.remove(); } catch (e) {} }, 0);
      setTimeout(function () { try { URL.revokeObjectURL(u); } catch (e) {} }, 60000);
      resolve(true);
    });
  }

  function keepBlob(id, blob, name, mime) {
    if (!blob || blob.size > MAX_KEEP_BLOB) return;
    App.dlBlobs[id] = { blob: blob, name: name, mime: mime };
    var keys = Object.keys(App.dlBlobs);
    while (keys.length > 5) { delete App.dlBlobs[keys.shift()]; }
  }

  async function fetchFile(id, url, name, scan, report, confirmed) {
    var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    var live = { received: 0, size: 0, speed: 0, ctrl: ctrl };
    App.dlLive[id] = live;
    upsert({ id: id, url: url, name: name, size: 0, received: 0, status: "running", speed: 0, risk: scan.risk, score: scan.score, report: report, ts: Date.now() });
    var res;
    try {
      res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined, credentials: "omit", referrerPolicy: "no-referrer" });
    } catch (e) {
      if (live.cancelled) { failEntry(id, "أوقفه المستخدم"); return; }
      sendExternal(id, url, "لم يسمح الخادم بالجلب المباشر داخل التطبيق، فحُوّل الرابط إلى النظام");
      return;
    }
    if (!res.ok) { failEntry(id, "ردّ الخادم برمز خطأ " + res.status); toast("فشل التنزيل (" + res.status + ")"); return; }

    var mime = (res.headers.get("content-type") || "").split(";")[0].trim();
    var size = Number(res.headers.get("content-length")) || 0;
    var real = "";
    try { real = App.fileNameFromDisposition(res.headers.get("content-disposition")) || ""; } catch (e) {}
    if (real) { try { real = App.sanitizeFileName(real) || real; } catch (e) {} }
    if (real && real !== name) {
      name = real;
      if (setting("scanDownloads", true)) {
        var s2 = runScan(url, name, mime);
        report = report.concat([{ ok: true, text: "أُعيد الفحص بالاسم الفعلي للملف: " + name }]).concat(s2.items);
        if (RISK_ORDER[s2.risk] > RISK_ORDER[scan.risk]) {
          scan = s2;
          if (!confirmed && needConfirm(s2.risk)) {
            var ok = await confirmRisk(name, s2);
            if (!ok) {
              try { ctrl && ctrl.abort(); } catch (e) {}
              delete App.dlLive[id];
              rejectEntry(id, url, name, s2, report, "رفضتَ التنزيل بعد الفحص");
              return;
            }
            report.push({ ok: false, text: "وافقتَ على التنزيل رغم التحذير" });
          }
        }
      }
    }
    live.size = size;
    upsert({ id: id, name: name, size: size, risk: scan.risk, score: scan.score, report: report });

    if (size > MAX_INMEM) {
      try { ctrl && ctrl.abort(); } catch (e) {}
      sendExternal(id, url, "حجم الملف كبير (" + fmtBytes(size) + ")، فحُوّل إلى مدير التنزيل في النظام");
      return;
    }

    var blob;
    try {
      if (!res.body || !res.body.getReader) {
        blob = await res.blob();
        live.received = blob.size;
      } else {
        var reader = res.body.getReader(), chunks = [];
        var lastT = Date.now(), lastB = 0, lastUi = 0;
        while (true) {
          var r = await reader.read();
          if (r.done) break;
          chunks.push(r.value);
          live.received += r.value.length;
          if (live.received > MAX_INMEM) { try { ctrl && ctrl.abort(); } catch (e) {} throw new Error("big"); }
          var now = Date.now();
          if (now - lastT >= 500) { live.speed = (live.received - lastB) / ((now - lastT) / 1000); lastT = now; lastB = live.received; }
          if (now - lastUi >= 250) { lastUi = now; updateLive(id); }
        }
        blob = new Blob(chunks, { type: mime || "application/octet-stream" });
      }
    } catch (e) {
      if (live.cancelled) { failEntry(id, "أوقفه المستخدم"); toast("أُوقف التنزيل"); return; }
      if (e && e.message === "big") { sendExternal(id, url, "الملف أكبر من الحد المسموح داخل التطبيق"); return; }
      failEntry(id, "انقطع الاتصال أثناء التنزيل");
      toast("انقطع التنزيل");
      notify("فشل التنزيل", name);
      return;
    }

    var avg = live.speed;
    delete App.dlLive[id];
    keepBlob(id, blob, name, mime);
    var saved = true;
    try { await saveBlob(name, blob, mime); } catch (e) { saved = false; }
    upsert({ id: id, status: "done", size: blob.size, received: blob.size, speed: avg,
      report: report.concat([{ ok: saved, text: saved ? "حُفظ الملف في الجهاز (" + fmtBytes(blob.size) + ")" : "اكتمل الجلب لكن تعذّر الحفظ، جرّب «حفظ مرة أخرى»" }]) });
    haptic(30);
    notify("اكتمل التنزيل", name + " · " + fmtBytes(blob.size));
    toast("اكتمل تنزيل «" + name + "»");
  }

  App.startDownload = async function (input, opts) {
    opts = opts || {};
    var p = prepUrl(input);
    if (p.error) { toast(p.error); return false; }
    var url = p.url;
    var report = [];
    if (setting("stripParams", true)) {
      try {
        var st = App.stripTracking(url);
        var n = st ? (Array.isArray(st.removed) ? st.removed.length : Number(st.removed) || 0) : 0;
        if (st && st.url) url = st.url;
        if (n) { report.push({ ok: true, text: "أُزيل " + n + " من معاملات التتبّع من الرابط" }); try { App.bumpStat("params", n); } catch (e) {} }
      } catch (e) {}
    }
    if (setting("forceHttps", true) && /^http:\/\//i.test(url)) {
      url = "https://" + url.slice(7);
      report.push({ ok: true, text: "رُقّي الاتصال إلى HTTPS" });
    }
    var id = opts.retryId || uid();
    var name = nameFromUrl(url);
    var scan = { risk: "safe", score: RISK_SCORE.safe, items: [] };

    var b = null;
    try { b = App.isBlocked(url); } catch (e) {}
    if (b && b.blocked && setting("adBlock", true)) {
      rejectEntry(id, url, name, { risk: "danger", score: 90, items: [] }, report, b.reason || "المصدر موجود في قائمة الحظر");
      return false;
    }
    var confirmed = false;
    if (setting("scanDownloads", true)) {
      scan = runScan(url, name, "");
      report = report.concat(scan.items);
      if (needConfirm(scan.risk)) {
        var ok = await confirmRisk(name, scan);
        if (!ok) { rejectEntry(id, url, name, scan, report, "رفضتَ التنزيل بعد الفحص"); return false; }
        confirmed = true;
        report.push({ ok: false, text: "وافقتَ على التنزيل رغم التحذير" });
      }
    } else {
      report.push({ ok: false, text: "فحص الملفات معطّل من الإعدادات" });
    }
    haptic(15);
    toast("بدأ تنزيل «" + name + "»");
    fetchFile(id, url, name, scan, report, confirmed);
    return true;
  };

  App.retryDownload = function (id) {
    var d = findDl(id);
    if (!d || !d.url) { toast("لم يُعثر على التنزيل"); return; }
    if (App.dlLive[id]) { toast("التنزيل جارٍ بالفعل"); return; }
    App.startDownload(d.url, { retryId: id });
  };

  function cancelDl(id) {
    var live = App.dlLive[id];
    if (!live) return;
    live.cancelled = true;
    try { live.ctrl && live.ctrl.abort(); } catch (e) {}
    haptic(20);
  }

  async function removeDl(d) {
    var ok = await Kit.confirm("حذف «" + (d.name || "الملف") + "» من القائمة؟ لن يُحذف الملف المحفوظ في جهازك.", { danger: true, ok: "حذف" });
    if (!ok) return;
    cancelDl(d.id);
    delete App.dlBlobs[d.id];
    App.downloadsStore.update(function (arr) { return (Array.isArray(arr) ? arr : []).filter(function (x) { return x && x.id !== d.id; }); });
    haptic(25);
    toast("حُذف من القائمة");
    if (Kit.back && arguments[1]) Kit.back();
  }

  function saveAgain(id) {
    var b = App.dlBlobs[id];
    if (!b) { toast("الملف غير متاح في الذاكرة، أعد تنزيله"); return; }
    saveBlob(b.name, b.blob, b.mime).then(function () { toast("حُفظ الملف"); }, function () { toast("تعذّر حفظ الملف"); });
  }

  function statusOf(d) {
    if (d.status === "running" && !App.dlLive[d.id]) return "failed";
    return d.status || "failed";
  }
  var STATUS = {
    done: { label: "مكتمل", icon: "check", color: "var(--ok)" },
    running: { label: "جارٍ", icon: "download", color: "var(--primary)" },
    failed: { label: "موقوف", icon: "pause", color: "var(--muted)" },
    blocked: { label: "مرفوض", icon: "shield", color: "var(--danger)" },
    external: { label: "خارجي", icon: "globe", color: "var(--accent)" }
  };

  function fixStale() {
    if (staleChecked) return;
    staleChecked = true;
    var stale = list().some(function (d) { return d.status === "running" && !App.dlLive[d.id]; });
    if (!stale) return;
    setTimeout(function () {
      App.downloadsStore.update(function (arr) {
        return (Array.isArray(arr) ? arr : []).map(function (d) {
          return d && d.status === "running" && !App.dlLive[d.id]
            ? Object.assign({}, d, { status: "failed", speed: 0, report: (d.report || []).concat([{ ok: false, text: "انقطع التنزيل عند إغلاق التطبيق" }]) }) : d;
        });
      });
    }, 0);
  }

  function dlCard(d) {
    var st = statusOf(d), meta = STATUS[st] || STATUS.failed, live = App.dlLive[d.id];
    var sub = [hostOf(d.url), d.size ? fmtBytes(d.size) : "", Kit.util.fmtDate(d.ts || Date.now())].filter(Boolean).join(" · ");
    var acts = [Kit.ui.iconBtn("info", "تقرير الفحص", function () { Kit.go("scanreport", { id: d.id }); })];
    if (live) acts.push(Kit.ui.iconBtn("x", "إيقاف", function () { cancelDl(d.id); }));
    if (!live && st !== "done") acts.push(Kit.ui.iconBtn("refresh", "إعادة المحاولة", function () { App.retryDownload(d.id); }));
    if (st === "done" && App.dlBlobs[d.id]) acts.push(Kit.ui.iconBtn("download", "حفظ مرة أخرى", function () { saveAgain(d.id); }));
    acts.push(Kit.ui.iconBtn("copy", "نسخ الرابط", function () { try { Kit.native.copy(d.url); toast("نُسخ الرابط"); } catch (e) {} }));
    if (!live) acts.push(Kit.ui.iconBtn("trash", "حذف", function () { removeDl(d); }));

    return h("div", {
      class: "k-card barq-dl", "data-search": ((d.name || "") + " " + (d.url || "")).toLowerCase(),
      style: { display: "flex", flexDirection: "column", gap: "8px" }
    },
      h("div", { class: "k-row", style: { alignItems: "center", gap: "10px", cursor: "pointer", minWidth: "0" },
        onclick: function () { Kit.go("scanreport", { id: d.id }); } },
        h("span", { style: { color: riskColor(d.risk), display: "inline-flex", flexShrink: "0" } }, Kit.icon("file", 28)),
        h("div", { class: "k-col k-grow", style: { minWidth: "0", gap: "2px" } },
          h("div", { dir: "auto", style: { fontWeight: "600", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, d.name || "ملف"),
          h("div", { class: "k-small k-muted", style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, sub)),
        h("span", { class: "k-badge", style: { color: meta.color, display: "inline-flex", alignItems: "center", gap: "4px", flexShrink: "0" } },
          Kit.icon(meta.icon, 14), d.status === "running" && !live ? "متوقّف" : meta.label)),
      live ? h("div", { "data-dl-live": d.id, class: "k-col", style: { gap: "4px" } },
        h("div", { class: "barq-dl-track", style: { height: "6px", background: "var(--surface2)", borderRadius: "3px", overflow: "hidden" } },
          h("div", { class: "barq-dl-fill", style: { height: "100%", width: "5%", background: "var(--primary)", transition: "width .25s" } })),
        h("div", { class: "barq-dl-meta k-small k-muted" }, "جارٍ الاتصال…")) : null,
      h("div", { class: "k-row k-wrap", style: { gap: "2px", justifyContent: "flex-end" } }, acts)
    );
  }

  function applyFilter(root, q) {
    var query = String(q || "").trim().toLowerCase(), shown = 0;
    var cards = root.querySelectorAll(".barq-dl");
    for (var i = 0; i < cards.length; i++) {
      var m = !query || (cards[i].getAttribute("data-search") || "").indexOf(query) >= 0;
      cards[i].style.display = m ? "flex" : "none";
      if (m) shown++;
    }
    var note = root.querySelector(".barq-dl-nomatch");
    if (note) note.style.display = query && cards.length && !shown ? "block" : "none";
  }

  function newDownloadCard() {
    var f = Kit.ui.field({ label: "رابط الملف", type: "url", value: dlState.draft, placeholder: "https://example.com/file.pdf",
      onInput: function (v) { dlState.draft = typeof v === "string" ? v : (v && v.target ? v.target.value : ""); } });
    if (f.input) { f.input.setAttribute("dir", "ltr"); f.input.addEventListener("input", function () { dlState.draft = f.input.value; err.textContent = ""; }); }
    var err = h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } });
    function val() { return String(f.input ? f.input.value : dlState.draft).trim(); }
    function go(ev) {
      if (ev && ev.preventDefault) ev.preventDefault();
      var p = prepUrl(val());
      if (p.error) { err.textContent = p.error; return; }
      dlState.draft = "";
      if (f.input) f.input.value = "";
      App.startDownload(p.url);
    }
    function scanOnly() {
      var p = prepUrl(val());
      if (p.error) { err.textContent = p.error; return; }
      Kit.go("scanreport", { url: p.url });
    }
    return h("form", { class: "k-card k-col", onsubmit: go, style: { gap: "8px" } },
      h("div", { class: "k-h2" }, "تنزيل جديد"),
      f, err,
      setting("scanDownloads", true) ? null : h("div", { class: "k-small", style: { color: "var(--danger)" } }, "تنبيه: فحص الملفات معطّل من الإعدادات."),
      h("div", { class: "k-row", style: { gap: "8px" } },
        Kit.ui.btn("فحص وتنزيل", { kind: "primary", icon: "download", block: true, onClick: go }),
        Kit.ui.btn("فحص فقط", { kind: "tonal", icon: "shield", block: true, onClick: scanOnly })));
  }

  App.screens.downloads = function (el) {
    fixStale();
    var all = list();
    var root = h("div", { class: "k-col barq-downloads", style: { gap: "14px", paddingBlockEnd: "16px" } });
    root.appendChild(newDownloadCard());

    var done = all.filter(function (d) { return d.status === "done"; });
    var total = done.reduce(function (s, d) { return s + (Number(d.size) || 0); }, 0);
    root.appendChild(Kit.ui.grid([
      Kit.ui.stat({ icon: "check", value: Kit.util.fmtNum(done.length), label: "مكتملة" }),
      Kit.ui.stat({ icon: "shield", value: Kit.util.fmtNum(all.filter(function (d) { return d.status === "blocked"; }).length), label: "مرفوضة" }),
      Kit.ui.stat({ icon: "file", value: fmtBytes(total), label: "الحجم" })
    ], 3));

    if (!all.length) {
      root.appendChild(Kit.ui.empty({ icon: "download", title: "لا توجد تنزيلات",
        text: "الصق رابط ملف في الأعلى، وسنفحصه قبل تنزيله.",
        action: { label: "فتح تبويب جديد", onClick: function () { App.newTab(false); } } }));
      el.appendChild(root);
      return;
    }

    root.appendChild(Kit.ui.section("قائمة التنزيلات (" + all.length + ")", {
      label: "مسح المنتهية", onClick: async function () {
        var ok = await Kit.confirm("حذف كل العناصر غير الجارية من القائمة؟ لن تُحذف الملفات المحفوظة.", { danger: true, ok: "مسح" });
        if (!ok) return;
        App.downloadsStore.update(function (arr) { return (Array.isArray(arr) ? arr : []).filter(function (d) { return d && App.dlLive[d.id]; }); });
        haptic(30); toast("مُسحت القائمة");
      } }));

    var s = Kit.ui.search(function (v) {
      dlState.query = typeof v === "string" ? v : (v && v.target ? v.target.value : "");
      applyFilter(root, dlState.query);
    }, "ابحث بالاسم أو الرابط");
    if (s.input && dlState.query) s.input.value = dlState.query;
    root.appendChild(s);

    root.appendChild(Kit.ui.chips([
      { value: "all", label: "الكل" }, { value: "done", label: "مكتمل" }, { value: "running", label: "جارٍ" },
      { value: "failed", label: "موقوف" }, { value: "blocked", label: "مرفوض" }, { value: "external", label: "خارجي" }
    ], dlState.filter, function (v) { dlState.filter = v; Kit.refresh(); }));
    root.appendChild(Kit.ui.segmented([
      { value: "new", label: "الأحدث" }, { value: "name", label: "الاسم" }, { value: "size", label: "الحجم" }
    ], dlState.sort, function (v) { dlState.sort = v; Kit.refresh(); }));

    var shown = all.filter(function (d) { return dlState.filter === "all" || statusOf(d) === dlState.filter || (dlState.filter === "running" && App.dlLive[d.id]); });
    shown.sort(function (a, b) {
      if (dlState.sort === "name") return String(a.name || "").localeCompare(String(b.name || ""), "ar");
      if (dlState.sort === "size") return (Number(b.size) || 0) - (Number(a.size) || 0);
      return (b.ts || 0) - (a.ts || 0);
    });
    if (!shown.length) {
      root.appendChild(Kit.ui.empty({ icon: "filter", title: "لا توجد عناصر بهذه الحالة",
        text: "جرّب حالة أخرى.", action: { label: "عرض الكل", onClick: function () { dlState.filter = "all"; Kit.refresh(); } } }));
    } else {
      root.appendChild(h("div", { class: "k-col", style: { gap: "10px" } }, shown.map(dlCard)));
      root.appendChild(h("div", { class: "k-small k-muted barq-dl-nomatch", style: { display: "none", textAlign: "center" } }, "لا توجد تنزيلات تطابق بحثك."));
    }
    root.appendChild(h("div", { class: "k-small k-muted" }, App.SCAN_NOTE || "الفحص وقائي بقواعد محلية ولا يغني عن برنامج مكافحة فيروسات."));
    el.appendChild(root);
    if (dlState.query) applyFilter(root, dlState.query);
    Object.keys(App.dlLive).forEach(updateLive);
  };

  // ---------- Scan report ----------
  var ACTION_TEXT = {
    done: "سُمح بالتنزيل وحُفظ الملف", running: "التنزيل جارٍ الآن", failed: "توقّف التنزيل قبل اكتماله",
    blocked: "رُفض التنزيل ولم يُجلب الملف", external: "حُوّل التنزيل إلى مدير التنزيل في النظام"
  };

  function itemsBlock(title, items, ok) {
    if (!items.length) return null;
    return h("div", { class: "k-col", style: { gap: "6px" } }, Kit.ui.section(title + " (" + items.length + ")"),
      h("div", { class: "k-card" }, items.map(function (it) {
        return h("div", { class: "k-row", style: { alignItems: "flex-start", gap: "8px", paddingBlock: "6px" } },
          h("span", { style: { color: ok ? "var(--ok)" : "var(--danger)", display: "inline-flex", flexShrink: "0" } }, Kit.icon(ok ? "check" : "info", 18)),
          h("span", { class: "k-grow" }, it.text));
      })));
  }

  App.screens.scanreport = function (el, params) {
    params = params || {};
    var d = params.id ? findDl(params.id) : null;
    var url, name, risk, items, score, action;
    if (d) {
      url = d.url; name = d.name || "ملف"; risk = d.risk || "safe"; items = normItems(d.report);
      score = Number(d.score) || RISK_SCORE[risk] || 0; action = ACTION_TEXT[statusOf(d)] || "";
    } else if (params.url) {
      url = params.url;
      if (params.kind === "link") {
        var r = null;
        try { r = App.checkUrl(url); } catch (e) {}
        r = r || {};
        risk = RISK_ORDER.hasOwnProperty(r.risk) ? r.risk : "safe"; items = normItems(r.items);
        score = Number(r.score) || RISK_SCORE[risk]; name = hostOf(url) || url;
      } else {
        name = nameFromUrl(url);
        var sc = runScan(url, name, "");
        risk = sc.risk; items = sc.items; score = sc.score;
      }
      action = "فحص فقط، لم يُتّخذ أي إجراء";
    } else {
      el.appendChild(Kit.ui.empty({ icon: "file", title: "لا يوجد تقرير",
        text: "ربما حُذف هذا العنصر من قائمة التنزيلات.", action: { label: "التنزيلات", onClick: function () { Kit.go("downloads"); } } }));
      return;
    }
    score = Kit.util.clamp(score, 0, 100);
    var passed = items.filter(function (i) { return i.ok; });
    var warns = items.filter(function (i) { return !i.ok; });

    var root = h("div", { class: "k-col", style: { gap: "14px", paddingBlockEnd: "16px" } });
    root.appendChild(h("div", { class: "k-card k-row", style: { alignItems: "center", gap: "14px" } },
      Kit.ui.ring(score, { label: "خطورة" }),
      h("div", { class: "k-col k-grow", style: { minWidth: "0", gap: "4px" } },
        h("div", { class: "k-h2", style: { color: riskColor(risk) } }, riskLabel(risk)),
        h("div", { dir: "auto", style: { fontWeight: "600", wordBreak: "break-all" } }, name),
        h("div", { class: "k-small k-muted", dir: "ltr", style: { wordBreak: "break-all" } }, url || ""))));
    root.appendChild(Kit.ui.list([Kit.ui.item({ title: "الإجراء المتّخذ", sub: action, icon: "info" })].concat(
      d ? [Kit.ui.item({ title: "التفاصيل", sub: [fmtBytes(d.size), d.speed ? "متوسط " + fmtBytes(d.speed) + "/ث" : "", Kit.util.fmtDate(d.ts || Date.now()) + " " + Kit.util.fmtTime(d.ts || Date.now())].filter(Boolean).join(" · "), icon: "file" })] : [])));
    var w = itemsBlock("التحذيرات", warns, false); if (w) root.appendChild(w);
    var p = itemsBlock("البنود التي اجتيزت", passed, true); if (p) root.appendChild(p);
    if (!items.length) root.appendChild(h("div", { class: "k-muted" }, "لم تُرصد أي ملاحظات."));
    root.appendChild(h("div", { class: "k-small k-muted" }, App.SCAN_NOTE || "هذا الفحص وقائي ولا يغني عن برنامج مكافحة فيروسات."));

    var btns = h("div", { class: "k-col", style: { gap: "8px" } });
    if (d && !App.dlLive[d.id] && d.status !== "done") btns.appendChild(Kit.ui.btn("إعادة المحاولة", { kind: "primary", icon: "refresh", block: true, onClick: function () { App.retryDownload(d.id); Kit.go("downloads"); } }));
    if (!d && params.kind !== "link") btns.appendChild(Kit.ui.btn("تنزيل الملف", { kind: "primary", icon: "download", block: true, onClick: function () { App.startDownload(url); Kit.go("downloads"); } }));
    if (d && d.status === "done" && App.dlBlobs[d.id]) btns.appendChild(Kit.ui.btn("حفظ مرة أخرى", { kind: "tonal", icon: "download", block: true, onClick: function () { saveAgain(d.id); } }));
    btns.appendChild(Kit.ui.btn("نسخ الرابط", { kind: "tonal", icon: "copy", block: true, onClick: function () { try { Kit.native.copy(url); toast("نُسخ الرابط"); } catch (e) {} } }));
    btns.appendChild(Kit.ui.btn("فتح في المتصفح الخارجي", { kind: "ghost", icon: "globe", block: true, onClick: async function () {
      if (risk !== "safe" && !(await Kit.confirm("الرابط يحمل تحذيرات أمنية. فتحه خارجياً رغم ذلك؟", { danger: true, ok: "فتح" }))) return;
      try { App.openExternal(url); } catch (e) { try { Kit.native.openUrl(url); } catch (e2) {} }
    } }));
    if (d && !App.dlLive[d.id]) btns.appendChild(Kit.ui.btn("حذف من القائمة", { kind: "danger", icon: "trash", block: true, onClick: function () { removeDl(d, true); } }));
    root.appendChild(btns);
    el.appendChild(root);
  };
})();