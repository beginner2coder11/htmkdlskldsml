(function () {
  "use strict";

  var MAX_STACK = 50;

  function toast(msg) { try { Kit.toast(msg); } catch (e) {} }
  function refresh() { try { Kit.refresh(); } catch (e) {} }
  function go(id, params) { try { Kit.go(id, params || {}); } catch (e) {} }

  function cloneTab(t) {
    var c = {};
    for (var k in t) if (Object.prototype.hasOwnProperty.call(t, k)) c[k] = t[k];
    c.back = Array.isArray(t.back) ? t.back.slice() : [];
    c.fwd = Array.isArray(t.fwd) ? t.fwd.slice() : [];
    return c;
  }

  function normalTabs() {
    var l = App.tabsStore.get();
    return Array.isArray(l) ? l.filter(function (t) { return t && t.id; }) : [];
  }

  App.allTabs = function (priv) {
    return priv ? App.privateTabs.filter(function (t) { return t && t.id; }) : normalTabs();
  };

  App.findTab = function (id, priv) {
    if (!id) return null;
    var list = App.allTabs(!!priv);
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  };

  App.currentTab = function () {
    var s = App.sessionStore.get() || {};
    if (!s.currentTabId) return null;
    return App.findTab(s.currentTabId, !!s.currentPrivate);
  };

  function setCurrent(id, priv) {
    App.sessionStore.set({ currentTabId: id || null, currentPrivate: !!(id && priv) });
  }

  function saveTab(tab) {
    if (tab.private) {
      var idx = -1;
      for (var i = 0; i < App.privateTabs.length; i++) if (App.privateTabs[i] && App.privateTabs[i].id === tab.id) idx = i;
      if (idx >= 0) App.privateTabs[idx] = tab; else App.privateTabs.push(tab);
      refresh();
      return;
    }
    App.tabsStore.update(function (list) {
      var arr = Array.isArray(list) ? list : [];
      var found = false;
      arr = arr.map(function (t) {
        if (t && t.id === tab.id) { found = true; return tab; }
        return t;
      });
      if (!found) arr.push(tab);
      return arr;
    });
  }

  App.titleFor = function (url) {
    if (!url) return "تبويب جديد";
    if (App.isSearchUrl(url)) {
      try {
        var q = new URL(url).searchParams.get("q");
        if (q) return "بحث: " + q;
      } catch (e) {}
    }
    return App.shortHost(url) || url;
  };

  App.engineHome = function () {
    if (App.engineKey() === "google_inapp") return "https://www.google.com/webhp?igu=1";
    var eng = App.SEARCH_ENGINES[App.engineKey()];
    try { return new URL(eng.url).origin + "/"; } catch (e) { return "https://duckduckgo.com/"; }
  };

  function makeTab(priv) {
    return { id: App.uid(), url: "", title: "تبويب جديد", private: !!priv, created: Date.now(), back: [], fwd: [], blocked: null };
  }

  // Prepares a URL: forces HTTPS when enabled, strips tracking params and checks the blocklists.
  function prepare(url) {
    var out = url;
    if (App.setting("forceHttps", true)) out = App.upgradeHttps(out);
    var cleaned = { removed: 0 };
    try { cleaned = App.cleanUrl(out) || cleaned; } catch (e) {}
    if (cleaned.removed > 0 && cleaned.url) {
      out = cleaned.url;
      App.bumpStat("params", cleaned.removed);
    }
    var blk = { blocked: false };
    try { blk = App.isBlocked(out) || blk; } catch (e) {}
    return { url: out, removed: cleaned.removed || 0, block: blk };
  }

  function applyUrl(tab, prep, push) {
    if (push && tab.url && tab.url !== prep.url) {
      tab.back.push(tab.url);
      if (tab.back.length > MAX_STACK) tab.back.splice(0, tab.back.length - MAX_STACK);
      tab.fwd = [];
    }
    tab.url = prep.url;
    tab.title = App.titleFor(prep.url);
    if (prep.block.blocked) {
      tab.blocked = { url: prep.url, reason: prep.block.reason || "", kind: prep.block.kind, domain: prep.block.domain || "" };
      App.bumpStat(App.statKeyForKind(prep.block.kind), 1);
      App.haptic(40);
    } else {
      tab.blocked = null;
    }
  }

  function afterNavigate(tab) {
    if (!tab.private && !tab.blocked) App.addHistory(tab.url, tab.title);
  }

  // Opens text or a URL. opts: {private, newTab, tabId, go(default true)}.
  // Returns the tab that now shows the page, or null when the input is empty.
  App.openUrl = function (input, opts) {
    var o = opts || {};
    var url = App.normalizeInput(input);
    if (!url) { toast("اكتب رابطاً أو كلمة للبحث"); return null; }

    var current = App.currentTab();
    var priv = typeof o.private === "boolean" ? o.private : !!(current && current.private);
    var base = null;
    if (o.tabId) base = App.findTab(o.tabId, priv);
    else if (!o.newTab && current && !!current.private === priv) base = current;
    var tab = base ? cloneTab(base) : makeTab(priv);

    var prep = prepare(url);
    applyUrl(tab, prep, true);
    saveTab(tab);
    setCurrent(tab.id, tab.private);
    afterNavigate(tab);
    if (prep.removed > 0) toast("أُزيل " + prep.removed + " من معاملات التتبّع");
    if (o.go === false) refresh(); else go("browser");
    return tab;
  };

  // Opens a blank tab ready for typing (search engine pages usually refuse to be framed).
  App.newTab = function (priv, url) {
    if (url) return App.openUrl(url, { private: !!priv, newTab: true });
    App.haptic(15);
    var tab = makeTab(priv);
    saveTab(tab);
    setCurrent(tab.id, tab.private);
    go("browser");
    return tab;
  };

  // Switches to an existing tab; private tabs ask for the PIN when locked.
  App.switchTab = async function (id, priv) {
    if (priv && !(await App.unlockPrivate())) return false;
    var tab = App.findTab(id, !!priv);
    if (!tab) { toast("لم يعد هذا التبويب موجوداً"); return false; }
    setCurrent(tab.id, !!priv);
    go("browser");
    return true;
  };

  App.closeTab = function (id) {
    var priv = !!App.findTab(id, true);
    if (!priv && !App.findTab(id, false)) return;
    var s = App.sessionStore.get() || {};
    var wasCurrent = s.currentTabId === id && !!s.currentPrivate === priv;

    if (priv) {
      App.privateTabs = App.privateTabs.filter(function (t) { return t && t.id !== id; });
      if (!App.privateTabs.length) App.privateUnlocked = false;
    } else {
      App.tabsStore.update(function (list) {
        return (Array.isArray(list) ? list : []).filter(function (t) { return t && t.id !== id; });
      });
    }
    App.haptic(15);
    if (wasCurrent) {
      var same = App.allTabs(priv);
      var other = App.allTabs(!priv);
      if (same.length) setCurrent(same[same.length - 1].id, priv);
      else if (!priv && other.length) setCurrent(other[other.length - 1].id, true);
      else if (priv && other.length) setCurrent(other[other.length - 1].id, false);
      else setCurrent(null, false);
    } else {
      refresh();
    }
  };

  // Closes every tab of one kind without asking (used by wipe and clear-on-exit).
  App.closeAllNow = function (priv) {
    var s = App.sessionStore.get() || {};
    if (priv) {
      App.privateTabs = [];
      App.privateUnlocked = false;
      if (s.currentPrivate) {
        var n = normalTabs();
        setCurrent(n.length ? n[n.length - 1].id : null, false);
      } else refresh();
    } else {
      App.tabsStore.set([]);
      if (!s.currentPrivate) {
        var p = App.allTabs(true);
        setCurrent(p.length ? p[p.length - 1].id : null, !!p.length);
      }
    }
  };

  // Asks for confirmation, then closes all tabs of one kind. Resolves to true when closed.
  App.closeAll = async function (priv) {
    var count = App.allTabs(!!priv).length;
    if (!count) { toast("لا توجد تبويبات لإغلاقها"); return false; }
    var msg = priv
      ? "إغلاق كل التبويبات الخاصة (" + count + ")؟ ستُمحى نهائياً."
      : "إغلاق كل التبويبات العادية (" + count + ")؟";
    var ok = await Kit.confirm(msg, { danger: true, ok: "إغلاق الكل" });
    if (!ok) return false;
    App.closeAllNow(!!priv);
    App.haptic(40);
    toast(priv ? "أُغلقت التبويبات الخاصة ومُحيت" : "أُغلقت كل التبويبات");
    return true;
  };

  function step(dir) {
    var cur = App.currentTab();
    if (!cur) return false;
    var tab = cloneTab(cur);
    var from = dir < 0 ? tab.back : tab.fwd;
    var to = dir < 0 ? tab.fwd : tab.back;
    if (!from.length) return false;
    if (tab.url) to.push(tab.url);
    var url = from.pop();
    applyUrl(tab, prepare(url), false);
    saveTab(tab);
    afterNavigate(tab);
    return true;
  }

  App.canGoBack = function () { var t = App.currentTab(); return !!(t && t.back && t.back.length); };
  App.canGoForward = function () { var t = App.currentTab(); return !!(t && t.fwd && t.fwd.length); };
  App.goBack = function () { return step(-1); };
  App.goForward = function () { return step(1); };

  App.reloadNonce = 0;
  App.reloadCurrent = function () {
    var t = App.currentTab();
    if (!t) return;
    if (t.blocked) {
      var prep = prepare(t.url);
      if (!prep.block.blocked) { var c = cloneTab(t); applyUrl(c, prep, false); saveTab(c); return; }
    }
    App.reloadNonce++;
    refresh();
  };

  // Unblocks the current blocked page until the app is closed.
  App.allowBlockedOnce = function (tab) {
    var t = tab || App.currentTab();
    if (!t || !t.blocked) return;
    App.allowOnce(t.blocked.url || t.url);
    var c = cloneTab(t);
    c.blocked = null;
    saveTab(c);
    afterNavigate(c);
    App.haptic(20);
    toast("سُمح بهذا الموقع مؤقتاً حتى إغلاق التطبيق");
  };

  App.translateUrl = function (url) {
    var lang = App.setting("translateLang", "ar") || "ar";
    return "https://translate.google.com/translate?sl=auto&tl=" + encodeURIComponent(lang) + "&u=" + encodeURIComponent(url);
  };

  App.translatePage = function (tab) {
    var t = tab || App.currentTab();
    if (!t || !t.url) { toast("افتح صفحة أولاً لترجمتها"); return null; }
    if (t.blocked) { toast("لا يمكن ترجمة صفحة محظورة"); return null; }
    if (/^https:\/\/translate\.google\.com\/translate/i.test(t.url) || /\.translate\.goog$/i.test(App.hostOf(t.url))) {
      toast("هذه الصفحة مترجمة بالفعل");
      return null;
    }
    toast("جارٍ فتح الصفحة عبر خدمة الترجمة");
    return App.openUrl(App.translateUrl(t.url), { tabId: t.id, private: !!t.private, go: false });
  };

  // ---------- Sharing helpers (always share the cleaned link) ----------
  function cleanForShare(url) {
    var r = { url: url, removed: 0 };
    try { r = App.cleanUrl(url) || r; } catch (e) {}
    if (r.removed > 0) App.bumpStat("params", r.removed);
    return r.url || url;
  }

  App.shareUrl = function (url, title) {
    if (!url) { toast("لا يوجد رابط للمشاركة"); return; }
    try { Kit.native.share(title || "", cleanForShare(url)); } catch (e) { toast("تعذّرت المشاركة"); }
  };

  App.copyUrl = function (url) {
    if (!url) { toast("لا يوجد رابط لنسخه"); return; }
    try { Kit.native.copy(cleanForShare(url)); App.haptic(15); toast("نُسخ الرابط"); } catch (e) { toast("تعذّر النسخ"); }
  };

  App.openExternal = function (url) {
    if (!url) return;
    try { Kit.native.openUrl(url); } catch (e) { toast("تعذّر فتح المتصفح الخارجي"); }
  };

  // ---------- PIN lock for private tabs ----------
  function hashPin(pin) {
    var s = "barq:" + String(pin), h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return "h:" + h.toString(16);
  }
  function pinMatches(input) {
    var stored = (App.securityStore.get() || {}).pin;
    if (!stored) return true;
    return stored === hashPin(input) || stored === String(input);
  }
  App.hasPin = function () { return !!(App.securityStore.get() || {}).pin; };

  var fails = 0, lockedUntil = 0;
  App.unlockPrivate = async function () {
    if (!App.hasPin() || App.privateUnlocked) { App.privateUnlocked = true; return true; }
    if (Date.now() < lockedUntil) {
      toast("محاولات كثيرة، انتظر " + Math.ceil((lockedUntil - Date.now()) / 1000) + " ثانية");
      return false;
    }
    var v = await Kit.prompt("أدخل رمز PIN للتبويبات الخاصة", { type: "password", placeholder: "الرمز السرّي" });
    if (v == null) return false;
    if (pinMatches(String(v).trim())) {
      fails = 0;
      App.privateUnlocked = true;
      App.haptic(20);
      refresh();
      return true;
    }
    fails++;
    App.haptic(80);
    if (fails >= 5) { lockedUntil = Date.now() + 30000; fails = 0; toast("رمز خاطئ، أُوقفت المحاولات 30 ثانية"); }
    else toast("رمز PIN غير صحيح");
    return false;
  };

  App.lockPrivate = function () { App.privateUnlocked = false; refresh(); };

  App.setPin = async function () {
    if (App.hasPin()) {
      var cur = await Kit.prompt("أدخل الرمز الحالي", { type: "password", placeholder: "الرمز الحالي" });
      if (cur == null) return;
      if (!pinMatches(String(cur).trim())) { App.haptic(80); toast("الرمز الحالي غير صحيح"); return; }
    }
    var p1 = await Kit.prompt(App.hasPin() ? "رمز جديد (اتركه فارغاً لإزالة القفل)" : "اختر رمز PIN من 4 إلى 8 أرقام", { type: "password", placeholder: "مثال: 1234" });
    if (p1 == null) return;
    p1 = String(p1).trim();
    if (!p1) {
      if (!App.hasPin()) return;
      if (await Kit.confirm("إزالة قفل التبويبات الخاصة؟", { danger: true, ok: "إزالة" })) {
        App.securityStore.set({ pin: null });
        toast("أُزيل قفل التبويبات الخاصة");
      }
      return;
    }
    if (!/^\d{4,8}$/.test(p1)) { toast("الرمز يجب أن يتكوّن من 4 إلى 8 أرقام"); return; }
    var p2 = await Kit.prompt("أعد إدخال الرمز للتأكيد", { type: "password", placeholder: "الرمز مرة أخرى" });
    if (p2 == null) return;
    if (String(p2).trim() !== p1) { App.haptic(80); toast("الرمزان غير متطابقين"); return; }
    App.securityStore.set({ pin: hashPin(p1) });
    App.privateUnlocked = false;
    App.haptic(30);
    toast("فُعّل قفل التبويبات الخاصة");
  };

  // ---------- Bookmark sheet (add, or edit when the URL/id already exists) ----------
  App.bookmarkFolders = function () {
    var seen = {}, out = [];
    (App.bookmarksStore.get() || []).forEach(function (b) {
      var f = b && String(b.folder || "").trim();
      if (f && !seen[f]) { seen[f] = true; out.push(f); }
    });
    return out;
  };

  App.addBookmarkSheet = function (tab) {
    var src = tab || App.currentTab() || {};
    var list = App.bookmarksStore.get() || [];
    var existing = null;
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      if (b && ((src.id && b.id === src.id) || (src.url && b.url === src.url))) { existing = b; break; }
    }
    var h = Kit.h;
    Kit.sheet(function (close) {
      var tf = Kit.ui.field({ label: "الاسم", value: existing ? existing.title : (src.title || ""), placeholder: "اسم الإشارة" });
      var uf = Kit.ui.field({ label: "الرابط", type: "url", value: existing ? existing.url : (src.url || ""), placeholder: "https://example.com" });
      if (uf.input) uf.input.setAttribute("dir", "ltr");
      var ff = Kit.ui.field({ label: "المجلد", value: existing ? existing.folder : "عام", placeholder: "مثال: أخبار" });
      var pinned = existing ? !!existing.pinned : false;
      var err = h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } });

      var folderChips = h("div", { class: "k-chips" }, App.bookmarkFolders().map(function (f) {
        return h("button", { type: "button", class: "k-chip", onclick: function () { if (ff.input) ff.input.value = f; } }, f);
      }));

      function save(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        var title = String(tf.input ? tf.input.value : "").trim();
        var url = String(uf.input ? uf.input.value : "").trim();
        var folder = String(ff.input ? ff.input.value : "").trim() || "عام";
        if (!title) { err.textContent = "اكتب اسماً للإشارة"; return; }
        if (!App.validUrl(url)) { err.textContent = "الرابط غير صالح، مثال صحيح: https://example.com"; return; }
        if (!/^https?:\/\//i.test(url)) url = "https://" + url;
        var dup = (App.bookmarksStore.get() || []).some(function (b) { return b && b.url === url && (!existing || b.id !== existing.id); });
        if (dup) { err.textContent = "هذا الرابط محفوظ في إشارة أخرى"; return; }
        App.bookmarksStore.update(function (arr) {
          arr = Array.isArray(arr) ? arr : [];
          if (existing) {
            return arr.map(function (b) {
              return b && b.id === existing.id ? { id: b.id, title: title, url: url, folder: folder, pinned: pinned, ts: b.ts || Date.now() } : b;
            });
          }
          arr.unshift({ id: App.uid(), title: title, url: url, folder: folder, pinned: pinned, ts: Date.now() });
          return arr;
        });
        App.haptic(25);
        toast(existing ? "حُفظت التعديلات" : "أُضيفت الإشارة إلى «" + folder + "»");
        close();
      }

      async function remove() {
        if (!existing) return;
        if (!(await Kit.confirm("حذف الإشارة «" + existing.title + "»؟", { danger: true, ok: "حذف" }))) return;
        App.bookmarksStore.update(function (arr) { return (Array.isArray(arr) ? arr : []).filter(function (b) { return b && b.id !== existing.id; }); });
        App.haptic(30);
        toast("حُذفت الإشارة");
        close();
      }

      return h("form", { class: "k-col k-gap", onsubmit: save },
        tf, uf, ff,
        folderChips.childNodes.length ? folderChips : null,
        h("div", { class: "k-row", style: { minHeight: "44px", alignItems: "center" } },
          Kit.icon("pin", 20),
          h("span", { class: "k-grow", style: { marginInlineStart: "8px" } }, "تثبيت في الأعلى"),
          Kit.ui.switch(pinned, function (v) { pinned = !!v; })),
        err,
        Kit.ui.btn(existing ? "حفظ التعديلات" : "حفظ الإشارة", { kind: "primary", icon: "check", block: true, onClick: save }),
        existing ? Kit.ui.btn("حذف الإشارة", { kind: "danger", icon: "trash", block: true, onClick: remove }) : null
      );
    }, { title: existing ? "تعديل الإشارة" : "إضافة إشارة مرجعية" });
  };
})();