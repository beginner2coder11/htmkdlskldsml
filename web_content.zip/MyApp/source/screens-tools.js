(function () {
  "use strict";

  var h = Kit.h;
  App.screens = App.screens || {};

  // ---------- Shared helpers ----------
  function toast(m) { try { Kit.toast(m); } catch (e) {} }
  function haptic(ms) { try { App.haptic(ms); } catch (e) { try { Kit.native.vibrate(ms); } catch (e2) {} } }
  function setting(k, d) { try { return App.setting(k, d); } catch (e) { try { return Kit.setting(k, d); } catch (e2) { return d; } } }
  function num(n) { try { return Kit.util.fmtNum(Number(n) || 0); } catch (e) { return String(Number(n) || 0); } }
  function uid() { try { return App.uid(); } catch (e) { return Kit.util.uid(); } }
  function inputVal(v) { return typeof v === "string" ? v : (v && v.target ? v.target.value : ""); }
  function arr(store) { try { var v = store.get(); return Array.isArray(v) ? v.filter(function (x) { return x && typeof x === "object"; }) : []; } catch (e) { return []; } }
  function hostOf(url) { try { return App.hostOf(url) || ""; } catch (e) { try { return new URL(url).hostname; } catch (e2) { return ""; } } }
  function fmtDate(ts) { try { return Kit.util.fmtDate(ts); } catch (e) { return new Date(ts).toLocaleDateString(); } }
  function fmtTime(ts) { try { return Kit.util.fmtTime(ts); } catch (e) { return new Date(ts).toLocaleTimeString(); } }
  function stop(node) { node.addEventListener("click", function (e) { e.stopPropagation(); }); return node; }
  function errBox() { return h("div", { class: "k-small", role: "alert", style: { color: "var(--danger)", minHeight: "1.2em" } }); }
  function openLink(url, opts) { try { App.openUrl(url, opts || {}); } catch (e) { toast("تعذّر فتح الرابط"); } }
  function cleanLink(url) {
    try { var r = App.stripTracking(url); if (r && r.url) { if (r.removed) { try { App.bumpStat("params", r.removed); } catch (e) {} } return r.url; } } catch (e) {}
    return url;
  }
  function copyLink(url) { try { Kit.native.copy(cleanLink(url)); haptic(15); toast("نُسخ الرابط"); } catch (e) { toast("تعذّر النسخ"); } }
  function shareLink(title, url) { try { Kit.native.share(title || "", cleanLink(url)); } catch (e) { toast("تعذّرت المشاركة"); } }

  function normUrl(text) {
    var t = String(text || "").trim();
    if (!t) return { error: "اكتب الرابط" };
    if (/\s/.test(t)) return { error: "الرابط لا يجب أن يحتوي على مسافات" };
    if (!/^[a-z][a-z0-9+.-]*:/i.test(t)) t = "https://" + t;
    var u;
    try { u = new URL(t); } catch (e) { return { error: "الرابط غير صالح، مثال: https://example.com" }; }
    if (!/^https?:$/.test(u.protocol)) return { error: "يُقبل فقط رابط يبدأ بـ http أو https" };
    if (!u.hostname || (u.hostname.indexOf(".") < 0 && u.hostname !== "localhost")) return { error: "اسم النطاق في الرابط غير صحيح" };
    return { url: u.href };
  }

  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function dayKey(ts) { var d = new Date(ts); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function groupDays(list) {
    var today = dayKey(Date.now()), yest = dayKey(Date.now() - 86400000), groups = [], map = {};
    list.slice().sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); }).forEach(function (it) {
      var k = dayKey(it.ts || 0);
      if (!map[k]) { map[k] = { key: k, label: k === today ? "اليوم" : k === yest ? "أمس" : fmtDate(it.ts || 0), items: [] }; groups.push(map[k]); }
      map[k].items.push(it);
    });
    return groups;
  }
  function letterAvatar(title) { var c = String(title || "?").trim().charAt(0) || "?"; try { return Kit.ui.avatar(c.toUpperCase()); } catch (e) { return h("span", {}, c); } }

  // ---------- Tools hub ----------
  App.screens.tools = function (el) {
    var bm = arr(App.bookmarksStore), hist = arr(App.historyStore), tests = arr(App.speedtestsStore);
    var tr = []; try { var t = App.translationsStore.get(); tr = t && Array.isArray(t.recent) ? t.recent : []; } catch (e) {}
    var last = tests[0];
    function tile(icon, title, sub, screen) {
      return Kit.ui.card([
        h("div", { class: "k-col", style: { gap: "6px", minHeight: "92px" } },
          h("span", { style: { color: "var(--primary)", display: "inline-flex" } }, Kit.icon(icon, 28)),
          h("div", { style: { fontWeight: "600" } }, title),
          h("div", { class: "k-small k-muted" }, sub))
      ], { onClick: function () { haptic(8); Kit.go(screen); } });
    }
    var root = h("div", { class: "k-col barq-tools", style: { gap: "14px", paddingBlockEnd: "16px" } });
    root.appendChild(Kit.ui.grid([
      tile("globe", "المترجم", num(App.DICT_COUNT || 0) + " عبارة وكلمة دون اتصال", "translator"),
      tile("zap", "اختبار السرعة", last ? fmtSpeed(last.down) + " Mbps آخر قياس" : "قِس سرعة اتصالك", "speedtest"),
      tile("star", "الإشارات المرجعية", num(bm.length) + " إشارة", "bookmarks"),
      tile("clock", "السجل", num(hist.length) + " زيارة", "history")
    ], 2));
    root.appendChild(Kit.ui.section("النسخ الاحتياطي"));
    root.appendChild(Kit.ui.list([
      Kit.ui.item({ title: "تصدير الإشارات والاتصال السريع", sub: "ملف JSON يمكنك حفظه أو نقله", icon: "download", chevron: true, onClick: App.exportData }),
      Kit.ui.item({ title: "استيراد من ملف", sub: "دمج إشارات واتصال سريع من ملف JSON", icon: "upload", chevron: true, onClick: App.importData })
    ]));
    root.appendChild(Kit.ui.section("ملخّص"));
    root.appendChild(Kit.ui.grid([
      Kit.ui.stat({ icon: "star", value: num(bm.filter(function (b) { return b.pinned; }).length), label: "مثبّتة" }),
      Kit.ui.stat({ icon: "heart", value: num(tr.filter(function (x) { return x && x.fav; }).length), label: "ترجمات مفضّلة" }),
      Kit.ui.stat({ icon: "chart", value: num(tests.length), label: "اختبارات سرعة" })
    ], 3));
    el.appendChild(root);
  };

  // ---------- Translator ----------
  var tr = { src: "", from: "ar", to: "en", filter: "all", res: null };
  var LANG = { ar: "العربية", en: "English" };

  function trList() { try { var t = App.translationsStore.get(); return t && Array.isArray(t.recent) ? t.recent.filter(function (x) { return x && x.id; }) : []; } catch (e) { return []; } }
  function updateTr(fn) {
    App.translationsStore.update(function (t) {
      if (!t || typeof t !== "object") t = {};
      if (!Array.isArray(t.recent)) t.recent = [];
      fn(t); return t;
    });
  }
  function findSaved(res) {
    var s = String(tr.src).trim();
    return trList().filter(function (x) { return x.src === s && x.from === res.from && x.to === res.to; })[0] || null;
  }
  function saveTranslation(res, fav) {
    var s = String(tr.src).trim();
    if (!s || !res || !res.out) { toast("اكتب نصاً للترجمة أولاً"); return null; }
    var id = null;
    updateTr(function (t) {
      var old = t.recent.filter(function (x) { return x && x.src === s && x.from === res.from && x.to === res.to; })[0];
      t.recent = t.recent.filter(function (x) { return x && x !== old; });
      var e = { id: old ? old.id : uid(), from: res.from, to: res.to, src: s, out: res.out, fav: fav === undefined ? !!(old && old.fav) : fav, ts: Date.now() };
      id = e.id; t.recent.unshift(e);
      t.recent = t.recent.slice(0, 60);
    });
    return id;
  }

  App.screens.translator = function (el) {
    var root = h("div", { class: "k-col barq-translator", style: { gap: "12px", paddingBlockEnd: "16px" } });
    var dirRow = h("div", { class: "k-row barq-tr-dir", style: { alignItems: "center", justifyContent: "space-between", gap: "8px" } });
    var out = h("div", { class: "k-card barq-tr-out", style: { minHeight: "70px", whiteSpace: "pre-wrap", wordBreak: "break-word", fontSize: "1.1em" } });
    var meta = h("div", { class: "k-small k-muted" });
    var sugg = h("div", { class: "k-row k-wrap", style: { gap: "6px" } });
    var favBtn = h("span");

    function drawDir() {
      dirRow.textContent = "";
      dirRow.appendChild(h("span", { class: "k-chip", style: { minWidth: "96px", textAlign: "center" } }, LANG[tr.from]));
      dirRow.appendChild(Kit.ui.iconBtn("refresh", "تبديل الاتجاه", function () {
        var prevOut = tr.res && tr.res.out && String(tr.src).trim() ? tr.res.out : "";
        var f = tr.from; tr.from = tr.to; tr.to = f;
        if (prevOut) { tr.src = prevOut; if (field.input) field.input.value = prevOut; }
        haptic(10); drawDir(); update();
      }));
      dirRow.appendChild(h("span", { class: "k-chip", style: { minWidth: "96px", textAlign: "center" } }, LANG[tr.to]));
      out.setAttribute("dir", tr.to === "ar" ? "rtl" : "ltr");
    }

    function drawFav() {
      favBtn.textContent = "";
      var saved = tr.res && tr.res.out ? findSaved(tr.res) : null;
      var on = !!(saved && saved.fav);
      favBtn.appendChild(Kit.ui.btn(on ? "في المفضّلة" : "تفضيل", { kind: on ? "tonal" : "ghost", icon: "heart", small: true, onClick: function () {
        if (!tr.res || !tr.res.out) { toast("لا توجد ترجمة لحفظها"); return; }
        saveTranslation(tr.res, !on); haptic(15); toast(on ? "أُزيلت من المفضّلة" : "أُضيفت إلى المفضّلة");
      } }));
    }

    function update() {
      var s = String(tr.src || "");
      if (s.trim() && /[A-Za-z\u0620-\u064A]/.test(s)) {
        var det = "en"; try { det = App.detectLang(s); } catch (e) {}
        if (det !== tr.from) { tr.from = det; tr.to = det === "ar" ? "en" : "ar"; drawDir(); }
      }
      var res = null;
      try { res = s.trim() ? App.translate(s, tr.from, tr.to) : null; } catch (e) { res = null; }
      tr.res = res;
      out.textContent = "";
      meta.textContent = "";
      if (!res || !res.out) {
        out.appendChild(h("span", { class: "k-muted" }, s.trim() ? "تعذّرت الترجمة" : "ستظهر الترجمة هنا"));
      } else {
        out.appendChild(document.createTextNode(res.out));
        if (res.exact) meta.textContent = "ترجمة مطابقة من القاموس.";
        else {
          meta.textContent = "تُرجمت " + num(res.matched) + " من " + num(res.total) + " كلمة.";
          if (res.unknown && res.unknown.length) meta.textContent += " غير موجودة في القاموس: " + res.unknown.slice(0, 6).join("، ");
        }
      }
      sugg.textContent = "";
      if (s.trim() && s.length <= 30 && !(res && res.exact)) {
        var list = [];
        try { list = App.dictSuggest(s, tr.from, 6) || []; } catch (e) {}
        list.forEach(function (sg) {
          sugg.appendChild(h("button", { type: "button", class: "k-chip", style: { minHeight: "36px" }, onclick: function () {
            tr.src = sg.src; if (field.input) field.input.value = sg.src; update();
          } }, sg.src + " ← " + sg.out));
        });
      }
      drawFav();
    }

    var field = Kit.ui.field({ label: "النص", multiline: true, value: tr.src, placeholder: "اكتب كلمة أو عبارة، مثل: صباح الخير" });
    var deb = function (fn) { try { return Kit.util.debounce(fn, 150); } catch (e) { return fn; } }(update);
    if (field.input) {
      field.input.setAttribute("dir", "auto");
      field.input.addEventListener("input", function () { tr.src = field.input.value; deb(); });
    }

    drawDir();
    root.appendChild(dirRow);
    root.appendChild(field);
    root.appendChild(sugg);
    root.appendChild(out);
    root.appendChild(meta);
    root.appendChild(h("div", { class: "k-row k-wrap", style: { gap: "8px" } },
      Kit.ui.btn("حفظ في السجل", { kind: "primary", icon: "check", small: true, onClick: function () { if (saveTranslation(tr.res)) { haptic(15); toast("حُفظت الترجمة"); } } }),
      Kit.ui.btn("نسخ", { kind: "ghost", icon: "copy", small: true, onClick: function () {
        if (!tr.res || !tr.res.out) { toast("لا توجد ترجمة لنسخها"); return; }
        try { Kit.native.copy(tr.res.out); haptic(15); toast("نُسخت الترجمة"); } catch (e) { toast("تعذّر النسخ"); }
      } }),
      Kit.ui.btn("مشاركة", { kind: "ghost", icon: "share", small: true, onClick: function () {
        if (!tr.res || !tr.res.out) { toast("لا توجد ترجمة لمشاركتها"); return; }
        try { Kit.native.share(tr.src.trim() + "\n" + tr.res.out, ""); } catch (e) { toast("تعذّرت المشاركة"); }
      } }),
      favBtn,
      Kit.ui.iconBtn("x", "مسح النص", function () { tr.src = ""; if (field.input) { field.input.value = ""; field.input.focus(); } update(); })));
    root.appendChild(h("div", { class: "k-small k-muted" }, "يعمل المترجم دون اتصال بقاموس محلي للعبارات والكلمات الشائعة، لذا قد لا يترجم الجمل الطويلة كاملة."));
    update();

    var all = trList();
    root.appendChild(Kit.ui.section("الترجمات السابقة", all.length ? { label: "مسح غير المفضّلة", onClick: async function () {
      if (!(await Kit.confirm("حذف كل الترجمات غير المفضّلة؟", { danger: true, ok: "حذف" }))) return;
      updateTr(function (t) { t.recent = t.recent.filter(function (x) { return x && x.fav; }); }); haptic(20);
    } } : undefined));
    root.appendChild(Kit.ui.chips([{ value: "all", label: "الكل (" + all.length + ")" }, { value: "fav", label: "المفضّلة (" + all.filter(function (x) { return x.fav; }).length + ")" }],
      tr.filter, function (v) { tr.filter = v; Kit.refresh(); }));
    var shown = tr.filter === "fav" ? all.filter(function (x) { return x.fav; }) : all;
    if (!shown.length) {
      root.appendChild(Kit.ui.empty({ icon: tr.filter === "fav" ? "heart" : "globe", title: tr.filter === "fav" ? "لا توجد ترجمات مفضّلة" : "لا توجد ترجمات بعد", text: "اكتب عبارة واحفظها لتظهر هنا." }));
    } else {
      root.appendChild(Kit.ui.list(shown.map(function (x) {
        return Kit.ui.item({
          title: x.src, sub: x.out, icon: x.fav ? "heart" : "globe",
          onClick: function () { tr.src = x.src; tr.from = x.from === "en" ? "en" : "ar"; tr.to = tr.from === "ar" ? "en" : "ar"; Kit.refresh(); },
          trailing: stop(h("div", { class: "k-row", style: { gap: "2px" } },
            Kit.ui.iconBtn(x.fav ? "heart" : "star", x.fav ? "إزالة من المفضّلة" : "تفضيل", function () {
              updateTr(function (t) { t.recent.forEach(function (y) { if (y && y.id === x.id) y.fav = !y.fav; }); }); haptic(10);
            }),
            Kit.ui.iconBtn("trash", "حذف", async function () {
              if (!(await Kit.confirm("حذف هذه الترجمة؟", { danger: true, ok: "حذف" }))) return;
              updateTr(function (t) { t.recent = t.recent.filter(function (y) { return y && y.id !== x.id; }); }); haptic(20);
            })))
        });
      })));
    }
    el.appendChild(root);
  };

  // ---------- Speed test ----------
  var SPEED_BASE = "https://speed.cloudflare.com/__down?bytes=";
  var DL_BUDGET = 9000;
  var sp = { running: false, phase: "", pct: 0, ping: null, live: null, error: "" };
  var spUi = {};

  function fmtSpeed(n) { n = Number(n) || 0; return n >= 100 ? String(Math.round(n)) : n.toFixed(1); }
  function speedRating(m) { return m < 2 ? "بطيء" : m < 10 ? "مقبول" : m < 50 ? "جيد" : "ممتاز"; }

  async function timedFetch(url, ms, onChunk) {
    var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    App.speedAbort = ctrl;
    var timer = setTimeout(function () { try { ctrl && ctrl.abort(); } catch (e) {} }, ms);
    try {
      var res = await fetch(url, { cache: "no-store", signal: ctrl ? ctrl.signal : undefined });
      if (!res.ok) throw new Error("http " + res.status);
      if (!onChunk) { try { await res.arrayBuffer(); } catch (e) {} return; }
      if (res.body && res.body.getReader) {
        var reader = res.body.getReader();
        for (;;) { var r = await reader.read(); if (r.done) break; onChunk(r.value ? r.value.length : 0); }
      } else { var b = await res.arrayBuffer(); onChunk(b.byteLength); }
    } finally { clearTimeout(timer); }
  }

  App.runSpeedTest = async function (onProgress) {
    if (sp.running) throw new Error("busy");
    function report(p) { try { if (onProgress) onProgress(p); } catch (e) {} }
    if (typeof navigator !== "undefined" && navigator.onLine === false) throw new Error("offline");
    sp.running = true; sp.cancelled = false;
    try {
      var pings = [];
      for (var i = 0; i < 6; i++) {
        if (sp.cancelled) throw new Error("cancel");
        var t0 = performance.now();
        await timedFetch(SPEED_BASE + "0&r=" + Math.random().toString(36).slice(2), 5000);
        var dt = performance.now() - t0;
        if (i > 0) pings.push(dt);
        var sorted = pings.slice().sort(function (a, b) { return a - b; });
        report({ phase: "ping", pct: Math.round((i + 1) / 6 * 20), ping: sorted.length ? Math.round(sorted[Math.floor(sorted.length / 2)]) : null });
      }
      pings.sort(function (a, b) { return a - b; });
      var ping = Math.round(pings[Math.floor(pings.length / 2)] || 0);
      var sizes = [500000, 2000000, 5000000, 10000000, 25000000], total = 0, spent = 0;
      for (var s = 0; s < sizes.length; s++) {
        if (sp.cancelled) throw new Error("cancel");
        if (spent > DL_BUDGET * 0.6 && s > 0) break;
        var start = performance.now(), lastRep = 0;
        await timedFetch(SPEED_BASE + sizes[s] + "&r=" + Math.random().toString(36).slice(2), 20000, function (n) {
          total += n;
          var now = performance.now();
          if (now - lastRep > 150) {
            lastRep = now;
            var el = spent + (now - start);
            report({ phase: "down", ping: ping, pct: 20 + Math.round(80 * Math.min(1, el / DL_BUDGET)), live: total * 8 / (el / 1000) / 1e6 });
          }
        });
        spent += performance.now() - start;
      }
      if (!total || !spent) throw new Error("nodata");
      var down = Math.round(total * 8 / (spent / 1000) / 1e6 * 100) / 100;
      report({ phase: "done", pct: 100, ping: ping, live: down });
      return { ping: ping, down: down, bytes: total };
    } finally { sp.running = false; App.speedAbort = null; }
  };

  function paintSpeed() {
    if (!spUi.ring || !document.body.contains(spUi.ring)) return;
    spUi.ring.textContent = "";
    spUi.ring.appendChild(Kit.ui.ring(Kit.util.clamp(Math.round(sp.pct || 0), 0, 100), { label: sp.running ? (sp.phase === "ping" ? "Ping" : "تنزيل") : "التقدّم" }));
    spUi.phase.textContent = sp.error ? sp.error : sp.running ? (sp.phase === "ping" ? "جارٍ قياس زمن الاستجابة…" : "جارٍ قياس سرعة التنزيل…") : sp.live != null ? "اكتمل القياس: " + speedRating(sp.live) : "اضغط «ابدأ الاختبار» لقياس اتصالك.";
    spUi.phase.style.color = sp.error ? "var(--danger)" : "";
    spUi.ping.textContent = sp.ping != null ? num(sp.ping) : "—";
    spUi.down.textContent = sp.live != null ? fmtSpeed(sp.live) : "—";
  }

  async function startSpeed() {
    if (sp.running) { sp.cancelled = true; try { App.speedAbort && App.speedAbort.abort(); } catch (e) {} return; }
    sp.error = ""; sp.pct = 0; sp.ping = null; sp.live = null; sp.phase = "ping";
    haptic(20);
    var p = App.runSpeedTest(function (u) { sp.phase = u.phase; sp.pct = u.pct; if (u.ping != null) sp.ping = u.ping; if (u.live != null) sp.live = u.live; paintSpeed(); });
    sp.running = true; Kit.refresh();
    try {
      var r = await p;
      sp.live = r.down; sp.ping = r.ping; sp.pct = 100;
      App.speedtestsStore.update(function (l) { l = Array.isArray(l) ? l : []; l.unshift({ id: uid(), ts: Date.now(), ping: r.ping, down: r.down }); return l.slice(0, 30); });
      haptic(40); toast("السرعة " + fmtSpeed(r.down) + " Mbps");
    } catch (e) {
      var m = String(e && e.message || "");
      sp.error = sp.cancelled || m === "cancel" ? "أُلغي الاختبار." : m === "offline" ? "لا يوجد اتصال بالإنترنت." : "تعذّر إكمال الاختبار. تحقّق من اتصالك وحاول مجدداً.";
      sp.pct = 0;
      Kit.refresh();
    }
  }

  App.screens.speedtest = function (el) {
    var tests = arr(App.speedtestsStore);
    var root = h("div", { class: "k-col barq-speed", style: { gap: "14px", paddingBlockEnd: "16px" } });
    spUi.ring = h("div", { class: "barq-speed-ring", style: { display: "flex", justifyContent: "center" } });
    spUi.phase = h("div", { class: "k-small k-muted", style: { textAlign: "center" }, "aria-live": "polite" });
    spUi.ping = h("div", { class: "k-h1" }); spUi.down = h("div", { class: "k-h1" });
    root.appendChild(h("div", { class: "k-card k-col", style: { gap: "12px", alignItems: "stretch" } },
      spUi.ring, spUi.phase,
      h("div", { class: "k-row", style: { justifyContent: "space-around", textAlign: "center" } },
        h("div", { class: "k-col" }, spUi.ping, h("div", { class: "k-small k-muted" }, "Ping (ms)")),
        h("div", { class: "k-col" }, spUi.down, h("div", { class: "k-small k-muted" }, "التنزيل (Mbps)"))),
      Kit.ui.btn(sp.running ? "إيقاف الاختبار" : "ابدأ الاختبار", { kind: sp.running ? "danger" : "primary", icon: sp.running ? "x" : "play", block: true, onClick: startSpeed })));
    root.appendChild(h("div", { class: "k-small k-muted" }, "يقيس الاختبار زمن الاستجابة وسرعة التنزيل الفعلية بتحميل ملفات اختبار من خوادم Cloudflare العامة، ويستهلك نحو 10 إلى 40 ميغابايت."));

    var avg = tests.length ? tests.reduce(function (a, t) { return a + (Number(t.down) || 0); }, 0) / tests.length : 0;
    var best = tests.reduce(function (a, t) { return Math.max(a, Number(t.down) || 0); }, 0);
    root.appendChild(Kit.ui.section("سجل النتائج", tests.length ? { label: "مسح الكل", onClick: async function () {
      if (!(await Kit.confirm("حذف كل نتائج اختبار السرعة؟", { danger: true, ok: "حذف" }))) return;
      App.speedtestsStore.set([]); haptic(20);
    } } : undefined));
    if (!tests.length) {
      root.appendChild(Kit.ui.empty({ icon: "zap", title: "لا توجد نتائج بعد", text: "شغّل أول اختبار لتظهر نتائجه هنا.", action: { label: "ابدأ الاختبار", onClick: startSpeed } }));
    } else {
      root.appendChild(Kit.ui.grid([
        Kit.ui.stat({ icon: "chart", value: fmtSpeed(avg), label: "متوسط Mbps" }),
        Kit.ui.stat({ icon: "trophy", value: fmtSpeed(best), label: "أفضل Mbps" })
      ], 2));
      root.appendChild(h("div", { class: "k-card" }, Kit.ui.bars(tests.slice(0, 10).reverse().map(function (t) {
        var d = new Date(t.ts || 0); return { label: d.getDate() + "/" + (d.getMonth() + 1), value: Math.round((Number(t.down) || 0) * 10) / 10 };
      }))));
      root.appendChild(Kit.ui.list(tests.map(function (t) {
        return Kit.ui.item({
          title: fmtSpeed(t.down) + " Mbps · " + speedRating(Number(t.down) || 0),
          sub: "Ping " + num(t.ping) + " ms · " + fmtDate(t.ts) + " " + fmtTime(t.ts), icon: "zap",
          trailing: stop(h("div", {}, Kit.ui.iconBtn("trash", "حذف", function () {
            App.speedtestsStore.update(function (l) { return (Array.isArray(l) ? l : []).filter(function (x) { return x && x.id !== t.id; }); }); haptic(15);
          })))
        });
      })));
    }
    el.appendChild(root);
    paintSpeed();
  };

  // ---------- Bookmarks ----------
  var bm = { q: "", folder: "all", sort: "recent" };

  function folderNames() {
    var out = [];
    function add(f) { f = String(f || "").trim(); if (f && out.indexOf(f) < 0) out.push(f); }
    try { var f = App.bookmarkFolders(); if (Array.isArray(f)) f.forEach(add); } catch (e) {}
    arr(App.bookmarksStore).forEach(function (b) { add(b.folder); });
    if (!out.length) add("عام");
    return out;
  }

  function bookmarkSheet(item) {
    Kit.sheet(function (close) {
      var err = errBox(), folders = folderNames();
      var fTitle = Kit.ui.field({ label: "الاسم", value: item ? item.title : "", placeholder: "اسم الموقع" });
      var fUrl = Kit.ui.field({ label: "الرابط", type: "url", value: item ? item.url : "", placeholder: "https://example.com" });
      var opts = folders.map(function (f) { return { value: f, label: f }; }).concat([{ value: "__new", label: "مجلد جديد…" }]);
      var fFolder = Kit.ui.field({ label: "المجلد", options: opts, value: item && item.folder ? item.folder : (bm.folder !== "all" ? bm.folder : folders[0]) });
      var fNew = Kit.ui.field({ label: "اسم المجلد الجديد", placeholder: "مثال: عمل" });
      fNew.style.display = "none";
      if (fUrl.input) fUrl.input.setAttribute("dir", "ltr");
      if (fFolder.input) fFolder.input.addEventListener("change", function () { fNew.style.display = fFolder.input.value === "__new" ? "" : "none"; });
      [fTitle, fUrl, fNew].forEach(function (f) { if (f.input) f.input.addEventListener("input", function () { err.textContent = ""; }); });
      function save(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        var title = (fTitle.input ? fTitle.input.value : "").trim();
        if (!title) { err.textContent = "اكتب اسماً للإشارة"; haptic(30); return; }
        if (title.length > 120) { err.textContent = "الاسم طويل جداً"; return; }
        var u = normUrl(fUrl.input ? fUrl.input.value : "");
        if (u.error) { err.textContent = u.error; haptic(30); return; }
        var folder = fFolder.input ? fFolder.input.value : "عام";
        if (folder === "__new") {
          folder = (fNew.input ? fNew.input.value : "").trim();
          if (!folder) { err.textContent = "اكتب اسم المجلد الجديد"; return; }
          if (folder.length > 30) { err.textContent = "اسم المجلد طويل جداً"; return; }
        }
        var dup = arr(App.bookmarksStore).filter(function (b) { return b.url === u.url && (!item || b.id !== item.id); })[0];
        if (dup) { err.textContent = "هذا الرابط محفوظ مسبقاً في «" + (dup.folder || "عام") + "»"; return; }
        App.bookmarksStore.update(function (l) {
          l = Array.isArray(l) ? l : [];
          if (item) l.forEach(function (b) { if (b && b.id === item.id) { b.title = title; b.url = u.url; b.folder = folder; } });
          else l.unshift({ id: uid(), title: title, url: u.url, folder: folder, pinned: false, ts: Date.now() });
          return l;
        });
        haptic(20); toast(item ? "حُفظ التعديل" : "أُضيفت الإشارة"); close();
      }
      return h("form", { class: "k-col", style: { gap: "10px" }, onsubmit: save }, fTitle, fUrl, fFolder, fNew, err,
        Kit.ui.btn("حفظ", { kind: "primary", icon: "check", block: true, onClick: save }));
    }, { title: item ? "تعديل الإشارة" : "إشارة جديدة" });
  }

  function patchBookmark(id, fn) {
    App.bookmarksStore.update(function (l) { l = Array.isArray(l) ? l : []; l.forEach(function (b) { if (b && b.id === id) fn(b); }); return l; });
  }

  function bookmarkMenu(b) {
    Kit.sheet(function (close) {
      function act(fn) { return function () { close(); fn(); }; }
      return Kit.ui.list([
        Kit.ui.item({ title: "فتح", icon: "globe", onClick: act(function () { openLink(b.url); }) }),
        Kit.ui.item({ title: "فتح في تبويب خفي", icon: "eye", onClick: act(function () { openLink(b.url, { private: true, newTab: true }); }) }),
        Kit.ui.item({ title: b.pinned ? "إلغاء التثبيت" : "تثبيت", icon: "star", onClick: act(function () { patchBookmark(b.id, function (x) { x.pinned = !x.pinned; }); haptic(10); }) }),
        Kit.ui.item({ title: "نسخ الرابط", icon: "copy", onClick: act(function () { copyLink(b.url); }) }),
        Kit.ui.item({ title: "مشاركة", icon: "share", onClick: act(function () { shareLink(b.title, b.url); }) }),
        Kit.ui.item({ title: "تعديل أو نقل إلى مجلد", icon: "edit", onClick: act(function () { bookmarkSheet(b); }) }),
        Kit.ui.item({ title: "حذف", icon: "trash", onClick: act(async function () {
          if (!(await Kit.confirm("حذف الإشارة «" + b.title + "»؟", { danger: true, ok: "حذف" }))) return;
          App.bookmarksStore.update(function (l) { return (Array.isArray(l) ? l : []).filter(function (x) { return x && x.id !== b.id; }); });
          haptic(20); toast("حُذفت الإشارة");
        }) })
      ]);
    }, { title: b.title });
  }

  function bookmarkRow(b) {
    return Kit.ui.item({
      title: b.title || hostOf(b.url), sub: hostOf(b.url) + " · " + (b.folder || "عام"), leading: letterAvatar(b.title || hostOf(b.url)),
      onClick: function () { openLink(b.url); },
      trailing: stop(h("div", { class: "k-row", style: { gap: "2px" } },
        h("span", { style: { color: b.pinned ? "var(--accent)" : "var(--muted)", display: "inline-flex" } },
          Kit.ui.iconBtn("star", b.pinned ? "إلغاء التثبيت" : "تثبيت", function () { patchBookmark(b.id, function (x) { x.pinned = !x.pinned; }); haptic(10); })),
        Kit.ui.iconBtn("more", "المزيد", function () { bookmarkMenu(b); })))
    });
  }

  App.screens.bookmarks = function (el) {
    var all = arr(App.bookmarksStore), folders = folderNames();
    if (bm.folder !== "all" && folders.indexOf(bm.folder) < 0) bm.folder = "all";
    var root = h("div", { class: "k-col barq-bookmarks", style: { gap: "12px", paddingBlockEnd: "16px" } });
    root.appendChild(Kit.ui.btn("إضافة إشارة", { kind: "primary", icon: "plus", block: true, onClick: function () { bookmarkSheet(null); } }));
    if (!all.length) {
      root.appendChild(Kit.ui.empty({ icon: "star", title: "لا توجد إشارات مرجعية", text: "احفظ مواقعك المفضّلة للوصول إليها بسرعة.", action: { label: "إضافة إشارة", onClick: function () { bookmarkSheet(null); } } }));
      el.appendChild(root); return;
    }
    var box = h("div", { class: "k-col", style: { gap: "10px" } });
    var s = Kit.ui.search(function (v) { bm.q = s && s.input ? s.input.value : inputVal(v); draw(); }, "ابحث في الإشارات");
    if (s.input && bm.q) s.input.value = bm.q;
    root.appendChild(s);
    root.appendChild(Kit.ui.chips([{ value: "all", label: "الكل (" + all.length + ")" }].concat(folders.map(function (f) {
      return { value: f, label: f + " (" + all.filter(function (b) { return (b.folder || "عام") === f; }).length + ")" };
    })), bm.folder, function (v) { bm.folder = v; Kit.refresh(); }));
    root.appendChild(Kit.ui.segmented([{ value: "recent", label: "الأحدث" }, { value: "name", label: "حسب الاسم" }], bm.sort, function (v) { bm.sort = v; Kit.refresh(); }));
    root.appendChild(box);

    function draw() {
      box.textContent = "";
      var q = String(bm.q || "").trim().toLowerCase();
      var list = all.filter(function (b) {
        if (bm.folder !== "all" && (b.folder || "عام") !== bm.folder) return false;
        return !q || (String(b.title || "") + " " + String(b.url || "") + " " + String(b.folder || "")).toLowerCase().indexOf(q) >= 0;
      }).sort(bm.sort === "name" ? function (a, b) { return String(a.title || "").localeCompare(String(b.title || ""), "ar"); } : function (a, b) { return (b.ts || 0) - (a.ts || 0); });
      if (!list.length) { box.appendChild(h("div", { class: "k-muted k-small", style: { textAlign: "center", paddingBlock: "16px" } }, "لا توجد إشارات تطابق بحثك.")); return; }
      var pinned = list.filter(function (b) { return b.pinned; }), rest = list.filter(function (b) { return !b.pinned; });
      if (pinned.length) { box.appendChild(Kit.ui.section("مثبّتة")); box.appendChild(Kit.ui.list(pinned.map(bookmarkRow))); }
      if (bm.folder === "all") {
        folders.forEach(function (f) {
          var g = rest.filter(function (b) { return (b.folder || "عام") === f; });
          if (g.length) { box.appendChild(Kit.ui.section(f)); box.appendChild(Kit.ui.list(g.map(bookmarkRow))); }
        });
      } else if (rest.length) { if (pinned.length) box.appendChild(Kit.ui.section("الأخرى")); box.appendChild(Kit.ui.list(rest.map(bookmarkRow))); }
    }
    draw();
    el.appendChild(root);
  };

  // ---------- History ----------
  var hs = { q: "" };

  App.screens.history = function (el) {
    var all = arr(App.historyStore);
    var root = h("div", { class: "k-col barq-history", style: { gap: "12px", paddingBlockEnd: "16px" } });
    if (!setting("saveHistory", true)) root.appendChild(h("div", { class: "k-card k-small k-muted" }, "حفظ السجل معطّل من الإعدادات، فلن تُضاف زيارات جديدة."));
    if (!all.length) {
      root.appendChild(Kit.ui.empty({ icon: "clock", title: "السجل فارغ", text: "ستظهر هنا المواقع التي تزورها في التبويبات العادية.", action: { label: "ابدأ التصفّح", onClick: function () { Kit.go("home"); } } }));
      el.appendChild(root); return;
    }
    root.appendChild(h("div", { class: "k-row", style: { gap: "8px" } },
      Kit.ui.btn("مسح آخر ساعة", { kind: "tonal", icon: "clock", block: true, onClick: async function () {
        var cut = Date.now() - 3600000, n = all.filter(function (x) { return (x.ts || 0) >= cut; }).length;
        if (!n) { toast("لا توجد زيارات في آخر ساعة"); return; }
        if (!(await Kit.confirm("حذف " + num(n) + " زيارة من آخر ساعة؟", { danger: true, ok: "حذف" }))) return;
        App.historyStore.update(function (l) { return (Array.isArray(l) ? l : []).filter(function (x) { return x && (x.ts || 0) < cut; }); });
        haptic(25); toast("حُذفت زيارات آخر ساعة");
      } }),
      Kit.ui.btn("مسح الكل", { kind: "danger", icon: "trash", block: true, onClick: async function () {
        if (!(await Kit.confirm("مسح السجل بالكامل؟ لا يمكن التراجع.", { danger: true, ok: "مسح" }))) return;
        App.historyStore.set([]); haptic(30); toast("مُسح السجل");
      } })));
    var box = h("div", { class: "k-col", style: { gap: "10px" } });
    var s = Kit.ui.search(function (v) { hs.q = s && s.input ? s.input.value : inputVal(v); draw(); }, "ابحث في السجل");
    if (s.input && hs.q) s.input.value = hs.q;
    root.appendChild(s);
    root.appendChild(box);
    function draw() {
      box.textContent = "";
      var q = String(hs.q || "").trim().toLowerCase();
      var list = all.filter(function (x) { return !q || (String(x.title || "") + " " + String(x.url || "")).toLowerCase().indexOf(q) >= 0; });
      if (!list.length) { box.appendChild(h("div", { class: "k-muted k-small", style: { textAlign: "center", paddingBlock: "16px" } }, "لا توجد زيارات تطابق بحثك.")); return; }
      groupDays(list).forEach(function (g) {
        box.appendChild(Kit.ui.section(g.label + " · " + num(g.items.length)));
        box.appendChild(Kit.ui.list(g.items.map(function (x) {
          return Kit.ui.item({
            title: x.title || hostOf(x.url), sub: fmtTime(x.ts || 0) + " · " + hostOf(x.url), leading: letterAvatar(x.title || hostOf(x.url)),
            onClick: function () { openLink(x.url); },
            trailing: stop(h("div", {}, Kit.ui.iconBtn("x", "حذف من السجل", function () {
              App.historyStore.update(function (l) { return (Array.isArray(l) ? l : []).filter(function (y) { return y && y.id !== x.id; }); });
              haptic(10);
            })))
          });
        })));
      });
    }
    draw();
    el.appendChild(root);
  };

  // ---------- Export / import ----------
  App.exportData = function () {
    var data = { app: "barq-browser", version: 1, exported: Date.now(), bookmarks: arr(App.bookmarksStore), speeddial: arr(App.speeddialStore) };
    var name = "barq-backup-" + (function () { try { return Kit.util.today(); } catch (e) { return dayKey(Date.now()); } })() + ".json";
    try {
      Kit.native.saveFile(name, JSON.stringify(data, null, 2), "application/json");
      haptic(20); toast("صُدّرت " + num(data.bookmarks.length) + " إشارة و" + num(data.speeddial.length) + " مربّعاً");
    } catch (e) { toast("تعذّر حفظ الملف"); }
  };

  App.importData = async function () {
    var file = null;
    try { file = await Kit.native.pickFile(".json,application/json"); } catch (e) { toast("تعذّر فتح الملف"); return; }
    if (!file || typeof file.text !== "string") return;
    var data;
    try { data = JSON.parse(file.text); } catch (e) { toast("الملف ليس بصيغة JSON صالحة"); return; }
    if (Array.isArray(data)) data = { bookmarks: data };
    if (!data || typeof data !== "object" || (!Array.isArray(data.bookmarks) && !Array.isArray(data.speeddial))) { toast("الملف لا يحتوي على إشارات أو اتصال سريع"); return; }
    var haveBm = {}, haveDial = {}, bms = [], dials = [], bad = 0;
    arr(App.bookmarksStore).forEach(function (b) { haveBm[b.url] = 1; });
    arr(App.speeddialStore).forEach(function (d) { haveDial[d.url] = 1; });
    (Array.isArray(data.bookmarks) ? data.bookmarks : []).forEach(function (b) {
      if (!b || typeof b !== "object") { bad++; return; }
      var u = normUrl(b.url); if (u.error) { bad++; return; }
      if (haveBm[u.url]) return; haveBm[u.url] = 1;
      bms.push({ id: uid(), title: String(b.title || hostOf(u.url)).slice(0, 120), url: u.url, folder: String(b.folder || "مستورد").slice(0, 30), pinned: !!b.pinned, ts: Number(b.ts) || Date.now() });
    });
    (Array.isArray(data.speeddial) ? data.speeddial : []).forEach(function (d) {
      if (!d || typeof d !== "object") { bad++; return; }
      var u = normUrl(d.url); if (u.error) { bad++; return; }
      if (haveDial[u.url]) return; haveDial[u.url] = 1;
      dials.push({ id: uid(), title: String(d.title || hostOf(u.url)).slice(0, 40), url: u.url, color: /^#[0-9a-f]{6}$/i.test(d.color || "") ? d.color : "#1E6FFF" });
    });
    if (!bms.length && !dials.length) { toast(bad ? "لا توجد عناصر صالحة في الملف" : "كل العناصر موجودة مسبقاً"); return; }
    var ok = await Kit.confirm("استيراد " + num(bms.length) + " إشارة و" + num(dials.length) + " مربّع اتصال سريع؟" + (bad ? " سيُتجاهل " + num(bad) + " عنصراً غير صالح." : ""), { ok: "استيراد" });
    if (!ok) return;
    if (bms.length) App.bookmarksStore.update(function (l) { return bms.concat(Array.isArray(l) ? l : []); });
    if (dials.length) App.speeddialStore.update(function (l) { return (Array.isArray(l) ? l : []).concat(dials).slice(0, 40); });
    haptic(30); toast("اكتمل الاستيراد");
  };
})();