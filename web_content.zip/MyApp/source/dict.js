(function () {
  "use strict";

  // Each entry: [Arabic forms separated by "|", English forms separated by "|"].
  // The first form on each side is the one used as the translation output.
  var RAW = [
    // Greetings and courtesy
    ["مرحباً|مرحبا|أهلاً|أهلا", "hello|hi|hey"], ["أهلاً وسهلاً|أهلا وسهلا", "welcome"],
    ["السلام عليكم", "peace be upon you"], ["وعليكم السلام", "and peace be upon you"],
    ["صباح الخير", "good morning"], ["صباح النور", "good morning to you"],
    ["مساء الخير", "good evening|good afternoon"], ["مساء النور", "good evening to you"],
    ["تصبح على خير|تصبحين على خير", "good night"], ["مع السلامة|إلى اللقاء|وداعاً", "goodbye|bye|bye bye"],
    ["أراك لاحقاً|أراك لاحقا", "see you later|see you"], ["أراك غداً|أراك غدا", "see you tomorrow"],
    ["كيف حالك|كيف الحال", "how are you|how are you doing"], ["أنا بخير", "i am fine|i'm fine|i am good|i'm good"],
    ["بخير والحمد لله", "fine thank god"], ["وأنت", "and you|what about you"],
    ["شكراً|شكرا", "thank you|thanks"], ["شكراً جزيلاً|شكرا جزيلا", "thank you very much|thanks a lot"],
    ["عفواً|عفوا", "you are welcome|you're welcome"], ["على الرحب والسعة", "my pleasure"],
    ["من فضلك|لو سمحت|رجاءً", "please"], ["آسف|أنا آسف|متأسف", "sorry|i am sorry|i'm sorry"],
    ["المعذرة|عذراً", "excuse me|pardon"], ["تشرفت بمعرفتك", "nice to meet you|pleased to meet you"],
    ["ما اسمك", "what is your name|what's your name"], ["اسمي", "my name is|my name"],
    ["من أين أنت", "where are you from"], ["أنا من", "i am from|i'm from"],
    ["كم عمرك", "how old are you"], ["هل تتكلم الإنجليزية", "do you speak english"],
    ["هل تتكلم العربية", "do you speak arabic"], ["أتكلم قليلاً من العربية", "i speak a little arabic"],
    ["لا أفهم", "i do not understand|i don't understand"], ["فهمت", "i understand|i understood|got it"],
    ["تكلم ببطء من فضلك", "please speak slowly|speak slowly please"], ["هل يمكنك مساعدتي", "can you help me|could you help me"],
    ["أحتاج مساعدة", "i need help"], ["النجدة", "help me"],
    ["لا مشكلة", "no problem"], ["لا بأس", "it is okay|it's okay|that's okay"],
    ["بالتأكيد|طبعاً", "of course|sure|certainly"], ["ربما", "maybe|perhaps"],
    ["أحبك", "i love you"], ["مبروك|ألف مبروك", "congratulations|congrats"],
    ["عيد سعيد", "happy eid"], ["عيد ميلاد سعيد", "happy birthday"], ["سنة سعيدة", "happy new year"],
    ["رمضان كريم", "ramadan kareem"], ["حظاً سعيداً|حظا سعيدا", "good luck"], ["بالتوفيق", "all the best"],
    ["انتبه", "be careful|watch out"], ["انتظر لحظة|لحظة من فضلك", "wait a moment|one moment please|just a moment"],
    ["تفضل", "here you go|go ahead"], ["إن شاء الله", "god willing"], ["الحمد لله", "thank god|praise be to god"],
    ["ما شاء الله", "god has willed it"], ["لا أعرف", "i do not know|i don't know"], ["أعرف", "i know"],
    ["أنا موافق", "i agree"], ["ماذا تقصد", "what do you mean"], ["هيا بنا", "let's go|let us go"],
    ["ما هذا", "what is this|what's this"], ["كم الساعة", "what time is it"], ["ما الأمر", "what is wrong|what's wrong"],
    ["لا تقلق", "do not worry|don't worry"], ["أنا مشغول", "i am busy|i'm busy"], ["دقيقة واحدة", "one minute"],
    // Travel and needs
    ["أين الحمام", "where is the bathroom|where is the toilet|where's the bathroom"],
    ["أين الفندق", "where is the hotel"], ["أين المطار", "where is the airport"], ["أين المحطة", "where is the station"],
    ["كم السعر|بكم هذا|كم سعر هذا", "how much is this|how much is it|how much"],
    ["هذا غالٍ جداً|هذا غالي جدا", "this is too expensive|it is too expensive"], ["أريد هذا", "i want this|i would like this"],
    ["الحساب من فضلك", "the bill please|check please"], ["هل تقبلون البطاقة", "do you accept cards|do you take cards"],
    ["أنا جائع", "i am hungry|i'm hungry"], ["أنا عطشان", "i am thirsty|i'm thirsty"],
    ["أنا متعب", "i am tired|i'm tired"], ["أنا مريض", "i am sick|i'm sick|i am ill"],
    ["اتصل بالإسعاف", "call an ambulance"], ["اتصل بالشرطة", "call the police"],
    ["كيف أصل إلى", "how do i get to"], ["اتجه يميناً|اتجه يمينا", "turn right"], ["اتجه يساراً|اتجه يسارا", "turn left"],
    ["إلى الأمام مباشرة", "straight ahead|go straight"], ["أنا ضائع", "i am lost|i'm lost"],
    ["أين أقرب صيدلية", "where is the nearest pharmacy"], ["أين أقرب مستشفى", "where is the nearest hospital"],
    ["أريد أن أحجز غرفة", "i want to book a room|i would like to book a room"], ["تذكرة واحدة", "one ticket"],
    ["ذهاب وعودة", "round trip|return ticket"], ["متى يغادر القطار", "when does the train leave"],
    ["الإنترنت لا يعمل", "the internet is not working|the internet isn't working"],
    ["ما كلمة مرور الواي فاي", "what is the wifi password|what's the wifi password"], ["هل يوجد واي فاي", "is there wifi"],
    // Pronouns and function words
    ["أنا", "i|me|i'm"], ["أنت|أنتِ", "you"], ["هو", "he|him|it"], ["هي", "she|her"], ["نحن", "we|us"], ["هم", "they|them"],
    ["هذا|هذه", "this"], ["ذلك|تلك", "that"], ["هؤلاء", "these|those"],
    ["ماذا", "what"], ["لماذا", "why"], ["متى", "when"], ["أين", "where"], ["كيف", "how"], ["كم", "how many|how much"],
    ["أي", "which"], ["من", "from"], ["مَن", "who"], ["في", "in|inside"], ["على", "on"], ["إلى", "to"], ["مع", "with"],
    ["عن", "about"], ["بعد", "after"], ["قبل", "before"], ["تحت", "under|below"], ["فوق", "above|over"], ["بين", "between"],
    ["عند", "at"], ["هنا", "here"], ["هناك", "there"], ["الآن", "now"], ["اليوم", "today"], ["غداً|غدا", "tomorrow"],
    ["أمس|البارحة", "yesterday"], ["دائماً|دائما", "always"], ["أبداً|أبدا", "never"], ["أحياناً|أحيانا", "sometimes"],
    ["جداً|جدا", "very"], ["قليلاً|قليلا", "a little|a bit"], ["كثيراً|كثيرا", "a lot|much"], ["أيضاً|أيضا", "also|too"],
    ["لكن|ولكن", "but"], ["أو", "or"], ["و", "and"], ["لا", "no"], ["نعم|أجل", "yes|yeah"], ["ليس", "not|is not"],
    ["كل", "all|every"], ["بعض", "some"], ["فقط", "only|just"], ["ربما", "probably"], ["لأن", "because"], ["إذا|لو", "if"],
    ["أريد", "i want|want"], ["أحب", "i like|like|love"], ["أذهب", "i go|go"], ["آكل", "i eat|eat"], ["أشرب", "i drink|drink"],
    ["أنام", "i sleep|sleep"], ["أعمل", "i work"], ["أقرأ", "i read|read"], ["أكتب", "i write|write"], ["أرى", "i see|see"],
    ["أستطيع", "i can|can"], ["أحتاج", "i need|need"], ["أبحث عن", "i am looking for|looking for"], ["افتح", "open it"],
    ["أغلق", "close"], ["ابدأ", "start"], ["توقف", "stop"], ["تعال", "come"], ["اذهب", "go away"], ["انتظر", "wait"],
    // Places and things
    ["بيت|منزل", "house|home"], ["مدرسة", "school"], ["جامعة", "university"], ["عمل", "work|job"], ["مكتب", "office|desk"],
    ["سيارة", "car"], ["حافلة|باص", "bus"], ["قطار", "train"], ["طائرة", "plane|airplane"], ["طريق", "road|way"],
    ["شارع", "street"], ["مدينة", "city"], ["بلد|دولة", "country"], ["سوق", "market"], ["مطعم", "restaurant"],
    ["فندق", "hotel"], ["مطار", "airport"], ["محطة", "station"], ["مستشفى", "hospital"], ["صيدلية", "pharmacy"],
    ["طبيب|دكتور", "doctor"], ["دواء", "medicine"], ["بنك|مصرف", "bank"], ["مسجد", "mosque"], ["حديقة", "park|garden"],
    ["كتاب", "book"], ["قلم", "pen"], ["ورقة", "paper"], ["باب", "door"], ["نافذة", "window"], ["غرفة", "room"],
    ["مال|نقود", "money"], ["تذكرة", "ticket"], ["حقيبة", "bag"], ["مفتاح", "key"], ["ساعة", "hour|clock|watch"],
    // Food
    ["ماء", "water"], ["خبز", "bread"], ["حليب", "milk"], ["قهوة", "coffee"], ["شاي", "tea"], ["طعام|أكل", "food"],
    ["لحم", "meat"], ["دجاج", "chicken"], ["سمك", "fish"], ["أرز|رز", "rice"], ["فاكهة", "fruit"], ["تفاح", "apple|apples"],
    ["برتقال", "orange|oranges"], ["موز", "banana|bananas"], ["سكر", "sugar"], ["ملح", "salt"], ["عصير", "juice"],
    ["فطور", "breakfast"], ["غداء", "lunch"], ["عشاء", "dinner"], ["بيض", "eggs|egg"], ["خضار", "vegetables"],
    // People
    ["صديق", "friend"], ["عائلة|أسرة", "family"], ["أب|والد", "father|dad"], ["أم|والدة", "mother|mom"],
    ["أخ", "brother"], ["أخت", "sister"], ["ابن", "son"], ["ابنة|بنت", "daughter|girl"], ["ولد", "boy"],
    ["رجل", "man"], ["امرأة", "woman"], ["طفل", "child|baby|kid"], ["أطفال", "children|kids"], ["ناس|أشخاص", "people"],
    ["اسم", "name"], ["زوج", "husband"], ["زوجة", "wife"], ["جد", "grandfather"], ["جدة", "grandmother"],
    // Time and nature
    ["وقت", "time"], ["يوم", "day"], ["أسبوع", "week"], ["شهر", "month"], ["سنة|عام", "year"], ["دقيقة", "minute"],
    ["ثانية", "second"], ["صباح", "morning"], ["مساء", "evening"], ["ليل|ليلة", "night"], ["ظهر", "noon"],
    ["شمس", "sun"], ["قمر", "moon"], ["سماء", "sky"], ["بحر", "sea"], ["مطر", "rain"], ["طقس", "weather"],
    ["الأحد", "sunday"], ["الإثنين|الاثنين", "monday"], ["الثلاثاء", "tuesday"], ["الأربعاء", "wednesday"],
    ["الخميس", "thursday"], ["الجمعة", "friday"], ["السبت", "saturday"],
    // Numbers
    ["صفر", "zero"], ["واحد", "one"], ["اثنان|اثنين", "two"], ["ثلاثة", "three"], ["أربعة", "four"], ["خمسة", "five"],
    ["ستة", "six"], ["سبعة", "seven"], ["ثمانية", "eight"], ["تسعة", "nine"], ["عشرة", "ten"], ["عشرون|عشرين", "twenty"],
    ["مئة|مائة", "hundred"], ["ألف", "thousand"], ["مليون", "million"],
    // Colours
    ["أحمر", "red"], ["أزرق", "blue"], ["أخضر", "green"], ["أصفر", "yellow"], ["أسود", "black"], ["أبيض", "white"],
    ["بني", "brown"], ["رمادي", "gray|grey"], ["برتقالي", "orange colour"], ["بنفسجي", "purple"],
    // Adjectives
    ["كبير", "big|large"], ["صغير", "small|little"], ["جديد", "new"], ["قديم", "old"], ["جميل", "beautiful|pretty|nice"],
    ["جيد", "good"], ["سيء|سيئ", "bad"], ["سريع", "fast|quick"], ["بطيء", "slow"], ["سهل", "easy"], ["صعب", "difficult|hard"],
    ["رخيص", "cheap"], ["غالي|غالٍ", "expensive"], ["سعيد", "happy"], ["حزين", "sad"], ["قريب", "near|close"],
    ["بعيد", "far"], ["مفتوح", "open"], ["مغلق", "closed"], ["آمن", "safe|secure"], ["خطير", "dangerous"],
    ["صحيح", "correct|right|true"], ["خطأ", "wrong|error|mistake"], ["مهم", "important"], ["كثير", "many"],
    ["حار", "hot"], ["بارد", "cold"], ["طويل", "long|tall"], ["قصير", "short"], ["نظيف", "clean"], ["متسخ", "dirty"],
    ["مجاني", "free"], ["ممتاز", "excellent|great"], ["يمين", "right side"], ["يسار", "left"],
    // Tech and browsing
    ["متصفح", "browser"], ["بحث", "search"], ["رابط", "link|url"], ["موقع", "website|site|location"], ["صفحة", "page"],
    ["تبويب", "tab"], ["تنزيل", "download"], ["رفع", "upload"], ["ملف", "file"], ["إعدادات", "settings"], ["أمان", "security"],
    ["خصوصية", "privacy"], ["إعلان", "ad|advertisement"], ["إعلانات", "ads|advertisements"], ["متتبع", "tracker"],
    ["كلمة المرور|كلمة السر", "password"], ["حساب", "account"], ["بريد إلكتروني", "email|e-mail"], ["رسالة", "message"],
    ["هاتف|جوال", "phone|mobile"], ["حاسوب|كمبيوتر", "computer"], ["إنترنت", "internet"], ["شبكة", "network"],
    ["تطبيق", "app|application"], ["تحديث", "update|refresh"], ["حفظ", "save"], ["حذف", "delete|remove"], ["نسخ", "copy"],
    ["مشاركة", "share"], ["إلغاء", "cancel"], ["موافق", "ok|okay"], ["تسجيل الدخول", "login|log in|sign in"],
    ["تسجيل الخروج", "logout|log out|sign out"], ["تحذير", "warning"], ["سرعة", "speed"], ["صورة", "image|photo|picture"],
    ["فيديو", "video"], ["لغة", "language"], ["عربي|العربية", "arabic"], ["إنجليزي|الإنجليزية", "english"],
    ["ترجمة", "translation|translate"], ["مساعدة", "help"], ["إشعار", "notification"], ["إشارة مرجعية", "bookmark"],
    ["سجل", "history|log"], ["فيروس", "virus"], ["خادم", "server"], ["اتصال", "connection"]
  ];

  // ---------- Normalisation ----------
  function normAr(s) {
    return String(s || "")
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/ؤ/g, "و")
      .replace(/ئ/g, "ي");
  }
  function normEn(s) {
    return String(s || "").toLowerCase().replace(/[\u2018\u2019`]/g, "'").replace(/^'+|'+$/g, "");
  }
  var PUNCT_RE = /[.,!?;:"«»()\[\]{}\u060C\u061B\u061F\u2026\u201C\u201D-]+/g;
  function normKey(s, lang) {
    var t = lang === "ar" ? normAr(s) : normEn(s);
    return t.replace(PUNCT_RE, " ").replace(/\s+/g, " ").trim()
      .split(" ").map(function (w) { return lang === "ar" ? w : w.replace(/^'+|'+$/g, ""); }).join(" ");
  }

  // ---------- Build lookup maps ----------
  var AR = Object.create(null), EN = Object.create(null), MAXN = 1;
  App.DICT = [];
  RAW.forEach(function (p) {
    if (!Array.isArray(p) || p.length < 2) return;
    var arAlt = String(p[0]).split("|").map(function (x) { return x.trim(); }).filter(Boolean);
    var enAlt = String(p[1]).split("|").map(function (x) { return x.trim(); }).filter(Boolean);
    if (!arAlt.length || !enAlt.length) return;
    var entry = { ar: arAlt[0], en: enAlt[0], arAlt: arAlt, enAlt: enAlt };
    App.DICT.push(entry);
    arAlt.forEach(function (a) {
      var k = normKey(a, "ar");
      if (k && !(k in AR)) AR[k] = entry.en;
      MAXN = Math.max(MAXN, k.split(" ").length);
    });
    enAlt.forEach(function (e) {
      var k = normKey(e, "en");
      if (k && !(k in EN)) EN[k] = entry.ar;
      MAXN = Math.max(MAXN, k.split(" ").length);
    });
  });
  MAXN = Math.min(MAXN, 7);
  App.DICT_COUNT = App.DICT.length;

  App.detectLang = function (text) {
    var s = String(text || "");
    var ar = (s.match(/[\u0620-\u064A]/g) || []).length;
    var en = (s.match(/[A-Za-z]/g) || []).length;
    return ar >= en && ar > 0 ? "ar" : "en";
  };

  // ---------- Tokenising ----------
  var WCH = "A-Za-z0-9\\u00C0-\\u024F'\\u2019\\u0610-\\u061A\\u0620-\\u0669\\u066E-\\u06D3\\u06D5-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF";
  var TOKEN_RE = new RegExp("[" + WCH + "]+|\\s+|[^" + WCH + "\\s]", "g");
  var WORD_RE = new RegExp("^[" + WCH + "]+$");
  var GAP_RE = /^[ \t\u00A0]+$/;
  var TO_AR = { ",": "\u060C", "?": "\u061F", ";": "\u061B" };
  var TO_EN = { "\u060C": ",", "\u061F": "?", "\u061B": ";" };

  function convPunct(t, to) {
    var m = to === "ar" ? TO_AR : TO_EN;
    return t.split("").map(function (c) { return m[c] || c; }).join("");
  }
  function isWord(t) { return WORD_RE.test(t) && /[^'\u2019]/.test(t); }

  // ---------- Single-word lookup with light morphology ----------
  var AR_PREFIXES = [
    ["وال", "and the "], ["بال", "with the "], ["فال", "so the "], ["كال", "like the "], ["لل", "for the "],
    ["ال", "the "], ["و", "and "], ["ف", "so "], ["ب", "with "], ["ل", "for "]
  ];

  function tryArStem(k) {
    if (!k) return null;
    if (AR[k]) return AR[k];
    if (AR["ال" + k]) return AR["ال" + k];
    if (k.length > 4 && /ات$/.test(k)) {
      var s = k.slice(0, -2);
      if (AR[s + "ه"]) return AR[s + "ه"];
      if (AR[s]) return AR[s];
    }
    if (k.length > 4 && /(ون|ين)$/.test(k) && AR[k.slice(0, -2)]) return AR[k.slice(0, -2)];
    return null;
  }

  function lookupAr(word) {
    var k = normAr(word);
    var hit = tryArStem(k);
    if (hit) return hit;
    for (var i = 0; i < AR_PREFIXES.length; i++) {
      var p = AR_PREFIXES[i][0];
      if (k.indexOf(p) === 0 && k.length - p.length >= 2) {
        var r = tryArStem(k.slice(p.length));
        if (r) {
          var pre = AR_PREFIXES[i][1];
          if (/the $/.test(pre) && /^(the|a|an) /i.test(r)) pre = pre.replace(/the $/, "");
          return pre + r;
        }
      }
    }
    return null;
  }

  function lookupEn(word) {
    var k = normEn(word);
    if (!k) return null;
    if (EN[k]) return EN[k];
    var tries = [];
    if (/'s$/.test(k)) tries.push(k.slice(0, -2));
    if (/ies$/.test(k) && k.length > 4) tries.push(k.slice(0, -3) + "y");
    if (/es$/.test(k) && k.length > 3) tries.push(k.slice(0, -2));
    if (/s$/.test(k) && k.length > 3) tries.push(k.slice(0, -1));
    if (/ing$/.test(k) && k.length > 5) { tries.push(k.slice(0, -3)); tries.push(k.slice(0, -3) + "e"); }
    if (/ed$/.test(k) && k.length > 4) { tries.push(k.slice(0, -2)); tries.push(k.slice(0, -1)); }
    if (/ly$/.test(k) && k.length > 4) tries.push(k.slice(0, -2));
    for (var i = 0; i < tries.length; i++) if (EN[tries[i]]) return EN[tries[i]];
    return null;
  }

  function finishEnglish(s) {
    return s
      .replace(/(^|[^A-Za-z'])i(?=$|[^A-Za-z])/g, "$1I")
      .replace(/^(\s*)([a-z])/, function (m, a, b) { return a + b.toUpperCase(); })
      .replace(/([.!?]\s+)([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); });
  }

  // ---------- Main API ----------
  App.translate = function (text, from, to) {
    var src = String(text == null ? "" : text);
    var res = { out: "", matched: 0, total: 0, ratio: 0, exact: false, complete: false, unknown: [], from: from, to: to };
    if (!src.trim()) return res;
    if (from !== "ar" && from !== "en") from = App.detectLang(src);
    if (to !== "ar" && to !== "en") to = from === "ar" ? "en" : "ar";
    res.from = from; res.to = to;
    var wordCount = (src.match(TOKEN_RE) || []).filter(isWord).length;
    if (from === to) {
      res.out = src; res.matched = res.total = wordCount; res.ratio = wordCount ? 1 : 0; res.complete = true;
      return res;
    }
    var map = from === "ar" ? AR : EN;

    // 1) Whole phrase
    var full = normKey(src, from);
    if (full && map[full]) {
      var tail = (src.trim().match(/[.!?\u061F\u060C,\u2026]+$/) || [""])[0];
      var outFull = map[full] + convPunct(tail, to);
      res.out = to === "en" ? finishEnglish(outFull) : outFull;
      res.matched = res.total = Math.max(1, wordCount);
      res.ratio = 1; res.exact = true; res.complete = true;
      return res;
    }

    // 2) Greedy longest phrase, then word by word
    var tokens = src.match(TOKEN_RE) || [];
    var out = [], i = 0, pendingThe = false, guard = 0;
    while (i < tokens.length && guard++ < 20000) {
      var t = tokens[i];
      if (!isWord(t)) { out.push(/^\s+$/.test(t) ? t : convPunct(t, to)); i++; continue; }

      var idxs = [i], j = i;
      while (idxs.length < MAXN && tokens[j + 1] && GAP_RE.test(tokens[j + 1]) && tokens[j + 2] && isWord(tokens[j + 2])) {
        j += 2; idxs.push(j);
      }
      var hit = null, n;
      for (n = idxs.length; n >= 2; n--) {
        var key = normKey(idxs.slice(0, n).map(function (x) { return tokens[x]; }).join(" "), from);
        if (map[key]) { hit = map[key]; break; }
      }
      if (hit) {
        out.push(hit); res.total += n; res.matched += n; pendingThe = false;
        i = idxs[n - 1] + 1;
        continue;
      }

      if (from === "en" && to === "ar") {
        var lw = normEn(t);
        if ((lw === "the" || lw === "a" || lw === "an") && idxs.length > 1) {
          pendingThe = lw === "the";
          i = idxs[1];
          continue;
        }
      }

      res.total++;
      var r = from === "ar" ? lookupAr(t) : lookupEn(t);
      if (r) {
        if (pendingThe && to === "ar" && r.indexOf(" ") < 0 && normAr(r).indexOf("ال") !== 0) r = "ال" + r;
        out.push(r); res.matched++;
      } else {
        out.push(t);
        if (res.unknown.indexOf(t) < 0) res.unknown.push(t);
      }
      pendingThe = false;
      i++;
    }

    var joined = out.join("");
    res.out = to === "en" ? finishEnglish(joined) : joined;
    res.ratio = res.total ? res.matched / res.total : 0;
    res.complete = res.total > 0 && res.matched === res.total;
    return res;
  };

  // Suggestions for the translator screen (dictionary browsing / autocomplete).
  App.dictSuggest = function (query, lang, limit) {
    limit = Math.max(1, Math.min(Number(limit) || 8, 50));
    var q = String(query || "").trim();
    if (!q) return [];
    if (lang !== "ar" && lang !== "en") lang = App.detectLang(q);
    var nq = normKey(q, lang);
    if (!nq) return [];
    var starts = [], contains = [];
    for (var i = 0; i < App.DICT.length; i++) {
      var e = App.DICT[i];
      var alts = lang === "ar" ? e.arAlt : e.enAlt;
      var best = -1;
      for (var a = 0; a < alts.length; a++) {
        var k = normKey(alts[a], lang), p = k.indexOf(nq);
        if (p === 0) { best = 0; break; }
        if (p > 0) best = 1;
      }
      if (best === 0) starts.push(e); else if (best === 1) contains.push(e);
      if (starts.length >= limit) break;
    }
    return starts.concat(contains).slice(0, limit).map(function (e) {
      return lang === "ar" ? { src: e.ar, out: e.en, from: "ar", to: "en" } : { src: e.en, out: e.ar, from: "en", to: "ar" };
    });
  };
})();