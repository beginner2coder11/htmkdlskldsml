(function () {
  "use strict";

  var DAY = 86400000;
  var HOUR = 3600000;
  var now = Date.now();

  function pad(n) { return (n < 10 ? "0" : "") + n; }

  App.dayKey = function (ts) {
    var d = new Date(typeof ts === "number" ? ts : Date.now());
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  };

  App.todayKey = function () {
    try { if (Kit.util && Kit.util.today) return Kit.util.today(); } catch (e) {}
    return App.dayKey(Date.now());
  };

  function uid() {
    try { if (Kit.util && Kit.util.uid) return Kit.util.uid(); } catch (e) {}
    return "id" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }
  App.uid = uid;

  // ---------- Seeds ----------
  var seedTabs = [
    { id: "tab-wiki", url: "https://ar.wikipedia.org/", title: "ويكيبيديا العربية", private: false, created: now - 2 * HOUR, back: [], fwd: [] },
    { id: "tab-ddg", url: "https://duckduckgo.com/", title: "DuckDuckGo", private: false, created: now - HOUR, back: [], fwd: [] }
  ];

  var seedHistory = [
    { id: uid(), url: "https://ar.wikipedia.org/", title: "ويكيبيديا، الموسوعة الحرة", ts: now - 3 * HOUR },
    { id: uid(), url: "https://www.aljazeera.net/", title: "الجزيرة نت", ts: now - 5 * HOUR },
    { id: uid(), url: "https://www.youtube.com/", title: "يوتيوب", ts: now - DAY - 2 * HOUR },
    { id: uid(), url: "https://github.com/", title: "GitHub", ts: now - DAY - 4 * HOUR },
    { id: uid(), url: "https://www.bbc.com/arabic", title: "BBC News عربي", ts: now - 2 * DAY + 3 * HOUR },
    { id: uid(), url: "https://stackoverflow.com/", title: "Stack Overflow", ts: now - 2 * DAY + HOUR }
  ];

  var seedBookmarks = [
    { id: uid(), title: "الجزيرة نت", url: "https://www.aljazeera.net/", folder: "أخبار", pinned: true, ts: now - 10 * DAY },
    { id: uid(), title: "BBC News عربي", url: "https://www.bbc.com/arabic", folder: "أخبار", pinned: false, ts: now - 9 * DAY },
    { id: uid(), title: "سكاي نيوز عربية", url: "https://www.skynewsarabia.com/", folder: "أخبار", pinned: false, ts: now - 8 * DAY },
    { id: uid(), title: "ويكيبيديا العربية", url: "https://ar.wikipedia.org/", folder: "تعلّم", pinned: true, ts: now - 7 * DAY },
    { id: uid(), title: "MDN Web Docs", url: "https://developer.mozilla.org/ar/", folder: "تعلّم", pinned: false, ts: now - 6 * DAY },
    { id: uid(), title: "Khan Academy", url: "https://www.khanacademy.org/", folder: "تعلّم", pinned: false, ts: now - 5 * DAY },
    { id: uid(), title: "GitHub", url: "https://github.com/", folder: "أدوات", pinned: false, ts: now - 4 * DAY },
    { id: uid(), title: "ترجمة Google", url: "https://translate.google.com/", folder: "أدوات", pinned: false, ts: now - 3 * DAY }
  ];

  var seedDial = [
    { id: uid(), title: "Google", url: "https://www.google.com/", color: "#4285F4" },
    { id: uid(), title: "يوتيوب", url: "https://m.youtube.com/", color: "#FF0000" },
    { id: uid(), title: "ويكيبيديا", url: "https://ar.wikipedia.org/", color: "#5C6B7A" },
    { id: uid(), title: "الجزيرة", url: "https://www.aljazeera.net/", color: "#D2A12C" },
    { id: uid(), title: "X", url: "https://x.com/", color: "#14171A" },
    { id: uid(), title: "GitHub", url: "https://github.com/", color: "#6E40C9" },
    { id: uid(), title: "Gmail", url: "https://mail.google.com/", color: "#EA4335" },
    { id: uid(), title: "الطقس", url: "https://www.accuweather.com/ar", color: "#00A3E0" }
  ];

  var seedDownloads = [
    {
      id: uid(), url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
      name: "dummy.pdf", size: 13264, received: 13264, status: "done", speed: 0, risk: "safe",
      report: [
        { ok: true, text: "الاتصال مشفّر (HTTPS)" },
        { ok: true, text: "امتداد الملف آمن: pdf" },
        { ok: true, text: "لا يوجد امتداد مزدوج مخادع" },
        { ok: true, text: "المصدر غير موجود في قوائم الحظر" }
      ],
      ts: now - 2 * DAY
    },
    {
      id: uid(), url: "http://free-invoices-download.xyz/files/invoice.pdf.exe",
      name: "invoice.pdf.exe", size: 0, received: 0, status: "blocked", speed: 0, risk: "danger",
      report: [
        { ok: false, text: "اتصال غير مشفّر (HTTP)" },
        { ok: false, text: "امتداد مزدوج مخادع: يبدو pdf لكنه ملف تنفيذي exe" },
        { ok: false, text: "ملف تنفيذي قد يشغّل برامج ضارة" },
        { ok: true, text: "المصدر غير موجود في قوائم الحظر" }
      ],
      ts: now - DAY - 5 * HOUR
    },
    {
      id: uid(), url: "https://upload.wikimedia.org/wikipedia/commons/4/47/PNG_transparency_demonstration_1.png",
      name: "PNG_transparency_demonstration_1.png", size: 226933, received: 226933, status: "done", speed: 0, risk: "safe",
      report: [
        { ok: true, text: "الاتصال مشفّر (HTTPS)" },
        { ok: true, text: "امتداد الملف آمن: png" },
        { ok: true, text: "لا يوجد امتداد مزدوج مخادع" },
        { ok: true, text: "المصدر غير موجود في قوائم الحظر" }
      ],
      ts: now - 6 * HOUR
    }
  ];

  var seedRules = {
    custom: [
      { id: uid(), domain: "popads.net", enabled: true },
      { id: uid(), domain: "adcash.com", enabled: true }
    ],
    allow: [
      { id: uid(), domain: "wikipedia.org" }
    ],
    builtinEnabled: true
  };

  function seedStats() {
    var days = {};
    var sample = [
      { ads: 42, trackers: 67, params: 9, files: 0 },
      { ads: 58, trackers: 81, params: 14, files: 1 },
      { ads: 31, trackers: 49, params: 6, files: 0 },
      { ads: 74, trackers: 102, params: 18, files: 0 },
      { ads: 46, trackers: 70, params: 11, files: 1 },
      { ads: 63, trackers: 88, params: 15, files: 0 }
    ];
    for (var i = 0; i < sample.length; i++) {
      days[App.dayKey(now - (6 - i) * DAY)] = sample[i];
    }
    return { days: days };
  }

  var seedSpeed = [
    { id: uid(), ts: now - 5 * DAY, ping: 38, down: 24.6 },
    { id: uid(), ts: now - 3 * DAY, ping: 45, down: 19.2 },
    { id: uid(), ts: now - DAY, ping: 31, down: 31.8 }
  ];

  var seedTranslations = {
    recent: [
      { id: uid(), from: "ar", to: "en", src: "صباح الخير", out: "Good morning", fav: true, ts: now - 2 * DAY },
      { id: uid(), from: "en", to: "ar", src: "Thank you", out: "شكراً لك", fav: false, ts: now - DAY },
      { id: uid(), from: "ar", to: "en", src: "أين المحطة؟", out: "Where is the station?", fav: false, ts: now - 4 * HOUR }
    ]
  };

  // ---------- Stores ----------
  App.tabsStore = Kit.store("tabs", seedTabs);
  App.sessionStore = Kit.store("session", { currentTabId: null, currentPrivate: false });
  App.historyStore = Kit.store("history", seedHistory);
  App.bookmarksStore = Kit.store("bookmarks", seedBookmarks);
  App.speeddialStore = Kit.store("speeddial", seedDial);
  App.downloadsStore = Kit.store("downloads", seedDownloads);
  App.rulesStore = Kit.store("rules", seedRules);
  App.statsStore = Kit.store("stats", seedStats());
  App.speedtestsStore = Kit.store("speedtests", seedSpeed);
  App.translationsStore = Kit.store("translations", seedTranslations);
  App.securityStore = Kit.store("security", { pin: null });

  // ---------- Repair corrupted data defensively ----------
  function repairArray(store) {
    try {
      var v = store.get();
      if (!Array.isArray(v)) { store.set([]); return; }
      var clean = v.filter(function (x) { return x && typeof x === "object"; });
      if (clean.length !== v.length) store.set(clean);
    } catch (e) {}
  }
  [App.tabsStore, App.historyStore, App.bookmarksStore, App.speeddialStore, App.downloadsStore, App.speedtestsStore].forEach(repairArray);

  try {
    var tabsNow = App.tabsStore.get() || [];
    var tabsBad = tabsNow.some(function (t) { return !Array.isArray(t.back) || !Array.isArray(t.fwd) || t.private; });
    if (tabsBad) {
      App.tabsStore.set(tabsNow.filter(function (t) { return !t.private; }).map(function (t) {
        t.back = Array.isArray(t.back) ? t.back : [];
        t.fwd = Array.isArray(t.fwd) ? t.fwd : [];
        return t;
      }));
    }
    var s = App.sessionStore.get();
    if (!s || typeof s !== "object") App.sessionStore.set({ currentTabId: null, currentPrivate: false });
    else if (s.currentPrivate) App.sessionStore.set({ currentTabId: null, currentPrivate: false });

    var r = App.rulesStore.get();
    if (!r || typeof r !== "object" || !Array.isArray(r.custom) || !Array.isArray(r.allow)) {
      App.rulesStore.set({
        custom: r && Array.isArray(r.custom) ? r.custom : [],
        allow: r && Array.isArray(r.allow) ? r.allow : [],
        builtinEnabled: r && typeof r.builtinEnabled === "boolean" ? r.builtinEnabled : true
      });
    }
    var st = App.statsStore.get();
    if (!st || typeof st !== "object" || !st.days || typeof st.days !== "object") App.statsStore.set({ days: {} });

    var tr = App.translationsStore.get();
    if (!tr || typeof tr !== "object" || !Array.isArray(tr.recent)) App.translationsStore.set({ recent: [] });

    var sec = App.securityStore.get();
    if (!sec || typeof sec !== "object") App.securityStore.set({ pin: null });
  } catch (e) {}

  // ---------- In-memory private tabs (never persisted) ----------
  if (!Array.isArray(App.privateTabs)) App.privateTabs = [];
  App.privateUnlocked = false;

  // ---------- Helpers ----------
  App.setting = function (key, def) {
    try { return Kit.setting(key, def); } catch (e) { return def; }
  };

  App.haptic = function (ms) {
    try { if (Kit.native && Kit.native.vibrate) Kit.native.vibrate(ms || 20); } catch (e) {}
  };

  App.bumpStat = function (key, n) {
    var amount = typeof n === "number" && isFinite(n) ? n : 1;
    if (!amount) return;
    var day = App.todayKey();
    App.statsStore.update(function (st) {
      if (!st || typeof st !== "object") st = { days: {} };
      if (!st.days || typeof st.days !== "object") st.days = {};
      var d = st.days[day] || { ads: 0, trackers: 0, params: 0, files: 0 };
      d[key] = (Number(d[key]) || 0) + amount;
      st.days[day] = d;
      // keep at most 60 days
      var keys = Object.keys(st.days).sort();
      while (keys.length > 60) { delete st.days[keys.shift()]; }
      return st;
    });
  };

  App.statsForDay = function (day) {
    var st = App.statsStore.get() || {};
    var d = (st.days && st.days[day]) || {};
    return { ads: Number(d.ads) || 0, trackers: Number(d.trackers) || 0, params: Number(d.params) || 0, files: Number(d.files) || 0 };
  };

  App.lastDays = function (n) {
    var out = [];
    var count = Math.max(1, n || 7);
    for (var i = count - 1; i >= 0; i--) {
      var ts = Date.now() - i * DAY;
      var key = App.dayKey(ts);
      var s = App.statsForDay(key);
      s.day = key;
      s.ts = ts;
      s.label = App.weekdayShort(ts);
      out.push(s);
    }
    return out;
  };

  var WEEKDAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  App.weekdayShort = function (ts) {
    var d = new Date(ts);
    return WEEKDAYS[d.getDay()] || "";
  };

  App.hostOf = function (url) {
    if (!url || typeof url !== "string") return "";
    try {
      return new URL(url).hostname.toLowerCase();
    } catch (e) {
      var m = url.match(/^(?:[a-z][a-z0-9+.-]*:)?\/\/([^\/?#:]+)/i) || url.match(/^([^\/?#:\s]+)/);
      return m ? m[1].toLowerCase() : "";
    }
  };

  App.shortHost = function (url) {
    return App.hostOf(url).replace(/^www\./, "").replace(/^m\./, "");
  };

  App.SEARCH_ENGINES = {
    google_inapp: { label: "Google (داخل التطبيق)", url: "https://www.google.com/search?igu=1&q=" },
    duckduckgo: { label: "DuckDuckGo", url: "https://duckduckgo.com/?q=" },
    google: { label: "Google", url: "https://www.google.com/search?q=" },
    bing: { label: "Bing", url: "https://www.bing.com/search?q=" },
    brave: { label: "Brave Search", url: "https://search.brave.com/search?q=" },
    startpage: { label: "Startpage", url: "https://www.startpage.com/do/search?q=" }
  };

  App.engineKey = function () {
    var k = App.setting("searchEngine", "google_inapp");
    return App.SEARCH_ENGINES[k] ? k : "google_inapp";
  };

  App.searchUrl = function (q) {
    var eng = App.SEARCH_ENGINES[App.engineKey()];
    return eng.url + encodeURIComponent(String(q || "").trim());
  };

  App.isSearchUrl = function (url) {
    if (!url) return false;
    for (var k in App.SEARCH_ENGINES) {
      if (url.indexOf(App.SEARCH_ENGINES[k].url) === 0) return true;
    }
    return false;
  };

  var DOMAIN_RE = /^(?:[a-z0-9\u0600-\u06FF](?:[a-z0-9\u0600-\u06FF-]{0,61}[a-z0-9\u0600-\u06FF])?\.)+[a-z\u0600-\u06FF]{2,24}\.?(?::\d{1,5})?(?:[\/?#].*)?$/i;
  var IP_RE = /^(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?(?:[\/?#].*)?$/;
  var LOCAL_RE = /^localhost(?::\d{1,5})?(?:[\/?#].*)?$/i;

  App.looksLikeUrl = function (text) {
    var t = String(text || "").trim();
    if (!t || /\s/.test(t)) return false;
    if (/^https?:\/\/\S+/i.test(t)) return true;
    var bare = t.replace(/^\/\//, "");
    return DOMAIN_RE.test(bare) || IP_RE.test(bare) || LOCAL_RE.test(bare);
  };

  App.upgradeHttps = function (url) {
    if (typeof url === "string" && /^http:\/\//i.test(url)) return "https://" + url.slice(7);
    return url;
  };

  // Returns a full URL: either the typed address (with https added when missing) or a search URL.
  App.normalizeInput = function (text) {
    var t = String(text == null ? "" : text).trim();
    if (!t) return "";
    if (/^(javascript|data|file|blob|about|vbscript):/i.test(t)) return App.searchUrl(t);
    if (/^https?:\/\//i.test(t)) {
      if (/\s/.test(t)) return App.searchUrl(t);
      return t;
    }
    if (App.looksLikeUrl(t)) {
      return "https://" + t.replace(/^\/\//, "");
    }
    return App.searchUrl(t);
  };

  App.validUrl = function (text) {
    var t = String(text || "").trim();
    if (!t || /\s/.test(t)) return false;
    var full = /^https?:\/\//i.test(t) ? t : "https://" + t;
    try {
      var u = new URL(full);
      var host = u.hostname;
      return !!host && (host.indexOf(".") > 0 || host === "localhost");
    } catch (e) { return false; }
  };

  App.addHistory = function (url, title) {
    if (!url || typeof url !== "string") return;
    if (!/^https?:\/\//i.test(url)) return;
    if (!App.setting("saveHistory", true)) return;
    var cleanTitle = String(title || "").trim() || App.shortHost(url) || url;
    var ts = Date.now();
    App.historyStore.update(function (list) {
      if (!Array.isArray(list)) list = [];
      var first = list[0];
      if (first && first.url === url && ts - (first.ts || 0) < 60000) {
        first.ts = ts;
        if (title) first.title = cleanTitle;
        return list;
      }
      list.unshift({ id: uid(), url: url, title: cleanTitle, ts: ts });
      if (list.length > 1000) list.length = 1000;
      return list;
    });
  };

  App.dayLabel = function (key) {
    var todayK = App.todayKey();
    var yest = App.dayKey(Date.now() - DAY);
    if (key === todayK) return "اليوم";
    if (key === yest) return "أمس";
    var parts = String(key).split("-");
    var d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    if (isNaN(d.getTime())) return String(key);
    try { return App.weekdayShort(d.getTime()) + "، " + Kit.util.fmtDate(d.getTime()); }
    catch (e) { return key; }
  };

  // Groups items with a ts field into [{day, label, items}] newest first.
  App.groupByDay = function (list) {
    var arr = Array.isArray(list) ? list.slice() : [];
    arr = arr.filter(function (x) { return x && typeof x === "object"; });
    arr.sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); });
    var groups = [];
    var map = {};
    arr.forEach(function (item) {
      var key = App.dayKey(item.ts || 0);
      if (!map[key]) {
        map[key] = { day: key, label: App.dayLabel(key), items: [] };
        groups.push(map[key]);
      }
      map[key].items.push(item);
    });
    return groups;
  };

  App.fmtBytes = function (n) {
    var v = Number(n) || 0;
    if (v < 1024) return v + " بايت";
    if (v < 1048576) return (v / 1024).toFixed(1) + " ك.ب";
    if (v < 1073741824) return (v / 1048576).toFixed(1) + " م.ب";
    return (v / 1073741824).toFixed(2) + " ج.ب";
  };

  App.fmtSpeed = function (bytesPerSec) {
    var v = Number(bytesPerSec) || 0;
    return App.fmtBytes(Math.round(v)) + "/ث";
  };
})();