(function () {
  "use strict";

  // ---------- Built-in blocklist (ads + trackers) ----------
  var ADS = [
    "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
    "adnxs.com", "adsrvr.org", "advertising.com", "taboola.com", "outbrain.com", "criteo.com",
    "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
    "indexww.com", "smartadserver.com", "adform.net", "amazon-adsystem.com", "media.net",
    "zedo.com", "revcontent.com", "mgid.com", "propellerads.com", "popads.net",
    "popcash.net", "adcash.com", "exoclick.com", "juicyads.com", "trafficjunky.net",
    "adsterra.com", "hilltopads.net", "clickadu.com", "yllix.com", "bidvertiser.com",
    "infolinks.com", "chitika.com", "buysellads.com", "carbonads.net", "adroll.com",
    "yieldmo.com", "sharethrough.com", "triplelift.com", "33across.com", "sovrn.com",
    "lijit.com", "contextweb.com", "spotxchange.com", "spotx.tv", "teads.tv",
    "unrulymedia.com", "inmobi.com", "applovin.com", "unityads.unity3d.com", "vungle.com",
    "chartboost.com", "adcolony.com", "startapp.com", "mopub.com", "smaato.net",
    "adsafeprotected.com", "moatads.com", "doubleverify.com", "serving-sys.com", "adtech.de",
    "yieldlab.net", "adition.com", "adblade.com", "adsnative.com", "zergnet.com",
    "nativo.com", "gumgum.com", "kargo.com", "undertone.com", "conversantmedia.com",
    "emxdgt.com", "districtm.io", "lkqd.net", "springserve.com", "adhigh.net",
    "adspirit.de", "admixer.net", "adriver.ru", "adfox.ru", "360yield.com",
    "bidswitch.net", "adkernel.com", "adzerk.net", "zemanta.com", "plista.com",
    "ligatus.com", "popunder.net", "adskeeper.co.uk", "adsco.re", "a-ads.com",
    "coinzilla.com", "ad-maven.com", "admaven.com", "onclickads.net", "trafficstars.com",
    "richpush.co", "pushame.com", "adition.net", "yieldone.com", "adgear.com"
  ];

  var TRACKERS = [
    "google-analytics.com", "googletagmanager.com", "googletagservices.com", "analytics.google.com",
    "scorecardresearch.com", "quantserve.com", "quantcount.com", "quantcast.com", "hotjar.com",
    "hotjar.io", "mixpanel.com", "mxpnl.com", "segment.io", "amplitude.com",
    "heapanalytics.com", "fullstory.com", "mouseflow.com", "crazyegg.com", "clarity.ms",
    "nr-data.net", "chartbeat.com", "chartbeat.net", "parsely.com", "parse.ly",
    "comscore.com", "krxd.net", "bluekai.com", "demdex.net", "omtrdc.net",
    "2o7.net", "everesttech.net", "exelator.com", "rlcdn.com", "agkn.com",
    "tapad.com", "bounceexchange.com", "mathtag.com", "eyeota.net", "crwdcntrl.net",
    "addthis.com", "sharethis.com", "statcounter.com", "histats.com", "getclicky.com",
    "kissmetrics.com", "appsflyer.com", "adjust.com", "kochava.com", "pixel.facebook.com",
    "connect.facebook.net", "ads.linkedin.com", "analytics.twitter.com", "ads-twitter.com",
    "analytics.tiktok.com", "bat.bing.com", "mc.yandex.ru", "top-fwz1.mail.ru", "counter.yadro.ru",
    "tns-counter.ru", "adobedtm.com", "tealiumiq.com", "tiqcdn.com", "ensighten.com",
    "siteimproveanalytics.com", "matomo.cloud", "inspectlet.com", "luckyorange.com", "smartlook.com",
    "sessioncam.com", "imrworldwide.com", "adsymptotic.com", "ct.pinterest.com", "tr.snapchat.com",
    "events.redditmedia.com", "optimizely.com", "branch.io", "mparticle.com", "braze.com",
    "clicktale.net", "contentsquare.net", "yandex.ru/metrika"
  ];

  var MAP = {};
  var LIST = [];
  function addAll(arr, kind) {
    arr.forEach(function (d) {
      var dom = String(d).toLowerCase().split("/")[0];
      if (!dom || MAP[dom]) return;
      MAP[dom] = kind;
      LIST.push({ domain: dom, kind: kind });
    });
  }
  addAll(ADS, "ad");
  addAll(TRACKERS, "tracker");

  App.BLOCKLIST = LIST;
  App.BLOCKLIST_COUNT = LIST.length;

  App.kindLabel = function (kind) {
    if (kind === "ad") return "إعلانات";
    if (kind === "tracker") return "متتبّع";
    if (kind === "custom") return "قاعدة مخصّصة";
    return "";
  };

  // Stats key matching a block kind (for App.bumpStat).
  App.statKeyForKind = function (kind) {
    return kind === "tracker" ? "trackers" : "ads";
  };

  // ---------- Tracking parameters ----------
  App.TRACKING_PARAMS = [
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id",
    "utm_name", "utm_reader", "utm_brand", "utm_social", "utm_social-type",
    "fbclid", "gclid", "dclid", "gbraid", "wbraid", "gclsrc", "msclkid", "yclid",
    "twclid", "ttclid", "li_fat_id", "igshid", "mc_cid", "mc_eid", "_hsenc", "_hsmi",
    "hsctatracking", "mkt_tok", "oly_anon_id", "oly_enc_id", "vero_id", "vero_conv",
    "rb_clickid", "s_cid", "_ga", "_gl", "srsltid", "spm", "scm", "trk", "trkcampaign",
    "ncid", "cmpid", "zanpid", "epik", "ga_source", "ga_medium", "ga_campaign",
    "__s", "wickedid", "ref_src", "ref_url", "sc_cid", "irclickid", "mbid", "pk_campaign",
    "pk_kwd", "piwik_campaign", "piwik_kwd", "matomo_campaign", "at_campaign", "at_medium"
  ];

  var PARAM_SET = {};
  App.TRACKING_PARAMS.forEach(function (p) { PARAM_SET[p.toLowerCase()] = true; });
  var PARAM_PREFIXES = ["utm_", "pk_", "mtm_", "hsa_"];

  function isTrackingParam(name) {
    var n = String(name || "").toLowerCase();
    if (!n) return false;
    if (PARAM_SET[n]) return true;
    for (var i = 0; i < PARAM_PREFIXES.length; i++) {
      if (n.indexOf(PARAM_PREFIXES[i]) === 0) return true;
    }
    return false;
  }
  App.isTrackingParam = isTrackingParam;

  // Pure: removes tracking parameters. Callers decide based on the "stripParams" setting.
  App.stripTracking = function (url) {
    var out = { url: typeof url === "string" ? url : "", removed: 0, names: [] };
    if (!out.url || out.url.indexOf("?") < 0) return out;
    var u;
    try { u = new URL(out.url); } catch (e) { return out; }
    var names = [];
    try {
      u.searchParams.forEach(function (value, key) {
        if (isTrackingParam(key) && names.indexOf(key) < 0) names.push(key);
      });
    } catch (e) { return out; }
    if (!names.length) return out;
    var removed = 0;
    names.forEach(function (k) {
      var vals = u.searchParams.getAll(k);
      removed += vals.length || 1;
      u.searchParams.delete(k);
    });
    var qs = u.searchParams.toString();
    u.search = qs ? "?" + qs : "";
    var result = u.toString();
    if (!qs) result = result.replace(/\?(?=#|$)/, "");
    out.url = result;
    out.removed = removed;
    out.names = names;
    return out;
  };

  // Applies stripping only if the setting is enabled.
  App.cleanUrl = function (url) {
    if (!App.setting("stripParams", true)) return { url: url, removed: 0, names: [] };
    return App.stripTracking(url);
  };

  // ---------- Domain helpers ----------
  App.normalizeDomain = function (text) {
    var t = String(text == null ? "" : text).trim().toLowerCase();
    if (!t) return "";
    t = t.replace(/^[a-z][a-z0-9+.-]*:\/\//, "");
    t = t.replace(/^\*\./, "");
    t = t.split(/[\/?#]/)[0];
    t = t.replace(/:\d+$/, "");
    t = t.replace(/^www\./, "");
    t = t.replace(/\.$/, "");
    return t;
  };

  var LABEL_RE = /^(?!-)[a-z0-9\u0600-\u06FF-]{1,63}(?<!-)$/;
  App.validDomain = function (text) {
    var d = App.normalizeDomain(text);
    if (!d || d.length > 253 || /\s/.test(d)) return false;
    if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(d)) {
      return d.split(".").every(function (p) { return Number(p) <= 255; });
    }
    var parts = d.split(".");
    if (parts.length < 2) return false;
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p || p.length > 63 || p.charAt(0) === "-" || p.charAt(p.length - 1) === "-") return false;
      if (!/^[a-z0-9\u0600-\u06FF-]+$/.test(p)) return false;
    }
    var tld = parts[parts.length - 1];
    return /^[a-z\u0600-\u06FF]{2,24}$/.test(tld) || /^xn--[a-z0-9-]{2,59}$/.test(tld);
  };
  void LABEL_RE;

  App.domainMatches = function (host, domain) {
    var h = String(host || "").toLowerCase().replace(/\.$/, "");
    var d = App.normalizeDomain(domain);
    if (!h || !d) return false;
    return h === d || (h.length > d.length && h.slice(-(d.length + 1)) === "." + d);
  };

  function hostFrom(input) {
    var s = String(input || "").trim();
    if (!s) return "";
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) return App.hostOf(s);
    return App.normalizeDomain(s);
  }

  function builtinKind(host) {
    var h = String(host || "").toLowerCase().replace(/\.$/, "");
    if (!h) return null;
    var parts = h.split(".");
    for (var i = 0; i < parts.length - 1; i++) {
      var suffix = parts.slice(i).join(".");
      if (Object.prototype.hasOwnProperty.call(MAP, suffix)) return { kind: MAP[suffix], domain: suffix };
    }
    return null;
  }
  App.builtinMatch = builtinKind;

  function rules() {
    var r = null;
    try { r = App.rulesStore.get(); } catch (e) {}
    if (!r || typeof r !== "object") r = {};
    return {
      custom: Array.isArray(r.custom) ? r.custom : [],
      allow: Array.isArray(r.allow) ? r.allow : [],
      builtinEnabled: r.builtinEnabled !== false
    };
  }

  // ---------- Allow once (in memory for this session only) ----------
  App.allowOnceHosts = App.allowOnceHosts || {};
  App.allowOnce = function (urlOrHost) {
    var h = hostFrom(urlOrHost);
    if (h) App.allowOnceHosts[h] = true;
  };
  App.clearAllowOnce = function () { App.allowOnceHosts = {}; };

  App.isAllowed = function (hostOrUrl) {
    var h = hostFrom(hostOrUrl);
    if (!h) return false;
    var list = rules().allow;
    for (var i = 0; i < list.length; i++) {
      var a = list[i];
      if (a && a.domain && App.domainMatches(h, a.domain)) return true;
    }
    return false;
  };

  App.isBlocked = function (url) {
    var res = { blocked: false, reason: "", kind: null, domain: "" };
    var host = hostFrom(url);
    if (!host) return res;
    if (App.allowOnceHosts[host]) return res;
    if (App.isAllowed(host)) return res;

    var r = rules();
    for (var i = 0; i < r.custom.length; i++) {
      var c = r.custom[i];
      if (c && c.enabled !== false && c.domain && App.domainMatches(host, c.domain)) {
        res.blocked = true;
        res.kind = "custom";
        res.domain = App.normalizeDomain(c.domain);
        res.reason = "محظور بقاعدة مخصّصة أضفتها: " + res.domain;
        return res;
      }
    }

    if (!App.setting("adBlock", true) || !r.builtinEnabled) return res;
    var m = builtinKind(host);
    if (m) {
      res.blocked = true;
      res.kind = m.kind;
      res.domain = m.domain;
      res.reason = m.kind === "tracker"
        ? "نطاق تتبّع معروف يجمع بيانات تصفّحك: " + m.domain
        : "نطاق إعلانات معروف: " + m.domain;
    }
    return res;
  };

  // ---------- Rule editing helpers (return an Arabic error message or null) ----------
  App.addCustomRule = function (text) {
    var d = App.normalizeDomain(text);
    if (!d) return "اكتب اسم النطاق أولاً";
    if (!App.validDomain(d)) return "النطاق غير صالح، مثال صحيح: ads.example.com";
    var exists = rules().custom.some(function (c) { return c && App.normalizeDomain(c.domain) === d; });
    if (exists) return "هذا النطاق موجود في قواعدك بالفعل";
    App.rulesStore.update(function (r) {
      if (!r || typeof r !== "object") r = { custom: [], allow: [], builtinEnabled: true };
      if (!Array.isArray(r.custom)) r.custom = [];
      r.custom.unshift({ id: App.uid(), domain: d, enabled: true });
      return r;
    });
    return null;
  };

  App.addAllowDomain = function (text) {
    var d = App.normalizeDomain(text);
    if (!d) return "اكتب اسم النطاق أولاً";
    if (!App.validDomain(d)) return "النطاق غير صالح، مثال صحيح: example.com";
    var exists = rules().allow.some(function (a) { return a && App.normalizeDomain(a.domain) === d; });
    if (exists) return "هذا النطاق موجود في قائمة السماح بالفعل";
    App.rulesStore.update(function (r) {
      if (!r || typeof r !== "object") r = { custom: [], allow: [], builtinEnabled: true };
      if (!Array.isArray(r.allow)) r.allow = [];
      r.allow.unshift({ id: App.uid(), domain: d });
      return r;
    });
    return null;
  };
})();