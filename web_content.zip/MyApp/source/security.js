(function () {
  "use strict";

  // ---------- Reference lists ----------
  var SHORTENERS = [
    "bit.ly", "bitly.com", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "cutt.ly", "rebrand.ly", "shorturl.at", "tiny.cc", "rb.gy", "bit.do", "t.ly", "s.id",
    "v.gd", "lnkd.in", "adf.ly", "shorte.st", "ouo.io", "bc.vc", "soo.gd", "clck.ru",
    "qr.ae", "u.to", "x.co", "trib.al", "dlvr.it", "fb.me", "tr.im", "shrtco.de",
    "short.io", "bl.ink", "linktr.ee", "urlz.fr", "cli.re", "rotf.lol", "tny.im", "po.st"
  ];

  var SUSPICIOUS_TLDS = [
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "work", "click", "loan", "zip", "mov",
    "country", "stream", "download", "racing", "win", "bid", "review", "party", "gdn",
    "men", "kim", "cam", "rest", "monster", "buzz", "icu", "cyou", "sbs"
  ];

  var BRANDS = [
    "paypal", "apple", "icloud", "google", "facebook", "instagram", "whatsapp", "microsoft",
    "outlook", "office365", "amazon", "netflix", "binance", "coinbase", "stcpay", "alrajhi",
    "snb", "emiratesnbd", "aramex", "dhl", "fedex", "steam", "telegram", "tiktok"
  ];

  var LURE_WORDS = ["login", "signin", "verify", "verification", "account", "secure", "update", "wallet", "confirm", "banking", "password", "unlock"];

  var SECOND_LEVEL = ["com", "net", "org", "gov", "edu", "co", "ac", "sch", "med", "mil"];

  var DANGEROUS_EXT = [
    "exe", "msi", "msp", "bat", "cmd", "com", "scr", "pif", "js", "jse", "vbs", "vbe", "vb",
    "wsf", "wsh", "ps1", "psm1", "hta", "jar", "apk", "xapk", "apks", "aab", "dll", "cpl",
    "msc", "reg", "lnk", "sh", "run", "bin", "app", "dmg", "pkg", "deb", "rpm", "gadget",
    "inf", "scf", "appx", "msix", "ipa", "command", "elf"
  ];

  var WARN_EXT = [
    "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso", "img", "vhd", "docm", "xlsm",
    "pptm", "dotm", "xlam", "html", "htm", "svg", "swf", "torrent", "chm", "one"
  ];

  var DECOY_EXT = [
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "jpg", "jpeg", "png",
    "gif", "webp", "mp3", "mp4", "avi", "mkv", "wav", "csv", "odt", "zip", "rar"
  ];

  var EXEC_MIME = [
    "application/x-msdownload", "application/x-msdos-program", "application/x-ms-installer",
    "application/x-msi", "application/vnd.android.package-archive", "application/x-sh",
    "application/x-shellscript", "application/java-archive", "application/x-java-archive",
    "application/x-executable", "application/x-elf", "application/x-bat", "application/hta",
    "application/x-apple-diskimage", "application/vnd.microsoft.portable-executable"
  ];

  function inList(list, v) { return list.indexOf(v) >= 0; }

  App.SCAN_NOTE = "هذا الفحص وقائي يعتمد على قواعد محلية ولا يغني عن برنامج مكافحة فيروسات.";

  // ---------- Punycode decoding (RFC 3492) ----------
  function decodeDigit(cp) {
    if (cp >= 48 && cp < 58) return cp - 22;
    if (cp >= 65 && cp < 91) return cp - 65;
    if (cp >= 97 && cp < 123) return cp - 97;
    return 36;
  }

  function adapt(delta, numPoints, first) {
    var k = 0;
    delta = first ? Math.floor(delta / 700) : delta >> 1;
    delta += Math.floor(delta / numPoints);
    var guard = 0;
    while (delta > 455 && guard++ < 50) { delta = Math.floor(delta / 35); k += 36; }
    return Math.floor(k + (36 * delta) / (delta + 38));
  }

  function punyDecode(input) {
    var output = [], n = 128, i = 0, bias = 72;
    var basic = input.lastIndexOf("-");
    if (basic < 0) basic = 0;
    for (var j = 0; j < basic; j++) {
      var c = input.charCodeAt(j);
      if (c >= 0x80) throw new Error("bad");
      output.push(c);
    }
    var idx = basic > 0 ? basic + 1 : 0;
    var loops = 0;
    while (idx < input.length) {
      if (++loops > 500) throw new Error("bad");
      var oldi = i, w = 1;
      for (var k = 36; ; k += 36) {
        if (idx >= input.length || k > 3600) throw new Error("bad");
        var digit = decodeDigit(input.charCodeAt(idx++));
        if (digit >= 36) throw new Error("bad");
        i += digit * w;
        var t = k <= bias ? 1 : (k >= bias + 26 ? 26 : k - bias);
        if (digit < t) break;
        w *= 36 - t;
      }
      var len = output.length + 1;
      bias = adapt(i - oldi, len, oldi === 0);
      n += Math.floor(i / len);
      i %= len;
      if (n > 0x10FFFF) throw new Error("bad");
      output.splice(i++, 0, n);
    }
    return String.fromCodePoint.apply(null, output);
  }

  // Converts xn-- labels to readable Unicode for display. Returns the input on failure.
  App.decodeHost = function (host) {
    var h = String(host || "");
    if (h.indexOf("xn--") < 0) return h;
    return h.split(".").map(function (label) {
      if (label.toLowerCase().indexOf("xn--") !== 0) return label;
      try { return punyDecode(label.slice(4).toLowerCase()); } catch (e) { return label; }
    }).join(".");
  };

  function scriptsOf(text) {
    var s = { latin: /[a-z]/i.test(text), cyrillic: /[\u0400-\u04FF]/.test(text), greek: /[\u0370-\u03FF]/.test(text), arabic: /[\u0600-\u06FF]/.test(text) };
    var count = 0;
    for (var k in s) if (s[k]) count++;
    s.count = count;
    return s;
  }

  // ---------- Domain helpers ----------
  function baseDomain(host) {
    var parts = String(host || "").split(".").filter(Boolean);
    if (parts.length <= 2) return parts.join(".");
    var sld = parts[parts.length - 2];
    var tld = parts[parts.length - 1];
    if (tld.length === 2 && inList(SECOND_LEVEL, sld)) return parts.slice(-3).join(".");
    return parts.slice(-2).join(".");
  }
  App.baseDomain = baseDomain;

  function isIPv4(h) {
    if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(h)) return false;
    return h.split(".").every(function (p) { return Number(p) <= 255; });
  }
  function isPrivateIPv4(h) {
    return /^(10\.|127\.|192\.168\.|169\.254\.)/.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h);
  }

  function finish(score, items, extra) {
    var s = Math.max(0, Math.min(100, Math.round(score)));
    var risk = s >= 60 ? "danger" : (s >= 25 ? "warn" : "safe");
    var out = { risk: risk, score: s, items: items };
    if (extra) for (var k in extra) out[k] = extra[k];
    return out;
  }

  // ---------- URL safety check ----------
  App.checkUrl = function (input) {
    var items = [];
    var score = 0;
    var raw = String(input == null ? "" : input).trim();
    if (!raw) return finish(0, [{ ok: false, text: "لم يُدخَل أي رابط" }], { url: "", host: "", invalid: true });

    if (/^(javascript|vbscript|data|file):/i.test(raw)) {
      return finish(95, [{ ok: false, text: "رابط بمخطط خطِر قد ينفّذ تعليمات برمجية: " + raw.split(":")[0] }], { url: raw, host: "", invalid: false });
    }

    var full = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : "https://" + raw.replace(/^\/\//, "");
    var u;
    try { u = new URL(full); } catch (e) { u = null; }
    if (!u || !u.hostname) {
      return finish(0, [{ ok: false, text: "صيغة الرابط غير صالحة" }], { url: raw, host: "", invalid: true });
    }

    var proto = u.protocol.toLowerCase();
    var host = u.hostname.toLowerCase().replace(/\.$/, "");
    var bareHost = host.replace(/^\[|\]$/g, "");

    // 1. Encryption
    if (proto === "https:") items.push({ ok: true, text: "الاتصال مشفّر (HTTPS)" });
    else if (proto === "http:") { score += 30; items.push({ ok: false, text: "اتصال غير مشفّر (HTTP) يمكن لأي طرف في الشبكة قراءته أو تعديله" }); }
    else { score += 40; items.push({ ok: false, text: "بروتوكول غير معتاد: " + proto.replace(":", "") }); }

    // 2. Credentials trick (user@host)
    if (u.username || u.password) {
      score += 45;
      items.push({ ok: false, text: "الرابط يحتوي على «@» قبل النطاق، وهي حيلة لإخفاء الموقع الحقيقي" });
    }

    // 3. IP address
    var ipv6 = host.indexOf(":") >= 0 || /^\[/.test(u.host);
    if (isIPv4(bareHost) || ipv6) {
      var priv = isIPv4(bareHost) && isPrivateIPv4(bareHost);
      score += priv ? 15 : 35;
      items.push({ ok: false, text: priv ? "عنوان IP محلي مباشر بدل اسم نطاق" : "عنوان IP مباشر بدل اسم نطاق، وهو شائع في الروابط الاحتيالية" });
    } else {
      items.push({ ok: true, text: "يستخدم اسم نطاق وليس عنوان IP" });
    }

    // 4. Punycode / homograph
    var decoded = App.decodeHost(host);
    if (host.indexOf("xn--") >= 0) {
      var mixed = decoded.split(".").some(function (label) { return scriptsOf(label).count > 1; });
      var sc = scriptsOf(decoded);
      if (mixed) {
        score += 55;
        items.push({ ok: false, text: "نطاق بأحرف مخادعة (punycode) يمزج أبجديات مختلفة: " + decoded });
      } else if (sc.cyrillic || sc.greek) {
        score += 40;
        items.push({ ok: false, text: "نطاق بأحرف مرمّزة (punycode) قد تشبه أحرفاً لاتينية: " + decoded });
      } else {
        score += 15;
        items.push({ ok: false, text: "نطاق بأحرف دولية مرمّزة (punycode): " + decoded + "، تأكّد أنه الموقع المقصود" });
      }
    } else if (!ipv6 && !isIPv4(bareHost)) {
      items.push({ ok: true, text: "لا توجد أحرف مخادعة في النطاق" });
    }

    // 5. Shorteners
    var isShort = SHORTENERS.some(function (d) { return App.domainMatches(host, d); });
    if (isShort) {
      score += 25;
      items.push({ ok: false, text: "رابط مختصر يخفي الوجهة الحقيقية، افتحه بحذر" });
    }

    // 6. Blocklists
    var blk = { blocked: false };
    try { blk = App.isBlocked(u.toString()) || blk; } catch (e) {}
    if (blk.blocked) {
      score += 70;
      items.push({ ok: false, text: "النطاق محظور: " + (blk.reason || blk.domain || host) });
    } else {
      items.push({ ok: true, text: "المصدر غير موجود في قوائم الحظر" });
    }

    // 7. Long / suspicious domain shape
    if (!isIPv4(bareHost) && !ipv6) {
      var labels = host.split(".");
      var hyphens = (host.match(/-/g) || []).length;
      var digits = (host.replace(/[^0-9]/g, "")).length;
      var shapeIssues = [];
      if (host.length > 45) shapeIssues.push("طويل جداً (" + host.length + " حرفاً)");
      if (labels.length >= 5) shapeIssues.push("كثير النطاقات الفرعية");
      if (hyphens >= 4) shapeIssues.push("كثير الشرطات");
      if (digits >= 6 && host.indexOf("xn--") < 0) shapeIssues.push("كثير الأرقام");
      if (shapeIssues.length) {
        score += 15 + 5 * shapeIssues.length;
        items.push({ ok: false, text: "نطاق مشبوه الشكل: " + shapeIssues.join("، ") });
      }

      var tld = labels[labels.length - 1];
      if (inList(SUSPICIOUS_TLDS, tld)) {
        score += 15;
        items.push({ ok: false, text: "امتداد نطاق يكثر استخدامه في الاحتيال: ." + tld });
      }

      // Brand impersonation (brand name outside its real domain)
      var base = baseDomain(host);
      var baseName = base.split(".")[0];
      var brand = null;
      BRANDS.forEach(function (b) {
        if (!brand && host.indexOf(b) >= 0 && baseName !== b) brand = b;
      });
      if (brand) {
        score += 30;
        items.push({ ok: false, text: "يذكر اسم «" + brand + "» لكن النطاق الحقيقي هو " + base + "، وقد يكون انتحالاً" });
      }
    }

    // 8. Non-standard port
    if (u.port && u.port !== "80" && u.port !== "443") {
      score += 10;
      items.push({ ok: false, text: "منفذ غير معتاد: " + u.port });
    }

    // 9. Phishing lure words combined with other signals
    var pathLower = (u.pathname + u.search).toLowerCase();
    var lure = LURE_WORDS.filter(function (w) { return pathLower.indexOf(w) >= 0 || host.indexOf(w) >= 0; });
    if (lure.length && score >= 25) {
      score += 15;
      items.push({ ok: false, text: "يطلب تسجيل دخول أو تحقّق مع إشارات خطر أخرى (" + lure.slice(0, 3).join("، ") + ")" });
    }

    // 10. Tracking parameters (informational)
    var tracking = { removed: 0 };
    try { tracking = App.stripTracking(u.toString()); } catch (e) {}
    if (tracking.removed > 0) {
      score += 5;
      items.push({ ok: false, text: "يحتوي على " + tracking.removed + " من معاملات التتبّع يمكن إزالتها" });
    }

    return finish(score, items, {
      url: u.toString(),
      host: host,
      display: decoded,
      https: proto === "https:",
      shortener: isShort,
      blocked: !!blk.blocked,
      cleanUrl: tracking.url || u.toString(),
      invalid: false
    });
  };

  // ---------- File name helpers ----------
  App.fileNameFromUrl = function (url, fallbackExt) {
    var name = "";
    try {
      var u = new URL(url);
      var seg = u.pathname.split("/").filter(Boolean).pop() || "";
      try { name = decodeURIComponent(seg); } catch (e) { name = seg; }
    } catch (e) {
      var m = String(url || "").split(/[?#]/)[0].split("/").pop();
      name = m || "";
    }
    name = App.sanitizeFileName(name);
    if (!name) name = "download" + (fallbackExt ? "." + fallbackExt : "");
    return name;
  };

  App.fileNameFromDisposition = function (header) {
    var h = String(header || "");
    if (!h) return "";
    var star = h.match(/filename\*\s*=\s*(?:UTF-8|utf-8)?''([^;]+)/);
    if (star) { try { return App.sanitizeFileName(decodeURIComponent(star[1].trim())); } catch (e) {} }
    var plain = h.match(/filename\s*=\s*"?([^";]+)"?/i);
    return plain ? App.sanitizeFileName(plain[1].trim()) : "";
  };

  // Keeps hidden direction characters visible to the scanner but removes path separators.
  App.sanitizeFileName = function (name) {
    return String(name || "").replace(/[\/\\:*?"<>|\u0000-\u001F]/g, "_").trim().slice(0, 180);
  };

  var BIDI_RE = /[\u202A-\u202E\u2066-\u2069\u200E\u200F]/;

  // ---------- File scan before download ----------
  App.scanFile = function (url, name, mime) {
    var items = [];
    var score = 0;
    var fileName = String(name || "") || App.fileNameFromUrl(url);
    var hiddenBidi = BIDI_RE.test(fileName);
    var visible = fileName.replace(/[\u202A-\u202E\u2066-\u2069\u200E\u200F]/g, "");
    var lower = visible.toLowerCase().trim().replace(/[.\s]+$/, "");
    var parts = lower.split(".");
    var ext = parts.length > 1 ? parts[parts.length - 1] : "";
    var prev = parts.length > 2 ? parts[parts.length - 2] : "";
    var mt = String(mime || "").toLowerCase().split(";")[0].trim();

    var executable = inList(DANGEROUS_EXT, ext);
    var doubleExt = false;

    // 1. Source
    var src = App.checkUrl(url);
    if (src.invalid) {
      score += 30;
      items.push({ ok: false, text: "رابط المصدر غير صالح" });
    } else if (src.https) {
      items.push({ ok: true, text: "الاتصال مشفّر (HTTPS)" });
    } else {
      score += 20;
      items.push({ ok: false, text: "اتصال غير مشفّر (HTTP) قد يسمح بتبديل الملف أثناء نقله" });
    }

    // 2. Hidden direction characters
    if (hiddenBidi) {
      score += 70;
      items.push({ ok: false, text: "اسم الملف يحتوي على محارف اتجاه خفية تُخفي امتداده الحقيقي" });
    }

    // 3. Extension
    if (!ext) {
      score += 15;
      items.push({ ok: false, text: "لا يوجد امتداد واضح للملف" });
    } else if (executable) {
      score += 50;
      items.push({ ok: false, text: "ملف تنفيذي (" + ext + ") قد يشغّل برامج ضارة" });
    } else if (inList(WARN_EXT, ext)) {
      score += 20;
      items.push({ ok: false, text: "امتداد يحتاج حذراً (" + ext + ")، قد يحتوي على ملفات أو أكواد مخفية" });
    } else {
      items.push({ ok: true, text: "امتداد الملف آمن: " + ext });
    }

    // 4. Double extension
    if (executable && prev && inList(DECOY_EXT, prev)) {
      doubleExt = true;
      score += 45;
      items.push({ ok: false, text: "امتداد مزدوج مخادع: يبدو " + prev + " لكنه ملف تنفيذي " + ext });
    } else if (ext) {
      items.push({ ok: true, text: "لا يوجد امتداد مزدوج مخادع" });
    }

    // 5. MIME mismatch
    if (mt) {
      var execMime = inList(EXEC_MIME, mt);
      if (execMime && !executable) {
        score += 40;
        executable = true;
        items.push({ ok: false, text: "نوع المحتوى (" + mt + ") يشير إلى ملف تنفيذي بينما الاسم يوحي بغير ذلك" });
      } else if (execMime) {
        items.push({ ok: false, text: "نوع المحتوى يؤكّد أنه ملف تنفيذي" });
      }
    }

    // 6. Blocklists and suspicious source
    if (src.blocked) {
      score += 70;
      items.push({ ok: false, text: "المصدر محظور في قوائم الحظر" });
    } else if (!src.invalid) {
      items.push({ ok: true, text: "المصدر غير موجود في قوائم الحظر" });
    }
    if (!src.invalid && src.risk !== "safe") {
      var extraSignals = (src.items || []).filter(function (it) {
        return !it.ok && !/HTTP|الحظر|محظور|التتبّع/.test(it.text);
      });
      if (extraSignals.length) {
        score += Math.min(30, 10 * extraSignals.length);
        extraSignals.slice(0, 3).forEach(function (it) { items.push({ ok: false, text: "المصدر: " + it.text }); });
      }
    }

    return finish(score, items, {
      name: visible || fileName,
      ext: ext,
      executable: executable,
      doubleExt: doubleExt,
      hiddenChars: hiddenBidi,
      blocked: !!src.blocked,
      https: !!src.https,
      note: App.SCAN_NOTE
    });
  };

  // Whether a scan result should stop the download and ask the user explicitly.
  App.needsConfirmation = function (scan) {
    if (!scan) return false;
    if (scan.risk === "danger" || scan.blocked) return true;
    if (scan.executable && App.setting("blockExecutables", true)) return true;
    return scan.risk === "warn";
  };

  // ---------- Presentation helpers ----------
  App.riskColor = function (risk) {
    if (risk === "danger") return "var(--danger)";
    if (risk === "warn") return "var(--warn, #F5A623)";
    return "var(--ok)";
  };

  App.riskLabel = function (risk) {
    if (risk === "danger") return "خطر";
    if (risk === "warn") return "تحذير";
    return "آمن";
  };

  App.riskIcon = function (risk) {
    if (risk === "danger") return "x";
    if (risk === "warn") return "info";
    return "check";
  };

  App.riskBadge = function (risk, score) {
    var label = App.riskLabel(risk) + (typeof score === "number" ? " · " + score + "/100" : "");
    return Kit.h("span", {
      class: "k-badge barq-risk",
      style: { background: App.riskColor(risk), color: "var(--on-primary)" }
    }, label);
  };
})();