# 4.000 WOCHEN Plus X – Store-Text (Entwurf)

## Kurzbeschreibung
Zeit sichtbar machen. Zeit bewusst machen. Zeit gestalten.

## Vollständige Beschreibung
4.000 WOCHEN Plus X macht die eigene Lebenszeit sichtbar und hilft dabei, persönliche Zeit bewusster zu gestalten.

Die App verbindet einen persönlichen Lebenskalender mit Wochenplanung, heutigen Aufgaben, Zielen, Menschen, Erlebnissen, Gesundheit, Reisen & Träumen, Notizen, Inspiration und weiteren persönlichen Bereichen.

### Funktionen
- Persönliche Startseite
- Lebenskalender „4.000 Wochen“
- Wochenplanung
- Übersicht „Heute“
- Ziele und persönliche Vorhaben
- Menschen und wichtige Beziehungen
- Erlebnisse und persönliche Momente
- Gesundheit
- Reisen & Träume
- Notizen und Tagebuch
- Inspiration
- Persönliche Darstellung mit Foto und Beschriftung
- Erinnerungen und Benachrichtigungen

Die persönlichen Einträge werden in der aktuellen App-Version lokal auf dem Gerät gespeichert. Die App enthält nach der technischen Prüfung keine eigene Internetkommunikation.

## Hinweis
Die Beschreibung muss vor Veröffentlichung noch mit den tatsächlichen finalen Funktionen der Release-Version abgeglichen werden.
