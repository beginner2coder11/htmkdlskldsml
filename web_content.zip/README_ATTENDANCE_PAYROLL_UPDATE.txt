JAS LAUNDRY ROOM - ATTENDANCE & PAYROLL UPDATE

- Weekly Off is manually assigned to the actual date selected by the Owner. No Sunday or weekday is automatically off.
- Monthly Working Days are shown per staff member: calendar days in the selected month minus dates explicitly marked Weekly Off.
- Paid Leave is paid and does not reduce Working Days. Absent is unpaid.
- Required daily Working Hours are independently editable for each staff member and branch.
- Payroll uses the individual staff member's required daily hours to prorate Present / Half Day pay from recorded attendance hours.
- Existing billing, customer, price list, WhatsApp, and cloud-sync source sections are retained.

Please back up app data before replacing the HTML and rebuilding the APK. Verify Attendance, Payroll, and Firebase sync on the target device before using for live payroll.
