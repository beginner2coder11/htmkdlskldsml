package fr.tirage.hasard;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.content.ContentResolver;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_OPEN = 101;
    private static final int REQ_CREATE = 102;
    private WebView web;
    private String pendingCallback;
    private String pendingContent;
    private String pendingName;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, 103);
                return true;
            }
        });
        web.addJavascriptInterface(new AndroidFiles(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    private String js(String value) {
        if (value == null) value = "";
        return org.json.JSONObject.quote(value);
    }
    private void call(String script) { runOnUiThread(() -> web.evaluateJavascript(script, null)); }

    private String displayName(Uri uri) {
        String name = "document.txt";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private String read(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return "";
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    private void write(Uri uri, String content) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("Le fournisseur de fichiers refuse l’écriture.");
            out.write(content.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private class AndroidFiles {
        @JavascriptInterface public void openTextFile(String callback) {
            pendingCallback = callback;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/plain");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_OPEN);
            });
        }
        @JavascriptInterface public void saveTextFile(String uriText, String content, String callback) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(uriText);
                    write(uri, content);
                    call(callback + "(true,'Enregistré')");
                } catch (Exception e) {
                    call(callback + "(false," + js("Échec : " + e.getMessage()) + ")");
                }
            });
        }
        @JavascriptInterface public void createTextFile(String name, String content, String callback) {
            pendingName = name == null || name.isEmpty() ? "document.txt" : name;
            pendingContent = content == null ? "" : content;
            pendingCallback = callback;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TITLE, pendingName);
                startActivityForResult(i, REQ_CREATE);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 103 && fileChooserCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null ? new Uri[]{data.getData()} : null;
            fileChooserCallback.onReceiveValue(result); fileChooserCallback = null; return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_OPEN && pendingCallback != null) call(pendingCallback + "('', '', '')");
            if (requestCode == REQ_CREATE && pendingCallback != null) call(pendingCallback + "(false,'Annulé')");
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_OPEN) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
                catch (Exception ignored) {
                    try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored2) {}
                }
                String content = read(uri);
                String name = displayName(uri);
                call(pendingCallback + "(" + js(name) + "," + js(content) + "," + js(uri.toString()) + ")");
            } else if (requestCode == REQ_CREATE) {
                write(uri, pendingContent);
                String name = displayName(uri);
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) {}
                call(pendingCallback + "(true,'Enregistré'," + js(name) + "," + js(uri.toString()) + ")");
            }
        } catch (Exception e) {
            if (pendingCallback != null) call(pendingCallback + "(false," + js("Erreur : " + e.getMessage()) + ")");
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
