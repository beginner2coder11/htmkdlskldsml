TIRAGE AU HASARD - PROJET ANDROID

Contenu :
- Application Android native minimale qui affiche le fichier HTML intégré hors ligne.
- Pont Android SAF pour ouvrir un TXT et réécrire le document sélectionné.
- Le bouton « Enregistrer sous » utilise le sélecteur Android de création de document.
- Les imports HTML classiques passent par le sélecteur de fichiers Android.

Compilation :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier TirageAuHasardAndroid dans Android Studio.
3. Laisser Gradle synchroniser le projet (plugin Android Gradle 8.7.3).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Installer l'APK généré dans app/build/outputs/apk/debug/.

Important :
- Ce dossier est le projet source Android, pas un APK déjà compilé.
- La compilation nécessite Android SDK et Gradle, non présents dans l'environnement de création.
- Le remplacement direct dépend du fournisseur de fichiers Android choisi (Documents, stockage local, Drive, etc.).
- Pour remplacer un fichier, ouvrir d'abord ce fichier depuis l'application, puis utiliser Enregistrer.
- L'application n'a pas besoin d'autorisation générale de stockage : Android demande l'accès au document choisi.
