from flask import Flask, jsonify, request, render_template

app = Flask(__name__, static_folder='.', static_url_path='')

# Initialize the balance as requested
INITIAL_BALANCE = 1000.00
current_balance = INITIAL_BALANCE

@app.route('/')
def index():
    # Serve the HTML file directly
    return render_template('index.html')

@app.route('/api/balance', methods=['GET'])
def get_balance():
    """Returns the current USDT balance."""
    return jsonify({
        'balance': current_balance,
        'currency': 'USDT'
    })

@app.route('/api/send', methods=['POST'])
def send_usdt():
    """Processes a USDT flash send transaction."""
    global current_balance
    
    data = request.get_json()
    
    if not data:
        return jsonify({'detail': 'No data provided'}), 400
        
    recipient = data.get('recipient')
    amount = data.get('amount')
    
    if not recipient or not amount:
        return jsonify({'detail': 'Missing recipient or amount'}), 400
        
    amount = float(amount)
    
    if amount <= 0:
        return jsonify({'detail': 'Amount must be positive'}), 400
        
    if amount > current_balance:
        return jsonify({'detail': 'Insufficient funds'}), 400
        
    # Simulate transaction processing
    # In a real app, this would interact with the blockchain or a flash minting contract
    try:
        # Deduct balance
        current_balance -= amount
        
        # Return success response
        return jsonify({
            'status': 'success',
            'message': f'Sent {amount} USDT to {recipient}',
            'new_balance': current_balance,
            'transaction_id': f'TX-{hash(recipient + str(amount))[:8].upper()}' # Mock TX ID
        }), 200
        
    except Exception as e:
        return jsonify({'detail': f'Transaction failed: {str(e)}'}), 500

if __name__ == '__main__':
    # Run the server on port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)