
const DB_KEY='afz_v2';
const STORAGE_KEY='afz_v2_local';
const emptyDB={stock:[],products:[],sales:[],customers:[],expenses:[],deliveryDocs:[],credits:[],checks:[],prices:{}};
let db=loadLocal(); if(!Array.isArray(db.products)) db.products=[]; if(!Array.isArray(db.credits)) db.credits=[]; if(!Array.isArray(db.checks)) db.checks=[]; if(!db.prices || Array.isArray(db.prices) || typeof db.prices!=='object') db.prices={}; if(!db.discountPrices || Array.isArray(db.discountPrices) || typeof db.discountPrices!=='object') db.discountPrices={}; syncCatalogLinks();
function el(id){return document.getElementById(id)}
function loadLocal(){try{const x=localStorage.getItem(STORAGE_KEY);return x?JSON.parse(x):structuredClone(emptyDB)}catch(e){return structuredClone(emptyDB)}}
function saveLocal(){localStorage.setItem(STORAGE_KEY,JSON.stringify(db));}
function money(n){return (Number(n)||0).toFixed(2)+' DH'}
function show(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));el(id).classList.add('active');const titles={home:'الرئيسية',stock:'المخزون',products:'المنتوجات',prices:'الأسعار',sales:'المبيعات',customers:'الزبائن',delivery:'وصل التسليم',expenses:'مصاريف اليوم',credit:'الكريدي',checks:'دفتر الشيكات',notifications:'الإشعارات',reports:'التقارير',backup:'نسخة احتياطية'};document.body.classList.toggle('single-section',id!=='home');if(el('sectionTitle'))el('sectionTitle').textContent=titles[id]||'';render()}
async function compressImage(file){if(!file)return '';return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const max=800,scale=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',0.72))};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
async function normalizeProductName(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,' ')}
function getCatalogProduct(id){return (db.products||[]).find(x=>String(x.id)===String(id))||null}
function syncCatalogLinks(){
 if(!Array.isArray(db.products))db.products=[];
 if(!Array.isArray(db.stock))db.stock=[];
 db.stock.forEach(st=>{
   if(st.productId && getCatalogProduct(st.productId)) return;
   const match=db.products.find(x=>normalizeProductName(x.name)===normalizeProductName(st.name));
   if(match) st.productId=match.id;
   else if(st.name){const np={id:Date.now()+Math.floor(Math.random()*100000),name:st.name,image:st.image||''};db.products.push(np);st.productId=np.id;}
 });
}
function renderStockProductOptions(){
 const s=el('stockProduct'); if(!s)return;
 syncCatalogLinks();
 s.innerHTML='<option value="">اختر المنتوج من قسم المنتوجات</option>'+(db.products||[]).map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join('');
}
function fillStockProduct(){
 const p=getCatalogProduct(el('stockProduct')?.value);
 if(!p){if(el('pname'))el('pname').value='';if(el('stockProductPreview'))el('stockProductPreview').innerHTML='';return;}
 el('pname').value=p.name||'';
 if(el('stockProductPreview'))el('stockProductPreview').innerHTML=p.image?`<img src="${p.image}" style="width:70px;height:70px;object-fit:contain;border-radius:10px">`:'🛍️ '+esc(p.name||'');
}
async function addProduct(e){
 e.preventDefault();
 const name=el('productName').value.trim();
 if(!name)return alert('أدخل اسم المنتوج');
 if((db.products||[]).some(x=>normalizeProductName(x.name)===normalizeProductName(name)))return alert('هذا المنتوج موجود بالفعل');
 const image=await compressImage(el('productImage').files[0]);
 db.products.push({id:Date.now()+Math.floor(Math.random()*1000),name,image});
 try{save();e.target.reset();alert('تم حفظ المنتوج بنجاح');}catch(err){alert('تعذر حفظ الصورة. جرّب صورة أصغر.');}
}
function editProduct(id){
 const p=db.products.find(x=>String(x.id)===String(id));if(!p)return;
 const name=prompt('اسم المنتوج:',p.name||'');if(name===null)return;
 if(!name.trim())return alert('أدخل اسم المنتوج');
 p.name=name.trim();
 (db.stock||[]).forEach(st=>{if(String(st.productId)===String(id))st.name=p.name;if(String(st.productId)===String(id)&&p.image)st.image=p.image;});
 (db.sales||[]).forEach(s=>(s.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 (db.deliveryDocs||[]).forEach(d=>(d.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 save();alert('تم تعديل المنتوج بنجاح وتم تحديث الأقسام المرتبطة');
}
function deleteProduct(id){
 const linked=(db.stock||[]).some(x=>String(x.productId)===String(id));
 if(linked){alert('لا يمكن حذف المنتوج لأنه مرتبط بالمخزون. احذف ارتباطه من المخزون أولاً.');return;}
 if(!confirm('حذف هذا المنتوج؟'))return;
 db.products=db.products.filter(x=>String(x.id)!==String(id));delete db.prices[String(id)];save();
}
function renderProducts(){
 const list=el('productsList');if(!list)return;
 const q=(el('productsSearch')?.value||'').trim().toLowerCase();
 const rows=(db.products||[]).filter(p=>!q||String(p.name||'').toLowerCase().includes(q));
 list.innerHTML=rows.length?'<div class="product-grid">'+rows.map(p=>`<div class="product-card">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name)}">`:'<div class="noimg">🛍️</div>'}<h4>${esc(p.name||'')}</h4><div class="product-actions"><button onclick="editProduct(${p.id})">✏️ تعديل</button><button class="danger" onclick="deleteProduct(${p.id})">🗑️ حذف</button></div></div>`).join('')+'</div>':(db.products?.length?'<div class="empty">لا توجد نتائج للبحث</div>':'<div class="empty card">لا توجد منتوجات بعد</div>');
}
async function addStock(e){
 e.preventDefault();
 syncCatalogLinks();
 const productId=el('stockProduct').value;
 const catalog=getCatalogProduct(productId);
 const name=el('pname').value.trim(),ref=el('pref').value.trim();
 const qty=Number(el('pqty').value),buy=Number(el('pbuy').value||0);
 if(!catalog||!name||qty<0)return alert('اختر منتوجاً من قسم المنتوجات وأدخل الكمية');
 const old=db.stock.find(x=>x.productId&&String(x.productId)===String(productId) || (x.ref&&ref&&x.ref===ref));
 if(old){old.productId=catalog.id;old.name=catalog.name;old.qty+=qty;old.buy=buy;if(catalog.image)old.image=catalog.image;}
 else db.stock.push({id:Date.now(),productId:catalog.id,name:catalog.name,ref,qty,buy,image:catalog.image||''});
 try{save();e.target.reset();if(el('stockProductPreview'))el('stockProductPreview').innerHTML='';renderStockProductOptions();alert('تم حفظ القطعة وربطها بالمنتوج')}catch(err){alert('تعذر حفظ المنتج.')}
}
let saleCart=[];
function addToCart(e){
 e.preventDefault();
 const p=db.stock.find(x=>String(x.id)===String(el('saleProduct').value));
 const q=Number(el('saleQty').value), price=Number(el('salePrice').value);
 if(!p)return alert('اختر منتجًا');
 if(q<=0)return alert('الكمية غير صحيحة');
 const already=saleCart.filter(x=>String(x.productId)===String(p.id)).reduce((a,x)=>a+Number(x.qty||0),0);
 if(q+already>Number(p.qty||0))return alert('الكمية المطلوبة أكبر من المخزون المتوفر');
 if(price<0)return alert('السعر غير صحيح');
 const existing=saleCart.find(x=>String(x.productId)===String(p.id)&&Number(x.price)===price);
 if(existing){existing.qty+=q;existing.total=existing.qty*existing.price;existing.profit=(existing.price-existing.buyPrice)*existing.qty;} else saleCart.push({productId:p.id,name:p.name,ref:p.ref||'',qty:q,price:price,buyPrice:Number(p.buy||0),profit:(price-Number(p.buy||0))*q,total:q*price});
 el('saleQty').value='1'; renderCart();
}
function fillCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('saleCustomer').value));
 if(c){el('saleCustomerName').value=c.name||'';el('saleCustomerPhone').value=c.phone||'';}
 else {el('saleCustomerName').value='';el('saleCustomerPhone').value='';}
}
function removeCartItem(i){saleCart.splice(i,1);renderCart()}
function clearCart(){saleCart=[];renderCart()}
function renderCart(){
 const box=el('cartBox');
 if(!box)return;
 if(!saleCart.length){box.innerHTML='<div class="empty card">لم تتم إضافة منتجات إلى الفاتورة بعد.</div>';return;}
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 box.innerHTML='<div class="cart"><div class="badge">'+saleCart.length+' منتجات/أسطر</div><table><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>المجموع</th><th></th></tr>'+saleCart.map((x,i)=>'<tr><td>'+esc(x.name)+(x.ref?'<div class="small">'+esc(x.ref)+'</div>':'')+'</td><td>'+x.qty+'</td><td>'+money(x.price)+'</td><td>'+money(x.total)+'</td><td><button class="remove" onclick="removeCartItem('+i+')">حذف</button></td></tr>').join('')+'</table><div class="cart-total"><span>المجموع النهائي</span><span>'+money(total)+'</span></div></div>';
}
function finalizeSale(){
 if(!saleCart.length)return alert('أضف منتجًا واحدًا على الأقل');
 for(const item of saleCart){const p=db.stock.find(x=>String(x.id)===String(item.productId));if(!p||Number(item.qty)>Number(p.qty||0))return alert('المخزون غير كافٍ للمنتج: '+item.name);}
 const customerName=el('saleCustomerName').value.trim()||'زبون عابر';
 const customerPhone=el('saleCustomerPhone').value.trim();
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 saleCart.forEach(item=>{const p=db.stock.find(x=>String(x.id)===String(item.productId));p.qty-=Number(item.qty);});
 db.sales.push({id:Date.now(),date:new Date().toISOString(),customer:{name:customerName,phone:customerPhone},items:saleCart.map(x=>({...x})),total});
 save(); saleCart=[]; if(el('saleCustomer'))el('saleCustomer').value=''; if(el('saleCustomerName'))el('saleCustomerName').value=''; if(el('saleCustomerPhone'))el('saleCustomerPhone').value=''; if(el('saleQty'))el('saleQty').value='1'; renderCart(); alert('تم حفظ البيع بنجاح');
}
function saleItems(s){
 if(Array.isArray(s.items)) return s.items;
 if(s.name) return [{name:s.name,ref:s.ref||'',qty:s.qty||0,price:s.price||0,total:s.total||0}];
 return [];
}
function downloadLastSalePdf(){
 if(!db.sales.length){alert('لا توجد مبيعات لتحميلها');return;}
 const x=db.sales[db.sales.length-1],items=saleItems(x),customer=x.customer||{},date=x.date||new Date().toLocaleString('ar-MA'),total=Number(x.total||0);
 const rows=items.map((it,i)=>`<tr><td class="num">${i+1}</td><td>${esc(it.name||it.productName||'')}</td><td class="num">${Number(it.qty||it.quantity||1)}</td><td class="money">${money(it.price||it.salePrice||0)}</td><td class="money">${money((it.qty||it.quantity||1)*(it.price||it.salePrice||0))}</td></tr>`).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:24px 28px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:23px}.title div{margin-top:5px;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:12px;padding:12px;background:#fff}.customer-box{border:1.5px solid #0b4f8a;background:linear-gradient(180deg,#f7fbff 0%,#fff 100%)}.customer-head{display:flex;align-items:center;gap:7px;border-bottom:1px solid #dfe6ec;padding-bottom:7px;margin-bottom:8px;font-size:12px;font-weight:bold;color:#0b4f8a}.customer-icon{width:24px;height:24px;border-radius:50%;background:#0b4f8a;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:13px}.customer-name{font-size:17px;font-weight:700;line-height:1.35;margin-bottom:8px}.customer-row{font-size:12px;line-height:1.7;color:#33424f;margin-top:3px;word-break:break-word}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div>الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br>AFRIQUIA FREINS ZEMAMRA</div></div>
</body></html>`;
 const name='Facture-'+formatDeliveryNumber(x.deliveryNumber||x.id||Date.now())+'.pdf'; if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function') AndroidPrint.savePdf(html,name); else {localStorage.setItem('__afriquia_pdf_html',html); location.href='afriquia://savepdf?name='+encodeURIComponent(name);}
}

function deliveryItemsTotal(items){return (items||[]).reduce((a,i)=>a+Number(i.total||Number(i.qty||1)*Number(i.price||0)),0)}
let currentDeliveryId=null;
let deliveryDraftItems=[];
function nextDeliveryNumber(){
 const docs=Array.isArray(db.deliveryDocs)?db.deliveryDocs:[];
 let max=0;
 docs.forEach(d=>{const n=String(d.deliveryNumber||'').match(/\d+/);if(n)max=Math.max(max,Number(n[0])||0);});
 return 'B'+String(max+1).padStart(4,'0');
}
function formatDeliveryNumber(value){
 const m=String(value||'').match(/\d+/);
 if(!m)return nextDeliveryNumber();
 return 'B'+String(Number(m[0])||0).padStart(4,'0');
}
function ensureDeliveryNumber(){
 const input=el('deliveryNumber');
 if(input && !currentDeliveryId && !String(input.value||'').trim()) input.value=nextDeliveryNumber();
}

function refreshDeliveryCustomers(selectedId=''){const s=el('deliveryCustomerSelect');if(!s)return;const customers=Array.isArray(db.customers)?db.customers:[];s.innerHTML='<option value="">اختر الزبون من قسم الزبائن</option>'+customers.map(c=>`<option value="${esc(String(c.id))}">${esc(c.name)}${c.phone?' — '+esc(c.phone):''}</option>`).join('');if(selectedId!==undefined)s.value=String(selectedId||'');}
function selectDeliveryCustomer(){const id=el('deliveryCustomerSelect')?.value;if(!id)return;const c=(db.customers||[]).find(x=>String(x.id)===String(id));if(!c)return;el('deliveryCustomerName').value=c.name||'';el('deliveryCustomerPhone').value=c.phone||'';}
function resetIndependentDelivery(){currentDeliveryId=null;deliveryDraftItems=[];if(el('deliveryCustomerSelect'))el('deliveryCustomerSelect').value='';if(el('deliveryCustomerName'))el('deliveryCustomerName').value='';if(el('deliveryCustomerPhone'))el('deliveryCustomerPhone').value='';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value='';if(el('deliveryNumber'))el('deliveryNumber').value='';if(el('deliveryDate')){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16)}renderDeliveryEditor();ensureDeliveryNumber()}
function renderDeliveryEditor(){
 syncCatalogLinks();
 refreshDeliveryCustomers(el('deliveryCustomerSelect')?.value||'');
 if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];
 ensureDeliveryNumber();
 if(el('deliveryDate') && !el('deliveryDate').value){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16);}
 const select=el('deliveryProduct');
 if(select){select.innerHTML='<option value="">اختر منتجاً من المخزون</option>'+db.stock.map(p=>`<option value="${p.id}">${esc(p.name||'')} ${p.ref?'— '+esc(p.ref):''}</option>`).join('');}
 const box=el('deliveryItemsEditor'); if(box){const items=deliveryDraftItems;const total=deliveryItemsTotal(items);box.innerHTML='<h4 style="margin-top:0">منتجات الوصل</h4>'+(!items.length?'<div class="empty">لم تتم إضافة منتجات بعد</div>':'<table><tr><th>اسم</th><th>عدد</th><th>ثمن</th><th>المجموع</th><th></th></tr>'+items.map((i,n)=>`<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.price)}</td><td>${money(i.total)}</td><td><button type="button" class="remove" onclick="removeDeliveryItem(${n})">حذف</button></td></tr>`).join('')+'</table><div class="cart-total"><span>المجموع</span><b>'+money(total)+'</b></div>');}
 const list=el('deliveryList'); if(list){list.innerHTML='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3>الوصول المستقلة المحفوظة</h3><button type="button" onclick="resetIndependentDelivery()">➕ وصل جديد</button></div>'+(!db.deliveryDocs.length?'<div class="empty">لا توجد وصول محفوظة</div>':'<table><tr><th>رقم الوصل</th><th>الزبون</th><th>العنوان</th><th>التاريخ</th><th>المجموع</th><th></th></tr>'+db.deliveryDocs.slice().reverse().map(d=>`<tr><td>${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</td><td>${esc(d.customerName||'زبون عابر')}</td><td>${esc(d.customerAddress||'')}</td><td>${d.date?esc(new Date(d.date).toLocaleDateString('ar-MA')):'-'}</td><td>${money(deliveryItemsTotal(d.items))}</td><td><button type="button" onclick="editIndependentDelivery('${d.id}')">تحرير</button> <button type="button" onclick="previewIndependentDelivery('${d.id}')">👁️ معاينة</button> <button type="button" onclick="downloadIndependentDeliveryPdf('${d.id}')">⚡ PDF سريع</button></td></tr>`).join('')+'</table>')+'</div>';}}
function addDeliveryItem(){const sel=el('deliveryProduct');const p=sel?.value?db.stock.find(x=>String(x.id)===String(sel.value)):null;const name=(el('deliveryProductName').value||p?.name||'').trim();const qty=Number(el('deliveryProductQty').value||0);const price=Number(el('deliveryProductPrice').value||0);if(!name)return alert('أدخل اسم المنتج');if(qty<=0)return alert('أدخل العدد');if(price<0)return alert('الثمن غير صحيح');deliveryDraftItems.push({productId:p?.productId||'',name,ref:p?.ref||'',qty,price,total:qty*price});el('deliveryProductName').value='';el('deliveryProductQty').value='1';el('deliveryProductPrice').value='';if(sel)sel.value='';renderDeliveryEditor()}
function removeDeliveryItem(i){deliveryDraftItems.splice(i,1);renderDeliveryEditor()}
function saveIndependentDelivery(e){e.preventDefault();if(!deliveryDraftItems.length)return alert('أضف منتجاً واحداً على الأقل');if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];const doc={id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerId:el('deliveryCustomerSelect')?.value||'',customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x})),total:deliveryItemsTotal(deliveryDraftItems)};const idx=db.deliveryDocs.findIndex(x=>String(x.id)===String(doc.id));if(idx>=0)db.deliveryDocs[idx]=doc;else db.deliveryDocs.push(doc);saveLocal();alert('تم حفظ وصل التسليم بشكل مستقل عن المبيعات');resetIndependentDelivery()}
function editIndependentDelivery(id){const d=db.deliveryDocs.find(x=>String(x.id)===String(id));if(!d)return;currentDeliveryId=d.id;deliveryDraftItems=(d.items||[]).map(x=>({...x}));refreshDeliveryCustomers(d.customerId||'');el('deliveryCustomerName').value=d.customerName||'';el('deliveryCustomerPhone').value=d.customerPhone||'';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value=d.customerAddress||'';if(el('deliveryNumber'))el('deliveryNumber').value=formatDeliveryNumber(d.deliveryNumber||d.id||'');const dt=new Date(d.date);if(!Number.isNaN(dt.getTime()))el('deliveryDate').value=new Date(dt.getTime()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);renderDeliveryEditor()}
function independentDeliveryHtml(d){
 const isFr=localStorage.getItem('afz_lang')==='fr';
 const L=isFr?{
   dir:'ltr',phone:'Téléphone : 0667668693',address:'Adresse : Zone industrielle, Zemamra',title:'Bon de livraison',number:'N° du bon :',customer:'Client',customerPhone:'TEl:',customerAddress:'Adresse :',date:'Date',product:'Nom du produit',qty:'Quantité',price:'Prix',total:'Total',grand:'Total final',thanks:'Les produits mentionnés ci-dessus ont été livrés',pass:'Client de passage'
 }:{
   dir:'rtl',phone:'الهاتف: 0667668693',address:'العنوان: الحي الصناعي الزمامرة',title:'وصل التسليم',number:'رقم الوصل:',customer:'الزبون',customerPhone:'الهاتف:',customerAddress:'العنوان:',date:'التاريخ',product:'اسم المنتج',qty:'العدد',price:'الثمن',total:'المجموع',grand:'المجموع النهائي',thanks:'تم تسليم المنتجات المذكورة أعلاه',pass:'زبون عابر'
 };
 const items=d.items||[];
 const rows=items.map(i=>`<tr><td>${esc(i.name)}</td><td class="num">${Number(i.qty||0)}</td><td class="money">${money(i.price)}</td><td class="money">${money(Number(i.total||Number(i.qty||0)*Number(i.price||0)))}</td></tr>`).join('');
 const dateText=d.date?esc(new Date(d.date).toLocaleString(isFr?'fr-MA':'ar-MA')):'-';
 return `<!doctype html><html lang="${isFr?'fr':'ar'}" dir="${L.dir}"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;direction:${L.dir}}.note{width:100%;padding:24px 28px}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:${isFr?'right':'left'};white-space:nowrap}.summary{margin-top:16px;margin-${isFr?'left':'right'}:auto;width:300px}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;padding-top:8px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}</style></head><body><div class="note"><div style="display:block;text-align:center;border-bottom:3px solid #0b4f8a;padding-bottom:12px"><div style="display:block"><img class="logo" src="logo.png" style="display:block;margin:0 auto 6px"><div><h1 style="font-size:22px;margin:0">AFRIQUIA FREINS ZEMAMRA</h1><p style="font-size:13px;margin:4px 0;font-weight:bold">${L.phone}</p><p style="font-size:13px;margin:4px 0">${L.address}</p></div></div><div style="margin-top:10px"><h2 style="margin:0;font-size:23px">${L.title}</h2><div style="margin-top:4px;font-size:12px">${L.number} ${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</div></div></div><div class="info"><div class="box customer-box"><div class="customer-head"><span class="customer-icon">👤</span><span>${L.customer}</span></div><div class="customer-name">${esc(d.customerName||L.pass)}</div>${d.customerPhone?'<div class="customer-row">📞 '+L.customerPhone+' '+esc(d.customerPhone)+'</div>':'<div class="customer-row" style="color:#8a959e">📞 '+(isFr?'TEl: non renseigné':'TEl: غير مسجل')+'</div>'}${d.customerAddress?'<div class="customer-row">📍 '+L.customerAddress+' '+esc(d.customerAddress)+'</div>':'<div class="customer-row" style="color:#8a959e">📍 '+(isFr?'Adresse non renseignée':'العنوان غير مسجل')+'</div>'}</div><div class="box"><div class="label">${L.date}</div><div class="value">${dateText}</div></div></div><table class="table"><tr><th>${L.product}</th><th>${L.qty}</th><th>${L.price}</th><th>${L.total}</th></tr>${rows}</table><div class="summary"><div class="grand"><span>${L.grand}</span> <b>${money(deliveryItemsTotal(items))}</b></div></div><div class="thanks">${L.thanks}<br>${L.phone} | ${L.address}</div></div></body></html>`;
}
function getCurrentDeliveryData(id){const saved=id?db.deliveryDocs.find(x=>String(x.id)===String(id)):null;return saved||({id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x}))});}
function previewIndependentDelivery(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);let modal=el('deliveryPreviewModal');if(!modal){modal=document.createElement('div');modal.id='deliveryPreviewModal';modal.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99999;display:flex;flex-direction:column;padding:10px';document.body.appendChild(modal);}modal.innerHTML='<div style="background:#fff;border-radius:12px;padding:8px;display:flex;gap:8px;align-items:center;justify-content:space-between"><b>👁️ معاينة وصل التسليم</b><div><button type="button" onclick="downloadIndependentDeliveryPdf()">⚡ طباعة PDF</button><button type="button" class="outline" onclick="closeDeliveryPreview()">✕ إغلاق</button></div></div><iframe title="معاينة وصل التسليم" style="flex:1;width:100%;border:0;border-radius:8px;margin-top:8px;background:#fff"></iframe>';modal.style.display='flex';const frame=modal.querySelector('iframe');frame.srcdoc=html;}
function closeDeliveryPreview(){const m=el('deliveryPreviewModal');if(m)m.style.display='none';}
function downloadIndependentDeliveryPdf(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);const name='Bon-de-livraison-'+String(d.id||Date.now())+'.pdf';try{if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function'){AndroidPrint.savePdf(html,name);return;}localStorage.setItem('__afriquia_pdf_html',html);localStorage.setItem('__afriquia_pdf_name',name);location.href='afriquia://savepdf';}catch(e){alert('تعذر إنشاء PDF: '+e.message)}}
function downloadSelectedDeliveryPdf(){downloadIndependentDeliveryPdf(currentDeliveryId)}


function printLastSaleThermal(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:10px;margin-right:auto;width:65%}.sumrow{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #ccc;font-size:9px}.grand{font-size:13px;font-weight:bold;border-top:2px solid #111}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>#${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج / المرجع</th><th>كم</th><th>الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Afriquia Thermal Invoice '+String(x.id||'')); else alert('الطباعة الحرارية متاحة داخل تطبيق Android.');
}
function printLastDeliveryNote(){
 if(!db.sales.length){alert('لا توجد مبيعات لإنشاء وصل التسليم');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const rows=items.map((i,n)=>{const qty=Number(i.qty||i.quantity||1),price=Number(i.price||i.salePrice||0),lineTotal=Number(i.total||qty*price);return '<tr><td><b>'+esc(i.name)+'</b></td><td class="num">'+qty+'</td><td class="money">'+money(price)+'</td><td class="money">'+money(lineTotal)+'</td></tr>';}).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.note{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.contact{margin-top:8px;text-align:center;font-size:9px;font-weight:bold}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}</style></head><body><div class="note"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p></div></div><div class="title"><h2>وصل التسليم</h2><div>رقم الوصل: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="contact">الهاتف: 0667668693 — العنوان: الحي الصناعي الزمامرة</div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">هاتف الزبون: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>المنتج</th><th>العدد</th><th>الثمن</th><th>المجموع</th></tr>${rows}</table><div class="thanks">تم تسليم المنتجات المذكورة أعلاه<br><span class="small">الهاتف: 0667668693 | الحي الصناعي الزمامرة</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Bon de livraison '+String(x.id||'')); else if(window.AndroidPrint&&AndroidPrint.printHtml) AndroidPrint.printHtml(html,'Bon de livraison '+String(x.id||'')); else {const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function printLastSale(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff} .invoice{max-width:760px;margin:auto;padding:24px 28px} .head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{font-size:22px;margin:0;color:#0b4f8a}.brand p{margin:5px 0 0;color:#687784;font-size:12px}.title{text-align:left}.title h2{margin:0;font-size:23px;color:#17212b}.title div{margin-top:5px;color:#687784;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e;margin-bottom:4px}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;color:#0b4f8a;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px;color:#687784}.small{font-size:10px;color:#77838e}@page{size:A4;margin:8mm}@media print{.invoice{padding:0}}
</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا ❤️<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.printHtml)AndroidPrint.printHtml(html,'Afriquia Stock - Invoice '+String(x.id||''));else{const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function pickCustomerContact(){
 try{
   if(window.AndroidPrint && AndroidPrint.pickCustomerContact){
     AndroidPrint.pickCustomerContact();
   }else{
     alert('اختيار جهات الاتصال متاح داخل تطبيق Android فقط');
   }
 }catch(err){alert('تعذر فتح جهات الاتصال');}
}
function setCustomerFromContact(name,phone){
 el('custName').value=name||'';
 el('custPhone').value=phone||'';
 el('custName').focus();
}
function addCustomer(e){e.preventDefault();const name=el('custName').value.trim(),phone=el('custPhone').value.trim();if(!name)return;db.customers.push({id:Date.now(),name,phone});save();e.target.reset();alert('تم حفظ الزبون');}
function addExpense(e){e.preventDefault();const name=el('expName').value.trim(),amount=Number(el('expAmount').value);if(!name||amount<0)return;db.expenses.push({date:new Date().toISOString(),name,amount});save();e.target.reset();alert('تم حفظ المصروف');}
function editStock(id){
 const p=db.stock.find(x=>x.id===id); if(!p)return;
 const name=prompt('اسم القطعة:',p.name); if(name===null)return;
 const ref=prompt('المرجع / Référence:',p.ref||''); if(ref===null)return;
 const qty=prompt('الكمية:',p.qty); if(qty===null)return;
 const buy=prompt('ثمن الشراء DH:',p.buy||0); if(buy===null)return;
 if(!name.trim()||Number(qty)<0||Number(buy)<0){alert('بيانات غير صحيحة');return}
 p.name=name.trim(); p.ref=ref.trim(); p.qty=Number(qty); p.buy=Number(buy);
 save(); alert('تم تعديل المنتج بنجاح');
}
function deleteStock(id){if(confirm('حذف هذا المنتج من المخزون؟')){db.stock=db.stock.filter(x=>x.id!==id);delete db.prices[String(id)];save()}}
function saveProductPrices(id){
 const input=el('price_'+id);
 if(!input)return;
 const value=Number(input.value);
 if(!Number.isFinite(value)||value<0){alert('أدخل ثمناً صحيحاً');return;}
 db.prices[String(id)]=value;
 const linked=(db.stock||[]).find(x=>String(x.productId)===String(id));
 if(linked) linked.salePrice=value;
 save();
 alert('تم حفظ سعر المنتوج');
}
function getProductStock(id){
 return (db.stock||[]).find(x=>String(x.productId)===String(id))||null;
}
function getProductPrice(id){
 const v=db.prices[String(id)];
 if(v!==undefined && Number.isFinite(Number(v))) return Number(v);
 const st=getProductStock(id);
 if(st && db.prices[String(st.id)]!==undefined) return Number(db.prices[String(st.id)]);
 return st && st.salePrice!==undefined ? Number(st.salePrice) : 0;
}
function renderPrices(){
 syncCatalogLinks();
 const input=el('priceSearch'), result=el('pricesResult');
 if(!input||!result)return;
 const q=(input.value||'').trim().toLowerCase();
 const products=Array.isArray(db.products)?db.products:[];
 const rows=products.filter(p=>{
   const st=getProductStock(p.id);
   return !q || String(p.name||'').toLowerCase().includes(q) || String(st?.ref||'').toLowerCase().includes(q);
 });
 if(!products.length){result.innerHTML='<div class="empty">لا توجد منتوجات. أضف المنتوج أولاً من قسم المنتوجات.</div>';return;}
 if(!rows.length){result.innerHTML='<div class="empty">لا توجد نتائج للبحث</div>';return;}
 result.innerHTML='<div class="product-grid">'+rows.map(p=>{
   const st=getProductStock(p.id), price=getProductPrice(p.id), buy=Number(st?.buy||0), ref=st?.ref||'-';
   return `<div class="product-card" style="text-align:center">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name||'')}">`:'<div class="noimg">🛍️</div>'}<h4>${esc(p.name||'')}</h4><div class="meta">المرجع: ${esc(ref)}</div><div class="meta">ثمن الشراء: <b>${money(buy)}</b></div><label class="small" style="display:block;margin-top:8px">ثمن البيع DH</label><input id="price_${esc(String(p.id))}" type="number" min="0" step="0.01" value="${price}" style="width:100%;box-sizing:border-box"><button type="button" onclick="saveProductPrices('${esc(String(p.id))}')" style="margin-top:8px">💾 حفظ السعر</button></div>`;
 }).join('')+'</div>';
}

function exportBackup(){try{const payload={version:3,exportedAt:new Date().toISOString(),stock:Array.isArray(db.stock)?db.stock:[],products:Array.isArray(db.products)?db.products:[],sales:Array.isArray(db.sales)?db.sales:[],customers:Array.isArray(db.customers)?db.customers:[],expenses:Array.isArray(db.expenses)?db.expenses:[],deliveryDocs:Array.isArray(db.deliveryDocs)?db.deliveryDocs:[],credits:Array.isArray(db.credits)?db.credits:[],checks:Array.isArray(db.checks)?db.checks:[],prices:db.prices||{},discountPrices:db.discountPrices||{}};const json=JSON.stringify(payload,null,2);if(window.AndroidBackup&&typeof AndroidBackup.exportBackup==='function'){AndroidBackup.exportBackup(json);return}const blob=new Blob([json],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AFRIQUIA-BACKUP-'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);alert('تم تصدير النسخة الاحتياطية بنجاح')}catch(e){alert('تعذر تصدير البيانات: '+e.message)}}
function importBackup(file){const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x||!Array.isArray(x.stock)||!Array.isArray(x.sales)||!Array.isArray(x.customers))throw 0;if(!confirm('سيتم استبدال البيانات الحالية بالنسخة الاحتياطية. هل تريد المتابعة؟'))return;db={stock:x.stock||[],products:x.products||[],sales:x.sales||[],customers:x.customers||[],expenses:x.expenses||[],deliveryDocs:x.deliveryDocs||[],credits:x.credits||[],checks:x.checks||[],prices:x.prices||{},discountPrices:x.discountPrices||{}};save();alert('تم استرجاع البيانات بنجاح')}catch(e){alert('ملف النسخة الاحتياطية غير صالح')}};r.onerror=()=>alert('تعذر قراءة ملف النسخة الاحتياطية');r.readAsText(file)}
function save(){saveLocal();try{if(window.AndroidNotifications&&typeof AndroidNotifications.syncChecks==='function')AndroidNotifications.syncChecks(JSON.stringify(db.checks||[]));}catch(e){}render()}
function clearSalesFilters(){if(el('salesSearch'))el('salesSearch').value='';if(el('salesPeriod'))el('salesPeriod').value='all';if(el('salesCustomerSearch'))el('salesCustomerSearch').value='';render();}
function saleItemProfit(item){
 const qty=Number(item.qty||item.quantity||1), price=Number(item.price||item.salePrice||0);
 let buy=Number(item.buyPrice);
 if(!Number.isFinite(buy)) { const p=db.stock.find(x=>String(x.id)===String(item.productId)); buy=Number(p?.buy||0); }
 return (price-buy)*qty;
}
function addQuickSale(){
 const ref=(el('quickSaleRef')?.value||'').trim();
 const qty=Number(el('quickSaleQty')?.value||0);
 let price=Number(el('quickSalePrice')?.value||0);
 if(!ref)return alert('أدخل رقم المنتج');
 if(qty<=0 || !Number.isInteger(qty))return alert('أدخل كمية صحيحة');
 const p=db.stock.find(x=>String(x.ref||'').trim()===ref);
 if(!p)return alert('رقم المنتج غير موجود في المخزون');
 if(!el('quickSalePrice').value){ const linkedPrice=db.prices[String(p.productId)]; const legacyPrice=db.prices[String(p.id)]; if(linkedPrice!==undefined) el('quickSalePrice').value=linkedPrice; else if(legacyPrice!==undefined) el('quickSalePrice').value=legacyPrice; }
 const available=Number(p.qty||0);
 if(qty>available)return alert('الكمية المطلوبة أكبر من المخزون المتوفر: '+available);
 if(!Number.isFinite(price) || price<=0)return alert('أدخل ثمن البيع');
 const buy=Number(p.buy||0);
 const total=qty*price;
 const profit=(price-buy)*qty;
 p.qty=available-qty;
 db.sales.push({id:Date.now()+Math.floor(Math.random()*1000),date:new Date().toISOString(),customer:{name:'زبون عابر',phone:''},items:[{productId:p.id,name:p.name||'',ref:p.ref||ref,qty,price,buyPrice:buy,total,profit,remainingQty:p.qty}],total});
 save();
 if(el('quickSaleRef'))el('quickSaleRef').value='';
 if(el('quickSaleQty'))el('quickSaleQty').value='1';
 if(el('quickSalePrice'))el('quickSalePrice').value='';
 render();
 alert('تم تسجيل البيع. المتبقي في المخزون: '+p.qty+' قطعة');
}
function dailySalesData(){
 const map={};
 for(const s of db.sales){
  const d=new Date(s.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  const row=map[key]; row.ops+=1; row.revenue+=Number(s.total||0); row.profit+=saleProfit(s);
  row.qty+=saleItems(s).reduce((a,i)=>a+Number(i.qty||i.quantity||1),0);
 }
 for(const e of db.expenses){
  const d=new Date(e.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  map[key].expenses+=Number(e.amount||0);
 }
 return Object.values(map).sort((a,b)=>b.date.localeCompare(a.date));
}
function saleItemTotal(item){return Number(item.total||((Number(item.qty||item.quantity||1))*Number(item.price||item.salePrice||0)));}
function saleProfit(s){return saleItems(s).reduce((a,i)=>a+saleItemProfit(i),0)}
function saleMatchesFilters(s){
 const term=(el('salesSearch')?.value||'').trim().toLowerCase();
 const customerTerm=(el('salesCustomerSearch')?.value||'').trim().toLowerCase();
 const period=el('salesPeriod')?.value||'all';
 const items=saleItems(s);
 if(term && !items.some(i=>String(i.name||i.productName||'').toLowerCase().includes(term)||String(i.ref||'').toLowerCase().includes(term))) return false;
 const c=s.customer||{}; if(customerTerm && !String(c.name||'').toLowerCase().includes(customerTerm)) return false;
 if(period!=='all'){const d=new Date(s.date||0), now=new Date(); if(Number.isNaN(d.getTime())) return false; if(period==='day' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth()||d.getDate()!==now.getDate())) return false; if(period==='month' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth())) return false; if(period==='year' && d.getFullYear()!==now.getFullYear()) return false;}
 return true;
}
function fillCreditCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('creditCustomer')?.value||''));
 if(c){if(el('creditCustomerName'))el('creditCustomerName').value=c.name||'';if(el('creditPhone'))el('creditPhone').value=c.phone||'';}
}
function addCredit(e){
 e.preventDefault();
 const name=(el('creditCustomerName')?.value||'').trim();
 const phone=(el('creditPhone')?.value||'').trim();
 const amount=Number(el('creditAmount')?.value||0);
 if(!name)return alert('أدخل اسم الزبون');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 if(!Array.isArray(db.credits))db.credits=[];
 const customerId=el('creditCustomer')?.value||'';
 db.credits.push({id:Date.now()+Math.floor(Math.random()*1000),customerId,customerName:name,phone,date:new Date(el('creditDate')?.value||Date.now()).toISOString(),amount,note:(el('creditNote')?.value||'').trim(),paid:false});
 save(); e.target.reset(); if(el('creditDate'))el('creditDate').value=''; alert('تم تسجيل الكريدي بنجاح');
}
function markCreditPaid(id){
 const c=db.credits.find(x=>String(x.id)===String(id)); if(!c)return;
 c.paid=true; c.paidDate=new Date().toISOString(); save();
}
function deleteCredit(id){
 if(!confirm('هل تريد حذف هذا الكريدي؟'))return;
 db.credits=db.credits.filter(x=>String(x.id)!==String(id)); save();
}
function addCheck(e){
 e.preventDefault();
 if(!Array.isArray(db.checks))db.checks=[];
 const number=(el('checkNumber')?.value||'').trim();
 const beneficiary=(el('checkBeneficiary')?.value||'').trim();
 const amount=Number(el('checkAmount')?.value||0);
 if(!number)return alert('أدخل رقم الشيك');
 if(!beneficiary)return alert('أدخل اسم المستفيد');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 const date=el('checkDate')?.value||new Date().toISOString().slice(0,10);
 if((db.checks||[]).some(c=>String(c.date||'')===date)){
   return alert('غير مسموح: يوجد شيك مسجل مسبقاً في نفس التاريخ. يمكن تسجيل شيك واحد فقط في كل تاريخ.');
 }
 db.checks.push({id:Date.now()+Math.floor(Math.random()*1000),number,beneficiary,amount,date,status:el('checkStatus')?.value||'pending',note:(el('checkNote')?.value||'').trim()});
 save();e.target.reset();renderChecks();alert('تم تسجيل الشيك بنجاح');
}
function updateCheckStatus(id,status){
 const c=(db.checks||[]).find(x=>String(x.id)===String(id));if(!c)return;c.status=status;save();renderChecks();
}
function deleteCheck(id){
 if(!confirm('هل تريد حذف هذا الشيك؟'))return;db.checks=(db.checks||[]).filter(x=>String(x.id)!==String(id));save();renderChecks();
}
function renderNotifications(){
 const box=el('notificationsList'), badge=el('notificationBadge');
 if(!box)return;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const until=new Date(today); until.setDate(until.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending'||!c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today&&d<=until;
 }).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 if(badge){badge.textContent=upcoming.length;badge.style.display=upcoming.length?'inline-block':'none';}
 box.innerHTML=upcoming.length?upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-bottom:10px;background:#fff8e1;border-right:4px solid #f0ad4e"><b>🔔 شيك رقم ${esc(c.number)}</b><div style="margin-top:6px">المستفيد: ${esc(c.beneficiary)}</div><div>المبلغ: <b>${money(c.amount)}</b></div><div>تاريخ الدخول: <b>${esc(c.date)}</b> — ${when}</div></div>`}).join(''):'<div class="empty card">لا توجد إشعارات حالياً.</div>';
}
function renderChecks(){
 if(!el('checkList'))return;if(!Array.isArray(db.checks))db.checks=[];
 const search=(el('checkSearch')?.value||'').trim().toLowerCase();
 const rows=db.checks.filter(c=>{if(!search)return true;return [c.number,c.beneficiary,c.note].some(v=>String(v||'').toLowerCase().includes(search));}).slice().sort((a,b)=>new Date(a.date||'9999-12-31')-new Date(b.date||'9999-12-31'));
 const total=rows.reduce((a,c)=>a+Number(c.amount||0),0);
 const pending=rows.filter(c=>c.status==='pending').reduce((a,c)=>a+Number(c.amount||0),0);
 const cashed=rows.filter(c=>c.status==='cashed').reduce((a,c)=>a+Number(c.amount||0),0);
 const sum=el('checkSummary');if(sum)sum.innerHTML=`<div class="card">مجموع الشيكات<b>${money(total)}</b><span class="small">${rows.length} شيك</span></div><div class="card">في الانتظار<b>${money(pending)}</b></div><div class="card">تم صرفه<b>${money(cashed)}</b></div>`;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const alertUntil=new Date(today); alertUntil.setDate(alertUntil.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending' || !c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today && d<=alertUntil;
 }).filter(c=>!search || [c.number,c.beneficiary,c.note].some(v=>String(v||'').toLowerCase().includes(search))).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const alerts=el('checkAlerts');
 if(alerts){
   alerts.style.display=upcoming.length?'block':'none';
   alerts.innerHTML=upcoming.length?'<h3>🔔 إشعار الشيكات القريبة</h3><div class="small">هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:</div>'+upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-top:8px;background:#fff8e1"><b>شيك ${esc(c.number)}</b> — ${esc(c.beneficiary)} — ${money(c.amount)}<br><span class="small">تاريخ الشيك: ${esc(c.date)} • ${when}</span></div>`}).join(''):'';
 }
 const scheduled=(db.checks||[]).filter(c=>c.status==='pending' && String(c.date||'')>=today.toISOString().slice(0,10)).filter(c=>!search || [c.number,c.beneficiary,c.note].some(v=>String(v||'').toLowerCase().includes(search))).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const sched=el('scheduledCheckList'); if(sched) sched.innerHTML=scheduled.length?'<div style="overflow:auto"><table><tr><th>رقم الشيك</th><th>المستفيد</th><th>المبلغ</th><th>تاريخ الشيك</th></tr>'+scheduled.map(c=>`<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td></tr>`).join('')+'</table></div>':'<div class="empty">لا توجد شيكات مبرمجة</div>';
 el('checkList').innerHTML=rows.length?'<div class="card"><h3>📋 جميع الشيكات — الأقرب تاريخاً أولاً</h3><div style="overflow:auto"><table><tr><th>الرقم</th><th>المستفيد</th><th>المبلغ</th><th>التاريخ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>{const status=c.status==='cashed'?'<span class="badge">تم صرفه</span>':c.status==='cancelled'?'<span class="badge" style="background:#fde8e8;color:#a33">ملغى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">في الانتظار</span>';return `<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td><td>${status}</td><td><select onchange="updateCheckStatus('${c.id}',this.value)"><option value="pending" ${c.status==='pending'?'selected':''}>في الانتظار</option><option value="cashed" ${c.status==='cashed'?'selected':''}>تم صرفه</option><option value="cancelled" ${c.status==='cancelled'?'selected':''}>ملغى</option></select><button type="button" class="danger" onclick="deleteCheck('${c.id}')">🗑️</button></td></tr>`}).join('')+'</table></div></div>':'<div class="empty card">لا توجد شيكات مسجلة</div>';
}
function renderCredit(){
 if(!el('creditList'))return;
 if(!Array.isArray(db.credits))db.credits=[];
 const open=db.credits.filter(x=>!x.paid), paid=db.credits.filter(x=>x.paid);
 const openTotal=open.reduce((a,x)=>a+Number(x.amount||0),0), paidTotal=paid.reduce((a,x)=>a+Number(x.amount||0),0);
 const sum=el('creditSummary'); if(sum)sum.innerHTML=`<div class="card">المستحق حالياً<b>${money(openTotal)}</b></div><div class="card">عدد الديون<b>${open.length}</b></div>`;
 const sel=el('creditCustomer'); if(sel){const current=sel.value;sel.innerHTML='<option value="">اختر الزبون</option>'+db.customers.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}${c.phone?' - '+esc(c.phone):''}</option>`).join('');if(current)sel.value=current;}
 const search=(el('creditSearch')?.value||'').trim().toLowerCase();
 const rows=db.credits.filter(c=>{if(!search)return true; const hay=[c.customerName,c.phone,c.note].map(v=>String(v||'').toLowerCase()); return hay.some(v=>v.includes(search));}).slice().sort((a,b)=>new Date(b.date||0)-new Date(a.date||0));
 el('creditList').innerHTML=rows.length?'<div class="card"><table><tr><th>التاريخ</th><th>الزبون</th><th>المبلغ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>`<tr><td>${esc(new Date(c.date||0).toLocaleDateString('ar-MA'))}</td><td>${esc(c.customerName||'-')}<div class="small">${esc(c.phone||'')}</div>${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${c.paid?'<span class="badge">مؤدى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">باقي</span>'}</td><td>${c.paid?'':'<button type="button" onclick="markCreditPaid(\''+c.id+'\')">✅ تسديد</button>'}<button type="button" class="danger" onclick="deleteCredit(\''+c.id+'\')">🗑️</button></td></tr>`).join('')+'</table></div>':'<div class="empty card">لا توجد ديون مسجلة</div>';
}
function render(){
 syncCatalogLinks();
 renderStockProductOptions();
 el('cStock').textContent=money(db.stock.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0));
 const nowForHome=new Date();
 const lastMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth()-1,1);
 const thisMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth(),1);
 const lastMonthSales=db.sales.reduce((sum,x)=>{const d=new Date(x.date||0); return d>=lastMonthStart && d<thisMonthStart ? sum+Number(x.total||0) : sum;},0);
 el('cSales').textContent=money(db.sales.reduce((a,x)=>a+Number(x.total||0),0));
 el('cLastMonthSales').textContent=money(lastMonthSales);
 el('cExp').textContent=money(db.expenses.reduce((a,x)=>a+Number(x.amount||0),0));
 const creditTotal=(db.credits||[]).filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0); if(el('cCredit'))el('cCredit').textContent=money(creditTotal);
 const term=(el('stockSearch')?.value||'').trim().toLowerCase();
 const filtered=db.stock.filter(x=>!term||String(x.ref||'').toLowerCase().includes(term)||String(x.name||'').toLowerCase().includes(term));
 const totalQty=filtered.reduce((a,x)=>a+Number(x.qty||0),0);
 const totalBuy=filtered.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0);
 const searchedProduct=term && filtered.length===1 ? filtered[0] : null;
 el('searchStats').innerHTML=term?`<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px"><div>📦 <b>${searchedProduct?esc(searchedProduct.name||'-'):'-'}</b></div><div>🔢 <b>${searchedProduct?esc(searchedProduct.ref||'-'):'-'}</b></div><div>🔢 الكمية: <b>${totalQty}</b></div><div>💰 إجمالي الشراء: <b>${money(totalBuy)}</b></div></div>`:'';
 const accountingRows=filtered.map(x=>{const qty=Number(x.qty||0),buy=Number(x.buy||0),lineTotal=qty*buy;return `<tr><td>${esc(x.name||'-')}</td><td>${esc(x.ref||'-')}</td><td>${qty}</td><td>${money(lineTotal)}</td></tr>`}).join('');
 el('stockAccounting').innerHTML=`<h3 style="margin-top:0">📊 حسابات المخزون</h3>${filtered.length?`<div style="overflow-x:auto"><table class="stock-accounting-table"><thead><tr><th>المنتوج</th><th>المرجع</th><th>العدد</th><th>مجموع ثمن الشراء</th></tr></thead><tbody>${accountingRows}</tbody><tfoot><tr><th colspan="2">الإجمالي</th><th>${totalQty}</th><th>${money(totalBuy)}</th></tr></tfoot></table></div>`:`<div class="empty">لا توجد منتجات في المخزون</div>`}`;
 renderPrices();
 renderProducts();
 el('stockList').innerHTML=filtered.length?'<div class="product-grid">'+filtered.map(x=>`<div class="product-card">${x.image?`<img class="prodimg" src="${x.image}" alt="${esc(x.name)}">`:'<div class="noimg">📦</div>'}<h4>${esc(x.name)}</h4><div class="meta">المرجع: ${esc(x.ref||'-')}</div><div class="meta">الكمية: <b>${x.qty}</b> قطعة</div><div class="product-actions"><button onclick="editStock(${x.id})">✏️ تعديل</button><button class="danger" onclick="deleteStock(${x.id})">🗑️ حذف</button></div></div>`).join('')+'</div>':(db.stock.length?'<div class="empty">لا توجد نتائج للبحث</div>':'<div class="empty">لا توجد قطع بعد</div>');
 const now=new Date();
 const todaySales=db.sales.filter(x=>{const d=new Date(x.date);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).slice().reverse();
 const filteredRevenue=todaySales.reduce((a,x)=>a+Number(x.total||0),0), filteredProfit=todaySales.reduce((a,x)=>a+saleProfit(x),0);
 const todayExpenses=db.expenses.filter(x=>{const d=new Date(x.date||0);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).reduce((a,x)=>a+Number(x.amount||0),0);
 el('salesSummary').innerHTML=`<div class="card">مصاريف اليوم<b>${money(todayExpenses)}</b></div><div class="card">المدخول اليومي<b>${money(filteredRevenue)}</b></div><div class="card">الأرباح اليوم<b>${money(filteredProfit)}</b></div>`;
 el('salesRows').innerHTML=todaySales.length?todaySales.flatMap(x=>saleItems(x).map(it=>{const d=new Date(x.date),profit=saleItemProfit(it),price=Number(it.price||it.salePrice||0),qty=Number(it.qty||it.quantity||1),revenue=saleItemTotal(it);const p=db.stock.find(z=>String(z.id)===String(it.productId)||String(z.ref||'')===String(it.ref||''));const remaining=it.remainingQty!==undefined?Number(it.remainingQty):(p?Number(p.qty||0):'-');return `<tr><td class="sales-date">${esc(d.toLocaleDateString('ar-MA'))}</td><td>${esc(it.ref||'-')}</td><td>${qty}</td><td>${money(price)}</td><td class="${profit>=0?'profit-positive':'profit-negative'}">${money(profit)}</td><td><b>${remaining}</b></td></tr>`})).join(''):'<tr><td colspan="6" style="text-align:center;padding:18px">لا توجد مبيعات اليوم</td></tr>';
 const daily=dailySalesData();
 el('dailySalesRows').innerHTML=daily.length?daily.map(r=>`<tr><td class="sales-date">${esc(r.date)}</td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${(r.profit-r.expenses)>=0?'profit-positive':'profit-negative'}">${money(r.profit-r.expenses)}</td></tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';
 el('custList').innerHTML=db.customers.length?'<table><tr><th>الزبون</th><th>الهاتف</th></tr>'+db.customers.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||'-')}</td></tr>`).join('')+'</table>':'<div class="empty">لا يوجد زبائن</div>';
 el('expList').innerHTML=db.expenses.length?'<table><tr><th>المصروف</th><th>المبلغ</th></tr>'+db.expenses.slice().reverse().map(x=>`<tr><td>${esc(x.name)}</td><td>${money(x.amount)}</td></tr>`).join('')+'</table>':'<div class="empty">لا توجد مصاريف</div>';
 const reportInput=el('reportMonth');
if(reportInput && !reportInput.value){
  const d=new Date(); reportInput.value=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
if(el('monthlyReportCards')){
  const ym=reportInput?.value||'';
  const [ry,rm]=ym.split('-').map(Number);
  const reportYear=el('reportYear');
  if(reportYear && !reportYear.value) reportYear.value=ry || new Date().getFullYear();
  const selectedYear=Number(reportYear?.value||new Date().getFullYear());
  const inMonth=(date)=>{const d=new Date(date||0);return d.getFullYear()===ry && d.getMonth()+1===rm;};
  const inYear=(date)=>{const d=new Date(date||0);return d.getFullYear()===selectedYear;};
  const ms=db.sales.filter(x=>inMonth(x.date));
  const me=db.expenses.filter(x=>inMonth(x.date));
  const mc=(db.credits||[]).filter(x=>inMonth(x.date));
  const salesTotal=ms.reduce((a,x)=>a+Number(x.total||0),0);
  const profitTotal=ms.reduce((a,x)=>a+saleProfit(x),0);
  const expensesTotal=me.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditAdded=mc.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditOpen=mc.filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0);
  const net=profitTotal-expensesTotal;
  el('monthlyReportCards').innerHTML=
    `<div class="card">مجموع المبيعات الشهرية<b>${money(salesTotal)}</b><span class="small">${ms.length} عملية</span></div>
     <div class="card">مجموع أرباح الشهر<b>${money(profitTotal)}</b><span class="small">قبل المصاريف</span></div>
     <div class="card">مجموع المصاريف الشهرية<b>${money(expensesTotal)}</b><span class="small">${me.length} مصروف</span></div>
     <div class="card">صافي الربح بعد المصاريف<b>${money(net)}</b><span class="small">الأرباح − المصاريف</span></div>
     <div class="card">مجموع الكريدي المسجل<b>${money(creditAdded)}</b><span class="small">خلال الشهر المختار</span></div>
     <div class="card">الكريدي المتبقي<b>${money(creditOpen)}</b><span class="small">غير المؤدى من كريدي الشهر</span></div>
     <div class="card">عدد عمليات البيع<b>${ms.length}</b><span class="small">خلال الشهر</span></div>`;
  const yearlyCashedChecks=(db.checks||[]).filter(c=>c.status==='cashed' && inYear(c.date));
  const yearlyCashedAmount=yearlyCashedChecks.reduce((a,c)=>a+Number(c.amount||0),0);
  const yearlyChecksTotal=(db.checks||[]).filter(c=>inYear(c.date)).reduce((a,c)=>a+Number(c.amount||0),0);
  if(el('annualCheckReport')) el('annualCheckReport').innerHTML=
    `<div class="card"><h3 style="margin-top:0">💰 حساب صرف الشيكات السنوي — ${selectedYear}</h3><span class="small">إجمالي قيمة الشيكات التي تم وضع حالتها "تم صرفه" خلال السنة</span><b>${money(yearlyCashedAmount)}</b><span class="small">عدد الشيكات المصروفة: ${yearlyCashedChecks.length}</span></div>
     <div class="card">إجمالي الشيكات المسجلة في السنة<b>${money(yearlyChecksTotal)}</b><span class="small">يشمل جميع الحالات</span></div>`;
}
 renderDeliveryEditor();
 renderCredit();
 renderNotifications();
 renderChecks();
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
window.addEventListener('load',()=>{const sp=el('saleProduct');if(sp)sp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(sp.value));if(p)el('salePrice').value=''});const dp=el('deliveryProduct');if(dp)dp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(dp.value));if(p){el('deliveryProductName').value=p.name||'';el('deliveryProductPrice').value='';}});const f=el('backupFile');if(f)f.addEventListener('change',e=>{if(e.target.files[0])importBackup(e.target.files[0])});render();renderCart()});


(function(){
  const AFZ_TRANSLATIONS = {"المنتوجات":"Produits", "🔍 ابحث باسم المنتوج":"🔍 Rechercher par nom du produit", "➕ إضافة منتوج":"➕ Ajouter un produit", "اسم المنتوج":"Nom du produit", "📷 صورة المنتوج":"📷 Image du produit", "حفظ المنتوج":"Enregistrer le produit", "تعديل":"Modifier", "حذف":"Supprimer", "تم حفظ المنتوج بنجاح":"Produit enregistré avec succès", "تم تعديل المنتوج بنجاح":"Produit modifié avec succès", "حذف هذا المنتوج؟":"Supprimer ce produit ?", "لا توجد منتوجات بعد":"Aucun produit pour le moment", "لا توجد نتائج للبحث":"Aucun résultat", "تسيير المخزون والمبيعات والحسابات": "Gestion du stock, des ventes et de la comptabilité", "الرئيسية": "Accueil", "المخزون": "Stock", "المبيعات": "Ventes", "الزبائن": "Clients", "وصل التسليم": "Bon de livraison", "مصاريف اليوم": "Dépenses du jour", "الكريدي": "Crédit", "دفتر الشيكات": "Carnet de chèques", "الإشعارات": "Notifications", "التقارير": "Rapports", "نسخة احتياطية": "Sauvegarde", "مجموع رأس مال المخزون": "Valeur totale du stock", "حسب ثمن الشراء": "Selon le prix d'achat", "مبيعات اليوم": "Ventes du jour", "إجمالي المبيعات": "Total des ventes", "أرباح اليوم": "Bénéfice du jour", "صافي ربح مبيعات اليوم": "Bénéfice net des ventes du jour", "مبيعات الشهر الماضي": "Ventes du mois précédent", "إجمالي مبيعات الشهر السابق": "Total des ventes du mois précédent", "المسجلة": "Enregistrées", "مجموع الكريدي": "Total du crédit", "إجمالي المبالغ غير المؤداة": "Total des montants impayés", "🔍 ابحث بالمرجع أو اسم المنتوج": "🔍 Rechercher par référence ou nom du produit", "🔎 بحث باسم الزبون أو الهاتف أو الملاحظة...": "🔎 Rechercher par nom, téléphone ou remarque...", "🔎 بحث برقم الشيك أو المستفيد...": "🔎 Rechercher par numéro de chèque ou bénéficiaire...", "تحميل بيانات المخزون PDF": "📄 Télécharger le stock en PDF", "إضافة قطعة": "Ajouter un article", "اسم القطعة": "Nom de l'article", "المرجع / Référence": "Référence", "الكمية": "Quantité", "ثمن الشراء DH": "Prix d'achat DH", "صورة المنتوج": "📷 Image du produit", "حفظ القطعة": "Enregistrer l'article", "📊 تسجيل مبيعات اليوم": "📊 Enregistrer les ventes du jour", "تسجيل مبيعات اليوم": "Enregistrer les ventes du jour", "رقم المنتج": "Référence produit", "➕ إضافة بيع": "➕ Ajouter la vente", "التاريخ": "Date", "الأرباح": "Bénéfice", "المتبقي": "Restant", "لا توجد مبيعات اليوم": "Aucune vente aujourd'hui", "📅 الملخص اليومي": "📅 Résumé quotidien", "الملخص اليومي": "Résumé quotidien", "المدخول اليومي": "Chiffre d'affaires du jour", "الصافي": "Net", "لا توجد بيانات": "Aucune donnée", "تحرير بون دوليفريزون مستقل": "Créer un bon de livraison indépendant", "هذا القسم مستقل تماماً عن قسم المبيعات. إنشاء وتعديل وصل التسليم هنا لا ينشئ بيعاً ولا يغيّر المخزون.": "Cette section est totalement indépendante des ventes. La création ou la modification d'un bon de livraison ici ne crée pas de vente et ne modifie pas le stock.", "اختر الزبون من قسم الزبائن": "Choisir le client depuis la section Clients", "اسم الزبون": "Nom du client", "هاتف الزبون": "Téléphone du client", "عنوان الزبون": "Adresse du client", "إضافة منتج إلى الوصل": "Ajouter un produit au bon", "اسم المنتج": "Nom du produit", "العدد": "Quantité", "الثمن": "Prix", "➕ إضافة المنتج": "➕ Ajouter le produit", "حفظ الوصل": "Enregistrer le bon", "معاينة الوصل": "Aperçu du bon", "⚡ طباعة PDF سريعة": "⚡ Impression PDF rapide", "إضافة زبون": "Ajouter un client", "الهاتف": "Téléphone", "📱 اختيار الزبون من جهة الاتصال": "📱 Choisir le client depuis les contacts", "اختر جهة اتصال من الهاتف وسيتم إدخال الاسم ورقم الهاتف تلقائياً، ثم اضغط حفظ الزبون.": "Choisissez un contact sur le téléphone : le nom et le numéro seront remplis automatiquement, puis appuyez sur Enregistrer le client.", "حفظ الزبون": "Enregistrer le client", "إدارة الكريدي": "Gestion du crédit", "اختر الزبون": "Choisir le client", "مبلغ الكريدي DH": "Montant du crédit DH", "ملاحظة (اختياري)": "Remarque (facultatif)", "تسجيل الكريدي": "Enregistrer le crédit", "رقم الشيك": "Numéro du chèque", "اسم المستفيد": "Bénéficiaire", "مبلغ الشيك DH": "Montant du chèque DH", "في الانتظار": "En attente", "تم صرفه": "Encaissé", "ملغى": "Annulé", "تسجيل الشيك": "Enregistrer le chèque", "جدول الشيكات المبرمجة": "Tableau des chèques programmés", "تنبيهات الشيكات التي اقترب تاريخ دخولها إلى البنك.": "Alertes pour les chèques dont la date de dépôt à la banque approche.", "إضافة مصروف": "Ajouter une dépense", "نوع المصروف": "Type de dépense", "المبلغ DH": "Montant DH", "حفظ المصروف": "Enregistrer la dépense", "حفظ واسترجاع البيانات": "Sauvegarde et restauration des données", "البيانات تحفظ داخل الهاتف. يمكنك أيضًا أخذ نسخة احتياطية.": "Les données sont enregistrées sur le téléphone. Vous pouvez également créer une sauvegarde.", "📥 تصدير نسخة احتياطية": "📥 Exporter une sauvegarde", "اختر ملف JSON لاسترجاع البيانات.": "Choisissez un fichier JSON pour restaurer les données.", "📊 التقارير الشهرية والسنوية": "📊 Rapports mensuels et annuels", "اختر الشهر": "Choisir le mois", "السنة": "Année", "المسجل": "Enregistré", "قبل المصاريف": "Avant dépenses", "خلال الشهر المختار": "Pendant le mois sélectionné", "غير المؤدى من كريدي الشهر": "Impayé du crédit du mois", "عدد عمليات البيع": "Nombre de ventes", "خلال الشهر": "Pendant le mois", "حساب صرف الشيكات السنوي": "Comptabilisation annuelle des chèques encaissés", "إجمالي قيمة الشيكات التي تم وضع حالتها \"تم صرفه\" خلال السنة": "Valeur totale des chèques marqués « Encaissé » pendant l'année", "عدد الشيكات المصروفة": "Nombre de chèques encaissés", "إجمالي الشيكات المسجلة في السنة": "Total des chèques enregistrés dans l'année", "يشمل جميع الحالات": "Toutes les situations incluses", "شيك": "chèque", "شيكات": "chèques", "لا توجد إشعارات حالياً.": "Aucune notification actuellement.", "إشعار الشيكات القريبة": "Alerte des chèques proches", "هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:": "Certains chèques seront à déposer à la banque dans les 3 prochains jours :", "المستفيد:": "Bénéficiaire :", "المبلغ:": "Montant :", "تاريخ الشيك:": "Date du chèque :", "اليوم": "Aujourd'hui", "غداً": "Demain", "بعد": "Dans", " أيام": " jours", "لا توجد شيكات مبرمجة": "Aucun chèque programmé", "جميع الشيكات — الأقرب تاريخاً أولاً": "Tous les chèques — date la plus proche en premier", "لا توجد شيكات مسجلة": "Aucun chèque enregistré", "المستحق حالياً": "Dû actuellement", "عدد الديون": "Nombre de dettes", "لا توجد ديون مسجلة": "Aucune dette enregistrée", "لا يوجد زبائن": "Aucun client", "لا توجد مصاريف": "Aucune dépense", "المصروف": "Dépense", "الزبون": "Client", "المرجع:": "Référence :", "قطعة": "article", "حسابات المخزون": "Comptabilité du stock", "إجمالي الشراء": "Total des achats", "المنتجات:": "Produits :", "الكمية:": "Quantité :", "مجموع المبيعات الشهرية": "Total des ventes mensuelles", "مجموع أرباح الشهر": "Total du bénéfice mensuel", "مجموع المصاريف الشهرية": "Total des dépenses mensuelles", "صافي الربح بعد المصاريف": "Bénéfice net après dépenses", "مجموع الكريدي المسجل": "Total du crédit enregistré", "الكريدي المتبقي": "Crédit restant", "عدد الشيكات المصروفة:": "Nombre de chèques encaissés :", "اختر منتجاً من المخزون أو اكتب الاسم": "Choisir un produit du stock ou saisir le nom", "منتجات الوصل": "Produits du bon", "لا تتم إضافة منتجات بعد": "Aucun produit ajouté", "لا توجد وصول محفوظة": "Aucun bon enregistré", "رقم الوصل": "N° du bon", "العنوان": "Adresse", "المجموع": "Total", "الوصول المستقلة المحفوظة": "Bons indépendants enregistrés", "➕ وصل جديد": "➕ Nouveau bon", "اسم": "Nom", "عدد": "Qté", "حذف": "Supprimer", "المجموع النهائي": "Total final", "زبون عابر": "Client de passage", "تم حفظ المنتج بنجاح": "Produit enregistré avec succès", "تعذر حفظ الصورة. جرّب صورة أصغر.": "Impossible d'enregistrer l'image. Essayez une image plus petite.", "اختر منتجًا": "Choisissez un produit", "الكمية غير صحيحة": "Quantité incorrecte", "الكمية المطلوبة أكبر من المخزون المتوفر": "La quantité demandée dépasse le stock disponible", "السعر غير صحيح": "Prix incorrect", "أضف منتجًا واحدًا على الأقل": "Ajoutez au moins un produit", "تم حفظ البيع بنجاح": "Vente enregistrée avec succès", "لا توجد مبيعات لتحميلها": "Aucune vente à télécharger", "أدخل اسم المنتج": "Saisissez le nom du produit", "أدخل العدد": "Saisissez la quantité", "الثمن غير صحيح": "Prix incorrect", "أضف منتجاً واحداً على الأقل": "Ajoutez au moins un produit", "تم حفظ وصل التسليم بشكل مستقل عن المبيعات": "Bon de livraison enregistré indépendamment des ventes", "أضف منتجات إلى الوصل أولاً": "Ajoutez d'abord des produits au bon", "تعذر إنشاء PDF:": "Impossible de créer le PDF :", "الطباعة الحرارية متاحة داخل تطبيق Android.": "L'impression thermique est disponible uniquement dans l'application Android.", "لا توجد مبيعات للطباعة": "Aucune vente à imprimer", "لا توجد مبيعات لإنشاء وصل التسليم": "Aucune vente pour créer un bon de livraison", "اختيار جهات الاتصال متاح داخل تطبيق Android فقط": "La sélection des contacts est disponible uniquement dans l'application Android", "تعذر فتح جهات الاتصال": "Impossible d'ouvrir les contacts", "تم حفظ الزبون": "Client enregistré", "تم حفظ المصروف": "Dépense enregistrée", "بيانات غير صحيحة": "Données incorrectes", "تم تعديل المنتج بنجاح": "Produit modifié avec succès", "حذف هذا المنتج؟": "Supprimer ce produit ?", "تم استرجاع البيانات": "Données restaurées", "ملف النسخة الاحتياطية غير صالح": "Fichier de sauvegarde invalide", "أدخل رقم المنتج": "Saisissez la référence du produit", "أدخل كمية صحيحة": "Saisissez une quantité valide", "رقم المنتج غير موجود في المخزون": "Produit introuvable dans le stock", "أدخل اسم الزبون": "Saisissez le nom du client", "أدخل مبلغاً صحيحاً": "Saisissez un montant valide", "تم تسجيل الكريدي بنجاح": "Crédit enregistré avec succès", "هل تريد حذف هذا الكريدي؟": "Voulez-vous supprimer ce crédit ?", "أدخل رقم الشيك": "Saisissez le numéro du chèque", "أدخل اسم المستفيد": "Saisissez le bénéficiaire", "تم تسجيل الشيك بنجاح": "Chèque enregistré avec succès", "هل تريد حذف هذا الشيك؟": "Voulez-vous supprimer ce chèque ?", "تم تسجيل البيع. المتبقي في المخزون:": "Vente enregistrée. Stock restant :", "اسم": "Nom", "رقم": "Référence", "الثمن": "Prix", "مع الخفض": "Prix remisé", "💰 الأسعار": "💰 Prix", "🔍 ابحث باسم المنتوج أو الرقم": "🔍 Rechercher par nom du produit ou référence", "لا توجد نتائج للبحث": "Aucun résultat"};
  let AFZ_LANG = localStorage.getItem('afz_lang') || 'ar';
  const originalText = new WeakMap();
  const originalAttr = new WeakMap();

  function tr(value){
    if (AFZ_LANG === 'ar') return value;
    if (AFZ_TRANSLATIONS[value] !== undefined) return AFZ_TRANSLATIONS[value];
    let out=value;
    const keys=Object.keys(AFZ_TRANSLATIONS).sort((a,b)=>b.length-a.length);
    for(const k of keys){
      if(out.includes(k)) out=out.split(k).join(AFZ_TRANSLATIONS[k]);
    }
    return out;
  }

  function translateTree(root){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n=>{
      if(!originalText.has(n)) originalText.set(n,n.nodeValue);
      const o=originalText.get(n);
      n.nodeValue=tr(o);
    });
    root.querySelectorAll('input,textarea,select,option,button').forEach(el=>{
      ['placeholder','title'].forEach(a=>{
        if(el.hasAttribute(a)){
          if(!originalAttr.has(el)) originalAttr.set(el,{});
          const rec=originalAttr.get(el);
          if(rec[a]===undefined) rec[a]=el.getAttribute(a);
          el.setAttribute(a,tr(rec[a]));
        }
      });
    });
  }

  function applyLanguage(){
    document.documentElement.lang=AFZ_LANG==='fr'?'fr':'ar';
    document.documentElement.dir=AFZ_LANG==='fr'?'ltr':'rtl';
    document.body.classList.toggle('lang-fr',AFZ_LANG==='fr');
    const b=document.getElementById('langToggle');
    if(b) b.textContent=AFZ_LANG==='fr'?'🇲🇦 العربية':'🇫🇷 Français';
    translateTree(document.body);
  }

  window.toggleLanguage=function(){
    AFZ_LANG=AFZ_LANG==='fr'?'ar':'fr';
    localStorage.setItem('afz_lang',AFZ_LANG);
    applyLanguage();
  };
  window.addEventListener('DOMContentLoaded',()=>setTimeout(applyLanguage,0));

  // Wrap render so dynamically generated sections are translated as well.
  const wrap=()=>{
    if(typeof window.render==='function' && !window.__afzRenderWrapped){
      const base=window.render;
      window.render=function(){ base.apply(this,arguments); setTimeout(applyLanguage,0); };
      window.__afzRenderWrapped=true;
    }
  };
  setTimeout(wrap,0);
  setInterval(wrap,250);
})();
