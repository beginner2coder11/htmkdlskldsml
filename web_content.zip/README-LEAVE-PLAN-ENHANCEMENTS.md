# Hotel HR Manager — Leave Plan Enhancements

This update adds the requested leave planning improvements to the existing app source:

- Dashboard has two standard-size KPI cards: **Service on leave today** and **Kitchen on leave today**. They count approved plans whose date range includes today and open Leave Plans when tapped.
- Leave Plans includes bulk Excel (`.xlsx`, `.xls`) and CSV import for the full staff leave schedule.
- A downloadable Excel/CSV template is provided. Required columns: `Employee Name`, `Start Date`, `End Date`. Recommended columns: `Staff ID`, `Department`, `Leave Type`, `Status`, `Notes`.
- Imported plans match staff by Staff ID first, then exact employee name. Employees must already exist in the app. Invalid rows are skipped and reported; existing leave plans are kept.
- Year selector displays separate annual plan tables for Service and Kitchen. It includes plans overlapping the selected year, except cancelled plans.
- The same updated `app.js` is included in `hrsettings/` and the Android WebView assets.

Excel parsing uses the app's existing SheetJS library from its CDN. If the device is offline and the library has not loaded, CSV import and template export remain available; reconnect before importing `.xlsx`/`.xls`.

## Validation

`node --check` passes for `app.js`, and the source ZIP passes `unzip -t`. This is source code, not a compiled or device-tested APK. Build a new APK in APK Forge/GitHub Actions and test with a backup of your existing records first.
