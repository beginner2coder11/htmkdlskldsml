-- Run this once in Supabase SQL Editor before using the new restaurant status controls.
ALTER TABLE public.restaurants
ADD COLUMN IF NOT EXISTS is_open boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.restaurants.is_open IS 'Whether the restaurant is currently open to receive orders';
