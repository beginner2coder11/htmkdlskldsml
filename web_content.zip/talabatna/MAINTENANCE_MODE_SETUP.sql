-- تشغيل هذا الملف مرة واحدة في Supabase > SQL Editor
-- يضيف إعدادات وضع الصيانة دون حذف أو تعديل البيانات الحالية.
alter table public.site_settings
  add column if not exists maintenance_mode boolean not null default false,
  add column if not exists maintenance_message text,
  add column if not exists maintenance_until timestamptz,
  add column if not exists maintenance_link text;

insert into public.site_settings (id, maintenance_mode)
values (1, false)
on conflict (id) do nothing;
