from flask import Flask, request, jsonify
import json
import os
import datetime

app = Flask(__name__)

# Database File
DB_FILE = 'users.json'

def load_db():
    if not os.path.exists(DB_FILE):
        # Initialize with default user
        default_data = {
            "users": [
                {
                    "username": "admin",
                    "password": "123456",
                    "balance": 14.2045,
                    "history": []
                }
            ]
        }
        save_db(default_data)
        return default_data
    with open(DB_FILE, 'r') as f:
        return json.load(f)

def save_db(data):
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    db = load_db()
    user = next((u for u in db['users'] if u['username'] == data['username']), None)
    
    if user and user['password'] == data['password']:
        # Remove password from response for security
        user.pop('password', None)
        return jsonify({"status": "success", "user": user})
    
    return jsonify({"status": "error", "message": "Invalid credentials"}), 401

@app.route('/api/send', methods=['POST'])
def send_btc():
    data = request.json
    db = load_db()
    
    # Find user (simple check, in production use tokens)
    user = next((u for u in db['users'] if u['username'] == data['username']), None)
    
    if not user:
        return jsonify({"status": "error", "message": "User not found"}), 404
        
    amount = float(data['amount'])
    recipient = data['recipient']
    
    if user['balance'] >= amount:
        user['balance'] -= amount
        tx_id = f"tx_{datetime.datetime.now().timestamp()}"
        
        new_tx = {
            "id": tx_id,
            "type": "Sent",
            "amount": amount,
            "recipient": recipient,
            "status": "Pending",
            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        user['history'].insert(0, new_tx) # Add to top
        save_db(db)
        
        return jsonify({"status": "success", "new_balance": user['balance'], "tx": new_tx})
    
    return jsonify({"status": "error", "message": "Insufficient funds"}), 400

@app.route('/api/history/<username>', methods=['GET'])
def get_history(username):
    db = load_db()
    user = next((u for u in db['users'] if u['username'] == username), None)
    if user:
        return jsonify({"status": "success", "history": user.get('history', [])})
    return jsonify({"status": "error"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)