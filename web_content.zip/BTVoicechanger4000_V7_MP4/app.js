
const CONFIG = {
    SAMPLE_RATE: 48000,
    LATENCY_HINT: 'interactive',
    BT_FREQS: { STD: 19600, BT: 15500, SUB: 10 }
};

const pitchProcessorCode = `
class PitchProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.maxDelay = 48000 * 0.2; 
        this.ringBuffer = new Float32Array(this.maxDelay);
        this.writePtr = 0;
        this.phase0 = 0.0;
        this.phase1 = 0.5;
        this.isActive = false;
        this.semitones = 0;
        this.port.onmessage = (event) => {
            if (event.data.type === 'update') {
                this.isActive = event.data.isActive;
                this.semitones = event.data.semitones;
            }
        };
    }
    process(inputs, outputs, parameters) {
        const input = inputs[0];
        const output = outputs[0];
        if (!input || !input[0] || !output || !output[0]) return true;
        const inputChannel = input[0];
        const outputChannel = output[0];
        const len = inputChannel.length;
        if (!this.isActive || this.semitones === 0) {
            for (let i = 0; i < len; i++) { outputChannel[i] = inputChannel[i]; }
            return true;
        }
        const pitchRatio = Math.pow(2, this.semitones / 12);
        const grainLen = Math.floor(48000 * 0.016);
        for (let i = 0; i < len; i++) {
            this.ringBuffer[this.writePtr] = inputChannel[i];
            this.phase0 += (1 - pitchRatio) / grainLen;
            if (this.phase0 < 0) this.phase0 += 1.0;
            if (this.phase0 >= 1.0) this.phase0 -= 1.0;
            this.phase1 = (this.phase0 + 0.5) % 1.0;
            const w0 = 0.5 * (1 - Math.cos(2 * Math.PI * this.phase0));
            const w1 = 0.5 * (1 - Math.cos(2 * Math.PI * this.phase1));
            const delay0 = this.phase0 * grainLen + 4;
            const delay1 = this.phase1 * grainLen + 4;
            let rIdx0 = Math.floor(this.writePtr - delay0 + this.maxDelay) % this.maxDelay;
            let rIdx1 = Math.floor(this.writePtr - delay1 + this.maxDelay) % this.maxDelay;
            outputChannel[i] = this.ringBuffer[rIdx0] * w0 + this.ringBuffer[rIdx1] * w1;
            this.writePtr = (this.writePtr + 1) % this.maxDelay;
        }
        return true;
    }
}
registerProcessor('pitch-processor', PitchProcessor);
`;

class AudioFXEngine {
    constructor() {
        this.audioCtx = null;
        this.micStream = null;
        this.isMicActive = false;
        this.nodes = {};
        this.state = {
            isMuted: false, previousVolume: 0.8, isBtActive: true,
            isGateActive: false, isPitchActive: false, isDelayActive: false,
            isReverbActive: false, isVibratoActive: false, isRecording: false
        };
        this.animationFrameId = null;
        this.mediaRecorder = null;
        this.recordedChunks = [];
        this.ui = new UIController(this);
        this.ui.init();
    }
    async initAudioContext() {
        if (!this.audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.audioCtx = new AudioContext({ latencyHint: CONFIG.LATENCY_HINT, sampleRate: CONFIG.SAMPLE_RATE });
            const blob = new Blob([pitchProcessorCode], { type: 'application/javascript' });
            const blobUrl = URL.createObjectURL(blob);
            try { await this.audioCtx.audioWorklet.addModule(blobUrl); } catch(e) { console.error(e); }
        }
        if (this.audioCtx.state === 'suspended') { await this.audioCtx.resume(); }
    }
    async startMicrophone(deviceId) {
        try {
            await this.initAudioContext();
            const audioConstraints = { echoCancellation: false, noiseSuppression: false, autoGainControl: false, latency: 0 };
            if (deviceId) audioConstraints.deviceId = { exact: deviceId };
            try { this.micStream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints }); }
            catch (err) { this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
            this.ui.enumerateInputDevices();
            this.buildAudioGraph();
            this.isMicActive = true;
            this.ui.updateMicUI(true);
            this.ui.startVisualizer();
        } catch (err) { this.ui.showError("Mikrofonzugriff verweigert."); }
    }
    async stopMicrophone() {
        if (this.state.isRecording) { this.state.isRecording = false; this.stopRecording(); }
        if (this.micStream) { this.micStream.getTracks().forEach(t => t.stop()); this.micStream = null; }
        if (this.nodes.sourceNode) this.nodes.sourceNode.disconnect();
        if (this.nodes.vibratoOsc) try { this.nodes.vibratoOsc.stop(); } catch(e){}
        if (this.nodes.btKeepAliveOsc) try { this.nodes.btKeepAliveOsc.stop(); } catch(e){}
        if (this.nodes.gateTimer) clearInterval(this.nodes.gateTimer);
        if (this.audioCtx && this.audioCtx.state === 'running') await this.audioCtx.suspend();
        this.isMicActive = false;
        this.ui.updateMicUI(false);
        this.ui.stopVisualizer();
    }
    startRecording() {
        if (!this.nodes.mediaDest || !this.isMicActive) return;
        
        // Optimiert für Android & MP4 Container (AAC Audio)
        let mime = 'audio/mp4';
        if (!MediaRecorder.isTypeSupported(mime)) {
            mime = 'audio/aac';
            if (!MediaRecorder.isTypeSupported(mime)) {
                mime = 'audio/webm'; // Fallback
            }
        }
        
        try {
            this.mediaRecorder = new MediaRecorder(this.nodes.mediaDest.stream, mime ? { mimeType: mime } : undefined);
        } catch(e) {
            this.mediaRecorder = new MediaRecorder(this.nodes.mediaDest.stream);
            mime = 'audio/webm';
        }

        this.recordedChunks = [];
        this.mediaRecorder.ondataavailable = e => { if (e.data.size > 0) this.recordedChunks.push(e.data); };
        this.mediaRecorder.onstop = async () => {
            this.ui.updateRecordUI('processing');
            const ext = mime.includes('mp4') || mime.includes('aac') ? 'mp4' : 'webm';
            const blob = new Blob(this.recordedChunks, { type: mime });
            await this.saveFile(blob, `BT_Voicechanger_Aufnahme.${ext}`);
            this.ui.updateRecordUI('idle');
        };
        this.mediaRecorder.start(100);
        this.ui.updateRecordUI('recording');
    }
    stopRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
        }
    }
    
    async saveFile(blob, defaultName) {
        if (window.showSaveFilePicker) {
            try {
                const handle = await window.showSaveFilePicker({
                    suggestedName: defaultName,
                    types: [{ description: 'Audio/Video Container', accept: { 'audio/mp4': ['.mp4'], 'audio/webm': ['.webm'] } }]
                });
                const writable = await handle.createWritable();
                await writable.write(blob);
                await writable.close();
                return;
            } catch (err) {
                if (err.name === 'AbortError') return;
            }
        }
        
        // Direkter Download für Android / Standard Browser
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = defaultName;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
    }

    buildAudioGraph() {
        const ctx = this.audioCtx;
        const n = this.nodes;
        n.sourceNode = ctx.createMediaStreamSource(this.micStream);
        n.inputGainNode = ctx.createGain();
        n.inputGainNode.gain.value = parseFloat(document.getElementById('sliderMicGain').value);
        n.gateAnalyser = ctx.createAnalyser(); n.gateAnalyser.fftSize = 256;
        n.gateExpanderGain = ctx.createGain();
        this.setupNoiseGateLoop();
        n.pitchNode = new AudioWorkletNode(ctx, 'pitch-processor');
        this.updatePitchSettings();
        n.vibratoDelayNode = ctx.createDelay(0.1); n.vibratoDelayNode.delayTime.value = 0.01;
        n.vibratoOsc = ctx.createOscillator(); n.vibratoGain = ctx.createGain();
        n.vibratoOsc.frequency.value = parseFloat(document.getElementById('sliderVibratoSpeed').value);
        n.vibratoGain.gain.value = this.state.isVibratoActive ? parseFloat(document.getElementById('sliderVibratoDepth').value) * 0.003 : 0;
        n.vibratoOsc.connect(n.vibratoGain); n.vibratoGain.connect(n.vibratoDelayNode.delayTime); n.vibratoOsc.start();
        n.bufferDelayNode = ctx.createDelay(5.5);
        n.bufferDelayNode.delayTime.value = parseFloat(document.getElementById('sliderBufferDelay').value) / 1000;
        n.eqSubFilter = ctx.createBiquadFilter(); n.eqSubFilter.type = 'lowshelf'; n.eqSubFilter.frequency.value = 80;
        n.eqBassFilter = ctx.createBiquadFilter(); n.eqBassFilter.type = 'peaking'; n.eqBassFilter.frequency.value = 250;
        n.eqMidFilter = ctx.createBiquadFilter(); n.eqMidFilter.type = 'peaking'; n.eqMidFilter.frequency.value = 1500;
        n.eqTrebleFilter = ctx.createBiquadFilter(); n.eqTrebleFilter.type = 'peaking'; n.eqTrebleFilter.frequency.value = 4000;
        n.eqAirFilter = ctx.createBiquadFilter(); n.eqAirFilter.type = 'highshelf'; n.eqAirFilter.frequency.value = 10000;
        ['Sub', 'Bass', 'Mid', 'Treble', 'Air'].forEach(b => { n[`eq${b}Filter`].gain.value = parseFloat(document.getElementById(`sliderEq${b}`).value); });
        n.delayNode = ctx.createDelay(2.0); n.delayNode.delayTime.value = parseFloat(document.getElementById('sliderDelayTime').value);
        n.delayFeedbackGain = ctx.createGain(); n.delayFeedbackGain.gain.value = parseFloat(document.getElementById('sliderDelayFeedback').value);
        n.delayWetGain = ctx.createGain(); n.delayWetGain.gain.value = this.state.isDelayActive ? parseFloat(document.getElementById('sliderDelayMix').value) : 0.0;
        n.delayNode.connect(n.delayFeedbackGain); n.delayFeedbackGain.connect(n.delayNode);
        n.reverbNode = ctx.createConvolver(); this.createReverbImpulse();
        n.reverbWetGain = ctx.createGain(); n.reverbWetGain.gain.value = this.state.isReverbActive ? parseFloat(document.getElementById('sliderReverbMix').value) : 0.0;
        n.masterGain = ctx.createGain(); n.masterGain.gain.value = this.state.isMuted ? 0 : parseFloat(document.getElementById('sliderMasterVol').value);
        n.analyserNode = ctx.createAnalyser(); n.analyserNode.fftSize = 256;
        
        n.mediaDest = ctx.createMediaStreamDestination();

        n.btKeepAliveOsc = ctx.createOscillator(); n.btKeepAliveGain = ctx.createGain();
        const freq = parseFloat(document.getElementById('selectBtMode').value);
        n.btKeepAliveOsc.frequency.value = freq;
        n.btKeepAliveGain.gain.value = this.state.isBtActive ? (freq === 10 ? 0.005 : 0.002) : 0;
        n.btKeepAliveOsc.connect(n.btKeepAliveGain); n.btKeepAliveGain.connect(n.masterGain); n.btKeepAliveOsc.start();
        const channelMerger = ctx.createChannelMerger(2);
        
        n.sourceNode.connect(n.inputGainNode);
        n.inputGainNode.connect(n.gateAnalyser);
        n.inputGainNode.connect(n.gateExpanderGain);
        n.gateExpanderGain.connect(n.pitchNode);
        n.pitchNode.connect(n.vibratoDelayNode);
        n.vibratoDelayNode.connect(n.bufferDelayNode);
        n.bufferDelayNode.connect(n.eqSubFilter);
        n.eqSubFilter.connect(n.eqBassFilter);
        n.eqBassFilter.connect(n.eqMidFilter);
        n.eqMidFilter.connect(n.eqTrebleFilter);
        n.eqTrebleFilter.connect(n.eqAirFilter);
        
        const fxNode = n.eqAirFilter;
        fxNode.connect(n.delayNode); n.delayNode.connect(n.delayWetGain);
        fxNode.connect(n.reverbNode); n.reverbNode.connect(n.reverbWetGain);
        fxNode.connect(n.masterGain); n.delayWetGain.connect(n.masterGain); n.reverbWetGain.connect(n.masterGain);
        
        n.masterGain.connect(n.analyserNode);
        n.masterGain.connect(n.mediaDest); 
        n.analyserNode.connect(channelMerger, 0, 0); n.analyserNode.connect(channelMerger, 0, 1);
        channelMerger.connect(ctx.destination);
    }
    updatePitchSettings() {
        if (!this.nodes.pitchNode) return;
        const semitones = parseInt(document.getElementById('sliderPitch').value);
        this.nodes.pitchNode.port.postMessage({ type: 'update', isActive: this.state.isPitchActive, semitones: semitones });
    }
    setupNoiseGateLoop() {
        const buffer = new Float32Array(this.nodes.gateAnalyser.fftSize);
        let isGateClosed = false, lastTime = 0;
        this.nodes.gateTimer = setInterval(() => {
            if (!this.isMicActive || !this.audioCtx) return;
            if (!this.state.isGateActive) {
                if (isGateClosed && this.nodes.gateExpanderGain) {
                    isGateClosed = false;
                    this.nodes.gateExpanderGain.gain.cancelScheduledValues(this.audioCtx.currentTime);
                    this.nodes.gateExpanderGain.gain.setValueAtTime(1.0, this.audioCtx.currentTime);
                }
                return;
            }
            this.nodes.gateAnalyser.getFloatTimeDomainData(buffer);
            let sum = 0; for (let i = 0; i < buffer.length; i++) sum += buffer[i] * buffer[i];
            const rms = Math.sqrt(sum / buffer.length);
            const db = 20 * Math.log10(Math.max(rms, 0.00001));
            const thresh = parseFloat(document.getElementById('sliderGateThreshold').value);
            const now = this.audioCtx.currentTime;
            if (now - lastTime < 0.15) return;
            if (db < thresh && !isGateClosed) {
                isGateClosed = true; lastTime = now;
                this.nodes.gateExpanderGain.gain.setTargetAtTime(0.0, now, 0.05);
            } else if (db >= thresh + 3 && isGateClosed) {
                isGateClosed = false; lastTime = now;
                this.nodes.gateExpanderGain.gain.setTargetAtTime(1.0, now, 0.02);
            }
        }, 20);
    }
    createReverbImpulse() {
        if (!this.audioCtx || !this.nodes.reverbNode) return;
        const rate = this.audioCtx.sampleRate, length = rate * 1.5;
        const impulse = this.audioCtx.createBuffer(2, length, rate);
        const l = impulse.getChannelData(0), r = impulse.getChannelData(1);
        for (let i = 0; i < length; i++) {
            const decay = Math.exp(-i / (rate * 0.3));
            l[i] = (Math.random() * 2 - 1) * decay;
            r[i] = (Math.random() * 2 - 1) * decay;
        }
        this.nodes.reverbNode.buffer = impulse;
    }
}

class UIController {
    constructor(engine) { this.engine = engine; }
    init() {
        this.bindEvents();
        const theme = localStorage.getItem('btVoiceChangerTheme') || 'fire';
        this.applyTheme(theme, false);
        this.enumerateInputDevices();
        this.drawEmptyVisualizer();
        
        window.addEventListener('resize', () => {
            this.resizeCanvas();
            if (!this.engine.isMicActive) this.drawEmptyVisualizer();
        });
    }
    resizeCanvas() {
        const canvas = document.getElementById('visualizer');
        if (canvas && canvas.parentElement) {
            const pw = canvas.parentElement.clientWidth;
            const ph = canvas.parentElement.clientHeight;
            if(canvas.width !== pw) canvas.width = pw;
            if(canvas.height !== ph) canvas.height = ph;
        }
    }
    showError(msg) {
        const overlay = document.getElementById('micStatusOverlay');
        if (overlay) {
            overlay.innerHTML = `<span class="flex items-center gap-2 text-red-500"><i class="fa-solid fa-triangle-exclamation"></i> ${msg}</span>`;
            overlay.classList.remove('hidden');
        }
        setTimeout(() => {
            if (overlay && !this.engine.isMicActive) {
                overlay.innerHTML = `<span class="flex items-center gap-3"><i class="fa-solid fa-microphone-slash text-brand-fire text-lg"></i> MIKROFON INAKTIV</span>`;
            }
        }, 4000);
    }
    async enumerateInputDevices() {
        try {
            const select = document.getElementById('selectMicDevice');
            if (!select || !navigator.mediaDevices?.enumerateDevices) return;
            const devices = await navigator.mediaDevices.enumerateDevices();
            const inputs = devices.filter(d => d.kind === 'audioinput');
            select.innerHTML = '<option value="">Standard-Mikrofon</option>';
            inputs.forEach((d, i) => {
                const opt = document.createElement('option');
                opt.value = d.deviceId; opt.textContent = d.label || `Mikrofon ${i + 1}`;
                select.appendChild(opt);
            });
        } catch(e) {}
    }
    bindEvents() {
        const bind = (id, evt, fn) => document.getElementById(id)?.addEventListener(evt, fn);
        bind('btnToggleMic', 'click', () => {
            if (this.engine.isMicActive) this.engine.stopMicrophone();
            else this.engine.startMicrophone(document.getElementById('selectMicDevice').value);
        });
        bind('btnRecord', 'click', () => {
            if (!this.engine.isMicActive) return;
            const s = this.engine.state;
            if (s.isRecording) {
                s.isRecording = false;
                this.engine.stopRecording();
            } else {
                s.isRecording = true;
                this.engine.startRecording();
            }
        });
        document.querySelectorAll('.theme-cube').forEach(b => b.addEventListener('click', (e) => this.applyTheme(e.currentTarget.getAttribute('data-theme'))));
        ['bt', 'gate', 'pitch', 'delay', 'reverb', 'vibrato'].forEach(eff => {
            bind(`btnToggle${eff.charAt(0).toUpperCase() + eff.slice(1)}`, 'click', () => this.toggleEffect(eff));
        });
        bind('btnMute', 'click', () => this.toggleMute());
        bind('selectMicDevice', 'change', (e) => {
            if (this.engine.isMicActive) { this.engine.stopMicrophone(); this.engine.startMicrophone(e.target.value); }
        });
        const inputs = [
            'sliderMicGain', 'sliderBufferDelay', 'sliderGateThreshold', 'sliderGateRelease',
            'sliderPitch', 'sliderEqSub', 'sliderEqBass', 'sliderEqMid', 'sliderEqTreble', 'sliderEqAir',
            'sliderDelayTime', 'sliderDelayFeedback', 'sliderDelayMix',
            'sliderReverbMix', 'sliderVibratoSpeed', 'sliderVibratoDepth', 'sliderMasterVol', 'selectBtMode'
        ];
        inputs.forEach(id => {
            bind(id, 'input', () => this.updateControlsFromUI());
            bind(id, 'change', () => this.updateControlsFromUI());
        });
        document.querySelectorAll('.btn-save-preset').forEach(b => b.addEventListener('click', (e) => this.saveSettings(e)));
        document.querySelectorAll('.btn-load-preset').forEach(b => b.addEventListener('click', (e) => this.loadSettings(e)));
        bind('btnPresetMenu', 'click', () => document.getElementById('presetDropdown')?.classList.toggle('hidden'));
        document.addEventListener('click', (e) => {
            const container = document.getElementById('presetMenuContainer'), drop = document.getElementById('presetDropdown');
            if (container && drop && !container.contains(e.target)) drop.classList.add('hidden');
        });
        bind('btnFeedbackInfo', 'click', () => document.getElementById('modalFeedback')?.classList.remove('hidden'));
        bind('btnCloseModal', 'click', () => document.getElementById('modalFeedback')?.classList.add('hidden'));
        bind('btnConfirmModal', 'click', () => document.getElementById('modalFeedback')?.classList.add('hidden'));
    }
    toggleEffect(effect) {
        const s = this.engine.state;
        if (effect === 'bt') {
            s.isBtActive = !s.isBtActive;
            if (this.engine.nodes.btKeepAliveGain) this.engine.nodes.btKeepAliveGain.gain.value = s.isBtActive ? 0.002 : 0;
            this.updateEffectBtnUI('bt', s.isBtActive);
        } else {
            const key = `is${effect.charAt(0).toUpperCase() + effect.slice(1)}Active`;
            s[key] = !s[key];
            this.updateEffectBtnUI(effect, s[key]);
            if (effect === 'pitch') this.engine.updatePitchSettings();
            this.updateControlsFromUI();
        }
    }
    updateEffectBtnUI(name, isActive) {
        const btn = document.getElementById(`btnToggle${name.charAt(0).toUpperCase() + name.slice(1)}`);
        const lbl = document.getElementById(`lbl${name.charAt(0).toUpperCase() + name.slice(1)}Btn`);
        const badge = document.getElementById(`${name}IconBadge`);
        if (!btn || !lbl) return;
        if (isActive) {
            btn.className = 'px-3 py-1.5 rounded-md font-tech text-[10px] font-bold tracking-wider transition-all flex items-center gap-1 bg-gradient-to-r from-red-600 via-brand-fire to-amber-600 text-white border border-red-500/80 shadow-md shadow-red-900/40 active:scale-95';
            lbl.textContent = 'EIN';
            if (badge) badge.className = 'w-9 h-9 rounded-lg bg-red-950/60 border border-red-500/40 flex items-center justify-center text-brand-fire shadow-inner shrink-0 transition-all';
        } else {
            btn.className = 'px-3 py-1.5 rounded-md font-tech text-[10px] font-bold tracking-wider transition-all flex items-center gap-1 bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-blue-200 border border-blue-600/60 shadow-sm active:scale-95';
            lbl.textContent = 'AUS';
            if (badge) badge.className = 'w-9 h-9 rounded-lg bg-blue-950/60 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-inner shrink-0 transition-all';
        }
    }
    updateRecordUI(state) {
        const btn = document.getElementById('btnRecord');
        const icon = document.getElementById('recIcon');
        const text = document.getElementById('recText');
        if (!btn || !icon || !text) return;
        
        if (state === 'idle') {
            icon.className = 'fa-solid fa-circle text-sm';
            text.textContent = 'REC';
            btn.className = 'w-16 sm:w-20 rounded-xl flex flex-col items-center justify-center gap-1 bg-red-950/40 text-red-500 border border-red-900/50 hover:bg-red-900/40 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer';
            btn.disabled = !this.engine.isMicActive;
        } else if (state === 'recording') {
            icon.className = 'fa-solid fa-square text-sm animate-pulse';
            text.textContent = 'REC';
            btn.className = 'w-16 sm:w-20 rounded-xl flex flex-col items-center justify-center gap-1 bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.6)] border border-red-500 transition-all cursor-pointer';
            btn.disabled = false;
        } else if (state === 'processing') {
            icon.className = 'fa-solid fa-spinner fa-spin text-sm text-amber-300';
            text.textContent = 'MP4...';
            btn.className = 'w-16 sm:w-20 rounded-xl flex flex-col items-center justify-center gap-1 bg-amber-600 text-white shadow-[0_0_15px_rgba(217,119,6,0.6)] border border-amber-500 transition-all cursor-wait opacity-80';
            btn.disabled = true;
        }
    }
    toggleMute() {
        const s = this.engine.state;
        s.isMuted = !s.isMuted;
        const btn = document.getElementById('btnMute'), icon = document.getElementById('iconMute'), lbl = document.getElementById('lblMuteBtn');
        const slider = document.getElementById('sliderMasterVol'), muteBadge = document.getElementById('muteIconBadge'), muteStatusBadge = document.getElementById('muteStatusBadge');
        if (s.isMuted) {
            if (slider) s.previousVolume = parseFloat(slider.value) || 0.8;
            if (this.engine.nodes.masterGain) this.engine.nodes.masterGain.gain.value = 0;
            if (btn) btn.className = 'group relative px-2 py-1 bg-gradient-to-r from-red-950/90 to-red-900/60 text-red-200 border border-red-500 rounded-md text-[10px] font-tech font-bold transition-all shadow-md active:scale-95 flex items-center gap-1.5';
            if (muteBadge) muteBadge.className = 'w-5 h-5 rounded bg-red-900 border border-red-400 flex items-center justify-center text-red-200 shadow-inner transition-all';
            if (icon) icon.className = 'fa-solid fa-volume-xmark text-red-300 text-[10px]';
            if (muteStatusBadge) { muteStatusBadge.textContent = 'MUTE'; muteStatusBadge.className = 'text-[8px] font-mono px-1 py-0.5 rounded bg-red-900 text-red-200 border border-red-600 font-bold tracking-widest'; }
        } else {
            if (this.engine.nodes.masterGain) this.engine.nodes.masterGain.gain.value = s.previousVolume;
            if (btn) btn.className = 'group relative px-2 py-1 bg-gradient-to-r from-black/60 to-blue-950/30 hover:to-blue-900/40 text-slate-100 border border-blue-950/80 hover:border-blue-600/60 rounded-md text-[10px] font-tech font-bold transition-all shadow-sm active:scale-95 flex items-center gap-1.5';
            if (muteBadge) muteBadge.className = 'w-5 h-5 rounded bg-blue-950/80 border border-blue-600/60 flex items-center justify-center text-blue-400 shadow-inner group-hover:scale-105 transition-all';
            if (icon) icon.className = 'fa-solid fa-volume-high text-blue-400 text-[10px]';
            if (muteStatusBadge) { muteStatusBadge.textContent = 'LIVE'; muteStatusBadge.className = 'text-[8px] font-mono px-1 py-0.5 rounded bg-blue-950/80 text-blue-400 border border-blue-800/60 font-bold tracking-widest'; }
        }
    }
    updateControlsFromUI() {
        const n = this.engine.nodes, s = this.engine.state;
        const masterVol = parseFloat(document.getElementById('sliderMasterVol').value);
        document.getElementById('lblMasterVol').textContent = `${Math.round(masterVol * 100)}%`;
        if (n.masterGain && !s.isMuted) n.masterGain.gain.value = masterVol;

        const gainVal = parseFloat(document.getElementById('sliderMicGain').value);
        const dbBoost = (20 * Math.log10(gainVal)).toFixed(1);
        const elGain = document.getElementById('valMicGain');
        if (elGain) {
            elGain.textContent = `${dbBoost > 0 ? '+' : ''}${dbBoost} dB (${gainVal.toFixed(1)}x)`;
            if(dbBoost > 0) elGain.className = 'text-[11px] font-mono text-brand-fire font-bold bg-black/40 px-1.5 py-0.5 rounded border border-brand-fire/30';
            else if(dbBoost < 0) elGain.className = 'text-[11px] font-mono text-blue-400 font-bold bg-black/40 px-1.5 py-0.5 rounded border border-blue-500/30';
            else elGain.className = 'text-[11px] font-mono text-slate-300 font-bold bg-black/40 px-1.5 py-0.5 rounded border border-slate-700';
        }
        if (n.inputGainNode) n.inputGainNode.gain.value = gainVal;

        const bufMs = parseFloat(document.getElementById('sliderBufferDelay').value);
        document.getElementById('valBufferDelay').textContent = `${(bufMs / 1000).toFixed(1)}s (${bufMs} ms)`;
        if (n.bufferDelayNode) n.bufferDelayNode.delayTime.value = bufMs / 1000;

        document.getElementById('valGateThreshold').textContent = `${document.getElementById('sliderGateThreshold').value} dB`;
        document.getElementById('valGateRelease').textContent = `${document.getElementById('sliderGateRelease').value} ms`;

        const pitchVal = parseInt(document.getElementById('sliderPitch').value);
        const elPitch = document.getElementById('valPitch');
        if (elPitch) {
            elPitch.textContent = `${pitchVal > 0 ? '+' : ''}${pitchVal}`;
            if(pitchVal > 0) elPitch.className = 'text-xs font-mono text-brand-fire font-bold bg-black/40 px-2 py-0.5 rounded border border-brand-fire/40';
            else if(pitchVal < 0) elPitch.className = 'text-xs font-mono text-blue-400 font-bold bg-black/40 px-2 py-0.5 rounded border border-blue-500/40';
            else elPitch.className = 'text-xs font-mono text-slate-300 font-bold bg-black/40 px-2 py-0.5 rounded border border-slate-700';
        }
        this.engine.updatePitchSettings();

        const updateEqVal = (id, labelId, filter) => {
            const val = parseInt(document.getElementById(id).value);
            const label = document.getElementById(labelId);
            if (label) {
                label.textContent = `${val > 0 ? '+' : ''}${val} dB`;
                if(val > 0) label.className = 'text-xs font-mono text-brand-fire font-bold bg-black/40 px-2 py-0.5 rounded border border-brand-fire/40';
                else if(val < 0) label.className = 'text-xs font-mono text-blue-400 font-bold bg-black/40 px-2 py-0.5 rounded border border-blue-500/40';
                else label.className = 'text-xs font-mono text-slate-300 font-bold bg-black/40 px-2 py-0.5 rounded border border-slate-700';
            }
            if (filter) filter.gain.value = val;
        };
        updateEqVal('sliderEqSub', 'valEqSub', n.eqSubFilter);
        updateEqVal('sliderEqBass', 'valEqBass', n.eqBassFilter);
        updateEqVal('sliderEqMid', 'valEqMid', n.eqMidFilter);
        updateEqVal('sliderEqTreble', 'valEqTreble', n.eqTrebleFilter);
        updateEqVal('sliderEqAir', 'valEqAir', n.eqAirFilter);

        const dTime = parseFloat(document.getElementById('sliderDelayTime').value);
        const dFb = parseFloat(document.getElementById('sliderDelayFeedback').value);
        const dMix = parseFloat(document.getElementById('sliderDelayMix').value);
        document.getElementById('valDelayTime').textContent = `${dTime.toFixed(2)}s`;
        document.getElementById('valDelayFeedback').textContent = `${Math.round(dFb * 100)}%`;
        document.getElementById('valDelayMix').textContent = `${Math.round(dMix * 100)}%`;
        if (n.delayNode) n.delayNode.delayTime.value = dTime;
        if (n.delayFeedbackGain) n.delayFeedbackGain.gain.value = dFb;
        if (n.delayWetGain) n.delayWetGain.gain.value = s.isDelayActive ? dMix : 0.0;

        const rMix = parseFloat(document.getElementById('sliderReverbMix').value);
        document.getElementById('valReverbMix').textContent = `${Math.round(rMix * 100)}%`;
        if (n.reverbWetGain) n.reverbWetGain.gain.value = s.isReverbActive ? rMix : 0.0;

        const vSpeed = parseFloat(document.getElementById('sliderVibratoSpeed').value);
        const vDepth = parseFloat(document.getElementById('sliderVibratoDepth').value);
        document.getElementById('valVibratoSpeed').textContent = `${vSpeed.toFixed(1)} Hz`;
        document.getElementById('valVibratoDepth').textContent = `${Math.round(vDepth * 100)}%`;
        if (n.vibratoOsc) n.vibratoOsc.frequency.value = vSpeed;
        if (n.vibratoGain) n.vibratoGain.gain.value = s.isVibratoActive ? vDepth * 0.003 : 0;

        if (n.btKeepAliveOsc && this.engine.audioCtx) {
            const freq = parseFloat(document.getElementById('selectBtMode').value);
            n.btKeepAliveOsc.frequency.setValueAtTime(freq, this.engine.audioCtx.currentTime);
            if (n.btKeepAliveGain && s.isBtActive) {
                n.btKeepAliveGain.gain.setValueAtTime(freq === 10 ? 0.005 : 0.002, this.engine.audioCtx.currentTime);
            }
        }
    }
    applyTheme(theme, save = true) {
        const root = document.documentElement;
        let color = '#ff2a00', glow = 'rgba(255, 42, 0, 0.8)', borderCol = '#3a1414', cardBg = '#160a0a', bodyBg = '#0a0505', bgGlow = '#3a0800';
        if (theme === 'green') { color = '#22c55e'; glow = 'rgba(34, 197, 94, 0.9)'; borderCol = '#1c5a2c'; cardBg = '#082210'; bodyBg = '#041208'; bgGlow = '#052a10'; }
        else if (theme === 'blue') { color = '#0ea5e9'; glow = 'rgba(14, 165, 233, 0.9)'; borderCol = '#1c3e5a'; cardBg = '#081c2b'; bodyBg = '#040d14'; bgGlow = '#08253a'; }
        else if (theme === 'yellow') { color = '#eab308'; glow = 'rgba(234, 179, 8, 0.9)'; borderCol = '#5a4e1c'; cardBg = '#262008'; bodyBg = '#141104'; bgGlow = '#3a3005'; }
        root.style.setProperty('--brand-color', color);
        root.style.setProperty('--brand-glow', glow);
        root.style.setProperty('--border-col', borderCol);
        root.style.setProperty('--bg-body', bodyBg);
        root.style.setProperty('--brand-bg-glow', bgGlow);
        let tag = document.getElementById('dynamicThemeStyle');
        if (!tag) { tag = document.createElement('style'); tag.id = 'dynamicThemeStyle'; document.head.appendChild(tag); }
        tag.textContent = `
            .border-brand-border { border-color: var(--border-col) !important; }
            .bg-brand-card { background-color: ${cardBg} !important; }
            .text-brand-fire { color: var(--brand-color) !important; }
            .bg-brand-fire { background-color: var(--brand-color) !important; }
        `;
        if (save) localStorage.setItem('btVoiceChangerTheme', theme);
        document.querySelectorAll('.theme-cube').forEach(b => {
            b.classList.toggle('ring-2', b.getAttribute('data-theme') === theme);
            b.classList.toggle('ring-white', b.getAttribute('data-theme') === theme);
            b.classList.toggle('scale-110', b.getAttribute('data-theme') === theme);
        });
    }
    updateMicUI(isActive) {
        const btn = document.getElementById('btnToggleMic'), lbl = document.getElementById('lblMicBtn'), overlay = document.getElementById('micStatusOverlay');
        if (!btn || !lbl || !overlay) return;
        if (isActive) {
            btn.className = 'flex-1 rounded-xl font-tech font-bold text-sm sm:text-base tracking-wider transition-all duration-300 flex items-center justify-center gap-3 bg-gradient-to-r from-red-600 via-brand-fire to-amber-600 text-white shadow-lg shadow-red-600/40 border border-red-400/40 active:scale-95';
            lbl.textContent = 'STOPPEN';
            overlay.classList.add('hidden');
            if(!this.engine.state.isRecording) this.updateRecordUI('idle');
        } else {
            btn.className = 'flex-1 rounded-xl font-tech font-bold text-sm sm:text-base tracking-wider transition-all duration-300 flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-600 via-green-500 to-lime-600 text-white shadow-lg shadow-green-600/30 border border-green-400/30 active:scale-95';
            lbl.textContent = 'STARTEN';
            overlay.classList.remove('hidden');
            this.updateRecordUI('idle'); 
        }
    }
    drawEmptyVisualizer() {
        const canvas = document.getElementById('visualizer');
        if (!canvas) return;
        this.resizeCanvas();
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = 'rgba(10, 5, 5, 0.35)'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath(); ctx.strokeStyle = 'rgba(255, 42, 0, 0.2)'; ctx.lineWidth = 2;
        ctx.moveTo(0, canvas.height / 2); ctx.lineTo(canvas.width, canvas.height / 2); ctx.stroke();
    }
    startVisualizer() {
        if (this.engine.animationFrameId) return;
        const canvas = document.getElementById('visualizer'); if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const draw = () => {
            if (!this.engine.isMicActive) return;
            this.engine.animationFrameId = requestAnimationFrame(draw);
            this.resizeCanvas();
            
            ctx.fillStyle = 'rgba(10, 5, 5, 0.45)'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            if (!this.engine.nodes.analyserNode) return;
            const len = this.engine.nodes.analyserNode.frequencyBinCount;
            const data = new Uint8Array(len);
            this.engine.nodes.analyserNode.getByteTimeDomainData(data);
            ctx.lineWidth = 2.5;
            const grad = ctx.createLinearGradient(0, 0, canvas.width, 0);
            grad.addColorStop(0, '#ff2a00'); grad.addColorStop(0.5, '#ff6a00'); grad.addColorStop(1, '#cc0022');
            ctx.strokeStyle = grad; ctx.beginPath();
            const slice = canvas.width * 1.0 / len; let x = 0;
            for (let i = 0; i < len; i++) {
                const v = data[i] / 128.0, y = v * (canvas.height / 2);
                if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                x += slice;
            }
            ctx.lineTo(canvas.width, canvas.height / 2); ctx.stroke();
        };
        draw();
    }
    stopVisualizer() {
        if (this.engine.animationFrameId) { cancelAnimationFrame(this.engine.animationFrameId); this.engine.animationFrameId = null; }
        this.drawEmptyVisualizer();
    }
    saveSettings(e) {
        e.stopPropagation();
        const slot = e.currentTarget.getAttribute('data-slot');
        const s = this.engine.state;
        const settings = {
            'sliderMicGain': document.getElementById('sliderMicGain')?.value,
            'sliderBufferDelay': document.getElementById('sliderBufferDelay')?.value,
            'sliderGateThreshold': document.getElementById('sliderGateThreshold')?.value,
            'sliderGateRelease': document.getElementById('sliderGateRelease')?.value,
            'sliderPitch': document.getElementById('sliderPitch')?.value,
            'sliderEqSub': document.getElementById('sliderEqSub')?.value,
            'sliderEqBass': document.getElementById('sliderEqBass')?.value,
            'sliderEqMid': document.getElementById('sliderEqMid')?.value,
            'sliderEqTreble': document.getElementById('sliderEqTreble')?.value,
            'sliderEqAir': document.getElementById('sliderEqAir')?.value,
            'sliderDelayTime': document.getElementById('sliderDelayTime')?.value,
            'sliderDelayFeedback': document.getElementById('sliderDelayFeedback')?.value,
            'sliderDelayMix': document.getElementById('sliderDelayMix')?.value,
            'sliderReverbMix': document.getElementById('sliderReverbMix')?.value,
            'sliderVibratoSpeed': document.getElementById('sliderVibratoSpeed')?.value,
            'sliderVibratoDepth': document.getElementById('sliderVibratoDepth')?.value,
            'selectBtMode': document.getElementById('selectBtMode')?.value,
            'isBtActive': s.isBtActive, 'isGateActive': s.isGateActive, 'isPitchActive': s.isPitchActive,
            'isDelayActive': s.isDelayActive, 'isReverbActive': s.isReverbActive, 'isVibratoActive': s.isVibratoActive
        };
        try {
            localStorage.setItem(`btVoiceChangerPreset_${slot}`, JSON.stringify(settings));
            this.flashButton(e.currentTarget, 'bg-emerald-600', 'fa-check');
        } catch(err) { this.flashButton(e.currentTarget, 'bg-red-600', 'fa-xmark'); }
    }
    loadSettings(e) {
        e.stopPropagation();
        const slot = e.currentTarget.getAttribute('data-slot');
        try {
            const saved = localStorage.getItem(`btVoiceChangerPreset_${slot}`);
            if (!saved) throw new Error();
            const settings = JSON.parse(saved);
            Object.keys(settings).forEach(k => {
                const el = document.getElementById(k);
                if (el && typeof settings[k] !== 'boolean') el.value = settings[k];
            });
            const s = this.engine.state;
            if (settings.isBtActive !== s.isBtActive) this.toggleEffect('bt');
            if (settings.isGateActive !== s.isGateActive) this.toggleEffect('gate');
            if (settings.isPitchActive !== s.isPitchActive) this.toggleEffect('pitch');
            if (settings.isDelayActive !== s.isDelayActive) this.toggleEffect('delay');
            if (settings.isReverbActive !== s.isReverbActive) this.toggleEffect('reverb');
            if (settings.isVibratoActive !== s.isVibratoActive) this.toggleEffect('vibrato');
            this.updateControlsFromUI();
            this.flashButton(e.currentTarget, 'bg-blue-600', 'fa-check');
        } catch (err) { this.flashButton(e.currentTarget, 'bg-red-600', 'fa-xmark'); }
    }
    flashButton(btn, colorClass, iconClass) {
        const origHtml = btn.innerHTML, origClass = btn.className;
        btn.innerHTML = `<i class="fa-solid ${iconClass} text-[9px]"></i>`;
        btn.className = `btn-preset ${colorClass} text-white rounded-md py-1 text-xs flex justify-center items-center transition-colors`;
        setTimeout(() => { btn.innerHTML = origHtml; btn.className = origClass; }, 1000);
    }
}

window.addEventListener('DOMContentLoaded', () => { window.audioFXEngine = new AudioFXEngine(); });
