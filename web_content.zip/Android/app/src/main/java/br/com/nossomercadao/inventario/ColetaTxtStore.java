package br.com.nossomercadao.inventario;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.UUID;

/** Durable TXT snapshot. No Android dependency; same bytes are saved and shared. */
public final class ColetaTxtStore {
    private ColetaTxtStore() {}
    public static String safeName(String name) {
        return name != null && name.matches("[A-Za-z0-9_-]{1,80}\\.txt") ? name : "inventario.txt";
    }
    public static int validate(String text) throws IOException {
        if (text == null || text.isEmpty()) throw new IOException("A coleta está vazia.");
        String[] lines = text.split("\\r\\n", -1);
        HashSet<String> codes = new HashSet<String>();
        for (String line : lines) {
            if (!line.matches("[0-9]{1,64},[0-9]+(?:\\.[0-9]{1,3})?"))
                throw new IOException("TXT inválido: use somente codigo,quantidade, sem cabeçalho.");
            String[] fields = line.split(",", 2);
            if (!codes.add(fields[0])) throw new IOException("Código duplicado no TXT. Consolide a quantidade antes de exportar.");
            if (new BigDecimal(fields[1]).compareTo(new BigDecimal("999999999")) > 0)
                throw new IOException("Quantidade fora do limite.");
        }
        return lines.length;
    }
    public static File persist(File appFiles, String name, String text) throws IOException {
        validate(text);
        File dir = new File(new File(appFiles, "exports"), UUID.randomUUID().toString());
        if (!dir.mkdirs()) throw new IOException("Não foi possível criar a pasta da coleta.");
        File result = new File(dir, safeName(name));
        try (FileOutputStream out = new FileOutputStream(result)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        } catch (IOException e) {
            result.delete(); dir.delete(); throw e;
        }
        return result;
    }
    public static File resolveSaved(File appFiles, String path) throws IOException {
        if (path == null || path.isEmpty()) return null;
        File root = new File(appFiles, "exports").getCanonicalFile();
        File file = new File(path).getCanonicalFile();
        if (!file.getPath().startsWith(root.getPath() + File.separator) || !file.isFile() || file.length() == 0)
            return null;
        return file;
    }
}
