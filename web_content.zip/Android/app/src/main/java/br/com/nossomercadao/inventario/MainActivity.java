package br.com.nossomercadao.inventario;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.ActivityNotFoundException;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.media.AudioManager;
import android.media.ToneGenerator;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.google.zxing.ResultPoint;
import com.google.zxing.BarcodeFormat;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private SharedPreferences prefs;
    private boolean scannerBusy, cameraDesired, activityVisible, scanDispatchBusy;
    private LinearLayout scannerHolder;
    private DecoratedBarcodeView scannerView;
    private long lastScanDispatch;
    private ToneGenerator scanTone;
    private boolean exportBusy;
    private final AtomicBoolean sharePreparing = new AtomicBoolean(false);
    private boolean pageReady;
    private String queuedStatus;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<String> cameraPermission = registerForActivityResult(
        new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted && cameraDesired) launchScanner(); else if(granted) scannerBusy=false;
            else { scannerBusy = false; cameraDesired=false; cameraState(false); status("Câmera não autorizada. Libere a permissão nas configurações do aplicativo ou use digitação."); }
        });
    private final ActivityResultLauncher<String> createTxt = registerForActivityResult(
        new ActivityResultContracts.CreateDocument("text/plain"), uri -> {
            if (uri == null) { exportBusy = false; status("Salvamento cancelado. A contagem continua no aplicativo."); return; }
            io.execute(() -> {
                try (FileInputStream input = new FileInputStream(new File(getFilesDir(), "pending-export.txt"));
                     OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                    if (output == null) throw new IllegalStateException("Destino indisponível");
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                    output.flush(); status("Arquivo TXT salvo no local escolhido.");
                } catch (Exception e) { status("Falha ao gravar TXT. Tente novamente: " + e.getMessage()); }
                finally { runOnUiThread(() -> exportBusy = false); }
            });
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("inventario", MODE_PRIVATE);
        if (state != null) { exportBusy = state.getBoolean("exportBusy"); cameraDesired = state.getBoolean("cameraDesired"); }
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new FrameLayout.LayoutParams(-1,-1));
        scannerHolder = new LinearLayout(this); scannerHolder.setOrientation(LinearLayout.VERTICAL); scannerHolder.setVisibility(android.view.View.GONE);
        content.addView(scannerHolder,new LinearLayout.LayoutParams(-1,-2));
        content.addView(web,new LinearLayout.LayoutParams(-1,0,1f));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(root); root.requestApplyInsets();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new InventoryBridge(), "InventoryAndroid");
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse resource = loader.shouldInterceptRequest(request.getUrl());
                if (resource != null) return resource;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOME.equals(request.getUrl().toString());
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) { pageReady = false; }
            @Override public void onPageFinished(WebView view, String url) {
                if (!HOME.equals(url)) return;
                pageReady = true; if(cameraDesired)launchScanner(); deliverBarcode();
                if (queuedStatus != null) { String message = queuedStatus; queuedStatus = null; status(message); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Inventário")
                    .setMessage(message).setPositiveButton("Confirmar", (d, w) -> result.confirm())
                    .setNegativeButton("Cancelar", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show(); return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.confirm()).show(); return true;
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){var ids=['exportPanel','editDialog'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&e.style.display==='block'){e.style.display='none';return true;}}return false;})()", value -> {
                    if (!"true".equals(value)) new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Fechar o coletor? As contagens gravadas ficam neste aplicativo. Exporte o TXT como cópia de segurança.")
                        .setPositiveButton("Fechar", (d, w) -> finish()).setNegativeButton("Continuar", null).show();
                });
            }
        });
        web.loadUrl(HOME);
    }
    private void status(String message) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (!pageReady) { queuedStatus = message; return; }
            web.evaluateJavascript("window.onNativeStatus&&window.onNativeStatus(" + JSONObject.quote(message) + ");", null);
        });
    }
    private void deliverBarcode() {
        if (!pageReady) return;
        String code = prefs.getString("pendingBarcode", null);
        if (code != null) web.evaluateJavascript("(function(){if(typeof window.onBarcodeScanned!=='function')return false;window.onBarcodeScanned(" + JSONObject.quote(code) + ");return true;})()", result -> {
            if ("true".equals(result)) prefs.edit().remove("pendingBarcode").apply();
        });
    }
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private void cameraState(boolean active){
        if(pageReady && !isDestroyed())web.evaluateJavascript("window.onCameraState&&window.onCameraState("+active+");",null);
    }
    private void launchScanner() {
        scannerBusy=false;
        if(!cameraDesired||!pageReady)return;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){cameraDesired=false;cameraState(false);return;}
        try {
            if(scannerView==null){
                LinearLayout toolbar=new LinearLayout(this); toolbar.setPadding(dp(8),0,dp(8),0);
                TextView caption=new TextView(this);caption.setText("Câmera contínua • confirme a quantidade abaixo");caption.setTextSize(12);
                toolbar.addView(caption,new LinearLayout.LayoutParams(0,-2,1f));
                Button close=new Button(this);close.setText("Fechar");close.setTextSize(12);close.setOnClickListener(v->closeScanner());toolbar.addView(close,new LinearLayout.LayoutParams(-2,dp(42)));
                scannerHolder.addView(toolbar);
                scannerView=new DecoratedBarcodeView(this);scannerView.setStatusText("Aponte para o código de barras");
                scannerHolder.addView(scannerView,new LinearLayout.LayoutParams(-1,dp(165)));
                scannerView.getBarcodeView().setDecoderFactory(new com.journeyapps.barcodescanner.DefaultDecoderFactory(Arrays.asList(BarcodeFormat.EAN_13,BarcodeFormat.EAN_8,BarcodeFormat.UPC_A,BarcodeFormat.UPC_E,BarcodeFormat.CODE_128,BarcodeFormat.CODE_39,BarcodeFormat.ITF,BarcodeFormat.CODABAR)));
                scannerView.decodeContinuous(new BarcodeCallback(){
                    @Override public void barcodeResult(BarcodeResult result){
                        if(result==null||result.getText()==null||!cameraDesired||!activityVisible||!pageReady||scanDispatchBusy)return;
                        long now=android.os.SystemClock.elapsedRealtime();if(now-lastScanDispatch<300)return;lastScanDispatch=now;scanDispatchBusy=true;
                        String code=result.getText();
                        web.evaluateJavascript("(function(){return typeof window.onBarcodeScanned==='function'&&window.onBarcodeScanned("+JSONObject.quote(code)+");})()",accepted->{
                            scanDispatchBusy=false;
                            if("true".equals(accepted))try{if(scanTone==null)scanTone=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,55);scanTone.startTone(ToneGenerator.TONE_PROP_BEEP,100);}catch(Exception ignored){}
                        });
                    }
                    @Override public void possibleResultPoints(List<ResultPoint> points){}
                });
            }
            scannerHolder.setVisibility(android.view.View.VISIBLE);if(activityVisible)scannerView.resume();cameraState(true);
        } catch(Exception e){closeScanner();status("Falha ao abrir câmera: "+e.getMessage());}
    }
    private void closeScanner(){
        cameraDesired=false;scannerBusy=false;scanDispatchBusy=false;
        if(scannerView!=null)scannerView.pause();if(scannerHolder!=null)scannerHolder.setVisibility(android.view.View.GONE);cameraState(false);
    }
    private String safeName(String name) {
        return ColetaTxtStore.safeName(name);
    }
    private File writeFile(File target, String text) throws Exception {
        try (FileOutputStream output = new FileOutputStream(target)) {
            output.write(text.getBytes(StandardCharsets.UTF_8)); output.flush();
        }
        return target;
    }
    public class InventoryBridge {
        @JavascriptInterface public String loadData() { return prefs.getString("items", "[]"); }
        @JavascriptInterface public boolean saveData(String json) {
            try {
                JSONArray records = new JSONArray(json);
                for (int i = 0; i < records.length(); i++) {
                    JSONObject item = records.getJSONObject(i);
                    if (!item.getString("code").matches("[0-9]{1,64}")) return false;
                    double qty = item.getDouble("qty");
                    if (Double.isNaN(qty) || Double.isInfinite(qty) || qty < 0 || qty > 999999999) return false;
                }
                return prefs.edit().putString("items", json).commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void startScan() {
            runOnUiThread(() -> {
                if(cameraDesired&&!scannerBusy){closeScanner();return;}
                if(scannerBusy)return;cameraDesired=true;scannerBusy=true;
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchScanner();
                else cameraPermission.launch(Manifest.permission.CAMERA);
            });
        }
        @JavascriptInterface public void stopScan(){runOnUiThread(()->closeScanner());}
        @JavascriptInterface public void saveTxtAs(String name, String text) {
            runOnUiThread(() -> {
                if (exportBusy) { status("Finalize o salvamento anterior."); return; }
                exportBusy = true;
                io.execute(() -> {
                    try {
                        saveSnapshot(name,text);writeFile(new File(getFilesDir(), "pending-export.txt"), text);
                        runOnUiThread(() -> { try { createTxt.launch(safeName(name)); } catch (Exception e) { exportBusy = false; status("Não foi possível abrir o seletor de arquivos."); } });
                    } catch (Exception e) { runOnUiThread(() -> exportBusy = false); status("Falha ao preparar TXT: " + e.getMessage()); }
                });
            });
        }
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("Inventário", text)); status("Lista copiada.");
                } catch (Exception e) { status("Falha ao copiar: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void saveTxt(String name, String text) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { saveTxtAs(name, text); return; }
            io.execute(() -> {
                try {
                    File file=saveSnapshot(name,text);
                    copyToDownloads(file);
                    status("TXT gravado em Downloads/NossoMercadao: "+file.getName());
                } catch(Exception e){status("Não foi possível gravar em Downloads. Use Salvar em… ou Reenviar último TXT. "+e.getMessage());}
            });
        }
        @JavascriptInterface public String lastExportInfo(){
            try{
                File file=ColetaTxtStore.resolveSaved(getFilesDir(),prefs.getString("lastExportPath",""));
                if(file==null)return "{}";
                return new JSONObject().put("name",file.getName()).put("time",prefs.getLong("lastExportTime",file.lastModified())).put("bytes",file.length()).toString();
            }catch(Exception e){return "{}";}
        }
        @JavascriptInterface public void shareLastTxt(){
            if(!sharePreparing.compareAndSet(false,true))return;
            io.execute(()->{
                try{
                    File file=ColetaTxtStore.resolveSaved(getFilesDir(),prefs.getString("lastExportPath",""));
                    if(file==null)throw new IllegalStateException("Nenhum TXT anterior disponível.");
                    openSavedFile(file,true,"Reenviando o TXT já gravado: "+file.getName()+". ");
                }catch(Exception e){status("Não foi possível reenviar: "+e.getMessage());}
                finally{sharePreparing.set(false);}
            });
        }
        @JavascriptInterface public void shareTxt(String name, String text) { prepareShare(name, text, false); }
        @JavascriptInterface public void shareWhatsAppTxt(String name, String text) { prepareShare(name, text, true); }
    }
    private File saveSnapshot(String name,String text)throws Exception{
        File file=ColetaTxtStore.persist(getFilesDir(),safeName(name),text);
        boolean remembered=prefs.edit().putString("lastExportPath",file.getAbsolutePath()).putLong("lastExportTime",System.currentTimeMillis()).commit();
        if(!remembered)android.util.Log.w("Coletor","TXT gravado, mas não foi possível lembrar o último arquivo.");
        return file;
    }
    private void copyToDownloads(File file)throws Exception{
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.Q)return;
        Uri uri=null;
        try{
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,file.getName());values.put(MediaStore.Downloads.MIME_TYPE,"text/plain");
            values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/NossoMercadao");values.put(MediaStore.Downloads.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IllegalStateException("Downloads indisponível.");
            try(FileInputStream input=new FileInputStream(file);OutputStream output=getContentResolver().openOutputStream(uri,"w")){
                if(output==null)throw new IllegalStateException("Destino indisponível.");
                byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1)output.write(buffer,0,count);output.flush();
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);
            if(getContentResolver().update(uri,ready,null,null)!=1)throw new IllegalStateException("Não foi possível publicar o arquivo.");
        }catch(Exception e){if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}throw e;}
    }
    private void prepareShare(String name, String text, boolean whatsapp) {
        if(!sharePreparing.compareAndSet(false,true))return;
        io.execute(() -> {
            try {
                File file=saveSnapshot(name,text);
                String saved="TXT gravado no coletor: "+file.getName()+". ";
                if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){
                    try{copyToDownloads(file);saved="TXT gravado em Downloads/NossoMercadao: "+file.getName()+". ";}
                    catch(Exception e){saved+="Cópia em Downloads indisponível; o original permanece no coletor. ";}
                }
                openSavedFile(file,whatsapp,saved);
            } catch (Exception e) { status("Não foi possível gravar o TXT. Compartilhamento não iniciado. "+e.getMessage()); }
            finally{sharePreparing.set(false);}
        });
    }
    private void openSavedFile(File file,boolean whatsapp,String saved)throws Exception{
        Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".files",file);
        runOnUiThread(()->{
            Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain");send.putExtra(Intent.EXTRA_STREAM,uri);
            send.setClipData(ClipData.newRawUri(file.getName(),uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            openShare(send,whatsapp,saved);
        });
    }
    private void openShare(Intent send, boolean whatsapp,String saved) {
        if (isFinishing() || isDestroyed()) return;
        if (whatsapp) {
            for (String target : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                try {
                    Intent direct = new Intent(send).setPackage(target);
                    startActivity(direct);
                    status(saved+"Arquivo TXT preparado para o WhatsApp. Confira o documento, escolha o contato e confirme o envio.");
                    return;
                } catch (ActivityNotFoundException ignored) {
                    // Try WhatsApp Business, then the system sharesheet.
                } catch (Exception e) {
                    // The system sharesheet remains available if direct delivery is refused.
                }
            }
        }
        try {
            Intent chooser = Intent.createChooser(send, "Compartilhar coleta • escolha o aplicativo");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
            status(saved+"Arquivo TXT anexado ao compartilhamento Android. Escolha WhatsApp ou outro aplicativo e confirme o envio.");
        } catch (Exception e) { status(saved+"Não foi possível abrir o compartilhamento. O arquivo está gravado; use Reenviar último TXT."); }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putBoolean("exportBusy", exportBusy); state.putBoolean("cameraDesired", cameraDesired);
        super.onSaveInstanceState(state);
    }
    @Override protected void onPause(){activityVisible=false;scanDispatchBusy=false;if(scannerView!=null)scannerView.pause();super.onPause();}
    @Override protected void onResume(){super.onResume();activityVisible=true;if(cameraDesired&&scannerView!=null)scannerView.resume();}
    @Override protected void onDestroy() {
        pageReady = false;cameraDesired=false;if(scannerView!=null)scannerView.pause();if(scanTone!=null)scanTone.release();
        if (web != null) { web.removeJavascriptInterface("InventoryAndroid"); web.destroy(); }
        io.shutdown(); super.onDestroy();
    }
}
