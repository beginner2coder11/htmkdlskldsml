package br.com.nossomercadao.inventario;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.ActivityNotFoundException;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private SharedPreferences prefs;
    private boolean scannerBusy;
    private boolean exportBusy;
    private boolean pageReady;
    private String queuedStatus;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(
        new ScanContract(), result -> {
            scannerBusy = false;
            if (result.getContents() != null) {
                final String code = result.getContents();
                if (code.matches("[0-9]{1,64}")) {
                    prefs.edit().putString("pendingBarcode", code).commit();
                    deliverBarcode();
                } else status("Código lido não é numérico. Tente novamente.");
            } else status("Leitura cancelada. Você pode digitar o código manualmente.");
        });
    private final ActivityResultLauncher<String> cameraPermission = registerForActivityResult(
        new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) launchScanner();
            else { scannerBusy = false; status("Câmera não autorizada. Libere a permissão nas configurações do aplicativo ou use digitação."); }
        });
    private final ActivityResultLauncher<String> createTxt = registerForActivityResult(
        new ActivityResultContracts.CreateDocument("text/plain"), uri -> {
            if (uri == null) { exportBusy = false; status("Salvamento cancelado. A contagem continua no aplicativo."); return; }
            io.execute(() -> {
                try (FileInputStream input = new FileInputStream(new File(getFilesDir(), "pending-export.txt"));
                     OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                    if (output == null) throw new IllegalStateException("Destino indisponível");
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                    output.flush(); status("Arquivo TXT salvo no local escolhido.");
                } catch (Exception e) { status("Falha ao gravar TXT. Tente novamente: " + e.getMessage()); }
                finally { runOnUiThread(() -> exportBusy = false); }
            });
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("inventario", MODE_PRIVATE);
        if (state != null) { exportBusy = state.getBoolean("exportBusy"); scannerBusy = state.getBoolean("scannerBusy"); }
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(root); root.requestApplyInsets();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new InventoryBridge(), "InventoryAndroid");
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse resource = loader.shouldInterceptRequest(request.getUrl());
                if (resource != null) return resource;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOME.equals(request.getUrl().toString());
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) { pageReady = false; }
            @Override public void onPageFinished(WebView view, String url) {
                if (!HOME.equals(url)) return;
                pageReady = true; deliverBarcode();
                if (queuedStatus != null) { String message = queuedStatus; queuedStatus = null; status(message); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Inventário")
                    .setMessage(message).setPositiveButton("Confirmar", (d, w) -> result.confirm())
                    .setNegativeButton("Cancelar", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show(); return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.confirm()).show(); return true;
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){var ids=['exportPanel','editDialog'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&e.style.display==='block'){e.style.display='none';return true;}}return false;})()", value -> {
                    if (!"true".equals(value)) new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Fechar o coletor? As contagens gravadas ficam neste aplicativo. Exporte o TXT como cópia de segurança.")
                        .setPositiveButton("Fechar", (d, w) -> finish()).setNegativeButton("Continuar", null).show();
                });
            }
        });
        web.loadUrl(HOME);
    }
    private void status(String message) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (!pageReady) { queuedStatus = message; return; }
            web.evaluateJavascript("window.onNativeStatus&&window.onNativeStatus(" + JSONObject.quote(message) + ");", null);
        });
    }
    private void deliverBarcode() {
        if (!pageReady) return;
        String code = prefs.getString("pendingBarcode", null);
        if (code != null) web.evaluateJavascript("(function(){if(typeof window.onBarcodeScanned!=='function')return false;window.onBarcodeScanned(" + JSONObject.quote(code) + ");return true;})()", result -> {
            if ("true".equals(result)) prefs.edit().remove("pendingBarcode").apply();
        });
    }
    private void launchScanner() {
        try {
            ScanOptions options = new ScanOptions();
            options.setCaptureActivity(ScannerActivity.class);
            options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
            options.setPrompt("Aponte para o código de barras • Voltar para cancelar");
            options.setBeepEnabled(true);
            options.setOrientationLocked(false);
            options.setBarcodeImageEnabled(false);
            scanner.launch(options);
        } catch (Exception e) { scannerBusy = false; status("Falha ao abrir scanner: " + e.getMessage()); }
    }
    private String safeName(String name) {
        return name != null && name.matches("inventario_[0-9_]+\\.txt") ? name : "inventario.txt";
    }
    private File writeFile(File target, String text) throws Exception {
        try (FileOutputStream output = new FileOutputStream(target)) {
            output.write(text.getBytes(StandardCharsets.UTF_8)); output.flush();
        }
        return target;
    }
    public class InventoryBridge {
        @JavascriptInterface public String loadData() { return prefs.getString("items", "[]"); }
        @JavascriptInterface public boolean saveData(String json) {
            try {
                JSONArray records = new JSONArray(json);
                for (int i = 0; i < records.length(); i++) {
                    JSONObject item = records.getJSONObject(i);
                    if (!item.getString("code").matches("[0-9]{1,64}")) return false;
                    double qty = item.getDouble("qty");
                    if (Double.isNaN(qty) || Double.isInfinite(qty) || qty < 0 || qty > 999999999) return false;
                }
                return prefs.edit().putString("items", json).commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void startScan() {
            runOnUiThread(() -> {
                if (scannerBusy) return; scannerBusy = true;
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchScanner();
                else cameraPermission.launch(Manifest.permission.CAMERA);
            });
        }
        @JavascriptInterface public void saveTxtAs(String name, String text) {
            runOnUiThread(() -> {
                if (exportBusy) { status("Finalize o salvamento anterior."); return; }
                exportBusy = true;
                io.execute(() -> {
                    try {
                        writeFile(new File(getFilesDir(), "pending-export.txt"), text);
                        runOnUiThread(() -> { try { createTxt.launch(safeName(name)); } catch (Exception e) { exportBusy = false; status("Não foi possível abrir o seletor de arquivos."); } });
                    } catch (Exception e) { runOnUiThread(() -> exportBusy = false); status("Falha ao preparar TXT: " + e.getMessage()); }
                });
            });
        }
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("Inventário", text)); status("Lista copiada.");
                } catch (Exception e) { status("Falha ao copiar: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void saveTxt(String name, String text) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { saveTxtAs(name, text); return; }
            io.execute(() -> {
                Uri uri = null;
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName(name));
                    values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NossoMercadao");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("Downloads indisponível");
                    try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                        if (output == null) throw new IllegalStateException("Não foi possível abrir o arquivo");
                        output.write(text.getBytes(StandardCharsets.UTF_8)); output.flush();
                    }
                    ContentValues ready = new ContentValues(); ready.put(MediaStore.Downloads.IS_PENDING, 0);
                    if (getContentResolver().update(uri, ready, null, null) != 1) throw new IllegalStateException("Arquivo não foi publicado");
                    status("TXT salvo em Downloads/NossoMercadao: " + safeName(name));
                } catch (Exception e) {
                    if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                    status("Não foi possível salvar em Downloads. Toque em Salvar em… para escolher uma pasta. " + e.getMessage());
                }
            });
        }
        @JavascriptInterface public void shareTxt(String name, String text) { prepareShare(name, text, false); }
        @JavascriptInterface public void shareWhatsAppTxt(String name, String text) { prepareShare(name, text, true); }
        @JavascriptInterface public void shareWhatsAppText(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                openShare(send, true);
            });
        }
    }
    private void prepareShare(String name, String text, boolean whatsapp) {
        io.execute(() -> {
            try {
                File dir = new File(getCacheDir(), "exports");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Pasta indisponível");
                File file = writeFile(new File(dir, System.currentTimeMillis() + "_" + safeName(name)), text);
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", file);
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newRawUri("Inventário TXT", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    openShare(send, whatsapp);
                });
            } catch (Exception e) { status("Falha ao preparar compartilhamento: " + e.getMessage()); }
        });
    }
    private void openShare(Intent send, boolean whatsapp) {
        if (isFinishing() || isDestroyed()) return;
        if (whatsapp) {
            for (String target : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                try {
                    Intent direct = new Intent(send).setPackage(target);
                    startActivity(direct);
                    status("WhatsApp aberto. Escolha o contato e confirme o envio.");
                    return;
                } catch (ActivityNotFoundException ignored) {
                    // Try WhatsApp Business, then the system sharesheet.
                } catch (Exception e) {
                    // The system sharesheet remains available if direct delivery is refused.
                }
            }
        }
        try {
            Intent chooser = Intent.createChooser(send, "Compartilhar coleta • escolha o aplicativo");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
            status("Escolha o aplicativo no painel Android. O envio ainda precisa ser confirmado.");
        } catch (Exception e) { status("Não foi possível abrir o compartilhamento. Use Salvar TXT ou Copiar conteúdo."); }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putBoolean("exportBusy", exportBusy); state.putBoolean("scannerBusy", scannerBusy);
        super.onSaveInstanceState(state);
    }
    @Override protected void onDestroy() {
        pageReady = false;
        if (web != null) { web.removeJavascriptInterface("InventoryAndroid"); web.destroy(); }
        io.shutdown(); super.onDestroy();
    }
}
