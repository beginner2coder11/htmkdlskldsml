const C = 'lifeos-v2';
const A = ['./', 'index.html', 'manifest.json', 'css/style.css', 'js/database.js', 'js/settings.js', 'js/search.js', 'js/ui.js', 'js/budget.js', 'js/toolbox.js', 'js/life.js', 'js/app.js', 'assets/icons/icon.svg'];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(A))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).catch(() => caches.match('index.html'))));
});
