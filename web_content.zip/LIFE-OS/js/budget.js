/* LIFE OS – MYBUDGET */
const CATS = {
  out: [['Market', '#31c76a'], ['Fatura', '#ffb547'], ['Ulaşım', '#3987ff'], ['Yemek', '#ff5252'], ['Sağlık', '#9065ff'], ['Alışveriş', '#8fbaff'], ['Eğlence', '#c4b0ff'], ['Diğer', '#8a8a8a']],
  in: [['Maaş', '#31c76a'], ['Ek gelir', '#3987ff'], ['Diğer', '#8a8a8a']]
};
const catColor = (t, c) => (CATS[t].find(x => x[0] === c) || [0, '#8a8a8a'])[1];
const B = { tab: 'sum', mon: 0 };
const bMonth = () => {
  const n = new Date(), d = new Date(n.getFullYear(), n.getMonth() + B.mon, 1);
  return { key: d.getFullYear() + '-' + pad(d.getMonth() + 1), label: d.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' }) };
};
const monthStats = async key => {
  const tx = (await DB.all('tx')).filter(t => t.date.startsWith(key));
  const s = k => tx.filter(x => x.type === k).reduce((a, x) => a + x.amount, 0);
  return { tx, inc: s('in'), out: s('out') };
};
MV.budget = async m => {
  const mi = bMonth();
  const [{ tx, inc, out }, cfg] = [await monthStats(mi.key), (await DB.get('kv', 'budget')) || {}];
  tx.sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  const limit = cfg.limit || 0, bal = inc - out;
  let body = '';
  if (B.tab === 'sum') {
    const g = {}; tx.filter(x => x.type === 'out').forEach(x => g[x.cat] = (g[x.cat] || 0) + x.amount);
    const gs = Object.entries(g).sort((a, b) => b[1] - a[1]);
    const R = 60, C = 2 * Math.PI * R; let off = 0;
    const segs = gs.map(([c, v]) => { const l = v / out * C, s = `<circle cx="75" cy="75" r="${R}" fill="none" stroke="${catColor('out', c)}" stroke-width="15" stroke-dasharray="${Math.max(l - 3, .5)} ${C}" stroke-dashoffset="${-off}"/>`; off += l; return s; }).join('');
    const pct = limit ? out / limit : 0, lc = pct < .75 ? '#31c76a' : pct < 1 ? '#ffb547' : '#ff5252';
    body = `<section class="card"><span class="label">Kalan</span><div class="big ${bal < 0 ? 'neg' : ''}">${money(bal)}</div>
      <div class="cols2"><div><span class="label">Gelir</span><div class="mid pos">${money(inc)}</div></div><div><span class="label">Gider</span><div class="mid neg">${money(out)}</div></div></div></section>
    <section class="card"><div class="sec" style="margin:0"><h2>Aylık limit</h2><small><a href="#/m/budget" data-a="limit" style="color:var(--blue)">${limit ? 'Düzenle' : 'Belirle'}</a></small></div>
      ${limit ? `<div class="pb" style="--c:${lc}"><i style="width:${Math.min(pct, 1) * 100}%"></i></div><p class="empty" style="margin-top:10px">${money(out)} / ${money(limit)}${pct >= 1 ? ' · limit aşıldı' : ' · ' + money(limit - out) + ' kaldı'}</p>` : '<p class="empty" style="margin-top:8px">Harcamalarını izlemek için bir aylık limit belirle.</p>'}</section>
    <section class="card"><div class="sec" style="margin:0 0 14px"><h2>Harcama dağılımı</h2></div>${gs.length ? `
      <div class="donut"><svg viewBox="0 0 150 150" width="150" height="150" style="transform:rotate(-90deg)"><circle cx="75" cy="75" r="${R}" fill="none" stroke="#262626" stroke-width="15"/>${segs}</svg><div><span class="label">Gider</span><b class="mid">${money(out)}</b></div></div>
      ${gs.map(([c, v]) => `<div class="row" style="cursor:default"><span class="dot" style="--c:${catColor('out', c)}">${c[0]}</span><span class="t"><b>${c}</b><small>%${Math.round(v / out * 100)}</small></span><span class="amt2">${money(v)}</span></div>`).join('')}` : '<p class="empty">Bu ay gider kaydı yok. + ile ilk işlemini ekle.</p>'}</section>`;
  } else {
    const days = [...new Set(tx.map(t => t.date))];
    body = days.length ? days.map(d => `<div class="dh">${dlabel(d)}</div><section class="card" style="padding:4px 16px">${tx.filter(t => t.date === d).map(t => `<button class="row" data-a="txOpen" data-id="${t.id}"><span class="dot" style="--c:${catColor(t.type, t.cat)}">${t.cat[0]}</span><span class="t"><b>${esc(t.cat)}</b>${t.note ? `<small>${esc(t.note)}</small>` : ''}</span><span class="amt2 ${t.type === 'in' ? 'pos' : ''}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</span></button>`).join('')}</section>`).join('') : '<section class="card"><p class="empty">Bu ay işlem yok.</p></section>';
  }
  view.innerHTML = `${mhero(m)}${seg('btab', [['sum', 'Özet'], ['list', 'İşlemler']], B.tab)}
    <div class="month"><button data-a="bmon" data-d="-1" aria-label="Önceki ay">${ic('back', 20)}</button><b>${mi.label}</b><button data-a="bmon" data-d="1" aria-label="Sonraki ay">${ic('next', 20)}</button></div>${body}${fab('txNew', 'green')}`;
  $('#btab').onchange = () => { B.tab = $('#btab').dataset.val; route(); };
};
A.bmon = b => { B.mon += +b.dataset.d; route(); };
A.txNew = () => {
  const cats = t => chips('tcat', CATS[t].map(([n, c]) => [n, n, c]), CATS[t][0][0]);
  sheet(`<h2 class="st">Yeni işlem</h2>${seg('ttype', [['out', 'Gider'], ['in', 'Gelir']], 'out')}
    <input class="amt" id="tamt" inputmode="decimal" placeholder="0,00 ₺">
    <div class="field" id="tcatw">${cats('out')}</div>
    <div class="field"><label>Not</label><input id="tnote" placeholder="İsteğe bağlı" maxlength="60"></div>
    <div class="field"><label>Tarih</label><input id="tdate" type="date" value="${today()}"></div>
    <button class="btn" style="width:100%" data-a="txSave">Kaydet</button>`);
  $('#ttype').onchange = () => { $('#tcatw').innerHTML = cats($('#ttype').dataset.val); };
};
A.txSave = async () => {
  const amount = num($('#tamt').value);
  if (!(amount > 0)) { toast('Geçerli bir tutar gir'); return $('#tamt').focus(); }
  await DB.put('tx', { id: DB.uid(), type: $('#ttype').dataset.val, amount, cat: $('#tcat').dataset.val, note: $('#tnote').value.trim(), date: $('#tdate').value || today(), created: Date.now() });
  A.closeSheet(); toast('İşlem kaydedildi'); route();
};
A.txOpen = async b => {
  const t = await DB.get('tx', b.dataset.id); if (!t) return;
  sheet(`<h2 class="st">${esc(t.cat)}</h2><div class="big ${t.type === 'in' ? 'pos' : 'neg'}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</div>
    <p class="empty" style="margin:8px 0 20px">${dlabel(t.date)}${t.note ? ' · ' + esc(t.note) : ''}</p><button class="btn danger" style="width:100%" data-a="txDel" data-id="${t.id}">İşlemi sil</button>`);
};
A.txDel = async b => { await DB.del('tx', b.dataset.id); A.closeSheet(); toast('İşlem silindi'); route(); };
A.limit = async () => {
  const c = (await DB.get('kv', 'budget')) || {};
  sheet(`<h2 class="st">Aylık gider limiti</h2><input class="amt" id="tlim" inputmode="decimal" placeholder="0 ₺" value="${c.limit || ''}"><button class="btn" style="width:100%" data-a="limSave">Kaydet</button>`);
};
A.limSave = async () => { await DB.put('kv', { limit: num($('#tlim').value) || 0 }, 'budget'); A.closeSheet(); route(); };
