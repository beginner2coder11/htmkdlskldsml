/* LIFE OS – Cüzdanım */
const mshort = n => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(n);
const B = { tab: 'mov', per: 'month', off: 0 };
const sumBy = (arr, k) => arr.filter(x => x.type === k).reduce((n, x) => n + x.amount, 0);
const monthStats = async key => { const tx = (await DB.all('tx')).filter(t => t.date.startsWith(key)); return { tx, inc: sumBy(tx, 'in'), out: sumBy(tx, 'out') }; };
const rng = () => {
  const n = new Date(), t = new Date(n.getFullYear(), n.getMonth(), n.getDate()); let a, b, label;
  if (B.per === 'day') { a = b = new Date(t.getFullYear(), t.getMonth(), t.getDate() + B.off); label = dtxt(dstr(a)); }
  else if (B.per === 'week') { a = new Date(t.getFullYear(), t.getMonth(), t.getDate() - ((t.getDay() + 6) % 7) + 7 * B.off); b = new Date(a.getFullYear(), a.getMonth(), a.getDate() + 6); label = `${a.getDate()} ${MON[a.getMonth()]} – ${b.getDate()} ${MON[b.getMonth()]}`; }
  else { a = new Date(t.getFullYear(), t.getMonth() + B.off, 1); b = new Date(a.getFullYear(), a.getMonth() + 1, 0); label = `${MON[a.getMonth()]} ${a.getFullYear()}`; }
  return { a: dstr(a), b: dstr(b), label };
};
const nowRanges = () => {
  const t = new Date(), d = dstr(t), w = new Date(t.getFullYear(), t.getMonth(), t.getDate() - ((t.getDay() + 6) % 7)), m = new Date(t.getFullYear(), t.getMonth(), 1);
  return [['Bugün', d, d], ['Bu hafta', dstr(w), dstr(new Date(w.getFullYear(), w.getMonth(), w.getDate() + 6))], ['Bu ay', dstr(m), dstr(new Date(m.getFullYear(), m.getMonth() + 1, 0))]];
};
const txRow = t => `<button class="row" data-a="txOpen" data-id="${t.id}"><span class="dot" style="--c:${t.type === 'in' ? '#74b88f' : '#d98383'}">${t.type === 'in' ? '+' : '−'}</span><span class="t"><b>${t.note ? esc(t.note) : (t.type === 'in' ? 'Gelir' : 'Gider')}</b><small>${dlabel(t.date)}</small></span><span class="amt2 ${t.type === 'in' ? 'pos' : 'neg'}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</span></button>`;
const txSection = (title, type, items) => `<section class="card"><div class="sec" style="margin:0 0 6px"><h2>${title}</h2><b class="mid ${type === 'in' ? 'pos' : 'neg'}">${money(sumBy(items, type))}</b></div>${items.length ? items.map(txRow).join('') : '<p class="empty">Bu dönemde kayıt yok.</p>'}</section>`;

async function movBody() {
  const all = await DB.all('tx'), r = rng();
  const items = all.filter(t => t.date >= r.a && t.date <= r.b).sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  const inc = sumBy(items, 'in'), out = sumBy(items, 'out'), bal = inc - out;
  const stats = nowRanges().map(([n, a, b]) => { const p = all.filter(t => t.date >= a && t.date <= b); return `<div class="stat"><span class="label">${n}</span><b class="pos">+${mshort(sumBy(p, 'in'))}</b><b class="neg">−${mshort(sumBy(p, 'out'))}</b></div>`; }).join('');
  const per = [['day', 'Gün'], ['week', 'Hafta'], ['month', 'Ay']];
  setTimeout(() => { const g = $('#bper'); if (g) g.onchange = () => { B.per = g.dataset.val; B.off = 0; route(); }; });
  return `<div class="stats">${stats}</div>${seg('bper', per, B.per)}
    <div class="month"><button data-a="bnav" data-d="-1" aria-label="Önceki">${ic('back', 20)}</button><b>${r.label}</b><button data-a="bnav" data-d="1" aria-label="Sonraki">${ic('next', 20)}</button></div>
    <section class="card"><span class="label">Kalan</span><div class="big ${bal < 0 ? 'neg' : ''}">${money(bal)}</div>
      <div class="cols2"><div><span class="label">Toplam gelir</span><div class="mid pos">${money(inc)}</div></div><div><span class="label">Toplam gider</span><div class="mid neg">${money(out)}</div></div></div></section>
    ${txSection('Gelirler', 'in', items.filter(t => t.type === 'in'))}${txSection('Giderler', 'out', items.filter(t => t.type === 'out'))}`;
}
async function debtBody() {
  const ds = await DB.all('debts'), open = ds.filter(d => !d.paid), rec = open.filter(d => d.kind === 'recv'), owe = open.filter(d => d.kind === 'owe');
  const done = ds.filter(d => d.paid).sort((a, b) => b.created - a.created).slice(0, 5), tot = a => a.reduce((n, d) => n + d.amount, 0);
  const dRow = d => `<button class="row" data-a="debtOpen" data-id="${d.id}"><span class="dot" style="--c:${d.kind === 'recv' ? '#74b88f' : '#d98383'}">${esc((d.person[0] || '?').toUpperCase())}</span><span class="t"><b>${esc(d.person)}</b><small>${d.due ? 'Vade: ' + dlabel(d.due) : 'Vade yok'}${d.note ? ' · ' + esc(d.note) : ''}</small></span><span class="amt2 ${d.kind === 'recv' ? 'pos' : 'neg'}">${money(d.amount)}</span></button>`;
  const sec = (t, a, c) => `<section class="card"><div class="sec" style="margin:0 0 6px"><h2>${t}</h2><b class="mid ${c}">${money(tot(a))}</b></div>${a.length ? a.map(dRow).join('') : '<p class="empty">Kayıt yok.</p>'}</section>`;
  const net = tot(rec) - tot(owe);
  return `<section class="card"><span class="label">Net durum (alacak − borç)</span><div class="big ${net < 0 ? 'neg' : ''}">${money(net)}</div></section>${sec('Alacaklarım', rec, 'pos')}${sec('Borçlarım', owe, 'neg')}${done.length ? `<div class="dh">Kapananlar</div><section class="card" style="padding:4px 16px;opacity:.7">${done.map(dRow).join('')}</section>` : ''}`;
}
async function goalBody() {
  const gs = (await DB.all('goals')).sort((a, b) => b.created - a.created);
  return gs.length ? gs.map(g => { const p = Math.min(g.saved / g.target, 1); return `<button class="card goal" data-a="goalOpen" data-id="${g.id}" style="--c:${p >= 1 ? '#74b88f' : '#7aa7e0'}"><div style="display:flex;justify-content:space-between;gap:10px"><b>${esc(g.name)}</b><span class="label">%${Math.round(p * 100)}</span></div><div class="pb"><i style="width:${p * 100}%"></i></div><p class="empty" style="margin-top:10px">${money(g.saved)} / ${money(g.target)}</p></button>`; }).join('') : '<section class="card"><p class="empty">Birikim hedefi yok. + ile ilk hedefini ekle.</p></section>';
}
MV.budget = async m => {
  const body = B.tab === 'mov' ? await movBody() : B.tab === 'debt' ? await debtBody() : await goalBody();
  view.innerHTML = `${mhero(m)}${seg('btab', [['mov', 'Hareketler'], ['debt', 'Borç / Alacak'], ['goal', 'Birikim']], B.tab)}<div style="height:16px"></div>${body}${fab(B.tab === 'mov' ? 'txNew' : B.tab === 'debt' ? 'debtNew' : 'goalNew', 'green')}`;
  $('#btab').onchange = () => { B.tab = $('#btab').dataset.val; route(); };
};
A.bnav = b => { B.off += +b.dataset.d; route(); };
A.txNew = b => {
  const t = (b && b.dataset && b.dataset.t) || 'out';
  sheet(`<h2 class="st">Yeni işlem</h2>${seg('ttype', [['in', 'Gelir'], ['out', 'Gider']], t)}
    <input class="amt" id="tamt" inputmode="decimal" placeholder="0,00 ₺">
    <div class="field"><label>Açıklama</label><input id="tnote" placeholder="İsteğe bağlı" maxlength="60"></div>
    ${dateField('tdate', 'Tarih', today())}
    <button class="btn" style="width:100%" data-a="txSave">Kaydet</button>`);
};
A.txSave = async () => {
  const amount = num($('#tamt').value);
  if (!(amount > 0)) { toast('Geçerli bir tutar gir'); return $('#tamt').focus(); }
  await DB.put('tx', { id: DB.uid(), type: $('#ttype').dataset.val, amount, note: $('#tnote').value.trim(), date: $('#tdate').dataset.val || today(), created: Date.now() });
  A.closeSheet(); toast('İşlem kaydedildi'); route();
};
A.txOpen = async b => {
  const t = await DB.get('tx', b.dataset.id); if (!t) return;
  sheet(`<h2 class="st">${t.type === 'in' ? 'Gelir' : 'Gider'}</h2><div class="big ${t.type === 'in' ? 'pos' : 'neg'}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</div>
    <p class="empty" style="margin:8px 0 20px">${dtxt(t.date)}${t.note ? ' · ' + esc(t.note) : ''}</p><button class="btn danger" style="width:100%" data-a="txDel" data-id="${t.id}">İşlemi sil</button>`);
};
A.txDel = async b => { await DB.del('tx', b.dataset.id); A.closeSheet(); toast('İşlem silindi'); route(); };
