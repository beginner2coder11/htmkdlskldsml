/* LIFE OS – Cüzdanım */
const CATS = {
  out: [['Market', '#74b88f'], ['Fatura', '#d9ad66'], ['Ulaşım', '#7aa7e0'], ['Yemek', '#d98383'], ['Sağlık', '#a898d8'], ['Alışveriş', '#a9c4ea'], ['Eğlence', '#c9bfe8'], ['Diğer', '#8d949e']],
  in: [['Maaş', '#74b88f'], ['Ek gelir', '#7aa7e0'], ['Diğer', '#8d949e']]
};
const catColor = (t, c) => (CATS[t].find(x => x[0] === c) || [0, '#8d949e'])[1];
const mshort = n => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(n);
const B = { per: 'month', off: 0 };
const sumBy = (arr, k) => arr.filter(x => x.type === k).reduce((n, x) => n + x.amount, 0);
const monthStats = async key => { const tx = (await DB.all('tx')).filter(t => t.date.startsWith(key)); return { tx, inc: sumBy(tx, 'in'), out: sumBy(tx, 'out') }; };
const rng = () => {
  const n = new Date(), t = new Date(n.getFullYear(), n.getMonth(), n.getDate()); let a, b, label;
  if (B.per === 'day') { a = b = new Date(t.getFullYear(), t.getMonth(), t.getDate() + B.off); label = dtxt(dstr(a)); }
  else if (B.per === 'week') { a = new Date(t.getFullYear(), t.getMonth(), t.getDate() - ((t.getDay() + 6) % 7) + 7 * B.off); b = new Date(a.getFullYear(), a.getMonth(), a.getDate() + 6); label = `${a.getDate()} ${MON[a.getMonth()]} – ${b.getDate()} ${MON[b.getMonth()]}`; }
  else { a = new Date(t.getFullYear(), t.getMonth() + B.off, 1); b = new Date(a.getFullYear(), a.getMonth() + 1, 0); label = `${MON[a.getMonth()]} ${a.getFullYear()}`; }
  return { a: dstr(a), b: dstr(b), label };
};
const nowRanges = () => {
  const t = new Date(), d = dstr(t), w = new Date(t.getFullYear(), t.getMonth(), t.getDate() - ((t.getDay() + 6) % 7)), m = new Date(t.getFullYear(), t.getMonth(), 1);
  return [['Bugün', d, d], ['Bu hafta', dstr(w), dstr(new Date(w.getFullYear(), w.getMonth(), w.getDate() + 6))], ['Bu ay', dstr(m), dstr(new Date(m.getFullYear(), m.getMonth() + 1, 0))]];
};
const txRow = t => `<button class="row" data-a="txOpen" data-id="${t.id}"><span class="dot" style="--c:${catColor(t.type, t.cat)}">${esc(t.cat[0])}</span><span class="t"><b>${esc(t.cat)}</b><small>${t.note ? esc(t.note) + ' · ' : ''}${dlabel(t.date)}</small></span><span class="amt2 ${t.type === 'in' ? 'pos' : ''}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</span></button>`;
const txSection = (title, type, items) => {
  const total = sumBy(items, type);
  const head = `<div class="sec" style="margin:0 0 14px"><h2>${title}</h2><b class="mid ${type === 'in' ? 'pos' : 'neg'}">${money(total)}</b></div>`;
  if (!items.length) return `<section class="card">${head}<p class="empty">Bu dönemde kayıt yok.</p></section>`;
  const g = {}; items.forEach(x => g[x.cat] = (g[x.cat] || 0) + x.amount);
  const bars = Object.entries(g).sort((a, b) => b[1] - a[1]).map(([c, v]) => `<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;gap:10px"><span>${esc(c)}</span><span class="label">%${Math.round(v / total * 100)} · ${money(v)}</span></div><div class="pb" style="--c:${catColor(type, c)};margin-top:7px"><i style="width:${v / total * 100}%"></i></div></div>`).join('');
  return `<section class="card">${head}${bars}<div class="dh" style="margin:18px 0 4px">Tüm kayıtlar (${items.length})</div>${items.map(txRow).join('')}</section>`;
};
MV.budget = async m => {
  const all = await DB.all('tx'), cfg = (await DB.get('kv', 'budget')) || {}, r = rng();
  const items = all.filter(t => t.date >= r.a && t.date <= r.b).sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  const outs = items.filter(t => t.type === 'out'), ins = items.filter(t => t.type === 'in');
  const inc = sumBy(items, 'in'), out = sumBy(items, 'out'), bal = inc - out, limit = cfg.limit || 0, pct = limit ? out / limit : 0;
  const lc = pct < .75 ? '#74b88f' : pct < 1 ? '#d9ad66' : '#d98383';
  const stats = nowRanges().map(([n, a, b]) => { const p = all.filter(t => t.date >= a && t.date <= b); return `<div class="stat"><span class="label">${n}</span><b class="pos">+${mshort(sumBy(p, 'in'))}</b><b class="neg">−${mshort(sumBy(p, 'out'))}</b></div>`; }).join('');
  const per = { day: 'Gün', week: 'Hafta', month: 'Ay' };
  view.innerHTML = `${mhero(m)}<div class="stats">${stats}</div>
    ${seg('bper', Object.entries(per), B.per)}
    <div class="month"><button data-a="bnav" data-d="-1" aria-label="Önceki">${ic('back', 20)}</button><b>${r.label}</b><button data-a="bnav" data-d="1" aria-label="Sonraki">${ic('next', 20)}</button></div>
    <section class="card"><span class="label">${per[B.per]} sonunda kalan</span><div class="big ${bal < 0 ? 'neg' : ''}">${money(bal)}</div>
      <div class="cols2"><div><span class="label">Toplam gelir</span><div class="mid pos">${money(inc)}</div></div><div><span class="label">Toplam gider</span><div class="mid neg">${money(out)}</div></div></div></section>
    ${B.per === 'month' ? `<section class="card"><div class="sec" style="margin:0"><h2>Aylık limit</h2><small><a href="#/m/budget" data-a="limit" style="color:var(--blue)">${limit ? 'Düzenle' : 'Belirle'}</a></small></div>${limit ? `<div class="pb" style="--c:${lc}"><i style="width:${Math.min(pct, 1) * 100}%"></i></div><p class="empty" style="margin-top:10px">${money(out)} / ${money(limit)}${pct >= 1 ? ' · limit aşıldı' : ' · ' + money(limit - out) + ' kaldı'}</p>` : '<p class="empty" style="margin-top:8px">Harcamalarını izlemek için aylık limit belirle.</p>'}</section>` : ''}
    ${txSection('Giderler', 'out', outs)}${txSection('Gelirler', 'in', ins)}${fab('txNew', 'green')}`;
  $('#bper').onchange = () => { B.per = $('#bper').dataset.val; B.off = 0; route(); };
};
A.bnav = b => { B.off += +b.dataset.d; route(); };
A.txNew = () => {
  const cats = t => chips('tcat', CATS[t].map(([n, c]) => [n, n, c]), CATS[t][0][0]);
  sheet(`<h2 class="st">Yeni işlem</h2>${seg('ttype', [['out', 'Gider'], ['in', 'Gelir']], 'out')}
    <input class="amt" id="tamt" inputmode="decimal" placeholder="0,00 ₺">
    <div class="field" id="tcatw">${cats('out')}</div>
    <div class="field"><label>Not (nereye harcadın / nereden geldi)</label><input id="tnote" placeholder="İsteğe bağlı" maxlength="60"></div>
    ${dateField('tdate', 'Tarih', today())}
    <button class="btn" style="width:100%" data-a="txSave">Kaydet</button>`);
  $('#ttype').onchange = () => { $('#tcatw').innerHTML = cats($('#ttype').dataset.val); };
};
A.txSave = async () => {
  const amount = num($('#tamt').value);
  if (!(amount > 0)) { toast('Geçerli bir tutar gir'); return $('#tamt').focus(); }
  await DB.put('tx', { id: DB.uid(), type: $('#ttype').dataset.val, amount, cat: $('#tcat').dataset.val, note: $('#tnote').value.trim(), date: $('#tdate').dataset.val || today(), created: Date.now() });
  A.closeSheet(); toast('İşlem kaydedildi'); route();
};
A.txOpen = async b => {
  const t = await DB.get('tx', b.dataset.id); if (!t) return;
  sheet(`<h2 class="st">${esc(t.cat)}</h2><div class="big ${t.type === 'in' ? 'pos' : 'neg'}">${t.type === 'in' ? '+' : '−'}${money(t.amount)}</div>
    <p class="empty" style="margin:8px 0 20px">${dtxt(t.date)}${t.note ? ' · ' + esc(t.note) : ''}</p><button class="btn danger" style="width:100%" data-a="txDel" data-id="${t.id}">İşlemi sil</button>`);
};
A.txDel = async b => { await DB.del('tx', b.dataset.id); A.closeSheet(); toast('İşlem silindi'); route(); };
A.limit = async () => {
  const c = (await DB.get('kv', 'budget')) || {};
  sheet(`<h2 class="st">Aylık gider limiti</h2><input class="amt" id="tlim" inputmode="decimal" placeholder="0 ₺" value="${c.limit || ''}"><button class="btn" style="width:100%" data-a="limSave">Kaydet</button>`);
};
A.limSave = async () => { await DB.put('kv', { limit: num($('#tlim').value) || 0 }, 'budget'); A.closeSheet(); route(); };
