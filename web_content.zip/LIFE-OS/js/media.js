/* LIFE OS – Media (PIN korumalı, şifreli foto/video kitaplığı) */
const MD = { f: 'all', list: [], idx: 0, url: '', dirty: false };
const CH = 4 * 1024 * 1024, MAXF = 600 * 1024 * 1024;
const mEncBuf = async buf => { const iv = crypto.getRandomValues(new Uint8Array(12)); return { iv, d: await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, VT.key, buf) }; };
const mDecBuf = r => crypto.subtle.decrypt({ name: 'AES-GCM', iv: r.iv }, VT.key, r.d);
const prog = (t, p) => {
  let o = $('#prog'); if (!o) { o = document.createElement('div'); o.id = 'prog'; o.className = 'prog'; document.body.appendChild(o); }
  o.innerHTML = `<div class="pp"><b>${esc(t)}</b><div class="pb" style="--c:var(--blue)"><i style="width:${Math.round(p * 100)}%"></i></div></div>`;
};
const progOff = () => { const o = $('#prog'); if (o) o.remove(); };
const blobUrl = b => new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.onerror = () => r(null); fr.readAsDataURL(b); });
const vidThumb = f => new Promise(res => {
  const u = URL.createObjectURL(f), v = document.createElement('video'); let end = false;
  const done = x => { if (end) return; end = true; URL.revokeObjectURL(u); res(x); };
  v.muted = true; v.preload = 'metadata'; v.playsInline = true;
  v.onloadeddata = () => { v.currentTime = Math.min(1, (v.duration || 2) / 2); };
  v.onseeked = () => { try { const k = Math.min(1, 360 / Math.max(v.videoWidth, v.videoHeight)), c = document.createElement('canvas'); c.width = Math.round(v.videoWidth * k) || 1; c.height = Math.round(v.videoHeight * k) || 1; c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); done(c.toDataURL('image/jpeg', .7)); } catch (e) { done(null); } };
  v.onerror = () => done(null); setTimeout(() => done(null), 8000); v.src = u;
});
const mThumb = async f => f.type.startsWith('video/') ? vidThumb(f) : (async () => { const b = await mkThumb(f); return b ? blobUrl(b) : null; })();
async function mImport(files, onProg) {
  let ok = 0;
  for (const [fi, f] of files.entries()) {
    if (!f.type.startsWith('video/') && !f.type.startsWith('image/')) continue;
    if (f.size > MAXF) { toast(`${f.name}: çok büyük (en fazla ${fmtSize(MAXF)})`); continue; }
    const id = DB.uid(), n = Math.max(1, Math.ceil(f.size / CH)); let wrote = 0;
    try {
      for (let i = 0; i < n; i++) {
        const e = await mEncBuf(await f.slice(i * CH, Math.min((i + 1) * CH, f.size)).arrayBuffer());
        await DB.put('mediachunks', { k: id + ':' + i, id, iv: e.iv, d: e.d }); wrote++; if (onProg) onProg(f.name, (i + 1) / n, fi + 1, files.length);
      }
      const thumb = await mThumb(f);
      await DB.put('media', { id, kind: f.type.startsWith('video/') ? 'vid' : 'img', n, created: Date.now(), ...await vEnc({ name: f.name.replace(/\.[^.]+$/, '') || 'Dosya', type: f.type, size: f.size, fav: false, thumb }) });
      ok++;
    } catch (e) {
      for (let i = 0; i < wrote; i++) { try { await DB.del('mediachunks', id + ':' + i); } catch (x) { /* yoksay */ } }
      toast('Eklenemedi: depolama alanı yetersiz olabilir');
    }
  }
  return ok;
}
async function mBlob(rec, meta) {
  const parts = []; for (let i = 0; i < rec.n; i++) { const c = await DB.get('mediachunks', rec.id + ':' + i); parts.push(await mDecBuf(c)); }
  return new Blob(parts, { type: meta.type });
}
const mDelRec = async it => { for (let i = 0; i < it.n; i++) await DB.del('mediachunks', it.id + ':' + i); await DB.del('media', it.id); };

MV.media = async m => {
  if (!await vGate(m)) return; VT.last = Date.now();
  const items = [];
  for (const r of await DB.all('media')) { try { items.push({ ...r, o: await vDec(r) }); } catch (e) { /* okunamayan */ } }
  items.sort((a, b) => b.created - a.created);
  const list = items.filter(i => MD.f === 'all' || (MD.f === 'img' && i.kind === 'img') || (MD.f === 'vid' && i.kind === 'vid') || (MD.f === 'fav' && i.o.fav)); MD.list = list;
  const total = items.reduce((n, i) => n + (i.o.size || 0), 0);
  view.innerHTML = `${mhero(m, '#/home', `${items.length} dosya · ${fmtSize(total)}`)}
  <div class="bar" style="margin:0 0 14px"><button class="btn w" data-a="mAdd">Dosya ekle</button><button class="btn sec w" data-a="mCam">Kamera</button><button class="btn sec" data-a="vLockNow" style="flex:none">Kilitle</button></div>
  <input type="file" id="mfile" accept="image/*,video/*" multiple hidden>${chips('mflt', [['all', 'Tümü'], ['img', 'Fotoğraf'], ['vid', 'Video'], ['fav', '★ Favoriler']], MD.f)}<div style="height:14px"></div>
  ${list.length ? `<div class="phg">${list.map((i, k) => `<button class="ph" data-a="mOpen" data-k="${k}">${i.o.thumb ? `<img alt="" src="${i.o.thumb}">` : `<div class="pdf">${mi(i.kind === 'vid' ? 'media' : 'docs', 34)}<span>${esc(i.o.name)}</span></div>`}${i.kind === 'vid' ? '<b class="play">▶</b>' : ''}${i.o.fav ? '<i>★</i>' : ''}</button>`).join('')}</div>` : '<section class="card"><p class="empty">Henüz dosya yok. “Dosya ekle” ile galerinden foto ve video seçebilirsin; hepsi şifrelenerek uygulamaya kopyalanır.</p></section>'}
  <p class="label" style="margin:16px 2px 0">Not: Kopyalamadan sonra telefon galerisindeki orijinaller silinmez. Gizlilik için onları kendin sil.</p>`;
  $('#mflt').onchange = () => { MD.f = $('#mflt').dataset.val; route(); };
  $('#mfile').onchange = async e => {
    const files = [...e.target.files]; if (!files.length) return;
    prog('Şifreleniyor…', 0);
    const ok = await mImport(files, (name, p, i, n) => prog(`Şifreleniyor ${i}/${n} · ${name}`, p));
    progOff(); if (ok) toast(`${ok} dosya şifrelenip eklendi`); route();
  };
  every(() => { if (VT.key && !VT.hold && Date.now() - VT.last > 180000) { vLock(); A.mClose(); route(); } }, 5000);
};
A.mAdd = () => $('#mfile').click();
A.mCam = () => openCam('media');
async function mView(k) {
  const it = MD.list[k]; if (!it) return; MD.idx = k; const o = it.o;
  prog('Açılıyor…', .3); let blob;
  try { blob = await mBlob(it, o); } catch (e) { progOff(); return toast('Dosya açılamadı'); }
  progOff(); if (MD.url) URL.revokeObjectURL(MD.url); MD.url = URL.createObjectURL(blob);
  let v = $('#mviewer'); if (!v) { v = document.createElement('div'); v.id = 'mviewer'; v.className = 'viewer'; document.body.appendChild(v); }
  v.innerHTML = `<div class="vtop"><button class="nb" data-a="mClose" aria-label="Kapat">${ic('back', 22)}</button><b class="vt">${esc(o.name)}</b><button class="nb" id="mfav" data-a="mFav" style="color:${o.fav ? 'var(--orange)' : 'var(--tx2)'}">${o.fav ? '★' : '☆'}</button></div>
  <div class="vbody" id="mbody">${it.kind === 'vid' ? `<video id="mvid" src="${MD.url}" controls playsinline autoplay></video>` : `<img src="${MD.url}" alt="">`}</div>
  <div class="vbar"><button class="nb" data-a="mPrev" aria-label="Önceki" ${k === 0 ? 'disabled' : ''}>${ic('back', 22)}</button><button class="btn sec w" data-a="mShare">Dışa aktar</button><button class="btn danger w" data-a="mDel">Sil</button><button class="nb" data-a="mNext" aria-label="Sonraki" ${k >= MD.list.length - 1 ? 'disabled' : ''}>${ic('next', 22)}</button></div>`;
  const vid = $('#mvid');
  if (vid) {
    vid.onplay = () => { VT.hold = true; }; vid.onpause = () => { VT.hold = false; };
    vid.onended = () => { VT.hold = false; if (MD.idx < MD.list.length - 1) { for (let j = MD.idx + 1; j < MD.list.length; j++) if (MD.list[j].kind === 'vid') return mView(j); } };
  } else {
    let x0 = null; const b = $('#mbody');
    b.ontouchstart = e => { x0 = e.touches.length === 1 ? e.touches[0].clientX : null; };
    b.ontouchend = e => { if (x0 === null || (window.visualViewport && window.visualViewport.scale > 1.05)) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (dx > 80) A.mPrev(); else if (dx < -80) A.mNext(); };
  }
}
A.mOpen = b => mView(+b.dataset.k);
A.mPrev = () => { if (MD.idx > 0) mView(MD.idx - 1); };
A.mNext = () => { if (MD.idx < MD.list.length - 1) mView(MD.idx + 1); };
A.mClose = () => { const v = $('#mviewer'); if (v) v.remove(); if (MD.url) { URL.revokeObjectURL(MD.url); MD.url = ''; } VT.hold = false; if (MD.dirty) { MD.dirty = false; route(); } };
A.mFav = async () => {
  const it = MD.list[MD.idx]; if (!it || !VT.key) return; it.o.fav = !it.o.fav;
  await DB.put('media', { id: it.id, kind: it.kind, n: it.n, created: it.created, ...await vEnc(it.o) });
  const f = $('#mfav'); if (f) { f.textContent = it.o.fav ? '★' : '☆'; f.style.color = it.o.fav ? 'var(--orange)' : 'var(--tx2)'; } MD.dirty = true;
};
A.mShare = async () => {
  const it = MD.list[MD.idx]; if (!it) return; const ext = (it.o.type.split('/')[1] || 'bin').replace('jpeg', 'jpg').replace('quicktime', 'mov');
  const r = await shareFile(await mBlob(it, it.o), it.o.name + '.' + ext);
  if (r === 'shared') toast('Paylaşım menüsü açıldı'); else if (r === 'download') toast('İndirme başlatıldı. İndirilenler klasörüne bak.');
};
A.mDel = async () => {
  const it = MD.list[MD.idx]; if (!it || !confirm('Bu dosya silinsin mi?')) return;
  await mDelRec(it); MD.list.splice(MD.idx, 1); MD.dirty = true; toast('Silindi');
  if (!MD.list.length) A.mClose(); else mView(Math.min(MD.idx, MD.list.length - 1));
};
