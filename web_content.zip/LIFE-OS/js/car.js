/* LIFE OS – Araç takibi */
const CR = { tab: 'sum', car: '' };
const CT = { fuel: ['Yakıt', '#d9ad66'], svc: ['Bakım', '#7aa7e0'], other: ['Diğer', '#a898d8'] };
const dleft = ds => ds ? Math.round((new Date(ds + 'T00:00') - new Date(today() + 'T00:00')) / 864e5) : null;
const dcol = n => n < 0 || n <= 7 ? '#d98383' : n <= 30 ? '#d9ad66' : '#74b88f';
const dtext = n => n === 0 ? 'Bugün' : n < 0 ? `${-n} gün geçti` : `${n} gün kaldı`;
const fuelAvg = logs => {
  const f = logs.filter(l => l.type === 'fuel' && l.liters > 0 && l.km > 0).sort((a, b) => a.km - b.km);
  if (f.length < 2) return null; const dist = f[f.length - 1].km - f[0].km; if (dist <= 0) return null;
  return f.slice(1).reduce((n, l) => n + l.liters, 0) / dist * 100;
};
MV.car = async m => {
  const cars = await DB.all('cars');
  if (!cars.length) { view.innerHTML = `${mhero(m)}<section class="card"><p class="empty" style="margin-bottom:14px">Henüz araç eklemedin. Muayene, sigorta, yakıt ve bakım takibi için aracını ekle.</p><button class="btn" style="width:100%" data-a="carNew">Araç ekle</button></section>`; return; }
  const car = cars.find(c => c.id === CR.car) || cars[0]; CR.car = car.id;
  const logs = (await DB.all('carlogs')).filter(l => l.carId === car.id).sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  const yr = String(new Date().getFullYear()), mo = today().slice(0, 7);
  let body = '';
  if (CR.tab === 'sum') {
    const rem = [['Muayene', car.muayene], ['Trafik sigortası', car.sigorta], ['Kasko', car.kasko], ['Bakım tarihi', car.svcDate]].filter(r => r[1]);
    const kmLeft = car.svcKm ? car.svcKm - (car.km || 0) : null, avg = fuelAvg(logs);
    const sum = f => logs.filter(f).reduce((n, l) => n + (l.amount || 0), 0);
    body = `<section class="card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px"><div><span class="label">${esc(car.plate || 'Plaka yok')}</span><div class="mid" style="margin-top:2px">${esc(car.name)}</div></div><button class="btn sec" data-a="carEdit" style="padding:9px 14px">Düzenle</button></div><div class="big" style="margin-top:14px">${fmt(car.km || 0)} <span class="label">km</span></div></section>
    <div class="sec" style="margin-top:6px"><h2>Hatırlatmalar</h2></div>
    <section class="card" style="padding:4px 16px">${rem.length || kmLeft !== null ? rem.map(([n, d]) => { const k = dleft(d), c = dcol(k); return `<div class="row" style="cursor:default"><span class="dot" style="--c:${c}">${n[0]}</span><span class="t"><b>${n}</b><small>${dtxt(d)}</small></span><span class="amt2" style="color:${c}">${dtext(k)}</span></div>`; }).join('') + (kmLeft !== null ? `<div class="row" style="cursor:default"><span class="dot" style="--c:${kmLeft <= 0 ? '#d98383' : kmLeft <= 1000 ? '#d9ad66' : '#74b88f'}">K</span><span class="t"><b>Bakım kilometresi</b><small>${fmt(car.svcKm)} km</small></span><span class="amt2" style="color:${kmLeft <= 0 ? '#d98383' : kmLeft <= 1000 ? '#d9ad66' : '#74b88f'}">${kmLeft <= 0 ? fmt(-kmLeft) + ' km geçti' : fmt(kmLeft) + ' km kaldı'}</span></div>` : '') : '<p class="empty" style="padding:12px 0">Muayene, sigorta ve bakım tarihlerini Düzenle’den ekle.</p>'}</section>
    <div class="sec"><h2>Özet</h2></div><div class="cols2" style="margin:0"><div><span class="label">Bu ay yakıt</span><div class="mid">${money(sum(l => l.type === 'fuel' && l.date.startsWith(mo)))}</div></div><div><span class="label">Ort. tüketim</span><div class="mid">${avg ? avg.toFixed(1) + ' L/100km' : '—'}</div></div><div><span class="label">${yr} toplam gider</span><div class="mid">${money(sum(l => l.date.startsWith(yr)))}</div></div><div><span class="label">${yr} bakım</span><div class="mid">${money(sum(l => l.type === 'svc' && l.date.startsWith(yr)))}</div></div></div>`;
  } else {
    body = logs.length ? `<section class="card" style="padding:4px 16px">${logs.map(l => `<button class="row" data-a="carLogOpen" data-id="${l.id}"><span class="dot" style="--c:${CT[l.type][1]}">${CT[l.type][0][0]}</span><span class="t"><b>${CT[l.type][0]}${l.note ? ' · ' + esc(l.note) : ''}</b><small>${dlabel(l.date)}${l.km ? ' · ' + fmt(l.km) + ' km' : ''}${l.liters ? ' · ' + fmt(l.liters) + ' L' : ''}</small></span><span class="amt2">${money(l.amount || 0)}</span></button>`).join('')}</section>` : '<section class="card"><p class="empty">Henüz kayıt yok. + ile yakıt veya bakım ekle.</p></section>';
  }
  view.innerHTML = `${mhero(m)}${cars.length > 1 ? `<div style="margin-bottom:14px">${chips('ccar', cars.map(c => [c.id, esc(c.name)]), car.id)}</div>` : ''}${seg('ctab', [['sum', 'Özet'], ['logs', 'Kayıtlar']], CR.tab)}<div style="height:16px"></div>${body}${fab('carLogNew', 'orange')}
  <p style="margin-top:6px"><a href="#/m/car" data-a="carNew" style="color:var(--blue);font-size:14px">+ Başka araç ekle</a></p>`;
  $('#ctab').onchange = () => { CR.tab = $('#ctab').dataset.val; route(); };
  const cc = $('#ccar'); if (cc) cc.onchange = () => { CR.car = cc.dataset.val; route(); };
};
const carForm = c => sheet(`<h2 class="st">${c ? 'Aracı düzenle' : 'Araç ekle'}</h2>
  <div class="field"><label>Araç adı</label><input id="cn" maxlength="40" placeholder="Örn. Renault Clio" value="${c ? esc(c.name) : ''}"></div>
  <div class="field"><label>Plaka</label><input id="cp" maxlength="12" value="${c ? esc(c.plate || '') : ''}"></div>
  <div class="field"><label>Güncel kilometre</label><input id="ck" inputmode="numeric" value="${c && c.km || ''}"></div>
  ${dateField('cmu', 'Muayene tarihi', c && c.muayene || '')}${dateField('csi', 'Trafik sigortası bitiş', c && c.sigorta || '')}${dateField('cka', 'Kasko bitiş', c && c.kasko || '')}${dateField('csd', 'Sonraki bakım tarihi', c && c.svcDate || '')}
  <div class="field"><label>Sonraki bakım kilometresi</label><input id="csk" inputmode="numeric" value="${c && c.svcKm || ''}"></div>
  <div class="bar"><button class="btn w" data-a="carSave" data-id="${c ? c.id : ''}">Kaydet</button>${c ? `<button class="btn danger" data-a="carDel" data-id="${c.id}">Sil</button>` : ''}</div>`);
A.carNew = () => carForm();
A.carEdit = async () => carForm(await DB.get('cars', CR.car));
A.carSave = async b => {
  const name = $('#cn').value.trim(); if (!name) { toast('Araç adı yaz'); return $('#cn').focus(); }
  const c = b.dataset.id ? await DB.get('cars', b.dataset.id) : { id: DB.uid(), created: Date.now() };
  Object.assign(c, { name, plate: $('#cp').value.trim().toUpperCase(), km: parseInt($('#ck').value) || 0, muayene: $('#cmu').dataset.val, sigorta: $('#csi').dataset.val, kasko: $('#cka').dataset.val, svcDate: $('#csd').dataset.val, svcKm: parseInt($('#csk').value) || 0 });
  await DB.put('cars', c); CR.car = c.id; A.closeSheet(); route();
};
A.carDel = async b => {
  if (!confirm('Araç ve tüm kayıtları silinsin mi?')) return;
  for (const l of await DB.all('carlogs')) if (l.carId === b.dataset.id) await DB.del('carlogs', l.id);
  await DB.del('cars', b.dataset.id); CR.car = ''; A.closeSheet(); route();
};
A.carLogNew = async () => {
  const car = await DB.get('cars', CR.car); if (!car) return A.carNew();
  sheet(`<h2 class="st">Yeni kayıt</h2>${seg('ltype', [['fuel', 'Yakıt'], ['svc', 'Bakım'], ['other', 'Diğer']], 'fuel')}
  <input class="amt" id="lamt" inputmode="decimal" placeholder="0,00 ₺">
  <div class="field" id="lliw"><label>Litre</label><input id="llit" inputmode="decimal" placeholder="0"></div>
  <div class="field"><label>Kilometre</label><input id="lkm" inputmode="numeric" value="${car.km || ''}"></div>
  <div class="field"><label>Not</label><input id="lnote" maxlength="60" placeholder="İsteğe bağlı"></div>
  ${dateField('ldate', 'Tarih', today())}
  <div class="field"><label>Cüzdanım’a gider olarak işle</label>${seg('ltx', [['0', 'Hayır'], ['1', 'Evet']], '0')}</div>
  <button class="btn" style="width:100%" data-a="carLogSave">Kaydet</button>`);
  $('#ltype').onchange = () => { $('#lliw').style.display = $('#ltype').dataset.val === 'fuel' ? '' : 'none'; };
};
A.carLogSave = async () => {
  const amount = num($('#lamt').value); if (!(amount > 0)) { toast('Tutarı gir'); return $('#lamt').focus(); }
  const type = $('#ltype').dataset.val, km = parseInt($('#lkm').value) || 0, date = $('#ldate').dataset.val || today(), note = $('#lnote').value.trim();
  await DB.put('carlogs', { id: DB.uid(), carId: CR.car, type, amount, liters: type === 'fuel' ? (num($('#llit').value) || 0) : 0, km, date, note, created: Date.now() });
  const car = await DB.get('cars', CR.car); if (car && km > (car.km || 0)) { car.km = km; await DB.put('cars', car); }
  if ($('#ltx').dataset.val === '1') await DB.put('tx', { id: DB.uid(), type: 'out', amount, note: 'Araç – ' + CT[type][0] + (note ? ' · ' + note : ''), date, created: Date.now() });
  A.closeSheet(); toast('Kayıt eklendi'); route();
};
A.carLogOpen = async b => {
  const l = await DB.get('carlogs', b.dataset.id); if (!l) return;
  sheet(`<h2 class="st">${CT[l.type][0]}</h2><div class="big">${money(l.amount || 0)}</div><p class="empty" style="margin:8px 0 20px">${dtxt(l.date)}${l.km ? ' · ' + fmt(l.km) + ' km' : ''}${l.liters ? ' · ' + fmt(l.liters) + ' L (' + money(l.amount / l.liters) + '/L)' : ''}${l.note ? ' · ' + esc(l.note) : ''}</p><button class="btn danger" style="width:100%" data-a="carLogDel" data-id="${l.id}">Kaydı sil</button>`);
};
A.carLogDel = async b => { await DB.del('carlogs', b.dataset.id); A.closeSheet(); route(); };
