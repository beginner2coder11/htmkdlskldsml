/* LIFE OS – ayarlar ve yedekleme */
const STORES = ['notes', 'tasks', 'tx', 'habits'];
const Settings = {
  async get() { return (await DB.get('kv', 'settings')) || { name: '' }; },
  set(v) { return DB.put('kv', v, 'settings'); },
  async exportAll() {
    const d = { app: 'LIFE OS', version: 2, date: new Date().toISOString(), settings: await this.get(), budget: await DB.get('kv', 'budget') || {} };
    for (const s of STORES) d[s] = await DB.all(s);
    return d;
  },
  async importAll(d) {
    if (!d || d.app !== 'LIFE OS') throw new Error('Geçersiz yedek dosyası');
    for (const s of STORES) { await DB.clear(s); for (const x of d[s] || []) await DB.put(s, x); }
    await this.set(d.settings || { name: '' });
    await DB.put('kv', d.budget || {}, 'budget');
  },
  async wipe() { for (const s of [...STORES, 'kv']) await DB.clear(s); }
};
