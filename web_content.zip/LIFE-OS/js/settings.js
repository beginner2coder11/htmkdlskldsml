/* LIFE OS – ayarlar ve yedekleme */
const STORES = ['notes', 'tasks', 'tx', 'habits', 'debts', 'goals', 'vault', 'cars', 'carlogs', 'crypto'];
const KVK = ['vaultcfg', 'brain', 'folders', 'cryptowatch', 'cryptoprices'];
const Settings = {
  async get() { return (await DB.get('kv', 'settings')) || { name: '' }; },
  set(v) { return DB.put('kv', v, 'settings'); },
  async exportAll() {
    const d = { app: 'LIFE OS', version: 5, date: new Date().toISOString(), settings: await this.get(), kv: {} };
    for (const s of STORES) d[s] = await DB.all(s);
    for (const k of KVK) { const v = await DB.get('kv', k); if (v !== undefined) d.kv[k] = v; }
    return d;
  },
  async importAll(d) {
    if (!d || d.app !== 'LIFE OS') throw new Error('Geçersiz yedek dosyası');
    for (const s of STORES) { await DB.clear(s); for (const x of d[s] || []) await DB.put(s, x); }
    await this.set(d.settings || { name: '' });
    const kv = d.kv || (d.budget ? { budget: d.budget } : {});
    for (const k of KVK) if (kv[k] !== undefined) await DB.put('kv', kv[k], k);
  },
  async wipe() { for (const s of [...STORES, 'docs', 'books', 'weights', 'water', 'workouts', 'kv']) await DB.clear(s); }
};
