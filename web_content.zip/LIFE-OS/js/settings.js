/* LIFE OS – ayarlar ve yedekleme */
const STORES = ['notes', 'tasks', 'tx', 'habits', 'debts', 'goals', 'vault', 'cars', 'carlogs', 'crypto'];
const KVK = ['vaultcfg', 'brain', 'folders', 'cryptowatch', 'cryptoprices', 'emcontacts', 'kit', 'quakecfg', 'weathercfg'];
const pwKey = async (pw, salt, iter) => {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
};
const Settings = {
  async get() { return (await DB.get('kv', 'settings')) || { name: '', haptic: true }; },
  set(v) { return DB.put('kv', v, 'settings'); },
  async exportAll() {
    const d = { app: 'LIFE OS', version: 6, date: new Date().toISOString(), settings: await this.get(), kv: {} };
    for (const s of STORES) d[s] = await DB.all(s);
    for (const k of KVK) { const v = await DB.get('kv', k); if (v !== undefined) d.kv[k] = v; }
    return d;
  },
  async importAll(d) {
    if (!d || d.app !== 'LIFE OS') throw new Error('Geçersiz yedek dosyası');
    for (const s of STORES) { await DB.clear(s); for (const x of d[s] || []) await DB.put(s, x); }
    await this.set(d.settings || { name: '' });
    const kv = d.kv || {};
    for (const k of KVK) if (kv[k] !== undefined) await DB.put('kv', kv[k], k);
  },
  async seal(text, pw) {
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), iter = 200000;
    const key = await pwKey(pw, salt, iter), c = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return JSON.stringify({ app: 'LIFE OS', enc: 1, iter, salt: b64(salt), iv: b64(iv), d: b64(c) });
  },
  async unseal(o, pw) {
    const key = await pwKey(pw, unb64(o.salt), o.iter);
    return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.iv) }, key, unb64(o.d)));
  },
  async wipe() { for (const s of [...STORES, 'docs', 'media', 'mediachunks', 'books', 'weights', 'water', 'workouts', 'kv']) await DB.clear(s); }
};
