/* LIFE OS – yerel veri katmanı (IndexedDB) */
const DB = (() => {
  let p;
  const open = () => p || (p = new Promise((res, rej) => {
    const r = indexedDB.open('lifeos', 6);
    r.onupgradeneeded = () => {
      const d = r.result;
      const mk = (n, o) => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, o); };
      mk('notes', { keyPath: 'id' }); mk('tasks', { keyPath: 'id' }); mk('kv');
      mk('tx', { keyPath: 'id' }); mk('habits', { keyPath: 'id' });
      mk('debts', { keyPath: 'id' }); mk('goals', { keyPath: 'id' }); mk('books', { keyPath: 'id' }); mk('docs', { keyPath: 'id' });
      mk('vault', { keyPath: 'id' }); mk('weights', { keyPath: 'id' }); mk('water', { keyPath: 'date' }); mk('workouts', { keyPath: 'id' }); mk('cars', { keyPath: 'id' }); mk('carlogs', { keyPath: 'id' }); mk('crypto', { keyPath: 'id' }); mk('media', { keyPath: 'id' }); mk('mediachunks', { keyPath: 'k' });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  }));
  const run = (s, m, f, ...a) => open().then(d => new Promise((res, rej) => {
    const t = d.transaction(s, m);
    const q = t.objectStore(s)[f](...a);
    t.oncomplete = () => res(q.result);
    t.onerror = () => rej(t.error);
  }));
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  return {
    uid: () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    all: s => run(s, 'readonly', 'getAll'),
    get: (s, k) => run(s, 'readonly', 'get', k),
    put: (s, v, k) => run(s, 'readwrite', 'put', ...(k === undefined ? [v] : [v, k])),
    del: (s, k) => run(s, 'readwrite', 'delete', k),
    clear: s => run(s, 'readwrite', 'clear'),
    putMany: ops => open().then(db => new Promise((res, rej) => {
      const t = db.transaction([...new Set(ops.map(o => o[0]))], 'readwrite');
      ops.forEach(([s, v, k]) => (k === undefined ? t.objectStore(s).put(v) : t.objectStore(s).put(v, k)));
      t.oncomplete = () => res(); t.onerror = () => rej(t.error);
    }))
  };
})();
