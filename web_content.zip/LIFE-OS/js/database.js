/* LIFE OS – yerel veri katmanı (IndexedDB) */
const DB = (() => {
  let p;
  const open = () => p || (p = new Promise((res, rej) => {
    const r = indexedDB.open('lifeos', 2);
    r.onupgradeneeded = () => {
      const d = r.result;
      const mk = (n, o) => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, o); };
      mk('notes', { keyPath: 'id' }); mk('tasks', { keyPath: 'id' }); mk('kv');
      mk('tx', { keyPath: 'id' }); mk('habits', { keyPath: 'id' });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  }));
  const run = (s, m, f, ...a) => open().then(d => new Promise((res, rej) => {
    const t = d.transaction(s, m);
    const q = t.objectStore(s)[f](...a);
    t.oncomplete = () => res(q.result);
    t.onerror = () => rej(t.error);
  }));
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  return {
    uid: () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    all: s => run(s, 'readonly', 'getAll'),
    get: (s, k) => run(s, 'readonly', 'get', k),
    put: (s, v, k) => run(s, 'readwrite', 'put', ...(k === undefined ? [v] : [v, k])),
    del: (s, k) => run(s, 'readwrite', 'delete', k),
    clear: s => run(s, 'readwrite', 'clear')
  };
})();
