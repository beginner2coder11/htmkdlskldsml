/* LIFE OS 2.0 – ana ekran, gezinme, ayarlar */
const greet = n => {
  const h = new Date().getHours();
  const g = h < 5 ? 'İyi geceler' : h < 12 ? 'Günaydın' : h < 18 ? 'İyi günler' : 'İyi akşamlar';
  return n ? `${g}, ${esc(n)}` : g;
};
const tile = m => `<a class="tile" href="#/m/${m.id}" style="--c:var(--${m.c})"><div class="ico">${ic(m.i, 25)}</div><span>${m.n}</span></a>`;
const V = {};

V.home = async () => {
  const [tasks, notes, st] = await Promise.all([DB.all('tasks'), DB.all('notes'), Settings.get()]);
  const t0 = today(), mi = dstr(new Date()).slice(0, 7);
  const ms = await monthStats(mi);
  const td = tasks.filter(t => t.due === t0 || (!t.done && (!t.due || t.due < t0)));
  const dn = td.filter(t => t.done).length, bal = ms.inc - ms.out;
  const recent = notes.sort((a, b) => b.created - a.created).slice(0, 3);
  view.innerHTML = `
  <header class="top">${mark(28)}<b>LIFE OS</b></header>
  <section class="hero"><p class="hello">${greet(st.name)}</p><div class="clock" id="clock"></div><p class="date" id="date"></p></section>
  <a class="searchbar" href="#/search">${ic('search', 20)}<span>Notlarda, görevlerde, modüllerde ara</span></a>
  <div class="sec"><h2>Modüller</h2></div>
  <section class="grid">${MODS.map(tile).join('')}</section>
  <section class="bento">
    <a class="card" href="#/m/budget"><span class="label">${new Date().toLocaleDateString('tr-TR', { month: 'long' })} bakiyesi</span><div class="mid ${bal < 0 ? 'neg' : ''}" style="margin-top:auto;font-size:24px">${money(bal)}</div><span class="label"><span class="pos">+${money(ms.inc)}</span><br><span class="neg">−${money(ms.out)}</span></span></a>
    <a class="card" href="#/m/life"><span class="label">Bugünün görevleri</span><div style="display:flex;justify-content:center;margin:auto 0;position:relative">${ring(td.length ? dn / td.length : 0, '#31c76a', 78, 8)}<b class="mid" style="position:absolute;inset:0;display:grid;place-items:center;font-size:18px">${dn}/${td.length}</b></div></a>
  </section>
  <div class="sec"><h2>Bugün</h2><small>${td.filter(t => !t.done).length} açık</small></div>
  <section class="card" style="padding:6px 16px 16px">${td.length ? `<ul class="list">${td.sort((a, b) => a.done - b.done).slice(0, 6).map(t => taskRow(t)).join('')}</ul>` : '<p class="empty" style="padding:12px 0">Bugün için görev yok.</p>'}
    <div class="bar"><input id="qt" placeholder="Yeni görev ekle" maxlength="120"><button class="btn" data-a="addTask">Ekle</button></div></section>
  <div class="sec"><h2>Hızlı not</h2></div>
  <section class="card"><textarea id="qn" placeholder="Aklındakini yaz…" style="min-height:90px"></textarea><div class="bar"><button class="btn w" data-a="saveNote">Notu kaydet</button></div>
    ${recent.length ? `<ul class="list" style="margin-top:8px">${recent.map(n => `<li><span class="t">${esc(n.title)}<small>${dlabel(dstr(new Date(n.created)))}</small></span></li>`).join('')}</ul>` : ''}</section>`;
  const tick = () => {
    const d = new Date();
    $('#clock').textContent = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    $('#date').textContent = d.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  };
  tick(); every(tick, 10000);
};

MV.mind = async m => {
  const notes = (await DB.all('notes')).sort((a, b) => b.created - a.created);
  view.innerHTML = `${mhero(m)}${notes.length ? `<section class="card" style="padding:4px 16px"><ul class="list">${notes.map(n => `<li><button class="t" data-a="noteOpen" data-id="${n.id}" style="background:none;border:0;text-align:left"><b style="font-weight:600">${esc(n.title)}</b><small>${esc(n.body.slice(0, 90))}</small></button></li>`).join('')}</ul></section>` : '<section class="card"><p class="empty">Henüz not yok. + ile ilk notunu yaz.</p></section>'}${fab('noteNew')}`;
};
const noteSheet = n => sheet(`<h2 class="st">${n ? 'Notu düzenle' : 'Yeni not'}</h2><div class="field"><textarea id="sn" placeholder="Yaz…">${n ? esc(n.body) : ''}</textarea></div><div class="bar"><button class="btn w" data-a="noteSave" data-id="${n ? n.id : ''}">Kaydet</button>${n ? `<button class="btn danger" data-a="delNote" data-id="${n.id}">Sil</button>` : ''}</div>`);
A.noteNew = () => noteSheet();
A.noteOpen = async b => noteSheet(await DB.get('notes', b.dataset.id));
A.noteSave = async b => {
  const body = $('#sn').value.trim(); if (!body) return $('#sn').focus();
  const n = b.dataset.id ? await DB.get('notes', b.dataset.id) : { id: DB.uid(), created: Date.now(), fav: false };
  n.body = body; n.title = body.split('\n')[0].slice(0, 60); await DB.put('notes', n); A.closeSheet(); toast('Not kaydedildi'); route();
};
A.delNote = async b => { await DB.del('notes', b.dataset.id); A.closeSheet(); route(); };

const soon = m => {
  view.innerHTML = `${mhero(m)}<span class="chip">Hazırlanıyor · Aşama ${m.st}</span><section class="card"><div class="sec" style="margin:0 0 4px"><h2>Bu modülde olacaklar</h2></div><ul class="list feat" style="--c:var(--${m.c})">${m.f.map(f => `<li>${ic('ring', 20)}<span class="t">${f}</span></li>`).join('')}</ul></section>`;
};
V.m = (id, sub) => { const m = mod(id); if (!m) return V.home(); (MV[id] || soon)(m, sub); };

V.modules = () => {
  view.innerHTML = `<h1 class="page">Modüller</h1>${MODS.map(m => `<a class="mrow" href="#/m/${m.id}" style="--c:var(--${m.c})"><div class="ico">${ic(m.i, 24)}</div><div class="t"><b>${m.n}</b><small>${m.ok ? m.s : m.s + ' · yakında'}</small></div>${ic('next', 20)}</a>`).join('')}`;
};

V.search = () => {
  const hint = '<p class="empty">Yazmaya başla; sonuçlar anında listelenir.</p>';
  view.innerHTML = `<h1 class="page">Ara</h1><input id="q" type="search" placeholder="Not, görev, işlem veya modül ara" autocomplete="off"><div id="res" style="margin-top:16px">${hint}</div>`;
  const q = $('#q'); q.focus();
  q.oninput = async () => {
    const r = await Search.run(q.value, MODS);
    $('#res').innerHTML = !q.value.trim() ? hint : r.length ? r.slice(0, 40).map(x => `<a class="res" href="${x.href}"><span class="k">${x.k}</span><span class="t"><b>${esc(x.h)}</b><small>${esc(x.s)}</small></span></a>`).join('') : '<p class="empty">Sonuç bulunamadı. Başka bir kelime dene.</p>';
  };
};

V.settings = async () => {
  const st = await Settings.get();
  view.innerHTML = `<h1 class="page">Ayarlar</h1>
  <section class="card"><div class="field"><label for="nm">Adın</label><input id="nm" value="${esc(st.name || '')}" maxlength="30" placeholder="Ana ekranda karşılanmak için"></div><button class="btn" data-a="saveName">Kaydet</button></section>
  <section class="card"><div class="sec" style="margin:0 0 12px"><h2>Yedekleme</h2></div><div class="bar" style="margin:0"><button class="btn w" data-a="exp">Yedek al</button><button class="btn sec w" data-a="imp">Geri yükle</button></div><input id="file" type="file" accept="application/json,.json" hidden></section>
  <section class="card"><div class="sec" style="margin:0 0 8px"><h2>Veriler</h2></div><p class="empty" style="margin-bottom:14px">Tüm veriler yalnızca bu telefonda saklanır. Hiçbir sunucuya gönderilmez.</p><button class="btn danger" data-a="wipe">Tüm verileri sil</button></section>
  <p class="empty" style="text-align:center;margin-top:24px">LIFE OS 2.0<br>Kendi dijital dünyan, kendi kontrolünde.</p>`;
  $('#file').onchange = async e => {
    try { await Settings.importAll(JSON.parse(await e.target.files[0].text())); toast('Yedek geri yüklendi'); } catch (err) { toast('Yedek okunamadı'); }
  };
};

Object.assign(A, {
  async addTask() { const i = $('#qt'), t = i.value.trim(); if (!t) return i.focus(); await DB.put('tasks', { id: DB.uid(), text: t, due: today(), done: false, created: Date.now() }); route(); },
  async toggle(b) { const t = await DB.get('tasks', b.dataset.id); t.done = !t.done; t.doneAt = t.done ? Date.now() : 0; await DB.put('tasks', t); route(); },
  async delTask(b) { await DB.del('tasks', b.dataset.id); route(); },
  async saveNote() { const b = $('#qn').value.trim(); if (!b) return $('#qn').focus(); await DB.put('notes', { id: DB.uid(), title: b.split('\n')[0].slice(0, 60), body: b, fav: false, created: Date.now() }); toast('Not kaydedildi'); route(); },
  async saveName() { const s = await Settings.get(); s.name = $('#nm').value.trim(); await Settings.set(s); toast('Kaydedildi'); },
  async exp() {
    const blob = new Blob([JSON.stringify(await Settings.exportAll(), null, 1)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'lifeos-yedek-' + today() + '.json'; a.click(); toast('Yedek hazırlandı');
  },
  imp() { $('#file').click(); },
  async wipe() { if (confirm('Tüm veriler silinsin mi? Bu işlem geri alınamaz.')) { await Settings.wipe(); toast('Veriler silindi'); route(); } }
});
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'qt') A.addTask(); });

const NAV = [['home', 'Ana', 'home'], ['search', 'Ara', 'search'], ['modules', 'Modüller', 'grid'], ['settings', 'Ayarlar', 'sliders']];
function route() {
  clearT();
  const [v, a, b] = (location.hash.slice(2) || 'home').split('/');
  (V[v] || V.home)(a, b);
  const cur = v === 'm' ? 'modules' : V[v] ? v : 'home';
  $('#nav').innerHTML = NAV.map(([k, l, i]) => `<a href="#/${k}" class="${k === cur ? 'on' : ''}" aria-label="${l}">${ic(i, 22)}<span>${l}</span></a>`).join('');
  scrollTo(0, 0);
}
addEventListener('hashchange', route);
route();
if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) navigator.serviceWorker.register('service-worker.js');
