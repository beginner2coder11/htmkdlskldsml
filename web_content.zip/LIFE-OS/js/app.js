/* LIFE OS 4.0 – ana ekran, gezinme, ayarlar, yedekleme */
const greet = n => {
  const h = new Date().getHours();
  const g = h < 5 ? 'İyi geceler' : h < 12 ? 'Günaydın' : h < 18 ? 'İyi günler' : 'İyi akşamlar';
  return n ? `${g}, ${esc(n)}` : g;
};
const tile = m => `<a class="tile" href="#/m/${m.id}" style="--c:var(--${m.c})"><div class="ico">${mi(m.i, 58)}</div><span>${m.n}</span></a>`;
const V = {};

/* ---- Hava durumu (Open-Meteo, şehir seçilerek) ---- */
const WMO = c => c === 0 ? ['Açık', 'wSun'] : c <= 2 ? ['Parçalı bulutlu', 'wPart'] : c === 3 ? ['Bulutlu', 'wCloud'] : c <= 48 ? ['Sisli', 'wFog'] : c <= 57 ? ['Çisenti', 'wRain'] : c <= 67 ? ['Yağmurlu', 'wRain'] : c <= 77 ? ['Karlı', 'wSnow'] : c <= 82 ? ['Sağanak', 'wRain'] : c <= 86 ? ['Kar sağanağı', 'wSnow'] : ['Gök gürültülü', 'wStorm'];
async function wxLoad() {
  const cfg = await DB.get('kv', 'weathercfg'); if (!cfg) return { cfg: null, w: null };
  let w = await DB.get('kv', 'weather');
  if ((!w || Date.now() - w.t > 1800000) && navigator.onLine !== false) {
    try {
      const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${cfg.lat}&longitude=${cfg.lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1`);
      if (r.ok) { const j = await r.json(); w = { t: Date.now(), cur: j.current, d: { max: j.daily.temperature_2m_max[0], min: j.daily.temperature_2m_min[0], rain: j.daily.precipitation_probability_max[0] } }; await DB.put('kv', w, 'weather'); }
    } catch (e) { /* çevrimdışı: son bilinen değer */ }
  }
  return { cfg, w };
}
const wxHtml = ({ cfg, w }) => {
  if (!cfg) return '<a class="wxset" href="#/settings">Hava durumu için şehir seç</a>';
  if (!w) return `<small>${esc(cfg.name)} · hava durumu alınamadı</small>`;
  const [txt, icn] = WMO(w.cur.weather_code);
  return `${mi(icn, 46)}<div><b>${Math.round(w.cur.temperature_2m)}°</b><small>${txt}</small><small>${esc(cfg.name)} · ${Math.round(w.d.min)}°/${Math.round(w.d.max)}°${w.d.rain != null ? ' · %' + w.d.rain + ' yağış' : ''}</small></div>`;
};

V.home = async () => {
  const [tasks, st] = await Promise.all([DB.all('tasks'), Settings.get()]);
  const t0 = today(), ms = await monthStats(t0.slice(0, 7));
  const td = tasks.filter(t => t.due === t0 || (!t.done && (!t.due || t.due < t0)));
  const dn = td.filter(t => t.done).length, bal = ms.inc - ms.out;
  view.innerHTML = `
  <header class="top">${mark(28)}<b>LIFE OS</b></header>
  <section class="hero"><div><p class="hello">${greet(st.name)}</p><div class="clock" id="clock"></div><p class="date" id="date"></p></div><div class="wx" id="wx"></div></section>
  <a class="searchbar" href="#/search">${ic('search', 20)}<span>Notlarda, görevlerde, modüllerde ara</span></a>
  <section class="qa">
    <button data-a="txNew" data-t="in" style="--c:var(--green)"><i>${ic('plus', 20)}</i>Gelir</button>
    <button data-a="txNew" data-t="out" style="--c:var(--red)"><i>${ic('plus', 20)}</i>Gider</button>
    <button data-a="noteNew" style="--c:var(--blue)"><i>${ic('plus', 20)}</i>Not</button>
    <button data-a="taskNew" data-q="1" style="--c:var(--orange)"><i>${ic('plus', 20)}</i>Görev</button>
  </section>
  <div class="sec"><h2>Modüller</h2></div>
  <section class="grid">${MODS.map(tile).join('')}</section>
  <section class="bento">
    <a class="card" href="#/m/budget"><span class="label">${new Date().toLocaleDateString('tr-TR', { month: 'long' })} bakiyesi</span><div class="mid ${bal < 0 ? 'neg' : ''}" style="margin-top:auto;font-size:24px">${money(bal)}</div><span class="label"><span class="pos">+${money(ms.inc)}</span><br><span class="neg">−${money(ms.out)}</span></span></a>
    <a class="card" href="#/m/toolbox/life"><span class="label">Bugünün görevleri</span><div style="display:flex;justify-content:center;margin:auto 0;position:relative">${ring(td.length ? dn / td.length : 0, '#74b88f', 78, 8)}<b class="mid" style="position:absolute;inset:0;display:grid;place-items:center;font-size:18px">${dn}/${td.length}</b></div></a>
  </section>
  <div class="sec"><h2>Bugün</h2><small>${td.filter(t => !t.done).length} açık</small></div>
  <section class="card" style="padding:6px 16px 16px">${td.length ? `<ul class="list">${td.sort((a, b) => a.done - b.done).slice(0, 6).map(t => taskRow(t)).join('')}</ul>` : '<p class="empty" style="padding:12px 0">Bugün için görev yok.</p>'}
    <div class="bar"><input id="qt" placeholder="Yeni görev ekle" maxlength="120"><button class="btn" data-a="addTask">Ekle</button></div></section>`;
  const tick = () => {
    const d = new Date(), c = $('#clock'); if (!c) return;
    c.textContent = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    $('#date').textContent = d.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  };
  tick(); every(tick, 10000);
  wxLoad().then(x => { const e = $('#wx'); if (e) e.innerHTML = wxHtml(x); });
};

MV.notes = async m => {
  const notes = (await DB.all('notes')).sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0) || b.created - a.created);
  view.innerHTML = `${mhero(m)}<input id="nq" type="search" placeholder="Notlarda ara" autocomplete="off" style="margin-bottom:14px">
  ${notes.length ? `<section class="card" style="padding:4px 16px"><ul class="list" id="nl">${notes.map(n => `<li data-s="${esc(Search.norm(n.title + ' ' + n.body))}"><button class="t" data-a="noteOpen" data-id="${n.id}" style="background:none;border:0;text-align:left"><b style="font-weight:600">${esc(n.title)}</b><small>${esc(n.body.slice(0, 90))}</small></button><button class="x" data-a="notePin" data-id="${n.id}" style="color:${n.fav ? 'var(--orange)' : '#5a626c'};font-size:20px" aria-label="Yıldızla">${n.fav ? '★' : '☆'}</button></li>`).join('')}</ul></section>` : '<section class="card"><p class="empty">Henüz not yok. + ile ilk notunu yaz.</p></section>'}${fab('noteNew')}`;
  const q = $('#nq'); q.oninput = () => { const s = Search.norm(q.value).trim(); document.querySelectorAll('#nl li').forEach(li => { li.style.display = li.dataset.s.includes(s) ? '' : 'none'; }); };
};
const noteSheet = n => sheet(`<h2 class="st">${n ? 'Notu düzenle' : 'Yeni not'}</h2><div class="field"><textarea id="sn" placeholder="Yaz…">${n ? esc(n.body) : ''}</textarea></div><div class="bar"><button class="btn w" data-a="noteSave" data-id="${n ? n.id : ''}">Kaydet</button>${n ? `<button class="btn danger" data-a="delNote" data-id="${n.id}">Sil</button>` : ''}</div>`);
A.noteNew = () => noteSheet();
A.noteOpen = async b => noteSheet(await DB.get('notes', b.dataset.id));
A.noteSave = async b => {
  const body = $('#sn').value.trim(); if (!body) return $('#sn').focus();
  const n = b.dataset.id ? await DB.get('notes', b.dataset.id) : { id: DB.uid(), created: Date.now(), fav: false };
  n.body = body; n.title = body.split('\n')[0].slice(0, 60); await DB.put('notes', n); A.closeSheet(); toast('Not kaydedildi'); route();
};
A.delNote = async b => { await DB.del('notes', b.dataset.id); A.closeSheet(); route(); };
A.notePin = async b => { const n = await DB.get('notes', b.dataset.id); n.fav = !n.fav; await DB.put('notes', n); route(); };

const soon = m => {
  view.innerHTML = `${mhero(m)}<section class="card"><div class="sec" style="margin:0 0 4px"><h2>Bu modülde olacaklar</h2></div><ul class="list feat" style="--c:var(--${m.c})">${m.f.map(f => `<li>${ic('ring', 20)}<span class="t">${f}</span></li>`).join('')}</ul></section>`;
};
V.m = (id, sub) => { const m = mod(id); if (!m) return V.home(); return (MV[id] || soon)(m, sub); };

V.modules = () => {
  view.innerHTML = `<h1 class="page">Modüller</h1>${MODS.map(m => `<a class="mrow" href="#/m/${m.id}" style="--c:var(--${m.c})"><div class="ico">${mi(m.i, 44)}</div><div class="t"><b>${m.n}</b><small>${m.s}</small></div>${ic('next', 20)}</a>`).join('')}`;
};

V.search = () => {
  const hint = '<p class="empty">Yazmaya başla; sonuçlar anında listelenir.</p>';
  view.innerHTML = `<h1 class="page">Ara</h1><input id="q" type="search" placeholder="Not, görev, işlem veya dosya ara" autocomplete="off"><div id="res" style="margin-top:16px">${hint}</div>`;
  const q = $('#q'); q.focus();
  q.oninput = async () => {
    const r = await Search.run(q.value, MODS);
    $('#res').innerHTML = !q.value.trim() ? hint : r.length ? r.slice(0, 40).map(x => `<a class="res" href="${x.href}"><span class="k">${x.k}</span><span class="t"><b>${esc(x.h)}</b><small>${esc(x.s)}</small></span></a>`).join('') : '<p class="empty">Sonuç bulunamadı. Başka bir kelime dene.</p>';
  };
};

V.settings = async () => {
  const st = await Settings.get(), wc = await DB.get('kv', 'weathercfg'), lb = await DB.get('kv', 'lastbackup');
  view.innerHTML = `<h1 class="page">Ayarlar</h1>
  <section class="card"><div class="field"><label for="nm">Adın</label><input id="nm" value="${esc(st.name || '')}" maxlength="30" placeholder="Ana ekranda karşılanmak için"></div><button class="btn" data-a="saveName">Kaydet</button></section>
  <section class="card"><div class="sec" style="margin:0 0 12px"><h2>Dokunma titreşimi</h2></div>${seg('hap', [['1', 'Açık'], ['0', 'Kapalı']], st.haptic === false ? '0' : '1')}<p class="empty" style="margin-top:10px">Titreşim için APK’nın titreşim izni gerekir.</p></section>
  <section class="card"><div class="sec" style="margin:0 0 12px"><h2>Hava durumu</h2></div><div class="field"><label>Şehir${wc ? ' · şu an: ' + esc(wc.name) : ''}</label><input id="wxq" placeholder="Örn. Ankara" maxlength="40"></div><button class="btn sec" style="width:100%" data-a="wxSet">Şehri bul ve kaydet</button></section>
  <section class="card"><div class="sec" style="margin:0 0 12px"><h2>Yedekleme</h2></div><div class="bar" style="margin:0"><button class="btn w" data-a="bkNew">Yedek al</button><button class="btn sec w" data-a="bkRestore">Geri yükle</button></div>
    <p class="empty" style="margin-top:12px">${lb ? 'Son yedek: ' + new Date(lb).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) + '. ' : 'Henüz yedek almadın. '}Dökümanlar ve Media dosyaları yedeğe dahil değildir.</p></section>
  <section class="card"><div class="sec" style="margin:0 0 8px"><h2>Veriler</h2></div><p class="empty" style="margin-bottom:14px">Tüm veriler yalnızca bu telefonda saklanır. İnternete yalnızca fiyat, hava durumu ve deprem listesi için bağlanılır.</p><button class="btn danger" data-a="wipe">Tüm verileri sil</button></section>
  <p class="empty" style="text-align:center;margin-top:24px">LIFE OS 4.0<br>Kendi dijital dünyan, kendi kontrolünde.</p>`;
  $('#hap').onchange = async () => { const s = await Settings.get(); s.haptic = $('#hap').dataset.val === '1'; HAPTIC = s.haptic; await Settings.set(s); vibe(40); };
};

/* ---- Yedekleme ---- */
A.bkNew = () => sheet(`<h2 class="st">Yedek al</h2><p class="empty" style="margin-bottom:14px">Notlar, finans, kripto, araç, görevler ve Kasa verileri yedeklenir. Dökümanlar ile Media dosyaları dahil değildir.</p>
  <div class="field"><label>Yedek parolası (önerilir)</label><input id="bkp" type="password" autocomplete="new-password" placeholder="Boş bırakırsan şifresiz olur"></div>
  <div class="bar"><button class="btn w" data-a="bkGo" data-m="share">Paylaş / Kaydet</button><button class="btn sec w" data-a="bkGo" data-m="copy">Panoya kopyala</button></div>
  <p class="empty" style="margin-top:12px">“Paylaş” menüsünden Google Drive’ı seçebilirsin. Paylaş çalışmıyorsa “Panoya kopyala”yı kullan ve metni bir nota ya da Drive belgesine yapıştır.</p>`);
A.bkGo = async b => {
  const pw = $('#bkp').value; let json = JSON.stringify(await Settings.exportAll());
  if (pw) { if (!(window.crypto && crypto.subtle)) return toast('Şifreleme desteklenmiyor'); json = await Settings.seal(json, pw); }
  if (b.dataset.m === 'copy') { await copyText(json); await DB.put('kv', Date.now(), 'lastbackup'); A.closeSheet(); return route(); }
  const r = await shareFile(new Blob([json], { type: 'application/json' }), 'lifeos-yedek-' + today() + '.json');
  if (r === 'shared') { await DB.put('kv', Date.now(), 'lastbackup'); toast('Paylaşım menüsü açıldı'); A.closeSheet(); route(); }
  else if (r === 'download') toast('İndirme başlatıldı. İndirilenler klasörüne bak. Görünmüyorsa “Panoya kopyala” yöntemini kullan.');
};
A.bkRestore = () => sheet(`<h2 class="st">Yedekten geri yükle</h2><p class="empty" style="margin-bottom:12px">Mevcut veriler yedektekilerle değiştirilir.</p>
  <button class="btn sec" style="width:100%;margin-bottom:12px" data-a="bkPick">Yedek dosyası seç</button><input id="bkf" type="file" accept="application/json,.json,text/plain" hidden>
  <div class="field"><label>veya yedek metnini yapıştır</label><textarea id="bkt" style="min-height:90px"></textarea></div>
  <div class="field"><label>Parola (yedek şifreliyse)</label><input id="bkp2" type="password" autocomplete="off"></div><button class="btn" style="width:100%" data-a="bkDo">Geri yükle</button>`);
A.bkPick = () => { const f = $('#bkf'); f.onchange = async e => { const x = e.target.files[0]; if (x) { $('#bkt').value = await x.text(); toast('Dosya okundu'); } }; f.click(); };
A.bkDo = async () => {
  try {
    let o = JSON.parse($('#bkt').value.trim()), pw = $('#bkp2').value;
    if (o.enc) { if (!pw) return toast('Bu yedek şifreli, parola gir'); try { o = JSON.parse(await Settings.unseal(o, pw)); } catch (e) { return toast('Parola yanlış'); } }
    if (!confirm('Mevcut veriler silinip yedektekiler yüklenecek. Devam edilsin mi?')) return;
    await Settings.importAll(o); vLock(); A.closeSheet(); toast('Yedek geri yüklendi'); route();
  } catch (e) { toast('Yedek okunamadı'); }
};
A.wxSet = async () => {
  const q = $('#wxq').value.trim(); if (!q) return; toast('Aranıyor…');
  try {
    const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=tr&format=json`), j = await r.json(), c = j.results && j.results[0];
    if (!c) return toast('Şehir bulunamadı');
    await DB.put('kv', { name: c.name, lat: c.latitude, lon: c.longitude }, 'weathercfg'); await DB.del('kv', 'weather'); toast(c.name + ' kaydedildi'); route();
  } catch (e) { toast('Şehir aranamadı. İnternet bağlantısını ve APK iznini kontrol et.'); }
};

Object.assign(A, {
  async addTask() { const i = $('#qt'), t = i.value.trim(); if (!t) return i.focus(); await DB.put('tasks', { id: DB.uid(), text: t, due: today(), done: false, created: Date.now() }); route(); },
  async toggle(b) { const t = await DB.get('tasks', b.dataset.id); t.done = !t.done; t.doneAt = t.done ? Date.now() : 0; await DB.put('tasks', t); route(); },
  async delTask(b) { await DB.del('tasks', b.dataset.id); route(); },
  async saveName() { const s = await Settings.get(); s.name = $('#nm').value.trim(); await Settings.set(s); toast('Kaydedildi'); },
  async wipe() { if (confirm('Tüm veriler (fotoğraflar, Media ve Kasa dahil) silinsin mi? Bu işlem geri alınamaz.')) { await Settings.wipe(); vLock(); toast('Veriler silindi'); route(); } },
  goBack() {
    if ($('.sheet.dp')) return A.dpClose();
    if ($('.sheet')) return A.closeSheet();
    if ($('#cam')) return A.camClose();
    if ($('#mviewer')) return A.mClose();
    if ($('#viewer')) return A.vClose();
    const h = location.hash; if (!h || h === '#/home' || h === '#/') return;
    history.back(); setTimeout(() => { if (location.hash === h) location.hash = '#/home'; }, 250);
  }
});
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'qt') A.addTask(); });

const NAV = [['home', 'Ana', 'nHome'], ['search', 'Ara', 'nSearch'], ['modules', 'Modüller', 'nGrid'], ['settings', 'Ayarlar', 'nSet']];
let HST = [];
const dirOf = h => { const n = HST.length; if (n && HST[n - 1] === h) return 'same'; if (n >= 2 && HST[n - 2] === h) { HST.pop(); return 'back'; } HST.push(h); if (HST.length > 40) HST.shift(); return 'fwd'; };
function route() {
  clearT(); runLeave();
  if (VT.key && !/^#\/m\/(vault|media)(\/|$)/.test(location.hash)) vLock();
  const h = location.hash || '#/home', d = dirOf(h);
  view.className = ''; if (d !== 'same') { void view.offsetWidth; view.classList.add(d === 'back' ? 'in-back' : 'in-fwd'); }
  const [v, a, b] = h.slice(2).split('/');
  (V[v] || V.home)(a, b);
  const cur = v === 'm' ? 'modules' : V[v] ? v : 'home', atHome = cur === 'home' && v !== 'm';
  $('#nav').innerHTML = `<button class="nbk ${atHome ? 'dis' : ''}" data-a="goBack" aria-label="Geri">${ic('back', 22)}</button>` +
    NAV.map(([k, l, i]) => `<a href="#/${k}" class="${k === cur ? 'on' : ''}" aria-label="${l}">${mi(i, 24)}<span>${l}</span></a>`).join('');
  if (d !== 'same') scrollTo(0, 0);
}
addEventListener('hashchange', () => { A.dpClose(); A.closeSheet(); A.vClose(); A.mClose(); A.camClose(); route(); });
Settings.get().then(s => { HAPTIC = s.haptic !== false; });
route();
if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) navigator.serviceWorker.register('service-worker.js');
