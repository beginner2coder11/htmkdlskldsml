/* LIFE OS – ortak arama (çevrimdışı) */
const Search = {
  norm: s => String(s || '').toLocaleLowerCase('tr'),
  async run(q, mods) {
    q = this.norm(q).trim();
    if (!q) return [];
    const has = (...a) => a.some(x => this.norm(x).includes(q));
    const out = [];
    mods.forEach(m => { if (has(m.n, m.s, ...m.f)) out.push({ k: 'Modül', h: m.n, s: m.s, href: '#/m/' + m.id }); });
    (await DB.all('notes')).sort((a, b) => b.created - a.created).forEach(n => { if (has(n.title, n.body)) out.push({ k: 'Not', h: n.title, s: n.body, href: '#/m/notes' }); });
    (await DB.all('tasks')).forEach(t => { if (has(t.text)) out.push({ k: 'Görev', h: t.text, s: t.done ? 'Tamamlandı' : 'Açık', href: '#/m/toolbox/life' }); });
    (await DB.all('tx')).sort((a, b) => b.date.localeCompare(a.date)).forEach(t => { if (has(t.cat, t.note)) out.push({ k: 'Finans', h: t.cat + (t.note ? ' · ' + t.note : ''), s: t.date + ' · ' + t.amount + ' ₺', href: '#/m/budget' }); });
    (await DB.all('habits')).forEach(h => { if (has(h.name)) out.push({ k: 'Alışkanlık', h: h.name, s: 'Alışkanlık takibi', href: '#/m/toolbox/life' }); });
    (await DB.all('docs')).forEach(d => { if (has(d.name)) out.push({ k: 'Döküman', h: d.name, s: d.folder || 'Genel', href: '#/m/docs' }); });
    (await DB.all('debts')).forEach(d => { if (has(d.person, d.note)) out.push({ k: 'Borç', h: d.person, s: d.amount + ' ₺', href: '#/m/budget' }); });
    return out;
  }
};
