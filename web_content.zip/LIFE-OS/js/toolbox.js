/* LIFE OS – TOOLBOX */
const row = (l, v) => `<div class="orow"><span>${l}</span><b>${v}</b></div>`;
const FORMS = {
  percent: { n: 'Yüzde', i: 'percent', c: 'orange', f: [['a', 'Sayı', 'num'], ['b', 'Yüzde (%)', 'num']],
    r: v => { const a = num(v.a), b = num(v.b); if (isNaN(a) || isNaN(b)) return; const p = a * b / 100; return [['Yüzdesi', fmt(p)], ['Sayı + yüzde', fmt(a + p)], ['Sayı − yüzde', fmt(a - p)]]; } },
  vat: { n: 'KDV', i: 'receipt', c: 'blue', f: [['a', 'Tutar (₺)', 'num'], ['rate', 'KDV oranı', 'chips', [['1', '%1'], ['10', '%10'], ['20', '%20']], '20'], ['mode', 'Girilen tutar', 'seg', [['excl', 'KDV hariç'], ['incl', 'KDV dahil']], 'excl']],
    r: v => { const a = num(v.a), k = +v.rate / 100; if (isNaN(a)) return; const net = v.mode === 'excl' ? a : a / (1 + k), gross = v.mode === 'excl' ? a * (1 + k) : a; return [['KDV dahil', money(gross)], ['KDV tutarı', money(gross - net)], ['KDV hariç', money(net)]]; } },
  discount: { n: 'İndirim', i: 'percent', c: 'green', f: [['a', 'Fiyat (₺)', 'num'], ['b', 'İndirim (%)', 'num']],
    r: v => { const a = num(v.a), b = num(v.b); if (isNaN(a) || isNaN(b)) return; return [['Ödenecek', money(a * (1 - b / 100))], ['İndirim tutarı', money(a * b / 100)]]; } },
  age: { n: 'Yaş hesapla', i: 'cal', c: 'purple', f: [['a', 'Doğum tarihi', 'date']],
    r: v => {
      if (!v.a) return; const b = new Date(v.a + 'T00:00'), n = new Date(), t0 = new Date(today() + 'T00:00');
      let y = n.getFullYear() - b.getFullYear(), m = n.getMonth() - b.getMonth(), d = n.getDate() - b.getDate();
      if (d < 0) { m--; d += new Date(n.getFullYear(), n.getMonth(), 0).getDate(); } if (m < 0) { y--; m += 12; }
      let nb = new Date(n.getFullYear(), b.getMonth(), b.getDate()); if (nb <= t0) nb = new Date(n.getFullYear() + 1, b.getMonth(), b.getDate());
      return [['Yaş', `${y} yıl ${m} ay ${d} gün`], ['Yaşadığın gün', fmt(Math.floor((t0 - b) / 864e5))], ['Sonraki doğum günü', Math.round((nb - t0) / 864e5) + ' gün sonra']];
    } },
  datediff: { n: 'Tarih farkı', i: 'days', c: 'blue', f: [['a', 'Başlangıç', 'date', 0, today()], ['b', 'Bitiş', 'date']],
    r: v => { if (!v.a || !v.b) return; const k = Math.round((new Date(v.b + 'T00:00') - new Date(v.a + 'T00:00')) / 864e5); return [['Fark', Math.abs(k) + ' gün'], ['Hafta', fmt(Math.abs(k) / 7)], ['Yönü', k >= 0 ? 'Bitiş ileride' : 'Bitiş geride']]; } }
};
const TOOLS = [['calc', 'Hesap makinesi', 'calc', 'blue'], ...Object.entries(FORMS).map(([k, d]) => [k, d.n, d.i, d.c]), ['unit', 'Birim dönüştürücü', 'swap', 'green'], ['sw', 'Kronometre', 'stopw', 'orange'], ['tm', 'Zamanlayıcı', 'hourg', 'red']];
const fld = ([id, l, t, o, d]) => t === 'date' ? dateField(id, l, d || '') : `<div class="field"><label>${l}</label>${t === 'num' ? `<input data-k="${id}" inputmode="decimal" placeholder="0" value="${d || ''}">` : (t === 'seg' ? seg : chips)(id, o, d)}</div>`;
LIVE.form = f => { const r = FORMS[f.dataset.tool].r(vals(f)); $('#out').innerHTML = r ? r.map(x => row(...x)).join('') : '<p class="empty">Değerleri girince sonuç burada görünür.</p>'; };

const UN = { Uzunluk: { mm: .001, cm: .01, m: 1, km: 1000, 'inç': .0254, ft: .3048, mil: 1609.344 }, 'Ağırlık': { g: .001, kg: 1, ton: 1000, lb: .45359237, oz: .028349523 }, Hacim: { ml: .001, L: 1, galon: 3.785411784 }, 'Sıcaklık': { '°C': 0, '°F': 0, K: 0 } };
const conv = (c, v, f, t) => {
  if (c === 'Sıcaklık') { const k = f === '°C' ? v : f === '°F' ? (v - 32) * 5 / 9 : v - 273.15; return t === '°C' ? k : t === '°F' ? k * 9 / 5 + 32 : k + 273.15; }
  return v * UN[c][f] / UN[c][t];
};
LIVE.unit = f => {
  const v = vals(f), keys = Object.keys(UN[v.cat]);
  if (f.dataset.cat !== v.cat) { f.dataset.cat = v.cat; const o = keys.map(k => `<option>${k}</option>`).join(''); $('#uf').innerHTML = o; $('#ut').innerHTML = o; $('#ut').selectedIndex = 1; return LIVE.unit(f); }
  const x = num(v.val); $('#out').innerHTML = isNaN(x) ? '<p class="empty">Bir değer gir.</p>' : row(`${fmt(x)} ${v.f}`, `${fmt(conv(v.cat, x, v.f, v.t))} ${v.t}`);
};

const K = { e: '' };
const calcEval = e => {
  const s = e.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/,/g, '.').replace(/(\d+\.?\d*)%/g, '($1/100)');
  if (!/^[\d+\-*/.() ]+$/.test(s)) return null;
  try { const r = Function('"use strict";return (' + s + ')')(); return isFinite(r) ? +r.toFixed(10) : null; } catch (x) { return null; }
};
const calcDraw = () => {
  const r = calcEval(K.e); $('#cs').textContent = K.e; $('#cb').textContent = K.e ? (r === null ? '' : new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 10 }).format(r)) : '0';
};
A.key = b => {
  const k = b.dataset.v; let e = K.e;
  if (k === 'C') e = ''; else if (k === '⌫') e = e.slice(0, -1);
  else if (k === '=') { const r = calcEval(e); if (r !== null) e = String(r).replace('.', ','); }
  else { if (/[+−×÷]$/.test(e) && /[+−×÷]/.test(k)) e = e.slice(0, -1); e += k; }
  K.e = e; calcDraw();
};

const SW = { acc: 0, start: 0, run: false, laps: [] };
const tfmt = ms => `${pad(Math.floor(ms / 60000))}:${pad(Math.floor(ms / 1000) % 60)}.${pad(Math.floor(ms / 10) % 100)}`;
const swNow = () => SW.acc + (SW.run ? Date.now() - SW.start : 0);
const swDraw = () => { $('#swd').textContent = tfmt(swNow()); $('#sgo').textContent = SW.run ? 'Durdur' : 'Başlat'; $('#ssd').textContent = SW.run ? 'Tur' : 'Sıfırla'; $('#laps').innerHTML = SW.laps.map((l, i) => `<li><span class="t">Tur ${i + 1}</span><b>${tfmt(l)}</b></li>`).reverse().join(''); };
A.swGo = () => { if (SW.run) { SW.acc += Date.now() - SW.start; SW.run = false; } else { SW.start = Date.now(); SW.run = true; } swDraw(); };
A.swSide = () => { if (SW.run) SW.laps.push(swNow()); else { SW.acc = 0; SW.laps = []; } swDraw(); };

const TM = { run: false, end: 0, left: 0 };
const tmDraw = ms => { $('#tmd').textContent = tfmt(Math.max(ms, 0)).slice(0, 5); $('#tgo').textContent = TM.run ? 'Duraklat' : 'Başlat'; };
A.tmGo = () => {
  if (TM.run) { TM.left = TM.end - Date.now(); TM.run = false; }
  else { if (!TM.left) TM.left = num($('#tmin').dataset.val) * 60000; TM.end = Date.now() + TM.left; TM.run = true; }
  tmDraw(TM.run ? TM.end - Date.now() : TM.left);
};
A.tmReset = () => { TM.run = false; TM.left = 0; tmDraw(num($('#tmin').dataset.val) * 60000); };

MV.toolbox = (m, sub) => {
  if (!sub) {
    view.innerHTML = `${mhero(m)}<div class="tools">${TOOLS.map(([k, n, i, c]) => `<a class="tool" href="#/m/toolbox/${k}" style="--c:var(--${c})"><div class="ico">${ic(i, 24)}</div>${n}</a>`).join('')}</div>`;
    return;
  }
  const t = TOOLS.find(x => x[0] === sub); if (!t) return MV.toolbox(m);
  const head = `<a class="back" href="#/m/toolbox" aria-label="Geri">${ic('back', 22)}</a><h1 class="page">${t[1]}</h1>`;
  if (sub === 'calc') {
    const keys = [['C', 'fn'], ['⌫', 'fn'], ['%', 'fn'], ['÷', 'op'], ['7'], ['8'], ['9'], ['×', 'op'], ['4'], ['5'], ['6'], ['−', 'op'], ['1'], ['2'], ['3'], ['+', 'op'], ['0', 'w2'], [','], ['=', 'eq']];
    view.innerHTML = `${head}<div class="disp"><small id="cs"></small><b id="cb">0</b></div><div class="keys">${keys.map(([k, c]) => `<button class="key ${c || ''}" data-a="key" data-v="${k}">${k}</button>`).join('')}</div>`;
    calcDraw();
  } else if (sub === 'unit') {
    view.innerHTML = `${head}<div data-live="unit" id="uw"><div class="card">${seg('cat', Object.keys(UN).map(k => [k, k]), 'Uzunluk')}<div class="field" style="margin-top:16px"><label>Değer</label><input data-k="val" inputmode="decimal" placeholder="0" value="1"></div>
      <div class="cols2" style="margin:0"><div style="padding:0;background:none"><label class="label">Kaynak</label><select data-k="f" id="uf"></select></div><div style="padding:0;background:none"><label class="label">Hedef</label><select data-k="t" id="ut"></select></div></div></div><div class="card out" id="out"></div></div>`;
    LIVE.unit($('#uw'));
  } else if (sub === 'sw') {
    SW.run = false;
    view.innerHTML = `${head}<div class="disp"><b id="swd">00:00.00</b></div><div class="bar"><button class="btn sec w" id="ssd" data-a="swSide">Sıfırla</button><button class="btn w" id="sgo" data-a="swGo">Başlat</button></div><ul class="list" id="laps" style="margin-top:16px"></ul>`;
    swDraw(); every(() => { if (SW.run) $('#swd').textContent = tfmt(swNow()); }, 50);
  } else if (sub === 'tm') {
    TM.run = false; TM.left = 0;
    view.innerHTML = `${head}<div class="disp"><b id="tmd" style="font-size:84px">05:00</b></div><div class="field">${chips('tmin', [['1', '1 dk'], ['5', '5 dk'], ['10', '10 dk'], ['15', '15 dk'], ['30', '30 dk']], '5')}</div><div class="bar"><button class="btn sec w" data-a="tmReset">Sıfırla</button><button class="btn w" id="tgo" data-a="tmGo">Başlat</button></div>`;
    $('#tmin').onchange = () => { if (!TM.run && !TM.left) tmDraw(num($('#tmin').dataset.val) * 60000); };
    every(() => { if (!TM.run) return; const r = TM.end - Date.now(); if (r <= 0) { TM.run = false; TM.left = 0; tmDraw(0); if (navigator.vibrate) navigator.vibrate([300, 150, 300]); toast('Süre doldu'); } else tmDraw(r); }, 200);
  } else {
    const d = FORMS[sub];
    view.innerHTML = `${head}<div data-live="form" data-tool="${sub}" id="fw"><div class="card">${d.f.map(fld).join('')}</div><div class="card out" id="out"></div></div>`;
    LIVE.form($('#fw'));
  }
};
