/* LIFE OS – ortak arayüz yardımcıları */
const $ = (s, r = document) => r.querySelector(s);
const view = $('#view');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const P = {
  home: 'M4 11l8-7 8 7v9h-5v-6H9v6H4z', search: 'M4 11a7 7 0 1 0 14 0a7 7 0 1 0-14 0M20 20l-4-4',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  sliders: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 7a2 2 0 1 0 4 0a2 2 0 1 0-4 0M6 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0',
  note: 'M7 3h8l4 4v14H7zM15 3v4h4M10 12h6M10 16h6', wallet: 'M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 7l12-3v3M16 14h2',
  calc: 'M6 3h12v18H6zM9 7h6M9 11h2M13 11h2M9 15h2M13 15h2', globe: 'M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  lock: 'M6 11h12v10H6zM8 11V8a4 4 0 0 1 8 0v3', bolt: 'M13 2L4 14h7l-1 8 9-12h-7z', pulse: 'M3 12h4l2-5 4 10 2-5h6',
  book: 'M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h10', check: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4M9 15l2 2 4-4',
  back: 'M15 5l-7 7 7 7', next: 'M9 5l7 7-7 7', tick: 'M5 12l5 5 9-10', x: 'M6 6l12 12M18 6L6 18', ring: 'M4 12a8 8 0 1 0 16 0a8 8 0 1 0-16 0',
  plus: 'M12 5v14M5 12h14', percent: 'M5 7a2 2 0 1 0 4 0a2 2 0 1 0-4 0M15 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0M19 5L5 19',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6', cal: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4', swap: 'M7 7h12l-3-3M17 17H5l3 3',
  stopw: 'M12 9v4l3 2M5 14a7 7 0 1 0 14 0a7 7 0 1 0-14 0M9 2h6', hourg: 'M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9', days: 'M4 6h16v14H4zM4 10h16M8 14h3M13 14h3'
};
const ic = (n, s = 24) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n]}"/></svg>`;
const mark = (s = 28) => {
  const c = ['#7aa7e0', '#a898d8', '#74b88f', '#d9ad66', '#d98383', '#7aa7e0', '#a898d8', '#74b88f', '#d9ad66'];
  return `<svg width="${s}" height="${s}" viewBox="0 0 30 30" aria-hidden="true">${c.map((x, i) => `<circle cx="${5 + (i % 3) * 10}" cy="${5 + Math.floor(i / 3) * 10}" r="3.6" fill="${x}"/>`).join('')}</svg>`;
};
const ring = (p, c, s = 64, w = 7) => {
  const r = (s - w) / 2, C = 2 * Math.PI * r, h = s / 2;
  return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" style="transform:rotate(-90deg)"><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="#2e333a" stroke-width="${w}"/>${p > 0 ? `<circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-dasharray="${C * Math.min(p, 1)} ${C}"/>` : ''}</svg>`;
};
const MI = {
  notes: '<defs><linearGradient id="n{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#ffa63d"/></linearGradient></defs><rect x="3" y="2.5" width="14.5" height="19" rx="3.5" fill="url(#n{u})"/><path d="M6.5 8h7.5M6.5 12h7.5M6.5 16h4" stroke="#fff" stroke-opacity=".9" stroke-width="1.6" stroke-linecap="round"/><path d="M13.6 21.2l1-4 6.3-6.3a1.5 1.5 0 0 1 2.1 2.1l-6.3 6.3z" fill="#4f8df5"/>',
  wallet: '<defs><linearGradient id="w{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#86e8aa"/><stop offset="1" stop-color="#27a465"/></linearGradient></defs><rect x="2" y="6" width="20" height="15" rx="4" fill="url(#w{u})"/><path d="M4.5 6.3l11.2-3.5a1.6 1.6 0 0 1 2.1 1.5V6z" fill="#1f8a58"/><rect x="13.5" y="11.5" width="9" height="5.4" rx="2.7" fill="#146b42"/><circle cx="17" cy="14.2" r="1.5" fill="#ffd45e"/>',
  toolbox: '<defs><linearGradient id="t{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffc46b"/><stop offset="1" stop-color="#f0643c"/></linearGradient></defs><path d="M8.5 7V5.8A1.8 1.8 0 0 1 10.3 4h3.4a1.8 1.8 0 0 1 1.8 1.8V7" stroke="#ffc46b" stroke-width="2" stroke-linecap="round"/><rect x="2" y="7" width="20" height="14" rx="3.6" fill="url(#t{u})"/><path d="M2 13.2h20" stroke="#000" stroke-opacity=".2" stroke-width="1.4"/><rect x="9.8" y="11" width="4.4" height="4.4" rx="1.3" fill="#fff4cf"/>',
  docs: '<defs><linearGradient id="d{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c3b0ff"/><stop offset="1" stop-color="#7a52e6"/></linearGradient></defs><rect x="2" y="3.5" width="20" height="17" rx="4" fill="url(#d{u})"/><circle cx="8.3" cy="9" r="2.2" fill="#ffe27a"/><path d="M2 17l5.8-5.2 4.4 4 3.4-3L22 17.2v.3a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3z" fill="#fff" fill-opacity=".88"/>',
  vault: '<defs><linearGradient id="v{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8fa0"/><stop offset="1" stop-color="#e8384f"/></linearGradient></defs><path d="M7.5 10.5V8a4.5 4.5 0 0 1 9 0v2.5" stroke="#ffc2cb" stroke-width="2.3" stroke-linecap="round"/><rect x="3.5" y="10" width="17" height="12" rx="3.8" fill="url(#v{u})"/><circle cx="12" cy="15.2" r="2" fill="#fff"/><rect x="11.2" y="15.8" width="1.6" height="3.4" rx=".8" fill="#fff"/>',
  brain: '<defs><linearGradient id="b{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c3b0ff"/><stop offset="1" stop-color="#7a52e6"/></linearGradient></defs><path d="M12 2a7 7 0 0 0-3.9 12.8c.6.4.9 1 .9 1.8V18h6v-1.4c0-.8.3-1.4.9-1.8A7 7 0 0 0 12 2z" fill="url(#b{u})"/><rect x="9" y="19" width="6" height="2.6" rx="1.3" fill="#d9d0f5"/><path d="M10.1 10l1.9 2.1L13.9 10" stroke="#ffe27a" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>',
  fit: '<rect x="2.5" y="8.5" width="3.2" height="7" rx="1.3" fill="#74b88f"/><rect x="18.3" y="8.5" width="3.2" height="7" rx="1.3" fill="#74b88f"/><rect x="5.7" y="6.5" width="3" height="11" rx="1.3" fill="#74b88f" fill-opacity=".3" stroke="#74b88f" stroke-width="1.4"/><rect x="15.3" y="6.5" width="3" height="11" rx="1.3" fill="#74b88f" fill-opacity=".3" stroke="#74b88f" stroke-width="1.4"/><path d="M8.7 12h6.6" stroke="#d98383" stroke-width="2" stroke-linecap="round"/>',
  library: '<rect x="3" y="4" width="5.2" height="16" rx="1.5" fill="#d9ad66" fill-opacity=".22" stroke="#d9ad66" stroke-width="1.6"/><rect x="9.6" y="4" width="5.2" height="16" rx="1.5" fill="#7aa7e0" fill-opacity=".22" stroke="#7aa7e0" stroke-width="1.6"/><rect x="16" y="5" width="4.6" height="15" rx="1.5" transform="rotate(-12 18.3 12.5)" fill="#74b88f" fill-opacity=".22" stroke="#74b88f" stroke-width="1.6"/><path d="M3 8.6h5.2" stroke="#d98383" stroke-width="1.5"/>',
  life: '<defs><linearGradient id="l{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7ab8ff"/><stop offset="1" stop-color="#2f6fe0"/></linearGradient></defs><rect x="2" y="4" width="20" height="18" rx="4.2" fill="url(#l{u})"/><path d="M2 8.2A4.2 4.2 0 0 1 6.2 4h11.6A4.2 4.2 0 0 1 22 8.2V10H2z" fill="#ff6b7d"/><path d="M8 2.2v3.6M16 2.2v3.6" stroke="#fff" stroke-width="2" stroke-linecap="round"/><path d="M8 16l2.7 2.7 5.3-5.6" stroke="#fff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>',
  nHome: '<path d="M4 11.2L12 4l8 7.2V19a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19z" fill="#7aa7e0" fill-opacity=".25" stroke="#7aa7e0" stroke-width="1.6" stroke-linejoin="round"/><rect x="10" y="13.5" width="4" height="7" rx="1.2" fill="#d9ad66"/>',
  nSearch: '<circle cx="10.5" cy="10.5" r="6" fill="#a898d8" fill-opacity=".22" stroke="#a898d8" stroke-width="1.7"/><path d="M15.2 15.2L20 20" stroke="#d9ad66" stroke-width="2.2" stroke-linecap="round"/>',
  nGrid: '<rect x="4" y="4" width="7" height="7" rx="2" fill="#7aa7e0"/><rect x="13" y="4" width="7" height="7" rx="2" fill="#74b88f"/><rect x="4" y="13" width="7" height="7" rx="2" fill="#d9ad66"/><rect x="13" y="13" width="7" height="7" rx="2" fill="#a898d8"/>',
  nSet: '<path d="M4 7h16M4 17h16" stroke="#8d949e" stroke-width="1.6" stroke-linecap="round"/><circle cx="9" cy="7" r="2.7" fill="#7aa7e0"/><circle cx="15" cy="17" r="2.7" fill="#d9ad66"/>',
  tCalc: '<rect x="5" y="3" width="14" height="18" rx="3.5" fill="#7aa7e0" fill-opacity=".2" stroke="#7aa7e0" stroke-width="1.6"/><rect x="8" y="6" width="8" height="3.6" rx="1.1" fill="#d9ad66"/><circle cx="9" cy="13" r="1.1" fill="#cfe0f5"/><circle cx="12" cy="13" r="1.1" fill="#cfe0f5"/><circle cx="15" cy="13" r="1.1" fill="#74b88f"/><circle cx="9" cy="16.6" r="1.1" fill="#cfe0f5"/><circle cx="12" cy="16.6" r="1.1" fill="#cfe0f5"/><circle cx="15" cy="16.6" r="1.1" fill="#74b88f"/>',
  tPct: '<circle cx="12" cy="12" r="9" fill="#74b88f" fill-opacity=".2" stroke="#74b88f" stroke-width="1.6"/><path d="M15.5 8.5l-7 7" stroke="#d9ad66" stroke-width="1.9" stroke-linecap="round"/><circle cx="9" cy="9" r="1.5" fill="#cfe9d9"/><circle cx="15" cy="15" r="1.5" fill="#cfe9d9"/>',
  tVat: '<path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8z" fill="#7aa7e0" fill-opacity=".2" stroke="#7aa7e0" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 8.5h6M9 12h6" stroke="#cfe0f5" stroke-width="1.6" stroke-linecap="round"/><path d="M9 15.2h3" stroke="#d9ad66" stroke-width="1.8" stroke-linecap="round"/>',
  tDisc: '<path d="M4 12V5.5A1.5 1.5 0 0 1 5.5 4H12l8.2 8.2a1.5 1.5 0 0 1 0 2.1L14.3 20.2a1.5 1.5 0 0 1-2.1 0z" fill="#a898d8" fill-opacity=".2" stroke="#a898d8" stroke-width="1.6" stroke-linejoin="round"/><circle cx="8.3" cy="8.3" r="1.6" fill="#d9ad66"/>',
  tAge: '<rect x="3.5" y="5" width="17" height="15" rx="3.5" fill="#a898d8" fill-opacity=".2" stroke="#a898d8" stroke-width="1.6"/><path d="M3.5 10h17" stroke="#a898d8" stroke-width="1.3"/><path d="M8 3v4M16 3v4" stroke="#7aa7e0" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="15" r="2" fill="#d9ad66"/>',
  tDiff: '<rect x="3.5" y="5" width="17" height="15" rx="3.5" fill="#74b88f" fill-opacity=".2" stroke="#74b88f" stroke-width="1.6"/><path d="M3.5 10h17" stroke="#74b88f" stroke-width="1.3"/><path d="M8 14.5h8m0 0l-2-2m2 2l-2 2" stroke="#d9ad66" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  tSwap: '<path d="M5 8h12l-3-3" stroke="#7aa7e0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M19 16H7l3 3" stroke="#d9ad66" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  tWatch: '<circle cx="12" cy="13.5" r="7" fill="#d9ad66" fill-opacity=".2" stroke="#d9ad66" stroke-width="1.6"/><path d="M12 13.5V9.8" stroke="#d98383" stroke-width="1.9" stroke-linecap="round"/><path d="M10 3.5h4" stroke="#7aa7e0" stroke-width="1.9" stroke-linecap="round"/><path d="M18 7.2l1.3-1.3" stroke="#7aa7e0" stroke-width="1.9" stroke-linecap="round"/>',
  tTimer: '<path d="M8 4h8v3.5c0 2.2-4 3-4 4.5s4 2.3 4 4.5V20H8v-3.5c0-2.2 4-3 4-4.5S8 9.7 8 7.5z" fill="#a898d8" fill-opacity=".2" stroke="#a898d8" stroke-width="1.6" stroke-linejoin="round"/><path d="M10 18.2h4" stroke="#d9ad66" stroke-width="1.9" stroke-linecap="round"/>',
  car: '<defs><linearGradient id="k{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5ee6d6"/><stop offset="1" stop-color="#1a9fbf"/></linearGradient></defs><rect x="2" y="10.5" width="20" height="7.5" rx="3.2" fill="url(#k{u})"/><path d="M6.4 10.6l1.2-3.1a1.1 1.1 0 0 1 1-.7h6.8a1.1 1.1 0 0 1 1 .7l1.2 3.1z" fill="#fff" fill-opacity=".92"/><circle cx="7" cy="17.8" r="2.3" fill="#162033" stroke="#d6dfeb" stroke-width="1.4"/><circle cx="17" cy="17.8" r="2.3" fill="#162033" stroke="#d6dfeb" stroke-width="1.4"/><circle cx="4.4" cy="13.6" r="1" fill="#ffe27a"/><circle cx="19.6" cy="13.6" r="1" fill="#ff7a8a"/>',
  water: '<path d="M12 3.5c3 3.8 5.5 6.4 5.5 9.5a5.5 5.5 0 0 1-11 0c0-3.1 2.5-5.7 5.5-9.5z" fill="#7aa7e0" fill-opacity=".25" stroke="#7aa7e0" stroke-width="1.6" stroke-linejoin="round"/><path d="M9.6 14a2.5 2.5 0 0 0 2 2" stroke="#cfe0f5" stroke-width="1.5" stroke-linecap="round"/>',
  gMem: '<rect x="3.5" y="6" width="10" height="13" rx="2.4" fill="#a898d8" fill-opacity=".25" stroke="#a898d8" stroke-width="1.6"/><rect x="10.5" y="4" width="10" height="13" rx="2.4" fill="#d9ad66" fill-opacity=".25" stroke="#d9ad66" stroke-width="1.6"/><circle cx="15.5" cy="10.5" r="2" fill="#d9ad66"/>',
  gMath: '<path d="M6 8h6M9 5v6" stroke="#7aa7e0" stroke-width="2" stroke-linecap="round"/><path d="M14 7.2h6M14 10.2h6" stroke="#d9ad66" stroke-width="2" stroke-linecap="round"/><path d="M5 17l5 4M10 17l-5 4" stroke="#74b88f" stroke-width="2" stroke-linecap="round"/><path d="M14 19h6" stroke="#d98383" stroke-width="2" stroke-linecap="round"/>',
  gSeq: '<circle cx="5" cy="16" r="2.2" fill="#74b88f"/><circle cx="11" cy="12" r="2.2" fill="#7aa7e0"/><circle cx="17" cy="8" r="2.2" fill="#a898d8"/><path d="M5 16L11 12L17 8" stroke="#8d949e" stroke-width="1.2" stroke-dasharray="2 2"/><circle cx="21" cy="4.5" r="1.3" fill="#d9ad66"/>',
  gWord: '<rect x="3" y="4" width="9" height="9" rx="2.4" fill="#d9ad66" fill-opacity=".25" stroke="#d9ad66" stroke-width="1.6"/><rect x="12" y="11" width="9" height="9" rx="2.4" fill="#74b88f" fill-opacity=".25" stroke="#74b88f" stroke-width="1.6"/><text x="7.5" y="11" font-size="7.5" font-weight="700" text-anchor="middle" fill="#d9ad66">A</text><text x="16.5" y="18" font-size="7.5" font-weight="700" text-anchor="middle" fill="#74b88f">B</text>',
  gColor: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.4 0 2-1 1.5-2.1-.5-1.2.3-2.4 1.7-2.4H17a3.5 3.5 0 0 0 3.5-3.5C20.5 7 16.7 3.5 12 3.5z" fill="#d98383" fill-opacity=".18" stroke="#d98383" stroke-width="1.6"/><circle cx="8" cy="10" r="1.4" fill="#7aa7e0"/><circle cx="11.5" cy="7" r="1.4" fill="#d9ad66"/><circle cx="15.5" cy="8.5" r="1.4" fill="#74b88f"/>',
  crypto: '<defs><linearGradient id="c{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#f5a623"/></linearGradient></defs><circle cx="12" cy="12" r="9.5" fill="url(#c{u})"/><circle cx="12" cy="12" r="6.6" stroke="#fff" stroke-opacity=".55" stroke-width="1.3"/><path d="M8.4 14.6l2.6-3 2 1.8 3-3.6" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.6 9.8h2.8v2.8" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  media: '<defs><linearGradient id="m{u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8fa0"/><stop offset="1" stop-color="#d8305f"/></linearGradient></defs><rect x="2" y="4" width="20" height="16" rx="4.2" fill="url(#m{u})"/><path d="M10 8.6v6.8a.8.8 0 0 0 1.2.7l5.6-3.4a.8.8 0 0 0 0-1.4l-5.6-3.4a.8.8 0 0 0-1.2.7z" fill="#fff"/>',
  tLife: '<rect x="3.5" y="5" width="17" height="15" rx="3.5" fill="#7aa7e0" fill-opacity=".2" stroke="#7aa7e0" stroke-width="1.6"/><path d="M3.5 10h17" stroke="#7aa7e0" stroke-width="1.3"/><path d="M8 3v4M16 3v4" stroke="#d98383" stroke-width="1.8" stroke-linecap="round"/><path d="M8.6 15l2.3 2.3 4.6-4.7" stroke="#74b88f" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>',
  tSos: '<circle cx="12" cy="12" r="9" fill="#d98383" fill-opacity=".2" stroke="#d98383" stroke-width="1.6"/><path d="M5.8 12h1.4M9 12h1.4M13.6 12h1.4M16.8 12h1.4" stroke="#ffe27a" stroke-width="2.2" stroke-linecap="round"/><path d="M12 6.5v2.2M12 15.3v2.2" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/>',
  tWhistle: '<path d="M3 11.5a5 5 0 0 1 5-5h7a5 5 0 0 1 0 10H9.5a6 6 0 0 1-5-2.7z" fill="#d9ad66" fill-opacity=".25" stroke="#d9ad66" stroke-width="1.6" stroke-linejoin="round"/><circle cx="15" cy="12" r="2" fill="#d9ad66"/><path d="M19 6l2-2M20 9h2.5M18 3.5V2" stroke="#d98383" stroke-width="1.6" stroke-linecap="round"/>',
  tPhone: '<path d="M6.5 3.5h3l1.5 4-2 1.3a10 10 0 0 0 5.2 5.2l1.3-2 4 1.5v3a2 2 0 0 1-2 2A15 15 0 0 1 4.5 5.5a2 2 0 0 1 2-2z" fill="#74b88f" fill-opacity=".25" stroke="#74b88f" stroke-width="1.6" stroke-linejoin="round"/><path d="M15 4.5a5 5 0 0 1 4.5 4.5M15 8a2 2 0 0 1 1.5 1.5" stroke="#ffe27a" stroke-width="1.6" stroke-linecap="round"/>',
  tQuake: '<path d="M2 12h4l2-6 3 12 3-9 2 3h6" stroke="#a898d8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 20h18" stroke="#d9ad66" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="3 3"/>',
  tList: '<rect x="4" y="3.5" width="16" height="17" rx="3.5" fill="#7aa7e0" fill-opacity=".2" stroke="#7aa7e0" stroke-width="1.6"/><path d="M7.5 8h2.2M7.5 12h2.2M7.5 16h2.2" stroke="#d98383" stroke-width="2" stroke-linecap="round"/><path d="M12 8h4.5M12 12h4.5M12 16h3" stroke="#cfe0f5" stroke-width="1.6" stroke-linecap="round"/>',
  wSun: '<circle cx="12" cy="12" r="5" fill="#ffd45e"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8" stroke="#ffb547" stroke-width="1.8" stroke-linecap="round"/>',
  wPart: '<circle cx="9" cy="9" r="4" fill="#ffd45e"/><path d="M9 2.5v1.6M2.5 9h1.6M4.4 4.4l1.1 1.1M13.6 4.4l-1.1 1.1" stroke="#ffb547" stroke-width="1.6" stroke-linecap="round"/><path d="M8 20a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.3A3.4 3.4 0 0 1 18 20z" fill="#cfd8e6"/>',
  wCloud: '<path d="M7 19a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.3A3.4 3.4 0 0 1 17 19z" fill="#cfd8e6"/>',
  wRain: '<path d="M7 18a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.3A3.4 3.4 0 0 1 17 18z" fill="#cfd8e6"/><path d="M8 20l-.8 2M12 20l-.8 2M16 20l-.8 2" stroke="#6cb2ff" stroke-width="1.8" stroke-linecap="round"/>',
  wSnow: '<path d="M7 18a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.3A3.4 3.4 0 0 1 17 18z" fill="#cfd8e6"/><circle cx="8" cy="21" r="1" fill="#fff"/><circle cx="12" cy="21.4" r="1" fill="#fff"/><circle cx="16" cy="21" r="1" fill="#fff"/>',
  wStorm: '<path d="M7 18a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.3A3.4 3.4 0 0 1 17 18z" fill="#cfd8e6"/><path d="M12.5 15l-2.3 3.6h2l-1 3 3.3-4.3h-2z" fill="#ffd45e"/>',
  wFog: '<path d="M4 8h16M3 12h18M5 16h14M8 20h8" stroke="#a9b8cc" stroke-width="2" stroke-linecap="round"/>'
};
let UID = 0;
const mi = (n, s = 24) => { const u = ++UID; return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" aria-hidden="true">${(MI[n] || '').replace(/\{u\}/g, u)}</svg>`; };
const MODS = [
  { id: 'notes', n: 'Notlar', s: 'Notlarını yaz ve sakla', c: 'blue', i: 'notes', ok: 1, f: ['Not yazma ve düzenleme', 'Önemli notları yıldızlama', 'Notlarda arama'] },
  { id: 'budget', n: 'Cüzdanım', s: 'Gelir, gider, borç ve birikim', c: 'green', i: 'wallet', ok: 1, f: ['Gelir ve gider takibi', 'Günlük, haftalık, aylık özet', 'Borç ve alacak takibi', 'Birikim hedefleri'] },
  { id: 'toolbox', n: 'Alet Çantası', s: 'Hesaplama ve dönüştürme araçları', c: 'orange', i: 'toolbox', ok: 1, f: ['Hesap makinesi', 'Takvim ve görevler', 'Acil durum araçları', 'Yüzde, KDV, indirim', 'Birim dönüştürücü', 'Kronometre ve zamanlayıcı'] },
  { id: 'docs', n: 'Dökümanlar', s: 'Fotoğraf ve belge arşivi', c: 'purple', i: 'docs', ok: 1, f: ['Fotoğraf çekme ve saklama', 'Klasörler', 'PDF saklama', 'Favoriler', 'Ada göre arama'] },
  { id: 'vault', n: 'Kasa', s: 'PIN korumalı şifreli kasa', c: 'red', i: 'vault', ok: 1, f: ['PIN kilidi', 'Şifreli şifre kayıtları', 'Şifreli notlar', 'Şifre oluşturucu', 'Otomatik kilit'] },
  { id: 'brain', n: 'Beyin', s: 'Zekâ ve hafıza oyunları', c: 'purple', i: 'brain', ok: 1, f: ['Hafıza oyunu', 'Hızlı işlem', 'Sayı dizileri', 'Kelime oyunu', 'Renk-dikkat oyunu'] },
  { id: 'crypto', n: 'Kripto', s: 'Coin portföyü ve fiyat takibi', c: 'orange', i: 'crypto', ok: 1, f: ['Alış ve satış kayıtları', 'Ortalama maliyet', 'Kâr / zarar', 'Canlı fiyat', 'Takip listesi'] },
  { id: 'car', n: 'Araç', s: 'Yakıt, bakım ve muayene takibi', c: 'orange', i: 'car', ok: 1, f: ['Yakıt ve tüketim', 'Bakım kayıtları', 'Muayene ve sigorta hatırlatma', 'Masraf özeti'] },
  { id: 'media', n: 'Media', s: 'Şifreli foto ve video galerisi', c: 'red', i: 'media', ok: 1, f: ['Şifreli fotoğraf ve video kitaplığı', 'Tam ekran görüntüleyici', 'Video oynatıcı', 'PIN ile giriş', 'Otomatik kilit'] }
];
const mod = id => MODS.find(m => m.id === id);
const MV = {}, A = {}, LIVE = {};
let T = [], LEAVE = [], HAPTIC = true;
const onLeave = f => LEAVE.push(f);
const runLeave = () => { const l = LEAVE; LEAVE = []; l.forEach(f => { try { f(); } catch (e) { /* yoksay */ } }); };
const vibe = (ms = 8) => { if (HAPTIC && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* yoksay */ } } };
const fmtSize = b => b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function shareFile(blob, name) {
  const f = new File([blob], name, { type: blob.type || 'application/octet-stream' });
  if (navigator.canShare && navigator.canShare({ files: [f] })) { try { await navigator.share({ files: [f] }); return 'shared'; } catch (e) { if (e && e.name === 'AbortError') return 'cancel'; } }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); return 'download';
}
const every = (f, ms) => T.push(setInterval(f, ms));
const clearT = () => { T.forEach(clearInterval); T = []; };
const pad = n => String(n).padStart(2, '0');
const dstr = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const today = () => dstr(new Date());
const num = s => { s = String(s).trim(); if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.'); return parseFloat(s); };
const money = n => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 2 }).format(n);
const fmt = n => isFinite(n) ? new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 4 }).format(+n.toFixed(6)) : '—';
const dlabel = ds => {
  const k = Math.round((new Date(ds + 'T00:00') - new Date(today() + 'T00:00')) / 864e5);
  return k === 0 ? 'Bugün' : k === 1 ? 'Yarın' : k === -1 ? 'Dün' : new Date(ds + 'T00:00').toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
};
function toast(t) {
  const el = $('#toast'); el.textContent = t; el.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 1800);
}
const seg = (id, o, cur) => `<div class="seg" data-k="${id}" id="${id}" data-val="${cur}">${o.map(([v, l]) => `<button type="button" class="${v === cur ? 'on' : ''}" data-a="pick" data-v="${v}">${l}</button>`).join('')}</div>`;
const chips = (id, o, cur) => `<div class="chips" data-k="${id}" id="${id}" data-val="${cur}">${o.map(([v, l, c]) => `<button type="button" class="${v === cur ? 'on' : ''}" ${c ? `style="--c:${c}"` : ''} data-a="pick" data-v="${v}">${l}</button>`).join('')}</div>`;
const vals = r => { const o = {}; r.querySelectorAll('[data-k]').forEach(e => o[e.dataset.k] = e.dataset.val !== undefined ? e.dataset.val : e.value); return o; };
A.pick = b => {
  const g = b.parentElement; g.dataset.val = b.dataset.v;
  [...g.children].forEach(c => c.classList.toggle('on', c === b));
  if (g.onchange) g.onchange();
  const f = g.closest('[data-live]'); if (f && LIVE[f.dataset.live]) LIVE[f.dataset.live](f);
};
function sheet(html, cls = '') {
  const o = $(cls ? '.sheet.' + cls : '.sheet:not(.dp)'); if (o) o.remove();
  const s = document.createElement('div'); s.className = 'sheet ' + cls;
  s.innerHTML = `<div class="bd" data-a="${cls ? 'dpClose' : 'closeSheet'}"></div><div class="panel"><i class="grab"></i>${html}</div>`;
  document.body.appendChild(s); requestAnimationFrame(() => s.classList.add('open'));
}
A.closeSheet = () => { const s = $('.sheet:not(.dp)'); if (s) { s.classList.remove('open'); setTimeout(() => s.remove(), 220); } };
const mhero = (m, back = '#/home', sub) => `<a class="back" href="${back}" aria-label="Geri">${ic('back', 22)}</a><div class="mhero" style="--c:var(--${m.c})"><div class="ico">${mi(m.i, 46)}</div><div><h1>${m.n}</h1><p>${sub || m.s}</p></div></div>`;
const fab = (a, c = 'blue') => `<button class="fab" data-a="${a}" style="--c:var(--${c})" aria-label="Ekle">${ic('plus', 26)}</button>`;
const MON = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const dtxt = ds => { if (!ds) return 'Tarih seç'; const [y, m, d] = ds.split('-'); return `${+d} ${MON[m - 1]} ${y}`; };
const dateField = (id, l, v = '') => `<div class="field"><label>${l}</label><button type="button" class="dfield" id="${id}" data-k="${id}" data-val="${v}" data-a="dpick">${ic('cal', 20)}<span>${dtxt(v)}</span></button></div>`;
const DP = {};
function dpDraw() {
  const { y, m, sel, mode, base } = DP; let head, body;
  const nb = d => `<button class="nb" data-a="dnav" data-d="${d}" aria-label="${d < 0 ? 'Önceki' : 'Sonraki'}">${ic(d < 0 ? 'back' : 'next', 20)}</button>`;
  if (mode === 'days') {
    const lead = (new Date(y, m, 1).getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate(), t0 = today();
    const cells = [...Array(lead).fill(''), ...Array.from({ length: dim }, (_, i) => `${y}-${pad(m + 1)}-${pad(i + 1)}`)];
    head = `<div class="dtl"><button data-a="dmode" data-v="months">${MON[m]}</button><button data-a="dmode" data-v="years">${y}</button></div>`;
    body = `<div class="cal">${['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'].map(d => `<b>${d}</b>`).join('')}${cells.map(d => d ? `<button class="${d === sel ? 'sel' : ''} ${d === t0 ? 'td' : ''}" data-a="dday" data-d="${d}">${+d.slice(8)}</button>` : '<span></span>').join('')}</div>`;
  } else if (mode === 'months') {
    head = `<div class="dtl"><button data-a="dmode" data-v="years">${y}</button></div>`;
    body = `<div class="pgrid" style="grid-template-columns:repeat(3,1fr)">${MON.map((n, i) => `<button class="${i === m ? 'on' : ''}" data-a="dmon" data-v="${i}">${n}</button>`).join('')}</div>`;
  } else {
    head = `<div class="dtl"><span>${base} – ${base + 19}</span></div>`;
    body = `<div class="pgrid">${Array.from({ length: 20 }, (_, i) => base + i).map(v => `<button class="${v === y ? 'on' : ''}" data-a="dyr" data-v="${v}">${v}</button>`).join('')}</div>`;
  }
  const html = `<div class="dpt">${nb(-1)}${head}${nb(1)}</div>${body}<div class="bar"><button class="btn sec w" data-a="dpClose">Vazgeç</button><button class="btn w" data-a="dday" data-d="${today()}">Bugün</button></div>`;
  const el = $('.sheet.dp .panel'); if (el) el.innerHTML = '<i class="grab"></i>' + html; else sheet(html, 'dp');
}
A.dpick = b => { const v = b.dataset.val || today(), [y, m] = v.split('-').map(Number); Object.assign(DP, { id: b.id, y, m: m - 1, sel: b.dataset.val, mode: 'days', base: y - 10 }); dpDraw(); };
A.dnav = b => { const d = +b.dataset.d; if (DP.mode === 'days') { const n = new Date(DP.y, DP.m + d, 1); DP.y = n.getFullYear(); DP.m = n.getMonth(); } else if (DP.mode === 'months') DP.y += d; else DP.base += 20 * d; dpDraw(); };
A.dmode = b => { DP.mode = b.dataset.v; if (DP.mode === 'years') DP.base = DP.y - 10; dpDraw(); };
A.dyr = b => { DP.y = +b.dataset.v; DP.mode = 'months'; dpDraw(); };
A.dmon = b => { DP.m = +b.dataset.v; DP.mode = 'days'; dpDraw(); };
A.dday = b => { const d = b.dataset.d, f = $('#' + DP.id); f.dataset.val = d; f.querySelector('span').textContent = dtxt(d); A.dpClose(); const w = f.closest('[data-live]'); if (w && LIVE[w.dataset.live]) LIVE[w.dataset.live](w); };
A.dpClose = () => { const s = $('.sheet.dp'); if (s) { s.classList.remove('open'); setTimeout(() => s.remove(), 220); } };
document.addEventListener('click', e => { if (e.target.closest('button,a,[data-a]')) vibe(); const b = e.target.closest('[data-a]'); if (b && A[b.dataset.a]) A[b.dataset.a](b, e); });
document.addEventListener('input', e => { const f = e.target.closest('[data-live]'); if (f && LIVE[f.dataset.live]) LIVE[f.dataset.live](f); });
