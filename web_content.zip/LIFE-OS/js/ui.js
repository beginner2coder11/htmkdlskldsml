/* LIFE OS – ortak arayüz yardımcıları */
const $ = (s, r = document) => r.querySelector(s);
const view = $('#view');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const P = {
  home: 'M4 11l8-7 8 7v9h-5v-6H9v6H4z', search: 'M4 11a7 7 0 1 0 14 0a7 7 0 1 0-14 0M20 20l-4-4',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  sliders: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 7a2 2 0 1 0 4 0a2 2 0 1 0-4 0M6 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0',
  note: 'M7 3h8l4 4v14H7zM15 3v4h4M10 12h6M10 16h6', wallet: 'M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 7l12-3v3M16 14h2',
  calc: 'M6 3h12v18H6zM9 7h6M9 11h2M13 11h2M9 15h2M13 15h2', globe: 'M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  lock: 'M6 11h12v10H6zM8 11V8a4 4 0 0 1 8 0v3', bolt: 'M13 2L4 14h7l-1 8 9-12h-7z', pulse: 'M3 12h4l2-5 4 10 2-5h6',
  book: 'M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h10', check: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4M9 15l2 2 4-4',
  back: 'M15 5l-7 7 7 7', next: 'M9 5l7 7-7 7', tick: 'M5 12l5 5 9-10', x: 'M6 6l12 12M18 6L6 18', ring: 'M4 12a8 8 0 1 0 16 0a8 8 0 1 0-16 0',
  plus: 'M12 5v14M5 12h14', percent: 'M5 7a2 2 0 1 0 4 0a2 2 0 1 0-4 0M15 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0M19 5L5 19',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6', cal: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4', swap: 'M7 7h12l-3-3M17 17H5l3 3',
  stopw: 'M12 9v4l3 2M5 14a7 7 0 1 0 14 0a7 7 0 1 0-14 0M9 2h6', hourg: 'M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9', days: 'M4 6h16v14H4zM4 10h16M8 14h3M13 14h3'
};
const ic = (n, s = 24) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n]}"/></svg>`;
const mark = (s = 28) => {
  const c = ['#7aa7e0', '#a898d8', '#74b88f', '#d9ad66', '#d98383', '#7aa7e0', '#a898d8', '#74b88f', '#d9ad66'];
  return `<svg width="${s}" height="${s}" viewBox="0 0 30 30" aria-hidden="true">${c.map((x, i) => `<circle cx="${5 + (i % 3) * 10}" cy="${5 + Math.floor(i / 3) * 10}" r="3.6" fill="${x}"/>`).join('')}</svg>`;
};
const ring = (p, c, s = 64, w = 7) => {
  const r = (s - w) / 2, C = 2 * Math.PI * r, h = s / 2;
  return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" style="transform:rotate(-90deg)"><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="#2e333a" stroke-width="${w}"/>${p > 0 ? `<circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-dasharray="${C * Math.min(p, 1)} ${C}"/>` : ''}</svg>`;
};
const MODS = [
  { id: 'mind', n: 'Zihin', s: 'Kişisel bilgi merkezi', c: 'blue', i: 'note', st: 2, ok: 1, f: ['Not oluşturma ve düzenleme', 'Kategoriler ve etiketler', 'Favoriler', 'Kişisel bilgi arşivi', 'Notlarda arama'] },
  { id: 'budget', n: 'Cüzdanım', s: 'Finans yönetimi', c: 'green', i: 'wallet', st: 2, ok: 1, f: ['Gelir ve gider takibi', 'Borç, alacak ve taksit takibi', 'Aylık bütçe', 'Birikim hedefleri', 'Grafikler ve raporlar (TL)'] },
  { id: 'toolbox', n: 'Alet Çantası', s: 'Dijital alet çantası', c: 'orange', i: 'calc', st: 2, ok: 1, f: ['Hesap makineleri', 'Yüzde, KDV, indirim', 'Yaş ve tarih hesaplama', 'Birim dönüştürücü', 'Kronometre ve zamanlayıcı'] },
  { id: 'world', n: 'Dünya', s: 'Dünya ansiklopedisi', c: 'purple', i: 'globe', st: 3, f: ['Ülkeler ve başkentler', 'Tarih ve coğrafya', 'Bilim, fizik, kimya, biyoloji', 'Astronomi ve uzay', 'Çevrimdışı bilgi arama'] },
  { id: 'vault', n: 'Kasa', s: 'Güvenli kişisel kasa', c: 'red', i: 'lock', st: 5, f: ['PIN kilidi ve parmak izi', 'Şifreli notlar', 'Şifre kayıtları', 'Güvenli belge kayıtları', 'Şifre oluşturucu ve otomatik kilit'] },
  { id: 'brain', n: 'Beyin', s: 'Zekâ merkezi', c: 'purple', i: 'bolt', st: 4, f: ['Mantık ve matematik soruları', 'Hafıza ve dikkat oyunları', 'Sayı dizileri ve kelime oyunları', 'Zorluk seviyeleri', 'Puan ve rekor sistemi'] },
  { id: 'fit', n: 'Fitness', s: 'Fitness takibi', c: 'green', i: 'pulse', st: 4, f: ['Kilo, boy ve VKİ', 'Su takibi', 'Egzersiz kayıtları ve programlar', 'Günlük hedefler', 'İlerleme grafikleri'] },
  { id: 'library', n: 'Kütüphane', s: 'Dijital kütüphane', c: 'orange', i: 'book', st: 3, f: ['PDF ve metin arşivi', 'Kitap listesi ve kategoriler', 'Favoriler ve son okunanlar', 'Okuma geçmişi', 'Okuma işaretleri'] },
  { id: 'life', n: 'Yaşam', s: 'Günlük yaşam yönetimi', c: 'blue', i: 'check', st: 2, ok: 1, f: ['Takvim ve görev listesi', 'Görevler', 'Alışkanlık takibi', 'Hatırlatıcılar', 'Günlük, haftalık, aylık plan'] }
];
const mod = id => MODS.find(m => m.id === id);
const MV = {}, A = {}, LIVE = {};
let T = [];
const every = (f, ms) => T.push(setInterval(f, ms));
const clearT = () => { T.forEach(clearInterval); T = []; };
const pad = n => String(n).padStart(2, '0');
const dstr = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const today = () => dstr(new Date());
const num = s => parseFloat(String(s).replace(',', '.'));
const money = n => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 2 }).format(n);
const fmt = n => isFinite(n) ? new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 4 }).format(+n.toFixed(6)) : '—';
const dlabel = ds => {
  const k = Math.round((new Date(ds + 'T00:00') - new Date(today() + 'T00:00')) / 864e5);
  return k === 0 ? 'Bugün' : k === 1 ? 'Yarın' : k === -1 ? 'Dün' : new Date(ds + 'T00:00').toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
};
function toast(t) {
  const el = $('#toast'); el.textContent = t; el.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 1800);
}
const seg = (id, o, cur) => `<div class="seg" data-k="${id}" id="${id}" data-val="${cur}">${o.map(([v, l]) => `<button type="button" class="${v === cur ? 'on' : ''}" data-a="pick" data-v="${v}">${l}</button>`).join('')}</div>`;
const chips = (id, o, cur) => `<div class="chips" data-k="${id}" id="${id}" data-val="${cur}">${o.map(([v, l, c]) => `<button type="button" class="${v === cur ? 'on' : ''}" ${c ? `style="--c:${c}"` : ''} data-a="pick" data-v="${v}">${l}</button>`).join('')}</div>`;
const vals = r => { const o = {}; r.querySelectorAll('[data-k]').forEach(e => o[e.dataset.k] = e.dataset.val !== undefined ? e.dataset.val : e.value); return o; };
A.pick = b => {
  const g = b.parentElement; g.dataset.val = b.dataset.v;
  [...g.children].forEach(c => c.classList.toggle('on', c === b));
  if (g.onchange) g.onchange();
  const f = g.closest('[data-live]'); if (f && LIVE[f.dataset.live]) LIVE[f.dataset.live](f);
};
function sheet(html, cls = '') {
  const o = $(cls ? '.sheet.' + cls : '.sheet:not(.dp)'); if (o) o.remove();
  const s = document.createElement('div'); s.className = 'sheet ' + cls;
  s.innerHTML = `<div class="bd" data-a="${cls ? 'dpClose' : 'closeSheet'}"></div><div class="panel"><i class="grab"></i>${html}</div>`;
  document.body.appendChild(s); requestAnimationFrame(() => s.classList.add('open'));
}
A.closeSheet = () => { const s = $('.sheet:not(.dp)'); if (s) { s.classList.remove('open'); setTimeout(() => s.remove(), 220); } };
const mhero = (m, back = '#/home', sub) => `<a class="back" href="${back}" aria-label="Geri">${ic('back', 22)}</a><div class="mhero" style="--c:var(--${m.c})"><div class="ico">${ic(m.i, 28)}</div><div><h1>${m.n}</h1><p>${sub || m.s}</p></div></div>`;
const fab = (a, c = 'blue') => `<button class="fab" data-a="${a}" style="--c:var(--${c})" aria-label="Ekle">${ic('plus', 26)}</button>`;
const MON = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const dtxt = ds => { if (!ds) return 'Tarih seç'; const [y, m, d] = ds.split('-'); return `${+d} ${MON[m - 1]} ${y}`; };
const dateField = (id, l, v = '') => `<div class="field"><label>${l}</label><button type="button" class="dfield" id="${id}" data-k="${id}" data-val="${v}" data-a="dpick">${ic('cal', 20)}<span>${dtxt(v)}</span></button></div>`;
const DP = {};
function dpDraw() {
  const { y, m, sel, mode, base } = DP; let head, body;
  const nb = d => `<button class="nb" data-a="dnav" data-d="${d}" aria-label="${d < 0 ? 'Önceki' : 'Sonraki'}">${ic(d < 0 ? 'back' : 'next', 20)}</button>`;
  if (mode === 'days') {
    const lead = (new Date(y, m, 1).getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate(), t0 = today();
    const cells = [...Array(lead).fill(''), ...Array.from({ length: dim }, (_, i) => `${y}-${pad(m + 1)}-${pad(i + 1)}`)];
    head = `<div class="dtl"><button data-a="dmode" data-v="months">${MON[m]}</button><button data-a="dmode" data-v="years">${y}</button></div>`;
    body = `<div class="cal">${['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'].map(d => `<b>${d}</b>`).join('')}${cells.map(d => d ? `<button class="${d === sel ? 'sel' : ''} ${d === t0 ? 'td' : ''}" data-a="dday" data-d="${d}">${+d.slice(8)}</button>` : '<span></span>').join('')}</div>`;
  } else if (mode === 'months') {
    head = `<div class="dtl"><button data-a="dmode" data-v="years">${y}</button></div>`;
    body = `<div class="pgrid" style="grid-template-columns:repeat(3,1fr)">${MON.map((n, i) => `<button class="${i === m ? 'on' : ''}" data-a="dmon" data-v="${i}">${n}</button>`).join('')}</div>`;
  } else {
    head = `<div class="dtl"><span>${base} – ${base + 19}</span></div>`;
    body = `<div class="pgrid">${Array.from({ length: 20 }, (_, i) => base + i).map(v => `<button class="${v === y ? 'on' : ''}" data-a="dyr" data-v="${v}">${v}</button>`).join('')}</div>`;
  }
  const html = `<div class="dpt">${nb(-1)}${head}${nb(1)}</div>${body}<div class="bar"><button class="btn sec w" data-a="dpClose">Vazgeç</button><button class="btn w" data-a="dday" data-d="${today()}">Bugün</button></div>`;
  const el = $('.sheet.dp .panel'); if (el) el.innerHTML = '<i class="grab"></i>' + html; else sheet(html, 'dp');
}
A.dpick = b => { const v = b.dataset.val || today(), [y, m] = v.split('-').map(Number); Object.assign(DP, { id: b.id, y, m: m - 1, sel: b.dataset.val, mode: 'days', base: y - 10 }); dpDraw(); };
A.dnav = b => { const d = +b.dataset.d; if (DP.mode === 'days') { const n = new Date(DP.y, DP.m + d, 1); DP.y = n.getFullYear(); DP.m = n.getMonth(); } else if (DP.mode === 'months') DP.y += d; else DP.base += 20 * d; dpDraw(); };
A.dmode = b => { DP.mode = b.dataset.v; if (DP.mode === 'years') DP.base = DP.y - 10; dpDraw(); };
A.dyr = b => { DP.y = +b.dataset.v; DP.mode = 'months'; dpDraw(); };
A.dmon = b => { DP.m = +b.dataset.v; DP.mode = 'days'; dpDraw(); };
A.dday = b => { const d = b.dataset.d, f = $('#' + DP.id); f.dataset.val = d; f.querySelector('span').textContent = dtxt(d); A.dpClose(); const w = f.closest('[data-live]'); if (w && LIVE[w.dataset.live]) LIVE[w.dataset.live](w); };
A.dpClose = () => { const s = $('.sheet.dp'); if (s) { s.classList.remove('open'); setTimeout(() => s.remove(), 220); } };
document.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (b && A[b.dataset.a]) A[b.dataset.a](b, e); });
document.addEventListener('input', e => { const f = e.target.closest('[data-live]'); if (f && LIVE[f.dataset.live]) LIVE[f.dataset.live](f); });
