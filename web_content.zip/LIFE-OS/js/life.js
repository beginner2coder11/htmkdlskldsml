/* LIFE OS – görevler, alışkanlıklar, takvim */
const L = { tab: 'tasks', sel: today(), mon: 0 };
const HCOL = ['#7aa7e0', '#a898d8', '#74b88f', '#d9ad66', '#d98383'];
const taskRow = (t, due) => `<li class="${t.done ? 'done' : ''}"><button class="chk" data-a="toggle" data-id="${t.id}" aria-label="Tamamla">${t.done ? ic('tick', 14) : ''}</button><span class="t">${esc(t.text)}${due && t.due ? `<small>${dlabel(t.due)}</small>` : ''}</span><button class="x" data-a="delTask" data-id="${t.id}" aria-label="Sil">${ic('x', 18)}</button></li>`;
const lastDays = n => { const d = new Date(); return Array.from({ length: n }, (_, i) => dstr(new Date(d.getFullYear(), d.getMonth(), d.getDate() - (n - 1 - i)))); };
const streak = h => { const ds = lastDays(366).reverse(); let i = h.days[ds[0]] ? 0 : 1, n = 0; while (i < ds.length && h.days[ds[i]]) { n++; i++; } return n; };

MV.life = async m => {
  const tasks = await DB.all('tasks'), t0 = today();
  let body = '';
  if (L.tab === 'tasks') {
    const open = tasks.filter(t => !t.done).sort((a, b) => (a.due || '').localeCompare(b.due || ''));
    const done = tasks.filter(t => t.done).sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0)).slice(0, 5);
    const grp = [['Gecikmiş', open.filter(t => t.due && t.due < t0)], ['Bugün', open.filter(t => !t.due || t.due === t0)], ['Yaklaşan', open.filter(t => t.due > t0)], ['Tamamlanan', done]];
    body = grp.filter(g => g[1].length).map(([n, a]) => `<div class="dh">${n}</div><section class="card" style="padding:4px 16px"><ul class="list">${a.map(t => taskRow(t, n !== 'Bugün')).join('')}</ul></section>`).join('') || '<section class="card"><p class="empty">Görev yok. + ile ilk görevini ekle.</p></section>';
  } else if (L.tab === 'habits') {
    const hs = await DB.all('habits'), ds = lastDays(7);
    body = hs.length ? `<section class="card"><div class="hl">${ds.map(d => `<span>${new Date(d + 'T00:00').toLocaleDateString('tr-TR', { weekday: 'narrow' })}</span>`).join('')}</div>${hs.map(h => `<div class="row" style="cursor:default"><button class="t" data-a="habOpen" data-id="${h.id}" style="background:none;border:0;text-align:left"><b>${esc(h.name)}</b><small>${streak(h)} gün seri</small></button><div class="hd" style="--c:${h.color}">${ds.map((d, i) => `<button class="${h.days[d] ? 'on' : ''} ${i === 6 ? 'now' : ''}" style="--c:${h.color}" data-a="habTog" data-id="${h.id}" data-d="${d}" aria-label="${d}"></button>`).join('')}</div></div>`).join('')}</section>` : '<section class="card"><p class="empty">Henüz alışkanlık yok. + ile başla.</p></section>';
  } else {
    const n = new Date(), f = new Date(n.getFullYear(), n.getMonth() + L.mon, 1), first = (f.getDay() + 6) % 7, dim = new Date(f.getFullYear(), f.getMonth() + 1, 0).getDate();
    const has = new Set(tasks.map(t => t.due));
    const cells = [...Array(first).fill(''), ...Array.from({ length: dim }, (_, i) => dstr(new Date(f.getFullYear(), f.getMonth(), i + 1)))];
    const day = tasks.filter(t => t.due === L.sel);
    body = `<div class="month"><button data-a="lmon" data-d="-1" aria-label="Önceki ay">${ic('back', 20)}</button><b>${f.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' })}</b><button data-a="lmon" data-d="1" aria-label="Sonraki ay">${ic('next', 20)}</button></div>
    <section class="card"><div class="cal">${['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'].map(d => `<b>${d}</b>`).join('')}${cells.map(d => d ? `<button class="${d === L.sel ? 'sel' : ''} ${d === t0 ? 'td' : ''}" data-a="lsel" data-d="${d}">${+d.slice(8)}${has.has(d) ? '<i></i>' : ''}</button>` : '<span></span>').join('')}</div></section>
    <div class="dh">${dlabel(L.sel)}</div><section class="card" style="padding:4px 16px">${day.length ? `<ul class="list">${day.map(t => taskRow(t)).join('')}</ul>` : '<p class="empty" style="padding:12px 0">Bu güne görev yok.</p>'}</section>`;
  }
  view.innerHTML = `${mhero(m)}${seg('ltab', [['tasks', 'Görevler'], ['habits', 'Alışkanlıklar'], ['cal', 'Takvim']], L.tab)}<div style="height:16px"></div>${body}${fab(L.tab === 'habits' ? 'habNew' : 'taskNew')}`;
  $('#ltab').onchange = () => { L.tab = $('#ltab').dataset.val; route(); };
};
A.lmon = b => { L.mon += +b.dataset.d; route(); };
A.lsel = b => { L.sel = b.dataset.d; route(); };
A.taskNew = b => sheet(`<h2 class="st">Yeni görev</h2><div class="field"><input id="ttx" placeholder="Ne yapılacak?" maxlength="120"></div>${dateField('tdt', 'Tarih', (b && b.dataset && b.dataset.q) ? today() : (L.tab === 'cal' ? L.sel : today()))}<button class="btn" style="width:100%" data-a="taskSave">Ekle</button>`);
A.taskSave = async () => {
  const text = $('#ttx').value.trim(); if (!text) { toast('Görev adı yaz'); return $('#ttx').focus(); }
  await DB.put('tasks', { id: DB.uid(), text, due: $('#tdt').dataset.val || '', done: false, created: Date.now() }); A.closeSheet(); route();
};
A.habNew = () => sheet(`<h2 class="st">Yeni alışkanlık</h2><div class="field"><input id="hnm" placeholder="Örn. 2 litre su" maxlength="40"></div><div class="field"><label>Renk</label>${chips('hcol', HCOL.map(c => [c, '●', c]), HCOL[0])}</div><button class="btn" style="width:100%" data-a="habSave">Ekle</button>`);
A.habSave = async () => {
  const name = $('#hnm').value.trim(); if (!name) { toast('Alışkanlık adı yaz'); return $('#hnm').focus(); }
  await DB.put('habits', { id: DB.uid(), name, color: $('#hcol').dataset.val, days: {}, created: Date.now() }); A.closeSheet(); route();
};
A.habTog = async b => { const h = await DB.get('habits', b.dataset.id), d = b.dataset.d; if (d > today()) return; if (h.days[d]) delete h.days[d]; else h.days[d] = 1; await DB.put('habits', h); route(); };
A.habOpen = async b => { const h = await DB.get('habits', b.dataset.id); sheet(`<h2 class="st">${esc(h.name)}</h2><p class="empty" style="margin-bottom:20px">${streak(h)} günlük seri · toplam ${Object.keys(h.days).length} gün</p><button class="btn danger" style="width:100%" data-a="habDel" data-id="${h.id}">Alışkanlığı sil</button>`); };
A.habDel = async b => { await DB.del('habits', b.dataset.id); A.closeSheet(); route(); };
