/* LIFE OS – Kasa (PBKDF2 + AES-GCM ile şifreli) */
const VT = { key: null, tab: 'pw', pin: '', stage: 'enter', first: '', fails: 0, until: 0, last: Date.now(), map: {}, cur: null };
const te = new TextEncoder(), td = new TextDecoder();
const b64 = u => btoa(String.fromCharCode(...new Uint8Array(u)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const vDerive = async (pin, salt) => {
  const k = await crypto.subtle.importKey('raw', te.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
};
const vEnc = async (o, key = VT.key) => { const iv = crypto.getRandomValues(new Uint8Array(12)); return { iv: b64(iv), d: b64(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te.encode(JSON.stringify(o)))) }; };
const vDec = async (r, key = VT.key) => JSON.parse(td.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(r.iv) }, key, unb64(r.d))));
const vLock = () => { VT.key = null; VT.pin = ''; VT.map = {}; VT.cur = null; };
const copyText = async t => {
  try { await navigator.clipboard.writeText(t); toast('Kopyalandı'); }
  catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); toast('Kopyalandı'); } catch (x) { toast('Kopyalanamadı'); } a.remove(); }
};
const pinDots = () => Array.from({ length: 6 }, (_, i) => `<i class="${i < VT.pin.length ? 'on' : ''}"></i>`).join('');
const pinHtml = (t, s) => `<div class="pinw"><div class="ico" style="--c:var(--red);width:64px;height:64px">${mi('vault', 34)}</div><h2>${t}</h2><p class="empty">${s}</p><div class="dots" id="pdots">${pinDots()}</div><div class="keys pk">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map(k => k === '' ? '<span></span>' : `<button class="key" data-a="pk" data-v="${k}">${k}</button>`).join('')}</div></div>`;

MV.vault = async m => {
  if (!(window.crypto && crypto.subtle)) { view.innerHTML = `${mhero(m)}<section class="card"><p class="empty">Bu cihazda şifreleme desteklenmiyor, bu yüzden Kasa kapalı. Güvenli bağlantı (https) veya güncel bir WebView gerekir.</p></section>`; return; }
  if (VT.key) return vaultMain(m);
  const cfg = await DB.get('kv', 'vaultcfg'); VT.pin = ''; VT.first = '';
  if (!cfg) { VT.stage = 'set'; view.innerHTML = `${mhero(m)}${pinHtml('PIN belirle', 'Kasa için 6 haneli bir PIN seç')}`; }
  else { VT.stage = 'enter'; view.innerHTML = `${mhero(m)}${pinHtml('Kasa kilitli', 'PIN’ini gir')}<p style="text-align:center;margin-top:18px"><a href="#/m/vault" data-a="vReset" style="color:var(--red);font-size:14px">PIN’ini mi unuttun? Kasayı sıfırla</a></p>`; }
};
const pinText = (h, s) => { $('.pinw h2').textContent = h; $('.pinw .empty').textContent = s; $('#pdots').innerHTML = pinDots(); };
A.pk = async b => {
  const k = b.dataset.v;
  if (k === '⌫') VT.pin = VT.pin.slice(0, -1); else if (VT.pin.length < 6) VT.pin += k;
  $('#pdots').innerHTML = pinDots();
  if (VT.pin.length < 6) return;
  const pin = VT.pin; VT.pin = '';
  if (VT.stage === 'set') { VT.first = pin; VT.stage = 'confirm'; return pinText('PIN’i doğrula', 'Aynı PIN’i tekrar gir'); }
  if (VT.stage === 'confirm') {
    if (pin !== VT.first) { VT.stage = 'set'; VT.first = ''; toast('PIN’ler eşleşmedi, tekrar dene'); return pinText('PIN belirle', 'Kasa için 6 haneli bir PIN seç'); }
    const salt = crypto.getRandomValues(new Uint8Array(16)), key = await vDerive(pin, salt);
    await DB.put('kv', { salt: b64(salt), check: await vEnc('LIFEOS', key) }, 'vaultcfg'); VT.key = key; VT.last = Date.now(); return route();
  }
  if (Date.now() < VT.until) { toast('Çok fazla deneme. Biraz bekle.'); return pinText('Kasa kilitli', 'PIN’ini gir'); }
  const cfg = await DB.get('kv', 'vaultcfg');
  try {
    const key = await vDerive(pin, unb64(cfg.salt));
    if (await vDec(cfg.check, key) !== 'LIFEOS') throw 0;
    VT.key = key; VT.fails = 0; VT.last = Date.now(); route();
  } catch (e) {
    VT.fails++;
    if (VT.fails >= 5) { VT.until = Date.now() + 30000; VT.fails = 0; toast('5 yanlış deneme: 30 sn bekle'); } else toast('Yanlış PIN');
    $('#pdots').innerHTML = pinDots();
  }
};
async function vaultMain(m) {
  const recs = await DB.all('vault'), items = [];
  for (const r of recs) { try { items.push({ ...r, o: await vDec(r) }); } catch (e) { /* okunamayan kayıt */ } }
  VT.map = Object.fromEntries(items.map(i => [i.id, i]));
  const list = items.filter(i => i.kind === VT.tab).sort((a, b) => a.o.t.localeCompare(b.o.t, 'tr'));
  view.innerHTML = `${mhero(m, '#/home', 'Kasa açık')}<div class="bar" style="margin:0 0 16px"><button class="btn sec w" data-a="vLockNow">Kilitle</button><button class="btn sec w" data-a="vPinChange">PIN değiştir</button></div>${seg('vtab', [['pw', 'Şifreler'], ['note', 'Notlar']], VT.tab)}<div style="height:16px"></div>
  ${list.length ? `<section class="card" style="padding:4px 16px">${list.map(i => `<button class="row" data-a="vOpen" data-id="${i.id}"><span class="dot" style="--c:${i.kind === 'pw' ? '#d98383' : '#a898d8'}">${esc((i.o.t[0] || '?').toUpperCase())}</span><span class="t"><b>${esc(i.o.t)}</b><small>${esc(i.kind === 'pw' ? (i.o.u || 'Kullanıcı adı yok') : (i.o.n || '').slice(0, 50))}</small></span>${ic('next', 18)}</button>`).join('')}</section>` : `<section class="card"><p class="empty">${VT.tab === 'pw' ? 'Henüz şifre yok.' : 'Henüz not yok.'} + ile ekle.</p></section>`}${fab('vNew', 'red')}`;
  $('#vtab').onchange = () => { VT.tab = $('#vtab').dataset.val; route(); };
  every(() => { if (VT.key && Date.now() - VT.last > 90000) { vLock(); A.closeSheet(); route(); } }, 5000);
}
const vForm = it => {
  const kind = it ? it.kind : VT.tab, pw = kind === 'pw', o = it ? it.o : {};
  sheet(`<h2 class="st">${it ? 'Düzenle' : pw ? 'Yeni şifre' : 'Yeni not'}</h2>
  <div class="field"><label>Başlık</label><input id="vt" maxlength="60" value="${esc(o.t || '')}"></div>
  ${pw ? `<div class="field"><label>Kullanıcı adı / e-posta</label><input id="vu" maxlength="80" autocomplete="off" value="${esc(o.u || '')}"></div>
  <div class="field"><label>Şifre</label><div class="bar" style="margin:0"><input id="vp" autocomplete="off" value="${esc(o.p || '')}"><button class="btn sec" data-a="vGen">Oluştur</button></div></div>` : ''}
  <div class="field"><label>${pw ? 'Not' : 'Metin'}</label><textarea id="vn" style="min-height:${pw ? 70 : 150}px">${esc(o.n || '')}</textarea></div>
  <button class="btn" style="width:100%" data-a="vSave" data-id="${it ? it.id : ''}" data-k="${kind}">Kaydet</button>`);
};
A.vNew = () => vForm();
A.vEdit = () => vForm(VT.cur);
A.vGen = () => {
  const cs = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%*?';
  const i = $('#vp'); i.value = Array.from(crypto.getRandomValues(new Uint32Array(16)), x => cs[x % cs.length]).join('');
};
A.vSave = async b => {
  const kind = b.dataset.k, t = $('#vt').value.trim(); if (!t) return toast('Başlık yaz');
  const o = { t, n: $('#vn').value.trim() }; if (kind === 'pw') { o.u = $('#vu').value.trim(); o.p = $('#vp').value; }
  const id = b.dataset.id || DB.uid(), old = b.dataset.id ? await DB.get('vault', id) : null;
  await DB.put('vault', { id, kind, created: old ? old.created : Date.now(), ...await vEnc(o) });
  A.closeSheet(); toast('Kasaya kaydedildi'); route();
};
A.vOpen = b => {
  const it = VT.map[b.dataset.id]; if (!it) return; VT.cur = it; const o = it.o;
  sheet(`<h2 class="st">${esc(o.t)}</h2>
  ${it.kind === 'pw' ? `<div class="field"><label>Kullanıcı adı</label><div class="bar" style="margin:0"><input readonly value="${esc(o.u || '')}"><button class="btn sec" data-a="vCopy" data-f="u">Kopyala</button></div></div>
  <div class="field"><label>Şifre</label><div class="bar" style="margin:0"><input id="vshow" type="password" readonly value="${esc(o.p || '')}"><button class="btn sec" data-a="vEye">Göster</button><button class="btn sec" data-a="vCopy" data-f="p">Kopyala</button></div></div>` : ''}
  ${o.n ? `<div class="field"><label>${it.kind === 'pw' ? 'Not' : 'Metin'}</label><p style="white-space:pre-wrap;word-break:break-word">${esc(o.n)}</p></div>` : ''}
  <div class="bar"><button class="btn w" data-a="vEdit">Düzenle</button><button class="btn danger" data-a="vDel">Sil</button></div>`);
};
A.vEye = b => { const i = $('#vshow'); i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'Göster' : 'Gizle'; };
A.vCopy = b => copyText((VT.cur.o[b.dataset.f]) || '');
A.vDel = async () => { if (!confirm('Bu kayıt silinsin mi?')) return; await DB.del('vault', VT.cur.id); A.closeSheet(); route(); };
A.vLockNow = () => { vLock(); route(); };
A.vPinChange = () => sheet(`<h2 class="st">PIN değiştir</h2><div class="field"><label>Yeni PIN (6 hane)</label><input id="np1" type="password" inputmode="numeric" maxlength="6"></div><div class="field"><label>Yeni PIN (tekrar)</label><input id="np2" type="password" inputmode="numeric" maxlength="6"></div><button class="btn" style="width:100%" data-a="vPinSave">Değiştir</button>`);
A.vPinSave = async () => {
  const a = $('#np1').value, b = $('#np2').value;
  if (!/^\d{6}$/.test(a)) return toast('PIN 6 rakam olmalı'); if (a !== b) return toast('PIN’ler eşleşmiyor');
  const salt = crypto.getRandomValues(new Uint8Array(16)), key = await vDerive(a, salt), out = [];
  for (const r of await DB.all('vault')) { try { out.push({ ...r, ...await vEnc(await vDec(r), key) }); } catch (e) { /* atla */ } }
  for (const r of out) await DB.put('vault', r);
  await DB.put('kv', { salt: b64(salt), check: await vEnc('LIFEOS', key) }, 'vaultcfg'); VT.key = key; A.closeSheet(); toast('PIN değişti'); route();
};
A.vReset = async () => {
  if (!confirm('Kasadaki TÜM şifreler ve notlar kalıcı olarak silinecek. Devam edilsin mi?')) return;
  await DB.clear('vault'); await DB.del('kv', 'vaultcfg'); vLock(); toast('Kasa sıfırlandı'); route();
};
document.addEventListener('click', () => { VT.last = Date.now(); }, true);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { if (VT.key) { vLock(); A.closeSheet(); } }
  else if (location.hash.startsWith('#/m/vault')) route();
});
