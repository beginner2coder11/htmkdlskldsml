/* LIFE OS – Kasa (zarf şifreleme: PIN → KEK, KEK → rastgele DEK, DEK → veri) */
const VT = { key: null, tab: 'pw', pin: '', stage: 'enter', first: '', fails: 0, until: 0, last: Date.now(), map: {}, cur: null, hold: false };
const te = new TextEncoder(), td = new TextDecoder();
const KDF_NEW = 600000, KDF_OLD = 150000;
const b64 = u => { const a = new Uint8Array(u); let s = ''; for (let i = 0; i < a.length; i += 8192) s += String.fromCharCode(...a.subarray(i, i + 8192)); return btoa(s); };
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const vKek = async (pin, salt, iter = KDF_OLD) => {
  const k = await crypto.subtle.importKey('raw', te.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
};
const vEnc = async (o, key = VT.key) => { const iv = crypto.getRandomValues(new Uint8Array(12)); return { iv: b64(iv), d: b64(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te.encode(JSON.stringify(o)))) }; };
const vDec = async (r, key = VT.key) => JSON.parse(td.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(r.iv) }, key, unb64(r.d))));
const vNewDek = () => crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
const vWrap = async (dek, kek) => vEnc(b64(await crypto.subtle.exportKey('raw', dek)), kek);
const vUnwrap = async (w, kek) => crypto.subtle.importKey('raw', unb64(await vDec(w, kek)), 'AES-GCM', true, ['encrypt', 'decrypt']);
async function vCreate(pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16)), kek = await vKek(pin, salt, KDF_NEW), dek = await vNewDek();
  await DB.put('kv', { salt: b64(salt), iter: KDF_NEW, wrapped: await vWrap(dek, kek), check: await vEnc('LIFEOS', dek) }, 'vaultcfg'); return dek;
}
async function vOpen(pin, cfg) {
  const kek = await vKek(pin, unb64(cfg.salt), cfg.iter || KDF_OLD);
  if (cfg.wrapped) { const dek = await vUnwrap(cfg.wrapped, kek); if (await vDec(cfg.check, dek) !== 'LIFEOS') throw new Error('pin'); return dek; }
  if (await vDec(cfg.check, kek) !== 'LIFEOS') throw new Error('pin');   // eski (zarfsız) kasa: zarfa taşı
  const dek = await vNewDek(), salt = crypto.getRandomValues(new Uint8Array(16)), nk = await vKek(pin, salt, KDF_NEW), ops = [];
  for (const r of await DB.all('vault')) { try { ops.push(['vault', { ...r, ...await vEnc(await vDec(r, kek), dek) }]); } catch (e) { /* okunamayanı atla */ } }
  ops.push(['kv', { salt: b64(salt), iter: KDF_NEW, wrapped: await vWrap(dek, nk), check: await vEnc('LIFEOS', dek) }, 'vaultcfg']);
  await DB.putMany(ops); return dek;
}
const vLock = () => { VT.key = null; VT.pin = ''; VT.map = {}; VT.cur = null; VT.hold = false; };
const copyText = async (t, clear) => {
  let ok = true;
  try { await navigator.clipboard.writeText(t); } catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { ok = document.execCommand('copy'); } catch (x) { ok = false; } a.remove(); }
  toast(ok ? (clear ? 'Kopyalandı · 30 sn sonra silinir' : 'Kopyalandı') : 'Kopyalanamadı');
  if (ok && clear) setTimeout(() => { try { navigator.clipboard.writeText(''); } catch (e) { /* yoksay */ } }, 30000);
};
const pinDots = () => Array.from({ length: 6 }, (_, i) => `<i class="${i < VT.pin.length ? 'on' : ''}"></i>`).join('');
const pinHtml = (t, s) => `<div class="pinw"><div class="ico" style="--c:var(--red);width:64px;height:64px">${mi('vault', 54)}</div><h2>${t}</h2><p class="empty">${s}</p><div class="dots" id="pdots">${pinDots()}</div><div class="keys pk">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map(k => k === '' ? '<span></span>' : `<button class="key" data-a="pk" data-v="${k}">${k}</button>`).join('')}</div></div>`;
async function vGate(m) {
  if (!(window.crypto && crypto.subtle)) { view.innerHTML = `${mhero(m)}<section class="card"><p class="empty">Bu cihazda şifreleme desteklenmiyor, bu yüzden bu bölüm kapalı. Güncel bir WebView gerekir.</p></section>`; return false; }
  if (VT.key) return true;
  const cfg = await DB.get('kv', 'vaultcfg'); VT.pin = ''; VT.first = ''; VT.stage = cfg ? 'enter' : 'set';
  view.innerHTML = `${mhero(m)}${cfg ? pinHtml('Kilitli', 'PIN’ini gir') + '<p style="text-align:center;margin-top:18px"><a href="#/m/vault" data-a="vReset" style="color:var(--red);font-size:14px">PIN’ini mi unuttun? Sıfırla</a></p>' : pinHtml('PIN belirle', 'Kasa ve Media için 6 haneli bir PIN seç')}`;
  return false;
}
MV.vault = async m => { if (await vGate(m)) vaultMain(m); };
const pinText = (h, s) => { $('.pinw h2').textContent = h; $('.pinw .empty').textContent = s; $('#pdots').innerHTML = pinDots(); };
A.pk = async b => {
  const k = b.dataset.v;
  if (k === '⌫') VT.pin = VT.pin.slice(0, -1); else if (VT.pin.length < 6) VT.pin += k;
  $('#pdots').innerHTML = pinDots();
  if (VT.pin.length < 6) return;
  const pin = VT.pin; VT.pin = '';
  if (VT.stage === 'set') { VT.first = pin; VT.stage = 'confirm'; return pinText('PIN’i doğrula', 'Aynı PIN’i tekrar gir'); }
  if (VT.stage === 'confirm') {
    if (pin !== VT.first) { VT.stage = 'set'; VT.first = ''; toast('PIN’ler eşleşmedi, tekrar dene'); return pinText('PIN belirle', 'Kasa ve Media için 6 haneli bir PIN seç'); }
    VT.key = await vCreate(pin); VT.last = Date.now(); return route();
  }
  if (Date.now() < VT.until) { toast('Çok fazla deneme. Biraz bekle.'); return pinText('Kilitli', 'PIN’ini gir'); }
  const cfg = await DB.get('kv', 'vaultcfg');
  try { VT.key = await vOpen(pin, cfg); VT.fails = 0; VT.last = Date.now(); route(); }
  catch (e) {
    VT.fails++;
    if (VT.fails >= 5) { VT.until = Date.now() + 30000; VT.fails = 0; toast('5 yanlış deneme: 30 sn bekle'); } else toast('Yanlış PIN');
    $('#pdots').innerHTML = pinDots();
  }
};
async function vaultMain(m) {
  const recs = await DB.all('vault'), items = [];
  for (const r of recs) { try { items.push({ ...r, o: await vDec(r) }); } catch (e) { /* okunamayan kayıt */ } }
  VT.map = Object.fromEntries(items.map(i => [i.id, i]));
  const list = items.filter(i => i.kind === VT.tab).sort((a, b) => a.o.t.localeCompare(b.o.t, 'tr'));
  view.innerHTML = `${mhero(m, '#/home', 'Kasa açık')}<div class="bar" style="margin:0 0 16px"><button class="btn sec w" data-a="vLockNow">Kilitle</button><button class="btn sec w" data-a="vPinChange">PIN değiştir</button></div>${seg('vtab', [['pw', 'Şifreler'], ['note', 'Notlar']], VT.tab)}<div style="height:16px"></div>
  ${list.length ? `<section class="card" style="padding:4px 16px">${list.map(i => `<button class="row" data-a="vOpen" data-id="${i.id}"><span class="dot" style="--c:${i.kind === 'pw' ? '#d98383' : '#a898d8'}">${esc((i.o.t[0] || '?').toUpperCase())}</span><span class="t"><b>${esc(i.o.t)}</b><small>${esc(i.kind === 'pw' ? (i.o.u || 'Kullanıcı adı yok') : (i.o.n || '').slice(0, 50))}</small></span>${ic('next', 18)}</button>`).join('')}</section>` : `<section class="card"><p class="empty">${VT.tab === 'pw' ? 'Henüz şifre yok.' : 'Henüz not yok.'} + ile ekle.</p></section>`}${fab('vNew', 'red')}`;
  $('#vtab').onchange = () => { VT.tab = $('#vtab').dataset.val; route(); };
  every(() => { if (VT.key && !VT.hold && Date.now() - VT.last > 90000) { vLock(); A.closeSheet(); route(); } }, 5000);
}
const vForm = it => {
  const kind = it ? it.kind : VT.tab, pw = kind === 'pw', o = it ? it.o : {};
  sheet(`<h2 class="st">${it ? 'Düzenle' : pw ? 'Yeni şifre' : 'Yeni not'}</h2>
  <div class="field"><label>Başlık</label><input id="vt" maxlength="60" value="${esc(o.t || '')}"></div>
  ${pw ? `<div class="field"><label>Kullanıcı adı / e-posta</label><input id="vu" maxlength="80" autocomplete="off" value="${esc(o.u || '')}"></div>
  <div class="field"><label>Şifre</label><div class="bar" style="margin:0"><input id="vp" autocomplete="off" value="${esc(o.p || '')}"><button class="btn sec" data-a="vGen">Oluştur</button></div></div>` : ''}
  <div class="field"><label>${pw ? 'Not' : 'Metin'}</label><textarea id="vn" style="min-height:${pw ? 70 : 150}px">${esc(o.n || '')}</textarea></div>
  <button class="btn" style="width:100%" data-a="vSave" data-id="${it ? it.id : ''}" data-k="${kind}">Kaydet</button>`);
};
A.vNew = () => vForm();
A.vEdit = () => vForm(VT.cur);
A.vGen = () => {
  const cs = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%*?';
  $('#vp').value = Array.from(crypto.getRandomValues(new Uint32Array(16)), x => cs[x % cs.length]).join('');
};
A.vSave = async b => {
  const kind = b.dataset.k, t = $('#vt').value.trim(); if (!t) return toast('Başlık yaz');
  const o = { t, n: $('#vn').value.trim() }; if (kind === 'pw') { o.u = $('#vu').value.trim(); o.p = $('#vp').value; }
  const id = b.dataset.id || DB.uid(), old = b.dataset.id ? await DB.get('vault', id) : null;
  await DB.put('vault', { id, kind, created: old ? old.created : Date.now(), ...await vEnc(o) });
  A.closeSheet(); toast('Kasaya kaydedildi'); route();
};
A.vOpen = b => {
  const it = VT.map[b.dataset.id]; if (!it) return; VT.cur = it; const o = it.o;
  sheet(`<h2 class="st">${esc(o.t)}</h2>
  ${it.kind === 'pw' ? `<div class="field"><label>Kullanıcı adı</label><div class="bar" style="margin:0"><input readonly value="${esc(o.u || '')}"><button class="btn sec" data-a="vCopy" data-f="u">Kopyala</button></div></div>
  <div class="field"><label>Şifre</label><div class="bar" style="margin:0"><input id="vshow" type="password" readonly value="${esc(o.p || '')}"><button class="btn sec" data-a="vEye">Göster</button><button class="btn sec" data-a="vCopy" data-f="p">Kopyala</button></div></div>` : ''}
  ${o.n ? `<div class="field"><label>${it.kind === 'pw' ? 'Not' : 'Metin'}</label><p style="white-space:pre-wrap;word-break:break-word">${esc(o.n)}</p></div>` : ''}
  <div class="bar"><button class="btn w" data-a="vEdit">Düzenle</button><button class="btn danger" data-a="vDel">Sil</button></div>`);
};
A.vEye = b => { const i = $('#vshow'); i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'Göster' : 'Gizle'; };
A.vCopy = b => copyText((VT.cur.o[b.dataset.f]) || '', b.dataset.f === 'p');
A.vDel = async () => { if (!confirm('Bu kayıt silinsin mi?')) return; await DB.del('vault', VT.cur.id); A.closeSheet(); route(); };
A.vLockNow = () => { vLock(); A.mClose && A.mClose(); route(); };
A.vPinChange = () => sheet(`<h2 class="st">PIN değiştir</h2><p class="empty" style="margin-bottom:12px">Kasa ve Media aynı PIN’i kullanır. Değişiklik anında yapılır, dosyalar yeniden şifrelenmez.</p><div class="field"><label>Yeni PIN (6 hane)</label><input id="np1" type="password" inputmode="numeric" maxlength="6"></div><div class="field"><label>Yeni PIN (tekrar)</label><input id="np2" type="password" inputmode="numeric" maxlength="6"></div><button class="btn" style="width:100%" data-a="vPinSave">Değiştir</button>`);
A.vPinSave = async () => {
  const a = $('#np1').value, b = $('#np2').value;
  if (!/^\d{6}$/.test(a)) return toast('PIN 6 rakam olmalı'); if (a !== b) return toast('PIN’ler eşleşmiyor');
  const cfg = await DB.get('kv', 'vaultcfg'), salt = crypto.getRandomValues(new Uint8Array(16)), nk = await vKek(a, salt, KDF_NEW);
  await DB.put('kv', { salt: b64(salt), iter: KDF_NEW, wrapped: await vWrap(VT.key, nk), check: cfg.check }, 'vaultcfg');
  A.closeSheet(); toast('PIN değişti');
};
A.vReset = async () => {
  if (!confirm('Kasa ve Media’daki TÜM şifreler, notlar, fotoğraf ve videolar kalıcı olarak silinecek. Devam edilsin mi?')) return;
  await DB.clear('vault'); await DB.clear('media'); await DB.clear('mediachunks'); await DB.del('kv', 'vaultcfg'); vLock(); toast('Sıfırlandı'); route();
};
document.addEventListener('click', () => { VT.last = Date.now(); }, true);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { if (VT.key) { vLock(); A.closeSheet(); } if (A.mClose) A.mClose(); if (A.camClose) A.camClose(); }
  else if (/^#\/m\/(vault|media)/.test(location.hash)) route();
});
