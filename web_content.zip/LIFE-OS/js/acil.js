/* LIFE OS – Acil durum araçları (SOS, düdük, numaralar, deprem) */
const ACIL = {};
const aHead = t => `<a class="back" href="#/m/toolbox" aria-label="Geri">${ic('back', 22)}</a><h1 class="page">${t}</h1>`;

/* ---- SOS: ekran flaşı + (destekleniyorsa) fener ---- */
const SOS = { run: false, track: null, lock: null };
const SOSP = [1, 1, 1, 3, 3, 3, 1, 1, 1];
async function sosTorch(on) {
  try { if (SOS.track) await SOS.track.applyConstraints({ advanced: [{ torch: on }] }); } catch (e) { /* fener yok */ }
}
async function sosStart() {
  if (SOS.run) return; SOS.run = true;
  const o = document.createElement('div'); o.id = 'sosflash'; o.dataset.a = 'sosStop'; o.innerHTML = '<span>Durdurmak için dokun</span>'; document.body.appendChild(o);
  try { if (navigator.wakeLock) SOS.lock = await navigator.wakeLock.request('screen'); } catch (e) { /* yoksay */ }
  try {
    const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }), t = s.getVideoTracks()[0];
    if (t.getCapabilities && t.getCapabilities().torch) SOS.track = t; else s.getTracks().forEach(x => x.stop());
  } catch (e) { /* kamera izni yok */ }
  const U = 220, set = on => { const f = $('#sosflash'); if (f) f.style.background = on ? '#fff' : '#000'; sosTorch(on); };
  while (SOS.run) {
    for (const p of SOSP) { if (!SOS.run) break; set(true); await sleep(p * U); set(false); await sleep(U); }
    if (SOS.run) await sleep(U * 6);
  }
}
function sosStop() {
  SOS.run = false; const f = $('#sosflash'); if (f) f.remove();
  if (SOS.track) { sosTorch(false); SOS.track.stop(); SOS.track = null; }
  if (SOS.lock) { try { SOS.lock.release(); } catch (e) { /* yoksay */ } SOS.lock = null; }
}
A.sosGo = () => { vibe(30); sosStart(); };
A.sosStop = () => sosStop();
ACIL.sos = () => {
  view.innerHTML = `${aHead('SOS')}<section class="card"><p>Ekran, SOS işaretini (···−−−···) ışıkla verir. Fener desteklenen telefonlarda fener de yanıp söner. Ekran parlaklığını artırmayı unutma.</p></section>
  <button class="sosbtn" style="background:var(--red)" data-a="sosGo">SOS başlat</button><p class="label" style="margin:0 2px">Bu araç bir yardımcıdır; gerçek acil durumda önce 112’yi ara.</p>`;
  onLeave(sosStop);
};

/* ---- Düdük / siren ---- */
const WH = { ctx: null, o: null, g: null, iv: 0, m: '', t0: 0 };
function whStop() {
  if (WH.iv) { clearInterval(WH.iv); WH.iv = 0; } if (WH.o) { try { WH.o.stop(); } catch (e) { /* yoksay */ } WH.o = null; }
  document.querySelectorAll('.whb').forEach(b => b.classList.remove('on'));
}
A.whGo = b => {
  const m = b.dataset.m; if (WH.m === m && WH.o) { whStop(); WH.m = ''; return; } whStop(); WH.m = m; vibe(30);
  try {
    WH.ctx = WH.ctx || new (window.AudioContext || window.webkitAudioContext)(); if (WH.ctx.state === 'suspended') WH.ctx.resume();
    const o = WH.ctx.createOscillator(), g = WH.ctx.createGain(); o.type = m === 'siren' ? 'sawtooth' : 'square'; o.frequency.value = 3100; g.gain.value = 0; o.connect(g); g.connect(WH.ctx.destination); o.start(); WH.o = o; WH.g = g; WH.t0 = Date.now();
    WH.iv = setInterval(() => {
      const t = (Date.now() - WH.t0) / 1000; let on = 1;
      if (m === 'three') { const c = t % 3.6; on = (c < .4 || (c > .6 && c < 1) || (c > 1.2 && c < 1.6)) ? 1 : 0; }
      if (m === 'siren') WH.o.frequency.value = 1000 + 500 * Math.sin(t * 3.2);
      WH.g.gain.value = on;
    }, 50);
    b.classList.add('on');
  } catch (e) { toast('Ses başlatılamadı'); }
};
ACIL.whistle = () => {
  view.innerHTML = `${aHead('Düdük')}<section class="card"><p>Telefonun sesini sonuna kadar aç. Yüksek frekanslı düdük sesi çıkar; enkaz altında ya da kalabalıkta dikkat çekmek için kullanılır.</p></section>
  <button class="sosbtn whb" style="background:var(--orange)" data-a="whGo" data-m="three">3’lü düdük</button>
  <button class="sosbtn whb" style="background:#e3e6ea" data-a="whGo" data-m="cont">Sürekli düdük</button>
  <button class="sosbtn whb" style="background:var(--purple)" data-a="whGo" data-m="siren">Siren</button><p class="label" style="margin:0 2px">Durdurmak için aynı düğmeye tekrar bas.</p>`;
  onLeave(() => { whStop(); WH.m = ''; });
};

/* ---- Acil numaralar ---- */
const TELS = [['112', 'Acil Çağrı', 'Ambulans, polis, itfaiye'], ['155', 'Polis İmdat', ''], ['156', 'Jandarma İmdat', ''], ['110', 'İtfaiye', ''], ['122', 'AFAD', 'Afet ve acil durum'], ['177', 'Orman Yangını İhbar', ''], ['114', 'Zehir Danışma', ''], ['183', 'Sosyal Destek Hattı', 'Kadın, çocuk, yaşlı, engelli']];
const telRow = ([n, t, s]) => `<div class="callrow"><span class="dot" style="--c:#74b88f;font-size:13px">${esc(n.length > 4 ? '☎' : n)}</span><span class="t"><b>${esc(t)}</b><small>${esc(s || n)}</small></span><button class="btn sec" data-a="telCopy" data-n="${esc(n)}" style="padding:10px 14px;font-size:14px">Kopyala</button><a class="btn" href="tel:${esc(n.replace(/\s/g, ''))}">Ara</a></div>`;
A.telCopy = b => copyText(b.dataset.n);
ACIL.tel = async () => {
  const cs = (await DB.get('kv', 'emcontacts')) || [];
  view.innerHTML = `${aHead('Acil numaralar')}<section class="card" style="padding:4px 16px">${TELS.map(telRow).join('')}</section>
  <div class="sec"><h2>Acil kişilerim</h2></div><section class="card" style="padding:4px 16px">${cs.length ? cs.map(c => `<div class="callrow"><span class="dot" style="--c:#7aa7e0">${esc((c.n[0] || '?').toUpperCase())}</span><span class="t"><b>${esc(c.n)}</b><small>${esc(c.t)}</small></span><button class="x" data-a="emDel" data-id="${c.id}" aria-label="Sil">${ic('x', 18)}</button><a class="btn" href="tel:${esc(c.t.replace(/\s/g, ''))}">Ara</a></div>`).join('') : '<p class="empty" style="padding:12px 0">Henüz kişi eklemedin.</p>'}</section>
  <button class="btn sec" style="width:100%" data-a="emNew">+ Acil kişi ekle</button><p class="label" style="margin:14px 2px">“Ara” düğmesi telefon uygulamasını açar. Çalışmazsa “Kopyala”yı kullan. Numaraları resmî kaynaklardan ara sıra kontrol et.</p>`;
};
A.emNew = () => sheet(`<h2 class="st">Acil kişi ekle</h2><div class="field"><label>Ad</label><input id="emn" maxlength="40"></div><div class="field"><label>Telefon</label><input id="emt" inputmode="tel" maxlength="20"></div><button class="btn" style="width:100%" data-a="emSave">Kaydet</button>`);
A.emSave = async () => {
  const n = $('#emn').value.trim(), t = $('#emt').value.trim(); if (!n || !/^[+\d][\d\s]{2,}$/.test(t)) return toast('Ad ve geçerli bir telefon gir');
  const cs = (await DB.get('kv', 'emcontacts')) || []; cs.push({ id: DB.uid(), n, t }); await DB.put('kv', cs, 'emcontacts'); A.closeSheet(); route();
};
A.emDel = async b => { const cs = ((await DB.get('kv', 'emcontacts')) || []).filter(c => c.id !== b.dataset.id); await DB.put('kv', cs, 'emcontacts'); route(); };

/* ---- Deprem rehberi ---- */
const KIT = ['Su (kişi başı en az 3 günlük)', 'Dayanıklı yiyecek / konserve', 'İlk yardım çantası', 'Fener ve yedek pil', 'Düdük', 'Powerbank', 'Pilli / şarjlı radyo', 'Battaniye', 'Kimlik ve önemli belge fotokopileri', 'Nakit para', 'Kişisel ilaçlar', 'Yedek kıyafet ve sağlam ayakkabı', 'Hijyen malzemeleri', 'Acil kişilerin numaraları (kağıda yazılı)'];
A.kitTog = async b => { const k = new Set((await DB.get('kv', 'kit')) || []), i = +b.dataset.i; k.has(i) ? k.delete(i) : k.add(i); await DB.put('kv', [...k], 'kit'); route(); };
A.areaSave = async () => { await DB.put('kv', { area: $('#qa').value.trim() }, 'quakecfg'); toast('Kaydedildi'); };
A.locGo = () => {
  if (!navigator.geolocation) return toast('Konum desteklenmiyor');
  toast('Konum alınıyor…');
  navigator.geolocation.getCurrentPosition(p => {
    const la = p.coords.latitude.toFixed(5), lo = p.coords.longitude.toFixed(5), txt = `Buradayım: ${la}, ${lo} https://maps.google.com/?q=${la},${lo}`;
    $('#locout').innerHTML = `<p style="word-break:break-all;margin-bottom:12px">${esc(txt)}</p><div class="bar" style="margin:0"><button class="btn w" data-a="locCopy" data-t="${esc(txt)}">Kopyala</button><a class="btn sec w" style="text-align:center;text-decoration:none" href="sms:?body=${encodeURIComponent(txt)}">SMS</a></div>`;
  }, () => toast('Konum alınamadı. Konum izni verilmemiş olabilir.'), { enableHighAccuracy: true, timeout: 15000 });
};
A.locCopy = b => copyText(b.dataset.t);
ACIL.quake = async () => {
  const kit = new Set((await DB.get('kv', 'kit')) || []), area = ((await DB.get('kv', 'quakecfg')) || {}).area || '';
  view.innerHTML = `${aHead('Deprem rehberi')}
  <section class="card"><h2 style="font-size:19px;margin-bottom:10px">Deprem anında</h2><ul class="list feat" style="--c:var(--purple)"><li>${ic('ring', 20)}<span class="t"><b>ÇÖK – KAPAN – TUTUN</b></span></li><li>${ic('ring', 20)}<span class="t">Sağlam bir masanın veya sıranın yanına çök, başını ve boynunu koru.</span></li><li>${ic('ring', 20)}<span class="t">Pencere, cam ve devrilebilecek eşyalardan uzak dur. Asansör kullanma.</span></li><li>${ic('ring', 20)}<span class="t">Dışarıdaysan açık alana geç; bina, direk ve kablolardan uzak dur.</span></li><li>${ic('ring', 20)}<span class="t">Araçtaysan güvenli bir yerde durup bekle.</span></li></ul></section>
  <section class="card"><h2 style="font-size:19px;margin-bottom:10px">Sarsıntıdan sonra</h2><ul class="list feat" style="--c:var(--orange)"><li>${ic('ring', 20)}<span class="t">Gaz kokusu varsa vanayı kapat; kıvılcım çıkaracak şey kullanma.</span></li><li>${ic('ring', 20)}<span class="t">Sağlam ayakkabı giy, hasarlı binaya girme, artçılara hazır ol.</span></li><li>${ic('ring', 20)}<span class="t">Toplanma alanına git. Hatları meşgul etmemek için arama yerine SMS tercih et.</span></li></ul></section>
  <div class="sec"><h2>Afet çantası</h2><small>${kit.size}/${KIT.length}</small></div><section class="card" style="padding:4px 16px">${KIT.map((k, i) => `<button class="chk2 ${kit.has(i) ? 'on' : ''}" data-a="kitTog" data-i="${i}"><i>${kit.has(i) ? '✓' : ''}</i><span>${esc(k)}</span></button>`).join('')}</section>
  <section class="card"><div class="field" style="margin-bottom:12px"><label>Toplanma alanım</label><input id="qa" maxlength="80" placeholder="Örn. Mahalle parkı, okul bahçesi" value="${esc(area)}"></div><button class="btn sec" style="width:100%" data-a="areaSave">Kaydet</button></section>
  <section class="card"><h2 style="font-size:17px;margin-bottom:10px">Konumumu paylaş</h2><div id="locout"><button class="btn" style="width:100%" data-a="locGo">Konumumu bul</button></div></section>
  <p class="label" style="margin:0 2px">Bu içerik genel bilgilendirmedir. Resmî rehber ve uyarılar için AFAD’ın kaynaklarına bak.</p>`;
};

/* ---- Son depremler (AFAD açık servisi, internet gerekir) ---- */
const pdt = s => { s = String(s || ''); return new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : s.replace(' ', 'T') + 'Z'); };
ACIL.quakes = async () => {
  view.innerHTML = `${aHead('Son depremler')}<section class="card"><p class="empty">Yükleniyor…</p></section>`;
  const st = new Date(Date.now() - 48 * 3600e3).toISOString().slice(0, 19), en = new Date(Date.now() + 3600e3).toISOString().slice(0, 19);
  try {
    const r = await fetch(`https://deprem.afad.gov.tr/apiv2/event/filter?start=${st}&end=${en}&orderby=timedesc&limit=40`);
    if (!r.ok) throw new Error('http ' + r.status);
    const j = await r.json(); if (!Array.isArray(j)) throw new Error('biçim');
    const rows = j.map(e => ({ t: pdt(e.eventDate || e.date), m: parseFloat(e.magnitude), d: parseFloat(e.depth), p: e.location || [e.province, e.district].filter(Boolean).join(' / ') }));
    const col = m => m >= 5 ? '#d98383' : m >= 4 ? '#d9ad66' : '#74b88f';
    if (!$('.back')) return;
    view.innerHTML = `${aHead('Son depremler')}<section class="card" style="padding:4px 16px">${rows.length ? rows.map(x => `<div class="row" style="cursor:default"><span class="dot" style="--c:${col(x.m)}">${isNaN(x.m) ? '?' : x.m.toFixed(1)}</span><span class="t"><b>${esc(x.p || 'Konum yok')}</b><small>${isNaN(x.t) ? '' : x.t.toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}${isNaN(x.d) ? '' : ' · ' + x.d.toFixed(0) + ' km derinlik'}</small></span></div>`).join('') : '<p class="empty" style="padding:12px 0">Son 48 saatte kayıt yok.</p>'}</section><p class="label" style="margin:0 2px">Kaynak: AFAD. Resmî duyuru yerine geçmez.</p>`;
  } catch (e) {
    if ($('.back')) view.innerHTML = `${aHead('Son depremler')}<section class="card"><p class="empty">Deprem listesi alınamadı. İnternet bağlantını ve APK’nın internet iznini kontrol et.</p></section>`;
  }
};
