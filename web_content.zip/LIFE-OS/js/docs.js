/* LIFE OS – Dökümanlar (fotoğraf ve PDF arşivi) */
const D = { f: 'all' }, DV = { id: '', url: '' };
let URLS = [];
const objUrl = b => { const u = URL.createObjectURL(b); URLS.push(u); return u; };
const getFolders = async () => (await DB.get('kv', 'folders')) || [];
const mkThumb = f => new Promise(res => {
  if (!f.type.startsWith('image/')) return res(null);
  const u = URL.createObjectURL(f), i = new Image();
  i.onload = () => {
    const k = Math.min(1, 360 / Math.max(i.width, i.height)), c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(i.width * k)); c.height = Math.max(1, Math.round(i.height * k));
    c.getContext('2d').drawImage(i, 0, 0, c.width, c.height);
    c.toBlob(b => { URL.revokeObjectURL(u); res(b); }, 'image/jpeg', .75);
  };
  i.onerror = () => { URL.revokeObjectURL(u); res(null); };
  i.src = u;
});
MV.docs = async m => {
  URLS.forEach(u => URL.revokeObjectURL(u)); URLS = [];
  const [all, fl] = await Promise.all([DB.all('docs'), getFolders()]);
  const list = all.filter(d => D.f === 'all' || (D.f === 'fav' ? d.fav : d.folder === D.f)).sort((a, b) => b.created - a.created);
  const opts = [['all', 'Tümü'], ['fav', '★ Favoriler'], ['', 'Genel'], ...fl.map(f => [f, f])];
  view.innerHTML = `${mhero(m, '#/home', all.length + ' dosya')}
  <div class="bar" style="margin:0 0 16px"><button class="btn w" data-a="docCam">Fotoğraf çek</button><button class="btn sec w" data-a="docPick">Dosya ekle</button></div>
  <input type="file" id="dcam" accept="image/*" capture="environment" hidden><input type="file" id="dfile" accept="image/*,application/pdf" multiple hidden>
  <div style="display:flex;gap:8px;align-items:flex-start;margin-bottom:${fl.includes(D.f) ? 8 : 16}px"><div style="flex:1">${chips('dfold', opts, D.f)}</div><button class="btn sec" data-a="folderNew" style="padding:9px 14px;flex:none">+ Klasör</button></div>
  ${fl.includes(D.f) ? '<p style="margin-bottom:16px"><a href="#/m/docs" data-a="folderDel" style="color:var(--red);font-size:14px">Bu klasörü sil (dosyalar Genel\'e taşınır)</a></p>' : ''}
  ${list.length ? `<div class="phg">${list.map(d => `<button class="ph" data-a="docOpen" data-id="${d.id}">${d.type.startsWith('image/') ? `<img loading="lazy" alt="" src="${objUrl(d.thumb || d.blob)}">` : `<div class="pdf">${mi('docs', 34)}<span>${esc(d.name)}</span></div>`}${d.fav ? '<i>★</i>' : ''}</button>`).join('')}</div>` : '<section class="card"><p class="empty">Bu klasörde dosya yok. Yukarıdan fotoğraf çek ya da dosya ekle.</p></section>'}`;
  $('#dfold').onchange = () => { D.f = $('#dfold').dataset.val; route(); };
  const add = async e => {
    let n = 0;
    for (const f of [...e.target.files]) {
      await DB.put('docs', { id: DB.uid(), name: f.name.replace(/\.[^.]+$/, '') || 'Dosya', ext: (f.name.match(/\.[a-z0-9]+$/i) || [''])[0], type: f.type || 'application/octet-stream', blob: f, thumb: await mkThumb(f), size: f.size, folder: D.f === 'all' || D.f === 'fav' ? '' : D.f, fav: false, created: Date.now() });
      n++;
    }
    if (n) { toast(n + ' dosya eklendi'); route(); }
  };
  $('#dcam').onchange = add; $('#dfile').onchange = add;
};
A.docCam = () => $('#dcam').click();
A.docPick = () => $('#dfile').click();
A.folderNew = () => sheet(`<h2 class="st">Yeni klasör</h2><div class="field"><input id="fnm" maxlength="30" placeholder="Klasör adı"></div><button class="btn" style="width:100%" data-a="folderSave">Oluştur</button>`);
A.folderSave = async () => {
  const n = $('#fnm').value.trim(); if (!n) return toast('Klasör adı yaz');
  const fl = await getFolders(); if (fl.includes(n) || ['Tümü', 'Genel', 'Favoriler'].includes(n)) return toast('Bu isim kullanılıyor');
  fl.push(n); await DB.put('kv', fl, 'folders'); D.f = n; A.closeSheet(); route();
};
A.folderDel = async () => {
  if (!confirm('Klasör silinsin mi? İçindeki dosyalar Genel\'e taşınır.')) return;
  const name = D.f; await DB.put('kv', (await getFolders()).filter(f => f !== name), 'folders');
  for (const d of await DB.all('docs')) if (d.folder === name) { d.folder = ''; await DB.put('docs', d); }
  D.f = 'all'; route();
};
A.docOpen = async b => {
  const d = await DB.get('docs', b.dataset.id); if (!d) return;
  A.vClose(); DV.id = d.id; DV.url = URL.createObjectURL(d.blob);
  const o = document.createElement('div'); o.className = 'viewer'; o.id = 'viewer';
  o.innerHTML = `<div class="vtop"><button class="nb" data-a="vClose" aria-label="Kapat">${ic('back', 22)}</button><b class="vt">${esc(d.name)}</b><button class="nb" id="vfav" data-a="vFav" style="color:${d.fav ? 'var(--orange)' : 'var(--tx2)'}">${d.fav ? '★' : '☆'}</button></div>
  <div class="vbody">${d.type.startsWith('image/') ? `<img src="${DV.url}" alt="">` : `<div class="pdf">${mi('docs', 56)}<p>${esc(d.name)}</p><p class="empty">PDF dosyası · Paylaş / İndir ile aç</p></div>`}</div>
  <div class="vbar"><button class="btn sec w" data-a="vEdit">Düzenle</button><button class="btn sec w" data-a="vShare">Paylaş / İndir</button><button class="btn danger w" data-a="vDel">Sil</button></div>`;
  document.body.appendChild(o);
};
A.vClose = () => { const o = $('#viewer'); if (o) o.remove(); if (DV.url) { URL.revokeObjectURL(DV.url); DV.url = ''; } };
A.vFav = async () => { const d = await DB.get('docs', DV.id); d.fav = !d.fav; await DB.put('docs', d); const f = $('#vfav'); f.textContent = d.fav ? '★' : '☆'; f.style.color = d.fav ? 'var(--orange)' : 'var(--tx2)'; route(); };
A.vDel = async () => { if (!confirm('Bu dosya silinsin mi?')) return; await DB.del('docs', DV.id); A.vClose(); toast('Dosya silindi'); route(); };
A.vShare = async () => {
  const d = await DB.get('docs', DV.id), f = new File([d.blob], d.name + (d.ext || ''), { type: d.type });
  if (navigator.canShare && navigator.canShare({ files: [f] })) { try { await navigator.share({ files: [f] }); return; } catch (e) { /* iptal */ } }
  const a = document.createElement('a'); a.href = URL.createObjectURL(d.blob); a.download = f.name; a.click(); toast('Dosya indiriliyor');
};
A.vEdit = async () => {
  const d = await DB.get('docs', DV.id), fl = await getFolders();
  sheet(`<h2 class="st">Düzenle</h2><div class="field"><label>Ad</label><input id="enm" maxlength="60" value="${esc(d.name)}"></div><div class="field"><label>Klasör</label>${chips('efold', [['', 'Genel'], ...fl.map(f => [f, f])], d.folder || '')}</div><button class="btn" style="width:100%" data-a="vSave">Kaydet</button>`);
};
A.vSave = async () => {
  const d = await DB.get('docs', DV.id); d.name = $('#enm').value.trim() || d.name; d.folder = $('#efold').dataset.val;
  await DB.put('docs', d); A.closeSheet(); const t = $('#viewer .vt'); if (t) t.textContent = d.name; route();
};
