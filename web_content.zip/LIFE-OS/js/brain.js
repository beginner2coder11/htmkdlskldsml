/* LIFE OS – Beyin (zekâ oyunları) */
const BR = { lvl: 'easy' }, GM = {};
const LV = [['easy', 'Kolay'], ['mid', 'Orta'], ['hard', 'Zor']];
const GAMES = [['mem', 'Hafıza', 'gMem', 'purple', 'Eşleşen kartları bul'], ['math', 'İşlem', 'gMath', 'blue', '60 saniyede hızlı hesap'], ['seq', 'Sayı dizisi', 'gSeq', 'green', 'Sıradaki sayıyı bul'], ['word', 'Kelime', 'gWord', 'orange', 'Harfleri düzene sok'], ['color', 'Renk', 'gColor', 'red', 'Yazıya değil renge bak']];
const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const bScores = async () => (await DB.get('kv', 'brain')) || {};
const bSave = async (g, score, lower) => {
  const s = await bScores(), k = g + '_' + BR.lvl, old = s[k];
  const best = old === undefined || (lower ? score < old : score > old);
  if (best) { s[k] = score; await DB.put('kv', s, 'brain'); }
  return { best, rec: best ? score : old };
};
const gHead = (m, t) => `<a class="back" href="#/m/brain" aria-label="Geri">${ic('back', 22)}</a><h1 class="page" style="margin-bottom:6px">${t}</h1><p class="label" style="margin:0 2px 16px">${LV.find(x => x[0] === BR.lvl)[1]} seviye</p>`;
async function gEnd(game, score, label, lower) {
  const r = await bSave(game, score, lower);
  sheet(`<h2 class="st">${r.best ? 'Yeni rekor!' : 'Oyun bitti'}</h2><div class="big">${fmt(score)}</div><p class="empty" style="margin:6px 0 20px">${label} · Rekor: ${fmt(r.rec)}</p><div class="bar"><button class="btn w" data-a="gAgain">Tekrar oyna</button><button class="btn sec w" data-a="gHub">Menü</button></div>`);
}
A.gAgain = () => { A.closeSheet(); route(); };
A.gHub = () => { A.closeSheet(); location.hash = '#/m/brain'; };
let MS = null;

MV.brain = async (m, sub) => {
  if (sub && GM[sub]) return GM[sub](m);
  const sc = await bScores();
  view.innerHTML = `${mhero(m)}${seg('blv', LV, BR.lvl)}<div class="tools" style="margin-top:16px">${GAMES.map(([k, n, i, c, d]) => { const v = sc[k + '_' + BR.lvl]; return `<a class="tool" href="#/m/brain/${k}" style="--c:var(--${c})"><div class="ico">${mi(i, 46)}</div><div>${n}<small class="label" style="display:block;margin-top:4px;color:var(--orange)">${v === undefined ? 'Rekor yok' : fmt(v) + (k === 'mem' ? ' hamle' : ' puan')}</small></div></a>`; }).join('')}</div>`;
  $('#blv').onchange = () => { BR.lvl = $('#blv').dataset.val; route(); };
};

const MG = ['●', '■', '▲', '◆', '★', '♥', '♣', '♠', '☾', '✚'], MC = ['#7aa7e0', '#d98383', '#74b88f', '#d9ad66', '#a898d8', '#a9c4ea', '#c9bfe8', '#d98383', '#74b88f', '#d9ad66'];
GM.mem = m => {
  const n = { easy: 6, mid: 8, hard: 10 }[BR.lvl], cards = shuffle([...Array(n).keys(), ...Array(n).keys()]);
  const S = MS = { cards, open: [], done: new Set(), moves: 0, lock: false, t0: 0, over: false };
  view.innerHTML = `${gHead(m, 'Hafıza')}<div class="cols2" style="margin:0 0 16px"><div><span class="label">Hamle</span><div class="mid" id="mv">0</div></div><div><span class="label">Süre</span><div class="mid" id="mt">00:00</div></div></div>
  <div class="mgrid" style="grid-template-columns:repeat(${n <= 6 ? 3 : 4},1fr)">${cards.map((c, i) => `<button class="mc" id="mc${i}" data-a="mflip" data-i="${i}"><b style="color:${MC[c]}">${MG[c]}</b></button>`).join('')}</div>`;
  every(() => { if (S.t0 && !S.over) { const s = Math.floor((Date.now() - S.t0) / 1000); $('#mt').textContent = pad(Math.floor(s / 60)) + ':' + pad(s % 60); } }, 500);
};
A.mflip = b => {
  const S = MS; if (!S || !S.cards || S.lock || S.over) return;
  const i = +b.dataset.i; if (S.open.includes(i) || S.done.has(i)) return;
  if (!S.t0) S.t0 = Date.now(); b.classList.add('up'); S.open.push(i); if (S.open.length < 2) return;
  S.moves++; $('#mv').textContent = S.moves; const [a, c] = S.open;
  if (S.cards[a] === S.cards[c]) {
    S.done.add(a); S.done.add(c); S.open = []; $('#mc' + a).classList.add('ok'); $('#mc' + c).classList.add('ok');
    if (S.done.size === S.cards.length) { S.over = true; gEnd('mem', S.moves, 'hamlede tamamladın', true); }
  } else { S.lock = true; setTimeout(() => { [a, c].forEach(x => { const e = $('#mc' + x); if (e) e.classList.remove('up'); }); S.open = []; S.lock = false; }, 650); }
};

GM.math = m => {
  const S = MS = { score: 0, left: 60, over: false, q: null }, L = BR.lvl;
  const gen = () => {
    const ops = L === 'easy' ? ['+', '−'] : ['+', '−', '×'], op = ops[rnd(0, ops.length - 1)]; let a, b, ans;
    const mx = L === 'easy' ? 20 : L === 'mid' ? 99 : 499;
    if (op === '+') { a = rnd(2, mx); b = rnd(2, mx); ans = a + b; }
    else if (op === '−') { a = rnd(5, mx); b = rnd(1, a); ans = a - b; }
    else { a = rnd(2, L === 'mid' ? 12 : 19); b = rnd(2, L === 'mid' ? 12 : 19); ans = a * b; }
    const o = new Set([ans]); while (o.size < 4) { const v = ans + rnd(1, Math.max(3, Math.round(ans * .15))) * (Math.random() < .5 ? -1 : 1); if (v >= 0) o.add(v); }
    return { t: `${a} ${op} ${b}`, ans, opts: shuffle([...o]) };
  };
  S.draw = () => { S.q = gen(); $('#mq').textContent = S.q.t; $('#mo').innerHTML = S.q.opts.map(o => `<button class="opt" data-a="mans" data-v="${o}">${o}</button>`).join(''); };
  view.innerHTML = `${gHead(m, 'İşlem')}<div class="cols2" style="margin:0 0 16px"><div><span class="label">Puan</span><div class="mid" id="ms">0</div></div><div><span class="label">Süre</span><div class="mid" id="mtm">60</div></div></div><div class="qbig" id="mq"></div><div class="opts" id="mo"></div>`;
  S.draw();
  every(() => { if (S.over) return; S.left--; $('#mtm').textContent = S.left; if (S.left <= 0) { S.over = true; gEnd('math', S.score, 'doğru cevap', false); } }, 1000);
};
A.mans = b => { const S = MS; if (!S || S.over || !S.q) return; if (+b.dataset.v === S.q.ans) S.score++; else S.score = Math.max(0, S.score - 1); $('#ms').textContent = S.score; S.draw(); };

GM.seq = m => {
  const S = MS = { i: 0, score: 0, q: null, over: false }, L = BR.lvl;
  const gen = () => {
    const t = rnd(0, L === 'easy' ? 1 : L === 'mid' ? 3 : 5), st = rnd(1, 9); let s = [];
    if (t === 0) { const d = rnd(2, L === 'easy' ? 6 : 9); for (let i = 0; i < 6; i++) s.push(st + d * i); }
    else if (t === 1) { const d = rnd(2, 7), f = rnd(40, 70); for (let i = 0; i < 6; i++) s.push(f - d * i); }
    else if (t === 2) { const r = rnd(2, 3); for (let i = 0; i < 6; i++) s.push(st * Math.pow(r, i)); }
    else if (t === 3) { for (let i = 1; i <= 6; i++) s.push(i * i + (L === 'hard' ? st : 0)); }
    else if (t === 4) { s = [rnd(1, 4), rnd(2, 6)]; for (let i = 2; i < 6; i++) s.push(s[i - 1] + s[i - 2]); }
    else { const d1 = rnd(1, 4), d2 = rnd(2, 5); let v = st; s = [v]; for (let i = 1; i < 6; i++) { v += i % 2 ? d1 : d2; s.push(v); } }
    const ans = s.pop(), o = new Set([ans]); while (o.size < 4) { const v = ans + rnd(1, Math.max(3, Math.round(Math.abs(ans) * .2))) * (Math.random() < .5 ? -1 : 1); if (v > 0) o.add(v); }
    return { s, ans, opts: shuffle([...o]) };
  };
  S.draw = () => { S.q = gen(); $('#sp').textContent = `${S.i + 1} / 10`; $('#sq').innerHTML = S.q.s.join(' , ') + ' , <u>?</u>'; $('#so').innerHTML = S.q.opts.map(o => `<button class="opt" data-a="sans" data-v="${o}">${o}</button>`).join(''); };
  view.innerHTML = `${gHead(m, 'Sayı dizisi')}<div class="cols2" style="margin:0"><div><span class="label">Soru</span><div class="mid" id="sp"></div></div><div><span class="label">Doğru</span><div class="mid" id="ss">0</div></div></div><div class="seqs" id="sq"></div><div class="opts" id="so"></div>`;
  S.draw();
};
A.sans = b => {
  const S = MS; if (!S || S.over || !S.q) return; if (+b.dataset.v === S.q.ans) { S.score++; $('#ss').textContent = S.score; }
  S.i++; if (S.i >= 10) { S.over = true; gEnd('seq', S.score, '/ 10 doğru', false); } else S.draw();
};

const WORDS = {
  easy: ['kedi', 'elma', 'masa', 'ağaç', 'kapı', 'deniz', 'kitap', 'bulut', 'çiçek', 'kalem', 'okul', 'balık'],
  mid: ['yıldız', 'pencere', 'telefon', 'mutfak', 'gökyüzü', 'sandalye', 'çikolata', 'bisiklet', 'şemsiye', 'kahvaltı', 'pazartesi'],
  hard: ['bilgisayar', 'kütüphane', 'öğretmen', 'televizyon', 'dondurma', 'arkadaşlık', 'helikopter', 'uçurtma', 'kelebek', 'gözlükçü', 'mühendislik']
};
GM.word = m => {
  const list = shuffle(WORDS[BR.lvl]).slice(0, 10), S = MS = { i: 0, score: 0, hint: false, over: false, list };
  const scr = w => { let s; do { s = shuffle(Array.from(w)).join(''); } while (s === w); return s; };
  S.draw = () => { const w = list[S.i]; S.hint = false; $('#wp').textContent = `${S.i + 1} / ${list.length}`; $('#wl').innerHTML = Array.from(scr(w)).map(c => `<i>${esc(c.toLocaleUpperCase('tr'))}</i>`).join(''); $('#wa').value = ''; $('#wh').textContent = ''; };
  view.innerHTML = `${gHead(m, 'Kelime')}<div class="cols2" style="margin:0"><div><span class="label">Kelime</span><div class="mid" id="wp"></div></div><div><span class="label">Puan</span><div class="mid" id="ws">0</div></div></div>
  <div class="wl" id="wl"></div><input id="wa" autocomplete="off" autocapitalize="none" placeholder="Kelimeyi yaz"><p class="label" id="wh" style="margin:8px 2px;min-height:20px"></p>
  <div class="bar"><button class="btn sec w" data-a="whint">İpucu (−½)</button><button class="btn sec w" data-a="wskip">Atla</button><button class="btn w" data-a="wok">Kontrol</button></div>`;
  S.draw();
};
const wNext = () => { const S = MS; S.i++; $('#ws').textContent = fmt(S.score); if (S.i >= S.list.length) { S.over = true; gEnd('word', S.score, '/ 10 puan', false); } else S.draw(); };
A.wok = () => {
  const S = MS; if (!S || S.over) return; const g = $('#wa').value.trim().toLocaleLowerCase('tr'), w = S.list[S.i];
  if (g === w) { S.score += S.hint ? .5 : 1; toast('Doğru!'); } else if (g) toast('Doğru cevap: ' + w.toLocaleUpperCase('tr')); else return;
  wNext();
};
A.wskip = () => { if (MS && !MS.over) wNext(); };
A.whint = () => { const S = MS; if (!S || S.over) return; S.hint = true; $('#wh').textContent = 'İlk harf: ' + S.list[S.i][0].toLocaleUpperCase('tr') + ' · ' + S.list[S.i].length + ' harf'; };

const SC = [['Kırmızı', '#d98383'], ['Mavi', '#7aa7e0'], ['Yeşil', '#74b88f'], ['Sarı', '#d9ad66'], ['Mor', '#a898d8']];
GM.color = m => {
  const n = { easy: 3, mid: 4, hard: 5 }[BR.lvl], cs = SC.slice(0, n), S = MS = { score: 0, left: 30, over: false, ans: '' };
  S.draw = () => { const w = cs[rnd(0, n - 1)]; let c; do { c = cs[rnd(0, n - 1)]; } while (BR.lvl !== 'easy' && c === w); S.ans = c[0]; const e = $('#cw'); e.textContent = w[0]; e.style.color = c[1]; };
  view.innerHTML = `${gHead(m, 'Renk')}<div class="cols2" style="margin:0 0 16px"><div><span class="label">Puan</span><div class="mid" id="cs">0</div></div><div><span class="label">Süre</span><div class="mid" id="ct">30</div></div></div><p class="label" style="text-align:center">Yazının rengini seç</p><div class="qbig" id="cw" style="font-size:60px"></div>
  <div class="opts" style="grid-template-columns:repeat(${n === 4 ? 2 : 1},1fr)">${cs.map(c => `<button class="opt" data-a="cans" data-v="${c[0]}">${c[0]}</button>`).join('')}</div>`;
  S.draw();
  every(() => { if (S.over) return; S.left--; $('#ct').textContent = S.left; if (S.left <= 0) { S.over = true; gEnd('color', S.score, 'doğru cevap', false); } }, 1000);
};
A.cans = b => { const S = MS; if (!S || S.over || !S.ans) return; if (b.dataset.v === S.ans) S.score++; else S.score = Math.max(0, S.score - 1); $('#cs').textContent = S.score; S.draw(); };
