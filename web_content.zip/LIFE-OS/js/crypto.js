/* LIFE OS – Kripto takip (ortalama maliyet yöntemi, fiyatlar ₺) */
const COINS = [['bitcoin', 'Bitcoin', 'BTC'], ['ethereum', 'Ethereum', 'ETH'], ['tether', 'Tether', 'USDT'], ['binancecoin', 'BNB', 'BNB'], ['solana', 'Solana', 'SOL'], ['ripple', 'XRP', 'XRP'], ['usd-coin', 'USD Coin', 'USDC'], ['cardano', 'Cardano', 'ADA'], ['dogecoin', 'Dogecoin', 'DOGE'], ['tron', 'TRON', 'TRX'], ['avalanche-2', 'Avalanche', 'AVAX'], ['polkadot', 'Polkadot', 'DOT'], ['chainlink', 'Chainlink', 'LINK'], ['the-open-network', 'Toncoin', 'TON'], ['shiba-inu', 'Shiba Inu', 'SHIB'], ['litecoin', 'Litecoin', 'LTC'], ['stellar', 'Stellar', 'XLM'], ['monero', 'Monero', 'XMR'], ['uniswap', 'Uniswap', 'UNI'], ['cosmos', 'Cosmos', 'ATOM'], ['near', 'NEAR', 'NEAR'], ['aptos', 'Aptos', 'APT'], ['arbitrum', 'Arbitrum', 'ARB'], ['pepe', 'Pepe', 'PEPE'], ['sui', 'Sui', 'SUI'], ['bitcoin-cash', 'Bitcoin Cash', 'BCH'], ['ethereum-classic', 'Ethereum Classic', 'ETC'], ['algorand', 'Algorand', 'ALGO'], ['vechain', 'VeChain', 'VET'], ['filecoin', 'Filecoin', 'FIL']];
const CRY = { tab: 'port', last: 0, sel: null, target: '' };
const fmtQ = n => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 8 }).format(n);
const moneyP = n => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', minimumFractionDigits: 2, maximumFractionDigits: n < .01 ? 8 : n < 1 ? 4 : 2 }).format(n);
const sgn = n => (n >= 0 ? '+' : '−') + money(Math.abs(n));
const pc = n => (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(2).replace('.', ',') + '%';
const cCol = id => ['#7aa7e0', '#d9ad66', '#74b88f', '#a898d8', '#d98383', '#a9c4ea'][[...id].reduce((n, c) => n + c.charCodeAt(0), 0) % 6];
const cDot = (id, sym) => `<span class="dot" style="--c:${cCol(id)};font-size:11px;letter-spacing:-.02em">${esc(sym.slice(0, 4))}</span>`;

const cPos = txs => {
  const s = [...txs].sort((a, b) => a.date.localeCompare(b.date) || a.created - b.created); let qty = 0, cost = 0, realized = 0;
  for (const t of s) {
    if (t.type === 'buy') { cost += t.qty * t.price + (t.fee || 0); qty += t.qty; }
    else { const avg = qty > 0 ? cost / qty : 0, q = Math.min(t.qty, qty); realized += (t.price - avg) * q - (t.fee || 0); cost -= avg * q; qty -= q; }
  }
  if (qty < 1e-12) { qty = 0; cost = 0; }
  return { qty, cost, avg: qty > 0 ? cost / qty : 0, realized };
};
async function cData() {
  const [txs, pr, w] = await Promise.all([DB.all('crypto'), DB.get('kv', 'cryptoprices'), DB.get('kv', 'cryptowatch')]);
  const P = (pr && pr.p) || {}, by = {};
  txs.forEach(t => (by[t.coinId] = by[t.coinId] || { id: t.coinId, name: t.name, sym: t.sym, tx: [] }).tx.push(t));
  const hold = Object.values(by).map(c => { const p = cPos(c.tx), px = P[c.id] || null; return { ...c, ...p, px, val: px ? p.qty * px.price : null }; });
  const sym = {}; COINS.forEach(k => { sym[k[0]] = k[2]; }); (w || []).forEach(x => { sym[x.id] = x.sym; }); Object.values(by).forEach(x => { sym[x.id] = x.sym; });
  return { txs, P, t: pr && pr.t, watch: w || [], hold, by, sym };
}
async function cFetch(ids, sym = {}) {
  if (!ids.length) return { ok: false, msg: 'Önce bir coin ekle' };
  if (navigator.onLine === false) return { ok: false, msg: 'İnternet bağlantısı yok' };
  let msg = '';
  try {
    const r = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids.join(',')}&vs_currencies=try&include_24hr_change=true`);
    if (r.status === 429) msg = 'Çok sık istek (limit). Birkaç dakika sonra dene.'; else if (!r.ok) msg = 'Fiyat sunucusu hata verdi (' + r.status + ')';
    else {
      const j = await r.json(), old = (await DB.get('kv', 'cryptoprices')) || { p: {} }; let n = 0;
      for (const id of ids) if (j[id] && j[id].try != null) { old.p[id] = { price: j[id].try, chg: j[id].try_24h_change }; n++; }
      if (n) { old.t = Date.now(); await DB.put('kv', old, 'cryptoprices'); return { ok: true, src: 'CoinGecko' }; }
      msg = 'Coin için fiyat bulunamadı (ID doğru mu?)';
    }
  } catch (e) { msg = 'Bağlantı kurulamadı'; }
  try {   // yedek kaynak: Binance TRY çiftleri
    const old = (await DB.get('kv', 'cryptoprices')) || { p: {} }; let n = 0;
    await Promise.all(ids.map(async id => {
      const s = sym[id]; if (!s) return;
      try { const r = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${encodeURIComponent(s)}TRY`); if (!r.ok) return; const j = await r.json(); if (j.lastPrice) { old.p[id] = { price: +j.lastPrice, chg: +j.priceChangePercent }; n++; } } catch (e) { /* yoksay */ }
    }));
    if (n) { old.t = Date.now(); await DB.put('kv', old, 'cryptoprices'); return { ok: true, src: 'Binance (yedek kaynak)' }; }
  } catch (e) { /* yoksay */ }
  return { ok: false, msg };
}
const cIds = d => [...new Set([...d.hold.map(c => c.id), ...d.watch.map(c => c.id)])];
const tLabel = t => !t ? 'Fiyat yok' : 'Son güncelleme: ' + new Date(t).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const txRowC = t => `<button class="row" data-a="cTxOpen" data-id="${t.id}"><span class="dot" style="--c:${t.type === 'buy' ? '#74b88f' : '#d98383'}">${t.type === 'buy' ? 'A' : 'S'}</span><span class="t"><b>${esc(t.sym)} · ${t.type === 'buy' ? 'Alış' : 'Satış'}</b><small>${fmtQ(t.qty)} × ${moneyP(t.price)} · ${dlabel(t.date)}</small></span><span class="amt2 ${t.type === 'buy' ? 'neg' : 'pos'}">${t.type === 'buy' ? '−' : '+'}${money(t.qty * t.price)}</span></button>`;

MV.crypto = async (m, sub) => {
  const d = await cData();
  if (!CRY.fetching && navigator.onLine !== false && Date.now() - CRY.last > 120000 && cIds(d).length && (!d.t || Date.now() - d.t > 300000)) {
    CRY.last = Date.now(); cFetch(cIds(d), d.sym).then(r => { if (r.ok && location.hash.startsWith('#/m/crypto')) route(); });
  }
  if (sub) return coinDetail(m, sub, d);
  const open = d.hold.filter(c => c.qty > 0), priced = open.filter(c => c.val !== null);
  const val = priced.reduce((n, c) => n + c.val, 0), costP = priced.reduce((n, c) => n + c.cost, 0), costAll = open.reduce((n, c) => n + c.cost, 0);
  const pnl = val - costP, pnlP = costP ? pnl / costP * 100 : 0, real = d.hold.reduce((n, c) => n + c.realized, 0);
  let body = '';
  if (CRY.tab === 'port') {
    body = `<section class="card"><span class="label">Toplam değer</span><div class="big">${money(val)}</div>
      <div class="cols2"><div><span class="label">Maliyet</span><div class="mid">${money(costAll)}</div></div><div><span class="label">Kâr / Zarar</span><div class="mid ${pnl >= 0 ? 'pos' : 'neg'}">${sgn(pnl)}</div><span class="label ${pnl >= 0 ? 'pos' : 'neg'}">${costP ? pc(pnlP) : '—'}</span></div></div>
      <div class="cols2" style="margin-top:12px"><div><span class="label">Gerçekleşen K/Z</span><div class="mid ${real >= 0 ? 'pos' : 'neg'}">${sgn(real)}</div></div><div><span class="label">Fiyatlar</span><div class="label" style="margin-top:4px;color:var(--tx)">${tLabel(d.t)}</div></div></div>
      <div class="bar"><button class="btn sec w" data-a="cRefresh">Fiyatları güncelle</button></div></section>
      ${open.length ? `<section class="card" style="padding:4px 16px">${open.sort((a, b) => (b.val || 0) - (a.val || 0)).map(c => `<a class="row" href="#/m/crypto/${c.id}" style="text-decoration:none;color:inherit">${cDot(c.id, c.sym)}<span class="t"><b>${esc(c.name)}</b><small>${fmtQ(c.qty)} ${esc(c.sym)} · ort. ${moneyP(c.avg)}</small></span><span style="text-align:right"><b class="amt2">${c.val !== null ? money(c.val) : '—'}</b><small class="${c.val !== null && c.val >= c.cost ? 'pos' : 'neg'}" style="display:block;font-size:13px">${c.val !== null && c.cost ? pc((c.val - c.cost) / c.cost * 100) : 'fiyat yok'}</small></span></a>`).join('')}</section>` : '<section class="card"><p class="empty">Henüz coin yok. + ile ilk alışını ekle.</p></section>'}`;
  } else if (CRY.tab === 'watch') {
    const rows = cIds(d).map(id => { const c = d.by[id] || d.watch.find(w => w.id === id), px = d.P[id]; return { id, name: c.name, sym: c.sym || c.symbol, px }; });
    body = `<div class="bar" style="margin:0 0 14px"><button class="btn sec w" data-a="coinPick" data-t="watch">+ Takibe ekle</button><button class="btn sec w" data-a="cRefresh">Güncelle</button></div>
      ${rows.length ? `<section class="card" style="padding:4px 16px">${rows.map(r => `<button class="row" data-a="cWatchOpen" data-id="${r.id}">${cDot(r.id, r.sym)}<span class="t"><b>${esc(r.name)}</b><small>${esc(r.sym)}</small></span><span style="text-align:right"><b class="amt2">${r.px ? moneyP(r.px.price) : '—'}</b>${r.px && r.px.chg != null ? `<small class="${r.px.chg >= 0 ? 'pos' : 'neg'}" style="display:block;font-size:13px">${pc(r.px.chg)} · 24s</small>` : ''}</span></button>`).join('')}</section><p class="label" style="margin:0 2px">${tLabel(d.t)}</p>` : '<section class="card"><p class="empty">Takip listen boş. Coin ekleyip fiyatını izle.</p></section>'}`;
  } else {
    const tx = [...d.txs].sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
    body = tx.length ? `<section class="card" style="padding:4px 16px">${tx.map(txRowC).join('')}</section>` : '<section class="card"><p class="empty">Henüz işlem yok.</p></section>';
  }
  view.innerHTML = `${mhero(m)}${seg('ctab2', [['port', 'Portföy'], ['watch', 'Takip'], ['tx', 'İşlemler']], CRY.tab)}<div style="height:16px"></div>${body}${fab('cNew', 'orange')}`;
  $('#ctab2').onchange = () => { CRY.tab = $('#ctab2').dataset.val; route(); };
};
function coinDetail(m, id, d) {
  const c = d.hold.find(x => x.id === id), meta = c || d.watch.find(w => w.id === id) || (COINS.find(k => k[0] === id) ? { id, name: COINS.find(k => k[0] === id)[1], sym: COINS.find(k => k[0] === id)[2], tx: [], qty: 0, cost: 0, avg: 0, realized: 0, px: d.P[id] || null, val: null } : null);
  if (!meta) { location.hash = '#/m/crypto'; return; }
  const px = d.P[id] || null, val = px ? meta.qty * px.price : null, pnl = val !== null ? val - meta.cost : null;
  const tx = [...(meta.tx || [])].sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  view.innerHTML = `<a class="back" href="#/m/crypto" aria-label="Geri">${ic('back', 22)}</a><div style="display:flex;align-items:center;gap:14px;margin:0 2px 18px">${cDot(id, meta.sym)}<div><h1 class="page" style="margin:0">${esc(meta.name)}</h1><span class="label">${esc(meta.sym)}</span></div></div>
  <section class="card"><span class="label">Güncel fiyat${px && px.manual ? ' (elle girilen)' : ''}</span><div class="big">${px ? moneyP(px.price) : '—'}</div>${px && px.chg != null ? `<span class="label ${px.chg >= 0 ? 'pos' : 'neg'}">${pc(px.chg)} · 24 saat</span>` : ''}
    <div class="cols2"><div><span class="label">Elindeki</span><div class="mid">${fmtQ(meta.qty)}</div></div><div><span class="label">Ort. maliyet</span><div class="mid">${meta.qty ? moneyP(meta.avg) : '—'}</div></div><div><span class="label">Güncel değer</span><div class="mid">${val !== null ? money(val) : '—'}</div></div><div><span class="label">Kâr / Zarar</span><div class="mid ${pnl !== null && pnl >= 0 ? 'pos' : 'neg'}">${pnl !== null && meta.qty ? sgn(pnl) : '—'}</div></div></div>
    <div class="cols2" style="margin-top:12px"><div><span class="label">Toplam maliyet</span><div class="mid">${money(meta.cost)}</div></div><div><span class="label">Gerçekleşen K/Z</span><div class="mid ${meta.realized >= 0 ? 'pos' : 'neg'}">${sgn(meta.realized)}</div></div></div></section>
  <div class="bar" style="margin:0 0 16px"><button class="btn w" data-a="cNew" data-t="buy" data-c="${id}">Alış ekle</button><button class="btn sec w" data-a="cNew" data-t="sell" data-c="${id}">Satış ekle</button></div>
  <div class="bar" style="margin:0 0 16px"><button class="btn sec w" data-a="cManual" data-id="${id}">Elle fiyat gir</button><button class="btn sec w" data-a="cRefresh">Fiyatı güncelle</button></div>
  ${tx.length ? `<div class="sec"><h2>İşlemler</h2></div><section class="card" style="padding:4px 16px">${tx.map(txRowC).join('')}</section>` : ''}`;
}
A.cRefresh = async () => {
  const d = await cData(), ids = cIds(d); if (!ids.length) return toast('Önce bir coin ekle');
  toast('Fiyatlar alınıyor…'); const r = await cFetch(ids, d.sym); CRY.last = Date.now();
  toast(r.ok ? 'Fiyatlar güncellendi · ' + r.src : r.msg + (r.msg === 'Bağlantı kurulamadı' ? '. APK’nın internet iznini kontrol et.' : '')); route();
};
const coinRows = q => {
  q = Search.norm(q).trim();
  return COINS.filter(c => !q || Search.norm(c[1] + ' ' + c[2]).includes(q)).map(([id, n, s]) => `<button class="row" data-a="coinSel" data-id="${id}" data-n="${esc(n)}" data-s="${s}">${cDot(id, s)}<span class="t"><b>${esc(n)}</b><small>${s}</small></span></button>`).join('') || '<p class="empty">Bulunamadı. Aşağıdan elle ekleyebilirsin.</p>';
};
A.coinPick = b => {
  CRY.target = b.dataset.t;
  sheet(`<h2 class="st">Coin seç</h2><input id="cks" placeholder="Coin ara (ör. btc)" autocomplete="off"><div id="ckl" style="max-height:32vh;overflow:auto;margin:10px 0">${coinRows('')}</div>
  <div class="sec" style="margin:6px 0 10px"><h2 style="font-size:16px">Listede yok mu?</h2></div>
  <div class="cols2" style="margin:0 0 10px"><div style="padding:0;background:none"><input id="cxn" placeholder="Ad"></div><div style="padding:0;background:none"><input id="cxs" placeholder="Sembol"></div></div>
  <input id="cxi" placeholder="CoinGecko ID (ör. bitcoin)" autocapitalize="none" autocomplete="off" style="margin-bottom:10px"><button class="btn sec" style="width:100%" data-a="coinCustom">Bu coini kullan</button>`, 'dp');
  $('#cks').oninput = () => { $('#ckl').innerHTML = coinRows($('#cks').value); };
};
const pickCoin = async c => {
  A.dpClose();
  if (CRY.target === 'tx') { CRY.sel = c; const s = $('#xcoin span'); if (s) s.textContent = `${c.name} (${c.sym})`; }
  else {
    const w = (await DB.get('kv', 'cryptowatch')) || [];
    if (!w.some(x => x.id === c.id)) { w.push({ id: c.id, name: c.name, sym: c.sym }); await DB.put('kv', w, 'cryptowatch'); }
    toast('Takibe eklendi'); route(); cFetch([c.id], { [c.id]: c.sym }).then(r => { if (r.ok && location.hash.startsWith('#/m/crypto')) route(); });
  }
};
A.coinSel = b => pickCoin({ id: b.dataset.id, name: b.dataset.n, sym: b.dataset.s });
A.coinCustom = () => {
  const id = $('#cxi').value.trim().toLowerCase(), name = $('#cxn').value.trim(), sym = $('#cxs').value.trim().toUpperCase();
  if (!/^[a-z0-9-]+$/.test(id)) return toast('Geçerli bir CoinGecko ID gir'); if (!name || !sym) return toast('Ad ve sembol gir');
  pickCoin({ id, name, sym });
};
const cForm = (type, coin) => {
  CRY.sel = coin || null; CRY.target = 'tx';
  sheet(`<h2 class="st">İşlem ekle</h2>${seg('xtype', [['buy', 'Alış'], ['sell', 'Satış']], type)}
  <div class="field" style="margin-top:16px"><label>Coin</label><button type="button" class="dfield" id="xcoin" data-a="coinPick" data-t="tx">${mi('crypto', 22)}<span>${coin ? esc(coin.name) + ' (' + esc(coin.sym) + ')' : 'Coin seç'}</span></button></div>
  <div class="cols2" style="margin:0 0 16px"><div style="padding:0;background:none"><label class="label">Adet</label><input id="xq" inputmode="decimal" placeholder="0"></div><div style="padding:0;background:none"><label class="label">Birim fiyat (₺)</label><input id="xp" inputmode="decimal" placeholder="0"></div></div>
  <p class="label" id="xtot" style="margin:-6px 2px 14px;min-height:18px"></p>
  <div class="field"><label>Komisyon (₺, isteğe bağlı)</label><input id="xf" inputmode="decimal" placeholder="0"></div>
  ${dateField('xdate', 'Tarih', today())}
  <div class="field"><label>Not</label><input id="xn" maxlength="60" placeholder="İsteğe bağlı (borsa vb.)"></div>
  <button class="btn" style="width:100%" data-a="cSave">Kaydet</button>`);
  const up = () => { const q = num($('#xq').value), p = num($('#xp').value); $('#xtot').textContent = q > 0 && p > 0 ? 'Toplam: ' + money(q * p) : ''; };
  $('#xq').oninput = up; $('#xp').oninput = up;
};
A.cNew = async b => {
  const type = (b && b.dataset && b.dataset.t) || 'buy', id = b && b.dataset && b.dataset.c; let coin = null;
  if (id) { const k = COINS.find(x => x[0] === id), d = await cData(), h = d.by[id] || d.watch.find(w => w.id === id); coin = h ? { id, name: h.name, sym: h.sym || h.symbol } : k ? { id, name: k[1], sym: k[2] } : null; }
  cForm(type, coin);
};
A.cSave = async () => {
  const c = CRY.sel, type = $('#xtype').dataset.val, qty = num($('#xq').value), price = num($('#xp').value), fee = num($('#xf').value) || 0;
  if (!c) return toast('Coin seç'); if (!(qty > 0)) { toast('Adet gir'); return $('#xq').focus(); } if (!(price > 0)) { toast('Birim fiyat gir'); return $('#xp').focus(); }
  const d = await cData();
  if (type === 'sell') { const h = d.by[c.id] ? cPos(d.by[c.id].tx).qty : 0; if (qty > h + 1e-9) return toast(`Elinde yeterli adet yok (${fmtQ(h)})`); }
  await DB.put('crypto', { id: DB.uid(), coinId: c.id, name: c.name, sym: c.sym, type, qty, price, fee, date: $('#xdate').dataset.val || today(), note: $('#xn').value.trim(), created: Date.now() });
  if (!d.P[c.id]) { const pr = (await DB.get('kv', 'cryptoprices')) || { p: {} }; pr.p[c.id] = { price, chg: null, manual: true }; pr.t = pr.t || Date.now(); await DB.put('kv', pr, 'cryptoprices'); }
  A.closeSheet(); toast('İşlem kaydedildi'); route(); cFetch([c.id], { [c.id]: c.sym }).then(r => { if (r.ok && location.hash.startsWith('#/m/crypto')) route(); });
};
A.cTxOpen = async b => {
  const t = await DB.get('crypto', b.dataset.id); if (!t) return;
  sheet(`<h2 class="st">${esc(t.name)} · ${t.type === 'buy' ? 'Alış' : 'Satış'}</h2><div class="big">${money(t.qty * t.price)}</div>
  <p class="empty" style="margin:8px 0 20px">${fmtQ(t.qty)} ${esc(t.sym)} × ${moneyP(t.price)}${t.fee ? ' · komisyon ' + money(t.fee) : ''}<br>${dtxt(t.date)}${t.note ? ' · ' + esc(t.note) : ''}</p><button class="btn danger" style="width:100%" data-a="cTxDel" data-id="${t.id}">İşlemi sil</button>`);
};
A.cTxDel = async b => { await DB.del('crypto', b.dataset.id); A.closeSheet(); route(); };
A.cWatchOpen = async b => {
  const id = b.dataset.id, d = await cData(), px = d.P[id], w = d.watch.find(x => x.id === id), held = d.by[id];
  sheet(`<h2 class="st">${esc((held || w).name)}</h2><div class="big">${px ? moneyP(px.price) : '—'}</div>${px && px.chg != null ? `<p class="${px.chg >= 0 ? 'pos' : 'neg'}" style="margin-top:6px">${pc(px.chg)} · 24 saat</p>` : ''}
  <div class="bar" style="margin-top:18px"><a class="btn w" href="#/m/crypto/${id}" style="text-align:center">Ayrıntı</a>${w && !held ? `<button class="btn danger" data-a="cWatchDel" data-id="${id}">Takipten çıkar</button>` : ''}</div>`);
};
A.cWatchDel = async b => { const w = ((await DB.get('kv', 'cryptowatch')) || []).filter(x => x.id !== b.dataset.id); await DB.put('kv', w, 'cryptowatch'); A.closeSheet(); route(); };
A.cManual = b => sheet(`<h2 class="st">Elle fiyat gir</h2><p class="empty" style="margin-bottom:6px">İnternet yokken değeri hesaplamak için. Sonraki güncellemede canlı fiyat bunun yerine geçer.</p><input class="amt" id="mpx" inputmode="decimal" placeholder="0,00 ₺"><button class="btn" style="width:100%" data-a="cManualSave" data-id="${b.dataset.id}">Kaydet</button>`);
A.cManualSave = async b => {
  const p = num($('#mpx').value); if (!(p > 0)) return toast('Geçerli bir fiyat gir');
  const pr = (await DB.get('kv', 'cryptoprices')) || { p: {} }; pr.p[b.dataset.id] = { price: p, chg: null, manual: true }; pr.t = pr.t || Date.now();
  await DB.put('kv', pr, 'cryptoprices'); A.closeSheet(); route();
};
