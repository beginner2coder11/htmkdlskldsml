# Afriquia Stock - PDF v4

إصلاح نهائي لمسار تحميل PDF:
- زر فاتورة PDF يستعمل جسر Android مباشرة.
- زر وصل التسليم PDF يستعمل جسر Android مباشرة.
- تمت إزالة fallback إلى afriquia-pdf:// الذي كان يسبب رسالة "No app on this device can open that link".
- يتم حفظ PDF داخل Downloads بواسطة MediaStore على Android 10+.
