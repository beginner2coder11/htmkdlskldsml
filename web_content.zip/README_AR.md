# Afriquia Stock — نسخة جاهزة لـ Android Studio

## معلومات المشروع
- Package: `com.afriquia.freinszemamra`
- Version: 1.1
- Target SDK: 35
- Minimum SDK: 23
- Java: 17

## أهم الوظائف
- فاتورة متعددة المنتجات.
- وصل التسليم بالفرنسية: Bon de livraison.
- حفظ/تحميل الفاتورة ووصل التسليم بصيغة PDF.
- طباعة حرارية Bluetooth عبر SPP.
- طباعة حرارية USB OTG عبر ESC/POS.
- اختيار 58mm أو 80mm.
- بيانات المحل: الهاتف 0667668693، العنوان الحي الصناعي الزمامرة.
- قسم المبيعات والبحث والتصفية حسب اليوم/الشهر/السنة.

## فتح وبناء APK
1. فك الضغط عن المجلد.
2. افتح مجلد `AfriquiaStockAndroid` في Android Studio.
3. انتظر Gradle Sync.
4. تأكد من تثبيت Android SDK 35 وJDK 17.
5. اختر `Build > Generate App Bundles or APKs > Generate APKs`.
6. للنسخة النهائية اختر `Build > Generate Signed App Bundle / APK` ثم `APK`.

## الطباعة الحرارية
- Bluetooth: قم بإقران الطابعة من إعدادات الهاتف، ثم اختر الطابعة من داخل التطبيق.
- Android 12+: سيطلب التطبيق إذن Bluetooth عند الحاجة.
- USB: وصل الطابعة بواسطة USB OTG ووافق على إذن USB.
- الطابعة يجب أن تدعم ESC/POS وأن يكون لها منفذ Bulk OUT للطباعة عبر USB.
