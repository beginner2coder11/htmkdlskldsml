# دليل بناء ونشر أكاديمية الورق الذهبية على Google Play

## 1) المتطلبات
- Android Studio (أحدث إصدار مستقر)
- JDK 17 (يأتي مضمّنًا مع Android Studio)

## 2) فتح المشروع
1. افتح Android Studio ← Open ← اختر مجلد `android`.
2. انتظر انتهاء مزامنة Gradle (قد تُنزَّل الملفات أول مرة).

## 3) إنشاء مفتاح التوقيع (مرة واحدة)
```bash
keytool -genkeypair -v -keystore release.keystore -alias key0 \
  -keyalg RSA -keysize 2048 -validity 10000
```
- ضع ملف `release.keystore` داخل مجلد `android/app`.
- فعّل أسطر التوقيع في `android/app/build.gradle` (قسم signingConfigs/release).

## 4) بناء حزمة AAB موقّعة
- من القائمة: Build ← Generate Signed Bundle / APK ← Android App Bundle ← اختر `release`.
- ستجد الملف في: `android/app/release/app-release.aab`.

## 5) الرفع على Play Console
1. أنشئ تطبيقًا جديدًا في Play Console وارفع ملف AAB.
2. املأ بطاقة المتجر: استخدم الصور من مجلد `play-assets`:
   - الأيقونة: `icon-512.png` (512×512)
   - الصورة المميزة: `feature-graphic-1024x500.png` (1024×500)
   - لقطات الشاشة: مجلد `screenshots` (أضف لقطتين على الأقل)
3. أضف رابط سياسة الخصوصية (محتوى ملف `PRIVACY_POLICY.md`).
4. أكمل: نموذج سلامة البيانات، تصنيف المحتوى، الفئة، الوصف، ثم أرسل للمراجعة.

## قائمة التحقق قبل الإرسال (وفق متطلبات Google Play الحالية)
- [ ] الحزمة بصيغة AAB وموقّعة بمفتاح الإصدار
- [ ] رقم الإصدار (versionCode) يزيد مع كل تحديث
- [ ] الأيقونة والصورة المميزة ولقطات الشاشة بالمقاسات المطلوبة
- [ ] رابط سياسة خصوصية يعمل
- [ ] نموذج سلامة البيانات مكتمل
- [ ] لا أذونات حساسة غير مبررة في AndroidManifest

اسم الحزمة: `com.nexusapp.p73acc8dd` — الإصدار: `9.6 (24)`
