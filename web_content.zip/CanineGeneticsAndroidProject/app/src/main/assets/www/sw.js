const CACHE='canine-genetics-v1';
const CORE='./Canine_Genetics_Simulator.html';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.add(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{const copy=resp.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return resp}).catch(()=>caches.match(CORE))))});
