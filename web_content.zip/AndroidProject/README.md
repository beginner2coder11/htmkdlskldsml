# 4.000 WOCHEN Plus X – Android API 36 Konverter-Projekt

Dieses Android-Studio-Projekt verwendet die aktuell festgelegte Referenz-/Master-Version
von „4.000 WOCHEN Plus X“.

## Eingebundene Master-Version
Die Master-HTML-Datei wurde 1:1 als

`app/src/main/assets/index.html`

eingebunden.

Referenzdatei:
`4000_WOCHEN_Plus_X_MASTER_Lebenskalender_SANDUHR_ANIMATION_SONNENKERN_KONVERTER_BESCHRIFTUNG_SYNC_FINAL.html`

## Technischer Stand
- compileSdk 36
- targetSdk 36
- minSdk 26
- Application ID: `de.wochen.plusx`
- WebView mit JavaScript und LocalStorage
- Native Android-Erinnerungen über AlarmManager + BroadcastReceiver
- Notification Channel „Erinnerungen“
- POST_NOTIFICATIONS für Android 13+
- Boot-/App-Update-Rescheduling der Erinnerungen
- WebView-Bridge `AndroidReminders`

## Verwendung
Den Projektordner in Android Studio öffnen.
Anschließend kann eine Test-APK oder ein signiertes AAB für Google Play gebaut werden.

Wichtig:
Die Datei `app/src/main/assets/index.html` ist die App-Inhaltsdatei.
Änderungen an der HTML-Master-Version müssen dort wieder als neue Referenz eingebunden werden.
