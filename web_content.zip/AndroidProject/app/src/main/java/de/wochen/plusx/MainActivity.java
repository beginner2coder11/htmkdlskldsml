package de.wochen.plusx;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannel(this);
        requestNotificationPermission();

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new ReminderBridge(this), "AndroidReminders");
        webView.setBackgroundColor(0xFF07141B);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    public static class ReminderBridge {
        private final Context context;
        ReminderBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void scheduleReminder(String source, String date, String time, String reminder, String text) {
            if ("none".equals(reminder) || date == null || date.isEmpty() || time == null || time.isEmpty()) return;
            long trigger = calculateTrigger(date, time, reminder);
            if (trigger <= System.currentTimeMillis()) return;
            int requestCode = stableId(source, date, time, reminder, text);
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            PendingIntent pi = pendingIntent(context, requestCode, text);
            alarm.cancel(pi);
            context.getSharedPreferences("native_reminders", Context.MODE_PRIVATE).edit()
                    .putString(String.valueOf(requestCode), String.valueOf(source) + "|" + date + "|" + time + "|" + reminder + "|" + (text == null ? "" : text))
                    .apply();
            // Use an inexact idle-aware alarm so the app does not need the special
            // SCHEDULE_EXACT_ALARM permission. The reminder remains user-facing and
            // may be delivered with a small system-dependent delay.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }

        @JavascriptInterface
        public void cancelReminder(String source, String date, String time, String reminder, String text) {
            int requestCode = stableId(source, date, time, reminder, text);
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm != null) alarm.cancel(pendingIntent(context, requestCode, text));
            context.getSharedPreferences("native_reminders", Context.MODE_PRIVATE).edit().remove(String.valueOf(requestCode)).apply();
        }

        private static PendingIntent pendingIntent(Context context, int requestCode, String text) {
            Intent i = new Intent(context, ReminderReceiver.class);
            i.putExtra(ReminderReceiver.EXTRA_TEXT, text == null ? "" : text);
            i.putExtra(ReminderReceiver.EXTRA_ID, requestCode);
            return PendingIntent.getBroadcast(context, requestCode, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }

        private static int stableId(String source, String date, String time, String reminder, String text) {
            String key = String.valueOf(source) + "|" + String.valueOf(date) + "|" + String.valueOf(time) + "|" + String.valueOf(reminder) + "|" + String.valueOf(text);
            return key.hashCode() & 0x7fffffff;
        }

        private static long calculateTrigger(String date, String time, String reminder) {
            return BootReceiver.trigger(date, time, reminder);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
