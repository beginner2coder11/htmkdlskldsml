package de.wochen.plusx;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

public final class NotificationHelper {
    private NotificationHelper() {}
    public static final String CHANNEL_ID = "reminders";

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Erinnerungen",
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Erinnerungen aus 4.000 WOCHEN Plus X");
            nm.createNotificationChannel(channel);
        }
    }
}
