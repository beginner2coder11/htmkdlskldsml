package de.wochen.plusx;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "reminders";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_ID = "id";

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationHelper.createChannel(context);
        String text = intent.getStringExtra(EXTRA_TEXT);
        if (text == null || text.trim().isEmpty()) text = "Du hast eine Erinnerung.";
        int id = intent.getIntExtra(EXTRA_ID, (int)(System.currentTimeMillis() & 0x7fffffff));

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(
                context, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("4.000 WOCHEN Plus X")
                .setContentText("Erinnerung: " + text)
                .setStyle(new Notification.BigTextStyle().bigText("Erinnerung: " + text))
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            nm.notify(id, builder.build());
        }
    }
}
