package de.wochen.plusx;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
    private static final String PREFS = "native_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) &&
            !Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) return;
        NotificationHelper.createChannel(context);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
            if (!(e.getValue() instanceof String)) continue;
            String[] v = ((String)e.getValue()).split("\\|", -1);
            if (v.length < 5) continue;
            long trigger = trigger(v[1], v[2], v[3]);
            if (trigger <= System.currentTimeMillis()) continue;
            int id = Integer.parseInt(e.getKey());
            Intent ri = new Intent(context, ReminderReceiver.class);
            ri.putExtra(ReminderReceiver.EXTRA_TEXT, v[4]);
            ri.putExtra(ReminderReceiver.EXTRA_ID, id);
            PendingIntent pi = PendingIntent.getBroadcast(context, id, ri, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    static long trigger(String date, String time, String reminder) {
        Calendar base = Calendar.getInstance();
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(date + " " + time);
            if (d == null) return 0;
            base.setTime(d);
        } catch (ParseException e) { return 0; }
        if ("yearly".equals(reminder)) {
            Calendar target = Calendar.getInstance();
            target.set(Calendar.MONTH, base.get(Calendar.MONTH));
            target.set(Calendar.DAY_OF_MONTH, base.get(Calendar.DAY_OF_MONTH));
            target.set(Calendar.HOUR_OF_DAY, base.get(Calendar.HOUR_OF_DAY));
            target.set(Calendar.MINUTE, base.get(Calendar.MINUTE));
            target.set(Calendar.SECOND, 0); target.set(Calendar.MILLISECOND, 0);
            if (target.getTimeInMillis() <= System.currentTimeMillis()) target.add(Calendar.YEAR, 1);
            return target.getTimeInMillis();
        }
        int minutes = "1h".equals(reminder) ? 60 : "10m".equals(reminder) ? 10 : "1d".equals(reminder) ? 1440 : "3d".equals(reminder) ? 4320 : "1w".equals(reminder) ? 10080 : 0;
        base.add(Calendar.MINUTE, -minutes);
        return base.getTimeInMillis();
    }
}
