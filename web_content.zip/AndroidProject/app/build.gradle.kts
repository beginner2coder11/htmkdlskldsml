plugins { id("com.android.application") }

android {
    namespace = "de.wochen.plusx"
    compileSdk = 36

    defaultConfig {
        applicationId = "de.wochen.plusx"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "1.3"
    }
}
