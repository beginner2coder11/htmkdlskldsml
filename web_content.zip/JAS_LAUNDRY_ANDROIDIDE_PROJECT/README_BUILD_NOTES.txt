Build notes
===========
Project: JAS Laundry Room
Android application id: com.jaslaundry.room
Minimum Android: 6.0 (API 23)
Compile / target SDK: 35
Java: 17
Android Gradle Plugin: 8.6.1
Expected Gradle: 8.7

Open the folder containing settings.gradle in AndroidIDE and allow Gradle sync. This package intentionally contains project source, not a precompiled APK. The current environment did not have Android SDK/Gradle installed, so a device APK build could not be executed here.
