JAS LAUNDRY ROOM - ANDROIDIDE PROJECT

ഈ ZIP ഒരു Android Studio / AndroidIDE Gradle project ആണ്. ഇതിൽ നിലവിലുള്ള JAS Laundry Room HTML app Android WebView-ൽ തുറക്കുന്നതിനുള്ള wrapper ചേർത്തിരിക്കുന്നു.

പ്രധാനമായി ഉൾപ്പെടുത്തിയിരിക്കുന്നത്:
- app/src/main/assets/index.html : നിലവിലുള്ള JAS Laundry Room HTML app
- Java Android WebView launcher
- JavaScript + DOM storage (local app data)
- Internet access (Firebase / online libraries)
- WhatsApp / external website links തുറക്കാനുള്ള support
- window.open / bill preview popup support
- WebView print support
- File picker support

ANDROIDIDE-ൽ BUILD ചെയ്യാനുള്ള ഘട്ടങ്ങൾ:
1. ZIP extract ചെയ്യുക.
2. AndroidIDE തുറക്കുക.
3. Open Project തിരഞ്ഞെടുക്കുക.
4. Extract ചെയ്ത JAS_LAUNDRY_ANDROIDIDE_PROJECT ഫോൾഡർ തിരഞ്ഞെടുക്കുക (അതിനകത്തെ settings.gradle കാണുന്ന root folder).
5. Gradle sync പൂർത്തിയാകാൻ കാത്തിരിക്കുക. Internet വേണം; ആദ്യ sync-ൽ Gradle / Android Gradle Plugin download ചെയ്യും.
6. SDK Manager-ൽ Android SDK Platform 35 ഇൻസ്റ്റാൾ ചെയ്തിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.
7. Build menu → Assemble Debug / Build APK തിരഞ്ഞെടുക്കുക.
8. APK സാധാരണയായി app/build/outputs/apk/debug/app-debug.apk എന്ന പാതയിൽ ലഭിക്കും.

പ്രധാന കുറിപ്പുകൾ:
- ഈ പരിതസ്ഥിതിയിൽ Android SDK/Gradle build നടക്കാത്തതിനാൽ APK ഇവിടെ compile ചെയ്ത് പരിശോധിച്ചിട്ടില്ല. ഇത് AndroidIDE-യിൽ തുറന്ന് build ചെയ്യാനുള്ള project source ആണ്.
- Firebase Cloud Sync പ്രവർത്തിക്കാൻ നിങ്ങളുടെ Firebase Web App config, Email/Password Authentication, Firestore Rules എന്നിവ ശരിയായിരിക്കണം. Firebase Authorized Domains-ൽ appassets.androidplatform.net ചേർക്കേണ്ടിവരും; ഈ project file:// origin ആണ് ഉപയോഗിക്കുന്നത്, അതിനാൽ Firebase Auth/Firestore ഉപയോഗിച്ച് യഥാർത്ഥ device-ൽ പരിശോധന നിർബന്ധമാണ്.
- HTML-ലെ existing data localStorage-ൽ ആണ്. App data clear ചെയ്യുകയോ uninstall ചെയ്യുകയോ ചെയ്താൽ local-only records നഷ്ടപ്പെടാം. ആദ്യം Backup എടുക്കുക.
- Attendance, Payroll tabs Owner login-ൽ മാത്രമാണ് കാണിക്കുന്നത്. Staff login-ന് അവ കാണിക്കാത്തത് access control ആണ്. Staff punch-in/out flow login/logout സമയത്ത് ലഭ്യമാകണം.
- Sunday auto Weekly Off ഇല്ല. Owner ഓരോ യഥാർത്ഥ അവധി ദിവസവും Weekly Off ആയി രേഖപ്പെടുത്തണം.
- Working Hours ഓരോ Staff account-നും പ്രത്യേകം edit ചെയ്യാം.
