# No custom shrinking rules are required for this WebView-only application.
