
const DB_KEY='afz_v2';
const STORAGE_KEY='afz_v2_local';
const emptyDB={stock:[],products:[],sales:[],customers:[],expenses:[],deliveryDocs:[],credits:[],checks:[],prices:{},priceSections:['عام'],priceSectionMap:{}};
let db=loadLocal();
// تهيئة البيانات بدون إنشاء سجلات جديدة عند كل تشغيل.
function normalizeSavedData(){
 if(!db||typeof db!=='object') db=structuredClone(emptyDB);
 if(!Array.isArray(db.products)) db.products=[];
 if(!Array.isArray(db.stock)) db.stock=[];
 if(!Array.isArray(db.sales)) db.sales=[];
 if(!Array.isArray(db.customers)) db.customers=[];
 if(!Array.isArray(db.priceSections)||!db.priceSections.length) db.priceSections=['عام'];
 if(!db.priceSectionMap||typeof db.priceSectionMap!=='object'||Array.isArray(db.priceSectionMap)) db.priceSectionMap={};
 if(!Array.isArray(db.credits)) db.credits=[];
 if(!Array.isArray(db.checks)) db.checks=[];
 if(!db.prices || Array.isArray(db.prices) || typeof db.prices!=='object') db.prices={};
 if(!db.priceRefs || typeof db.priceRefs!=='object' || Array.isArray(db.priceRefs)) db.priceRefs={};
 if(!db.purchasePrices || typeof db.purchasePrices!=='object' || Array.isArray(db.purchasePrices)) db.purchasePrices={};
 if(!db.discountPrices || Array.isArray(db.discountPrices) || typeof db.discountPrices!=='object') db.discountPrices={};
 // دمج المنتجات التي تحمل الاسم نفسه، مع إزالة تكرار الأرقام فقط.
 const merged=new Map();
 db.products.forEach(p=>{
   const name=String(p?.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   const nums=Array.isArray(p.numbers)?p.numbers.map(x=>String(x||'').trim()).filter(Boolean):[];
   let cur=merged.get(key);
   if(!cur){cur={...p,name,image:p.image||'',numbers:[]};merged.set(key,cur);}
   else if(!cur.image && p.image) cur.image=p.image;
   const seen=new Set(cur.numbers.map(x=>String(x).toLowerCase()));
   nums.forEach(n=>{const k=n.toLowerCase();if(!seen.has(k)){seen.add(k);cur.numbers.push(n);}});
 });
 db.products=[...merged.values()];
 // لا تسمح priceRefs بتكرار الرقم لنفس المنتج.
 Object.keys(db.priceRefs).forEach(pid=>{
   const refs=Array.isArray(db.priceRefs[pid])?db.priceRefs[pid]:[]; const seen=new Set();
   db.priceRefs[pid]=refs.map(x=>String(x||'').trim()).filter(x=>{const k=x.toLowerCase();if(!x||seen.has(k))return false;seen.add(k);return true;});
 });
}
normalizeSavedData();
function el(id){return document.getElementById(id)}
function loadLocal(){try{const x=localStorage.getItem(STORAGE_KEY);const dbx=x?JSON.parse(x):structuredClone(emptyDB);try{if(window.AndroidExpenses&&typeof AndroidExpenses.loadExpenses==='function'){const raw=AndroidExpenses.loadExpenses();if(raw){const ex=JSON.parse(raw);if(Array.isArray(ex))dbx.expenses=ex;}}}catch(e){}return dbx}catch(e){return structuredClone(emptyDB)}}
function saveLocal(){localStorage.setItem(STORAGE_KEY,JSON.stringify(db));try{if(window.AndroidExpenses&&typeof AndroidExpenses.saveExpenses==='function')AndroidExpenses.saveExpenses(JSON.stringify(Array.isArray(db.expenses)?db.expenses:[]));}catch(e){}}
function money(n){return (Number(n)||0).toFixed(2)+' DH'}
function clearQuickSaleSearchFields(){
 const name=el('quickSaleName'), ref=el('quickSaleRef');
 if(name)name.value='';
 if(ref)ref.value='';
 const np=el('quickSaleNamePicker'), rp=el('quickSaleRefPicker');
 if(np)np.style.display='none';
 if(rp)rp.style.display='none';
}
function show(id){
 if(id!=='sales')clearQuickSaleSearchFields();
 document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));el(id).classList.add('active');const titles={home:'الرئيسية',products:'المنتوجات',stock:'المخزون',prices:'الأسعار',sales:'المبيعات',customers:'الزبائن',delivery:'وصل التسليم',expenses:'مصاريف اليوم',credit:'الكريدي',checks:'دفتر الشيكات',notifications:'الإشعارات',reports:'التقارير',backup:'نسخة احتياطية'};document.body.classList.toggle('single-section',id!=='home');if(el('sectionTitle'))el('sectionTitle').textContent=titles[id]||'';render()}
async function compressImage(file){if(!file)return '';return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const max=800,scale=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',0.72))};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
function normalizeProductName(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,' ')}
function stockCatalogId(name){return 'stockcat:'+normalizeProductName(name);}
function stockCatalogProducts(){
 const groups=new Map();
 // تبدأ قائمة العرض من المنتجات المسجلة في الأسعار/المنتوجات، وليس من المخزون فقط.
 (db.products||[]).forEach(p=>{
   const name=String(p.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   groups.set(key,{id:p.id,name:p.name,image:p.image||'',numbers:getPriceOnlyRefs(p.id)});
 });
 // قسم الأسعار هو المصدر الوحيد للاسم والرقم والصورة. لا ننشئ أي منتوج من المخزون.
 return [...groups.values()].map(p=>({...p,numbers:sortNumbersAscending(p.numbers)}));
}
function syncProductsFromStock(){
 // لا نسمح للمخزون بإنشاء أسماء أو أرقام أو صور جديدة. المرجع الوحيد هو قسم الأسعار.
 if(!Array.isArray(db.products)) db.products=[];
 return db.products;
}
function getCatalogProduct(id){
 syncProductsFromStock();
 return (db.products||[]).find(x=>String(x.id)===String(id))||null;
}
function getCatalogProductByName(name){
 const q=normalizeProductName(name); syncProductsFromStock();
 return (db.products||[]).find(x=>normalizeProductName(x.name)===q)||null;
}
function getCatalogProductByRef(ref){
 const q=String(ref||'').trim().toLowerCase(); if(!q)return null; syncProductsFromStock();
 return (db.products||[]).find(p=>getPriceOnlyRefs(p.id).some(n=>String(n).trim().toLowerCase()===q))||null;
}
function productNumbers(p){
 if(!p)return [];
 return sortNumbersAscending(Array.isArray(p.numbers)?p.numbers:[]);
}
function getCatalogRefsForName(name){const p=getCatalogProductByName(name);return p?productNumbers(p):[];}
function isCatalogRefForProduct(productId,ref){const p=getCatalogProduct(productId);const q=String(ref||'').trim().toLowerCase();return !!p && getPriceOnlyRefs(p.id).some(n=>String(n).trim().toLowerCase()===q);}
function syncCatalogLinks(){
 syncProductsFromStock();
}
function stockNameRegistry(){
 const groups=new Map();
 (db.products||[]).forEach(p=>{
   const name=String(p.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   const refs=getPriceOnlyRefs(p.id);
   if(!groups.has(key)) groups.set(key,{name:p.name,image:p.image||'',refs:[]});
   const g=groups.get(key);
   refs.forEach(ref=>{if(ref&&!g.refs.some(x=>x.toLowerCase()===String(ref).toLowerCase()))g.refs.push(String(ref));});
 });
 return [...groups.values()].map(g=>({...g,refs:sortNumbersAscending(g.refs)})).sort((a,b)=>a.name.localeCompare(b.name,'ar',{numeric:true,sensitivity:'base'}));
}
function renderStockNameRegistry(){
 const box=el('stockNameRegistry'); if(!box)return;
 const groups=stockNameRegistry();
 box.innerHTML=groups.length?`<div style="overflow-x:auto"><table class="stock-accounting-table"><thead><tr><th>اسم المنتوج</th><th>الأرقام المسجلة</th></tr></thead><tbody>${groups.map(g=>`<tr><td><b>${esc(g.name)}</b></td><td>${g.refs.length?g.refs.map(r=>`<span class="product-number-chip">${esc(r)}</span>`).join(' '):'-'}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد أسماء مسجلة في المخزون بعد</div>';
}
function toggleStockNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('pname');
 if(input && input.dataset.stockNameMode==='new' && !input.readOnly){
   input.focus();
   return;
 }
 openStockNamePicker(true);
}
function getStockSearchNames(){
 return [...new Set((db.stock||[]).map(x=>String(x.name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'}));
}
function openStockSearchNamePicker(){
 const box=el('stockSearchNamePicker'); if(!box)return;
 const q=normalizeProductName(el('stockNameSearch')?.value||'');
 const names=getStockSearchNames().filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=names.length?names.map(n=>`<button type="button" class="search-picker-item stock-search-name-option" data-stock-search-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء مسجلة</div>';
 box.style.display='block';
}
function filterStockSearchNamePicker(){openStockSearchNamePicker();}
function toggleStockSearchNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const box=el('stockSearchNamePicker');
 if(box && box.style.display==='block'){box.style.display='none';return;}
 openStockSearchNamePicker();
}
function resetStockSearchNumber(){
 const name=String(el('stockNameSearch')?.value||'').trim();
 const ref=el('stockSearch');
 if(ref){
   const valid=getStockRefsForName(name).some(r=>String(r)===String(ref.value||'').trim());
   if(!valid) ref.value='';
 }
 renderStockSearchOptions();
}
function openStockSearchPicker(){
 const box=el('stockSearchPicker'); if(!box)return;
 const name=String(el('stockNameSearch')?.value||'').trim();
 if(!name){
   box.innerHTML='<div class="search-picker-empty">اختر اسم المنتوج أولاً</div>';
   box.style.display='block'; return;
 }
 const q=String(el('stockSearch')?.value||'').trim().toLowerCase();
 const refs=getStockRefsForName(name).filter(r=>!q||r.toLowerCase().includes(q));
 box.innerHTML=refs.length?refs.map(r=>`<button type="button" class="search-picker-item stock-search-option" data-stock-search-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أرقام لهذا الاسم</div>';
 box.style.display='block';
}
function filterStockSearchPicker(){openStockSearchPicker();}
function toggleStockSearchPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const box=el('stockSearchPicker');
 if(box && box.style.display==='block'){box.style.display='none';return;}
 openStockSearchPicker();
}
function openStockNamePicker(showAll=false){
 const box=el('stockNamePicker'); if(!box)return;
 const input=el('pname');
 if(input){input.dataset.stockNameMode='existing';input.readOnly=true;}
 renderStockProductOptions();
 const q=showAll?'':normalizeProductName(input?.value||'');
 const names=stockNameRegistry().map(g=>g.name).filter(n=>!q||normalizeProductName(n).includes(q));
 const items=names.length?names.map(n=>`<button type="button" data-stock-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء مطابقة</div>';
 box.innerHTML=`<div class="stock-name-choice"><b>المنتوجات المسجلة في قسم الأسعار</b></div>${items}`;
 box.style.display='block';
}
function filterStockNamePicker(){openStockNamePicker(); renderStockRefOptions();}
function selectStockName(name){
 const input=el('pname');
 if(input){input.value=name||'';input.readOnly=true;input.dataset.stockNameMode='existing';}
 const box=el('stockNamePicker'); if(box)box.style.display='none';
 const ref=el('pref');
 if(ref){ref.value='';ref.readOnly=true;ref.dataset.stockRefMode='existing';ref.placeholder='اختر رقم المنتوج';}
 renderStockRefOptions();
 openStockRefPicker();
 updateStockQtyMode();
 updateStockImageMode();
}
function openStockRefPicker(){
 const box=el('stockRefPicker'); if(!box)return;
 const name=String(el('pname')?.value||'').trim();
 if(!name || (el('pname')?.dataset.stockNameMode!=='existing')){
   box.innerHTML='<div class="search-picker-empty">اختر اسم المنتوج أولاً</div>';
   box.style.display='block';
   return;
 }
 const q=String(el('pref')?.value||'').trim().toLowerCase();
 const priceProduct=getCatalogProductByName(name);
 const priceRefs=priceProduct?getPriceOnlyRefs(priceProduct.id):[];
 const filtered=priceRefs.filter(r=>!q||r.toLowerCase().includes(q));
 box.innerHTML=`<div class="small" style="padding:6px 8px">الأرقام ذات الأثمان المسجلة لـ <b>${esc(name)}</b></div>`+
   (filtered.length ? filtered.map(r=>`<button type="button" class="search-picker-item" data-stock-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join('') : '<div class="search-picker-empty">لا توجد أرقام مسعّرة لهذا الاسم</div>');
 box.style.display='block';
}
function filterStockRefPicker(){openStockRefPicker();}
function getStockRefsForName(name){
 const p=getCatalogProductByName(name);
 if(!p)return [];
 return sortNumbersAscending(getPriceOnlyRefs(p.id));
}
document.addEventListener('click',function(e){
 const sn=e.target.closest('[data-stock-search-name]');
 if(sn){e.preventDefault();e.stopPropagation();const name=sn.getAttribute('data-stock-search-name')||'';if(el('stockNameSearch'))el('stockNameSearch').value=name;if(el('stockSearch'))el('stockSearch').value='';const nb=el('stockSearchNamePicker');if(nb)nb.style.display='none';openStockSearchPicker();render();return;}
 const sr=e.target.closest('[data-stock-search-ref]');
 if(sr){e.preventDefault();e.stopPropagation();if(el('stockSearch'))el('stockSearch').value=sr.getAttribute('data-stock-search-ref')||'';const b=el('stockSearchPicker');if(b)b.style.display='none';render();return;}
 const n=e.target.closest('[data-stock-name]');
 if(n){e.preventDefault();selectStockName(n.getAttribute('data-stock-name')||'');return;}
 const addNew=e.target.closest('[data-stock-new-name]');
 if(addNew){
   e.preventDefault();
   alert('لا يمكن إضافة اسم منتوج من المخزون. أضفه أولاً من قسم الأسعار.');
   return;
   const input=el('pname');
   if(input){input.readOnly=false;input.value='';input.removeAttribute('list');input.placeholder='اكتب اسم المنتوج الجديد';input.setAttribute('data-stock-name-mode','new');input.focus();}
   const box=el('stockNamePicker'); if(box)box.style.display='none';
   const ref=el('pref');
   if(ref){ref.value='';ref.readOnly=false;ref.dataset.stockRefMode='new';ref.placeholder='اكتب رقم المنتوج الجديد';}
   const rb=el('stockRefPicker'); if(rb)rb.style.display='none';
   updateStockQtyMode();
   updateStockImageMode();
   return;
 }
 const newRef=e.target.closest('[data-stock-new-ref]');
 if(newRef){
   e.preventDefault(); e.stopPropagation();
   alert('لا يمكن إضافة رقم جديد من المخزون. سجّل الرقم وثمنه أولاً من قسم الأسعار.');
   return;
 }
 const r=e.target.closest('[data-stock-ref]');
 if(r){
   e.preventDefault(); e.stopPropagation();
   const ref=el('pref');
   if(ref){ref.value=r.getAttribute('data-stock-ref')||'';ref.readOnly=true;ref.dataset.stockRefMode='existing';}
   const b=el('stockRefPicker');if(b)b.style.display='none';
   updateStockQtyMode();
 }
});

document.addEventListener('change',function(e){
 if(e.target && e.target.id==='stockImage') previewStockImage();
 if(e.target && e.target.id==='priceProductImage') previewPriceProductImage();
});

function renderStockProductOptions(){
 const dl=el('stockProductNames');
 if(dl){const names=stockNameRegistry().map(g=>g.name);dl.innerHTML=names.map(name=>`<option value="${esc(name)}"></option>`).join('');}
}
function fillStockProduct(){ return true; }
function renderStockRefOptions(selected=''){ return true; }
function validateCatalogStockRef(){ return true; }
function parseProductNumbers(value){
 return sortNumbersAscending(String(value||'').split(/[\/,،;\s]+/).map(x=>x.trim()).filter(Boolean));
}
async function addProduct(e){
 e.preventDefault();
 return alert('إضافة المنتوجات مسموحة فقط من قسم الأسعار.');
 const name=el('productName').value.trim();
 if(!name)return alert('أدخل اسم المنتوج');
 const numbers=parseProductNumbers(el('productNumbers').value);
 const existing=(db.products||[]).find(x=>normalizeProductName(x.name)===normalizeProductName(name));
 if(existing){
   existing.numbers=sortNumbersAscending([...(existing.numbers||[]),...numbers]);
   if(el('productImage').files[0]) existing.image=await compressImage(el('productImage').files[0]);
   save();e.target.reset();renderProductSection();renderProductNamePicker();renderProductSearchResult();
   return alert('تم تحديث المنتوج وإضافة الأرقام الجديدة');
 }
 let image='';
 try{image=await compressImage(el('productImage').files[0]);}catch(err){return alert('تعذر حفظ الصورة. جرّب صورة أصغر.');}
 db.products.push({id:Date.now()+Math.floor(Math.random()*1000),name,image,numbers});
 try{save();e.target.reset();renderProductSection();renderProductNamePicker();renderProductSearchResult();alert('تم حفظ المنتوج بنجاح');}catch(err){alert('تعذر حفظ المنتوج: '+err.message);}
}
function editProduct(id){
 return alert('تعديل اسم أو صورة المنتوج مسموح فقط من قسم الأسعار.');
 /*
 const p=db.products.find(x=>String(x.id)===String(id));if(!p)return;
 const name=prompt('اسم المنتوج:',p.name||'');if(name===null)return;
 if(!name.trim())return alert('أدخل اسم المنتوج');
 const nums=prompt('أرقام/مراجع المنتوج (مثال: A12 / B13 / 14C):',productNumbers(p).join(' / '));if(nums===null)return;
 const cleanName=name.trim();
 const duplicate=db.products.some(x=>String(x.id)!==String(id)&&normalizeProductName(x.name)===normalizeProductName(cleanName));
 if(duplicate)return alert('اسم المنتوج موجود بالفعل');
 p.name=cleanName;p.numbers=parseProductNumbers(nums);
 (db.stock||[]).forEach(st=>{if(String(st.productId)===String(id)){st.name=p.name;if(p.image)st.image=p.image;}});
 (db.sales||[]).forEach(s=>(s.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 (db.deliveryDocs||[]).forEach(d=>(d.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 save();renderProductSection();renderProductNamePicker();renderProductSearchResult();alert('تم تعديل المنتوج بنجاح');
 */
}
function deleteProduct(id){
 const linked=(db.stock||[]).some(x=>String(x.productId)===String(id));
 if(linked){alert('لا يمكن حذف المنتوج لأنه مرتبط بالمخزون. احذف أسطره من المخزون أولاً.');return;}
 if(!confirm('حذف هذا المنتوج وأرقامه؟'))return;
 db.products=db.products.filter(x=>String(x.id)!==String(id));
 delete db.prices[String(id)];
 save();renderProductSection();renderProductNamePicker();renderProductSearchResult();
}
function productCardHtml(p){
 const nums=productNumbers(p);
 const rows=(db.stock||[]).filter(st=>String(st.productId)===String(p.id)||normalizeProductName(st.name)===normalizeProductName(p.name));
 const qty=rows.reduce((sum,st)=>sum+Number(st.qty||0),0);
 const total=rows.reduce((sum,st)=>{const buy=Number(st.buy||((db.prices||{})[String(p.id)]||{}).buy||0);return sum+(Number(st.qty||0)*buy)},0);
 const refs=nums.length?nums.join('، '):'—';
 return `<div class="product-card product-identity-card" onclick="selectProductFromCard('${esc(String(p.id))}')">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name)}">`:'<div class="noimg">🛍️</div>'}<div class="identity-title">${esc(p.name||'')}</div><div class="identity-row"><span>رقم المنتوج</span><b>${esc(refs)}</b></div><div class="identity-row"><span>عدد المنتوج</span><b>${qty}</b></div><div class="identity-total"><span>مجموع الثمن</span><b>${money(total)}</b></div></div>`;
}
function resetProductNumberSearch(){
 const n=el('productNumberSearch'); if(n)n.value='';
 renderProductNumberPicker();
}
function productPriceRows(){
 const groups=new Map();
 (db.stock||[]).forEach(st=>{
   const p=getCatalogProduct(st.productId)||getCatalogProductByName(st.name);
   const name=p?.name||st.name||''; const ref=st.ref||'';
   const key=(p?.id||name)+'::'+ref;
   const priceObj=(db.prices||{})[String(p?.id||'')]||{};
   const buy=Number(st.buy ?? priceObj.buy ?? 0);
   const sale=Number(st.sale ?? priceObj.sale ?? 0);
   groups.set(key,{name,ref,buy,sale});
 });
 (db.products||[]).forEach(p=>{
   const po=(db.prices||{})[String(p.id)]||{};
   productNumbers(p).forEach(ref=>{const key=String(p.id)+'::'+ref;if(!groups.has(key))groups.set(key,{name:p.name||'',ref,buy:Number(po.buy||0),sale:Number(po.sale||0)});});
 });
 return [...groups.values()].sort((a,b)=>a.name.localeCompare(b.name,'ar',{numeric:true})||sortNumbersAscending([a.ref,b.ref]).indexOf(a.ref)-sortNumbersAscending([a.ref,b.ref]).indexOf(b.ref));
}
function renderAllProductPrices(){
 const box=el('allProductPrices'); if(!box)return;
 const qn=(el('productNameSearch')?.value||'').trim().toLowerCase();
 const qr=(el('productNumberSearch')?.value||'').trim().toLowerCase();
 const rows=productPriceRows().filter(x=>(!qn||x.name.toLowerCase().includes(qn))&&(!qr||x.ref.toLowerCase().includes(qr)));
 const groups=new Map();
 rows.forEach(x=>{const key=normalizeProductName(x.name);if(!groups.has(key))groups.set(key,{name:x.name,rows:[]});groups.get(key).rows.push(x);});
 box.innerHTML=groups.size?[...groups.values()].map(g=>`<div class="product-price-group">
   <div class="product-price-group-title">💰 ${esc(g.name)}</div>
   <div class="price-table-wrap"><table class="price-table"><thead><tr><th>رقم المنتوج</th><th>ثمن الشراء</th><th>ثمن البيع</th></tr></thead><tbody>${g.rows.map(x=>`<tr><td><b>${esc(x.ref||'-')}</b></td><td>${money(x.buy)}</td><td>${money(x.sale)}</td></tr>`).join('')}</tbody></table></div>
 </div>`).join(''):'<div class="empty" style="padding:12px">لا توجد أثمان مسجلة</div>';
}
function renderProductSection(){
 renderProducts();
 renderAllProductPrices();
 renderProductSearchResult();
}
function renderProducts(){
 const list=el('productsList');if(!list)return;
 syncCatalogLinks();
 const nameQ=(el('productNameSearch')?.value||'').trim().toLowerCase();
 const refQ=(el('productNumberSearch')?.value||'').trim().toLowerCase();
 let rows=(db.products||[]).filter(p=>(!nameQ||String(p.name||'').toLowerCase().includes(nameQ))&&(!refQ||productNumbers(p).some(r=>r.toLowerCase().includes(refQ))));
 // عند اختيار اسم محدد لا نعرض أي منتوج آخر. وعند اختيار الرقم نعرض صاحب الرقم فقط.
 if(nameQ){
   const exact=(db.products||[]).filter(p=>normalizeProductName(p.name)===normalizeProductName(el('productNameSearch')?.value||''));
   if(exact.length) rows=exact.filter(p=>!refQ||productNumbers(p).some(r=>r.toLowerCase().includes(refQ)));
 }
 if(refQ){
   rows=rows.filter(p=>productNumbers(p).some(r=>r.toLowerCase().includes(refQ)));
 }
 list.innerHTML=rows.length?'<div class="product-grid">'+rows.map(productCardHtml).join('')+'</div>':'<div class="empty">لا توجد نتائج للمنتوج المحدد</div>';
 renderProductNamePicker();
}
function renderProductNamePicker(){
 const box=el('productNamePicker');if(!box)return;
 const names=[...new Map((db.products||[]).map(p=>[normalizeProductName(p.name),p.name])).values()].sort((a,b)=>a.localeCompare(b,'ar',{numeric:true}));
 box.innerHTML=names.length?names.map(n=>`<button type="button" onclick="chooseProductName('${esc(n).replace(/'/g,"\\'")}')">${esc(n)}</button>`).join(''):'<div class="empty">لا توجد أسماء مسجلة</div>';
}
function openProductNamePicker(){renderProductNamePicker();const b=el('productNamePicker');if(b)b.style.display='block';filterProductNamePicker();}
function filterProductNamePicker(){
 const q=(el('productNameSearch')?.value||'').trim().toLowerCase(),b=el('productNamePicker');if(!b)return;
 [...b.querySelectorAll('button')].forEach(x=>x.style.display=(!q||x.textContent.toLowerCase().includes(q))?'block':'none');b.style.display='block';
}
function chooseProductName(name){
 el('productNameSearch').value=name;el('productNumberSearch').value='';
 const b=el('productNamePicker');if(b)b.style.display='none';
 renderProductNumberPicker();renderProductSearchResult();
}
function selectedProductForSearch(){
 const name=(el('productNameSearch')?.value||'').trim();
 return (db.products||[]).find(p=>normalizeProductName(p.name)===normalizeProductName(name))||null;
}
function renderProductNumberPicker(){
 const box=el('productNumberPicker');if(!box)return;
 const p=selectedProductForSearch();
 const nums=p?productNumbers(p):sortNumbersAscending((db.products||[]).flatMap(productNumbers));
 box.innerHTML=nums.length?nums.map(n=>`<button type="button" onclick="chooseProductNumber('${esc(n).replace(/'/g,"\\'")}')">${esc(n)}</button>`).join(''):'<div class="empty">لا توجد أرقام لهذا الاسم</div>';
}
function openProductNumberPicker(){renderProductNumberPicker();const b=el('productNumberPicker');if(b)b.style.display='block';filterProductNumberPicker();}
function filterProductNumberPicker(){
 const q=(el('productNumberSearch')?.value||'').trim().toLowerCase(),b=el('productNumberPicker');if(!b)return;
 [...b.querySelectorAll('button')].forEach(x=>x.style.display=(!q||x.textContent.toLowerCase().includes(q))?'block':'none');b.style.display='block';
}
function chooseProductNumber(number){el('productNumberSearch').value=number;const b=el('productNumberPicker');if(b)b.style.display='none';renderProductSearchResult();}
function selectProductFromCard(id){
 const p=getCatalogProduct(id);if(!p)return;
 el('productNameSearch').value=p.name||'';el('productNumberSearch').value='';renderProductNumberPicker();renderProductSearchResult();
 document.getElementById('productNameSearch')?.scrollIntoView({behavior:'smooth',block:'center'});
}
function renderProductSearchResult(){
 const box=el('productSearchResult');if(!box)return;
 const p=selectedProductForSearch();
 if(!p){box.innerHTML='<div class="empty">اختر اسماً من قائمة البحث.</div>';return;}
 const q=(el('productNumberSearch')?.value||'').trim();const nums=productNumbers(p);const filtered=q?nums.filter(n=>n.toLowerCase().includes(q.toLowerCase())):nums;
 box.innerHTML=`<div class="product-card" style="cursor:default">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name)}">`:''}<h4>${esc(p.name)}</h4><div class="meta">جميع الأرقام المسجلة لهذا الاسم</div><div class="product-numbers">${(filtered.length?filtered:nums).map(n=>`<span class="product-number-chip">${esc(n)}</span>`).join('')||'<span class="small">لا توجد أرقام</span>'}</div></div>`;
}

function sanitizeDigits(input){
  if(!input) return;
  const cleaned=String(input.value||'').replace(/[^0-9]/g,'');
  if(input.value!==cleaned) input.value=cleaned;
}

function updateStockQtyMode(){
 const label=el('pqtyLabel'), input=el('pqty'), hint=el('pqtyHint');
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim();
 const mode=el('pname')?.dataset.stockNameMode||'choose';
 let old=null;
 if(name && ref) old=(db.stock||[]).find(x=>normalizeProductName(x.name)===normalizeProductName(name)&&String(x.ref||'').trim().toLowerCase()===ref.toLowerCase());
 if(old){
   if(label) label.textContent='الكمية التي تريد إضافتها';
   if(input) input.placeholder='مثال: 10';
   if(hint) hint.innerHTML='الموجود حالياً: <b>'+Number(old.qty||0)+'</b> — اكتب فقط الكمية التي تريد إضافتها.';
 }else if(mode==='new'){
   if(label) label.textContent='الكمية الأولية للمنتوج الجديد';
   if(input) input.placeholder='مثال: 20';
   if(hint) hint.textContent='هذه هي الكمية التي سيبدأ بها المنتوج الجديد.';
 }else{
   if(label) label.textContent='الكمية التي تريد إضافتها';
   if(input) input.placeholder='شحال بغيت تزيد؟';
   if(hint) hint.textContent='اختر الاسم والرقم أولاً.';
 }
}
function updateStockImageMode(){
 const wrap=el('stockImageWrap');
 const input=el('stockImage');
 const preview=el('stockImagePreview');
 const mode=el('pname')?.dataset.stockNameMode||'choose';
 const show=mode==='new';
 if(wrap)wrap.style.display=show?'block':'none';
 if(!show){if(input)input.value='';if(preview){preview.innerHTML='';preview.style.display='none';}}
}
function previewStockImage(){
 const input=el('stockImage'),preview=el('stockImagePreview');
 if(!input||!preview)return;
 const file=input.files?.[0];
 if(!file){preview.innerHTML='';preview.style.display='none';return;}
 if(!file.type.startsWith('image/')){input.value='';preview.innerHTML='';preview.style.display='none';return alert('اختر صورة فقط.');}
 const r=new FileReader();
 r.onload=()=>{preview.innerHTML='<img src="'+r.result+'" alt="صورة المنتوج">';preview.style.display='block';};
 r.readAsDataURL(file);
}
function resetStockNameField(){
 const input=el('pname');
 if(input){input.value='';input.readOnly=true;input.dataset.stockNameMode='choose';input.placeholder='اختر منتوجًا مسجلًا في قسم الأسعار';}
 const box=el('stockNamePicker'); if(box)box.style.display='none';
 const ref=el('pref'); if(ref){ref.value='';ref.readOnly=true;ref.dataset.stockRefMode='choose';ref.placeholder='اختر رقم المنتوج';}
 const rb=el('stockRefPicker'); if(rb)rb.style.display='none';
 updateStockQtyMode();
 updateStockImageMode();
}
async function addStock(e){
 e.preventDefault();
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim();
 const qty=Number(el('pqty')?.value||0);
 if(!name)return alert('اختر منتوجًا مسجلًا في قسم الأسعار');
 if(!ref)return alert('اختر رقمًا مسجلًا لهذا المنتوج من قسم الأسعار');
 if(qty<=0)return alert('أدخل كمية صحيحة أكبر من صفر');
 const product=getCatalogProductByName(name);
 if(!product)return alert('هذا المنتوج غير مسجل في قسم الأسعار. أضفه أولاً إلى قسم الأسعار.');
 const pricedRefs=getPriceOnlyRefs(product.id);
 const refKey=ref.toLowerCase();
 const registeredRef=pricedRefs.find(r=>String(r).trim().toLowerCase()===refKey);
 if(!registeredRef)return alert('هذا الرقم لا يملك ثمنًا مسجلًا في قسم الأسعار. أضف الرقم وثمنه أولاً في قسم الأسعار.');
 const productId=String(product.id);
 const buy=getPurchasePriceForRef(product.id,registeredRef);
 if(!Number.isFinite(Number(buy)))return alert('تعذر جلب ثمن الشراء من قسم الأسعار');
 const image=product.image||'';
 const old=db.stock.find(x=>String(x.productId||'')===productId && String(x.ref||'').trim().toLowerCase()===refKey);
 if(old){old.productId=product.id;old.name=product.name;old.ref=registeredRef;old.qty=Number(old.qty||0)+qty;old.buy=Number(buy);old.image=image;}
 else db.stock.push({id:Date.now()+Math.floor(Math.random()*1000),productId:product.id,name:product.name,ref:registeredRef,qty,buy:Number(buy),image});
 syncStockPurchasePrices();
 syncProductsFromStock();
 try{save();e.target.reset();resetStockNameField();renderStockNameRegistry();renderProductCardsSearch();renderStockSearchOptions();alert('تمت إضافة الكمية. تم أخذ ثمن الشراء تلقائيًا من قسم الأسعار.')}catch(err){alert('تعذر حفظ المنتج: '+err.message)}
}
function switchSalesOperation(){
 const type=el('salesOperationType')?.value||'sale';
 const saleBox=el('salesOperationSale'), expenseBox=el('salesOperationExpense');
 if(saleBox)saleBox.style.display=type==='sale'?'block':'none';
 if(expenseBox)expenseBox.style.display=type==='expense'?'block':'none';
 if(type==='expense' && el('salesExpenseDate') && !el('salesExpenseDate').value)el('salesExpenseDate').value=todayISO();
}
function addSalesExpense(){
 const date=el('salesExpenseDate')?.value||todayISO();
 const name=String(el('salesExpenseName')?.value||'').trim();
 const amountText=String(el('salesExpenseAmount')?.value||'').trim().replace(',', '.');
 const amount=Number(amountText);
 if(!date)return alert('اختر التاريخ');
 if(!name)return alert('أدخل نوع المصروف');
 if(!amountText || !Number.isFinite(amount) || amount<0)return alert('أدخل مبلغاً صحيحاً');
 if(!Array.isArray(db.expenses))db.expenses=[];
 db.expenses.push({id:'exp_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),date:date+'T12:00:00',name,amount});
 save();
 if(el('salesExpenseName'))el('salesExpenseName').value='';
 if(el('salesExpenseAmount'))el('salesExpenseAmount').value='';
 if(el('salesExpenseDate'))el('salesExpenseDate').value=date;
 render();
 alert('تم حفظ المصروف بنجاح');
}

let saleCart=[];
function addToCart(e){
 e.preventDefault();
 const p=db.stock.find(x=>String(x.id)===String(el('saleProduct').value));
 const q=Number(el('saleQty').value), price=Number(el('salePrice').value);
 if(!p)return alert('اختر منتجًا');
 if(q<=0)return alert('الكمية غير صحيحة');
 const already=saleCart.filter(x=>String(x.productId)===String(p.id)).reduce((a,x)=>a+Number(x.qty||0),0);
 if(q+already>Number(p.qty||0))return alert('الكمية المطلوبة أكبر من المخزون المتوفر');
 if(price<0)return alert('السعر غير صحيح');
 const existing=saleCart.find(x=>String(x.productId)===String(p.id)&&Number(x.price)===price);
 if(existing){existing.qty+=q;existing.total=existing.qty*existing.price;existing.profit=(existing.price-existing.buyPrice)*existing.qty;} else saleCart.push({productId:p.id,name:p.name,ref:p.ref||'',qty:q,price:price,buyPrice:Number(p.buy||0),profit:(price-Number(p.buy||0))*q,total:q*price});
 el('saleQty').value='1'; renderCart();
}
function fillCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('saleCustomer').value));
 if(c){el('saleCustomerName').value=c.name||'';el('saleCustomerPhone').value=c.phone||'';}
 else {el('saleCustomerName').value='';el('saleCustomerPhone').value='';}
}
function removeCartItem(i){saleCart.splice(i,1);renderCart()}
function clearCart(){saleCart=[];renderCart()}
function renderCart(){
 const box=el('cartBox');
 if(!box)return;
 if(!saleCart.length){box.innerHTML='<div class="empty card">لم تتم إضافة منتجات إلى الفاتورة بعد.</div>';return;}
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 box.innerHTML='<div class="cart"><div class="badge">'+saleCart.length+' منتجات/أسطر</div><table><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>المجموع</th><th></th></tr>'+saleCart.map((x,i)=>'<tr><td>'+esc(x.name)+(x.ref?'<div class="small">'+esc(x.ref)+'</div>':'')+'</td><td>'+x.qty+'</td><td>'+money(x.price)+'</td><td>'+money(x.total)+'</td><td><button class="remove" onclick="removeCartItem('+i+')">حذف</button></td></tr>').join('')+'</table><div class="cart-total"><span>المجموع النهائي</span><span>'+money(total)+'</span></div></div>';
}
function finalizeSale(){
 if(!saleCart.length)return alert('أضف منتجًا واحدًا على الأقل');
 for(const item of saleCart){const p=db.stock.find(x=>String(x.id)===String(item.productId));if(!p||Number(item.qty)>Number(p.qty||0))return alert('المخزون غير كافٍ للمنتج: '+item.name);}
 const customerName=el('saleCustomerName').value.trim()||'زبون عابر';
 const customerPhone=el('saleCustomerPhone').value.trim();
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 saleCart.forEach(item=>{const p=db.stock.find(x=>String(x.id)===String(item.productId));p.qty-=Number(item.qty);});
 db.sales.push({id:Date.now(),date:new Date().toISOString(),customer:{name:customerName,phone:customerPhone},items:saleCart.map(x=>({...x})),total});
 save(); saleCart=[]; if(el('saleCustomer'))el('saleCustomer').value=''; if(el('saleCustomerName'))el('saleCustomerName').value=''; if(el('saleCustomerPhone'))el('saleCustomerPhone').value=''; if(el('saleQty'))el('saleQty').value='1'; renderCart(); alert('تم حفظ البيع بنجاح');
}
function saleItems(s){
 const raw=Array.isArray(s.items)?s.items:(s.name?[{name:s.name,ref:s.ref||'',qty:s.qty||0,price:s.price||0,total:s.total||0,productId:s.productId||''}]:[]);
 return raw.map(it=>{
   const p=getCatalogProduct(it.productId)||getCatalogProductByRef(it.ref);
   if(!p)return {...it};
   const wanted=String(it.ref||'').trim().toLowerCase();
   const ref=productNumbers(p).find(r=>String(r).trim().toLowerCase()===wanted)||it.ref||productNumbers(p)[0]||'';
   return {...it,productId:p.id,name:p.name,ref};
 });
}
function downloadLastSalePdf(){
 if(!db.sales.length){alert('لا توجد مبيعات لتحميلها');return;}
 const x=db.sales[db.sales.length-1],items=saleItems(x),customer=x.customer||{},date=x.date||new Date().toLocaleString('ar-MA'),total=Number(x.total||0);
 const rows=items.map((it,i)=>`<tr><td class="num">${i+1}</td><td>${esc(it.name||it.productName||'')}</td><td class="num">${Number(it.qty||it.quantity||1)}</td><td class="money">${money(it.price||it.salePrice||0)}</td><td class="money">${money((it.qty||it.quantity||1)*(it.price||it.salePrice||0))}</td></tr>`).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:24px 28px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:23px}.title div{margin-top:5px;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:12px;padding:12px;background:#fff}.customer-box{border:1.5px solid #0b4f8a;background:linear-gradient(180deg,#f7fbff 0%,#fff 100%)}.customer-head{display:flex;align-items:center;gap:7px;border-bottom:1px solid #dfe6ec;padding-bottom:7px;margin-bottom:8px;font-size:12px;font-weight:bold;color:#0b4f8a}.customer-icon{width:24px;height:24px;border-radius:50%;background:#0b4f8a;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:13px}.customer-name{font-size:17px;font-weight:700;line-height:1.35;margin-bottom:8px}.customer-row{font-size:12px;line-height:1.7;color:#33424f;margin-top:3px;word-break:break-word}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}
.monthly-summary-table th,.monthly-summary-table td{font-size:10px;padding:5px 4px;white-space:nowrap}.monthly-summary-table tfoot th{background:#eef4f8;font-weight:bold}.monthly-summary-wrap{overflow-x:auto}@media(max-width:520px){.monthly-summary-table{font-size:9px}.monthly-summary-table th,.monthly-summary-table td{font-size:8.5px;padding:4px 2px}}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table{width:100%!important;table-layout:fixed!important;border-collapse:collapse!important;font-size:11px!important;line-height:1!important;margin:0!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table tr{height:34px!important;max-height:34px!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{height:34px!important;min-height:34px!important;max-height:34px!important;padding:2px 3px!important;line-height:1!important;vertical-align:middle!important;text-align:center!important;white-space:nowrap!important;overflow:hidden!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th{font-size:9px!important;font-weight:700!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{font-size:11px!important;font-weight:400!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount-cell{font-size:11px!important;direction:ltr!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount{display:inline!important;font-size:11px!important;font-weight:700!important;line-height:1!important;white-space:nowrap!important;margin:0!important;padding:0!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-delete-one{display:inline-flex!important;width:22px!important;height:22px!important;min-width:22px!important;min-height:22px!important;padding:0!important;margin:0!important;align-items:center!important;justify-content:center!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(1),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(1){width:27%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(2),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(2){width:35%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(3),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(3){width:28%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(4),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(4){width:10%!important}
@media(max-width:520px){#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table tr,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{height:32px!important;min-height:32px!important;max-height:32px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th{font-size:8px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-delete-one{width:20px!important;height:20px!important;min-width:20px!important;min-height:20px!important;font-size:11px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div>الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br>AFRIQUIA FREINS ZEMAMRA</div></div>
</body></html>`;
 const name='Facture-'+formatDeliveryNumber(x.deliveryNumber||x.id||Date.now())+'.pdf'; if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function') AndroidPrint.savePdf(html,name); else {localStorage.setItem('__afriquia_pdf_html',html); location.href='afriquia://savepdf?name='+encodeURIComponent(name);}
}

function deliveryItemsTotal(items){return (items||[]).reduce((a,i)=>a+Number(i.total||Number(i.qty||1)*Number(i.price||0)),0)}
let currentDeliveryId=null;
let deliveryDraftItems=[];
function nextDeliveryNumber(){
 const docs=Array.isArray(db.deliveryDocs)?db.deliveryDocs:[];
 let max=0;
 docs.forEach(d=>{const n=String(d.deliveryNumber||'').match(/\d+/);if(n)max=Math.max(max,Number(n[0])||0);});
 return 'B'+String(max+1).padStart(4,'0');
}
function formatDeliveryNumber(value){
 const m=String(value||'').match(/\d+/);
 if(!m)return nextDeliveryNumber();
 return 'B'+String(Number(m[0])||0).padStart(4,'0');
}
function ensureDeliveryNumber(){
 const input=el('deliveryNumber');
 if(input && !currentDeliveryId && !String(input.value||'').trim()) input.value=nextDeliveryNumber();
}

function refreshDeliveryCustomers(selectedId=''){const s=el('deliveryCustomerSelect');if(!s)return;const customers=Array.isArray(db.customers)?db.customers:[];s.innerHTML='<option value="">اختر الزبون من قسم الزبائن</option>'+customers.map(c=>`<option value="${esc(String(c.id))}">${esc(c.name)}${c.phone?' — '+esc(c.phone):''}</option>`).join('');if(selectedId!==undefined)s.value=String(selectedId||'');}
function selectDeliveryCustomer(){const id=el('deliveryCustomerSelect')?.value;if(!id)return;const c=(db.customers||[]).find(x=>String(x.id)===String(id));if(!c)return;el('deliveryCustomerName').value=c.name||'';el('deliveryCustomerPhone').value=c.phone||'';}
function resetIndependentDelivery(){currentDeliveryId=null;deliveryDraftItems=[];if(el('deliveryCustomerSelect'))el('deliveryCustomerSelect').value='';if(el('deliveryCustomerName'))el('deliveryCustomerName').value='';if(el('deliveryCustomerPhone'))el('deliveryCustomerPhone').value='';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value='';if(el('deliveryNumber'))el('deliveryNumber').value='';if(el('deliveryDate')){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16)}renderDeliveryEditor();ensureDeliveryNumber()}
function renderDeliveryEditor(){
 syncCatalogLinks();
 refreshDeliveryCustomers(el('deliveryCustomerSelect')?.value||'');
 if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];
 deliveryDraftItems=deliveryDraftItems.map(i=>{const p=getCatalogProduct(i.productId)||getCatalogProductByRef(i.ref);if(!p)return i;const wanted=String(i.ref||'').trim().toLowerCase();const ref=productNumbers(p).find(r=>String(r).trim().toLowerCase()===wanted)||productNumbers(p)[0]||'';return {...i,productId:p.id,name:p.name,ref};});
 ensureDeliveryNumber();
 if(el('deliveryDate') && !el('deliveryDate').value){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16);}
 const select=el('deliveryProduct');
 if(select){select.innerHTML='<option value="">اختر المنتج والرقم من المخزون</option>'+db.stock.map(p=>{const c=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);const name=c?.name||p.name||'';const ref=p.ref||'';return `<option value="${p.id}">${esc(name)} ${ref?'— '+esc(ref):''}</option>`}).join('');}
 const box=el('deliveryItemsEditor'); if(box){const items=deliveryDraftItems;const total=deliveryItemsTotal(items);box.innerHTML='<h4 style="margin-top:0">منتجات الوصل</h4>'+(!items.length?'<div class="empty">لم تتم إضافة منتجات بعد</div>':'<table><tr><th>اسم</th><th>عدد</th><th>ثمن</th><th>المجموع</th><th></th></tr>'+items.map((i,n)=>`<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.price)}</td><td>${money(i.total)}</td><td><button type="button" class="remove" onclick="removeDeliveryItem(${n})">حذف</button></td></tr>`).join('')+'</table><div class="cart-total"><span>المجموع</span><b>'+money(total)+'</b></div>');}
 const list=el('deliveryList'); if(list){list.innerHTML='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3>الوصول المستقلة المحفوظة</h3><button type="button" onclick="resetIndependentDelivery()">➕ وصل جديد</button></div>'+(!db.deliveryDocs.length?'<div class="empty">لا توجد وصول محفوظة</div>':'<table><tr><th>رقم الوصل</th><th>الزبون</th><th>العنوان</th><th>التاريخ</th><th>المجموع</th><th></th></tr>'+db.deliveryDocs.slice().reverse().map(d=>`<tr><td>${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</td><td>${esc(d.customerName||'زبون عابر')}</td><td>${esc(d.customerAddress||'')}</td><td>${d.date?esc(new Date(d.date).toLocaleDateString('ar-MA')):'-'}</td><td>${money(deliveryItemsTotal(d.items))}</td><td><button type="button" onclick="editIndependentDelivery('${d.id}')">تحرير</button> <button type="button" onclick="previewIndependentDelivery('${d.id}')">👁️ معاينة</button> <button type="button" onclick="downloadIndependentDeliveryPdf('${d.id}')">⚡ PDF سريع</button></td></tr>`).join('')+'</table>')+'</div>';}}
function addDeliveryItem(){const sel=el('deliveryProduct');const p=sel?.value?db.stock.find(x=>String(x.id)===String(sel.value)):null;const catalog=p?(getCatalogProduct(p.productId)||getCatalogProductByName(p.name)):null;const name=catalog?.name||'';const ref=p?.ref||'';const qty=Number(el('deliveryProductQty').value||0);const price=Number(el('deliveryProductPrice').value||0);if(!p||!catalog)return alert('اختر المنتج من المخزون');if(!ref||!isCatalogRefForProduct(catalog.id,ref))return alert('رقم المنتج غير مرتبط بقسم المنتوجات');if(qty<=0)return alert('أدخل العدد');if(price<0)return alert('الثمن غير صحيح');deliveryDraftItems.push({productId:catalog.id,name,ref,qty,price,total:qty*price});el('deliveryProductName').value='';el('deliveryProductRef').value='';el('deliveryProductQty').value='1';el('deliveryProductPrice').value='';if(sel)sel.value='';renderDeliveryEditor()}
function removeDeliveryItem(i){deliveryDraftItems.splice(i,1);renderDeliveryEditor()}
function saveIndependentDelivery(e){e.preventDefault();if(!deliveryDraftItems.length)return alert('أضف منتجاً واحداً على الأقل');if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];const doc={id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerId:el('deliveryCustomerSelect')?.value||'',customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x})),total:deliveryItemsTotal(deliveryDraftItems)};const idx=db.deliveryDocs.findIndex(x=>String(x.id)===String(doc.id));if(idx>=0)db.deliveryDocs[idx]=doc;else db.deliveryDocs.push(doc);saveLocal();alert('تم حفظ وصل التسليم بشكل مستقل عن المبيعات');resetIndependentDelivery()}
function editIndependentDelivery(id){const d=db.deliveryDocs.find(x=>String(x.id)===String(id));if(!d)return;currentDeliveryId=d.id;deliveryDraftItems=(d.items||[]).map(x=>({...x}));refreshDeliveryCustomers(d.customerId||'');el('deliveryCustomerName').value=d.customerName||'';el('deliveryCustomerPhone').value=d.customerPhone||'';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value=d.customerAddress||'';if(el('deliveryNumber'))el('deliveryNumber').value=formatDeliveryNumber(d.deliveryNumber||d.id||'');const dt=new Date(d.date);if(!Number.isNaN(dt.getTime()))el('deliveryDate').value=new Date(dt.getTime()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);renderDeliveryEditor()}
function independentDeliveryHtml(d){
 const isFr=localStorage.getItem('afz_lang')==='fr';
 const L=isFr?{
   dir:'ltr',phone:'Téléphone : 0667668693',address:'Adresse : Zone industrielle, Zemamra',title:'Bon de livraison',number:'N° du bon :',customer:'Client',customerPhone:'TEl:',customerAddress:'Adresse :',date:'Date',product:'Nom du produit',qty:'Quantité',price:'Prix',total:'Total',grand:'Total final',thanks:'Les produits mentionnés ci-dessus ont été livrés',pass:'Client de passage'
 }:{
   dir:'rtl',phone:'الهاتف: 0667668693',address:'العنوان: الحي الصناعي الزمامرة',title:'وصل التسليم',number:'رقم الوصل:',customer:'الزبون',customerPhone:'الهاتف:',customerAddress:'العنوان:',date:'التاريخ',product:'اسم المنتج',qty:'العدد',price:'الثمن',total:'المجموع',grand:'المجموع النهائي',thanks:'تم تسليم المنتجات المذكورة أعلاه',pass:'زبون عابر'
 };
 const items=d.items||[];
 const rows=items.map(i=>`<tr><td>${esc(i.name)}</td><td class="num">${Number(i.qty||0)}</td><td class="money">${money(i.price)}</td><td class="money">${money(Number(i.total||Number(i.qty||0)*Number(i.price||0)))}</td></tr>`).join('');
 const dateText=d.date?esc(new Date(d.date).toLocaleString(isFr?'fr-MA':'ar-MA')):'-';
 return `<!doctype html><html lang="${isFr?'fr':'ar'}" dir="${L.dir}"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;direction:${L.dir}}.note{width:100%;padding:24px 28px}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:${isFr?'right':'left'};white-space:nowrap}.summary{margin-top:16px;margin-${isFr?'left':'right'}:auto;width:300px}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;padding-top:8px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style></head><body><div class="note"><div style="display:block;text-align:center;border-bottom:3px solid #0b4f8a;padding-bottom:12px"><div style="display:block"><img class="logo" src="logo.png" style="display:block;margin:0 auto 6px"><div><h1 style="font-size:22px;margin:0">AFRIQUIA FREINS ZEMAMRA</h1><p style="font-size:13px;margin:4px 0;font-weight:bold">${L.phone}</p><p style="font-size:13px;margin:4px 0">${L.address}</p></div></div><div style="margin-top:10px"><h2 style="margin:0;font-size:23px">${L.title}</h2><div style="margin-top:4px;font-size:12px">${L.number} ${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</div></div></div><div class="info"><div class="box customer-box"><div class="customer-head"><span class="customer-icon">👤</span><span>${L.customer}</span></div><div class="customer-name">${esc(d.customerName||L.pass)}</div>${d.customerPhone?'<div class="customer-row">📞 '+L.customerPhone+' '+esc(d.customerPhone)+'</div>':'<div class="customer-row" style="color:#8a959e">📞 '+(isFr?'TEl: non renseigné':'TEl: غير مسجل')+'</div>'}${d.customerAddress?'<div class="customer-row">📍 '+L.customerAddress+' '+esc(d.customerAddress)+'</div>':'<div class="customer-row" style="color:#8a959e">📍 '+(isFr?'Adresse non renseignée':'العنوان غير مسجل')+'</div>'}</div><div class="box"><div class="label">${L.date}</div><div class="value">${dateText}</div></div></div><table class="table"><tr><th>${L.product}</th><th>${L.qty}</th><th>${L.price}</th><th>${L.total}</th></tr>${rows}</table><div class="summary"><div class="grand"><span>${L.grand}</span> <b>${money(deliveryItemsTotal(items))}</b></div></div><div class="thanks">${L.thanks}<br>${L.phone} | ${L.address}</div></div></body></html>`;
}
function getCurrentDeliveryData(id){const saved=id?db.deliveryDocs.find(x=>String(x.id)===String(id)):null;return saved||({id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x}))});}
function previewIndependentDelivery(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);let modal=el('deliveryPreviewModal');if(!modal){modal=document.createElement('div');modal.id='deliveryPreviewModal';modal.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99999;display:flex;flex-direction:column;padding:10px';document.body.appendChild(modal);}modal.innerHTML='<div style="background:#fff;border-radius:12px;padding:8px;display:flex;gap:8px;align-items:center;justify-content:space-between"><b>👁️ معاينة وصل التسليم</b><div><button type="button" onclick="downloadIndependentDeliveryPdf()">⚡ طباعة PDF</button><button type="button" class="outline" onclick="closeDeliveryPreview()">✕ إغلاق</button></div></div><iframe title="معاينة وصل التسليم" style="flex:1;width:100%;border:0;border-radius:8px;margin-top:8px;background:#fff"></iframe>';modal.style.display='flex';const frame=modal.querySelector('iframe');frame.srcdoc=html;}
function closeDeliveryPreview(){const m=el('deliveryPreviewModal');if(m)m.style.display='none';}
function downloadIndependentDeliveryPdf(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);const name='Bon-de-livraison-'+String(d.id||Date.now())+'.pdf';try{if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function'){AndroidPrint.savePdf(html,name);return;}localStorage.setItem('__afriquia_pdf_html',html);localStorage.setItem('__afriquia_pdf_name',name);location.href='afriquia://savepdf';}catch(e){alert('تعذر إنشاء PDF: '+e.message)}}
function downloadSelectedDeliveryPdf(){downloadIndependentDeliveryPdf(currentDeliveryId)}


function printLastSaleThermal(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:10px;margin-right:auto;width:65%}.sumrow{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #ccc;font-size:9px}.grand{font-size:13px;font-weight:bold;border-top:2px solid #111}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>#${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج / المرجع</th><th>كم</th><th>الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Afriquia Thermal Invoice '+String(x.id||'')); else alert('الطباعة الحرارية متاحة داخل تطبيق Android.');
}
function printLastDeliveryNote(){
 if(!db.sales.length){alert('لا توجد مبيعات لإنشاء وصل التسليم');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const rows=items.map((i,n)=>{const qty=Number(i.qty||i.quantity||1),price=Number(i.price||i.salePrice||0),lineTotal=Number(i.total||qty*price);return '<tr><td><b>'+esc(i.name)+'</b></td><td class="num">'+qty+'</td><td class="money">'+money(price)+'</td><td class="money">'+money(lineTotal)+'</td></tr>';}).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.note{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.contact{margin-top:8px;text-align:center;font-size:9px;font-weight:bold}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style></head><body><div class="note"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p></div></div><div class="title"><h2>وصل التسليم</h2><div>رقم الوصل: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="contact">الهاتف: 0667668693 — العنوان: الحي الصناعي الزمامرة</div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">هاتف الزبون: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>المنتج</th><th>العدد</th><th>الثمن</th><th>المجموع</th></tr>${rows}</table><div class="thanks">تم تسليم المنتجات المذكورة أعلاه<br><span class="small">الهاتف: 0667668693 | الحي الصناعي الزمامرة</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Bon de livraison '+String(x.id||'')); else if(window.AndroidPrint&&AndroidPrint.printHtml) AndroidPrint.printHtml(html,'Bon de livraison '+String(x.id||'')); else {const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function printLastSale(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff} .invoice{max-width:760px;margin:auto;padding:24px 28px} .head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{font-size:22px;margin:0;color:#0b4f8a}.brand p{margin:5px 0 0;color:#687784;font-size:12px}.title{text-align:left}.title h2{margin:0;font-size:23px;color:#17212b}.title div{margin-top:5px;color:#687784;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e;margin-bottom:4px}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;color:#0b4f8a;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px;color:#687784}.small{font-size:10px;color:#77838e}@page{size:A4;margin:8mm}@media print{.invoice{padding:0}}

.daily-expense-entry{padding:8px;overflow:hidden}.daily-expense-entry h3{margin:2px 0 8px;font-size:15px}.daily-expense-entry .daily-entry-wrap{overflow-x:auto}.daily-expense-entry table{width:100%;table-layout:fixed;font-size:11px;border-collapse:collapse}.daily-expense-entry th,.daily-expense-entry td{padding:4px 3px;border-bottom:1px solid #e5e9ed}.daily-expense-entry th{font-size:10px;white-space:nowrap}.daily-expense-entry input{margin:0;padding:6px 4px;font-size:11px;width:100%;min-width:0}.daily-expense-entry th:nth-child(1),.daily-expense-entry td:nth-child(1){width:30%}.daily-expense-entry th:nth-child(2),.daily-expense-entry td:nth-child(2){width:36%}.daily-expense-entry th:nth-child(3),.daily-expense-entry td:nth-child(3){width:24%}.daily-expense-entry th:nth-child(4),.daily-expense-entry td:nth-child(4){width:10%}.daily-expense-entry button{padding:5px 6px;font-size:10px;min-height:30px}@media(max-width:520px){.daily-expense-entry{padding:6px}.daily-expense-entry table{font-size:10px}.daily-expense-entry th,.daily-expense-entry td{padding:3px 2px}.daily-expense-entry th{font-size:9px}.daily-expense-entry input{padding:5px 3px;font-size:10px}.daily-expense-entry button{padding:4px 5px;font-size:9px}}

/* Daily expense entry table - compact phone layout */
.daily-expense-entry{padding:7px;margin-top:8px;background:#fff;border-radius:10px;overflow:hidden}
.daily-entry-title{font-size:15px;font-weight:800;margin:0 0 6px;text-align:right}
.daily-entry-help{margin-bottom:6px;text-align:right}
.daily-entry-wrap{width:100%;overflow-x:auto}
.daily-entry-table,.daily-saved-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:9px}
.daily-entry-table th,.daily-entry-table td,.daily-saved-table th,.daily-saved-table td{padding:2px 2px;border-bottom:1px solid #e5e9ed;text-align:center;vertical-align:middle;line-height:1.05}
.daily-entry-table th,.daily-saved-table th{font-size:8px;white-space:nowrap;background:#f7fbff}
/* Final compact daily-expense table for phone screens */
.daily-expense-entry-main .daily-saved-table{width:100%;table-layout:fixed;border-collapse:collapse;font-size:10px;line-height:1}
.daily-expense-entry-main .daily-saved-table tr{height:32px}
.daily-expense-entry-main .daily-saved-table th,.daily-expense-entry-main .daily-saved-table td{padding:2px 2px!important;height:32px;line-height:1!important;vertical-align:middle;text-align:center;white-space:nowrap;overflow:hidden}
.daily-expense-entry-main .daily-saved-table th{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table td{font-size:10px!important}
.daily-expense-entry-main .daily-saved-table td b{display:inline!important;font-size:10px!important;margin:0!important;line-height:1!important;font-weight:700!important;white-space:nowrap}
.daily-expense-entry-main .daily-saved-table th:nth-child(1),.daily-expense-entry-main .daily-saved-table td:nth-child(1){width:25%}
.daily-expense-entry-main .daily-saved-table th:nth-child(2),.daily-expense-entry-main .daily-saved-table td:nth-child(2){width:35%}
.daily-expense-entry-main .daily-saved-table th:nth-child(3),.daily-expense-entry-main .daily-saved-table td:nth-child(3){width:28%}
.daily-expense-entry-main .daily-saved-table th:nth-child(4),.daily-expense-entry-main .daily-saved-table td:nth-child(4){width:12%}
.daily-expense-entry-main .daily-saved-table .daily-delete-one{display:inline-flex!important;align-items:center;justify-content:center;min-width:22px!important;width:22px;height:22px!important;min-height:22px!important;padding:0!important;margin:0!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
@media(max-width:520px){
.daily-expense-entry-main .daily-saved-table{font-size:9px}
.daily-expense-entry-main .daily-saved-table tr{height:29px}
.daily-expense-entry-main .daily-saved-table th,.daily-expense-entry-main .daily-saved-table td{height:29px;padding:1px!important}
.daily-expense-entry-main .daily-saved-table th{font-size:8px!important}
.daily-expense-entry-main .daily-saved-table td{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table td b{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table .daily-delete-one{width:20px;height:20px!important;min-width:20px!important;min-height:20px!important;font-size:11px!important}
}
.daily-saved-table th:nth-child(1),.daily-saved-table td:nth-child(1){width:24%}
.daily-saved-table th:nth-child(2),.daily-saved-table td:nth-child(2){width:40%}
.daily-saved-table th:nth-child(3),.daily-saved-table td:nth-child(3){width:24%}
.daily-saved-table th:nth-child(4),.daily-saved-table td:nth-child(4){width:12%}
.daily-one-form{display:grid;grid-template-columns:1fr;gap:4px}
.daily-one-form label{font-size:10px;font-weight:bold;margin-top:1px}
.daily-one-form input{width:100%;min-width:0;margin:0;padding:5px 4px;font-size:11px;border:1px solid #d5dde5;border-radius:6px;background:#fff}
.daily-save-one{width:100%;margin-top:3px;padding:6px 8px;font-size:11px;min-height:34px}
.daily-saved-title{font-size:12px;font-weight:800;margin:8px 0 4px}
.daily-delete-one{min-width:24px;padding:2px 4px;font-size:10px}
.daily-empty{font-size:10px;padding:7px!important}
@media(max-width:520px){.daily-expense-entry{padding:6px}.daily-entry-title{font-size:14px}.daily-saved-table{font-size:8px}.daily-saved-table th,.daily-saved-table td{padding:2px 1px}.daily-saved-table th{font-size:7px}.daily-one-form input{padding:5px 3px;font-size:10px}.daily-one-form label{font-size:9px}.daily-save-one{font-size:10px;padding:5px 6px;min-height:31px}.daily-saved-title{font-size:11px}}

 .daily-expense-entry{padding:7px}
 .daily-entry-title{font-size:13px;margin-bottom:3px}
 .daily-entry-table{font-size:8px;line-height:1}
 .daily-entry-table th,.daily-entry-table td{padding:1px 1px;height:20px}
 .daily-entry-table th{font-size:7px;padding:1px}
 .daily-entry-table input,.daily-saved-table input{padding:2px 1px;font-size:8px;min-height:20px}
 .daily-entry-actions button{font-size:10px;padding:7px 8px}
}

.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.daily-one-form{display:flex;flex-direction:column;gap:6px;margin:8px 0 12px}
.daily-one-form label{font-size:12px;font-weight:700;color:#687784;text-align:right}
.daily-one-form input{width:100%;padding:10px 9px;font-size:13px;border:1px solid #d5dde5;border-radius:9px;background:#fff;box-sizing:border-box}
.daily-save-one{width:100%;padding:10px 12px!important;font-size:13px!important;margin-top:4px}
.daily-saved-title{font-size:14px;font-weight:800;margin:7px 0 5px;text-align:right}
.daily-saved-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:9px;line-height:1.05}
.daily-saved-table th,.daily-saved-table td{padding:3px 2px;border-bottom:1px solid #e5e9ed;text-align:center;vertical-align:middle}
.daily-saved-table th{font-size:8px;white-space:nowrap;background:#f7fbff}
.daily-saved-table th:nth-child(1),.daily-saved-table td:nth-child(1){width:25%}
.daily-saved-table th:nth-child(2),.daily-saved-table td:nth-child(2){width:39%}
.daily-saved-table th:nth-child(3),.daily-saved-table td:nth-child(3){width:25%}
.daily-saved-table th:nth-child(4),.daily-saved-table td:nth-child(4){width:11%}
.daily-delete-one{min-width:22px!important;padding:2px 5px!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
.daily-empty{padding:8px!important;color:#7a8791}
@media(max-width:520px){.daily-one-form input{font-size:12px;padding:9px 8px}.daily-one-form label{font-size:11px}.daily-save-one{font-size:12px!important}.daily-entry-table{font-size:7px!important;line-height:1!important}.daily-entry-table th,.daily-entry-table td{padding:1px!important;height:18px!important}.daily-entry-table th{font-size:6px!important}.daily-delete-one{font-size:9px!important;min-width:18px!important;padding:1px 3px!important;height:18px!important}.daily-saved-table{font-size:7px;line-height:1}.daily-saved-table th,.daily-saved-table td{padding:1px}.daily-saved-table th{font-size:6px}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style></head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا ❤️<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.printHtml)AndroidPrint.printHtml(html,'Afriquia Stock - Invoice '+String(x.id||''));else{const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function pickCustomerContact(){
 try{
   if(window.AndroidPrint && AndroidPrint.pickCustomerContact){
     AndroidPrint.pickCustomerContact();
   }else{
     alert('اختيار جهات الاتصال متاح داخل تطبيق Android فقط');
   }
 }catch(err){alert('تعذر فتح جهات الاتصال');}
}
function setCustomerFromContact(name,phone){
 el('custName').value=name||'';
 el('custPhone').value=phone||'';
 el('custName').focus();
}
function pickCreditContact(){
 try{
   if(window.AndroidPrint && AndroidPrint.pickCreditContact){
     AndroidPrint.pickCreditContact();
   }else{
     alert('اختيار جهات الاتصال متاح داخل تطبيق Android فقط');
   }
 }catch(err){alert('تعذر فتح جهات الاتصال');}
}
function setCreditCustomerFromContact(name,phone){
 if(el('creditCustomerName')) el('creditCustomerName').value=name||'';
 if(el('creditPhone')) el('creditPhone').value=phone||'';
 if(el('creditCustomer')){
   const c=(db.customers||[]).find(x=>String(x.name||'').trim()===String(name||'').trim() || String(x.phone||'').trim()===String(phone||'').trim());
   if(c) el('creditCustomer').value=String(c.id);
 }
 if(el('creditCustomerName')) el('creditCustomerName').focus();
}
function addCustomer(e){e.preventDefault();const name=el('custName').value.trim(),phone=el('custPhone').value.trim();if(!name)return;db.customers.push({id:Date.now(),name,phone});save();e.target.reset();alert('تم حفظ الزبون');}
function addExpense(e){e.preventDefault();const name=el('expName').value.trim(),amount=Number(el('expAmount').value);if(!name||amount<0)return;db.expenses.push({date:new Date().toISOString(),name,amount});save();e.target.reset();alert('تم حفظ المصروف');}
let selectedStockCardName = '';
function selectStockCard(name){
  selectedStockCardName = String(name||'').trim();
  render();
  setTimeout(()=>{ const box=el('stockList'); if(box) box.scrollIntoView({behavior:'smooth',block:'start'}); }, 30);
}
function clearStockCardSelection(){
  selectedStockCardName = '';
  render();
}

async function editStockImageByName(encodedName){
 const name=decodeURIComponent(String(encodedName||''));
 if(!name)return;
 const input=document.createElement('input');
 input.type='file'; input.accept='image/*'; input.style.display='none';
 document.body.appendChild(input);
 input.onchange=async()=>{
   try{
     const file=input.files&&input.files[0]; if(!file)return;
     if(!file.type.startsWith('image/')) return alert('اختر صورة فقط.');
     const image=await compressImage(file);
     const key=normalizeProductName(name);
     let changed=false;
     (db.stock||[]).forEach(x=>{if(normalizeProductName(x.name)===key){x.image=image;changed=true;}});
     (db.products||[]).forEach(x=>{if(normalizeProductName(x.name)===key){x.image=image;changed=true;}});
     if(changed){save();syncProductsFromStock();render();}
   }catch(err){alert('تعذر تغيير الصورة. جرّب صورة أصغر.');}
   finally{input.remove();}
 };
 input.click();
}
function editStock(id){
 const p=db.stock.find(x=>String(x.id)===String(id));if(!p)return;
 const catalog=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);if(!catalog)return alert('المنتوج غير موجود في المخزون');
 const refs=productNumbers(catalog);if(!refs.length)return alert('أضف رقم المنتوج أولاً في المخزون');
 const ref=prompt('رقم المنتوج من القائمة المرتبطة:\n'+refs.join(' / '),p.ref||refs[0]);if(ref===null)return;
 const cleanRef=String(ref).trim();if(!refs.some(r=>String(r).toLowerCase()===cleanRef.toLowerCase()))return alert('هذا الرقم غير مسجل لهذا المنتوج في المخزون.');
 const qty=prompt('الكمية:',p.qty);if(qty===null)return;
 if(Number(qty)<0)return alert('بيانات غير صحيحة');
 p.productId=catalog.id;p.name=catalog.name;p.ref=refs.find(r=>String(r).toLowerCase()===cleanRef.toLowerCase())||cleanRef;p.qty=Number(qty);if(catalog.image)p.image=catalog.image;syncStockPurchasePrices();
 save();alert('تم تعديل المنتج مع إبقاء الاسم والرقم مرتبطين بالمخزون');
}
function deleteStock(id){if(confirm('حذف هذا المنتج من المخزون؟')){db.stock=db.stock.filter(x=>x.id!==id);delete db.prices[String(id)];save()}}
function saveProductPrices(id){
 const input=el('price_'+id);
 if(!input)return;
 const value=Number(input.value);
 if(!Number.isFinite(value)||value<0){alert('أدخل ثمناً صحيحاً');return;}
 db.prices[String(id)]=value;
 const linked=(db.stock||[]).find(x=>String(x.productId)===String(id));
 if(linked) linked.salePrice=value;
 save();
 alert('تم حفظ سعر المنتوج');
}
function getProductStock(id){
 return (db.stock||[]).find(x=>String(x.productId)===String(id))||null;
}
function getProductPrice(id){
 const v=db.prices[String(id)];
 if(v!==undefined && Number.isFinite(Number(v))) return Number(v);
 const st=getProductStock(id);
 if(st && db.prices[String(st.id)]!==undefined) return Number(db.prices[String(st.id)]);
 return st && st.salePrice!==undefined ? Number(st.salePrice) : 0;
}
function sortNumbersAscending(values){
 return [...new Set((values||[]).map(v=>String(v||'').trim()).filter(Boolean))].sort((a,b)=>{
   const an=a.match(/\d+(?:[.,]\d+)?/), bn=b.match(/\d+(?:[.,]\d+)?/);
   if(an&&bn){ const av=Number(an[0].replace(',','.')), bv=Number(bn[0].replace(',','.')); if(av!==bv)return av-bv; }
   return a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'});
 });
}

function showSearchPicker(input){
 try{ if(input && typeof input.showPicker==='function') input.showPicker(); }catch(e){}
}
function fillDatalist(id, values, numeric=false){
 const list=el(id); if(!list)return;
 let vals=[...new Set((values||[]).map(v=>String(v||'').trim()).filter(Boolean))];
 if(numeric) vals=sortNumbersAscending(vals); else vals.sort((a,b)=>a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'}));
 list.innerHTML=vals.map(v=>`<option value="${esc(v)}"></option>`).join('');
}
function renderAllSearchLists(){
 renderStockSearchOptions();
 renderPriceProductNames();
 renderNewPriceProductNames();
 renderPriceNumberOptions();
 fillDatalist('creditNames',(db.credits||[]).map(x=>x.customerName));
 fillDatalist('creditPhones',(db.credits||[]).map(x=>x.phone),true);
 fillDatalist('checkNumbers',(db.checks||[]).map(x=>x.number),true);
 fillDatalist('checkBeneficiaries',(db.checks||[]).map(x=>x.beneficiary));
}

function renderStockSearchOptions(){
 const names=el('stockProductNames');
 const vals=[...new Set((db.stock||[]).map(x=>String(x.name||'').trim()).filter(Boolean))];
 if(names) names.innerHTML=vals.map(n=>`<option value="${esc(n)}"></option>`).join('');
 const nums=el('stockNumbers');
 if(nums){
   const nameQ=normalizeProductName(el('stockNameSearch')?.value||'');
   let refs=(db.stock||[]).filter(x=>!nameQ||normalizeProductName(x.name).includes(nameQ)).map(x=>String(x.ref||'').trim()).filter(Boolean);
   refs=sortNumbersAscending([...new Set(refs)]);
   nums.innerHTML=refs.map(n=>`<option value="${esc(n)}"></option>`).join('');
   const current=String(el('stockSearch')?.value||'').trim();
   if(current && nameQ && !refs.includes(current) && el('stockSearch')) el('stockSearch').value='';
 }
}
function getPriceProductNames(){
 const names=[...new Map(stockCatalogProducts().map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 return names.sort((a,b)=>a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'}));
}
function renderPriceNamePicker(filter=true){
 const box=el('priceNamePicker'); if(!box)return;
 const q=filter?normalizeProductName(el('priceNameSearch')?.value||''):'';
 const names=getPriceProductNames().filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=names.length?names.map(n=>`<button type="button" class="search-picker-item price-name-option" data-name="${esc(n)}">${esc(n)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أسماء مسجلة</div>`;
}
function openPriceNamePicker(){
 renderPriceProductNames();
 renderPriceNamePicker(false);
 const box=el('priceNamePicker'); if(box)box.style.display='block';
 syncPriceNumberFromName();
}
function filterPriceNamePicker(){
 renderPriceNamePicker();
 syncPriceNumberFromName();
 updatePricePurchaseSearch();
 const box=el('priceNamePicker'); if(box)box.style.display='block';
}
function selectPriceName(name){
 const input=el('priceNameSearch');
 if(input){ input.value=String(name||''); input.focus(); }
 const box=el('priceNamePicker'); if(box)box.style.display='none';
 syncPriceNumberFromName();
 updatePricePurchaseSearch();
 renderPrices();
}
function openPriceNumberPicker(){
 renderPriceNumberPicker(false);
 const box=el('priceNumberPicker'); if(box)box.style.display='block';
}
function filterPriceNumberPicker(){
 renderPriceNumberPicker(true);
 const box=el('priceNumberPicker'); if(box)box.style.display='block';
}
function getPriceProductNumbers(){
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 let refs=[];
 stockCatalogProducts().forEach(product=>{
   const name=normalizeProductName(product.name||'');
   if(qName && name!==qName)return;
   refs.push(...getPriceRefsForDisplay(product.id));
 });
 return sortNumbersAscending(refs);
}
function renderPriceNumberPicker(filter=true){
 const box=el('priceNumberPicker'); if(!box)return;
 const q=filter?String(el('priceNumberSearch')?.value||'').trim().toLowerCase():'';
 const refs=getPriceProductNumbers().filter(r=>!q||r.toLowerCase().includes(q));
 box.innerHTML=refs.length?refs.map(r=>`<button type="button" class="search-picker-item price-number-option" data-ref="${esc(r)}">${esc(r)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أرقام مسجلة</div>`;
}
function selectPriceNumber(ref){
 const input=el('priceNumberSearch'); if(input)input.value=ref;
 const box=el('priceNumberPicker'); if(box)box.style.display='none';
 updatePricePurchaseSearch();
 renderPrices();
}
function syncStockPurchasePrices(){
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 (db.stock||[]).forEach(x=>{
   const productId=String(x.productId||'');
   const raw=pp[productId];
   const wanted=String(x.ref||x.number||x.code||'').trim().toLowerCase();
   if(raw&&typeof raw==='object'&&!Array.isArray(raw)&&wanted && raw[wanted]!==undefined && Number.isFinite(Number(raw[wanted]))){x.buy=Number(raw[wanted]);return;}
   if(raw&&typeof raw==='object'&&!Array.isArray(raw)){const k=Object.keys(raw).find(k=>String(k).trim().toLowerCase()===wanted);if(k!==undefined&&Number.isFinite(Number(raw[k]))){x.buy=Number(raw[k]);return;}}
   if(raw!==undefined&&Number.isFinite(Number(raw)))x.buy=Number(raw);
 });
}

function getPurchasePriceForRef(productId,ref){
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 const key=String(productId);
 const raw=pp[key];
 const wanted=String(ref||'').trim().toLowerCase();
 if(raw&&typeof raw==='object'&&!Array.isArray(raw)){
   if(wanted && raw[wanted]!==undefined && Number.isFinite(Number(raw[wanted]))) return Number(raw[wanted]);
   const exactKey=Object.keys(raw).find(k=>String(k).trim().toLowerCase()===wanted);
   if(exactKey!==undefined && Number.isFinite(Number(raw[exactKey]))) return Number(raw[exactKey]);
   const first=Object.values(raw).find(v=>Number.isFinite(Number(v)));
   if(first!==undefined)return Number(first);
 }
 if(raw!==undefined && Number.isFinite(Number(raw))) return Number(raw);
 const st=(Array.isArray(db.stock)?db.stock:[]).find(x=>String(x.productId)===key && (!wanted || String(x.ref||x.number||x.code||'').trim().toLowerCase()===wanted));
 if(st&&Number.isFinite(Number(st.buy)))return Number(st.buy);
 return getPurchasePriceForProduct(productId);
}
function updatePricePurchaseSearch(){
 const out=el('pricePurchaseSearch'); if(!out)return;
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 const qRef=String(el('priceNumberSearch')?.value||'').trim().toLowerCase();
 const products=stockCatalogProducts();
 const matches=products.filter(product=>{
   const name=normalizeProductName(product.name||'');
   if(qName && name!==qName)return false;
   if(qRef){
     const refs=getAllProductRefs(product.id);
     if(!refs.some(r=>r.toLowerCase()===qRef))return false;
   }
   return true;
 });
 const product=matches[0];
 if(!product){out.value='';return;}
 const refs=getAllProductRefs(product.id);
 if(!qRef){out.value='';return;}
 const selectedRef=refs.find(r=>r.toLowerCase()===qRef)||'';
 if(!selectedRef){out.value='';return;}
 const buy=getPurchasePriceForRef(product.id,selectedRef);
 out.value=Number.isFinite(buy) ? (buy.toFixed(2).replace(/\.00$/,'')+' DH') : '';
}
function closePriceNamePicker(e){
 document.querySelectorAll('.search-picker-wrap').forEach(wrap=>{
   if(!wrap.contains(e.target)){
     wrap.querySelectorAll('.search-picker-list').forEach(box=>box.style.display='none');
   }
 });
}
document.addEventListener('click',closePriceNamePicker);
document.addEventListener('click',function(e){
 const opt=e.target.closest('.price-name-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 const name=opt.getAttribute('data-name')||'';
 selectPriceName(name);
});
document.addEventListener('pointerdown',function(e){
 const opt=e.target.closest('.price-number-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectPriceNumber(opt.getAttribute('data-ref')||'');
},{passive:false});
document.addEventListener('click',function(e){
 const opt=e.target.closest('.price-number-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectPriceNumber(opt.getAttribute('data-ref')||'');
});
document.addEventListener('click',function(e){
 const opt=e.target.closest('.new-price-name-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectNewPriceProductName(opt.getAttribute('data-name')||'');
});


function renderPriceProductNames(){
 const list=el('priceProductNames'); if(!list)return;
 const names=[...new Map((db.stock||[]).map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 list.innerHTML=names.map(n=>`<option value="${esc(n)}"></option>`).join('');
}
function syncPriceNumberFromName(){
 const nameInput=el('priceNameSearch'), numberInput=el('priceNumberSearch');
 if(!nameInput||!numberInput)return;
 const q=normalizeProductName(nameInput.value||'');
 const products=stockCatalogProducts();
 let refs=[];
 products.forEach(p=>{if(!q||normalizeProductName(p.name).includes(q))refs.push(...getAllProductRefs(p.id));});
 refs=sortNumbersAscending(refs);
 const list=el('priceProductNumbers');
 if(list) list.innerHTML=refs.map(r=>`<option value=\"${esc(r)}\"></option>`).join('');
 if(q && numberInput.value && !refs.includes(String(numberInput.value).trim())) numberInput.value='';
}
function renderPriceNumberOptions(){
 const list=el('priceProductNumbers'); if(!list)return;
 const q=normalizeProductName(el('priceNameSearch')?.value||'');
 let refs=[];
 stockCatalogProducts().forEach(p=>{if(!q||normalizeProductName(p.name).includes(q))refs.push(...getAllProductRefs(p.id));});
 refs=sortNumbersAscending(refs);
 list.innerHTML=refs.map(r=>`<option value=\"${esc(r)}\"></option>`).join('');
}
function getPriceOnlyRefs(productId){
 const map=(db.priceRefs&&typeof db.priceRefs==='object')?db.priceRefs:{};
 const refs=Array.isArray(map[String(productId)])?map[String(productId)]:[];
 return refs.map(v=>String(v||'').trim()).filter(Boolean);
}
function getAllProductRefs(productId){return getPriceOnlyRefs(productId);}
function getPurchasePriceForProduct(productId){
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 if(pp[String(productId)]!==undefined && Number.isFinite(Number(pp[String(productId)]))) return Number(pp[String(productId)]);
 const st=getProductStock(productId);
 return st&&Number.isFinite(Number(st.buy))?Number(st.buy):0;
}
function getNewPriceProductNames(){
 const names=[...new Map((db.products||[]).map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 return names.sort((a,b)=>a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'}));
}
function getPriceRefsForProduct(product){
 return productNumbers(product);
}
function getAlreadyPricedRefs(productId){
 const map=(db.priceRefs&&typeof db.priceRefs==='object')?db.priceRefs:{};
 const refs=Array.isArray(map[String(productId)])?map[String(productId)]:[];
 return refs.map(v=>String(v||'').trim()).filter(Boolean);
}
function previewPriceProductImage(){
 const input=el('priceProductImage'),preview=el('priceProductImagePreview');
 if(!input||!preview)return;
 const file=input.files?.[0];
 if(!file){preview.innerHTML='';preview.style.display='none';return;}
 if(!file.type.startsWith('image/')){input.value='';preview.innerHTML='';preview.style.display='none';return alert('اختر صورة فقط.');}
 const r=new FileReader();
 r.onload=()=>{preview.innerHTML='<img src="'+r.result+'" alt="صورة المنتوج">';preview.style.display='block';};
 r.readAsDataURL(file);
}

function switchNewPriceProductMode(){
 const mode=el('newPriceProductMode')?.value||'new';
 const name=el('newPriceProductName'), ref=el('newPriceProductRef'), nameBox=el('newPriceProductPicker'), refBox=el('newPriceProductRefPicker'), hint=el('newPriceProductHint');
 if(!name||!ref)return;
 name.value='';ref.value='';
 if(nameBox)nameBox.style.display='none'; if(refBox)refBox.style.display='none';
 const imageWrap=el('priceProductImageWrap'), imageInput=el('priceProductImage');
 if(imageWrap)imageWrap.style.display=mode==='new'?'block':'none';
 if(imageInput){imageInput.value='';}
 const imagePreview=el('priceProductImagePreview'); if(imagePreview){imagePreview.innerHTML='';imagePreview.style.display='none';}
 if(mode==='existing'){
   name.placeholder='اختر اسم المنتوج المسجل';
   ref.placeholder='أدخل رقمًا جديدًا لهذا المنتوج';
   if(hint)hint.textContent='اختر اسمًا مسجلًا، ثم اكتب رقمًا جديدًا لهذا الاسم، ثم أدخل ثمن الشراء. الأرقام السابقة لا تظهر هنا.';
 }else{
   name.placeholder='اسم المنتوج الجديد';
   ref.placeholder='رقم المنتوج الجديد';
   if(hint)hint.textContent='للمنتوج الجديد: أدخل الاسم ثم رقم المنتوج ثم ثمن الشراء.';
 }
}
function renderNewPriceProductNames(){
 const names=getNewPriceProductNames();
 const box=el('newPriceProductPicker'); if(!box)return;
 const q=normalizeProductName(el('newPriceProductName')?.value||'');
 const filtered=names.filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=filtered.length?filtered.map(n=>`<button type="button" class="search-picker-item new-price-name-option" data-name="${esc(n)}">${esc(n)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أسماء مسجلة</div>`;
}
function openNewPriceProductPicker(){
 if((el('newPriceProductMode')?.value||'new')!=='existing')return;
 renderNewPriceProductNames(); const box=el('newPriceProductPicker'); if(box)box.style.display='block';
}
function filterNewPriceProductPicker(){openNewPriceProductPicker();}
function selectNewPriceProductName(name){
 const input=el('newPriceProductName'); if(input){input.value=String(name||'');input.focus();}
 const box=el('newPriceProductPicker'); if(box)box.style.display='none';
}
function getSelectedCatalogProductByName(name){
 const n=normalizeProductName(name); return (db.products||[]).find(p=>normalizeProductName(p.name)===n)||null;
}
function getNewPriceProductRefs(){ return []; }
function renderNewPriceProductRefPicker(){
 const box=el('newPriceProductRefPicker');
 if(box) box.style.display='none';
}
function openNewPriceProductRefPicker(){ renderNewPriceProductRefPicker(); }
function filterNewPriceProductRefPicker(){ renderNewPriceProductRefPicker(); }
function selectNewPriceProductRef(ref){
 const input=el('newPriceProductRef'); if(input){input.value=String(ref||'');input.focus();}
 renderNewPriceProductRefPicker();
}
async function addNewPriceProduct(e){
 e.preventDefault();
 const mode=el('newPriceProductMode')?.value||'new';
 const name=String(el('newPriceProductName')?.value||'').trim();
 const ref=String(el('newPriceProductRef')?.value||'').trim();
 const buy=Number(el('newPriceProductBuy')?.value||0);
 if(!name||!ref)return alert('أدخل اسم المنتوج ورقم المنتوج');
 if(!Number.isFinite(buy)||buy<0)return alert('أدخل ثمن شراء صحيح');
 if(!Array.isArray(db.products))db.products=[];
 if(!db.priceRefs||typeof db.priceRefs!=='object'||Array.isArray(db.priceRefs))db.priceRefs={};
 if(!db.purchasePrices||typeof db.purchasePrices!=='object'||Array.isArray(db.purchasePrices))db.purchasePrices={};
 let product=null;
 if(mode==='new'){
   if(db.products.some(p=>normalizeProductName(p.name)===normalizeProductName(name)))return alert('هذا الاسم مسجل بالفعل. اختر «إضافة رقم لمنتوج مسجل».');
   const duplicateGlobal=db.products.some(p=>productNumbers(p).some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()));
   if(duplicateGlobal)return alert('هذا الرقم مسجل مسبقًا مع منتوج آخر.');
   const imageFile=el('priceProductImage')?.files?.[0];
   let image='';
   if(imageFile){
     try{image=await compressImage(imageFile);}catch(err){return alert('تعذر حفظ الصورة. جرّب صورة أصغر أو أعد اختيارها.');}
   }
   product={id:'prod_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),name:name,image,numbers:[ref]};
   db.products.push(product);
 }else{
   product=getSelectedCatalogProductByName(name);
   if(!product)return alert('اختر اسمًا من الأسماء المسجلة.');
   const refs=productNumbers(product);
   if(refs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()))return alert('هذا الرقم مسجل مسبقًا لهذا المنتوج.');
   const duplicateGlobal=db.products.some(p=>String(p.id)!==String(product.id)&&productNumbers(p).some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()));
   if(duplicateGlobal)return alert('هذا الرقم مسجل مسبقًا مع منتوج آخر.');
   product.numbers=sortNumbersAscending([...refs,ref]);
 }
 const pid=String(product.id);
 if(!Array.isArray(db.priceRefs[pid]))db.priceRefs[pid]=[];
 if(db.priceRefs[pid].some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()))return alert('هذا الرقم لديه ثمن شراء مسجل بالفعل.');
 db.priceRefs[pid].push(ref);
 if(!db.purchasePrices[pid]||typeof db.purchasePrices[pid]!=='object'||Array.isArray(db.purchasePrices[pid]))db.purchasePrices[pid]={};
 db.purchasePrices[pid][ref.toLowerCase()]=buy;
 // حفظ مباشر مع تحقق فعلي من أن المنتج والرقم والثمن دخلوا التخزين قبل إعادة العرض.
 try{
   saveLocal();
   const stored=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
   const sp=(stored?.products||[]).find(p=>String(p.id)===String(product.id));
   const srefs=stored?.priceRefs?.[pid]||[];
   const sbuy=stored?.purchasePrices?.[pid]?.[ref.toLowerCase()];
   if(!sp || !srefs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()) || Number(sbuy)!==Number(buy)) throw new Error('لم يتم تأكيد الحفظ');
 }catch(err){
   db.products=db.products.filter(p=>String(p.id)!==String(product.id));
   if(db.priceRefs?.[pid]) db.priceRefs[pid]=db.priceRefs[pid].filter(r=>String(r).trim().toLowerCase()!==ref.toLowerCase());
   if(db.purchasePrices?.[pid]) delete db.purchasePrices[pid][ref.toLowerCase()];
   return alert('تعذر حفظ المنتوج في ذاكرة الهاتف. جرّب مرة أخرى.');
 }
 render();
 el('newPriceProductName').value='';el('newPriceProductRef').value='';el('newPriceProductBuy').value='';
 if(el('priceProductImage'))el('priceProductImage').value='';
 if(el('priceProductImagePreview')){el('priceProductImagePreview').innerHTML='';el('priceProductImagePreview').style.display='none';}
 renderProductSection();renderProductNamePicker();renderProductSearchResult();renderPrices();
 switchNewPriceProductMode();
 alert('تم حفظ المنتوج والرقم وثمن الشراء بنجاح');
}

async function editPriceProductInfo(productId){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 if(!p)return;
 const oldName=String(p.name||'');
 const name=prompt('اسم المنتوج:',oldName);
 if(name===null)return;
 const clean=String(name).trim();
 if(!clean)return alert('أدخل اسم المنتوج');
 const duplicate=(db.products||[]).some(x=>String(x.id)!==String(productId)&&normalizeProductName(x.name)===normalizeProductName(clean));
 if(duplicate)return alert('هذا الاسم موجود بالفعل.');
 const file=await new Promise(resolve=>{
   const input=document.createElement('input'); input.type='file'; input.accept='image/*';
   input.onchange=()=>resolve(input.files?.[0]||null); input.click();
 });
 let image=p.image||'';
 if(file){ try{image=await compressImage(file);}catch(e){return alert('تعذر حفظ الصورة.');} }
 p.name=clean; p.image=image;
 (db.stock||[]).forEach(st=>{if(String(st.productId)===String(productId)){st.name=clean;st.image=image;}});
 (db.sales||[]).forEach(s=>{(s.items||[]).forEach(it=>{if(String(it.productId)===String(productId)){it.name=clean;it.image=image;}});});
 (db.deliveryDocs||[]).forEach(d=>{(d.items||[]).forEach(it=>{if(String(it.productId)===String(productId)){it.name=clean;it.image=image;}});});
 save();
 render();
 alert('تم تعديل اسم وصورة المنتوج من قسم الأسعار.');
}

function updatePriceOnly(productId,ref){
 const input=el('edit_price_'+String(productId)+'_'+encodeURIComponent(String(ref)).replace(/%/g,'_'));
 const buy=Number(input?.value);
 if(!input||!Number.isFinite(buy)||buy<0)return alert('أدخل ثمناً صحيحاً');
 if(!db.purchasePrices||typeof db.purchasePrices!=='object')db.purchasePrices={};
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!db.purchasePrices[key] || typeof db.purchasePrices[key]!=='object' || Array.isArray(db.purchasePrices[key])) db.purchasePrices[key]={};
 db.purchasePrices[key][refKey]=buy;
 syncStockPurchasePrices();
 if(!db.priceRefs||typeof db.priceRefs!=='object')db.priceRefs={};
 if(!Array.isArray(db.priceRefs[key]))db.priceRefs[key]=[];
 if(!db.priceRefs[key].some(r=>String(r).trim().toLowerCase()===refKey))db.priceRefs[key].push(ref);
 save();
}

function deletePriceOnly(productId,ref){
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!confirm('هل تريد حذف ثمن هذا الرقم؟'))return;
 if(db.priceRefs&&Array.isArray(db.priceRefs[key])){
   db.priceRefs[key]=db.priceRefs[key].filter(r=>String(r).trim().toLowerCase()!==refKey);
   if(!db.priceRefs[key].length)delete db.priceRefs[key];
 }
 if(db.purchasePrices&&db.purchasePrices[key]&&typeof db.purchasePrices[key]==='object'){
   delete db.purchasePrices[key][refKey];
   if(!Object.keys(db.purchasePrices[key]).length)delete db.purchasePrices[key];
 }
 const product=(db.products||[]).find(p=>String(p.id)===key);
 if(product&&Array.isArray(product.numbers)) product.numbers=product.numbers.filter(r=>String(r).trim().toLowerCase()!==refKey);
 syncStockPurchasePrices();
 save();
 renderProductSection();renderProductNamePicker();renderProductSearchResult();renderPrices();
}

function renderPriceCards(){
 const box=el('priceCardsList'); if(!box)return;
 const products=stockCatalogProducts();
 const groups=[];
 products.forEach(p=>{
   const refs=getPriceRefsForDisplay(p.id);
   if(!refs.length)return;
   groups.push({p,refs});
 });
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 const qRef=String(el('priceNumberSearch')?.value||'').trim().toLowerCase();
 const filtered=groups.filter(g=>{
   const nameOk=!qName||normalizeProductName(g.p.name).includes(qName);
   const refOk=!qRef||g.refs.some(r=>String(r).toLowerCase().includes(qRef));
   return nameOk&&refOk;
 }).sort((a,b)=>String(a.p.name).localeCompare(String(b.p.name),'ar',{numeric:true,sensitivity:'base'}));
 if(!filtered.length){box.innerHTML='<div class="empty card">لا توجد أسعار مسجلة</div>';return;}
 box.innerHTML=filtered.map((g,idx)=>{
   const refs=[...g.refs].sort((a,b)=>{
     const an=Number(String(a).replace(/[^0-9.-]/g,'')),bn=Number(String(b).replace(/[^0-9.-]/g,''));
     if(Number.isFinite(an)&&Number.isFinite(bn)&&an!==bn)return an-bn;
     return String(a).localeCompare(String(b),'ar',{numeric:true,sensitivity:'base'});
   });
   const image=g.p.image||'';
   const rows=refs.map(ref=>{
     const buy=getPurchasePriceForRef(g.p.id,ref);
     const inputId='edit_price_'+String(g.p.id)+'_'+encodeURIComponent(String(ref)).replace(/%/g,'_');
     return `<tr><td class="ref-cell">${esc(ref)}</td><td><input id="${inputId}" class="price-edit-input" type="number" min="0" step="0.01" value="${Number.isFinite(Number(buy))?Number(buy):0}"></td><td><button type="button" class="price-save-btn" title="تعديل الثمن" onclick="event.stopPropagation();updatePriceOnly(${JSON.stringify(String(g.p.id))},${JSON.stringify(String(ref))})">✏️ تعديل</button><button type="button" class="price-save-btn danger" title="حذف" onclick="event.stopPropagation();deletePriceOnly(${JSON.stringify(String(g.p.id))},${JSON.stringify(String(ref))})">🗑️ حذف</button></td></tr>`;
   }).join('');
   const encoded=encodeURIComponent(String(g.p.name));
   return `<div class="price-product-card price-color-${idx%10}" onclick="togglePriceCard('${encoded}')"><div class="price-card-head">${image?`<img class="price-card-image" src="${image}" alt="${esc(g.p.name)}">`:'<div class="price-card-image price-no-image">📦</div>'}<div><div class="price-card-name">${esc(g.p.name)}</div><div class="small">${refs.length} رقم مسجل</div></div><button type="button" class="price-save-btn" onclick="event.stopPropagation();editPriceProductInfo(${JSON.stringify(String(g.p.id))})">✏️ تعديل الاسم/الصورة</button><span class="price-card-arrow">▼</span></div><div id="price-details-${encoded}" class="price-card-details"><table class="price-card-table"><thead><tr><th>رقم المنتوج</th><th>الثمن</th><th>الإجراءات</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
 }).join('');
}
function togglePriceCard(encoded){ const box=el('price-details-'+encoded); if(box)box.classList.toggle('open'); }

function renderPriceBottomCards(){
 const body=el('pricesBottomCardsBody'); if(!body)return;
 // بطاقات الأسعار تعتمد مباشرة على المنتجات المسجلة في قسم الأسعار.
 const products=Array.isArray(db.products)?db.products.filter(p=>String(p.name||'').trim()):[];
 const groups=products.map(p=>{
   const refs=new Set();
   getPriceOnlyRefs(p.id).forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   if(Array.isArray(p.numbers)) p.numbers.forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   const raw=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices[String(p.id)]:null;
   if(raw&&typeof raw==='object'&&!Array.isArray(raw)) Object.keys(raw).forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   return {p,refs:sortNumbersAscending([...refs])};
 }).sort((a,b)=>String(a.p.name).localeCompare(String(b.p.name),'ar',{numeric:true,sensitivity:'base'}));
 if(!groups.length){body.innerHTML='<div class="price-bottom-empty">لا توجد منتوجات مسجلة في قسم الأسعار</div>';return;}
 body.innerHTML=groups.map((x,idx)=>{
   const p=x.p, refs=x.refs, encoded=encodeURIComponent(String(p.id));
   const img=p.image||'';
   const rows=refs.length?refs.map(ref=>{
     const buy=getPurchasePriceForRef(p.id,ref);
     return `<div class="price-bottom-details-row"><div class="price-bottom-details-ref">${esc(ref)}</div><div class="price-bottom-details-buy">${Number.isFinite(Number(buy))?money(buy):'-'}</div><div class="price-bottom-details-actions"><button type="button" class="price-save-btn" title="تعديل الثمن" onclick="event.stopPropagation();editBottomPrice(${JSON.stringify(String(p.id))},${JSON.stringify(String(ref))})">✏️</button><button type="button" class="price-save-btn danger" title="حذف" onclick="event.stopPropagation();deletePriceOnly(${JSON.stringify(String(p.id))},${JSON.stringify(String(ref))})">🗑️</button></div></div>`;
   }).join(''):'<div class="price-bottom-empty">لا توجد أرقام مسجلة لهذا المنتوج</div>';
   return `<div class="price-bottom-product-card price-color-${idx%10}" onclick="togglePriceBottomCard('${encoded}')"><div class="price-bottom-product-head">${img?`<img class="price-bottom-product-image" src="${img}" alt="${esc(p.name)}">`:'<div class="price-bottom-product-image price-bottom-product-no-image">📦</div>'}<div class="price-bottom-product-info"><div class="price-bottom-product-name">${esc(p.name)}</div><div class="price-bottom-product-count">${refs.length} رقم مسجل</div></div><span class="price-bottom-product-arrow">▼</span></div><div id="price-bottom-details-${encoded}" class="price-bottom-product-details"><div class="price-bottom-details-row" style="font-weight:900;color:#0b4f8a;background:#eef7ff;border-radius:8px"><div>رقم المنتوج</div><div>ثمن الشراء</div><div>الإجراءات</div></div>${rows}</div></div>`;
 }).join('');
}
function togglePriceBottomCard(encoded){ const box=el('price-bottom-details-'+encoded); if(box)box.classList.toggle('open'); }

function getPriceRefsForDisplay(productId){
 const refs=getPriceOnlyRefs(productId);
 const out=[...refs];
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 const raw=pp[String(productId)];
 if(raw&&typeof raw==='object'&&!Array.isArray(raw)) Object.keys(raw).forEach(ref=>{if(ref&&!out.some(x=>String(x).toLowerCase()===String(ref).toLowerCase()))out.push(ref);});
 return out.filter(Boolean);
}
function editBottomPrice(productId,ref){
 const current=getPurchasePriceForRef(productId,ref);
 const value=prompt('أدخل ثمن الشراء الجديد:',Number.isFinite(Number(current))?Number(current):'');
 if(value===null)return;
 const buy=Number(value);
 if(!Number.isFinite(buy)||buy<0)return alert('أدخل ثمناً صحيحاً');
 if(!db.purchasePrices||typeof db.purchasePrices!=='object')db.purchasePrices={};
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!db.purchasePrices[key]||typeof db.purchasePrices[key]!=='object'||Array.isArray(db.purchasePrices[key]))db.purchasePrices[key]={};
 db.purchasePrices[key][refKey]=buy;
 save();
 renderPrices();
}

function renderPriceBottomTable(){
 const body=el('pricesBottomTableBody'); if(!body)return;
 const products=stockCatalogProducts(), groups=new Map();
 products.forEach(p=>{
   const refs=getPriceRefsForDisplay(p.id);
   refs.forEach(ref=>{
     const section=getPriceSection(p.id,ref)||'عام';
     if(!groups.has(section))groups.set(section,[]);
     groups.get(section).push({p:p,name:p.name||'',ref:String(ref||''),buy:getPurchasePriceForRef(p.id,ref)});
   });
 });
 const orderedSections=[...getPriceSections(),...groups.keys()].filter((x,i,a)=>a.indexOf(x)===i);
 const active=window.activePriceSection||'';
 let html='';
 orderedSections.filter(section=>!active||section===active).forEach(section=>{
   const rows=(groups.get(section)||[]).sort((a,b)=>String(a.name).localeCompare(String(b.name),'ar',{numeric:true,sensitivity:'base'})||String(a.ref).localeCompare(String(b.ref),'ar',{numeric:true,sensitivity:'base'}));
   html+=`<tr><td colspan="5" style="padding:0;border:0"><div class="product-price-section"><div class="product-price-section-title">🗂️ ${esc(section)}</div>${rows.length?`<div class="price-table-wrap"><table class="price-table"><thead><tr><th>اسم المنتوج</th><th>رقم المنتوج</th><th>ثمنه</th><th>الإجراءات</th></tr></thead><tbody>${rows.map(x=>`<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.ref||'-')}</td><td><b>${Number.isFinite(Number(x.buy))?money(x.buy):'-'}</b></td><td><button type="button" class="price-save-btn" onclick="event.stopPropagation();editBottomPrice(${JSON.stringify(String(x.p.id))},${JSON.stringify(String(x.ref))})">✏️ تعديل الثمن</button><button type="button" class="price-save-btn danger" onclick="event.stopPropagation();deletePriceOnly(${JSON.stringify(String(x.p.id))},${JSON.stringify(String(x.ref))})">🗑️ حذف</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="price-section-empty">لا توجد أسعار في هذا القسم</div>'}</div></td></tr>`;
 });
 body.innerHTML=html||'<tr><td colspan="5" class="empty">لا توجد أسعار مسجلة</td></tr>';
}

function renderPrices(){
 syncCatalogLinks();
 renderPriceProductNames();
 renderNewPriceProductNames();
 renderPriceNumberOptions();
 renderPriceCards();
 renderPriceBottomCards();
 updatePricePurchaseSearch();
 const nameInput=el('priceNameSearch'), numberInput=el('priceNumberSearch'), result=el('pricesResult');
 if(!nameInput||!numberInput||!result)return;
 const qName=normalizeProductName(nameInput.value||''), qNumber=String(numberInput.value||'').trim().toLowerCase();
 if(!qName && !qNumber){ result.innerHTML=''; return; }
 if(qName && !qNumber){ result.innerHTML='<div class="small">اختر رقم المنتوج لإظهار ثمنه.</div>'; return; }
 const product=stockCatalogProducts().find(p=>{
   const sameName=!qName || normalizeProductName(p.name)===qName;
   const refs=getPriceRefsForDisplay(p.id);
   return sameName && refs.some(r=>String(r).trim().toLowerCase()===qNumber);
 });
 if(!product){ result.innerHTML='<div class="empty">لا توجد نتيجة مطابقة لهذا الاسم ورقم المنتوج.</div>'; return; }
 const ref=getPriceRefsForDisplay(product.id).find(r=>String(r).trim().toLowerCase()===qNumber)||qNumber;
 const buy=getPurchasePriceForRef(product.id,ref);
 result.innerHTML=`<div class="card price-result-card" style="text-align:center;margin-top:10px"><div class="small">${esc(product.name)} — ${esc(ref)}</div><div style="font-size:24px;font-weight:800;margin-top:6px">${money(buy)}</div></div>`;
}

function exportBackup(){try{const payload={version:4,exportedAt:new Date().toISOString(),stock:Array.isArray(db.stock)?db.stock:[],products:Array.isArray(db.products)?db.products:[],sales:Array.isArray(db.sales)?db.sales:[],customers:Array.isArray(db.customers)?db.customers:[],expenses:Array.isArray(db.expenses)?db.expenses:[],deliveryDocs:Array.isArray(db.deliveryDocs)?db.deliveryDocs:[],credits:Array.isArray(db.credits)?db.credits:[],checks:Array.isArray(db.checks)?db.checks:[],prices:db.prices||{},priceRefs:db.priceRefs||{},purchasePrices:db.purchasePrices||{},discountPrices:db.discountPrices||{},priceSections:getPriceSections(),priceSectionMap:db.priceSectionMap||{}};const json=JSON.stringify(payload,null,2);if(window.AndroidBackup&&typeof AndroidBackup.exportBackup==='function'){AndroidBackup.exportBackup(json);return}const blob=new Blob([json],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AFRIQUIA-BACKUP-'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);alert('تم تصدير النسخة الاحتياطية بنجاح')}catch(e){alert('تعذر تصدير البيانات: '+e.message)}}
function importBackup(file){const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x||!Array.isArray(x.stock)||!Array.isArray(x.sales)||!Array.isArray(x.customers))throw 0;if(!confirm('سيتم استبدال البيانات الحالية بالنسخة الاحتياطية. هل تريد المتابعة؟'))return;db={stock:x.stock||[],products:x.products||[],sales:x.sales||[],customers:x.customers||[],expenses:x.expenses||[],deliveryDocs:x.deliveryDocs||[],credits:x.credits||[],checks:x.checks||[],prices:x.prices||{},priceRefs:x.priceRefs||{},purchasePrices:x.purchasePrices||{},discountPrices:x.discountPrices||{},priceSections:Array.isArray(x.priceSections)&&x.priceSections.length?x.priceSections:['عام'],priceSectionMap:x.priceSectionMap||{}};save();alert('تم استرجاع البيانات بنجاح')}catch(e){alert('ملف النسخة الاحتياطية غير صالح')}};r.onerror=()=>alert('تعذر قراءة ملف النسخة الاحتياطية');r.readAsText(file)}
function save(){saveLocal();try{if(window.AndroidNotifications&&typeof AndroidNotifications.syncChecks==='function')AndroidNotifications.syncChecks(JSON.stringify(db.checks||[]));}catch(e){}render()}
function clearSalesFilters(){if(el('salesSearch'))el('salesSearch').value='';if(el('salesPeriod'))el('salesPeriod').value='all';if(el('salesCustomerSearch'))el('salesCustomerSearch').value='';render();}
function saleItemProfit(item){
 const qty=Number(item.qty||item.quantity||1), price=Number(item.price||item.salePrice||0);
 let buy=Number(item.buyPrice);
 if(!Number.isFinite(buy)) { const p=db.stock.find(x=>String(x.id)===String(item.productId)); buy=Number(p?.buy||0); }
 return (price-buy)*qty;
}
function openQuickSaleNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('quickSaleName');
 if(!input)return;
 // عند الضغط على سهم الاسم، ابدأ اختياراً جديداً وامسح الاسم/المرجع السابقين.
 if(input.value)input.value='';
 const refInput=el('quickSaleRef'); if(refInput)refInput.value='';
 const refBox=el('quickSaleRefPicker'); if(refBox)refBox.style.display='none';
 renderQuickSaleNames();
 input.focus({preventScroll:true});
 const box=el('quickSaleNamePicker'); if(box)box.style.display='block';
}
function openQuickSaleRefPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('quickSaleRef');
 if(!input)return;
 // عند الضغط على سهم المرجع، امسح المرجع السابق فقط مع الإبقاء على الاسم المختار.
 if(input.value)input.value='';
 renderQuickSaleRefs(true);
 input.focus({preventScroll:true});
 const box=el('quickSaleRefPicker'); if(box)box.style.display='block';
 const nameBox=el('quickSaleNamePicker'); if(nameBox)nameBox.style.display='none';
}
window.addEventListener('popstate',()=>{clearQuickSaleSearchFields();});
window.addEventListener('pagehide',()=>{clearQuickSaleSearchFields();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')clearQuickSaleSearchFields();});
function initQuickSaleSearchFix(){
 const nameInput=el('quickSaleName'), refInput=el('quickSaleRef');
 if(!nameInput||!refInput)return;
 nameInput.addEventListener('input',()=>{renderQuickSaleNames();if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';});
 nameInput.addEventListener('focus',()=>{renderQuickSaleNames();});
 refInput.addEventListener('input',()=>{renderQuickSaleRefs(false);});
 refInput.addEventListener('focus',()=>{if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';});
 document.addEventListener('click',function(e){
   const nameOpt=e.target.closest('#quickSaleNamePicker .search-picker-item');
   if(nameOpt){e.preventDefault();e.stopPropagation();selectQuickSaleName(nameOpt.getAttribute('data-sale-name')||nameOpt.textContent.replace(/^📦\s*/,''));return;}
   const refOpt=e.target.closest('#quickSaleRefPicker .search-picker-item');
   if(refOpt){e.preventDefault();e.stopPropagation();selectQuickSaleRef(refOpt.getAttribute('data-sale-ref')||refOpt.textContent.replace(/^🔢\s*/,''));return;}
 });
}

function renderQuickSaleNames(){
 const box=el('quickSaleNamePicker'); if(!box)return;
 const q=normalizeProductName(el('quickSaleName')?.value||'');
 const names=[...new Set((db.stock||[]).map(x=>String(x.name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ar',{numeric:true,sensitivity:'base'})).filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=names.length?names.map(n=>`<button type="button" class="search-picker-item" data-sale-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء في المخزون</div>';
 box.style.display='block';
}
function selectQuickSaleName(name){
 if(el('quickSaleName'))el('quickSaleName').value=name;
 if(el('quickSaleRef'))el('quickSaleRef').value='';
 if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';
 if(el('quickSaleNamePicker'))el('quickSaleNamePicker').style.display='none';
}
function renderQuickSaleRefs(show=true){
 const box=el('quickSaleRefPicker');
 const q=String(el('quickSaleRef')?.value||'').trim().toLowerCase();
 const name=normalizeProductName(el('quickSaleName')?.value||'');
 const refs=[...new Set((db.stock||[]).filter(x=>!name||normalizeProductName(x.name||'')===name).map(x=>String(x.ref||'').trim()).filter(Boolean))].filter(r=>!q||r.toLowerCase().includes(q));
 if(box){box.innerHTML=refs.length?sortNumbersAscending(refs).map(r=>`<button type="button" class="search-picker-item" data-sale-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أرقام لهذا الاسم</div>';box.style.display=show?'block':'none';}
}
function selectQuickSaleRef(ref){
 if(el('quickSaleRef'))el('quickSaleRef').value=ref;
 if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';
 const p=(db.stock||[]).find(x=>String(x.ref||'').trim().toLowerCase()===String(ref).trim().toLowerCase() && (!el('quickSaleName')?.value || normalizeProductName(x.name||'')===normalizeProductName(el('quickSaleName').value)));
 if(p && el('quickSaleName'))el('quickSaleName').value=p.name||'';
}
function addQuickSale(){
 const name=(el('quickSaleName')?.value||'').trim();
 const ref=(el('quickSaleRef')?.value||'').trim();
 const qty=Number(el('quickSaleQty')?.value||0);
 let price=Number(el('quickSalePrice')?.value||0);
 if(!ref)return alert('أدخل رقم المنتج');
 if(qty<=0 || !Number.isInteger(qty))return alert('أدخل كمية صحيحة');
 const stockMatch=(db.stock||[]).find(x=>String(x.ref||'').trim().toLowerCase()===ref.toLowerCase() && (!name||normalizeProductName(x.name||'')===normalizeProductName(name)));
 if(!stockMatch)return alert('اختر الاسم والرقم من المنتوجات المسجلة في المخزون');
 const catalog=getCatalogProduct(stockMatch.productId)||getCatalogProductByName(stockMatch.name);
 if(!catalog)return alert('المنتوج غير موجود في سجل المخزون');
 const canonicalRef=productNumbers(catalog).find(r=>String(r).trim().toLowerCase()===ref.toLowerCase())||ref;
 const p=db.stock.find(x=>String(x.productId)===String(catalog.id)&&String(x.ref||'').trim().toLowerCase()===String(canonicalRef).trim().toLowerCase());
 if(!p)return alert('هذا الرقم موجود في قسم المنتوجات لكنه غير موجود في المخزون');

 const available=Number(p.qty||0);
 if(qty>available)return alert('الكمية المطلوبة أكبر من المخزون المتوفر: '+available);
 if(!Number.isFinite(price) || price<=0)return alert('أدخل ثمن البيع');
 const buy=Number(p.buy||0);
 const total=qty*price;
 const profit=(price-buy)*qty;
 p.qty=available-qty;
 db.sales.push({id:Date.now()+Math.floor(Math.random()*1000),date:new Date().toISOString(),customer:{name:'زبون عابر',phone:''},items:[{productId:p.id,name:p.name||'',ref:canonicalRef,qty,price,buyPrice:buy,total,profit,remainingQty:p.qty}],total});
 save();
 if(el('quickSaleRef'))el('quickSaleRef').value='';
 if(el('quickSaleQty'))el('quickSaleQty').value='1';
 if(el('quickSalePrice'))el('quickSalePrice').value='';
 render();
 alert('تم تسجيل البيع. المتبقي في المخزون: '+p.qty+' قطعة');
}
function dailySalesData(){
 const map={};
 for(const s of db.sales){
  const d=new Date(s.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  const row=map[key]; row.ops+=1; row.revenue+=Number(s.total||0); row.profit+=saleProfit(s);
  row.qty+=saleItems(s).reduce((a,i)=>a+Number(i.qty||i.quantity||1),0);
 }
 for(const e of db.expenses){
  const d=new Date(e.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  map[key].expenses+=Number(e.amount||0);
 }
 return Object.values(map).sort((a,b)=>b.date.localeCompare(a.date));
}
function saleItemTotal(item){return Number(item.total||((Number(item.qty||item.quantity||1))*Number(item.price||item.salePrice||0)));}
function saleProfit(s){return saleItems(s).reduce((a,i)=>a+saleItemProfit(i),0)}
function saleMatchesFilters(s){
 const term=(el('salesSearch')?.value||'').trim().toLowerCase();
 const customerTerm=(el('salesCustomerSearch')?.value||'').trim().toLowerCase();
 const period=el('salesPeriod')?.value||'all';
 const items=saleItems(s);
 if(term && !items.some(i=>String(i.name||i.productName||'').toLowerCase().includes(term)||String(i.ref||'').toLowerCase().includes(term))) return false;
 const c=s.customer||{}; if(customerTerm && !String(c.name||'').toLowerCase().includes(customerTerm)) return false;
 if(period!=='all'){const d=new Date(s.date||0), now=new Date(); if(Number.isNaN(d.getTime())) return false; if(period==='day' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth()||d.getDate()!==now.getDate())) return false; if(period==='month' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth())) return false; if(period==='year' && d.getFullYear()!==now.getFullYear()) return false;}
 return true;
}
function fillCreditCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('creditCustomer')?.value||''));
 if(c){if(el('creditCustomerName'))el('creditCustomerName').value=c.name||'';if(el('creditPhone'))el('creditPhone').value=c.phone||'';}
}
function addCredit(e){
 e.preventDefault();
 const name=(el('creditCustomerName')?.value||'').trim();
 const phone=(el('creditPhone')?.value||'').trim();
 const amount=Number(el('creditAmount')?.value||0);
 if(!name)return alert('أدخل اسم الزبون');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 if(!Array.isArray(db.credits))db.credits=[];
 const customerId=el('creditCustomer')?.value||'';
 db.credits.push({id:Date.now()+Math.floor(Math.random()*1000),customerId,customerName:name,phone,date:new Date(el('creditDate')?.value||Date.now()).toISOString(),amount,note:(el('creditNote')?.value||'').trim(),paid:false});
 save(); e.target.reset(); if(el('creditDate'))el('creditDate').value=''; alert('تم تسجيل الكريدي بنجاح');
}
function markCreditPaid(id){
 const c=db.credits.find(x=>String(x.id)===String(id)); if(!c)return;
 c.paid=true; c.paidDate=new Date().toISOString(); save();
}
function deleteCredit(id){
 if(!confirm('هل تريد حذف هذا الكريدي؟'))return;
 db.credits=db.credits.filter(x=>String(x.id)!==String(id)); save();
}
function addCheck(e){
 e.preventDefault();
 if(!Array.isArray(db.checks))db.checks=[];
 const number=(el('checkNumber')?.value||'').trim();
 const beneficiary=(el('checkBeneficiary')?.value||'').trim();
 const amount=Number(el('checkAmount')?.value||0);
 if(!number)return alert('أدخل رقم الشيك');
 if(!beneficiary)return alert('أدخل اسم المستفيد');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 const date=el('checkDate')?.value||new Date().toISOString().slice(0,10);
 if((db.checks||[]).some(c=>String(c.date||'')===date)){
   return alert('غير مسموح: يوجد شيك مسجل مسبقاً في نفس التاريخ. يمكن تسجيل شيك واحد فقط في كل تاريخ.');
 }
 db.checks.push({id:Date.now()+Math.floor(Math.random()*1000),number,beneficiary,amount,date,status:el('checkStatus')?.value||'pending',note:(el('checkNote')?.value||'').trim()});
 save();e.target.reset();renderChecks();alert('تم تسجيل الشيك بنجاح');
}
function updateCheckStatus(id,status){
 const c=(db.checks||[]).find(x=>String(x.id)===String(id));if(!c)return;c.status=status;save();renderChecks();
}
function deleteCheck(id){
 if(!confirm('هل تريد حذف هذا الشيك؟'))return;db.checks=(db.checks||[]).filter(x=>String(x.id)!==String(id));save();renderChecks();
}
function renderNotifications(){
 const box=el('notificationsList'), badge=el('notificationBadge');
 if(!box)return;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const until=new Date(today); until.setDate(until.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending'||!c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today&&d<=until;
 }).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 if(badge){badge.textContent=upcoming.length;badge.style.display=upcoming.length?'inline-block':'none';}
 box.innerHTML=upcoming.length?upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-bottom:10px;background:#fff8e1;border-right:4px solid #f0ad4e"><b>🔔 شيك رقم ${esc(c.number)}</b><div style="margin-top:6px">المستفيد: ${esc(c.beneficiary)}</div><div>المبلغ: <b>${money(c.amount)}</b></div><div>تاريخ الدخول: <b>${esc(c.date)}</b> — ${when}</div></div>`}).join(''):'<div class="empty card">لا توجد إشعارات حالياً.</div>';
}
function renderChecks(){
 if(!el('checkList'))return;if(!Array.isArray(db.checks))db.checks=[];
 const numberSearch=(el('checkNumberSearch')?.value||'').trim().toLowerCase();
 const beneficiarySearch=(el('checkBeneficiarySearch')?.value||'').trim().toLowerCase();
 const noteSearch=(el('checkNoteSearch')?.value||'').trim().toLowerCase();
 const checkMatches=c=>(!numberSearch||String(c.number||'').toLowerCase().includes(numberSearch))&&(!beneficiarySearch||String(c.beneficiary||'').toLowerCase().includes(beneficiarySearch))&&(!noteSearch||String(c.note||'').toLowerCase().includes(noteSearch));
 const rows=db.checks.filter(checkMatches).slice().sort((a,b)=>new Date(a.date||'9999-12-31')-new Date(b.date||'9999-12-31'));
 const total=rows.reduce((a,c)=>a+Number(c.amount||0),0);
 const pending=rows.filter(c=>c.status==='pending').reduce((a,c)=>a+Number(c.amount||0),0);
 const cashed=rows.filter(c=>c.status==='cashed').reduce((a,c)=>a+Number(c.amount||0),0);
 const sum=el('checkSummary');if(sum)sum.innerHTML=`<div class="card">مجموع الشيكات<b>${money(total)}</b><span class="small">${rows.length} شيك</span></div><div class="card">في الانتظار<b>${money(pending)}</b></div><div class="card">تم صرفه<b>${money(cashed)}</b></div>`;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const alertUntil=new Date(today); alertUntil.setDate(alertUntil.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending' || !c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today && d<=alertUntil;
 }).filter(checkMatches).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const alerts=el('checkAlerts');
 if(alerts){
   alerts.style.display=upcoming.length?'block':'none';
   alerts.innerHTML=upcoming.length?'<h3>🔔 إشعار الشيكات القريبة</h3><div class="small">هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:</div>'+upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-top:8px;background:#fff8e1"><b>شيك ${esc(c.number)}</b> — ${esc(c.beneficiary)} — ${money(c.amount)}<br><span class="small">تاريخ الشيك: ${esc(c.date)} • ${when}</span></div>`}).join(''):'';
 }
 const scheduled=(db.checks||[]).filter(c=>c.status==='pending' && String(c.date||'')>=today.toISOString().slice(0,10)).filter(checkMatches).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const sched=el('scheduledCheckList'); if(sched) sched.innerHTML=scheduled.length?'<div style="overflow:auto"><table><tr><th>رقم الشيك</th><th>المستفيد</th><th>المبلغ</th><th>تاريخ الشيك</th></tr>'+scheduled.map(c=>`<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td></tr>`).join('')+'</table></div>':'<div class="empty">لا توجد شيكات مبرمجة</div>';
 el('checkList').innerHTML=rows.length?'<div class="card"><h3>📋 جميع الشيكات — الأقرب تاريخاً أولاً</h3><div style="overflow:auto"><table><tr><th>الرقم</th><th>المستفيد</th><th>المبلغ</th><th>التاريخ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>{const status=c.status==='cashed'?'<span class="badge">تم صرفه</span>':c.status==='cancelled'?'<span class="badge" style="background:#fde8e8;color:#a33">ملغى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">في الانتظار</span>';return `<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td><td>${status}</td><td><select onchange="updateCheckStatus('${c.id}',this.value)"><option value="pending" ${c.status==='pending'?'selected':''}>في الانتظار</option><option value="cashed" ${c.status==='cashed'?'selected':''}>تم صرفه</option><option value="cancelled" ${c.status==='cancelled'?'selected':''}>ملغى</option></select><button type="button" class="danger" onclick="deleteCheck('${c.id}')">🗑️</button></td></tr>`}).join('')+'</table></div></div>':'<div class="empty card">لا توجد شيكات مسجلة</div>';
}
function todayISO(){
 const d=new Date();
 const pad=n=>String(n).padStart(2,'0');
 return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
}
function saveDailyExpenseOne(){
 const date=el('dailyOneDate')?.value||todayISO();
 const name=String(el('dailyOneName')?.value||'').trim();
 const amountText=String(el('dailyOneAmount')?.value||'').trim();
 const normalizedAmount=amountText.replace(',', '.');
 const amount=Number(normalizedAmount);
 if(!date){alert('اختر التاريخ');return false;}
 if(!name){alert('أدخل نوع المصروف');return false;}
 if(!amountText || !Number.isFinite(amount) || amount<0){alert('أدخل مبلغاً صحيحاً');return false;}
 if(!Array.isArray(db.expenses)) db.expenses=[];
 const item={id:'exp_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),date:date+'T12:00:00',name:name,amount:amount};
 db.expenses.push(item);
 try{
   saveLocal();
   const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
   if(!saved || !Array.isArray(saved.expenses) || !saved.expenses.some(x=>String(x.id)===String(item.id))) throw new Error('لم يتم تأكيد الحفظ');
 }catch(e){
   db.expenses=db.expenses.filter(x=>String(x.id)!==String(item.id));
   alert('تعذر حفظ المصروف في ذاكرة الهاتف');
   return false;
 }
 renderDailyExpenseEntry();
 renderExpenses();
 const d=el('dailyOneDate'), n=el('dailyOneName'), a=el('dailyOneAmount');
 if(d)d.value=date; if(n){n.value='';n.focus();} if(a)a.value='';
 alert('تم حفظ المصروف بنجاح');
 return true;
}

function deleteDailyExpense(id){
 if(!id)return;
 if(!confirm('هل تريد حذف هذا المصروف؟'))return;
 db.expenses=(db.expenses||[]).filter(x=>String(x.id||'')!==String(id));
 save();
 renderDailyExpenseEntry();
 renderExpenses();
}
function renderDailyExpenseEntry(){
 const box=el('dailyExpenseEntry');
 if(!box)return;
 const entries=(Array.isArray(db.expenses)?db.expenses:[]).map((x,i)=>({...x,__i:i})).sort((a,b)=>{const da=Date.parse(a.date||'')||0, dbb=Date.parse(b.date||'')||0; return dbb-da || (b.__i-a.__i);});
 const rows=entries.map(x=>{
   const dt=new Date(x.date||'');
   const date=!Number.isNaN(dt.getTime())?dt.toLocaleDateString('ar-MA') : String(x.date||'-').slice(0,10);
   const id=String(x.id||x.__i);
   if(!x.id)x.id=id;
   return `<tr><td>${esc(date)}</td><td>${esc(x.name||'-')}</td><td class="daily-amount-cell"><span class="daily-amount">${money(x.amount||0)}</span></td><td><button type="button" class="daily-delete-one" onclick="deleteDailyExpense('${esc(id)}')">×</button></td></tr>`;
 }).join('');
 box.innerHTML=`<div class="daily-entry-title">📅 إضافة المصاريف اليومية</div>
 <div class="daily-one-form">
   <label>تاريخ اليوم</label>
   <input id="dailyOneDate" type="date" value="${todayISO()}">
   <label>نوع المصروف</label>
   <input id="dailyOneName" type="text" placeholder="اكتب نوع المصروف">
   <label>المبلغ</label>
   <input id="dailyOneAmount" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0.00 DH">
   <button type="button" class="danger daily-save-one" onclick="saveDailyExpenseOne()">💾 حفظ المصروف اليومي</button>
 </div>
 <div class="daily-saved-title">📋 المصاريف التي تم تسجيلها</div>
 <div class="daily-expenses-total"><span>مجموع المصاريف</span><b>${money((Array.isArray(db.expenses)?db.expenses:[]).reduce((sum,x)=>sum+Number(x.amount||0),0))}</b></div>
 <div class="daily-entry-wrap"><table class="daily-saved-table"><thead><tr><th>التاريخ</th><th>نوع المصروف</th><th>المبلغ</th><th></th></tr></thead><tbody id="dailyExpenseRows">${rows || '<tr><td colspan="4" class="daily-empty">لا توجد مصاريف مسجلة بعد</td></tr>'}</tbody></table></div>`;
}

function renderExpenses(){
 renderDailyExpenseEntry();
 const type=el('expSearchType'), value=el('expSearchValue'), year=el('expSearchYear'), list=el('expList');
 if(!type||!value||!list)return;
 const currentType=type.value||'';
 const currentValue=value.value||'';
 const currentYear=year?.value||'';
 const expenses=Array.isArray(db.expenses)?db.expenses:[];
 const years=[...new Set(expenses.map(x=>{const d=new Date(x.date||0);return Number.isNaN(d.getTime())?null:d.getFullYear();}).filter(y=>y))].sort((a,b)=>b-a);
 const months=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
 if(currentType==='month'){
   value.innerHTML='<option value="">اختر الشهر</option>'+months.map((m,i)=>`<option value="${i+1}">${m}</option>`).join('');
   value.value=currentValue;
   if(year){year.style.display='block';year.innerHTML='<option value="">اختر السنة</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');year.value=currentYear;}
 }else if(currentType==='year'){
   value.innerHTML='<option value="">اختر السنة</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
   value.value=currentValue;
   if(year){year.style.display='none';year.innerHTML='<option value=""></option>';year.value='';}
 }else{
   value.innerHTML='<option value="">اختر أولاً نوع البحث</option>';
   if(year){year.style.display='none';year.innerHTML='<option value=""></option>';year.value='';}
 }
 if(!currentType || !currentValue || (currentType==='month' && !currentYear)){
   list.innerHTML='';
   return;
 }
 const amountForDay=(y,m,d)=>expenses.filter(x=>{const dt=new Date(x.date||0);return !Number.isNaN(dt.getTime())&&dt.getFullYear()===y&&dt.getMonth()+1===m&&dt.getDate()===d;}).reduce((a,x)=>a+Number(x.amount||0),0);
 const entriesForDay=(y,m,d)=>expenses.filter(x=>{const dt=new Date(x.date||0);return !Number.isNaN(dt.getTime())&&dt.getFullYear()===y&&dt.getMonth()+1===m&&dt.getDate()===d;});
 if(currentType==='month'){
   const m=Number(currentValue), y=Number(currentYear), daysInMonth=new Date(y,m,0).getDate();
   let monthTotal=0;
   const rows=[];
   for(let d=1;d<=daysInMonth;d++){
     const total=amountForDay(y,m,d); monthTotal+=total;
     const dayEntries=entriesForDay(y,m,d);
     const details=dayEntries.length?dayEntries.map(x=>`${esc(x.name)}: ${money(x.amount)}`).join('<br>'):'<span class="small">0.00 DH</span>';
     rows.push(`<tr><td>${d}</td><td>${details}</td><td><b>${money(total)}</b></td></tr>`);
   }
   list.innerHTML=`<div class="card expense-report-card" style="margin-top:8px;padding:8px"><div class="card expense-total-box" style="text-align:center;margin:0 0 10px;padding:16px 10px;border:3px solid #0b4f8a;border-radius:14px;background:#f7fbff"><span style="font-size:20px;font-weight:bold;display:block">جميع مصاريف الشهر ${esc(months[m-1])} سنة ${y}</span><b style="font-size:30px;display:block;margin-top:6px">${money(monthTotal)}</b></div><h3 style="margin:2px 0 6px;font-size:14px">📅 ${esc(months[m-1])} ${y}</h3><div style="overflow:auto"><table class="expense-report-table"><tr><th>اليوم</th><th>المصاريف</th><th>مجموع اليوم</th></tr>${rows.join('')}</table></div></div>`;
   return;
 }
 if(currentType==='year'){
   const y=Number(currentValue);
   const monthlyTotals=Array.from({length:12},(_,i)=>({month:i+1,total:0}));
   expenses.forEach(x=>{const d=new Date(x.date||0);if(!Number.isNaN(d.getTime())&&d.getFullYear()===y)monthlyTotals[d.getMonth()].total+=Number(x.amount||0);});
   const annualTotal=monthlyTotals.reduce((a,x)=>a+x.total,0);
   const rows=monthlyTotals.map((m,i)=>`<tr><td>${i+1}</td><td>${months[i]}</td><td><b>${money(m.total)}</b></td></tr>`).join('');
   list.innerHTML=`<div class="card expense-report-card" style="margin-top:8px;padding:8px"><div class="card expense-total-box" style="text-align:center;margin:0 0 10px;padding:16px 10px;border:3px solid #0b4f8a;border-radius:14px;background:#f7fbff"><span style="font-size:20px;font-weight:bold;display:block">جميع مصاريف السنة ${y}</span><b style="font-size:30px;display:block;margin-top:6px">${money(annualTotal)}</b></div><h3 style="margin:2px 0 6px;font-size:14px">📅 مصاريف سنة ${y}</h3><div style="overflow:auto"><table class="expense-report-table"><tr><th>رقم الشهر</th><th>الشهر</th><th>مجموع الشهر</th></tr>${rows}</table></div></div>`;
 }
}

function renderCredit(){
 if(!el('creditList'))return;
 if(!Array.isArray(db.credits))db.credits=[];
 const open=db.credits.filter(x=>!x.paid), paid=db.credits.filter(x=>x.paid);
 const openTotal=open.reduce((a,x)=>a+Number(x.amount||0),0), paidTotal=paid.reduce((a,x)=>a+Number(x.amount||0),0);
 const sum=el('creditSummary'); if(sum)sum.innerHTML=`<div class="card">المستحق حالياً<b>${money(openTotal)}</b></div><div class="card">عدد الديون<b>${open.length}</b></div>`;
 const sel=el('creditCustomer'); if(sel){const current=sel.value;sel.innerHTML='<option value="">اختر الزبون</option>'+db.customers.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}${c.phone?' - '+esc(c.phone):''}</option>`).join('');if(current)sel.value=current;}
 const nameSearch=(el('creditNameSearch')?.value||'').trim().toLowerCase();
 const phoneSearch=(el('creditPhoneSearch')?.value||'').trim().toLowerCase();
 const noteSearch=(el('creditNoteSearch')?.value||'').trim().toLowerCase();
 const rows=db.credits.filter(c=>{return (!nameSearch||String(c.customerName||'').toLowerCase().includes(nameSearch))&&(!phoneSearch||String(c.phone||'').toLowerCase().includes(phoneSearch))&&(!noteSearch||String(c.note||'').toLowerCase().includes(noteSearch));}).slice().sort((a,b)=>new Date(b.date||0)-new Date(a.date||0));
 el('creditList').innerHTML=rows.length?'<div class="card"><table><tr><th>التاريخ</th><th>الزبون</th><th>المبلغ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>`<tr><td>${esc(new Date(c.date||0).toLocaleDateString('ar-MA'))}</td><td>${esc(c.customerName||'-')}<div class="small">${esc(c.phone||'')}</div>${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${c.paid?'<span class="badge">مؤدى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">باقي</span>'}</td><td>${c.paid?'':'<button type="button" onclick="markCreditPaid(\''+c.id+'\')">✅ تسديد</button>'}<button type="button" class="danger" onclick="deleteCredit(\''+c.id+'\')">🗑️</button></td></tr>`).join('')+'</table></div>':'<div class="empty card">لا توجد ديون مسجلة</div>';
}
function renderProductCardsSearch(){ render(); const q=el('productCardsSearch'); if(q){ try{q.focus(); const pos=q.value.length; q.setSelectionRange(pos,pos);}catch(e){} } }
function render(){
 syncStockPurchasePrices();
 renderProductSection();
 syncCatalogLinks();
 renderStockProductOptions();
 renderStockRefOptions(el('pref')?.value||'');
 renderStockSearchOptions();
 renderQuickSaleRefs(false);
 el('cStock').textContent=money(db.stock.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0));
 const nowForHome=new Date();
 const lastMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth()-1,1);
 const thisMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth(),1);
 const lastMonthSales=db.sales.reduce((sum,x)=>{const d=new Date(x.date||0); return d>=lastMonthStart && d<thisMonthStart ? sum+Number(x.total||0) : sum;},0);
 el('cSales').textContent=money(db.sales.reduce((a,x)=>a+Number(x.total||0),0));
 el('cLastMonthSales').textContent=money(lastMonthSales);
 el('cExp').textContent=money(db.expenses.reduce((a,x)=>a+Number(x.amount||0),0));
 const creditTotal=(db.credits||[]).filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0); if(el('cCredit'))el('cCredit').textContent=money(creditTotal);
 const nameTerm=normalizeProductName(el('stockNameSearch')?.value||'');
 const term=(el('stockSearch')?.value||'').trim().toLowerCase();
 const filtered=db.stock.filter(x=>{const name=normalizeProductName(x.name||'');const ref=String(x.ref||'').toLowerCase();return (!nameTerm||name===nameTerm)&&(!term||ref===term);});
 const searchReady=!!nameTerm&&!!term;
 const totalQty=filtered.reduce((a,x)=>a+Number(x.qty||0),0);
 const totalBuy=filtered.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0);
 const searchedProduct=searchReady && filtered.length===1 ? filtered[0] : null;
 el('searchStats').innerHTML=(nameTerm||term)?`<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px"><div>📦 <b>${nameTerm?esc(el('stockNameSearch')?.value||'-'):'-'}</b></div><div>🔢 الرقم: <b>${term?esc(el('stockSearch')?.value||'-'):'-'}</b></div><div>🔢 مجموع العدد: <b>${totalQty}</b></div><div>💰 إجمالي الشراء: <b>${money(totalBuy)}</b></div></div>`:'';
 const accountingRows=filtered.map(x=>{const qty=Number(x.qty||0);const buy=Number(x.buy||0);const productTotal=qty*buy;return `<tr><td>${esc(x.name||'-')}</td><td>${esc(x.ref||'-')}</td><td><b>${qty}</b></td><td><b>${money(productTotal)}</b></td></tr>`}).join('');
 const displayRows=searchReady?filtered:db.stock;
 const totalAllValue=displayRows.reduce((a,x)=>a+Number(x.qty||0)*Number(x.buy||0),0);
 const grouped=new Map();
 displayRows.forEach(x=>{const key=normalizeProductName(x.name||'');if(!grouped.has(key)) grouped.set(key,{name:x.name||'-',image:x.image||'',items:[]});const g=grouped.get(key);if(!g.image&&x.image)g.image=x.image;g.items.push(x);});
 const groups=[...grouped.values()].sort((a,b)=>a.name.localeCompare(b.name,'ar',{numeric:true,sensitivity:'base'}));
 const cardSearch=String(el('productCardsSearch')?.value||'').trim().toLowerCase();
 const searchedGroups=cardSearch?groups.filter(g=>String(g.name||'').toLowerCase().includes(cardSearch)||g.items.some(x=>String(x.ref||'').toLowerCase().includes(cardSearch))):groups;
 const visibleGroups = selectedStockCardName ? searchedGroups.filter(g=>normalizeProductName(g.name)===normalizeProductName(selectedStockCardName)) : searchedGroups;
 el('stockList').innerHTML=visibleGroups.length?`<div class="stock-total-banner">${selectedStockCardName?'<button type="button" onclick="clearStockCardSelection()" style="margin-bottom:8px;width:100%">⬅️ رجوع إلى جميع المنتوجات</button>':''}<span>${selectedStockCardName?'📦 معلومات المنتوج المختار':'إجمالي قيمة المنتجات المعروضة'}</span><b>${selectedStockCardName?esc(visibleGroups[0].name):money(totalAllValue)}</b></div>`+visibleGroups.map(g=>{
   const totalQty=g.items.reduce((a,x)=>a+Number(x.qty||0),0);
   const totalValue=g.items.reduce((a,x)=>a+Number(x.qty||0)*Number(x.buy||0),0);
   const rows=[...g.items].sort((a,b)=>{const na=Number(String(a.ref||'').replace(/[^0-9.-]/g,''));const nb=Number(String(b.ref||'').replace(/[^0-9.-]/g,''));if(Number.isFinite(na)&&Number.isFinite(nb)&&na!==nb)return nb-na;return String(b.ref||'').localeCompare(String(a.ref||''),'ar',{numeric:true})}).map(x=>{const q=Number(x.qty||0),buy=Number(x.buy||0),v=q*buy;return `<tr><td class="ref-cell">${esc(x.ref||'-')}</td><td><b>${q}</b></td><td>${money(buy)}</td><td class="sum-cell">${money(v)}</td><td class="edit-cell"><button type="button" onclick="event.stopPropagation();editStock(${x.id})">✏️</button></td></tr>`}).join('');
   const refs=`<div style="overflow-x:auto"><table class="stock-items-table"><thead><tr><th>رقم المنتوج</th><th>العدد</th><th>ثمن الشراء</th><th>مجموع الثمن</th><th>تعديل</th></tr></thead><tbody>${rows}</tbody></table></div><div class="stock-card-bottom-total"><span>💰 مجموع الثمن</span><strong>${money(totalValue)}</strong></div>`;
   const encodedName=encodeURIComponent(g.name);
   return `<div class="stock-card-v11 stock-color-${groups.indexOf(g)%10} ${selectedStockCardName?'stock-card-selected':''}" onclick="selectStockCard(decodeURIComponent('${encodedName}'))"><div class="stock-card-head">${g.image?`<img class="stock-card-image" src="${g.image}" alt="${esc(g.name)}">`:'<div class="stock-card-image" style="display:flex;align-items:center;justify-content:center;font-size:38px">📦</div>'}<div><div class="stock-card-name">${esc(g.name)}</div><div class="stock-card-summary">${g.items.length} رقم مسجل</div></div></div>${refs}<div class="stock-card-actions"><button type="button" onclick="event.stopPropagation();editStock(${g.items[0].id})">✏️ تعديل جميع المعلومات</button></div></div>`;
 }).join(''):`<div class="empty card">${db.stock.length?'لا توجد نتائج للبحث':'لا توجد سلع في المخزون بعد'}</div>`;
 const now=new Date();
 const todaySales=db.sales.filter(x=>{const d=new Date(x.date);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).slice().reverse();
 const filteredRevenue=todaySales.reduce((a,x)=>a+Number(x.total||0),0), filteredProfit=todaySales.reduce((a,x)=>a+saleProfit(x),0);
 const todayExpenses=db.expenses.filter(x=>{const d=new Date(x.date||0);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).reduce((a,x)=>a+Number(x.amount||0),0);
 const monthSales=db.sales.filter(x=>{const d=new Date(x.date||0);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth();});
 const monthlyRevenue=monthSales.reduce((a,x)=>a+Number(x.total||0),0);
 const _dNow=new Date();
  const _daysAr=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const _monthsAr=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
  const _dateAr=`${_daysAr[_dNow.getDay()]} ${_dNow.getDate()} ${_monthsAr[_dNow.getMonth()]} ${_dNow.getFullYear()}`;
  const _monthAr=`شهر ${_monthsAr[_dNow.getMonth()]} ${_dNow.getFullYear()}`;
  el('salesSummary').innerHTML=`<div class="card sales-expense-card">مصاريف اليوم<span class="date-label">${_dateAr}</span><b>${money(todayExpenses)}</b></div><div class="card sales-income-card">المدخول اليومي<span class="date-label">${_dateAr}</span><b>${money(filteredRevenue)}</b></div><div class="card sales-month-card monthly-income-card">المدخول الشهري<span class="date-label">${_monthAr}</span><b>${money(monthlyRevenue)}</b></div><div class="card sales-profit-card profit-card">الأرباح اليوم<span class="date-label">${_dateAr}</span><b>${money(filteredProfit)}</b></div>`;
 el('salesRows').innerHTML=todaySales.length?todaySales.flatMap(x=>saleItems(x).map(it=>{const d=new Date(x.date),profit=saleItemProfit(it),price=Number(it.price||it.salePrice||0),qty=Number(it.qty||it.quantity||1),revenue=saleItemTotal(it);const p=db.stock.find(z=>String(z.id)===String(it.productId)||String(z.ref||'')===String(it.ref||''));const remaining=it.remainingQty!==undefined?Number(it.remainingQty):(p?Number(p.qty||0):'-');return `<tr><td class="sales-date">${esc(d.toLocaleDateString('ar-MA'))}</td><td>${esc(it.ref||'-')}</td><td>${qty}</td><td>${money(price)}</td><td class="${profit>=0?'profit-positive':'profit-negative'}">${money(profit)}</td><td><b>${remaining}</b></td></tr>`})).join(''):'<tr><td colspan="6" style="text-align:center;padding:18px">لا توجد مبيعات اليوم</td></tr>';
 const daily=dailySalesData();
 el('dailySalesRows').innerHTML=daily.length?daily.map(r=>`<tr><td class="sales-date">${esc(r.date)}</td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${(r.profit-r.expenses)>=0?'profit-positive':'profit-negative'}">${money(r.profit-r.expenses)}</td></tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';

 // الملخص الشهري: يجمع كل المداخيل والمصاريف والأرباح والصافي لكل شهر موجود في البيانات.
 const monthlyMap=new Map();
 (db.sales||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
   const row=monthlyMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.revenue+=Number(x.total||0); row.profit+=saleProfit(x); row.salesCount+=1; monthlyMap.set(key,row);
 });
 (db.expenses||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
   const row=monthlyMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.expenses+=Number(x.amount||0); row.expenseCount+=1; monthlyMap.set(key,row);
 });
 const monthlyRows=[...monthlyMap.values()].sort((a,b)=>b.key.localeCompare(a.key));
 const monthNamesAr=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
 const monthLabel=(key)=>{const [yy,mm]=key.split('-').map(Number);return `${monthNamesAr[(mm||1)-1]} ${yy}`;};
 const monthlyRevenueTotal=monthlyRows.reduce((a,r)=>a+r.revenue,0);
 const monthlyProfitTotal=monthlyRows.reduce((a,r)=>a+r.profit,0);
 const monthlyExpenseTotal=monthlyRows.reduce((a,r)=>a+r.expenses,0);
 if(el('monthlySalesRows')) el('monthlySalesRows').innerHTML=monthlyRows.length?monthlyRows.map(r=>{const net=r.revenue-r.expenses;return `<tr><td class="sales-date"><b>${esc(monthLabel(r.key))}</b></td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${net>=0?'profit-positive':'profit-negative'}">${money(net)}</td><td>${r.expenseCount}</td></tr>`}).join(''):'<tr><td colspan="7" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';
 if(el('monthlySalesTotal')) el('monthlySalesTotal').innerHTML=monthlyRows.length?`<tr><th>المجموع</th><th>${money(monthlyRevenueTotal)}</th><th>${money(monthlyProfitTotal)}</th><th>${money(monthlyExpenseTotal)}</th><th class="${(monthlyRevenueTotal-monthlyExpenseTotal)>=0?'profit-positive':'profit-negative'}">${money(monthlyRevenueTotal-monthlyExpenseTotal)}</th><th>${monthlyRows.reduce((a,r)=>a+r.expenseCount,0)}</th></tr>`:'';

 // الملخص السنوي: يجمع نفس بيانات الملخص الشهري حسب كل سنة.
 const annualMap=new Map();
 (db.sales||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=String(d.getFullYear());
   const row=annualMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.revenue+=Number(x.total||0); row.profit+=saleProfit(x); row.salesCount+=1; annualMap.set(key,row);
 });
 (db.expenses||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=String(d.getFullYear());
   const row=annualMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.expenses+=Number(x.amount||0); row.expenseCount+=1; annualMap.set(key,row);
 });
 const annualRows=[...annualMap.values()].sort((a,b)=>Number(b.key)-Number(a.key));
 const annualRevenueTotal=annualRows.reduce((a,r)=>a+r.revenue,0);
 const annualProfitTotal=annualRows.reduce((a,r)=>a+r.profit,0);
 const annualExpenseTotal=annualRows.reduce((a,r)=>a+r.expenses,0);
 if(el('annualSalesRows')) el('annualSalesRows').innerHTML=annualRows.length?annualRows.map(r=>{const net=r.revenue-r.expenses;return `<tr><td class="sales-date"><b>${esc(r.key)}</b></td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${net>=0?'profit-positive':'profit-negative'}">${money(net)}</td><td>${r.expenseCount}</td></tr>`}).join(''):'<tr><td colspan="7" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';
 if(el('annualSalesTotal')) el('annualSalesTotal').innerHTML=annualRows.length?`<tr><th>المجموع</th><th>${money(annualRevenueTotal)}</th><th>${money(annualProfitTotal)}</th><th>${money(annualExpenseTotal)}</th><th class="${(annualRevenueTotal-annualExpenseTotal)>=0?'profit-positive':'profit-negative'}">${money(annualRevenueTotal-annualExpenseTotal)}</th><th>${annualRows.reduce((a,r)=>a+r.expenseCount,0)}</th></tr>`:'';
 el('custList').innerHTML=db.customers.length?'<table><tr><th>الزبون</th><th>الهاتف</th></tr>'+db.customers.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||'-')}</td></tr>`).join('')+'</table>':'<div class="empty">لا يوجد زبائن</div>';
 renderExpenses();
 const reportInput=el('reportMonth');
if(reportInput && !reportInput.value){
  const d=new Date(); reportInput.value=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
if(el('monthlyReportCards')){
  const ym=reportInput?.value||'';
  const [ry,rm]=ym.split('-').map(Number);
  const reportYear=el('reportYear');
  if(reportYear && !reportYear.value) reportYear.value=ry || new Date().getFullYear();
  const selectedYear=Number(reportYear?.value||new Date().getFullYear());
  const inMonth=(date)=>{const d=new Date(date||0);return d.getFullYear()===ry && d.getMonth()+1===rm;};
  const inYear=(date)=>{const d=new Date(date||0);return d.getFullYear()===selectedYear;};
  const ms=db.sales.filter(x=>inMonth(x.date));
  const me=db.expenses.filter(x=>inMonth(x.date));
  const mc=(db.credits||[]).filter(x=>inMonth(x.date));
  const salesTotal=ms.reduce((a,x)=>a+Number(x.total||0),0);
  const profitTotal=ms.reduce((a,x)=>a+saleProfit(x),0);
  const expensesTotal=me.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditAdded=mc.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditOpen=mc.filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0);
  const net=profitTotal-expensesTotal;
  el('monthlyReportCards').innerHTML=
    `<div class="card">مجموع المبيعات الشهرية<b>${money(salesTotal)}</b><span class="small">${ms.length} عملية</span></div>
     <div class="card">مجموع أرباح الشهر<b>${money(profitTotal)}</b><span class="small">قبل المصاريف</span></div>
     <div class="card">مجموع المصاريف الشهرية<b>${money(expensesTotal)}</b><span class="small">${me.length} مصروف</span></div>
     <div class="card">صافي الربح بعد المصاريف<b>${money(net)}</b><span class="small">الأرباح − المصاريف</span></div>
     <div class="card">مجموع الكريدي المسجل<b>${money(creditAdded)}</b><span class="small">خلال الشهر المختار</span></div>
     <div class="card">الكريدي المتبقي<b>${money(creditOpen)}</b><span class="small">غير المؤدى من كريدي الشهر</span></div>
     <div class="card">عدد عمليات البيع<b>${ms.length}</b><span class="small">خلال الشهر</span></div>`;
  const yearlyCashedChecks=(db.checks||[]).filter(c=>c.status==='cashed' && inYear(c.date));
  const yearlyCashedAmount=yearlyCashedChecks.reduce((a,c)=>a+Number(c.amount||0),0);
  const yearlyChecksTotal=(db.checks||[]).filter(c=>inYear(c.date)).reduce((a,c)=>a+Number(c.amount||0),0);
  if(el('annualCheckReport')) el('annualCheckReport').innerHTML=
    `<div class="card"><h3 style="margin-top:0">💰 حساب صرف الشيكات السنوي — ${selectedYear}</h3><span class="small">إجمالي قيمة الشيكات التي تم وضع حالتها "تم صرفه" خلال السنة</span><b>${money(yearlyCashedAmount)}</b><span class="small">عدد الشيكات المصروفة: ${yearlyCashedChecks.length}</span></div>
     <div class="card">إجمالي الشيكات المسجلة في السنة<b>${money(yearlyChecksTotal)}</b><span class="small">يشمل جميع الحالات</span></div>`;
}
 renderDeliveryEditor();
 renderCredit();
 renderNotifications();
 renderChecks();
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
window.addEventListener('load',()=>{initQuickSaleSearchFix();const sp=el('saleProduct');if(sp)sp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(sp.value));if(p)el('salePrice').value=''});const dp=el('deliveryProduct');if(dp)dp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(dp.value));if(p){const c=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);el('deliveryProductName').value=c?.name||p.name||'';el('deliveryProductRef').value=p.ref||'';el('deliveryProductPrice').value='';}});const f=el('backupFile');if(f)f.addEventListener('change',e=>{if(e.target.files[0])importBackup(e.target.files[0])});render();renderCart()});


(function(){
  const AFZ_TRANSLATIONS = {"💰 جميع أثمان المنتجات":"💰 Tous les prix des produits", "🪪 البطاقات التعريفية للمنتوجات":"🪪 Fiches produits", "1️⃣ اسم المنتوج أولاً":"1️⃣ Nom du produit d’abord", "2️⃣ رقم المنتوج ثانياً":"2️⃣ Référence du produit ensuite", "المنتوجات":"Produits", "🔍 ابحث باسم المنتوج":"🔍 Rechercher par nom du produit", "🔍 بحث في بطاقات المنتوجات بالاسم أو الرقم":"🔍 Rechercher dans les fiches produits par nom ou référence", "➕ إضافة منتوج":"➕ Ajouter un produit", "اسم المنتوج":"Nom du produit", "📷 صورة المنتوج":"📷 Image du produit", "حفظ المنتوج":"Enregistrer le produit", "تعديل":"Modifier", "حذف":"Supprimer", "تم حفظ المنتوج بنجاح":"Produit enregistré avec succès", "تم تعديل المنتوج بنجاح":"Produit modifié avec succès", "حذف هذا المنتوج؟":"Supprimer ce produit ?", "لا توجد منتوجات بعد":"Aucun produit pour le moment", "لا توجد نتائج للبحث":"Aucun résultat", "تسيير المخزون والمبيعات والحسابات": "Gestion du stock, des ventes et de la comptabilité", "الرئيسية": "Accueil", "المخزون": "Stock", "المبيعات": "Ventes", "الزبائن": "Clients", "وصل التسليم": "Bon de livraison", "مصاريف اليوم": "Dépenses du jour", "الكريدي": "Crédit", "دفتر الشيكات": "Carnet de chèques", "الإشعارات": "Notifications", "التقارير": "Rapports", "نسخة احتياطية": "Sauvegarde", "مجموع رأس مال المخزون": "Valeur totale du stock", "حسب ثمن الشراء": "Selon le prix d'achat", "مبيعات اليوم": "Ventes du jour", "إجمالي المبيعات": "Total des ventes", "أرباح اليوم": "Bénéfice du jour", "صافي ربح مبيعات اليوم": "Bénéfice net des ventes du jour", "مبيعات الشهر الماضي": "Ventes du mois précédent", "إجمالي مبيعات الشهر السابق": "Total des ventes du mois précédent", "المسجلة": "Enregistrées", "مجموع الكريدي": "Total du crédit", "إجمالي المبالغ غير المؤداة": "Total des montants impayés", "🔍 ابحث بالمرجع أو اسم المنتوج": "🔍 Rechercher par référence ou nom du produit", "🔍 بحث باسم الزبون": "🔍 Rechercher par nom du client", "📞 بحث بالهاتف": "📞 Rechercher par téléphone", "📝 بحث بالملاحظة": "📝 Rechercher par remarque", "🔢 بحث برقم الشيك": "🔢 Rechercher par numéro de chèque", "🔍 بحث باسم المستفيد": "🔍 Rechercher par bénéficiaire", "تحميل بيانات المخزون PDF": "📄 Télécharger le stock en PDF", "إضافة قطعة": "Ajouter un article", "اسم القطعة": "Nom de l'article", "المرجع / Référence": "Référence", "الكمية": "Quantité", "ثمن الشراء DH": "Prix d'achat DH", "صورة المنتوج": "📷 Image du produit", "حفظ القطعة": "Enregistrer l'article", "📊 تسجيل مبيعات اليوم": "📊 Enregistrer les ventes du jour", "تسجيل مبيعات اليوم": "Enregistrer les ventes du jour", "رقم المنتج": "Référence produit", "➕ إضافة بيع": "➕ Ajouter la vente", "التاريخ": "Date", "الأرباح": "Bénéfice", "المتبقي": "Restant", "لا توجد مبيعات اليوم": "Aucune vente aujourd'hui", "📅 الملخص اليومي": "📅 Résumé quotidien", "الملخص اليومي": "Résumé quotidien", "المدخول اليومي": "Chiffre d'affaires du jour", "المدخول الشهري": "Chiffre d'affaires du mois", "الصافي": "Net", "لا توجد بيانات": "Aucune donnée", "تحرير بون دوليفريزون مستقل": "Créer un bon de livraison indépendant", "هذا القسم مستقل تماماً عن قسم المبيعات. إنشاء وتعديل وصل التسليم هنا لا ينشئ بيعاً ولا يغيّر المخزون.": "Cette section est totalement indépendante des ventes. La création ou la modification d'un bon de livraison ici ne crée pas de vente et ne modifie pas le stock.", "اختر الزبون من قسم الزبائن": "Choisir le client depuis la section Clients", "اسم الزبون": "Nom du client", "هاتف الزبون": "Téléphone du client", "عنوان الزبون": "Adresse du client", "إضافة منتج إلى الوصل": "Ajouter un produit au bon", "اسم المنتج": "Nom du produit", "العدد": "Quantité", "الثمن": "Prix", "➕ إضافة المنتج": "➕ Ajouter le produit", "حفظ الوصل": "Enregistrer le bon", "معاينة الوصل": "Aperçu du bon", "⚡ طباعة PDF سريعة": "⚡ Impression PDF rapide", "إضافة زبون": "Ajouter un client", "الهاتف": "Téléphone", "📱 اختيار الزبون من جهة الاتصال": "📱 Choisir le client depuis les contacts", "اختر جهة اتصال من الهاتف وسيتم إدخال الاسم ورقم الهاتف تلقائياً، ثم اضغط حفظ الزبون.": "Choisissez un contact sur le téléphone : le nom et le numéro seront remplis automatiquement, puis appuyez sur Enregistrer le client.", "حفظ الزبون": "Enregistrer le client", "إدارة الكريدي": "Gestion du crédit", "اختر الزبون": "Choisir le client", "مبلغ الكريدي DH": "Montant du crédit DH", "ملاحظة (اختياري)": "Remarque (facultatif)", "تسجيل الكريدي": "Enregistrer le crédit", "رقم الشيك": "Numéro du chèque", "اسم المستفيد": "Bénéficiaire", "مبلغ الشيك DH": "Montant du chèque DH", "في الانتظار": "En attente", "تم صرفه": "Encaissé", "ملغى": "Annulé", "تسجيل الشيك": "Enregistrer le chèque", "جدول الشيكات المبرمجة": "Tableau des chèques programmés", "تنبيهات الشيكات التي اقترب تاريخ دخولها إلى البنك.": "Alertes pour les chèques dont la date de dépôt à la banque approche.", "إضافة مصروف": "Ajouter une dépense", "نوع المصروف": "Type de dépense", "المبلغ DH": "Montant DH", "حفظ المصروف": "Enregistrer la dépense", "حفظ واسترجاع البيانات": "Sauvegarde et restauration des données", "البيانات تحفظ داخل الهاتف. يمكنك أيضًا أخذ نسخة احتياطية.": "Les données sont enregistrées sur le téléphone. Vous pouvez également créer une sauvegarde.", "📥 تصدير نسخة احتياطية": "📥 Exporter une sauvegarde", "اختر ملف JSON لاسترجاع البيانات.": "Choisissez un fichier JSON pour restaurer les données.", "📊 التقارير الشهرية والسنوية": "📊 Rapports mensuels et annuels", "اختر الشهر": "Choisir le mois", "السنة": "Année", "المسجل": "Enregistré", "قبل المصاريف": "Avant dépenses", "خلال الشهر المختار": "Pendant le mois sélectionné", "غير المؤدى من كريدي الشهر": "Impayé du crédit du mois", "عدد عمليات البيع": "Nombre de ventes", "خلال الشهر": "Pendant le mois", "حساب صرف الشيكات السنوي": "Comptabilisation annuelle des chèques encaissés", "إجمالي قيمة الشيكات التي تم وضع حالتها \"تم صرفه\" خلال السنة": "Valeur totale des chèques marqués « Encaissé » pendant l'année", "عدد الشيكات المصروفة": "Nombre de chèques encaissés", "إجمالي الشيكات المسجلة في السنة": "Total des chèques enregistrés dans l'année", "يشمل جميع الحالات": "Toutes les situations incluses", "شيك": "chèque", "شيكات": "chèques", "لا توجد إشعارات حالياً.": "Aucune notification actuellement.", "إشعار الشيكات القريبة": "Alerte des chèques proches", "هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:": "Certains chèques seront à déposer à la banque dans les 3 prochains jours :", "المستفيد:": "Bénéficiaire :", "المبلغ:": "Montant :", "تاريخ الشيك:": "Date du chèque :", "اليوم": "Aujourd'hui", "غداً": "Demain", "بعد": "Dans", " أيام": " jours", "لا توجد شيكات مبرمجة": "Aucun chèque programmé", "جميع الشيكات — الأقرب تاريخاً أولاً": "Tous les chèques — date la plus proche en premier", "لا توجد شيكات مسجلة": "Aucun chèque enregistré", "المستحق حالياً": "Dû actuellement", "عدد الديون": "Nombre de dettes", "لا توجد ديون مسجلة": "Aucune dette enregistrée", "لا يوجد زبائن": "Aucun client", "لا توجد مصاريف": "Aucune dépense", "المصروف": "Dépense", "الزبون": "Client", "المرجع:": "Référence :", "قطعة": "article", "حسابات المخزون": "Comptabilité du stock", "إجمالي الشراء": "Total des achats", "المنتجات:": "Produits :", "الكمية:": "Quantité :", "مجموع المبيعات الشهرية": "Total des ventes mensuelles", "مجموع أرباح الشهر": "Total du bénéfice mensuel", "مجموع المصاريف الشهرية": "Total des dépenses mensuelles", "صافي الربح بعد المصاريف": "Bénéfice net après dépenses", "مجموع الكريدي المسجل": "Total du crédit enregistré", "الكريدي المتبقي": "Crédit restant", "عدد الشيكات المصروفة:": "Nombre de chèques encaissés :", "اختر منتجاً من المخزون أو اكتب الاسم": "Choisir un produit du stock ou saisir le nom", "منتجات الوصل": "Produits du bon", "لا تتم إضافة منتجات بعد": "Aucun produit ajouté", "لا توجد وصول محفوظة": "Aucun bon enregistré", "رقم الوصل": "N° du bon", "العنوان": "Adresse", "المجموع": "Total", "الوصول المستقلة المحفوظة": "Bons indépendants enregistrés", "➕ وصل جديد": "➕ Nouveau bon", "اسم": "Nom", "عدد": "Qté", "حذف": "Supprimer", "المجموع النهائي": "Total final", "زبون عابر": "Client de passage", "تم حفظ المنتج بنجاح": "Produit enregistré avec succès", "تعذر حفظ الصورة. جرّب صورة أصغر.": "Impossible d'enregistrer l'image. Essayez une image plus petite.", "اختر منتجًا": "Choisissez un produit", "الكمية غير صحيحة": "Quantité incorrecte", "الكمية المطلوبة أكبر من المخزون المتوفر": "La quantité demandée dépasse le stock disponible", "السعر غير صحيح": "Prix incorrect", "أضف منتجًا واحدًا على الأقل": "Ajoutez au moins un produit", "تم حفظ البيع بنجاح": "Vente enregistrée avec succès", "لا توجد مبيعات لتحميلها": "Aucune vente à télécharger", "أدخل اسم المنتج": "Saisissez le nom du produit", "أدخل العدد": "Saisissez la quantité", "الثمن غير صحيح": "Prix incorrect", "أضف منتجاً واحداً على الأقل": "Ajoutez au moins un produit", "تم حفظ وصل التسليم بشكل مستقل عن المبيعات": "Bon de livraison enregistré indépendamment des ventes", "أضف منتجات إلى الوصل أولاً": "Ajoutez d'abord des produits au bon", "تعذر إنشاء PDF:": "Impossible de créer le PDF :", "الطباعة الحرارية متاحة داخل تطبيق Android.": "L'impression thermique est disponible uniquement dans l'application Android.", "لا توجد مبيعات للطباعة": "Aucune vente à imprimer", "لا توجد مبيعات لإنشاء وصل التسليم": "Aucune vente pour créer un bon de livraison", "اختيار جهات الاتصال متاح داخل تطبيق Android فقط": "La sélection des contacts est disponible uniquement dans l'application Android", "تعذر فتح جهات الاتصال": "Impossible d'ouvrir les contacts", "تم حفظ الزبون": "Client enregistré", "تم حفظ المصروف": "Dépense enregistrée", "بيانات غير صحيحة": "Données incorrectes", "تم تعديل المنتج بنجاح": "Produit modifié avec succès", "حذف هذا المنتج؟": "Supprimer ce produit ?", "تم استرجاع البيانات": "Données restaurées", "ملف النسخة الاحتياطية غير صالح": "Fichier de sauvegarde invalide", "أدخل رقم المنتج": "Saisissez la référence du produit", "أدخل كمية صحيحة": "Saisissez une quantité valide", "رقم المنتج غير موجود في المخزون": "Produit introuvable dans le stock", "أدخل اسم الزبون": "Saisissez le nom du client", "أدخل مبلغاً صحيحاً": "Saisissez un montant valide", "تم تسجيل الكريدي بنجاح": "Crédit enregistré avec succès", "هل تريد حذف هذا الكريدي؟": "Voulez-vous supprimer ce crédit ?", "أدخل رقم الشيك": "Saisissez le numéro du chèque", "أدخل اسم المستفيد": "Saisissez le bénéficiaire", "تم تسجيل الشيك بنجاح": "Chèque enregistré avec succès", "هل تريد حذف هذا الشيك؟": "Voulez-vous supprimer ce chèque ?", "تم تسجيل البيع. المتبقي في المخزون:": "Vente enregistrée. Stock restant :", "اسم": "Nom", "رقم": "Référence", "الثمن": "Prix", "مع الخفض": "Prix remisé", "💰 الأسعار": "💰 Prix", "🔍 بحث باسم المنتوج": "🔍 Rechercher par nom du produit", "🔢 بحث برقم/مرجع المنتوج": "🔢 Rechercher par référence du produit", "⭐ أولوية البحث بالاسم: اكتب اسم المنتوج أولاً، وستظهر في خانة الرقم فقط الأرقام المرتبطة بهذا الاسم. يمكنك بعدها اختيار رقم لتضييق النتيجة.": "Vous pouvez rechercher par nom ou référence du produit.", "🔍 ابحث باسم المنتوج أو الرقم": "🔍 Rechercher par nom du produit ou référence", "لا توجد نتائج للبحث": "Aucun résultat"};
  let AFZ_LANG = localStorage.getItem('afz_lang') || 'ar';
  const originalText = new WeakMap();
  const originalAttr = new WeakMap();

  function tr(value){
    if (AFZ_LANG === 'ar') return value;
    if (AFZ_TRANSLATIONS[value] !== undefined) return AFZ_TRANSLATIONS[value];
    let out=value;
    const keys=Object.keys(AFZ_TRANSLATIONS).sort((a,b)=>b.length-a.length);
    for(const k of keys){
      if(out.includes(k)) out=out.split(k).join(AFZ_TRANSLATIONS[k]);
    }
    return out;
  }

  function translateTree(root){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n=>{
      if(!originalText.has(n)) originalText.set(n,n.nodeValue);
      const o=originalText.get(n);
      n.nodeValue=tr(o);
    });
    root.querySelectorAll('input,textarea,select,option,button').forEach(el=>{
      ['placeholder','title'].forEach(a=>{
        if(el.hasAttribute(a)){
          if(!originalAttr.has(el)) originalAttr.set(el,{});
          const rec=originalAttr.get(el);
          if(rec[a]===undefined) rec[a]=el.getAttribute(a);
          el.setAttribute(a,tr(rec[a]));
        }
      });
    });
  }

  function applyLanguage(){
    document.documentElement.lang=AFZ_LANG==='fr'?'fr':'ar';
    document.documentElement.dir=AFZ_LANG==='fr'?'ltr':'rtl';
    document.body.classList.toggle('lang-fr',AFZ_LANG==='fr');
    const b=document.getElementById('langToggle');
    if(b) b.textContent=AFZ_LANG==='fr'?'🇲🇦 العربية':'🇫🇷 Français';
    translateTree(document.body);
  }

  window.toggleLanguage=function(){
    AFZ_LANG=AFZ_LANG==='fr'?'ar':'fr';
    localStorage.setItem('afz_lang',AFZ_LANG);
    applyLanguage();
  };
  window.addEventListener('DOMContentLoaded',()=>setTimeout(applyLanguage,0));

  // Wrap render so dynamically generated sections are translated as well.
  const wrap=()=>{
    if(typeof window.render==='function' && !window.__afzRenderWrapped){
      const base=window.render;
      window.render=function(){ base.apply(this,arguments); setTimeout(applyLanguage,0); };
      window.__afzRenderWrapped=true;
    }
  };
  setTimeout(wrap,0);
  setInterval(wrap,250);
})();
