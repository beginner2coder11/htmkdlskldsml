/**
 * JAS Laundry Room - Google Apps Script Web App backend
 * Stores one JSON snapshot in a Google Drive file. The token is kept in
 * Script Properties, not in this source file.
 *
 * Required Script Property:
 *   JAS_SECRET_TOKEN = a long random secret (at least 32 characters)
 *
 * Deploy as Web app. Execute as: Me. Access: choose the narrowest access
 * that works for the phones/accounts you control. Anyone-with-link access
 * makes the secret token the main gate; keep it private and rotate it if leaked.
 */
const JAS_DATA_FILE_NAME = 'JAS_LAUNDRY_ROOM_CLOUD_DATA.json';
const JAS_DATA_FILE_ID_PROPERTY = 'JAS_DATA_FILE_ID';

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
function checkToken_(token) {
  const expected = PropertiesService.getScriptProperties().getProperty('JAS_SECRET_TOKEN');
  if (!expected || !token || token !== expected) throw new Error('Unauthorized: Secret Token mismatch.');
}
function dataFile_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty(JAS_DATA_FILE_ID_PROPERTY);
  if (id) {
    try { return DriveApp.getFileById(id); } catch (e) { props.deleteProperty(JAS_DATA_FILE_ID_PROPERTY); }
  }
  const file = DriveApp.createFile(JAS_DATA_FILE_NAME, JSON.stringify({ db: {}, users: [], updatedAt: 0 }), MimeType.JSON);
  props.setProperty(JAS_DATA_FILE_ID_PROPERTY, file.getId());
  return file;
}
function doGet(e) {
  try {
    checkToken_(e && e.parameter && e.parameter.token);
    const action = String(e.parameter.action || 'ping').toLowerCase();
    if (action === 'ping') return json_({ ok: true, service: 'JAS Laundry Google Cloud', version: 1 });
    if (action === 'get') {
      const raw = dataFile_().getBlob().getDataAsString('UTF-8');
      const data = JSON.parse(raw || '{}');
      return json_({ ok: true, data: data, updatedAt: Number(data.updatedAt) || 0 });
    }
    return json_({ ok: false, error: 'Unsupported GET action.' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}
function doPost(e) {
  try {
    checkToken_(e && e.parameter && e.parameter.token);
    const action = String(e.parameter.action || '').toLowerCase();
    if (action !== 'save') return json_({ ok: false, error: 'Unsupported POST action.' });
    const body = JSON.parse((e.postData && e.postData.contents) || '{}');
    if (!body || typeof body !== 'object' || !body.db || !Array.isArray(body.users)) {
      throw new Error('Invalid payload. Expected db and users.');
    }
    body.updatedAt = Date.now();
    dataFile_().setContent(JSON.stringify(body));
    return json_({ ok: true, updatedAt: body.updatedAt });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}
