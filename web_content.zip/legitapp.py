from flask import Flask, request, jsonify, render_template
import uuid
import hashlib

app = Flask(__name__, static_folder='.', static_url_path='')

# In-memory storage for simplicity (in production, use a database)
user_balances = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_token():
    data = request.json
    
    recipient = data.get('recipient')
    network = data.get('network')
    asset = data.get('asset')

    if not recipient or not network or not asset:
        return jsonify({'success': False, 'error': 'Missing parameters'}), 400

    # --- SIMULATED LOGIC ---
    
    # 1. Generate a unique token ID
    token_id = str(uuid.uuid4())
    
    # 2. Create a pseudo-hash using SHA-256 as shown in the UI badge
    raw_data = f"{recipient}{network}{asset}{token_id}"
    signature = hashlib.sha256(raw_data.encode()).hexdigest()
    
    flash_token = f"FLASH-{network}-{asset[:3]}-{signature[:16]}"
    
    # 3. Simulate processing time (optional, for realism)
    # In a real app, this might involve blockchain interaction or API calls
    
    # 4. Return success
    return jsonify({
        'success': True,
        'token': flash_token,
        'message': 'Flash token generated successfully'
    })

if __name__ == '__main__':
    # Run the server
    app.run(debug=True, port=5000)