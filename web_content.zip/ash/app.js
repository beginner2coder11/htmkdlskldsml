(() => {
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const uid = () => (globalThis.crypto?.randomUUID?.() || `ash-${Date.now()}-${Math.random().toString(36).slice(2)}`);
const defaults = { key:'ash', bond:50, outfit:'default', soundOn:true, lastInteractionAt:0, createdAt:new Date().toISOString() };
const titles = {call:'呼んだ',pet:'なでた',walk:'おさんぽ',feed:'唐揚げ',sit:'おすわり',nap:'おひるね'};
const icons = {call:'🐾',pet:'♡',walk:'♧',feed:'🍗',sit:'⌂',nap:'☾'};
let db, state={...defaults}, busy=false, action='idle', lastUserAction=Date.now(), lastApproach=0, currentSprite=0;
let spriteLoop=null, bubbleTimeout=null, toastTimeout=null, recognition=null, recording=false, audioContext=null;
let photoUrls=[], fullPhotoUrl=null;
let recentEvents=[];

function openDB(){
 return new Promise((resolve,reject)=>{
  if(!('indexedDB' in window)) return reject(new Error('IndexedDB非対応'));
  const req=indexedDB.open('ash-meadow-v2',1);
  req.onupgradeneeded=()=>{const d=req.result;
   if(!d.objectStoreNames.contains('petState')) d.createObjectStore('petState',{keyPath:'key'});
   if(!d.objectStoreNames.contains('events')){const s=d.createObjectStore('events',{keyPath:'id'});s.createIndex('occurredAt','occurredAt');}
   if(!d.objectStoreNames.contains('photos'))d.createObjectStore('photos',{keyPath:'id'});
  };
  req.onsuccess=()=>resolve(req.result);
  req.onerror=()=>reject(req.error||new Error('保存先を開けません'));
  req.onblocked=()=>reject(new Error('別のタブが保存データを使用しています'));
 });
}
function op(store,mode,operation,...args){return new Promise((resolve,reject)=>{
 if(!db)return reject(new Error('データベースに接続できません'));
 let result,tx;
 try {tx=db.transaction(store,mode);const req=tx.objectStore(store)[operation](...args);req.onsuccess=()=>{result=req.result};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||new Error('保存に失敗しました'));tx.onabort=()=>reject(tx.error||new Error('保存が中断されました'));}
 catch(e){reject(e)}
});}
const get=(store,id)=>op(store,'readonly','get',id);
const getAll=store=>op(store,'readonly','getAll');
const put=(store,item)=>op(store,'readwrite','put',item);
const del=(store,id)=>op(store,'readwrite','delete',id);

function toast(msg){const node=$('#toast');node.textContent=msg;node.classList.add('show');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>node.classList.remove('show'),3200);}
function bubble(msg,ms=1800){const el=$('#bubble');el.textContent=msg;el.classList.add('visible');clearTimeout(bubbleTimeout);if(ms>0)bubbleTimeout=setTimeout(()=>el.classList.remove('visible'),ms);}
function setCaption(msg){$('#meadowCaption').textContent=msg;}
function setBusy(v){busy=v;$$('.action, #pet').forEach(b=>b.disabled=v)}
function movePet(left,near=false){const p=$('#pet');p.style.left=left;p.classList.toggle('is-near',near)}
function setPose(pose,frame=0){const img=$('#petImage');const useJacket=state.outfit==='jacket';
 let src;
 if(useJacket){const index=pose==='sleep'?5:pose==='sit'?4:pose==='stand'?(frame%2?7:6):(frame%2?2:3);src=`./assets/ash/jacket-${index}.webp`;}
 else src=`./assets/ash/${pose}-${frame%4}.webp`;
 if(img.getAttribute('src')!==src)img.src=src;
}
function stopSpriteLoop(){if(spriteLoop){clearInterval(spriteLoop);spriteLoop=null}$('#pet').classList.remove('is-walking','is-petting','is-eating','is-sleeping');}
function startSpriteLoop(pose,klass,delay=300){stopSpriteLoop();$('#pet').classList.add(klass);currentSprite=0;setPose(pose,0);spriteLoop=setInterval(()=>{currentSprite=(currentSprite+1)%4;setPose(pose,currentSprite)},delay)}
function resetPose(){stopSpriteLoop();setPose('sit',0);movePet('32%');setCaption('ひなたぼっこ、気持ちいいね。');action='idle';}
async function saveState(){try{await put('petState',{...state})}catch(e){console.warn(e);toast('保存できませんでした。端末の空き容量をご確認ください。')}}
async function logAction(type,detail={}){
 const record={id:uid(),type,occurredAt:new Date().toISOString(),detail};
 try{await put('events',record);recentEvents.push(record)}catch(e){console.warn(e);toast('行動履歴の保存に失敗しました')}
 const points={call:1,pet:2,walk:3,feed:3,sit:1,nap:1};state.bond=Math.min(100,Math.max(0,(Number(state.bond)||50)+(points[type]||0)));
 state.lastInteractionAt=Date.now();await saveState();renderBond();
}
function renderBond(){const n=Math.max(0,Math.min(100,Number(state.bond)||0));$('#bondValue').textContent=n;$('#bondFill').style.width=n+'%'}
function userTouched(){lastUserAction=Date.now();}
async function approach({auto=false}={}){
 action='approaching';startSpriteLoop('stand','is-walking',230);movePet('66%');
 if(!auto)bubble('呼んだ？',1500);else bubble('ヨウちゃん、いっしょにおろうね',2200);
 await sleep(1800);stopSpriteLoop();setPose('stand',1);movePet('52%',true);setCaption(auto?'アッシュが自分から来てくれた。':'アッシュが駆け寄ってきた！');
 await sleep(auto?2300:900);
}
function getSoundContext(){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;if(!audioContext)audioContext=new AC();return audioContext}catch(e){return null}}
async function unlockSound(){if(!state.soundOn)return;const ctx=getSoundContext();if(ctx&&ctx.state==='suspended')try{await ctx.resume()}catch(e){}}
function huff(){if(!state.soundOn)return;const ctx=getSoundContext();if(!ctx||ctx.state!=='running')return;
 try{const len=Math.round(ctx.sampleRate*.26);const buf=ctx.createBuffer(1,len,ctx.sampleRate);const arr=buf.getChannelData(0);for(let i=0;i<len;i++){const p=i/len;arr[i]=(Math.random()*2-1)*Math.pow(Math.sin(Math.PI*p),1.3)*.72;}
 const src=ctx.createBufferSource();src.buffer=buf;const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(980,ctx.currentTime);filter.frequency.exponentialRampToValueAtTime(340,ctx.currentTime+.23);
 const gain=ctx.createGain();gain.gain.value=.34;src.connect(filter).connect(gain).connect(ctx.destination);src.start();}catch(e){console.warn(e)}
}
async function execute(type,options={}){
 if(busy)return;userTouched();setBusy(true);const food=$('#foodIcon');
 try{
  switch(type){
   case 'call':
    await unlockSound();bubble('アッシュ！',1000);await sleep(400);await approach();bubble('ワン！',1200);await logAction('call',{method:options.method||'tap'});await sleep(1250);break;
   case 'pet':
    action='pet';startSpriteLoop('sit','is-petting',350);bubble('うれしいな ♡',1700);setCaption('よしよし、アッシュ。');await sleep(1800);await logAction('pet');break;
   case 'walk':
    action='walk';startSpriteLoop('stand','is-walking',300);bubble('おさんぽ！',1500);setCaption('芝生をいっしょにお散歩。');movePet('69%');await sleep(1550);movePet('21%');await sleep(1700);movePet('42%');await sleep(1100);await logAction('walk');break;
   case 'feed':
    await unlockSound();action='feed';bubble('唐揚げだ！',1000);food.classList.add('visible');startSpriteLoop('stand','is-walking',300);movePet('58%');await sleep(1250);stopSpriteLoop();startSpriteLoop('sit','is-eating',310);setCaption('もぐもぐ……');bubble('もぐもぐ',2300);await sleep(2650);stopSpriteLoop();setPose('sit',0);food.classList.remove('visible');bubble('フッ！',2000);setCaption('もういらない、の「フッ！」');huff();await logAction('feed',{sound:'再現SE'});await sleep(1800);break;
   case 'sit':
    action='sit';setPose('sit',0);bubble('おすわり！',1600);setCaption('ちょこん、とおすわり。');await sleep(1550);await logAction('sit');break;
   case 'nap':
    action='nap';setPose('sleep',0);$('#pet').classList.add('is-sleeping');bubble('すやすや…',1800);setCaption('おひるね中。');await sleep(3400);await logAction('nap');break;
  }
 }catch(e){console.error(e);toast('動作を完了できませんでした')}finally{food.classList.remove('visible');resetPose();setBusy(false);}
}

async function maybeApproach(){if(document.hidden||busy||action!=='idle'||!$('#screen-home').classList.contains('active'))return;
 const now=Date.now();if(now-lastUserAction<48000||now-lastApproach<110000)return;
 lastApproach=now;setBusy(true);
 try{await approach({auto:true});await sleep(1000)}finally{resetPose();setBusy(false)}
}
function stopListening(){if(recognition){try{recognition.abort()}catch(e){}recognition=null}recording=false;$('#micBtn').classList.remove('listening');$('#micHint').textContent='マイクを使う'}
function listenForAsh(){
 if(busy)return;const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Speech){toast('この端末は音声認識に対応していません。「アッシュを呼ぶ」は使えます。');return;}
 if(!localStorage.getItem('ash-mic-permission-notice')){
  if(!confirm('音声認識は端末・ブラウザによって、音声が外部の音声認識サービスに送信されることがあります。声で呼ぶ機能を使いますか？'))return;
  localStorage.setItem('ash-mic-permission-notice','yes');
 }
 stopListening();userTouched();
 const rec=new Speech();recognition=rec;rec.lang='ja-JP';rec.interimResults=false;rec.continuous=false;rec.maxAlternatives=3;
 let recognized=false;recording=true;$('#micBtn').classList.add('listening');$('#micHint').textContent='聞いてるよ…';toast('「アッシュ！」と呼んでみて');
 rec.onresult=(event)=>{
  const phrases=Array.from(event.results[0]||[]).map(x=>x.transcript.normalize('NFKC').replace(/[\s　、。！？!?]/g,''));
  recognized=phrases.some(s=>/(アッシュ|あっしゅ|アシュ丸|アシュまる|あしゅ丸|あしゅまる|アシュ)/i.test(s));
  if(!recognized)toast('名前が聞き取れなかったよ。もう一度呼んでみて。');
 };
 rec.onerror=e=>{if(e.error!=='aborted'&&e.error!=='no-speech')toast('音声認識が使えません。タップで呼ぶこともできます。');};
 rec.onend=()=>{if(recognition!==rec)return;stopListening();if(recognized)execute('call',{method:'voice'});};
 try{rec.start()}catch(e){stopListening();toast('マイクを開始できませんでした。');}
}

function switchScreen(which){stopListening();const el=$(`#screen-${which}`);if(!el)return;
 $$('.screen').forEach(s=>{s.classList.remove('active');s.hidden=true});el.classList.add('active');el.hidden=false;
 $$('.nav-item').forEach(n=>{const active=n.dataset.screen===which;n.classList.toggle('active',active);if(active)n.setAttribute('aria-current','page');else n.removeAttribute('aria-current')});
 window.scrollTo({top:0,behavior:'instant'});
 if(which==='album')renderAlbum();if(which==='history')renderHistory();
}

function showModal(title,html){$('#modalTitle').textContent=title;$('#modalBody').className='modal-body';$('#modalBody').innerHTML=html;$('#modal').showModal()}
function escapeHtml(text){return String(text??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));}
function closeModal(){const m=$('#modal');if(m.open)m.close();if(fullPhotoUrl){URL.revokeObjectURL(fullPhotoUrl);fullPhotoUrl=null}}
function profile(){showModal('アッシュのこと',`<img class="profile-art" src="./assets/ash/sit-0.webp" alt="アッシュのイラスト"/><p>芝生で一緒に過ごす、ロングコートチワワのアッシュ。ここにあるのはアッシュをもとにしたイラストだよ。本人の写真はアルバムに追加できるよ。</p><div class="profile-fact"><span>名前</span><strong>アッシュ（男の子）</strong></div><div class="profile-fact"><span>お誕生日</span><strong>2004年2月8日</strong></div><div class="profile-fact"><span>旅立った日</span><strong>2017年3月10日</strong></div><div class="profile-fact"><span>血統書名</span><strong>グリーンガーネット・ファルコ・カカオ</strong></div>`)}
function settings(){showModal('アッシュの設定',`<div class="setting-row"><div><strong>鳴き声・効果音</strong><small>「フッ！」は再現SEで、本物の録音ではありません。</small></div><input type="checkbox" id="soundToggle" ${state.soundOn?'checked':''} aria-label="効果音を再生" /></div><div class="setting-row"><div><strong>おきがえ</strong><small>元の衣装画像はソース取得後に移植できます。</small></div><select id="outfitSelect"><option value="default">いつものアッシュ</option><option value="jacket">ライダージャケット</option></select></div><p class="note">名前を呼ぶマイク機能はボタンを押した時だけ起動します。音声認識は通信を使う場合があります。</p><h3>思い出とデータを守る</h3><button class="action-button secondary" id="persistBtn">端末の保存保護をリクエスト</button><button class="action-button secondary" id="exportBtn">写真・育成・履歴をバックアップ</button><button class="action-button secondary" id="importBtn">バックアップから復元</button><p class="note">写真と履歴はこの端末のIndexedDBに保存されます。サイトデータの削除、端末故障、アプリのアンインストールで失われる場合があるため、バックアップを保管してください。新しい公開URLには旧URLのデータは自動引き継ぎされません。</p><p class="note" id="storageInfo">保存容量を確認しています…</p><p class="note" id="offlineInfo">オフライン準備状況を確認しています…</p>`);
 $('#outfitSelect').value=state.outfit;
 $('#soundToggle').addEventListener('change',e=>{state.soundOn=e.target.checked;saveState();toast(state.soundOn?'効果音をオンにしました':'効果音をオフにしました')});
 $('#outfitSelect').addEventListener('change',e=>{state.outfit=e.target.value;setPose('sit',0);saveState();toast('おきがえしたよ')});
 $('#persistBtn').onclick=async()=>{try{const okay=await navigator.storage?.persist?.();toast(okay?'保存保護が有効になりました':'保存保護が許可されませんでした。バックアップもご利用ください。')}catch(e){toast('この端末では保存保護に対応していません')}};
 $('#exportBtn').onclick=exportBackup;
 $('#importBtn').onclick=()=>$('#importBackupInput').click();
 navigator.storage?.estimate?.().then(({usage,quota})=>{const el=$('#storageInfo');if(el)el.textContent=`このサイトの使用容量：約${(usage/1024/1024).toFixed(1)}MB ／ 使用可能枠の目安：約${(quota/1024/1024).toFixed(0)}MB`;}).catch(()=>{});
 $('#offlineInfo').textContent=('serviceWorker' in navigator)?'オフライン対応：初回アクセス後に画像・コードを端末へ保存します。':'この端末ではオフライン保存が使えない可能性があります。';
}

async function thumb(file){return new Promise((resolve,reject)=>{
 const img=new Image();const url=URL.createObjectURL(file);
 img.onload=()=>{try{const scale=Math.min(1,360/Math.max(img.naturalWidth,img.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);canvas.toBlob(b=>{URL.revokeObjectURL(url);b?resolve(b):reject(new Error('サムネイルを作れません'))},'image/webp',.8);}catch(e){URL.revokeObjectURL(url);reject(e)}};
 img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('写真を読み取れません'))};img.src=url;
});}
async function addPhotos(files){if(!db)return toast('写真の保存が利用できません');let ok=0;
 for(const file of [...files]){
  if(!['image/png','image/webp','image/jpeg'].includes(file.type)){toast('JPEG・PNG・WebPの写真を選んでください');continue;}
  if(file.size>25*1024*1024){toast('25MBを超える写真は追加できません');continue;}
  try{const t=await thumb(file);await put('photos',{id:uid(),blob:file,thumbnail:t,title:file.name.replace(/\.[^.]+$/,''),date:new Date().toISOString().slice(0,10),note:'',addedAt:new Date().toISOString(),fileName:file.name});ok++;}
  catch(e){console.error(e);toast('一部の写真を保存できませんでした。容量をご確認ください。')}
 }
 if(ok)toast(`${ok}枚の写真をアルバムに追加したよ`);await renderAlbum();}
async function renderAlbum(){if(!db)return;let photos;
 try{photos=(await getAll('photos')).sort((a,b)=>b.addedAt.localeCompare(a.addedAt))}catch(e){toast('写真を読み込めません');return}
 for(const u of photoUrls)URL.revokeObjectURL(u);photoUrls=[];
 const area=$('#gallery');area.replaceChildren();$('#photoCount').textContent=photos.length;$('#albumEmpty').hidden=!!photos.length;
 for(const photo of photos){const btn=document.createElement('button');btn.type='button';btn.className='photo-card';const img=document.createElement('img');const url=URL.createObjectURL(photo.thumbnail||photo.blob);photoUrls.push(url);img.src=url;img.alt=photo.title||'アッシュの思い出';img.loading='lazy';const cp=document.createElement('div');cp.className='photo-copy';const strong=document.createElement('strong');strong.textContent=photo.title||'アッシュの写真';const small=document.createElement('small');small.textContent=photo.date||'日付なし';cp.append(strong,small);btn.append(img,cp);btn.addEventListener('click',()=>viewPhoto(photo.id));area.append(btn)}
}
async function viewPhoto(id){const photo=await get('photos',id);if(!photo)return toast('写真が見つかりませんでした');
 if(fullPhotoUrl)URL.revokeObjectURL(fullPhotoUrl);fullPhotoUrl=URL.createObjectURL(photo.blob);
 showModal('思い出の写真',`<img class="photo-full" id="fullPhoto" alt="アッシュの思い出の写真" /><label for="photoTitle">タイトル</label><input id="photoTitle" type="text" maxlength="80" /><label for="photoDate">思い出の日付</label><input id="photoDate" type="date" /><label for="photoNote">思い出のメモ</label><textarea id="photoNote" maxlength="1000" placeholder="この日のアッシュは…"></textarea><button class="action-button" id="savePhotoBtn">思い出を保存</button><button class="action-button danger" id="deletePhotoBtn">この写真を削除</button>`);
 $('#fullPhoto').src=fullPhotoUrl;$('#photoTitle').value=photo.title||'';$('#photoDate').value=photo.date||'';$('#photoNote').value=photo.note||'';
 $('#savePhotoBtn').onclick=async()=>{photo.title=$('#photoTitle').value.trim()||'アッシュの写真';photo.date=$('#photoDate').value;photo.note=$('#photoNote').value;try{await put('photos',photo);closeModal();await renderAlbum();toast('思い出を保存したよ')}catch(e){toast('保存に失敗しました')}};
 $('#deletePhotoBtn').onclick=async()=>{if(!confirm('この写真をアルバムから削除しますか？端末の元写真は削除されません。'))return;await del('photos',id);closeModal();await renderAlbum();toast('アルバムから写真を削除しました')};
}
function localDay(t){const d=new Date(t);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function localStamp(t){return new Date(t).toLocaleString('ja-JP',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});}
async function renderHistory(){if(!db)return;let events;
 try{events=(await getAll('events')).sort((a,b)=>b.occurredAt.localeCompare(a.occurredAt))}catch(e){toast('履歴を読み込めません');return}
 const counts={call:0,pet:0,walk:0,feed:0};events.forEach(e=>{if(e.type in counts)counts[e.type]++});$('#statCall').textContent=counts.call;$('#statPet').textContent=counts.pet;$('#statWalk').textContent=counts.walk;$('#statFeed').textContent=counts.feed;
 const range=$('#historyRange').value;const today=localDay(new Date());const weekAgo=Date.now()-7*86400000;
 const filtered=events.filter(e=>range==='all'||(range==='today'&&localDay(e.occurredAt)===today)||(range==='week'&&new Date(e.occurredAt).getTime()>=weekAgo));
 const area=$('#historyList');area.replaceChildren();$('#historyEmpty').hidden=!!filtered.length;
 for(const e of filtered.slice(0,150)){const wrap=document.createElement('div');wrap.className='history-row';const icon=document.createElement('span');icon.className='history-icon';icon.textContent=icons[e.type]||'♡';const mid=document.createElement('div');const label=document.createElement('strong');label.textContent=titles[e.type]||'ふれあい';const desc=document.createElement('small');desc.textContent=e.type==='call'?(e.detail?.method==='voice'?'声で呼んだ':'タップで呼んだ'):'アッシュといっしょ';mid.append(label,desc);const date=document.createElement('span');date.className='history-date';date.textContent=localStamp(e.occurredAt);wrap.append(icon,mid,date);area.append(wrap)}
}
function readFileAsDataUrl(blob){return new Promise((resolve,reject)=>{const fr=new FileReader();fr.onload=()=>resolve(fr.result);fr.onerror=()=>reject(fr.error);fr.readAsDataURL(blob)});}
function dataUrlToBlob(data){const [header,body]=data.split(',');if(!header||!body||!/^data:[\w/+.-]+;base64$/i.test(header))throw new Error('写真データが正しくありません');const mime=header.slice(5,-7);const raw=atob(body);const arr=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)arr[i]=raw.charCodeAt(i);return new Blob([arr],{type:mime});}
async function exportBackup(){if(!db)return toast('保存データに接続できません');toast('バックアップを準備しています…');
 try{const [photos,events]=await Promise.all([getAll('photos'),getAll('events')]);const pictureData=[];
  for(const p of photos){pictureData.push({id:p.id,title:p.title,date:p.date,note:p.note,addedAt:p.addedAt,fileName:p.fileName,blob:await readFileAsDataUrl(p.blob)});}
  const result={kind:'ash-hinata-v2-backup',version:1,exportedAt:new Date().toISOString(),state,events,photos:pictureData};
  const file=new Blob([JSON.stringify(result)],{type:'application/json;charset=utf-8'});const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download=`ash-hinata-backup-${localDay(new Date())}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);toast('バックアップを書き出したよ。大切に保管してね。');
 }catch(e){console.error(e);toast('バックアップに失敗しました。容量をご確認ください。')}
}
async function importBackup(file){if(!db)return toast('保存データに接続できません');if(!file)return;
 try{const backup=JSON.parse(await file.text());if(backup?.kind!=='ash-hinata-v2-backup'||backup.version!==1||!Array.isArray(backup.events)||!Array.isArray(backup.photos))throw new Error('対応していないバックアップです');
  if(!confirm(`バックアップを復元しますか？\n写真 ${backup.photos.length}枚・記録 ${backup.events.length}件を追加または更新します。きずなと服の設定はバックアップ側の値に置き換わります。`))return;
  let photos=0,events=0;
  for(const e of backup.events){if(e&&typeof e.id==='string'&&typeof e.type==='string'&&typeof e.occurredAt==='string'){await put('events',e);events++}}
  for(const p of backup.photos){if(typeof p.id!=='string'||typeof p.blob!=='string')continue;const b=dataUrlToBlob(p.blob);if(!['image/png','image/jpeg','image/webp'].includes(b.type)||b.size>25*1024*1024)continue;const t=await thumb(b);await put('photos',{id:p.id,blob:b,thumbnail:t,title:p.title||'アッシュの写真',date:p.date||'',note:p.note||'',addedAt:p.addedAt||new Date().toISOString(),fileName:p.fileName||'photo'});photos++;}
  if(backup.state&&typeof backup.state.bond==='number'){state={...defaults,...backup.state,key:'ash',bond:Math.max(0,Math.min(100,backup.state.bond))};await saveState();renderBond();resetPose()}
  closeModal();toast(`復元完了：写真${photos}枚、記録${events}件`);await renderAlbum();await renderHistory();
 }catch(e){console.error(e);toast('復元できませんでした。正しいバックアップを選んでください。')}
}

async function init(){
 try{db=await openDB();const old=await get('petState','ash');if(old)state={...defaults,...old};}catch(e){console.error(e);toast('この端末で保存機能が使えません。端末設定をご確認ください。')}
 renderBond();setPose('sit',0);
 $('#profileBtn').addEventListener('click',profile);$('#settingsBtn').addEventListener('click',settings);$('#closeModal').addEventListener('click',closeModal);$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeModal()});
 $('#callBtn').onclick=()=>execute('call',{method:'tap'});$('#micBtn').onclick=listenForAsh;$('#feedBtn').onclick=()=>execute('feed');$('#petBtn').onclick=()=>execute('pet');$('#pet').onclick=()=>execute('pet');$('#walkBtn').onclick=()=>execute('walk');$('#sitBtn').onclick=()=>execute('sit');$('#sleepBtn').onclick=()=>execute('nap');
 $$('.nav-item').forEach(btn=>btn.addEventListener('click',()=>switchScreen(btn.dataset.screen)));
 $('#photoInput').addEventListener('change',async e=>{await addPhotos(e.target.files);e.target.value=''});
 $('#historyRange').addEventListener('change',renderHistory);
 $('#importBackupInput').addEventListener('change',async e=>{const file=e.target.files[0];e.target.value='';await importBackup(file)});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){stopListening();stopSpriteLoop();}else if(!busy){setPose('sit',0);lastUserAction=Date.now()}});
 setInterval(maybeApproach,7000);
 if('serviceWorker' in navigator&&location.protocol.startsWith('http')){
  try{const reg=await navigator.serviceWorker.register('./sw.js',{scope:'./'});reg.update().catch(()=>{});}catch(e){console.warn('Service worker registration failed',e)}
 }
}
init();
})();
