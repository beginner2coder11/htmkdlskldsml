const CACHE='ash-hinata-v2-r1';
const FILES=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./assets/meadow.webp','./assets/icons/icon-192.png','./assets/icons/icon-512.png',
 ...['sit','sleep','stand'].flatMap(t=>[0,1,2,3].map(n=>`./assets/ash/${t}-${n}.webp`)),
 ...[0,1,2,3,4,5,6,7].map(n=>`./assets/ash/jacket-${n}.webp`)];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('ash-hinata-')&&k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',e=>{
 const req=e.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 if(req.mode==='navigate'){e.respondWith(fetch(req).then(r=>{if(r.ok){const c=r.clone();caches.open(CACHE).then(cache=>cache.put('./',c)).catch(()=>{});}return r}).catch(()=>caches.match('./index.html')));return;}
 e.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{if(res.ok){const c=res.clone();caches.open(CACHE).then(cache=>cache.put(req,c)).catch(()=>{})}return res})))
});
