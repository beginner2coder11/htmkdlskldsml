# Busdriver Navi V26 – Fahrer-Cockpit (Testprojekt)

## Neu
- `nav26.html`: nächste Haltestelle mit geschätzter Entfernung **entlang der gewählten GPX-Geometrie** aus GPS-Position und AVV-Haltestellenkoordinaten; Auswahl der konkreten Fahrt (Richtung, Zeit, Tagesvariante); 2D/3D, Nordausrichtung, GPS-Zentrierung, Tag/Nacht.
- `dienst26.html`: Dienstplanfoto auswählen, optionale browserseitige OCR (Tesseract.js, Internet nötig), erkannte Zeitzeilen übernehmen, **manuell prüfen**, Linienfahrten, Leerfahrten, andere Arbeit, bestätigte Pausen eintragen, Arbeits- und Fahrzeiten und Wendezeiten ausrechnen.
- 2299 WestVerkehr-Fahrten und 794 benannte Haltestellen mit Positionsdaten aus AVV-GTFS. Die Haltestellenzuordnung ist **heuristisch**, besonders bei Haltestellen mit mehreren Masten und Linienvarianten.

## Grenzen / Sicherheit
Die neue Haltestellenentfernung ist eine Näherung, kein zertifiziertes Navigationssystem. Die Zuordnung einzelner Haltestellen zur Streckengeometrie kann falsch sein. Keine Abbiegeanweisungen oder geprüfte Busbefahrbarkeit. Foto-OCR kann Fehler machen. Ein Dienstplanfoto allein reicht **nicht** für eine rechtsverbindliche Bewertung der Lenk-, Ruhe- und Arbeitszeiten. Insbesondere EU-VO 561/2006-Ausnahmen für bestimmte Linienverkehre bis 50 km, Fahrpersonalverordnung, ArbZG, Pausen und tarifliche Regeln sind gesondert zu prüfen. Die Anwendung zeigt deshalb Warnhinweise, aber keine „gesetzlich OK“-Freigabe.

Das ZIP ist ein Android-Studio-Projekt, **keine APK**. Kein Android-Build oder Gerätetest erfolgt. Die Web-Karte benötigt Internet.
