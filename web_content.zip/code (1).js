const express = require('express');
const cors = require('cors');
const db = require('./db');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors()); // Allow requests from your APK/Web view
app.use(express.json());

// --- Helper Functions ---

// Generate a realistic-looking TX Hash based on network
function generateTxHash(network) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const length = network === 'TRC20' ? 64 : 66; // TRC20 doesn't start with 0x usually, but we'll keep it generic
    
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    if (network !== 'TRC20') return '0x' + result.substring(2);
    return result;
}

// --- Routes ---

// 1. Register/Login User (Simple simulation)
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    
    // Check if user exists
    let user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    
    if (!user) {
        // Create new user with default 2000 USDT balance
        const userId = uuidv4();
        db.prepare('INSERT INTO users (id, username, password, balance) VALUES (?, ?, ?, ?)').run(userId, username, password || 'default', 2000.00);
        user = { id: userId, username, balance: 2000.00 };
    } else {
        // Verify password (simplified)
        if (password && user.password !== password) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
    }
    
    res.json({ 
        success: true, 
        user: { id: user.id, username: user.username, balance: user.balance } 
    });
});

// 2. Get User Balance
app.get('/api/user/:id/balance', (req, res) => {
    const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    res.json({ balance: user.balance });
});

// 3. Send USDT (Flash Transaction)
app.post('/api/send', (req, res) => {
    const { userId, senderAddress, recipientAddress, amount, network } = req.body;
    
    // Fetch user balance
    const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    if (user.balance < amount) {
        return res.status(400).json({ error: 'Insufficient funds' });
    }
    
    // Deduct Balance
    const newBalance = user.balance - amount;
    db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(newBalance, userId);
    
    // Record Transaction
    const txId = uuidv4();
    const txHash = generateTxHash(network);
    const timestamp = new Date().toISOString();
    
    db.prepare(`
      INSERT INTO transactions (id, user_id, sender_address, recipient_address, amount, network, tx_hash, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(txId, userId, senderAddress, recipientAddress, amount, network, txHash, timestamp);
    
    res.json({
        success: true,
        transaction: {
            id: txId,
            hash: txHash,
            amount: amount,
            network: network,
            status: 'Confirmed',
            time: timestamp
        },
        newBalance: newBalance
    });
});

// 4. Get Transaction History
app.get('/api/history/:id', (req, res) => {
    const history = db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 50').all(req.params.id);
    res.json(history);
});

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`USDT Flasher Backend running on port ${PORT}`);
});