const express = require('express');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files (HTML, CSS, JS) from the root directory
app.use(express.static(path.join(__dirname)));

// API Endpoint to simulate the Backend "Broadcast"
app.post('/api/broadcast', (req, res) => {
    const { wallet, amount } = req.body;
    
    // Simulate network delay
    setTimeout(() => {
        const txHash = '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
        
        res.json({
            status: 'confirmed',
            hash: txHash,
            message: `Flash USDT ${amount} sent to ${wallet.substring(0,6)}...`,
            timestamp: new Date().toISOString(),
            validity_days: 365
        });
    }, 1500);
});

app.listen(PORT, () => {
    console.log(`USDT Flash App running on http://localhost:${PORT}`);
});