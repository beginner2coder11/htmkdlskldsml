// Example: Loading money from your Android/HTML app
async function loadMoney(accountId, amount) {
    const response = await fetch('http://YOUR_SERVER_IP:3000/api/deposit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            accountId: accountId,
            amount: amount
        })
    });

    const data = await response.json();
    
    if (data.message === 'Deposit successful') {
        alert(`Success! New balance: $${data.newBalance}`);
    } else {
        alert('Deposit failed: ' + data.error);
    }
}