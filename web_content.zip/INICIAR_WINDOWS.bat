@echo off
setlocal
cd /d "%~dp0"
title Nosso Mercadao - Consulta de Precos Windows
echo Nosso Mercadao - Terminal de consulta Windows 10
echo Mantenha esta janela aberta durante o uso.
echo A interface sera aberta em http://127.0.0.1:8787
set "TERMINAL_JAVA=java"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "TERMINAL_JAVA=%JAVA_HOME%\bin\java.exe"
"%TERMINAL_JAVA%" -version >nul 2>nul
if errorlevel 1 (
 echo Java nao encontrado. Instale Java 8 ou superior e execute novamente.
 pause
 exit /b 1
)
"%TERMINAL_JAVA%" -jar TerminalConsultaWindows.jar
if errorlevel 1 echo Consulte a mensagem acima. A porta local 8787 pode estar ocupada ou o Java pode estar incompleto.
pause
