"use strict";
(function(){
 const key='jr-player-radio-app';
 const radioPackage='com.appmind.radios.br';
 const defaults={name:'Rádio Brasil',package:radioPackage,enabled:true};
 let config={...defaults};
 try{const stored=JSON.parse(localStorage.getItem(key)||'null');if(stored&&typeof stored==='object'&&stored.package)config={...config,...stored}}catch{}
 const valid=p=>/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/.test(p);
 const note=t=>$('radioAppStatus').textContent=t;
 function fill(){ $('radioAppName').value=config.name||'';$('radioAppPackage').value=config.package||'';$('radioUseApp').checked=!!config.enabled;}
 function openSettings(){fill();$('radioSettings').showModal();}
 function launch(pkg){
  if(!valid(pkg)){note('Informe o pacote Android correto.');return}
  if(!/Android/i.test(navigator.userAgent)){note('A abertura de aplicativos funciona no Android.');return}
  note('Abertura solicitada. Se não abrir, confira se o rádio está instalado e se o gerador permite abrir aplicativos externos.');
  // URI confirmada no AndroidManifest.xml do Rádio Brasil 4.2.36 enviado.
  const uri=pkg===radioPackage
   ?'intent://tab/stations#Intent;scheme=countryradios;action=android.intent.action.VIEW;category=android.intent.category.BROWSABLE;package='+pkg+';end'
   :'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package='+encodeURIComponent(pkg)+';end';
  // Pausa o áudio local para não tocar junto com o rádio externo.
  const media=$('media');if(media&&typeof media.pause==='function')media.pause();
  window.location.href=uri;
 }
 $('radioAppSave').onclick=()=>{const pkg=$('radioAppPackage').value.trim();const enabled=$('radioUseApp').checked;if(enabled&&!valid(pkg)){note('Informe um pacote válido, como com.exemplo.radio.');return}config={name:$('radioAppName').value.trim(),package:pkg,enabled};try{localStorage.setItem(key,JSON.stringify(config));note('Configuração salva neste aparelho.')}catch{note('Não foi possível salvar a configuração.');}};
 $('radioAppTest').onclick=()=>launch($('radioAppPackage').value.trim());
 $('dashRadio').onclick=()=>{if(config.enabled&&valid(config.package)){launch(config.package);if(!/Android/i.test(navigator.userAgent))openSettings()}else openSettings()};
 $('radioConfigOpen').onclick=()=>{$('menu').close();openSettings()};fill();
})();
