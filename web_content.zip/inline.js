
const DB_KEY='afz_v2';
const STORAGE_KEY='afz_v2_local';
const emptyDB={stock:[],products:[],sales:[],customers:[],expenses:[],deliveryDocs:[],credits:[],checks:[],prices:{},priceRefs:{},purchasePrices:{},companyPrices:[],companies:[],priceSections:['عام'],priceSectionMap:{}};

// إصلاح النسخة الاحتياطية: توفير دوال أقسام الأسعار قبل استخدامها في العرض والتصدير.
function getPriceSections(){
  return (Array.isArray(db.priceSections) && db.priceSections.length) ? db.priceSections.slice() : ['عام'];
}
// توافق مع النسخ التي كانت تستدعي الاسم بصيغة الجمع.
function getPricesSections(){
  return getPriceSections();
}

let db=loadLocal();
// تهيئة البيانات بدون إنشاء سجلات جديدة عند كل تشغيل.
function normalizeSavedData(){
 if(!db||typeof db!=='object') db=structuredClone(emptyDB);
 if(!Array.isArray(db.products)) db.products=["TAMBOUR DE FREINS", ];
 if(!Array.isArray(db.stock)) db.stock=[];
 if(!Array.isArray(db.sales)) db.sales=[];
 if(!Array.isArray(db.customers)) db.customers=[];
 if(!Array.isArray(db.priceSections)||!db.priceSections.length) db.priceSections=['عام'];
 db.priceSections=sortNamesAZ(db.priceSections);
 if(!db.priceSectionMap||typeof db.priceSectionMap!=='object'||Array.isArray(db.priceSectionMap)) db.priceSectionMap={};
 if(!Array.isArray(db.credits)) db.credits=[];
 if(!Array.isArray(db.checks)) db.checks=[];
 if(!db.prices || Array.isArray(db.prices) || typeof db.prices!=='object') db.prices={};
 if(!db.priceRefs || typeof db.priceRefs!=='object' || Array.isArray(db.priceRefs)) db.priceRefs={};
 if(!db.purchasePrices || typeof db.purchasePrices!=='object' || Array.isArray(db.purchasePrices)) db.purchasePrices={};
 if(!Array.isArray(db.companyPrices)) db.companyPrices=[];
 if(!Array.isArray(db.companies)) db.companies=[];
 // ترحيل أسماء الشركات الموجودة مسبقاً إلى قائمة الشركات المستقلة.
 const companyMap=new Map();
 db.companies.forEach(x=>{const name=String(x?.name||x||'').trim();if(name&&!companyMap.has(name.toLowerCase()))companyMap.set(name.toLowerCase(),{id:String(x?.id||('company_'+Date.now()+'_'+Math.random().toString(36).slice(2,7))),name});});
 db.companyPrices.forEach(x=>{const name=String(x?.company||'').trim();if(name&&!companyMap.has(name.toLowerCase()))companyMap.set(name.toLowerCase(),{id:'company_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),name});});
 db.companies=[...companyMap.values()].sort((a,b)=>compareNamesAZ(a.name,b.name));
 if(!db.discountPrices || Array.isArray(db.discountPrices) || typeof db.discountPrices!=='object') db.discountPrices={};
 // دمج المنتجات التي تحمل الاسم نفسه، مع إزالة تكرار الأرقام فقط.
 const merged=new Map();
 db.products.forEach(p=>{
   const name=String(p?.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   const nums=Array.isArray(p.numbers)?p.numbers.map(x=>String(x||'').trim()).filter(Boolean):[];
   let cur=merged.get(key);
   if(!cur){cur={...p,name,image:p.image||'',numbers:[]};merged.set(key,cur);}
   else if(!cur.image && p.image) cur.image=p.image;
   const seen=new Set(cur.numbers.map(x=>String(x).toLowerCase()));
   nums.forEach(n=>{const k=n.toLowerCase();if(!seen.has(k)){seen.add(k);cur.numbers.push(n);}});
 });
 db.products=[...merged.values()];
 db.products.sort((a,b)=>compareNamesAZ(a.name,b.name));
 // تحويل الأرقام القديمة إلى سجل المنتج مرة واحدة، ثم يصبح products هو المصدر الوحيد.
 db.products.forEach(p=>{
   const legacy=Array.isArray(db.priceRefs?.[String(p.id)])?db.priceRefs[String(p.id)]:[];
   const all=[...(Array.isArray(p.numbers)?p.numbers:[]),...legacy].map(x=>String(x||'').trim()).filter(Boolean);
   const seen=new Set();
   p.numbers=sortRefsAZ(all.filter(x=>{const k=x.toLowerCase();if(seen.has(k))return false;seen.add(k);return true;}));
 });
}
normalizeSavedData();

// أرقام ثابتة لمنتوج RONDELLE DEMBRAYAGE: تُضاف مرة واحدة إلى قسم المنتجات وأرقامها
// وتبقى محفوظة داخل بيانات التطبيق، مع منع تكرار أي رقم موجود مسبقًا.
function seedRondelleDembrayageNumbers(){
 const productName='RONDELLE DEMBRAYAGE';
 // الأرقام المعتمدة من الصورة، محفوظة بنفس الكتابة والترتيب.
 const fixedNumbers=[
  '380/220/5','420/220/5','430/240/4',
  '350/220/4','350/220/4,8','380/220/4',
  '302/190/4','310/175/4','325/205/4',
  '280/165/4','280/165/5','302/190/3,7',
  '260/170/3','273/178/3,5','280/165/3,2',
  '228/150/3','228/150/3.2','228/150/3,5',
  '200/137/3,2','215/145/3,2','225/145/3,2',
  '152/90/5','178/101/5',
  '250/155/3','250/155/3,2','250/155/3,5',
  '241/156/3','241/156/3,2','241/156/3,5',
  '190/134/3,2','190/134/3','181/127/3,2','170/120/3,2',
  '165/90/4,8','260/170/3,2','160/110/3,2'
 ];
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_rondelle_dem',name:productName,image:'rondelle_dem_br.png',numbers:[]};
   db.products.push(product);
   changed=true;
 }
 if(product.image!=='rondelle_dem_br.png'){ product.image='rondelle_dem_br.png'; changed=true; }
 const current=Array.isArray(product.numbers)?product.numbers.map(x=>String(x||'').trim()).filter(Boolean):[];
 const same=current.length===fixedNumbers.length && current.every((v,i)=>v.toLowerCase()===fixedNumbers[i].toLowerCase());
 if(!same){ product.numbers=[...fixedNumbers]; changed=true; }
 if(changed) saveLocal();
}
seedRondelleDembrayageNumbers();
// أرقام ثابتة لمنتوج GOUJON DE ROUE: تُضاف مرة واحدة إلى قسم المنتجات وأرقامها.
function seedGoujonDeRoueNumbers(){
 const productName='GOUJON DE ROUE';
 const fixedNumbers=['VOLVO N10 AR T96','VOLVO N10 AR T110','VOLVO N10AV','VOLVO FM AR','VOLVO FM AV','SCANIA ROND AR T97','SCANIA ROND AV','SCANIA CARRĖ AR','SCANIA CARRĖ AV','MAN AR','MAN AV','DAF AR T102','DAF AV','MUTSU 8G AR','MUTSU 8G AV','MUTSU CANTER 6G AR','MUTSU CARTER 6G AV','MUTSU 5G AR','MUTSU 5G AV','ISUZU FTR AR','ISUZU FTR AV','ISUZU 15 AR','ISUZU 15 AV','VOLVO/RENAULT T114','RENAULT T96','RENAULT/IVECO','FUWA'];
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_goujon_roue_'+Date.now(),name:productName,image:"images/goujon_de_roue.jpg",numbers:[]};
   db.products.push(product);
   changed=true;
 }
 if(product.image!=="images/goujon_de_roue.jpg"){
   product.image="images/goujon_de_roue.jpg";
   changed=true;
 }
 const current=Array.isArray(product.numbers)?product.numbers.map(x=>String(x||'').trim()).filter(Boolean):[];
 const same=current.length===fixedNumbers.length && current.every((v,i)=>v.toLowerCase()===fixedNumbers[i].toLowerCase());
 if(!same){ product.numbers=[...fixedNumbers]; changed=true; }
 if(changed) saveLocal();
}
seedGoujonDeRoueNumbers();
// أرقام ثابتة لمنتوج TAMBOUR DE FREINS.
function seedTambourDeFreinsNumbers(){
 const productName='TAMBOUR DE FREINS';
 const fixedNumbers=['FUWA 16T','Tam 13T','MUTSU 10G AR','MUTSU 10G AV','ISUZU 10G AR/AV','MUTSU 6G AR/AV','ISUZU NBR','MUTSU 5G AR/AV'];
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_tambour_freins',name:productName,image:'images/tambour_de_freins.png',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.image!=='images/tambour_de_freins.png'){product.image='images/tambour_de_freins.png';changed=true;}
 const current=Array.isArray(product.numbers)?product.numbers.map(x=>String(x||'').trim()).filter(v=>{const k=v.toLowerCase(); return v && k!=='isuzu 10ar' && k!=='isuzu 10 ar' && k!=='isuzu 10g av' && k!=='mutsu 6g av' && k!=='mutsu 5g av' && k!=='mitsu 5g av';}).map(v=>v.toLowerCase()==='isuzu 10g ar'?'ISUZU 10G AR/AV':v):[];
 const seen=new Set(), cleaned=[];
 current.forEach(v=>{const k=v.toLowerCase();if(!seen.has(k)){seen.add(k);cleaned.push(v);}});
 fixedNumbers.forEach(v=>{const k=v.toLowerCase();if(!seen.has(k)){seen.add(k);cleaned.push(v);}});
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
seedTambourDeFreinsNumbers();

// بيانات مستخرجة من وصل التسليم TRUCKSAIS (BL2603907 بتاريخ 28/09/26).
// تُضاف مرة واحدة إلى قسم المنتجات وتعريفة الشركات، مع منع التكرار.
function seedTruckSaisDeliveryProducts(){
 const rows=[
  {name:'RONDELLE DEMBRAYAGE',ref:'273X178X3',price:64.48},
  {name:'COLLE',ref:'CO-ABX',price:200},
  {name:'RIVET TUBULAIRE 5X8',ref:'350.080',price:74.75}
 ];
 const company='TRUCKSAIS';
 if(!Array.isArray(db.products))db.products=[];
 if(!Array.isArray(db.companies))db.companies=[];
 if(!Array.isArray(db.companyPrices))db.companyPrices=[];
 let changed=false;
 let companyObj=db.companies.find(c=>normalizeProductName(c?.name||c||'')===normalizeProductName(company));
 if(!companyObj){
   companyObj={id:'company_seed_trucksais',name:company};
   db.companies.push(companyObj); changed=true;
 }
 rows.forEach(row=>{
   let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(row.name));
   if(!product){
     product={id:'prod_seed_trucksais_'+normalizeProductName(row.name).replace(/[^a-z0-9]+/g,'_'),name:row.name,image:'',numbers:[]};
     db.products.push(product); changed=true;
   }
   if(!Array.isArray(product.numbers))product.numbers=[];
   if(!product.numbers.some(r=>String(r).trim().toLowerCase()===row.ref.toLowerCase())){
     product.numbers.push(row.ref); product.numbers=sortNumbersAscending(product.numbers); changed=true;
   }
   const exists=db.companyPrices.find(x=>String(x.productId)===String(product.id)&&String(x.ref||'').trim().toLowerCase()===row.ref.toLowerCase()&&normalizeProductName(x.company||'')===normalizeProductName(company));
   if(!exists){
     db.companyPrices.push({id:'cp_seed_trucksais_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),company,productId:product.id,productName:product.name,ref:row.ref,price:row.price});
     changed=true;
   }
 });
 if(changed)saveLocal();
}
seedTruckSaisDeliveryProducts();
// أسماء الشركات المسجلة مسبقًا لتظهر في اختيار الشركة داخل التطبيق.
function seedCompanyNames(){
 const fixedCompanies=['SOFRENO','MORO','MANTEX','AZIKI','MATFORS'];
 if(!Array.isArray(db.companies)) db.companies=[];
 const existing=new Set(db.companies.map(c=>String(c?.name||'').trim().toLowerCase()).filter(Boolean));
 let changed=false;
 fixedCompanies.forEach(name=>{
   const key=name.toLowerCase();
   if(!existing.has(key)){
     db.companies.push({id:'company_seed_'+key,name});
     existing.add(key); changed=true;
   }
 });
 if(changed) saveLocal();
}
seedCompanyNames();

// تنظيف قائمة المنتجات بناءً على طلب المستخدم: الإبقاء فقط على JEU DE GARNITURE.
// الأرقام محفوظة كنصوص حتى تبقى الأصفار في البداية كما هي.
function keepOnlyJeuDeGarniture(){
 const jeuName='JEU DE GARNITURE';
 const goujonName='GOUJON DE ROUE';
 const tambourName='TAMBOUR DE FREINS';
 const moyeuName='MOYEU DE ROUE';
 const fixedNumbers=['8321','8328','8112','8469','8468','8330','8331','8173','8172','5834','5835','6329','6303','5823','5836','5837','00742','002','003','005','0105','0068','0223','0120','8091','5583','5593','5587','5586','0740','0774','0050','5608','5676','8009','8016','8007','8177','8079','8027','0785','8154','8153','8003','8158','0012','IVECO 90/5','MERS 80/8'];
 if(!Array.isArray(db.products)) db.products=[];
 let jeu=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(jeuName));
 if(!jeu) jeu={id:'prod_jeu_de_garniture',name:jeuName,image:'jeu_de_garniture.jpg',numbers:[]};
 jeu.name=jeuName; jeu.image='jeu_de_garniture.jpg'; jeu.numbers=[...fixedNumbers];
 let goujon=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(goujonName));
 if(!goujon) goujon={id:'prod_seed_goujon_roue',name:goujonName,image:'images/goujon_de_roue.jpg',numbers:[]};
 goujon.name=goujonName; goujon.image='images/goujon_de_roue.jpg';
 let tambour=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(tambourName));
 if(!tambour) tambour={id:'prod_seed_tambour_freins',name:tambourName,image:'images/tambour_de_freins.png',numbers:[]};
 tambour.name=tambourName; tambour.image='images/tambour_de_freins.png';
 let moyeu=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(moyeuName));
 if(!moyeu) moyeu={id:'prod_seed_moyeu_de_roue',name:moyeuName,image:'images/moyeu_de_roue.jpg',numbers:[]};
 moyeu.name=moyeuName; moyeu.image='images/moyeu_de_roue.jpg';
 moyeu.numbers=['FUWA 16T','FRUEHAUF  MANUEL  6001 13T'];
 db.products=[jeu,goujon,tambour,moyeu];
 if(db.priceRefs && typeof db.priceRefs==='object'){ Object.keys(db.priceRefs).forEach(k=>{if(k!==String(jeu.id)&&k!==String(goujon.id))delete db.priceRefs[k];}); }
 if(db.purchasePrices && typeof db.purchasePrices==='object'){ Object.keys(db.purchasePrices).forEach(k=>{if(k!==String(jeu.id)&&k!==String(goujon.id))delete db.purchasePrices[k];}); }
 if(Array.isArray(db.companyPrices)){ db.companyPrices=db.companyPrices.filter(x=>String(x.productId)===String(jeu.id)||String(x.productId)===String(goujon.id)||normalizeProductName(x?.productName||'')===normalizeProductName(jeuName)||normalizeProductName(x?.productName||'')===normalizeProductName(goujonName)); }
 saveLocal();
}
keepOnlyJeuDeGarniture();

// إضافة المنتوج الأخير RONDELLE DEMBRAYAGE إلى قسم المنتجات بعد تنظيف القائمة.
// يبقى هذا المنتوج محفوظاً مع صورته وجميع أرقامه الـ23.
function ensureRondelleDembrayageAfterCleanup(){
 const productName='RONDELLE DEMBRAYAGE';
 const fixedNumbers=[
  '380/220/5','420/220/5','430/240/4',
  '350/220/4','350/220/4,8','380/220/4',
  '302/190/4','310/175/4','325/205/4',
  '280/165/4','280/165/5','302/190/3,7',
  '260/170/3','273/178/3,5','280/165/3,2',
  '228/150/3','228/150/3.2','228/150/3,5',
  '200/137/3,2','215/145/3,2','225/145/3,2',
  '152/90/5','178/101/5',
  '250/155/3','250/155/3,2','250/155/3,5',
  '241/156/3','241/156/3,2','241/156/3,5',
  '190/134/3,2','190/134/3','181/127/3,2','170/120/3,2',
  '165/90/4,8','260/170/3,2','160/110/3,2'
 ];
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_rondelle_dem_final',name:productName,image:'rondelle_dem_br.png',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.image!=='rondelle_dem_br.png'){product.image='rondelle_dem_br.png';changed=true;}
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
ensureRondelleDembrayageAfterCleanup();

// تنظيف نهائي لمنتوج GOUJON DE ROUE: حذف أي رقم/مرجع مكرر مهما كان اختلاف حالة الأحرف أو المسافات.
function dedupeGoujonDeRoue(){
 const name='GOUJON DE ROUE';
 if(!Array.isArray(db.products)) return;
 const product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(name));
 if(!product || !Array.isArray(product.numbers)) return;
 const seen=new Set();
 const cleaned=[];
 product.numbers.forEach(v=>{
   const raw=String(v??'').trim();
   if(!raw) return;
   const key=raw.replace(/\s+/g,' ').toLowerCase();
   if(seen.has(key)) return;
   seen.add(key);
   cleaned.push(raw);
 });
 if(cleaned.length!==product.numbers.length){ product.numbers=cleaned; saveLocal(); }
}
dedupeGoujonDeRoue();

// إضافة منتوج CHAMBER DE AIR إلى قسم المنتجات.
function ensureChamberDeAir(){
 const productName='CHAMBER DE AIR';
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_chamber_de_air',name:productName,image:'images/chamber_de_air.jpg',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.name!==productName){product.name=productName;changed=true;}
 if(product.image!=='images/chamber_de_air.jpg'){product.image='images/chamber_de_air.jpg';changed=true;}
 const fixedNumbers=['24','30','24/24','30/30','24/30'];
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
ensureChamberDeAir();

// إضافة منتوج LEVIER DE CAME MANUEL مع صورته.
function ensureLevierDeCame(){
 const productName='LEVIER DE CAME MANUEL';
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_levier_de_came',name:productName,image:'images/levier_de_came.png',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.name!==productName){product.name=productName;changed=true;}
 if(product.image!=='images/levier_de_came.png'){product.image='images/levier_de_came.png';changed=true;}
 const fixedNumbers=['','','','','DAF VOLVO MANUEL 5325','DAF VOLVO MANUEL 5324','FRUEHAUF MANUEL 6001','L L CAME MANUEL 37 DENTS','L L CAME MANUEL 10 DENTS','','','','','SCANIA MANUEL 6518','SCANIA MANUEL 6517'];
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
ensureLevierDeCame();

// إضافة منتوج LEVIER DE CAME AUTOMATIC مع صورته وأرقامه.
function ensureLevierDeCameAutomatic(){
 const productName='LEVIER DE CAME AUTOMATIC';
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_levier_de_came_automatic',name:productName,image:'images/levier_de_came_automatic.png',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.name!==productName){product.name=productName;changed=true;}
 if(product.image!=='images/levier_de_came_automatic.png'){product.image='images/levier_de_came_automatic.png';changed=true;}
 const fixedNumbers=[
  'DAF AUTOMATIC 1544',
  'DAF AUTOMATIC 1543',
  'RENAULT AUTOMATIC 424095',
  'RENAULT AUTOMATIC 424094',
  'DAF CF AR AUTOMATIC 424043',
  'DAF CF AR AUTOMATIC 424042',
  'RENAULT AUTOMATIC 424009',
  'RENAULT AUTOMATIC 424008'
 ];
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
ensureLevierDeCameAutomatic();


// إضافة منتوج DISK DEMBRAYAGE مع صورته وأرقامه.
function ensureDiskDembrayage(){
 const productName='DISK DEMBRAYAGE';
 if(!Array.isArray(db.products)) db.products=[];
 let product=db.products.find(x=>normalizeProductName(x?.name||'')===normalizeProductName(productName));
 let changed=false;
 if(!product){
   product={id:'prod_seed_disk_dem_br',name:productName,image:'images/disk_dem_br.jpg',numbers:[]};
   db.products.push(product); changed=true;
 }
 if(product.name!==productName){product.name=productName;changed=true;}
 if(product.image!=='images/disk_dem_br.jpg'){product.image='images/disk_dem_br.jpg';changed=true;}
 const fixedNumbers=['MUTSU 10G', 'MUTSU 8G', 'MUTSU 5G', 'MUTSU 6G HD', 'ISUZU FTR 350', 'ISUZU 15 325'];
 if(JSON.stringify(product.numbers)!==JSON.stringify(fixedNumbers)){product.numbers=[...fixedNumbers];changed=true;}
 if(changed) saveLocal();
}
ensureDiskDembrayage();




function el(id){return document.getElementById(id)}
function loadLocal(){try{const x=localStorage.getItem(STORAGE_KEY);const dbx=x?JSON.parse(x):structuredClone(emptyDB);try{if(window.AndroidExpenses&&typeof AndroidExpenses.loadExpenses==='function'){const raw=AndroidExpenses.loadExpenses();if(raw){const ex=JSON.parse(raw);if(Array.isArray(ex))dbx.expenses=ex;}}}catch(e){}return dbx}catch(e){return structuredClone(emptyDB)}}
const AFZ_PERSIST_META='afz_persist_meta_v1';
const AFZ_IDB_NAME='afz_persistent_data_v1';
const AFZ_IDB_STORE='appdata';
function afzIdb(){return new Promise((resolve,reject)=>{try{if(!window.indexedDB)return reject(new Error('IndexedDB unavailable'));const r=indexedDB.open(AFZ_IDB_NAME,1);r.onupgradeneeded=()=>{try{if(!r.result.objectStoreNames.contains(AFZ_IDB_STORE))r.result.createObjectStore(AFZ_IDB_STORE,{keyPath:'id'});}catch(e){}};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('IndexedDB error'));}catch(e){reject(e)}})}
async function afzIdbPut(data,ts){try{const dbi=await afzIdb();await new Promise((resolve,reject)=>{const tx=dbi.transaction(AFZ_IDB_STORE,'readwrite');tx.objectStore(AFZ_IDB_STORE).put({id:'main',ts,data});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});dbi.close();}catch(e){}}
async function afzIdbGet(){try{const dbi=await afzIdb();const rec=await new Promise((resolve,reject)=>{const tx=dbi.transaction(AFZ_IDB_STORE,'readonly');const r=tx.objectStore(AFZ_IDB_STORE).get('main');r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error);});dbi.close();return rec;}catch(e){return null}}
async function afzHydratePersistentData(){const rec=await afzIdbGet();if(!rec||!rec.data)return;let localTs=Number(localStorage.getItem(AFZ_PERSIST_META)||0);if(!localTs)localTs=0;if(Number(rec.ts||0)>localTs){try{const restored=JSON.parse(rec.data);if(restored&&typeof restored==='object'){db=restored;normalizeSavedData();localStorage.setItem(STORAGE_KEY,rec.data);localStorage.setItem(AFZ_PERSIST_META,String(rec.ts));render();renderCart();}}catch(e){}}}
function saveLocal(){
 const payload=JSON.stringify(db); const ts=Date.now();
 try{localStorage.setItem(STORAGE_KEY,payload);localStorage.setItem(AFZ_PERSIST_META,String(ts));}catch(e){console.warn('localStorage save failed',e)}
 afzIdbPut(payload,ts);
 try{if(window.AndroidExpenses&&typeof AndroidExpenses.saveExpenses==='function')AndroidExpenses.saveExpenses(JSON.stringify(Array.isArray(db.expenses)?db.expenses:[]));}catch(e){}
}
// حفظ تلقائي إضافي عند إخفاء التطبيق أو إغلاق صفحة WebView، حتى لا تضيع آخر تعديلات.
function afzForceSave(){try{saveLocal();}catch(e){}}
window.addEventListener('pagehide',afzForceSave);
window.addEventListener('beforeunload',afzForceSave);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')afzForceSave();});
function money(n){return (Number(n)||0).toFixed(2)+' DH'}
function clearQuickSaleSearchFields(){
 const name=el('quickSaleName'), ref=el('quickSaleRef');
 if(name)name.value='';
 if(ref)ref.value='';
 const np=el('quickSaleNamePicker'), rp=el('quickSaleRefPicker');
 if(np)np.style.display='none';
 if(rp)rp.style.display='none';
}
let sectionHistory=[];
let AFZ_APP_MODE='';
function AFZ_SET_MODE(mode){
  AFZ_APP_MODE=mode==='browse'?'browse':'edit';
  document.body.classList.toggle('afz-browse-mode',AFZ_APP_MODE==='browse');
  document.body.classList.toggle('afz-edit-mode',AFZ_APP_MODE==='edit');
  let controls=document.getElementById('afzModeControls');
  if(!controls){
    controls=document.createElement('div');
    controls.id='afzModeControls';
    controls.className='afz-mode-controls';
    const header=document.querySelector('header');
    if(header) header.appendChild(controls);
  }
  let toggle=document.getElementById('afzModeToggle');
  if(!toggle){
    toggle=document.createElement('button');
    toggle.id='afzModeToggle';
    toggle.type='button';
    toggle.className='afz-toggle-btn';
    toggle.onclick=function(){AFZ_SET_MODE(AFZ_APP_MODE==='browse'?'edit':'browse');};
    controls.appendChild(toggle);
  }
  toggle.classList.toggle('edit',AFZ_APP_MODE==='edit');
  toggle.textContent=AFZ_APP_MODE==='browse'?'👁️ وضع التصفح':'✏️ وضع التعديل';
  toggle.title=AFZ_APP_MODE==='browse'?'اضغط للانتقال إلى التعديل وتسجيل البيانات':'اضغط للعودة إلى وضع التصفح';
  if(typeof render==='function') setTimeout(()=>render(),0);
}

function AFZ_CAN_EDIT(){return AFZ_APP_MODE==='edit';}
document.addEventListener('DOMContentLoaded',function(){AFZ_SET_MODE('browse');});

let currentSection='home';
function show(id, skipHistory=false){
 if(arguments[0]==='products') setTimeout(renderMasterProductNamePicker,0);
 if(!el(id))return;
 if(!skipHistory && currentSection!==id){
   if(id==='home') sectionHistory=[];
   else if(currentSection && currentSection!=='home') sectionHistory.push(currentSection);
   else if(currentSection==='home' && sectionHistory.length===0) sectionHistory.push('home');
 }
 if(id!=='sales')clearQuickSaleSearchFields();
 document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
 el(id).classList.add('active');
 const titles={home:'الرئيسية',products:'المنتجات | الاسم | الرقم | الصورة',companyPrices:'أسعار الشركات',stock:'المخزون',purchasePrices:'أسعار الشركات',prices:'الأسعار',sales:'المبيعات',customers:'الزبائن',delivery:'وصل التسليم',expenses:'مصاريف اليوم',credit:'الكريدي',checks:'دفتر الشيكات',notifications:'الإشعارات',reports:'التقارير',backup:'نسخة احتياطية'};
 currentSection=id;
 document.body.classList.toggle('single-section',id!=='home');
 if(el('sectionTitle'))el('sectionTitle').textContent=titles[id]||'';
 const back=el('sectionBackButton');
 if(back)back.disabled=(id==='home');
 render();
}
function resetNavigationState(){
 // إعادة تعيين كل الحالات المؤقتة عند الضغط على رجوع/الرئيسية، دون لمس البيانات المحفوظة.
 if(typeof selectedStockCardName!=='undefined') selectedStockCardName='';
 if(typeof selectedPriceCardName!=='undefined') selectedPriceCardName='';
 if(typeof selectedPriceBottomCardId!=='undefined') selectedPriceBottomCardId='';
 if(typeof selectedPurchaseProductCardName!=='undefined') selectedPurchaseProductCardName='';
 // مسح حقول البحث والاختيارات والنتائج المؤقتة حتى يبدأ القسم من حالته الأصلية.
 document.querySelectorAll('input[id*="Search"], input[id*="search"]').forEach(input=>{
   if(input.type==='text' || input.type==='search') input.value='';
 });
 // قسم تعريفة الشركات يستخدم قوائم اختيار، لذلك يجب تصفيرها أيضاً عند الرجوع.
 ['companyPriceSearchName','companyPriceSearchRef','companyPriceSearchCompany'].forEach(id=>{
   const node=el(id);
   if(node){ node.value=''; node.selectedIndex=0; node.dispatchEvent(new Event('change',{bubbles:true})); }
 });
 const companySearchResult=el('companyPriceSearchResult');
 if(companySearchResult) companySearchResult.innerHTML='';
 const companyCards=el('companyPricesTable');
 if(companyCards) companyCards.style.display='';
 document.querySelectorAll('.search-picker-list').forEach(x=>x.style.display='none');
 document.querySelectorAll('.choice-modal.open').forEach(x=>x.classList.remove('open'));
 window.scrollTo(0,0);
}
function goHomeSection(){
 resetNavigationState();
 sectionHistory=[];
 show('home',true);
}
function goBackSection(){
 if(currentSection==='home'){return;}
 resetNavigationState();
 const target=sectionHistory.length?sectionHistory.pop():'home';
 show(target,true);
 window.scrollTo(0,0);
}
window.addEventListener('popstate',()=>{ if(currentSection!=='home') goBackSection(); });
async function compressImage(file){if(!file)return '';return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const max=800,scale=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',0.72))};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
function normalizeProductName(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,' ')}
// الترتيب الموحد في جميع أقسام التطبيق: الأسماء والمراجع والحروف A → Z.
function compareNamesAZ(a,b){
 const clean=v=>String(v??'').replace(/^[\s\-_.]+/,'').trim();
 const A=clean(a), B=clean(b);
 return A.localeCompare(B,'en',{numeric:true,sensitivity:'base'});
}

// ترتيب أسماء جميع البطاقات الظاهرة في التطبيق من A إلى Z بشكل موحّد.
function sortCardContainersAZ(){
 const rules=[
   ['.product-grid','.product-card','.identity-title'],
   ['.master-products-grid','.master-product-card','.master-product-card-name'],
   ['#priceCards','.price-product-card','.price-card-name'],
   ['#pricesBottomCardsBody','.price-bottom-product-card','.price-bottom-product-name'],
   ['#purchaseProductCardsGrid','.purchase-product-card','.purchase-product-card-name'],
   ['#companyPricesTable','.company-price-product-card','.company-price-product-card-title span:last-child']
 ];
 rules.forEach(([containerSel,cardSel,nameSel])=>{
   const container=document.querySelector(containerSel);
   if(!container)return;
   const cards=[...container.querySelectorAll(':scope > '+cardSel)];
   if(cards.length<2)return;
   cards.sort((a,b)=>compareNamesAZ(a.querySelector(nameSel)?.textContent||'',b.querySelector(nameSel)?.textContent||''));
   cards.forEach(card=>container.appendChild(card));
 });
}

// ترتيب أسماء المنتجات في كل عرض وبحث داخل التطبيق من A إلى Z.
function sortProductRowsAZ(rows){
  return (Array.isArray(rows)?rows:[]).slice().sort((a,b)=>{
    const byName=compareNamesAZ(a?.name,b?.name);
    if(byName!==0)return byName;
    const ar=Array.isArray(a?.numbers)?a.numbers[0]:'';
    const br=Array.isArray(b?.numbers)?b.numbers[0]:'';
    return compareRefsDesc(ar,br);
  });
}


// ترتيب المراجع/الكلمات داخل بطاقة كل منتوج من A إلى Z.
function compareProductRefsAZDesc(a,b){
 const A=String(a??'').trim(), B=String(b??'').trim();
 // ترتيب الكلمات والحروف A → Z، ثم الرقم من الأكبر إلى الأصغر عند تطابق الكلمات.
 const stripNum=x=>x.replace(/\d+(?:[.,]\d+)?/g,' ').replace(/\s+/g,' ').trim();
 const byName=compareNamesAZ(stripNum(A),stripNum(B));
 if(byName!==0)return byName;
 return compareRefsDesc(A,B);
}
function sortRefsAZ(values){
  return [...new Set((values||[])
    .map(v=>String(v??'').trim())
    .filter(Boolean))]
    .sort(compareProductRefsAZDesc);
}

function compareRefsDesc(a,b){
 const A=String(a??'').trim(), B=String(b??'').trim();
 const na=A.match(/\d+(?:[.,]\d+)?/g)||[], nb=B.match(/\d+(?:[.,]\d+)?/g)||[];
 const n=Math.max(na.length,nb.length);
 for(let i=0;i<n;i++){
   const av=i<na.length?Number(na[i].replace(',','.')):NaN;
   const bv=i<nb.length?Number(nb[i].replace(',','.')):NaN;
   if(Number.isFinite(av)&&Number.isFinite(bv)&&av!==bv)return bv-av;
   if(Number.isFinite(av)&&!Number.isFinite(bv))return -1;
   if(!Number.isFinite(av)&&Number.isFinite(bv))return 1;
 }
 return compareNamesAZ(A,B);
}
function sortNamesAZ(values){
 return [...new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean))].sort(compareNamesAZ);
}
function sortNumbersDesc(values){
 return [...new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean))].sort(compareRefsDesc);
}
function stockCatalogId(name){return 'stockcat:'+normalizeProductName(name);}

function stockSortNamesDescending(values){ return sortNamesAZ(values); }
function stockSortNumbersDescending(values){
 return [...new Set((values||[]).map(v=>String(v||'').trim()).filter(Boolean))].sort((a,b)=>{
   const an=a.match(/\d+(?:[.,]\d+)?/), bn=b.match(/\d+(?:[.,]\d+)?/);
   if(an&&bn){ const av=Number(an[0].replace(',','.')), bv=Number(bn[0].replace(',','.')); if(av!==bv)return bv-av; }
   if(an&&!bn)return -1; if(!an&&bn)return 1;
   return b.localeCompare(a,'ar',{numeric:true,sensitivity:'base'});
 });
}
function stockCatalogProducts(){
 const groups=new Map();
 // تبدأ قائمة العرض من المنتجات المسجلة في الأسعار/المنتوجات، وليس من المخزون فقط.
 (db.products||[]).forEach(p=>{
   const name=String(p.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   groups.set(key,{id:p.id,name:p.name,image:p.image||'',numbers:getPriceOnlyRefs(p.id)});
 });
 // قسم الأسعار هو المصدر الوحيد للاسم والرقم والصورة. لا ننشئ أي منتوج من المخزون.
 return [...groups.values()].sort((a,b)=>compareNamesAZ(a.name,b.name)).map(p=>({...p,numbers:sortNumbersAscending(p.numbers)}));
}
function syncProductsFromStock(){
 // لا نسمح للمخزون بإنشاء أسماء أو أرقام أو صور جديدة. المرجع الوحيد هو قسم الأسعار.
 if(!Array.isArray(db.products)) db.products=[];
 return db.products;
}
function getCatalogProduct(id){
 syncProductsFromStock();
 return (db.products||[]).find(x=>String(x.id)===String(id))||null;
}
function getCatalogProductByName(name){
 const q=normalizeProductName(name); syncProductsFromStock();
 return (db.products||[]).find(x=>normalizeProductName(x.name)===q)||null;
}
function getCatalogProductByRef(ref){
 const q=String(ref||'').trim().toLowerCase(); if(!q)return null; syncProductsFromStock();
 return (db.products||[]).find(p=>getPriceOnlyRefs(p.id).some(n=>String(n).trim().toLowerCase()===q))||null;
}
function productNumbers(p){
 if(!p)return [];
 const raw=Array.isArray(p.numbers)?p.numbers:[];
 return sortRefsAZ(raw);
}
// ترتيب أرقام قسم المنتجات من الأكبر إلى الأصغر مع إبقاء الحروف مرتبة طبيعياً.
function productNumbersDesc(p){
 if(!p)return [];
 const raw=Array.isArray(p.numbers)?p.numbers:[];
 return [...new Set(raw.map(v=>String(v??'').trim()).filter(Boolean))].sort(compareRefsDesc);
}
function getCatalogRefsForName(name){const p=getCatalogProductByName(name);return p?productNumbers(p):[];}
function isCatalogRefForProduct(productId,ref){const p=getCatalogProduct(productId);const q=String(ref||'').trim().toLowerCase();return !!p && getPriceOnlyRefs(p.id).some(n=>String(n).trim().toLowerCase()===q);}
function syncCatalogLinks(){
 syncProductsFromStock();
}
function stockNameRegistry(){
 const groups=new Map();
 (db.products||[]).forEach(p=>{
   const name=String(p.name||'').trim(); if(!name)return;
   const key=normalizeProductName(name);
   const refs=getPriceOnlyRefs(p.id);
   if(!groups.has(key)) groups.set(key,{name:p.name,image:p.image||'',refs:[]});
   const g=groups.get(key);
   refs.forEach(ref=>{if(ref&&!g.refs.some(x=>x.toLowerCase()===String(ref).toLowerCase()))g.refs.push(String(ref));});
 });
 return [...groups.values()].map(g=>({...g,refs:stockSortNumbersDescending(g.refs)})).sort((a,b)=>compareNamesAZ(a.name,b.name));
}
function renderRegisteredProductNames(){
 const sel=el('registeredProductName');
 if(!sel)return;
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 sel.innerHTML=products.length?'<option value="">اختر اسم المنتوج المسجل</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join(''):'<option value="">لا توجد منتوجات مسجلة</option>';
}
function renderPurchaseRegisteredProductNames(){
 const sel=el('purchaseRegisteredProductName');
 if(!sel)return;
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 sel.innerHTML=products.length?'<option value="">اختر اسم المنتوج المسجل</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join(''):'<option value="">لا توجد منتوجات مسجلة</option>';
}
function togglePurchaseRegisteredNumberForm(force){
 const form=el('purchaseRegisteredNumberForm'); if(!form)return;
 const show=force===undefined?form.style.display==='none':!!force;
 if(show){
   // لا تسمح بفتح نموذجين في نفس الوقت داخل قسم ثمن المنتجات.
   const productForm=el('purchaseProductForm');
   if(productForm){productForm.style.display='none';productForm.hidden=true;}
 }
 form.style.display=show?'block':'none'; form.hidden=!show;
 if(show){
   renderPurchaseRegisteredProductNames();
   const status=el('purchaseRegisteredNumberStatus'); if(status){status.textContent='';status.style.display='none';}
   const inp=el('purchaseRegisteredProductNumber'); if(inp){inp.value='';setTimeout(()=>inp.focus(),50);}
   const buy=el('purchaseRegisteredProductBuy'); if(buy)buy.value='';
 }else{
   form.reset();
   const status=el('purchaseRegisteredNumberStatus'); if(status){status.textContent='';status.style.display='none';}
 }
}
function savePurchaseRegisteredNumber(e){
 e.preventDefault();
 const id=String(el('purchaseRegisteredProductName')?.value||'').trim();
 const ref=String(el('purchaseRegisteredProductNumber')?.value||'').trim();
 const buyText=String(el('purchaseRegisteredProductBuy')?.value||'').trim();
 const buy=Number(buyText);
 const status=el('purchaseRegisteredNumberStatus');
 const inp=el('purchaseRegisteredProductNumber');
 const buyInp=el('purchaseRegisteredProductBuy');
 const fail=(msg,clear=false)=>{if(status){status.textContent=msg;status.style.display='block';status.style.color='#b42318';}if(clear&&inp){inp.value='';setTimeout(()=>inp.focus(),30);}return false;};
 const product=getCatalogProduct(id);
 if(!product)return fail('اختر اسم المنتوج المسجل');
 if(!ref)return fail('أدخل رقم المنتوج أو المرجع الجديد',true);
 if(!buyText || !Number.isFinite(buy) || buy<0){if(buyInp)buyInp.focus();return fail('أدخل ثمن شراء صحيح للرقم الجديد');}
 const normalizedRef=ref.toLowerCase();
 const refs=productNumbers(product);
 // يسمح لنفس الاسم بعدة أرقام، لكن يمنع تكرار نفس الرقم لنفس الاسم.
 if(refs.some(r=>String(r).trim().toLowerCase()===normalizedRef)){
   return fail(`الرقم ${ref} مسجل مسبقًا باسم ${product.name}. اكتب رقمًا آخر لهذا المنتوج.`,true);
 }
 // الرقم نفسه يمكن استعماله لاسم آخر؛ المنع هنا فقط من تكرار الرقم داخل نفس اسم المنتوج.
 if(!Array.isArray(product.numbers))product.numbers=[];
 product.numbers.push(ref);
 product.numbers=sortNumbersAscending(product.numbers);
 const pid=String(product.id);
 if(!db.purchasePrices || typeof db.purchasePrices!=='object' || Array.isArray(db.purchasePrices))db.purchasePrices={};
 if(!db.purchasePrices[pid] || typeof db.purchasePrices[pid]!=='object' || Array.isArray(db.purchasePrices[pid]))db.purchasePrices[pid]={};
 db.purchasePrices[pid][normalizedRef]=buy;
 if(!db.priceRefs || typeof db.priceRefs!=='object')db.priceRefs={};
 if(!Array.isArray(db.priceRefs[pid]))db.priceRefs[pid]=[];
 if(!db.priceRefs[pid].some(r=>String(r).trim().toLowerCase()===normalizedRef))db.priceRefs[pid].push(ref);
 try{
   save();
   render();
   renderPurchaseRegisteredProductNames();
   if(inp){inp.value='';setTimeout(()=>inp.focus(),30);}
   if(buyInp)buyInp.value='';
   if(status){status.textContent=`تم تسجيل الرقم ${ref} وثمنه ${buy} DH للمنتوج ${product.name} بنجاح. يمكنك إضافة رقم آخر وثمنه لنفس المنتوج.`;status.style.display='block';status.style.color='#087443';}
 }catch(err){
   product.numbers=refs;
   if(db.priceRefs?.[pid]) db.priceRefs[pid]=db.priceRefs[pid].filter(r=>String(r).trim().toLowerCase()!==normalizedRef);
   if(db.purchasePrices?.[pid]) delete db.purchasePrices[pid][normalizedRef];
   return fail('تعذر حفظ الرقم وثمنه. حاول مرة أخرى.',true);
 }
 return true;
}
function addRegisteredProductNumber(e){
 e.preventDefault();
 const id=String(el('registeredProductName')?.value||'').trim();
 const ref=String(el('registeredProductNumber')?.value||'').trim();
 const product=getCatalogProduct(id);
 if(!product)return alert('اختر اسم المنتوج المسجل');
 if(!ref)return alert('أدخل رقم المنتوج أو المرجع');
 if(productNumbers(product).some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()))return alert('هذا الرقم مسجل مسبقًا لهذا المنتوج.');
 if(!Array.isArray(product.numbers))product.numbers=[];
 product.numbers.push(ref);
 product.numbers=sortNumbersAscending(product.numbers);
 save();
 e.target.reset();
 render();
 renderRegisteredProductNames();
 alert(`تمت إضافة الرقم ${ref} إلى منتوج ${product.name}`);
}
function renderStockNameRegistry(){
 const box=el('stockNameRegistry'); if(!box)return;
 const groups=stockNameRegistry();
 box.innerHTML=groups.length?`<div style="overflow-x:auto"><table class="stock-accounting-table"><thead><tr><th>اسم المنتوج</th><th>الأرقام المسجلة</th></tr></thead><tbody>${groups.map(g=>`<tr><td><b>${esc(g.name)}</b></td><td>${g.refs.length?g.refs.map(r=>`<span class="product-number-chip">${esc(r)}</span>`).join(' '):'-'}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد أسماء مسجلة في المخزون بعد</div>';
}
function toggleStockNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('pname');
 if(input && input.dataset.stockNameMode==='new' && !input.readOnly){
   input.focus();
   return;
 }
 openStockNamePicker(true);
}
function getStockSearchNames(){
 return stockSortNamesDescending((db.stock||[]).map(x=>String(x.name||'').trim()));
}
function openStockSearchNamePicker(){
 const box=el('stockSearchNamePicker'); if(!box)return;
 const q=normalizeProductName(el('stockNameSearch')?.value||'');
 const names=getStockSearchNames().filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=names.length?names.map(n=>`<button type="button" class="search-picker-item stock-search-name-option" data-stock-search-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء مسجلة</div>';
 box.style.display='block'; setStockPickerOpen(box,true);
}
function filterStockSearchNamePicker(){openStockSearchNamePicker();}
function toggleStockSearchNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const box=el('stockSearchNamePicker');
 if(box && box.style.display==='block'){box.style.display='none';setStockPickerOpen(box,false);return;}
 openStockSearchNamePicker();
}
function resetStockSearchNumber(){
 const name=String(el('stockNameSearch')?.value||'').trim();
 const ref=el('stockSearch');
 if(ref){
   const valid=getStockRefsForName(name).some(r=>String(r)===String(ref.value||'').trim());
   if(!valid) ref.value='';
 }
 renderStockSearchOptions();
}

function setStockPickerOpen(box, open=true){
  if(!box)return;
  if(open){box.classList.add('stock-modal-picker');document.body.classList.add('stock-picker-open');}
  else {box.classList.remove('stock-modal-picker');
    const any=['stockNamePicker','stockRefPicker','stockSearchNamePicker','stockSearchPicker'].some(id=>{const b=el(id);return b&&b.style.display==='block';});
    if(!any)document.body.classList.remove('stock-picker-open');
  }
}
function closeStockPickers(){
 ['stockNamePicker','stockRefPicker','stockSearchNamePicker','stockSearchPicker'].forEach(id=>{const b=el(id);if(b)b.style.display='none';});
 document.body.classList.remove('stock-picker-open');
}

function openStockSearchPicker(){
 const box=el('stockSearchPicker'); if(!box)return;
 const name=String(el('stockNameSearch')?.value||'').trim();
 if(!name){
   box.innerHTML='<div class="search-picker-empty">اختر اسم المنتوج أولاً</div>';
   box.style.display='block'; return;
 }
 const q=String(el('stockSearch')?.value||'').trim().toLowerCase();
 const refs=getStockRefsForName(name).filter(r=>!q||r.toLowerCase().includes(q));
 box.innerHTML=refs.length?refs.map(r=>`<button type="button" class="search-picker-item stock-search-option" data-stock-search-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أرقام لهذا الاسم</div>';
 box.style.display='block'; setStockPickerOpen(box,true);
}
function filterStockSearchPicker(){openStockSearchPicker();}
function toggleStockSearchPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const box=el('stockSearchPicker');
 if(box && box.style.display==='block'){box.style.display='none';setStockPickerOpen(box,false);return;}
 openStockSearchPicker();
}
function openStockNamePicker(showAll=false){
 const box=el('stockNamePicker'); if(!box)return;
 const input=el('pname');
 if(input){input.dataset.stockNameMode='existing';input.readOnly=true;}
 renderStockProductOptions();
 const q=showAll?'':normalizeProductName(input?.value||'');
 const names=[...(db.products||[])].map(p=>String(p.name||'').trim()).filter(Boolean)
   .sort((a,b)=>compareNamesAZ(a,b))
   .filter(n=>!q||normalizeProductName(n).includes(q));
 const items=names.length?names.map(n=>`<button type="button" data-stock-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء مسجلة في قسم «المنتجات | الاسم | الرقم | الصورة»</div>';
 box.innerHTML=`<div class="stock-name-choice"><b>الأسماء من قسم «المنتجات | الاسم | الرقم | الصورة»</b></div>${items}`;
 box.style.display='block'; setStockPickerOpen(box,true);
}
function filterStockNamePicker(){openStockNamePicker(); renderStockRefOptions();}
function selectStockName(name){
 const input=el('pname');
 if(input){input.value=name||'';input.readOnly=true;input.dataset.stockNameMode='existing';}
 const box=el('stockNamePicker'); if(box){box.style.display='none';setStockPickerOpen(box,false);}
 const ref=el('pref');
 if(ref){ref.value='';ref.readOnly=true;ref.dataset.stockRefMode='existing';ref.placeholder='اختر رقم المنتوج';}
 renderStockRefOptions();
 renderStockCompanyOptions();
 openStockRefPicker();
 updateStockQtyMode();
 updateStockImageMode();
}
function openStockRefPicker(){
 const box=el('stockRefPicker'); if(!box)return;
 const name=String(el('pname')?.value||'').trim();
 if(!name || (el('pname')?.dataset.stockNameMode!=='existing')){
   box.innerHTML='<div class="search-picker-empty">اختر اسم المنتوج أولاً</div>';
   box.style.display='block';
   return;
 }
 const q=String(el('pref')?.value||'').trim().toLowerCase();
 const product=getCatalogProductByName(name);
 const refs=product?productNumbers(product):[];
 const filtered=refs.filter(r=>!q||String(r).toLowerCase().includes(q));
 box.innerHTML=`<div class="small" style="padding:6px 8px">الأرقام من قسم «المنتجات | الاسم | الرقم | الصورة» لـ <b>${esc(name)}</b></div>`+
   (filtered.length ? filtered.map(r=>`<button type="button" class="search-picker-item" data-stock-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join('') : '<div class="search-picker-empty">لا توجد أرقام مسجلة لهذا الاسم</div>');
 box.style.display='block'; setStockPickerOpen(box,true);
}
function filterStockRefPicker(){openStockRefPicker();}
function getStockRefsForName(name){
 const p=getCatalogProductByName(name);
 if(!p)return [];
 return sortRefsAZ(productNumbers(p));
}
document.addEventListener('touchmove',function(e){
 const p=e.target.closest('#stockNamePicker,#stockRefPicker,#stockSearchNamePicker,#stockSearchPicker');
 if(p){ e.stopPropagation(); }
},{passive:true});
document.addEventListener('pointerdown',function(e){
 const p=e.target.closest('#stockNamePicker,#stockRefPicker,#stockSearchNamePicker,#stockSearchPicker');
 if(p) e.stopPropagation();
},{passive:true});

document.addEventListener('click',function(e){
 const sn=e.target.closest('[data-stock-search-name]');
 if(sn){e.preventDefault();e.stopPropagation();const name=sn.getAttribute('data-stock-search-name')||'';if(el('stockNameSearch'))el('stockNameSearch').value=name;if(el('stockSearch'))el('stockSearch').value='';const nb=el('stockSearchNamePicker');if(nb){nb.style.display='none';setStockPickerOpen(nb,false);}openStockSearchPicker();render();return;}
 const sr=e.target.closest('[data-stock-search-ref]');
 if(sr){e.preventDefault();e.stopPropagation();if(el('stockSearch'))el('stockSearch').value=sr.getAttribute('data-stock-search-ref')||'';const b=el('stockSearchPicker');if(b){b.style.display='none';setStockPickerOpen(b,false);}render();return;}
 const n=e.target.closest('[data-stock-name]');
 if(n){e.preventDefault();selectStockName(n.getAttribute('data-stock-name')||'');return;}
 const addNew=e.target.closest('[data-stock-new-name]');
 if(addNew){
   e.preventDefault();
   alert('لا يمكن إضافة اسم منتوج من المخزون. أضفه أولاً من قسم «تعريفة الشركات».');
   return;
   const input=el('pname');
   if(input){input.readOnly=false;input.value='';input.removeAttribute('list');input.placeholder='اكتب اسم المنتوج الجديد';input.setAttribute('data-stock-name-mode','new');input.focus();}
   const box=el('stockNamePicker'); if(box){box.style.display='none';setStockPickerOpen(box,false);}
   const ref=el('pref');
   if(ref){ref.value='';ref.readOnly=false;ref.dataset.stockRefMode='new';ref.placeholder='اكتب رقم المنتوج الجديد';}
   const rb=el('stockRefPicker'); if(rb)rb.style.display='none';
   updateStockQtyMode();
   updateStockImageMode();
   return;
 }
 const newRef=e.target.closest('[data-stock-new-ref]');
 if(newRef){
   e.preventDefault(); e.stopPropagation();
   alert('لا يمكن إضافة رقم جديد من المخزون. سجّل الرقم وثمنه أولاً من قسم «تعريفة الشركات».');
   return;
 }
 const r=e.target.closest('[data-stock-ref]');
 if(r){
   e.preventDefault(); e.stopPropagation();
   const ref=el('pref');
   if(ref){ref.value=r.getAttribute('data-stock-ref')||'';ref.readOnly=true;ref.dataset.stockRefMode='existing';}
   renderStockCompanyOptions();
   const b=el('stockRefPicker');if(b){b.style.display='none';setStockPickerOpen(b,false);}
   updateStockQtyMode();
   updateStockCompanyPriceHint();
 }
});

document.addEventListener('change',function(e){
 if(e.target && e.target.id==='stockImage') previewStockImage();
 if(e.target && e.target.id==='priceProductImage') previewPriceProductImage();
});

function renderStockProductOptions(){
 const dl=el('stockProductNames');
 if(dl){const names=[...(db.products||[])].map(p=>String(p.name||'').trim()).filter(Boolean).sort((a,b)=>compareNamesAZ(a,b));dl.innerHTML=names.map(name=>`<option value="${esc(name)}"></option>`).join('');}
}
function fillStockProduct(){ return true; }
function renderStockRefOptions(selected=''){ return true; }
function validateCatalogStockRef(){ return true; }
function parseProductNumbers(value){
 return sortNumbersAscending(String(value||'').split(/[\/,،;\s]+/).map(x=>x.trim()).filter(Boolean));
}
async function addProduct(e){
 e.preventDefault();
 return alert('إضافة المنتوجات مسموحة فقط من قسم «تعريفة الشركات».');
 const name=el('productName').value.trim();
 if(!name)return alert('أدخل اسم المنتوج');
 const numbers=parseProductNumbers(el('productNumbers').value);
 const existing=(db.products||[]).find(x=>normalizeProductName(x.name)===normalizeProductName(name));
 if(existing){
   existing.numbers=sortNumbersAscending([...(existing.numbers||[]),...numbers]);
   if(el('productImage').files[0]) existing.image=await compressImage(el('productImage').files[0]);
   save();e.target.reset();renderProductSection();renderProductNamePicker();renderProductSearchResult();
   return alert('تم تحديث المنتوج وإضافة الأرقام الجديدة');
 }
 let image='';
 try{image=await compressImage(el('productImage').files[0]);}catch(err){return alert('تعذر حفظ الصورة. جرّب صورة أصغر.');}
 db.products.push({id:Date.now()+Math.floor(Math.random()*1000),name,image,numbers});
 try{save();e.target.reset();renderProductSection();renderProductNamePicker();renderProductSearchResult();alert('تم حفظ المنتوج بنجاح');}catch(err){alert('تعذر حفظ المنتوج: '+err.message);}
}
function editProduct(id){
 return alert('تعديل اسم أو صورة المنتوج مسموح فقط من قسم «تعريفة الشركات».');
 /*
 const p=db.products.find(x=>String(x.id)===String(id));if(!p)return;
 const name=prompt('اسم المنتوج:',p.name||'');if(name===null)return;
 if(!name.trim())return alert('أدخل اسم المنتوج');
 const nums=prompt('أرقام/مراجع المنتوج (مثال: A12 / B13 / 14C):',productNumbers(p).join(' / '));if(nums===null)return;
 const cleanName=name.trim();
 const duplicate=db.products.some(x=>String(x.id)!==String(id)&&normalizeProductName(x.name)===normalizeProductName(cleanName));
 if(duplicate)return alert('اسم المنتوج موجود بالفعل');
 p.name=cleanName;p.numbers=parseProductNumbers(nums);
 (db.stock||[]).forEach(st=>{if(String(st.productId)===String(id)){st.name=p.name;if(p.image)st.image=p.image;}});
 (db.sales||[]).forEach(s=>(s.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 (db.deliveryDocs||[]).forEach(d=>(d.items||[]).forEach(it=>{if(String(it.productId)===String(id))it.name=p.name;}));
 save();renderProductSection();renderProductNamePicker();renderProductSearchResult();alert('تم تعديل المنتوج بنجاح');
 */
}
function deleteProduct(id){
 const linked=(db.stock||[]).some(x=>String(x.productId)===String(id));
 if(linked){alert('لا يمكن حذف المنتوج لأنه مرتبط بالمخزون. احذف أسطره من المخزون أولاً.');return;}
 if(!confirm('حذف هذا المنتوج وأرقامه؟'))return;
 db.products=db.products.filter(x=>String(x.id)!==String(id));
 delete db.prices[String(id)];
 save();renderProductSection();renderProductNamePicker();renderProductSearchResult();
}
function productCardHtml(p){
 const nums=productNumbersDesc(p);
 const rows=(db.stock||[]).filter(st=>String(st.productId)===String(p.id)||normalizeProductName(st.name)===normalizeProductName(p.name));
 const qty=rows.reduce((sum,st)=>sum+Number(st.qty||0),0);
 const total=rows.reduce((sum,st)=>{const buy=Number(st.buy||((db.prices||{})[String(p.id)]||{}).buy||0);return sum+(Number(st.qty||0)*buy)},0);
 const refs=nums.length?nums.join('، '):'—';
 return `<div class="product-card product-identity-card" onclick="selectProductFromCard('${esc(String(p.id))}')">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name)}">`:'<div class="noimg">🛍️</div>'}<div class="identity-title">${esc(p.name||'')}</div><div class="identity-row"><span>رقم المنتوج</span><b>${esc(refs)}</b></div><div class="identity-row"><span>عدد المنتوج</span><b>${qty}</b></div><div class="identity-total"><span>مجموع الثمن</span><b>${money(total)}</b></div></div>`;
}
function resetProductNumberSearch(){
 const n=el('productNumberSearch'); if(n)n.value='';
 renderProductNumberPicker();
}
function productPriceRows(){
 const groups=new Map();
 (db.stock||[]).forEach(st=>{
   const p=getCatalogProduct(st.productId)||getCatalogProductByName(st.name);
   const name=p?.name||st.name||''; const ref=st.ref||'';
   const key=(p?.id||name)+'::'+ref;
   const priceObj=(db.prices||{})[String(p?.id||'')]||{};
   const buy=Number(st.buy ?? priceObj.buy ?? 0);
   const sale=Number(st.sale ?? priceObj.sale ?? 0);
   groups.set(key,{name,ref,buy,sale});
 });
 (db.products||[]).forEach(p=>{
   const po=(db.prices||{})[String(p.id)]||{};
   productNumbers(p).forEach(ref=>{const key=String(p.id)+'::'+ref;if(!groups.has(key))groups.set(key,{name:p.name||'',ref,buy:Number(po.buy||0),sale:Number(po.sale||0)});});
 });
 return [...groups.values()].sort((a,b)=>compareNamesAZ(a.name,b.name)||compareRefsDesc(a.ref,b.ref));
}
function renderAllProductPrices(){
 const box=el('allProductPrices'); if(!box)return;
 const qn=(el('productNameSearch')?.value||'').trim().toLowerCase();
 const qr=(el('productNumberSearch')?.value||'').trim().toLowerCase();
 const rows=productPriceRows().filter(x=>(!qn||x.name.toLowerCase().includes(qn))&&(!qr||x.ref.toLowerCase().includes(qr)));
 const groups=new Map();
 rows.forEach(x=>{const key=normalizeProductName(x.name);if(!groups.has(key))groups.set(key,{name:x.name,rows:[]});groups.get(key).rows.push(x);});
 box.innerHTML=groups.size?[...groups.values()].map(g=>`<div class="product-price-group">
   <div class="product-price-group-title">💰 ${esc(g.name)}</div>
   <div class="price-table-wrap"><table class="price-table"><thead><tr><th>رقم المنتوج</th><th>ثمن الشراء</th><th>ثمن البيع</th></tr></thead><tbody>${g.rows.map(x=>`<tr><td><b>${esc(x.ref||'-')}</b></td><td>${money(x.buy)}</td><td>${money(x.sale)}</td></tr>`).join('')}</tbody></table></div>
 </div>`).join(''):'<div class="empty" style="padding:12px">لا توجد أثمان مسجلة</div>';
}
function renderProductSection(){
 renderProducts();
 renderAllProductPrices();
 renderProductSearchResult();
}
function renderProducts(){
 db.products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a?.name,b?.name));
 renderRegisteredProductNames();
 renderPurchaseRegisteredProductNames();
 const list=el('productsList');if(!list)return;
 syncCatalogLinks();
 const nameQ=(el('productNameSearch')?.value||'').trim().toLowerCase();
 const refQ=(el('productNumberSearch')?.value||'').trim().toLowerCase();
 let rows=(db.products||[]).filter(p=>(!nameQ||String(p.name||'').toLowerCase().includes(nameQ))&&(!refQ||productNumbers(p).some(r=>r.toLowerCase().includes(refQ))));
 rows=sortProductRowsAZ(rows);
 // عند اختيار اسم محدد لا نعرض أي منتوج آخر. وعند اختيار الرقم نعرض صاحب الرقم فقط.
 if(nameQ){
   const exact=(db.products||[]).filter(p=>normalizeProductName(p.name)===normalizeProductName(el('productNameSearch')?.value||''));
   if(exact.length) rows=exact.filter(p=>!refQ||productNumbers(p).some(r=>r.toLowerCase().includes(refQ)));
 }
 if(refQ){
   rows=rows.filter(p=>productNumbers(p).some(r=>r.toLowerCase().includes(refQ)));
 }
 list.innerHTML=rows.length?'<div class="product-grid">'+rows.map(productCardHtml).join('')+'</div>':'<div class="empty">لا توجد نتائج للمنتوج المحدد</div>';
 sortCardContainersAZ();
 renderProductNamePicker();
}
function preparePickerModal(box,title){
 if(!box)return;
 box.classList.add(box.id.startsWith('price')?'price-search-modal':'product-search-modal');
 let h=box.querySelector('.picker-modal-title');
 if(!h){
   h=document.createElement('div'); h.className='picker-modal-title';
   h.innerHTML=`<span>🔢 ${esc(title||'اختر') }</span><button type="button" class="picker-modal-close" aria-label="إغلاق" onclick="closePickerModal(this.parentElement.parentElement);event.stopPropagation();">×</button>`;
   box.prepend(h);
 }else{ const sp=h.querySelector('span'); if(sp)sp.textContent='🔢 '+(title||'اختر'); }
}
function closePickerModal(box){ if(box)box.style.display='none'; }
function renderProductNamePicker(){
 const box=el('productNamePicker');if(!box)return;
 const names=[...new Map((db.products||[]).map(p=>[normalizeProductName(p.name),p.name])).values()].sort((a,b)=>compareNamesAZ(a,b));
 preparePickerModal(box,'اختر اسم المنتج'); box.querySelectorAll(':scope > button, :scope > .empty').forEach(x=>x.remove()); const body=names.length?names.map(n=>`<button type="button" onclick="chooseProductName('${esc(n).replace(/'/g,"\\'")}')">${esc(n)}</button>`).join(''):'<div class="empty search-picker-empty">لا توجد أسماء مسجلة</div>'; box.insertAdjacentHTML('beforeend',body);
}
function openProductNamePicker(){renderProductNamePicker();const b=el('productNamePicker');if(b){b.style.display='block';b.scrollTop=0;}filterProductNamePicker();}
function filterProductNamePicker(){
 const q=(el('productNameSearch')?.value||'').trim().toLowerCase(),b=el('productNamePicker');if(!b)return;
 [...b.querySelectorAll('button')].forEach(x=>x.style.display=(!q||x.textContent.toLowerCase().includes(q))?'block':'none');b.style.display='block';
}
function chooseProductName(name){
 el('productNameSearch').value=name;el('productNumberSearch').value='';
 const b=el('productNamePicker');if(b)b.style.display='none';
 renderProductNumberPicker();renderProductSearchResult();
}
function selectedProductForSearch(){
 const name=(el('productNameSearch')?.value||'').trim();
 return (db.products||[]).find(p=>normalizeProductName(p.name)===normalizeProductName(name))||null;
}
function renderProductNumberPicker(){
 const box=el('productNumberPicker');if(!box)return;
 const p=selectedProductForSearch();
 const nums=p?productNumbersDesc(p):sortNumbersDesc((db.products||[]).flatMap(productNumbers));
 preparePickerModal(box,'اختر رقم المنتج'); box.querySelectorAll(':scope > button, :scope > .empty').forEach(x=>x.remove()); const body=nums.length?nums.map(n=>`<button type="button" onclick="chooseProductNumber('${esc(n).replace(/'/g,"\\'")}')">${esc(n)}</button>`).join(''):'<div class="empty search-picker-empty">لا توجد أرقام لهذا الاسم</div>'; box.insertAdjacentHTML('beforeend',body);
}
function openProductNumberPicker(){renderProductNumberPicker();const b=el('productNumberPicker');if(b){b.style.display='block';b.scrollTop=0;}filterProductNumberPicker();}
function filterProductNumberPicker(){
 const q=(el('productNumberSearch')?.value||'').trim().toLowerCase(),b=el('productNumberPicker');if(!b)return;
 [...b.querySelectorAll('button')].forEach(x=>x.style.display=(!q||x.textContent.toLowerCase().includes(q))?'block':'none');b.style.display='block';
}
function chooseProductNumber(number){el('productNumberSearch').value=number;const b=el('productNumberPicker');if(b)b.style.display='none';renderProductSearchResult();}
function selectProductFromCard(id){
 const p=getCatalogProduct(id);if(!p)return;
 el('productNameSearch').value=p.name||'';el('productNumberSearch').value='';renderProductNumberPicker();renderProductSearchResult();
 document.getElementById('productNameSearch')?.scrollIntoView({behavior:'smooth',block:'center'});
}
function renderProductSearchResult(){
 const box=el('productSearchResult');if(!box)return;
 const p=selectedProductForSearch();
 if(!p){box.innerHTML='<div class="empty">اختر اسماً من قائمة البحث.</div>';return;}
 const q=(el('productNumberSearch')?.value||'').trim();const nums=productNumbers(p);const filtered=q?nums.filter(n=>n.toLowerCase().includes(q.toLowerCase())):nums;
 box.innerHTML=`<div class="product-card" style="cursor:default">${p.image?`<img class="prodimg" src="${p.image}" alt="${esc(p.name)}">`:''}<h4>${esc(p.name)}</h4><div class="meta">جميع الأرقام المسجلة لهذا الاسم</div><div class="product-numbers">${(filtered.length?filtered:nums).map(n=>`<span class="product-number-chip">${esc(n)}</span>`).join('')||'<span class="small">لا توجد أرقام</span>'}</div></div>`;
}

function sanitizeDigits(input){
  if(!input) return;
  const cleaned=String(input.value||'').replace(/[^0-9]/g,'');
  if(input.value!==cleaned) input.value=cleaned;
}

function updateStockQtyMode(){
 const label=el('pqtyLabel'), input=el('pqty'), hint=el('pqtyHint');
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim();
 const mode=el('pname')?.dataset.stockNameMode||'choose';
 let old=null;
 if(name && ref) old=(db.stock||[]).find(x=>normalizeProductName(x.name)===normalizeProductName(name)&&String(x.ref||'').trim().toLowerCase()===ref.toLowerCase());
 if(old){
   if(label) label.textContent='الكمية التي تريد إضافتها';
   if(input) input.placeholder='مثال: 10';
   if(hint) hint.innerHTML='الموجود حالياً: <b>'+Number(old.qty||0)+'</b> — اكتب فقط الكمية التي تريد إضافتها.';
 }else if(mode==='new'){
   if(label) label.textContent='الكمية الأولية للمنتوج الجديد';
   if(input) input.placeholder='مثال: 20';
   if(hint) hint.textContent='هذه هي الكمية التي سيبدأ بها المنتوج الجديد.';
 }else{
   if(label) label.textContent='الكمية التي تريد إضافتها';
   if(input) input.placeholder='شحال بغيت تزيد؟';
   if(hint) hint.textContent='اختر الاسم والرقم أولاً.';
 }
}
function updateStockImageMode(){
 const wrap=el('stockImageWrap');
 const input=el('stockImage');
 const preview=el('stockImagePreview');
 const mode=el('pname')?.dataset.stockNameMode||'choose';
 const show=mode==='new';
 if(wrap)wrap.style.display=show?'block':'none';
 if(!show){if(input)input.value='';if(preview){preview.innerHTML='';preview.style.display='none';}}
}
function previewStockImage(){
 const input=el('stockImage'),preview=el('stockImagePreview');
 if(!input||!preview)return;
 const file=input.files?.[0];
 if(!file){preview.innerHTML='';preview.style.display='none';return;}
 if(!file.type.startsWith('image/')){input.value='';preview.innerHTML='';preview.style.display='none';return alert('اختر صورة فقط.');}
 const r=new FileReader();
 r.onload=()=>{preview.innerHTML='<img src="'+r.result+'" alt="صورة المنتوج">';preview.style.display='block';};
 r.readAsDataURL(file);
}
function renderStockCompanyOptions(){
 const sel=el('pcompany'); if(!sel)return;
 const current=sel.value;
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim().toLowerCase();
 const product=getCatalogProductByName(name);
 const pid=String(product?.id||'');
 let rows=(db.companyPrices||[]).filter(x=>{
   const sameProduct=pid && String(x.productId||'')===pid;
   const sameRef=ref && String(x.ref||'').trim().toLowerCase()===ref;
   return sameProduct&&sameRef;
 });
 let names=[...new Set(rows.map(x=>String(x.company||'').trim()).filter(Boolean))];
 if(!names.length){
   names=[...new Set((db.companyPrices||[]).filter(x=>pid&&String(x.productId||'')===pid).map(x=>String(x.company||'').trim()).filter(Boolean))];
 }
 names.sort((a,b)=>compareNamesAZ(a,b));
 sel.innerHTML='<option value="">اختر الشركة ⬇️</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');
 if(names.includes(current))sel.value=current;
 updateStockCompanyPriceHint();
}
function updateStockCompanyPriceHint(){
 const hint=el('pqtyHint');
 const priceHint=el('pcompanyPriceHint');
 const priceInput=el('pcompanyPrice');
 const company=String(el('pcompany')?.value||'').trim();
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim();
 if(!hint)return;
 if(company&&name&&ref){
   const p=getCatalogProductByName(name);
   const refKey=ref.toLowerCase();
   const companyKey=normalizeProductName(company);
   const nameKey=normalizeProductName(name);
   const item=(db.companyPrices||[]).find(x=>{
     const sameRef=String(x.ref||'').trim().toLowerCase()===refKey;
     const sameCompany=normalizeProductName(x.company||'')===companyKey;
     const sameProduct=String(x.productId||'')===String(p?.id||'') || normalizeProductName(x.productName||'')===nameKey;
     return sameRef&&sameCompany&&sameProduct;
   });
   if(item && Number.isFinite(Number(item.price))){
     if(priceInput){priceInput.value=Number(item.price);priceInput.readOnly=true;}
     if(priceHint)priceHint.innerHTML=`✅ الثمن التلقائي لشركة <b>${esc(company)}</b>: <b>${money(item.price)}</b>`;
     hint.innerHTML=`الشركة: <b>${esc(company)}</b> — تم جلب الثمن تلقائيًا من قسم «تعريفة الشركات».`;
   }else{
     if(priceInput){priceInput.value='';priceInput.readOnly=true;}
     if(priceHint)priceHint.innerHTML=`⚠️ لا يوجد ثمن مسجل لـ <b>${esc(company)}</b> لهذا المنتوج والرقم في قسم «تعريفة الشركات».`;
     hint.innerHTML=`الشركة: <b>${esc(company)}</b> — سجّل ثمن هذا المنتوج والرقم أولًا في قسم «تعريفة الشركات».`;
   }
 }else{
   if(priceInput){priceInput.value='';priceInput.readOnly=true;}
   if(priceHint)priceHint.textContent='اختر المنتوج والرقم ثم الشركة ليظهر الثمن تلقائيًا من «تعريفة الشركات».';
   hint.textContent='اختر المنتوج والرقم والشركة أولًا.';
 }
}
function resetStockNameField(){
 const input=el('pname');
 if(input){input.value='';input.readOnly=true;input.dataset.stockNameMode='choose';input.placeholder='اختر منتوجًا مسجلًا في قسم «تعريفة الشركات»';}
 const box=el('stockNamePicker'); if(box){box.style.display='none';setStockPickerOpen(box,false);}
 const ref=el('pref'); if(ref){ref.value='';ref.readOnly=true;ref.dataset.stockRefMode='choose';ref.placeholder='اختر رقم المنتوج';}
 const rb=el('stockRefPicker'); if(rb)rb.style.display='none';
 const company=el('pcompany'); if(company)company.value='';
 const companyPrice=el('pcompanyPrice'); if(companyPrice)companyPrice.value='';
 updateStockQtyMode();
 updateStockImageMode();
 updateStockCompanyPriceHint();
}
async function addStock(e){
 e.preventDefault();
 const name=String(el('pname')?.value||'').trim();
 const ref=String(el('pref')?.value||'').trim();
 const company=String(el('pcompany')?.value||'').trim();
 const companyPrice=Number(el('pcompanyPrice')?.value);
 const qty=Number(el('pqty')?.value||0);
 if(!name)return alert('اختر منتوجًا مسجلًا في قسم «تعريفة الشركات»');
 if(!ref)return alert('اختر رقمًا مسجلًا لهذا المنتوج من قسم «تعريفة الشركات»');
 if(!company)return alert('اختر الشركة');
 if(!Number.isFinite(companyPrice)||companyPrice<0)return alert('أدخل ثمن شراء صحيحًا مناسبًا للشركة');
 if(qty<=0)return alert('أدخل كمية صحيحة أكبر من صفر');
 const product=getCatalogProductByName(name);
 if(!product)return alert('هذا المنتوج غير مسجل في قسم «تعريفة الشركات». أضفه أولاً إلى قسم «تعريفة الشركات».');
 const catalogRefs=productNumbers(product);
 const refKey=ref.toLowerCase();
 const registeredRef=catalogRefs.find(r=>String(r).trim().toLowerCase()===refKey);
 if(!registeredRef)return alert('هذا الرقم غير مسجل لهذا المنتوج في قسم «المنتجات | الاسم | الرقم | الصورة».');
 const productId=String(product.id);
 const companyItem=(db.companyPrices||[]).find(x=>String(x.productId||'')===productId&&String(x.ref||'').trim().toLowerCase()===refKey&&normalizeProductName(x.company||'')===normalizeProductName(company));
 if(!companyItem || !Number.isFinite(Number(companyItem.price)))return alert('لا يوجد ثمن مسجل لهذه الشركة لهذا المنتوج والرقم في قسم «تعريفة الشركات».');
 const buy=Number(companyItem.price);
 // الثمن يُؤخذ تلقائيًا فقط من قسم «تعريفة الشركات» ولا يتم إدخاله أو تغييره من المخزون.
 const image=product.image||'';
 const old=db.stock.find(x=>String(x.productId||'')===productId && String(x.ref||'').trim().toLowerCase()===refKey && normalizeProductName(x.company||'')===normalizeProductName(company));
 if(old){old.productId=product.id;old.name=product.name;old.ref=registeredRef;old.company=company;old.qty=Number(old.qty||0)+qty;old.buy=Number(buy);old.image=image;}
 else db.stock.push({id:Date.now()+Math.floor(Math.random()*1000),productId:product.id,name:product.name,ref:registeredRef,company,qty,buy:Number(buy),image});
 syncStockPurchasePrices();
 syncProductsFromStock();
 try{save();e.target.reset();resetStockNameField();renderStockNameRegistry();renderProductCardsSearch();renderStockSearchOptions();alert('تمت إضافة الكمية. تم أخذ ثمن الشركة من قسم «تعريفة الشركات» وحفظه مع المخزون.')}catch(err){alert('تعذر حفظ المنتج: '+err.message)}
}
function switchSalesOperation(){
 const type=el('salesOperationType')?.value||'sale';
 const saleBox=el('salesOperationSale'), expenseBox=el('salesOperationExpense');
 if(saleBox)saleBox.style.display=type==='sale'?'block':'none';
 if(expenseBox)expenseBox.style.display=type==='expense'?'block':'none';
 if(type==='expense' && el('salesExpenseDate') && !el('salesExpenseDate').value)el('salesExpenseDate').value=todayISO();
}
function addSalesExpense(){
 const date=el('salesExpenseDate')?.value||todayISO();
 const name=String(el('salesExpenseName')?.value||'').trim();
 const amountText=String(el('salesExpenseAmount')?.value||'').trim().replace(',', '.');
 const amount=Number(amountText);
 if(!date)return alert('اختر التاريخ');
 if(!name)return alert('أدخل نوع المصروف');
 if(!amountText || !Number.isFinite(amount) || amount<0)return alert('أدخل مبلغاً صحيحاً');
 if(!Array.isArray(db.expenses))db.expenses=[];
 db.expenses.push({id:'exp_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),date:date+'T12:00:00',name,amount});
 save();
 if(el('salesExpenseName'))el('salesExpenseName').value='';
 if(el('salesExpenseAmount'))el('salesExpenseAmount').value='';
 if(el('salesExpenseDate'))el('salesExpenseDate').value=date;
 render();
 alert('تم حفظ المصروف بنجاح');
}

let saleCart=[];
function addToCart(e){
 e.preventDefault();
 const p=db.stock.find(x=>String(x.id)===String(el('saleProduct').value));
 const q=Number(el('saleQty').value), price=Number(el('salePrice').value);
 if(!p)return alert('اختر منتجًا');
 if(q<=0)return alert('الكمية غير صحيحة');
 const already=saleCart.filter(x=>String(x.productId)===String(p.id)).reduce((a,x)=>a+Number(x.qty||0),0);
 if(q+already>Number(p.qty||0))return alert('الكمية المطلوبة أكبر من المخزون المتوفر');
 if(price<0)return alert('السعر غير صحيح');
 const existing=saleCart.find(x=>String(x.productId)===String(p.id)&&Number(x.price)===price);
 if(existing){existing.qty+=q;existing.total=existing.qty*existing.price;existing.profit=(existing.price-existing.buyPrice)*existing.qty;} else saleCart.push({productId:p.id,name:p.name,ref:p.ref||'',qty:q,price:price,buyPrice:Number(p.buy||0),profit:(price-Number(p.buy||0))*q,total:q*price});
 el('saleQty').value='1'; renderCart();
}
function fillCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('saleCustomer').value));
 if(c){el('saleCustomerName').value=c.name||'';el('saleCustomerPhone').value=c.phone||'';}
 else {el('saleCustomerName').value='';el('saleCustomerPhone').value='';}
}
function removeCartItem(i){saleCart.splice(i,1);renderCart()}
function clearCart(){saleCart=[];renderCart()}
function renderCart(){
 const box=el('cartBox');
 if(!box)return;
 if(!saleCart.length){box.innerHTML='<div class="empty card">لم تتم إضافة منتجات إلى الفاتورة بعد.</div>';return;}
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 box.innerHTML='<div class="cart"><div class="badge">'+saleCart.length+' منتجات/أسطر</div><table><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>المجموع</th><th></th></tr>'+saleCart.map((x,i)=>'<tr><td>'+esc(x.name)+(x.ref?'<div class="small">'+esc(x.ref)+'</div>':'')+'</td><td>'+x.qty+'</td><td>'+money(x.price)+'</td><td>'+money(x.total)+'</td><td><button class="remove" onclick="removeCartItem('+i+')">حذف</button></td></tr>').join('')+'</table><div class="cart-total"><span>المجموع النهائي</span><span>'+money(total)+'</span></div></div>';
}
function finalizeSale(){
 if(!saleCart.length)return alert('أضف منتجًا واحدًا على الأقل');
 for(const item of saleCart){const p=db.stock.find(x=>String(x.id)===String(item.productId));if(!p||Number(item.qty)>Number(p.qty||0))return alert('المخزون غير كافٍ للمنتج: '+item.name);}
 const customerName=el('saleCustomerName').value.trim()||'زبون عابر';
 const customerPhone=el('saleCustomerPhone').value.trim();
 const total=saleCart.reduce((a,x)=>a+Number(x.total||0),0);
 saleCart.forEach(item=>{const p=db.stock.find(x=>String(x.id)===String(item.productId));p.qty-=Number(item.qty);});
 db.sales.push({id:Date.now(),date:new Date().toISOString(),customer:{name:customerName,phone:customerPhone},items:saleCart.map(x=>({...x})),total});
 save(); saleCart=[]; if(el('saleCustomer'))el('saleCustomer').value=''; if(el('saleCustomerName'))el('saleCustomerName').value=''; if(el('saleCustomerPhone'))el('saleCustomerPhone').value=''; if(el('saleQty'))el('saleQty').value='1'; renderCart(); alert('تم حفظ البيع بنجاح');
}
function saleItems(s){
 const raw=Array.isArray(s.items)?s.items:(s.name?[{name:s.name,ref:s.ref||'',qty:s.qty||0,price:s.price||0,total:s.total||0,productId:s.productId||''}]:[]);
 return raw.map(it=>{
   const p=getCatalogProduct(it.productId)||getCatalogProductByRef(it.ref);
   if(!p)return {...it};
   const wanted=String(it.ref||'').trim().toLowerCase();
   const ref=productNumbers(p).find(r=>String(r).trim().toLowerCase()===wanted)||it.ref||productNumbers(p)[0]||'';
   return {...it,productId:p.id,name:p.name,ref};
 });
}
function downloadLastSalePdf(){
 if(!db.sales.length){alert('لا توجد مبيعات لتحميلها');return;}
 const x=db.sales[db.sales.length-1],items=saleItems(x),customer=x.customer||{},date=x.date||new Date().toLocaleString('ar-MA'),total=Number(x.total||0);
 const rows=items.map((it,i)=>`<tr><td class="num">${i+1}</td><td>${esc(it.name||it.productName||'')}</td><td class="num">${Number(it.qty||it.quantity||1)}</td><td class="money">${money(it.price||it.salePrice||0)}</td><td class="money">${money((it.qty||it.quantity||1)*(it.price||it.salePrice||0))}</td></tr>`).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:24px 28px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:23px}.title div{margin-top:5px;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:12px;padding:12px;background:#fff}.customer-box{border:1.5px solid #0b4f8a;background:linear-gradient(180deg,#f7fbff 0%,#fff 100%)}.customer-head{display:flex;align-items:center;gap:7px;border-bottom:1px solid #dfe6ec;padding-bottom:7px;margin-bottom:8px;font-size:12px;font-weight:bold;color:#0b4f8a}.customer-icon{width:24px;height:24px;border-radius:50%;background:#0b4f8a;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:13px}.customer-name{font-size:17px;font-weight:700;line-height:1.35;margin-bottom:8px}.customer-row{font-size:12px;line-height:1.7;color:#33424f;margin-top:3px;word-break:break-word}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}
.monthly-summary-table th,.monthly-summary-table td{font-size:10px;padding:5px 4px;white-space:nowrap}.monthly-summary-table tfoot th{background:#eef4f8;font-weight:bold}.monthly-summary-wrap{overflow-x:auto}@media(max-width:520px){.monthly-summary-table{font-size:9px}.monthly-summary-table th,.monthly-summary-table td{font-size:8.5px;padding:4px 2px}}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table{width:100%!important;table-layout:fixed!important;border-collapse:collapse!important;font-size:11px!important;line-height:1!important;margin:0!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table tr{height:34px!important;max-height:34px!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{height:34px!important;min-height:34px!important;max-height:34px!important;padding:2px 3px!important;line-height:1!important;vertical-align:middle!important;text-align:center!important;white-space:nowrap!important;overflow:hidden!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th{font-size:9px!important;font-weight:700!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{font-size:11px!important;font-weight:400!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount-cell{font-size:11px!important;direction:ltr!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount{display:inline!important;font-size:11px!important;font-weight:700!important;line-height:1!important;white-space:nowrap!important;margin:0!important;padding:0!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-delete-one{display:inline-flex!important;width:22px!important;height:22px!important;min-width:22px!important;min-height:22px!important;padding:0!important;margin:0!important;align-items:center!important;justify-content:center!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(1),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(1){width:27%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(2),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(2){width:35%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(3),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(3){width:28%!important}
#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th:nth-child(4),#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td:nth-child(4){width:10%!important}
@media(max-width:520px){#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table tr,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th,#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{height:32px!important;min-height:32px!important;max-height:32px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table th{font-size:8px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table td{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-amount{font-size:10px!important}#dailyExpenseEntry.daily-expense-entry-main .daily-saved-table .daily-delete-one{width:20px!important;height:20px!important;min-width:20px!important;min-height:20px!important;font-size:11px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}

.choice-modal{position:fixed;inset:0;background:rgba(0,0,0,.42);display:none;align-items:center;justify-content:center;z-index:9999;padding:18px}.choice-modal.open{display:flex}.choice-modal-box{width:min(420px,100%);background:#fff;border-radius:16px;padding:18px;box-shadow:0 12px 35px rgba(0,0,0,.22);text-align:center}.choice-modal-box h3{margin:0 0 15px;color:#0b4f8a}.choice-modal-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}.choice-modal-actions button{min-height:52px;border:1px solid #cbd9e5;border-radius:12px;background:#f7fbfe;color:#17212b;font-size:15px;font-weight:800}.choice-modal-actions button:first-child{background:#eef7ff;color:#0b4f8a}@media(max-width:520px){.choice-modal-actions{grid-template-columns:1fr}.choice-modal-actions button{min-height:48px}}

/* تحسين واجهة إضافة المخزون */
.stock-model-add{padding:16px!important;border:1px solid #d8e8f5!important;background:linear-gradient(180deg,#fafdff,#f3f8fc)!important;box-shadow:0 8px 24px rgba(20,70,110,.08)!important}
.stock-model-add .stock-section-title{display:flex;align-items:center;justify-content:center;gap:7px;font-size:19px!important;color:#0b4f8a;background:linear-gradient(90deg,#eaf5ff,#dceeff)!important;border:0!important;border-right:5px solid #0b4f8a!important;border-radius:14px!important;padding:13px!important;margin:0 0 14px!important}
.stock-model-add .stock-form-grid{gap:12px!important}
.stock-model-add .stock-form-grid>div{background:#fff;border:1px solid #d9e5ee;border-radius:14px;padding:10px!important;box-shadow:0 3px 10px rgba(0,0,0,.035)}
.stock-model-add .stock-field-label,.stock-model-add .stock-price-field label,.stock-model-add .stock-qty-field label{font-size:13px!important;color:#164f78!important;margin-bottom:7px!important}
.stock-model-add .stock-field-label::first-letter{font-weight:900}
.stock-model-add input,.stock-model-add select{border:1.5px solid #c8d8e6!important;border-radius:12px!important;background:#fff!important;min-height:46px!important;font-size:16px!important;font-weight:700!important;color:#182a38!important;transition:.2s}
.stock-model-add input:focus,.stock-model-add select:focus{border-color:#0b6aa6!important;box-shadow:0 0 0 3px rgba(11,106,166,.10)!important;outline:none}
.stock-model-add .stock-price-field input{background:#eef9f3!important;border-color:#b9dec9!important;color:#176b49!important;font-size:18px!important;font-weight:900!important}
.stock-model-add .stock-qty-field input{background:#fffdf5!important;border-color:#e4d39a!important;font-size:18px!important;font-weight:900!important}
.stock-model-add .stock-price-field .small,.stock-model-add .stock-qty-field .small{display:block;background:#f5f8fa;border-radius:9px;padding:7px 8px!important;line-height:1.5!important;color:#667985!important}
.stock-model-add .stock-picker-arrow{width:34px!important;height:34px!important;border-radius:9px!important;background:#edf6ff!important}
.stock-model-add>form>button{margin-top:12px!important;border-radius:14px!important;min-height:52px!important;font-size:18px!important;font-weight:900!important;box-shadow:0 6px 14px rgba(11,79,138,.16)!important}
@media(max-width:520px){.stock-model-add{padding:12px!important}.stock-model-add .stock-section-title{font-size:17px!important}.stock-model-add .stock-form-grid{gap:9px!important}.stock-model-add .stock-form-grid>div{padding:8px!important}.stock-model-add input,.stock-model-add select{min-height:44px!important;font-size:15px!important}.stock-model-add .stock-price-field input,.stock-model-add .stock-qty-field input{font-size:17px!important}.stock-model-add .stock-price-field .small,.stock-model-add .stock-qty-field .small{font-size:10px!important}}
</style>
<style id="goujon-small-image">
/* GOUJON DE ROUE: smaller product image */
.goujon-de-roue-small img,
img.goujon-de-roue-small {
  max-width: 55% !important;
  width: 55% !important;
  height: auto !important;
  object-fit: contain !important;
  margin-left: auto !important;
  margin-right: auto !important;
  display: block !important;
}
</style>
</head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div>الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br>AFRIQUIA FREINS ZEMAMRA</div></div>

<style id="fixed-price-action-buttons">
.company-price-actions{position:relative!important;z-index:9999!important;pointer-events:auto!important}
.company-price-actions button{position:relative!important;z-index:10000!important;pointer-events:auto!important;touch-action:manipulation!important;cursor:pointer!important;user-select:none!important;-webkit-user-select:none!important;min-height:42px!important;padding:7px 10px!important}
.price-save-btn{position:relative;z-index:10000;pointer-events:auto;touch-action:manipulation;cursor:pointer}
</style>
</body></html>`;
 const name='Facture-'+formatDeliveryNumber(x.deliveryNumber||x.id||Date.now())+'.pdf'; if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function'){AndroidPrint.savePdf(html,name);return;} try{const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}else{alert('يجب فتح التطبيق بنسخة Android التي تدعم PDF.');}}catch(e){alert('يجب فتح التطبيق بنسخة Android التي تدعم PDF.')}
}

function deliveryItemsTotal(items){return (items||[]).reduce((a,i)=>a+Number(i.total||Number(i.qty||1)*Number(i.price||0)),0)}
let currentDeliveryId=null;
let deliveryDraftItems=[];
function nextDeliveryNumber(){
 const docs=Array.isArray(db.deliveryDocs)?db.deliveryDocs:[];
 let max=0;
 docs.forEach(d=>{const n=String(d.deliveryNumber||'').match(/\d+/);if(n)max=Math.max(max,Number(n[0])||0);});
 return 'B'+String(max+1).padStart(4,'0');
}
function formatDeliveryNumber(value){
 const m=String(value||'').match(/\d+/);
 if(!m)return nextDeliveryNumber();
 return 'B'+String(Number(m[0])||0).padStart(4,'0');
}
function ensureDeliveryNumber(){
 const input=el('deliveryNumber');
 if(input && !currentDeliveryId && !String(input.value||'').trim()) input.value=nextDeliveryNumber();
}

function refreshDeliveryCustomers(selectedId=''){const s=el('deliveryCustomerSelect');if(!s)return;const customers=Array.isArray(db.customers)?db.customers:[];s.innerHTML='<option value="">اختر الزبون من قسم الزبائن</option>'+customers.map(c=>`<option value="${esc(String(c.id))}">${esc(c.name)}${c.phone?' — '+esc(c.phone):''}</option>`).join('');if(selectedId!==undefined)s.value=String(selectedId||'');}
function selectDeliveryCustomer(){const id=el('deliveryCustomerSelect')?.value;if(!id)return;const c=(db.customers||[]).find(x=>String(x.id)===String(id));if(!c)return;el('deliveryCustomerName').value=c.name||'';el('deliveryCustomerPhone').value=c.phone||'';}
function resetIndependentDelivery(){currentDeliveryId=null;deliveryDraftItems=[];if(el('deliveryCustomerSelect'))el('deliveryCustomerSelect').value='';if(el('deliveryCustomerName'))el('deliveryCustomerName').value='';if(el('deliveryCustomerPhone'))el('deliveryCustomerPhone').value='';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value='';if(el('deliveryNumber'))el('deliveryNumber').value='';if(el('deliveryDate')){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16)}renderDeliveryEditor();ensureDeliveryNumber()}
function renderDeliveryEditor(){
 syncCatalogLinks();
 refreshDeliveryCustomers(el('deliveryCustomerSelect')?.value||'');
 if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];
 deliveryDraftItems=deliveryDraftItems.map(i=>{const p=getCatalogProduct(i.productId)||getCatalogProductByRef(i.ref);if(!p)return i;const wanted=String(i.ref||'').trim().toLowerCase();const ref=productNumbers(p).find(r=>String(r).trim().toLowerCase()===wanted)||productNumbers(p)[0]||'';return {...i,productId:p.id,name:p.name,ref};});
 ensureDeliveryNumber();
 if(el('deliveryDate') && !el('deliveryDate').value){const d=new Date(Date.now()-new Date().getTimezoneOffset()*60000);el('deliveryDate').value=d.toISOString().slice(0,16);}
 const select=el('deliveryProduct');
 if(select){select.innerHTML='<option value="">اختر المنتج والرقم من المخزون</option>'+db.stock.map(p=>{const c=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);const name=c?.name||p.name||'';const ref=p.ref||'';return `<option value="${p.id}">${esc(name)} ${ref?'— '+esc(ref):''}</option>`}).join('');}
 const box=el('deliveryItemsEditor'); if(box){const items=deliveryDraftItems;const total=deliveryItemsTotal(items);box.innerHTML='<h4 style="margin-top:0">منتجات الوصل</h4>'+(!items.length?'<div class="empty">لم تتم إضافة منتجات بعد</div>':'<table><tr><th>اسم</th><th>عدد</th><th>ثمن</th><th>المجموع</th><th></th></tr>'+items.map((i,n)=>`<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.price)}</td><td>${money(i.total)}</td><td><button type="button" class="remove" onclick="removeDeliveryItem(${n})">حذف</button></td></tr>`).join('')+'</table><div class="cart-total"><span>المجموع</span><b>'+money(total)+'</b></div>');}
 const list=el('deliveryList'); if(list){list.innerHTML='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3>الوصول المستقلة المحفوظة</h3><button type="button" onclick="resetIndependentDelivery()">➕ وصل جديد</button></div>'+(!db.deliveryDocs.length?'<div class="empty">لا توجد وصول محفوظة</div>':'<table><tr><th>رقم الوصل</th><th>الزبون</th><th>العنوان</th><th>التاريخ</th><th>المجموع</th><th></th></tr>'+db.deliveryDocs.slice().reverse().map(d=>`<tr><td>${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</td><td>${esc(d.customerName||'زبون عابر')}</td><td>${esc(d.customerAddress||'')}</td><td>${d.date?esc(new Date(d.date).toLocaleDateString('ar-MA')):'-'}</td><td>${money(deliveryItemsTotal(d.items))}</td><td><button type="button" onclick="editIndependentDelivery('${d.id}')">تحرير</button> <button type="button" onclick="previewIndependentDelivery('${d.id}')">👁️ معاينة</button> <button type="button" onclick="downloadIndependentDeliveryPdf('${d.id}')">⚡ PDF سريع</button></td></tr>`).join('')+'</table>')+'</div>';}}
function addDeliveryItem(){const sel=el('deliveryProduct');const p=sel?.value?db.stock.find(x=>String(x.id)===String(sel.value)):null;const catalog=p?(getCatalogProduct(p.productId)||getCatalogProductByName(p.name)):null;const name=catalog?.name||'';const ref=p?.ref||'';const qty=Number(el('deliveryProductQty').value||0);const price=Number(el('deliveryProductPrice').value||0);if(!p||!catalog)return alert('اختر المنتج من المخزون');if(!ref||!isCatalogRefForProduct(catalog.id,ref))return alert('رقم المنتج غير مرتبط بقسم المنتوجات');if(qty<=0)return alert('أدخل العدد');if(price<0)return alert('الثمن غير صحيح');deliveryDraftItems.push({productId:catalog.id,name,ref,qty,price,total:qty*price});el('deliveryProductName').value='';el('deliveryProductRef').value='';el('deliveryProductQty').value='1';el('deliveryProductPrice').value='';if(sel)sel.value='';renderDeliveryEditor()}
function removeDeliveryItem(i){deliveryDraftItems.splice(i,1);renderDeliveryEditor()}
function saveIndependentDelivery(e){e.preventDefault();if(!deliveryDraftItems.length)return alert('أضف منتجاً واحداً على الأقل');if(!Array.isArray(db.deliveryDocs))db.deliveryDocs=[];const doc={id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerId:el('deliveryCustomerSelect')?.value||'',customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x})),total:deliveryItemsTotal(deliveryDraftItems)};const idx=db.deliveryDocs.findIndex(x=>String(x.id)===String(doc.id));if(idx>=0)db.deliveryDocs[idx]=doc;else db.deliveryDocs.push(doc);saveLocal();alert('تم حفظ وصل التسليم بشكل مستقل عن المبيعات');resetIndependentDelivery()}
function editIndependentDelivery(id){const d=db.deliveryDocs.find(x=>String(x.id)===String(id));if(!d)return;currentDeliveryId=d.id;deliveryDraftItems=(d.items||[]).map(x=>({...x}));refreshDeliveryCustomers(d.customerId||'');el('deliveryCustomerName').value=d.customerName||'';el('deliveryCustomerPhone').value=d.customerPhone||'';if(el('deliveryCustomerAddress'))el('deliveryCustomerAddress').value=d.customerAddress||'';if(el('deliveryNumber'))el('deliveryNumber').value=formatDeliveryNumber(d.deliveryNumber||d.id||'');const dt=new Date(d.date);if(!Number.isNaN(dt.getTime()))el('deliveryDate').value=new Date(dt.getTime()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);renderDeliveryEditor()}
function independentDeliveryHtml(d){
 const isFr=localStorage.getItem('afz_lang')==='fr';
 const L=isFr?{
   dir:'ltr',phone:'Téléphone : 0667668693',address:'Adresse : Zone industrielle, Zemamra',title:'Bon de livraison',number:'N° du bon :',customer:'Client',customerPhone:'TEl:',customerAddress:'Adresse :',date:'Date',product:'Nom du produit',qty:'Quantité',price:'Prix',total:'Total',grand:'Total final',thanks:'Les produits mentionnés ci-dessus ont été livrés',pass:'Client de passage'
 }:{
   dir:'rtl',phone:'الهاتف: 0667668693',address:'العنوان: الحي الصناعي الزمامرة',title:'وصل التسليم',number:'رقم الوصل:',customer:'الزبون',customerPhone:'الهاتف:',customerAddress:'العنوان:',date:'التاريخ',product:'اسم المنتج',qty:'العدد',price:'الثمن',total:'المجموع',grand:'المجموع النهائي',thanks:'تم تسليم المنتجات المذكورة أعلاه',pass:'زبون عابر'
 };
 const items=d.items||[];
 const rows=items.map(i=>`<tr><td>${esc(i.name)}</td><td class="num">${Number(i.qty||0)}</td><td class="money">${money(i.price)}</td><td class="money">${money(Number(i.total||Number(i.qty||0)*Number(i.price||0)))}</td></tr>`).join('');
 const dateText=d.date?esc(new Date(d.date).toLocaleString(isFr?'fr-MA':'ar-MA')):'-';
 return `<!doctype html><html lang="${isFr?'fr':'ar'}" dir="${L.dir}"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;direction:${L.dir}}.note{width:100%;padding:24px 28px}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:${isFr?'right':'left'};white-space:nowrap}.summary{margin-top:16px;margin-${isFr?'left':'right'}:auto;width:300px}.grand{font-size:18px;font-weight:bold;border-top:2px solid #0b4f8a;padding-top:8px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px}@page{size:A4;margin:8mm}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style>
<style id="goujon-small-image">
/* GOUJON DE ROUE: smaller product image */
.goujon-de-roue-small img,
img.goujon-de-roue-small {
  max-width: 55% !important;
  width: 55% !important;
  height: auto !important;
  object-fit: contain !important;
  margin-left: auto !important;
  margin-right: auto !important;
  display: block !important;
}
</style>
</head><body><div class="note"><div style="display:block;text-align:center;border-bottom:3px solid #0b4f8a;padding-bottom:12px"><div style="display:block"><img class="logo" src="logo.png" style="display:block;margin:0 auto 6px"><div><h1 style="font-size:22px;margin:0">AFRIQUIA FREINS ZEMAMRA</h1><p style="font-size:13px;margin:4px 0;font-weight:bold">${L.phone}</p><p style="font-size:13px;margin:4px 0">${L.address}</p></div></div><div style="margin-top:10px"><h2 style="margin:0;font-size:23px">${L.title}</h2><div style="margin-top:4px;font-size:12px">${L.number} ${esc(formatDeliveryNumber(d.deliveryNumber||d.id))}</div></div></div><div class="info"><div class="box customer-box"><div class="customer-head"><span class="customer-icon">👤</span><span>${L.customer}</span></div><div class="customer-name">${esc(d.customerName||L.pass)}</div>${d.customerPhone?'<div class="customer-row">📞 '+L.customerPhone+' '+esc(d.customerPhone)+'</div>':'<div class="customer-row" style="color:#8a959e">📞 '+(isFr?'TEl: non renseigné':'TEl: غير مسجل')+'</div>'}${d.customerAddress?'<div class="customer-row">📍 '+L.customerAddress+' '+esc(d.customerAddress)+'</div>':'<div class="customer-row" style="color:#8a959e">📍 '+(isFr?'Adresse non renseignée':'العنوان غير مسجل')+'</div>'}</div><div class="box"><div class="label">${L.date}</div><div class="value">${dateText}</div></div></div><table class="table"><tr><th>${L.product}</th><th>${L.qty}</th><th>${L.price}</th><th>${L.total}</th></tr>${rows}</table><div class="summary"><div class="grand"><span>${L.grand}</span> <b>${money(deliveryItemsTotal(items))}</b></div></div><div class="thanks">${L.thanks}<br>${L.phone} | ${L.address}</div></div></body></html>`;
}
function getCurrentDeliveryData(id){const saved=id?db.deliveryDocs.find(x=>String(x.id)===String(id)):null;return saved||({id:currentDeliveryId||('DL-'+Date.now()),deliveryNumber:formatDeliveryNumber(el('deliveryNumber')?.value.trim()||(currentDeliveryId||nextDeliveryNumber())),customerName:el('deliveryCustomerName').value.trim()||'زبون عابر',customerPhone:el('deliveryCustomerPhone').value.trim(),customerAddress:el('deliveryCustomerAddress')?.value.trim()||'',date:el('deliveryDate')?.value ? new Date(el('deliveryDate').value).toISOString() : '',items:deliveryDraftItems.map(x=>({...x}))});}
function previewIndependentDelivery(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);let modal=el('deliveryPreviewModal');if(!modal){modal=document.createElement('div');modal.id='deliveryPreviewModal';modal.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99999;display:flex;flex-direction:column;padding:10px';document.body.appendChild(modal);}modal.innerHTML='<div style="background:#fff;border-radius:12px;padding:8px;display:flex;gap:8px;align-items:center;justify-content:space-between"><b>👁️ معاينة وصل التسليم</b><div><button type="button" onclick="downloadIndependentDeliveryPdf()">⚡ طباعة PDF</button><button type="button" class="outline" onclick="closeDeliveryPreview()">✕ إغلاق</button></div></div><iframe title="معاينة وصل التسليم" style="flex:1;width:100%;border:0;border-radius:8px;margin-top:8px;background:#fff"></iframe>';modal.style.display='flex';const frame=modal.querySelector('iframe');frame.srcdoc=html;}
function closeDeliveryPreview(){const m=el('deliveryPreviewModal');if(m)m.style.display='none';}
function downloadIndependentDeliveryPdf(id){const d=getCurrentDeliveryData(id);if(!d.items?.length)return alert('أضف منتجات إلى الوصل أولاً');const html=independentDeliveryHtml(d);const name='Bon-de-livraison-'+String(d.id||Date.now())+'.pdf';try{if(window.AndroidPrint&&typeof AndroidPrint.savePdf==='function'){AndroidPrint.savePdf(html,name);return;} try{const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}else{alert('يجب فتح التطبيق بنسخة Android التي تدعم PDF.');}}catch(e){alert('يجب فتح التطبيق بنسخة Android التي تدعم PDF.')}}catch(e){alert('تعذر إنشاء PDF: '+e.message)}}
function downloadSelectedDeliveryPdf(){downloadIndependentDeliveryPdf(currentDeliveryId)}


function printLastSaleThermal(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.invoice{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:10px;margin-right:auto;width:65%}.sumrow{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #ccc;font-size:9px}.grand{font-size:13px;font-weight:bold;border-top:2px solid #111}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style>
<style id="goujon-small-image">
/* GOUJON DE ROUE: smaller product image */
.goujon-de-roue-small img,
img.goujon-de-roue-small {
  max-width: 55% !important;
  width: 55% !important;
  height: auto !important;
  object-fit: contain !important;
  margin-left: auto !important;
  margin-right: auto !important;
  display: block !important;
}
</style>
</head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>#${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج / المرجع</th><th>كم</th><th>الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Afriquia Thermal Invoice '+String(x.id||'')); else alert('الطباعة الحرارية متاحة داخل تطبيق Android.');
}
function printLastDeliveryNote(){
 if(!db.sales.length){alert('لا توجد مبيعات لإنشاء وصل التسليم');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const rows=items.map((i,n)=>{const qty=Number(i.qty||i.quantity||1),price=Number(i.price||i.salePrice||0),lineTotal=Number(i.total||qty*price);return '<tr><td><b>'+esc(i.name)+'</b></td><td class="num">'+qty+'</td><td class="money">'+money(price)+'</td><td class="money">'+money(lineTotal)+'</td></tr>';}).join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;padding:0;background:#fff}.note{width:100%;padding:14px}.head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:10px}.brand{display:block;text-align:center}.logo{width:125px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{display:none}.brand p{display:none}.title h2{margin:0;font-size:17px}.title div{font-size:9px;margin-top:3px}.contact{margin-top:8px;text-align:center;font-size:9px;font-weight:bold}.info{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}.box{border:1px solid #999;padding:6px}.label{font-size:8px;color:#555}.value{font-size:10px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:8px}.table th{background:#111;color:#fff;padding:5px;font-size:8px}.table td{border-bottom:1px solid #ccc;padding:5px;font-size:8px}.num{text-align:center}.thanks{text-align:center;margin-top:15px;padding-top:8px;border-top:1px dashed #777;font-size:9px}.small{font-size:7px}@page{margin:0}
.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style>
<style id="goujon-small-image">
/* GOUJON DE ROUE: smaller product image */
.goujon-de-roue-small img,
img.goujon-de-roue-small {
  max-width: 55% !important;
  width: 55% !important;
  height: auto !important;
  object-fit: contain !important;
  margin-left: auto !important;
  margin-right: auto !important;
  display: block !important;
}
</style>
</head><body><div class="note"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p></div></div><div class="title"><h2>وصل التسليم</h2><div>رقم الوصل: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="contact">الهاتف: 0667668693 — العنوان: الحي الصناعي الزمامرة</div><div class="info"><div class="box"><div class="label">الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">هاتف الزبون: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>المنتج</th><th>العدد</th><th>الثمن</th><th>المجموع</th></tr>${rows}</table><div class="thanks">تم تسليم المنتجات المذكورة أعلاه<br><span class="small">الهاتف: 0667668693 | الحي الصناعي الزمامرة</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.showThermalPrinterDialog) AndroidPrint.showThermalPrinterDialog(html,'Bon de livraison '+String(x.id||'')); else if(window.AndroidPrint&&AndroidPrint.printHtml) AndroidPrint.printHtml(html,'Bon de livraison '+String(x.id||'')); else {const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function printLastSale(){
 if(!db.sales.length){alert('لا توجد مبيعات للطباعة');return;}
 const x=db.sales[db.sales.length-1], items=saleItems(x), d=new Date(x.date), date=d.toLocaleString('ar-MA');
 const customer=x.customer||{name:'زبون عابر',phone:''};
 const total=Number(x.total||items.reduce((a,i)=>a+Number(i.total||Number(i.qty||0)*Number(i.price||0)),0));
 const rows=items.map((i,n)=>'<tr><td class="num">'+(n+1)+'</td><td><b>'+esc(i.name)+'</b>'+(i.ref?'<br><small>'+esc(i.ref)+'</small>':'')+'</td><td class="num">'+i.qty+'</td><td class="money">'+money(i.price)+'</td><td class="money">'+money(i.total||Number(i.qty)*Number(i.price))+'</td></tr>').join('');
 const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#17212b;margin:0;padding:0;background:#fff} .invoice{max-width:760px;margin:auto;padding:24px 28px} .head{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #0b4f8a;padding-bottom:16px}.brand{display:block;text-align:center}.logo{width:170px;height:auto;max-width:100%;object-fit:contain;display:block;margin:0 auto}.brand h1{font-size:22px;margin:0;color:#0b4f8a}.brand p{margin:5px 0 0;color:#687784;font-size:12px}.title{text-align:left}.title h2{margin:0;font-size:23px;color:#17212b}.title div{margin-top:5px;color:#687784;font-size:12px}.info{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}.box{border:1px solid #dfe6ec;border-radius:10px;padding:10px}.label{font-size:11px;color:#77838e;margin-bottom:4px}.value{font-size:14px;font-weight:bold}.table{width:100%;border-collapse:collapse;margin-top:12px}.table th{background:#0b4f8a;color:white;padding:9px;font-size:12px}.table td{border-bottom:1px solid #e5e9ed;padding:9px;font-size:12px}.num{text-align:center}.money{text-align:left;white-space:nowrap}.summary{margin-top:16px;margin-right:auto;width:300px}.sumrow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e9ed}.grand{font-size:18px;font-weight:bold;color:#0b4f8a;border-top:2px solid #0b4f8a;margin-top:4px}.thanks{text-align:center;margin-top:30px;padding-top:12px;border-top:1px dashed #b7c2ca;font-size:12px;color:#687784}.small{font-size:10px;color:#77838e}@page{size:A4;margin:8mm}@media print{.invoice{padding:0}}

.daily-expense-entry{padding:8px;overflow:hidden}.daily-expense-entry h3{margin:2px 0 8px;font-size:15px}.daily-expense-entry .daily-entry-wrap{overflow-x:auto}.daily-expense-entry table{width:100%;table-layout:fixed;font-size:11px;border-collapse:collapse}.daily-expense-entry th,.daily-expense-entry td{padding:4px 3px;border-bottom:1px solid #e5e9ed}.daily-expense-entry th{font-size:10px;white-space:nowrap}.daily-expense-entry input{margin:0;padding:6px 4px;font-size:11px;width:100%;min-width:0}.daily-expense-entry th:nth-child(1),.daily-expense-entry td:nth-child(1){width:30%}.daily-expense-entry th:nth-child(2),.daily-expense-entry td:nth-child(2){width:36%}.daily-expense-entry th:nth-child(3),.daily-expense-entry td:nth-child(3){width:24%}.daily-expense-entry th:nth-child(4),.daily-expense-entry td:nth-child(4){width:10%}.daily-expense-entry button{padding:5px 6px;font-size:10px;min-height:30px}@media(max-width:520px){.daily-expense-entry{padding:6px}.daily-expense-entry table{font-size:10px}.daily-expense-entry th,.daily-expense-entry td{padding:3px 2px}.daily-expense-entry th{font-size:9px}.daily-expense-entry input{padding:5px 3px;font-size:10px}.daily-expense-entry button{padding:4px 5px;font-size:9px}}

/* Daily expense entry table - compact phone layout */
.daily-expense-entry{padding:7px;margin-top:8px;background:#fff;border-radius:10px;overflow:hidden}
.daily-entry-title{font-size:15px;font-weight:800;margin:0 0 6px;text-align:right}
.daily-entry-help{margin-bottom:6px;text-align:right}
.daily-entry-wrap{width:100%;overflow-x:auto}
.daily-entry-table,.daily-saved-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:9px}
.daily-entry-table th,.daily-entry-table td,.daily-saved-table th,.daily-saved-table td{padding:2px 2px;border-bottom:1px solid #e5e9ed;text-align:center;vertical-align:middle;line-height:1.05}
.daily-entry-table th,.daily-saved-table th{font-size:8px;white-space:nowrap;background:#f7fbff}
/* Final compact daily-expense table for phone screens */
.daily-expense-entry-main .daily-saved-table{width:100%;table-layout:fixed;border-collapse:collapse;font-size:10px;line-height:1}
.daily-expense-entry-main .daily-saved-table tr{height:32px}
.daily-expense-entry-main .daily-saved-table th,.daily-expense-entry-main .daily-saved-table td{padding:2px 2px!important;height:32px;line-height:1!important;vertical-align:middle;text-align:center;white-space:nowrap;overflow:hidden}
.daily-expense-entry-main .daily-saved-table th{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table td{font-size:10px!important}
.daily-expense-entry-main .daily-saved-table td b{display:inline!important;font-size:10px!important;margin:0!important;line-height:1!important;font-weight:700!important;white-space:nowrap}
.daily-expense-entry-main .daily-saved-table th:nth-child(1),.daily-expense-entry-main .daily-saved-table td:nth-child(1){width:25%}
.daily-expense-entry-main .daily-saved-table th:nth-child(2),.daily-expense-entry-main .daily-saved-table td:nth-child(2){width:35%}
.daily-expense-entry-main .daily-saved-table th:nth-child(3),.daily-expense-entry-main .daily-saved-table td:nth-child(3){width:28%}
.daily-expense-entry-main .daily-saved-table th:nth-child(4),.daily-expense-entry-main .daily-saved-table td:nth-child(4){width:12%}
.daily-expense-entry-main .daily-saved-table .daily-delete-one{display:inline-flex!important;align-items:center;justify-content:center;min-width:22px!important;width:22px;height:22px!important;min-height:22px!important;padding:0!important;margin:0!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
@media(max-width:520px){
.daily-expense-entry-main .daily-saved-table{font-size:9px}
.daily-expense-entry-main .daily-saved-table tr{height:29px}
.daily-expense-entry-main .daily-saved-table th,.daily-expense-entry-main .daily-saved-table td{height:29px;padding:1px!important}
.daily-expense-entry-main .daily-saved-table th{font-size:8px!important}
.daily-expense-entry-main .daily-saved-table td{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table td b{font-size:9px!important}
.daily-expense-entry-main .daily-saved-table .daily-delete-one{width:20px;height:20px!important;min-width:20px!important;min-height:20px!important;font-size:11px!important}
}
.daily-saved-table th:nth-child(1),.daily-saved-table td:nth-child(1){width:24%}
.daily-saved-table th:nth-child(2),.daily-saved-table td:nth-child(2){width:40%}
.daily-saved-table th:nth-child(3),.daily-saved-table td:nth-child(3){width:24%}
.daily-saved-table th:nth-child(4),.daily-saved-table td:nth-child(4){width:12%}
.daily-one-form{display:grid;grid-template-columns:1fr;gap:4px}
.daily-one-form label{font-size:10px;font-weight:bold;margin-top:1px}
.daily-one-form input{width:100%;min-width:0;margin:0;padding:5px 4px;font-size:11px;border:1px solid #d5dde5;border-radius:6px;background:#fff}
.daily-save-one{width:100%;margin-top:3px;padding:6px 8px;font-size:11px;min-height:34px}
.daily-saved-title{font-size:12px;font-weight:800;margin:8px 0 4px}
.daily-delete-one{min-width:24px;padding:2px 4px;font-size:10px}
.daily-empty{font-size:10px;padding:7px!important}
@media(max-width:520px){.daily-expense-entry{padding:6px}.daily-entry-title{font-size:14px}.daily-saved-table{font-size:8px}.daily-saved-table th,.daily-saved-table td{padding:2px 1px}.daily-saved-table th{font-size:7px}.daily-one-form input{padding:5px 3px;font-size:10px}.daily-one-form label{font-size:9px}.daily-save-one{font-size:10px;padding:5px 6px;min-height:31px}.daily-saved-title{font-size:11px}}

 .daily-expense-entry{padding:7px}
 .daily-entry-title{font-size:13px;margin-bottom:3px}
 .daily-entry-table{font-size:8px;line-height:1}
 .daily-entry-table th,.daily-entry-table td{padding:1px 1px;height:20px}
 .daily-entry-table th{font-size:7px;padding:1px}
 .daily-entry-table input,.daily-saved-table input{padding:2px 1px;font-size:8px;min-height:20px}
 .daily-entry-actions button{font-size:10px;padding:7px 8px}
}

.daily-month-select{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:6px;align-items:center;margin:8px 0}.daily-month-select label{font-size:11px;color:#687784;font-weight:bold}.daily-month-select select{margin:0;padding:7px 8px;font-size:11px}.daily-entry-table th:nth-child(1),.daily-entry-table td:nth-child(1){width:20%}.daily-entry-table th:nth-child(2),.daily-entry-table td:nth-child(2){width:38%}.daily-entry-table th:nth-child(3),.daily-entry-table td:nth-child(3){width:28%}.daily-entry-table th:nth-child(4),.daily-entry-table td:nth-child(4){width:14%}.daily-date-small{font-size:8px;color:#8a959e;margin-top:2px;direction:ltr}.daily-add-one{min-width:30px!important;padding:5px 7px!important;font-size:15px!important;border-radius:8px!important}.daily-entry-table tr{height:40px}@media(max-width:520px){.daily-month-select{grid-template-columns:auto 1fr auto 1fr}.daily-month-select select{font-size:10px;padding:6px}.daily-date-small{font-size:7px}.daily-entry-table{font-size:10px}.daily-entry-table th,.daily-entry-table td{padding:3px 2px}.daily-entry-table input{font-size:10px;padding:6px 3px}.daily-add-one{font-size:14px!important;min-width:27px!important}}

.daily-one-form{display:flex;flex-direction:column;gap:6px;margin:8px 0 12px}
.daily-one-form label{font-size:12px;font-weight:700;color:#687784;text-align:right}
.daily-one-form input{width:100%;padding:10px 9px;font-size:13px;border:1px solid #d5dde5;border-radius:9px;background:#fff;box-sizing:border-box}
.daily-save-one{width:100%;padding:10px 12px!important;font-size:13px!important;margin-top:4px}
.daily-saved-title{font-size:14px;font-weight:800;margin:7px 0 5px;text-align:right}
.daily-saved-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:9px;line-height:1.05}
.daily-saved-table th,.daily-saved-table td{padding:3px 2px;border-bottom:1px solid #e5e9ed;text-align:center;vertical-align:middle}
.daily-saved-table th{font-size:8px;white-space:nowrap;background:#f7fbff}
.daily-saved-table th:nth-child(1),.daily-saved-table td:nth-child(1){width:25%}
.daily-saved-table th:nth-child(2),.daily-saved-table td:nth-child(2){width:39%}
.daily-saved-table th:nth-child(3),.daily-saved-table td:nth-child(3){width:25%}
.daily-saved-table th:nth-child(4),.daily-saved-table td:nth-child(4){width:11%}
.daily-delete-one{min-width:22px!important;padding:2px 5px!important;font-size:12px!important;line-height:1!important;border-radius:5px!important}
.daily-empty{padding:8px!important;color:#7a8791}
@media(max-width:520px){.daily-one-form input{font-size:12px;padding:9px 8px}.daily-one-form label{font-size:11px}.daily-save-one{font-size:12px!important}.daily-entry-table{font-size:7px!important;line-height:1!important}.daily-entry-table th,.daily-entry-table td{padding:1px!important;height:18px!important}.daily-entry-table th{font-size:6px!important}.daily-delete-one{font-size:9px!important;min-width:18px!important;padding:1px 3px!important;height:18px!important}.daily-saved-table{font-size:7px;line-height:1}.daily-saved-table th,.daily-saved-table td{padding:1px}.daily-saved-table th{font-size:6px}}

.stock-group-card{cursor:default}.stock-group-rows{margin:8px 0;background:#f7fafc;border-radius:10px;padding:6px}.stock-ref-row{display:grid;grid-template-columns:auto 1fr 1fr auto;gap:5px;align-items:center;padding:6px 2px;border-bottom:1px solid #e4e9ed;font-size:11px}.stock-ref-row:last-child{border-bottom:0}.stock-ref-row button{padding:5px 7px;font-size:11px;min-width:34px}.stock-group-card .prodimg{height:130px}
@media(max-width:520px){.stock-ref-row{grid-template-columns:1fr 1fr;gap:5px}.stock-ref-row .product-number-chip{grid-column:1/-1;text-align:center}.stock-ref-row button{width:100%}}
</style>
<style id="goujon-small-image">
/* GOUJON DE ROUE: smaller product image */
.goujon-de-roue-small img,
img.goujon-de-roue-small {
  max-width: 55% !important;
  width: 55% !important;
  height: auto !important;
  object-fit: contain !important;
  margin-left: auto !important;
  margin-right: auto !important;
  display: block !important;
}
</style>
</head><body><div class="invoice"><div class="head"><div class="brand"><img class="logo" src="logo.png"><div><h1>AFRIQUIA FREINS ZEMAMRA</h1><p>الحي الصناعي الزمامرة</p><p>الهاتف: 0667668693</p></div></div><div class="title"><h2>فاتورة بيع</h2><div>رقم الفاتورة: ${esc(formatDeliveryNumber(x.deliveryNumber||x.id||Date.now()))}</div></div></div><div class="info"><div class="box"><div class="label">بيانات الزبون</div><div class="value">${esc(customer.name||'زبون عابر')}</div>${customer.phone?'<div class="small">الهاتف: '+esc(customer.phone)+'</div>':''}</div><div class="box"><div class="label">التاريخ</div><div class="value">${esc(date)}</div></div></div><table class="table"><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>ثمن الوحدة</th><th>المجموع</th></tr>${rows}</table><div class="summary"><div class="sumrow"><span>عدد الأسطر</span><b>${items.length}</b></div><div class="sumrow grand"><span>المجموع النهائي</span><b>${money(total)}</b></div></div><div class="thanks">شكراً لثقتكم بنا ❤️<br><span class="small">AFRIQUIA FREINS ZEMAMRA</span></div></div>
</body></html>`;
 if(window.AndroidPrint&&AndroidPrint.printHtml)AndroidPrint.printHtml(html,'Afriquia Stock - Invoice '+String(x.id||''));else{const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();w.focus();w.print();}}
}
function normalizePickedContact(payload){
 try{
   if(payload==null) return null;
   if(typeof payload==='string'){
     const raw=payload.trim();
     if(!raw) return null;
     try{payload=JSON.parse(raw)}catch(e){
       // دعم نص بسيط بالشكل: الاسم|الرقم
       const parts=raw.split('|');
       if(parts.length>=2) return {name:parts[0].trim(),phone:parts.slice(1).join('|').trim()};
       return null;
     }
   }
   if(Array.isArray(payload)) payload=payload[0];
   const name=Array.isArray(payload?.name)?(payload.name[0]||''):String(payload?.name||payload?.displayName||'');
   const phone=Array.isArray(payload?.tel)?(payload.tel[0]||''):String(payload?.tel||payload?.phone||payload?.number||'');
   return (name||phone)?{name,phone}:null;
 }catch(e){return null}
}

function applyPickedContact(target, contact){
 const c=normalizePickedContact(contact);
 if(!c) return false;
 if(target==='credit') setCreditCustomerFromContact(c.name,c.phone);
 else setCustomerFromContact(c.name,c.phone);
 return true;
}

// يستعمله غلاف Android بعد اختيار جهة الاتصال. وجوده يمنع اعتماد التطبيق على
// Web Contact Picker غير المدعوم غالباً داخل Android WebView.
window.onCustomerContactSelected=function(name,phone){ setCustomerFromContact(name||'',phone||''); };
window.onCreditContactSelected=function(name,phone){ setCreditCustomerFromContact(name||'',phone||''); };
window.setCustomerContact=function(name,phone){ setCustomerFromContact(name||'',phone||''); };
window.setCreditContact=function(name,phone){ setCreditCustomerFromContact(name||'',phone||''); };

function openVCardFallback(target){
 const id=target==='credit'?'creditVCardInput':'customerVCardInput';
 const input=el(id);
 if(input){input.value='';input.click();return true;}
 return false;
}

function parseVCard(text){
 const lines=String(text||'').replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n');
 // فك الأسطر المطوية في ملفات vCard
 const unfolded=[];
 for(const line of lines){
   if(/^[ \t]/.test(line) && unfolded.length) unfolded[unfolded.length-1]+=line.slice(1);
   else unfolded.push(line);
 }
 let name='', phone='';
 for(const line of unfolded){
   const idx=line.indexOf(':'); if(idx<0) continue;
   const left=line.slice(0,idx).toUpperCase(), value=line.slice(idx+1).trim();
   if(!value) continue;
   if(!name && (left.startsWith('FN') || left.startsWith('N;') || left==='N')) name=value.replace(/;/g,' ').trim();
   if(!phone && (left.startsWith('TEL') || left.includes(';TEL'))) phone=value;
 }
 return {name,phone};
}

async function handleCustomerVCard(event){
 try{
   const file=event.target.files&&event.target.files[0]; if(!file)return;
   const contact=parseVCard(await file.text());
   if(!contact.name&&!contact.phone) return alert('ملف جهة الاتصال غير صالح.');
   setCustomerFromContact(contact.name,contact.phone);
 }catch(e){alert('تعذر قراءة جهة الاتصال: '+(e?.message||'ملف غير صالح'));}
}
async function handleCreditVCard(event){
 try{
   const file=event.target.files&&event.target.files[0]; if(!file)return;
   const contact=parseVCard(await file.text());
   if(!contact.name&&!contact.phone) return alert('ملف جهة الاتصال غير صالح.');
   setCreditCustomerFromContact(contact.name,contact.phone);
 }catch(e){alert('تعذر قراءة جهة الاتصال: '+(e?.message||'ملف غير صالح'));}
}

async function pickCustomerContact(){
 let nativeAttempted=false;
 try{
   if(window.AndroidPrint && typeof AndroidPrint.pickCustomerContact === 'function'){
     nativeAttempted=true;
     const result=await AndroidPrint.pickCustomerContact();
     if(applyPickedContact('customer',result)) return;
     // بعض أغلفة Android لا تعيد القيمة من الدالة، بل تستدعي callback أعلاه.
     // لذلك لا نعرض خطأ مباشرة إذا نجح الاستدعاء.
     if(result===undefined || result===null) return;
   }
   if(navigator.contacts && typeof navigator.contacts.select === 'function'){
     const contacts=await navigator.contacts.select(['name','tel'],{multiple:false});
     if(applyPickedContact('customer',contacts)) return;
   }
 }catch(err){
   // ننتقل إلى البديل بدل إظهار رسالة appassets.androidplatform.net المضللة.
 }
 // WebView على Android لا يدعم Contact Picker في كثير من الإصدارات؛ استخدم VCF كبديل عملي.
 if(!openVCardFallback('customer') && nativeAttempted){
   alert('تعذر فتح جهات الاتصال من هذا الإصدار. يمكنك اختيار ملف جهة اتصال VCF.');
 }
}

function setCustomerFromContact(name,phone){
 el('custName').value=name||'';
 el('custPhone').value=phone||'';
 el('custName').focus();
}

async function pickCreditContact(){
 let nativeAttempted=false;
 try{
   if(window.AndroidPrint && typeof AndroidPrint.pickCreditContact === 'function'){
     nativeAttempted=true;
     const result=await AndroidPrint.pickCreditContact();
     if(applyPickedContact('credit',result)) return;
     if(result===undefined || result===null) return;
   }
   if(navigator.contacts && typeof navigator.contacts.select === 'function'){
     const contacts=await navigator.contacts.select(['name','tel'],{multiple:false});
     if(applyPickedContact('credit',contacts)) return;
   }
 }catch(err){
   // استخدم البديل أدناه.
 }
 if(!openVCardFallback('credit') && nativeAttempted){
   alert('تعذر فتح جهات الاتصال من هذا الإصدار. يمكنك اختيار ملف جهة اتصال VCF.');
 }
}

function setCreditCustomerFromContact(name,phone){
 if(el('creditCustomerName')) el('creditCustomerName').value=name||'';
 if(el('creditPhone')) el('creditPhone').value=phone||'';
 if(el('creditCustomer')){
   const c=(db.customers||[]).find(x=>String(x.name||'').trim()===String(name||'').trim() || String(x.phone||'').trim()===String(phone||'').trim());
   if(c) el('creditCustomer').value=String(c.id);
 }
 if(el('creditCustomerName')) el('creditCustomerName').focus();
}
function addCustomer(e){e.preventDefault();const name=el('custName').value.trim(),phone=el('custPhone').value.trim();if(!name)return;db.customers.push({id:Date.now(),name,phone});save();e.target.reset();alert('تم حفظ الزبون');}
function addExpense(e){e.preventDefault();const name=el('expName').value.trim(),amount=Number(el('expAmount').value);if(!name||amount<0)return;db.expenses.push({date:new Date().toISOString(),name,amount});save();e.target.reset();alert('تم حفظ المصروف');}
let selectedStockCardName = '';
function selectStockCard(name){
  selectedStockCardName = String(name||'').trim();
  render();
  setTimeout(()=>{ const box=el('stockList'); if(box) box.scrollIntoView({behavior:'smooth',block:'start'}); }, 30);
}
function clearStockCardSelection(){
  selectedStockCardName = '';
  render();
}

async function editStockImageByName(encodedName){
 const name=decodeURIComponent(String(encodedName||''));
 if(!name)return;
 const input=document.createElement('input');
 input.type='file'; input.accept='image/*'; input.style.display='none';
 document.body.appendChild(input);
 input.onchange=async()=>{
   try{
     const file=input.files&&input.files[0]; if(!file)return;
     if(!file.type.startsWith('image/')) return alert('اختر صورة فقط.');
     const image=await compressImage(file);
     const key=normalizeProductName(name);
     let changed=false;
     (db.stock||[]).forEach(x=>{if(normalizeProductName(x.name)===key){x.image=image;changed=true;}});
     (db.products||[]).forEach(x=>{if(normalizeProductName(x.name)===key){x.image=image;changed=true;}});
     if(changed){save();syncProductsFromStock();render();}
   }catch(err){alert('تعذر تغيير الصورة. جرّب صورة أصغر.');}
   finally{input.remove();}
 };
 input.click();
}
function editStock(id){
 const p=db.stock.find(x=>String(x.id)===String(id));if(!p)return;
 const qty=prompt('الكمية:',p.qty);if(qty===null)return;
 const n=Number(qty);
 if(!Number.isFinite(n)||n<0)return alert('بيانات غير صحيحة');
 // اسم المنتوج والرقم والصورة مصادرها الرئيسية هي «المنتجات | الاسم | الرقم | الصورة».
 // من المخزون يمكن تعديل الكمية فقط.
 const catalog=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);
 if(catalog){p.productId=catalog.id;p.name=catalog.name;p.ref=productNumbers(catalog).find(r=>String(r).trim().toLowerCase()===String(p.ref||'').trim().toLowerCase())||p.ref;if(catalog.image)p.image=catalog.image;}
 p.qty=n;
 syncStockPurchasePrices();
 save();
 render();
 alert('تم تعديل الكمية فقط. اسم المنتوج ورقمه وصورته لا تُعدّل من المخزون.');
}
function deleteStock(id){if(confirm('حذف هذا المنتج من المخزون؟')){db.stock=db.stock.filter(x=>x.id!==id);delete db.prices[String(id)];save()}}
function deleteStockGroup(encodedName){
  const name=decodeURIComponent(String(encodedName||''));
  const key=normalizeProductName(name);
  const items=(db.stock||[]).filter(x=>normalizeProductName(x.name||'')===key);
  if(!items.length)return;
  if(!confirm('هل تريد حذف مخزون «'+name+'» بالكامل؟\nسيتم حذف الكميات المسجلة لهذا المنتوج من قسم المخزون فقط، ولن يتم حذف المنتوج من «تعريفة الشركات» أو «المنتجات | الاسم | الرقم | الصورة».'))return;
  items.forEach(x=>{delete db.prices[String(x.id)]});
  db.stock=(db.stock||[]).filter(x=>normalizeProductName(x.name||'')!==key);
  selectedStockCardName='';
  save();
  alert('تم حذف مخزون «'+name+'» بنجاح');
}
function saveProductPrices(id){
 const input=el('price_'+id);
 if(!input)return;
 const value=Number(input.value);
 if(!Number.isFinite(value)||value<0){alert('أدخل ثمناً صحيحاً');return;}
 db.prices[String(id)]=value;
 const linked=(db.stock||[]).find(x=>String(x.productId)===String(id));
 if(linked) linked.salePrice=value;
 save();
 alert('تم حفظ سعر المنتوج');
}
function getProductStock(id){
 return (db.stock||[]).find(x=>String(x.productId)===String(id))||null;
}
function getProductPrice(id){
 const v=db.prices[String(id)];
 if(v!==undefined && Number.isFinite(Number(v))) return Number(v);
 const st=getProductStock(id);
 if(st && db.prices[String(st.id)]!==undefined) return Number(db.prices[String(st.id)]);
 return st && st.salePrice!==undefined ? Number(st.salePrice) : 0;
}
// ترتيب الأرقام/المراجع في التطبيق: أبجدياً من A إلى Z.
function sortNumbersAscending(values){
 return [...new Set((values||[]).map(v=>String(v||'').trim()).filter(Boolean))].sort((a,b)=>compareNamesAZ(a,b));
}

function showSearchPicker(input){
 try{ if(input && typeof input.showPicker==='function') input.showPicker(); }catch(e){}
}
function fillDatalist(id, values, numeric=false){
 const list=el(id); if(!list)return;
 let vals=[...new Set((values||[]).map(v=>String(v||'').trim()).filter(Boolean))];
 if(numeric) vals=sortNumbersAscending(vals); else vals.sort((a,b)=>compareNamesAZ(a,b));
 list.innerHTML=vals.map(v=>`<option value="${esc(v)}"></option>`).join('');
}
function renderAllSearchLists(){
 renderStockCompanyOptions();
 renderCheckSearchCompanyOptions();
 renderStockSearchOptions();
 renderPriceProductNames();
 renderNewPriceProductNames();
 renderPriceNumberOptions();
 fillDatalist('creditNames',(db.credits||[]).map(x=>x.customerName));
 fillDatalist('creditPhones',(db.credits||[]).map(x=>x.phone),true);
 fillDatalist('checkNumbers',(db.checks||[]).map(x=>x.number),true);
 fillDatalist('checkBeneficiaries',(db.checks||[]).map(x=>x.beneficiary));
}

function renderCheckSearchCompanyOptions(showPicker=false){
 const picker=el('checkSearchCompanyPicker');
 const datalist=el('checkSearchCompanyNames');
 // البحث يكون فقط بين الشركات المسجلة في «تعريفة الشركات» والتي لديها شيك فعلاً في دفتر الشيكات.
 const registered=[
   ...(db.companies||[]).map(x=>String(x?.name||x||'').trim()),
   ...(db.companyPrices||[]).map(x=>String(x?.company||'').trim())
 ].filter(Boolean);
 const uniqueRegistered=[...new Set(registered)];
 const checkedNames=new Set((db.checks||[])
   .map(x=>String(x?.beneficiary||'').trim())
   .filter(Boolean)
   .map(n=>n.toLowerCase()));
 const vals=[...new Set(uniqueRegistered.filter(n=>checkedNames.has(n.toLowerCase())))].sort((a,b)=>
   compareNamesAZ(a,b)
 );
 if(datalist) datalist.innerHTML=vals.map(n=>`<option value="${esc(n)}"></option>`).join('');
 if(!picker)return;
 const q=String(el('checkSearchName')?.value||'').trim().toLowerCase();
 const filtered=q?vals.filter(n=>n.toLowerCase().includes(q)):vals;
 picker.innerHTML=filtered.length
   ?filtered.map(n=>`<button type="button" class="search-picker-item check-search-company-option" data-check-company="${esc(n)}">🏢 ${esc(n)}</button>`).join('')
   :'<div class="search-picker-empty">لا توجد شركات مسجلة عليها شيكات</div>';
 if(showPicker) picker.style.display='block';
}
function openCheckSearchCompanyPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 renderCheckSearchCompanyOptions(true);
 const input=el('checkSearchName');
 if(input) input.focus();
}
function renderCheckSearchNumberOptions(showPicker=false){
 const picker=el('checkSearchNumberPicker');
 if(!picker)return;
 // إظهار أرقام الشيكات المسجلة فعلياً في دفتر الشيكات فقط.
 const vals=[...new Set((db.checks||[])
   .map(x=>String(x?.number||'').trim())
   .filter(Boolean))].sort(compareRefsDesc);
 const q=String(el('checkSearchNumber')?.value||'').trim().toLowerCase();
 const filtered=q?vals.filter(n=>n.toLowerCase().includes(q)):vals;
 picker.innerHTML=filtered.length
   ?filtered.map(n=>`<button type="button" class="search-picker-item check-search-number-option" data-check-number="${esc(n)}">🔢 ${esc(n)}</button>`).join('')
   :'<div class="search-picker-empty">لا توجد أرقام شيكات مسجلة</div>';
 if(showPicker) picker.style.display='block';
}
function openCheckSearchNumberPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 renderCheckSearchNumberOptions(true);
 const input=el('checkSearchNumber');
 if(input) input.focus();
}
function selectCheckSearchNumber(number){
 const input=el('checkSearchNumber');
 if(input) input.value=number||'';
 const nameEl=el('checkSearchName');
 if(nameEl) nameEl.value='';
 const picker=el('checkSearchNumberPicker');
 if(picker) picker.style.display='none';
 renderChecks();
}
function selectCheckSearchCompany(name){
 const input=el('checkSearchName');
 if(input) input.value=name||'';
 const numberEl=el('checkSearchNumber');
 if(numberEl) numberEl.value='';
 const picker=el('checkSearchCompanyPicker');
 if(picker) picker.style.display='none';
 renderChecks();
}
function renderStockSearchOptions(){
 const names=el('stockProductNames');
 const vals=stockSortNamesDescending((db.products||[]).map(x=>String(x.name||'').trim()));
 if(names) names.innerHTML=vals.map(n=>`<option value="${esc(n)}"></option>`).join('');
 const nums=el('stockNumbers');
 if(nums){
   const nameQ=normalizeProductName(el('stockNameSearch')?.value||'');
   let refs=(db.stock||[]).filter(x=>!nameQ||normalizeProductName(x.name).includes(nameQ)).map(x=>String(x.ref||'').trim()).filter(Boolean);
   if(nameQ && !refs.length){ const cp=getCatalogProductByName(el('stockNameSearch')?.value||''); if(cp) refs=productNumbers(cp); }
   refs=stockSortNumbersDescending([...new Set(refs)]);
   nums.innerHTML=refs.map(n=>`<option value="${esc(n)}"></option>`).join('');
   const current=String(el('stockSearch')?.value||'').trim();
   if(current && nameQ && !refs.includes(current) && el('stockSearch')) el('stockSearch').value='';
 }
}
function getPriceProductNames(){
 const names=[...new Map(stockCatalogProducts().map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 return names.sort((a,b)=>compareNamesAZ(a,b));
}
function renderPriceNamePicker(filter=true){
 const box=el('priceNamePicker'); if(!box)return;
 const q=filter?normalizeProductName(el('priceNameSearch')?.value||''):'';
 const names=getPriceProductNames().filter(n=>!q||normalizeProductName(n).includes(q));
 preparePickerModal(box,'اختر اسم المنتج'); box.querySelectorAll(':scope > button, :scope > .search-picker-empty').forEach(x=>x.remove()); const body=names.length?names.map(n=>`<button type="button" class="search-picker-item price-name-option" data-name="${esc(n)}">${esc(n)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أسماء مسجلة</div>`; box.insertAdjacentHTML('beforeend',body);
}
function openPriceNamePicker(){
 renderPriceProductNames();
 renderPriceNamePicker(false);
 const box=el('priceNamePicker'); if(box)box.style.display='block';
 syncPriceNumberFromName();
}
function filterPriceNamePicker(){
 renderPriceNamePicker();
 syncPriceNumberFromName();
 updatePricePurchaseSearch();
 const box=el('priceNamePicker'); if(box)box.style.display='block';
}
function selectPriceName(name){
 const input=el('priceNameSearch');
 if(input){ input.value=String(name||''); input.focus(); }
 const box=el('priceNamePicker'); if(box)box.style.display='none';
 syncPriceNumberFromName();
 updatePricePurchaseSearch();
 renderPrices();
}
function openPriceNumberPicker(){
 const name=normalizeProductName(el('priceNameSearch')?.value||'');
 const box=el('priceNumberPicker'); if(!box)return;
 if(!name){
   preparePickerModal(box,'اختر اسم المنتج'); box.querySelectorAll(':scope > button, :scope > .search-picker-empty').forEach(x=>x.remove()); box.insertAdjacentHTML('beforeend','<div class="search-picker-empty">اكتب أو اختر اسم المنتوج أولاً</div>');
   box.style.display='block';
   return;
 }
 renderPriceNumberPicker(false);
 box.style.display='block';
}
function filterPriceNumberPicker(){
 const name=normalizeProductName(el('priceNameSearch')?.value||'');
 const box=el('priceNumberPicker'); if(!box)return;
 if(!name){
   preparePickerModal(box,'اختر اسم المنتج'); box.querySelectorAll(':scope > button, :scope > .search-picker-empty').forEach(x=>x.remove()); box.insertAdjacentHTML('beforeend','<div class="search-picker-empty">اكتب أو اختر اسم المنتوج أولاً</div>');
   box.style.display='block';
   return;
 }
 renderPriceNumberPicker(true);
 box.style.display='block';
}
function getPriceProductNumbers(){
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 if(!qName)return [];
 let refs=[];
 stockCatalogProducts().forEach(product=>{
   const name=normalizeProductName(product.name||'');
   if(!name.includes(qName))return;
   refs.push(...getPriceRefsForDisplay(product.id));
 });
 return sortNumbersAscending(refs);
}
function renderPriceNumberPicker(filter=true){
 const box=el('priceNumberPicker'); if(!box)return;
 const name=normalizeProductName(el('priceNameSearch')?.value||'');
 if(!name){
   preparePickerModal(box,'اختر رقم المنتج'); box.querySelectorAll(':scope > button, :scope > .search-picker-empty').forEach(x=>x.remove()); box.insertAdjacentHTML('beforeend','<div class="search-picker-empty">اكتب أو اختر اسم المنتوج أولاً</div>');
   return;
 }
 const q=filter?String(el('priceNumberSearch')?.value||'').trim().toLowerCase():'';
 const refs=getPriceProductNumbers().filter(r=>!q||r.toLowerCase().includes(q));
 preparePickerModal(box,'اختر رقم المنتج'); box.querySelectorAll(':scope > button, :scope > .search-picker-empty').forEach(x=>x.remove()); const body=refs.length?refs.map(r=>`<button type="button" class="search-picker-item price-number-option" data-ref="${esc(r)}">${esc(r)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أرقام مسجلة لهذا الاسم</div>`; box.insertAdjacentHTML('beforeend',body);
}
function selectPriceNumber(ref){
 const input=el('priceNumberSearch'); if(input)input.value=ref;
 const box=el('priceNumberPicker'); if(box)box.style.display='none';
 updatePricePurchaseSearch();
 renderPrices();
}
function syncStockPurchasePrices(){
 (db.stock||[]).forEach(x=>{
   const productId=String(x.productId||'');
   const ref=String(x.ref||x.number||x.code||'').trim().toLowerCase();
   const companyKey=normalizeProductName(x.company||'');
   const item=(db.companyPrices||[]).find(v=>String(v.productId||'')===productId&&String(v.ref||'').trim().toLowerCase()===ref&&normalizeProductName(v.company||'')===companyKey);
   if(item && Number.isFinite(Number(item.price))) x.buy=Number(item.price);
 });
}

function getPurchasePriceForRef(productId,ref){
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 const key=String(productId);
 const raw=pp[key];
 const wanted=String(ref||'').trim().toLowerCase();
 if(raw&&typeof raw==='object'&&!Array.isArray(raw)){
   if(wanted && raw[wanted]!==undefined && Number.isFinite(Number(raw[wanted]))) return Number(raw[wanted]);
   const exactKey=Object.keys(raw).find(k=>String(k).trim().toLowerCase()===wanted);
   if(exactKey!==undefined && Number.isFinite(Number(raw[exactKey]))) return Number(raw[exactKey]);
   const first=Object.values(raw).find(v=>Number.isFinite(Number(v)));
   if(first!==undefined)return Number(first);
 }
 if(raw!==undefined && Number.isFinite(Number(raw))) return Number(raw);
 const st=(Array.isArray(db.stock)?db.stock:[]).find(x=>String(x.productId)===key && (!wanted || String(x.ref||x.number||x.code||'').trim().toLowerCase()===wanted));
 if(st&&Number.isFinite(Number(st.buy)))return Number(st.buy);
 return getPurchasePriceForProduct(productId);
}
function updatePricePurchaseSearch(){
 const out=el('pricePurchaseSearch'); if(!out)return;
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 const qRef=String(el('priceNumberSearch')?.value||'').trim().toLowerCase();
 const products=stockCatalogProducts();
 const matches=products.filter(product=>{
   const name=normalizeProductName(product.name||'');
   if(qName && name!==qName)return false;
   if(qRef){
     const refs=getAllProductRefs(product.id);
     if(!refs.some(r=>r.toLowerCase()===qRef))return false;
   }
   return true;
 });
 const product=matches[0];
 if(!product){out.value='';return;}
 const refs=getAllProductRefs(product.id);
 if(!qRef){out.value='';return;}
 const selectedRef=refs.find(r=>r.toLowerCase()===qRef)||'';
 if(!selectedRef){out.value='';return;}
 const buy=getPurchasePriceForRef(product.id,selectedRef);
 out.value=Number.isFinite(buy) ? (buy.toFixed(2).replace(/\.00$/,'')+' DH') : '';
}
function closePriceNamePicker(e){
 document.querySelectorAll('.search-picker-wrap').forEach(wrap=>{
   if(!wrap.contains(e.target)){
     wrap.querySelectorAll('.search-picker-list').forEach(box=>box.style.display='none');
   }
 });
}
document.addEventListener('click',closePriceNamePicker);
document.addEventListener('click',function(e){
 const opt=e.target.closest('.check-search-company-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectCheckSearchCompany(opt.getAttribute('data-check-company')||'');
});
document.addEventListener('click',function(e){
 const opt=e.target.closest('.check-search-number-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectCheckSearchNumber(opt.getAttribute('data-check-number')||'');
});
document.addEventListener('click',function(e){
 const opt=e.target.closest('.price-name-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 const name=opt.getAttribute('data-name')||'';
 selectPriceName(name);
});
document.addEventListener('pointerdown',function(e){
 const opt=e.target.closest('.price-number-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectPriceNumber(opt.getAttribute('data-ref')||'');
},{passive:false});
document.addEventListener('click',function(e){
 const opt=e.target.closest('.price-number-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectPriceNumber(opt.getAttribute('data-ref')||'');
});
document.addEventListener('click',function(e){
 if(e.target && e.target.id==='newPriceProductChoiceModal')closeNewPriceProductChoice();
});

document.addEventListener('click',function(e){
 const opt=e.target.closest('.new-price-name-option');
 if(!opt)return;
 e.preventDefault();
 e.stopPropagation();
 selectNewPriceProductName(opt.getAttribute('data-name')||'');
});


function renderPriceProductNames(){
 const list=el('priceProductNames'); if(!list)return;
 const names=[...new Map((db.stock||[]).map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 list.innerHTML=names.map(n=>`<option value="${esc(n)}"></option>`).join('');
}
function syncPriceNumberFromName(){
 const nameInput=el('priceNameSearch'), numberInput=el('priceNumberSearch');
 if(!nameInput||!numberInput)return;
 const q=normalizeProductName(nameInput.value||'');
 const products=stockCatalogProducts();
 let refs=[];
 products.forEach(p=>{if(!q||normalizeProductName(p.name).includes(q))refs.push(...getAllProductRefs(p.id));});
 refs=sortNumbersAscending(refs);
 const list=el('priceProductNumbers');
 if(list) list.innerHTML=refs.map(r=>`<option value=\"${esc(r)}\"></option>`).join('');
 if(q && numberInput.value && !refs.includes(String(numberInput.value).trim())) numberInput.value='';
}
function renderPriceNumberOptions(){
 const list=el('priceProductNumbers'); if(!list)return;
 const q=normalizeProductName(el('priceNameSearch')?.value||'');
 let refs=[];
 stockCatalogProducts().forEach(p=>{if(!q||normalizeProductName(p.name).includes(q))refs.push(...getAllProductRefs(p.id));});
 refs=sortNumbersAscending(refs);
 list.innerHTML=refs.map(r=>`<option value=\"${esc(r)}\"></option>`).join('');
}
function getPriceOnlyRefs(productId){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 return productNumbers(p);
}
function getAllProductRefs(productId){return getPriceOnlyRefs(productId);}
function getPurchasePriceForProduct(productId){
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 if(pp[String(productId)]!==undefined && Number.isFinite(Number(pp[String(productId)]))) return Number(pp[String(productId)]);
 const st=getProductStock(productId);
 return st&&Number.isFinite(Number(st.buy))?Number(st.buy):0;
}
function getNewPriceProductNames(){
 const names=[...new Map((db.products||[]).map(p=>[normalizeProductName(p.name),String(p.name||'').trim()]).filter(x=>x[1])).values()];
 return names.sort((a,b)=>compareNamesAZ(a,b));
}
function getPriceRefsForProduct(product){
 return productNumbers(product);
}
function getAlreadyPricedRefs(productId){
 const map=(db.priceRefs&&typeof db.priceRefs==='object')?db.priceRefs:{};
 const refs=Array.isArray(map[String(productId)])?map[String(productId)]:[];
 return refs.map(v=>String(v||'').trim()).filter(Boolean);
}
function previewPriceProductImage(){
 const input=el('priceProductImage'),preview=el('priceProductImagePreview');
 if(!input||!preview)return;
 const file=input.files?.[0];
 if(!file){preview.innerHTML='';preview.style.display='none';return;}
 if(!file.type.startsWith('image/')){input.value='';preview.innerHTML='';preview.style.display='none';return alert('اختر صورة فقط.');}
 const r=new FileReader();
 r.onload=()=>{preview.innerHTML='<img src="'+r.result+'" alt="صورة المنتوج">';preview.style.display='block';};
 r.readAsDataURL(file);
}

function openNewPriceProductChoice(){
 const modal=el('newPriceProductChoiceModal');
 if(modal)modal.classList.add('open');
}
function closeNewPriceProductChoice(){
 const modal=el('newPriceProductChoiceModal');
 if(modal)modal.classList.remove('open');
}
function chooseNewPriceProductType(mode){
 const m=el('newPriceProductMode');
 if(m)m.value=mode==='existing'?'existing':'new';
 closeNewPriceProductChoice();
 switchNewPriceProductMode();
 const input=el('newPriceProductName'), btn=el('addPriceProductNameBtn');
 if(!input)return;
 input.style.display='block';
 if(btn)btn.style.display='none';
 if(mode==='existing'){
   input.readOnly=true;
   input.placeholder='اختر اسم المنتوج المسجل';
   renderNewPriceProductNames();
   const box=el('newPriceProductPicker'); if(box)box.style.display='block';
 }else{
   input.readOnly=false;
   input.placeholder='اسم المنتوج الجديد';
   input.focus();
 }
}
function switchNewPriceProductMode(){
 const mode=el('newPriceProductMode')?.value||'new';
 const name=el('newPriceProductName'), ref=el('newPriceProductRef'), nameBox=el('newPriceProductPicker'), refBox=el('newPriceProductRefPicker'), hint=el('newPriceProductHint');
 if(!name||!ref)return;
 name.value='';ref.value='';
 const choiceBtn=el('addPriceProductNameBtn');
 if(choiceBtn){choiceBtn.style.display='block';choiceBtn.classList.remove('selected');}
 name.style.display='none';
 if(nameBox)nameBox.style.display='none'; if(refBox)refBox.style.display='none';
 const imageWrap=el('priceProductImageWrap'), imageInput=el('priceProductImage');
 if(imageWrap)imageWrap.style.display=mode==='new'?'block':'none';
 if(imageInput){imageInput.value='';}
 const imagePreview=el('priceProductImagePreview'); if(imagePreview){imagePreview.innerHTML='';imagePreview.style.display='none';}
 if(mode==='existing'){
   name.placeholder='اختر اسم المنتوج المسجل';
   ref.placeholder='أدخل رقمًا جديدًا لهذا المنتوج';
   if(hint)hint.textContent='اختر اسمًا مسجلًا، ثم اكتب رقمًا جديدًا لهذا الاسم، ثم أدخل ثمن الشراء. الأرقام السابقة لا تظهر هنا.';
 }else{
   name.placeholder='اسم المنتوج الجديد';
   ref.placeholder='رقم المنتوج الجديد';
   if(hint)hint.textContent='للمنتوج الجديد: أدخل الاسم ثم رقم المنتوج ثم ثمن الشراء.';
 }
}
function renderNewPriceProductNames(){
 const names=getNewPriceProductNames();
 const box=el('newPriceProductPicker'); if(!box)return;
 const q=normalizeProductName(el('newPriceProductName')?.value||'');
 const filtered=names.filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=filtered.length?filtered.map(n=>`<button type="button" class="search-picker-item new-price-name-option" data-name="${esc(n)}">${esc(n)}</button>`).join(''):`<div class="search-picker-empty">لا توجد أسماء مسجلة</div>`;
}
function openNewPriceProductPicker(){
 if((el('newPriceProductMode')?.value||'new')!=='existing')return;
 renderNewPriceProductNames(); const box=el('newPriceProductPicker'); if(box)box.style.display='block';
}
function filterNewPriceProductPicker(){openNewPriceProductPicker();}
function selectNewPriceProductName(name){
 const input=el('newPriceProductName'); if(input){input.style.display='block';input.value=String(name||'');input.focus();}
 const box=el('newPriceProductPicker'); if(box)box.style.display='none';
}
function getSelectedCatalogProductByName(name){
 const n=normalizeProductName(name); return (db.products||[]).find(p=>normalizeProductName(p.name)===n)||null;
}
function getNewPriceProductRefs(){ return []; }
function renderNewPriceProductRefPicker(){
 const box=el('newPriceProductRefPicker');
 if(box) box.style.display='none';
}
function openNewPriceProductRefPicker(){ renderNewPriceProductRefPicker(); }
function filterNewPriceProductRefPicker(){ renderNewPriceProductRefPicker(); }
function selectNewPriceProductRef(ref){
 const input=el('newPriceProductRef'); if(input){input.value=String(ref||'');input.focus();}
 renderNewPriceProductRefPicker();
}
async function addNewPriceProduct(e){
 e.preventDefault();
 const name=String(el('newPriceProductName')?.value||'').trim();
 const ref=String(el('newPriceProductRef')?.value||'').trim();
 const buy=Number(el('newPriceProductBuy')?.value||0);
 if(!name||!ref)return alert('أدخل اسم المنتوج ورقم المنتوج المرتبط');
 if(!Number.isFinite(buy)||buy<0)return alert('أدخل ثمن شراء صحيح');
 if(!Array.isArray(db.products))db.products=[];
 if(!db.priceRefs||typeof db.priceRefs!=='object'||Array.isArray(db.priceRefs))db.priceRefs={};
 if(!db.purchasePrices||typeof db.purchasePrices!=='object'||Array.isArray(db.purchasePrices))db.purchasePrices={};

 // الاسم هو هوية المنتوج: لا ننشئ منتوجًا ثانيًا لنفس الاسم.
 let product=db.products.find(p=>normalizeProductName(p.name)===normalizeProductName(name));
 const isNew=!product;
 if(isNew){
   const imageFile=el('priceProductImage')?.files?.[0];
   let image='';
   if(imageFile){
     try{image=await compressImage(imageFile);}catch(err){return alert('تعذر حفظ الصورة. جرّب صورة أصغر أو أعد اختيارها.');}
   }
   product={id:'prod_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),name:name,image,numbers:[ref]};
   db.products.push(product);
 }else{
   const refs=productNumbers(product);
   if(refs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()))return alert('هذا الرقم مسجل مسبقًا لهذا الاسم.');
   product.numbers=sortNumbersAscending([...refs,ref]);
 }

 const pid=String(product.id);
 if(!Array.isArray(db.priceRefs[pid]))db.priceRefs[pid]=[];
 if(db.priceRefs[pid].some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()))return alert('هذا الرقم لديه ثمن شراء مسجل بالفعل.');
 db.priceRefs[pid].push(ref);
 if(!db.purchasePrices[pid]||typeof db.purchasePrices[pid]!=='object'||Array.isArray(db.purchasePrices[pid]))db.purchasePrices[pid]={};
 db.purchasePrices[pid][ref.toLowerCase()]=buy;

 try{
   saveLocal();
   const stored=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
   const sp=(stored?.products||[]).find(p=>String(p.id)===String(product.id));
   const srefs=stored?.priceRefs?.[pid]||[];
   const sbuy=stored?.purchasePrices?.[pid]?.[ref.toLowerCase()];
   if(!sp || !srefs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase()) || Number(sbuy)!==Number(buy)) throw new Error('لم يتم تأكيد الحفظ');
 }catch(err){
   if(isNew) db.products=db.products.filter(p=>String(p.id)!==String(product.id));
   else if(product) product.numbers=productNumbers(product).filter(r=>String(r).trim().toLowerCase()!==ref.toLowerCase());
   if(db.priceRefs?.[pid]) db.priceRefs[pid]=db.priceRefs[pid].filter(r=>String(r).trim().toLowerCase()!==ref.toLowerCase());
   if(db.purchasePrices?.[pid]) delete db.purchasePrices[pid][ref.toLowerCase()];
   return alert('تعذر حفظ المنتوج في ذاكرة الهاتف. جرّب مرة أخرى.');
 }
 render();
 el('newPriceProductName').value='';el('newPriceProductRef').value='';el('newPriceProductBuy').value='';
 const img=el('priceProductImage');if(img)img.value='';
 const prev=el('priceProductImagePreview');if(prev){prev.innerHTML='';prev.style.display='none';}
}
function updatePriceOnly(productId,ref){
 const input=el('edit_price_'+String(productId)+'_'+encodeURIComponent(String(ref)).replace(/%/g,'_'));
 const buy=Number(input?.value);
 if(!input||!Number.isFinite(buy)||buy<0)return alert('أدخل ثمناً صحيحاً');
 if(!db.purchasePrices||typeof db.purchasePrices!=='object')db.purchasePrices={};
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!db.purchasePrices[key] || typeof db.purchasePrices[key]!=='object' || Array.isArray(db.purchasePrices[key])) db.purchasePrices[key]={};
 db.purchasePrices[key][refKey]=buy;
 syncStockPurchasePrices();
 if(!db.priceRefs||typeof db.priceRefs!=='object')db.priceRefs={};
 if(!Array.isArray(db.priceRefs[key]))db.priceRefs[key]=[];
 if(!db.priceRefs[key].some(r=>String(r).trim().toLowerCase()===refKey))db.priceRefs[key].push(ref);
 save();
}

function deletePriceOnly(productId,ref){
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!confirm('هل تريد حذف ثمن هذا الرقم؟'))return;
 if(db.priceRefs&&Array.isArray(db.priceRefs[key])){
   db.priceRefs[key]=db.priceRefs[key].filter(r=>String(r).trim().toLowerCase()!==refKey);
   if(!db.priceRefs[key].length)delete db.priceRefs[key];
 }
 if(db.purchasePrices&&db.purchasePrices[key]&&typeof db.purchasePrices[key]==='object'){
   delete db.purchasePrices[key][refKey];
   if(!Object.keys(db.purchasePrices[key]).length)delete db.purchasePrices[key];
 }
 const product=(db.products||[]).find(p=>String(p.id)===key);
 if(product&&Array.isArray(product.numbers)) product.numbers=product.numbers.filter(r=>String(r).trim().toLowerCase()!==refKey);
 syncStockPurchasePrices();
 save();
 renderProductSection();renderProductNamePicker();renderProductSearchResult();renderPrices();
}

let selectedPriceCardName = '';
function renderPriceCards(){
 const box=el('priceCardsList'); if(!box)return;
 const products=stockCatalogProducts();
 const groups=[];
 products.forEach(p=>{
   const refs=getPriceRefsForDisplay(p.id);
   if(!refs.length)return;
   groups.push({p,refs});
 });
 const qName=normalizeProductName(el('priceNameSearch')?.value||'');
 const qRef=String(el('priceNumberSearch')?.value||'').trim().toLowerCase();
 const filtered=groups.filter(g=>{
   const nameOk=!qName||normalizeProductName(g.p.name).includes(qName);
   const refOk=!qRef||g.refs.some(r=>String(r).toLowerCase().includes(qRef));
   return nameOk&&refOk;
 }).sort((a,b)=>compareNamesAZ(a.p.name,b.p.name));
 if(!filtered.length){box.innerHTML='<div class="empty card">لا توجد أسعار مسجلة</div>';return;}
 const visible=selectedPriceCardName ? filtered.filter(g=>String(g.p.name)===String(selectedPriceCardName)) : filtered;
 const backHtml=selectedPriceCardName ? '<button type="button" id="priceCardsBackButton" class="price-cards-back-btn" onclick="showAllPriceCards()">↩ الرجوع إلى البطاقات الأخرى</button>' : '';
 box.innerHTML=backHtml+visible.map((g,idx)=>{
   const refs=[...g.refs].sort((a,b)=>{
     const an=Number(String(a).replace(/[^0-9.-]/g,'')),bn=Number(String(b).replace(/[^0-9.-]/g,''));
     if(Number.isFinite(an)&&Number.isFinite(bn)&&an!==bn)return bn-an;
     return compareRefsDesc(a,b);
   });
   const image=g.p.image||'';
   const rows=refs.map(ref=>{
     const buy=getPurchasePriceForRef(g.p.id,ref);
     const inputId='edit_price_'+String(g.p.id)+'_'+encodeURIComponent(String(ref)).replace(/%/g,'_');
     return `<tr><td class="ref-cell">${esc(ref)}</td><td><input id="${inputId}" class="price-edit-input" type="number" min="0" step="0.01" value="${Number.isFinite(Number(buy))?Number(buy):0}"></td><td><button type="button" class="price-save-btn" title="تعديل الثمن" data-price-action="edit" data-product-id="${String(g.p.id).replace(/"/g,'&quot;')}" data-price-ref="${String(ref).replace(/"/g,'&quot;')}">✏️ تعديل</button><button type="button" class="price-save-btn danger" title="حذف" data-price-action="delete" data-product-id="${String(g.p.id).replace(/"/g,'&quot;')}" data-price-ref="${String(ref).replace(/"/g,'&quot;')}">🗑️ حذف</button></td></tr>`;
   }).join('');
   const encoded=encodeURIComponent(String(g.p.name));
   return `<div class="price-product-card price-color-${idx%10}" onclick="togglePriceCard('${encoded}')"><div class="price-card-head">${image?`<img class="price-card-image" src="${image}" alt="${esc(g.p.name)}">`:'<div class="price-card-image price-no-image">📦</div>'}<div class="price-card-info"><div class="price-card-name">${esc(g.p.name)}</div><div class="small">${refs.length} رقم مسجل</div><div class="price-card-refs"><b>الأرقام:</b> ${refs.map(r=>`<span class="price-ref-chip">${esc(r)}</span>`).join('')}</div></div><span class="price-card-arrow">▼</span></div><div id="price-details-${encoded}" class="price-card-details"><table class="price-card-table"><thead><tr><th>رقم المنتوج</th><th>الثمن</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
 }).join('');
 sortCardContainersAZ();
}
function togglePriceCard(encoded){
 const name=decodeURIComponent(encoded||'');
 if(!name)return;
 selectedPriceCardName=name;
 renderPriceCards();
 const box=el('price-details-'+encodeURIComponent(name));
 if(box){box.classList.add('open');const arrow=box.closest('.price-product-card')?.querySelector('.price-card-arrow');if(arrow)arrow.textContent='▲';}
}
function showAllPriceCards(){
 selectedPriceCardName='';
 renderPriceCards();
}

let selectedPriceBottomCardId = '';
function renderPriceBottomCards(){
 const body=el('pricesBottomCardsBody'); if(!body)return;
 // عند اختيار بطاقة: تظهر بطاقة واحدة فقط مع زر الرجوع.
 const products=Array.isArray(db.products)?db.products.filter(p=>String(p.name||'').trim()):[];
 const groups=products.map(p=>{
   const refs=new Set();
   getPriceOnlyRefs(p.id).forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   if(Array.isArray(p.numbers)) p.numbers.forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   const raw=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices[String(p.id)]:null;
   if(raw&&typeof raw==='object'&&!Array.isArray(raw)) Object.keys(raw).forEach(r=>{if(String(r).trim())refs.add(String(r).trim());});
   return {p,refs:sortNumbersAscending([...refs])};
 }).sort((a,b)=>compareNamesAZ(a.p.name,b.p.name));
 if(!groups.length){selectedPriceBottomCardId='';body.innerHTML='<div class="price-bottom-empty">لا توجد منتوجات مسجلة في قسم «تعريفة الشركات»</div>';return;}
 const visibleGroups=selectedPriceBottomCardId ? groups.filter(x=>String(x.p.id)===String(selectedPriceBottomCardId)) : groups;
 if(selectedPriceBottomCardId && !visibleGroups.length){selectedPriceBottomCardId='';}
 const list=selectedPriceBottomCardId ? groups.filter(x=>String(x.p.id)===String(selectedPriceBottomCardId)) : groups;
 const backHtml=selectedPriceBottomCardId ? '<button type="button" class="price-cards-back-btn" style="display:block;margin-bottom:12px" onclick="showAllPriceBottomCards()">↩ الرجوع إلى البطاقات الأخرى</button>' : '';
 body.innerHTML=backHtml+list.map((x,idx)=>{
   const p=x.p, refs=x.refs, encoded=encodeURIComponent(String(p.id));
   const img=p.image||'';
   const rows=refs.length?refs.map(ref=>{
     const buy=getPurchasePriceForRef(p.id,ref);
     return `<div class="price-bottom-details-row"><div class="price-bottom-details-ref">${esc(ref)}</div><div class="price-bottom-details-buy">${Number.isFinite(Number(buy))?money(buy):'-'}</div><div class="price-bottom-details-actions"><button type="button" class="price-save-btn" title="تعديل الثمن" data-price-bottom-action="edit" data-product-id="${String(p.id).replace(/"/g,'&quot;')}" data-price-ref="${String(ref).replace(/"/g,'&quot;')}">✏️</button><button type="button" class="price-save-btn danger" title="حذف" data-price-bottom-action="delete" data-product-id="${String(p.id).replace(/"/g,'&quot;')}" data-price-ref="${String(ref).replace(/"/g,'&quot;')}">🗑️</button></div></div>`;
   }).join(''):'<div class="price-bottom-empty">لا توجد أرقام مسجلة لهذا المنتوج</div>';
   const fullClass=selectedPriceBottomCardId?' price-card-fullscreen':''; const closeBtn=selectedPriceBottomCardId?'<button type="button" class="price-card-close-btn" aria-label="إغلاق" onclick="event.stopPropagation();showAllPriceBottomCards()">✕</button>':''; return `<div class="price-bottom-product-card price-color-${idx%10}${fullClass}" onclick="togglePriceBottomCard('${encoded}')">${closeBtn}<div class="price-bottom-product-head">${img?`<img class="price-bottom-product-image" src="${img}" alt="${esc(p.name)}">`:'<div class="price-bottom-product-image price-bottom-product-no-image">📦</div>'}<div class="price-bottom-product-info"><div class="price-bottom-product-name">${esc(p.name)}</div><div class="price-bottom-product-count">${refs.length} رقم مسجل</div></div></div><div id="price-bottom-details-${encoded}" class="price-bottom-product-details"><div class="price-bottom-details-row" style="font-weight:900;color:#0b4f8a;background:#eef7ff;border-radius:8px"><div>رقم المنتوج</div><div>ثمن الشراء</div><div></div></div>${rows}</div></div>`;
 }).join('');
 sortCardContainersAZ();
}
function togglePriceBottomCard(encoded){
 const id=decodeURIComponent(encoded||'');
 if(!id)return;
 selectedPriceBottomCardId=String(id);
 // عند اختيار بطاقة: أخفِ جميع البطاقات فوراً ثم أعد رسم القائمة ببطاقة واحدة فقط.
 const body=el('pricesBottomCardsBody');
 if(body){
   body.querySelectorAll('.price-bottom-product-card').forEach(card=>{card.style.display='none';});
 }
 renderPriceBottomCards();
 const selected=body?.querySelector('.price-bottom-product-card');
 if(selected){
   selected.style.display='block';
   selected.classList.add('price-card-fullscreen');
   const box=selected.querySelector('.price-bottom-product-details');
   if(box)box.classList.add('open');
   const arrow=selected.querySelector('.price-bottom-product-arrow');
   if(arrow)arrow.textContent='▲';
 }
}
function showAllPriceBottomCards(){
 selectedPriceBottomCardId='';
 const body=el('pricesBottomCardsBody');
 if(body)body.querySelectorAll('.price-bottom-product-card').forEach(card=>{card.style.display='';});
 renderPriceBottomCards();
}

function getPriceRefsForDisplay(productId){
 const refs=getPriceOnlyRefs(productId);
 const out=[...refs];
 const pp=db.purchasePrices&&typeof db.purchasePrices==='object'?db.purchasePrices:{};
 const raw=pp[String(productId)];
 if(raw&&typeof raw==='object'&&!Array.isArray(raw)) Object.keys(raw).forEach(ref=>{if(ref&&!out.some(x=>String(x).toLowerCase()===String(ref).toLowerCase()))out.push(ref);});
 return out.filter(Boolean);
}
function editBottomPrice(productId,ref){
 const current=getPurchasePriceForRef(productId,ref);
 const value=prompt('أدخل ثمن الشراء الجديد:',Number.isFinite(Number(current))?Number(current):'');
 if(value===null)return;
 const buy=Number(value);
 if(!Number.isFinite(buy)||buy<0)return alert('أدخل ثمناً صحيحاً');
 if(!db.purchasePrices||typeof db.purchasePrices!=='object')db.purchasePrices={};
 const key=String(productId), refKey=String(ref).trim().toLowerCase();
 if(!db.purchasePrices[key]||typeof db.purchasePrices[key]!=='object'||Array.isArray(db.purchasePrices[key]))db.purchasePrices[key]={};
 db.purchasePrices[key][refKey]=buy;
 save();
 renderPrices();
}

function renderPriceBottomTable(){
 const body=el('pricesBottomTableBody'); if(!body)return;
 const products=stockCatalogProducts(), groups=new Map();
 products.forEach(p=>{
   const refs=getPriceRefsForDisplay(p.id);
   refs.forEach(ref=>{
     const section=getPriceSection(p.id,ref)||'عام';
     if(!groups.has(section))groups.set(section,[]);
     groups.get(section).push({p:p,name:p.name||'',ref:String(ref||''),buy:getPurchasePriceForRef(p.id,ref)});
   });
 });
 const orderedSections=[...getPriceSections(),...groups.keys()].filter((x,i,a)=>a.indexOf(x)===i);
 const active=window.activePriceSection||'';
 let html='';
 orderedSections.filter(section=>!active||section===active).forEach(section=>{
   const rows=(groups.get(section)||[]).sort((a,b)=>compareNamesAZ(a.name,b.name)||compareRefsDesc(a.ref,b.ref));
   html+=`<tr><td colspan="5" style="padding:0;border:0"><div class="product-price-section"><div class="product-price-section-title">🗂️ ${esc(section)}</div>${rows.length?`<div class="price-table-wrap"><table class="price-table"><thead><tr><th>اسم المنتوج</th><th>رقم المنتوج</th><th>ثمنه</th><th></th></tr></thead><tbody>${rows.map(x=>`<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.ref||'-')}</td><td><b>${Number.isFinite(Number(x.buy))?money(x.buy):'-'}</b></td><td><button type="button" class="price-save-btn" onclick="event.stopPropagation();editBottomPrice(${JSON.stringify(String(x.p.id))},${JSON.stringify(String(x.ref))})">✏️ تعديل الثمن</button><button type="button" class="price-save-btn danger" onclick="event.stopPropagation();deletePriceOnly(${JSON.stringify(String(x.p.id))},${JSON.stringify(String(x.ref))})">🗑️ حذف</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="price-section-empty">لا توجد أسعار في هذا القسم</div>'}</div></td></tr>`;
 });
 body.innerHTML=html||'<tr><td colspan="5" class="empty">لا توجد أسعار مسجلة</td></tr>';
}

function renderPrices(){
 // عند فتح/إعادة رسم قسم الأسعار، أظهر جميع بطاقات المنتوجات كما كانت سابقاً.
 // لا نحذف البطاقات؛ فقط نعيد حالة العرض الافتراضية.
 selectedPriceCardName='';
 selectedPriceBottomCardId='';
 syncCatalogLinks();
 renderPriceProductNames();
 renderNewPriceProductNames();
 renderPriceNumberOptions();
 renderPriceCards();
 renderPriceBottomCards();
 updatePricePurchaseSearch();
 const nameInput=el('priceNameSearch'), numberInput=el('priceNumberSearch'), result=el('pricesResult');
 if(!nameInput||!numberInput||!result)return;
 const qName=normalizeProductName(nameInput.value||''), qNumber=String(numberInput.value||'').trim().toLowerCase();
 if(!qName && !qNumber){ result.innerHTML=''; return; }
 if(qName && !qNumber){ result.innerHTML='<div class="small">اختر رقم المنتوج لإظهار ثمنه.</div>'; return; }
 const products=stockCatalogProducts();
 const exactName=products.find(p=>normalizeProductName(p.name)===qName);
 const candidates=(exactName?[exactName]:products.filter(p=>normalizeProductName(p.name).includes(qName)));
 const product=candidates.find(p=>getPriceRefsForDisplay(p.id).some(r=>String(r).trim().toLowerCase()===qNumber));
 if(!product){ result.innerHTML='<div class="empty">لا توجد نتيجة مطابقة لهذا الاسم ورقم المنتوج.</div>'; return; }
 const ref=getPriceRefsForDisplay(product.id).find(r=>String(r).trim().toLowerCase()===qNumber)||qNumber;
 const buy=getPurchasePriceForRef(product.id,ref);
 result.innerHTML=`<div class="card price-result-card" style="text-align:center;margin-top:10px"><div class="small">${esc(product.name)} — ${esc(ref)}</div><div style="font-size:24px;font-weight:800;margin-top:6px">${money(buy)}</div></div>`;
}

function openPurchaseProductForm(mode){
 const form=el('purchaseProductForm'); if(!form)return;
 const existing=mode==='existing';
 // إغلاق نموذج إضافة الرقم للمنتوج المسجل قبل فتح نموذج الإضافة/التعديل.
 const registeredForm=el('purchaseRegisteredNumberForm');
 if(registeredForm){registeredForm.style.display='none';registeredForm.hidden=true;}
 el('purchaseProductMode').value=existing?'existing':'new';
 form.style.display='block';
 form.hidden=false;
 const wrap=el('purchaseExistingWrap'); if(wrap)wrap.style.display=existing?'block':'none';
 const refWrap=el('purchaseExistingRefWrap'); if(refWrap)refWrap.style.display=existing?'block':'none';
 const sel=el('purchaseExistingProduct'), refSel=el('purchaseExistingRef');
 if(existing){
   const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
   if(sel)sel.innerHTML=products.length?'<option value="">اختر اسم المنتوج</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name)}</option>`).join(''):'<option value="">لا توجد منتوجات مسجلة</option>';
   if(refSel)refSel.innerHTML='<option value="">اختر الرقم الذي تريد تعديله</option>';
 }else{
   if(sel)sel.innerHTML='';
   if(refSel)refSel.innerHTML='';
 }
 if(el('purchaseExistingOriginalRef'))el('purchaseExistingOriginalRef').value='';
 el('purchaseMasterName').value=''; el('purchaseMasterRef').value=''; el('purchaseMasterBuy').value='';
 const img=el('purchaseMasterImage'); if(img)img.value='';
 const prev=el('purchaseMasterImagePreview'); if(prev){prev.innerHTML='';prev.style.display='none';}
}
function closePurchaseProductForm(){
 const f=el('purchaseProductForm');
 if(f){f.style.display='none';f.hidden=true;}
}
function loadMasterProductToForm(){
 const id=el('purchaseExistingProduct')?.value; const p=getCatalogProduct(id);
 const refSel=el('purchaseExistingRef');
 if(refSel){
   const refs=p?sortNumbersAscending([...(productNumbers(p)||[]), ...((db.priceRefs&&db.priceRefs[String(p.id)])||[])]):[];
   const unique=[...new Map(refs.map(r=>[String(r).trim().toLowerCase(),String(r).trim()])).values()];
   refSel.innerHTML=unique.length?'<option value="">اختر الرقم الذي تريد تعديله</option>'+unique.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join(''):'<option value="">لا توجد أرقام مسجلة لهذا المنتوج</option>';
 }
 if(el('purchaseExistingOriginalRef'))el('purchaseExistingOriginalRef').value='';
 el('purchaseMasterRef').value='';
 el('purchaseMasterBuy').value='';
 if(!p)return;
 el('purchaseMasterName').value=p.name||'';
 const prev=el('purchaseMasterImagePreview');
 if(prev){prev.innerHTML=p.image?`<img class="master-product-image" src="${p.image}" alt="${esc(p.name)}">`:'';prev.style.display=p.image?'block':'none';}
}
function loadMasterProductRefToForm(){
 const id=el('purchaseExistingProduct')?.value;
 const ref=String(el('purchaseExistingRef')?.value||'').trim();
 const p=getCatalogProduct(id);
 if(!p||!ref){if(el('purchaseExistingOriginalRef'))el('purchaseExistingOriginalRef').value='';el('purchaseMasterRef').value='';el('purchaseMasterBuy').value='';return;}
 const refs=[...(productNumbers(p)||[]),...((db.priceRefs&&db.priceRefs[String(p.id)])||[])];
 const canonical=refs.find(r=>String(r).trim().toLowerCase()===ref.toLowerCase())||ref;
 if(el('purchaseExistingOriginalRef'))el('purchaseExistingOriginalRef').value=canonical;
 el('purchaseMasterRef').value=canonical;
 const pp=(db.purchasePrices&&db.purchasePrices[String(p.id)])||{};
 const raw=pp[String(canonical).toLowerCase()];
 el('purchaseMasterBuy').value=Number.isFinite(Number(raw))?Number(raw):'';
}
function propagateMasterIdentity(product){
 const pid=String(product.id), name=product.name||'', image=product.image||'';
 (db.stock||[]).forEach(st=>{if(String(st.productId)===pid){st.name=name;st.image=image;}});
 (db.sales||[]).forEach(s=>(s.items||[]).forEach(it=>{if(String(it.productId)===pid){it.name=name;if(image)it.image=image;}}));
 (db.deliveryDocs||[]).forEach(d=>(d.items||[]).forEach(it=>{if(String(it.productId)===pid){it.name=name;if(image)it.image=image;}}));
}
async function saveMasterProduct(e){
 e.preventDefault();
 const mode=el('purchaseProductMode')?.value||'new';
 const name=String(el('purchaseMasterName')?.value||'').trim();
 const ref=String(el('purchaseMasterRef')?.value||'').trim();
 const buyText=String(el('purchaseMasterBuy')?.value||'').trim();
 if(!name)return alert('أدخل اسم المنتوج');
 if(!Array.isArray(db.products))db.products=[];
 if(!db.purchasePrices||typeof db.purchasePrices!=='object'||Array.isArray(db.purchasePrices))db.purchasePrices={};
 let product=null;
 if(mode==='existing'){
   const id=el('purchaseExistingProduct')?.value;
   product=getCatalogProduct(id);
   if(!product)return alert('اختر منتوجًا مسجلًا');
   const duplicate=db.products.find(p=>String(p.id)!==String(product.id)&&normalizeProductName(p.name)===normalizeProductName(name));
   if(duplicate)return alert('اسم المنتوج موجود بالفعل. اختر اسمًا آخر.');
   const oldRef=String(el('purchaseExistingOriginalRef')?.value||'').trim();
   const newRef=String(ref||'').trim();
   if(oldRef && newRef){
     const sameOld=oldRef.toLowerCase()===newRef.toLowerCase();
     if(!sameOld){
       if(!Array.isArray(product.numbers))product.numbers=[];
       const idx=product.numbers.findIndex(r=>String(r).trim().toLowerCase()===oldRef.toLowerCase());
       if(idx>=0)product.numbers[idx]=newRef; else product.numbers.push(newRef);
       const pp=db.purchasePrices[String(product.id)]&&typeof db.purchasePrices[String(product.id)]==='object'?db.purchasePrices[String(product.id)]:{};
       const oldKey=oldRef.toLowerCase(), newKey=newRef.toLowerCase();
       if(pp[oldKey]!==undefined && pp[newKey]===undefined)pp[newKey]=pp[oldKey];
       delete pp[oldKey];
       db.purchasePrices[String(product.id)]=pp;
       product.numbers=sortNumbersAscending(product.numbers);
       if(Array.isArray(db.stock))db.stock.forEach(st=>{if(String(st.productId)===String(product.id)&&String(st.ref||'').trim().toLowerCase()===oldRef.toLowerCase())st.ref=newRef;});
     }
   }
   product.name=name;
 }else{
   if(!ref)return alert('أدخل رقم المنتوج');
   if(!buyText || !Number.isFinite(Number(buyText)) || Number(buyText)<0)return alert('أدخل ثمن شراء صحيح');
   if(db.products.some(p=>normalizeProductName(p.name)===normalizeProductName(name)))return alert('اسم المنتوج موجود بالفعل. استخدم «منتوج مسجل» لإضافة رقم أو تعديل البيانات.');
   let image=''; const file=el('purchaseMasterImage')?.files?.[0];
   if(file){try{image=await compressImage(file);}catch(err){return alert('تعذر حفظ الصورة.');}}
   product={id:'prod_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),name,image,numbers:[ref]};
   db.products.push(product);
 }
 const file=el('purchaseMasterImage')?.files?.[0];
 if(file){try{product.image=await compressImage(file);}catch(err){return alert('تعذر حفظ الصورة.');}}
 if(!Array.isArray(product.numbers))product.numbers=[];
 if(ref){
   const existingRef=product.numbers.find(r=>String(r).trim().toLowerCase()===ref.toLowerCase());
   if(!existingRef)product.numbers.push(ref);
   product.numbers=sortNumbersAscending(product.numbers);
   if(!db.purchasePrices[String(product.id)]||typeof db.purchasePrices[String(product.id)]!=='object'||Array.isArray(db.purchasePrices[String(product.id)]))db.purchasePrices[String(product.id)]={};
   if(buyText!=='')db.purchasePrices[String(product.id)][ref.toLowerCase()]=Number(buyText);
 }
 // إذا كان المنتوج جديدًا، احفظ ثمن الرقم الأول.
 if(mode==='new' && ref && !db.purchasePrices[String(product.id)])db.purchasePrices[String(product.id)]={[ref.toLowerCase()]:Number(buyText)};
 propagateMasterIdentity(product);
 save();
 closePurchaseProductForm();
 render();
 alert(mode==='new'?'تم إنشاء المنتوج وحفظ الاسم والرقم والصورة وثمن الشراء.':'تم تحديث بيانات المنتوج من المصدر الرئيسي.');
}
function editMasterProductName(productId){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 if(!p)return;
 const oldName=String(p.name||'');
 const name=prompt('اسم المنتوج:',oldName);
 if(name===null)return;
 const cleanName=name.trim();
 if(!cleanName)return alert('أدخل اسم المنتوج');
 const duplicate=(db.products||[]).some(x=>String(x.id)!==String(productId)&&normalizeProductName(x.name)===normalizeProductName(cleanName));
 if(duplicate)return alert('اسم المنتوج موجود بالفعل');
 p.name=cleanName;
 propagateMasterIdentity(p);
 (db.companyPrices||[]).forEach(x=>{
   if(String(x.productId)===String(productId))x.productName=cleanName;
 });
 save();
 renderMasterProductSearchOptions();
 renderMasterProductSearchRefs();
 renderMasterProductsTable();
 alert('تم تعديل اسم المنتوج بنجاح');
}
function editMasterProductRef(productId,ref){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 if(!p)return;
 const oldRef=String(ref||'').trim();
 const current=productNumbers(p);
 if(!current.some(r=>String(r).trim().toLowerCase()===oldRef.toLowerCase()))return;
 const newRef=prompt('الرقم الجديد:',oldRef);
 if(newRef===null)return;
 const cleanRef=newRef.trim();
 if(!cleanRef)return alert('أدخل الرقم الجديد');
 if(current.some(r=>String(r).trim().toLowerCase()===cleanRef.toLowerCase() && String(r).trim().toLowerCase()!==oldRef.toLowerCase()))
   return alert('هذا الرقم مسجل مسبقاً لهذا المنتوج.');

 p.numbers=current.map(r=>String(r).trim().toLowerCase()===oldRef.toLowerCase()?cleanRef:r);
 p.numbers=sortNumbersAscending(p.numbers);

 // نقل بيانات السعر الخاصة بالرقم القديم إلى الرقم الجديد.
 const pid=String(productId), oldKey=oldRef.toLowerCase(), newKey=cleanRef.toLowerCase();
 if(db.purchasePrices&&db.purchasePrices[pid]&&Object.prototype.hasOwnProperty.call(db.purchasePrices[pid],oldKey)){
   db.purchasePrices[pid][newKey]=db.purchasePrices[pid][oldKey];
   delete db.purchasePrices[pid][oldKey];
 }
 if(db.priceRefs&&Array.isArray(db.priceRefs[pid])){
   db.priceRefs[pid]=db.priceRefs[pid].map(r=>String(r).trim().toLowerCase()===oldKey?cleanRef:r);
 }
 (db.companyPrices||[]).forEach(x=>{
   if(String(x.productId)===pid && String(x.ref||'').trim().toLowerCase()===oldKey)x.ref=cleanRef;
 });
 (db.stock||[]).forEach(st=>{
   if(String(st.productId)===pid && String(st.ref||'').trim().toLowerCase()===oldKey)st.ref=cleanRef;
 });
 (db.sales||[]).forEach(s=>(s.items||[]).forEach(it=>{
   if(String(it.productId)===pid && String(it.ref||'').trim().toLowerCase()===oldKey)it.ref=cleanRef;
 }));
 (db.deliveryDocs||[]).forEach(d=>(d.items||[]).forEach(it=>{
   if(String(it.productId)===pid && String(it.ref||'').trim().toLowerCase()===oldKey)it.ref=cleanRef;
 }));

 save();
 render();
 renderMasterProductSearchOptions();
 renderMasterProductSearchRefs();
 renderMasterProductsTable();
 alert('تم تعديل رقم المنتوج بنجاح');
}
function editMasterProductImage(productId){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 if(!p)return;
 let input=document.getElementById('masterProductImageEditInput');
 if(!input){
   input=document.createElement('input');
   input.type='file';
   input.id='masterProductImageEditInput';
   input.accept='image/*';
   input.style.display='none';
   document.body.appendChild(input);
 }
 input.value='';
 input.onchange=async function(){
   const file=input.files&&input.files[0];
   if(!file)return;
   if(!file.type || !file.type.startsWith('image/')){input.value='';return alert('اختر صورة فقط.');}
   try{
     const image=await compressImage(file);
     if(!image)throw new Error('الصورة فارغة');
     p.image=image;
     propagateMasterIdentity(p);
     save();
     render();
     renderMasterProductSearchOptions();
     renderMasterProductSearchRefs();
     renderMasterProductsTable();
     if(typeof renderCompanyPricesTable==='function')renderCompanyPricesTable();
     alert('تم تعديل صورة المنتوج بنجاح');
   }catch(err){
     alert('تعذر تعديل الصورة. جرّب صورة أخرى.');
   }finally{input.value='';}
 };
 input.click();
}
function addMasterProductNumber(productId){
 const p=(db.products||[]).find(x=>String(x.id)===String(productId));
 if(!p)return;
 const ref=prompt('أدخل الرقم الجديد:');
 if(ref===null)return;
 const cleanRef=ref.trim();
 if(!cleanRef)return alert('أدخل الرقم الجديد');
 if(productNumbers(p).some(r=>String(r).trim().toLowerCase()===cleanRef.toLowerCase()))
   return alert('هذا الرقم مسجل مسبقاً لهذا المنتوج.');
 p.numbers=sortNumbersAscending([...(p.numbers||[]),cleanRef]);
 save();
 render();
 renderMasterProductSearchOptions();
 renderMasterProductSearchRefs();
 renderMasterProductsTable();
 alert('تمت إضافة الرقم بنجاح');
}
function togglePurchaseCleanCard(encoded){
 const box=el('purchase-clean-details-'+encoded);
 const card=box?.closest('.purchase-clean-card');
 if(box)box.classList.toggle('open');
 if(card)card.classList.toggle('open');
}
function renderPurchasePriceNamePicker(filter=true){
 const box=el('purchasePriceNamePicker'); if(!box)return;
 const q=filter?normalizeProductName(el('purchasePriceNameSearch')?.value||''):'';
 const names=[...new Map((db.products||[]).map(p=>[normalizeProductName(p.name),p.name])).values()].sort((a,b)=>compareNamesAZ(a,b));
 const rows=names.filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=rows.length?rows.map(n=>`<button type="button" class="search-picker-item" data-name="${esc(n)}">${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء مطابقة</div>';
}
function openPurchasePriceNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('purchasePriceNameSearch');
 const arrowPressed=!!(e?.target?.closest?.('#purchasePriceNameArrow')); renderPurchasePriceNamePicker(!arrowPressed && Boolean(input?.value));
 const box=el('purchasePriceNamePicker'); if(box)box.style.display='block';
 if(input){input.focus({preventScroll:true});input.closest('.search-picker-wrap')?.classList.add('purchase-search-field-active');}
}
function filterPurchasePriceNamePicker(){
 renderPurchasePriceNamePicker(true);
 const box=el('purchasePriceNamePicker'); if(box)box.style.display='block';
 const refInput=el('purchasePriceRefSearch');
 if(refInput && !String(el('purchasePriceNameSearch')?.value||'').trim())refInput.value='';
 renderPurchasePriceSection();
}
function selectPurchasePriceName(name){
 const input=el('purchasePriceNameSearch'); if(input)input.value=String(name||'');
 const box=el('purchasePriceNamePicker'); if(box)box.style.display='none';
 input?.closest('.search-picker-wrap')?.classList.remove('purchase-search-field-active');
 if(el('purchasePriceRefSearch'))el('purchasePriceRefSearch').value='';
 renderPurchasePriceRefPicker(false);
 renderPurchasePriceSection();
 const refInput=el('purchasePriceRefSearch');
 if(refInput){refInput.focus({preventScroll:true});openPurchasePriceRefPicker();}
}
function getPurchasePriceRefs(){
 const nameQ=normalizeProductName(el('purchasePriceNameSearch')?.value||'');
 let refs=[];
 (db.products||[]).filter(p=>!nameQ||normalizeProductName(p.name).includes(nameQ)).forEach(p=>refs.push(...productNumbers(p)));
 return [...new Set(refs.map(r=>String(r).trim()).filter(Boolean))].sort((a,b)=>compareRefsDesc(b,a));
}
function renderPurchasePriceRefPicker(filter=true){
 const box=el('purchasePriceRefPicker'); if(!box)return;
 const nameQ=normalizeProductName(el('purchasePriceNameSearch')?.value||'');
 const q=filter?String(el('purchasePriceRefSearch')?.value||'').trim().toLowerCase():'';
 if(!nameQ){
   box.innerHTML='<div class="search-picker-empty">اختر أو اكتب اسم المنتوج أولاً</div>';
   return;
 }
 const refs=getPurchasePriceRefs().filter(r=>!q||String(r).toLowerCase().includes(q));
 box.innerHTML=refs.length?refs.map(r=>`<button type="button" class="search-picker-item" data-ref="${esc(r)}">${esc(r)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أرقام مطابقة</div>';
}
function openPurchasePriceRefPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('purchasePriceRefSearch');
 if(!normalizeProductName(el('purchasePriceNameSearch')?.value||'')){
   const nameInput=el('purchasePriceNameSearch');
   if(nameInput)nameInput.focus({preventScroll:true});
   renderPurchasePriceRefPicker(false);
 }else{
   const arrowPressed=!!(e?.target?.closest?.('#purchasePriceRefArrow')); renderPurchasePriceRefPicker(!arrowPressed && Boolean(input?.value));
 }
 const box=el('purchasePriceRefPicker'); if(box)box.style.display='block';
 input?.closest('.search-picker-wrap')?.classList.add('purchase-search-field-active');
}
function filterPurchasePriceRefPicker(){
 renderPurchasePriceRefPicker(true);
 const box=el('purchasePriceRefPicker'); if(box)box.style.display='block';
 renderPurchasePriceSection();
}
function selectPurchasePriceRef(ref){
 const input=el('purchasePriceRefSearch'); if(input)input.value=String(ref||'');
 const box=el('purchasePriceRefPicker'); if(box)box.style.display='none';
 input?.closest('.search-picker-wrap')?.classList.remove('purchase-search-field-active');
 renderPurchasePriceSection();
}
document.addEventListener('click',function(e){
 const nameOpt=e.target.closest('#purchasePriceNamePicker [data-name]');
 if(nameOpt){
   e.preventDefault();e.stopPropagation();
   selectPurchasePriceName(nameOpt.getAttribute('data-name')||'');
   return;
 }
 const refOpt=e.target.closest('#purchasePriceRefPicker [data-ref]');
 if(refOpt){
   e.preventDefault();e.stopPropagation();
   selectPurchasePriceRef(refOpt.getAttribute('data-ref')||'');
 }
});

let selectedPurchaseProductCardName = '';
function renderPurchaseProductCardsStats(products){
 const box=el('purchaseProductCardsStats'); if(!box)return;
 const list=Array.isArray(products)?products:[];
 let refs=0, priced=0;
 list.forEach(p=>{
   const nums=typeof productNumbers==='function'?productNumbers(p):[];
   refs+=nums.length;
   const pp=(db.purchasePrices&&db.purchasePrices[String(p.id)]&&typeof db.purchasePrices[String(p.id)]==='object')?db.purchasePrices[String(p.id)]:{};
   nums.forEach(r=>{if(Number.isFinite(Number(pp[String(r).toLowerCase()])))priced++;});
 });
 box.innerHTML=`<div class="purchase-price-stat"><span>الأرقام</span><b>${refs}</b></div>`;
}

function renderPurchaseProductCards(){
 const box=el('purchaseProductCardsGrid'); if(!box)return;
 const products=Array.isArray(db.products)?db.products:[];
 renderPurchaseProductCardsStats(products);
 if(!products.length){selectedPurchaseProductCardName='';box.innerHTML='<div class="empty card" style="grid-column:1/-1">لا توجد منتوجات مسجلة</div>';return;}
 const groups=[]; const seen=new Set();
 products.forEach(p=>{
   const name=String(p.name||'بدون اسم').trim()||'بدون اسم';
   const key=normalizeProductName(name)||name.toLowerCase();
   if(seen.has(key))return;
   seen.add(key);
   const members=products.filter(x=>{
     const n=String(x.name||'بدون اسم').trim()||'بدون اسم';
     return (normalizeProductName(n)||n.toLowerCase())===key;
   });
   groups.push({key,name,product:members[0],members});
 });
 // ترتيب بطاقات المنتوجات حسب عدد الأرقام: الأكثر أرقامًا في الأعلى.
 groups.sort((a,b)=>compareNamesAZ(a.name,b.name));
 if(selectedPurchaseProductCardName && !groups.some(g=>g.key===selectedPurchaseProductCardName))selectedPurchaseProductCardName='';
 const list=selectedPurchaseProductCardName?groups.filter(g=>g.key===selectedPurchaseProductCardName):groups;
 const back=selectedPurchaseProductCardName
   ? '<button type="button" class="purchase-cards-back-btn" style="display:block;grid-column:1/-1" onclick="event.stopPropagation();showAllPurchaseProductCards()">↩ الرجوع إلى جميع البطاقات</button>'
   : '';
 box.innerHTML=back+list.map((g,idx)=>{
   const p=g.product;
   const details=[];
   g.members.forEach(member=>{
     const refs=typeof productNumbers==='function'?sortNumbersAscending(productNumbers(member)):[];
     refs.forEach(ref=>{
       const refKey=String(ref).trim().toLowerCase();
       const companyRows=(db.companyPrices||[]).filter(x=>String(x.productId)===String(member.id)&&String(x.ref||'').trim().toLowerCase()===refKey);
       if(companyRows.length){
         companyRows.sort((a,b)=>compareNamesAZ(a.company,b.company));
         companyRows.forEach(x=>{
           const v=Number(x.price);
           details.push({ref:String(ref),company:String(x.company||'غير محددة'),price:Number.isFinite(v)&&v>=0?v:null});
         });
       }else{
         const pp=(db.purchasePrices&&db.purchasePrices[String(member.id)]&&typeof db.purchasePrices[String(member.id)]==='object')?db.purchasePrices[String(member.id)]:{};
         const v=Number(pp[refKey]);
         details.push({ref:String(ref),company:'غير مسجلة',price:Number.isFinite(v)&&v>=0?v:null});
       }
     });
   });
   const image=p.image||p.imageData||p.photo||'';
   const img=image?`<img class="purchase-product-card-img" src="${esc(image)}" alt="">`:'<div class="purchase-product-card-noimg">📦</div>';
   const detailRows=details.length
     ? `<div class="purchase-product-card-details-title purchase-company-details-title"><span>رقم المنتج</span><span>الشركة</span><span>ثمن الشراء</span></div>`+
       details.map(d=>`<div class="purchase-product-card-row purchase-company-card-row"><span class="purchase-product-card-ref">${esc(d.ref)}</span><span class="purchase-product-card-company">${esc(d.company)}</span><b class="purchase-product-card-price">${d.price===null?'غير مسجل':money(d.price)}</b></div>`).join('')
     : '<div class="purchase-product-card-row"><span>الأرقام المسجلة</span><b>لا توجد أرقام مسجلة</b></div>';
   const summary=`<div class="purchase-product-card-row"><span>عدد الأرقام</span><b>${details.length}</b></div>`+
                 `<div class="purchase-product-card-hint">اضغط على البطاقة لعرض جميع الأرقام والأثمان</div>`;
   const body=selectedPurchaseProductCardName
     ? `<div class="purchase-product-card-body"><div class="purchase-product-card-details-title"><span>${esc(g.name)}</span><span>التفاصيل</span></div>${detailRows}</div>`
     : `<div class="purchase-product-card-body">${summary}</div>`;
   const cardKey=String(g.key);
   return `<article class="purchase-product-card${selectedPurchaseProductCardName===g.key ? ' open' : ''}" role="button" tabindex="0" data-purchase-card="${esc(cardKey)}" aria-label="فتح تفاصيل ${esc(g.name)}">
      ${selectedPurchaseProductCardName===g.key ? '<button type="button" class="purchase-product-card-close" aria-label="إغلاق" onclick="event.preventDefault();event.stopPropagation();showAllPurchaseProductCards()">✕</button>' : ''}
      <div class="purchase-product-card-head">${img}<div class="purchase-product-card-name">${esc(g.name)}</div><span class="purchase-product-card-arrow">▼</span></div>
      ${body}
    </article>`;
 }).join('');
 sortCardContainersAZ();
}
function selectPurchaseProductCard(name){
 selectedPurchaseProductCardName=String(name||'');
 renderPurchaseProductCards();
 const box=el('purchaseProductCardsGrid');
 if(box){const card=box.querySelector('.purchase-product-card'); if(card)card.scrollIntoView({behavior:'auto',block:'nearest'});}
}
// فتح بطاقة المنتوج عبر نقرة مؤكدة فقط: السحب/التمرير لا يفتح البطاقة.
if(!window.__purchaseProductCardsTapBound){
 window.__purchaseProductCardsTapBound=true;
 let purchaseCardPointer=null;
 const getPurchaseCard=function(target){
   return target&&target.closest?target.closest('#purchaseProductCardsGrid .purchase-product-card[data-purchase-card]'):null;
 };
 const isInteractivePurchaseTarget=function(target){
   return !!(target&&target.closest&&target.closest('button, input, select, textarea, a, [role=button]') &&
     !target.closest('.purchase-product-card-head'));
 };
 document.addEventListener('pointerdown',function(e){
   const card=getPurchaseCard(e.target);
   if(!card){purchaseCardPointer=null;return;}
   purchaseCardPointer={card,startX:e.clientX,startY:e.clientY,moved:false};
 },true);
 document.addEventListener('pointermove',function(e){
   const t=purchaseCardPointer;
   if(!t)return;
   const dx=e.clientX-t.startX,dy=e.clientY-t.startY;
   if((dx*dx+dy*dy)>144)t.moved=true;
 },true);
 document.addEventListener('pointercancel',function(){
   if(purchaseCardPointer)purchaseCardPointer.moved=true;
 },true);
 document.addEventListener('pointerup',function(e){
   if(purchaseCardPointer && purchaseCardPointer.card===getPurchaseCard(e.target)){
     purchaseCardPointer.lastUpMoved=purchaseCardPointer.moved;
   }
 },true);
 document.addEventListener('click',function(e){
   const card=getPurchaseCard(e.target);
   const t=purchaseCardPointer;
   if(!card||!t||t.card!==card)return;
   const moved=!!t.moved || !!t.lastUpMoved;
   purchaseCardPointer=null;
   // أزرار البطاقة وحقولها تبقى مستقلة ولا تفتح البطاقة.
   if(isInteractivePurchaseTarget(e.target))return;
   if(moved){e.preventDefault();e.stopImmediatePropagation();return;}
   const key=card.getAttribute('data-purchase-card')||'';
   if(!key)return;
   e.preventDefault();
   e.stopImmediatePropagation();
   selectPurchaseProductCard(key);
 },true);
}
function showAllPurchaseProductCards(){
 selectedPurchaseProductCardName='';
 renderPurchaseProductCards();
}

function renderPurchasePriceForm(){
 const companySel=el('purchasePriceCompany'), productSel=el('purchasePriceProduct'), refSel=el('purchasePriceRef');
 if(companySel){
   const current=companySel.value;
   const names=[...new Set([...(db.companies||[]).map(c=>String(c?.name||c||'').trim()),...(db.companyPrices||[]).map(x=>String(x.company||'').trim())].filter(Boolean))].sort((a,b)=>compareNamesAZ(a,b));
   companySel.innerHTML='<option value="">اختر الشركة</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');
   if(names.includes(current))companySel.value=current;
 }
 if(productSel){
   const current=productSel.value;
   const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
   productSel.innerHTML='<option value="">اختر اسم المنتوج المسجل</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join('');
   if(products.some(p=>String(p.id)===String(current)))productSel.value=current;
 }
 renderPurchasePriceFormRefs();
}
function renderPurchasePriceFormRefs(){
 const productSel=el('purchasePriceProduct'), refSel=el('purchasePriceRef'); if(!refSel)return;
 const p=(db.products||[]).find(x=>String(x.id)===String(productSel?.value||''));
 const current=refSel.value; const refs=p?productNumbers(p):[];
 refSel.innerHTML='<option value="">اختر رقم المنتوج المسجل</option>'+refs.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
 if(refs.includes(current))refSel.value=current;
}

function renderPurchasePriceSection(){
 const hiddenBox=el('purchasePricesList'); if(hiddenBox)hiddenBox.innerHTML='';
 renderPurchaseProductCards();
 const resultBox=el('purchasePriceSearchResult'); if(!resultBox)return;
 const nameQ=normalizeProductName(el('purchasePriceNameSearch')?.value||'');
 const refQ=String(el('purchasePriceRefSearch')?.value||'').trim().toLowerCase();
 if(!nameQ){
   resultBox.innerHTML='<div class="price-search-hint">🔎 ابدأ بكتابة أو اختيار اسم المنتوج.</div>';
   return;
 }
 const products=(db.products||[]).filter(p=>normalizeProductName(p.name).includes(nameQ));
 if(!products.length){
   resultBox.innerHTML='<div class="empty card" style="margin-top:10px">لا يوجد منتوج بهذا الاسم.</div>';
   return;
 }
 if(!refQ){
   resultBox.innerHTML='<div class="price-search-hint">✅ تم اختيار اسم المنتوج. الآن اكتب أو اختر الرقم/المرجع لإظهار أسعار الشركات.</div>';
   return;
 }
 const matches=[];
 products.forEach(p=>{
   const refs=productNumbers(p);
   refs.forEach(ref=>{
     if(!String(ref).trim().toLowerCase().includes(refQ))return;
     const rows=(db.companyPrices||[]).filter(x=>String(x.productId)===String(p.id)&&String(x.ref||'').trim().toLowerCase()===String(ref).trim().toLowerCase());
     rows.forEach(x=>matches.push({product:p,ref:String(ref),company:String(x.company||'غير محددة'),quality:String(x.quality||'غير محددة'),price:Number(x.price)}));
   });
 });
 if(!matches.length){
   resultBox.innerHTML='<div class="empty card" style="margin-top:10px">لا يوجد سعر شركة مسجل لهذا الاسم والرقم.</div>';
   return;
 }
 matches.sort((a,b)=>compareNamesAZ(a.company,b.company));
 const first=matches[0];
 const rows=matches.map(item=>{
   const valid=Number.isFinite(item.price)&&item.price>=0;
   return `<div class="price-search-company-row"><span>الشركة</span><b>${esc(item.company)}</b><span>الجودة</span><b>${esc(item.quality)}</b><span>الثمن</span><b class="price-search-result-price">${valid?money(item.price):'غير مسجل'}</b></div>`;
 }).join('');
 resultBox.innerHTML=`<div class="price-search-result-card"><div class="price-search-result-name">🔎 ${esc(first.product.name)} — ${esc(first.ref)}</div><div class="price-search-company-title">أسعار الشركات المسجلة</div>${rows}</div>`;
}
function savePurchasePriceFromSection(productId,ref){
 const iid='purchase_buy_'+String(productId)+'_'+encodeURIComponent(String(ref)).replace(/%/g,'_');
 const input=el(iid); const buy=Number(input?.value);
 if(!Number.isFinite(buy)||buy<0)return alert('ثمن الشراء غير صحيح');
 const p=getCatalogProduct(productId); if(!p)return alert('المنتوج غير موجود في المصدر الرئيسي');
 const canonical=productNumbers(p).find(r=>String(r).trim().toLowerCase()===String(ref).trim().toLowerCase());
 if(!canonical)return alert('هذا الرقم غير مسجل في المصدر الرئيسي');
 if(!db.purchasePrices||typeof db.purchasePrices!=='object'||Array.isArray(db.purchasePrices))db.purchasePrices={};
 const key=String(productId); if(!db.purchasePrices[key]||typeof db.purchasePrices[key]!=='object'||Array.isArray(db.purchasePrices[key]))db.purchasePrices[key]={};
 db.purchasePrices[key][canonical.toLowerCase()]=buy;
 syncStockPurchasePrices(); save(); alert('تم حفظ ثمن الشراء');
}


function renderMasterProductOptions(){
 const sel=el('companyPriceProduct'); if(!sel)return;
 const current=sel.value;
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 sel.innerHTML='<option value="">اختر المنتوج</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join('');
 if(products.some(p=>String(p.id)===String(current)))sel.value=current;
 renderCompanyPriceRefOptions();
}
function renderCompanyPriceRefOptions(){
 const sel=el('companyPriceRef'),pid=el('companyPriceProduct')?.value; if(!sel)return;
 const p=(db.products||[]).find(x=>String(x.id)===String(pid));
 const current=sel.value; const refs=p?productNumbers(p):[];
 sel.innerHTML='<option value="">اختر رقم المنتوج</option>'+refs.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
 if(refs.includes(current))sel.value=current;
}
function renderCompanyNames(){
 const companyMaster=[...(db.companies||[]).map(x=>String(x?.name||x||'').trim()),...(db.companyPrices||[]).map(x=>String(x?.company||'').trim())];
 const names=[...new Set(companyMaster.filter(Boolean))].sort((a,b)=>compareNamesAZ(a,b));
 const sels=[el('companyPriceCompany'),el('purchasePriceCompany')].filter(Boolean);
 sels.forEach(sel=>{const current=sel.value||'';sel.innerHTML='<option value="">اختر الشركة</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');if(names.includes(current))sel.value=current;});
 const list=el('companyNamesList'); if(list)list.innerHTML=names.map(n=>`<option value="${esc(n)}"></option>`).join('');
 const chips=el('registeredCompanies'); if(chips)chips.innerHTML=names.length?names.map(n=>`<span class="company-registered-chip">🏢 ${esc(n)}</span>`).join(''):'<span class="small">لا توجد شركات مسجلة بعد.</span>';
 const checkBeneficiary=el('checkBeneficiary');
 if(checkBeneficiary){
   const current=String(checkBeneficiary.value||'').trim();
   checkBeneficiary.innerHTML='<option value="">اختر الشركة من «تعريفة الشركات» ⬇️</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');
   if(names.includes(current))checkBeneficiary.value=current;
 }
 renderCompanyPriceSearchOptions();
}

function addCompany(){
 const input=el('newCompanyName');
 const name=String(input?.value||'').trim();
 if(!name)return alert('أدخل اسم الشركة');
 if(!Array.isArray(db.companies))db.companies=[];
 const exists=db.companies.some(c=>String(c?.name||c||'').trim().toLowerCase()===name.toLowerCase());
 if(exists)return alert('هذه الشركة مسجلة مسبقاً');
 db.companies.push({id:'company_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),name});
 save();
 if(input)input.value='';
 const sels=[el('companyPriceCompany'),el('purchasePriceCompany')].filter(Boolean); sels.forEach(sel=>sel.value=name);
 renderCompanyNames();
 const purchaseSel=el('purchasePriceCompany'); if(purchaseSel)purchaseSel.value=name;
 alert('تمت إضافة الشركة بنجاح');
}
function deleteCompany(name){
 const company=String(name||'').trim();
 if(!company)return;
 const hasPrices=(db.companyPrices||[]).some(x=>String(x.company||'').trim().toLowerCase()===company.toLowerCase());
 const msg=hasPrices?'هذه الشركة لديها أسعار مسجلة. حذفها سيحذف أسعارها أيضاً. هل تريد المتابعة؟':'هل تريد حذف هذه الشركة؟';
 if(!confirm(msg))return;
 db.companies=(db.companies||[]).filter(c=>String(c?.name||c||'').trim().toLowerCase()!==company.toLowerCase());
 db.companyPrices=(db.companyPrices||[]).filter(x=>String(x.company||'').trim().toLowerCase()!==company.toLowerCase());
 save();
 renderCompanyNames();
 renderPurchasePriceForm();
}

function renderMasterProductNamePicker(){
 const sel=el('masterExistingName'); if(!sel)return;
 const current=String(sel.value||'');
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 sel.innerHTML='<option value="">اختر اسم المنتوج المسجل</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join('');
 if(products.some(p=>String(p.id)===current))sel.value=current;
}
function handleMasterProductNameMode(){
 const mode=String(el('masterProductNameMode')?.value||'');
 const ew=el('masterExistingNameWrap'), nw=el('masterNewNameWrap'), name=el('masterOnlyName'), img=el('masterOnlyImage'), hint=el('masterImageHint');
 if(ew)ew.style.display=mode==='existing'?'block':'none';
 if(nw)nw.style.display=mode==='new'?'block':'none';
 if(name)name.value='';
 if(el('masterExistingName'))el('masterExistingName').value='';
 if(el('masterNewName'))el('masterNewName').value='';
 if(img)img.value='';
 const refInput=el('masterOnlyRef'); if(refInput){refInput.readOnly=false;refInput.value='';}
 if(hint)hint.textContent=mode==='existing'?'المنتوج المسجل لديه صورته الخاصة. أضف رقمًا جديدًا فقط، ولا حاجة لإعادة رفع الصورة.':'لكل اسم منتوج صورة واحدة ويمكن أن يكون له عدة أرقام. لا يمكن تكرار نفس الرقم لنفس الاسم.';
 const rh=el('masterRefHint'); if(rh){rh.textContent=mode==='existing'?'اكتب الرقم الجديد لهذا الاسم. يمكن إضافة أرقام كثيرة، لكن لا يمكن تكرار نفس الرقم لنفس الاسم.':'اكتب رقم المنتوج / المرجع.';rh.style.color='';}
}
function handleMasterExistingNameChange(){
 const id=String(el('masterExistingName')?.value||'');
 const p=getCatalogProduct(id);
 const name=el('masterOnlyName'); if(name)name.value=p?String(p.name||''):'';
 const ref=el('masterOnlyRef'); if(ref){ref.value=''; ref.readOnly=false;}
 const img=el('masterOnlyImage'); if(img)img.value='';
 const hint=el('masterImageHint'); if(hint)hint.textContent=p?(p.image?'هذا الاسم مسجل مسبقًا. يمكنك إضافة رقم جديد، ولا يمكن تكرار نفس الرقم لهذا الاسم.':'هذا الاسم مسجل مسبقًا بدون صورة. يمكنك إضافة رقم جديد وإضافة صورة واحدة له الآن.'):'اختر اسم المنتوج المسجل.';
}
function validateMasterNewRef(){
 const refEl=el('masterOnlyRef'), hint=el('masterRefHint');
 if(!refEl||!hint)return true;
 const ref=String(refEl.value||'').trim();
 const mode=String(el('masterProductNameMode')?.value||'');
 const pid=String(el('masterExistingName')?.value||'');
 if(!ref){
   hint.textContent=mode==='existing'?'اكتب الرقم الجديد لهذا الاسم.':'اكتب رقم المنتوج / المرجع.';
   hint.style.color='';
   return true;
 }
 if(mode==='existing'&&pid){
   const p=getCatalogProduct(pid);
   const duplicate=p&&productNumbers(p).some(r=>String(r).trim().toLowerCase()===ref.toLowerCase());
   if(duplicate){
     hint.textContent='⚠️ هذا الرقم مسجل مسبقًا لهذا الاسم. اكتب رقمًا جديدًا.';
     hint.style.color='#b42318';
     return false;
   }
 }
 hint.textContent='✅ هذا رقم جديد لهذا الاسم ويمكن تسجيله.';
 hint.style.color='#166534';
 return true;
}

async function addMasterProductOnly(e){
 e.preventDefault();
 const mode=String(el('masterProductNameMode')?.value||'');
 if(!mode)return alert('اختر هل اسم المنتوج مسجل أم اسم جديد');
 let name='';
 let product=null;
 if(mode==='existing'){
   const id=String(el('masterExistingName')?.value||'');
   product=getCatalogProduct(id);
   if(!product)return alert('اختر اسم المنتوج المسجل');
   name=String(product.name||'').trim();
 }else{
   name=String(el('masterNewName')?.value||'').trim();
   if(!name)return alert('اكتب اسم المنتوج الجديد');
   product=(db.products||[]).find(p=>normalizeProductName(p.name)===normalizeProductName(name))||null;
   if(product)return alert('هذا الاسم مسجل مسبقًا. اختر «اسم منتوج مسجل» ثم أضف الرقم.');
 }
 const ref=String(el('masterOnlyRef')?.value||'').trim();
 if(!ref)return alert('أدخل الرقم الجديد');
 if(!validateMasterNewRef())return alert('هذا الرقم مسجل مسبقًا لهذا الاسم. اكتب رقمًا جديدًا.');
 if(!Array.isArray(db.products))db.products=[];
 if(product && mode==='existing'){
   const refs=productNumbers(product);
   const duplicateSameName=refs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase());
   if(duplicateSameName)return alert('هذا الرقم مسجل مسبقًا لهذا الاسم. اختر رقمًا آخر.');
 }
 const file=el('masterOnlyImage')?.files?.[0];
 let image='';
 if(file){try{image=await compressImage(file);}catch(err){return alert('تعذر حفظ الصورة. جرّب صورة أصغر.');}}
 if(product){
   const refs=productNumbers(product);
   const duplicateSameName=refs.some(r=>String(r).trim().toLowerCase()===ref.toLowerCase());
   if(duplicateSameName)return alert('هذا الرقم مسجل مسبقًا لهذا الاسم. اختر رقمًا آخر.');
   product.numbers=[...refs,ref];
   product.numbers=sortNumbersAscending(product.numbers);
   if(image)product.image=image;
 }else{
   product={id:'prod_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),name,image,numbers:[ref]};
   db.products.push(product);
 }
 save();
 const n=el('masterOnlyName'),r=el('masterOnlyRef'),img=el('masterOnlyImage');
 if(n)n.value='';if(r)r.value='';if(img)img.value='';
 const rh=el('masterRefHint'); if(rh){rh.textContent='اكتب رقم المنتوج / المرجع.';rh.style.color='';}
 if(el('masterProductNameMode'))el('masterProductNameMode').value='';
 if(el('masterExistingName'))el('masterExistingName').innerHTML='<option value="">اختر اسم المنتوج المسجل</option>';
 if(el('masterNewName'))el('masterNewName').value='';
 if(el('masterExistingNameWrap'))el('masterExistingNameWrap').style.display='none';
 if(el('masterNewNameWrap'))el('masterNewNameWrap').style.display='none';
 renderMasterProductsTable(); renderMasterProductOptions(); renderMasterProductNamePicker(); renderPurchaseProductCards?.();
 alert(product.numbers.length>1?'تمت إضافة الرقم إلى نفس المنتوج وربطه بنفس الصورة.':'تم تسجيل المنتوج باسمه ورقمه وصورته.');
}
function renderMasterProductSearchOptions(){
 const nameSel=el('masterProductSearchName');
 if(!nameSel)return;
 const current=String(nameSel.value||'');
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 nameSel.innerHTML='<option value="">🔍 اختر اسم المنتوج</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name)}</option>`).join('');
 if(products.some(p=>String(p.id)===current))nameSel.value=current;
 renderMasterProductSearchRefs();
}
function renderMasterProductSearchRefs(){
 const nameSel=el('masterProductSearchName'), refSel=el('masterProductSearchRef');
 if(!refSel)return;
 const pid=String(nameSel?.value||'');
 const selected=(db.products||[]).find(p=>String(p.id)===pid);
 let refs=[];
 if(selected) refs=productNumbers(selected);
 else refs=[...new Set((db.products||[]).flatMap(p=>productNumbers(p)))];
 refs=stockSortNumbersDescending(refs);
 const current=String(refSel.value||'');
 refSel.innerHTML='<option value="">🔢 اختر رقم المنتوج</option>'+refs.map(r=>`<option value="${esc(String(r))}">${esc(String(r))}</option>`).join('');
 if(refs.some(r=>String(r)===current))refSel.value=current;
 else refSel.value='';
}
function clearMasterProductSearch(){
 const n=el('masterProductSearchName'),r=el('masterProductSearchRef');
 if(n)n.value='';
 renderMasterProductSearchRefs();
 if(r)r.value='';
 renderMasterProductsTable();
}
function renderMasterProductsTable(){
 const box=el('masterProductsTable'); if(!box)return;
 const nameSel=el('masterProductSearchName');
 if(nameSel && nameSel.tagName==='SELECT' && nameSel.options.length<=1){ renderMasterProductSearchOptions(); }
 const pid=String(el('masterProductSearchName')?.value||'');
 const rq=String(el('masterProductSearchRef')?.value||'').trim().toLowerCase();
 const nq='';
 const products=(db.products||[]).filter(p=>{
   if(pid&&String(p.id)!==pid)return false;
   if(rq&&!productNumbers(p).some(r=>String(r).toLowerCase()===rq))return false;
   return true;
 }).slice().sort((a,b)=>{
   const byName=compareNamesAZ(a?.name,b?.name);
   if(byName!==0)return byName;
   const ar=productNumbers(a)||[], br=productNumbers(b)||[];
   return compareRefsDesc(ar[0]||'',br[0]||'');
 });
 box.innerHTML=products.length?`<div class="master-products-grid">${products.map(p=>{
   const refs=[...(productNumbers(p)||[])].sort(compareProductRefsAZDesc);
   const img=p.image?`<img class="master-product-card-image" src="${p.image}" alt="${esc(p.name)}">`:'<div class="master-product-card-noimage">📦</div>';
   const filteredRefs=rq?refs.filter(r=>String(r).toLowerCase()===rq):refs;
   const pidJson=JSON.stringify(String(p.id));
   return `<div class="master-product-card" data-product-id="${esc(String(p.id))}">
     <div class="master-product-card-head">${img}<div class="master-product-card-name">${esc(p.name)}</div></div>
     <div class="master-product-card-body"><div class="master-product-card-label">الأرقام المسجلة</div><div class="master-product-numbers">${(filteredRefs.length?filteredRefs:refs).map(r=>{const rJson=JSON.stringify(String(r)); return `<span class="master-product-number"><b>${esc(r)}</b><button type="button" class="outline master-product-action" data-master-action="edit-ref" data-product-id="${esc(String(p.id))}" data-product-ref="${esc(String(r))}" title="تعديل الرقم">✏️</button><button type="button" class="danger master-product-action" data-master-action="delete-ref" data-product-id="${esc(String(p.id))}" data-product-ref="${esc(String(r))}" title="حذف الرقم">🗑️</button></span>`}).join('')}</div></div>
     <div class="master-product-card-footer"><span>${refs.length} ${refs.length===1?'رقم':'أرقام'}</span><div class="master-product-footer-actions"><button type="button" class="outline master-product-action" data-master-action="edit-image" data-product-id="${esc(String(p.id))}" title="تعديل صورة المنتوج">🖼️ تعديل الصورة</button><button type="button" class="outline master-product-action" data-master-action="edit-name" data-product-id="${esc(String(p.id))}" title="تعديل اسم المنتوج">✏️ تعديل الاسم</button></div></div>
   </div>`;
 }).join('')}</div>`:'<div class="company-price-empty">لا توجد منتوجات مسجلة</div>';
}
function deleteMasterProductRef(pid,ref){
 const productId=String(pid||'').trim();
 const targetRef=String(ref||'').trim();
 if(!productId||!targetRef)return;
 const p=(db.products||[]).find(x=>String(x.id)===productId);
 if(!p)return;
 const refs=productNumbers(p);
 if(!refs.some(r=>String(r).trim().toLowerCase()===targetRef.toLowerCase()))return;
 if(!confirm('هل تريد حذف الرقم «'+targetRef+'» من هذا المنتوج؟'))return;
 p.numbers=refs.filter(r=>String(r).trim().toLowerCase()!==targetRef.toLowerCase());
 // لا نحذف المنتوج نفسه؛ إذا كان هذا آخر رقم نطلب التأكيد قبل حذف السجل كاملاً.
 if(!p.numbers.length){
   if(!confirm('هذا هو آخر رقم لهذا المنتوج. هل تريد حذف المنتوج بالكامل؟')){
     p.numbers=[targetRef];
     return;
   }
   db.products=(db.products||[]).filter(x=>String(x.id)!==productId);
   if(db.purchasePrices)delete db.purchasePrices[productId];
   if(db.priceRefs)delete db.priceRefs[productId];
   db.companyPrices=(db.companyPrices||[]).filter(x=>String(x.productId)!==productId);
 }else{
   // حذف تعريفة الشركات المرتبطة بهذا الرقم فقط.
   db.companyPrices=(db.companyPrices||[]).filter(x=>!(String(x.productId)===productId&&String(x.ref||'').trim().toLowerCase()===targetRef.toLowerCase()));
   if(db.purchasePrices&&db.purchasePrices[productId])delete db.purchasePrices[productId][targetRef.toLowerCase()];
   if(db.priceRefs&&Array.isArray(db.priceRefs[productId]))db.priceRefs[productId]=db.priceRefs[productId].filter(r=>String(r).trim().toLowerCase()!==targetRef.toLowerCase());
 }
 save();
 renderMasterProductSearchOptions();
 renderMasterProductSearchRefs();
 renderMasterProductsTable();
 renderMasterProductOptions();
 renderCompanyPricesTable?.();
 alert('تم حذف الرقم بنجاح');
}
function addCompanyPrice(e){
 e.preventDefault();
 const companyEl=el('companyPriceCompany')||el('purchasePriceCompany');
 const productEl=el('companyPriceProduct')||el('purchasePriceProduct');
 const refEl=el('companyPriceRef')||el('purchasePriceRef');
 const qualityEl=el('companyPriceQuality')||el('purchasePriceQuality');
 const priceEl=el('companyPriceValue')||el('purchasePriceValue');

 const company=String(companyEl?.value||'').trim();
 const pid=String(productEl?.value||'');
 const ref=String(refEl?.value||'').trim();
 const quality=String(qualityEl?.value||'').trim();
 const price=Number(priceEl?.value);
 const p=(db.products||[]).find(x=>String(x.id)===pid);
 if(!company)return alert('أدخل اسم الشركة');
 if(!p)return alert('اختر المنتوج');
 if(!ref)return alert('اختر رقم المنتوج');
 if(!quality)return alert('أدخل نوع الجودة');
 if(!Number.isFinite(price)||price<0)return alert('أدخل ثمناً صحيحاً');
 if(!Array.isArray(db.companyPrices))db.companyPrices=[];
 const exists=db.companyPrices.find(x=>String(x.productId)===pid&&String(x.ref).trim().toLowerCase()===ref.toLowerCase()&&normalizeProductName(x.company)===normalizeProductName(company));
 if(exists){exists.price=price;exists.quality=quality;exists.productName=p.name;}else db.companyPrices.push({id:'cp_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),company,productId:pid,productName:p.name,ref,price,quality});
 save();
 companyEl.value=''; productEl.value=''; refEl.value=''; if(qualityEl)qualityEl.value=''; priceEl.value='';
 renderCompanyPricesTable();renderCompanyNames();renderPurchasePriceForm();
 alert(exists?'تم تحديث ثمن الشركة والجودة':'تم تسجيل ثمن الشركة والجودة');
}
function renderCompanyPriceSearchOptions(){
 const nameSel=el('companyPriceSearchName'), refSel=el('companyPriceSearchRef'), companySel=el('companyPriceSearchCompany');
 if(!nameSel||!refSel||!companySel)return;
 const currentName=nameSel.value, currentCompany=companySel.value;
 const products=(db.products||[]).slice().sort((a,b)=>compareNamesAZ(a.name,b.name));
 nameSel.innerHTML='<option value="">اسم المنتوج ⬇️</option>'+products.map(p=>`<option value="${esc(String(p.id))}">${esc(p.name||'')}</option>`).join('');
 if(products.some(p=>String(p.id)===String(currentName)))nameSel.value=currentName;
 renderCompanyPriceSearchRefs();
 const companies=[...new Set((db.companies||[]).map(x=>String(x?.name||x||'').trim()).filter(Boolean))].sort((a,b)=>compareNamesAZ(a,b));
 companySel.innerHTML='<option value="">الشركة ⬇️</option>'+companies.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
 if(companies.includes(currentCompany))companySel.value=currentCompany;
 renderCompanyPriceSearchResult();
}
function renderCompanyPriceSearchRefs(){
 const nameSel=el('companyPriceSearchName'), refSel=el('companyPriceSearchRef'); if(!nameSel||!refSel)return;
 const pid=nameSel.value, current=refSel.value;
 const p=(db.products||[]).find(x=>String(x.id)===String(pid));
 const refs=p?productNumbers(p):[];
 refSel.innerHTML='<option value="">رقم المنتوج ⬇️</option>'+refs.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
 refSel.disabled=!pid||!refs.length;
 if(refs.includes(current))refSel.value=current;
 else refSel.value='';
 renderCompanyPriceSearchResult();
}
function renderCompanyPriceSearchCompanies(){ renderCompanyPriceSearchResult(); }
function renderCompanyPriceSearchResult(){
 const box=el('companyPriceSearchResult'); if(!box)return;
 const cardsBox=el('companyPricesTable');
 const pid=String(el('companyPriceSearchName')?.value||'');
 const ref=String(el('companyPriceSearchRef')?.value||'').trim();
 const company=String(el('companyPriceSearchCompany')?.value||'').trim();
 // عند إجراء بحث كامل (اسم + رقم)، أخفِ جميع بطاقات تعريفة الشركات
 // واترك فقط نتيجة البحث ظاهرة. عند عدم وجود بحث كامل، أعد إظهار البطاقات.
 if(cardsBox) cardsBox.style.display=(pid&&ref)?'none':'';
 if(!pid||!ref){box.innerHTML='<div class="company-price-search-hint">اختر اسم المنتوج ثم رقم المنتوج لإظهار جميع الشركات وأسعارها.</div>';return;}
 const p=(db.products||[]).find(x=>String(x.id)===pid);
 const matches=(db.companyPrices||[]).filter(x=>String(x.productId)===pid&&String(x.ref).trim().toLowerCase()===ref.toLowerCase()&&(!company||normalizeProductName(x.company)===normalizeProductName(company)));
 if(!matches.length){box.innerHTML='<div class="company-price-empty">لا يوجد ثمن مسجل لهذا المنتوج والرقم.</div>';return;}
 matches.sort((a,b)=>compareNamesAZ(a.company,b.company));
 const rows=matches.map(item=>`<div class="company-price-result-row"><span>الشركة</span><b>${esc(item.company)}</b><span>الجودة</span><b>${esc(item.quality||'غير محددة')}</b><span>الثمن</span><b class="company-price-result-price">${money(item.price)}</b></div>`).join('');
 box.innerHTML=`<div class="company-price-result-card"><div class="company-price-result-title">🔎 نتيجة البحث — ${esc(p?.name||matches[0]?.productName||'')} / ${esc((p?productNumbers(p).find(r=>String(r).trim().toLowerCase()===ref.toLowerCase()):null)||ref)}</div>${rows}</div>`;
}
function renderCompanyPricesTable(){
 const box=el('companyPricesTable'); if(!box)return;
 const all=(db.companyPrices||[]).map(x=>{
   const p=(db.products||[]).find(p=>String(p.id)===String(x.productId));
   const masterRefs=p?productNumbers(p):[];
   const canonicalRef=masterRefs.find(r=>String(r).trim().toLowerCase()===String(x.ref||'').trim().toLowerCase())||String(x.ref||'');
   return {...x,displayName:p?.name||x.productName||'',displayImage:p?.image||'',displayRef:canonicalRef,masterProduct:p||null};
 });
 // البطاقة حسب المنتج، وداخلها كل رقم مع أسعار جميع الشركات الخاصة بهذا الرقم.
 const groups={};
 all.forEach(x=>{
   const key=String(x.productId||x.displayName||'').trim().toLowerCase()||'بدون منتوج';
   if(!groups[key])groups[key]={name:x.displayName||'بدون منتوج',image:x.displayImage||'',productId:x.productId,refs:{}};
   const refKey=String(x.displayRef||'').trim().toLowerCase()||'بدون رقم';
   if(!groups[key].refs[refKey])groups[key].refs[refKey]={ref:x.displayRef||'',rows:[]};
   groups[key].refs[refKey].rows.push(x);
 });
 const products=Object.values(groups).sort((a,b)=>
   compareNamesAZ(a.name,b.name)
 );
 if(!products.length){box.innerHTML='<div class="company-price-empty">لا توجد أسعار شركات مسجلة</div>';return;}
 box.innerHTML=products.map((g,idx)=>{
   const refs=Object.values(g.refs).sort((a,b)=>{
     const nums=v=>String(v||'').match(/\d+(?:[.,]\d+)?/g)||[];
     const A=nums(a.ref),B=nums(b.ref),n=Math.max(A.length,B.length);
     for(let i=0;i<n;i++){
       const av=i<A.length?Number(A[i].replace(',','.')):NaN;
       const bv=i<B.length?Number(B[i].replace(',','.')):NaN;
       if(Number.isFinite(av)&&Number.isFinite(bv)&&av!==bv)return bv-av;
       if(Number.isFinite(av)&&!Number.isFinite(bv))return -1;
       if(!Number.isFinite(av)&&Number.isFinite(bv))return 1;
     }
     return compareRefsDesc(a.ref,b.ref);
   });
   const refBlocks=refs.map(r=>{
     r.rows.sort((a,b)=>compareNamesAZ(a.company,b.company));
     const rows=r.rows.map(x=>`<tr data-company-price-row="${String(x.id).replace(/"/g,'&quot;')}" data-company-price-ref="${String(x.displayRef).replace(/"/g,'&quot;')}"><td class="company-price-company">${esc(x.company||'')}</td><td class="company-price-value">${money(x.price)}</td><td class="company-price-quality">${esc(x.quality||'غير محددة')}</td><td><div class="company-price-actions"><button type="button" class="company-price-edit" title="تعديل الشركة والجودة والثمن" data-company-price-action="edit" data-company-price-id="${String(x.id).replace(/"/g,'&quot;')}" onclick="editCompanyPrice(this.getAttribute('data-company-price-id'),event);return false;">✏️ تعديل</button><button type="button" class="company-price-delete" title="حذف هذا السعر" data-company-price-action="delete" data-company-price-id="${String(x.id).replace(/"/g,'&quot;')}" onclick="deleteCompanyPrice(this.getAttribute('data-company-price-id'),event);return false;">🗑️</button></div></td></tr>`).join('');
     return `<div class="company-price-ref-block"><div class="company-price-ref-title"><span>🔢 رقم المنتج</span><b>${esc(r.ref||'-')}</b></div><div class="company-price-table-wrap"><table class="company-price-table"><thead><tr><th>الشركة</th><th>الثمن</th><th>الجودة</th><th>إجراء</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
   }).join('');
   return `<div class="company-price-company-card company-price-product-card">
     <div class="company-price-company-head">
       <span class="company-price-product-card-title">${g.image?`<img src="${esc(g.image)}" alt="" class="company-master-product-image">`:'<span class="company-master-product-image company-master-product-noimage">📦</span>'}<span>${esc(g.name)}</span></span>
       <b>${refs.length} رقم</b>
     </div>
     ${refBlocks}
   </div>`;
 }).join('');
 sortCardContainersAZ();
}
function editCompanyPrice(id,e){
 if(e){e.preventDefault();e.stopPropagation();}
 const x=(db.companyPrices||[]).find(v=>String(v.id)===String(id)); if(!x)return alert('لم يتم العثور على السعر');
 const row=[...document.querySelectorAll('tr[data-company-price-row]')].find(r=>String(r.getAttribute('data-company-price-row'))===String(id));
 if(!row)return;
 const companyCell=row.children[0], priceCell=row.children[1], qualityCell=row.children[2], actionCell=row.children[3];
 const oldCompany=String(x.company||'');
 const oldPrice=String(x.price??'');
 const oldQuality=String(x.quality||'');
 companyCell.innerHTML=`<input class="company-price-edit-input" value="${esc(oldCompany)}" aria-label="اسم الشركة الجديد">`;
 priceCell.innerHTML=`<input class="company-price-edit-input" type="number" min="0" step="0.01" value="${esc(oldPrice)}" aria-label="الثمن الجديد">`;
 qualityCell.innerHTML=`<input class="company-price-edit-input" list="qualityOptions" value="${esc(oldQuality)}" aria-label="نوع الجودة الجديد">`;
 actionCell.innerHTML=`<div class="company-price-actions"><button type="button" class="company-price-save" title="حفظ التعديل" data-company-price-id="${String(id).replace(/"/g,'&quot;')}" onclick="saveCompanyPriceEdit(this.getAttribute('data-company-price-id'),event);return false;">💾</button><button type="button" class="company-price-cancel" title="إلغاء" onclick="renderCompanyPricesTable();return false;">↩️</button></div>`;
 const input=companyCell.querySelector('input'); if(input){input.focus();input.select();}
}
function saveCompanyPriceEdit(id,e){
 if(e){e.preventDefault();e.stopPropagation();}
 const x=(db.companyPrices||[]).find(v=>String(v.id)===String(id)); if(!x)return alert('لم يتم العثور على السعر');
 const row=[...document.querySelectorAll('tr[data-company-price-row]')].find(r=>String(r.getAttribute('data-company-price-row'))===String(id)); if(!row)return;
 const company=String(row.children[0].querySelector('input')?.value||'').trim();
 const normalized=String(row.children[1].querySelector('input')?.value||'').replace(',','.').trim();
 const price=Number(normalized);
 const quality=String(row.children[2].querySelector('input')?.value||'').trim();
 if(!company)return alert('أدخل اسم الشركة');
 if(!quality)return alert('أدخل نوع الجودة');
 if(!Number.isFinite(price)||price<0)return alert('الثمن غير صحيح');
 const duplicate=(db.companyPrices||[]).some(v=>String(v.id)!==String(id)&&String(v.productId)===String(x.productId)&&String(v.ref||'').trim().toLowerCase()===String(x.ref||'').trim().toLowerCase()&&normalizeProductName(v.company)===normalizeProductName(company));
 if(duplicate)return alert('يوجد بالفعل ثمن مسجل لنفس المنتوج والرقم وهذه الشركة.');
 const oldCompany=String(x.company||'').trim();
 x.company=company;
 x.price=price;
 x.quality=quality;
 // تحديث اسم الشركة في السجل الرئيسي وفي باقي الأسعار المرتبطة بها، حتى لا تتكرر أسماء مختلفة لنفس الشركة.
 if(normalizeProductName(oldCompany)!==normalizeProductName(company)){
   if(Array.isArray(db.companies))db.companies.forEach(c=>{if(normalizeProductName(c?.name||c)===normalizeProductName(oldCompany)){if(typeof c==='object')c.name=company;}});
   (db.companyPrices||[]).forEach(v=>{if(String(v.id)!==String(id)&&normalizeProductName(v.company)===normalizeProductName(oldCompany))v.company=company;});
 }
 save();
 renderCompanyPricesTable();
 renderCompanyNames();
 renderCompanyPriceSearchResult();
}
function deleteCompanyPrice(id,e){
 if(e){e.preventDefault();e.stopPropagation();}
 const x=(db.companyPrices||[]).find(v=>String(v.id)===String(id)); if(!x)return alert('لم يتم العثور على السعر');
 if(!confirm('هل تريد حذف ثمن هذه الشركة؟'))return;
 db.companyPrices=(db.companyPrices||[]).filter(v=>String(v.id)!==String(id));
 save();
 renderCompanyPricesTable();
 renderCompanyNames();
 renderCompanyPriceSearchResult();
}

let afzBackupBlobUrl=null;
let afzBackupBlob=null;
let afzBackupFileName='';
const AFZ_BACKUP_IDB_NAME='afz_backup_files_v1';
const AFZ_BACKUP_IDB_STORE='backups';
function afzOpenBackupDb(){return new Promise((resolve,reject)=>{try{if(!window.indexedDB)return reject(new Error('IndexedDB غير متاح'));const r=indexedDB.open(AFZ_BACKUP_IDB_NAME,1);r.onupgradeneeded=()=>{const d=r.result;if(!d.objectStoreNames.contains(AFZ_BACKUP_IDB_STORE))d.createObjectStore(AFZ_BACKUP_IDB_STORE,{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('تعذر فتح التخزين'));}catch(e){reject(e)}})}
async function afzStoreBackup(json,fileName){try{const d=await afzOpenBackupDb();await new Promise((resolve,reject)=>{const tx=d.transaction(AFZ_BACKUP_IDB_STORE,'readwrite');tx.objectStore(AFZ_BACKUP_IDB_STORE).put({id:'latest',name:fileName,ts:Date.now(),json});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});d.close();return true}catch(e){console.warn('backup internal save failed',e);return false}}
async function afzNativeBackup(json,fileName){try{const b=window.AndroidBackup;if(!b)return false;const fn=b.saveBackup||b.exportBackup||b.writeBackup||b.createBackup;if(typeof fn!=='function')return false;const result=fn.call(b,json,fileName);const finalResult=result&&typeof result.then==='function'?await result:result;return finalResult!==false}catch(e){console.warn('Android backup failed',e);return false}}
async function exportBackup(){
 try{
  // احفظ آخر بيانات التطبيق أولاً قبل إنشاء النسخة.
  try{saveLocal();}catch(e){}
  const payload={version:5,exportedAt:new Date().toISOString(),stock:Array.isArray(db.stock)?db.stock:[],products:Array.isArray(db.products)?db.products:[],sales:Array.isArray(db.sales)?db.sales:[],customers:Array.isArray(db.customers)?db.customers:[],expenses:Array.isArray(db.expenses)?db.expenses:[],deliveryDocs:Array.isArray(db.deliveryDocs)?db.deliveryDocs:[],credits:Array.isArray(db.credits)?db.credits:[],checks:Array.isArray(db.checks)?db.checks:[],prices:db.prices||{},priceRefs:db.priceRefs||{},purchasePrices:db.purchasePrices||{},companyPrices:Array.isArray(db.companyPrices)?db.companyPrices:[],companies:Array.isArray(db.companies)?db.companies:[],discountPrices:db.discountPrices||{},priceSections:getPriceSections(),priceSectionMap:db.priceSectionMap||{}};
  const json=JSON.stringify(payload,null,2);
  const now=new Date();
  const stamp=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0')+'-'+String(now.getHours()).padStart(2,'0')+'-'+String(now.getMinutes()).padStart(2,'0')+'-'+String(now.getSeconds()).padStart(2,'0');
  const fileName='AFRIQUIA-BACKUP-'+stamp+'.json';
  afzBackupFileName=fileName;
  afzBackupBlob=new Blob([json],{type:'application/json;charset=utf-8'});
  if(afzBackupBlobUrl)try{URL.revokeObjectURL(afzBackupBlobUrl)}catch(e){}
  afzBackupBlobUrl=URL.createObjectURL(afzBackupBlob);
  try{localStorage.setItem('afz_last_backup_name',fileName);localStorage.setItem('afz_last_backup_time',new Date().toISOString())}catch(e){}
  const internalSaved=await afzStoreBackup(json,fileName);
  // في تطبيق Android: احفظ مباشرة في مجلد Downloads. لا تعتمد على تنزيل Blob
  // من داخل WebView لأن بعض هواتف Android لا تنشئ ملفًا منه.
  if(window.AndroidBackup && typeof window.AndroidBackup.saveBackup==='function'){
    const nativeOk=await afzNativeBackup(json,fileName);
    if(nativeOk){
      showBackupSavedInfo(fileName,'تم حفظ النسخة الاحتياطية فعليًا في مجلد التنزيلات (Downloads).');
      return;
    }
    showBackupSavedInfo(fileName,'تعذر الحفظ التلقائي في التنزيلات. اضغط «حفظ الملف في الهاتف» للمحاولة مرة أخرى.');
    return;
  }
  // المتصفحات التي تدعم اختيار مكان الحفظ تحفظ الملف مباشرة.
  if(window.showSaveFilePicker){try{const h=await window.showSaveFilePicker({suggestedName:fileName,types:[{description:'نسخة احتياطية JSON',accept:{'application/json':['.json']}}]});const w=await h.createWritable();await w.write(afzBackupBlob);await w.close();showBackupSavedInfo(fileName,'تم حفظ الملف فعليًا في المكان الذي اخترته.');return;}catch(e){if(e&&e.name==='AbortError'){showBackupSavedInfo(fileName,internalSaved?'تم حفظ نسخة داخل التطبيق. لم يتم اختيار ملف خارجي.':'لم يتم اختيار مكان لحفظ الملف.');return;}}}
  showBackupSavedInfo(fileName,'تم إنشاء الملف. استخدم زر تنزيل الملف إلى الهاتف. لا يتم حفظ نسخة احتياطية داخل التطبيق.');
  // في المتصفح العادي فقط نعرض أدوات الحفظ الخارجية. داخل Android يتم الحفظ عبر الجسر الأصلي أعلاه.
 }catch(e){alert('تعذر إنشاء النسخة الاحتياطية: '+e.message)}
}
async function saveBackupToPhone(){
 try{
  if(!afzBackupBlob){alert('أنشئ النسخة الاحتياطية أولاً');return;}

  // إذا كان التطبيق يحتوي على جسر Android حقيقي، استخدمه أولاً.
  if(window.AndroidBackup && typeof window.AndroidBackup.saveBackup==='function'){
    const nativeOk=await afzNativeBackup(await afzBackupBlob.text(),afzBackupFileName);
    if(nativeOk){
      showBackupSavedInfo(afzBackupFileName,'تم حفظ الملف فعليًا في مجلد التنزيلات.');
      return;
    }
    // لا نمرر العملية إلى نافذة حفظ قد لا تستجيب داخل WebView.
    alert('تعذر حفظ النسخة الاحتياطية في الهاتف. حاول الضغط مرة أخرى.');
    return;
  }

  // دعم اختيار مكان الحفظ في المتصفحات التي توفر File System Access API.
  if(window.showSaveFilePicker){
   try{
    const h=await window.showSaveFilePicker({
      suggestedName:afzBackupFileName,
      types:[{description:'نسخة احتياطية JSON',accept:{'application/json':['.json']}}]
    });
    const w=await h.createWritable();
    await w.write(afzBackupBlob);
    await w.close();
    showBackupSavedInfo(afzBackupFileName,'تم حفظ الملف فعليًا في المكان الذي اخترته.');
    return;
   }catch(e){
    if(e&&e.name==='AbortError') return;
   }
  }

  const f=new File([afzBackupBlob],afzBackupFileName,{type:'application/json'});

  // مشاركة الملف إلى تطبيق «الملفات» في Android عندما تكون مدعومة.
  if(navigator.share){
   try{
    if(!navigator.canShare || navigator.canShare({files:[f]})){
     await navigator.share({
       title:'نسخة احتياطية',
       text:'اختر تطبيق «الملفات» ثم مجلد «التنزيلات» لحفظ النسخة.',
       files:[f]
     });
     showBackupSavedInfo(afzBackupFileName,'تم إرسال الملف إلى نافذة المشاركة. اختر «الملفات» ثم «التنزيلات».');
     return;
    }
   }catch(e){
    if(e&&e.name==='AbortError') return;
   }
  }

  // في WebView Android قد لا يعمل تنزيل Blob URL؛ لذلك نجهز أيضًا Data URL
  // ونستخدمه عند الضغط، مع منع فتح JSON كصفحة نصية.
  const box=el('backupSavedInfo');
  if(box){
   box.style.display='block';
   const name=el('backupSavedName');
   if(name) name.innerHTML='اسم الملف: '+afzBackupFileName+
     '<br><span style="color:#b45309">اضغط زر «تنزيل الملف إلى الهاتف» أدناه. لا تفتح الملف كصفحة نصية.</span>';

   const oldLinks=box.querySelectorAll('.afz-backup-download-link,.afz-backup-share-link,.afz-backup-help');
   oldLinks.forEach(x=>x.remove());

   // زر تنزيل متوافق أكثر مع Android WebView: نستخدم Data URL عند الضغط
   // بدل Blob URL الذي قد يفتح المحتوى كنص أو لا ينشئ ملفًا.
   const a=document.createElement('a');
   a.href='#';
   a.download=afzBackupFileName;
   a.rel='noopener';
   a.textContent='⬇️ تنزيل الملف إلى الهاتف';
   a.className='afz-backup-download-link';
   a.style.cssText='display:block;margin:12px 0;padding:16px;background:#0b4f8a;color:#fff;border-radius:12px;text-align:center;font-weight:900;text-decoration:none;font-size:17px';
   a.addEventListener('click',function(ev){
     ev.preventDefault();
     try{
       // text/plain يساعد WebView على تمرير التنزيل بدل عرض JSON داخل الصفحة.
       const dataUrl='data:application/json;charset=utf-8,'+encodeURIComponent(afzBackupBlob ? afzBackupBlob.text ? '' : '' : '');
       // نحصل على النص مباشرة من الذاكرة ثم ننشئ الرابط.
       afzBackupBlob.text().then(function(txt){
         const u='data:application/json;charset=utf-8,'+encodeURIComponent(txt);
         const x=document.createElement('a');
         x.href=u; x.download=afzBackupFileName; x.rel='noopener';
         x.style.display='none'; document.body.appendChild(x);
         x.click(); setTimeout(()=>{try{x.remove()}catch(e){}},1000);
       }).catch(function(){alert('تعذر تجهيز ملف النسخة الاحتياطية');});
     }catch(e){alert('تعذر تنزيل النسخة الاحتياطية: '+e.message);}
   });
   box.appendChild(a);

   const b=document.createElement('button');
   b.type='button';
   b.textContent='📤 مشاركة الملف إلى «الملفات»';
   b.className='afz-backup-share-link';
   b.style.cssText='width:100%;margin-top:6px;padding:14px;border:0;border-radius:12px;background:#14532d;color:#fff;font-weight:900;font-size:16px';
   b.onclick=async()=>{
    try{
      if(!navigator.share){alert('المشاركة غير مدعومة في هذا التطبيق. استخدم زر التنزيل أعلاه.');return;}
      await navigator.share({title:'نسخة احتياطية',text:'احفظ الملف في التنزيلات.',files:[f]});
    }catch(e){}
   };
   box.appendChild(b);

   const help=document.createElement('div');
   help.className='afz-backup-help';
   help.style.cssText='margin-top:10px;font-size:13px;line-height:1.7;color:#555';
   help.textContent='إذا ظهر الملف كنص بدل تنزيله، لا تضغط «فتح». ارجع واضغط «⬇️ تنزيل الملف إلى الهاتف» أو استخدم «مشاركة الملف إلى الملفات».';
   box.appendChild(help);
  }
 }catch(e){
   alert('لم يتم حفظ الملف: '+(e&&e.message?e.message:e));
 }
}
function showBackupSavedInfo(fileName,message){const box=el('backupSavedInfo'),name=el('backupSavedName');if(name)name.innerHTML='اسم الملف: '+fileName+'<br><span style="color:#14532d">'+(message||'')+'</span>';if(box)box.style.display='block';}

function importBackup(file){const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x||!Array.isArray(x.stock)||!Array.isArray(x.sales)||!Array.isArray(x.customers))throw 0;if(!confirm('سيتم استبدال البيانات الحالية بالنسخة الاحتياطية. هل تريد المتابعة؟'))return;db={stock:x.stock||[],products:x.products||[],sales:x.sales||[],customers:x.customers||[],expenses:x.expenses||[],deliveryDocs:x.deliveryDocs||[],credits:x.credits||[],checks:x.checks||[],prices:x.prices||{},priceRefs:x.priceRefs||{},purchasePrices:x.purchasePrices||{},companyPrices:Array.isArray(x.companyPrices)?x.companyPrices:[],companies:Array.isArray(x.companies)?x.companies:[],discountPrices:x.discountPrices||{},priceSections:Array.isArray(x.priceSections)&&x.priceSections.length?x.priceSections:['عام'],priceSectionMap:x.priceSectionMap||{}};normalizeSavedData();save();alert('تم استرجاع البيانات بنجاح')}catch(e){alert('ملف النسخة الاحتياطية غير صالح')}};r.onerror=()=>alert('تعذر قراءة ملف النسخة الاحتياطية');r.readAsText(file)}
function save(){saveLocal();try{if(window.AndroidNotifications&&typeof AndroidNotifications.syncChecks==='function')AndroidNotifications.syncChecks(JSON.stringify(db.checks||[]));}catch(e){}render()}
function clearSalesFilters(){if(el('salesSearch'))el('salesSearch').value='';if(el('salesPeriod'))el('salesPeriod').value='all';if(el('salesCustomerSearch'))el('salesCustomerSearch').value='';render();}
function saleItemProfit(item){
 const qty=Number(item.qty||item.quantity||1), price=Number(item.price||item.salePrice||0);
 let buy=Number(item.buyPrice);
 if(!Number.isFinite(buy)) { const p=db.stock.find(x=>String(x.id)===String(item.productId)); buy=Number(p?.buy||0); }
 return (price-buy)*qty;
}
function openQuickSaleNamePicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('quickSaleName');
 if(!input)return;
 // عند الضغط على سهم الاسم، ابدأ اختياراً جديداً وامسح الاسم/المرجع السابقين.
 if(input.value)input.value='';
 const refInput=el('quickSaleRef'); if(refInput)refInput.value='';
 const refBox=el('quickSaleRefPicker'); if(refBox)refBox.style.display='none';
 renderQuickSaleNames();
 input.focus({preventScroll:true});
 const box=el('quickSaleNamePicker'); if(box)box.style.display='block';
}
function openQuickSaleRefPicker(e){
 if(e){e.preventDefault();e.stopPropagation();}
 const input=el('quickSaleRef');
 if(!input)return;
 // عند الضغط على سهم المرجع، امسح المرجع السابق فقط مع الإبقاء على الاسم المختار.
 if(input.value)input.value='';
 renderQuickSaleRefs(true);
 input.focus({preventScroll:true});
 const box=el('quickSaleRefPicker'); if(box)box.style.display='block';
 const nameBox=el('quickSaleNamePicker'); if(nameBox)nameBox.style.display='none';
}
window.addEventListener('popstate',()=>{clearQuickSaleSearchFields();});
window.addEventListener('pagehide',()=>{clearQuickSaleSearchFields();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')clearQuickSaleSearchFields();});
function initQuickSaleSearchFix(){
 const nameInput=el('quickSaleName'), refInput=el('quickSaleRef');
 if(!nameInput||!refInput)return;
 nameInput.addEventListener('input',()=>{renderQuickSaleNames();if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';});
 nameInput.addEventListener('focus',()=>{renderQuickSaleNames();});
 refInput.addEventListener('input',()=>{renderQuickSaleRefs(false);});
 refInput.addEventListener('focus',()=>{if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';});
 document.addEventListener('click',function(e){
   const nameOpt=e.target.closest('#quickSaleNamePicker .search-picker-item');
   if(nameOpt){e.preventDefault();e.stopPropagation();selectQuickSaleName(nameOpt.getAttribute('data-sale-name')||nameOpt.textContent.replace(/^📦\s*/,''));return;}
   const refOpt=e.target.closest('#quickSaleRefPicker .search-picker-item');
   if(refOpt){e.preventDefault();e.stopPropagation();selectQuickSaleRef(refOpt.getAttribute('data-sale-ref')||refOpt.textContent.replace(/^🔢\s*/,''));return;}
 });
}

function renderQuickSaleNames(){
 const box=el('quickSaleNamePicker'); if(!box)return;
 const q=normalizeProductName(el('quickSaleName')?.value||'');
 const names=[...new Set((db.stock||[]).map(x=>String(x.name||'').trim()).filter(Boolean))].sort((a,b)=>compareNamesAZ(a,b)).filter(n=>!q||normalizeProductName(n).includes(q));
 box.innerHTML=names.length?names.map(n=>`<button type="button" class="search-picker-item" data-sale-name="${esc(n)}">📦 ${esc(n)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أسماء في المخزون</div>';
 box.style.display='block';
}
function selectQuickSaleName(name){
 if(el('quickSaleName'))el('quickSaleName').value=name;
 if(el('quickSaleRef'))el('quickSaleRef').value='';
 if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';
 if(el('quickSaleNamePicker'))el('quickSaleNamePicker').style.display='none';
}
function renderQuickSaleRefs(show=true){
 const box=el('quickSaleRefPicker');
 const q=String(el('quickSaleRef')?.value||'').trim().toLowerCase();
 const name=normalizeProductName(el('quickSaleName')?.value||'');
 const refs=[...new Set((db.stock||[]).filter(x=>!name||normalizeProductName(x.name||'')===name).map(x=>String(x.ref||'').trim()).filter(Boolean))].filter(r=>!q||r.toLowerCase().includes(q));
 if(box){box.innerHTML=refs.length?sortNumbersAscending(refs).map(r=>`<button type="button" class="search-picker-item" data-sale-ref="${esc(r)}">🔢 ${esc(r)}</button>`).join(''):'<div class="search-picker-empty">لا توجد أرقام لهذا الاسم</div>';box.style.display=show?'block':'none';}
}
function selectQuickSaleRef(ref){
 if(el('quickSaleRef'))el('quickSaleRef').value=ref;
 if(el('quickSaleRefPicker'))el('quickSaleRefPicker').style.display='none';
 const p=(db.stock||[]).find(x=>String(x.ref||'').trim().toLowerCase()===String(ref).trim().toLowerCase() && (!el('quickSaleName')?.value || normalizeProductName(x.name||'')===normalizeProductName(el('quickSaleName').value)));
 if(p && el('quickSaleName'))el('quickSaleName').value=p.name||'';
}
function addQuickSale(){
 const name=(el('quickSaleName')?.value||'').trim();
 const ref=(el('quickSaleRef')?.value||'').trim();
 const qty=Number(el('quickSaleQty')?.value||0);
 let price=Number(el('quickSalePrice')?.value||0);
 if(!ref)return alert('أدخل رقم المنتج');
 if(qty<=0 || !Number.isInteger(qty))return alert('أدخل كمية صحيحة');
 const stockMatches=(db.stock||[]).filter(x=>String(x.ref||'').trim().toLowerCase()===ref.toLowerCase() && (!name||normalizeProductName(x.name||'')===normalizeProductName(name)));
 if(!stockMatches.length)return alert('اختر الاسم والرقم من المنتوجات المسجلة في المخزون');
 const first=stockMatches[0];
 const catalog=getCatalogProduct(first.productId)||getCatalogProductByName(first.name);
 if(!catalog)return alert('المنتوج غير موجود في سجل المخزون');
 const canonicalRef=productNumbers(catalog).find(r=>String(r).trim().toLowerCase()===ref.toLowerCase())||ref;
 const matches=(db.stock||[]).filter(x=>String(x.productId)===String(catalog.id)&&String(x.ref||'').trim().toLowerCase()===String(canonicalRef).trim().toLowerCase());
 if(!matches.length)return alert('هذا الرقم موجود في قسم المنتوجات لكنه غير موجود في المخزون');
 const available=matches.reduce((sum,x)=>sum+Math.max(0,Number(x.qty||0)),0);
 if(qty>available)return alert('الكمية المطلوبة أكبر من مجموع المخزون المتوفر: '+available);
 if(!Number.isFinite(price) || price<=0)return alert('أدخل ثمن البيع');
 const total=qty*price;
 // خصم الكمية المباعة تلقائيًا من المخزون لنفس المنتوج والرقم، عبر جميع سجلات الشركات.
 let remainingToDeduct=qty;
 let weightedBuy=0;
 matches.forEach(x=>{weightedBuy+=Math.max(0,Number(x.qty||0))*Number(x.buy||0);});
 const buy=available>0?weightedBuy/available:0;
 for(const row of matches){
   if(remainingToDeduct<=0)break;
   const rowQty=Math.max(0,Number(row.qty||0));
   const take=Math.min(rowQty,remainingToDeduct);
   row.qty=rowQty-take;
   remainingToDeduct-=take;
 }
 const remainingQty=matches.reduce((sum,x)=>sum+Math.max(0,Number(x.qty||0)),0);
 const profit=(price-buy)*qty;
 db.sales.push({id:Date.now()+Math.floor(Math.random()*1000),date:new Date().toISOString(),customer:{name:'زبون عابر',phone:''},items:[{productId:catalog.id,name:catalog.name||first.name||'',ref:canonicalRef,qty,price,buyPrice:buy,total,profit,remainingQty}],total});
 save();
 if(el('quickSaleRef'))el('quickSaleRef').value='';
 if(el('quickSaleQty'))el('quickSaleQty').value='1';
 if(el('quickSalePrice'))el('quickSalePrice').value='';
 render();
 alert('تم تسجيل البيع وخصم '+qty+' من المخزون تلقائيًا. المتبقي: '+remainingQty+' قطعة');
}
function dailySalesData(){
 const map={};
 for(const s of db.sales){
  const d=new Date(s.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  const row=map[key]; row.ops+=1; row.revenue+=Number(s.total||0); row.profit+=saleProfit(s);
  row.qty+=saleItems(s).reduce((a,i)=>a+Number(i.qty||i.quantity||1),0);
 }
 for(const e of db.expenses){
  const d=new Date(e.date||Date.now()); if(Number.isNaN(d.getTime()))continue;
  const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  if(!map[key])map[key]={date:key,ops:0,qty:0,revenue:0,profit:0,expenses:0};
  map[key].expenses+=Number(e.amount||0);
 }
 return Object.values(map).sort((a,b)=>b.date.localeCompare(a.date));
}
function saleItemTotal(item){return Number(item.total||((Number(item.qty||item.quantity||1))*Number(item.price||item.salePrice||0)));}
function saleProfit(s){return saleItems(s).reduce((a,i)=>a+saleItemProfit(i),0)}
function saleMatchesFilters(s){
 const term=(el('salesSearch')?.value||'').trim().toLowerCase();
 const customerTerm=(el('salesCustomerSearch')?.value||'').trim().toLowerCase();
 const period=el('salesPeriod')?.value||'all';
 const items=saleItems(s);
 if(term && !items.some(i=>String(i.name||i.productName||'').toLowerCase().includes(term)||String(i.ref||'').toLowerCase().includes(term))) return false;
 const c=s.customer||{}; if(customerTerm && !String(c.name||'').toLowerCase().includes(customerTerm)) return false;
 if(period!=='all'){const d=new Date(s.date||0), now=new Date(); if(Number.isNaN(d.getTime())) return false; if(period==='day' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth()||d.getDate()!==now.getDate())) return false; if(period==='month' && (d.getFullYear()!==now.getFullYear()||d.getMonth()!==now.getMonth())) return false; if(period==='year' && d.getFullYear()!==now.getFullYear()) return false;}
 return true;
}
function fillCreditCustomer(){
 const c=db.customers.find(x=>String(x.id)===String(el('creditCustomer')?.value||''));
 if(c){if(el('creditCustomerName'))el('creditCustomerName').value=c.name||'';if(el('creditPhone'))el('creditPhone').value=c.phone||'';}
}
function addCredit(e){
 e.preventDefault();
 const name=(el('creditCustomerName')?.value||'').trim();
 const phone=(el('creditPhone')?.value||'').trim();
 const amount=Number(el('creditAmount')?.value||0);
 if(!name)return alert('أدخل اسم الزبون');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 if(!Array.isArray(db.credits))db.credits=[];
 const customerId=el('creditCustomer')?.value||'';
 db.credits.push({id:Date.now()+Math.floor(Math.random()*1000),customerId,customerName:name,phone,date:new Date(el('creditDate')?.value||Date.now()).toISOString(),amount,note:(el('creditNote')?.value||'').trim(),paid:false});
 save(); e.target.reset(); if(el('creditDate'))el('creditDate').value=''; alert('تم تسجيل الكريدي بنجاح');
}
function markCreditPaid(id){
 const c=db.credits.find(x=>String(x.id)===String(id)); if(!c)return;
 c.paid=true; c.paidDate=new Date().toISOString(); save();
}
function deleteCredit(id){
 if(!confirm('هل تريد حذف هذا الكريدي؟'))return;
 db.credits=db.credits.filter(x=>String(x.id)!==String(id)); save();
}
let editingCheckId=null;
function addCheck(e){
 e.preventDefault();
 if(!Array.isArray(db.checks))db.checks=[];
 const number=(el('checkNumber')?.value||'').trim();
 const beneficiary=(el('checkBeneficiary')?.value||'').trim();
 const amount=Number(el('checkAmount')?.value||0);
 if(!number)return alert('أدخل رقم الشيك');
 if(!beneficiary)return alert('أدخل اسم المستفيد');
 if(amount<=0)return alert('أدخل مبلغاً صحيحاً');
 const date=el('checkDate')?.value||new Date().toISOString().slice(0,10);
 const duplicate=(db.checks||[]).some(c=>String(c.date||'')===date && String(c.id)!==String(editingCheckId));
 if(duplicate){
   return alert('غير مسموح: يوجد شيك مسجل مسبقاً في نفس التاريخ. يمكن تسجيل شيك واحد فقط في كل تاريخ.');
 }
 if(editingCheckId!==null){
   const c=(db.checks||[]).find(x=>String(x.id)===String(editingCheckId));
   if(!c)return cancelCheckEdit();
   c.number=number;c.beneficiary=beneficiary;c.amount=amount;c.date=date;c.status=el('checkStatus')?.value||'pending';
   editingCheckId=null;
   save();e.target.reset();resetCheckEditUI();renderChecks();alert('تم تعديل الشيك بنجاح');
   return;
 }
 db.checks.push({id:Date.now()+Math.floor(Math.random()*1000),number,beneficiary,amount,date,status:el('checkStatus')?.value||'pending'});
 save();e.target.reset();renderChecks();alert('تم تسجيل الشيك بنجاح');
}
function editCheck(id){
 const c=(db.checks||[]).find(x=>String(x.id)===String(id));if(!c)return;
 editingCheckId=id;
 if(el('checkNumber'))el('checkNumber').value=c.number||'';
 if(el('checkBeneficiary'))el('checkBeneficiary').value=c.beneficiary||'';
 if(el('checkAmount'))el('checkAmount').value=Number(c.amount||0);
 if(el('checkDate'))el('checkDate').value=c.date||'';
 if(el('checkStatus'))el('checkStatus').value=c.status||'pending';
 const btn=el('checkSubmitBtn');if(btn)btn.textContent='💾 حفظ تعديل الشيك';
 const cancel=el('checkCancelEditBtn');if(cancel)cancel.style.display='inline-block';
 const form=el('checkNumber')?.closest('form');if(form)form.scrollIntoView({behavior:'smooth',block:'center'});
}
function resetCheckEditUI(){
 const btn=el('checkSubmitBtn');if(btn)btn.textContent='➕ تسجيل الشيك';
 const cancel=el('checkCancelEditBtn');if(cancel)cancel.style.display='none';
}
function cancelCheckEdit(){
 editingCheckId=null;
 const form=el('checkNumber')?.closest('form');if(form)form.reset();
 resetCheckEditUI();
}
function updateCheckStatus(id,status){
 const c=(db.checks||[]).find(x=>String(x.id)===String(id));if(!c)return;c.status=status;save();renderChecks();
}
function deleteCheck(id){
 if(!confirm('هل تريد حذف هذا الشيك؟'))return;
 if(String(editingCheckId)===String(id))cancelCheckEdit();
 db.checks=(db.checks||[]).filter(x=>String(x.id)!==String(id));save();renderChecks();
}
function renderNotifications(){
 const box=el('notificationsList'), badge=el('notificationBadge');
 if(!box)return;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const until=new Date(today); until.setDate(until.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending'||!c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today&&d<=until;
 }).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 if(badge){badge.textContent=upcoming.length;badge.style.display=upcoming.length?'inline-block':'none';}
 box.innerHTML=upcoming.length?upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-bottom:10px;background:#fff8e1;border-right:4px solid #f0ad4e"><b>🔔 شيك رقم ${esc(c.number)}</b><div style="margin-top:6px">المستفيد: ${esc(c.beneficiary)}</div><div>المبلغ: <b>${money(c.amount)}</b></div><div>تاريخ الدخول: <b>${esc(c.date)}</b> — ${when}</div></div>`}).join(''):'<div class="empty card">لا توجد إشعارات حالياً.</div>';
}
function handleCheckSearch(type){
 const nameEl=el('checkSearchName'), numberEl=el('checkSearchNumber');
 if(type==='name' && nameEl?.value) { if(numberEl) numberEl.value=''; }
 if(type==='number' && numberEl?.value) { if(nameEl) nameEl.value=''; }
 renderChecks();
}
function renderChecks(){
 if(!el('checkList'))return;if(!Array.isArray(db.checks))db.checks=[];
 const searchName=String(el('checkSearchName')?.value||'').trim().toLowerCase();
 const searchNumber=String(el('checkSearchNumber')?.value||'').trim().toLowerCase();
 const checkMatches=c=>{
   if(searchName) return String(c.beneficiary||'').toLowerCase().includes(searchName);
   if(searchNumber) return String(c.number||'').toLowerCase().includes(searchNumber);
   return true;
 };
 const rows=db.checks.filter(checkMatches).slice().sort((a,b)=>new Date(a.date||'9999-12-31')-new Date(b.date||'9999-12-31'));
 const searchResult=el('checkSearchResult');
 if(searchResult){
   const hasSearch=!!(searchName||searchNumber);
   searchResult.style.display=hasSearch?'block':'none';
   if(hasSearch){
     const title=searchName?`🔎 نتيجة البحث باسم الشركة: ${esc(el('checkSearchName')?.value||searchName)}`:`🔎 نتيجة البحث برقم الشيك: ${esc(el('checkSearchNumber')?.value||searchNumber)}`;
     searchResult.innerHTML=`<div class="check-search-result-title">${title}</div>`+(rows.length
       ? `<div style="overflow:auto"><table><tr><th>رقم الشيك</th><th>اسم الشركة</th><th>المبلغ</th><th>التاريخ</th><th>الحالة</th></tr>${rows.map(c=>{const status=c.status==='cashed'?'تم صرفه':c.status==='cancelled'?'ملغى':'في الانتظار';return `<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td><td>${status}</td></tr>`}).join('')}</table></div>`
       : '<div class="check-result-empty">لا توجد شيكات مطابقة للبحث.</div>');
   }
 }
 const total=rows.reduce((a,c)=>a+Number(c.amount||0),0);
 const pending=rows.filter(c=>c.status==='pending').reduce((a,c)=>a+Number(c.amount||0),0);
 const cashed=rows.filter(c=>c.status==='cashed').reduce((a,c)=>a+Number(c.amount||0),0);
 const sum=el('checkSummary');if(sum)sum.innerHTML=`<div class="card">مجموع الشيكات<b>${money(total)}</b><span class="small">${rows.length} شيك</span></div><div class="card">في الانتظار<b>${money(pending)}</b></div><div class="card">تم صرفه<b>${money(cashed)}</b></div>`;
 const now=new Date();
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const alertUntil=new Date(today); alertUntil.setDate(alertUntil.getDate()+3);
 const upcoming=(db.checks||[]).filter(c=>{
   if(c.status!=='pending' || !c.date)return false;
   const d=new Date(String(c.date)+'T00:00:00');
   return d>=today && d<=alertUntil;
 }).filter(checkMatches).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const alerts=el('checkAlerts');
 if(alerts){
   alerts.style.display=upcoming.length?'block':'none';
   alerts.innerHTML=upcoming.length?'<h3>🔔 إشعار الشيكات القريبة</h3><div class="small">هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:</div>'+upcoming.map(c=>{const d=new Date(String(c.date)+'T00:00:00');const diff=Math.ceil((d-today)/86400000);const when=diff===0?'اليوم':diff===1?'غداً':'بعد '+diff+' أيام';return `<div class="card" style="margin-top:8px;background:#fff8e1"><b>شيك ${esc(c.number)}</b> — ${esc(c.beneficiary)} — ${money(c.amount)}<br><span class="small">تاريخ الشيك: ${esc(c.date)} • ${when}</span></div>`}).join(''):'';
 }
 const scheduled=(db.checks||[]).filter(c=>c.status==='pending' && String(c.date||'')>=today.toISOString().slice(0,10)).filter(checkMatches).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const sched=el('scheduledCheckList'); if(sched) sched.innerHTML=scheduled.length?'<div style="overflow:auto"><table><tr><th>رقم الشيك</th><th>المستفيد</th><th>المبلغ</th><th>تاريخ الشيك</th></tr>'+scheduled.map(c=>`<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td></tr>`).join('')+'</table></div>':'<div class="empty">لا توجد شيكات مبرمجة</div>';
 el('checkList').innerHTML=rows.length?'<div class="card"><h3>📋 جميع الشيكات — الأقرب تاريخاً أولاً</h3><div style="overflow:auto"><table><tr><th>الرقم</th><th>المستفيد</th><th>المبلغ</th><th>التاريخ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>{const status=c.status==='cashed'?'<span class="badge">تم صرفه</span>':c.status==='cancelled'?'<span class="badge" style="background:#fde8e8;color:#a33">ملغى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">في الانتظار</span>';return `<tr><td>${esc(c.number)}</td><td>${esc(c.beneficiary)}${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${esc(c.date||'-')}</td><td>${status}</td><td><select onchange="updateCheckStatus('${c.id}',this.value)"><option value="pending" ${c.status==='pending'?'selected':''}>في الانتظار</option><option value="cashed" ${c.status==='cashed'?'selected':''}>تم صرفه</option><option value="cancelled" ${c.status==='cancelled'?'selected':''}>ملغى</option></select><button type="button" class="outline check-action-edit" onclick="editCheck('${c.id}')">✏️ تعديل</button><button type="button" class="danger" onclick="deleteCheck('${c.id}')">🗑️ حذف</button></td></tr>`}).join('')+'</table></div></div>':'<div class="empty card">لا توجد شيكات مسجلة</div>';
}
function todayISO(){
 const d=new Date();
 const pad=n=>String(n).padStart(2,'0');
 return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
}
function saveDailyExpenseOne(){
 const date=el('dailyOneDate')?.value||todayISO();
 const name=String(el('dailyOneName')?.value||'').trim();
 const amountText=String(el('dailyOneAmount')?.value||'').trim();
 const normalizedAmount=amountText.replace(',', '.');
 const amount=Number(normalizedAmount);
 if(!date){alert('اختر التاريخ');return false;}
 if(!name){alert('أدخل نوع المصروف');return false;}
 if(!amountText || !Number.isFinite(amount) || amount<0){alert('أدخل مبلغاً صحيحاً');return false;}
 if(!Array.isArray(db.expenses)) db.expenses=[];
 const item={id:'exp_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),date:date+'T12:00:00',name:name,amount:amount};
 db.expenses.push(item);
 try{
   saveLocal();
   const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
   if(!saved || !Array.isArray(saved.expenses) || !saved.expenses.some(x=>String(x.id)===String(item.id))) throw new Error('لم يتم تأكيد الحفظ');
 }catch(e){
   db.expenses=db.expenses.filter(x=>String(x.id)!==String(item.id));
   alert('تعذر حفظ المصروف في ذاكرة الهاتف');
   return false;
 }
 renderDailyExpenseEntry();
 renderExpenses();
 const d=el('dailyOneDate'), n=el('dailyOneName'), a=el('dailyOneAmount');
 if(d)d.value=date; if(n){n.value='';n.focus();} if(a)a.value='';
 alert('تم حفظ المصروف بنجاح');
 return true;
}

function deleteDailyExpense(id){
 if(!id)return;
 if(!confirm('هل تريد حذف هذا المصروف؟'))return;
 db.expenses=(db.expenses||[]).filter(x=>String(x.id||'')!==String(id));
 save();
 renderDailyExpenseEntry();
 renderExpenses();
}
function renderDailyExpenseEntry(){
 const box=el('dailyExpenseEntry');
 if(!box)return;
 const entries=(Array.isArray(db.expenses)?db.expenses:[]).map((x,i)=>({...x,__i:i})).sort((a,b)=>{const da=Date.parse(a.date||'')||0, dbb=Date.parse(b.date||'')||0; return dbb-da || (b.__i-a.__i);});
 const rows=entries.map(x=>{
   const dt=new Date(x.date||'');
   const date=!Number.isNaN(dt.getTime())?dt.toLocaleDateString('ar-MA') : String(x.date||'-').slice(0,10);
   const id=String(x.id||x.__i);
   if(!x.id)x.id=id;
   return `<tr><td>${esc(date)}</td><td>${esc(x.name||'-')}</td><td class="daily-amount-cell"><span class="daily-amount">${money(x.amount||0)}</span></td><td><button type="button" class="daily-delete-one" onclick="deleteDailyExpense('${esc(id)}')">×</button></td></tr>`;
 }).join('');
 box.innerHTML=`<div class="daily-entry-title">📅 إضافة المصاريف اليومية</div>
 <div class="daily-one-form">
   <label>تاريخ اليوم</label>
   <input id="dailyOneDate" type="date" value="${todayISO()}">
   <label>نوع المصروف</label>
   <input id="dailyOneName" type="text" placeholder="اكتب نوع المصروف">
   <label>المبلغ</label>
   <input id="dailyOneAmount" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0.00 DH">
   <button type="button" class="danger daily-save-one" onclick="saveDailyExpenseOne()">💾 حفظ المصروف اليومي</button>
 </div>
 <div class="daily-saved-title">📋 المصاريف التي تم تسجيلها</div>
 <div class="daily-expenses-total"><span>مجموع المصاريف</span><b>${money((Array.isArray(db.expenses)?db.expenses:[]).reduce((sum,x)=>sum+Number(x.amount||0),0))}</b></div>
 <div class="daily-entry-wrap"><table class="daily-saved-table"><thead><tr><th>التاريخ</th><th>نوع المصروف</th><th>المبلغ</th><th></th></tr></thead><tbody id="dailyExpenseRows">${rows || '<tr><td colspan="4" class="daily-empty">لا توجد مصاريف مسجلة بعد</td></tr>'}</tbody></table></div>`;
}

function renderExpenses(){
 renderDailyExpenseEntry();
 const type=el('expSearchType'), value=el('expSearchValue'), year=el('expSearchYear'), list=el('expList');
 if(!type||!value||!list)return;
 const currentType=type.value||'';
 const currentValue=value.value||'';
 const currentYear=year?.value||'';
 const expenses=Array.isArray(db.expenses)?db.expenses:[];
 const years=[...new Set(expenses.map(x=>{const d=new Date(x.date||0);return Number.isNaN(d.getTime())?null:d.getFullYear();}).filter(y=>y))].sort((a,b)=>b-a);
 const months=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
 if(currentType==='month'){
   value.innerHTML='<option value="">اختر الشهر</option>'+months.map((m,i)=>`<option value="${i+1}">${m}</option>`).join('');
   value.value=currentValue;
   if(year){year.style.display='block';year.innerHTML='<option value="">اختر السنة</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');year.value=currentYear;}
 }else if(currentType==='year'){
   value.innerHTML='<option value="">اختر السنة</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
   value.value=currentValue;
   if(year){year.style.display='none';year.innerHTML='<option value=""></option>';year.value='';}
 }else{
   value.innerHTML='<option value="">اختر أولاً نوع البحث</option>';
   if(year){year.style.display='none';year.innerHTML='<option value=""></option>';year.value='';}
 }
 if(!currentType || !currentValue || (currentType==='month' && !currentYear)){
   list.innerHTML='';
   return;
 }
 const amountForDay=(y,m,d)=>expenses.filter(x=>{const dt=new Date(x.date||0);return !Number.isNaN(dt.getTime())&&dt.getFullYear()===y&&dt.getMonth()+1===m&&dt.getDate()===d;}).reduce((a,x)=>a+Number(x.amount||0),0);
 const entriesForDay=(y,m,d)=>expenses.filter(x=>{const dt=new Date(x.date||0);return !Number.isNaN(dt.getTime())&&dt.getFullYear()===y&&dt.getMonth()+1===m&&dt.getDate()===d;});
 if(currentType==='month'){
   const m=Number(currentValue), y=Number(currentYear), daysInMonth=new Date(y,m,0).getDate();
   let monthTotal=0;
   const rows=[];
   for(let d=1;d<=daysInMonth;d++){
     const total=amountForDay(y,m,d); monthTotal+=total;
     const dayEntries=entriesForDay(y,m,d);
     const details=dayEntries.length?dayEntries.map(x=>`${esc(x.name)}: ${money(x.amount)}`).join('<br>'):'<span class="small">0.00 DH</span>';
     rows.push(`<tr><td>${d}</td><td>${details}</td><td><b>${money(total)}</b></td></tr>`);
   }
   list.innerHTML=`<div class="card expense-report-card" style="margin-top:8px;padding:8px"><div class="card expense-total-box" style="text-align:center;margin:0 0 10px;padding:16px 10px;border:3px solid #0b4f8a;border-radius:14px;background:#f7fbff"><span style="font-size:20px;font-weight:bold;display:block">جميع مصاريف الشهر ${esc(months[m-1])} سنة ${y}</span><b style="font-size:30px;display:block;margin-top:6px">${money(monthTotal)}</b></div><h3 style="margin:2px 0 6px;font-size:14px">📅 ${esc(months[m-1])} ${y}</h3><div style="overflow:auto"><table class="expense-report-table"><tr><th>اليوم</th><th>المصاريف</th><th>مجموع اليوم</th></tr>${rows.join('')}</table></div></div>`;
   return;
 }
 if(currentType==='year'){
   const y=Number(currentValue);
   const monthlyTotals=Array.from({length:12},(_,i)=>({month:i+1,total:0}));
   expenses.forEach(x=>{const d=new Date(x.date||0);if(!Number.isNaN(d.getTime())&&d.getFullYear()===y)monthlyTotals[d.getMonth()].total+=Number(x.amount||0);});
   const annualTotal=monthlyTotals.reduce((a,x)=>a+x.total,0);
   const rows=monthlyTotals.map((m,i)=>`<tr><td>${i+1}</td><td>${months[i]}</td><td><b>${money(m.total)}</b></td></tr>`).join('');
   list.innerHTML=`<div class="card expense-report-card" style="margin-top:8px;padding:8px"><div class="card expense-total-box" style="text-align:center;margin:0 0 10px;padding:16px 10px;border:3px solid #0b4f8a;border-radius:14px;background:#f7fbff"><span style="font-size:20px;font-weight:bold;display:block">جميع مصاريف السنة ${y}</span><b style="font-size:30px;display:block;margin-top:6px">${money(annualTotal)}</b></div><h3 style="margin:2px 0 6px;font-size:14px">📅 مصاريف سنة ${y}</h3><div style="overflow:auto"><table class="expense-report-table"><tr><th>رقم الشهر</th><th>الشهر</th><th>مجموع الشهر</th></tr>${rows}</table></div></div>`;
 }
}

function renderCredit(){
 if(!el('creditList'))return;
 if(!Array.isArray(db.credits))db.credits=[];
 const open=db.credits.filter(x=>!x.paid), paid=db.credits.filter(x=>x.paid);
 const openTotal=open.reduce((a,x)=>a+Number(x.amount||0),0), paidTotal=paid.reduce((a,x)=>a+Number(x.amount||0),0);
 const sum=el('creditSummary'); if(sum)sum.innerHTML=`<div class="card">المستحق حالياً<b>${money(openTotal)}</b></div><div class="card">عدد الديون<b>${open.length}</b></div>`;
 const sel=el('creditCustomer'); if(sel){const current=sel.value;sel.innerHTML='<option value="">اختر الزبون</option>'+db.customers.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}${c.phone?' - '+esc(c.phone):''}</option>`).join('');if(current)sel.value=current;}
 const nameSearch=(el('creditNameSearch')?.value||'').trim().toLowerCase();
 const phoneSearch=(el('creditPhoneSearch')?.value||'').trim().toLowerCase();
 const noteSearch=(el('creditNoteSearch')?.value||'').trim().toLowerCase();
 const rows=db.credits.filter(c=>{return (!nameSearch||String(c.customerName||'').toLowerCase().includes(nameSearch))&&(!phoneSearch||String(c.phone||'').toLowerCase().includes(phoneSearch))&&(!noteSearch||String(c.note||'').toLowerCase().includes(noteSearch));}).slice().sort((a,b)=>new Date(b.date||0)-new Date(a.date||0));
 el('creditList').innerHTML=rows.length?'<div class="card"><table><tr><th>التاريخ</th><th>الزبون</th><th>المبلغ</th><th>الحالة</th><th></th></tr>'+rows.map(c=>`<tr><td>${esc(new Date(c.date||0).toLocaleDateString('ar-MA'))}</td><td>${esc(c.customerName||'-')}<div class="small">${esc(c.phone||'')}</div>${c.note?'<div class="small">'+esc(c.note)+'</div>':''}</td><td><b>${money(c.amount)}</b></td><td>${c.paid?'<span class="badge">مؤدى</span>':'<span class="badge" style="background:#fff3cd;color:#856404">باقي</span>'}</td><td>${c.paid?'':'<button type="button" onclick="markCreditPaid(\''+c.id+'\')">✅ تسديد</button>'}<button type="button" class="danger" onclick="deleteCredit(\''+c.id+'\')">🗑️</button></td></tr>`).join('')+'</table></div>':'<div class="empty card">لا توجد ديون مسجلة</div>';
}
function renderProductCardsSearch(){ render(); }
function render(){
 syncStockPurchasePrices();
 renderProductSection();
 syncCatalogLinks();
 renderStockProductOptions();
 renderStockRefOptions(el('pref')?.value||'');
 renderPurchasePriceSection();
 renderPurchasePriceForm();
 renderMasterProductsTable();
 renderMasterProductOptions();
 renderCompanyPricesTable();
 renderCompanyNames();
 renderStockSearchOptions();
 renderQuickSaleRefs(false);
 el('cStock').textContent=money(db.stock.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0));
 const nowForHome=new Date();
 const lastMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth()-1,1);
 const thisMonthStart=new Date(nowForHome.getFullYear(),nowForHome.getMonth(),1);
 const lastMonthSales=db.sales.reduce((sum,x)=>{const d=new Date(x.date||0); return d>=lastMonthStart && d<thisMonthStart ? sum+Number(x.total||0) : sum;},0);
 el('cSales').textContent=money(db.sales.reduce((a,x)=>a+Number(x.total||0),0));
 el('cLastMonthSales').textContent=money(lastMonthSales);
 el('cExp').textContent=money(db.expenses.reduce((a,x)=>a+Number(x.amount||0),0));
 const creditTotal=(db.credits||[]).filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0); if(el('cCredit'))el('cCredit').textContent=money(creditTotal);
 const nameTerm=normalizeProductName(el('stockNameSearch')?.value||'');
 const term=(el('stockSearch')?.value||'').trim().toLowerCase();
 const filtered=db.stock.filter(x=>{const name=normalizeProductName(x.name||'');const ref=String(x.ref||'').toLowerCase();return (!nameTerm||name===nameTerm)&&(!term||ref===term);});
 const searchReady=!!nameTerm&&!!term;
 const totalQty=filtered.reduce((a,x)=>a+Number(x.qty||0),0);
 const totalBuy=filtered.reduce((a,x)=>a+(Number(x.qty||0)*Number(x.buy||0)),0);
 const searchedProduct=searchReady && filtered.length===1 ? filtered[0] : null;
 el('searchStats').innerHTML=searchReady?`<div class="stock-search-summary"><div class="stock-search-summary-head">🔎 نتيجة البحث</div><div class="stock-search-summary-grid"><div><span>اسم المنتوج</span><b>${esc(el('stockNameSearch')?.value||'-')}</b></div><div><span>رقم المنتوج</span><b>${esc(el('stockSearch')?.value||'-')}</b></div><div class="stock-search-summary-qty"><span>عدد المنتوج</span><b>${totalQty}</b></div><div class="stock-search-summary-total"><span>مجموع الثمن</span><b>${money(totalBuy)}</b></div></div></div>`:'';
 const accountingRows=filtered.map(x=>{const qty=Number(x.qty||0);const buy=Number(x.buy||0);const productTotal=qty*buy;return `<tr><td>${esc(x.name||'-')}</td><td>${esc(x.ref||'-')}</td><td><b>${qty}</b></td><td><b>${money(productTotal)}</b></td></tr>`}).join('');
 const displayRows=searchReady?filtered:db.stock;
 const totalAllValue=displayRows.reduce((a,x)=>a+Number(x.qty||0)*Number(x.buy||0),0);
 const grouped=new Map();
 displayRows.forEach(x=>{const key=normalizeProductName(x.name||'');if(!grouped.has(key)) grouped.set(key,{name:x.name||'-',image:x.image||'',items:[]});const g=grouped.get(key);if(!g.image&&x.image)g.image=x.image;g.items.push(x);});
 const groups=[...grouped.values()].sort((a,b)=>compareNamesAZ(a.name,b.name));
 const cardSearch=String(el('productCardsSearch')?.value||'').trim().toLowerCase();
 const searchedGroups=cardSearch?groups.filter(g=>String(g.name||'').toLowerCase().includes(cardSearch)||g.items.some(x=>String(x.ref||'').toLowerCase().includes(cardSearch))):groups;
 const visibleGroups = selectedStockCardName ? searchedGroups.filter(g=>normalizeProductName(g.name)===normalizeProductName(selectedStockCardName)) : searchedGroups;
 el('stockList').innerHTML=visibleGroups.length?`<div class="stock-total-banner">${selectedStockCardName?'<button type="button" onclick="clearStockCardSelection()" style="margin-bottom:8px;width:100%">⬅️ رجوع إلى جميع المنتوجات</button>':''}<span>${selectedStockCardName?'📦 معلومات المنتوج المختار':'إجمالي قيمة المنتجات المعروضة'}</span><b>${selectedStockCardName?esc(visibleGroups[0].name):money(totalAllValue)}</b></div>`+visibleGroups.map(g=>{
   const totalQty=g.items.reduce((a,x)=>a+Number(x.qty||0),0);
   const totalValue=g.items.reduce((a,x)=>a+Number(x.qty||0)*Number(x.buy||0),0);
   const rows=[...g.items].sort((a,b)=>{const na=Number(String(a.ref||'').replace(/[^0-9.-]/g,''));const nb=Number(String(b.ref||'').replace(/[^0-9.-]/g,''));if(Number.isFinite(na)&&Number.isFinite(nb)&&na!==nb)return nb-na;return compareRefsDesc(b.ref,a.ref);}).map(x=>{const q=Number(x.qty||0),buy=Number(x.buy||0),v=q*buy;return `<tr><td class="ref-cell">${esc(x.ref||'-')}</td><td><b>${q}</b></td><td>${money(buy)}</td><td class="sum-cell">${money(v)}</td><td class="edit-cell"><button type="button" onclick="event.stopPropagation();editStock(${x.id})">✏️</button></td></tr>`}).join('');
   const refs=`<div style="overflow-x:auto"><table class="stock-items-table"><thead><tr><th>رقم المنتوج</th><th>العدد</th><th>ثمن الشراء</th><th>مجموع الثمن</th><th>تعديل</th></tr></thead><tbody>${rows}</tbody></table></div><div class="stock-card-bottom-total"><span>💰 مجموع الثمن</span><strong>${money(totalValue)}</strong></div>`;
   const encodedName=encodeURIComponent(g.name);
   return `<div class="stock-card-v11 stock-color-${groups.indexOf(g)%10} ${selectedStockCardName?'stock-card-selected':''}" onclick="selectStockCard(decodeURIComponent('${encodedName}'))"><div class="stock-card-head">${g.image?`<img class="stock-card-image" src="${g.image}" alt="${esc(g.name)}">`:'<div class="stock-card-image" style="display:flex;align-items:center;justify-content:center;font-size:38px">📦</div>'}<div><div class="stock-card-name">${esc(g.name)}</div><div class="stock-card-summary">📦 مجموع الكمية: <strong>${totalQty}</strong></div></div></div>${refs}<div class="stock-card-actions"><button type="button" onclick="event.stopPropagation();editStock(${g.items[0].id})">✏️ تعديل الكمية</button><button type="button" class="stock-delete-group-btn" onclick="event.stopPropagation();deleteStockGroup('${encodedName}')">🗑️ تفريغ المخزون</button></div></div>`;
 }).join(''):`<div class="empty card">${db.stock.length?'لا توجد نتائج للبحث':'لا توجد سلع في المخزون بعد'}</div>`;
 const now=new Date();
 const todaySales=db.sales.filter(x=>{const d=new Date(x.date);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).slice().reverse();
 const filteredRevenue=todaySales.reduce((a,x)=>a+Number(x.total||0),0), filteredProfit=todaySales.reduce((a,x)=>a+saleProfit(x),0);
 const todayExpenses=db.expenses.filter(x=>{const d=new Date(x.date||0);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();}).reduce((a,x)=>a+Number(x.amount||0),0);
 const monthSales=db.sales.filter(x=>{const d=new Date(x.date||0);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth();});
 const monthlyRevenue=monthSales.reduce((a,x)=>a+Number(x.total||0),0);
 const _dNow=new Date();
  const _daysAr=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const _monthsAr=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
  const _dateAr=`${_daysAr[_dNow.getDay()]} ${_dNow.getDate()} ${_monthsAr[_dNow.getMonth()]} ${_dNow.getFullYear()}`;
  const _monthAr=`شهر ${_monthsAr[_dNow.getMonth()]} ${_dNow.getFullYear()}`;
  el('salesSummary').innerHTML=`<div class="card sales-expense-card">مصاريف اليوم<span class="date-label">${_dateAr}</span><b>${money(todayExpenses)}</b></div><div class="card sales-income-card">المدخول اليومي<span class="date-label">${_dateAr}</span><b>${money(filteredRevenue)}</b></div><div class="card sales-month-card monthly-income-card">المدخول الشهري<span class="date-label">${_monthAr}</span><b>${money(monthlyRevenue)}</b></div><div class="card sales-profit-card profit-card">الأرباح اليوم<span class="date-label">${_dateAr}</span><b>${money(filteredProfit)}</b></div>`;
 el('salesRows').innerHTML=todaySales.length?todaySales.flatMap(x=>saleItems(x).map(it=>{const d=new Date(x.date),profit=saleItemProfit(it),price=Number(it.price||it.salePrice||0),qty=Number(it.qty||it.quantity||1),revenue=saleItemTotal(it);const p=db.stock.find(z=>String(z.id)===String(it.productId)||String(z.ref||'')===String(it.ref||''));const remaining=it.remainingQty!==undefined?Number(it.remainingQty):(p?Number(p.qty||0):'-');return `<tr><td class="sales-date">${esc(d.toLocaleDateString('ar-MA'))}</td><td>${esc(it.ref||'-')}</td><td>${qty}</td><td>${money(price)}</td><td class="${profit>=0?'profit-positive':'profit-negative'}">${money(profit)}</td><td><b>${remaining}</b></td></tr>`})).join(''):'<tr><td colspan="6" style="text-align:center;padding:18px">لا توجد مبيعات اليوم</td></tr>';
 const daily=dailySalesData();
 el('dailySalesRows').innerHTML=daily.length?daily.map(r=>`<tr><td class="sales-date">${esc(r.date)}</td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${(r.profit-r.expenses)>=0?'profit-positive':'profit-negative'}">${money(r.profit-r.expenses)}</td></tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';

 // الملخص الشهري: يجمع كل المداخيل والمصاريف والأرباح والصافي لكل شهر موجود في البيانات.
 const monthlyMap=new Map();
 (db.sales||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
   const row=monthlyMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.revenue+=Number(x.total||0); row.profit+=saleProfit(x); row.salesCount+=1; monthlyMap.set(key,row);
 });
 (db.expenses||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
   const row=monthlyMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.expenses+=Number(x.amount||0); row.expenseCount+=1; monthlyMap.set(key,row);
 });
 const monthlyRows=[...monthlyMap.values()].sort((a,b)=>b.key.localeCompare(a.key));
 const monthNamesAr=['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
 const monthLabel=(key)=>{const [yy,mm]=key.split('-').map(Number);return `${monthNamesAr[(mm||1)-1]} ${yy}`;};
 const monthlyRevenueTotal=monthlyRows.reduce((a,r)=>a+r.revenue,0);
 const monthlyProfitTotal=monthlyRows.reduce((a,r)=>a+r.profit,0);
 const monthlyExpenseTotal=monthlyRows.reduce((a,r)=>a+r.expenses,0);
 if(el('monthlySalesRows')) el('monthlySalesRows').innerHTML=monthlyRows.length?monthlyRows.map(r=>{const net=r.revenue-r.expenses;return `<tr><td class="sales-date"><b>${esc(monthLabel(r.key))}</b></td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${net>=0?'profit-positive':'profit-negative'}">${money(net)}</td><td>${r.expenseCount}</td></tr>`}).join(''):'<tr><td colspan="7" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';
 if(el('monthlySalesTotal')) el('monthlySalesTotal').innerHTML=monthlyRows.length?`<tr><th>المجموع</th><th>${money(monthlyRevenueTotal)}</th><th>${money(monthlyProfitTotal)}</th><th>${money(monthlyExpenseTotal)}</th><th class="${(monthlyRevenueTotal-monthlyExpenseTotal)>=0?'profit-positive':'profit-negative'}">${money(monthlyRevenueTotal-monthlyExpenseTotal)}</th><th>${monthlyRows.reduce((a,r)=>a+r.expenseCount,0)}</th></tr>`:'';

 // الملخص السنوي: يجمع نفس بيانات الملخص الشهري حسب كل سنة.
 const annualMap=new Map();
 (db.sales||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=String(d.getFullYear());
   const row=annualMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.revenue+=Number(x.total||0); row.profit+=saleProfit(x); row.salesCount+=1; annualMap.set(key,row);
 });
 (db.expenses||[]).forEach(x=>{
   const d=new Date(x.date||0); if(Number.isNaN(d.getTime())) return;
   const key=String(d.getFullYear());
   const row=annualMap.get(key)||{key,revenue:0,profit:0,expenses:0,salesCount:0,expenseCount:0};
   row.expenses+=Number(x.amount||0); row.expenseCount+=1; annualMap.set(key,row);
 });
 const annualRows=[...annualMap.values()].sort((a,b)=>Number(b.key)-Number(a.key));
 const annualRevenueTotal=annualRows.reduce((a,r)=>a+r.revenue,0);
 const annualProfitTotal=annualRows.reduce((a,r)=>a+r.profit,0);
 const annualExpenseTotal=annualRows.reduce((a,r)=>a+r.expenses,0);
 if(el('annualSalesRows')) el('annualSalesRows').innerHTML=annualRows.length?annualRows.map(r=>{const net=r.revenue-r.expenses;return `<tr><td class="sales-date"><b>${esc(r.key)}</b></td><td>${money(r.revenue)}</td><td class="${r.profit>=0?'profit-positive':'profit-negative'}">${money(r.profit)}</td><td>${money(r.expenses)}</td><td class="${net>=0?'profit-positive':'profit-negative'}">${money(net)}</td><td>${r.expenseCount}</td></tr>`}).join(''):'<tr><td colspan="7" style="text-align:center;padding:18px">لا توجد بيانات</td></tr>';
 if(el('annualSalesTotal')) el('annualSalesTotal').innerHTML=annualRows.length?`<tr><th>المجموع</th><th>${money(annualRevenueTotal)}</th><th>${money(annualProfitTotal)}</th><th>${money(annualExpenseTotal)}</th><th class="${(annualRevenueTotal-annualExpenseTotal)>=0?'profit-positive':'profit-negative'}">${money(annualRevenueTotal-annualExpenseTotal)}</th><th>${annualRows.reduce((a,r)=>a+r.expenseCount,0)}</th></tr>`:'';
 el('custList').innerHTML=db.customers.length?'<table><tr><th>الزبون</th><th>الهاتف</th></tr>'+db.customers.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||'-')}</td></tr>`).join('')+'</table>':'<div class="empty">لا يوجد زبائن</div>';
 renderExpenses();
 const reportInput=el('reportMonth');
if(reportInput && !reportInput.value){
  const d=new Date(); reportInput.value=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
if(el('monthlyReportCards')){
  const ym=reportInput?.value||'';
  const [ry,rm]=ym.split('-').map(Number);
  const reportYear=el('reportYear');
  if(reportYear && !reportYear.value) reportYear.value=ry || new Date().getFullYear();
  const selectedYear=Number(reportYear?.value||new Date().getFullYear());
  const inMonth=(date)=>{const d=new Date(date||0);return d.getFullYear()===ry && d.getMonth()+1===rm;};
  const inYear=(date)=>{const d=new Date(date||0);return d.getFullYear()===selectedYear;};
  const ms=db.sales.filter(x=>inMonth(x.date));
  const me=db.expenses.filter(x=>inMonth(x.date));
  const mc=(db.credits||[]).filter(x=>inMonth(x.date));
  const salesTotal=ms.reduce((a,x)=>a+Number(x.total||0),0);
  const profitTotal=ms.reduce((a,x)=>a+saleProfit(x),0);
  const expensesTotal=me.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditAdded=mc.reduce((a,x)=>a+Number(x.amount||0),0);
  const creditOpen=mc.filter(x=>!x.paid).reduce((a,x)=>a+Number(x.amount||0),0);
  const net=profitTotal-expensesTotal;
  el('monthlyReportCards').innerHTML=
    `<div class="card">مجموع المبيعات الشهرية<b>${money(salesTotal)}</b><span class="small">${ms.length} عملية</span></div>
     <div class="card">مجموع أرباح الشهر<b>${money(profitTotal)}</b><span class="small">قبل المصاريف</span></div>
     <div class="card">مجموع المصاريف الشهرية<b>${money(expensesTotal)}</b><span class="small">${me.length} مصروف</span></div>
     <div class="card">صافي الربح بعد المصاريف<b>${money(net)}</b><span class="small">الأرباح − المصاريف</span></div>
     <div class="card">مجموع الكريدي المسجل<b>${money(creditAdded)}</b><span class="small">خلال الشهر المختار</span></div>
     <div class="card">الكريدي المتبقي<b>${money(creditOpen)}</b><span class="small">غير المؤدى من كريدي الشهر</span></div>
     <div class="card">عدد عمليات البيع<b>${ms.length}</b><span class="small">خلال الشهر</span></div>`;
  const yearlyCashedChecks=(db.checks||[]).filter(c=>c.status==='cashed' && inYear(c.date));
  const yearlyCashedAmount=yearlyCashedChecks.reduce((a,c)=>a+Number(c.amount||0),0);
  const yearlyChecksTotal=(db.checks||[]).filter(c=>inYear(c.date)).reduce((a,c)=>a+Number(c.amount||0),0);
  if(el('annualCheckReport')) el('annualCheckReport').innerHTML=
    `<div class="card"><h3 style="margin-top:0">💰 حساب صرف الشيكات السنوي — ${selectedYear}</h3><span class="small">إجمالي قيمة الشيكات التي تم وضع حالتها "تم صرفه" خلال السنة</span><b>${money(yearlyCashedAmount)}</b><span class="small">عدد الشيكات المصروفة: ${yearlyCashedChecks.length}</span></div>
     <div class="card">إجمالي الشيكات المسجلة في السنة<b>${money(yearlyChecksTotal)}</b><span class="small">يشمل جميع الحالات</span></div>`;
}
 renderDeliveryEditor();
 renderCredit();
 renderNotifications();
 renderChecks();
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
window.addEventListener('load',async()=>{await afzHydratePersistentData();
  // تنظيف المخزون المسجل مرة واحدة: نحافظ على المنتجات/الأرقام وتعريفة الشركات وأنواع الجودة، ونفرغ سجلات المخزون فقط.
  try{
    if(localStorage.getItem('afz_stock_cleared_v1')!=='1'){
      db.stock=[];
      saveLocal();
      localStorage.setItem('afz_stock_cleared_v1','1');
    }
    // تفريغ جميع سجلات المبيعات مرة واحدة: نحافظ على المنتجات والمخزون والشركات والجودة وباقي البيانات.
    if(localStorage.getItem('afz_sales_cleared_v1')!=='1'){
      db.sales=[];
      saveLocal();
      localStorage.setItem('afz_sales_cleared_v1','1');
    }
  }catch(e){}
  initQuickSaleSearchFix();const sp=el('saleProduct');if(sp)sp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(sp.value));if(p)el('salePrice').value=''});const dp=el('deliveryProduct');if(dp)dp.addEventListener('change',()=>{const p=db.stock.find(x=>String(x.id)===String(dp.value));if(p){const c=getCatalogProduct(p.productId)||getCatalogProductByName(p.name);el('deliveryProductName').value=c?.name||p.name||'';el('deliveryProductRef').value=p.ref||'';el('deliveryProductPrice').value='';}});const f=el('backupFile');if(f)f.addEventListener('change',e=>{if(e.target.files[0])importBackup(e.target.files[0])});render();renderCart()});

/* Added product numbers: IVECO 90/5, MERS 80/8 */


(function(){
  const AFZ_TRANSLATIONS = {"💰 جميع أثمان المنتجات":"💰 Tous les prix des produits", "🪪 البطاقات التعريفية للمنتوجات":"🪪 Fiches produits", "1️⃣ اسم المنتوج أولاً":"1️⃣ Nom du produit d’abord", "2️⃣ رقم المنتوج ثانياً":"2️⃣ Référence du produit ensuite", "المنتوجات":"Produits", "🔍 ابحث باسم المنتوج":"🔍 Rechercher par nom du produit", "🔍 بحث في بطاقات المنتوجات بالاسم أو الرقم":"🔍 Rechercher dans les fiches produits par nom ou référence", "➕ إضافة منتوج":"➕ Ajouter un produit", "اسم المنتوج":"Nom du produit", "📷 صورة المنتوج":"📷 Image du produit", "حفظ المنتوج":"Enregistrer le produit", "تعديل":"Modifier", "حذف":"Supprimer", "تم حفظ المنتوج بنجاح":"Produit enregistré avec succès", "تم تعديل المنتوج بنجاح":"Produit modifié avec succès", "حذف هذا المنتوج؟":"Supprimer ce produit ?", "لا توجد منتوجات بعد":"Aucun produit pour le moment", "لا توجد نتائج للبحث":"Aucun résultat", "تسيير المخزون والمبيعات والحسابات": "Gestion du stock, des ventes et de la comptabilité", "الرئيسية": "Accueil", "المخزون": "Stock", "المبيعات": "Ventes", "الزبائن": "Clients", "وصل التسليم": "Bon de livraison", "مصاريف اليوم": "Dépenses du jour", "الكريدي": "Crédit", "دفتر الشيكات": "Carnet de chèques", "الإشعارات": "Notifications", "التقارير": "Rapports", "نسخة احتياطية": "Sauvegarde", "مجموع رأس مال المخزون": "Valeur totale du stock", "حسب ثمن الشراء": "Selon le prix d'achat", "مبيعات اليوم": "Ventes du jour", "إجمالي المبيعات": "Total des ventes", "أرباح اليوم": "Bénéfice du jour", "صافي ربح مبيعات اليوم": "Bénéfice net des ventes du jour", "مبيعات الشهر الماضي": "Ventes du mois précédent", "إجمالي مبيعات الشهر السابق": "Total des ventes du mois précédent", "المسجلة": "Enregistrées", "مجموع الكريدي": "Total du crédit", "إجمالي المبالغ غير المؤداة": "Total des montants impayés", "🔍 ابحث بالمرجع أو اسم المنتوج": "🔍 Rechercher par référence ou nom du produit", "🔍 بحث باسم الزبون": "🔍 Rechercher par nom du client", "📞 بحث بالهاتف": "📞 Rechercher par téléphone", "📝 بحث بالملاحظة": "📝 Rechercher par remarque", "🔢 بحث برقم الشيك": "🔢 Rechercher par numéro de chèque", "🔍 بحث باسم المستفيد": "🔍 Rechercher par bénéficiaire", "تحميل بيانات المخزون PDF": "📄 Télécharger le stock en PDF", "إضافة قطعة": "Ajouter un article", "اسم القطعة": "Nom de l'article", "المرجع / Référence": "Référence", "الكمية": "Quantité", "ثمن الشراء DH": "Prix d'achat DH", "صورة المنتوج": "📷 Image du produit", "حفظ القطعة": "Enregistrer l'article", "📊 تسجيل مبيعات اليوم": "📊 Enregistrer les ventes du jour", "تسجيل مبيعات اليوم": "Enregistrer les ventes du jour", "رقم المنتج": "Référence produit", "➕ إضافة بيع": "➕ Ajouter la vente", "التاريخ": "Date", "الأرباح": "Bénéfice", "المتبقي": "Restant", "لا توجد مبيعات اليوم": "Aucune vente aujourd'hui", "📅 الملخص اليومي": "📅 Résumé quotidien", "الملخص اليومي": "Résumé quotidien", "المدخول اليومي": "Chiffre d'affaires du jour", "المدخول الشهري": "Chiffre d'affaires du mois", "الصافي": "Net", "لا توجد بيانات": "Aucune donnée", "تحرير بون دوليفريزون مستقل": "Créer un bon de livraison indépendant", "هذا القسم مستقل تماماً عن قسم المبيعات. إنشاء وتعديل وصل التسليم هنا لا ينشئ بيعاً ولا يغيّر المخزون.": "Cette section est totalement indépendante des ventes. La création ou la modification d'un bon de livraison ici ne crée pas de vente et ne modifie pas le stock.", "اختر الزبون من قسم الزبائن": "Choisir le client depuis la section Clients", "اسم الزبون": "Nom du client", "هاتف الزبون": "Téléphone du client", "عنوان الزبون": "Adresse du client", "إضافة منتج إلى الوصل": "Ajouter un produit au bon", "اسم المنتج": "Nom du produit", "العدد": "Quantité", "الثمن": "Prix", "➕ إضافة المنتج": "➕ Ajouter le produit", "حفظ الوصل": "Enregistrer le bon", "معاينة الوصل": "Aperçu du bon", "⚡ طباعة PDF سريعة": "⚡ Impression PDF rapide", "إضافة زبون": "Ajouter un client", "الهاتف": "Téléphone", "📱 اختيار الزبون من جهة الاتصال": "📱 Choisir le client depuis les contacts", "اختر جهة اتصال من الهاتف وسيتم إدخال الاسم ورقم الهاتف تلقائياً، ثم اضغط حفظ الزبون.": "Choisissez un contact sur le téléphone : le nom et le numéro seront remplis automatiquement, puis appuyez sur Enregistrer le client.", "حفظ الزبون": "Enregistrer le client", "إدارة الكريدي": "Gestion du crédit", "اختر الزبون": "Choisir le client", "مبلغ الكريدي DH": "Montant du crédit DH", "ملاحظة (اختياري)": "Remarque (facultatif)", "تسجيل الكريدي": "Enregistrer le crédit", "رقم الشيك": "Numéro du chèque", "اسم المستفيد": "Bénéficiaire", "مبلغ الشيك DH": "Montant du chèque DH", "في الانتظار": "En attente", "تم صرفه": "Encaissé", "ملغى": "Annulé", "تسجيل الشيك": "Enregistrer le chèque", "جدول الشيكات المبرمجة": "Tableau des chèques programmés", "تنبيهات الشيكات التي اقترب تاريخ دخولها إلى البنك.": "Alertes pour les chèques dont la date de dépôt à la banque approche.", "إضافة مصروف": "Ajouter une dépense", "نوع المصروف": "Type de dépense", "المبلغ DH": "Montant DH", "حفظ المصروف": "Enregistrer la dépense", "حفظ واسترجاع البيانات": "Sauvegarde et restauration des données", "البيانات تحفظ داخل الهاتف. يمكنك أيضًا أخذ نسخة احتياطية.": "Les données sont enregistrées sur le téléphone. Vous pouvez également créer une sauvegarde.", "📥 تصدير نسخة احتياطية": "📥 Exporter une sauvegarde", "اختر ملف JSON لاسترجاع البيانات.": "Choisissez un fichier JSON pour restaurer les données.", "📊 التقارير الشهرية والسنوية": "📊 Rapports mensuels et annuels", "اختر الشهر": "Choisir le mois", "السنة": "Année", "المسجل": "Enregistré", "قبل المصاريف": "Avant dépenses", "خلال الشهر المختار": "Pendant le mois sélectionné", "غير المؤدى من كريدي الشهر": "Impayé du crédit du mois", "عدد عمليات البيع": "Nombre de ventes", "خلال الشهر": "Pendant le mois", "حساب صرف الشيكات السنوي": "Comptabilisation annuelle des chèques encaissés", "إجمالي قيمة الشيكات التي تم وضع حالتها \"تم صرفه\" خلال السنة": "Valeur totale des chèques marqués « Encaissé » pendant l'année", "عدد الشيكات المصروفة": "Nombre de chèques encaissés", "إجمالي الشيكات المسجلة في السنة": "Total des chèques enregistrés dans l'année", "يشمل جميع الحالات": "Toutes les situations incluses", "شيك": "chèque", "شيكات": "chèques", "لا توجد إشعارات حالياً.": "Aucune notification actuellement.", "إشعار الشيكات القريبة": "Alerte des chèques proches", "هناك شيكات سيحين تاريخ دخولها إلى البنك خلال 3 أيام:": "Certains chèques seront à déposer à la banque dans les 3 prochains jours :", "المستفيد:": "Bénéficiaire :", "المبلغ:": "Montant :", "تاريخ الشيك:": "Date du chèque :", "اليوم": "Aujourd'hui", "غداً": "Demain", "بعد": "Dans", " أيام": " jours", "لا توجد شيكات مبرمجة": "Aucun chèque programmé", "جميع الشيكات — الأقرب تاريخاً أولاً": "Tous les chèques — date la plus proche en premier", "لا توجد شيكات مسجلة": "Aucun chèque enregistré", "المستحق حالياً": "Dû actuellement", "عدد الديون": "Nombre de dettes", "لا توجد ديون مسجلة": "Aucune dette enregistrée", "لا يوجد زبائن": "Aucun client", "لا توجد مصاريف": "Aucune dépense", "المصروف": "Dépense", "الزبون": "Client", "المرجع:": "Référence :", "قطعة": "article", "حسابات المخزون": "Comptabilité du stock", "إجمالي الشراء": "Total des achats", "المنتجات:": "Produits :", "الكمية:": "Quantité :", "مجموع المبيعات الشهرية": "Total des ventes mensuelles", "مجموع أرباح الشهر": "Total du bénéfice mensuel", "مجموع المصاريف الشهرية": "Total des dépenses mensuelles", "صافي الربح بعد المصاريف": "Bénéfice net après dépenses", "مجموع الكريدي المسجل": "Total du crédit enregistré", "الكريدي المتبقي": "Crédit restant", "عدد الشيكات المصروفة:": "Nombre de chèques encaissés :", "اختر منتجاً من المخزون أو اكتب الاسم": "Choisir un produit du stock ou saisir le nom", "منتجات الوصل": "Produits du bon", "لا تتم إضافة منتجات بعد": "Aucun produit ajouté", "لا توجد وصول محفوظة": "Aucun bon enregistré", "رقم الوصل": "N° du bon", "العنوان": "Adresse", "المجموع": "Total", "الوصول المستقلة المحفوظة": "Bons indépendants enregistrés", "➕ وصل جديد": "➕ Nouveau bon", "اسم": "Nom", "عدد": "Qté", "حذف": "Supprimer", "المجموع النهائي": "Total final", "زبون عابر": "Client de passage", "تم حفظ المنتج بنجاح": "Produit enregistré avec succès", "تعذر حفظ الصورة. جرّب صورة أصغر.": "Impossible d'enregistrer l'image. Essayez une image plus petite.", "اختر منتجًا": "Choisissez un produit", "الكمية غير صحيحة": "Quantité incorrecte", "الكمية المطلوبة أكبر من المخزون المتوفر": "La quantité demandée dépasse le stock disponible", "السعر غير صحيح": "Prix incorrect", "أضف منتجًا واحدًا على الأقل": "Ajoutez au moins un produit", "تم حفظ البيع بنجاح": "Vente enregistrée avec succès", "لا توجد مبيعات لتحميلها": "Aucune vente à télécharger", "أدخل اسم المنتج": "Saisissez le nom du produit", "أدخل العدد": "Saisissez la quantité", "الثمن غير صحيح": "Prix incorrect", "أضف منتجاً واحداً على الأقل": "Ajoutez au moins un produit", "تم حفظ وصل التسليم بشكل مستقل عن المبيعات": "Bon de livraison enregistré indépendamment des ventes", "أضف منتجات إلى الوصل أولاً": "Ajoutez d'abord des produits au bon", "تعذر إنشاء PDF:": "Impossible de créer le PDF :", "الطباعة الحرارية متاحة داخل تطبيق Android.": "L'impression thermique est disponible uniquement dans l'application Android.", "لا توجد مبيعات للطباعة": "Aucune vente à imprimer", "لا توجد مبيعات لإنشاء وصل التسليم": "Aucune vente pour créer un bon de livraison", "اختيار جهات الاتصال متاح داخل تطبيق Android فقط": "La sélection des contacts est disponible uniquement dans l'application Android", "تعذر فتح جهات الاتصال": "Impossible d'ouvrir les contacts", "تم حفظ الزبون": "Client enregistré", "تم حفظ المصروف": "Dépense enregistrée", "بيانات غير صحيحة": "Données incorrectes", "تم تعديل المنتج بنجاح": "Produit modifié avec succès", "حذف هذا المنتج؟": "Supprimer ce produit ?", "تم استرجاع البيانات": "Données restaurées", "ملف النسخة الاحتياطية غير صالح": "Fichier de sauvegarde invalide", "أدخل رقم المنتج": "Saisissez la référence du produit", "أدخل كمية صحيحة": "Saisissez une quantité valide", "رقم المنتج غير موجود في المخزون": "Produit introuvable dans le stock", "أدخل اسم الزبون": "Saisissez le nom du client", "أدخل مبلغاً صحيحاً": "Saisissez un montant valide", "تم تسجيل الكريدي بنجاح": "Crédit enregistré avec succès", "هل تريد حذف هذا الكريدي؟": "Voulez-vous supprimer ce crédit ?", "أدخل رقم الشيك": "Saisissez le numéro du chèque", "أدخل اسم المستفيد": "Saisissez le bénéficiaire", "تم تسجيل الشيك بنجاح": "Chèque enregistré avec succès", "هل تريد حذف هذا الشيك؟": "Voulez-vous supprimer ce chèque ?", "تم تسجيل البيع. المتبقي في المخزون:": "Vente enregistrée. Stock restant :", "اسم": "Nom", "رقم": "Référence", "الثمن": "Prix", "مع الخفض": "Prix remisé", "💰 الأسعار": "💰 Prix", "🔍 بحث باسم المنتوج": "🔍 Rechercher par nom du produit", "🔢 بحث برقم/مرجع المنتوج": "🔢 Rechercher par référence du produit", "⭐ أولوية البحث بالاسم: اكتب اسم المنتوج أولاً، وستظهر في خانة الرقم فقط الأرقام المرتبطة بهذا الاسم. يمكنك بعدها اختيار رقم لتضييق النتيجة.": "Vous pouvez rechercher par nom ou référence du produit.", "🔍 ابحث باسم المنتوج أو الرقم": "🔍 Rechercher par nom du produit ou référence", "لا توجد نتائج للبحث": "Aucun résultat"};
  Object.assign(AFZ_TRANSLATIONS, {
    "🏷️ المنتجات | الاسم | الرقم | الصورة":"🏷️ Produits et références",
    "🏷️ تعريفة الشركات":"💰 Prix des sociétés",
    "🏷️ تعريفة الشركات":"🏷️ Tarification des produits",
    "↩ رجوع":"↩ Retour",
    "⌂ الرئيسية":"⌂ Accueil",
    "📦 تسجيل المنتجات | الاسم | الرقم | الصورة":"📦 Enregistrer les produits et leurs références",
    "سجل هنا":"Enregistrez ici",
    "اسم المنتوج ورقمه":"le nom du produit et sa référence",
    "فقط. الثمن لا يسجل في هذا القسم، لأن لكل شركة يمكن أن يكون لها ثمن مختلف لنفس المنتوج.":"uniquement. Le prix n'est pas enregistré dans cette section, car chaque société peut avoir un prix différent pour le même produit.",
    "اختر: اسم مسجل أو اسم جديد":"Choisissez : nom enregistré ou nouveau nom",
    "اسم منتوج مسجل ⬇️":"Nom de produit enregistré ⬇️",
    "اسم منتوج جديد ➕":"Nouveau nom de produit ➕",
    "اختر اسم المنتوج المسجل":"Choisissez le nom du produit enregistré",
    "اكتب رقمًا جديدًا لهذا الاسم. يمكن للاسم الواحد أن يحتوي على عدة أرقام، لكن لا يمكن تكرار نفس الرقم لنفس الاسم.":"Saisissez une nouvelle référence pour ce nom. Un même nom peut avoir plusieurs références, mais une référence ne peut pas être répétée pour le même nom.",
    "لكل اسم منتوج صورة واحدة ويمكن أن يكون له عدة أرقام. لا يمكن تكرار نفس الرقم لنفس الاسم.":"Chaque nom de produit possède une seule image et peut avoir plusieurs références. Une même référence ne peut pas être répétée pour le même nom.",
    "💾 تسجيل المنتوج":"💾 Enregistrer le produit",
    "🔎 المنتجات | الاسم | الرقم | الصورة المسجلة":"🔎 Produits et références enregistrés",
    "🔍 اختر اسم المنتوج":"🔍 Choisissez le nom du produit",
    "🔢 اختر رقم المنتوج":"🔢 Choisissez la référence du produit",
    "مسح الاختيار":"Effacer la sélection",
    "تعريفة الشركات":"Prix des sociétés",
    "كل شركة لها":"Chaque société possède son propre",
    "جدول مستقل":"tableau",
    ". اسم المنتوج ورقمه وصورته مأخوذة تلقائياً من قسم":". Le nom, la référence et l'image du produit sont automatiquement pris depuis la section",
    "المنتجات | الاسم | الرقم | الصورة":"Produits et références",
    "، ولا تُنشأ بيانات مستقلة لها هنا. الثمن فقط يُسجّل حسب الشركة. ويمكن البحث باسم المنتوج أو الرقم أو الشركة.":", aucune donnée indépendante n'est créée ici. Seul le prix est enregistré par société. La recherche peut se faire par nom, référence ou société.",
    "➕ إضافة شركة جديدة":"➕ Ajouter une nouvelle société",
    "➕ إضافة الشركة":"➕ Ajouter la société",
    "اختر الشركة":"Choisissez la société",
    "اختر المنتوج":"Choisissez le produit",
    "اختر رقم المنتوج":"Choisissez la référence du produit",
    "💾 تسجيل ثمن الشركة":"💾 Enregistrer le prix de la société",
    "🔎 البحث في تعريفة الشركات":"🔎 Rechercher dans les prix des sociétés",
    "اسم المنتوج ⬇️":"Nom du produit ⬇️",
    "رقم المنتوج ⬇️":"Référence du produit ⬇️",
    "كل الشركات ⬇️":"Toutes les sociétés ⬇️",
    "➕ إضافة منتوج إلى المخزون":"➕ Ajouter un produit au stock",
    "1. المنتوج":"1. Produit",
    "2. الرقم":"2. Référence",
    "3. الشركة":"3. Société",
    "اختر الشركة ⬇️":"Choisissez la société ⬇️",
    "ثمن الشراء المناسب للشركة":"Prix d'achat de la société",
    "اختر المنتوج والرقم ثم الشركة ليظهر الثمن تلقائيًا من «تعريفة الشركات».":"Choisissez le produit, la référence puis la société pour afficher automatiquement le prix depuis « Prix des sociétés ».",
    "الكمية التي تريد إضافتها":"Quantité à ajouter",
    "هذه الكمية غادي تزيد للمخزون.":"Cette quantité sera ajoutée au stock.",
    "💾 إضافة المنتوج":"💾 Ajouter le produit",
    "📦 ملخص المنتجات بالمخزون":"📦 Résumé des produits en stock",
    "🏷️ تعريفة الشركات":"💰 Tarification des produits",
    "➕ إضافة منتوج جديد":"➕ Ajouter un nouveau produit",
    "✏️ تعديل منتوج مسجل":"✏️ Modifier un produit enregistré",
    "➕ إضافة منتوج مسجل":"➕ Ajouter un produit enregistré",
    "➕ إضافة رقم جديد لمنتوج مسجل":"➕ Ajouter une nouvelle référence à un produit enregistré",
    "اسم المنتوج المسجل":"Nom du produit enregistré",
    "رقم المنتوج / المرجع الجديد":"Nouvelle référence du produit",
    "ثمن الشراء DH":"Prix d'achat DH",
    "اختر الاسم ثم اكتب رقمًا جديدًا. لا يمكن تسجيل نفس الرقم مرتين لنفس المنتوج.":"Choisissez le nom puis saisissez une nouvelle référence. La même référence ne peut pas être enregistrée deux fois pour le même produit.",
    "💾 تسجيل الرقم":"💾 Enregistrer la référence",
    "أرقام المنتوج المسجلة":"Références des produits enregistrées",
    "رقم المنتوج":"Référence du produit",
    "صورة المنتوج":"📷 Image du produit",
    "في «منتوج مسجل» يمكنك تعديل الاسم أو الصورة، أو إضافة رقم جديد وثمنه. لا يمكن إنشاء أو تعديل هذه البيانات من المخزون.":"Dans « Produit enregistré », vous pouvez modifier le nom ou l'image, ou ajouter une nouvelle référence et son prix. Ces données ne peuvent pas être créées ou modifiées depuis le stock.",
    "💾 حفظ البيانات":"💾 Enregistrer les données",
    "🔎 البحث عن ثمن المنتوج":"🔎 Rechercher le prix du produit",
    "اكتب اسم المنتوج أولاً ثم الرقم/المرجع لإظهار الثمن المحدد.":"Saisissez d'abord le nom du produit puis la référence pour afficher le prix correspondant.",
    "📦 بطاقات المنتوجات":"📦 Fiches produits",
    "📊 تسجيل مبيعات اليوم":"📊 Enregistrer les ventes du jour",
    "نوع العملية":"Type d'opération",
    "💸 إضافة مصروف":"💸 Ajouter une dépense",
    "في إضافة البيع: اختر أولاً اسم المنتوج، ثم الرقم/المرجع، ثم حدّد العدد، وبعدها اكتب ثمن البيع.":"Pour ajouter une vente : choisissez d'abord le nom du produit, puis la référence, indiquez la quantité et saisissez ensuite le prix de vente.",
    "💾 حفظ المصروف":"💾 Enregistrer la dépense",
    "ثمن البيع":"Prix de vente",
    "📆 الملخص الشهري":"📆 Résumé mensuel",
    "الشهر":"Mois",
    "المداخيل":"Recettes",
    "المصاريف":"Dépenses",
    "عدد المصاريف":"Nombre de dépenses",
    "📊 الملخص السنوي":"📊 Résumé annuel",
    "السنة":"Année",
    "📝 تحرير بون دوليفريزون مستقل":"📝 Créer un bon de livraison indépendant",
    "هذا القسم مستقل تماماً عن قسم المبيعات. إنشاء وتعديل وصل التسليم هنا لا ينشئ بيعاً ولا يغيّر المخزون.":"Cette section est totalement indépendante des ventes. La création et la modification d'un bon de livraison ici ne créent pas de vente et ne modifient pas le stock.",
    "اختر الزبون من قسم الزبائن":"Choisissez le client depuis la section Clients",
    "👁️ معاينة الوصل":"👁️ Aperçu du bon",
    "📱 اختيار اسم الزبون ورقم الهاتف من جهات الاتصال":"📱 Choisir le nom et le téléphone du client depuis les contacts",
    "خانات البحث منفصلة: الاسم، الهاتف، والملاحظة.":"Champs de recherche séparés : nom, téléphone et remarque.",
    "💳 إدارة الكريدي":"💳 Gestion du crédit",
    "➕ تسجيل الكريدي":"➕ Enregistrer le crédit",
    "📒 دفتر الشيكات":"📒 Carnet de chèques",
    "اسم الشركة":"Nom de la société",
    "اختر الشركة من «تعريفة الشركات» ⬇️":"Choisissez la société depuis « Prix des sociétés » ⬇️",
    "أسماء الشركات مأخوذة تلقائيًا من قسم «تعريفة الشركات».":"Les noms des sociétés sont automatiquement récupérés depuis la section « Prix des sociétés ».",
    "في الانتظار":"En attente",
    "تم صرفه":"Encaissé",
    "ملغى":"Annulé",
    "➕ تسجيل الشيك":"➕ Enregistrer le chèque",
    "↩️ إلغاء التعديل":"↩️ Annuler la modification",
    "📅 جدول الشيكات المبرمجة":"📅 Tableau des chèques programmés",
    "تنبيهات الشيكات التي اقترب تاريخ دخولها إلى البنك.":"Alertes pour les chèques dont la date de dépôt à la banque approche.",
    "نوع البحث":"Type de recherche",
    "اختر نوع البحث":"Choisissez le type de recherche",
    "البحث بالشهر":"Recherche par mois",
    "البحث بالسنة":"Recherche par année",
    "الشهر / السنة":"Mois / année",
    "اختر أولاً نوع البحث":"Choisissez d'abord le type de recherche",
    "اختر الشهر أولاً":"Choisissez d'abord le mois",
    "اختر الشهر ثم السنة الخاصة به، أو اختر السنة مباشرة للبحث في جميع مصاريفها.":"Choisissez le mois puis son année, ou choisissez directement l'année pour rechercher toutes ses dépenses.",
    "💾 حفظ واسترجاع بيانات التطبيق":"💾 Sauvegarde et restauration des données de l'application",
    "💾 حفظ نسخة احتياطية":"💾 Enregistrer une sauvegarde",
    "📥 استرجاع البيانات":"📥 Restaurer les données",
    "✅ تم حفظ النسخة الاحتياطية":"✅ Sauvegarde enregistrée",
    "📁 الحفظ: اختر المكان من نافذة الحفظ، أو اضغط الزر التالي واختر «التنزيلات (Download)».":"📁 Enregistrement : choisissez l'emplacement dans la fenêtre d'enregistrement, ou appuyez sur le bouton suivant et choisissez « Téléchargements (Download) ».",
    "📥 حفظ الملف في الهاتف":"📥 Enregistrer le fichier sur le téléphone",
    "افتح تطبيق «الملفات» ثم مجلد «التنزيلات» للعثور على الملف ونقله إلى هاتف آخر.":"Ouvrez l'application « Fichiers », puis le dossier « Téléchargements » pour trouver le fichier et le transférer vers un autre téléphone.",
    "اسم المنتوج أو الرقم":"Nom ou référence du produit",
    "اسم الشركة أو الرقم":"Nom de la société ou référence",
    "الشركة":"Société",
    "رقم المنتوج/المرجع":"Référence du produit",
    "إجراء":"Action",
    "✏️ تعديل":"✏️ Modifier",
    "🗑️ حذف":"🗑️ Supprimer",
    "✏️ تعديل اسم الشركة والثمن":"✏️ Modifier le nom de la société et le prix",
    "🗑️ حذف السعر":"🗑️ Supprimer le prix",
    "اختر رقم المنتوج لإظهار ثمنه.":"Choisissez la référence du produit pour afficher son prix.",
    "لا توجد نتيجة مطابقة لهذا الاسم ورقم المنتوج.":"Aucun résultat correspondant à ce nom et à cette référence.",
    "اختر اسم المنتوج ثم رقم المنتوج لإظهار جميع الشركات وأسعارها.":"Choisissez le nom puis la référence du produit pour afficher toutes les sociétés et leurs prix.",
    "لا توجد منتوجات مسجلة في قسم «تعريفة الشركات»":"Aucun produit enregistré dans la section « Tarification des produits »",
    "رقم مسجل":"référence enregistrée",
    "الأرقام:":"Références :",
    "الثمن":"Prix",
    "ثمن الشراء":"Prix d'achat",
    "ثمنه":"Son prix",
    "ثمن الشركة":"Prix de la société",
    "عدد الأسعار":"Nombre de prix",
    "سعر":"prix",
    "أسعار":"prix",
    "اسم الشركة الجديد":"Nouveau nom de la société",
    "لم يتم العثور على السعر":"Prix introuvable",
    "أدخل اسم الشركة":"Saisissez le nom de la société",
    "هذه الشركة مسجلة مسبقاً":"Cette société est déjà enregistrée",
    "تمت إضافة الشركة بنجاح":"Société ajoutée avec succès",
    "تم تحديث ثمن الشركة":"Prix de la société mis à jour",
    "تم تسجيل ثمن الشركة":"Prix de la société enregistré",
    "يوجد بالفعل ثمن مسجل لنفس المنتوج والرقم وهذه الشركة.":"Un prix est déjà enregistré pour le même produit, la même référence et cette société.",
    "هل تريد حذف ثمن هذه الشركة؟":"Voulez-vous supprimer le prix de cette société ?",
    "هل تريد حذف هذه الشركة؟":"Voulez-vous supprimer cette société ?",
    "لا توجد أسعار في هذا القسم":"Aucun prix dans cette section",
    "عدد مسجل":"enregistré",
    "رجوع":"Retour",
    "الرئيسية":"Accueil"
  });
  let AFZ_LANG = localStorage.getItem('afz_lang') || 'ar';
  const originalText = new WeakMap();
  const originalAttr = new WeakMap();

  function tr(value){
    if (AFZ_LANG === 'ar') return value;
    if (AFZ_TRANSLATIONS[value] !== undefined) return AFZ_TRANSLATIONS[value];
    let out=value;
    const keys=Object.keys(AFZ_TRANSLATIONS).sort((a,b)=>b.length-a.length);
    for(const k of keys){
      if(out.includes(k)) out=out.split(k).join(AFZ_TRANSLATIONS[k]);
    }
    return out;
  }

  function translateTree(root){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n=>{
      if(!originalText.has(n)) originalText.set(n,n.nodeValue);
      const o=originalText.get(n);
      n.nodeValue=tr(o);
    });
    root.querySelectorAll('input,textarea,select,option,button').forEach(el=>{
      ['placeholder','title'].forEach(a=>{
        if(el.hasAttribute(a)){
          if(!originalAttr.has(el)) originalAttr.set(el,{});
          const rec=originalAttr.get(el);
          if(rec[a]===undefined) rec[a]=el.getAttribute(a);
          el.setAttribute(a,tr(rec[a]));
        }
      });
    });
  }

  function applyLanguage(){
    document.documentElement.lang=AFZ_LANG==='fr'?'fr':'ar';
    document.documentElement.dir=AFZ_LANG==='fr'?'ltr':'rtl';
    document.body.classList.toggle('lang-fr',AFZ_LANG==='fr');
    const b=document.getElementById('langToggle');
    if(b) b.textContent=AFZ_LANG==='fr'?'🇲🇦 العربية':'🇫🇷 Français';
    translateTree(document.body);
  }

  window.toggleLanguage=function(){
    AFZ_LANG=AFZ_LANG==='fr'?'ar':'fr';
    localStorage.setItem('afz_lang',AFZ_LANG);
    applyLanguage();
  };
  window.addEventListener('DOMContentLoaded',()=>setTimeout(applyLanguage,0));


  // حماية وضع التصفح: يمنع أي عملية إضافة/تعديل/حذف حتى لو استُدعيت من زر ديناميكي.
  document.addEventListener('click',function(ev){
    if(!AFZ_CAN_EDIT()){
      const b=ev.target.closest && ev.target.closest('button,[role="button"]');
      if(b){
        const raw=((b.getAttribute('onclick')||'')+' '+(b.getAttribute('data-price-action')||'')+' '+(b.getAttribute('data-price-bottom-action')||'')+' '+(b.getAttribute('data-master-action')||'')).toLowerCase();
        if(/add|edit|delete|remove|save|update/.test(raw)){
          ev.preventDefault(); ev.stopImmediatePropagation();
        }
      }
    }
  },true);
  document.addEventListener('submit',function(ev){
    if(!AFZ_CAN_EDIT()){
      const raw=(ev.target && ev.target.getAttribute('onsubmit')||'').toLowerCase();
      if(/add|edit|delete|remove|save|update/.test(raw)){
        ev.preventDefault(); ev.stopImmediatePropagation();
      }
    }
  },true);

  // إصلاح أزرار «المنتجات | الاسم | الرقم | الصورة»: نعتمد على تفويض النقر بدل inline onclick،
  // حتى تعمل الأزرار بشكل ثابت داخل Android/WebView وبعد إعادة رسم البطاقات.
  if(!window.__afzMasterProductActions){
    window.__afzMasterProductActions=true;
    document.addEventListener('click',function(ev){
      const btn=ev.target.closest && ev.target.closest('.master-product-action[data-master-action]');
      if(!btn)return;
      ev.preventDefault();
      ev.stopPropagation();
      const action=btn.getAttribute('data-master-action');
      const pid=btn.getAttribute('data-product-id')||'';
      const ref=btn.getAttribute('data-product-ref')||'';
      if(action==='edit-image' && typeof window.editMasterProductImage==='function') window.editMasterProductImage(pid);
      else if(action==='edit-name' && typeof window.editMasterProductName==='function') window.editMasterProductName(pid);
      else if(action==='edit-ref' && typeof window.editMasterProductRef==='function') window.editMasterProductRef(pid,ref);
      else if(action==='delete-ref' && typeof window.deleteMasterProductRef==='function') window.deleteMasterProductRef(pid,ref);
    },true);
  }
  // بعض WebView لا تجعل دوال script القديمة متاحة مباشرة لـ onclick؛ نضمن تصديرها.
  window.editMasterProductImage=window.editMasterProductImage||editMasterProductImage;
  window.editMasterProductName=window.editMasterProductName||editMasterProductName;
  window.editMasterProductRef=window.editMasterProductRef||editMasterProductRef;
  window.deleteMasterProductRef=window.deleteMasterProductRef||deleteMasterProductRef;

  // أزرار تعريفة الشركات تستخدم onclick مباشر داخل الزر، وهو أكثر ثباتاً في Android/WebView.
  // هذا المستمع يبقى فقط للأزرار القديمة التي تستخدم data-price-action.
  if(!window.__afzPriceActionDelegation){
    window.__afzPriceActionDelegation=true;
    document.addEventListener('click',function(ev){
      const priceBtn=ev.target.closest && ev.target.closest('[data-price-action]');
      if(priceBtn){
        ev.preventDefault();
        ev.stopPropagation();
        const productId=priceBtn.getAttribute('data-product-id');
        const ref=priceBtn.getAttribute('data-price-ref');
        const action=priceBtn.getAttribute('data-price-action');
        if(action==='edit' && typeof window.updatePriceOnly==='function') window.updatePriceOnly(productId,ref);
        else if(action==='delete' && typeof window.deletePriceOnly==='function') window.deletePriceOnly(productId,ref);
        return;
      }
      const bottomBtn=ev.target.closest && ev.target.closest('[data-price-bottom-action]');
      if(bottomBtn){
        ev.preventDefault();
        ev.stopPropagation();
        const productId=bottomBtn.getAttribute('data-product-id');
        const ref=bottomBtn.getAttribute('data-price-ref');
        const action=bottomBtn.getAttribute('data-price-bottom-action');
        if(action==='edit' && typeof window.editBottomPrice==='function') window.editBottomPrice(productId,ref);
        else if(action==='delete' && typeof window.deletePriceOnly==='function') window.deletePriceOnly(productId,ref);
      }
    },true);
  }

  // Wrap render so dynamically generated sections are translated as well.
  const wrap=()=>{
    if(typeof window.render==='function' && !window.__afzRenderWrapped){
      const base=window.render;
      window.render=function(){ base.apply(this,arguments); setTimeout(applyLanguage,0); };
      window.__afzRenderWrapped=true;
    }
  };
  setTimeout(wrap,0);
  setInterval(wrap,250);
})();
