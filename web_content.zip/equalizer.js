'use strict';
const eqFreq=[31,62,125,250,500,1000,2000,4000,8000,16000];
const eqPresets={flat:[0,0,0,0,0,0,0,0,0,0],bass:[7,6,4,2,0,0,0,0,0,0],voice:[-4,-3,-2,0,2,4,4,2,0,-2],rock:[4,3,1,-1,-2,0,2,3,4,3],soft:[2,2,1,0,-1,-1,0,1,1,0]};
let eqState={enabled:true,bands:Array(10).fill(0),bass:0,mid:0,treble:0,preamp:-6,preset:'flat',vu:false,vuMode:'digital',vuStyle:'bars',vuColor:'reference',vuCustomColor:'#ff1680'};
try{const saved=JSON.parse(localStorage.getItem('jr-player-eq')||'null');if(saved&&Array.isArray(saved.bands)&&saved.bands.length===10)Object.assign(eqState,saved)}catch{}
let stereoAnalysers=[],stereoSamples=[],analogLevels=[0,0];
let audioContext=null,eqNodes=[],toneNodes=[],preGain=null,analyser=null,samples=null,vuFrame=0,vuSmooth=0,frequencySamples=null,vuLevels=Array(24).fill(0),vuPeaks=Array(24).fill(0),vuLastTime=0;
function saveEq(){try{localStorage.setItem('jr-player-eq',JSON.stringify(eqState))}catch{}}
function setAudioEq(){if(!audioContext)return;const now=audioContext.currentTime;eqNodes.forEach((n,i)=>n.gain.setTargetAtTime(eqState.enabled?eqState.bands[i]:0,now,.025));toneNodes.forEach((n,i)=>n.gain.setTargetAtTime(eqState.enabled?eqState[['bass','mid','treble'][i]]:0,now,.025));const headroom=eqState.enabled?Math.max(0,...eqState.bands)+Math.max(0,eqState.bass,eqState.mid,eqState.treble):0;preGain.gain.setTargetAtTime(Math.pow(10,((eqState.enabled?eqState.preamp:0)-headroom)/20),now,.025);}
async function ensureAudio(){try{if(!audioContext){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw Error('Web Audio indisponível');audioContext=new AC();const source=audioContext.createMediaElementSource(media);let last=source;eqNodes=eqFreq.map((frequency,i)=>{const node=audioContext.createBiquadFilter();node.type=i===0?'lowshelf':i===9?'highshelf':'peaking';node.frequency.value=Math.min(frequency,audioContext.sampleRate*.45);node.Q.value=1.4;last.connect(node);last=node;return node});toneNodes=['lowshelf','peaking','highshelf'].map((type,i)=>{const n=audioContext.createBiquadFilter();n.type=type;n.frequency.value=[150,1000,6000][i];n.Q.value=.7;last.connect(n);last=n;return n});preGain=audioContext.createGain();last.connect(preGain);const limiter=audioContext.createDynamicsCompressor();limiter.threshold.value=-2;limiter.knee.value=3;limiter.ratio.value=12;limiter.attack.value=.003;limiter.release.value=.15;preGain.connect(limiter);analyser=audioContext.createAnalyser();analyser.fftSize=2048;limiter.connect(analyser);const splitter=audioContext.createChannelSplitter(2);limiter.connect(splitter);for(let ch=0;ch<2;ch++){const a=audioContext.createAnalyser();a.fftSize=1024;splitter.connect(a,ch);stereoAnalysers.push(a);stereoSamples.push(new Float32Array(a.fftSize))}analyser.connect(audioContext.destination);samples=new Float32Array(analyser.fftSize);frequencySamples=new Uint8Array(analyser.frequencyBinCount);analyser.smoothingTimeConstant=.65;analyser.minDecibels=-85;analyser.maxDecibels=-15;setAudioEq()}if(audioContext.state==='suspended')await audioContext.resume();$('eqStatus').textContent='Equalizador ativo no áudio • ajustes salvos neste aparelho.';return true}catch{$('eqStatus').textContent='Este WebView não disponibilizou o processamento de áudio. Teste em outro navegador ou conversor.';return false}}
function syncEq(){ $('eqEnabled').checked=eqState.enabled;$('eqPreset').value=eqState.preset;eqFreq.forEach((f,i)=>{const el=$('band'+i);el.value=eqState.bands[i];$('bandValue'+i).textContent=eqState.bands[i]+' dB'});['bass','mid','treble'].forEach(k=>{$(k).value=eqState[k];$(k+'Value').textContent=eqState[k]+' dB'});$('preamp').value=eqState.preamp;$('preampValue').textContent=eqState.preamp+' dB';setAudioEq();saveEq()}
eqFreq.forEach((f,i)=>{const label=document.createElement('label');label.className='band';const output=document.createElement('output');output.id='bandValue'+i;const range=document.createElement('input');range.type='range';range.min=-12;range.max=12;range.step=.5;range.id='band'+i;range.setAttribute('aria-label',f+' hertz');range.oninput=()=>{eqState.bands[i]=Number(range.value);eqState.preset='custom';syncEq()};const name=document.createElement('span');name.textContent=f>=1000?f/1000+'k':String(f);label.append(output,range,name);$('eqBands').append(label)});
[['bass','Graves'],['mid','Médios'],['treble','Agudos']].forEach(([key,name])=>{const label=document.createElement('label');label.className='tone';label.append(document.createTextNode(name));const output=document.createElement('output');output.id=key+'Value';const input=document.createElement('input');input.id=key;input.type='range';input.min=-12;input.max=12;input.step=.5;input.setAttribute('aria-label',name+' em decibéis');input.oninput=()=>{eqState[key]=Number(input.value);eqState.preset='custom';syncEq()};label.append(output,input);$('toneControls').append(label)});
$('preamp').oninput=()=>{eqState.preamp=Number($('preamp').value);syncEq()};$('eqEnabled').onchange=async()=>{eqState.enabled=$('eqEnabled').checked;await ensureAudio();syncEq()};$('eqPreset').onchange=()=>{const preset=$('eqPreset').value;if(!eqPresets[preset])return;eqState.preset=preset;eqState.bands=[...eqPresets[preset]];eqState.bass=eqState.mid=eqState.treble=0;syncEq()};$('eqReset').onclick=()=>{Object.assign(eqState,{bands:Array(10).fill(0),bass:0,mid:0,treble:0,preamp:-6,preset:'flat'});syncEq()};
$('menuOpen').onclick=()=>$('menu').showModal();$('eqOpen').onclick=async()=>{$('menu').close();$('equalizer').showModal();await ensureAudio()};$('settingsOpen').addEventListener('click',()=>$('menu').close());
function vuColorAt(t){
 switch(eqState.vuColor){
 case 'classic':return t>.85?'#ff4343':t>.65?'#ffd442':'#40ed8c';
 case 'ocean':return `hsl(${220-t*40},95%,${40+t*25}%)`;
 case 'fire':return `hsl(${35-t*35},100%,55%)`;
 case 'custom':return /^#[0-9a-f]{6}$/i.test(eqState.vuCustomColor)?eqState.vuCustomColor:'#ff1680';
 default:return t<.5?`rgb(${Math.round(25+t*150)},${Math.round(70-t*75)},${Math.round(150-t*30)})`:`rgb(${Math.round(100+(t-.5)*310)},${Math.round(32-(t-.5)*40)},${Math.round(135-(t-.5)*90)})`;
 }
}
function syncVuOptions(){
 $('vuMode').value=eqState.vuMode;$('vuGraphLabel').hidden=eqState.vuMode==='analog';$('vuStyle').value=eqState.vuStyle;$('vuColor').value=eqState.vuColor;$('vuCustomColor').value=eqState.vuCustomColor;$('vuCustomLabel').hidden=eqState.vuColor!=='custom';
 $('vuCanvas').setAttribute('aria-label',eqState.vuMode==='analog'?'Dois medidores analógicos de ponteiro, canais esquerdo e direito':eqState.vuStyle==='wave'?'Onda sonora que reage ao áudio':'Gráfico de frequências que reage ao áudio');
}
['vuMode','vuStyle','vuColor','vuCustomColor'].forEach(key=>{$(key).oninput=()=>{eqState[key]=$(key).value;syncVuOptions();saveEq()}});
function drawVu(timestamp=0){
 const canvas=$('vuCanvas');resizeVuCanvas();const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
 const dt=vuLastTime?Math.min(.1,Math.max(0,(timestamp-vuLastTime)/1000)):1/60;vuLastTime=timestamp;
 const active=analyser&&!media.paused&&!media.ended;let rms=0;
 if(active){analyser.getFloatTimeDomainData(samples);analyser.getByteFrequencyData(frequencySamples);for(const s of samples)rms+=s*s;rms=Math.sqrt(rms/samples.length)}
 const db=rms>0?Math.max(-60,20*Math.log10(rms)):-60;
 ctx.fillStyle='#050305';ctx.fillRect(0,0,w,h);
 if(eqState.vuMode==='analog'){drawAnalogVu(ctx,w,h,active,dt);updateVuValue(active,rms,db);vuFrame=eqState.vu?requestAnimationFrame(drawVu):0;return}
 const columns=24,rows=24,left=14,top=14,bottom=h-32,stepX=(w-left*2)/columns,stepY=(bottom-top)/rows;
 const maxHz=audioContext?Math.min(16000,audioContext.sampleRate/2):16000;
 for(let i=0;i<columns;i++){
  let target=0;
  if(active){const lo=40*Math.pow(maxHz/40,i/columns),hi=40*Math.pow(maxHz/40,(i+1)/columns);
   const first=Math.max(1,Math.floor(lo*analyser.fftSize/audioContext.sampleRate));
   const last=Math.min(frequencySamples.length-1,Math.max(first,Math.ceil(hi*analyser.fftSize/audioContext.sampleRate)-1));
   for(let bin=first;bin<=last;bin++)target=Math.max(target,frequencySamples[bin]/255);
  }
  vuLevels[i]=target>vuLevels[i]?target:Math.max(target,vuLevels[i]-dt*1.6);
  vuPeaks[i]=Math.max(vuLevels[i],vuPeaks[i]-dt*.45);
  const lit=Math.round(vuLevels[i]*rows),x=left+i*stepX,barW=stepX*.72;
  if(eqState.vuStyle==='bars')for(let j=0;j<rows;j++){
   const y=bottom-(j+1)*stepY,t=j/(rows-1);
   const color=vuColorAt(t);
   ctx.fillStyle=color;ctx.globalAlpha=j<lit?1:.09;ctx.shadowColor=color;ctx.shadowBlur=j<lit?5:0;ctx.fillRect(x,y,barW,stepY*.72);
  }
  ctx.globalAlpha=1;ctx.shadowBlur=0;
  if(eqState.vuStyle==='bars'&&vuPeaks[i]>.025){ctx.fillStyle=vuColorAt(1);ctx.fillRect(x,bottom-Math.max(1,Math.round(vuPeaks[i]*rows))*stepY,barW,2)}
 }
 if(eqState.vuStyle==='line'||eqState.vuStyle==='wave'){
  const gradient=ctx.createLinearGradient(0,bottom,0,top);gradient.addColorStop(0,vuColorAt(0));gradient.addColorStop(.5,vuColorAt(.5));gradient.addColorStop(1,vuColorAt(1));
  ctx.strokeStyle=gradient;ctx.lineWidth=3;ctx.shadowColor=vuColorAt(.75);ctx.shadowBlur=8;ctx.beginPath();
  if(eqState.vuStyle==='line'){
   vuLevels.forEach((v,i)=>{const x=left+i*(w-left*2)/(columns-1),y=bottom-v*(bottom-top);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});
  }else{
   const points=360,center=(top+bottom)/2;
   for(let i=0;i<points;i++){const x=left+i*(w-left*2)/(points-1),sample=active?samples[Math.floor(i*(samples.length-1)/(points-1))]:0,y=center-sample*(bottom-top)/2;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)}
  }
  ctx.stroke();
 }
 ctx.globalAlpha=1;ctx.shadowBlur=0;ctx.font='12px system-ui';ctx.fillStyle='#8e849b';ctx.textAlign='left';ctx.fillText(eqState.vuStyle==='wave'?'ONDA SONORA':'GRAVES',left,h-9);ctx.textAlign='center';ctx.fillText(eqState.vuStyle==='wave'?'':'MÉDIOS',w/2,h-9);ctx.textAlign='right';ctx.fillText(eqState.vuStyle==='wave'?'TEMPO →':'AGUDOS',w-left,h-9);
 updateVuValue(active,rms,db);
 vuFrame=eqState.vu?requestAnimationFrame(drawVu):0;
}
function showVu(show){if(!show)leaveVuFullscreen();eqState.vu=show;$('vuPanel').hidden=!show;$('art').hidden=show||(tracks.find(t=>t.id===current)?.kind==='video');$('vuToggle').setAttribute('aria-pressed',String(show));cancelAnimationFrame(vuFrame);vuFrame=0;vuLastTime=0;vuLevels.fill(0);vuPeaks.fill(0);if(show)drawVu();saveEq()}
$('vuToggle').onclick=async()=>{$('menu').close();if(!eqState.vu)await ensureAudio();showVu(!eqState.vu)};$('vuClose').onclick=()=>showVu(false);
document.addEventListener('click',e=>{if(e.target.closest('#play,.pick,#prev,#next'))ensureAudio()},true);
media.addEventListener('play',()=>{if(eqState.vu){$('art').hidden=true;if(!vuFrame)drawVu()}});media.addEventListener('emptied',()=>{if(eqState.vu)$('art').hidden=true});
syncEq();syncVuOptions();showVu(eqState.vu);
