JAS LAUNDRY ROOM – APPWRITE CONNECT UI UPDATE

Login page-ലും Settings page-ലും Appwrite Cloud Connect fields ചേർത്തിട്ടുണ്ട്. Endpoint, Project ID save ചെയ്ത് Appwrite ping test ചെയ്യാം.

പ്രധാന കുറിപ്പ്: ഈ update Appwrite connection UI + ping test മാത്രമാണ്. നിലവിലെ app-ന്റെ login, staff accounts, bills, customers, reports എന്നിവയുടെ cloud data sync ഇപ്പോഴും പഴയ Firebase code-ലാണ്. Appwrite-ലേക്ക് പൂർണ്ണമായി മാറ്റാൻ authentication, database collections/documents, permissions, realtime sync, data migration എന്നിവ പ്രത്യേകം rewrite ചെയ്യണം. അതിനാൽ ഈ ZIP-നെ Appwrite full cloud-sync version എന്ന് കരുതരുത്; പഴയ Firebase sync code പൂർണ്ണമായി നീക്കം ചെയ്തിട്ടില്ല.
