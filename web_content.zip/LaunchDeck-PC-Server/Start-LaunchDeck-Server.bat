@echo off
title LaunchDeck PC Server
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting Administrator permission to start the local server...
  powershell.exe -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LaunchDeck-PC-Server.ps1"
pause
