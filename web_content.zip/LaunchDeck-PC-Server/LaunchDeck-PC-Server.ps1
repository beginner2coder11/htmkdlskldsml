# LaunchDeck Remote PC Server - Windows PowerShell 5.1+
# Local-network only. Never expose port 8765 to the public internet.
$ErrorActionPreference = "Stop"
$Port = 8765
$Pin = "246810" # Change this PIN before use.
$Name = $env:COMPUTERNAME
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:$Port/")
try { $listener.Start() } catch {
  Write-Host "Could not start server on port $Port. Try running as Administrator or free the port." -ForegroundColor Red
  Write-Host $_.Exception.Message
  Read-Host "Press Enter to exit"; exit 1
}
$addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*"} | Select-Object -ExpandProperty IPAddress -Unique
Write-Host ""
Write-Host " LaunchDeck PC Server is RUNNING" -ForegroundColor Cyan
Write-Host " Computer: $Name"
Write-Host " Port:     $Port"
Write-Host " PIN:      $Pin" -ForegroundColor Yellow
Write-Host " Address(es): $($addresses -join ', ')"
Write-Host " Keep this window open. Phone and PC must use the same Wi-Fi."
Write-Host " Press Ctrl+C to stop."
function Send-Json($ctx, [int]$status, $obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 5
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $ctx.Response.StatusCode = $status
  $ctx.Response.ContentType = "application/json; charset=utf-8"
  $ctx.Response.Headers.Add("Access-Control-Allow-Origin", "*")
  $ctx.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
  $ctx.Response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $ctx.Response.Close()
}
while ($listener.IsListening) {
  $ctx = $null
  try {
    $ctx = $listener.GetContext()
    $path = $ctx.Request.Url.AbsolutePath.ToLowerInvariant()
    if ($ctx.Request.HttpMethod -eq "OPTIONS") { Send-Json $ctx 200 @{ok=$true}; continue }
    if ($path -eq "/health" -and $ctx.Request.HttpMethod -eq "GET") {
      Send-Json $ctx 200 @{ok=$true;name=$Name;service="LaunchDeck";version="1.0"}; continue
    }
    if ($ctx.Request.HttpMethod -ne "POST") { Send-Json $ctx 405 @{ok=$false;error="Use POST"}; continue }
    $reader = New-Object System.IO.StreamReader($ctx.Request.InputStream, $ctx.Request.ContentEncoding)
    $body = $reader.ReadToEnd(); $reader.Close()
    try { $data = $body | ConvertFrom-Json } catch { Send-Json $ctx 400 @{ok=$false;error="Invalid JSON"}; continue }
    if ([string]$data.pin -cne $Pin) { Send-Json $ctx 401 @{ok=$false;error="Incorrect PIN"}; continue }
    if ($path -eq "/connect") { Send-Json $ctx 200 @{ok=$true;name=$Name}; continue }
    if ($path -eq "/launch") {
      $action = [string]$data.action
      # Strict allowlist: the phone cannot submit arbitrary shell commands.
      switch ($action) {
        "explorer" { Start-Process explorer.exe }
        "browser"  { Start-Process "https://www.google.com" }
        "media"    { Start-Process explorer.exe -ArgumentList "shell:VideosLibrary" }
        "music"    { Start-Process explorer.exe -ArgumentList "shell:Music" }
        "settings" { Start-Process "ms-settings:" }
        "terminal" {
          $wt = Get-Command wt.exe -ErrorAction SilentlyContinue
          if ($wt) { Start-Process wt.exe } else { Start-Process powershell.exe }
        }
        "games"    { Start-Process explorer.exe -ArgumentList "shell:AppsFolder" }
        "downloads"{ Start-Process explorer.exe -ArgumentList (Join-Path $env:USERPROFILE "Downloads") }
        "display"  { Start-Process "ms-settings:display" }
        default    { Send-Json $ctx 400 @{ok=$false;error="Action not allowed"}; continue }
      }
      Send-Json $ctx 200 @{ok=$true;action=$action;name=$Name}; continue
    }
    Send-Json $ctx 404 @{ok=$false;error="Endpoint not found"}
  } catch {
    if ($ctx -and $ctx.Response -and $ctx.Response.OutputStream) {
      try { Send-Json $ctx 500 @{ok=$false;error="Server error"} } catch {}
    }
    Write-Host "Request error: $($_.Exception.Message)" -ForegroundColor DarkYellow
  }
}
