import hashlib
import os
import json

class WalletManager:
    def __init__(self, key_file):
        self.key_file = key_file
        self.private_key = self._load_or_create_key()
        self.address = self._derive_address(self.private_key)

    def _load_or_create_key(self):
        if os.path.exists(self.key_file):
            with open(self.key_file, 'r') as f:
                return json.load(f)["private_key"]
        else:
            # Generate a dummy private key (in production, use ECDSA/secp256k1)
            key = os.urandom(32).hex()
            self._save_key(key)
            return key

    def _save_key(self, key):
        with open(self.key_file, 'w') as f:
            json.dump({"private_key": key}, f)

    def _derive_address(self, private_key):
        # Simple SHA256 hash for demonstration (not real Bitcoin address format)
        addr_hash = hashlib.sha256(private_key.encode()).hexdigest()[:40]
        return f"bc1q{addr_hash}"

    def get_address(self):
        return self.address

    def sign_transaction(self, recipient, amount):
        # Create a unique transaction ID based on content + private key
        data = f"{self.address}:{recipient}:{amount}:{time.time()}"
        signature = hashlib.sha256((data + self.private_key).encode()).hexdigest()
        return f"0x{signature[:64]}"  # Fake txid format