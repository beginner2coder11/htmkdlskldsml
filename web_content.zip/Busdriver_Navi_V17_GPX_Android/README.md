# Busdriver Navi V17 – GPX aus Guru Maps

Android-Studio-Projekt, keine fertige APK.

## Daten
- Quelle: WestVerkehr_47_Linien_Alle_Fahrten_mit_GPS_Streckenverlaeufen_Guru_Maps.gpx
- Enthaltene GPX-Tracks im Original: 2318
- Linien mit mindestens einem verwertbaren GPX-Track: 32
- In `gpx-lines.json` ist pro Linie ein repräsentativer Track für den schnellen Vergleich auf der OpenStreetMap-Karte enthalten.
- Das vollständige GPX liegt unter `app/src/main/assets/westverkehr-original.gpx` und wird beim Start NICHT komplett eingelesen.
- Die Zuordnung zur konkreten Fahrt ist nicht gesichert. Der Referenztrack ist keine zertifizierte Busnavigation.

## Verwendung
Im Setup-Menü GPX-Linie auswählen und auf Karte anzeigen. Orange gestrichelte Linie = GPX-Referenz, türkis = gewählte Fahrt.

## APK
Das Projekt muss mit Android Studio gebaut werden. Standortberechtigungen sind im Manifest enthalten, GPS braucht Nutzereinwilligung.
