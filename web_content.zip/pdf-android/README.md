# مدير PDF المتكامل (غلاف أندرويد)

مشروع Android Studio كامل يغلّف تطبيق الويب `مدير PDF المتكامل`
داخل WebView أصلي، جاهز للبناء والتوقيع والنشر على Google Play.

## محتويات المشروع

- `app/src/main/assets/app.html` — التطبيق الكامل (ملف HTML واحد، مطابق للأصل).
- `MainActivity.kt` — نشاط Kotlin يعرض التطبيق في WebView مع دعم JavaScript
  والتخزين المحلي (localStorage) وزر الرجوع، بالإضافة إلى دعم اختيار الملفات
  (`onShowFileChooser`) لاختيار ملفات PDF (`<input type="file" accept="application/pdf">`).
- اسم الحزمة: `com.pdfmanager.app`
- `minSdk 24` / `targetSdk 34` / `compileSdk 34`
- **لا توجد أي صلاحيات** — التطبيق يعمل دون اتصال بالإنترنت بالكامل.

## طريقة البناء

1. افتح Android Studio ثم اختر **Open** وحدّد مجلد `pdf-android`.
2. انتظر انتهاء مزامنة Gradle (يتطلب اتصال إنترنت أول مرة لتنزيل الحزم).
3. من القائمة: **Build > Generate Signed Bundle / APK** لبناء نسخة النشر،
   أو اضغط **Run** للتجربة على جهاز أو محاكي.
4. ملف التطبيق نفسه موجود في `app/src/main/assets/app.html` —
   لتحديث التطبيق مستقبلًا استبدل هذا الملف بالنسخة الجديدة وأعد البناء.

## ملاحظات

- الوضع الليلي/النهاري والاتجاه RTL مدعومان داخل التطبيق نفسه.
- لم يُبنَ ملف APK هنا — هذا مشروع مصدري يُبنى داخل Android Studio.

