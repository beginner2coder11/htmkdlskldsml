# 4.000 WOCHEN Plus X – Android API 36 Konverter-Projekt

Dieses Projekt wurde aus den vorhandenen Android-API36-Master-ZIPs aufgebaut und mit der aktuellen Referenz-Masterdatei verbunden.

## Eingebundene Referenz
- `app/src/main/assets/index.html`
- `4000_WOCHEN_Plus_X_MASTER_Lebenskalender_SANDUHR_ANIMATION_SONNENKERN_KONVERTER_FINAL.html`

## Technischer Stand
- compileSdk 36
- targetSdk 36
- minSdk 26
- Application ID: `de.wochen.plusx`
- WebView mit JavaScript und LocalStorage
- Native Android-Erinnerungen über AlarmManager + BroadcastReceiver
- Notification Channel „Erinnerungen"
- POST_NOTIFICATIONS für Android 13+
- Boot-/App-Update-Rescheduling der Erinnerungen
- WebView-Bridge `AndroidReminders` für die HTML-Erinnerungsfunktion

## Verwendung
Das Projekt ist als Android-Studio-Projekt vorbereitet. Den Projektordner öffnen und anschließend eine APK für Tests oder ein signiertes AAB für Google Play bauen.
