WOOD METRIC — Paket Build Android (prototipe UI)
================================================

Isi:
- index.html: aplikasi UI mobile-first untuk dibungkus menjadi APK melalui HTML-to-APK builder.
- README-ID.txt: panduan dan batasan.

Fitur prototipe:
- Dashboard ringkas: jumlah pengukuran, menunggu dokumen, selesai.
- Master data truk (ID/nomor polisi, vendor, sopir).
- Form pengukuran: pilih truk, panjang 7,6/11,4 m, lebar 2,4/3,0 m, tinggi T1-T3.
- Hitung volume stapel = panjang x lebar x rata-rata tinggi.
- Konversi Akasia menggunakan faktor 0,59.
- Riwayat pengukuran, status dokumen, pencarian dan ekspor CSV.
- Tombol akses kamera langsung + fallback ambil/pilih foto.

PENTING — BATASAN DATA BERSAMA:
Versi ini adalah prototipe lokal. Data disimpan di localStorage perangkat/browser dan TIDAK otomatis terlihat oleh petugas lain.
Agar semua petugas bisa melihat data yang sama, perlu backend/database online (misalnya Firebase/Supabase) ditambah autentikasi dan aturan akses. Jangan gunakan untuk dokumen resmi sebelum integrasi dan validasi.
Foto saat ini tidak disimpan permanen ke rekaman pengukuran.
Garis kamera hanya panduan visual; tinggi T1-T3 masih input manual, bukan otomatis dihitung dari foto.
Kamera langsung hanya bekerja jika pembungkus APK mendukung WebView camera permission. Jika tidak, tombol ambil foto dari HP adalah fallback.

Build:
1. Ekstrak ZIP jika builder meminta file HTML, pilih index.html.
2. Atur nama aplikasi: Wood Metric.
3. Jika tersedia, aktifkan Camera Permission.
4. Build APK dan instal hanya jika sumber hasil build dipercaya.
5. Uji kamera, penyimpanan, perhitungan, ekspor CSV sebelum dipakai di lapangan.

Perhitungan:
rata-rata tinggi = (T1 + T2 + T3) / 3
volume stapel = panjang x lebar x rata-rata tinggi
konversi Akasia = volume stapel x 0,59
Pastikan faktor dan metode sesuai standar perusahaan sebelum penggunaan resmi.
