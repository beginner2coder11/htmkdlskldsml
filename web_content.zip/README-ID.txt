StapelCam HTI — proyek aplikasi Android (sumber), versi 0.1

PENTING:
- Ini adalah proyek sumber Android Studio, BUKAN APK siap instal.
- Lingkungan ini tidak memiliki Android SDK/Gradle untuk mengompilasi APK.
- Untuk menghasilkan APK, buka folder proyek ini di Android Studio pada komputer, tunggu Gradle sync, lalu pilih Build > Build APK(s).
- Proyek memerlukan internet saat pertama kali mengambil dependensi Gradle.
- Setelah APK dibuat, pindahkan ke Huawei, buka file APK, lalu izinkan instalasi dari sumber tersebut jika Android meminta.

Fitur yang dibungkus:
- Aplikasi web StapelCam dimuat di WebView Android lewat origin HTTPS lokal aman.
- Meminta izin kamera Android dan meneruskan izin kamera ke halaman.
- Data perhitungan tetap tersimpan lokal di WebView/browser storage perangkat.

Batasan prototipe:
- Belum mengukur tinggi kayu secara otomatis dari foto.
- Tinggi T1/T2/T3 masih dimasukkan manual.
- Garis kamera hanya panduan visual; bukan kalibrasi meter.
- Validasi dengan alat ukur dan standar perusahaan sebelum angka dipakai sebagai data resmi.
