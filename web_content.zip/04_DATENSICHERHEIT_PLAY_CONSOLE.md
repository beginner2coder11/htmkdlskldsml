# Datensicherheit – Vorbereitung für die Play Console

Diese Angaben sind ein technischer Vorentwurf und müssen vor der Einreichung gegen die finale Release-APK/AAB geprüft werden.

## Aktueller technischer Befund
- HTML-App nutzt localStorage.
- Keine fetch()-Aufrufe im geprüften HTML.
- Keine HTTP/HTTPS-URLs im geprüften HTML.
- Android-Manifest enthält POST_NOTIFICATIONS und RECEIVE_BOOT_COMPLETED.
- Kein INTERNET-Permission-Eintrag im vorhandenen Manifest.
- Persönliche Inhalte werden nach aktuellem Stand lokal verarbeitet.

## Vorläufige Play-Console-Einordnung
- Datenerhebung durch den Entwickler/Server: nach aktuellem Codebefund keine eigene Servererhebung.
- Datenweitergabe an Dritte: nach aktuellem Codebefund keine eigene Weitergabe.
- Fotos: vom Nutzer ausgewählte Inhalte können lokal verarbeitet/gespeichert werden; finale Wrapper-Prüfung erforderlich.
- Persönliche Informationen: Name/Geburtsdatum können lokal gespeichert werden; finale Data-Safety-Klassifikation in der Play Console prüfen.
- App-Aktivität/Erinnerungen: lokale Erinnerungsdaten können für Benachrichtigungen verwendet werden.
- Sicherheit: keine eigene Netzwerkübertragung im geprüften HTML festgestellt.

Wichtig: Google verlangt das Datensicherheitsformular auch bei Apps, die keine Nutzerdaten erheben; die Angaben müssen den tatsächlichen Code einschließlich Drittanbieter-SDKs widerspiegeln.
