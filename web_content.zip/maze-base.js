(function(root){
const quiz=[
['Quel animal possède trois cœurs ?',['Le dauphin','La pieuvre','Le requin','La tortue'],1,'La pieuvre possède trois cœurs.'],
['Combien de côtés possède un hexagone ?',['5','6','7','8'],1,'Un hexagone possède six côtés.'],
['Quelle planète est surnommée la planète rouge ?',['Vénus','Jupiter','Mars','Saturne'],2,'Le sol de Mars contient des oxydes de fer qui lui donnent sa couleur.'],
['Dans quel pays se trouve la tour de Pise ?',['France','Espagne','Grèce','Italie'],3,'La tour de Pise se trouve en Italie.'],
['Quel ingrédient fait gonfler la pâte à pain ?',['Le sel','La levure','Le beurre','Le sucre glace'],1,'La levure produit du gaz qui fait gonfler la pâte.'],
['Combien de minutes y a-t-il dans deux heures ?',['90','100','120','180'],2,'Deux fois soixante minutes : 120 !'],
['Quel animal est un mammifère ?',['Le crocodile','Le dauphin','Le pingouin','La grenouille'],1,'Le dauphin respire de l’air et allaite ses petits.'],
['Quelle couleur obtient-on en mélangeant peinture bleue et jaune ?',['Vert','Violet','Orange','Rose'],0,'Le mélange donne du vert.'],
['Quel instrument possède des touches noires et blanches ?',['Le violon','La trompette','Le piano','La batterie'],2,'C’est le piano !'],
['Quel océan borde l’ouest de la France métropolitaine ?',['Indien','Arctique','Pacifique','Atlantique'],3,'C’est l’océan Atlantique.'],
['Combien de pattes possède une araignée ?',['4','6','8','10'],2,'Une araignée possède huit pattes.'],
['Quelle est la capitale du Portugal ?',['Madrid','Lisbonne','Rome','Athènes'],1,'Lisbonne est la capitale du Portugal.']
];
const mysteries=[['🚀','Une fusée',['Un avion','Une fusée','Un phare','Une bougie'],1],['🦉','Un hibou',['Un hibou','Un chat','Un aigle','Un renard'],0],['🍍','Un ananas',['Une fraise','Une poire','Un ananas','Un citron'],2],['🎸','Une guitare',['Un violon','Un piano','Une harpe','Une guitare'],3],['🐙','Une pieuvre',['Une méduse','Une pieuvre','Un crabe','Une étoile de mer'],1],['🚲','Un vélo',['Un vélo','Une moto','Un tracteur','Une trottinette'],0]];
function shuffle(a){return a.slice().sort(()=>Math.random()-.5)}
function maze(){
 const w=9,h=7,rows=[0,2,4,6],answer=Math.floor(Math.random()*4);
 for(let attempt=0;attempt<1000;attempt++){
  const cells=Array.from({length:w*h},()=>[1,1,1,1]),seen=new Set([27]),stack=[27],delta=[-w,1,w,-1];
  while(stack.length){let n=stack[stack.length-1],x=n%w,y=Math.floor(n/w);let ds=shuffle([0,1,2,3]).filter(d=>!(d===0&&y===0||d===1&&x===w-1||d===2&&y===h-1||d===3&&x===0)&&!seen.has(n+delta[d]));if(!ds.length){stack.pop();continue}let d=ds[0],v=n+delta[d];cells[n][d]=0;cells[v][(d+2)%4]=0;seen.add(v);stack.push(v)}
  rows.forEach((y,k)=>{if(k===answer)return;let n=y*w+w-1;[0,2,3].forEach(d=>{let v=n+delta[d];if(v>=0&&v<w*h){cells[n][d]=1;cells[v][(d+2)%4]=1}})});
  let reach=new Set([27]),todo=[27];while(todo.length){let n=todo.pop();cells[n].forEach((wall,d)=>{let v=n+delta[d];if(!wall&&!reach.has(v)){reach.add(v);todo.push(v)}})}
  if(reach.has(rows[answer]*w+w-1))return {w,h,cells,answer,rows};
 }
 throw Error('Maze generation failed');
}
function rounds(n){let qs=shuffle(quiz),ms=shuffle(mysteries);return Array.from({length:n},(_,i)=>{let type=i%3;if(type===0){let q=qs.pop();return {type,question:q[0],options:q[1],answer:q[2],explanation:q[3]}}if(type===1){let q=ms.pop();return {type,question:'Quel dessin se cache derrière les étoiles ?',icon:q[0],options:q[2],answer:q[3],explanation:'Le dessin mystère : '+q[1].toLowerCase()+' !'}}let m=maze();return {type,question:'Quelle sortie peut-on rejoindre depuis la flèche ?',options:['Sortie A','Sortie B','Sortie C','Sortie D'],answer:m.answer,maze:m,explanation:'Seule la sortie '+ 'ABCD'[m.answer]+' est reliée au départ.'}})}
const api={quiz,mysteries,maze,rounds};if(typeof module!=='undefined')module.exports=api;root.PartyEngine=api;
})(typeof window!=='undefined'?window:globalThis);
