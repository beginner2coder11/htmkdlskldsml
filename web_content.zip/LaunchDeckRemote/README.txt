LaunchDeck Remote — Android project (repacked for cloud APK build)

WHAT'S INCLUDED
- Native Android WebView app shell
- LaunchDeck Remote mobile interface in app/src/main/assets/index.html
- GitHub Actions workflow that builds and publishes a downloadable debug APK

IMPORTANT STATUS
This ZIP contains Android source code, not a compiled APK. This chat environment does not have the Android SDK or Gradle installed, so it cannot produce or verify an APK locally. The included cloud workflow builds the APK on GitHub after you upload this project to a GitHub repository.

BUILD APK USING A PHONE
1. On GitHub, create a new repository (for example: launchdeck-remote). The repository can be private.
2. Extract this ZIP on your phone using a ZIP/file manager.
3. Upload the extracted project files and folders to the repository's main branch. Include the hidden .github/workflows/build-apk.yml folder/file.
4. Open the repository on GitHub and tap Actions.
5. Choose “Build LaunchDeck Remote APK” and tap “Run workflow” if it did not start automatically after upload.
6. Open the completed workflow run. Under Artifacts, download “LaunchDeck-Remote-debug-APK”.
7. Extract the downloaded artifact ZIP; install app-debug.apk on your Android device. Android may ask you to allow installation from that source.

ANDROID STUDIO BUILD (COMPUTER)
Open this project folder in Android Studio, allow Gradle sync, then select Build > Build APK(s). The expected output is app/build/outputs/apk/debug/app-debug.apk.

FUNCTIONAL LIMITATIONS
The Android interface is a prototype. The app expects a separate PC companion service exposing GET /health and POST /launch. That PC companion is not included in this Android project, so the UI can be installed but PC launch actions will not work until the companion service is built, configured, and running on the same trusted local Wi-Fi network. Do not expose an unauthenticated companion service to the public internet.
