'use strict';
const fittedMain=document.querySelector('main');
const insetProbe=document.createElement('div');insetProbe.setAttribute('aria-hidden','true');insetProbe.style.cssText='position:fixed;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)';document.body.append(insetProbe);
function fittedPanelBounds(width,height,insets={top:0,right:0,bottom:0,left:0},offsetX=0,offsetY=0){
 const gap=16,usableWidth=Math.max(1,width-insets.left-insets.right-gap*2),usableHeight=Math.max(1,height-insets.top-insets.bottom-gap*2),portrait=height>width;
 const scale=Math.min((portrait?usableHeight:usableWidth)/1000,(portrait?usableWidth:usableHeight)/480);
 const panelWidth=(portrait?480:1000)*scale,panelHeight=(portrait?1000:480)*scale;
 const x=offsetX+insets.left+gap+(usableWidth-panelWidth)/2,y=offsetY+insets.top+gap+(usableHeight-panelHeight)/2;
 return {scale,portrait,x,y,panelWidth,panelHeight,transform:portrait?`matrix(0,${scale},${-scale},0,${x+panelWidth},${y})`:`matrix(${scale},0,0,${scale},${x},${y})`};
}
function fitDashboard(){
 const viewport=window.visualViewport,style=getComputedStyle(insetProbe),number=v=>parseFloat(v)||0;
 const bounds=fittedPanelBounds(viewport?.width||window.innerWidth,viewport?.height||window.innerHeight,{top:number(style.paddingTop),right:number(style.paddingRight),bottom:number(style.paddingBottom),left:number(style.paddingLeft)},viewport?.offsetLeft||0,viewport?.offsetTop||0);
 fittedMain.style.transform=bounds.transform;document.body.classList.add('panelFitted');
}
window.addEventListener('resize',fitDashboard);window.addEventListener('orientationchange',fitDashboard);window.visualViewport?.addEventListener('resize',fitDashboard);window.visualViewport?.addEventListener('scroll',fitDashboard);
$('libraryBack').onclick=dashboardHome;
fitDashboard();
