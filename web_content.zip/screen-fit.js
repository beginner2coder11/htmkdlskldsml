'use strict';
let viewportFrame=0;
function responsiveLayout(width,height){return {orientation:height>width?'portrait':'landscape',dockColumns:height>width?3:6}}
function updateResponsiveViewport(){
 const viewport=window.visualViewport,width=viewport?.width||window.innerWidth,height=viewport?.height||window.innerHeight;
 const layout=responsiveLayout(width,height);document.body.dataset.orientation=layout.orientation;
 document.documentElement.style.setProperty('--app-height',height+'px');
 const scene=document.querySelector('.dashboardScene');
 if(scene){const rect=scene.getBoundingClientRect(),portrait=layout.orientation==='portrait';const size=Math.max(1,Math.min(rect.width*(portrait?.40:.24),rect.height*(portrait?.33:.78),portrait?260:360));scene.style.setProperty('--dial-size',size+'px')}
 if(typeof resizeVuCanvas==='function')resizeVuCanvas();
}
function scheduleResponsiveLayout(){cancelAnimationFrame(viewportFrame);viewportFrame=requestAnimationFrame(updateResponsiveViewport)}
window.addEventListener('resize',scheduleResponsiveLayout);window.addEventListener('orientationchange',scheduleResponsiveLayout);window.visualViewport?.addEventListener('resize',scheduleResponsiveLayout);
$('libraryBack').onclick=dashboardHome;
updateResponsiveViewport();scheduleResponsiveLayout();
