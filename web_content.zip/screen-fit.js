'use strict';
let viewportFrame=0;
let manualScreenRotation=false;
const fixedOrientation='landscape';
function responsiveLayout(width,height){return {orientation:height>width?'portrait':'landscape',dockColumns:height>width?3:6}}
function updateResponsiveViewport(){
 const viewport=window.visualViewport,physicalWidth=viewport?.width||window.innerWidth,physicalHeight=viewport?.height||window.innerHeight;
 manualScreenRotation=fixedOrientation==='portrait'?physicalWidth>physicalHeight:physicalHeight>physicalWidth;
 const width=manualScreenRotation?physicalHeight:physicalWidth,height=manualScreenRotation?physicalWidth:physicalHeight;
 const root=document.documentElement;
 root.style.setProperty('--physical-width',physicalWidth+'px');
 root.style.setProperty('--layout-width',width+'px');
 root.style.setProperty('--app-height',height+'px');
 document.body.dataset.manualRotation=String(manualScreenRotation);
 const layout=responsiveLayout(width,height);document.body.dataset.orientation=layout.orientation;
 const scene=document.querySelector('.dashboardScene');
 if(scene){const portrait=layout.orientation==='portrait';const size=Math.max(1,Math.min(scene.clientWidth*(portrait?.40:.24),scene.clientHeight*(portrait?.33:.78),portrait?260:360));scene.style.setProperty('--dial-size',size+'px')}
 if(typeof resizeVuCanvas==='function')resizeVuCanvas();
}
function scheduleResponsiveLayout(){cancelAnimationFrame(viewportFrame);viewportFrame=requestAnimationFrame(updateResponsiveViewport)}
window.addEventListener('resize',scheduleResponsiveLayout);window.addEventListener('orientationchange',scheduleResponsiveLayout);window.visualViewport?.addEventListener('resize',scheduleResponsiveLayout);
$('libraryBack').onclick=dashboardHome;
updateResponsiveViewport();scheduleResponsiveLayout();
