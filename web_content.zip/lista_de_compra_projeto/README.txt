# LISTA DE COMPRA — Projeto

## Conteúdo
- `index.html`: aplicação completa.
- `manifest.json`: nome e configuração de instalação como PWA.
- `service-worker.js`: cache dos ficheiros para utilização offline após a primeira abertura num endereço HTTPS.
- `icons/`: ícones da aplicação.

## Funções
- Capital disponível.
- Produtos, unidades por caixa, custo por caixa, custo por unidade calculado, quantidade de caixas e total.
- Cálculo do total da compra e dinheiro restante.
- Comparação do custo unitário com o último registo guardado para o mesmo produto.
- Histórico local, detalhes, reutilização de listas e PDF da lista atual ou de uma lista histórica.

## Testar
Abra `index.html` num navegador moderno. O cálculo e o histórico local funcionam no navegador. A geração de PDF abre um relatório separado e apresenta a janela de impressão. Se a janela de impressão não aparecer automaticamente, use o botão “Imprimir / Guardar como PDF” no relatório. Escolha “Guardar como PDF” nas opções de impressão. Se o navegador bloquear a nova janela, permita pop-ups para a aplicação e tente novamente.

## Instalação como aplicação
**PWA:** publique todos os ficheiros numa hospedagem HTTPS (por exemplo, Netlify). Depois abra o endereço no Chrome Android e use o menu **Instalar aplicação** ou **Adicionar ao ecrã inicial**. O modo offline fica disponível depois do primeiro carregamento.

**APK:** importe `index.html` e os ficheiros do projeto para uma ferramenta de empacotamento HTML/WebView ou para um projeto Android WebView/Capacitor. Para instalação offline num APK, inclua os ficheiros dentro do pacote do aplicativo. O service worker não é executado em `file://`; isso não impede o funcionamento do HTML empacotado numa WebView, mas a estratégia de armazenamento e PDF deve ser testada no empacotador escolhido.

## Dados
As listas são guardadas em `localStorage` do navegador/dispositivo. Limpar os dados do navegador pode apagar o histórico. Não há servidor nem sincronização entre dispositivos.
