import os
import re
import tempfile
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Regex patterns for common license formats
PATTERNS = [
    r'[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}', # Standard Key
    r'[A-Za-z0-9+/]{20,}={0,2}',                          # Base64-ish blobs
    r'(?:LICENSE|KEY|SERIAL|AUTH)[=: ]{1,5}[A-Z0-9\-]{10,}' # Contextual keys
]

@app.route('/')
def index():
    return render_template('index.html') # Assuming index.html is in a 'templates' folder

@app.route('/api/analyze', methods=['POST'])
def analyze():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # Read file content directly from memory (no need to save to disk first)
    content = file.read()
    
    # Decode binary content to string for regex matching
    # We ignore errors to avoid crashing on weird binary chars
    try:
        text_content = content.decode('utf-8', errors='ignore')
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    found_keys = set()

    for pattern in PATTERNS:
        matches = re.findall(pattern, text_content)
        for match in matches:
            # Clean up whitespace/newlines often found in binaries
            clean_match = match.replace('\n', '').replace('\r', '')
            if len(clean_match) > 5: # Filter out tiny false positives
                found_keys.add(clean_match)

    return jsonify({
        "keys": list(found_keys),
        "count": len(found_keys)
    })

if __name__ == '__main__':
    # For Termux or local testing
    app.run(host='0.0.0.0', port=5000, debug=False)