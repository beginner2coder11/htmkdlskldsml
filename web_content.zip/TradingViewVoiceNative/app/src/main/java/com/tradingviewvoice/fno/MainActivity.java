package com.tradingviewvoice.fno;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer recognizer;
    private static final int MIC_REQ = 44;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void requestMic() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
            return;
        }
        startNativeVoice();
    }

    private void startNativeVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            send("", "unavailable"); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p){ send("", "listening"); }
            public void onBeginningOfSpeech(){ send("", "listening"); }
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){ send("", "processing"); }
            public void onError(int e){ send("", "error:" + e); }
            public void onResults(Bundle r){
                ArrayList<String> x=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String best=(x!=null && !x.isEmpty())?x.get(0):"";
                send(best, "result");
            }
            public void onPartialResults(Bundle r){}
            public void onEvent(int a, Bundle b){}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        String lang = "hi-IN";
        try {
            web.evaluateJavascript("window.getVoiceLanguage ? window.getVoiceLanguage() : 'hi-IN'", v -> {
                String clean=v==null?"hi-IN":v.replace("\"", "");
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, clean);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, clean);
                recognizer.startListening(i);
            });
        } catch(Exception ex) { i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang); recognizer.startListening(i); }
    }

    private void send(String text, String state) {
        String t=text==null?"":text.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
        runOnUiThread(() -> web.evaluateJavascript("window.nativeVoiceResult('"+t+"','"+state+"')", null));
    }

    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==MIC_REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) startNativeVoice();
        else send("", "permission_denied");
    }

    @Override protected void onDestroy(){ if(recognizer!=null) recognizer.destroy(); if(web!=null) web.destroy(); super.onDestroy(); }

    public class VoiceBridge {
        @JavascriptInterface public void startVoice(){ runOnUiThread(() -> requestMic()); }
    }
}
