# Busdriver Navi V25 – Fahrer Edition (einheitliches Design)

Alle bisherigen Ansichten verwenden jetzt das anthrazit-gelbe Fahrer-Edition-Design: Linienauswahl (`home.html`), 2D/3D-GPX-Karte (`nav23.html`) und bestehende Funktionsseiten (`index.html`) einschließlich Dienstplan-Scanner, Wendezeiten, Fahrzeuge, Einstellungen und Leaflet-Karte. Die Startseite ist die Linienauswahl.

## Wichtige Grenzen
Dies ist ein Android-Studio-Projekt, **keine installierbare APK**. Android-Build und Gerätetest wurden nicht durchgeführt. Die 2D/3D-Ansicht nutzt MapLibre aus einem CDN und benötigt Netzverbindung. GPX ist eine Referenzstrecke, **keine verifizierte busgeeignete Abbiegenavigation**. Die Fotoerkennung des Dienstplans ist nicht garantiert; Zeiten kontrollieren. Standortberechtigung wird über Android angefragt.
