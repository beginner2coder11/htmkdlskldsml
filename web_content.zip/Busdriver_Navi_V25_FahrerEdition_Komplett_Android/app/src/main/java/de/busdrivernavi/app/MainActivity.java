package de.busdrivernavi.app;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.webkit.WebResourceResponse;
import java.io.InputStream;
import android.content.Intent;
import android.webkit.ValueCallback;
import java.util.Map;
import java.util.HashMap;

public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private static final int PICK_FILE=77;
 private GeolocationPermissions.Callback pendingCallback;
 private String pendingOrigin;
 private static final String HOST="appassets.androidplatform.net";
 @Override public void onCreate(Bundle state){super.onCreate(state);
  web=new WebView(this);setContentView(web);web.setKeepScreenOn(true);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setGeolocationEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMediaPlaybackRequiresUserGesture(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
    Uri u=request.getUrl();if(HOST.equals(u.getHost()) && u.getPath()!=null && u.getPath().startsWith("/assets/")){
     String name=u.getPath().substring("/assets/".length());
     if(!name.matches("[A-Za-z0-9._-]+"))return null;
     try {InputStream stream=getAssets().open(name);String mime=name.endsWith(".html")?"text/html":name.endsWith(".png")?"image/png":name.endsWith(".js")?"application/javascript":name.endsWith(".webmanifest")?"application/manifest+json":"text/plain";
      return new WebResourceResponse(mime,"UTF-8",stream);
     }catch(Exception ex){return null;}
    }return super.shouldInterceptRequest(view,request);
   }
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
     if(fileCallback!=null)fileCallback.onReceiveValue(null);
     fileCallback=callback;
     try {Intent intent=params.createIntent();startActivityForResult(intent,PICK_FILE);return true;}
     catch(Exception e){fileCallback=null;return false;}
   }
   @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
    if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);}
    else {pendingOrigin=origin;pendingCallback=callback;requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},42);}
   }
  });
  web.loadUrl("https://"+HOST+"/assets/home.html");
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==PICK_FILE && fileCallback!=null){
   fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));fileCallback=null;
  }
 }
 @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){super.onRequestPermissionsResult(requestCode,permissions,grants);if(requestCode==42 && pendingCallback!=null){boolean ok=false;for(int g:grants)if(g==PackageManager.PERMISSION_GRANTED)ok=true;pendingCallback.invoke(pendingOrigin,ok,false);pendingCallback=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
