/**
 * JAS LAUNDRY ROOM - Google Apps Script backend starter
 * Deploy as Web App: Execute as ME; Who has access: Anyone.
 * IMPORTANT: Set APP_SECRET in Script Properties before deployment.
 * Do not put a Google account password or service-account key here.
 */
const JAS = {
  PROP_SECRET: 'JAS_APP_SECRET',
  PROP_SHEET: 'JAS_DATA_SPREADSHEET_ID',
  SESSION_PREFIX: 'JAS_SESSION_',
  SESSION_HOURS: 12,
  HASH_ROUNDS: 1200,
  CHUNK_SIZE: 40000,
  USERS_SHEET: 'Users',
  DATA_SHEET: 'ERP_Data'
};

function setupJasCloud() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty(JAS.PROP_SECRET)) {
    throw new Error('First set Script Property JAS_APP_SECRET to a long random secret, then run setupJasCloud again.');
  }
  let id = props.getProperty(JAS.PROP_SHEET);
  let ss;
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create('JAS Laundry ERP Cloud Data');
    props.setProperty(JAS.PROP_SHEET, ss.getId());
  }
  let users = ss.getSheetByName(JAS.USERS_SHEET) || ss.insertSheet(JAS.USERS_SHEET);
  if (users.getLastRow() === 0) users.appendRow(['login','name','role','salt','passwordHash','active','createdAt']);
  let data = ss.getSheetByName(JAS.DATA_SHEET) || ss.insertSheet(JAS.DATA_SHEET);
  if (data.getLastRow() === 0) data.appendRow(['chunkIndex','jsonChunk','updatedAt']);
  Logger.log('JAS Cloud ready. Spreadsheet: ' + ss.getUrl());
  return ss.getUrl();
}

function doGet() {
  return json_({ok:true, service:'JAS Laundry ERP API', version:'1.0', message:'POST actions are available.'});
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const secret = String(req.secret || '');
    if (!constantTimeEqual_(secret, PropertiesService.getScriptProperties().getProperty(JAS.PROP_SECRET) || '')) {
      return json_({ok:false, error:'APP_AUTH_FAILED', message:'Cloud app token is invalid.'});
    }
    const action = String(req.action || '');
    const result = route_(action, req, lock);
    return json_({ok:true, ...result});
  } catch (err) {
    return json_({ok:false, error:'SERVER_ERROR', message:String(err && err.message || err)});
  }
}

function route_(action, req, lock) {
  switch (action) {
    case 'ping': return {service:'JAS Laundry ERP API', time:new Date().toISOString()};
    case 'bootstrapOwner': return bootstrapOwner_(req, lock);
    case 'login': return login_(req, lock);
    case 'validateSession': return {user: requireSession_(req.session)};
    case 'logout': return logout_(req.session);
    case 'getData': return getData_(req);
    case 'saveData': return saveData_(req, lock);
    case 'createStaff': return createStaff_(req, lock);
    case 'listStaff': return listStaff_(req);
    case 'setStaffActive': return setStaffActive_(req, lock);
    case 'changePassword': return changePassword_(req, lock);
    default: throw new Error('Unknown API action: ' + action);
  }
}

function bootstrapOwner_(req, lock) {
  lock.waitLock(20000);
  try {
    const sh = usersSheet_();
    if (sh.getLastRow() > 1) throw new Error('An account already exists. Owner bootstrap is closed.');
    const name = clean_(req.name, 80), login = normalizeLogin_(req.login), password = String(req.password || '');
    validateAccount_(name, login, password, 'owner');
    const salt = Utilities.getUuid() + Utilities.getUuid();
    sh.appendRow([login, name, 'owner', salt, passwordHash_(password, salt), true, Date.now()]);
    return {message:'First Owner account created.'};
  } finally { lock.releaseLock(); }
}

function login_(req, lock) {
  const login = normalizeLogin_(req.login), password = String(req.password || ''), role = String(req.role || '');
  if (!login || !password || !['owner','staff'].includes(role)) throw new Error('Enter valid Login ID, password and role.');
  const sh = usersSheet_(), values = sh.getDataRange().getValues();
  for (let i=1; i<values.length; i++) {
    const r = values[i];
    if (String(r[0]).toLowerCase() !== login || String(r[2]) !== role) continue;
    if (r[5] === false || String(r[5]).toLowerCase() === 'false') throw new Error('This account is disabled by the Owner.');
    if (!constantTimeEqual_(passwordHash_(password, String(r[3])), String(r[4]))) throw new Error('Incorrect Login ID or password.');
    const token = Utilities.getUuid().replace(/-/g,'') + Utilities.getUuid().replace(/-/g,'');
    const user = {login:String(r[0]), name:String(r[1]), role:String(r[2])};
    const expiresAt = Date.now() + JAS.SESSION_HOURS*60*60*1000;
    PropertiesService.getScriptProperties().setProperty(JAS.SESSION_PREFIX + sha256_(token), JSON.stringify({user, expiresAt}));
    return {session:token, user, expiresAt};
  }
  throw new Error('Account not found. Ask the Owner to create the account.');
}

function requireSession_(token) {
  if (!token) throw new Error('Login session is missing. Please log in again.');
  const key = JAS.SESSION_PREFIX + sha256_(String(token));
  const props = PropertiesService.getScriptProperties();
  const raw = props.getProperty(key);
  if (!raw) throw new Error('Login session expired. Please log in again.');
  const s = JSON.parse(raw);
  if (!s.expiresAt || s.expiresAt < Date.now()) { props.deleteProperty(key); throw new Error('Login session expired. Please log in again.'); }
  return s.user;
}

function logout_(token) {
  if (token) PropertiesService.getScriptProperties().deleteProperty(JAS.SESSION_PREFIX + sha256_(String(token)));
  return {message:'Session ended.'};
}

function getData_(req) {
  const user = requireSession_(req.session);
  const data = readData_();
  if (user.role === 'owner') return {data, user};
  return {data:staffView_(data, user), user};
}

function saveData_(req, lock) {
  const user = requireSession_(req.session);
  if (!req.data || typeof req.data !== 'object') throw new Error('ERP data payload is missing.');
  lock.waitLock(20000);
  try {
    const current = readData_();
    let next;
    if (user.role === 'owner') {
      next = req.data;
    } else {
      // Staff can update operational records only; owner-only payroll, expenses,
      // cash controls, users and business configuration remain server-protected.
      const allowed = ['bills','customers','customerAdvances','refunds','activities','attendance'];
      next = {...current};
      allowed.forEach(k => { if (Object.prototype.hasOwnProperty.call(req.data,k)) next[k] = req.data[k]; });
    }
    writeData_(next);
    return {message:'Saved', updatedAt:Date.now()};
  } finally { lock.releaseLock(); }
}

function createStaff_(req, lock) {
  const owner = requireSession_(req.session);
  if (owner.role !== 'owner') throw new Error('Owner permission required.');
  lock.waitLock(20000);
  try {
    const name = clean_(req.name,80), login = normalizeLogin_(req.login), password = String(req.password || '');
    validateAccount_(name, login, password, 'staff');
    const sh = usersSheet_(), values = sh.getDataRange().getValues();
    if (values.slice(1).some(r => String(r[0]).toLowerCase() === login)) throw new Error('This Login ID already exists.');
    const salt = Utilities.getUuid() + Utilities.getUuid();
    sh.appendRow([login,name,'staff',salt,passwordHash_(password,salt),true,Date.now()]);
    return {message:'Staff account created.'};
  } finally { lock.releaseLock(); }
}

function listStaff_(req) {
  const owner = requireSession_(req.session);
  if (owner.role !== 'owner') throw new Error('Owner permission required.');
  const rows = usersSheet_().getDataRange().getValues();
  return {users:rows.slice(1).filter(r=>r[2]==='staff').map(r=>({login:r[0],name:r[1],role:r[2],active:r[5]!==false&&String(r[5]).toLowerCase()!=='false'}))};
}

function setStaffActive_(req, lock) {
  const owner = requireSession_(req.session);
  if (owner.role !== 'owner') throw new Error('Owner permission required.');
  lock.waitLock(20000);
  try {
    const sh=usersSheet_(), rows=sh.getDataRange().getValues(), login=normalizeLogin_(req.login);
    for(let i=1;i<rows.length;i++) if(String(rows[i][0]).toLowerCase()===login && rows[i][2]==='staff') { sh.getRange(i+1,6).setValue(!!req.active); return {message:'Staff status updated.'}; }
    throw new Error('Staff account not found.');
  } finally { lock.releaseLock(); }
}

function changePassword_(req, lock) {
  const user = requireSession_(req.session);
  const target = normalizeLogin_(req.login || user.login);
  if (user.role !== 'owner' && target !== user.login) throw new Error('You can change only your own password.');
  const password = String(req.newPassword || '');
  if (password.length < 10) throw new Error('New password must be at least 10 characters.');
  lock.waitLock(20000);
  try {
    const sh=usersSheet_(), rows=sh.getDataRange().getValues();
    for(let i=1;i<rows.length;i++) if(String(rows[i][0]).toLowerCase()===target) {
      const salt=Utilities.getUuid()+Utilities.getUuid(); sh.getRange(i+1,4).setValue(salt); sh.getRange(i+1,5).setValue(passwordHash_(password,salt)); return {message:'Password updated.'};
    }
    throw new Error('Account not found.');
  } finally { lock.releaseLock(); }
}

function staffView_(data, user) {
  const out = {};
  ['prices','bills','customers','customerAdvances','refunds','activities','attendance'].forEach(k=>{ if (data && Object.prototype.hasOwnProperty.call(data,k)) out[k]=data[k]; });
  if (data && data.settings) out.settings = {shop:data.settings.shop,phone:data.settings.phone,secondaryPhone:data.settings.secondaryPhone,address:data.settings.address};
  if (Array.isArray(out.attendance)) out.attendance = out.attendance.filter(x => String(x.staffId||'') === user.login || String(x.staff||'') === user.name);
  return out;
}

function readData_() {
  const sh=dataSheet_(), last=sh.getLastRow();
  if (last < 2) return {};
  const rows=sh.getRange(2,1,last-1,2).getValues().sort((a,b)=>Number(a[0])-Number(b[0]));
  const raw=rows.map(r=>String(r[1]||'')).join('');
  return raw ? JSON.parse(raw) : {};
}
function writeData_(obj) {
  const sh=dataSheet_(), raw=JSON.stringify(obj), chunks=[];
  for(let i=0;i<raw.length;i+=JAS.CHUNK_SIZE) chunks.push(raw.slice(i,i+JAS.CHUNK_SIZE));
  sh.clearContents(); sh.appendRow(['chunkIndex','jsonChunk','updatedAt']);
  const now=Date.now();
  if(chunks.length) sh.getRange(2,1,chunks.length,3).setValues(chunks.map((c,i)=>[i,c,now]));
}
function usersSheet_(){return spreadsheet_().getSheetByName(JAS.USERS_SHEET);}
function dataSheet_(){return spreadsheet_().getSheetByName(JAS.DATA_SHEET);}
function spreadsheet_(){const id=PropertiesService.getScriptProperties().getProperty(JAS.PROP_SHEET);if(!id)throw new Error('Run setupJasCloud() once before using the API.');return SpreadsheetApp.openById(id);}
function validateAccount_(name,login,password,role){if(!name||!login||password.length<10)throw new Error('Name, Login ID and a password of at least 10 characters are required.');if(role==='owner'&&!/^\S+@\S+\.\S+$/.test(login))throw new Error('Owner Login ID must be a valid email address.');}
function normalizeLogin_(v){return String(v||'').trim().toLowerCase();}
function clean_(v,n){return String(v||'').trim().slice(0,n);}
function passwordHash_(password,salt){let bytes=Utilities.newBlob(salt+'|'+password).getBytes();for(let i=0;i<JAS.HASH_ROUNDS;i++)bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,bytes);return Utilities.base64Encode(bytes);}
function sha256_(s){return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(s)));}
function constantTimeEqual_(a,b){a=String(a);b=String(b);if(a.length!==b.length)return false;let v=0;for(let i=0;i<a.length;i++)v|=a.charCodeAt(i)^b.charCodeAt(i);return v===0;}
function json_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
