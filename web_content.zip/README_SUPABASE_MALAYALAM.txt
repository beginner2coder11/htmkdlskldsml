JAS LAUNDRY - SUPABASE MIGRATION BUILD

ഈ build-ൽ Supabase Cloud Sync option ചേർത്തിട്ടുണ്ട്. പഴയ Local Storage STORE (jasLaundryBillingV2) തുടരും. Cloud connect ചെയ്യുമ്പോൾ ആദ്യം recovery copy Local Storage-ൽ സൃഷ്ടിക്കുകയും local + cloud records merge ചെയ്യുകയും ചെയ്യുന്നു. പഴയ Firebase configuration/code നീക്കം ചെയ്തിട്ടില്ല; പക്ഷേ പുതിയ Supabase panel ആണ് ഉപയോഗിക്കേണ്ടത്.

ആദ്യം ചെയ്യേണ്ടത്:
1. Supabase Dashboard -> SQL Editor -> New query തുറക്കുക.
2. ZIP-ലുള്ള SUPABASE_SETUP.sql മുഴുവൻ paste ചെയ്ത് Run ചെയ്യുക.
3. Settings -> Authentication -> Providers -> Email-ൽ Email provider enabled ആണെന്ന് ഉറപ്പാക്കുക.
4. Email confirmation enabled ആണെങ്കിൽ signup email confirm ചെയ്യണം; അല്ലെങ്കിൽ Auth settings-ൽ Confirm email disable ചെയ്യാം.
5. App Settings -> Supabase Cloud Sync-ൽ URL, Publishable Key, Owner email, Supabase password നൽകുക.
6. Connect Supabase & Start Sync അമർത്തുക.
7. ഓരോ staff device-ലും ആദ്യം Owner app login ചെയ്ത് Settings → Supabase Cloud Sync-ൽ അതേ Supabase Owner account ഉപയോഗിച്ച് Connect ചെയ്യുക. ഇതിലൂടെ staff account list (password hashes ഉൾപ്പെടെ)യും business data-യും download ചെയ്യും. ശേഷം app logout ചെയ്ത് ആ device-ൽ local Staff ID/password ഉപയോഗിക്കാം. Supabase Auth session നിലനിൽക്കുന്നതിനാൽ background sync തുടരും. Staff-ന് വേറെ Supabase identities/row-level branch permissions ഈ build-ൽ ഇല്ല; staff device-ൽ Owner cloud session-ന്റെ access model ആണ് ഉപയോഗിക്കുന്നത്.

സുരക്ഷയും പരിമിതികളും:
- Publishable key browser-ൽ ഉപയോഗിക്കാവുന്നതാണ്; Secret/service_role key HTML-ൽ ഒരിക്കലും ഇടരുത്.
- SQL RLS policy ഓരോ signed-in Supabase Owner-നും സ്വന്തം owner_uid row മാത്രം അനുവദിക്കുന്നു.
- എല്ലാ device-ലും അതേ Owner Supabase account ഉപയോഗിക്കേണ്ടതാണ്. Staff app login local hashed account list ആണ്; cloud data access ഓരോ device-ലും setup ചെയ്ത Owner Supabase session വഴിയാണ്. അതിനാൽ trusted staff devices മാത്രം Owner Supabase session setup ചെയ്യുക. Staff-specific Supabase identities/branch-level RLS ഈ build-ൽ ഇല്ല.
- Database SQL run ചെയ്യാതെ Cloud connect വിജയിക്കില്ല.
- ഈ ZIP live Supabase project-ൽ നിന്ന് end-to-end പരീക്ഷിച്ചിട്ടില്ല. ആദ്യം test device + downloaded Local Recovery JSON ഉപയോഗിച്ച് verify ചെയ്യുക. പഴയ app data clear/uninstall ചെയ്യരുത്.
- App-ൽ legacy Firebase code ഉണ്ട്; Supabase integration function overrides active cloud sync entry points. പഴയ Firebase settings പാനൽ ഇപ്പോഴും കാണാം; Supabase panel മാത്രം ഉപയോഗിക്കുക.
- Cloud payload നിലവിലെ app data object ആണ്. വലിയ ഡാറ്റാ വോള്യത്തിനും production multi-staff സുരക്ഷയ്ക്കും normalized per-record schema + staff membership/RLS migration ആവശ്യമാണ്.

HTML2APK Converter entry file: index.html
