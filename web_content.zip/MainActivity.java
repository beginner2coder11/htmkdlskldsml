package cl.metsur.traslados;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Envuelve index.html (assets) en un WebView y agrega lo que el WebView no trae:
 * compartir la imagen (WhatsApp, etc.), guardar en la Galería, copiar texto.
 * Nada de esto requiere permisos.
 */
public class MainActivity extends Activity {

    private static final int REQ_SAVE_FILE = 1002;
    private static final String APP_URL = "file:///android_asset/index.html";

    private WebView webView;
    private String shimJs = "";
    private byte[] pendingBytes;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try { shimJs = readAsset("android-shim.js"); } catch (Exception ignored) { }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(shimJs, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Aceptar", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.confirm())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Aceptar", (d, w) -> result.confirm())
                        .setNegativeButton("Cancelar", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        // Mantener presionada la imagen de la planilla = guardarla en la Galería
        webView.setOnLongClickListener(v -> {
            WebView.HitTestResult r = webView.getHitTestResult();
            int t = r.getType();
            if (t == WebView.HitTestResult.IMAGE_TYPE || t == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                String u = r.getExtra();
                if (u != null && u.startsWith("data:image") && u.contains(";base64,")) {
                    int comma = u.indexOf(',');
                    String mime = u.substring(5, u.indexOf(';'));
                    saveBytes("planilla_traslados.png", Base64.decode(u.substring(comma + 1), Base64.DEFAULT), mime);
                    return true;
                }
            }
            return false;
        });

        if (savedInstanceState == null) {
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    // ------------------------------------------------------------------ puente JS -> Android
    private class AndroidBridge {

        /** Escribe un archivo (base64) en la caché de la app para poder compartirlo. */
        @JavascriptInterface
        public boolean writeCacheFile(String path, String base64) {
            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) return false;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                try (FileOutputStream os = new FileOutputStream(new File(dir, safeName(path)))) {
                    os.write(bytes);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /** Abre el menú "Compartir" del sistema (WhatsApp, Telegram, correo...). */
        @JavascriptInterface
        public void share(final String title, final String text, final String path) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    boolean hasFile = false;
                    if (path != null && !path.isEmpty()) {
                        File f = new File(new File(getCacheDir(), "shared"), safeName(path));
                        if (f.exists()) {
                            Uri uri = FileProvider.getUriForFile(MainActivity.this,
                                    getPackageName() + ".fileprovider", f);
                            send.setType(mimeFor(f.getName()));
                            send.putExtra(Intent.EXTRA_STREAM, uri);
                            send.setClipData(ClipData.newRawUri("", uri));
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            hasFile = true;
                        }
                    }
                    if (!hasFile) send.setType("text/plain");
                    if (text != null && !text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
                    Intent chooser = Intent.createChooser(send, title == null || title.isEmpty() ? "Compartir" : title);
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(chooser);
                } catch (Exception e) {
                    toast("No se pudo abrir el menú de compartir");
                }
            });
        }

        /** Descarga: imágenes a la Galería (Pictures/Metsur); otros archivos con "Guardar como". */
        @JavascriptInterface
        public void saveFile(final String name, final String base64, final String mime) {
            try {
                final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> saveBytes(name, bytes, mime));
            } catch (Exception e) {
                runOnUiThread(() -> toast("No se pudo guardar el archivo"));
            }
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("texto", text));
            });
        }
    }

    // ------------------------------------------------------------------ guardado
    private void saveBytes(String name, byte[] bytes, String mime) {
        if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
        if (mime.startsWith("image/") && Build.VERSION.SDK_INT >= 29) {
            try {
                saveToGallery(name, bytes, mime);
                toast("Imagen guardada en la Galería (carpeta Metsur)");
            } catch (Exception e) {
                toast("No se pudo guardar la imagen");
            }
        } else {
            // Android 8 o menor / archivos no-imagen: selector del sistema, sin permisos
            pendingBytes = bytes;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE, name);
            try {
                startActivityForResult(i, REQ_SAVE_FILE);
            } catch (Exception e) {
                pendingBytes = null;
                toast("No se pudo abrir el selector de archivos");
            }
        }
    }

    private void saveToGallery(String name, byte[] bytes, String mime) throws Exception {
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                .format(new java.util.Date());
        int dot = name.lastIndexOf('.');
        String finalName = dot > 0
                ? name.substring(0, dot) + "_" + stamp + name.substring(dot)
                : name + "_" + stamp;

        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, finalName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Metsur");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);

        ContentResolver cr = getContentResolver();
        Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IllegalStateException("insert null");
        try (OutputStream os = cr.openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("sin salida");
            os.write(bytes);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(uri, done, null, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SAVE_FILE) {
            byte[] bytes = pendingBytes;
            pendingBytes = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && bytes != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (os == null) throw new IllegalStateException("sin salida");
                    os.write(bytes);
                    toast("Archivo guardado");
                } catch (Exception e) {
                    toast("No se pudo guardar el archivo");
                }
            }
        }
    }

    // ------------------------------------------------------------------ utilidades
    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    private static String safeName(String path) {
        String n = path == null ? "" : path;
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash >= 0) n = n.substring(slash + 1);
        n = n.replaceAll("[^A-Za-z0-9._-]", "_");
        return n.isEmpty() ? "archivo" : n;
    }

    private static String mimeFor(String name) {
        String n = name.toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".pdf")) return "application/pdf";
        return "application/octet-stream";
    }

    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toString("UTF-8");
        }
    }

    // ------------------------------------------------------------------ ciclo de vida
    @Override
    public void onBackPressed() {
        // Si hay una ventana emergente de la página abierta, cerrarla; si no, salir.
        webView.evaluateJavascript(
                "(function(){var o=document.getElementById('ov');if(o){o.remove();return 1}return 0})()",
                value -> { if (!"1".equals(value)) finish(); });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
