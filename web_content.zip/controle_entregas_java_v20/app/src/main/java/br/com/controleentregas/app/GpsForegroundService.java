package br.com.controleentregas.app;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class GpsForegroundService extends Service implements LocationListener {
    public static final String ACTION_STOP = "br.com.controleentregas.app.action.STOP_GPS";
    private static final int NOTIFICATION_ID = 321;
    private static final String CHANNEL_ID = "gps_tracking";
    private LocationManager locationManager;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("gps_native", MODE_PRIVATE);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Rastreamento GPS", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mostra quando o aplicativo está registrando seu percurso");
            channel.setShowBadge(false);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLocationUpdates();
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(NOTIFICATION_ID, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startLocationUpdates();
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi = launch == null ? null : PendingIntent.getActivity(this, 322, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setContentTitle("Controle de Entregas").setContentText("Rastreamento GPS ativo — registrando seu percurso")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE).setOnlyAlertOnce(true);
        if (pi != null) b.setContentIntent(pi);
        return b.build();
    }

    private void startLocationUpdates() {
        boolean fine = checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) { stopSelf(); return; }
        try {
            boolean registered = false;
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 3f, this, Looper.getMainLooper()); registered = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000L, 8f, this, Looper.getMainLooper()); registered = true;
            }
            if (!registered) ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, buildNotification());
        } catch (SecurityException | IllegalArgumentException e) {
            stopLocationUpdates();
        }
    }

    @Override public void onLocationChanged(Location location) {
        if (location.getAccuracy() > 40f) return;
        JSONArray points;
        try { points = new JSONArray(prefs.getString("points", "[]")); } catch (Exception e) { points = new JSONArray(); }
        long last = points.length() == 0 ? 0 : points.optJSONObject(points.length()-1).optLong("ts", 0);
        if (location.getTime() <= last) return;
        JSONObject p = new JSONObject();
        try { p.put("lat", location.getLatitude()); p.put("lon", location.getLongitude()); p.put("ts", location.getTime()); p.put("accuracy", (double)location.getAccuracy()); }
        catch (Exception ignored) { return; }
        points.put(p);
        while (points.length() > 20000) points.remove(0);
        prefs.edit().putString("points", points.toString()).apply();
    }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    private void stopLocationUpdates() { try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) { } }
    @Override public void onDestroy() { stopLocationUpdates(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
