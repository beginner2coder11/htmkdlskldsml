package br.com.controleentregas.app

import android.app.Activity
import android.app.AlertDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Environment
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.*

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingBackupPayload: String? = null
    private val saveRequest = 5101
    private val openRequest = 5102
    private val locationRequest = 7301
    private val backgroundLocationRequest = 7302
    private val notificationRequest = 7303
    private var waitingForBackgroundSettings = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(16,20,29))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            setSupportZoom(false)
        }
        webView.addJavascriptInterface(BackupBridge(), "AndroidBackupBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) =
                request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            override fun shouldInterceptRequest(view: WebView?, url: String?) =
                url?.let { assetLoader.shouldInterceptRequest(Uri.parse(it)) }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                styledDialog(message ?: "", false) { result.confirm() }.also { d ->
                    d.setOnCancelListener { result.cancel() }
                    d.show()
                }
                return true
            }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                styledDialog(message ?: "", true, { result.confirm() }, { result.cancel() }).also { d ->
                    d.setOnCancelListener { result.cancel() }
                    d.show()
                }
                return true
            }
            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity).apply {
                    setSingleLine(true); setText(defaultValue ?: "")
                    setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
                    setPadding(28, 22, 28, 22)
                    background = rounded(Color.rgb(28,37,51), 22)
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                }
                val d = AlertDialog.Builder(this@MainActivity)
                    .setTitle("Controle de Entregas").setMessage(message)
                    .setView(input)
                    .setNegativeButton("CANCELAR") { _, _ -> result.cancel() }
                    .setPositiveButton("CONFIRMAR") { _, _ -> result.confirm(input.text.toString()) }
                    .create()
                d.setOnShowListener { styleDialogButtons(d) }
                d.show()
                return true
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun styledDialog(message: String, confirm: Boolean,
                             yes: (() -> Unit)? = null, no: (() -> Unit)? = null): AlertDialog {
        val d = AlertDialog.Builder(this)
            .setTitle("Controle de Entregas")
            .setMessage(message)
            .setPositiveButton(if (confirm) "CONFIRMAR" else "ENTENDI") { _, _ -> yes?.invoke() }
            .apply { if (confirm) setNegativeButton("CANCELAR") { _, _ -> no?.invoke() } }
            .create()
        d.setOnShowListener { styleDialogButtons(d) }
        return d
    }

    private fun styleDialogButtons(d: AlertDialog) {
        d.window?.setBackgroundDrawable(rounded(Color.rgb(26,34,48), 28))
        d.findViewById<TextView>(android.R.id.alertTitle)?.setTextColor(Color.WHITE)
        d.findViewById<TextView>(android.R.id.message)?.setTextColor(Color.rgb(220,226,236))
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            setTextColor(Color.rgb(101,214,162)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(Color.rgb(169,180,197)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun showBackgroundLocationSettingsGuide() {
        val message = "Para permitir que o aplicativo registre o percurso mesmo quando não estiver aberto, abra as permissões de localização e selecione \"Permitir o tempo todo\", se essa opção estiver disponível.\n\nDepois, volte para o Controle de Entregas. O rastreamento será iniciado quando o aplicativo retornar. Se preferir não conceder essa permissão agora, ainda será possível iniciar o serviço enquanto o aplicativo estiver aberto; o Android manterá uma notificação de rastreamento."
        AlertDialog.Builder(this)
            .setTitle("Localização em segundo plano")
            .setMessage(message)
            .setPositiveButton("ABRIR CONFIGURAÇÕES") { _, _ ->
                waitingForBackgroundSettings = true
                try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                    waitingForBackgroundSettings = false
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("CONTINUAR SEM ESSA PERMISSÃO") { _, _ ->
                startGpsServiceIfAllowed()
            }
            .setOnCancelListener { startGpsServiceIfAllowed() }
            .create().also { d ->
                d.setOnShowListener { styleDialogButtons(d) }
                d.show()
            }
    }

    private fun continueLocationSetup() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
            return
        }

        if (Build.VERSION.SDK_INT >= 30 &&
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            showBackgroundLocationSettingsGuide()
            return
        }

        startGpsServiceIfAllowed()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForBackgroundSettings) {
            waitingForBackgroundSettings = false
            // Evita reabrir a orientação em ciclo quando a pessoa retorna sem conceder
            // "Permitir o tempo todo". O serviço ainda pode ser iniciado com a tela do app visível.
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Localização em segundo plano não autorizada · iniciando rastreamento com o app aberto');")
                startGpsServiceIfAllowed()
            } else {
                continueLocationSetup()
            }
        }
    }

    private fun startGpsServiceIfAllowed() {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Permissão de localização não concedida');")
            return
        }
        try {
            val intent = Intent(this, GpsForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Serviço GPS solicitado · aguardando sinal');")
        } catch (e: Exception) {
            val message = (e.message ?: "O Android impediu a inicialização do serviço GPS")
                .replace("\\", "\\").replace("'", "\\'")
            callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Falha ao iniciar GPS: $message');")
        }
    }

    inner class BackupBridge {
        @JavascriptInterface fun playTabSound() {
            runOnUiThread {
                try {
                    val tone = ToneGenerator(AudioManager.STREAM_SYSTEM, 90)
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 70)
                    webView.postDelayed({ try { tone.release() } catch (_: Exception) {} }, 180)
                } catch (_: Exception) {}
            }
        }
        @JavascriptInterface fun requestLocationPermissions() {
            runOnUiThread {
                val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!fine && !coarse) {
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        locationRequest
                    )
                    return@runOnUiThread
                }
                if (Build.VERSION.SDK_INT == 29 &&
                    checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), backgroundLocationRequest)
                    return@runOnUiThread
                }
                continueLocationSetup()
            }
        }
        @JavascriptInterface fun startGpsService() { runOnUiThread { startGpsServiceIfAllowed() } }
        @JavascriptInterface fun clearNativeGpsPoints() {
            getSharedPreferences("gps_native", MODE_PRIVATE).edit().putString("points", "[]").apply()
        }
        @JavascriptInterface fun getNativeGpsPoints(): String {
            return getSharedPreferences("gps_native", MODE_PRIVATE).getString("points", "[]") ?: "[]"
        }
        @JavascriptInterface fun stopGpsService() {
            val i = Intent(this@MainActivity, GpsForegroundService::class.java).setAction(GpsForegroundService.ACTION_STOP)
            startService(i)
        }
        @JavascriptInterface fun saveBackupFile(payload: String, filename: String?) {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        val folder = Environment.DIRECTORY_DOWNLOADS + "/Backup_app_entregador"
                        val safeBase = (filename ?: "backup-controle-entregas").substringBeforeLast(".").replace(Regex("[^a-zA-Z0-9._-]"), "-")
                        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, "$safeBase-$stamp.json")
                            put(MediaStore.Downloads.MIME_TYPE, "application/json")
                            put(MediaStore.Downloads.RELATIVE_PATH, folder)
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: throw IOException("Não foi possível criar o arquivo na pasta Downloads")
                        contentResolver.openOutputStream(uri, "w")?.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                            ?: throw IOException("Não foi possível gravar o backup")
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                        pruneExternalBackups(folder)
                        callJs("window.onNativeBackupExported && window.onNativeBackupExported(${JSONObject.quote("Download/Backup_app_entregador/$safeBase-$stamp.json")});")
                    } else {
                        pendingBackupPayload = payload
                        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType("application/json").putExtra(Intent.EXTRA_TITLE, "backup-controle-entregas.json")
                        startActivityForResult(intent, saveRequest)
                    }
                } catch (e: Exception) {
                    callJs("window.onNativeBackupExportFailed && window.onNativeBackupExportFailed(${JSONObject.quote(e.message ?: "Falha ao exportar")});")
                }
            }
        }
        private fun pruneExternalBackups(relativePath: String) {
            if (Build.VERSION.SDK_INT < 29) return
            val resolver = contentResolver
            val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DATE_ADDED)
            val found = mutableListOf<Pair<Long, Long>>()
            resolver.query(uri, projection, "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?", arrayOf("$relativePath/", "%.json"), "${MediaStore.Downloads.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) found.add(c.getLong(0) to c.getLong(1))
            }
            found.drop(3).forEach { (id, _) -> resolver.delete(uri, "${MediaStore.Downloads._ID}=?", arrayOf(id.toString())) }
        }
        @JavascriptInterface fun saveLocalBackup(payload: String, kind: String, timestamp: String) {
            try {
                val dir = File(filesDir, "backups").apply { mkdirs() }
                File(dir, "backup-${timestamp.replace(Regex("[^0-9]"), "")}.json").writeText(payload)
                dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(3)?.forEach { it.delete() }
            } catch (_: Exception) {}
        }
        @JavascriptInterface fun pickBackupFile() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(i, openRequest)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            locationRequest -> {
                val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (granted) {
                    if (Build.VERSION.SDK_INT == 29 &&
                        checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), backgroundLocationRequest)
                    } else {
                        continueLocationSetup()
                    }
                } else {
                    callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Permissão de localização negada');")
                }
            }
            backgroundLocationRequest -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
                } else {
                    startGpsServiceIfAllowed()
                }
            }
            notificationRequest -> {
                // A permissão de notificações não é requisito para iniciar um FGS,
                // mas no Android 13+ sua concessão permite exibir a notificação na gaveta.
                continueLocationSetup()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode == saveRequest && resultCode == RESULT_OK) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write((pendingBackupPayload ?: "").toByteArray(Charsets.UTF_8)) }
                pendingBackupPayload = null
                callJs("document.getElementById('backupMsg').textContent='Arquivo JSON salvo no local escolhido.';")
            } catch (_: Exception) {}
        } else if (requestCode == openRequest && resultCode == RESULT_OK) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                callJs("receiveBackupFileContents(${JSONObject.quote(text)});")
            } catch (_: Exception) {}
        }
    }
    private fun callJs(script: String) { runOnUiThread { webView.evaluateJavascript(script, null) } }
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
