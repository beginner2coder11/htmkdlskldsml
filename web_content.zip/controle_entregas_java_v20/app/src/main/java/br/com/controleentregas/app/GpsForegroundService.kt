package br.com.controleentregas.app

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder

class GpsForegroundService : Service() {
    private val channel = "gps_tracking"
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Rastreamento GPS", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        notification.setContentTitle("Controle de Entregas")
            .setContentText("Rastreamento de percurso em andamento")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
        startForeground(321, notification.build())
        if (intent?.action == "STOP") {
            stopForeground(true); stopSelf(); return START_NOT_STICKY
        }
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
