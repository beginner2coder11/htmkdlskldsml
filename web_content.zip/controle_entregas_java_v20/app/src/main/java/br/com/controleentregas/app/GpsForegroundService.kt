package br.com.controleentregas.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

class GpsForegroundService : Service(), LocationListener {
    companion object {
        const val ACTION_STOP = "br.com.controleentregas.app.action.STOP_GPS"
        private const val NOTIFICATION_ID = 321
        private const val CHANNEL_ID = "gps_tracking"
    }

    private lateinit var locationManager: LocationManager
    private val prefs by lazy { getSharedPreferences("gps_native", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Rastreamento GPS",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mostra quando o aplicativo está registrando seu percurso"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopLocationUpdates()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        // O serviço precisa se promover imediatamente, antes de iniciar operações demoradas.
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: SecurityException) {
            stopLocationUpdates()
            stopSelf()
            return START_NOT_STICKY
        } catch (_: RuntimeException) {
            stopLocationUpdates()
            stopSelf()
            return START_NOT_STICKY
        }

        startLocationUpdates()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = launchIntent?.let {
            android.app.PendingIntent.getActivity(
                this,
                322,
                it,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) android.app.PendingIntent.FLAG_IMMUTABLE else 0
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Controle de Entregas")
            .setContentText("Rastreamento GPS ativo — registrando seu percurso")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun startLocationUpdates() {
        val fine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            stopSelf()
            return
        }

        try {
            var registered = false
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 3000L, 3f, this, Looper.getMainLooper()
                )
                registered = true
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER, 8000L, 8f, this, Looper.getMainLooper()
                )
                registered = true
            }
            // Se os provedores estiverem temporariamente indisponíveis, o serviço continua ativo
            // e poderá receber atualizações quando o sistema os disponibilizar.
            if (!registered) {
                val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, buildNotification())
            }
        } catch (_: SecurityException) {
            stopLocationUpdates()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        } catch (_: IllegalArgumentException) {
            stopLocationUpdates()
        }
    }

    override fun onLocationChanged(location: Location) {
        if (location.accuracy > 40f) return
        val points = try {
            JSONArray(prefs.getString("points", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val point = JSONObject()
            .put("lat", location.latitude)
            .put("lon", location.longitude)
            .put("ts", location.time)
            .put("accuracy", location.accuracy.toDouble())

        val lastTimestamp = if (points.length() > 0) {
            points.optJSONObject(points.length() - 1)?.optLong("ts", 0L) ?: 0L
        } else 0L

        if (location.time > lastTimestamp) {
            points.put(point)
            while (points.length() > 20000) points.remove(0)
            prefs.edit().putString("points", points.toString()).apply()
        }
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun stopLocationUpdates() {
        try {
            locationManager.removeUpdates(this)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        stopLocationUpdates()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
