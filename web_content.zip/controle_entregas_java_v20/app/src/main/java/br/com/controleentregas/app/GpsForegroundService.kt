package br.com.controleentregas.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

class GpsForegroundService : Service(), LocationListener {
    private val channel = "gps_tracking"
    private lateinit var locationManager: LocationManager
    private val prefs by lazy { getSharedPreferences("gps_native", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Rastreamento GPS", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopLocationUpdates()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        notification.setContentTitle("Controle de Entregas")
            .setContentText("Registrando seu percurso em segundo plano")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
        startForeground(321, notification.build())
        startLocationUpdates()
        return START_STICKY
    }

    private fun startLocationUpdates() {
        val fine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        try {
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 3f, this, Looper.getMainLooper())
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000L, 8f, this, Looper.getMainLooper())
            }
        } catch (_: SecurityException) { }
    }

    override fun onLocationChanged(location: Location) {
        if (location.accuracy > 40f) return
        val points = try { JSONArray(prefs.getString("points", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val point = JSONObject().put("lat", location.latitude).put("lon", location.longitude)
            .put("ts", location.time).put("accuracy", location.accuracy.toDouble())
        if (points.length() == 0 || location.time > (points.optJSONObject(points.length() - 1)?.optLong("ts", 0L) ?: 0L)) {
            points.put(point)
            while (points.length() > 20000) points.remove(0)
            prefs.edit().putString("points", points.toString()).apply()
        }
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
    override fun onProviderEnabled(provider: String) { }
    override fun onProviderDisabled(provider: String) { }

    private fun stopLocationUpdates() {
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
    }

    override fun onDestroy() { stopLocationUpdates(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
