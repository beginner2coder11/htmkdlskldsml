package br.com.controleentregas.app;

import android.app.*;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private String pendingBackupPayload;
    private static final int SAVE_REQUEST=5101, OPEN_REQUEST=5102, LOCATION_REQUEST=7301, BACKGROUND_REQUEST=7302, NOTIFICATION_REQUEST=7303;
    private boolean waitingForBackgroundSettings=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,20,29));
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setSupportZoom(false);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackupBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return assetLoader.shouldInterceptRequest(r.getUrl()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, String u) { return assetLoader.shouldInterceptRequest(Uri.parse(u)); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v,String url,String msg,JsResult result) { new AlertDialog.Builder(MainActivity.this).setTitle("Controle de Entregas").setMessage(msg).setPositiveButton("ENTENDI",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show(); return true; }
            @Override public boolean onJsConfirm(WebView v,String url,String msg,JsResult result) { new AlertDialog.Builder(MainActivity.this).setTitle("Controle de Entregas").setMessage(msg).setPositiveButton("CONFIRMAR",(d,w)->result.confirm()).setNegativeButton("CANCELAR",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show(); return true; }
            @Override public boolean onJsPrompt(WebView v,String url,String msg,String def,JsPromptResult result) {
                EditText input=new EditText(MainActivity.this); input.setSingleLine(true); input.setText(def==null?"":def); input.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
                new AlertDialog.Builder(MainActivity.this).setTitle("Controle de Entregas").setMessage(msg).setView(input).setNegativeButton("CANCELAR",(d,w)->result.cancel()).setPositiveButton("CONFIRMAR",(d,w)->result.confirm(input.getText().toString())).show(); return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void callJs(String js) { runOnUiThread(()->{ if(webView!=null) webView.evaluateJavascript(js,null); }); }
    private void showBackgroundGuide() {
        new AlertDialog.Builder(this).setTitle("Localização em segundo plano")
            .setMessage("Para permitir que o aplicativo registre o percurso mesmo quando não estiver aberto, abra as permissões de localização e selecione ‘Permitir o tempo todo’, se disponível. Depois, volte para o Controle de Entregas.")
            .setPositiveButton("ABRIR CONFIGURAÇÕES",(d,w)->{ waitingForBackgroundSettings=true; startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))); })
            .setNegativeButton("CONTINUAR",(d,w)->startGpsServiceIfAllowed()).setOnCancelListener(d->startGpsServiceIfAllowed()).show();
    }
    private void continueLocationSetup() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST); return; }
        if(Build.VERSION.SDK_INT>=30 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED) { showBackgroundGuide(); return; }
        startGpsServiceIfAllowed();
    }
    @Override protected void onResume() { super.onResume(); if(waitingForBackgroundSettings) { waitingForBackgroundSettings=false; if(Build.VERSION.SDK_INT>=30 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED) { callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Localização em segundo plano não autorizada · rastreamento com o app aberto');"); startGpsServiceIfAllowed(); } else continueLocationSetup(); } }
    private void startGpsServiceIfAllowed() {
        boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        boolean coarse=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if(!fine&&!coarse) { callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Permissão de localização não concedida');"); return; }
        try { Intent i=new Intent(this,GpsForegroundService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Serviço GPS solicitado · aguardando sinal');"); }
        catch(Exception e) { callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Falha ao iniciar GPS: "+JSONObject.quote(e.getMessage()==null?"erro do Android":e.getMessage())+"');"); }
    }

    public class BackupBridge {
        @JavascriptInterface public void playTabSound() { runOnUiThread(()->{ try { ToneGenerator t=new ToneGenerator(AudioManager.STREAM_SYSTEM,90); t.startTone(ToneGenerator.TONE_PROP_BEEP2,70); webView.postDelayed(t::release,180); } catch(Exception ignored){} }); }
        @JavascriptInterface public void requestLocationPermissions() { runOnUiThread(()->{
            boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            boolean coarse=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            if(!fine&&!coarse) { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST); return; }
            if(Build.VERSION.SDK_INT==29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},BACKGROUND_REQUEST); return; }
            continueLocationSetup();
        }); }
        @JavascriptInterface public void startGpsService() { runOnUiThread(()->startGpsServiceIfAllowed()); }
        @JavascriptInterface public void clearNativeGpsPoints() { getSharedPreferences("gps_native",MODE_PRIVATE).edit().putString("points","[]").apply(); }
        @JavascriptInterface public String getNativeGpsPoints() { return getSharedPreferences("gps_native",MODE_PRIVATE).getString("points","[]"); }
        @JavascriptInterface public void stopGpsService() { Intent i=new Intent(MainActivity.this,GpsForegroundService.class).setAction(GpsForegroundService.ACTION_STOP); startService(i); }
        @JavascriptInterface public void saveBackupFile(String payload,String filename) { runOnUiThread(()->saveBackup(payload,filename)); }
        @JavascriptInterface public void saveLocalBackup(String payload,String kind,String timestamp) { try { File dir=new File(getFilesDir(),"backups"); dir.mkdirs(); String stamp=timestamp.replaceAll("[^0-9]",""); try(FileOutputStream out=new FileOutputStream(new File(dir,"backup-"+stamp+".json"))) { out.write(payload.getBytes("UTF-8")); } File[] fs=dir.listFiles(); if(fs!=null){ Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified())); for(int i=3;i<fs.length;i++) fs[i].delete(); } } catch(Exception ignored){} }
        @JavascriptInterface public void pickBackupFile() { runOnUiThread(()->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"); startActivityForResult(i,OPEN_REQUEST); }); }
    }
    private void saveBackup(String payload,String filename) {
        try {
            if(Build.VERSION.SDK_INT>=29) {
                String folder=Environment.DIRECTORY_DOWNLOADS+"/Backup_app_entregador";
                String base=(filename==null?"backup-controle-entregas":filename).replaceFirst("\\.[^.]*$","").replaceAll("[^a-zA-Z0-9._-]","-");
                String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,base+"-"+stamp+".json"); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,folder); v.put(MediaStore.Downloads.IS_PENDING,1);
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(uri==null) throw new IOException("Não foi possível criar o arquivo na pasta Downloads");
                try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){ if(out==null) throw new IOException("Não foi possível gravar o backup"); out.write(payload.getBytes("UTF-8")); }
                ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,done,null,null);
                callJs("window.onNativeBackupExported && window.onNativeBackupExported("+JSONObject.quote("Download/Backup_app_entregador/"+base+"-"+stamp+".json")+");");
            } else { pendingBackupPayload=payload; Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"backup-controle-entregas.json"); startActivityForResult(i,SAVE_REQUEST); }
        } catch(Exception e) { callJs("window.onNativeBackupExportFailed && window.onNativeBackupExportFailed("+JSONObject.quote(e.getMessage()==null?"Falha ao exportar":e.getMessage())+");"); }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==LOCATION_REQUEST) { boolean ok=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED; if(ok) { if(Build.VERSION.SDK_INT==29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},BACKGROUND_REQUEST); else continueLocationSetup(); } else callJs("document.getElementById('gpsStatus') && (document.getElementById('gpsStatus').textContent='Permissão de localização negada');"); }
        else if(requestCode==BACKGROUND_REQUEST || requestCode==NOTIFICATION_REQUEST) continueLocationSetup();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(data==null||data.getData()==null||resultCode!=RESULT_OK)return; Uri uri=data.getData();
        try { if(requestCode==SAVE_REQUEST) { try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){ if(out!=null)out.write((pendingBackupPayload==null?"":pendingBackupPayload).getBytes("UTF-8")); } pendingBackupPayload=null; callJs("document.getElementById('backupMsg').textContent='Arquivo JSON salvo no local escolhido.';"); }
            else if(requestCode==OPEN_REQUEST) { StringBuilder b=new StringBuilder(); try(BufferedReader r=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)))){ String line; while((line=r.readLine())!=null)b.append(line).append('\n'); } callJs("receiveBackupFileContents("+JSONObject.quote(b.toString())+");"); }
        } catch(Exception ignored){}
    }
    @Override public void onBackPressed() { if(webView!=null&&webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(webView!=null)webView.destroy(); super.onDestroy(); }
}
