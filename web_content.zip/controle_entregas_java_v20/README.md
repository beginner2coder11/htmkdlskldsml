# Controle de Entregas — V59 Java (fonte Android)

Esta versão converteu as classes nativas `MainActivity` e `GpsForegroundService` de Kotlin para **Java**. O HTML/CSS/JavaScript original foi mantido dentro de `app/src/main/assets/index.html`.

## Importante sobre o compilador HTML to APK

Este ZIP é um **projeto Android Gradle**, não um APK. Ele contém código Java nativo, Manifest e configuração Gradle. Um conversor que aceite somente HTML/CSS/JavaScript não compilará essas classes Java nem criará o serviço nativo de localização. Para usar os recursos nativos de GPS em segundo plano, o projeto precisa ser compilado como projeto Android Gradle (por exemplo, no Android Studio ou em um ambiente que aceite projetos Gradle completos).

## Alterações desta versão

- Classes nativas convertidas para Java; removida a dependência do plugin Kotlin.
- Serviço de localização em primeiro plano com tipo `location`, notificação persistente e registro de pontos GPS.
- Permissões de localização, localização em segundo plano e notificações mantidas no Manifest e no fluxo da Activity.
- Interface HTML original mantida sem alterações.
- Ponte JavaScript `AndroidBackupBridge` preserva os métodos de GPS e backup usados pela interface.
- `versionCode 21`, `versionName 3.0`.

## Limitação de validação

O projeto foi revisado estruturalmente, mas **não foi compilado nem testado em um aparelho Android** neste ambiente. Portanto, ainda não há APK validado. A concessão de localização em segundo plano e as restrições do Android/Motorola também precisam ser verificadas no aparelho.
