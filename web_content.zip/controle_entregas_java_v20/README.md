# Controle de Entregas V34
Projeto Android reconfigurado para Kotlin. Os arquivos nativos MainActivity e GpsForegroundService estão em Kotlin; interface web (HTML/JS) mantida como origem da interface.
Compilar com Android Studio/Gradle. Não há APK pré-compilado ou verificação de build neste pacote.
