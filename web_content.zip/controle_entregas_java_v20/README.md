# Controle de Entregas V34
Projeto Android reconfigurado para Kotlin. Os arquivos nativos MainActivity e GpsForegroundService estão em Kotlin; interface web (HTML/JS) mantida como origem da interface.
Compilar com Android Studio/Gradle. Não há APK pré-compilado ou verificação de build neste pacote.


Versão 56 (2.7): rastreamento GPS nativo em serviço de primeiro plano, coleta de coordenadas com o app minimizado mediante permissões Android, integração dos pontos ao histórico do mapa e backup JSON completo (incluindo histórico GPS) em Download/Backup_app_entregador, mantendo até três arquivos externos.
