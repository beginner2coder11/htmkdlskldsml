# Controle de Entregas — correção de GPS em segundo plano

Este pacote contém o projeto-fonte atualizado a partir do ZIP confirmado pelo usuário como a base da V57.

## Alterações desta revisão (candidata à V58)

- Serviço de GPS promovido imediatamente a serviço em primeiro plano.
- Tipo `location` informado explicitamente ao Android 10 ou superior.
- Notificação persistente com título e texto claros, canal próprio e atalho para reabrir o app.
- Tratamento de falhas de segurança ao iniciar o serviço, evitando falhas silenciosas.
- Fluxo de permissão de notificações do Android 13 ou superior.
- Fluxo de localização em segundo plano para Android 11 ou superior, sem iniciar o serviço depois de enviar o usuário às Configurações.
- Ao retornar das Configurações, o app inicia o serviço enquanto a Activity está visível, mesmo se o usuário não conceder "Permitir o tempo todo".
- Serviço declarado para continuar quando a tarefa do app é removida.
- Adicionada a dependência AndroidX WebKit utilizada pelo `MainActivity`.
- Número interno atualizado para versionCode 20 / versionName 2.9.

## Importante

Este é o **código-fonte corrigido**, não um APK instalado ou compilado. O ambiente desta sessão não possui Gradle/Android SDK configurado; portanto, não foi possível executar uma compilação Android nem validar o comportamento no Moto G56.

## Como testar no Moto G56 depois de gerar o APK

1. Instale a versão de teste.
2. Abra o app e inicie o rastreamento no Mapa.
3. Conceda localização precisa e notificações quando solicitadas.
4. Na orientação de segundo plano, abra as configurações do app > Permissões > Localização e selecione "Permitir o tempo todo", se a opção estiver disponível.
5. Volte ao app. Deve aparecer a notificação "Rastreamento GPS ativo".
6. Minimize o app e deixe a tela apagada por 5 a 10 minutos.
7. Reabra o app e confira se o trajeto foi acumulado.
8. Pause e finalize para confirmar que o serviço é encerrado.

Se a notificação não aparecer, confira se as notificações do app estão permitidas. Se o GPS parar com a tela apagada, configure a bateria do app para uso irrestrito/sem otimização nas configurações do Motorola, se essa opção estiver disponível.

As funções HTML/JavaScript e a ponte de backup foram preservadas sem alterações.
