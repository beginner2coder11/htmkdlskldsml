import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Noot — Muziekspeler" },
      { name: "description", content: "Noot: een simpele, open source muziekspeler in je browser." },
      { property: "og:title", content: "Noot — Muziekspeler" },
      { property: "og:description", content: "Een simpele, open source muziekspeler in je browser." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/noot.html"
      title="Noot"
      className="fixed inset-0 h-full w-full border-0"
      allow="autoplay; fullscreen"
    />
  );
}
