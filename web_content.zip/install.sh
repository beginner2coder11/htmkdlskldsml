#!/usr/bin/env bash
# =============================================================================
#  Off-Grid Repository installer for Ubuntu (22.04 / 24.04+)
#
#  1. Installs Project NOMAD (offline Wikipedia, maps, AI, Khan Academy, etc.)
#  2. Builds an offline locator database of hospitals, urgent care, pharmacies,
#     grocery stores, food banks, gun shops, armories and military bases within
#     a radius (default 500 mi) of a home point (default ZIP 30115, Canton GA)
#  3. (Optional) Downloads an offline street map for the same region
#  4. Downloads a library of firearm and radio manuals + emergency radio guides,
#     your UV-32 channel plan, and CHIRP (radio programming) for re-flashing radios
#  4b. Installs radio/off-grid desktop software and saves installers for phones/PCs
#  5. Serves the locator and library at http://<this-machine>:8090 as a systemd service
#
#  Usage:
#     sudo bash install.sh                 # everything
#     sudo bash install.sh --no-nomad      # skip Project NOMAD
#     sudo bash install.sh --no-map        # skip the street-map download
#     sudo bash install.sh --no-zim        # skip the iFixit repair-guide archive
#     sudo bash install.sh --no-chirp      # skip CHIRP radio-programming software
#     sudo bash install.sh --no-software   # skip ham/off-grid desktop apps and saved installers
#     sudo bash install.sh --ai-sync       # only (re)load everything into NOMAD's AI Knowledge Base
#     sudo bash install.sh --no-ai-sync    # don't touch NOMAD's Knowledge Base
#     sudo bash install.sh --data-only     # just refresh the locator data
#     sudo bash install.sh --library-only  # just fetch new manuals / re-index the library
#     sudo bash install.sh --lat 34.24 --lon -84.45 --label "Home" --radius 300
#     sudo bash install.sh --maxzoom 15    # sharper map (much larger download)
#
#  Run it while you still have internet. Re-run any time to refresh the data;
#  downloads resume where they stopped.
# =============================================================================
set -euo pipefail

# ---- defaults ---------------------------------------------------------------
LAT="34.2387"; LON="-84.4513"; LABEL="ZIP 30115 (Canton, GA)"; RADIUS=500
BASE="/opt/offgrid"; PORT=8090; ZIM_PORT=8091; MAXZOOM=14
DO_NOMAD=1; DO_MAP=1; DO_ZIM=1; DO_CHIRP=1; DO_SOFT=1; DO_AI=1; AI_ONLY=0; NOMAD_URL="http://127.0.0.1:8080"; DATA_ONLY=0; LIBRARY_ONLY=0
# Extra offline archives from download.kiwix.org (folder/name-prefix). Missing ones are skipped.
ZIMS=(ifixit/ifixit_en_all                 # repair guides: cars, trucks, tools, generators
      other/zimgit-medicine_en             # curated medical PDF library
      other/zimgit-water_en                # water sourcing & treatment library
      other/zimgit-food-preparation_en     # food prep & preservation library
      other/zimgit-post-disaster_en        # post-disaster resource library
      other/wikem_en_all_maxi              # emergency medicine reference
      other/mdwiki_en_all_maxi             # WikiProject Medicine articles
      zimit/fas-military-medicine_en       # military medicine manuals
      other/appropedia_en_all_maxi         # appropriate tech: off-grid power, water, building
      stack_exchange/diy.stackexchange.com_en_all          # home repair Q&A
      stack_exchange/mechanics.stackexchange.com_en_all    # vehicle repair Q&A
      stack_exchange/gardening.stackexchange.com_en_all    # gardening Q&A
      stack_exchange/outdoors.stackexchange.com_en_all     # outdoors & survival Q&A
      stack_exchange/ham.stackexchange.com_en_all          # amateur radio Q&A
      stack_exchange/sustainability.stackexchange.com_en_all
      stack_exchange/cooking.stackexchange.com_en_all)
# Very large, add manually if you have room: gutenberg/gutenberg_en_all (Project Gutenberg books, ~100+ GB)

# States that touch a 500-mile circle around Canton, GA. Edit if you change the center.
STATES=(georgia alabama tennessee south-carolina north-carolina florida mississippi
        kentucky virginia west-virginia louisiana arkansas missouri illinois indiana
        ohio pennsylvania maryland)

while [[ $# -gt 0 ]]; do
  case "$1" in
    --lat) LAT="$2"; shift 2;;
    --lon) LON="$2"; shift 2;;
    --label) LABEL="$2"; shift 2;;
    --radius) RADIUS="$2"; shift 2;;
    --port) PORT="$2"; shift 2;;
    --maxzoom) MAXZOOM="$2"; shift 2;;
    --dir) BASE="$2"; shift 2;;
    --no-nomad) DO_NOMAD=0; shift;;
    --no-map) DO_MAP=0; shift;;
    --no-zim) DO_ZIM=0; shift;;
    --no-chirp) DO_CHIRP=0; shift;;
    --no-software) DO_SOFT=0; shift;;
    --no-ai-sync) DO_AI=0; shift;;
    --ai-sync) AI_ONLY=1; shift;;
    --nomad-url) NOMAD_URL="$2"; shift 2;;
    --data-only) DATA_ONLY=1; DO_NOMAD=0; shift;;
    --library-only) LIBRARY_ONLY=1; DO_NOMAD=0; DATA_ONLY=1; shift;;
    -h|--help) sed -n '2,32p' "$0"; exit 0;;
    *) echo "Unknown option: $1"; exit 1;;
  esac
done

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RAW="$BASE/osm/raw"; FILT="$BASE/osm/filtered"; WWW="$BASE/www"; VENV="$BASE/venv"
GEOFABRIK="https://download.geofabrik.de/north-america/us"

say()  { printf '\n\033[1;33m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;31m!! %s\033[0m\n' "$*"; }

port_busy() { ss -ltnH "sport = :$1" 2>/dev/null | grep -q .; }
free_port() { local p=$1; while port_busy "$p"; do p=$((p+1)); done; echo "$p"; }

[[ $EUID -eq 0 ]] || { echo "Please run with sudo:  sudo bash $0"; exit 1; }

# Load the repository into Project NOMAD's AI Knowledge Base (guides, buy list, radio plans,
# nearest-places lists from the locator, manuals). Safe to re-run: unchanged files are skipped.
ai_sync() {
  [[ $DO_AI -eq 1 ]] || return 0
  if curl -fsS -m 5 "$NOMAD_URL/api/health" >/dev/null 2>&1 || curl -fsS -m 5 "$NOMAD_URL/" >/dev/null 2>&1; then
    say "Loading the off-grid repository into NOMAD's AI Knowledge Base"
    python3 "$BASE/scripts/nomad_sync.py" --base "$BASE" --nomad "$NOMAD_URL" --label "$LABEL" \
      || warn "AI sync had problems — files are in $BASE/nomad_kb for manual upload."
  else
    echo "  (NOMAD not reachable at $NOMAD_URL — skipping AI sync. Later: sudo offgrid-ai-sync)"
  fi
}
if [[ $AI_ONLY -eq 1 ]]; then
  cp "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/scripts/nomad_sync.py" "$BASE/scripts/" 2>/dev/null || true
  ai_sync; exit 0
fi
grep -qiE 'ubuntu|debian' /etc/os-release || warn "This script targets Ubuntu/Debian; continuing anyway."

# ---- 1. packages -----------------------------------------------------------
if [[ $DATA_ONLY -eq 0 ]]; then
  say "Installing system packages"
  apt-get update
  apt-get install -y curl ca-certificates jq osmium-tool python3 python3-venv python3-pip tar iproute2 poppler-utils rsync
  apt-get install -y kiwix-tools || warn "kiwix-tools not available from apt — the iFixit archive step will be skipped."
fi

# ---- 2. Project NOMAD -------------------------------------------------------
if [[ $DO_NOMAD -eq 1 ]]; then
  say "Installing Project NOMAD (official installer)"
  curl -fsSL https://raw.githubusercontent.com/Crosstalk-Solutions/project-nomad/refs/heads/main/install/install_nomad.sh \
    -o /tmp/install_nomad.sh
  bash /tmp/install_nomad.sh || warn "NOMAD installer reported an error — the locator will still be installed."
  echo "After this finishes, open the NOMAD command center and pick the content packs"
  echo "(Wikipedia, medical, maps, Khan Academy, AI models) you want downloaded."
fi

# ---- 3. Python environment --------------------------------------------------
mkdir -p "$RAW" "$FILT" "$WWW/data" "$WWW/vendor" "$WWW/map" "$BASE/scripts"
cp "$HERE"/scripts/*.py "$HERE"/scripts/*.sh "$BASE/scripts/"
cp "$HERE"/www/index.html "$WWW/index.html"
mkdir -p "$WWW/library" "$BASE/library"
cp "$HERE"/library/manuals.tsv "$HERE"/library/software.tsv "$BASE/library/"
for d in "$HERE"/library/*/; do mkdir -p "$WWW/library/$(basename "$d")"; cp -r "$d"* "$WWW/library/$(basename "$d")/"; done
if [[ ! -x "$VENV/bin/python" ]]; then
  say "Creating Python environment"
  python3 -m venv "$VENV"
fi
"$VENV/bin/pip" install --quiet --upgrade pip osmium

# Rebuild printable channel plans from any radio channel CSVs in the library
for csvf in "$WWW"/library/*/*Channels_Reference*.csv; do
  [[ -f "$csvf" ]] || continue
  out="${csvf%_Useful_Channels_Reference.csv}_Channel_Plan.html"
  [[ "$out" == "$csvf" ]] && out="${csvf%.csv}_Plan.html"
  python3 "$BASE/scripts/build_channels.py" --csv "$csvf" --out "$out" || warn "Channel plan build failed for $csvf"
done

# ---- 3a. CHIRP radio programming software -----------------------------------
# Lets you re-flash the UV-32 (or any CHIRP-supported radio) from the saved .img file.
# A copy of the installer wheel is kept in the Library (Software) so other machines can grab it offline.
if [[ $DO_CHIRP -eq 1 && $DATA_ONLY -eq 0 ]]; then
  say "Installing CHIRP (radio programming)"
  mkdir -p "$WWW/library/Software"
  if apt-get install -y python3-wxgtk4.0 pipx; then
    CH="https://archive.chirpmyradio.com/chirp_next"
    rel=$(curl -fsSL "$CH/" | grep -oE 'next-[0-9]{8}' | sort -u | tail -1 || true)
    whl=""; [[ -n "$rel" ]] && whl=$(curl -fsSL "$CH/$rel/" | grep -oE 'chirp-[0-9]{8}-py3-none-any\.whl' | head -1 || true)
    if [[ -n "$whl" && ! -s "$WWW/library/Software/$whl" ]]; then
      curl -fL --retry 3 "$CH/$rel/$whl" -o "$WWW/library/Software/$whl.part" && mv "$WWW/library/Software/$whl.part" "$WWW/library/Software/$whl"
    fi
    [[ -z "$whl" ]] && whl=$(ls -1 "$WWW/library/Software"/chirp-*.whl 2>/dev/null | tail -1 | xargs -r basename)
    if [[ -n "$whl" && -s "$WWW/library/Software/$whl" ]]; then
      PIPX_HOME=/opt/pipx PIPX_BIN_DIR=/usr/local/bin pipx install --force --system-site-packages "$WWW/library/Software/$whl" \
        && echo "CHIRP installed: run 'chirp' from a desktop session." || warn "CHIRP install failed (wheel is saved in the Library)."
      [[ -n "${SUDO_USER:-}" ]] && usermod -aG dialout "$SUDO_USER" && echo "Added $SUDO_USER to 'dialout' (USB programming cable access; log out/in)."
    else
      warn "Could not download CHIRP — get it later from chirpmyradio.com."
    fi
  else
    warn "python3-wxgtk4.0/pipx not available — skipping CHIRP."
  fi
fi

# ---- 3c. Off-grid & radio software -------------------------------------------
# Desktop apps for ham/digital radio, SDR, maps, documents, passwords, inventory.
# Every .deb downloaded is also kept in $BASE/software/debs for reinstalling with no internet.
RADIO_PKGS=(direwolf xastir fldigi flrig flmsg flamp js8call wsjtx gqrx-sdr rtl-sdr gpredict
            libhamlib-utils qsstv qdmr dmrconfig multimon-ng
            sdrangel cubicsdr rtl-433 dump1090-mutability soapysdr-tools soapysdr-module-rtlsdr
            hackrf airspy inspectrum sox build-essential cmake pkg-config libusb-1.0-0-dev default-jre)
OFFGRID_PKGS=(kiwix libreoffice calibre keepassxc vlc gnucash syncthing gpsd gpsd-clients foxtrotgps
              stellarium marble anki p7zip-full unzip mumble-server wine)
if [[ $DO_SOFT -eq 1 && $DATA_ONLY -eq 0 ]]; then
  say "Installing off-grid & radio software (${#RADIO_PKGS[@]} radio + ${#OFFGRID_PKGS[@]} general apps)"
  export DEBIAN_FRONTEND=noninteractive
  for p in "${RADIO_PKGS[@]}" "${OFFGRID_PKGS[@]}"; do
    apt-get install -y -o APT::Keep-Downloaded-Packages=true "$p" >/dev/null 2>&1 \
      && echo "  ✓ $p" || echo "  - $p (not available on this Ubuntu release, skipped)"
  done
  # SDR: keep the TV driver off RTL-SDR dongles; install the signal-search tool
  echo -e "blacklist dvb_usb_rtl28xxu\nblacklist rtl2832\nblacklist rtl2830" > /etc/modprobe.d/blacklist-rtlsdr.conf
  install -m 755 "$HERE/scripts/offgrid_scan.py" /usr/local/bin/offgrid-scan
  mkdir -p "$BASE/software/debs"
  cp -n /var/cache/apt/archives/*.deb "$BASE/software/debs/" 2>/dev/null || true
  [[ -n "${SUDO_USER:-}" ]] && usermod -aG dialout,plugdev "$SUDO_USER" 2>/dev/null || true
  "$VENV/bin/pip" install --quiet meshtastic && ln -sf "$VENV/bin/meshtastic" /usr/local/bin/meshtastic \
    || warn "meshtastic CLI not installed"
  # Grocy: pantry / food-storage inventory with expiry dates (web app, needs Docker from NOMAD)
  if command -v docker >/dev/null 2>&1; then
    if ! docker ps -a --format '{{.Names}}' | grep -qx grocy; then
      GROCY_PORT=$(free_port 9283)
      mkdir -p "$BASE/grocy"
      docker run -d --name grocy --restart unless-stopped -p "$GROCY_PORT:80" \
        -e TZ=America/New_York -v "$BASE/grocy:/config" lscr.io/linuxserver/grocy:latest >/dev/null \
        && echo "  ✓ Grocy food-storage inventory at http://localhost:$GROCY_PORT (login admin / admin — change it)" \
        || warn "Grocy container failed to start"
    fi
  else
    warn "Docker not found — skipping Grocy (install NOMAD first, then re-run)."
  fi
fi
if [[ $DO_SOFT -eq 1 && ( $DATA_ONLY -eq 0 || $LIBRARY_ONLY -eq 1 ) ]]; then
  say "Saving installers for phones and other computers (Library → Software)"
  bash "$BASE/scripts/fetch_software.sh" "$BASE/library/software.tsv" "$WWW/library/Software" "$BASE/library/software_titles.tsv"
fi
if [[ $DO_SOFT -eq 1 && $DATA_ONLY -eq 0 ]]; then
  SW="$WWW/library/Software"
  # SDR++ from the saved .deb (not in Ubuntu's archive)
  if ! command -v sdrpp >/dev/null 2>&1; then
    . /etc/os-release; code="${VERSION_CODENAME:-noble}"
    deb=$(ls -1 "$SW"/*sdrpp*"$code"*.deb "$SW"/*"$code"*sdrpp*.deb 2>/dev/null | head -1)
    [[ -n "$deb" ]] && apt-get install -y "$deb" >/dev/null 2>&1 && echo "  ✓ SDR++ (sdrpp)" || echo "  - SDR++ not installed (no matching .deb)"
  fi
  # SatDump from the saved .deb
  if ! command -v satdump >/dev/null 2>&1; then
    deb=$(ls -1 "$SW"/*atdump*amd64.deb 2>/dev/null | head -1)
    [[ -n "$deb" ]] && apt-get install -y "$deb" >/dev/null 2>&1 && echo "  ✓ SatDump" || echo "  - SatDump not installed"
  fi
  # SDRTrunk: unzip to /opt/sdrtrunk and link the launcher
  z=$(ls -1 "$SW"/*sdr-trunk*linux*.zip "$SW"/*sdrtrunk*linux*.zip 2>/dev/null | head -1)
  if [[ -n "$z" && ! -d /opt/sdrtrunk ]]; then
    mkdir -p /opt/sdrtrunk && unzip -q "$z" -d /opt/sdrtrunk \
      && ln -sf "$(find /opt/sdrtrunk -path '*/bin/sdr-trunk' | head -1)" /usr/local/bin/sdr-trunk && echo "  ✓ SDRTrunk (sdr-trunk)"
  fi
  # RTL-SDR Blog V4 needs the updated driver; build it from the saved source
  t=$(ls -1 "$SW"/master.tar.gz "$SW"/*rtl-sdr-blog*.tar.gz 2>/dev/null | head -1)
  if [[ -n "$t" && ! -f /usr/local/lib/librtlsdr.so ]] && command -v cmake >/dev/null 2>&1; then
    say "Building RTL-SDR Blog driver (supports V3 and V4 dongles)"
    rm -rf /tmp/rtlblog && mkdir -p /tmp/rtlblog && tar -xzf "$t" -C /tmp/rtlblog --strip-components=1 \
      && ( cd /tmp/rtlblog && mkdir -p build && cd build && cmake .. -DINSTALL_UDEV_RULES=ON >/dev/null \
           && make -j"$(nproc)" >/dev/null && make install >/dev/null && ldconfig ) \
      && echo "  ✓ rtl-sdr-blog driver" || warn "rtl-sdr-blog build failed (stock rtl-sdr still works for V3 dongles)"
  fi
fi

# ---- 3b. Manuals library -----------------------------------------------------
say "Downloading manuals library (firearms, radios, emergency radio guides)"
bash "$BASE/scripts/fetch_library.sh" "$BASE/library/manuals.tsv" "$WWW/library" "$VENV/bin/python"
if [[ $LIBRARY_ONLY -eq 1 ]]; then chmod -R a+rX "$WWW"; ai_sync; say "Library updated: http://localhost:$PORT/library/"; exit 0; fi

# ---- 4. Download OpenStreetMap data per state ------------------------------
say "Downloading OpenStreetMap data for ${#STATES[@]} states (~6–8 GB, resumable)"
for s in "${STATES[@]}"; do
  f="$RAW/$s-latest.osm.pbf"; part="$f.part"; url="$GEOFABRIK/$s-latest.osm.pbf"
  if [[ -f "$f" && -z $(find "$f" -mtime +7) ]]; then echo "  - $s (up to date)"; continue; fi
  echo "  - $s"
  ok=0
  for _ in 1 2; do
    curl -fL --retry 5 --retry-delay 10 -C - -o "$part" "$url" || { rm -f "$part"; continue; }
    want=$(curl -fsSL "$url.md5" | cut -d' ' -f1 || true)
    if [[ -z "$want" || "$want" == "$(md5sum "$part" | cut -d' ' -f1)" ]]; then ok=1; break; fi
    warn "Checksum mismatch for $s (stale partial download?) — starting over"; rm -f "$part"
  done
  if [[ $ok -eq 1 ]]; then mv "$part" "$f"; else warn "Download failed for $s — keeping any older copy"; fi
done

# ---- 5. Filter to the categories we care about ------------------------------
say "Filtering for hospitals, urgent care, pharmacies, groceries, food banks, gun shops, armories, military"
for s in "${STATES[@]}"; do
  in="$RAW/$s-latest.osm.pbf"; out="$FILT/$s.osm.pbf"
  [[ -f "$in" ]] || continue
  osmium tags-filter "$in" \
    nwr/amenity=hospital,clinic,doctors,pharmacy,food_bank,soup_kitchen,food_sharing,social_facility \
    nwr/healthcare=hospital,clinic,doctor,centre,urgent_care,pharmacy \
    nwr/shop=supermarket,grocery,greengrocer,wholesale,food,weapons,guns,hunting \
    nwr/social_facility=food_bank,soup_kitchen \
    nwr/military nwr/landuse=military nwr/building=military nwr/office=military,newspaper,radio,television \
    nwr/amenity=police,fire_station,studio nwr/emergency=ambulance_station \
    nwr/man_made=mast,tower,communications_tower nwr/communication:amateur_radio \
    nwr/communication:amateur_radio:repeater nwr/studio \
    nwr/amenity=fuel,community_centre,refugee_site,shelter nwr/shop=gas,fuel,hardware,doityourself,farm,agrarian,trade,garden_centre \
    nwr/social_facility=shelter nwr/emergency=assembly_point \
    nwr/amenity=drinking_water,water_point nwr/natural=spring nwr/man_made=water_well \
    nwr/shop=outdoor,sports,fishing,camping,car_parts,tyres,department_store,variety_store,general,discount nwr/amenity=veterinary \
    nwr/power=plant nwr/shop=caravan,boat,golf nwr/leisure=marina,golf_course \
    -o "$out" --overwrite --progress
done

# ---- 5b. FCC broadcast transmitters (AM / FM / TV, public FCC data) -----------
say "Fetching FCC licensed AM/FM/TV stations for the region"
mkdir -p "$BASE/fcc" "$BASE/repeaters"
declare -A ABBR=([georgia]=GA [alabama]=AL [tennessee]=TN [south-carolina]=SC [north-carolina]=NC [florida]=FL
  [mississippi]=MS [kentucky]=KY [virginia]=VA [west-virginia]=WV [louisiana]=LA [arkansas]=AR [missouri]=MO
  [illinois]=IL [indiana]=IN [ohio]=OH [pennsylvania]=PA [maryland]=MD)
for s in "${STATES[@]}"; do
  st="${ABBR[$s]:-}"; [[ -z "$st" ]] && continue
  for q in am fm tv; do
    out="$BASE/fcc/${q}_${st}.txt"
    [[ -s "$out" && -z $(find "$out" -mtime +30) ]] && continue
    curl -fsSL --retry 3 -m 180 -A "Mozilla/5.0 offgrid-locator" \
      "https://transition.fcc.gov/fcc-bin/${q}q?state=${st}&list=4&size=9" -o "$out.part" \
      && mv "$out.part" "$out" || { rm -f "$out.part"; warn "FCC ${q^^} list for $st failed"; }
  done
done
if ! compgen -G "$BASE/repeaters/*.csv" >/dev/null; then
  echo "  Tip: put repeater CSV exports (e.g. from your RepeaterBook account) in $BASE/repeaters/ and re-run --data-only"
fi

# ---- 6. Build the locator database -----------------------------------------
say "Building locator database (${RADIUS} mi around ${LABEL})"
"$VENV/bin/python" "$BASE/scripts/build_pois.py" --in-dir "$FILT" --out-dir "$WWW/data" \
  --lat "$LAT" --lon "$LON" --radius "$RADIUS" --label "$LABEL" \
  --fcc-dir "$BASE/fcc" --repeater-dir "$BASE/repeaters"

# ---- 7. Map libraries (vendored so the page works offline) -----------------
if [[ ! -f "$WWW/vendor/protomaps-leaflet.js" ]]; then
  say "Fetching map libraries"
  tmp=$(mktemp -d)
  curl -fsSL https://registry.npmjs.org/leaflet/-/leaflet-1.9.4.tgz | tar -xz -C "$tmp"
  cp "$tmp/package/dist/leaflet.js" "$tmp/package/dist/leaflet.css" "$WWW/vendor/"
  cp -r "$tmp/package/dist/images" "$WWW/vendor/"
  rm -rf "$tmp"; tmp=$(mktemp -d)
  curl -fsSL https://registry.npmjs.org/protomaps-leaflet/-/protomaps-leaflet-5.1.0.tgz | tar -xz -C "$tmp"
  cp "$tmp/package/dist/protomaps-leaflet.js" "$WWW/vendor/"
  rm -rf "$tmp"
fi

# ---- 8. Offline street map for the region ----------------------------------
if [[ $DO_MAP -eq 1 && ! -f "$WWW/map/region.pmtiles" ]]; then
  say "Downloading offline street map (zoom 0–$MAXZOOM). This is the big one: roughly 5–15 GB."
  if ! command -v pmtiles >/dev/null; then
    arch=$(uname -m); [[ $arch == aarch64 ]] && arch=arm64
    url=$(curl -fsSL https://api.github.com/repos/protomaps/go-pmtiles/releases/latest |
          jq -r --arg a "Linux_${arch}" '.assets[] | select(.name|test($a)) | .browser_download_url' | head -1)
    curl -fsSL "$url" | tar -xz -C /usr/local/bin pmtiles
  fi
  # newest available planet build (builds are published daily and kept for a while)
  src=""
  for i in $(seq 0 21); do
    d=$(date -u -d "-$i day" +%Y%m%d)
    if curl -fsI "https://build.protomaps.com/$d.pmtiles" >/dev/null 2>&1; then
      src="https://build.protomaps.com/$d.pmtiles"; break
    fi
  done
  if [[ -z "$src" ]]; then
    warn "Couldn't find a Protomaps planet build — skipping map (the list still works)."
  else
    # bounding box of the radius circle
    read -r W S E N < <(python3 -c "
import math; lat,lon,r=$LAT,$LON,$RADIUS
dl=r/69.0; dn=r/(69.17*math.cos(math.radians(lat)))
print(f'{lon-dn:.4f} {lat-dl:.4f} {lon+dn:.4f} {lat+dl:.4f}')")
    pmtiles extract "$src" "$WWW/map/region.pmtiles.part" --bbox="$W,$S,$E,$N" --maxzoom="$MAXZOOM" \
      && mv "$WWW/map/region.pmtiles.part" "$WWW/map/region.pmtiles" \
      || warn "Map extract failed — re-run the script to try again."
  fi
fi

# ---- 8b. Offline repair guides (iFixit via Kiwix) ----------------------------
if [[ $DO_ZIM -eq 1 ]] && command -v kiwix-serve >/dev/null; then
  mkdir -p "$BASE/zim"
  for z in "${ZIMS[@]}"; do
    dir="${z%%/*}"; prefix="${z##*/}"
    name=$(curl -fsSL "https://download.kiwix.org/zim/$dir/" | grep -oE "${prefix}_[0-9]{4}-[0-9]{2}\.zim" | sort -u | tail -1)
    if [[ -z "$name" ]]; then warn "Couldn't find $prefix on download.kiwix.org — skipping"; continue; fi
    if [[ -f "$BASE/zim/$name" ]]; then echo "  - $name (already have)"; continue; fi
    say "Downloading $name (several GB, resumable)"
    curl -fL --retry 5 -C - -o "$BASE/zim/$name.part" "https://download.kiwix.org/zim/$dir/$name" \
      && mv "$BASE/zim/$name.part" "$BASE/zim/$name" \
      && find "$BASE/zim" -name "${prefix}_*.zim" ! -name "$name" -delete \
      || warn "Download of $name failed — re-run to resume."
  done
fi

# ---- 9. Service -------------------------------------------------------------
if [[ $DATA_ONLY -eq 0 ]]; then
  systemctl stop offgrid-locator.service offgrid-kiwix.service 2>/dev/null || true
  PORT=$(free_port "$PORT"); ZIM_PORT=$(free_port "$ZIM_PORT")
  [[ "$ZIM_PORT" == "$PORT" ]] && ZIM_PORT=$(free_port $((PORT+1)))
  say "Installing offgrid-locator service on port $PORT"
  cat > /etc/systemd/system/offgrid-locator.service <<EOF
[Unit]
Description=Off-Grid Locator (offline places database)
After=network.target

[Service]
ExecStart=$VENV/bin/python $BASE/scripts/serve.py --dir $WWW --port $PORT
Restart=always
User=nobody
Group=nogroup

[Install]
WantedBy=multi-user.target
EOF
  if command -v kiwix-serve >/dev/null && compgen -G "$BASE/zim/*.zim" >/dev/null; then
    cat > /etc/systemd/system/offgrid-kiwix.service <<EOF
[Unit]
Description=Off-Grid repair guides (Kiwix)
After=network.target

[Service]
ExecStart=/bin/bash -c 'exec kiwix-serve --port $ZIM_PORT $BASE/zim/*.zim'
Restart=always
User=nobody
Group=nogroup

[Install]
WantedBy=multi-user.target
EOF
    echo "window.OFFGRID={zimPort:$ZIM_PORT,nomadUrl:\"${NOMAD_URL##*:}\"};" > "$WWW/config.js"
  else
    echo "window.OFFGRID={nomadUrl:\"${NOMAD_URL##*:}\"};" > "$WWW/config.js"
  fi
  systemctl daemon-reload
  systemctl enable --now offgrid-locator.service
  systemctl restart offgrid-locator.service
  if [[ -f /etc/systemd/system/offgrid-kiwix.service ]]; then
    systemctl enable --now offgrid-kiwix.service; systemctl restart offgrid-kiwix.service
  fi
fi
chmod -R a+rX "$WWW"
printf '#!/bin/sh\nexec sudo python3 %s/scripts/nomad_sync.py --base %s --nomad %s --label "%s" "$@"\n' "$BASE" "$BASE" "$NOMAD_URL" "$LABEL" > /usr/local/bin/offgrid-ai-sync
chmod 755 /usr/local/bin/offgrid-ai-sync
install -m 755 "$HERE/scripts/offgrid_backup.sh" /usr/local/bin/offgrid-backup
ai_sync

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
say "Done."
echo "  Locator:   http://localhost:$PORT   (other devices on your network: http://${IP:-<this-ip>}:$PORT)"
echo "  Library:   http://localhost:$PORT/library/   (add PDFs to $WWW/library/<Category>/ then run --library-only)"
[[ -f /etc/systemd/system/offgrid-kiwix.service ]] && echo "  Repairs:   http://localhost:$ZIM_PORT   (iFixit: cars, trucks, tools, electronics)"
echo "  Files:     $WWW/data/pois.csv  and  pois.geojson  (open in a spreadsheet or QGIS)"
echo "  Offline:   open $WWW/index.html directly in a browser if the service isn't running"
echo "  NOMAD/AI:  http://${IP:-localhost}:${NOMAD_URL##*:}  (AI Chat answers from this repository; refresh with: sudo offgrid-ai-sync)"
echo "  Refresh:   sudo bash $HERE/install.sh --data-only"
echo "  Backup:    sudo offgrid-backup /media/${SUDO_USER:-you}/<drive>   (keep the drive in a Faraday can)"
