# بناء APK بسرعة

## Android Studio
افتح المشروع ثم:
`Build` → `Generate App Bundles or APKs` → `Generate APKs`.

الملف الناتج يكون عادة داخل:
`app/build/outputs/apk/debug/app-debug.apk`

للنسخة النهائية الموقعة استخدم:
`Build` → `Generate Signed App Bundle / APK` → `APK`.
