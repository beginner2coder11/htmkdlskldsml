package com.suryakant.appbuilder;

/*
 * सूर्या ऐप बिल्डर
 * Developer: SURYAKANT BHARTI
 * Made with Surya App Builder (Developer: SURYAKANT BHARTI)
 */

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
//BUILDER_START
import androidx.core.content.FileProvider;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
//BUILDER_END

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final int REQ_STORAGE = 102;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String startUrl;
    private String keepHost = "";

    private static final String OFFLINE_HTML =
            "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
            + "<body style='font-family:sans-serif;text-align:center;padding:70px 24px;color:#555'>"
            + "<div style='font-size:60px'>📶</div><h2>इंटरनेट नहीं है</h2>"
            + "<p>कृपया इंटरनेट चालू करें और फिर से कोशिश करें।</p>"
            + "<button onclick='AppBridge.reload()' style='padding:12px 24px;font-size:17px;border:0;border-radius:10px;background:#1976d2;color:#fff'>फिर से कोशिश करें</button>"
            + "</body></html>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getBoolean(R.bool.fullscreen)) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        startUrl = getString(R.string.start_url);
        if (startUrl.startsWith("http")) {
            Uri su = Uri.parse(startUrl);
            keepHost = su.getHost() == null ? "" : su.getHost().replaceFirst("^www\\.", "");
        }

        web = new WebView(this);
        setContentView(web);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && startUrl.startsWith("http")) {
                    view.loadDataWithBaseURL(null, OFFLINE_HTML, "text/html", "UTF-8", null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                if (url.startsWith("data:") || url.startsWith("blob:")) {
                    toast("इस फ़ाइल को सेव करने के लिए ऐप का सेव बटन इस्तेमाल करें");
                    return;
                }
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                dm.enqueue(req);
                toast("डाउनलोड शुरू: " + name);
            } catch (Exception e) {
                openExternal(Uri.parse(url));
            }
        });

        web.addJavascriptInterface(new Bridge(), "AppBridge");
        web.loadUrl(startUrl);
    }

    private boolean handleUrl(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        if (sc.equals("file") || sc.equals("about") || sc.equals("data") || sc.equals("javascript") || sc.equals("blob")) return false;
        if (sc.equals("http") || sc.equals("https")) {
            String h = u.getHost() == null ? "" : u.getHost().replaceFirst("^www\\.", "");
            if (keepHost.length() > 0 && (h.equals(keepHost) || h.endsWith("." + keepHost))) return false;
            openExternal(u);
            return true;
        }
        openExternal(u);
        return true;
    }

    private void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("यह लिंक नहीं खुल सका");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
            return;
        }
        web.evaluateJavascript("(window.appBack ? window.appBack() : 'exit')", value -> {
            if (value == null || value.contains("exit")) finish();
        });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void saveBytes(byte[] bytes, String name, String mime) throws IOException {
        boolean isImage = mime != null && mime.startsWith("image/");
        String folder = getString(R.string.folder_name);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    (isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/" + folder);
            Uri collection = isImage ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri uri = getContentResolver().insert(collection, v);
            if (uri == null) throw new IOException("insert failed");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException("no stream");
                os.write(bytes);
            }
        } else {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
                throw new IOException("permission");
            }
            File base = Environment.getExternalStoragePublicDirectory(isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(base, folder);
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(bytes);
            }
        }
    }

    //BUILDER_START
    private File fetchToFile(String url, String token, String name) throws IOException {
        String cur = url;
        boolean auth = true;
        for (int i = 0; i < 8; i++) {
            URL u = new URL(cur);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(30000);
            c.setReadTimeout(60000);
            c.setRequestProperty("Accept", "application/octet-stream");
            c.setRequestProperty("User-Agent", "SuryaAppBuilder");
            if (auth && token != null && token.length() > 0) c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect without location");
                URL next = new URL(u, loc);
                if (!next.getHost().equals(u.getHost())) auth = false;
                cur = next.toString();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new IOException("HTTP " + code);
            }
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir != null && !dir.exists()) dir.mkdirs();
            File f = new File(dir, name);
            try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            c.disconnect();
            return f;
        }
        throw new IOException("too many redirects");
    }

    private byte[] readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private void installApk(final File f) {
        runOnUiThread(() -> {
            try {
                Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("इंस्टॉल नहीं खुल सका — Download फ़ोल्डर से APK खोलें");
            }
        });
    }
    //BUILDER_END

    /** JavaScript: window.AppBridge.* */
    private class Bridge {

        @JavascriptInterface
        public boolean isApp() {
            return true;
        }

        @JavascriptInterface
        public void toast(String msg) {
            MainActivity.this.toast(msg);
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "शेयर करें"));
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            openExternal(Uri.parse(url));
        }

        @JavascriptInterface
        public void reload() {
            runOnUiThread(() -> web.loadUrl(startUrl));
        }

        @JavascriptInterface
        public void saveFile(String base64, String name, String mime) {
            try {
                saveBytes(Base64.decode(base64, Base64.DEFAULT), name, mime);
                boolean isImage = mime != null && mime.startsWith("image/");
                MainActivity.this.toast(isImage ? "गैलरी में सेव हो गई ✓" : "Download फ़ोल्डर में सेव हो गई ✓");
            } catch (IOException e) {
                if ("permission".equals(e.getMessage())) MainActivity.this.toast("अनुमति दें और फिर से सेव करें");
                else MainActivity.this.toast("सेव नहीं हो पाई");
            } catch (Exception e) {
                MainActivity.this.toast("सेव नहीं हो पाई");
            }
        }

        //BUILDER_START
        @JavascriptInterface
        public void downloadApk(final String id, final String url, final String token, final String name) {
            new Thread(() -> {
                try {
                    File f = fetchToFile(url, token, name);
                    try {
                        saveBytes(readAll(f), name, "application/vnd.android.package-archive");
                    } catch (Exception ignored) {
                    }
                    js("window.__apkDone && window.__apkDone('" + id + "', true)");
                    installApk(f);
                } catch (Exception e) {
                    js("window.__apkDone && window.__apkDone('" + id + "', false)");
                }
            }).start();
        }
        //BUILDER_END
    }
}
