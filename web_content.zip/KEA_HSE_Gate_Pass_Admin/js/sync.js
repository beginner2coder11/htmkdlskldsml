/* Admin only: exchange files with the Guard app */
$("rSend").onclick=()=>{if(!REG.length)return toast("No passes to send yet");
 dl("KEA_Guard_Passes_"+today()+".json","application/json",JSON.stringify({type:"kea-passes",v:1,exported:Date.now(),CFG:{site:CFG.site,hseName:CFG.hseName,hsePhone:CFG.hsePhone,guardPin:CFG.guardPin||""},LOGO:LOGO==DEFAULT_LOGO?"":LOGO,REG}));
 toast("Passes file ready - send it to the guard")};
$("rImpScans").onclick=()=>$("fileScans").click();
$("fileScans").onchange=e=>{const f=e.target.files[0];e.target.value="";if(!f)return;const r=new FileReader();
 r.onload=()=>{try{const d=JSON.parse(r.result);if(d.type!="kea-scans"||!Array.isArray(d.ATT))throw 0;
  const have=new Set(ATT.map(a=>a.id));let n=0;d.ATT.forEach(a=>{if(!have.has(a.id)){ATT.push(a);n++}});ATT.sort((x,y)=>x.ts-y.ts);sv(K.att,ATT);
  renderRecent();if(!$("t-dash").hidden)renderDash();toast(n+" new scan(s) added from the guard file")}
  catch(x){alert("This is not a guard scans file")}};r.readAsText(f)};
