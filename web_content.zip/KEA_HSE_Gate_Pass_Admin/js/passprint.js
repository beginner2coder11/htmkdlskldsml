/* Admin only: print / PDF of passes */
function printPasses(list){if(!list.length)return toast("Select at least one pass");
 $("printArea").innerHTML=list.map(r=>`<div class="pair"><div class="cwrap">${frontHTML(r)}</div><div class="cwrap">${backHTML()}</div></div>`).join("");genQR($("printArea"));setTimeout(()=>window.print(),500)}
function selPasses(){const l=[...document.querySelectorAll(".rk:checked")].map(c=>REG[+c.dataset.i]).filter(Boolean);if(!l.length)toast("Tick the passes you want first");return l}
$("rPrintSel").onclick=()=>{const l=selPasses();if(l.length)printPasses(l)};
$("rPdfSel").onclick=()=>{const l=selPasses();if(l.length)pdfPasses(l)};
$("rPrintList").onclick=()=>{const c=$("rc").value;$("prHeadR").innerHTML=prHead("Gate Pass Register",(c?"Company: "+c:"All companies")+" | "+REG.length+" passes");doPrint("pr")};
document.addEventListener("change",e=>{if(e.target.id=="rAll")document.querySelectorAll(".rk").forEach(c=>c.checked=e.target.checked)});
async function pdfPasses(list){
 if(typeof html2canvas=="undefined"||!window.jspdf){toast("PDF download needs internet - opening print instead (choose Save as PDF)");return printPasses(list)}
 toast("Preparing PDF...");
 try{let st=$("pdfStage");if(!st){st=document.createElement("div");st.id="pdfStage";document.body.appendChild(st)}
  st.innerHTML=list.map(r=>`<div class="cwrap">${frontHTML(r)}</div><div class="cwrap">${backHTML()}</div>`).join("");genQR(st);await new Promise(o=>setTimeout(o,600));
  const cards=[...st.querySelectorAll(".card")],doc=new jspdf.jsPDF({unit:"mm",format:"a4"});
  for(let i=0;i<cards.length;i++){const pair=Math.floor(i/2),side=i%2,pos=pair%3;if(side==0&&pair>0&&pos==0)doc.addPage();
   const c=await html2canvas(cards[i],{scale:3,backgroundColor:"#ffffff",useCORS:true});
   const x=side==0?47:47+54+8,y=10+pos*(85.6+6);doc.addImage(c.toDataURL("image/png"),"PNG",x,y,54,85.6);doc.setDrawColor(150);doc.setLineDashPattern([1,1],0);doc.rect(x,y,54,85.6)}
  st.innerHTML="";doc.save(list.length==1?list[0].no+".pdf":"KEA_Gate_Passes_"+today()+".pdf");toast("PDF downloaded")}
 catch(e){toast("PDF failed - opening print instead");printPasses(list)}}
$("bPdf").onclick=()=>{if(!issue())return;pdfPasses([recView()])};
