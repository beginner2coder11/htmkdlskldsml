/* Default settings - everything here can also be changed inside the app (Settings tab). */
const DEFAULT_CFG = {
  prefix: "KEA-GP",
  site: "Veona by Gutti",
  hseName: "Asim Taj",
  hsePhone: "",
  assembly: "Designated emergency assembly point",
  categories: ["Worker", "Subcontractor", "Visitor", "Driver / Delivery", "Staff"],
  rules: [
    "Wear this pass visibly at all times inside the site.",
    "Wear the required PPE: safety helmet, safety shoes and hi-vis vest.",
    "Follow site rules, safety signs and HSE team instructions.",
    "Enter authorised areas only. No work without a valid permit.",
    "Report every incident, near miss and unsafe condition immediately.",
    "Know your nearest emergency exit and assembly point.",
    "This pass is not transferable. Report a lost or damaged pass to HSE at once.",
    "Return this pass on completion of work or when it expires."
  ]
};
