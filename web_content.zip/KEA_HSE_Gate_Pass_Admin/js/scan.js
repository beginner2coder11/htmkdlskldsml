/* KEA HSE Gate Pass System - scanner, attendance and dashboard */
const hhmm=ts=>{const d=new Date(ts);return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")};
const dkey=ts=>fd(new Date(ts));
const hrs=ms=>{const m=Math.round(ms/60000);return Math.floor(m/60)+"h "+String(m%60).padStart(2,"0")+"m"};
const byNo=t=>{const s=String(t||"").trim().toUpperCase();if(!s)return null;return REG.find(r=>r.no.toUpperCase()==s)||REG.find(r=>s.includes(r.no.toUpperCase()))||null};
const ppl=a=>REG.find(r=>r.id==a.pid)||{name:a.nm||"-",comp:a.cp||"-",idno:"",photo:"",no:a.no||"",cat:""};
const thumb=p=>p.photo?`<img src="${p.photo}">`:"";
const wl=p=>p.id?`<a class="lnk" onclick="showWorker(${p.id})">${esc(p.name)}</a>`:esc(p.name);
function lastMap(){const m={};ATT.forEach(a=>{if(a.res=="OK")m[a.pid]=a});return m}
function logScan(a){a.id=Date.now()+Math.random();ATT.push(a);ATT.sort((x,y)=>x.ts-y.ts);sv(K.att,ATT);renderRecent()}
let AC;function beep(ok){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.connect(g);g.connect(AC.destination);o.frequency.value=ok?880:200;g.gain.value=.15;o.start();o.stop(AC.currentTime+(ok?.15:.5));if(navigator.vibrate)navigator.vibrate(ok?80:[200,100,200])}catch(e){}}

/* ---------- scan result ---------- */
let lastCode="",lastAt=0;
function handleCode(text,src){text=String(text||"").trim();if(!text)return;const now=Date.now();
 if(src=="cam"&&text==lastCode&&now-lastAt<4000)return;lastCode=text;lastAt=now;
 const p=byNo(text),mode=$("sMode").value;
 if(!p){logScan({ts:now,res:"NOT FOUND",code:text.slice(0,40)});showRes({bad:true,title:"NOT FOUND",sub:"No gate pass with this number: "+text.slice(0,40)});beep(0);return}
 let res="OK";if(p.to<today())res="EXPIRED";else if(p.from>today())res="NOT YET VALID";
 const base={ts:now,pid:p.id,no:p.no,nm:p.name,cp:p.comp};
 if(res!="OK"){logScan({...base,res});showRes({p,bad:true,title:res=="EXPIRED"?"PASS EXPIRED":"NOT YET VALID",sub:res=="EXPIRED"?"Expired on "+dmy(p.to)+". Do not allow entry - refer to HSE.":"Valid from "+dmy(p.from)});beep(0);return}
 const l=lastMap()[p.id],last=l&&dkey(l.ts)==today()?l:null,type=mode=="auto"?(last&&last.type=="IN"?"OUT":"IN"):mode;
 logScan({...base,res:"OK",type});showRes({p,type,ts:now});beep(1)}
function showRes(o){const p=o.p;let cls=o.bad?"bad":(o.type=="IN"?"in":"out"),title=o.bad?o.title:(o.type=="IN"?"ACCESS GRANTED - IN":"EXIT RECORDED - OUT");
 const rows=p?[["Emirates ID",p.idno||"-"],["Nationality",p.nat||"-"],["Designation",p.des||"-"],["Category",p.cat],["Pass No.",p.no],["Valid until",dmy(p.to)],["Site",CFG.site]].map(r=>`<tr><td>${r[0]}</td><td><b>${esc(r[1])}</b></td></tr>`).join(""):"";
 $("scanRes").innerHTML=`<div class="sres ${cls}"><div class="sban">${title}</div><div class="sbody">${p?`<div class="sph" style="background-image:url('${p.photo||AVATAR}')"></div><h2>${esc(p.name)}</h2><div class="sc2">${esc(p.comp)}</div><table>${rows}</table>`:""}${o.sub?`<p><b>${esc(o.sub)}</b></p>`:""}</div>${o.ts?`<div class="stime">${dmy(dkey(o.ts))} &nbsp; ${hhmm(o.ts)}</div>`:""}</div>`}
function renderRecent(){$("recent").innerHTML=ATT.slice(-8).reverse().map(a=>{const p=ppl(a);const ok=a.res=="OK";return `<div class="rec"><b>${hhmm(a.ts)}</b><span class="tg ${ok?a.type:"X"}">${ok?a.type:a.res}</span><span>${esc(p.name)} - ${esc(p.comp)}</span></div>`}).join("")||'<div class="hint">No scans yet</div>'}
$("bMan").onclick=()=>{handleCode($("manIn").value,"man");$("manIn").value="";$("manIn").focus()};
$("manIn").addEventListener("keydown",e=>{if(e.key=="Enter")$("bMan").click()});

/* ---------- camera scanner ---------- */
let sStream=null,sTimer=null,sDet=null,sCan=null,sBusy=false;
function loadJsQR(){return new Promise((ok,no)=>{if(window.jsQR)return ok();const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js";s.onload=ok;s.onerror=no;document.head.appendChild(s)})}
async function startScan(){if(sStream)return;
 try{sStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1280}},audio:false})}catch(e){toast("Camera not available. Use the manual / handheld box.");return}
 const v=$("sv");v.srcObject=sStream;try{await v.play()}catch(e){}$("scanBox").hidden=false;$("bScanOn").hidden=true;$("bScanOff").hidden=false;
 sDet=null;if("BarcodeDetector" in window){try{sDet=new BarcodeDetector({formats:["qr_code","code_128"]})}catch(e){try{sDet=new BarcodeDetector()}catch(x){}}}
 if(!sDet){try{await loadJsQR()}catch(e){toast("Scanner library needs internet. Use manual / handheld entry.")}}
 sTimer=setInterval(scanFrame,250)}
async function scanFrame(){const v=$("sv");if(!v.videoWidth||sBusy)return;sBusy=true;
 try{if(sDet){const r=await sDet.detect(v);if(r.length)handleCode(r[0].rawValue,"cam")}
  else if(window.jsQR){sCan=sCan||document.createElement("canvas");const k=Math.min(1,640/v.videoWidth);sCan.width=v.videoWidth*k;sCan.height=v.videoHeight*k;const x=sCan.getContext("2d",{willReadFrequently:true});x.drawImage(v,0,0,sCan.width,sCan.height);const d=x.getImageData(0,0,sCan.width,sCan.height),q=jsQR(d.data,d.width,d.height);if(q&&q.data)handleCode(q.data,"cam")}}catch(e){}
 sBusy=false}
function stopScan(){clearInterval(sTimer);sTimer=null;if(sStream)sStream.getTracks().forEach(t=>t.stop());sStream=null;$("scanBox").hidden=true;$("bScanOn").hidden=false;$("bScanOff").hidden=true}
$("bScanOn").onclick=startScan;$("bScanOff").onclick=stopScan;

/* ---------- dashboard ---------- */
function dData(){const from=$("dFrom").value||today(),to=$("dTo").value||from,comp=$("dComp").value,q=($("dQ").value||"").toLowerCase();
 const match=p=>(!comp||p.comp==comp)&&(!q||(p.name+p.idno+p.no+p.comp).toLowerCase().includes(q));
 const recs=ATT.filter(a=>dkey(a.ts)>=from&&dkey(a.ts)<=to&&match(ppl(a)));return{from,to,recs,match}}
function daily(ok){const m={};ok.forEach(a=>{const k=a.pid+"|"+dkey(a.ts);(m[k]=m[k]||[]).push(a)});
 return Object.values(m).map(arr=>{arr.sort((x,y)=>x.ts-y.ts);let tot=0,open=null,fin=null,lout=null;arr.forEach(a=>{if(a.type=="IN"){if(!open)open=a.ts;if(!fin)fin=a.ts}else{if(open){tot+=a.ts-open;open=null}lout=a.ts}});
  const day=dkey(arr[0].ts);return{pid:arr[0].pid,a:arr[0],day,fin,lout,tot,open,status:open?(day==today()?"On site":"No exit"):"Complete"}}).sort((x,y)=>y.day.localeCompare(x.day)||((x.fin||0)-(y.fin||0)))}
function renderDash(){if(!$("dFrom").value){$("dFrom").value=today();$("dTo").value=today()}
 const cs=[...new Set(REG.map(r=>r.comp))].sort(),cv=$("dComp").value;$("dComp").innerHTML='<option value="">All companies</option>'+cs.map(c=>`<option${c==cv?" selected":""}>${esc(c)}</option>`).join("");
 const D=dData(),ok=D.recs.filter(a=>a.res=="OK"),lm=lastMap(),T=today();
 const onsite=[],noexit=[];REG.filter(D.match).forEach(p=>{const l=lm[p.id];if(l&&l.type=="IN"){(dkey(l.ts)==T?onsite:noexit).push({p,l})}});
 const k=(l,v,c)=>`<div class="kpi" style="border-color:${c||"#1F4E78"}"><span>${l}</span><b>${v}</b></div>`;
 $("dK").innerHTML=k("ON SITE NOW",onsite.length,"#2E7D32")+k("ENTRIES (IN)",ok.filter(a=>a.type=="IN").length)+k("EXITS (OUT)",ok.filter(a=>a.type=="OUT").length)+k("PEOPLE SCANNED",new Set(ok.map(a=>a.pid)).size)+k("REJECTED SCANS",D.recs.filter(a=>a.res!="OK").length,"#C00000")+k("NO EXIT (EARLIER DAYS)",noexit.length,"#C55A11")+k("ACTIVE PASSES",REG.filter(r=>r.to>=T&&D.match(r)).length);
 const row=(x,i)=>`<tr><td>${thumb(x.p)}</td><td>${wl(x.p)}</td><td>${esc(x.p.idno)}</td><td>${esc(x.p.comp)}</td><td>${esc(x.p.cat)}</td><td>${esc(x.p.no)}</td><td>${(dkey(x.l.ts)!=T?dmy(dkey(x.l.ts))+" ":"")+hhmm(x.l.ts)}</td><td>${hrs(Date.now()-x.l.ts)}</td></tr>`;
 $("dOnN").textContent="("+onsite.length+")";
 $("dOn").innerHTML=onsite.sort((a,b)=>b.l.ts-a.l.ts).map(row).join("")+noexit.map(x=>row(x).replace("<tr>",'<tr style="background:#FFEB9C">')).join("")||'<tr><td colspan="8">Nobody on site</td></tr>';
 const co={};REG.filter(D.match).forEach(p=>{const c=co[p.comp]=co[p.comp]||{on:0,en:0,n:0};c.n++});onsite.forEach(x=>co[x.p.comp].on++);ok.filter(a=>a.type=="IN").forEach(a=>{const c=co[ppl(a).comp];if(c)c.en++});
 $("dCo").innerHTML=Object.entries(co).sort((a,b)=>b[1].on-a[1].on).map(([n,c])=>`<tr><td style="text-align:left">${esc(n)}</td><td><b>${c.on}</b></td><td>${c.en}</td><td>${c.n}</td></tr>`).join("")||'<tr><td colspan="4">-</td></tr>';
 const hr=Array(24).fill(0);ok.filter(a=>a.type=="IN").forEach(a=>hr[new Date(a.ts).getHours()]++);const mx=Math.max(1,...hr);
 $("dHr").innerHTML=hr.map((n,h)=>h>=4&&h<=21?`<div class="bar"><span>${String(h).padStart(2,"0")}:00</span><i style="width:${n/mx*70}%"></i> ${n||""}</div>`:"").join("");
 $("dAtt").innerHTML=daily(ok).map(d=>{const p=ppl(d.a);return `<tr><td>${dmy(d.day)}</td><td>${thumb(p)}</td><td>${wl(p)}</td><td>${esc(p.idno)}</td><td>${esc(p.comp)}</td><td>${esc(p.no)}</td><td>${d.fin?hhmm(d.fin):"-"}</td><td>${d.lout?hhmm(d.lout):"-"}</td><td>${hrs(d.tot)}${d.open&&d.day==T?" + on site":""}</td><td class="${d.status=="Complete"?"ok":d.status=="On site"?"":"bad"}">${d.status}</td></tr>`}).join("")||'<tr><td colspan="10">No attendance in this period</td></tr>';
 $("dLog").innerHTML=D.recs.slice().reverse().map(a=>{const p=ppl(a),g=a.res=="OK";return `<tr><td>${dmy(dkey(a.ts))}</td><td>${hhmm(a.ts)}</td><td class="${g?"ok":"bad"}">${g?a.type:a.res}</td><td>${thumb(p)}</td><td>${wl(p)}</td><td>${esc(p.comp)}</td><td>${esc(p.no||a.code||"")}</td><td>${g?"Accepted":"Rejected"}</td><td class="np"><button class="btn r" onclick="delScan(${a.id})">X</button></td></tr>`}).join("")||'<tr><td colspan="9">No scans in this period</td></tr>'}
["dFrom","dTo","dComp","dQ"].forEach(i=>$(i).addEventListener("input",renderDash));
$("dToday").onclick=()=>{$("dFrom").value=today();$("dTo").value=today();renderDash()};
function delScan(id){if(confirm("Delete this scan record?")){ATT=ATT.filter(a=>a.id!=id);sv(K.att,ATT);renderDash();renderRecent()}}
$("dPrint").onclick=()=>{const D=dData();$("prHeadD").innerHTML=prHead("Gate Pass Attendance Report",dmy(D.from)+" to "+dmy(D.to)+(($("dComp").value)?" | Company: "+$("dComp").value:""));doPrint("pd")};
const csvq=c=>'"'+String(c==null?"":c).replace(/"/g,'""')+'"';
$("dCsv").onclick=()=>{const D=dData(),ok=D.recs.filter(a=>a.res=="OK");const rows=daily(ok).map(d=>{const p=ppl(d.a);return[dmy(d.day),p.name,p.idno,p.comp,p.cat,p.no,d.fin?hhmm(d.fin):"",d.lout?hhmm(d.lout):"",(d.tot/3600000).toFixed(2),d.status]});
 dl("KEA_Attendance_"+D.from+"_to_"+D.to+".csv","text/csv","\ufeff"+[["Date","Name","Emirates ID","Company","Category","Pass No","First IN","Last OUT","Hours","Status"],...rows].map(r=>r.map(csvq).join(",")).join("\n"))};
$("dCsv2").onclick=()=>{const D=dData();const rows=D.recs.map(a=>{const p=ppl(a);return[dkey(a.ts),hhmm(a.ts),a.res=="OK"?a.type:a.res,p.name,p.idno,p.comp,p.no||a.code||""]});
 dl("KEA_Scan_Log_"+D.from+"_to_"+D.to+".csv","text/csv","\ufeff"+[["Date","Time","Action / Result","Name","Emirates ID","Company","Pass No"],...rows].map(r=>r.map(csvq).join(",")).join("\n"))};

/* ---------- worker detail ---------- */
function showWorker(id){const i=REG.findIndex(r=>r.id==id);if(i<0)return;const p=REG[i],h=ATT.filter(a=>a.pid==id).slice(-40).reverse();
 $("wBody").innerHTML=`<div class="wh"><div class="sph" style="background-image:url('${p.photo||AVATAR}')"></div><div style="flex:1;min-width:200px"><h2 style="margin:0;color:#1F4E78">${esc(p.name)}</h2><div class="sc2">${esc(p.comp)}</div><table>${[["Emirates ID",p.idno||"-"],["Nationality",p.nat||"-"],["Designation",p.des||"-"],["Category",p.cat],["Pass No.",p.no],["Valid",dmy(p.from)+" to "+dmy(p.to)],["Pass status",p.to<today()?"Expired":"Active"]].map(r=>`<tr><td>${r[0]}</td><td><b>${esc(r[1])}</b></td></tr>`).join("")}</table></div></div>
 <h3 style="margin-top:10px">Scan history</h3><div class="sc" style="max-height:220px;overflow:auto"><table><thead><tr><th>Date</th><th>Time</th><th>Action</th></tr></thead><tbody>${h.map(a=>`<tr><td>${dmy(dkey(a.ts))}</td><td>${hhmm(a.ts)}</td><td class="${a.res=="OK"?"ok":"bad"}">${a.res=="OK"?a.type:a.res}</td></tr>`).join("")||'<tr><td colspan="3">No scans yet</td></tr>'}</tbody></table></div>
 <div class="row" style="margin-top:8px">${window.openRec?`<button class="btn" onclick="$('wModal').hidden=true;openRec(${i})">Open pass</button><button class="btn g" onclick="printPasses([REG[${i}]])">Print pass</button>`:""}<button class="btn r" onclick="$('wModal').hidden=true">Close</button></div>`;$("wModal").hidden=false}
$("wModal").addEventListener("click",e=>{if(e.target.id=="wModal")$("wModal").hidden=true});
setInterval(()=>{if(!$("t-dash").hidden)renderDash()},30000);
renderRecent();$("manIn").focus();

/* ---------- print / PDF ---------- */
function doPrint(cls){document.body.classList.add(cls);const rm=()=>{document.body.classList.remove(cls);removeEventListener("afterprint",rm)};addEventListener("afterprint",rm);setTimeout(()=>window.print(),300);setTimeout(rm,120000)}
function prHead(title,sub){return `<div style="display:flex;align-items:center;gap:12px;border-bottom:3px solid #C55A11;padding-bottom:6px;margin-bottom:8px"><img src="${esc(LOGO)}" style="height:44px"><div><b style="font-size:16px;color:#1F4E78">${esc(title)}</b><div style="font-size:11px">${esc(CFG.site)} | ${esc(sub)}</div><div style="font-size:10px;color:#555">Printed ${dmy(today())} ${hhmm(Date.now())} | HSE: ${esc(CFG.hseName)}</div></div></div>`}
