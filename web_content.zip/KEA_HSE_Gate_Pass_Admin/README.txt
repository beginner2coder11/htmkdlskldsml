KEA HSE GATE PASS - ADMIN APP (HSE office)
==========================================
Open index.html in Chrome (online link recommended for camera, ID reading, QR code, PNG/PDF download).

TABS
  Issue Pass  Upload / scan Emirates ID -> photo cropped -> unique pass number -> print or PDF.
              Front has QR code + barcode, back page is the same for everyone.
  Register    All passes, search, reprint, selected passes print / PDF, register report, Excel, backup / restore.
  Scan + Dashboard  Same as the guard app. Shows attendance after you import the guard's scans file.
  Settings    Logo, categories, site, HSE name, back page, Admin PIN, Guard app PIN.

WORKING WITH THE GUARD APP (separate zip: KEA_HSE_Gate_Guard_App)
  1. Issue passes here.
  2. Register > "Send passes to guard (file)" -> send the downloaded KEA_Guard_Passes_....json to the guard
     (WhatsApp / email). The guard imports it in the Guard app > Data tab.
  3. The guard sends back KEA_Guard_Scans_....json.
  4. Register > "Import guard scans (file)". Already-imported scans are not duplicated.
  5. Open the Dashboard tab to see on-site list, attendance hours, scan log, print / PDF.

DATA
  Stored in this browser only. Use Register > Save backup regularly.
  Emirates ID images are never saved - only the cropped photo and the checked details.
