package com.yourpackage.cardgen; // Change this to your actual package name

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    private WebView myWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = findViewById(R.id.webview);
        
        // Enable JavaScript because your card generator uses JS
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Load the HTML file from the assets folder
        myWebView.loadUrl("file:///android_asset/index.html");
        
        // Keep the app open when links are clicked (don't open external browser)
        myWebView.setWebViewClient(new WebViewClient());
    }

    // Allow back button to go back in history instead of closing app
    @Override
    public void onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}