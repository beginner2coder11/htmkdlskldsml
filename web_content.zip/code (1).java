package com.example.nobank;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Create the WebView
        webView = new WebView(this);
        setContentView(webView);

        // Configure WebView settings
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Crucial for the HTML/JS interaction
        webSettings.setDomStorageEnabled(true);

        // Load the local HTML file from assets
        // If you are using a local Flask server, change this to: 
        // webView.loadUrl("http://10.0.2.2:5000");
        webView.loadUrl("file:///android_asset/index.html");

        // Allow navigation within the app
        webView.setWebViewClient(new WebViewClient());
    }

    // Handle back button to go back in history instead of closing app
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}