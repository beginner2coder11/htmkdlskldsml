BURGOS GESTIÓN - Proyecto Android

Incluye el HTML actualizado dentro de app/src/main/assets/index.html y un contenedor WebView offline.

Cómo generar la APK:
1. Instala Android Studio en un ordenador.
2. Descomprime esta carpeta.
3. Android Studio > Open > selecciona la carpeta BurgosGestion.
4. Espera a que Gradle sincronice y descargue las herramientas necesarias.
5. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará el enlace a app-debug.apk.

Nota importante sobre datos: esta primera versión envuelve el HTML en WebView con almacenamiento web habilitado. Antes de usarla como única copia de los datos, prueba crear registros, cerrar la app, abrirla de nuevo y cambiar de año. Conviene exportar o respaldar los datos con regularidad.
