globalThis.Reports=(()=>{
 const money=v=>v===null?'Por calcular':new Intl.NumberFormat('pt-AO',{minimumFractionDigits:2,maximumFractionDigits:2}).format(v)+' Kz';
 const date=s=>s?s.split('-').reverse().join('/'):'—';
 const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const n=v=>new Intl.NumberFormat('pt-AO',{maximumFractionDigits:3}).format(v);
 function purchase(db,p){
 const c=CC.calc(p),r={title:'Compra #'+String(p.number).padStart(3,'0'),business:db.settings.business,subtitle:date(p.date)+(p.reference?' · Fatura '+p.reference:''),sections:[],note:'Receita e lucro são estimativas. Frete e outras despesas são considerados apenas no resumo.'};
 r.sections.push({title:'Produtos e custos',headers:['Produto','Categoria','Caixas/emb.','Un./emb.','Custo/emb.','Custo/un.','Total'],rows:p.items.map((i,j)=>[i.name,i.category,n(CC.number(i.boxes)),n(CC.number(i.units))+' '+i.saleUnit,money(CC.number(i.cost)),money(c.rows[j].unitCost),money(c.rows[j].goods)])});
 r.sections.push({title:'Venda e lucro bruto estimado',headers:['Produto','Venda/un.','Lucro/un.','Lucro/emb.','Lucro total'],rows:p.items.map((i,j)=>[i.name,money(CC.number(i.price)),money(c.rows[j].unitProfit),money(c.rows[j].boxProfit),money(c.rows[j].profit)])});
 const summary=[['Mercadorias',money(c.goods)],['Frete',money(c.freight)],...p.expenses.map(x=>[x.name,money(CC.number(x.value))]),['Investimento total',money(c.investment)],['Receita potencial',money(c.revenue)],['Lucro bruto estimado',money(c.gross)],['Resultado estimado após despesas',money(c.net)]];
 if(CC.number(p.capital)!==null)summary.push(['Capital disponível',money(CC.number(p.capital))],['Capital restante',money(c.remaining)]);
 if(CC.number(p.invoiceTotal)!==null)summary.push(['Total da fatura informado',money(CC.number(p.invoiceTotal))],['Diferença para mercadorias',money(CC.round(c.goods-CC.number(p.invoiceTotal)))]);r.sections.push({title:'Resumo da compra',headers:['Indicador','Valor'],rows:summary});
 if(p.notes)r.sections.push({title:'Observações',text:p.notes});return r;
 }
 function history(db,pid){
 const prod=db.products.find(p=>p.id===pid),hist=CC.history(db,pid);
 return {title:'Histórico do produto',business:db.settings.business,subtitle:prod.name,sections:[{title:'Custos e preços por compra',headers:['Data','Compra','Unidade','Custo/un.','Venda/un.','Lucro/un.','Variação custo'],rows:hist.map((h,j)=>{const prior=hist[j-1],v=prior&&prior.item.saleUnit===h.item.saleUnit?CC.variation(h.calc.unitCost,prior.calc.unitCost):null;return [date(h.purchase.date),'#'+h.purchase.number,h.item.saleUnit,money(h.calc.unitCost),money(h.calc.price),money(h.calc.unitProfit),v?v.label+' '+money(Math.abs(v.delta)):'—'];})}],note:'Comparações entre unidades de venda iguais. Lucro bruto estimado, sem despesas gerais.'};
 }
 function period(db,from,to,category='',productId=''){
 const ps=db.purchases.filter(p=>(!from||p.date>=from)&&(!to||p.date<=to));
 const filtered=!!(category||productId);const rows=ps.flatMap(p=>p.items.filter(i=>(!category||i.category===category)&&(!productId||i.productId===productId)).map(i=>({p,i,c:CC.item(i)})));
 const good=CC.round(rows.reduce((s,x)=>s+x.c.goods,0)),complete=rows.every(x=>x.c.profit!==null),gross=complete?CC.round(rows.reduce((s,x)=>s+x.c.profit,0)):null;
 const r={title:filtered?'Relatório de produtos':'Relatório de compras',business:db.settings.business,subtitle:(from?date(from):'Início')+' a '+(to?date(to):'hoje')+(category?' · '+category:''),sections:[],note:filtered?'Lucro bruto estimado. Despesas gerais não são distribuídas pelos produtos.':'Receita e lucro estimados. Despesas gerais apenas no resumo.'};
 if(filtered)r.sections.push({title:'Movimentos',headers:['Data','Produto','Categoria','Qtd.','Custo total','Lucro bruto'],rows:rows.map(x=>[date(x.p.date),x.i.name,x.i.category,n(x.c.qty)+' '+x.i.saleUnit,money(x.c.goods),money(x.c.profit)])});
 else r.sections.push({title:'Compras do período',headers:['Data','Compra','Mercadorias','Despesas','Investimento','Resultado estimado'],rows:ps.sort(CCsort).map(p=>{const c=CC.calc(p);return [date(p.date),'#'+p.number,money(c.goods),money(c.freight+c.other),money(c.investment),money(c.net)];})});
 let sum=[['Mercadorias',money(good)],['Lucro bruto estimado',money(gross)]];
 if(!filtered){const expense=CC.round(ps.reduce((s,p)=>{const c=CC.calc(p);return s+c.freight+c.other;},0));sum.push(['Frete e outras despesas',money(expense)],['Investimento total',money(good+expense)],['Resultado estimado após despesas',money(gross===null?null:gross-expense)]);}
 r.sections.push({title:'Totais',headers:['Indicador','Valor'],rows:sum});return r;
 }
 const CCsort=(a,b)=>a.date.localeCompare(b.date)||a.number-b.number;
 function html(r){return '<article class="report-sheet"><small>CONTROLO DE COMPRAS</small><h2>'+e(r.business)+'</h2><h3>'+e(r.title)+'</h3><p class="muted">'+e(r.subtitle)+'</p>'+r.sections.map(s=>'<section class="report-section"><h3>'+e(s.title)+'</h3>'+(s.text?'<p>'+e(s.text)+'</p>':'<div class="tablewrap"><table><thead><tr>'+s.headers.map(x=>'<th>'+e(x)+'</th>').join('')+'</tr></thead><tbody>'+s.rows.map(row=>'<tr>'+row.map(x=>'<td>'+e(x)+'</td>').join('')+'</tr>').join('')+(s.rows.length?'':'<tr><td colspan="'+s.headers.length+'">Sem dados neste filtro.</td></tr>')+'</tbody></table></div>')+'</section>').join('')+'<p class="report-note">'+e(r.note)+'</p></article>';}
 async function pdf(r){
 const {PDFDocument,StandardFonts,rgb}=PDFLib,doc=await PDFDocument.create(),font=await doc.embedFont(StandardFonts.Helvetica),bold=await doc.embedFont(StandardFonts.HelveticaBold);
 doc.setTitle(r.title);doc.setAuthor(r.business);doc.setSubject('Controlo de Compras — relatório estimado');
 const clean=t=>String(t??'').replace(/→/g,' > ').replace(/−/g,'-').replace(/[\u202f\u00a0]/g,' ').split('').map(c=>{try{font.encodeText(c);return c;}catch{return '?';}}).join('');
 let page,y,pageNo=0;const width=595.28,margin=34,area=width-2*margin;
 const text=(t,x,yy,size=9,b=false,col=rgb(.08,.18,.23))=>page.drawText(clean(t),{x,y:yy,size,font:b?bold:font,color:col});
 function addPage(){page=doc.addPage([width,841.89]);pageNo++;y=793;text(r.business,margin,y,14,true);y-=20;text(r.title,margin,y,11,true);y-=16;text(r.subtitle,margin,y,8);y-=25;page.drawLine({start:{x:margin,y:y+12},end:{x:width-margin,y:y+12},thickness:1,color:rgb(.1,.5,.4)});text('Controlo de Compras · '+pageNo,margin,25,8);}
 function wrap(t,w,size=8){const result=[];for(const paragraph of clean(t).split('\n')){let line='';for(const word of paragraph.split(/\s+/)){if(font.widthOfTextAtSize((line?line+' ':'')+word,size)<=w){line+=(line?' ':'')+word;continue;}if(line)result.push(line);line='';for(const ch of word){if(font.widthOfTextAtSize(line+ch,size)>w){result.push(line);line='';}line+=ch;}}result.push(line);}return result;}
 function need(h){if(y-h<48)addPage();}
 addPage();
 for(const s of r.sections){need(50);text(s.title,margin,y,11,true);y-=19;
 if(s.text){for(const line of wrap(s.text,area,9)){need(15);text(line,margin,y,9);y-=13;}y-=10;continue;}
 const count=s.headers.length,weights=count===2?[.64,.36]:[.25,...Array(count-1).fill(.75/(count-1))],ws=weights.map(v=>v*area);
 function row(vals,head=false){const ls=vals.map((v,i)=>wrap(v,ws[i]-10,head?7:8)),height=Math.max(...ls.map(a=>a.length))*11+12;
 if(y-height<48){addPage();if(!head)row(s.headers,true);}
 page.drawRectangle({x:margin,y:y-height,width:area,height,color:head?rgb(.90,.94,.93):rgb(1,1,1),borderColor:rgb(.86,.9,.9),borderWidth:.4});
 let x=margin;ls.forEach((lines,i)=>{lines.forEach((l,j)=>text(l,x+5,y-12-j*11,head?7:8,head));x+=ws[i];});y-=height;
 }
 row(s.headers,true);if(s.rows.length)s.rows.forEach(v=>row(v));else row(s.headers.map((_,i)=>i?'':'Sem dados.'));y-=22;
 }
 for(const line of wrap(r.note,area,8)){need(14);text(line,margin,y,8,false,rgb(.35,.43,.46));y-=12;}
 return new Blob([await doc.save()],{type:'application/pdf'});
 }
 return {purchase,history,period,html,pdf};
})();
