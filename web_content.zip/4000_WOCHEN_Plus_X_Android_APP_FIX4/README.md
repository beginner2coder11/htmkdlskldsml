# 4.000 WOCHEN Plus X – Android App

Dieses Android-Studio-Projekt enthält die aktuelle FIX4-Master-HTML-Version als lokale WebView-App und das aktuelle App-Icon.

## App
- Name: 4.000 WOCHEN Plus X
- Application ID: de.wochen.plusx
- Version: 1.0 (Code 1)
- Ziel: Android 8.0+ (API 26+), Target SDK 35
- HTML-Datei: app/src/main/assets/index.html
- Icon: app/src/main/res/mipmap-*/ic_launcher.png

## Öffnen
Projektordner in Android Studio öffnen und Gradle synchronisieren. Danach `Build > Build APK(s)`.
