# إصلاح النسخة الاحتياطية — حفظ حقيقي على الهاتف

تم تغيير آلية النسخة الاحتياطية لتجنب `appassets.androidplatform.net` وWebView download.

## السلوك الجديد
- Android 10 وما بعده: يحفظ التطبيق الملف مباشرة في `Downloads/Afriquia` باستخدام `MediaStore`.
- Android 9 وما قبله: يحفظ في `Downloads/Afriquia` بعد طلب صلاحية التخزين عند الحاجة.
- لا تظهر رسالة النجاح إلا بعد انتهاء الكتابة الفعلية للملف.
- اسم الملف: `AFRIQUIA-BACKUP-yyyy-MM-dd-HHmmss.json`.
- الملف JSON حقيقي ويمكن العثور عليه من تطبيق الملفات في `Downloads/Afriquia`.
