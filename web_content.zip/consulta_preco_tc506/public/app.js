let cfg = {};
const el = id => document.getElementById(id);
async function loadConfig(){
  cfg = await fetch('/api/config').then(r=>r.json());
  el('store').textContent = cfg.storeName || 'CONSULTA DE PREÇO';
  el('tcpPort').textContent = cfg.server?.tcpPort || 9090;
  el('webUrl').textContent = location.origin;
  el('mockMode').checked = !!cfg.mockMode;
  el('dbHost').value = cfg.database?.host || '';
  el('dbPort').value = cfg.database?.port || 5432;
  el('dbName').value = cfg.database?.database || '';
  el('dbUser').value = cfg.database?.user || '';
  el('dbPass').value = cfg.database?.password || '';
  el('webPort').value = cfg.server?.webPort || 8080;
  el('cfgTcpPort').value = cfg.server?.tcpPort || 9090;
  el('table').value = cfg.query?.table || 'produtos';
  el('barcodeColumn').value = cfg.query?.barcodeColumn || 'codigo_barras';
  el('nameColumn').value = cfg.query?.nameColumn || 'descricao';
  el('priceColumn').value = cfg.query?.priceColumn || 'preco_venda';
  el('activeWhere').value = cfg.query?.activeWhere || '';
}
function openConfig(){ el('cfgDialog').showModal(); }
async function saveConfig(){
  const body = {
    mockMode: el('mockMode').checked,
    server: { webPort: Number(el('webPort').value), tcpPort: Number(el('cfgTcpPort').value) },
    database: { type:'postgres', host: el('dbHost').value, port: Number(el('dbPort').value), database: el('dbName').value, user: el('dbUser').value, password: el('dbPass').value, ssl:false },
    query: { table: el('table').value, barcodeColumn: el('barcodeColumn').value, nameColumn: el('nameColumn').value, priceColumn: el('priceColumn').value, activeWhere: el('activeWhere').value }
  };
  const r = await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(r=>r.json());
  el('log').textContent = r.ok ? 'Configuração salva. Reinicie o servidor se alterar portas.' : JSON.stringify(r,null,2);
  el('cfgDialog').close(); loadConfig();
}
async function consulta(){
  const code = el('barcode').value.trim(); if(!code) return;
  const screen = el('screen');
  screen.innerHTML = '<div class="idle">CONSULTANDO...</div>';
  try{
    const r = await fetch('/api/consulta/'+encodeURIComponent(code)).then(r=>r.json());
    if(!r.ok) throw new Error(r.error);
    if(!r.found) screen.innerHTML = `<div class="notfound">PRODUTO NÃO<br>ENCONTRADO<br><small>${code}</small></div>`;
    else screen.innerHTML = `<div class="product"><div class="name">${escapeHtml(r.product.descricao)}</div><div class="price">${Number(r.product.preco_venda).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</div></div>`;
    el('log').textContent = r.display;
  }catch(e){ screen.innerHTML = `<div class="notfound">ERRO<br><small>${escapeHtml(e.message)}</small></div>`; }
  el('barcode').select();
}
async function testDb(){
  const r = await fetch('/api/test-db').then(r=>r.json()).catch(e=>({ok:false,error:e.message}));
  el('log').textContent = JSON.stringify(r,null,2);
}
function escapeHtml(s){ return String(s).replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
loadConfig();
