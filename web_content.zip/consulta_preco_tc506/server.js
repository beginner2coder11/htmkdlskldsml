const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const net = require('net');
const { Pool } = require('pg');

const root = __dirname;
const configPath = path.join(root, 'config.json');
const demoPath = path.join(root, 'produtos.demo.json');

function loadConfig() {
  if (!fs.existsSync(configPath)) fs.copyFileSync(path.join(root, 'config.example.json'), configPath);
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}
function saveConfig(cfg) { fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2)); }
let config = loadConfig();
let pool = null;

function getPool() {
  if (config.mockMode) return null;
  if (!pool) {
    pool = new Pool({
      host: config.database.host,
      port: Number(config.database.port || 5432),
      database: config.database.database,
      user: config.database.user,
      password: config.database.password,
      ssl: config.database.ssl ? { rejectUnauthorized: false } : false,
      max: 8,
      idleTimeoutMillis: 30000
    });
  }
  return pool;
}
function moneyBR(value) {
  return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function safeIdent(v, fallback) {
  const s = String(v || fallback || '').trim();
  if (!/^[a-zA-Z0-9_\.]+$/.test(s)) throw new Error('Identificador SQL inválido: ' + s);
  return s;
}
async function findProduct(barcode) {
  const code = String(barcode || '').replace(/[^0-9A-Za-z]/g, '').trim();
  if (!code) return null;
  if (config.mockMode) {
    const items = JSON.parse(fs.readFileSync(demoPath, 'utf8'));
    return items.find(p => String(p.codigo_barras) === code) || null;
  }
  const q = config.query || {};
  const table = safeIdent(q.table, 'produtos');
  const bc = safeIdent(q.barcodeColumn, 'codigo_barras');
  const name = safeIdent(q.nameColumn, 'descricao');
  const price = safeIdent(q.priceColumn, 'preco_venda');
  const whereExtra = q.activeWhere && String(q.activeWhere).trim() ? ` AND (${q.activeWhere})` : '';
  const sql = `SELECT ${bc} AS codigo_barras, ${name} AS descricao, ${price} AS preco_venda FROM ${table} WHERE ${bc} = $1 ${whereExtra} LIMIT 1`;
  const result = await getPool().query(sql, [code]);
  return result.rows[0] || null;
}
function tc506Response(product, code) {
  if (!product) return `PRODUTO NAO ENCONTRADO\nCOD: ${code}\n`;
  const name = String(product.descricao || '').substring(0, 40);
  return `${name}\n${moneyBR(product.preco_venda)}\n`;
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(root, 'public')));

app.get('/api/config', (req, res) => res.json(loadConfig()));
app.post('/api/config', async (req, res) => {
  config = { ...loadConfig(), ...req.body, database: { ...loadConfig().database, ...(req.body.database || {}) }, query: { ...loadConfig().query, ...(req.body.query || {}) }, server: { ...loadConfig().server, ...(req.body.server || {}) } };
  if (pool) { await pool.end().catch(() => {}); pool = null; }
  saveConfig(config);
  res.json({ ok: true, config });
});
app.get('/api/consulta/:codigo', async (req, res) => {
  try {
    const product = await findProduct(req.params.codigo);
    res.json({ ok: true, found: !!product, product, display: tc506Response(product, req.params.codigo) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.get('/api/test-db', async (req, res) => {
  try {
    if (config.mockMode) return res.json({ ok: true, mode: 'demo', message: 'Modo demonstração ativo.' });
    const r = await getPool().query('SELECT NOW() AS data_servidor');
    res.json({ ok: true, databaseTime: r.rows[0].data_servidor });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

function startTcpServer() {
  const port = Number(config.server.tcpPort || 9090);
  const tcpServer = net.createServer(socket => {
    socket.setEncoding('utf8');
    socket.on('data', async data => {
      const code = String(data).trim().replace(/\r|\n/g, '');
      try {
        const product = await findProduct(code);
        socket.write(tc506Response(product, code));
      } catch (e) {
        socket.write(`ERRO SERVIDOR\n${e.message.substring(0, 40)}\n`);
      }
    });
  });
  tcpServer.listen(port, '0.0.0.0', () => console.log(`TCP consulta ativo na porta ${port}`));
}

const webPort = Number(config.server.webPort || 8080);
app.listen(webPort, '0.0.0.0', () => {
  console.log(`Web: http://localhost:${webPort}`);
  startTcpServer();
});
