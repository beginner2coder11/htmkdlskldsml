# Consulta de Preço estilo Gertec TC506

Sistema em rede local com:
- Tela web simulando terminal de consulta de preço.
- Configuração de IP, porta, banco, usuário e senha.
- Consulta PostgreSQL.
- Modo demonstração sem banco.
- Servidor TCP simples para adaptação ao terminal TC506 real.

## Instalação

1. Instale o Node.js.
2. Abra a pasta do projeto no terminal.
3. Execute:

```bash
npm install
npm start
```

4. Acesse no navegador:

```text
http://IP_DO_COMPUTADOR:8080
```

Exemplo:

```text
http://192.168.1.50:8080
```

## Configuração do banco

Clique em **Configurar banco** e preencha:

- IP do banco
- Porta
- Nome do banco
- Usuário
- Senha
- Tabela de produtos
- Coluna do código de barras
- Coluna da descrição
- Coluna do preço

Por padrão o sistema usa PostgreSQL.

## Exemplo de tabela

```sql
CREATE TABLE produtos (
  codigo_barras varchar(30) PRIMARY KEY,
  descricao varchar(120),
  preco_venda numeric(12,2),
  ativo boolean default true
);
```

## Porta TCP para TC506 real

O servidor abre a porta TCP configurada, por padrão `9090`.
O terminal deve apontar para o IP do computador servidor e essa porta.

Resposta básica enviada ao terminal:

```text
NOME DO PRODUTO
R$ 9,99
```

Caso seu modelo exija protocolo específico com STX/ETX/checksum, ajuste a função `tc506Response()` no arquivo `server.js` conforme o manual/SDK Gertec usado na sua automação.

## Segurança

Use apenas em rede local confiável. Não exponha este servidor diretamente na internet, pois ele armazena senha de banco no arquivo `config.json`.
