"""LaunchDeck Remote PC companion: local Wi-Fi HTTP + optional Bluetooth serial."""
import json, os, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = os.path.dirname(os.path.abspath(__file__))
HOST = '0.0.0.0'
PORT = 8765
BLUETOOTH_COM_PORT = 'COM5'  # Change this to the Windows incoming Bluetooth COM port.
BLUETOOTH_BAUD = 9600

DEFAULT_APPS = {
    "browser": {"name": "Web Browser", "command": "start", "args": ["https://www.google.com"]},
    "media": {"name": "Media Player", "command": "start", "args": ["wmplayer.exe"]},
    "games": {"name": "Games", "command": "start", "args": ["steam://open/main"]},
    "files": {"name": "File Explorer", "command": "explorer.exe", "args": []},
    "tools": {"name": "PC Tools", "command": "control.exe", "args": []},
    "custom": {"name": "Custom app", "command": "notepad.exe", "args": []},
}

def load_apps():
    path = os.path.join(BASE, 'apps.json')
    if not os.path.exists(path):
        with open(path, 'w', encoding='utf-8') as f: json.dump(DEFAULT_APPS, f, indent=2)
    with open(path, 'r', encoding='utf-8') as f: return json.load(f)

APPS = load_apps()

def launch_app(key):
    item = APPS.get(key)
    if not item: return False, 'App key is not in apps.json'
    command = item.get('command')
    args = item.get('args', [])
    if not command or not isinstance(args, list): return False, 'Invalid app configuration'
    try:
        if command.lower() == 'start':
            # Windows shell start is needed for URLs and protocol handlers.
            subprocess.Popen(['cmd', '/c', 'start', '', *args], cwd=BASE)
        else:
            subprocess.Popen([command, *args], cwd=BASE)
        print(f"Launch request: {key} ({item.get('name', key)})")
        return True, 'Launch request accepted'
    except Exception as exc:
        print(f'Launch failed for {key}: {exc}')
        return False, str(exc)

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload):
        data = json.dumps(payload).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data))); self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type'); self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers(); self.wfile.write(data)
    def do_OPTIONS(self): self._send(200, {'ok': True})
    def do_GET(self):
        if self.path.rstrip('/') == '/health': self._send(200, {'ok': True, 'service': 'LaunchDeck Remote', 'transport': 'wifi'})
        elif self.path.rstrip('/') == '/apps': self._send(200, {'apps': [{'id': k, 'name': v.get('name', k)} for k,v in APPS.items()]})
        else: self._send(404, {'ok': False, 'error': 'Not found'})
    def do_POST(self):
        if self.path.rstrip('/') != '/launch': self._send(404, {'ok': False, 'error': 'Not found'}); return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            data = json.loads(self.rfile.read(length).decode('utf-8'))
            ok, message = launch_app(str(data.get('app', '')))
            self._send(200 if ok else 400, {'ok': ok, 'message': message})
        except Exception as exc: self._send(400, {'ok': False, 'error': str(exc)})
    def log_message(self, fmt, *args): print('[Wi-Fi] ' + (fmt % args))

def bluetooth_loop():
    try:
        import serial
    except ImportError:
        print('Bluetooth serial disabled: install pyserial with: py -m pip install pyserial')
        return
    print(f'Bluetooth serial listener opening {BLUETOOTH_COM_PORT} at {BLUETOOTH_BAUD} baud...')
    while True:
        try:
            with serial.Serial(BLUETOOTH_COM_PORT, BLUETOOTH_BAUD, timeout=1) as ser:
                print(f'Bluetooth serial ready on {BLUETOOTH_COM_PORT}')
                buf = b''
                while True:
                    chunk = ser.read(256)
                    if not chunk: continue
                    buf += chunk
                    while b'\n' in buf:
                        line, buf = buf.split(b'\n', 1)
                        try:
                            msg = json.loads(line.decode('utf-8').strip())
                            key = str(msg.get('app', ''))
                            ok, message = launch_app(key)
                            ser.write((json.dumps({'ok': ok, 'app': key, 'message': message}) + '\n').encode('utf-8'))
                        except Exception as exc:
                            ser.write((json.dumps({'ok': False, 'message': str(exc)}) + '\n').encode('utf-8'))
        except Exception as exc:
            print(f'Bluetooth COM port unavailable ({BLUETOOTH_COM_PORT}): {exc}')
            time.sleep(5)

if __name__ == '__main__':
    threading.Thread(target=bluetooth_loop, daemon=True).start()
    print('LaunchDeck Remote PC companion starting...')
    print(f'Wi-Fi address: http://<this-PC-IP>:{PORT}')
    print('Keep this window open while using the phone app.')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
