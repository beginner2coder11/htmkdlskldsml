LaunchDeck Remote — Android Studio project (sliding launcher UI)

WHAT'S INCLUDED
- A regular Android application project with the LaunchDeck Remote app name.
- The sliding-icon launcher screen is bundled inside the Android app.
- The interface works offline and does not need a browser or a hosted website.
- Search, category tabs, horizontally sliding app cards, and quick-launch shortcuts are included.

IMPORTANT LIMITATION
This build is currently a launcher-interface prototype. Selecting an icon shows a demo message; it does not yet launch a real Windows program. PC control requires a separately running Windows companion service and a secure pairing/launch implementation. Do not expose a PC control service to the public internet.

BUILD AN APK
1. Download and extract this ZIP on a computer.
2. Install Android Studio from https://developer.android.com/studio
3. In Android Studio, choose Open and select the extracted LaunchDeckRemote folder.
4. Allow Gradle sync and install the requested Android SDK if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, use the notification's Locate link. The APK is normally at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. If prompted, allow installation from that source.

This ZIP is source code, not a compiled APK. A build environment with Android SDK/Gradle is required to compile it.
