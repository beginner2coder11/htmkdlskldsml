LaunchDeck Remote — Android Project + Windows Companion (Preview 0.2)

CONTENTS
- app/: Android Studio project for the LaunchDeck Remote mobile interface.
- pc_companion/: optional Windows PC companion that serves /health and /launch for the app.

BUILD THE APK
This ZIP is source code, not a compiled APK. To create an installable APK:
1. Install Android Studio on a Windows/Mac/Linux computer: https://developer.android.com/studio
2. Extract this ZIP and open the extracted LaunchDeck project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK, normally app/build/outputs/apk/debug/app-debug.apk.

RUN THE PC COMPANION
1. On a Windows PC, open pc_companion/README.txt and follow its steps.
2. Keep the phone and PC on the same trusted Wi-Fi network.

IMPORTANT
- This environment does not have the Android SDK or Gradle installed, so no APK has been compiled here.
- This is a prototype; test on your own devices before relying on it.
- The companion uses a local-network HTTP service and has no PIN authentication in this preview. Do not expose it to the internet or use on public Wi-Fi.
