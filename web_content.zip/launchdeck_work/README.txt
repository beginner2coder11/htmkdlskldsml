LaunchDeck Remote — Android source + Windows PC companion (Wi-Fi and Bluetooth)

WHAT'S INCLUDED
- Android Studio project for LaunchDeck Remote.
- Native Android Bluetooth Classic (SPP/RFCOMM) support for paired devices.
- Wi-Fi launch mode using the local HTTP companion.
- Windows PC companion: server.py, start_server.bat, apps.json.
- Configurable launch allowlist in apps.json.

IMPORTANT STATUS
This ZIP is project source, not a compiled APK. You must build it in Android Studio. Bluetooth support is implemented using Bluetooth Classic SPP and requires the Windows PC to expose an incoming Bluetooth serial COM port. Bluetooth pairing alone is not enough.

BUILD THE ANDROID APK
1. Extract this ZIP on a computer.
2. Open the extracted folder in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if asked.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio's APK output is normally app/build/outputs/apk/debug/app-debug.apk.

SET UP THE WINDOWS PC COMPANION
1. Install Python 3 on Windows.
2. Open Command Prompt in this folder and run: py -m pip install -r requirements.txt
3. Open Windows Bluetooth settings and pair the PC with your Android phone.
4. In Windows Bluetooth settings / More Bluetooth settings, create an INCOMING COM port for the phone if Windows offers that option. The exact menu varies by Windows version and Bluetooth adapter.
5. Edit server.py and change BLUETOOTH_COM_PORT = 'COM5' to the incoming COM port Windows assigned. Do not use an outgoing COM port.
6. Double-click start_server.bat and leave the window open.
7. In the phone app, choose Bluetooth, tap Refresh paired devices, select the PC, and tap Connect Bluetooth.

WI-FI MODE
1. Start the PC companion.
2. Find the PC's local IPv4 address using ipconfig.
3. Enter http://PC-IP:8765 in the app and tap Connect to PC. Allow Python through Windows Firewall on your private network if prompted.

CUSTOMIZE LAUNCH BUTTONS
Edit apps.json. Each key must match a button ID (browser, media, games, files, tools, custom). Only configure commands you trust. The companion runs configured commands on your PC, so keep it on a trusted home network and do not port-forward it to the internet.

LIMITATIONS / TESTING
- This source has not been built into an APK in this environment; Android Studio build and device testing are still required.
- Bluetooth behavior depends on Windows Bluetooth stack/driver and an available incoming serial COM port. Some Windows setups do not expose SPP COM ports; in that case use Wi-Fi mode or a supported Bluetooth serial adapter/service.
- The Bluetooth UI lists already-paired devices; pair the phone and PC in system settings first.
- This is a local personal remote. There is no cloud access or remote access over the internet.
