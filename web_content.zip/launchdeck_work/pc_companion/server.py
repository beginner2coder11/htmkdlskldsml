"""LaunchDeck Remote PC companion. LAN-only, allowlist-based launcher."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, subprocess, webbrowser

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'apps.json'
HOST = '0.0.0.0'
PORT = 8765

def load_apps():
    try:
        return json.loads(CONFIG.read_text(encoding='utf-8'))
    except Exception:
        return {}

class Handler(BaseHTTPRequestHandler):
    def _send(self, status, payload):
        data = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def do_OPTIONS(self):
        self._send(200, {'ok': True})

    def do_GET(self):
        if self.path.rstrip('/') == '/health':
            return self._send(200, {'ok': True, 'service': 'LaunchDeck Remote PC companion'})
        return self._send(404, {'ok': False, 'error': 'not found'})

    def do_POST(self):
        if self.path.rstrip('/') != '/launch':
            return self._send(404, {'ok': False, 'error': 'not found'})
        try:
            length = min(int(self.headers.get('Content-Length', '0')), 4096)
            body = json.loads(self.rfile.read(length).decode('utf-8'))
            key = body.get('app')
            apps = load_apps()
            entry = apps.get(key)
            if not isinstance(entry, dict) or not entry.get('command'):
                return self._send(400, {'ok': False, 'error': 'app not configured in apps.json'})
            command = entry['command']
            if not isinstance(command, list) or not all(isinstance(x, str) for x in command):
                return self._send(400, {'ok': False, 'error': 'command must be a list of strings'})
            subprocess.Popen(command, cwd=entry.get('cwd') or None, shell=False)
            return self._send(200, {'ok': True, 'launched': key})
        except Exception as exc:
            return self._send(400, {'ok': False, 'error': str(exc)})

    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt % args))

if __name__ == '__main__':
    print(f'LaunchDeck Remote companion listening on port {PORT}.')
    print('Use only on a trusted home Wi-Fi network; do not expose this port to the internet.')
    print('PC address: find your IPv4 address with ipconfig, then enter http://YOUR-IP:8765 on the phone.')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
