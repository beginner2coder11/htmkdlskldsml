LaunchDeck Remote — Windows PC Companion

1. Install Python 3 from python.org if not already installed.
2. Double-click start_server.bat and allow Python through Windows Firewall on your private/home network.
3. On the PC, open Command Prompt and run ipconfig. Find the active Wi-Fi/Ethernet adapter's IPv4 Address.
4. On the phone (same Wi-Fi), enter http://YOUR-PC-IP:8765 in LaunchDeck Remote and tap Connect to PC.
5. Edit apps.json to change the commands each button launches. Commands must be lists of strings. Keep this service on a trusted LAN only.

Security note: this preview companion does not require a PIN and must not be exposed to the public internet. Use only on a trusted home network. A PIN-authenticated version is recommended before wider use.
