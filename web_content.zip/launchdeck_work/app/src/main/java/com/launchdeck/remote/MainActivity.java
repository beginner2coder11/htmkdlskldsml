package com.launchdeck.remote;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_BT = 901;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream btOut;
    private volatile String btStatus = "Bluetooth disconnected";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adapter = BluetoothAdapter.getDefaultAdapter();
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setBackgroundColor(0xFF0B1020);
        web.addJavascriptInterface(new Bridge(), "LaunchDeckNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED);
    }

    private class Bridge {
        @JavascriptInterface public String getBluetoothStatus() { return btStatus; }
        @JavascriptInterface public String getPairedDevices() {
            JSONArray out = new JSONArray();
            if (adapter == null) return out.toString();
            if (!hasBtPermission()) return out.toString();
            try {
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                for (BluetoothDevice d : devices) {
                    JSONObject item = new JSONObject();
                    item.put("name", d.getName() == null ? "Bluetooth device" : d.getName());
                    item.put("address", d.getAddress());
                    out.put(item);
                }
            } catch (Exception ignored) {}
            return out.toString();
        }
        @JavascriptInterface public void openBluetoothSettings() {
            runOnUiThread(() -> startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)));
        }
        @JavascriptInterface public void connectBluetooth(String address) {
            if (adapter == null) { btStatus = "This phone has no Bluetooth adapter"; return; }
            if (!hasBtPermission()) { btStatus = "Bluetooth permission needed"; runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT)); return; }
            io.execute(() -> {
                closeSocket();
                try {
                    if (!adapter.isEnabled()) { btStatus = "Turn Bluetooth on in Android settings"; return; }
                    BluetoothDevice device = adapter.getRemoteDevice(address);
                    btStatus = "Connecting to " + device.getName() + "…";
                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    adapter.cancelDiscovery();
                    socket.connect();
                    btOut = socket.getOutputStream();
                    btStatus = "Bluetooth connected: " + (device.getName() == null ? address : device.getName());
                } catch (Exception e) {
                    closeSocket();
                    btStatus = "Bluetooth connection failed. Pair the PC and check its incoming COM port.";
                }
            });
        }
        @JavascriptInterface public void disconnectBluetooth() { io.execute(() -> { closeSocket(); btStatus = "Bluetooth disconnected"; }); }
        @JavascriptInterface public void sendBluetoothCommand(String json) {
            io.execute(() -> {
                try {
                    if (socket == null || !socket.isConnected() || btOut == null) { btStatus = "Connect Bluetooth to the PC first"; return; }
                    btOut.write((json + "\n").getBytes(StandardCharsets.UTF_8));
                    btOut.flush();
                    btStatus = "Command sent over Bluetooth";
                } catch (Exception e) { closeSocket(); btStatus = "Bluetooth send failed. Reconnect and try again."; }
            });
        }
    }

    private synchronized void closeSocket() {
        try { if (btOut != null) btOut.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        btOut = null; socket = null;
    }

    @Override public void onDestroy() { closeSocket(); io.shutdownNow(); if (web != null) web.destroy(); super.onDestroy(); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
