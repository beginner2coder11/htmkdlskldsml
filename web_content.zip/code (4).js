const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

// Simple in-memory storage for demo purposes
// In a real app, you'd use a database like SQLite or MongoDB
const transactions = [];

const server = http.createServer((req, res) => {
    // Set CORS headers to allow mobile app access
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    // Route: Serve the main HTML page
    if (req.url === '/' || req.url === '/index.html') {
        const filePath = './index.html'; // Make sure your HTML file is named index.html
        const contentType = 'text/html';
        
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(500);
                res.end('Error loading page');
                return;
            }
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
        });
    } 
    // Route: Handle the Load Money API request
    else if (req.url === '/api/load' && req.method === 'POST') {
        let body = '';
        
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                
                // Basic validation
                if (!data.aba || !data.accountNumber || !data.amount) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: false, message: 'Missing required fields' }));
                    return;
                }

                // Simulate processing delay
                setTimeout(() => {
                    // Save transaction
                    const transaction = {
                        id: Date.now(),
                        bankName: data.bankName,
                        aba: data.aba,
                        accountNumber: data.accountNumber,
                        amount: parseFloat(data.amount),
                        timestamp: new Date().toISOString()
                    };
                    transactions.push(transaction);

                    console.log(`Transaction processed: $${transaction.amount} loaded to ${data.bankName}`);

                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                        success: true, 
                        message: 'Funds loaded successfully',
                        transactionId: transaction.id
                    }));
                }, 1000);

            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, message: 'Invalid JSON' }));
            }
        });
    } 
    // Default: 404
    else {
        res.writeHead(404);
        res.end('Not Found');
    }
});

server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log('Ready to package into ZIP for APK conversion.');
});