# LA CITÉ DE LA FOI — Projet Android

Projet Android prêt à être ouvert dans Android Studio.

- Nom : LA CITÉ DE LA FOI
- Devise : Une foi • Une famille • Une mission • Un destin
- Package : com.lacitedelafoi.app
- Version : 1.0.0
- Connexion de démonstration : admin / 1234

Le contenu de l'application est embarqué localement dans `app/src/main/assets`, donc l'application n'a pas besoin du navigateur Chrome pour afficher l'interface. Les membres enregistrés sont stockés localement sur le téléphone via localStorage.

## Créer l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Gradle se synchroniser.
3. Brancher le téléphone Android ou utiliser un émulateur.
4. Run pour tester.
5. Pour l'APK : Build > Build APK(s).

Android Studio utilise Gradle pour construire et empaqueter les applications Android, et Android documente WebView comme méthode pour intégrer une application Web dans une application Android.
