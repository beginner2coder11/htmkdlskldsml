# إصلاح النسخة الاحتياطية — AFRIQUIA FREINS ZEMAMRA

تم تعديل المشروع بحيث زر **تصدير نسخة احتياطية** لا يعتمد على رابط WebView مثل `appassets.androidplatform.net`.

على Android 10 وما بعده:
- يتم إنشاء ملف JSON مباشرة داخل:
  `Downloads/AFRIQUIA/`
- لا تظهر صفحة `appassets.androidplatform.net`.
- اسم الملف يبدأ بـ `AFRIQUIA-BACKUP-`.

على الإصدارات القديمة:
- يستخدم مجلد Downloads مع إذن التخزين عند الحاجة.

المشروع يحتاج Android Studio للبناء إلى APK.
