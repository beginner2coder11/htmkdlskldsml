DIAMOND CONSTRUCTION V2 — BASE-22 ANDROID APK PROJECT

This project wraps the BASE-22 software in the existing Android WebView application. It keeps the same Android application ID as FINAL APK 4, with versionCode 22 so Android can install it as an update. The app loads the bundled page from a local HTTPS asset origin (appassets.androidplatform.net), which supports Firebase Auth and Realtime Database. The screenshot URL `/web/index.html` is served from the bundled `assets/web/index.html` page, with its manifest beside it; `/assets/` remains mapped to the root asset folder. It needs Internet access for cloud sync.

MOBILE CONTROLS
- Mobile Dashboard has a three-dot menu containing the current software's Dashboard sections.
- Portrait and landscape layouts adapt to screen width/height. Forms, fields, buttons, dialogs, tables, and amount values fit or scroll inside their own panel instead of pushing the full page sideways.
- Entry fields and touch buttons have mobile-friendly minimum sizes; wide tables remain readable with in-panel horizontal scrolling.
- Site Dashboard has Back and a site sections menu.
- Other screens have Back, Sync, and Menu controls.
- Android physical Back closes the menu/modal or returns through the screen navigation.
- Payment to Work Transfers is linked from the mobile menu.

BUILD THE APK (free with Android Studio)
1. Install Android Studio on the Windows computer and let it install Android SDK Platform 35 and the Android Gradle Plugin when asked.
2. Extract this ZIP to a permanent folder. In Android Studio, choose Open and select the `project` folder.
3. Wait for Gradle Sync to finish, then select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio creates the test APK at `project/app/build/outputs/apk/debug/app-debug.apk`.
5. Keep the existing APK installed and install this newer APK over it. Do not uninstall the older app first; uninstalling can clear its local WebView data.

DATA SAFETY BEFORE INSTALLING
- Open the current app and use Firebase Sync. Confirm that it shows synced, and save a separate software backup.
- Install BASE-22 over the existing APK (same app ID and higher versionCode). Do not clear app storage or uninstall the old app.
- On first launch, wait for Firebase sync and verify existing sites/payments before entering new records.
- This source package does not include or change business records or Firebase data. No live Firebase account was accessed during packaging.

VALIDATION / LIMITS
- Preserved the FINAL APK 4 Android WebView wrapper, Android package ID, Firebase HTTPS asset host, Internet permission, and WebView persistent storage settings.
- Updated the bundled app page to BASE-22 and added the BASE-22-compatible mobile menu/back controls.
- JavaScript syntax and project/package configuration were checked. This workspace has no Android SDK/Android Studio installation, so a compiled `.apk` could not be produced here; open the included Android Studio project and build it using the steps above.
