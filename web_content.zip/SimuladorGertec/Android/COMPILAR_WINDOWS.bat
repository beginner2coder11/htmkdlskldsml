@echo off
setlocal
cd /d "%~dp0"
echo Compilando o Simulador Terminal Nosso Mercadao...
where java >nul 2>nul
if errorlevel 1 (
  echo Configure JAVA_HOME para o JDK 17 e adicione JAVA_HOME\bin ao PATH.
  pause
  exit /b 1
)
if not exist ".build-tools\gradle-8.9\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; New-Item -ItemType Directory -Force '.build-tools' | Out-Null; $u='https://services.gradle.org/distributions/gradle-8.9-bin.zip'; Invoke-WebRequest -UseBasicParsing $u -OutFile '.build-tools\gradle.zip'; $expected=(Invoke-WebRequest -UseBasicParsing ($u+'.sha256')).Content.Trim(); $actual=(Get-FileHash '.build-tools\gradle.zip' -Algorithm SHA256).Hash; if($actual -ine $expected){throw 'Checksum do Gradle invalido'}; Expand-Archive -Force '.build-tools\gradle.zip' '.build-tools'; Remove-Item '.build-tools\gradle.zip'"
  if errorlevel 1 (
    echo Falha ao preparar Gradle. Verifique internet, proxy e antivirus.
    pause
    exit /b 1
  )
)
call ".build-tools\gradle-8.9\bin\gradle.bat" --no-daemon assembleDebug
if errorlevel 1 (
  echo Falha na compilacao. Confira JDK 17, SDK 35 e local.properties no Android Studio.
  pause
  exit /b 1
)
echo APK gerado: app\build\outputs\apk\debug\app-debug.apk
explorer "app\build\outputs\apk\debug"
pause
