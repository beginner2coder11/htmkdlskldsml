package br.com.nossomercadao.simuladorterminal;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;

public class MainActivity extends ComponentActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private SharedPreferences prefs;
    private boolean pageReady, scannerBusy;
    private String queuedStatus;
    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(new ScanContract(), result -> {
        scannerBusy = false;
        if (result.getContents() != null && result.getContents().matches("[0-9]{1,64}")) {
            prefs.edit().putString("pendingBarcode", result.getContents()).commit(); deliverBarcode();
        } else status(result.getContents() == null ? "Leitura cancelada." : "Código de barras não numérico.");
    });
    private final ActivityResultLauncher<String> permission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
        if (granted) launchScanner();
        else { scannerBusy = false; status("Câmera não autorizada. Libere a permissão nas configurações do aplicativo ou digite o código."); }
    });
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("simulador_terminal", MODE_PRIVATE);
        if (state != null) scannerBusy = state.getBoolean("scannerBusy");
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom()); return insets;
        });
        setContentView(root); root.requestApplyInsets();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new Bridge(), "InventoryAndroid");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse resource = loader.shouldInterceptRequest(request.getUrl());
                if (resource != null) return resource;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return !HOME.equals(request.getUrl().toString()); }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) { pageReady = false; }
            @Override public void onPageFinished(WebView view, String url) {
                if (!HOME.equals(url)) return;
                pageReady = true; deliverBarcode();
                if (queuedStatus != null) { String text = queuedStatus; queuedStatus = null; status(text); }
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){var e=document.getElementById('settings');if(e.style.display==='block'){e.style.display='none';return true;}return false;})()", result -> {
                    if (!"true".equals(result)) new AlertDialog.Builder(MainActivity.this).setMessage("Fechar o terminal de consulta?")
                        .setPositiveButton("Fechar", (d,w) -> finish()).setNegativeButton("Continuar", null).show();
                });
            }
        });
        web.loadUrl(HOME);
    }
    private void status(String text) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (!pageReady) { queuedStatus = text; return; }
            web.evaluateJavascript("window.onNativeStatus&&window.onNativeStatus(" + JSONObject.quote(text) + ");", null);
        });
    }
    private void deliverBarcode() {
        if (!pageReady) return;
        String code = prefs.getString("pendingBarcode", null);
        if (code != null) web.evaluateJavascript("(function(){if(typeof window.onBarcodeScanned!=='function')return false;window.onBarcodeScanned("+JSONObject.quote(code)+");return true;})()", result -> {
            if ("true".equals(result)) prefs.edit().remove("pendingBarcode").apply();
        });
    }
    private void launchScanner() {
        try {
            ScanOptions options = new ScanOptions(); options.setCaptureActivity(ScannerActivity.class);
            options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
            options.setPrompt("Aponte para o código de barras"); options.setBeepEnabled(true);
            options.setOrientationLocked(false); options.setBarcodeImageEnabled(false); scanner.launch(options);
        } catch (Exception e) { scannerBusy = false; status("Falha ao abrir scanner: "+e.getMessage()); }
    }
    private boolean localHost(String host) {
        if (host == null) return false;
        String[] parts = host.split("\\.", -1); if (parts.length != 4) return false;
        int[] n = new int[4];
        for (int i=0; i<4; i++) {
            if (!parts[i].matches("[0-9]{1,3}") || (parts[i].length()>1 && parts[i].charAt(0)=='0')) return false;
            n[i]=Integer.parseInt(parts[i]); if (n[i]>255) return false;
        }
        return n[0]==10 || (n[0]==192 && n[1]==168) || (n[0]==172 && n[1]>=16 && n[1]<=31);
    }
    public class Bridge {
        @JavascriptInterface public String loadConfig() { return prefs.getString("server", ""); }
        @JavascriptInterface public boolean saveConfig(String json) {
            try {
                JSONObject c = new JSONObject(json); int port = Integer.parseInt(c.getString("port"));
                if (!localHost(c.getString("terminalIp")) || !localHost(c.getString("localIp")) || port<1 || port>65535) return false;
                return prefs.edit().putString("server", c.toString()).commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void startScan() {
            runOnUiThread(() -> {
                if (scannerBusy) return; scannerBusy=true;
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) launchScanner();
                else permission.launch(Manifest.permission.CAMERA);
            });
        }
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putBoolean("scannerBusy", scannerBusy); super.onSaveInstanceState(state); }
    @Override protected void onDestroy() { pageReady=false; if(web!=null){web.removeJavascriptInterface("InventoryAndroid");web.destroy();}super.onDestroy(); }
}
