package br.com.nossomercadao.simuladorterminal;
import com.journeyapps.barcodescanner.CaptureActivity;
public class ScannerActivity extends CaptureActivity {}
