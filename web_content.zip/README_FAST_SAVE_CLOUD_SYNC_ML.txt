JAS LAUNDRY ROOM - FAST SAVE & CLOUD SYNC UPDATE

ഈ ZIP-ൽ നിലവിലുള്ള HTML ആപ്പിൽ താഴെ പറയുന്ന മാറ്റങ്ങൾ ചേർത്തിട്ടുണ്ട്:
1. ബിൽ/എഡിറ്റ് മാറ്റങ്ങൾ ആദ്യം localStorage-ൽ ഉടൻ save ചെയ്യുന്നു.
2. Firebase/Firestore save UI-യെ കാത്തിരിപ്പിക്കാതെ background-ൽ നടത്തുന്നു.
3. ഒരേ സമയം പല cloud writes ഓടുന്നത് ഒഴിവാക്കി, അവസാനത്തെ പുതിയ ഡാറ്റ ക്രമത്തിൽ upload ചെയ്യുന്നു.
4. ഇന്റർനെറ്റ് ഇല്ലാത്തപ്പോൾ local save നിലനിർത്തി pending sync അടയാളപ്പെടുത്തുന്നു.
5. Internet തിരികെ വന്നാൽ pending data upload ചെയ്യാൻ ശ്രമിക്കുന്നു.
6. Cloud live listener-ൽ local pending changes ഉണ്ടെങ്കിൽ അവയെ ഉടൻ remote snapshot കൊണ്ട് overwrite ചെയ്യുന്നത് തടയുന്നു.
7. Cloud write failure വന്നാൽ status കാണിക്കുകയും retry delay ക്രമേണ കൂട്ടി വീണ്ടും ശ്രമിക്കുകയും ചെയ്യുന്നു.

പ്രധാന കുറിപ്പ്:
- ഇത് നിലവിലുള്ള Firestore-ന്റെ single-document data architecture തന്നെയാണ് ഉപയോഗിക്കുന്നത്. ഒരേ സമയത്ത് ഒന്നിലധികം ഫോണുകളിൽ ഒരേ റെക്കോർഡ് മാറ്റുമ്പോഴുള്ള conflict/merge പൂർണ്ണമായി പരിഹരിച്ചിട്ടില്ല. അതിനാൽ simultaneous multi-device editing-ന് പൂർണ്ണ data-loss guarantee നൽകാനാവില്ല.
- യഥാർത്ഥ Firebase login, Firestore Rules, Android APK/WebView, രണ്ടാമത്തെ ഫോണിലെ live sync എന്നിവ ഈ runtime-ൽ പരിശോധിക്കാനാവില്ല.
- ഇവിടെ നടത്തിയ പരിശോധന: HTML/JavaScript syntax പരിശോധനയും ZIP integrity പരിശോധനയും.
- പഴയ data clear ചെയ്യുകയോ Firebase collection/document delete ചെയ്യുകയോ ചെയ്തിട്ടില്ല.

ഉപയോഗം: ZIP നിങ്ങളുടെ APK builder-ൽ upload ചെയ്യുക. നിലവിലെ app-இன் data-வை அழிக்க/clear செய்யும் option-ஐ தேர்வு செய்ய வேண்டாம்.
