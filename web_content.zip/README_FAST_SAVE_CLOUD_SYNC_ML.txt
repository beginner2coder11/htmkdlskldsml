JAS LAUNDRY ROOM - LOCAL-FIRST SAVE UPDATE

- Bills and edits are saved to this device's localStorage first.
- Cloud transfer is handled by the Google Apps Script REST connector included in this updated package.
- Offline edits remain local and are retried when internet returns.
- The Google Cloud connector uses one shared JSON snapshot with periodic polling. It is not a transactional database and simultaneous multi-device edits can conflict.
- Configure the Apps Script backend and token using README_GOOGLE_CLOUD_MANUAL_CASH_ML.txt before relying on multi-phone sync.
- Existing local business data is not cleared by the update.
