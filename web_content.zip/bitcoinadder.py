from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add-btc', methods=['POST'])
def add_btc():
    # Get data from the form
    wallet = request.form.get('wallet_address')
    amount = request.form.get('amount')
    server = request.form.get('server')
    
    # Checkboxes might be missing if unchecked
    vpn = "Yes" if 'vpn' in request.form else "No"
    hide_ip = "Yes" if 'hide_ip' in request.form else "No"
    stealth = "Yes" if 'stealth' in request.form else "No"

    # Simulate processing
    result_msg = f"Successfully added {amount} BTC to {wallet} via {server.upper()}."
    
    # In a real app, you would call an API or database here.
    # For now, we just show the result.
    return render_template('result.html', msg=result_msg, details={
        'wallet': wallet,
        'amount': amount,
        'vpn': vpn,
        'ip': hide_ip,
        'stealth': stealth,
        'server': server
    })

if __name__ == '__main__':
    app.run(debug=True)