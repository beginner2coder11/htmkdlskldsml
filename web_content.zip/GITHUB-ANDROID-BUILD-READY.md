# Hotel HR Manager — GitHub Android APK build

This repository is prepared to build a **debug APK** in GitHub Actions. The APK is intended for testing and sideloading; it is not a Play Store release build and is not signed with a private release key.

## Upload the project to GitHub (phone-friendly)

1. Download and extract this ZIP on your phone using a file manager that can extract ZIP files.
2. Open your existing repository: `https://github.com/nassifkaiza-arch/F-B-Manager-`.
3. Upload the **contents inside the extracted folder** to the repository root, preserving folders such as `.github`, `android-wrapper`, and `hrsettings`. Do not upload only the ZIP file, and do not put everything inside an extra nested folder.
4. If GitHub asks whether to replace existing files, make sure you want this cumulative version before confirming. Keep a copy of your current repository first.
5. Open the repository's **Actions** tab. Select **Build Hotel HR Manager Android APK**, tap **Run workflow**, choose the default branch, and run it.
6. Wait for the workflow to finish. If successful, open that run and find **Artifacts** near the bottom. Download `Hotel-HR-Manager-debug-APK`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from the app you used to download/open it.

## Automatic builds

After this workflow is committed on `main` or `master`, changes to the Android wrapper, app source, workflow, or top-level documentation will trigger a build. You can also run it manually from Actions.

## If the build fails

Open the failed run, expand the first red step, and copy the first meaningful `error` or `e:` message. Send that log or a screenshot for diagnosis. Do not guess at the fix from the final generic “build failed” line.

## Important limitations

- A successful build confirms compilation and packaging, not that every feature has been tested on a physical phone.
- This project currently builds a **debug** APK. Do not publish it as a production Play Store release.
- A future update normally must use a compatible application ID and signing key to update an already-installed app without uninstalling it. Keep the release signing key private and backed up.
- GitHub Actions builds the Android wrapper in `android-wrapper/`. The editable web app is also in `hrsettings/`; the Android wrapper serves its bundled copy at `android-wrapper/app/src/main/assets/public/`.
- The current workflow checks that both project and bundled app files exist; it does not automatically copy `hrsettings/` over the Android bundled assets. If you edit `hrsettings/` separately, copy the matching `app.js`, `index.html`, and `style.css` into the Android assets folder before building, or the APK could contain older web assets.
- Cloud backup, AI service, account authentication, and notification integrations may require separate provider configuration and should not be assumed active just because the APK compiles.
