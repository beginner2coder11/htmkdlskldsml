HOTEL HR MANAGER — NATIVE FILE EXPORT FIX

This package contains the complete Android wrapper source and web assets.
Package ID: com.hotelhrmanager.app
Version: 1.2.1 (versionCode 4)

IMPORTANT ABOUT APK FORGE PREVIEW
The APK Forge Preview is a web preview. It does not expose the Android JavaScript bridge named HRAndroid, so it cannot open Android's native Save As dialog. In that preview, exports may only request a browser download; that message is not proof that a file was saved.

THE NATIVE APK SOURCE
The Android wrapper includes MainActivity.kt with:
- HRAndroid.saveFile(dataUrl, filename, mimeType)
- Android ACTION_CREATE_DOCUMENT (system Save As picker)
- file output through ContentResolver
- success/failure callback to window.hrNativeFileSaved
- Android file picker support for imports

BUILD REQUIREMENTS
Build the android-wrapper directory as an Android Gradle project in an environment that supports Android Gradle builds. Do not build only hrsettings/index.html or the web preview. Keep applicationId com.hotelhrmanager.app and sign the update with the same signing key as the currently installed APK if you want Android to install it as an update without uninstalling.

TEST AFTER INSTALLING THE BUILT APK
1. Open Reports & backup.
2. Tap Download full local backup; choose a folder/name in Android's Save As picker.
3. Verify the JSON file exists in the selected folder.
4. Tap Download all records as Excel; choose a folder and verify the XLSX file exists. If the Excel library is unavailable, the app may export CSV instead.
5. Test a report CSV/Excel export and JSON restore using a non-critical test backup first.

Do not clear app data or uninstall the existing app until a backup has been saved and verified. A ZIP is source code, not an APK, and cannot itself enable native file saving inside the APK Forge Preview.
