/* KEA HSE Gate Pass - app logic */
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ld=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){toast("Storage full - save a backup and delete old passes");return false}};
const K={cfg:"keaGPcfg",reg:"keaGPreg",cnt:"keaGPcnt",logo:"keaGPlogo",back:"keaGPback"};
let CFG=Object.assign({},DEFAULT_CFG,ld(K.cfg,{})),REG=ld(K.reg,[]),CNT=ld(K.cnt,0),LOGO=ld(K.logo,"")||DEFAULT_LOGO,BACK=ld(K.back,"");
const PAL=["#2E7D32","#C55A11","#1F4E78","#7B1FA2","#C00000","#00838F","#5D4037","#455A64"];
const AVATAR="data:image/svg+xml;utf8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 160"><rect width="120" height="160" fill="#e6e9ee"/><circle cx="60" cy="62" r="26" fill="#9aa5b4"/><path d="M12 160c0-34 22-52 48-52s48 18 48 52z" fill="#9aa5b4"/></svg>');
const fd=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const today=()=>fd(new Date());
const addDays=(s,n)=>{const d=new Date(s+"T12:00:00");d.setDate(d.getDate()+n);return fd(d)};
const dmy=s=>s?s.split("-").reverse().join("-"):"";
let tmr;function toast(m){const t=$("toast");t.textContent=m;t.classList.add("on");clearTimeout(tmr);tmr=setTimeout(()=>t.classList.remove("on"),2600)}
const fmtNo=(n,y)=>CFG.prefix+"-"+y+"-"+String(n).padStart(4,"0");
const catColor=c=>PAL[Math.max(0,CFG.categories.indexOf(c))%PAL.length];
function maskId(s,m){if(!s||m=="hide")return "";if(m!="masked")return s;const n=(s.match(/\d/g)||[]).length;let i=0;return s.replace(/\d/g,d=>{i++;return(i<=3||i==n)?d:"X"})}

/* ---------- current pass ---------- */
const blank=()=>({id:null,no:"",cat:CFG.categories[0]||"",comp:"",name:"",idno:"",nat:"",des:"",mask:"full",from:today(),to:addDays(today(),30),val:"30",photo:""});
let cur=blank();
function nextNo(){return fmtNo(CNT+1,(cur.from||today()).slice(0,4))}
function recView(){return Object.assign({},cur,{no:cur.no||nextNo()})}

/* ---------- card templates ---------- */
function frontHTML(r){
 const nm=r.name||"WORKER NAME",fs=nm.length>30?13:nm.length>22?15:19,idv=maskId(r.idno,r.mask);
 return `<div class="card"><div class="c-top"><img src="${esc(LOGO)}"></div><div class="c-band">HSE GATE PASS</div>
 <div class="c-cat" style="background:${catColor(r.cat)}">${esc(r.cat)}</div>
 <div class="c-photo" style="background-image:url('${r.photo||AVATAR}')"></div>
 <div class="c-name" style="font-size:${fs}px">${esc(nm)}</div><div class="c-comp">${esc(r.comp||"COMPANY NAME")}</div>${r.des?`<div class="c-des">${esc(r.des)}</div>`:""}
 <div class="c-info">${idv?`<div><span>Emirates ID</span><b>${esc(idv)}</b></div>`:""}${r.nat?`<div><span>Nationality</span><b>${esc(r.nat)}</b></div>`:""}<div><span>Valid from</span><b>${dmy(r.from)}</b></div><div><span>Valid until</span><b>${dmy(r.to)}</b></div><div><span>Site</span><b>${esc(CFG.site)}</b></div></div>
 <div class="c-no">${esc(r.no)}</div>
 <div class="c-foot"><div class="qr" data-q="${esc(r.no)}"></div><div class="c-sg"><i></i>HSE Officer${CFG.hseName?"<br><b>"+esc(CFG.hseName)+"</b>":""}</div></div></div>`}
function backHTML(){
 if(BACK)return `<div class="card bimg" style="background-image:url('${BACK}')"></div>`;
 return `<div class="card back"><div class="c-top" style="height:56px"><img src="${esc(LOGO)}" style="max-height:42px"></div><div class="b-title">HSE RULES &amp; REGULATIONS</div>
 <ol class="b-rules">${CFG.rules.map(x=>`<li>${esc(x)}</li>`).join("")}</ol>
 <div class="b-emg"><b>EMERGENCY</b>Police 999 &nbsp;|&nbsp; Ambulance 998 &nbsp;|&nbsp; Fire 997</div>
 <div class="b-site">${esc(CFG.assembly)}<br>HSE: ${esc(CFG.hseName)}${CFG.hsePhone?" - "+esc(CFG.hsePhone):""}</div>
 <div class="b-foot">Property of KEA Building Contracting. If found, please return to the site HSE office.</div></div>`}
function genQR(root){root.querySelectorAll(".qr").forEach(el=>{el.innerHTML="";if(typeof QRCode=="undefined"||!el.dataset.q){el.style.visibility="hidden";return}try{new QRCode(el,{text:el.dataset.q,width:116,height:116,correctLevel:QRCode.CorrectLevel.M})}catch(e){el.style.visibility="hidden"}})}
function renderPrev(){const r=recView();$("pvFront").innerHTML='<div class="cwrap">'+frontHTML(r)+"</div>";$("pvBack").innerHTML='<div class="cwrap">'+backHTML()+"</div>";genQR($("pvFront"))}

/* ---------- form binding ---------- */
const F={fCat:"cat",fComp:"comp",fName:"name",fIdNo:"idno",fNat:"nat",fDes:"des",fMask:"mask",fFrom:"from",fTo:"to"};
function fillForm(){Object.keys(F).forEach(i=>$(i).value=cur[F[i]]||"");$("fVal").value=cur.val||"30";renderPrev()}
function fillLists(){$("fCat").innerHTML=CFG.categories.map(c=>`<option>${esc(c)}</option>`).join("");
 const u=k=>[...new Set(REG.map(r=>r[k]).filter(Boolean))];$("dlComp").innerHTML=u("comp").map(c=>`<option value="${esc(c)}">`).join("");$("dlDes").innerHTML=u("des").map(c=>`<option value="${esc(c)}">`).join("")}
Object.keys(F).forEach(i=>$(i).addEventListener("input",()=>{cur[F[i]]=$(i).value;if(i=="fFrom"||i=="fVal")applyVal();renderPrev()}));
$("fVal").addEventListener("change",()=>{cur.val=$("fVal").value;applyVal();renderPrev()});
$("fTo").addEventListener("input",()=>{});
function applyVal(){if(!cur.from)return;cur.to=addDays(cur.from,+$("fVal").value||30);$("fTo").value=cur.to}

/* ---------- ID image + photo crop ---------- */
let IDimg=null,box={x:.04,y:.26,w:.27};
function loadID(file){if(!file)return;const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const m=1800,k=Math.min(1,m/im.width),c=document.createElement("canvas");c.width=im.width*k;c.height=im.height*k;c.getContext("2d").drawImage(im,0,0,c.width,c.height);setID(c.toDataURL("image/jpeg",.92))};im.src=fr.result};fr.readAsDataURL(file)}
function setID(src){const im=new Image();im.onload=()=>{IDimg=im;$("idImg").src=src;$("idArea").hidden=false;box={x:.04,y:.26,w:.27};drawBox();applyCrop();tryFace().then(()=>{drawBox();applyCrop()});if(navigator.onLine)runOCR();else showMsg("Offline: type the details manually. Photo is cropped automatically.",1)};im.src=src}
function hBox(){return box.w*IDimg.naturalWidth*(4/3)/IDimg.naturalHeight}
function clampBox(){box.w=Math.min(Math.max(box.w,.08),1);if(hBox()>1)box.w=IDimg.naturalHeight/(IDimg.naturalWidth*4/3);box.x=Math.min(Math.max(box.x,0),1-box.w);box.y=Math.min(Math.max(box.y,0),1-hBox())}
function drawBox(){if(!IDimg)return;clampBox();const b=$("cropBox").style;b.left=box.x*100+"%";b.top=box.y*100+"%";b.width=box.w*100+"%";b.height=hBox()*100+"%";$("sz").value=Math.round(box.w*100)}
function applyCrop(){if(!IDimg)return;const c=document.createElement("canvas");c.width=240;c.height=320;const iw=IDimg.naturalWidth,ih=IDimg.naturalHeight;
 c.getContext("2d").drawImage(IDimg,box.x*iw,box.y*ih,box.w*iw,box.w*iw*4/3,0,0,240,320);cur.photo=c.toDataURL("image/jpeg",.88);renderPrev()}
async function tryFace(){try{if(!("FaceDetector" in window))return;const f=await new FaceDetector({fastMode:true}).detect(IDimg);if(!f.length)return;const b=f.sort((a,c)=>c.boundingBox.width-a.boundingBox.width)[0].boundingBox,iw=IDimg.naturalWidth,ih=IDimg.naturalHeight,cw=b.width*1.9,ch=cw*4/3;box.w=cw/iw;box.x=(b.x+b.width/2-cw/2)/iw;box.y=(b.y+b.height/2-ch/2)/ih}catch(e){}}
(function(){let m=null;const w=$("idWrap");
 const pt=e=>{const r=w.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height}};
 $("cropBox").addEventListener("pointerdown",e=>{if(e.target.id=="hnd")return;m={t:"mv",p:pt(e),b:{...box}};e.currentTarget.setPointerCapture(e.pointerId);e.preventDefault()});
 $("hnd").addEventListener("pointerdown",e=>{m={t:"rs"};e.target.setPointerCapture(e.pointerId);e.stopPropagation();e.preventDefault()});
 const mv=e=>{if(!m||!IDimg)return;const p=pt(e);if(m.t=="mv"){box.x=m.b.x+p.x-m.p.x;box.y=m.b.y+p.y-m.p.y}else box.w=p.x-box.x;drawBox();applyCrop()};
 $("cropBox").addEventListener("pointermove",mv);$("hnd").addEventListener("pointermove",mv);
 ["pointerup","pointercancel"].forEach(n=>{$("cropBox").addEventListener(n,()=>m=null);$("hnd").addEventListener(n,()=>m=null)});
 $("sz").addEventListener("input",()=>{if(!IDimg)return;const cx=box.x+box.w/2,cy=box.y+hBox()/2;box.w=$("sz").value/100;box.x=cx-box.w/2;box.y=cy-hBox()/2;drawBox();applyCrop()})})();

/* ---------- OCR (online, Tesseract.js) ---------- */
function showMsg(t,err){const m=$("ocrMsg");m.hidden=!t;m.textContent=t||"";m.className="msg"+(err?" err":"")}
function loadScript(u){return new Promise((ok,no)=>{if(window.Tesseract)return ok();const s=document.createElement("script");s.src=u;s.onload=ok;s.onerror=()=>no(new Error("load"));document.head.appendChild(s)})}
async function runOCR(){if(!IDimg)return;if(!navigator.onLine){showMsg("No internet: type the details manually.",1);return}
 showMsg("Reading ID details... (first time takes a little longer)");
 try{await loadScript("https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js");
  const c=document.createElement("canvas"),k=Math.min(2,2000/IDimg.naturalWidth);c.width=IDimg.naturalWidth*k;c.height=IDimg.naturalHeight*k;const x=c.getContext("2d");x.filter="grayscale(1) contrast(1.35)";x.drawImage(IDimg,0,0,c.width,c.height);
  const w=await Tesseract.createWorker("eng",1,{logger:m=>{if(m.status=="recognizing text")showMsg("Reading ID details... "+Math.round(m.progress*100)+"%")}});
  const {data}=await w.recognize(c);await w.terminate();parseID(data.text)}
 catch(e){showMsg("Could not read the ID automatically. Please type the details (photo is already cropped).",1)}}
function parseID(t){const o={};let m=t.match(/784[\s\-.]?(\d{4})[\s\-.]?(\d{7})[\s\-.]?(\d)/);if(m)o.idno=`784-${m[1]}-${m[2]}-${m[3]}`;
 m=t.match(/Name\s*[:\-.]?\s*([A-Za-z][A-Za-z .'\-]{2,})/i);if(m)o.name=m[1].replace(/\s+/g," ").trim().toUpperCase();
 m=t.match(/Nationality\s*[:\-.]?\s*([A-Za-z]{3,})/i);if(m)o.nat=m[1].trim();
 let n=0;if(o.idno){cur.idno=o.idno;n++}if(o.name){cur.name=o.name;n++}if(o.nat){cur.nat=o.nat;n++}
 fillForm();showMsg(n?`Read ${n} detail(s) from the ID. Please check name, ID number and nationality before issuing.`:"Could not find details on this image. Please type them manually.",!n)}

/* ---------- camera ---------- */
let stream=null;
async function openCam(){if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return $("fileCam").click();
 try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920}},audio:false});$("vid").srcObject=stream;$("camModal").hidden=false}catch(e){$("fileCam").click()}}
function closeCam(){if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;$("camModal").hidden=true}
$("bCam").onclick=openCam;$("bCamX").onclick=closeCam;
$("bSnap").onclick=()=>{const v=$("vid");if(!v.videoWidth)return;const c=document.createElement("canvas");c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0);closeCam();setID(c.toDataURL("image/jpeg",.92))};
$("bUp").onclick=()=>$("fileUp").click();$("fileUp").onchange=e=>{loadID(e.target.files[0]);e.target.value=""};$("fileCam").onchange=e=>{loadID(e.target.files[0]);e.target.value=""};
$("bOcr").onclick=runOCR;

/* ---------- issue / print / png ---------- */
function snap(){const r={...cur};delete r.val;return r}
function issue(){if(!cur.name.trim()||!cur.comp.trim()){toast("Enter worker name and company name");return false}
 if(!cur.photo&&!confirm("No photo yet. Issue pass without photo?"))return false;
 if(!cur.id){CNT++;cur.id=Date.now();cur.no=fmtNo(CNT,(cur.from||today()).slice(0,4));cur.issued=today();REG.push(snap());sv(K.cnt,CNT)}
 else{const i=REG.findIndex(x=>x.id==cur.id);if(i>=0)REG[i]=Object.assign(REG[i],snap())}
 if(!sv(K.reg,REG))return false;fillLists();renderPrev();renderReg();toast("Pass "+cur.no+" saved");return true}
$("bIssue").onclick=issue;
$("bPrint").onclick=()=>{if(!issue())return;const r=recView();$("printArea").innerHTML='<div class="cwrap">'+frontHTML(r)+'</div><div class="cwrap">'+backHTML()+"</div>";genQR($("printArea"));setTimeout(()=>window.print(),400)};
$("bPng").onclick=async()=>{if(!issue())return;if(typeof html2canvas=="undefined")return toast("PNG needs internet. Use Print / Save PDF instead.");
 for(const [id,nm] of [["pvFront","front"],["pvBack","back"]]){const c=await html2canvas($(id).querySelector(".card"),{scale:3,backgroundColor:null,useCORS:true});
  await new Promise(ok=>c.toBlob(b=>{const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=cur.no+"_"+nm+".png";a.click();setTimeout(ok,300)}))}};
$("bNew").onclick=()=>{cur=blank();IDimg=null;$("idArea").hidden=true;showMsg("");fillForm()};
$("bNext").onclick=()=>{const k={cat:cur.cat,comp:cur.comp,des:cur.des,mask:cur.mask,from:cur.from,to:cur.to,val:cur.val};cur=Object.assign(blank(),k);IDimg=null;$("idArea").hidden=true;showMsg("");fillForm();window.scrollTo(0,0)};

/* ---------- register ---------- */
const st=r=>r.to<today()?"Expired":"Active";
function renderReg(){const q=($("rq").value||"").toLowerCase(),c=$("rc").value;
 const cs=[...new Set(REG.map(r=>r.comp))].sort();$("rc").innerHTML='<option value="">All companies</option>'+cs.map(x=>`<option${x==c?" selected":""}>${esc(x)}</option>`).join("");
 const k=(l,v)=>`<div class="kpi"><span>${l}</span><b>${v}</b></div>`;
 $("kpis").innerHTML=k("TOTAL ISSUED",REG.length)+k("ACTIVE",REG.filter(r=>st(r)=="Active").length)+k("EXPIRED",REG.filter(r=>st(r)=="Expired").length)+k("COMPANIES",cs.length)+k("ISSUED TODAY",REG.filter(r=>r.issued==today()).length);
 const rows=REG.map((r,i)=>[r,i]).filter(([r])=>(!c||r.comp==c)&&(!q||(r.no+r.name+r.comp).toLowerCase().includes(q))).reverse();
 $("rb").innerHTML=rows.map(([r,i],n)=>`<tr><td>${n+1}</td><td><b>${esc(r.no)}</b></td><td>${r.photo?`<img src="${r.photo}">`:""}</td><td>${esc(r.name)}</td><td>${esc(r.comp)}</td><td>${esc(r.cat)}</td><td>${dmy(r.issued)}</td><td>${dmy(r.to)}</td><td class="${st(r)=="Active"?"ok":"bad"}">${st(r)}</td><td><button class="btn" onclick="openRec(${i})">Open / Reprint</button> <button class="btn r" onclick="delRec(${i})">X</button></td></tr>`).join("")||'<tr><td colspan="10">No passes yet</td></tr>';
 $("cnt").textContent=CNT}
$("rq").oninput=renderReg;$("rc").onchange=renderReg;
function openRec(i){cur=Object.assign(blank(),REG[i],{val:"30"});IDimg=null;$("idArea").hidden=true;showMsg("");fillForm();tab("issue");window.scrollTo(0,0)}
function delRec(i){if(confirm("Delete pass "+REG[i].no+"? The number will not be reused.")){REG.splice(i,1);sv(K.reg,REG);fillLists();renderReg()}}
function dl(n,m,d){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([d],{type:m}));a.download=n;a.click()}
$("bCsv").onclick=()=>{const h=["Pass No","Name","Emirates ID","Nationality","Company","Category","Designation","Site","Issued","Valid From","Valid Until","Status"];
 const rows=REG.map(r=>[r.no,r.name,r.idno,r.nat,r.comp,r.cat,r.des,CFG.site,r.issued,r.from,r.to,st(r)]);
 dl("KEA_HSE_Gate_Pass_Register_"+today()+".csv","text/csv","\ufeff"+[h,...rows].map(r=>r.map(c=>'"'+String(c==null?"":c).replace(/"/g,'""')+'"').join(",")).join("\n"))};
$("bBak").onclick=()=>dl("KEA_Gate_Pass_backup_"+today()+".json","application/json",JSON.stringify({REG,CNT,CFG,LOGO:LOGO==DEFAULT_LOGO?"":LOGO,BACK}));
$("bRes").onclick=()=>$("fileRes").click();
$("fileRes").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.REG))throw 0;REG=d.REG;CNT=d.CNT||REG.length;CFG=Object.assign({},DEFAULT_CFG,d.CFG||{});LOGO=d.LOGO||DEFAULT_LOGO;BACK=d.BACK||"";sv(K.reg,REG);sv(K.cnt,CNT);sv(K.cfg,CFG);sv(K.logo,d.LOGO||"");sv(K.back,BACK);initAll();toast("Backup restored")}catch(x){alert("Not a valid backup file")}};r.readAsText(f);e.target.value=""};

/* ---------- settings ---------- */
function fillSet(){$("sPre").value=CFG.prefix;$("sSite").value=CFG.site;$("sHse").value=CFG.hseName;$("sPhone").value=CFG.hsePhone;$("sAsm").value=CFG.assembly;$("sCat").value=CFG.categories.join("\n");$("sRules").value=CFG.rules.join("\n");$("logoPrev").src=LOGO;$("hdLogo").src=LOGO;$("cnt").textContent=CNT}
$("bSave").onclick=()=>{const L=t=>t.split("\n").map(x=>x.trim()).filter(Boolean);
 CFG={prefix:$("sPre").value.trim()||"KEA-GP",site:$("sSite").value.trim(),hseName:$("sHse").value.trim(),hsePhone:$("sPhone").value.trim(),assembly:$("sAsm").value.trim(),categories:L($("sCat").value),rules:L($("sRules").value)};
 if(!CFG.categories.length)CFG.categories=DEFAULT_CFG.categories.slice();sv(K.cfg,CFG);fillLists();if(!CFG.categories.includes(cur.cat))cur.cat=CFG.categories[0];fillForm();toast("Settings saved")};
$("bDef").onclick=()=>{if(confirm("Reset all settings to defaults? Issued passes are kept.")){CFG=Object.assign({},DEFAULT_CFG);sv(K.cfg,CFG);fillSet();fillLists();fillForm()}};
function readImg(file,max,cb){if(!file)return;const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,max/im.width),c=document.createElement("canvas");c.width=im.width*k;c.height=im.height*k;const x=c.getContext("2d");c.getContext("2d").drawImage(im,0,0,c.width,c.height);cb(file.type=="image/png"?c.toDataURL("image/png"):c.toDataURL("image/jpeg",.92))};im.src=fr.result};fr.readAsDataURL(file)}
$("bLogo").onclick=()=>$("fileLogo").click();$("fileLogo").onchange=e=>{readImg(e.target.files[0],700,d=>{LOGO=d;sv(K.logo,d);fillSet();renderPrev();renderReg();toast("Logo updated")});e.target.value=""};
$("bLogoR").onclick=()=>{LOGO=DEFAULT_LOGO;sv(K.logo,"");fillSet();renderPrev()};
$("bBack").onclick=()=>$("fileBack").click();$("fileBack").onchange=e=>{readImg(e.target.files[0],900,d=>{BACK=d;sv(K.back,d);renderPrev();toast("Back page updated")});e.target.value=""};
$("bBackR").onclick=()=>{BACK="";sv(K.back,"");renderPrev()};
$("bCnt").onclick=()=>{const v=prompt("Set last issued number (next pass will be this + 1):",CNT);if(v==null)return;const n=parseInt(v);if(isNaN(n)||n<0)return;CNT=n;sv(K.cnt,CNT);fillSet();renderPrev()};

/* ---------- tabs / init ---------- */
function tab(t){document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.t==t));["issue","reg","set"].forEach(x=>$("t-"+x).hidden=x!=t);if(t=="reg")renderReg();if(t=="set")fillSet()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>tab(b.dataset.t));
function net(){const o=navigator.onLine;$("net").textContent=o?"Online - ID reading and QR ready":"Offline - type details manually";$("net").className="net "+(o?"on":"off")}
addEventListener("online",net);addEventListener("offline",net);
function initAll(){fillSet();fillLists();cur=blank();fillForm();renderReg();net()}
initAll();
