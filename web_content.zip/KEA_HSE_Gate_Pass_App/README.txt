KEA HSE GATE PASS - APP PACKAGE
================================
1. Unzip the whole folder (keep the folder structure).
2. Open index.html in Chrome (phone or laptop). For the camera and ID reading, host the folder online
   (any web hosting / Netlify / GitHub Pages) or open it while connected to the internet.

How it works
  - Issue Pass tab: upload or scan the Emirates ID (front). The photo is cut out automatically; drag the
    orange box to fix it. Name / ID number / nationality are read when online - always check them.
  - Type the company name and designation, choose category and validity.
  - "Issue pass & save" gives a unique number (KEA-GP-2026-0001, 0002 ...). Print / Save PDF prints the
    front and back at card size (54 x 85.6 mm). Download PNG saves front and back images.
  - "Next pass (same company)" keeps the company and validity for the next worker.
  - Register tab: all passes, search, expiry status, reprint, Excel (.csv), backup and restore.
  - Settings tab: company logo upload, back page rules/design, categories, site, HSE name and phone.

Folders
  index.html         start page
  css/style.css      card design and print layout
  js/app.js          app logic
  js/config.js       default settings (also editable in the app)
  js/logo.js         default KEA logo (replace it from Settings > Company logo)
  assets/            icons and logo copy
  manifest.json      "Add to Home Screen" support

Online parts (loaded from the internet when available): ID text reading (Tesseract.js), QR code, PNG export.
Without internet the pass still works: type the details manually and use Print / Save PDF.

Privacy: everything is stored only in the browser of the device that is used (passes, photos, settings).
The Emirates ID image itself is NOT saved - only the cropped photo and the typed/checked details.
Use Save backup regularly.
