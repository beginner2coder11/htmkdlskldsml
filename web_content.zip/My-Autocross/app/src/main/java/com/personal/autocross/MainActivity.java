package com.personal.autocross;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Offline, private app. Only bundled pages load inside the WebView. */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://app.autocross.local";
    private static final int PICK_MEDIA = 100, SAVE_BACKUP = 101;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingBackup;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff101719);
        getWindow().setNavigationBarColor(0xff101719);
        web = new WebView(this);
        web.setBackgroundColor(0xff101719);
        // Android 15 draws edge to edge; pad content away from bars and cutouts.
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                         insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isLocal(uri)) return false;
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ex) { Toast.makeText(MainActivity.this, "No browser installed", Toast.LENGTH_SHORT).show(); }
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!isLocal(request.getUrl())) return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                String path = request.getUrl().getPath();
                String name = path == null || path.equals("/") ? "index.html" : path.substring(1);
                if (name.contains("..") || name.contains("/")) return missing();
                String mime = name.endsWith(".js") ? "application/javascript" : name.endsWith(".json") ? "application/json" : name.endsWith(".svg") ? "image/svg+xml" : "text/html";
                try { return new WebResourceResponse(mime, "UTF-8", getAssets().open(name)); }
                catch (IOException ex) { return missing(); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                String[] types = params.getAcceptTypes();
                if (types.length > 0 && !types[0].isEmpty()) pick.putExtra(Intent.EXTRA_MIME_TYPES, types);
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(pick, PICK_MEDIA); }
                catch (ActivityNotFoundException ex) { callback.onReceiveValue(null); fileCallback = null; Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_LONG).show(); }
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Continue", (dialog, which) -> result.confirm())
                    .setNegativeButton("Cancel", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel()).show();
                return true;
            }
        });
        web.loadUrl(ORIGIN + "/");
    }
    private boolean isLocal(Uri uri) { return "https".equals(uri.getScheme()) && "app.autocross.local".equals(uri.getHost()); }
    private WebResourceResponse missing() { return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0])); }
    public final class BackupBridge {
        @JavascriptInterface public void save(String json) {
            runOnUiThread(() -> {
                if (pendingBackup != null) { Toast.makeText(MainActivity.this, "Finish the current backup first", Toast.LENGTH_SHORT).show(); return; }
                pendingBackup = json;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/json");
                save.putExtra(Intent.EXTRA_TITLE, "autocross-backup.json");
                try { startActivityForResult(save, SAVE_BACKUP); }
                catch (ActivityNotFoundException ex) { pendingBackup = null; Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_LONG).show(); }
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_MEDIA && fileCallback != null) {
            Uri[] selected = null;
            if (result == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    selected = new Uri[data.getClipData().getItemCount()];
                    for (int i = 0; i < selected.length; i++) selected[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) selected = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(selected); fileCallback = null;
        }
        if (request == SAVE_BACKUP) {
            String content = pendingBackup; pendingBackup = null;
            if (result == RESULT_OK && data != null && data.getData() != null && content != null) {
                Uri destination = data.getData();
                new Thread(() -> {
                    try (OutputStream out = getContentResolver().openOutputStream(destination)) {
                        if (out == null) throw new IOException("Unable to open destination");
                        out.write(content.getBytes(StandardCharsets.UTF_8));
                        runOnUiThread(() -> Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show());
                    } catch (IOException ex) {
                        runOnUiThread(() -> Toast.makeText(this, "Backup could not be saved", Toast.LENGTH_LONG).show());
                    }
                }).start();
            }
        }
    }
    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else new AlertDialog.Builder(this).setMessage("Close My Autocross?")
             .setPositiveButton("Close", (dialog, which) -> finish())
             .setNegativeButton("Stay", null).show();
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        web.removeJavascriptInterface("AndroidBackup"); web.destroy();
        super.onDestroy();
    }
}
