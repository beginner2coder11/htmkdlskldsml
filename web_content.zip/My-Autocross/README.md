# My Autocross for Android

A private offline Android app with an editable driver and car home page, photo/video gallery, dated event schedule with past-event results, and a TikTok profile link. Uses the Android system file picker; no broad device-storage permission or online account is needed. Photos, videos, and edits persist in app-private WebView storage. Uninstalling the app or clearing its data deletes this content; use Edit > Home > Export backup first.

## Build an APK

Requirements: Android Studio, JDK 17 or 21, Android SDK platform 35, and Gradle 8.9. Dependencies require an internet connection for the first build.

1. Open this folder in Android Studio.
2. If Gradle is not configured, install Gradle 8.9 and run `gradle wrapper --gradle-version 8.9` from this folder. This source archive does not include a Gradle wrapper binary.
3. Let Android Studio sync the project and install SDK platform 35 when prompted.
4. Choose Build > Build App Bundle(s) / APK(s) > Build APK(s), or run `./gradlew assembleDebug` after generating the wrapper.
5. The installable development APK is at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your Android device, open it, and allow installation from that source when Android asks.

Minimum supported Android version: Android 8.0. Keep Android System WebView updated. To update an installed APK without deleting content, use the same application ID and signing key; retain the build machine's debug signing key for development updates or configure your own release signing key.

## Use

Open Menu > Edit. On Home, set your name, bio, driver picture, car picture, car details, and TikTok profile URL. On Gallery, select one or more photos/videos, add a caption, and upload. On Schedule, add or edit an event and enter its finishing place. Once its date is before today (device-local date), it appears under Past events & results. If a past event has no entered place, it shows Result pending. Tap Done editing to view your pages.

Export backup saves a JSON document through the system file picker, including your media. Restore replaces the current content after confirmation. Large video collections can require substantial free memory and disk space during export.

## Verification status

The bundled JavaScript passes Node syntax checks. The Android project has not been compiled, installed, or tested on a device: the workspace has no Android SDK or Gradle, and build-tool downloads could not complete. This is source code, not a built APK.
