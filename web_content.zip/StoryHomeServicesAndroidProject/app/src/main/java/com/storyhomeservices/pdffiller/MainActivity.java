package com.storyhomeservices.pdffiller;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int CREATE_PDF_REQUEST = 4102;
    private WebView webView;
    private byte[] pendingPdf;
    private String pendingName = "completed.pdf";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SaveBridge(), "AndroidSave");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class SaveBridge {
        @JavascriptInterface public void savePdf(String base64, String filename) {
            runOnUiThread(() -> {
                try {
                    pendingPdf = Base64.decode(base64, Base64.DEFAULT);
                    pendingName = filename == null || filename.trim().isEmpty() ? "completed.pdf" : filename;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(intent, CREATE_PDF_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open folder picker.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_PDF_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdf != null) {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new Exception("No output stream");
                    out.write(pendingPdf);
                    out.flush();
                    Toast.makeText(this, "PDF saved successfully.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not save PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingPdf = null;
        }
    }

    @Override public void onBackPressed() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Exit Story Home Services PDF Filler?")
            .setMessage("Are you sure you want to exit the app?")
            .setNegativeButton("Stay", (d, w) -> d.dismiss())
            .setPositiveButton("Exit", (d, w) -> finish())
            .show();
    }
}
