/* Story Home Services PDF Filler. PDF.js and pdf-lib are loaded from CDN. */
if(window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
const DB_NAME='shs-pdf-filler', STORE='documents'; let db, docs=[], activeDoc=null, pdfDoc=null, pageNum=1, zoom=1, selectedField=null, signatureDirty=false;
const $=id=>document.getElementById(id);
function toast(s){const t=$('toast');t.textContent=s;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function req(p){return new Promise((resolve,reject)=>{p.onsuccess=()=>resolve(p.result);p.onerror=()=>reject(p.error)})}
async function allDocs(){docs=await req(db.transaction(STORE).objectStore(STORE).getAll());renderLibrary();populateSelects()}
async function putDoc(d){await req(db.transaction(STORE,'readwrite').objectStore(STORE).put(d));await allDocs()}
async function removeDoc(id){await req(db.transaction(STORE,'readwrite').objectStore(STORE).delete(id));await allDocs();toast('PDF removed from this device')}
function uid(){return 'd'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function bytesToB64(buf){let s='';const a=new Uint8Array(buf);for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode(...a.subarray(i,i+0x8000));return btoa(s)}
function b64ToBytes(s){const bin=atob(s),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a}
function renderLibrary(){const root=$('libraryList');root.innerHTML='';if(!docs.length){root.innerHTML='<div class="empty">No PDFs yet. Add a PDF to get started.</div>';return}docs.sort((a,b)=>b.created-a.created).forEach(d=>{const card=document.createElement('div');card.className='doc-card';const left=document.createElement('div');left.innerHTML=`<div class="doc-title"></div><div class="doc-meta">${d.fields?.length||0} saved fields · ${new Date(d.created).toLocaleDateString()}</div>`;left.querySelector('.doc-title').textContent=d.name;const actions=document.createElement('div');actions.className='doc-actions';[['Edit fields',()=>openEditor(d.id)],['Fill',()=>{ $('fillDoc').value=d.id;loadFill()}],['Delete',()=>{if(confirm('Delete this PDF and its saved field layout from this device?'))removeDoc(d.id)}]].forEach(([label,fn])=>{const b=document.createElement('button');b.textContent=label;b.onclick=fn;actions.append(b)});card.append(left,actions);root.append(card)})}
function populateSelects(){['editorDoc','fillDoc'].forEach(id=>{const s=$(id),v=s.value;s.innerHTML=id==='fillDoc'?'<option value="">Choose a PDF…</option>':'';docs.forEach(d=>{const o=document.createElement('option');o.value=d.id;o.textContent=d.name;s.append(o)});if(docs.some(d=>d.id===v))s.value=v})}
function showTab(name){document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===name));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name))}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
// Backup/restore: exports the complete PDF library, including original PDF bytes and field layouts.
$('backupLibrary').onclick=async()=>{
  try{
    await allDocs();
    const backup={app:'Story Home Services PDF Filler',formatVersion:1,createdAt:new Date().toISOString(),documents:docs};
    const blob=new Blob([JSON.stringify(backup)],{type:'application/json'});
    const stamp=new Date().toISOString().slice(0,10),name=`Story_Home_Services_PDF_Backup_${stamp}.json`;
    const file=new File([blob],name,{type:'application/json'});
    if(navigator.canShare&&navigator.canShare({files:[file]})){
      try{await navigator.share({files:[file],title:'PDF Library Backup',text:'Save this backup to Google Drive or another safe location.'});toast('Backup shared. Choose Google Drive or another destination.');return}
      catch(err){if(err.name==='AbortError')return;}
    }
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
    toast('Backup downloaded. You can upload it to Google Drive.');
  }catch(err){console.error(err);toast('Could not create backup. Check available storage.');}
};
$('restoreBackup').onchange=async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    const backup=JSON.parse(await file.text());
    if(backup.app!=='Story Home Services PDF Filler'||backup.formatVersion!==1||!Array.isArray(backup.documents))throw new Error('This is not a supported Story Home Services backup.');
    const valid=backup.documents.every(d=>d&&typeof d.id==='string'&&typeof d.name==='string'&&typeof d.data==='string'&&Array.isArray(d.fields));
    if(!valid)throw new Error('The backup file is incomplete or invalid.');
    const existing=await req(db.transaction(STORE).objectStore(STORE).getAll());
    const incoming=backup.documents;
    const ok=confirm(`Restore ${incoming.length} PDF(s)? Existing PDFs will be kept. Matching backup entries will replace the same saved record.`);
    if(!ok)return;
    const tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE);
    for(const d of incoming)store.put(d);
    await new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});
    await allDocs();toast(`Restored ${incoming.length} PDF(s) and saved field layouts.`);
  }catch(err){console.error(err);toast(err.message||'Could not restore this backup.');}
  finally{e.target.value='';}
};

$('choosePdfButton').addEventListener('click',()=>{$('pdfUpload').click()});
$('pdfUpload').addEventListener('change',async e=>{
  const f=e.target.files&&e.target.files[0];
  if(!f)return;
  const isPdf=(f.type==='application/pdf'||/\\.pdf$/i.test(f.name));
  if(!isPdf){toast('Please choose a PDF file');e.target.value='';return}
  try{
    const buf=await f.arrayBuffer();
    if(!buf.byteLength)throw new Error('The selected PDF is empty.');
    const d={id:uid(),name:f.name||'Uploaded PDF.pdf',data:bytesToB64(buf),fields:[],created:Date.now()};
    await putDoc(d);
    toast('PDF added to your library');
  }catch(err){console.error(err);toast(err.message||'Could not save PDF. Device storage may be full.')}
  finally{e.target.value=''}
});
async function openEditor(id){activeDoc=docs.find(d=>d.id===id);if(!activeDoc)return;$('editorDoc').value=id;$('editorNoPdf').hidden=true;$('editorArea').hidden=false;pageNum=1;zoom=1;selectedField=null;await loadPdf();showTab('editor');renderFields()}
$('editorDoc').onchange=()=>openEditor($('editorDoc').value);
async function loadPdf(){try{pdfDoc=await pdfjsLib.getDocument({data:b64ToBytes(activeDoc.data)}).promise;await renderPage()}catch(e){toast('Unable to open this PDF')}}
async function renderPage(){if(!pdfDoc)return;const page=await pdfDoc.getPage(pageNum),vp=page.getViewport({scale:zoom});const c=$('editorCanvas'),ctx=c.getContext('2d');c.width=vp.width;c.height=vp.height;c.style.width=vp.width+'px';c.style.height=vp.height+'px';$('editorStage').style.width=vp.width+'px';$('editorStage').style.height=vp.height+'px';$('fieldOverlay').style.width=vp.width+'px';$('fieldOverlay').style.height=vp.height+'px';await page.render({canvasContext:ctx,viewport:vp}).promise;$('pageInfo').textContent=`Page ${pageNum} / ${pdfDoc.numPages}`;$('zoomLabel').textContent=Math.round(zoom*100)+'%';renderFields()}
$('prevPage').onclick=()=>{if(pageNum>1){pageNum--;renderPage()}};$('nextPage').onclick=()=>{if(pdfDoc&&pageNum<pdfDoc.numPages){pageNum++;renderPage()}};
$('zoomIn').onclick=()=>{zoom=Math.min(3,zoom+.2);renderPage()};$('zoomOut').onclick=()=>{zoom=Math.max(.5,zoom-.2);renderPage()};
$('addField').onclick=()=>{if(!activeDoc)return;const label=$('fieldLabel').value.trim()||$('fieldType').selectedOptions[0].text;const type=$('fieldType').value;const f={id:uid(),label,type,page:pageNum,x:.12,y:.15,w:type==='signature'?.34:.24,h:type==='multiline'?.10:type==='signature'?.09:.045};activeDoc.fields.push(f);selectedField=f.id;renderFields();renderFieldList();$('fieldLabel').value=''};
function renderFields(){
 const o=$('fieldOverlay');o.innerHTML='';if(!activeDoc)return;
 activeDoc.fields.filter(f=>f.page===pageNum).forEach(f=>{
  const el=document.createElement('div');
  el.className='placed-field'+(f.id===selectedField?' selected':'');
  el.style.left=(f.x*100)+'%';el.style.top=(f.y*100)+'%';el.style.width=(f.w*100)+'%';el.style.height=(f.h*100)+'%';
  const label=document.createElement('span');label.className='tiny';label.textContent=f.label+' · '+f.type;el.append(label);
  const handle=document.createElement('span');handle.className='resize-handle';handle.setAttribute('aria-label','Resize field');el.append(handle);
  el.addEventListener('pointerdown',e=>{
   if(e.target===handle)return;
   selectedField=f.id;
   const rect=o.getBoundingClientRect(),sx=e.clientX,sy=e.clientY,ox=f.x,oy=f.y;
   el.setPointerCapture(e.pointerId);
   const move=ev=>{f.x=Math.max(0,Math.min(1-f.w,ox+(ev.clientX-sx)/rect.width));f.y=Math.max(0,Math.min(1-f.h,oy+(ev.clientY-sy)/rect.height));el.style.left=f.x*100+'%';el.style.top=f.y*100+'%'};
   const up=()=>{el.removeEventListener('pointermove',move);el.removeEventListener('pointerup',up);el.removeEventListener('pointercancel',up);renderFields();};
   el.addEventListener('pointermove',move);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);e.stopPropagation();
  });
  handle.addEventListener('pointerdown',e=>{
   e.preventDefault();e.stopPropagation();selectedField=f.id;
   const rect=o.getBoundingClientRect(),sx=e.clientX,sy=e.clientY,ow=f.w,oh=f.h;
   handle.setPointerCapture(e.pointerId);
   const move=ev=>{f.w=Math.max(.035,Math.min(1-f.x,ow+(ev.clientX-sx)/rect.width));f.h=Math.max(.025,Math.min(1-f.y,oh+(ev.clientY-sy)/rect.height));el.style.width=f.w*100+'%';el.style.height=f.h*100+'%'};
   const up=()=>{handle.removeEventListener('pointermove',move);handle.removeEventListener('pointerup',up);handle.removeEventListener('pointercancel',up);renderFields();renderFieldList()};
   handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',up);handle.addEventListener('pointercancel',up);
  });
  el.addEventListener('click',()=>{selectedField=f.id;renderFields()});
  o.append(el);
 });
 renderFieldList();
}
function renderFieldList(){const root=$('fieldList');root.innerHTML='';if(!activeDoc)return;activeDoc.fields.forEach(f=>{const r=document.createElement('div');r.className='field-row';const t=document.createElement('span');t.textContent=`${f.label} — ${f.type} (page ${f.page})`;const b=document.createElement('button');b.textContent='Select';b.onclick=()=>{selectedField=f.id;pageNum=f.page;renderPage()};r.append(t,b);root.append(r)})}
$('deleteField').onclick=()=>{if(!activeDoc||!selectedField)return;activeDoc.fields=activeDoc.fields.filter(f=>f.id!==selectedField);selectedField=null;renderFields()};
$('saveLayout').onclick=async()=>{if(!activeDoc)return;await putDoc(activeDoc);toast('Field layout saved')};
function openFillDoc(id){return docs.find(d=>d.id===id)}
$('loadFill').onclick=loadFill;
function loadFill(){const d=openFillDoc($('fillDoc').value);if(!d){toast('Choose a PDF first');return}if(!d.fields?.length){toast('This PDF has no saved fields. Add fields in Field Editor first.');return}activeDoc=d;$('fillNoDoc').hidden=true;$('fillArea').hidden=false;const root=$('fillFields');root.innerHTML='';$('signatureArea').hidden=!d.fields.some(f=>f.type==='signature');d.fields.forEach(f=>{const wrap=document.createElement('div');wrap.className='fill-field';const lab=document.createElement('label');lab.textContent=f.label;let input;if(f.type==='multiline'){input=document.createElement('textarea');input.rows=3}else if(f.type==='checkbox'){input=document.createElement('input');input.type='checkbox'}else if(f.type==='signature'){input=document.createElement('div');input.textContent='Signature will be added from the signature pad below.';input.style.color='#647383'}else{input=document.createElement('input');input.type=f.type==='date'?'date':'text'}input.dataset.fieldId=f.id;if(f.type!=='signature'){wrap.append(lab,input)}else wrap.append(lab,input);root.append(wrap)});setupSignature();showTab('fill')}
let sigCtx, sigDrawing=false;
function setupSignature(){const c=$('signatureCanvas'),rect=c.getBoundingClientRect(),ratio=window.devicePixelRatio||1;c.width=Math.max(1,rect.width*ratio);c.height=150*ratio;sigCtx=c.getContext('2d');sigCtx.scale(ratio,ratio);sigCtx.lineWidth=2.2;sigCtx.lineCap='round';sigCtx.lineJoin='round';sigCtx.strokeStyle='#14283b';c.onpointerdown=e=>{sigDrawing=true;c.setPointerCapture(e.pointerId);const r=c.getBoundingClientRect();sigCtx.beginPath();sigCtx.moveTo(e.clientX-r.left,e.clientY-r.top);signatureDirty=true};c.onpointermove=e=>{if(!sigDrawing)return;const r=c.getBoundingClientRect();sigCtx.lineTo(e.clientX-r.left,e.clientY-r.top);sigCtx.stroke()};c.onpointerup=()=>sigDrawing=false}
$('clearSignature').onclick=()=>{const c=$('signatureCanvas');sigCtx.clearRect(0,0,c.width,c.height);signatureDirty=false};
let previewBlob=null,previewFileName='completed.pdf';
async function buildCompletedPdf(){
 if(!activeDoc)throw new Error('Open a form first.');
 const {PDFDocument,StandardFonts,rgb}=PDFLib;
 const pdf=await PDFDocument.load(b64ToBytes(activeDoc.data));
 const font=await pdf.embedFont(StandardFonts.Helvetica);
 const values={};
 document.querySelectorAll('#fillFields [data-field-id]').forEach(el=>{
  values[el.dataset.fieldId]=el.type==='checkbox'?el.checked:el.value;
 });
 let signatureBytes=null;
 if(signatureDirty){
  signatureBytes=await pdf.embedPng($('signatureCanvas').toDataURL('image/png'));
 }
 for(const f of activeDoc.fields){
  const page=pdf.getPages()[f.page-1];if(!page)continue;
  const {width,height}=page.getSize();
  const x=f.x*width, top=f.y*height, w=f.w*width, h=f.h*height, y=height-top-h;
  if(f.type==='signature'){
   if(signatureBytes)page.drawImage(signatureBytes,{x,y,width:w,height:h});
   continue;
  }
  const val=values[f.id];
  if(f.type==='checkbox'){
   if(val)page.drawText('X',{x:x+3,y:y+3,size:Math.min(14,Math.max(8,h*.65)),font,color:rgb(0,0,0)});
   continue;
  }
  if(val!==undefined&&String(val).length){
   const size=Math.max(7,Math.min(12,h*.55));
   const lines=String(val).split('\n');
   lines.forEach((line,i)=>{
    const baseline=height-top-size-(i*(size+2));
    if(baseline>=y-2)page.drawText(line.slice(0,180),{x:x+3,y:baseline,size,font,color:rgb(0,0,0),maxWidth:Math.max(20,w-6)});
   });
  }
 }
 const bytes=await pdf.save();
 return {blob:new Blob([bytes],{type:'application/pdf'}),name:(activeDoc.name||'document.pdf').replace(/\.pdf$/i,'')+'_completed.pdf'};
}
async function renderPdfPreview(blob){
 const host=$('pdfPreviewPages');host.innerHTML='';
 const bytes=new Uint8Array(await blob.arrayBuffer());
 if(!window.pdfjsLib)throw new Error('PDF preview library did not load. Check your internet connection and reload the app.');
 const task=pdfjsLib.getDocument({data:bytes});
 const doc=await task.promise;
 for(let n=1;n<=doc.numPages;n++){
  const page=await doc.getPage(n);
  const scale=Math.min(1.35,Math.max(.75,(host.clientWidth-24)/page.getViewport({scale:1}).width));
  const viewport=page.getViewport({scale});
  const canvas=document.createElement('canvas');canvas.className='preview-page-canvas';
  canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
  canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';
  host.append(canvas);
  await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;
 }
}
async function showPdfPreview(){
 try{
  const result=await buildCompletedPdf();
  previewBlob=result.blob;previewFileName=result.name;
  $('previewFileName').value=result.name;
  $('pdfPreviewModal').hidden=false;
  await renderPdfPreview(result.blob);
 }catch(e){console.error(e);$('pdfPreviewPages').innerHTML='';toast(e.message||'Could not build PDF preview.')}
}
function cleanPdfName(value){
 let name=String(value||'completed.pdf').trim().replace(/[\\/:*?"<>|]/g,'_');
 if(!name)name='completed.pdf';
 if(!/\.pdf$/i.test(name))name+='.pdf';
 return name;
}
async function deliverPdf(blob,name){
 // In the Android wrapper, use the native Storage Access Framework picker.
 if(window.AndroidSave&&typeof window.AndroidSave.savePdf==='function'){
  try{
   const bytes=new Uint8Array(await blob.arrayBuffer());
   let binary='';const chunk=0x8000;
   for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
   const base64=btoa(binary);
   window.AndroidSave.savePdf(base64,name);
   toast('Choose a phone folder or Google Drive location in the Android picker.');
   return;
  }catch(err){console.error('Native folder picker failed:',err);alert('Could not open Android folder picker.');return}
 }
 // Browser/PWA fallback: Android share sheet, then a normal download.
 const file=new File([blob],name,{type:'application/pdf'});
 if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
  try{await navigator.share({files:[file],title:name,text:'Save this completed PDF to your phone or Google Drive.'});return}
  catch(err){if(err.name==='AbortError')return;console.warn(err)}
 }
 const url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=name;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),60000);
 toast('Download started. For direct folder selection, install the Android wrapper version.');
}
let pendingSaveBlob=null;
function openSaveDialog(blob,name){
 pendingSaveBlob=blob;$('saveFileName').value=name;$('savePdfModal').hidden=false;
}
async function saveFromDialog(){
 if(!pendingSaveBlob){toast('Create the completed PDF again.');return}
 const name=cleanPdfName($('saveFileName').value),blob=pendingSaveBlob;
 pendingSaveBlob=null;$('savePdfModal').hidden=true;
 await deliverPdf(blob,name);
}
async function downloadCompletedPdf(){
 if(!previewBlob){toast('Create a preview first.');return}
 openSaveDialog(previewBlob,$('previewFileName').value||previewFileName);
}
async function exportPdf(){
 try{
  const result=await buildCompletedPdf();previewBlob=result.blob;previewFileName=result.name;
  openSaveDialog(result.blob,result.name);
 }catch(e){console.error(e);toast(e.message||'Could not create PDF. Please try again.')}
}
$('previewPdf').onclick=showPdfPreview;
$('closePreview').onclick=()=>{$('pdfPreviewModal').hidden=true};
$('downloadFromPreview').onclick=downloadCompletedPdf;
$('exportPdf').onclick=exportPdf;
$('closeSaveDialog').onclick=()=>{$('savePdfModal').hidden=true;pendingSaveBlob=null};
$('confirmSavePdf').onclick=saveFromDialog;

// Ask before leaving the app using the Android/browser Back navigation.
// A generic browser prompt is used for closing/reloading because browsers do not
// permit custom text in beforeunload dialogs.
(function protectAppExit(){
 let allowExit=false;
 try{history.pushState({shsAppPage:true},'',location.href)}catch(e){}
 window.addEventListener('popstate',()=>{
  if(allowExit)return;
  const leave=confirm('Are you sure you want to exit Story Home Services PDF Filler?');
  if(leave){allowExit=true;history.back();}
  else{try{history.pushState({shsAppPage:true},'',location.href)}catch(e){}}
 });
 window.addEventListener('beforeunload',e=>{
  if(allowExit)return;
  e.preventDefault();e.returnValue='';
 });
})();
async function init(){try{db=await openDB();await allDocs()}catch(e){toast('This browser does not support local PDF storage')}if('serviceWorker'in navigator){navigator.serviceWorker.register('./sw.js').catch(()=>{})}}
init();