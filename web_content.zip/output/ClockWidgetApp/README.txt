1. Otvori folder ClockWidgetApp u Android Studiju.
2. Sačekaj Gradle sync.
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
5. Za temperaturu ubaci OpenWeather API ključ u clock-widget.html: const API_KEY="TVOJ_KLJUC";
