@echo off
setlocal
set "ROOT=%~dp0"
set "WRAPPER=%ROOT%gradle\wrapper\gradle-wrapper.jar"
if not exist "%WRAPPER%" (
  echo Baixando componente oficial Gradle Wrapper 8.10.2...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.10.2-wrapper.jar' -OutFile '%WRAPPER%' -ErrorAction Stop } catch { Write-Error $_; exit 1 }"
  if errorlevel 1 exit /b 1
)
java -classpath "%WRAPPER%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
