package br.com.nossomercadao.coletor;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private ValueCallback<Uri[]> pendingFile;
    private ActivityResultLauncher<Intent> scannerLauncher;
    private ActivityResultLauncher<Intent> fileLauncher;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        scannerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                String code = result.getData().getStringExtra("barcode");
                if(code != null && web != null) web.evaluateJavascript("window.onNativeBarcodeScanned(" + JSONObject.quote(code) + ")", null);
            }
        });
        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if(pendingFile!=null){
                Uri uri=(result.getResultCode()==RESULT_OK && result.getData()!=null)?result.getData().getData():null;
                pendingFile.onReceiveValue(uri==null?null:new Uri[]{uri});pendingFile=null;
            }
        });
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){return true;}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(pendingFile!=null)pendingFile.onReceiveValue(null);
                pendingFile=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                fileLauncher.launch(i);
                return true;
            }
        });
        web.addJavascriptInterface(new NativeBridge(),"AndroidCartazes");
        web.loadUrl("file:///android_asset/index.html");
    }
    public class NativeBridge{
        @JavascriptInterface public void scan(){runOnUiThread(()->scannerLauncher.launch(new Intent(MainActivity.this,ScannerActivity.class)));}
        @JavascriptInterface public void print(){runOnUiThread(()->{
            try{
                PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                manager.print("Cartazes Nosso Mercadão",web.createPrintDocumentAdapter("Cartazes Nosso Mercadão"),null);
            }catch(Exception e){Toast.makeText(MainActivity.this,"Erro na impressão: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        });}
    }
    @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(pendingFile!=null){pendingFile.onReceiveValue(null);pendingFile=null;}if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
