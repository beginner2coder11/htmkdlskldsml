package br.com.nossomercadao.coletor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScannerActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 104;
    private final AtomicBoolean finished = new AtomicBoolean(false);
    private ExecutorService analysisExecutor;
    private BarcodeScanner detector;
    private ProcessCameraProvider cameraProvider;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_scanner);
        findViewById(R.id.cancel).setOnClickListener(v -> finish());
        analysisExecutor = Executors.newSingleThreadExecutor();
        BarcodeScannerOptions opts = new BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128).build();
        detector = BarcodeScanning.getClient(opts);
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int code, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if(code == CAMERA_REQUEST) {
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) startCamera();
            else {Toast.makeText(this,"Permita o acesso à câmera nas configurações para escanear.",Toast.LENGTH_LONG).show();finish();}
        }
    }
    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            if(isFinishing() || isDestroyed())return;
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(((PreviewView)findViewById(R.id.preview)).getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(analysisExecutor, this::analyze);
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            } catch(Exception e) {
                ((TextView)findViewById(R.id.tip)).setText("Não foi possível iniciar a câmera: " + e.getMessage());
            }
        },ContextCompat.getMainExecutor(this));
    }
    @androidx.camera.core.ExperimentalGetImage
    private void analyze(ImageProxy frame) {
        if(finished.get()){frame.close();return;}
        android.media.Image image = frame.getImage();
        if(image==null){frame.close();return;}
        InputImage input = InputImage.fromMediaImage(image, frame.getImageInfo().getRotationDegrees());
        detector.process(input).addOnSuccessListener(codes -> {
            for(Barcode b:codes){
                String value=b.getRawValue();
                if(value!=null && value.matches("[0-9]{6,20}") && finished.compareAndSet(false,true)) {
                    Intent result=new Intent();result.putExtra("barcode",value);
                    setResult(RESULT_OK,result);
                    finish();break;
                }
            }
        }).addOnFailureListener(e -> { /* tenta o próximo quadro */ }).addOnCompleteListener(task -> frame.close());
    }
    @Override protected void onDestroy(){
        if(cameraProvider!=null) cameraProvider.unbindAll();
        if(detector!=null) detector.close();
        if(analysisExecutor!=null) analysisExecutor.shutdown();
        super.onDestroy();
    }
}
