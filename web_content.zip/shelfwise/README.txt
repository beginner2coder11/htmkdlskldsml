SHELFWISE - Free KDP Market Research App

HOW TO USE
1. Unzip this folder.
2. Open index.html in Chrome (phone or computer). Internet connection required.
3. Type a niche on the Research tab and tap "Scan this niche".

OPTIONAL
- Tools tab: add a free Gemini key (aistudio.google.com) or a Claude key for AI titles and market briefs.
- Tools tab: turn on the CORS relay if a source is blocked on your device.
- Research tab: paste competitor Best Sellers Ranks for more accurate scores.

DATA
Everything is saved on your device only (browser storage).
Back up your shelf from the Shelf tab.
