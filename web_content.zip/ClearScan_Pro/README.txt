ClearScan Pro — Android-ready browser prototype
===============================================

What is included
- Camera capture and multi-photo import
- Page thumbnails and page removal
- Original, grayscale, high-contrast and brighten filters
- OCR for printed English text using Tesseract.js
- Export combined multi-page PDF
- Export enhanced page images as JPG
- Export OCR text to editable DOCX and XLSX
- Edit OCR output before exporting and download TXT

Important limitations
- This is a functional browser prototype, NOT a compiled native Android APK.
- Automatic edge detection/perspective correction, offline OCR, advanced table reconstruction,
  handwriting OCR and native Android integration are not implemented.
- Export/OCR libraries load from CDNs, so internet access is needed.
- OCR and table recognition can make mistakes; proofread the output.
- Images are processed in the browser session; exported files are downloaded by your browser.

How to try on your Samsung Galaxy A15
1. Transfer index.html to the phone (USB, Drive, email, etc.).
2. For reliable camera access and library loading, the app should be opened from a secure HTTPS
   website. Opening the file directly may limit camera access and some browser features.
3. To use as a proper installable web app, host the files on an HTTPS static host and add the
   site to Chrome > menu (⋮) > Add to Home screen.
4. Tap Scan with camera or Import photos, then choose an export format.
5. In Chrome, downloads normally appear in My Files > Downloads.

Native APK build
The supplied package does not contain an APK. A signed APK requires Android build tooling,
a native Android project, dependency resolution, and signing. This environment cannot compile
and test a native APK. Do not install APKs from untrusted sources.
