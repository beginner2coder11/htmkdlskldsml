import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'ba.digitalnisat.app', appName: 'Digitalni Sat', webDir: 'www', android: { backgroundColor: '#020d0b' } };
export default config;
