# Digitalni sat — fullscreen verzija

Aplikacija je prilagođena za prikaz preko cijelog ekrana: koristi cijelu širinu i visinu ekrana, a pri prvom dodiru praznog dijela aplikacije pokušava sakriti sistemske trake u podržanom Android WebView-u.

## APK

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

U Android Studio: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.

Napomena: za potpuno pouzdan trajni immersive/fullscreen režim bez Android navigacione trake, nakon komande `npx cap add android` u Android Studio postavi immersive mode u native Android dijelu. Web dio već koristi cijeli raspoloživi ekran i traži fullscreen na prvi korisnički dodir.
